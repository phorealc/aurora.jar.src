package javazoom.jl.decoder;

public interface DecoderErrors extends JavaLayerErrors {
  public static final int UNKNOWN_ERROR = 512;
  
  public static final int UNSUPPORTED_LAYER = 513;
  
  public static final int ILLEGAL_SUBBAND_ALLOCATION = 514;
}


/* Location:              C:\Users\rapha\Downloads\aurora.jar!\META-INF\jars\jlayer-1.0.1.jar!\javazoom\jl\decoder\DecoderErrors.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */