package javazoom.jl.decoder;

public class JavaLayerError extends Error {}


/* Location:              C:\Users\rapha\Downloads\aurora.jar!\META-INF\jars\jlayer-1.0.1.jar!\javazoom\jl\decoder\JavaLayerError.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */