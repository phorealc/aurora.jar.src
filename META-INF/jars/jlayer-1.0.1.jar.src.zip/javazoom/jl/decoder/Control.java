package javazoom.jl.decoder;

public interface Control {
  void start();
  
  void stop();
  
  boolean isPlaying();
  
  void pause();
  
  boolean isRandomAccess();
  
  double getPosition();
  
  void setPosition(double paramDouble);
}


/* Location:              C:\Users\rapha\Downloads\aurora.jar!\META-INF\jars\jlayer-1.0.1.jar!\javazoom\jl\decoder\Control.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */