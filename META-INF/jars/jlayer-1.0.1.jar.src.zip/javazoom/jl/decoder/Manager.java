package javazoom.jl.decoder;

public class Manager {
  public void addControl(Control c) {}
  
  public void removeControl(Control c) {}
  
  public void removeAll() {}
}


/* Location:              C:\Users\rapha\Downloads\aurora.jar!\META-INF\jars\jlayer-1.0.1.jar!\javazoom\jl\decoder\Manager.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */