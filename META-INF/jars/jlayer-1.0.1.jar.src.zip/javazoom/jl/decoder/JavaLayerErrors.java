package javazoom.jl.decoder;

public interface JavaLayerErrors {
  public static final int BITSTREAM_ERROR = 256;
  
  public static final int DECODER_ERROR = 512;
}


/* Location:              C:\Users\rapha\Downloads\aurora.jar!\META-INF\jars\jlayer-1.0.1.jar!\javazoom\jl\decoder\JavaLayerErrors.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */