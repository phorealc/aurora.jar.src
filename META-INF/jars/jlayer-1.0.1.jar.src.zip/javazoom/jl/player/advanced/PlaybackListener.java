package javazoom.jl.player.advanced;

public abstract class PlaybackListener {
  public void playbackStarted(PlaybackEvent evt) {}
  
  public void playbackFinished(PlaybackEvent evt) {}
}


/* Location:              C:\Users\rapha\Downloads\aurora.jar!\META-INF\jars\jlayer-1.0.1.jar!\javazoom\jl\player\advanced\PlaybackListener.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */