/*   */ package org.jcodec.common;
/*   */ 
/*   */ public class SoundUtil {
/*   */   public static AudioFormat fromJavaX(AudioFormat af) {
/* 5 */     return null;
/*   */   }
/*   */   
/*   */   public static AudioFormat toJavax(AudioFormat format) {
/* 9 */     return null;
/*   */   }
/*   */ }


/* Location:              C:\Users\rapha\Downloads\aurora.jar!\META-INF\jars\jcodec-javase-0.2.5.jar!\org\jcodec\common\SoundUtil.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */