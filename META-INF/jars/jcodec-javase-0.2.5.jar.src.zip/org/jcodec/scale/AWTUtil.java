/*     */ package org.jcodec.scale;
/*     */ 
/*     */ import java.awt.image.BufferedImage;
/*     */ import java.awt.image.DataBufferByte;
/*     */ import java.io.File;
/*     */ import java.io.IOException;
/*     */ import javax.imageio.ImageIO;
/*     */ import org.jcodec.common.DemuxerTrackMeta;
/*     */ import org.jcodec.common.model.ColorSpace;
/*     */ import org.jcodec.common.model.Picture;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class AWTUtil
/*     */ {
/*     */   public static BufferedImage toBufferedImage(Picture src) {
/*  28 */     if (src.getColor() != ColorSpace.BGR) {
/*  29 */       Picture bgr = Picture.createCropped(src.getWidth(), src.getHeight(), ColorSpace.BGR, src.getCrop());
/*  30 */       if (src.getColor() == ColorSpace.RGB) {
/*  31 */         (new RgbToBgr()).transform(src, bgr);
/*     */       } else {
/*  33 */         Transform transform = ColorUtil.getTransform(src.getColor(), ColorSpace.RGB);
/*  34 */         transform.transform(src, bgr);
/*  35 */         (new RgbToBgr()).transform(bgr, bgr);
/*     */       } 
/*  37 */       src = bgr;
/*     */     } 
/*     */     
/*  40 */     BufferedImage dst = new BufferedImage(src.getCroppedWidth(), src.getCroppedHeight(), 5);
/*     */ 
/*     */     
/*  43 */     if (src.getCrop() == null) {
/*  44 */       toBufferedImage(src, dst);
/*     */     } else {
/*  46 */       toBufferedImageCropped(src, dst);
/*     */     } 
/*  48 */     return dst;
/*     */   }
/*     */   
/*     */   public static BufferedImage toBufferedImage(Picture src, DemuxerTrackMeta.Orientation orientation) {
/*  52 */     if (src.getColor() != ColorSpace.BGR) {
/*  53 */       Picture bgr = Picture.createCropped(src.getWidth(), src.getHeight(), ColorSpace.BGR, src.getCrop());
/*  54 */       if (src.getColor() == ColorSpace.RGB) {
/*  55 */         (new RgbToBgr()).transform(src, bgr);
/*     */       } else {
/*  57 */         Transform transform = ColorUtil.getTransform(src.getColor(), ColorSpace.RGB);
/*  58 */         transform.transform(src, bgr);
/*  59 */         (new RgbToBgr()).transform(bgr, bgr);
/*     */       } 
/*  61 */       src = bgr;
/*     */     } 
/*     */     
/*  64 */     BufferedImage dst = new BufferedImage(src.getCroppedWidth(), src.getCroppedHeight(), 5);
/*     */ 
/*     */     
/*  67 */     if (src.getCrop() == null) {
/*  68 */       toBufferedImage(src, dst);
/*     */     } else {
/*  70 */       toBufferedImageCropped(src, dst);
/*     */     } 
/*  72 */     if (orientation.equals(DemuxerTrackMeta.Orientation.D_90))
/*  73 */       return rotate90ToRight(dst); 
/*  74 */     if (orientation.equals(DemuxerTrackMeta.Orientation.D_180))
/*  75 */       return rotate180(dst); 
/*  76 */     if (orientation.equals(DemuxerTrackMeta.Orientation.D_270)) {
/*  77 */       return rotate90ToLeft(dst);
/*     */     }
/*  79 */     return dst;
/*     */   }
/*     */   
/*     */   public static BufferedImage rotate90ToRight(BufferedImage inputImage) {
/*  83 */     int width = inputImage.getWidth();
/*  84 */     int height = inputImage.getHeight();
/*  85 */     BufferedImage returnImage = new BufferedImage(height, width, inputImage.getType());
/*     */     
/*  87 */     for (int x = 0; x < width; x++) {
/*  88 */       for (int y = 0; y < height; y++) {
/*  89 */         returnImage.setRGB(height - y - 1, x, inputImage.getRGB(x, y));
/*     */       }
/*     */     } 
/*  92 */     return returnImage;
/*     */   }
/*     */   
/*     */   public static BufferedImage rotate180(BufferedImage inputImage) {
/*  96 */     int width = inputImage.getWidth();
/*  97 */     int height = inputImage.getHeight();
/*  98 */     BufferedImage returnImage = new BufferedImage(width, height, inputImage.getType());
/*     */     
/* 100 */     for (int x = 0; x < width; x++) {
/* 101 */       for (int y = 0; y < height; y++) {
/* 102 */         returnImage.setRGB(width - x - 1, height - y - 1, inputImage.getRGB(x, y));
/*     */       }
/*     */     } 
/* 105 */     return returnImage;
/*     */   }
/*     */   
/*     */   public static BufferedImage rotate90ToLeft(BufferedImage inputImage) {
/* 109 */     int width = inputImage.getWidth();
/* 110 */     int height = inputImage.getHeight();
/* 111 */     BufferedImage returnImage = new BufferedImage(height, width, inputImage.getType());
/*     */     
/* 113 */     for (int x = 0; x < width; x++) {
/* 114 */       for (int y = 0; y < height; y++) {
/* 115 */         returnImage.setRGB(y, width - x - 1, inputImage.getRGB(x, y));
/*     */       }
/*     */     } 
/* 118 */     return returnImage;
/*     */   }
/*     */   
/*     */   private static void toBufferedImageCropped(Picture src, BufferedImage dst) {
/* 122 */     byte[] data = ((DataBufferByte)dst.getRaster().getDataBuffer()).getData();
/* 123 */     byte[] srcData = src.getPlaneData(0);
/* 124 */     int dstStride = dst.getWidth() * 3;
/* 125 */     int srcStride = src.getWidth() * 3;
/* 126 */     for (int line = 0, srcOff = 0, dstOff = 0; line < dst.getHeight(); line++) {
/* 127 */       for (int id = dstOff, is = srcOff; id < dstOff + dstStride; id += 3, is += 3) {
/*     */         
/* 129 */         data[id] = (byte)(srcData[is] + 128);
/* 130 */         data[id + 1] = (byte)(srcData[is + 1] + 128);
/* 131 */         data[id + 2] = (byte)(srcData[is + 2] + 128);
/*     */       } 
/* 133 */       srcOff += srcStride;
/* 134 */       dstOff += dstStride;
/*     */     } 
/*     */   }
/*     */   
/*     */   public static void toBufferedImage(Picture src, BufferedImage dst) {
/* 139 */     byte[] data = ((DataBufferByte)dst.getRaster().getDataBuffer()).getData();
/* 140 */     byte[] srcData = src.getPlaneData(0);
/* 141 */     for (int i = 0; i < data.length; i++)
/*     */     {
/* 143 */       data[i] = (byte)(srcData[i] + 128);
/*     */     }
/*     */   }
/*     */   
/*     */   public static Picture fromBufferedImage(BufferedImage src, ColorSpace tgtColor) {
/* 148 */     Picture rgb = fromBufferedImageRGB(src);
/* 149 */     Transform tr = ColorUtil.getTransform(rgb.getColor(), tgtColor);
/* 150 */     Picture res = Picture.create(rgb.getWidth(), rgb.getHeight(), tgtColor);
/* 151 */     tr.transform(rgb, res);
/* 152 */     return res;
/*     */   }
/*     */   
/*     */   public static Picture fromBufferedImageRGB(BufferedImage src) {
/* 156 */     Picture dst = Picture.create(src.getWidth(), src.getHeight(), ColorSpace.RGB);
/* 157 */     fromBufferedImage(src, dst);
/* 158 */     return dst;
/*     */   }
/*     */   
/*     */   public static void fromBufferedImage(BufferedImage src, Picture dst) {
/* 162 */     byte[] dstData = dst.getPlaneData(0);
/*     */     
/* 164 */     int off = 0;
/* 165 */     for (int i = 0; i < src.getHeight(); i++) {
/* 166 */       for (int j = 0; j < src.getWidth(); j++) {
/* 167 */         int rgb1 = src.getRGB(j, i);
/* 168 */         dstData[off++] = (byte)((rgb1 >> 16 & 0xFF) - 128);
/* 169 */         dstData[off++] = (byte)((rgb1 >> 8 & 0xFF) - 128);
/* 170 */         dstData[off++] = (byte)((rgb1 & 0xFF) - 128);
/*     */       } 
/*     */     } 
/*     */   }
/*     */   
/*     */   public static void savePicture(Picture pic, String format, File file) throws IOException {
/* 176 */     ImageIO.write(toBufferedImage(pic), format, file);
/*     */   }
/*     */ }


/* Location:              C:\Users\rapha\Downloads\aurora.jar!\META-INF\jars\jcodec-javase-0.2.5.jar!\org\jcodec\scale\AWTUtil.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */