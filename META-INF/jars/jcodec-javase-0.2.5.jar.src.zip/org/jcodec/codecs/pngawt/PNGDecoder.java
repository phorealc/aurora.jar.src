/*    */ package org.jcodec.codecs.pngawt;
/*    */ 
/*    */ import java.awt.image.BufferedImage;
/*    */ import java.io.ByteArrayInputStream;
/*    */ import java.io.IOException;
/*    */ import java.nio.ByteBuffer;
/*    */ import javax.imageio.ImageIO;
/*    */ import org.jcodec.common.VideoCodecMeta;
/*    */ import org.jcodec.common.VideoDecoder;
/*    */ import org.jcodec.common.io.NIOUtils;
/*    */ import org.jcodec.common.model.ColorSpace;
/*    */ import org.jcodec.common.model.Picture;
/*    */ import org.jcodec.common.model.Size;
/*    */ import org.jcodec.scale.AWTUtil;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class PNGDecoder
/*    */   extends VideoDecoder
/*    */ {
/*    */   public Picture decodeFrame(ByteBuffer data, byte[][] buffer) {
/*    */     try {
/* 28 */       BufferedImage rgb = ImageIO.read(new ByteArrayInputStream(NIOUtils.toArray(data)));
/* 29 */       return AWTUtil.fromBufferedImageRGB(rgb);
/* 30 */     } catch (IOException e) {
/* 31 */       return null;
/*    */     } 
/*    */   }
/*    */ 
/*    */   
/*    */   public VideoCodecMeta getCodecMeta(ByteBuffer data) {
/*    */     try {
/* 38 */       BufferedImage rgb = ImageIO.read(new ByteArrayInputStream(NIOUtils.toArray(data)));
/* 39 */       return VideoCodecMeta.createSimpleVideoCodecMeta(new Size(rgb.getWidth(), rgb.getHeight()), ColorSpace.RGB);
/* 40 */     } catch (IOException e) {
/* 41 */       return null;
/*    */     } 
/*    */   }
/*    */ }


/* Location:              C:\Users\rapha\Downloads\aurora.jar!\META-INF\jars\jcodec-javase-0.2.5.jar!\org\jcodec\codecs\pngawt\PNGDecoder.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */