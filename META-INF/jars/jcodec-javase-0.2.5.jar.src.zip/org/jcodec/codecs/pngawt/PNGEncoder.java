/*    */ package org.jcodec.codecs.pngawt;
/*    */ 
/*    */ import java.awt.image.BufferedImage;
/*    */ import java.io.ByteArrayOutputStream;
/*    */ import java.io.IOException;
/*    */ import java.nio.ByteBuffer;
/*    */ import javax.imageio.ImageIO;
/*    */ import org.jcodec.common.VideoEncoder;
/*    */ import org.jcodec.common.model.ColorSpace;
/*    */ import org.jcodec.common.model.Picture;
/*    */ import org.jcodec.scale.AWTUtil;
/*    */ import org.jcodec.scale.RgbToBgr;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class PNGEncoder
/*    */   extends VideoEncoder
/*    */ {
/*    */   private BufferedImage bi;
/*    */   private RgbToBgr rgbToBgr;
/*    */   
/*    */   public VideoEncoder.EncodedFrame encodeFrame(Picture _pic, ByteBuffer _out) {
/* 30 */     Picture pic = _pic.cropped();
/* 31 */     if (this.bi == null) {
/* 32 */       this.bi = new BufferedImage(pic.getWidth(), pic.getHeight(), 5);
/*    */     }
/* 34 */     if (this.rgbToBgr == null) {
/* 35 */       this.rgbToBgr = new RgbToBgr();
/*    */     }
/* 37 */     if (pic.getColor() == ColorSpace.RGB) {
/* 38 */       this.rgbToBgr.transform(pic, pic);
/* 39 */     } else if (pic.getColor() != ColorSpace.BGR) {
/* 40 */       throw new IllegalArgumentException("Unsupported input color space: " + pic.getColor());
/*    */     } 
/* 42 */     AWTUtil.toBufferedImage(pic, this.bi);
/* 43 */     ByteArrayOutputStream baos = new ByteArrayOutputStream();
/*    */     try {
/* 45 */       ImageIO.write(this.bi, "png", baos);
/* 46 */     } catch (IOException e) {
/* 47 */       e.printStackTrace();
/*    */     } 
/* 49 */     return new VideoEncoder.EncodedFrame(ByteBuffer.wrap(baos.toByteArray()), true);
/*    */   }
/*    */ 
/*    */   
/*    */   public ColorSpace[] getSupportedColorSpaces() {
/* 54 */     return new ColorSpace[] { ColorSpace.RGB };
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public int estimateBufferSize(Picture frame) {
/* 60 */     return frame.getWidth() * frame.getHeight() * 3;
/*    */   }
/*    */ }


/* Location:              C:\Users\rapha\Downloads\aurora.jar!\META-INF\jars\jcodec-javase-0.2.5.jar!\org\jcodec\codecs\pngawt\PNGEncoder.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */