/*    */ package org.jcodec.api.awt;
/*    */ 
/*    */ import java.awt.image.BufferedImage;
/*    */ import java.io.Closeable;
/*    */ import java.io.File;
/*    */ import java.io.IOException;
/*    */ import javax.imageio.ImageIO;
/*    */ import org.jcodec.common.Codec;
/*    */ import org.jcodec.common.MuxerTrack;
/*    */ import org.jcodec.common.VideoCodecMeta;
/*    */ import org.jcodec.common.io.NIOUtils;
/*    */ import org.jcodec.common.io.SeekableByteChannel;
/*    */ import org.jcodec.common.model.ColorSpace;
/*    */ import org.jcodec.common.model.Packet;
/*    */ import org.jcodec.common.model.Size;
/*    */ import org.jcodec.containers.mp4.Brand;
/*    */ import org.jcodec.containers.mp4.MP4Packet;
/*    */ import org.jcodec.containers.mp4.muxer.MP4Muxer;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class SequenceMuxer
/*    */ {
/*    */   private SeekableByteChannel ch;
/*    */   private MuxerTrack outTrack;
/*    */   private int frameNo;
/*    */   private MP4Muxer muxer;
/*    */   private Size size;
/*    */   
/*    */   public SequenceMuxer(File out) throws IOException {
/* 36 */     this.ch = (SeekableByteChannel)NIOUtils.writableChannel(out);
/*    */ 
/*    */     
/* 39 */     this.muxer = MP4Muxer.createMP4Muxer(this.ch, Brand.MP4);
/*    */   }
/*    */ 
/*    */   
/*    */   public void encodeImage(File png) throws IOException {
/* 44 */     if (this.size == null) {
/* 45 */       BufferedImage read = ImageIO.read(png);
/* 46 */       this.size = new Size(read.getWidth(), read.getHeight());
/*    */       
/* 48 */       this.outTrack = this.muxer.addVideoTrack(Codec.PNG, VideoCodecMeta.createSimpleVideoCodecMeta(this.size, ColorSpace.RGB));
/*    */     } 
/*    */     
/* 51 */     this.outTrack.addFrame((Packet)MP4Packet.createMP4Packet(NIOUtils.fetchFromFile(png), this.frameNo, 25, 1L, this.frameNo, Packet.FrameType.KEY, null, this.frameNo, this.frameNo, 0));
/*    */ 
/*    */     
/* 54 */     this.frameNo++;
/*    */   }
/*    */ 
/*    */   
/*    */   public void finish() throws IOException {
/* 59 */     this.muxer.finish();
/* 60 */     NIOUtils.closeQuietly((Closeable)this.ch);
/*    */   }
/*    */ }


/* Location:              C:\Users\rapha\Downloads\aurora.jar!\META-INF\jars\jcodec-javase-0.2.5.jar!\org\jcodec\api\awt\SequenceMuxer.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */