/*    */ package org.jcodec.api.awt;
/*    */ 
/*    */ import java.awt.image.BufferedImage;
/*    */ import java.io.File;
/*    */ import java.io.IOException;
/*    */ import org.jcodec.api.SequenceEncoder;
/*    */ import org.jcodec.common.Codec;
/*    */ import org.jcodec.common.Format;
/*    */ import org.jcodec.common.io.NIOUtils;
/*    */ import org.jcodec.common.io.SeekableByteChannel;
/*    */ import org.jcodec.common.model.Rational;
/*    */ import org.jcodec.scale.AWTUtil;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class AWTSequenceEncoder
/*    */   extends SequenceEncoder
/*    */ {
/*    */   public AWTSequenceEncoder(SeekableByteChannel out, Rational fps) throws IOException {
/* 25 */     super(out, fps, Format.MOV, Codec.H264, null);
/*    */   }
/*    */   
/*    */   public static AWTSequenceEncoder createSequenceEncoder(File out, int fps) throws IOException {
/* 29 */     return new AWTSequenceEncoder((SeekableByteChannel)NIOUtils.writableChannel(out), Rational.R(fps, 1));
/*    */   }
/*    */   
/*    */   public static AWTSequenceEncoder create25Fps(File out) throws IOException {
/* 33 */     return new AWTSequenceEncoder((SeekableByteChannel)NIOUtils.writableChannel(out), Rational.R(25, 1));
/*    */   }
/*    */   
/*    */   public static AWTSequenceEncoder create30Fps(File out) throws IOException {
/* 37 */     return new AWTSequenceEncoder((SeekableByteChannel)NIOUtils.writableChannel(out), Rational.R(30, 1));
/*    */   }
/*    */   
/*    */   public static AWTSequenceEncoder create2997Fps(File out) throws IOException {
/* 41 */     return new AWTSequenceEncoder((SeekableByteChannel)NIOUtils.writableChannel(out), Rational.R(30000, 1001));
/*    */   }
/*    */   
/*    */   public static AWTSequenceEncoder create24Fps(File out) throws IOException {
/* 45 */     return new AWTSequenceEncoder((SeekableByteChannel)NIOUtils.writableChannel(out), Rational.R(24, 1));
/*    */   }
/*    */   
/*    */   public void encodeImage(BufferedImage bi) throws IOException {
/* 49 */     encodeNativeFrame(AWTUtil.fromBufferedImageRGB(bi));
/*    */   }
/*    */ }


/* Location:              C:\Users\rapha\Downloads\aurora.jar!\META-INF\jars\jcodec-javase-0.2.5.jar!\org\jcodec\api\awt\AWTSequenceEncoder.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */