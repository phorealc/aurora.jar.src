/*     */ package org.jcodec.api.awt;
/*     */ 
/*     */ import java.awt.image.BufferedImage;
/*     */ import java.io.Closeable;
/*     */ import java.io.File;
/*     */ import java.io.IOException;
/*     */ import org.jcodec.api.FrameGrab;
/*     */ import org.jcodec.api.JCodecException;
/*     */ import org.jcodec.api.PictureWithMetadata;
/*     */ import org.jcodec.api.specific.ContainerAdaptor;
/*     */ import org.jcodec.common.SeekableDemuxerTrack;
/*     */ import org.jcodec.common.io.FileChannelWrapper;
/*     */ import org.jcodec.common.io.NIOUtils;
/*     */ import org.jcodec.common.io.SeekableByteChannel;
/*     */ import org.jcodec.common.model.Picture;
/*     */ import org.jcodec.scale.AWTUtil;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class AWTFrameGrab
/*     */   extends FrameGrab
/*     */ {
/*     */   public static AWTFrameGrab createAWTFrameGrab(SeekableByteChannel _in) throws IOException, JCodecException {
/*  39 */     FrameGrab fg = FrameGrab.createFrameGrab(_in);
/*  40 */     return new AWTFrameGrab(fg.getVideoTrack(), fg.getDecoder());
/*     */   }
/*     */   
/*     */   public AWTFrameGrab(SeekableDemuxerTrack videoTrack, ContainerAdaptor decoder) {
/*  44 */     super(videoTrack, decoder);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static BufferedImage getFrame(File file, double second) throws IOException, JCodecException {
/*  57 */     FileChannelWrapper ch = null;
/*     */     try {
/*  59 */       ch = NIOUtils.readableChannel(file);
/*  60 */       return ((AWTFrameGrab)createAWTFrameGrab((SeekableByteChannel)ch).seekToSecondPrecise(second)).getFrameWithOrientation();
/*     */     } finally {
/*  62 */       NIOUtils.closeQuietly((Closeable)ch);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static BufferedImage getFrame(SeekableByteChannel file, double second) throws JCodecException, IOException {
/*  76 */     return ((AWTFrameGrab)createAWTFrameGrab(file).seekToSecondPrecise(second)).getFrame();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public BufferedImage getFrame() throws IOException {
/*  86 */     Picture nativeFrame = getNativeFrame();
/*  87 */     return (nativeFrame == null) ? null : AWTUtil.toBufferedImage(nativeFrame);
/*     */   }
/*     */   
/*     */   public BufferedImage getFrameWithOrientation() throws IOException {
/*  91 */     PictureWithMetadata nativeFrame = getNativeFrameWithMetadata();
/*  92 */     return (nativeFrame == null) ? null : AWTUtil.toBufferedImage(nativeFrame.getPicture(), nativeFrame.getOrientation());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static BufferedImage getFrame(File file, int frameNumber) throws IOException, JCodecException {
/* 105 */     FileChannelWrapper ch = null;
/*     */     try {
/* 107 */       ch = NIOUtils.readableChannel(file);
/* 108 */       return ((AWTFrameGrab)createAWTFrameGrab((SeekableByteChannel)ch).seekToFramePrecise(frameNumber)).getFrame();
/*     */     } finally {
/* 110 */       NIOUtils.closeQuietly((Closeable)ch);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static BufferedImage getFrame(SeekableByteChannel file, int frameNumber) throws JCodecException, IOException {
/* 124 */     return ((AWTFrameGrab)createAWTFrameGrab(file).seekToFramePrecise(frameNumber)).getFrame();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static BufferedImage getFrame(SeekableDemuxerTrack vt, ContainerAdaptor decoder, int frameNumber) throws IOException, JCodecException {
/* 139 */     return ((AWTFrameGrab)(new AWTFrameGrab(vt, decoder)).seekToFramePrecise(frameNumber)).getFrame();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static BufferedImage getFrame(SeekableDemuxerTrack vt, ContainerAdaptor decoder, double second) throws IOException, JCodecException {
/* 154 */     return ((AWTFrameGrab)(new AWTFrameGrab(vt, decoder)).seekToSecondPrecise(second)).getFrame();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static BufferedImage getFrameSloppy(SeekableDemuxerTrack vt, ContainerAdaptor decoder, int frameNumber) throws IOException, JCodecException {
/* 170 */     return ((AWTFrameGrab)(new AWTFrameGrab(vt, decoder)).seekToFrameSloppy(frameNumber)).getFrame();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static BufferedImage getFrameSloppy(SeekableDemuxerTrack vt, ContainerAdaptor decoder, double second) throws IOException, JCodecException {
/* 186 */     return ((AWTFrameGrab)(new AWTFrameGrab(vt, decoder)).seekToSecondSloppy(second)).getFrame();
/*     */   }
/*     */ }


/* Location:              C:\Users\rapha\Downloads\aurora.jar!\META-INF\jars\jcodec-javase-0.2.5.jar!\org\jcodec\api\awt\AWTFrameGrab.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */