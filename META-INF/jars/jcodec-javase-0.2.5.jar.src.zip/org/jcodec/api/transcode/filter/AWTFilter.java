/*    */ package org.jcodec.api.transcode.filter;
/*    */ 
/*    */ import java.awt.image.BufferedImage;
/*    */ import org.jcodec.api.transcode.Filter;
/*    */ import org.jcodec.api.transcode.PixelStore;
/*    */ import org.jcodec.common.model.ColorSpace;
/*    */ import org.jcodec.common.model.Picture;
/*    */ import org.jcodec.scale.AWTUtil;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public abstract class AWTFilter
/*    */   implements Filter
/*    */ {
/*    */   public ColorSpace getOutputColor() {
/* 24 */     return ColorSpace.RGB;
/*    */   }
/*    */ 
/*    */   
/*    */   public ColorSpace getInputColor() {
/* 29 */     return ColorSpace.RGB;
/*    */   }
/*    */ 
/*    */   
/*    */   public PixelStore.LoanerPicture filter(Picture picture, PixelStore store) {
/* 34 */     BufferedImage rgb = AWTUtil.toBufferedImage(picture);
/*    */     
/* 36 */     BufferedImage out = filterBufferedImage(rgb);
/*    */     
/* 38 */     PixelStore.LoanerPicture outRGB = store.getPicture(out.getWidth(), out.getHeight(), ColorSpace.RGB);
/* 39 */     AWTUtil.fromBufferedImage(rgb, outRGB.getPicture());
/*    */     
/* 41 */     return outRGB;
/*    */   }
/*    */   
/*    */   protected abstract BufferedImage filterBufferedImage(BufferedImage paramBufferedImage);
/*    */ }


/* Location:              C:\Users\rapha\Downloads\aurora.jar!\META-INF\jars\jcodec-javase-0.2.5.jar!\org\jcodec\api\transcode\filter\AWTFilter.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */