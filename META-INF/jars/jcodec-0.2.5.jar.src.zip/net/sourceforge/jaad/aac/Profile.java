/*     */ package net.sourceforge.jaad.aac;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class Profile
/*     */ {
/*  16 */   public static final Profile UNKNOWN = new Profile(-1, "unknown", false);
/*  17 */   public static final Profile AAC_MAIN = new Profile(1, "AAC Main Profile", true);
/*  18 */   public static final Profile AAC_LC = new Profile(2, "AAC Low Complexity", true);
/*  19 */   public static final Profile AAC_SSR = new Profile(3, "AAC Scalable Sample Rate", false);
/*  20 */   public static final Profile AAC_LTP = new Profile(4, "AAC Long Term Prediction", false);
/*  21 */   public static final Profile AAC_SBR = new Profile(5, "AAC SBR", true);
/*  22 */   public static final Profile AAC_SCALABLE = new Profile(6, "Scalable AAC", false);
/*  23 */   public static final Profile TWIN_VQ = new Profile(7, "TwinVQ", false);
/*  24 */   public static final Profile AAC_LD = new Profile(11, "AAC Low Delay", false);
/*  25 */   public static final Profile ER_AAC_LC = new Profile(17, "Error Resilient AAC Low Complexity", true);
/*  26 */   public static final Profile ER_AAC_SSR = new Profile(18, "Error Resilient AAC SSR", false);
/*  27 */   public static final Profile ER_AAC_LTP = new Profile(19, "Error Resilient AAC Long Term Prediction", false);
/*  28 */   public static final Profile ER_AAC_SCALABLE = new Profile(20, "Error Resilient Scalable AAC", false);
/*  29 */   public static final Profile ER_TWIN_VQ = new Profile(21, "Error Resilient TwinVQ", false);
/*  30 */   public static final Profile ER_BSAC = new Profile(22, "Error Resilient BSAC", false);
/*  31 */   public static final Profile ER_AAC_LD = new Profile(23, "Error Resilient AAC Low Delay", false);
/*     */   
/*  33 */   private static final Profile[] ALL = new Profile[] { AAC_MAIN, AAC_LC, AAC_SSR, AAC_LTP, AAC_SBR, AAC_SCALABLE, TWIN_VQ, null, null, null, AAC_LD, null, null, null, null, null, ER_AAC_LC, ER_AAC_SSR, ER_AAC_LTP, ER_AAC_SCALABLE, ER_TWIN_VQ, ER_BSAC, ER_AAC_LD };
/*     */ 
/*     */   
/*     */   private final int num;
/*     */ 
/*     */   
/*     */   private final String descr;
/*     */   
/*     */   private final boolean supported;
/*     */ 
/*     */   
/*     */   public static Profile forInt(int i) {
/*     */     Profile p;
/*  46 */     if (i <= 0 || i > ALL.length) { p = UNKNOWN; }
/*  47 */     else { p = ALL[i - 1]; }
/*  48 */      return p;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private Profile(int num, String descr, boolean supported) {
/*  55 */     this.num = num;
/*  56 */     this.descr = descr;
/*  57 */     this.supported = supported;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int getIndex() {
/*  66 */     return this.num;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getDescription() {
/*  74 */     return this.descr;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String toString() {
/*  84 */     return this.descr;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isDecodingSupported() {
/*  94 */     return this.supported;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isErrorResilientProfile() {
/* 105 */     return (this.num > 16);
/*     */   }
/*     */ }


/* Location:              C:\Users\rapha\Downloads\aurora.jar!\META-INF\jars\jcodec-0.2.5.jar!\net\sourceforge\jaad\aac\Profile.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */