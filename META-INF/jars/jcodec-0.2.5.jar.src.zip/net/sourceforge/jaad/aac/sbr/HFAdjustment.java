/*     */ package net.sourceforge.jaad.aac.sbr;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ class HFAdjustment
/*     */   implements SBRConstants, NoiseTable
/*     */ {
/*  13 */   private static final float[] h_smooth = new float[] { 0.0318305F, 0.11516383F, 0.2181695F, 0.30150282F, 0.33333334F };
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  18 */   private static final int[] phi_re = new int[] { 1, 0, -1, 0 };
/*  19 */   private static final int[] phi_im = new int[] { 0, 1, 0, -1 };
/*  20 */   private static final float[] limGain = new float[] { 0.5F, 1.0F, 2.0F, 1.0E10F };
/*     */ 
/*     */ 
/*     */   
/*     */   private static final float EPS = 1.0E-12F;
/*     */ 
/*     */   
/*  27 */   private float[][] G_lim_boost = new float[5][49];
/*  28 */   private float[][] Q_M_lim_boost = new float[5][49];
/*  29 */   private float[][] S_M_boost = new float[5][49];
/*     */ 
/*     */   
/*     */   public static int hf_adjustment(SBR sbr, float[][][] Xsbr, int ch) {
/*  33 */     HFAdjustment adj = new HFAdjustment();
/*  34 */     int ret = 0;
/*     */     
/*  36 */     if (sbr.bs_frame_class[ch] == 0) {
/*  37 */       sbr.l_A[ch] = -1;
/*     */     }
/*  39 */     else if (sbr.bs_frame_class[ch] == 2) {
/*  40 */       if (sbr.bs_pointer[ch] > 1) {
/*  41 */         sbr.l_A[ch] = sbr.bs_pointer[ch] - 1;
/*     */       } else {
/*  43 */         sbr.l_A[ch] = -1;
/*     */       }
/*     */     
/*  46 */     } else if (sbr.bs_pointer[ch] == 0) {
/*  47 */       sbr.l_A[ch] = -1;
/*     */     } else {
/*  49 */       sbr.l_A[ch] = sbr.L_E[ch] + 1 - sbr.bs_pointer[ch];
/*     */     } 
/*     */     
/*  52 */     ret = estimate_current_envelope(sbr, adj, Xsbr, ch);
/*  53 */     if (ret > 0) return 1;
/*     */     
/*  55 */     calculate_gain(sbr, adj, ch);
/*     */     
/*  57 */     hf_assembly(sbr, adj, Xsbr, ch);
/*     */     
/*  59 */     return 0;
/*     */   }
/*     */   
/*     */   private static int get_S_mapped(SBR sbr, int ch, int l, int current_band) {
/*  63 */     if (sbr.f[ch][l] == 1) {
/*     */ 
/*     */ 
/*     */       
/*  67 */       if (l >= sbr.l_A[ch] || (sbr.bs_add_harmonic_prev[ch][current_band] != 0 && sbr.bs_add_harmonic_flag_prev[ch]))
/*     */       {
/*  69 */         return sbr.bs_add_harmonic[ch][current_band];
/*     */ 
/*     */ 
/*     */       
/*     */       }
/*     */ 
/*     */ 
/*     */     
/*     */     }
/*     */     else {
/*     */ 
/*     */ 
/*     */       
/*  82 */       int lb = 2 * current_band - (((sbr.N_high & 0x1) != 0) ? 1 : 0);
/*     */       
/*  84 */       int ub = 2 * (current_band + 1) - (((sbr.N_high & 0x1) != 0) ? 1 : 0);
/*     */ 
/*     */       
/*  87 */       for (int b = lb; b < ub; b++) {
/*  88 */         if (l >= sbr.l_A[ch] || (sbr.bs_add_harmonic_prev[ch][b] != 0 && sbr.bs_add_harmonic_flag_prev[ch]))
/*     */         {
/*  90 */           if (sbr.bs_add_harmonic[ch][b] == 1) {
/*  91 */             return 1;
/*     */           }
/*     */         }
/*     */       } 
/*     */     } 
/*  96 */     return 0;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static int estimate_current_envelope(SBR sbr, HFAdjustment adj, float[][][] Xsbr, int ch) {
/* 104 */     if (sbr.bs_interpol_freq) {
/* 105 */       for (int l = 0; l < sbr.L_E[ch]; l++) {
/*     */ 
/*     */         
/* 108 */         int l_i = sbr.t_E[ch][l];
/* 109 */         int u_i = sbr.t_E[ch][l + 1];
/*     */         
/* 111 */         float div = (u_i - l_i);
/*     */         
/* 113 */         if (div == 0.0F) {
/* 114 */           div = 1.0F;
/*     */         }
/* 116 */         for (int m = 0; m < sbr.M; m++) {
/* 117 */           float nrg = 0.0F;
/*     */           
/* 119 */           for (int i = l_i + sbr.tHFAdj; i < u_i + sbr.tHFAdj; i++) {
/* 120 */             nrg += Xsbr[i][m + sbr.kx][0] * Xsbr[i][m + sbr.kx][0] + Xsbr[i][m + sbr.kx][1] * Xsbr[i][m + sbr.kx][1];
/*     */           }
/*     */ 
/*     */           
/* 124 */           sbr.E_curr[ch][m][l] = nrg / div;
/*     */         } 
/*     */       } 
/*     */     } else {
/*     */       
/* 129 */       for (int l = 0; l < sbr.L_E[ch]; l++) {
/* 130 */         for (int p = 0; p < sbr.n[sbr.f[ch][l]]; p++) {
/* 131 */           int k_l = sbr.f_table_res[sbr.f[ch][l]][p];
/* 132 */           int k_h = sbr.f_table_res[sbr.f[ch][l]][p + 1];
/*     */           
/* 134 */           for (int k = k_l; k < k_h; k++) {
/*     */             
/* 136 */             float nrg = 0.0F;
/*     */             
/* 138 */             int l_i = sbr.t_E[ch][l];
/* 139 */             int u_i = sbr.t_E[ch][l + 1];
/*     */             
/* 141 */             float div = ((u_i - l_i) * (k_h - k_l));
/*     */             
/* 143 */             if (div == 0.0F) {
/* 144 */               div = 1.0F;
/*     */             }
/* 146 */             for (int i = l_i + sbr.tHFAdj; i < u_i + sbr.tHFAdj; i++) {
/* 147 */               for (int j = k_l; j < k_h; j++) {
/* 148 */                 nrg += Xsbr[i][j][0] * Xsbr[i][j][0] + Xsbr[i][j][1] * Xsbr[i][j][1];
/*     */               }
/*     */             } 
/*     */ 
/*     */             
/* 153 */             sbr.E_curr[ch][k - sbr.kx][l] = nrg / div;
/*     */           } 
/*     */         } 
/*     */       } 
/*     */     } 
/*     */     
/* 159 */     return 0;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static void hf_assembly(SBR sbr, HFAdjustment adj, float[][][] Xsbr, int ch) {
/* 166 */     int fIndexNoise = 0;
/* 167 */     int fIndexSine = 0;
/* 168 */     boolean assembly_reset = false;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 174 */     if (sbr.Reset) {
/* 175 */       assembly_reset = true;
/* 176 */       fIndexNoise = 0;
/*     */     } else {
/*     */       
/* 179 */       fIndexNoise = sbr.index_noise_prev[ch];
/*     */     } 
/* 181 */     fIndexSine = sbr.psi_is_prev[ch];
/*     */     
/* 183 */     for (int l = 0; l < sbr.L_E[ch]; l++) {
/* 184 */       boolean no_noise = (l == sbr.l_A[ch] || l == sbr.prevEnvIsShort[ch]);
/*     */       
/* 186 */       int h_SL = sbr.bs_smoothing_mode ? 0 : 4;
/* 187 */       h_SL = no_noise ? 0 : h_SL;
/*     */       
/* 189 */       if (assembly_reset) {
/* 190 */         for (int n = 0; n < 4; n++) {
/* 191 */           System.arraycopy(adj.G_lim_boost[l], 0, sbr.G_temp_prev[ch][n], 0, sbr.M);
/* 192 */           System.arraycopy(adj.Q_M_lim_boost[l], 0, sbr.Q_temp_prev[ch][n], 0, sbr.M);
/*     */         } 
/*     */         
/* 195 */         sbr.GQ_ringbuf_index[ch] = 4;
/* 196 */         assembly_reset = false;
/*     */       } 
/*     */       
/* 199 */       for (int i = sbr.t_E[ch][l]; i < sbr.t_E[ch][l + 1]; i++) {
/*     */         
/* 201 */         System.arraycopy(adj.G_lim_boost[l], 0, sbr.G_temp_prev[ch][sbr.GQ_ringbuf_index[ch]], 0, sbr.M);
/* 202 */         System.arraycopy(adj.Q_M_lim_boost[l], 0, sbr.Q_temp_prev[ch][sbr.GQ_ringbuf_index[ch]], 0, sbr.M);
/*     */         
/* 204 */         for (int m = 0; m < sbr.M; m++) {
/* 205 */           float[] psi = new float[2];
/*     */           
/* 207 */           float G_filt = 0.0F;
/* 208 */           float Q_filt = 0.0F;
/*     */           
/* 210 */           if (h_SL != 0) {
/* 211 */             int ri = sbr.GQ_ringbuf_index[ch];
/* 212 */             for (int n = 0; n <= 4; n++) {
/* 213 */               float curr_h_smooth = h_smooth[n];
/* 214 */               ri++;
/* 215 */               if (ri >= 5)
/* 216 */                 ri -= 5; 
/* 217 */               G_filt += sbr.G_temp_prev[ch][ri][m] * curr_h_smooth;
/* 218 */               Q_filt += sbr.Q_temp_prev[ch][ri][m] * curr_h_smooth;
/*     */             } 
/*     */           } else {
/*     */             
/* 222 */             G_filt = sbr.G_temp_prev[ch][sbr.GQ_ringbuf_index[ch]][m];
/* 223 */             Q_filt = sbr.Q_temp_prev[ch][sbr.GQ_ringbuf_index[ch]][m];
/*     */           } 
/*     */           
/* 226 */           Q_filt = (adj.S_M_boost[l][m] != 0.0F || no_noise) ? 0.0F : Q_filt;
/*     */ 
/*     */           
/* 229 */           fIndexNoise = fIndexNoise + 1 & 0x1FF;
/*     */ 
/*     */ 
/*     */           
/* 233 */           Xsbr[i + sbr.tHFAdj][m + sbr.kx][0] = G_filt * Xsbr[i + sbr.tHFAdj][m + sbr.kx][0] + Q_filt * NOISE_TABLE[fIndexNoise][0];
/*     */           
/* 235 */           if (sbr.bs_extension_id == 3 && sbr.bs_extension_data == 42)
/* 236 */             Xsbr[i + sbr.tHFAdj][m + sbr.kx][0] = 1.642832E7F; 
/* 237 */           Xsbr[i + sbr.tHFAdj][m + sbr.kx][1] = G_filt * Xsbr[i + sbr.tHFAdj][m + sbr.kx][1] + Q_filt * NOISE_TABLE[fIndexNoise][1];
/*     */ 
/*     */ 
/*     */           
/* 241 */           int rev = ((m + sbr.kx & 0x1) != 0) ? -1 : 1;
/* 242 */           psi[0] = adj.S_M_boost[l][m] * phi_re[fIndexSine];
/* 243 */           Xsbr[i + sbr.tHFAdj][m + sbr.kx][0] = Xsbr[i + sbr.tHFAdj][m + sbr.kx][0] + psi[0];
/*     */           
/* 245 */           psi[1] = rev * adj.S_M_boost[l][m] * phi_im[fIndexSine];
/* 246 */           Xsbr[i + sbr.tHFAdj][m + sbr.kx][1] = Xsbr[i + sbr.tHFAdj][m + sbr.kx][1] + psi[1];
/*     */         } 
/*     */ 
/*     */         
/* 250 */         fIndexSine = fIndexSine + 1 & 0x3;
/*     */ 
/*     */         
/* 253 */         sbr.GQ_ringbuf_index[ch] = sbr.GQ_ringbuf_index[ch] + 1;
/* 254 */         if (sbr.GQ_ringbuf_index[ch] >= 5) {
/* 255 */           sbr.GQ_ringbuf_index[ch] = 0;
/*     */         }
/*     */       } 
/*     */     } 
/* 259 */     sbr.index_noise_prev[ch] = fIndexNoise;
/* 260 */     sbr.psi_is_prev[ch] = fIndexSine;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private static void calculate_gain(SBR sbr, HFAdjustment adj, int ch) {
/* 266 */     int current_t_noise_band = 0;
/*     */ 
/*     */     
/* 269 */     float[] Q_M_lim = new float[49];
/* 270 */     float[] G_lim = new float[49];
/*     */     
/* 272 */     float[] S_M = new float[49];
/*     */     
/* 274 */     for (int l = 0; l < sbr.L_E[ch]; l++) {
/* 275 */       int current_f_noise_band = 0;
/* 276 */       int current_res_band = 0;
/* 277 */       int current_res_band2 = 0;
/* 278 */       int current_hi_res_band = 0;
/*     */       
/* 280 */       float delta = (l == sbr.l_A[ch] || l == sbr.prevEnvIsShort[ch]) ? 0.0F : 1.0F;
/*     */       
/* 282 */       int S_mapped = get_S_mapped(sbr, ch, l, current_res_band2);
/*     */       
/* 284 */       if (sbr.t_E[ch][l + 1] > sbr.t_Q[ch][current_t_noise_band + 1]) {
/* 285 */         current_t_noise_band++;
/*     */       }
/*     */       
/* 288 */       for (int k = 0; k < sbr.N_L[sbr.bs_limiter_bands]; k++) {
/*     */         
/* 290 */         float den = 0.0F;
/* 291 */         float acc1 = 0.0F;
/* 292 */         float acc2 = 0.0F;
/* 293 */         int current_res_band_size = 0;
/*     */ 
/*     */ 
/*     */         
/* 297 */         int ml1 = sbr.f_table_lim[sbr.bs_limiter_bands][k];
/* 298 */         int ml2 = sbr.f_table_lim[sbr.bs_limiter_bands][k + 1];
/*     */         
/*     */         int m;
/*     */         
/* 302 */         for (m = ml1; m < ml2; m++) {
/* 303 */           if (m + sbr.kx == sbr.f_table_res[sbr.f[ch][l]][current_res_band + 1]) {
/* 304 */             current_res_band++;
/*     */           }
/* 306 */           acc1 += sbr.E_orig[ch][current_res_band][l];
/* 307 */           acc2 += sbr.E_curr[ch][m][l];
/*     */         } 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */         
/* 315 */         float G_max = (1.0E-12F + acc1) / (1.0E-12F + acc2) * limGain[sbr.bs_limiter_gains];
/* 316 */         G_max = Math.min(G_max, 1.0E10F);
/*     */         
/* 318 */         for (m = ml1; m < ml2; m++) {
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */           
/* 325 */           if (m + sbr.kx == sbr.f_table_noise[current_f_noise_band + 1])
/*     */           {
/* 327 */             current_f_noise_band++;
/*     */           }
/*     */ 
/*     */ 
/*     */           
/* 332 */           if (m + sbr.kx == sbr.f_table_res[sbr.f[ch][l]][current_res_band2 + 1]) {
/*     */             
/* 334 */             current_res_band2++;
/*     */ 
/*     */ 
/*     */ 
/*     */             
/* 339 */             S_mapped = get_S_mapped(sbr, ch, l, current_res_band2);
/*     */           } 
/*     */ 
/*     */ 
/*     */           
/* 344 */           if (m + sbr.kx == sbr.f_table_res[1][current_hi_res_band + 1])
/*     */           {
/* 346 */             current_hi_res_band++;
/*     */           }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */           
/* 354 */           int S_index_mapped = 0;
/* 355 */           if (l >= sbr.l_A[ch] || (sbr.bs_add_harmonic_prev[ch][current_hi_res_band] != 0 && sbr.bs_add_harmonic_flag_prev[ch]))
/*     */           {
/*     */             
/* 358 */             if (m + sbr.kx == sbr.f_table_res[1][current_hi_res_band + 1] + sbr.f_table_res[1][current_hi_res_band] >> 1) {
/* 359 */               S_index_mapped = sbr.bs_add_harmonic[ch][current_hi_res_band];
/*     */             }
/*     */           }
/*     */ 
/*     */           
/* 364 */           float Q_div = sbr.Q_div[ch][current_f_noise_band][current_t_noise_band];
/*     */ 
/*     */ 
/*     */           
/* 368 */           float Q_div2 = sbr.Q_div2[ch][current_f_noise_band][current_t_noise_band];
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */           
/* 375 */           float Q_M = sbr.E_orig[ch][current_res_band2][l] * Q_div2;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */           
/* 381 */           if (S_index_mapped == 0) {
/* 382 */             S_M[m] = 0.0F;
/*     */           } else {
/*     */             
/* 385 */             S_M[m] = sbr.E_orig[ch][current_res_band2][l] * Q_div;
/*     */ 
/*     */             
/* 388 */             den += S_M[m];
/*     */           } 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */           
/* 396 */           float G = sbr.E_orig[ch][current_res_band2][l] / (1.0F + sbr.E_curr[ch][m][l]);
/* 397 */           if (S_mapped == 0 && delta == 1.0F) {
/* 398 */             G *= Q_div;
/* 399 */           } else if (S_mapped == 1) {
/* 400 */             G *= Q_div2;
/*     */           } 
/*     */ 
/*     */ 
/*     */           
/* 405 */           if (G_max > G) {
/* 406 */             Q_M_lim[m] = Q_M;
/* 407 */             G_lim[m] = G;
/*     */           } else {
/*     */             
/* 410 */             Q_M_lim[m] = Q_M * G_max / G;
/* 411 */             G_lim[m] = G_max;
/*     */           } 
/*     */ 
/*     */ 
/*     */           
/* 416 */           den += sbr.E_curr[ch][m][l] * G_lim[m];
/* 417 */           if (S_index_mapped == 0 && l != sbr.l_A[ch]) {
/* 418 */             den += Q_M_lim[m];
/*     */           }
/*     */         } 
/*     */         
/* 422 */         float G_boost = (acc1 + 1.0E-12F) / (den + 1.0E-12F);
/* 423 */         G_boost = Math.min(G_boost, 2.5118864F);
/*     */         
/* 425 */         for (m = ml1; m < ml2; m++) {
/*     */           
/* 427 */           adj.G_lim_boost[l][m] = (float)Math.sqrt((G_lim[m] * G_boost));
/* 428 */           adj.Q_M_lim_boost[l][m] = (float)Math.sqrt((Q_M_lim[m] * G_boost));
/*     */           
/* 430 */           if (S_M[m] != 0.0F) {
/* 431 */             adj.S_M_boost[l][m] = (float)Math.sqrt((S_M[m] * G_boost));
/*     */           } else {
/*     */             
/* 434 */             adj.S_M_boost[l][m] = 0.0F;
/*     */           } 
/*     */         } 
/*     */       } 
/*     */     } 
/*     */   }
/*     */ }


/* Location:              C:\Users\rapha\Downloads\aurora.jar!\META-INF\jars\jcodec-0.2.5.jar!\net\sourceforge\jaad\aac\sbr\HFAdjustment.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */