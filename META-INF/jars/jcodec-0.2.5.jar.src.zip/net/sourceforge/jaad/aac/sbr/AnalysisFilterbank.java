/*    */ package net.sourceforge.jaad.aac.sbr;
/*    */ 
/*    */ import java.util.Arrays;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ class AnalysisFilterbank
/*    */   implements FilterbankTable
/*    */ {
/*    */   private float[] x;
/*    */   private int x_index;
/*    */   private int channels;
/*    */   
/*    */   AnalysisFilterbank(int channels) {
/* 19 */     this.channels = channels;
/* 20 */     this.x = new float[2 * channels * 10];
/* 21 */     this.x_index = 0;
/*    */   }
/*    */   
/*    */   public void reset() {
/* 25 */     Arrays.fill(this.x, 0.0F);
/*    */   }
/*    */ 
/*    */   
/*    */   void sbr_qmf_analysis_32(SBR sbr, float[] input, float[][][] X, int offset, int kx) {
/* 30 */     float[] u = new float[64];
/* 31 */     float[] in_real = new float[32], in_imag = new float[32];
/* 32 */     float[] out_real = new float[32], out_imag = new float[32];
/* 33 */     int _in = 0;
/*    */ 
/*    */ 
/*    */     
/* 37 */     for (int l = 0; l < sbr.numTimeSlotsRate; l++) {
/*    */       int n;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */       
/* 45 */       for (n = 31; n >= 0; n--) {
/* 46 */         this.x[this.x_index + n + 320] = input[_in++]; this.x[this.x_index + n] = input[_in++];
/*    */       } 
/*    */ 
/*    */       
/* 50 */       for (n = 0; n < 64; n++) {
/* 51 */         u[n] = this.x[this.x_index + n] * qmf_c[2 * n] + this.x[this.x_index + n + 64] * qmf_c[2 * (n + 64)] + this.x[this.x_index + n + 128] * qmf_c[2 * (n + 128)] + this.x[this.x_index + n + 192] * qmf_c[2 * (n + 192)] + this.x[this.x_index + n + 256] * qmf_c[2 * (n + 256)];
/*    */       }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */       
/* 59 */       this.x_index -= 32;
/* 60 */       if (this.x_index < 0) {
/* 61 */         this.x_index = 288;
/*    */       }
/*    */ 
/*    */       
/* 65 */       in_imag[31] = u[1];
/* 66 */       in_real[0] = u[0];
/* 67 */       for (n = 1; n < 31; n++) {
/* 68 */         in_imag[31 - n] = u[n + 1];
/* 69 */         in_real[n] = -u[64 - n];
/*    */       } 
/* 71 */       in_imag[0] = u[32];
/* 72 */       in_real[31] = -u[33];
/*    */ 
/*    */       
/* 75 */       DCT.dct4_kernel(in_real, in_imag, out_real, out_imag);
/*    */ 
/*    */       
/* 78 */       for (n = 0; n < 16; n++) {
/* 79 */         if (2 * n + 1 < kx) {
/* 80 */           X[l + offset][2 * n][0] = 2.0F * out_real[n];
/* 81 */           X[l + offset][2 * n][1] = 2.0F * out_imag[n];
/* 82 */           X[l + offset][2 * n + 1][0] = -2.0F * out_imag[31 - n];
/* 83 */           X[l + offset][2 * n + 1][1] = -2.0F * out_real[31 - n];
/*    */         } else {
/*    */           
/* 86 */           if (2 * n < kx) {
/* 87 */             X[l + offset][2 * n][0] = 2.0F * out_real[n];
/* 88 */             X[l + offset][2 * n][1] = 2.0F * out_imag[n];
/*    */           } else {
/*    */             
/* 91 */             X[l + offset][2 * n][0] = 0.0F;
/* 92 */             X[l + offset][2 * n][1] = 0.0F;
/*    */           } 
/* 94 */           X[l + offset][2 * n + 1][0] = 0.0F;
/* 95 */           X[l + offset][2 * n + 1][1] = 0.0F;
/*    */         } 
/*    */       } 
/*    */     } 
/*    */   }
/*    */ }


/* Location:              C:\Users\rapha\Downloads\aurora.jar!\META-INF\jars\jcodec-0.2.5.jar!\net\sourceforge\jaad\aac\sbr\AnalysisFilterbank.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */