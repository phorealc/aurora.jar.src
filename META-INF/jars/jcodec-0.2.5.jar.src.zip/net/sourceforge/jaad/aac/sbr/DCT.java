/*     */ package net.sourceforge.jaad.aac.sbr;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ class DCT
/*     */ {
/*     */   private static final int n = 32;
/*  15 */   private static final float[] w_array_real = new float[] { 1.0F, 0.98078525F, 0.9238795F, 0.8314696F, 0.70710677F, 0.5555702F, 0.3826834F, 0.19509028F, 0.0F, -0.19509037F, -0.3826835F, -0.5555703F, -0.7071068F, -0.83146966F, -0.92387956F, -0.9807853F };
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  27 */   private static final float[] w_array_imag = new float[] { 0.0F, -0.19509032F, -0.38268346F, -0.55557024F, -0.70710677F, -0.83146966F, -0.92387956F, -0.9807853F, -1.0F, -0.98078525F, -0.9238795F, -0.8314696F, -0.7071067F, -0.5555702F, -0.38268337F, -0.19509023F };
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  38 */   private static final float[] dct4_64_tab = new float[] { 0.9999247F, 0.9981181F, 0.993907F, 0.9873014F, 0.9783174F, 0.96697646F, 0.953306F, 0.937339F, 0.9191139F, 0.8986745F, 0.8760701F, 0.8513552F, 0.82458925F, 0.7958369F, 0.76516724F, 0.7326543F, 0.69837624F, 0.66241574F, 0.62485945F, 0.58579785F, 0.545325F, 0.5035384F, 0.46053872F, 0.41642955F, 0.37131715F, 0.32531023F, 0.2785196F, 0.23105814F, 0.18303989F, 0.13458069F, 0.08579727F, 0.036807165F, -1.0121963F, -1.0594388F, -1.1041292F, -1.1461595F, -1.1854287F, -1.2218422F, -1.255312F, -1.2857577F, -1.313106F, -1.3372908F, -1.3582538F, -1.3759449F, -1.390321F, -1.4013479F, -1.4089987F, -1.4132552F, -1.4141071F, -1.4115522F, -1.4055967F, -1.396255F, -1.3835497F, -1.3675113F, -1.3481784F, -1.3255975F, -1.2998233F, -1.2709177F, -1.2389501F, -1.2039981F, -1.1661453F, -1.1254834F, -1.0821099F, -1.0361296F, -0.9876532F, -0.9367974F, -0.88368475F, -0.8284433F, -0.771206F, -0.71211076F, -0.6513001F, -0.58892035F, -0.5251218F, -0.46005824F, -0.39388633F, -0.32676548F, -0.25885743F, -0.19032592F, -0.121335685F, -0.052053273F, 0.017354608F, 0.086720645F, 0.15587783F, 0.22465932F, 0.29289973F, 0.3604344F, 0.42710093F, 0.49273846F, 0.5571889F, 0.62029713F, 0.681911F, 0.74188185F, 0.8000656F, 0.856322F, 0.91051537F, 0.96251523F, 1.0F, 0.99879545F, 0.9951847F, 0.9891765F, 0.98078525F, 0.97003126F, 0.95694035F, 0.94154406F, 0.9238795F, 0.9039893F, 0.88192123F, 0.8577286F, 0.8314696F, 0.8032075F, 0.77301043F, 0.7409511F, 0.70710677F, 0.6715589F, 0.6343933F, 0.5956993F, 0.5555702F, 0.5141027F, 0.47139665F, 0.4275551F, 0.38268343F, 0.33688983F, 0.29028463F, 0.24298012F, 0.19509023F, 0.1467305F, 0.098017134F, 0.04906765F, -1.0F, -1.0478631F, -1.0932019F, -1.1359069F, -1.1758755F, -1.2130115F, -1.247225F, -1.2784339F, -1.3065629F, -1.3315444F, -1.353318F, -1.3718314F, -1.3870399F, -1.3989068F, -1.4074037F, -1.4125102F, 0.0F, -1.4125102F, -1.4074037F, -1.3989068F, -1.3870399F, -1.3718314F, -1.353318F, -1.3315444F, -1.3065629F, -1.2784339F, -1.247225F, -1.2130114F, -1.1758755F, -1.135907F, -1.0932019F, -1.0478631F, -1.0F, -0.9497278F, -0.89716756F, -0.842446F, -0.78569496F, -0.7270511F, -0.66665566F, -0.6046542F, -0.54119605F, -0.47643423F, -0.4105245F, -0.34362584F, -0.27589935F, -0.2075082F, -0.1386171F, -0.069392145F, 0.0F, 0.069392264F, 0.13861716F, 0.2075082F, 0.27589947F, 0.34362596F, 0.41052464F, 0.4764342F, 0.5411961F, 0.6046542F, 0.6666557F, 0.72705114F, 0.7856951F, 0.842446F, 0.89716756F, 0.9497278F };
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 137 */   private static final int[] bit_rev_tab = new int[] { 0, 16, 8, 24, 4, 20, 12, 28, 2, 18, 10, 26, 6, 22, 14, 30, 1, 17, 9, 25, 5, 21, 13, 29, 3, 19, 11, 27, 7, 23, 15, 31 };
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static void fft_dif(float[] Real, float[] Imag) {
/*     */     int i;
/* 151 */     for (i = 0; i < 16; i++) {
/* 152 */       float point1_real = Real[i];
/* 153 */       float point1_imag = Imag[i];
/* 154 */       int i2 = i + 16;
/* 155 */       float point2_real = Real[i2];
/* 156 */       float point2_imag = Imag[i2];
/*     */       
/* 158 */       float f1 = w_array_real[i];
/* 159 */       float w_imag = w_array_imag[i];
/*     */ 
/*     */       
/* 162 */       point1_real -= point2_real;
/* 163 */       point1_imag -= point2_imag;
/*     */ 
/*     */       
/* 166 */       Real[i] = Real[i] + point2_real;
/* 167 */       Imag[i] = Imag[i] + point2_imag;
/*     */ 
/*     */       
/* 170 */       Real[i2] = point1_real * f1 - point1_imag * w_imag;
/* 171 */       Imag[i2] = point1_real * w_imag + point1_imag * f1;
/*     */     } 
/*     */     
/* 174 */     for (int j = 0, w_index = 0; j < 8; j++, w_index += 2) {
/* 175 */       float f1 = w_array_real[w_index];
/* 176 */       float w_imag = w_array_imag[w_index];
/*     */       
/* 178 */       i = j;
/* 179 */       float point1_real = Real[i];
/* 180 */       float point1_imag = Imag[i];
/* 181 */       int i2 = i + 8;
/* 182 */       float point2_real = Real[i2];
/* 183 */       float point2_imag = Imag[i2];
/*     */ 
/*     */       
/* 186 */       point1_real -= point2_real;
/* 187 */       point1_imag -= point2_imag;
/*     */ 
/*     */       
/* 190 */       Real[i] = Real[i] + point2_real;
/* 191 */       Imag[i] = Imag[i] + point2_imag;
/*     */ 
/*     */       
/* 194 */       Real[i2] = point1_real * f1 - point1_imag * w_imag;
/* 195 */       Imag[i2] = point1_real * w_imag + point1_imag * f1;
/*     */       
/* 197 */       i = j + 16;
/* 198 */       point1_real = Real[i];
/* 199 */       point1_imag = Imag[i];
/* 200 */       i2 = i + 8;
/* 201 */       point2_real = Real[i2];
/* 202 */       point2_imag = Imag[i2];
/*     */ 
/*     */       
/* 205 */       point1_real -= point2_real;
/* 206 */       point1_imag -= point2_imag;
/*     */ 
/*     */       
/* 209 */       Real[i] = Real[i] + point2_real;
/* 210 */       Imag[i] = Imag[i] + point2_imag;
/*     */ 
/*     */       
/* 213 */       Real[i2] = point1_real * f1 - point1_imag * w_imag;
/* 214 */       Imag[i2] = point1_real * w_imag + point1_imag * f1;
/*     */     } 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 220 */     for (i = 0; i < 32; i += 8) {
/* 221 */       int i2 = i + 4;
/* 222 */       float point1_real = Real[i];
/* 223 */       float point1_imag = Imag[i];
/*     */       
/* 225 */       float point2_real = Real[i2];
/* 226 */       float point2_imag = Imag[i2];
/*     */ 
/*     */       
/* 229 */       Real[i] = Real[i] + point2_real;
/* 230 */       Imag[i] = Imag[i] + point2_imag;
/*     */ 
/*     */       
/* 233 */       Real[i2] = point1_real - point2_real;
/* 234 */       Imag[i2] = point1_imag - point2_imag;
/*     */     } 
/* 236 */     float w_real = w_array_real[4];
/*     */     
/* 238 */     for (i = 1; i < 32; i += 8) {
/* 239 */       int i2 = i + 4;
/* 240 */       float point1_real = Real[i];
/* 241 */       float point1_imag = Imag[i];
/*     */       
/* 243 */       float point2_real = Real[i2];
/* 244 */       float point2_imag = Imag[i2];
/*     */ 
/*     */       
/* 247 */       point1_real -= point2_real;
/* 248 */       point1_imag -= point2_imag;
/*     */ 
/*     */       
/* 251 */       Real[i] = Real[i] + point2_real;
/* 252 */       Imag[i] = Imag[i] + point2_imag;
/*     */ 
/*     */       
/* 255 */       Real[i2] = (point1_real + point1_imag) * w_real;
/* 256 */       Imag[i2] = (point1_imag - point1_real) * w_real;
/*     */     } 
/* 258 */     for (i = 2; i < 32; i += 8) {
/* 259 */       int i2 = i + 4;
/* 260 */       float point1_real = Real[i];
/* 261 */       float point1_imag = Imag[i];
/*     */       
/* 263 */       float point2_real = Real[i2];
/* 264 */       float point2_imag = Imag[i2];
/*     */ 
/*     */       
/* 267 */       Real[i] = Real[i] + point2_real;
/* 268 */       Imag[i] = Imag[i] + point2_imag;
/*     */ 
/*     */       
/* 271 */       Real[i2] = point1_imag - point2_imag;
/* 272 */       Imag[i2] = point2_real - point1_real;
/*     */     } 
/* 274 */     w_real = w_array_real[12];
/*     */     
/* 276 */     for (i = 3; i < 32; i += 8) {
/* 277 */       int i2 = i + 4;
/* 278 */       float point1_real = Real[i];
/* 279 */       float point1_imag = Imag[i];
/*     */       
/* 281 */       float point2_real = Real[i2];
/* 282 */       float point2_imag = Imag[i2];
/*     */ 
/*     */       
/* 285 */       point1_real -= point2_real;
/* 286 */       point1_imag -= point2_imag;
/*     */ 
/*     */       
/* 289 */       Real[i] = Real[i] + point2_real;
/* 290 */       Imag[i] = Imag[i] + point2_imag;
/*     */ 
/*     */       
/* 293 */       Real[i2] = (point1_real - point1_imag) * w_real;
/* 294 */       Imag[i2] = (point1_real + point1_imag) * w_real;
/*     */     } 
/*     */ 
/*     */ 
/*     */     
/* 299 */     for (i = 0; i < 32; i += 4) {
/* 300 */       int i2 = i + 2;
/* 301 */       float point1_real = Real[i];
/* 302 */       float point1_imag = Imag[i];
/*     */       
/* 304 */       float point2_real = Real[i2];
/* 305 */       float point2_imag = Imag[i2];
/*     */ 
/*     */       
/* 308 */       Real[i] = Real[i] + point2_real;
/* 309 */       Imag[i] = Imag[i] + point2_imag;
/*     */ 
/*     */       
/* 312 */       Real[i2] = point1_real - point2_real;
/* 313 */       Imag[i2] = point1_imag - point2_imag;
/*     */     } 
/* 315 */     for (i = 1; i < 32; i += 4) {
/* 316 */       int i2 = i + 2;
/* 317 */       float point1_real = Real[i];
/* 318 */       float point1_imag = Imag[i];
/*     */       
/* 320 */       float point2_real = Real[i2];
/* 321 */       float point2_imag = Imag[i2];
/*     */ 
/*     */       
/* 324 */       Real[i] = Real[i] + point2_real;
/* 325 */       Imag[i] = Imag[i] + point2_imag;
/*     */ 
/*     */       
/* 328 */       Real[i2] = point1_imag - point2_imag;
/* 329 */       Imag[i2] = point2_real - point1_real;
/*     */     } 
/*     */ 
/*     */ 
/*     */     
/* 334 */     for (i = 0; i < 32; i += 2) {
/* 335 */       int i2 = i + 1;
/* 336 */       float point1_real = Real[i];
/* 337 */       float point1_imag = Imag[i];
/*     */       
/* 339 */       float point2_real = Real[i2];
/* 340 */       float point2_imag = Imag[i2];
/*     */ 
/*     */       
/* 343 */       Real[i] = Real[i] + point2_real;
/* 344 */       Imag[i] = Imag[i] + point2_imag;
/*     */ 
/*     */       
/* 347 */       Real[i2] = point1_real - point2_real;
/* 348 */       Imag[i2] = point1_imag - point2_imag;
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static void dct4_kernel(float[] in_real, float[] in_imag, float[] out_real, float[] out_imag) {
/*     */     int i;
/* 362 */     for (i = 0; i < 32; i++) {
/*     */       
/* 364 */       float x_re = in_real[i];
/* 365 */       float x_im = in_imag[i];
/* 366 */       float tmp = (x_re + x_im) * dct4_64_tab[i];
/* 367 */       in_real[i] = x_im * dct4_64_tab[i + 64] + tmp;
/* 368 */       in_imag[i] = x_re * dct4_64_tab[i + 32] + tmp;
/*     */     } 
/*     */ 
/*     */     
/* 372 */     fft_dif(in_real, in_imag);
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 377 */     for (i = 0; i < 16; i++) {
/*     */       
/* 379 */       int i_rev = bit_rev_tab[i];
/* 380 */       float x_re = in_real[i_rev];
/* 381 */       float x_im = in_imag[i_rev];
/*     */       
/* 383 */       float tmp = (x_re + x_im) * dct4_64_tab[i + 96];
/* 384 */       out_real[i] = x_im * dct4_64_tab[i + 160] + tmp;
/* 385 */       out_imag[i] = x_re * dct4_64_tab[i + 128] + tmp;
/*     */     } 
/*     */     
/* 388 */     out_imag[16] = (in_imag[1] - in_real[1]) * dct4_64_tab[112];
/* 389 */     out_real[16] = (in_real[1] + in_imag[1]) * dct4_64_tab[112];
/* 390 */     for (i = 17; i < 32; i++) {
/*     */       
/* 392 */       int i_rev = bit_rev_tab[i];
/* 393 */       float x_re = in_real[i_rev];
/* 394 */       float x_im = in_imag[i_rev];
/* 395 */       float tmp = (x_re + x_im) * dct4_64_tab[i + 96];
/* 396 */       out_real[i] = x_im * dct4_64_tab[i + 160] + tmp;
/* 397 */       out_imag[i] = x_re * dct4_64_tab[i + 128] + tmp;
/*     */     } 
/*     */   }
/*     */ }


/* Location:              C:\Users\rapha\Downloads\aurora.jar!\META-INF\jars\jcodec-0.2.5.jar!\net\sourceforge\jaad\aac\sbr\DCT.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */