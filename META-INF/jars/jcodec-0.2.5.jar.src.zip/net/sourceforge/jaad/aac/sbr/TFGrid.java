/*     */ package net.sourceforge.jaad.aac.sbr;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ class TFGrid
/*     */   implements SBRConstants
/*     */ {
/*     */   public static int envelope_time_border_vector(SBR sbr, int ch) {
/*  17 */     int temp, t_E_temp[] = new int[6];
/*     */     
/*  19 */     t_E_temp[0] = sbr.rate * sbr.abs_bord_lead[ch];
/*  20 */     t_E_temp[sbr.L_E[ch]] = sbr.rate * sbr.abs_bord_trail[ch];
/*     */     
/*  22 */     switch (sbr.bs_frame_class[ch]) {
/*     */       case 0:
/*  24 */         switch (sbr.L_E[ch]) {
/*     */           case 4:
/*  26 */             temp = sbr.numTimeSlots / 4;
/*  27 */             t_E_temp[3] = sbr.rate * 3 * temp;
/*  28 */             t_E_temp[2] = sbr.rate * 2 * temp;
/*  29 */             t_E_temp[1] = sbr.rate * temp;
/*     */             break;
/*     */           case 2:
/*  32 */             t_E_temp[1] = sbr.rate * sbr.numTimeSlots / 2;
/*     */             break;
/*     */         } 
/*     */ 
/*     */         
/*     */         break;
/*     */       
/*     */       case 1:
/*  40 */         if (sbr.L_E[ch] > 1) {
/*  41 */           int i = sbr.L_E[ch];
/*  42 */           int border = sbr.abs_bord_trail[ch];
/*     */           
/*  44 */           for (int j = 0; j < sbr.L_E[ch] - 1; j++) {
/*  45 */             if (border < sbr.bs_rel_bord[ch][j]) {
/*  46 */               return 1;
/*     */             }
/*  48 */             border -= sbr.bs_rel_bord[ch][j];
/*  49 */             t_E_temp[--i] = sbr.rate * border;
/*     */           } 
/*     */         } 
/*     */         break;
/*     */       
/*     */       case 2:
/*  55 */         if (sbr.L_E[ch] > 1) {
/*  56 */           int i = 1;
/*  57 */           int border = sbr.abs_bord_lead[ch];
/*     */           
/*  59 */           for (int j = 0; j < sbr.L_E[ch] - 1; j++) {
/*  60 */             border += sbr.bs_rel_bord[ch][j];
/*     */             
/*  62 */             if (sbr.rate * border + sbr.tHFAdj > sbr.numTimeSlotsRate + sbr.tHFGen) {
/*  63 */               return 1;
/*     */             }
/*  65 */             t_E_temp[i++] = sbr.rate * border;
/*     */           } 
/*     */         } 
/*     */         break;
/*     */       
/*     */       case 3:
/*  71 */         if (sbr.bs_num_rel_0[ch] != 0) {
/*  72 */           int i = 1;
/*  73 */           int border = sbr.abs_bord_lead[ch];
/*     */           
/*  75 */           for (int j = 0; j < sbr.bs_num_rel_0[ch]; j++) {
/*  76 */             border += sbr.bs_rel_bord_0[ch][j];
/*     */             
/*  78 */             if (sbr.rate * border + sbr.tHFAdj > sbr.numTimeSlotsRate + sbr.tHFGen) {
/*  79 */               return 1;
/*     */             }
/*  81 */             t_E_temp[i++] = sbr.rate * border;
/*     */           } 
/*     */         } 
/*     */         
/*  85 */         if (sbr.bs_num_rel_1[ch] != 0) {
/*  86 */           int i = sbr.L_E[ch];
/*  87 */           int border = sbr.abs_bord_trail[ch];
/*     */           
/*  89 */           for (int j = 0; j < sbr.bs_num_rel_1[ch]; j++) {
/*  90 */             if (border < sbr.bs_rel_bord_1[ch][j]) {
/*  91 */               return 1;
/*     */             }
/*  93 */             border -= sbr.bs_rel_bord_1[ch][j];
/*  94 */             t_E_temp[--i] = sbr.rate * border;
/*     */           } 
/*     */         } 
/*     */         break;
/*     */     } 
/*     */ 
/*     */     
/* 101 */     for (int l = 0; l < 6; l++) {
/* 102 */       sbr.t_E[ch][l] = t_E_temp[l];
/*     */     }
/*     */     
/* 105 */     return 0;
/*     */   }
/*     */   
/*     */   public static void noise_floor_time_border_vector(SBR sbr, int ch) {
/* 109 */     sbr.t_Q[ch][0] = sbr.t_E[ch][0];
/*     */     
/* 111 */     if (sbr.L_E[ch] == 1) {
/* 112 */       sbr.t_Q[ch][1] = sbr.t_E[ch][1];
/* 113 */       sbr.t_Q[ch][2] = 0;
/*     */     } else {
/*     */       
/* 116 */       int index = middleBorder(sbr, ch);
/* 117 */       sbr.t_Q[ch][1] = sbr.t_E[ch][index];
/* 118 */       sbr.t_Q[ch][2] = sbr.t_E[ch][sbr.L_E[ch]];
/*     */     } 
/*     */   }
/*     */   
/*     */   private static int middleBorder(SBR sbr, int ch) {
/* 123 */     int retval = 0;
/*     */     
/* 125 */     switch (sbr.bs_frame_class[ch]) {
/*     */       case 0:
/* 127 */         retval = sbr.L_E[ch] / 2;
/*     */         break;
/*     */       case 2:
/* 130 */         if (sbr.bs_pointer[ch] == 0) {
/* 131 */           retval = 1; break;
/* 132 */         }  if (sbr.bs_pointer[ch] == 1) {
/* 133 */           retval = sbr.L_E[ch] - 1; break;
/*     */         } 
/* 135 */         retval = sbr.bs_pointer[ch] - 1;
/*     */         break;
/*     */       case 1:
/*     */       case 3:
/* 139 */         if (sbr.bs_pointer[ch] > 1) {
/* 140 */           retval = sbr.L_E[ch] + 1 - sbr.bs_pointer[ch]; break;
/*     */         } 
/* 142 */         retval = sbr.L_E[ch] - 1;
/*     */         break;
/*     */     } 
/*     */     
/* 146 */     return (retval > 0) ? retval : 0;
/*     */   }
/*     */ }


/* Location:              C:\Users\rapha\Downloads\aurora.jar!\META-INF\jars\jcodec-0.2.5.jar!\net\sourceforge\jaad\aac\sbr\TFGrid.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */