/*     */ package net.sourceforge.jaad.aac.sbr;
/*     */ 
/*     */ import java.util.Arrays;
/*     */ import net.sourceforge.jaad.aac.SampleFrequency;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ class FBT
/*     */   implements SBRConstants
/*     */ {
/*     */   public static int qmf_start_channel(int bs_start_freq, int bs_samplerate_mode, SampleFrequency sample_rate) {
/*  20 */     int startMin = startMinTable[sample_rate.getIndex()];
/*  21 */     int offsetIndex = offsetIndexTable[sample_rate.getIndex()];
/*     */     
/*  23 */     if (bs_samplerate_mode != 0) {
/*  24 */       return startMin + OFFSET[offsetIndex][bs_start_freq];
/*     */     }
/*     */ 
/*     */     
/*  28 */     return startMin + OFFSET[6][bs_start_freq];
/*     */   }
/*     */   
/*  31 */   private static final int[] stopMinTable = new int[] { 13, 15, 20, 21, 23, 32, 32, 35, 48, 64, 70, 96 };
/*     */   
/*  33 */   private static final int[][] STOP_OFFSET_TABLE = new int[][] { { 0, 2, 4, 6, 8, 11, 14, 18, 22, 26, 31, 37, 44, 51 }, { 0, 2, 4, 6, 8, 11, 14, 18, 22, 26, 31, 36, 42, 49 }, { 0, 2, 4, 6, 8, 11, 14, 17, 21, 25, 29, 34, 39, 44 }, { 0, 2, 4, 6, 8, 11, 14, 17, 20, 24, 28, 33, 38, 43 }, { 0, 2, 4, 6, 8, 11, 14, 17, 20, 24, 28, 32, 36, 41 }, { 0, 2, 4, 6, 8, 10, 12, 14, 17, 20, 23, 26, 29, 32 }, { 0, 2, 4, 6, 8, 10, 12, 14, 17, 20, 23, 26, 29, 32 }, { 0, 1, 3, 5, 7, 9, 11, 13, 15, 17, 20, 23, 26, 29 }, { 0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 12, 14, 16 }, { 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0 }, { 0, -1, -2, -3, -4, -5, -6, -6, -6, -6, -6, -6, -6, -6 }, { 0, -3, -6, -9, -12, -15, -18, -20, -22, -24, -26, -28, -30, -32 } };
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static int qmf_stop_channel(int bs_stop_freq, SampleFrequency sample_rate, int k0) {
/*  52 */     if (bs_stop_freq == 15) {
/*  53 */       return Math.min(64, k0 * 3);
/*     */     }
/*  55 */     if (bs_stop_freq == 14) {
/*  56 */       return Math.min(64, k0 * 2);
/*     */     }
/*     */ 
/*     */     
/*  60 */     int stopMin = stopMinTable[sample_rate.getIndex()];
/*     */ 
/*     */     
/*  63 */     return Math.min(64, stopMin + STOP_OFFSET_TABLE[sample_rate.getIndex()][Math.min(bs_stop_freq, 13)]);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static int master_frequency_table_fs0(SBR sbr, int k0, int k2, boolean bs_alter_scale) {
/*  79 */     int[] vDk = new int[64];
/*     */ 
/*     */     
/*  82 */     if (k2 <= k0) {
/*  83 */       sbr.N_master = 0;
/*  84 */       return 1;
/*     */     } 
/*     */     
/*  87 */     int dk = bs_alter_scale ? 2 : 1;
/*     */     
/*  89 */     if (bs_alter_scale) {
/*  90 */       nrBands = k2 - k0 + 2 >> 2 << 1;
/*     */     } else {
/*     */       
/*  93 */       nrBands = k2 - k0 >> 1 << 1;
/*     */     } 
/*  95 */     int nrBands = Math.min(nrBands, 63);
/*  96 */     if (nrBands <= 0) {
/*  97 */       return 1;
/*     */     }
/*  99 */     int k2Achieved = k0 + nrBands * dk;
/* 100 */     int k2Diff = k2 - k2Achieved; int k;
/* 101 */     for (k = 0; k < nrBands; k++) {
/* 102 */       vDk[k] = dk;
/*     */     }
/*     */     
/* 105 */     if (k2Diff != 0) {
/* 106 */       int incr = (k2Diff > 0) ? -1 : 1;
/* 107 */       k = (k2Diff > 0) ? (nrBands - 1) : 0;
/*     */       
/* 109 */       while (k2Diff != 0) {
/* 110 */         vDk[k] = vDk[k] - incr;
/* 111 */         k += incr;
/* 112 */         k2Diff += incr;
/*     */       } 
/*     */     } 
/*     */     
/* 116 */     sbr.f_master[0] = k0;
/* 117 */     for (k = 1; k <= nrBands; k++) {
/* 118 */       sbr.f_master[k] = sbr.f_master[k - 1] + vDk[k - 1];
/*     */     }
/*     */     
/* 121 */     sbr.N_master = nrBands;
/* 122 */     sbr.N_master = Math.min(sbr.N_master, 64);
/*     */     
/* 124 */     return 0;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static int find_bands(int warp, int bands, int a0, int a1) {
/* 132 */     float div = (float)Math.log(2.0D);
/* 133 */     if (warp != 0) div *= 1.3F;
/*     */     
/* 135 */     return (int)(bands * Math.log((a1 / a0)) / div + 0.5D);
/*     */   }
/*     */   
/*     */   public static float find_initial_power(int bands, int a0, int a1) {
/* 139 */     return (float)Math.pow((a1 / a0), (1.0F / bands));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static int master_frequency_table(SBR sbr, int k0, int k2, int bs_freq_scale, boolean bs_alter_scale) {
/*     */     boolean twoRegions;
/* 151 */     int k1, vDk0[] = new int[64], vDk1[] = new int[64];
/* 152 */     int[] vk0 = new int[64], vk1 = new int[64];
/* 153 */     int[] temp1 = { 6, 5, 4 };
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 158 */     if (k2 <= k0) {
/* 159 */       sbr.N_master = 0;
/* 160 */       return 1;
/*     */     } 
/*     */     
/* 163 */     int bands = temp1[bs_freq_scale - 1];
/*     */     
/* 165 */     if ((k2 / k0) > 2.2449D) {
/* 166 */       twoRegions = true;
/* 167 */       k1 = k0 << 1;
/*     */     } else {
/*     */       
/* 170 */       twoRegions = false;
/* 171 */       k1 = k2;
/*     */     } 
/*     */     
/* 174 */     int nrBand0 = 2 * find_bands(0, bands, k0, k1);
/* 175 */     nrBand0 = Math.min(nrBand0, 63);
/* 176 */     if (nrBand0 <= 0) {
/* 177 */       return 1;
/*     */     }
/* 179 */     float q = find_initial_power(nrBand0, k0, k1);
/* 180 */     float qk = k0;
/* 181 */     int A_1 = (int)(qk + 0.5F); int k;
/* 182 */     for (k = 0; k <= nrBand0; k++) {
/* 183 */       int A_0 = A_1;
/* 184 */       qk *= q;
/* 185 */       A_1 = (int)(qk + 0.5F);
/* 186 */       vDk0[k] = A_1 - A_0;
/*     */     } 
/*     */ 
/*     */ 
/*     */     
/* 191 */     Arrays.sort(vDk0, 0, nrBand0);
/*     */     
/* 193 */     vk0[0] = k0;
/* 194 */     for (k = 1; k <= nrBand0; k++) {
/* 195 */       vk0[k] = vk0[k - 1] + vDk0[k - 1];
/* 196 */       if (vDk0[k - 1] == 0) {
/* 197 */         return 1;
/*     */       }
/*     */     } 
/* 200 */     if (!twoRegions) {
/* 201 */       for (k = 0; k <= nrBand0; k++) {
/* 202 */         sbr.f_master[k] = vk0[k];
/*     */       }
/*     */       
/* 205 */       sbr.N_master = nrBand0;
/* 206 */       sbr.N_master = Math.min(sbr.N_master, 64);
/* 207 */       return 0;
/*     */     } 
/*     */     
/* 210 */     int nrBand1 = 2 * find_bands(1, bands, k1, k2);
/* 211 */     nrBand1 = Math.min(nrBand1, 63);
/*     */     
/* 213 */     q = find_initial_power(nrBand1, k1, k2);
/* 214 */     qk = k1;
/* 215 */     A_1 = (int)(qk + 0.5F);
/* 216 */     for (k = 0; k <= nrBand1 - 1; k++) {
/* 217 */       int A_0 = A_1;
/* 218 */       qk *= q;
/* 219 */       A_1 = (int)(qk + 0.5F);
/* 220 */       vDk1[k] = A_1 - A_0;
/*     */     } 
/*     */     
/* 223 */     if (vDk1[0] < vDk0[nrBand0 - 1]) {
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 228 */       Arrays.sort(vDk1, 0, nrBand1 + 1);
/* 229 */       int change = vDk0[nrBand0 - 1] - vDk1[0];
/* 230 */       vDk1[0] = vDk0[nrBand0 - 1];
/* 231 */       vDk1[nrBand1 - 1] = vDk1[nrBand1 - 1] - change;
/*     */     } 
/*     */ 
/*     */ 
/*     */     
/* 236 */     Arrays.sort(vDk1, 0, nrBand1);
/* 237 */     vk1[0] = k1;
/* 238 */     for (k = 1; k <= nrBand1; k++) {
/* 239 */       vk1[k] = vk1[k - 1] + vDk1[k - 1];
/* 240 */       if (vDk1[k - 1] == 0) {
/* 241 */         return 1;
/*     */       }
/*     */     } 
/* 244 */     sbr.N_master = nrBand0 + nrBand1;
/* 245 */     sbr.N_master = Math.min(sbr.N_master, 64);
/* 246 */     for (k = 0; k <= nrBand0; k++) {
/* 247 */       sbr.f_master[k] = vk0[k];
/*     */     }
/* 249 */     for (k = nrBand0 + 1; k <= sbr.N_master; k++) {
/* 250 */       sbr.f_master[k] = vk1[k - nrBand0];
/*     */     }
/*     */     
/* 253 */     return 0;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public static int derived_frequency_table(SBR sbr, int bs_xover_band, int k2) {
/* 259 */     int i = 0;
/*     */ 
/*     */ 
/*     */     
/* 263 */     if (sbr.N_master <= bs_xover_band) {
/* 264 */       return 1;
/*     */     }
/* 266 */     sbr.N_high = sbr.N_master - bs_xover_band;
/* 267 */     sbr.N_low = (sbr.N_high >> 1) + sbr.N_high - (sbr.N_high >> 1 << 1);
/*     */     
/* 269 */     sbr.n[0] = sbr.N_low;
/* 270 */     sbr.n[1] = sbr.N_high;
/*     */     int k;
/* 272 */     for (k = 0; k <= sbr.N_high; k++) {
/* 273 */       sbr.f_table_res[1][k] = sbr.f_master[k + bs_xover_band];
/*     */     }
/*     */     
/* 276 */     sbr.M = sbr.f_table_res[1][sbr.N_high] - sbr.f_table_res[1][0];
/* 277 */     sbr.kx = sbr.f_table_res[1][0];
/* 278 */     if (sbr.kx > 32)
/* 279 */       return 1; 
/* 280 */     if (sbr.kx + sbr.M > 64) {
/* 281 */       return 1;
/*     */     }
/* 283 */     int minus = ((sbr.N_high & 0x1) != 0) ? 1 : 0;
/*     */     
/* 285 */     for (k = 0; k <= sbr.N_low; k++) {
/* 286 */       if (k == 0) {
/* 287 */         i = 0;
/*     */       } else {
/* 289 */         i = 2 * k - minus;
/* 290 */       }  sbr.f_table_res[0][k] = sbr.f_table_res[1][i];
/*     */     } 
/*     */     
/* 293 */     sbr.N_Q = 0;
/* 294 */     if (sbr.bs_noise_bands == 0) {
/* 295 */       sbr.N_Q = 1;
/*     */     } else {
/*     */       
/* 298 */       sbr.N_Q = Math.max(1, find_bands(0, sbr.bs_noise_bands, sbr.kx, k2));
/* 299 */       sbr.N_Q = Math.min(5, sbr.N_Q);
/*     */     } 
/*     */     
/* 302 */     for (k = 0; k <= sbr.N_Q; k++) {
/* 303 */       if (k == 0) {
/* 304 */         i = 0;
/*     */       }
/*     */       else {
/*     */         
/* 308 */         i += (sbr.N_low - i) / (sbr.N_Q + 1 - k);
/*     */       } 
/* 310 */       sbr.f_table_noise[k] = sbr.f_table_res[0][i];
/*     */     } 
/*     */ 
/*     */     
/* 314 */     for (k = 0; k < 64; k++) {
/*     */       
/* 316 */       for (int g = 0; g < sbr.N_Q; g++) {
/* 317 */         if (sbr.f_table_noise[g] <= k && k < sbr.f_table_noise[g + 1]) {
/*     */           
/* 319 */           sbr.table_map_k_to_g[k] = g;
/*     */           break;
/*     */         } 
/*     */       } 
/*     */     } 
/* 324 */     return 0;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 332 */   private static final float[] limiterBandsCompare = new float[] { 1.327152F, 1.185093F, 1.119872F };
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static void limiter_frequency_table(SBR sbr) {
/* 340 */     sbr.f_table_lim[0][0] = sbr.f_table_res[0][0] - sbr.kx;
/* 341 */     sbr.f_table_lim[0][1] = sbr.f_table_res[0][sbr.N_low] - sbr.kx;
/* 342 */     sbr.N_L[0] = 1;
/*     */     
/* 344 */     for (int s = 1; s < 4; s++) {
/* 345 */       int[] limTable = new int[100];
/* 346 */       int[] patchBorders = new int[64];
/*     */       
/* 348 */       patchBorders[0] = sbr.kx; int k;
/* 349 */       for (k = 1; k <= sbr.noPatches; k++) {
/* 350 */         patchBorders[k] = patchBorders[k - 1] + sbr.patchNoSubbands[k - 1];
/*     */       }
/*     */       
/* 353 */       for (k = 0; k <= sbr.N_low; k++) {
/* 354 */         limTable[k] = sbr.f_table_res[0][k];
/*     */       }
/* 356 */       for (k = 1; k < sbr.noPatches; k++) {
/* 357 */         limTable[k + sbr.N_low] = patchBorders[k];
/*     */       }
/*     */ 
/*     */ 
/*     */       
/* 362 */       Arrays.sort(limTable, 0, sbr.noPatches + sbr.N_low);
/* 363 */       k = 1;
/* 364 */       int nrLim = sbr.noPatches + sbr.N_low - 1;
/*     */       
/* 366 */       if (nrLim < 0) {
/*     */         return;
/*     */       }
/*     */       
/* 370 */       while (k <= nrLim) {
/*     */         float nOctaves;
/*     */         
/* 373 */         if (limTable[k - 1] != 0) {
/* 374 */           nOctaves = limTable[k] / limTable[k - 1];
/*     */         } else {
/* 376 */           nOctaves = 0.0F;
/*     */         } 
/* 378 */         if (nOctaves < limiterBandsCompare[s - 1]) {
/*     */           
/* 380 */           if (limTable[k] != limTable[k - 1]) {
/* 381 */             boolean found = false, found2 = false; int i;
/* 382 */             for (i = 0; i <= sbr.noPatches; i++) {
/* 383 */               if (limTable[k] == patchBorders[i])
/* 384 */                 found = true; 
/*     */             } 
/* 386 */             if (found) {
/* 387 */               found2 = false;
/* 388 */               for (i = 0; i <= sbr.noPatches; i++) {
/* 389 */                 if (limTable[k - 1] == patchBorders[i])
/* 390 */                   found2 = true; 
/*     */               } 
/* 392 */               if (found2) {
/* 393 */                 k++;
/*     */                 
/*     */                 continue;
/*     */               } 
/*     */               
/* 398 */               limTable[k - 1] = sbr.f_table_res[0][sbr.N_low];
/*     */               
/* 400 */               Arrays.sort(limTable, 0, sbr.noPatches + sbr.N_low);
/* 401 */               nrLim--;
/*     */               
/*     */               continue;
/*     */             } 
/*     */           } 
/*     */           
/* 407 */           limTable[k] = sbr.f_table_res[0][sbr.N_low];
/*     */           
/* 409 */           Arrays.sort(limTable, 0, nrLim);
/* 410 */           nrLim--;
/*     */           
/*     */           continue;
/*     */         } 
/* 414 */         k++;
/*     */       } 
/*     */ 
/*     */ 
/*     */       
/* 419 */       sbr.N_L[s] = nrLim;
/* 420 */       for (k = 0; k <= nrLim; k++)
/* 421 */         sbr.f_table_lim[s][k] = limTable[k] - sbr.kx; 
/*     */     } 
/*     */   }
/*     */ }


/* Location:              C:\Users\rapha\Downloads\aurora.jar!\META-INF\jars\jcodec-0.2.5.jar!\net\sourceforge\jaad\aac\sbr\FBT.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */