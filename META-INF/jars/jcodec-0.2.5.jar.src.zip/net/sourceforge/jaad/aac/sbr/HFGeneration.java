/*     */ package net.sourceforge.jaad.aac.sbr;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ class HFGeneration
/*     */ {
/*  12 */   private static final int[] goalSbTab = new int[] { 21, 23, 32, 43, 46, 64, 85, 93, 128, 0, 0, 0 };
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static class acorr_coef
/*     */   {
/*  24 */     float[] r01 = new float[2];
/*  25 */     float[] r02 = new float[2];
/*  26 */     float[] r11 = new float[2];
/*  27 */     float[] r12 = new float[2];
/*  28 */     float[] r22 = new float[2];
/*     */     
/*     */     float det;
/*     */   }
/*     */ 
/*     */   
/*     */   public static void hf_generation(SBR sbr, float[][][] Xlow, float[][][] Xhigh, int ch) {
/*  35 */     float[][] alpha_0 = new float[64][2], alpha_1 = new float[64][2];
/*     */     
/*  37 */     int offset = sbr.tHFAdj;
/*  38 */     int first = sbr.t_E[ch][0];
/*  39 */     int last = sbr.t_E[ch][sbr.L_E[ch]];
/*     */     
/*  41 */     calc_chirp_factors(sbr, ch);
/*     */     
/*  43 */     if (ch == 0 && sbr.Reset) {
/*  44 */       patch_construction(sbr);
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*  49 */     for (int i = 0; i < sbr.noPatches; i++) {
/*  50 */       for (int x = 0; x < sbr.patchNoSubbands[i]; x++) {
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */         
/*  56 */         int k = sbr.kx + x;
/*  57 */         for (int q = 0; q < i; q++) {
/*  58 */           k += sbr.patchNoSubbands[q];
/*     */         }
/*  60 */         int p = sbr.patchStartSubband[i] + x;
/*     */         
/*  62 */         int g = sbr.table_map_k_to_g[k];
/*     */         
/*  64 */         float bw = sbr.bwArray[ch][g];
/*  65 */         float bw2 = bw * bw;
/*     */ 
/*     */ 
/*     */         
/*  69 */         if (bw2 > 0.0F) {
/*     */ 
/*     */           
/*  72 */           calc_prediction_coef(sbr, Xlow, alpha_0, alpha_1, p);
/*     */           
/*  74 */           float a0_r = alpha_0[p][0] * bw;
/*  75 */           float a1_r = alpha_1[p][0] * bw2;
/*  76 */           float a0_i = alpha_0[p][1] * bw;
/*  77 */           float a1_i = alpha_1[p][1] * bw2;
/*     */           
/*  79 */           float temp2_r = Xlow[first - 2 + offset][p][0];
/*  80 */           float temp3_r = Xlow[first - 1 + offset][p][0];
/*  81 */           float temp2_i = Xlow[first - 2 + offset][p][1];
/*  82 */           float temp3_i = Xlow[first - 1 + offset][p][1];
/*  83 */           for (int l = first; l < last; l++) {
/*  84 */             float temp1_r = temp2_r;
/*  85 */             temp2_r = temp3_r;
/*  86 */             temp3_r = Xlow[l + offset][p][0];
/*  87 */             float temp1_i = temp2_i;
/*  88 */             temp2_i = temp3_i;
/*  89 */             temp3_i = Xlow[l + offset][p][1];
/*     */             
/*  91 */             Xhigh[l + offset][k][0] = temp3_r + a0_r * temp2_r - a0_i * temp2_i + a1_r * temp1_r - a1_i * temp1_i;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */             
/*  97 */             Xhigh[l + offset][k][1] = temp3_i + a0_i * temp2_r + a0_r * temp2_i + a1_i * temp1_r + a1_r * temp1_i;
/*     */           
/*     */           }
/*     */ 
/*     */         
/*     */         }
/*     */         else {
/*     */ 
/*     */           
/* 106 */           for (int l = first; l < last; l++) {
/* 107 */             Xhigh[l + offset][k][0] = Xlow[l + offset][p][0];
/* 108 */             Xhigh[l + offset][k][1] = Xlow[l + offset][p][1];
/*     */           } 
/*     */         } 
/*     */       } 
/*     */     } 
/*     */     
/* 114 */     if (sbr.Reset) {
/* 115 */       FBT.limiter_frequency_table(sbr);
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   private static void auto_correlation(SBR sbr, acorr_coef ac, float[][][] buffer, int bd, int len) {
/* 121 */     float r01r = 0.0F, r01i = 0.0F, r02r = 0.0F, r02i = 0.0F, r11r = 0.0F;
/*     */     
/* 123 */     float rel = 0.99999905F;
/*     */     
/* 125 */     int offset = sbr.tHFAdj;
/*     */     
/* 127 */     float temp2_r = buffer[offset - 2][bd][0];
/* 128 */     float temp2_i = buffer[offset - 2][bd][1];
/* 129 */     float temp3_r = buffer[offset - 1][bd][0];
/* 130 */     float temp3_i = buffer[offset - 1][bd][1];
/*     */     
/* 132 */     float temp4_r = temp2_r;
/* 133 */     float temp4_i = temp2_i;
/* 134 */     float temp5_r = temp3_r;
/* 135 */     float temp5_i = temp3_i;
/*     */     
/* 137 */     for (int j = offset; j < len + offset; j++) {
/* 138 */       float temp1_r = temp2_r;
/* 139 */       float temp1_i = temp2_i;
/* 140 */       temp2_r = temp3_r;
/* 141 */       temp2_i = temp3_i;
/* 142 */       temp3_r = buffer[j][bd][0];
/* 143 */       temp3_i = buffer[j][bd][1];
/* 144 */       r01r += temp3_r * temp2_r + temp3_i * temp2_i;
/* 145 */       r01i += temp3_i * temp2_r - temp3_r * temp2_i;
/* 146 */       r02r += temp3_r * temp1_r + temp3_i * temp1_i;
/* 147 */       r02i += temp3_i * temp1_r - temp3_r * temp1_i;
/* 148 */       r11r += temp2_r * temp2_r + temp2_i * temp2_i;
/*     */     } 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 162 */     ac.r12[0] = r01r - temp3_r * temp2_r + temp3_i * temp2_i + temp5_r * temp4_r + temp5_i * temp4_i;
/*     */ 
/*     */     
/* 165 */     ac.r12[1] = r01i - temp3_i * temp2_r - temp3_r * temp2_i + temp5_i * temp4_r - temp5_r * temp4_i;
/*     */ 
/*     */     
/* 168 */     ac.r22[0] = r11r - temp2_r * temp2_r + temp2_i * temp2_i + temp4_r * temp4_r + temp4_i * temp4_i;
/*     */ 
/*     */ 
/*     */     
/* 172 */     ac.r01[0] = r01r;
/* 173 */     ac.r01[1] = r01i;
/* 174 */     ac.r02[0] = r02r;
/* 175 */     ac.r02[1] = r02i;
/* 176 */     ac.r11[0] = r11r;
/*     */     
/* 178 */     ac.det = ac.r11[0] * ac.r22[0] - rel * (ac.r12[0] * ac.r12[0] + ac.r12[1] * ac.r12[1]);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static void calc_prediction_coef(SBR sbr, float[][][] Xlow, float[][] alpha_0, float[][] alpha_1, int k) {
/* 185 */     acorr_coef ac = new acorr_coef();
/*     */     
/* 187 */     auto_correlation(sbr, ac, Xlow, k, sbr.numTimeSlotsRate + 6);
/*     */     
/* 189 */     if (ac.det == 0.0F) {
/* 190 */       alpha_1[k][0] = 0.0F;
/* 191 */       alpha_1[k][1] = 0.0F;
/*     */     } else {
/*     */       
/* 194 */       float tmp = 1.0F / ac.det;
/* 195 */       alpha_1[k][0] = (ac.r01[0] * ac.r12[0] - ac.r01[1] * ac.r12[1] - ac.r02[0] * ac.r11[0]) * tmp;
/* 196 */       alpha_1[k][1] = (ac.r01[1] * ac.r12[0] + ac.r01[0] * ac.r12[1] - ac.r02[1] * ac.r11[0]) * tmp;
/*     */     } 
/*     */     
/* 199 */     if (ac.r11[0] == 0.0F) {
/* 200 */       alpha_0[k][0] = 0.0F;
/* 201 */       alpha_0[k][1] = 0.0F;
/*     */     } else {
/*     */       
/* 204 */       float tmp = 1.0F / ac.r11[0];
/* 205 */       alpha_0[k][0] = -(ac.r01[0] + alpha_1[k][0] * ac.r12[0] + alpha_1[k][1] * ac.r12[1]) * tmp;
/* 206 */       alpha_0[k][1] = -(ac.r01[1] + alpha_1[k][1] * ac.r12[0] - alpha_1[k][0] * ac.r12[1]) * tmp;
/*     */     } 
/*     */     
/* 209 */     if (alpha_0[k][0] * alpha_0[k][0] + alpha_0[k][1] * alpha_0[k][1] >= 16.0F || alpha_1[k][0] * alpha_1[k][0] + alpha_1[k][1] * alpha_1[k][1] >= 16.0F) {
/*     */       
/* 211 */       alpha_0[k][0] = 0.0F;
/* 212 */       alpha_0[k][1] = 0.0F;
/* 213 */       alpha_1[k][0] = 0.0F;
/* 214 */       alpha_1[k][1] = 0.0F;
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   private static float mapNewBw(int invf_mode, int invf_mode_prev) {
/* 220 */     switch (invf_mode) {
/*     */       
/*     */       case 1:
/* 223 */         if (invf_mode_prev == 0) {
/* 224 */           return 0.6F;
/*     */         }
/* 226 */         return 0.75F;
/*     */ 
/*     */       
/*     */       case 2:
/* 230 */         return 0.9F;
/*     */ 
/*     */       
/*     */       case 3:
/* 234 */         return 0.98F;
/*     */     } 
/*     */ 
/*     */     
/* 238 */     if (invf_mode_prev == 1) {
/* 239 */       return 0.6F;
/*     */     }
/* 241 */     return 0.0F;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static void calc_chirp_factors(SBR sbr, int ch) {
/* 249 */     for (int i = 0; i < sbr.N_Q; i++) {
/* 250 */       sbr.bwArray[ch][i] = mapNewBw(sbr.bs_invf_mode[ch][i], sbr.bs_invf_mode_prev[ch][i]);
/*     */       
/* 252 */       if (sbr.bwArray[ch][i] < sbr.bwArray_prev[ch][i]) {
/* 253 */         sbr.bwArray[ch][i] = sbr.bwArray[ch][i] * 0.75F + sbr.bwArray_prev[ch][i] * 0.25F;
/*     */       } else {
/* 255 */         sbr.bwArray[ch][i] = sbr.bwArray[ch][i] * 0.90625F + sbr.bwArray_prev[ch][i] * 0.09375F;
/*     */       } 
/* 257 */       if (sbr.bwArray[ch][i] < 0.015625F) {
/* 258 */         sbr.bwArray[ch][i] = 0.0F;
/*     */       }
/* 260 */       if (sbr.bwArray[ch][i] >= 0.99609375F) {
/* 261 */         sbr.bwArray[ch][i] = 0.99609375F;
/*     */       }
/* 263 */       sbr.bwArray_prev[ch][i] = sbr.bwArray[ch][i];
/* 264 */       sbr.bs_invf_mode_prev[ch][i] = sbr.bs_invf_mode[ch][i];
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private static void patch_construction(SBR sbr) {
/* 271 */     int k, sb, msb = sbr.k0;
/* 272 */     int usb = sbr.kx;
/*     */     
/* 274 */     int goalSb = goalSbTab[sbr.sample_rate.getIndex()];
/*     */     
/* 276 */     sbr.noPatches = 0;
/*     */     
/* 278 */     if (goalSb < sbr.kx + sbr.M) {
/* 279 */       for (int i = 0; sbr.f_master[i] < goalSb; i++) {
/* 280 */         k = i + 1;
/*     */       }
/*     */     } else {
/*     */       
/* 284 */       k = sbr.N_master;
/*     */     } 
/*     */     
/* 287 */     if (sbr.N_master == 0) {
/* 288 */       sbr.noPatches = 0;
/* 289 */       sbr.patchNoSubbands[0] = 0;
/* 290 */       sbr.patchStartSubband[0] = 0;
/*     */       
/*     */       return;
/*     */     } 
/*     */     
/*     */     do {
/* 296 */       int odd, j = k + 1;
/*     */       
/*     */       do {
/* 299 */         j--;
/*     */         
/* 301 */         sb = sbr.f_master[j];
/* 302 */         odd = (sb - 2 + sbr.k0) % 2;
/*     */       }
/* 304 */       while (sb > sbr.k0 - 1 + msb - odd);
/*     */       
/* 306 */       sbr.patchNoSubbands[sbr.noPatches] = Math.max(sb - usb, 0);
/* 307 */       sbr.patchStartSubband[sbr.noPatches] = sbr.k0 - odd - sbr.patchNoSubbands[sbr.noPatches];
/*     */ 
/*     */       
/* 310 */       if (sbr.patchNoSubbands[sbr.noPatches] > 0) {
/* 311 */         usb = sb;
/* 312 */         msb = sb;
/* 313 */         sbr.noPatches++;
/*     */       } else {
/*     */         
/* 316 */         msb = sbr.kx;
/*     */       } 
/*     */       
/* 319 */       if (sbr.f_master[k] - sb >= 3)
/* 320 */         continue;  k = sbr.N_master;
/*     */     }
/* 322 */     while (sb != sbr.kx + sbr.M);
/*     */     
/* 324 */     if (sbr.patchNoSubbands[sbr.noPatches - 1] < 3 && sbr.noPatches > 1) {
/* 325 */       sbr.noPatches--;
/*     */     }
/*     */     
/* 328 */     sbr.noPatches = Math.min(sbr.noPatches, 5);
/*     */   }
/*     */ }


/* Location:              C:\Users\rapha\Downloads\aurora.jar!\META-INF\jars\jcodec-0.2.5.jar!\net\sourceforge\jaad\aac\sbr\HFGeneration.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */