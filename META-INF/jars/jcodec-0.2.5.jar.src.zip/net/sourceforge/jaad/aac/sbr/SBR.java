/*      */ package net.sourceforge.jaad.aac.sbr;
/*      */ 
/*      */ import java.util.Arrays;
/*      */ import net.sourceforge.jaad.aac.AACException;
/*      */ import net.sourceforge.jaad.aac.SampleFrequency;
/*      */ import net.sourceforge.jaad.aac.ps.PS;
/*      */ import net.sourceforge.jaad.aac.syntax.IBitStream;
/*      */ import net.sourceforge.jaad.aac.syntax.SyntaxConstants;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ public class SBR
/*      */   implements SBRConstants, SyntaxConstants, HuffmanTables
/*      */ {
/*      */   private final boolean downSampledSBR;
/*      */   final SampleFrequency sample_rate;
/*      */   int maxAACLine;
/*      */   int rate;
/*      */   boolean just_seeked;
/*      */   int ret;
/*      */   boolean[] amp_res;
/*      */   int k0;
/*      */   int kx;
/*      */   int M;
/*      */   int N_master;
/*      */   int N_high;
/*      */   int N_low;
/*      */   int N_Q;
/*      */   int[] N_L;
/*      */   int[] n;
/*      */   int[] f_master;
/*      */   int[][] f_table_res;
/*      */   int[] f_table_noise;
/*      */   int[][] f_table_lim;
/*      */   int[] table_map_k_to_g;
/*      */   int[] abs_bord_lead;
/*      */   int[] abs_bord_trail;
/*      */   int[] n_rel_lead;
/*      */   int[] n_rel_trail;
/*      */   int[] L_E;
/*      */   int[] L_E_prev;
/*      */   int[] L_Q;
/*      */   int[][] t_E;
/*      */   int[][] t_Q;
/*      */   int[][] f;
/*      */   int[] f_prev;
/*      */   float[][][] G_temp_prev;
/*      */   float[][][] Q_temp_prev;
/*      */   int[] GQ_ringbuf_index;
/*      */   int[][][] E;
/*      */   int[][] E_prev;
/*      */   float[][][] E_orig;
/*      */   float[][][] E_curr;
/*      */   int[][][] Q;
/*      */   float[][][] Q_div;
/*      */   float[][][] Q_div2;
/*      */   int[][] Q_prev;
/*      */   int[] l_A;
/*      */   int[] l_A_prev;
/*      */   int[][] bs_invf_mode;
/*      */   int[][] bs_invf_mode_prev;
/*      */   float[][] bwArray;
/*      */   float[][] bwArray_prev;
/*      */   int noPatches;
/*      */   int[] patchNoSubbands;
/*      */   int[] patchStartSubband;
/*      */   int[][] bs_add_harmonic;
/*      */   int[][] bs_add_harmonic_prev;
/*      */   int[] index_noise_prev;
/*      */   int[] psi_is_prev;
/*      */   int bs_start_freq_prev;
/*      */   int bs_stop_freq_prev;
/*      */   int bs_xover_band_prev;
/*      */   int bs_freq_scale_prev;
/*      */   boolean bs_alter_scale_prev;
/*      */   int bs_noise_bands_prev;
/*      */   int[] prevEnvIsShort;
/*      */   int kx_prev;
/*      */   int bsco;
/*      */   int bsco_prev;
/*      */   int M_prev;
/*      */   boolean Reset;
/*      */   int frame;
/*      */   int header_count;
/*      */   boolean stereo;
/*      */   AnalysisFilterbank[] qmfa;
/*      */   SynthesisFilterbank[] qmfs;
/*      */   float[][][][] Xsbr;
/*      */   int numTimeSlotsRate;
/*      */   int numTimeSlots;
/*      */   int tHFGen;
/*      */   int tHFAdj;
/*      */   PS ps;
/*      */   boolean ps_used;
/*      */   boolean psResetFlag;
/*      */   boolean bs_header_flag;
/*      */   int bs_crc_flag;
/*      */   int bs_sbr_crc_bits;
/*      */   int bs_protocol_version;
/*      */   boolean bs_amp_res;
/*      */   int bs_start_freq;
/*      */   int bs_stop_freq;
/*      */   int bs_xover_band;
/*      */   int bs_freq_scale;
/*      */   boolean bs_alter_scale;
/*      */   int bs_noise_bands;
/*      */   int bs_limiter_bands;
/*      */   int bs_limiter_gains;
/*      */   boolean bs_interpol_freq;
/*      */   boolean bs_smoothing_mode;
/*      */   int bs_samplerate_mode;
/*      */   boolean[] bs_add_harmonic_flag;
/*      */   boolean[] bs_add_harmonic_flag_prev;
/*      */   boolean bs_extended_data;
/*      */   int bs_extension_id;
/*      */   int bs_extension_data;
/*      */   boolean bs_coupling;
/*      */   int[] bs_frame_class;
/*      */   int[][] bs_rel_bord;
/*      */   int[][] bs_rel_bord_0;
/*      */   int[][] bs_rel_bord_1;
/*      */   int[] bs_pointer;
/*      */   int[] bs_abs_bord_0;
/*      */   int[] bs_abs_bord_1;
/*      */   int[] bs_num_rel_0;
/*      */   int[] bs_num_rel_1;
/*      */   int[][] bs_df_env;
/*      */   int[][] bs_df_noise;
/*      */   
/*      */   public SBR(boolean smallFrames, boolean stereo, SampleFrequency sample_rate, boolean downSampledSBR) {
/*  163 */     this.amp_res = new boolean[2];
/*  164 */     this.N_L = new int[4];
/*  165 */     this.n = new int[2];
/*  166 */     this.f_master = new int[64];
/*  167 */     this.f_table_res = new int[2][64];
/*  168 */     this.f_table_noise = new int[64];
/*  169 */     this.f_table_lim = new int[4][64];
/*  170 */     this.table_map_k_to_g = new int[64];
/*  171 */     this.abs_bord_lead = new int[2];
/*  172 */     this.abs_bord_trail = new int[2];
/*  173 */     this.n_rel_lead = new int[2];
/*  174 */     this.n_rel_trail = new int[2];
/*  175 */     this.L_E = new int[2];
/*  176 */     this.L_E_prev = new int[2];
/*  177 */     this.L_Q = new int[2];
/*  178 */     this.t_E = new int[2][6];
/*  179 */     this.t_Q = new int[2][3];
/*  180 */     this.f = new int[2][6];
/*  181 */     this.f_prev = new int[2];
/*  182 */     this.G_temp_prev = new float[2][5][64];
/*  183 */     this.Q_temp_prev = new float[2][5][64];
/*  184 */     this.GQ_ringbuf_index = new int[2];
/*  185 */     this.E = new int[2][64][5];
/*  186 */     this.E_prev = new int[2][64];
/*  187 */     this.E_orig = new float[2][64][5];
/*  188 */     this.E_curr = new float[2][64][5];
/*  189 */     this.Q = new int[2][64][2];
/*  190 */     this.Q_div = new float[2][64][2];
/*  191 */     this.Q_div2 = new float[2][64][2];
/*  192 */     this.Q_prev = new int[2][64];
/*  193 */     this.l_A = new int[2];
/*  194 */     this.l_A_prev = new int[2];
/*  195 */     this.bs_invf_mode = new int[2][5];
/*  196 */     this.bs_invf_mode_prev = new int[2][5];
/*  197 */     this.bwArray = new float[2][64];
/*  198 */     this.bwArray_prev = new float[2][64];
/*  199 */     this.patchNoSubbands = new int[64];
/*  200 */     this.patchStartSubband = new int[64];
/*  201 */     this.bs_add_harmonic = new int[2][64];
/*  202 */     this.bs_add_harmonic_prev = new int[2][64];
/*  203 */     this.index_noise_prev = new int[2];
/*  204 */     this.psi_is_prev = new int[2];
/*  205 */     this.prevEnvIsShort = new int[2];
/*  206 */     this.qmfa = new AnalysisFilterbank[2];
/*  207 */     this.qmfs = new SynthesisFilterbank[2];
/*  208 */     this.Xsbr = new float[2][40][64][2];
/*  209 */     this.bs_add_harmonic_flag = new boolean[2];
/*  210 */     this.bs_add_harmonic_flag_prev = new boolean[2];
/*  211 */     this.bs_frame_class = new int[2];
/*  212 */     this.bs_rel_bord = new int[2][9];
/*  213 */     this.bs_rel_bord_0 = new int[2][9];
/*  214 */     this.bs_rel_bord_1 = new int[2][9];
/*  215 */     this.bs_pointer = new int[2];
/*  216 */     this.bs_abs_bord_0 = new int[2];
/*  217 */     this.bs_abs_bord_1 = new int[2];
/*  218 */     this.bs_num_rel_0 = new int[2];
/*  219 */     this.bs_num_rel_1 = new int[2];
/*  220 */     this.bs_df_env = new int[2][9];
/*  221 */     this.bs_df_noise = new int[2][3];
/*      */ 
/*      */     
/*  224 */     this.downSampledSBR = downSampledSBR;
/*  225 */     this.stereo = stereo;
/*  226 */     this.sample_rate = sample_rate;
/*      */     
/*  228 */     this.bs_freq_scale = 2;
/*  229 */     this.bs_alter_scale = true;
/*  230 */     this.bs_noise_bands = 2;
/*  231 */     this.bs_limiter_bands = 2;
/*  232 */     this.bs_limiter_gains = 2;
/*  233 */     this.bs_interpol_freq = true;
/*  234 */     this.bs_smoothing_mode = true;
/*  235 */     this.bs_start_freq = 5;
/*  236 */     this.bs_amp_res = true;
/*  237 */     this.bs_samplerate_mode = 1;
/*  238 */     this.prevEnvIsShort[0] = -1;
/*  239 */     this.prevEnvIsShort[1] = -1;
/*  240 */     this.header_count = 0;
/*  241 */     this.Reset = true;
/*      */     
/*  243 */     this.tHFGen = 8;
/*  244 */     this.tHFAdj = 2;
/*      */     
/*  246 */     this.bsco = 0;
/*  247 */     this.bsco_prev = 0;
/*  248 */     this.M_prev = 0;
/*      */ 
/*      */     
/*  251 */     this.bs_start_freq_prev = -1;
/*      */     
/*  253 */     if (smallFrames) {
/*  254 */       this.numTimeSlotsRate = 30;
/*  255 */       this.numTimeSlots = 15;
/*      */     } else {
/*      */       
/*  258 */       this.numTimeSlotsRate = 32;
/*  259 */       this.numTimeSlots = 16;
/*      */     } 
/*      */     
/*  262 */     this.GQ_ringbuf_index[0] = 0;
/*  263 */     this.GQ_ringbuf_index[1] = 0;
/*      */     
/*  265 */     if (stereo) {
/*      */ 
/*      */       
/*  268 */       this.qmfa[0] = new AnalysisFilterbank(32);
/*  269 */       this.qmfa[1] = new AnalysisFilterbank(32);
/*  270 */       this.qmfs[0] = new SynthesisFilterbank(downSampledSBR ? 32 : 64);
/*  271 */       this.qmfs[1] = new SynthesisFilterbank(downSampledSBR ? 32 : 64);
/*      */     }
/*      */     else {
/*      */       
/*  275 */       this.qmfa[0] = new AnalysisFilterbank(32);
/*  276 */       this.qmfs[0] = new SynthesisFilterbank(downSampledSBR ? 32 : 64);
/*  277 */       this.qmfs[1] = null;
/*      */     } 
/*      */   }
/*      */ 
/*      */   
/*      */   void sbrReset() {
/*  283 */     if (this.qmfa[0] != null) this.qmfa[0].reset(); 
/*  284 */     if (this.qmfa[1] != null) this.qmfa[1].reset(); 
/*  285 */     if (this.qmfs[0] != null) this.qmfs[0].reset(); 
/*  286 */     if (this.qmfs[1] != null) this.qmfs[1].reset(); 
/*      */     int j;
/*  288 */     for (j = 0; j < 5; j++) {
/*  289 */       if (this.G_temp_prev[0][j] != null) Arrays.fill(this.G_temp_prev[0][j], 0.0F); 
/*  290 */       if (this.G_temp_prev[1][j] != null) Arrays.fill(this.G_temp_prev[1][j], 0.0F); 
/*  291 */       if (this.Q_temp_prev[0][j] != null) Arrays.fill(this.Q_temp_prev[0][j], 0.0F); 
/*  292 */       if (this.Q_temp_prev[1][j] != null) Arrays.fill(this.Q_temp_prev[1][j], 0.0F);
/*      */     
/*      */     } 
/*  295 */     for (int i = 0; i < 40; i++) {
/*  296 */       for (int k = 0; k < 64; k++) {
/*  297 */         this.Xsbr[0][i][j][0] = 0.0F;
/*  298 */         this.Xsbr[0][i][j][1] = 0.0F;
/*  299 */         this.Xsbr[1][i][j][0] = 0.0F;
/*  300 */         this.Xsbr[1][i][j][1] = 0.0F;
/*      */       } 
/*      */     } 
/*      */     
/*  304 */     this.GQ_ringbuf_index[0] = 0;
/*  305 */     this.GQ_ringbuf_index[1] = 0;
/*  306 */     this.header_count = 0;
/*  307 */     this.Reset = true;
/*      */     
/*  309 */     this.L_E_prev[0] = 0;
/*  310 */     this.L_E_prev[1] = 0;
/*  311 */     this.bs_freq_scale = 2;
/*  312 */     this.bs_alter_scale = true;
/*  313 */     this.bs_noise_bands = 2;
/*  314 */     this.bs_limiter_bands = 2;
/*  315 */     this.bs_limiter_gains = 2;
/*  316 */     this.bs_interpol_freq = true;
/*  317 */     this.bs_smoothing_mode = true;
/*  318 */     this.bs_start_freq = 5;
/*  319 */     this.bs_amp_res = true;
/*  320 */     this.bs_samplerate_mode = 1;
/*  321 */     this.prevEnvIsShort[0] = -1;
/*  322 */     this.prevEnvIsShort[1] = -1;
/*  323 */     this.bsco = 0;
/*  324 */     this.bsco_prev = 0;
/*  325 */     this.M_prev = 0;
/*  326 */     this.bs_start_freq_prev = -1;
/*      */     
/*  328 */     this.f_prev[0] = 0;
/*  329 */     this.f_prev[1] = 0;
/*  330 */     for (j = 0; j < 49; j++) {
/*  331 */       this.E_prev[0][j] = 0;
/*  332 */       this.Q_prev[0][j] = 0;
/*  333 */       this.E_prev[1][j] = 0;
/*  334 */       this.Q_prev[1][j] = 0;
/*  335 */       this.bs_add_harmonic_prev[0][j] = 0;
/*  336 */       this.bs_add_harmonic_prev[1][j] = 0;
/*      */     } 
/*  338 */     this.bs_add_harmonic_flag_prev[0] = false;
/*  339 */     this.bs_add_harmonic_flag_prev[1] = false;
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   void sbr_reset() {
/*  345 */     if (this.bs_start_freq != this.bs_start_freq_prev || this.bs_stop_freq != this.bs_stop_freq_prev || this.bs_freq_scale != this.bs_freq_scale_prev || this.bs_alter_scale != this.bs_alter_scale_prev || this.bs_xover_band != this.bs_xover_band_prev || this.bs_noise_bands != this.bs_noise_bands_prev) {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*  351 */       this.Reset = true;
/*      */     } else {
/*      */       
/*  354 */       this.Reset = false;
/*      */     } 
/*      */     
/*  357 */     this.bs_start_freq_prev = this.bs_start_freq;
/*  358 */     this.bs_stop_freq_prev = this.bs_stop_freq;
/*  359 */     this.bs_freq_scale_prev = this.bs_freq_scale;
/*  360 */     this.bs_alter_scale_prev = this.bs_alter_scale;
/*  361 */     this.bs_xover_band_prev = this.bs_xover_band;
/*  362 */     this.bs_noise_bands_prev = this.bs_noise_bands;
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   int calc_sbr_tables(int start_freq, int stop_freq, int samplerate_mode, int freq_scale, boolean alter_scale, int xover_band) {
/*  368 */     int result = 0;
/*      */ 
/*      */ 
/*      */     
/*  372 */     this.k0 = FBT.qmf_start_channel(start_freq, samplerate_mode, this.sample_rate);
/*  373 */     int k2 = FBT.qmf_stop_channel(stop_freq, this.sample_rate, this.k0);
/*      */ 
/*      */     
/*  376 */     if (this.sample_rate.getFrequency() >= 48000) {
/*  377 */       if (k2 - this.k0 > 32) {
/*  378 */         result++;
/*      */       }
/*  380 */     } else if (this.sample_rate.getFrequency() <= 32000) {
/*  381 */       if (k2 - this.k0 > 48) {
/*  382 */         result++;
/*      */       
/*      */       }
/*      */     }
/*  386 */     else if (k2 - this.k0 > 45) {
/*  387 */       result++;
/*      */     } 
/*      */     
/*  390 */     if (freq_scale == 0) {
/*  391 */       result += FBT.master_frequency_table_fs0(this, this.k0, k2, alter_scale);
/*      */     } else {
/*      */       
/*  394 */       result += FBT.master_frequency_table(this, this.k0, k2, freq_scale, alter_scale);
/*      */     } 
/*  396 */     result += FBT.derived_frequency_table(this, xover_band, k2);
/*      */     
/*  398 */     result = (result > 0) ? 1 : 0;
/*      */     
/*  400 */     return result;
/*      */   }
/*      */ 
/*      */   
/*      */   public int decode(IBitStream ld, int cnt) throws AACException {
/*  405 */     int result = 0;
/*  406 */     int num_align_bits = 0;
/*  407 */     long num_sbr_bits1 = ld.getPosition();
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  415 */     int bs_extension_type = ld.readBits(4);
/*      */     
/*  417 */     if (bs_extension_type == 14) {
/*  418 */       this.bs_sbr_crc_bits = ld.readBits(10);
/*      */     }
/*      */ 
/*      */     
/*  422 */     int saved_start_freq = this.bs_start_freq;
/*  423 */     int saved_samplerate_mode = this.bs_samplerate_mode;
/*  424 */     int saved_stop_freq = this.bs_stop_freq;
/*  425 */     int saved_freq_scale = this.bs_freq_scale;
/*  426 */     boolean saved_alter_scale = this.bs_alter_scale;
/*  427 */     int saved_xover_band = this.bs_xover_band;
/*      */     
/*  429 */     this.bs_header_flag = ld.readBool();
/*      */     
/*  431 */     if (this.bs_header_flag) {
/*  432 */       sbr_header(ld);
/*      */     }
/*      */     
/*  435 */     sbr_reset();
/*      */ 
/*      */ 
/*      */     
/*  439 */     if (this.header_count != 0) {
/*  440 */       if (this.Reset || (this.bs_header_flag && this.just_seeked)) {
/*  441 */         int rt = calc_sbr_tables(this.bs_start_freq, this.bs_stop_freq, this.bs_samplerate_mode, this.bs_freq_scale, this.bs_alter_scale, this.bs_xover_band);
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*  446 */         if (rt > 0) {
/*  447 */           calc_sbr_tables(saved_start_freq, saved_stop_freq, saved_samplerate_mode, saved_freq_scale, saved_alter_scale, saved_xover_band);
/*      */         }
/*      */       } 
/*      */ 
/*      */ 
/*      */       
/*  453 */       if (result == 0) {
/*  454 */         result = sbr_data(ld);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*  462 */         if (result > 0 && (this.Reset || (this.bs_header_flag && this.just_seeked)))
/*      */         {
/*  464 */           calc_sbr_tables(saved_start_freq, saved_stop_freq, saved_samplerate_mode, saved_freq_scale, saved_alter_scale, saved_xover_band);
/*      */         
/*      */         }
/*      */       
/*      */       }
/*      */ 
/*      */     
/*      */     }
/*      */     else {
/*      */       
/*  474 */       result = 1;
/*      */     } 
/*      */     
/*  477 */     int num_sbr_bits2 = (int)(ld.getPosition() - num_sbr_bits1);
/*      */ 
/*      */     
/*  480 */     if (8 * cnt < num_sbr_bits2) {
/*  481 */       throw new AACException("frame overread");
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  495 */     num_align_bits = 8 * cnt - num_sbr_bits2;
/*      */     
/*  497 */     while (num_align_bits > 7) {
/*  498 */       ld.readBits(8);
/*  499 */       num_align_bits -= 8;
/*      */     } 
/*  501 */     ld.readBits(num_align_bits);
/*      */ 
/*      */     
/*  504 */     return result;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private void sbr_header(IBitStream ld) throws AACException {
/*  511 */     this.header_count++;
/*      */     
/*  513 */     this.bs_amp_res = ld.readBool();
/*      */ 
/*      */ 
/*      */     
/*  517 */     this.bs_start_freq = ld.readBits(4);
/*  518 */     this.bs_stop_freq = ld.readBits(4);
/*  519 */     this.bs_xover_band = ld.readBits(3);
/*  520 */     ld.readBits(2);
/*  521 */     boolean bs_header_extra_1 = ld.readBool();
/*  522 */     boolean bs_header_extra_2 = ld.readBool();
/*      */     
/*  524 */     if (bs_header_extra_1) {
/*  525 */       this.bs_freq_scale = ld.readBits(2);
/*  526 */       this.bs_alter_scale = ld.readBool();
/*  527 */       this.bs_noise_bands = ld.readBits(2);
/*      */     }
/*      */     else {
/*      */       
/*  531 */       this.bs_freq_scale = 2;
/*  532 */       this.bs_alter_scale = true;
/*  533 */       this.bs_noise_bands = 2;
/*      */     } 
/*      */     
/*  536 */     if (bs_header_extra_2) {
/*  537 */       this.bs_limiter_bands = ld.readBits(2);
/*  538 */       this.bs_limiter_gains = ld.readBits(2);
/*  539 */       this.bs_interpol_freq = ld.readBool();
/*  540 */       this.bs_smoothing_mode = ld.readBool();
/*      */     }
/*      */     else {
/*      */       
/*  544 */       this.bs_limiter_bands = 2;
/*  545 */       this.bs_limiter_gains = 2;
/*  546 */       this.bs_interpol_freq = true;
/*  547 */       this.bs_smoothing_mode = true;
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private int sbr_data(IBitStream ld) throws AACException {
/*  556 */     this.rate = (this.bs_samplerate_mode != 0) ? 2 : 1;
/*      */     
/*  558 */     if (this.stereo) {
/*  559 */       int result; if ((result = sbr_channel_pair_element(ld)) > 0)
/*  560 */         return result; 
/*      */     } else {
/*      */       int result;
/*  563 */       if ((result = sbr_single_channel_element(ld)) > 0) {
/*  564 */         return result;
/*      */       }
/*      */     } 
/*  567 */     return 0;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private int sbr_single_channel_element(IBitStream ld) throws AACException {
/*  574 */     if (ld.readBool()) {
/*  575 */       ld.readBits(4);
/*      */     }
/*      */     int result;
/*  578 */     if ((result = sbr_grid(ld, 0)) > 0) {
/*  579 */       return result;
/*      */     }
/*  581 */     sbr_dtdf(ld, 0);
/*  582 */     invf_mode(ld, 0);
/*  583 */     sbr_envelope(ld, 0);
/*  584 */     sbr_noise(ld, 0);
/*      */     
/*  586 */     NoiseEnvelope.dequantChannel(this, 0);
/*      */     
/*  588 */     Arrays.fill(this.bs_add_harmonic[0], 0, 64, 0);
/*  589 */     Arrays.fill(this.bs_add_harmonic[1], 0, 64, 0);
/*      */     
/*  591 */     this.bs_add_harmonic_flag[0] = ld.readBool();
/*  592 */     if (this.bs_add_harmonic_flag[0]) {
/*  593 */       sinusoidal_coding(ld, 0);
/*      */     }
/*  595 */     this.bs_extended_data = ld.readBool();
/*      */     
/*  597 */     if (this.bs_extended_data) {
/*      */       
/*  599 */       int ps_ext_read = 0;
/*  600 */       int cnt = ld.readBits(4);
/*  601 */       if (cnt == 15) {
/*  602 */         cnt += ld.readBits(8);
/*      */       }
/*      */       
/*  605 */       int nr_bits_left = 8 * cnt;
/*  606 */       while (nr_bits_left > 7) {
/*  607 */         int tmp_nr_bits = 0;
/*      */         
/*  609 */         this.bs_extension_id = ld.readBits(2);
/*  610 */         tmp_nr_bits += 2;
/*      */ 
/*      */         
/*  613 */         if (this.bs_extension_id == 2) {
/*  614 */           if (ps_ext_read == 0) {
/*  615 */             ps_ext_read = 1;
/*      */           
/*      */           }
/*      */           else {
/*      */             
/*  620 */             this.bs_extension_id = 3;
/*      */           } 
/*      */         }
/*      */         
/*  624 */         tmp_nr_bits += sbr_extension(ld, this.bs_extension_id, nr_bits_left);
/*      */ 
/*      */         
/*  627 */         if (tmp_nr_bits > nr_bits_left) {
/*  628 */           return 1;
/*      */         }
/*  630 */         nr_bits_left -= tmp_nr_bits;
/*      */       } 
/*      */ 
/*      */       
/*  634 */       if (nr_bits_left > 0) {
/*  635 */         ld.readBits(nr_bits_left);
/*      */       }
/*      */     } 
/*      */     
/*  639 */     return 0;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private int sbr_channel_pair_element(IBitStream ld) throws AACException {
/*  646 */     if (ld.readBool()) {
/*      */       
/*  648 */       ld.readBits(4);
/*  649 */       ld.readBits(4);
/*      */     } 
/*      */     
/*  652 */     this.bs_coupling = ld.readBool();
/*      */     
/*  654 */     if (this.bs_coupling) {
/*  655 */       int result; if ((result = sbr_grid(ld, 0)) > 0) {
/*  656 */         return result;
/*      */       }
/*      */       
/*  659 */       this.bs_frame_class[1] = this.bs_frame_class[0];
/*  660 */       this.L_E[1] = this.L_E[0];
/*  661 */       this.L_Q[1] = this.L_Q[0];
/*  662 */       this.bs_pointer[1] = this.bs_pointer[0];
/*      */       int n;
/*  664 */       for (n = 0; n <= this.L_E[0]; n++) {
/*  665 */         this.t_E[1][n] = this.t_E[0][n];
/*  666 */         this.f[1][n] = this.f[0][n];
/*      */       } 
/*  668 */       for (n = 0; n <= this.L_Q[0]; n++) {
/*  669 */         this.t_Q[1][n] = this.t_Q[0][n];
/*      */       }
/*      */       
/*  672 */       sbr_dtdf(ld, 0);
/*  673 */       sbr_dtdf(ld, 1);
/*  674 */       invf_mode(ld, 0);
/*      */ 
/*      */       
/*  677 */       for (n = 0; n < this.N_Q; n++) {
/*  678 */         this.bs_invf_mode[1][n] = this.bs_invf_mode[0][n];
/*      */       }
/*      */       
/*  681 */       sbr_envelope(ld, 0);
/*  682 */       sbr_noise(ld, 0);
/*  683 */       sbr_envelope(ld, 1);
/*  684 */       sbr_noise(ld, 1);
/*      */       
/*  686 */       Arrays.fill(this.bs_add_harmonic[0], 0, 64, 0);
/*  687 */       Arrays.fill(this.bs_add_harmonic[1], 0, 64, 0);
/*      */       
/*  689 */       this.bs_add_harmonic_flag[0] = ld.readBool();
/*  690 */       if (this.bs_add_harmonic_flag[0]) {
/*  691 */         sinusoidal_coding(ld, 0);
/*      */       }
/*  693 */       this.bs_add_harmonic_flag[1] = ld.readBool();
/*  694 */       if (this.bs_add_harmonic_flag[1]) {
/*  695 */         sinusoidal_coding(ld, 1);
/*      */       }
/*      */     } else {
/*  698 */       int[] saved_t_E = new int[6], saved_t_Q = new int[3];
/*  699 */       int saved_L_E = this.L_E[0];
/*  700 */       int saved_L_Q = this.L_Q[0];
/*  701 */       int saved_frame_class = this.bs_frame_class[0];
/*      */       int n;
/*  703 */       for (n = 0; n < saved_L_E; n++) {
/*  704 */         saved_t_E[n] = this.t_E[0][n];
/*      */       }
/*  706 */       for (n = 0; n < saved_L_Q; n++) {
/*  707 */         saved_t_Q[n] = this.t_Q[0][n];
/*      */       }
/*      */       int result;
/*  710 */       if ((result = sbr_grid(ld, 0)) > 0)
/*  711 */         return result; 
/*  712 */       if ((result = sbr_grid(ld, 1)) > 0) {
/*      */         
/*  714 */         this.bs_frame_class[0] = saved_frame_class;
/*  715 */         this.L_E[0] = saved_L_E;
/*  716 */         this.L_Q[0] = saved_L_Q;
/*  717 */         for (n = 0; n < 6; n++) {
/*  718 */           this.t_E[0][n] = saved_t_E[n];
/*      */         }
/*  720 */         for (n = 0; n < 3; n++) {
/*  721 */           this.t_Q[0][n] = saved_t_Q[n];
/*      */         }
/*      */         
/*  724 */         return result;
/*      */       } 
/*  726 */       sbr_dtdf(ld, 0);
/*  727 */       sbr_dtdf(ld, 1);
/*  728 */       invf_mode(ld, 0);
/*  729 */       invf_mode(ld, 1);
/*  730 */       sbr_envelope(ld, 0);
/*  731 */       sbr_envelope(ld, 1);
/*  732 */       sbr_noise(ld, 0);
/*  733 */       sbr_noise(ld, 1);
/*      */       
/*  735 */       Arrays.fill(this.bs_add_harmonic[0], 0, 64, 0);
/*  736 */       Arrays.fill(this.bs_add_harmonic[1], 0, 64, 0);
/*      */       
/*  738 */       this.bs_add_harmonic_flag[0] = ld.readBool();
/*  739 */       if (this.bs_add_harmonic_flag[0]) {
/*  740 */         sinusoidal_coding(ld, 0);
/*      */       }
/*  742 */       this.bs_add_harmonic_flag[1] = ld.readBool();
/*  743 */       if (this.bs_add_harmonic_flag[1])
/*  744 */         sinusoidal_coding(ld, 1); 
/*      */     } 
/*  746 */     NoiseEnvelope.dequantChannel(this, 0);
/*  747 */     NoiseEnvelope.dequantChannel(this, 1);
/*      */     
/*  749 */     if (this.bs_coupling) {
/*  750 */       NoiseEnvelope.unmap(this);
/*      */     }
/*  752 */     this.bs_extended_data = ld.readBool();
/*  753 */     if (this.bs_extended_data) {
/*      */       
/*  755 */       int cnt = ld.readBits(4);
/*  756 */       if (cnt == 15) {
/*  757 */         cnt += ld.readBits(8);
/*      */       }
/*      */       
/*  760 */       int nr_bits_left = 8 * cnt;
/*  761 */       while (nr_bits_left > 7) {
/*  762 */         int tmp_nr_bits = 0;
/*      */         
/*  764 */         this.bs_extension_id = ld.readBits(2);
/*  765 */         tmp_nr_bits += 2;
/*  766 */         tmp_nr_bits += sbr_extension(ld, this.bs_extension_id, nr_bits_left);
/*      */ 
/*      */         
/*  769 */         if (tmp_nr_bits > nr_bits_left) {
/*  770 */           return 1;
/*      */         }
/*  772 */         nr_bits_left -= tmp_nr_bits;
/*      */       } 
/*      */ 
/*      */       
/*  776 */       if (nr_bits_left > 0) {
/*  777 */         ld.readBits(nr_bits_left);
/*      */       }
/*      */     } 
/*      */     
/*  781 */     return 0;
/*      */   }
/*      */ 
/*      */   
/*      */   private int sbr_log2(int val) {
/*  786 */     int[] log2tab = { 0, 0, 1, 2, 2, 3, 3, 3, 3, 4 };
/*  787 */     if (val < 10 && val >= 0) {
/*  788 */       return log2tab[val];
/*      */     }
/*  790 */     return 0;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private int sbr_grid(IBitStream ld, int ch) throws AACException {
/*  798 */     int i, env, rel, bs_abs_bord, bs_abs_bord_1, bs_num_env = 0;
/*  799 */     int saved_L_E = this.L_E[ch];
/*  800 */     int saved_L_Q = this.L_Q[ch];
/*  801 */     int saved_frame_class = this.bs_frame_class[ch];
/*      */     
/*  803 */     this.bs_frame_class[ch] = ld.readBits(2);
/*      */     
/*  805 */     switch (this.bs_frame_class[ch]) {
/*      */       case 0:
/*  807 */         i = ld.readBits(2);
/*      */         
/*  809 */         bs_num_env = Math.min(1 << i, 5);
/*      */         
/*  811 */         i = ld.readBit();
/*  812 */         for (env = 0; env < bs_num_env; env++) {
/*  813 */           this.f[ch][env] = i;
/*      */         }
/*      */         
/*  816 */         this.abs_bord_lead[ch] = 0;
/*  817 */         this.abs_bord_trail[ch] = this.numTimeSlots;
/*  818 */         this.n_rel_lead[ch] = bs_num_env - 1;
/*  819 */         this.n_rel_trail[ch] = 0;
/*      */         break;
/*      */       
/*      */       case 1:
/*  823 */         bs_abs_bord = ld.readBits(2) + this.numTimeSlots;
/*  824 */         bs_num_env = ld.readBits(2) + 1;
/*      */         
/*  826 */         for (rel = 0; rel < bs_num_env - 1; rel++) {
/*  827 */           this.bs_rel_bord[ch][rel] = 2 * ld.readBits(2) + 2;
/*      */         }
/*  829 */         i = sbr_log2(bs_num_env + 1);
/*  830 */         this.bs_pointer[ch] = ld.readBits(i);
/*      */         
/*  832 */         for (env = 0; env < bs_num_env; env++) {
/*  833 */           this.f[ch][bs_num_env - env - 1] = ld.readBit();
/*      */         }
/*      */         
/*  836 */         this.abs_bord_lead[ch] = 0;
/*  837 */         this.abs_bord_trail[ch] = bs_abs_bord;
/*  838 */         this.n_rel_lead[ch] = 0;
/*  839 */         this.n_rel_trail[ch] = bs_num_env - 1;
/*      */         break;
/*      */       
/*      */       case 2:
/*  843 */         bs_abs_bord = ld.readBits(2);
/*  844 */         bs_num_env = ld.readBits(2) + 1;
/*      */         
/*  846 */         for (rel = 0; rel < bs_num_env - 1; rel++) {
/*  847 */           this.bs_rel_bord[ch][rel] = 2 * ld.readBits(2) + 2;
/*      */         }
/*  849 */         i = sbr_log2(bs_num_env + 1);
/*  850 */         this.bs_pointer[ch] = ld.readBits(i);
/*      */         
/*  852 */         for (env = 0; env < bs_num_env; env++) {
/*  853 */           this.f[ch][env] = ld.readBit();
/*      */         }
/*      */         
/*  856 */         this.abs_bord_lead[ch] = bs_abs_bord;
/*  857 */         this.abs_bord_trail[ch] = this.numTimeSlots;
/*  858 */         this.n_rel_lead[ch] = bs_num_env - 1;
/*  859 */         this.n_rel_trail[ch] = 0;
/*      */         break;
/*      */       
/*      */       case 3:
/*  863 */         bs_abs_bord = ld.readBits(2);
/*  864 */         bs_abs_bord_1 = ld.readBits(2) + this.numTimeSlots;
/*  865 */         this.bs_num_rel_0[ch] = ld.readBits(2);
/*  866 */         this.bs_num_rel_1[ch] = ld.readBits(2);
/*      */         
/*  868 */         bs_num_env = Math.min(5, this.bs_num_rel_0[ch] + this.bs_num_rel_1[ch] + 1);
/*      */         
/*  870 */         for (rel = 0; rel < this.bs_num_rel_0[ch]; rel++) {
/*  871 */           this.bs_rel_bord_0[ch][rel] = 2 * ld.readBits(2) + 2;
/*      */         }
/*  873 */         for (rel = 0; rel < this.bs_num_rel_1[ch]; rel++) {
/*  874 */           this.bs_rel_bord_1[ch][rel] = 2 * ld.readBits(2) + 2;
/*      */         }
/*  876 */         i = sbr_log2(this.bs_num_rel_0[ch] + this.bs_num_rel_1[ch] + 2);
/*  877 */         this.bs_pointer[ch] = ld.readBits(i);
/*      */         
/*  879 */         for (env = 0; env < bs_num_env; env++) {
/*  880 */           this.f[ch][env] = ld.readBit();
/*      */         }
/*      */         
/*  883 */         this.abs_bord_lead[ch] = bs_abs_bord;
/*  884 */         this.abs_bord_trail[ch] = bs_abs_bord_1;
/*  885 */         this.n_rel_lead[ch] = this.bs_num_rel_0[ch];
/*  886 */         this.n_rel_trail[ch] = this.bs_num_rel_1[ch];
/*      */         break;
/*      */     } 
/*      */     
/*  890 */     if (this.bs_frame_class[ch] == 3) {
/*  891 */       this.L_E[ch] = Math.min(bs_num_env, 5);
/*      */     } else {
/*  893 */       this.L_E[ch] = Math.min(bs_num_env, 4);
/*      */     } 
/*  895 */     if (this.L_E[ch] <= 0) {
/*  896 */       return 1;
/*      */     }
/*  898 */     if (this.L_E[ch] > 1) {
/*  899 */       this.L_Q[ch] = 2;
/*      */     } else {
/*  901 */       this.L_Q[ch] = 1;
/*      */     } 
/*      */     int result;
/*  904 */     if ((result = TFGrid.envelope_time_border_vector(this, ch)) > 0) {
/*  905 */       this.bs_frame_class[ch] = saved_frame_class;
/*  906 */       this.L_E[ch] = saved_L_E;
/*  907 */       this.L_Q[ch] = saved_L_Q;
/*  908 */       return result;
/*      */     } 
/*  910 */     TFGrid.noise_floor_time_border_vector(this, ch);
/*      */     
/*  912 */     return 0;
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   private void sbr_dtdf(IBitStream ld, int ch) throws AACException {
/*      */     int i;
/*  919 */     for (i = 0; i < this.L_E[ch]; i++) {
/*  920 */       this.bs_df_env[ch][i] = ld.readBit();
/*      */     }
/*      */     
/*  923 */     for (i = 0; i < this.L_Q[ch]; i++) {
/*  924 */       this.bs_df_noise[ch][i] = ld.readBit();
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private void invf_mode(IBitStream ld, int ch) throws AACException {
/*  932 */     for (int n = 0; n < this.N_Q; n++) {
/*  933 */       this.bs_invf_mode[ch][n] = ld.readBits(2);
/*      */     }
/*      */   }
/*      */ 
/*      */   
/*      */   private int sbr_extension(IBitStream ld, int bs_extension_id, int num_bits_left) throws AACException {
/*      */     int ret;
/*  940 */     switch (bs_extension_id) {
/*      */       case 2:
/*  942 */         if (this.ps == null) {
/*  943 */           this.ps = new PS(this.sample_rate, this.numTimeSlotsRate);
/*      */         }
/*  945 */         if (this.psResetFlag) {
/*  946 */           this.ps.header_read = false;
/*      */         }
/*  948 */         ret = this.ps.decode(ld);
/*      */ 
/*      */         
/*  951 */         if (!this.ps_used && this.ps.header_read) {
/*  952 */           this.ps_used = true;
/*      */         }
/*      */         
/*  955 */         if (this.ps.header_read) {
/*  956 */           this.psResetFlag = false;
/*      */         }
/*      */         
/*  959 */         return ret;
/*      */     } 
/*  961 */     this.bs_extension_data = ld.readBits(6);
/*  962 */     return 6;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private void sinusoidal_coding(IBitStream ld, int ch) throws AACException {
/*  970 */     for (int n = 0; n < this.N_high; n++) {
/*  971 */       this.bs_add_harmonic[ch][n] = ld.readBit();
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   private void sbr_envelope(IBitStream ld, int ch) throws AACException {
/*  978 */     int t_huff[][], f_huff[][], delta = 0;
/*      */ 
/*      */     
/*  981 */     if (this.L_E[ch] == 1 && this.bs_frame_class[ch] == 0) {
/*  982 */       this.amp_res[ch] = false;
/*      */     } else {
/*  984 */       this.amp_res[ch] = this.bs_amp_res;
/*      */     } 
/*  986 */     if (this.bs_coupling && ch == 1) {
/*  987 */       delta = 1;
/*  988 */       if (this.amp_res[ch]) {
/*  989 */         t_huff = T_HUFFMAN_ENV_BAL_3_0DB;
/*  990 */         f_huff = F_HUFFMAN_ENV_BAL_3_0DB;
/*      */       } else {
/*      */         
/*  993 */         t_huff = T_HUFFMAN_ENV_BAL_1_5DB;
/*  994 */         f_huff = F_HUFFMAN_ENV_BAL_1_5DB;
/*      */       } 
/*      */     } else {
/*      */       
/*  998 */       delta = 0;
/*  999 */       if (this.amp_res[ch]) {
/* 1000 */         t_huff = T_HUFFMAN_ENV_3_0DB;
/* 1001 */         f_huff = F_HUFFMAN_ENV_3_0DB;
/*      */       } else {
/*      */         
/* 1004 */         t_huff = T_HUFFMAN_ENV_1_5DB;
/* 1005 */         f_huff = F_HUFFMAN_ENV_1_5DB;
/*      */       } 
/*      */     } 
/*      */     
/* 1009 */     for (int env = 0; env < this.L_E[ch]; env++) {
/* 1010 */       if (this.bs_df_env[ch][env] == 0) {
/* 1011 */         if (this.bs_coupling && ch == 1) {
/* 1012 */           if (this.amp_res[ch]) {
/* 1013 */             this.E[ch][0][env] = ld.readBits(5) << delta;
/*      */           } else {
/*      */             
/* 1016 */             this.E[ch][0][env] = ld.readBits(6) << delta;
/*      */           }
/*      */         
/*      */         }
/* 1020 */         else if (this.amp_res[ch]) {
/* 1021 */           this.E[ch][0][env] = ld.readBits(6) << delta;
/*      */         } else {
/*      */           
/* 1024 */           this.E[ch][0][env] = ld.readBits(7) << delta;
/*      */         } 
/*      */ 
/*      */         
/* 1028 */         for (int band = 1; band < this.n[this.f[ch][env]]; band++) {
/* 1029 */           this.E[ch][band][env] = decodeHuffman(ld, f_huff) << delta;
/*      */         }
/*      */       }
/*      */       else {
/*      */         
/* 1034 */         for (int band = 0; band < this.n[this.f[ch][env]]; band++) {
/* 1035 */           this.E[ch][band][env] = decodeHuffman(ld, t_huff) << delta;
/*      */         }
/*      */       } 
/*      */     } 
/*      */     
/* 1040 */     NoiseEnvelope.extract_envelope_data(this, ch);
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   private void sbr_noise(IBitStream ld, int ch) throws AACException {
/* 1046 */     int t_huff[][], f_huff[][], delta = 0;
/*      */ 
/*      */     
/* 1049 */     if (this.bs_coupling && ch == 1) {
/* 1050 */       delta = 1;
/* 1051 */       t_huff = T_HUFFMAN_NOISE_BAL_3_0DB;
/* 1052 */       f_huff = F_HUFFMAN_ENV_BAL_3_0DB;
/*      */     } else {
/*      */       
/* 1055 */       delta = 0;
/* 1056 */       t_huff = T_HUFFMAN_NOISE_3_0DB;
/* 1057 */       f_huff = F_HUFFMAN_ENV_3_0DB;
/*      */     } 
/*      */     
/* 1060 */     for (int noise = 0; noise < this.L_Q[ch]; noise++) {
/* 1061 */       if (this.bs_df_noise[ch][noise] == 0) {
/* 1062 */         if (this.bs_coupling && ch == 1) {
/* 1063 */           this.Q[ch][0][noise] = ld.readBits(5) << delta;
/*      */         } else {
/*      */           
/* 1066 */           this.Q[ch][0][noise] = ld.readBits(5) << delta;
/*      */         } 
/* 1068 */         for (int band = 1; band < this.N_Q; band++) {
/* 1069 */           this.Q[ch][band][noise] = decodeHuffman(ld, f_huff) << delta;
/*      */         }
/*      */       } else {
/*      */         
/* 1073 */         for (int band = 0; band < this.N_Q; band++) {
/* 1074 */           this.Q[ch][band][noise] = decodeHuffman(ld, t_huff) << delta;
/*      */         }
/*      */       } 
/*      */     } 
/*      */     
/* 1079 */     NoiseEnvelope.extract_noise_floor_data(this, ch);
/*      */   }
/*      */ 
/*      */   
/*      */   private int decodeHuffman(IBitStream ld, int[][] t_huff) throws AACException {
/* 1084 */     int index = 0;
/*      */     
/* 1086 */     while (index >= 0) {
/* 1087 */       int bit = ld.readBit();
/* 1088 */       index = t_huff[index][bit];
/*      */     } 
/*      */     
/* 1091 */     return index + 64;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private int sbr_save_prev_data(int ch) {
/* 1098 */     this.kx_prev = this.kx;
/* 1099 */     this.M_prev = this.M;
/* 1100 */     this.bsco_prev = this.bsco;
/*      */     
/* 1102 */     this.L_E_prev[ch] = this.L_E[ch];
/*      */ 
/*      */     
/* 1105 */     if (this.L_E[ch] <= 0) {
/* 1106 */       return 19;
/*      */     }
/* 1108 */     this.f_prev[ch] = this.f[ch][this.L_E[ch] - 1]; int i;
/* 1109 */     for (i = 0; i < 49; i++) {
/* 1110 */       this.E_prev[ch][i] = this.E[ch][i][this.L_E[ch] - 1];
/* 1111 */       this.Q_prev[ch][i] = this.Q[ch][i][this.L_Q[ch] - 1];
/*      */     } 
/*      */     
/* 1114 */     for (i = 0; i < 49; i++) {
/* 1115 */       this.bs_add_harmonic_prev[ch][i] = this.bs_add_harmonic[ch][i];
/*      */     }
/* 1117 */     this.bs_add_harmonic_flag_prev[ch] = this.bs_add_harmonic_flag[ch];
/*      */     
/* 1119 */     if (this.l_A[ch] == this.L_E[ch]) {
/* 1120 */       this.prevEnvIsShort[ch] = 0;
/*      */     } else {
/* 1122 */       this.prevEnvIsShort[ch] = -1;
/*      */     } 
/* 1124 */     return 0;
/*      */   }
/*      */ 
/*      */   
/*      */   private void sbr_save_matrix(int ch) {
/*      */     int i;
/* 1130 */     for (i = 0; i < this.tHFGen; i++) {
/* 1131 */       for (int j = 0; j < 64; j++) {
/* 1132 */         this.Xsbr[ch][i][j][0] = this.Xsbr[ch][i + this.numTimeSlotsRate][j][0];
/* 1133 */         this.Xsbr[ch][i][j][1] = this.Xsbr[ch][i + this.numTimeSlotsRate][j][1];
/*      */       } 
/*      */     } 
/* 1136 */     for (i = this.tHFGen; i < 40; i++) {
/* 1137 */       for (int j = 0; j < 64; j++) {
/* 1138 */         this.Xsbr[ch][i][j][0] = 0.0F;
/* 1139 */         this.Xsbr[ch][i][j][1] = 0.0F;
/*      */       } 
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   private int sbr_process_channel(float[] channel_buf, float[][][] X, int ch, boolean dont_process) {
/* 1147 */     int ret = 0;
/*      */     
/* 1149 */     this.bsco = 0;
/*      */ 
/*      */     
/* 1152 */     if (dont_process) {
/* 1153 */       this.qmfa[ch].sbr_qmf_analysis_32(this, channel_buf, this.Xsbr[ch], this.tHFGen, 32);
/*      */     } else {
/* 1155 */       this.qmfa[ch].sbr_qmf_analysis_32(this, channel_buf, this.Xsbr[ch], this.tHFGen, this.kx);
/*      */     } 
/* 1157 */     if (!dont_process) {
/*      */ 
/*      */       
/* 1160 */       HFGeneration.hf_generation(this, this.Xsbr[ch], this.Xsbr[ch], ch);
/*      */ 
/*      */ 
/*      */       
/* 1164 */       ret = HFAdjustment.hf_adjustment(this, this.Xsbr[ch], ch);
/* 1165 */       if (ret > 0) {
/* 1166 */         dont_process = true;
/*      */       }
/*      */     } 
/*      */     
/* 1170 */     if (this.just_seeked || dont_process) {
/* 1171 */       for (int l = 0; l < this.numTimeSlotsRate; l++) {
/* 1172 */         int k; for (k = 0; k < 32; k++) {
/* 1173 */           X[l][k][0] = this.Xsbr[ch][l + this.tHFAdj][k][0];
/* 1174 */           X[l][k][1] = this.Xsbr[ch][l + this.tHFAdj][k][1];
/*      */         } 
/* 1176 */         for (k = 32; k < 64; k++) {
/* 1177 */           X[l][k][0] = 0.0F;
/* 1178 */           X[l][k][1] = 0.0F;
/*      */         } 
/*      */       } 
/*      */     } else {
/*      */       
/* 1183 */       for (int l = 0; l < this.numTimeSlotsRate; l++) {
/*      */         int kx_band; int M_band;
/*      */         int bsco_band;
/* 1186 */         if (l < this.t_E[ch][0]) {
/* 1187 */           kx_band = this.kx_prev;
/* 1188 */           M_band = this.M_prev;
/* 1189 */           bsco_band = this.bsco_prev;
/*      */         } else {
/*      */           
/* 1192 */           kx_band = this.kx;
/* 1193 */           M_band = this.M;
/* 1194 */           bsco_band = this.bsco;
/*      */         } 
/*      */         int k;
/* 1197 */         for (k = 0; k < kx_band + bsco_band; k++) {
/* 1198 */           X[l][k][0] = this.Xsbr[ch][l + this.tHFAdj][k][0];
/* 1199 */           X[l][k][1] = this.Xsbr[ch][l + this.tHFAdj][k][1];
/*      */         } 
/* 1201 */         for (k = kx_band + bsco_band; k < kx_band + M_band; k++) {
/* 1202 */           X[l][k][0] = this.Xsbr[ch][l + this.tHFAdj][k][0];
/* 1203 */           X[l][k][1] = this.Xsbr[ch][l + this.tHFAdj][k][1];
/*      */         } 
/* 1205 */         for (k = Math.max(kx_band + bsco_band, kx_band + M_band); k < 64; k++) {
/* 1206 */           X[l][k][0] = 0.0F;
/* 1207 */           X[l][k][1] = 0.0F;
/*      */         } 
/*      */       } 
/*      */     } 
/*      */     
/* 1212 */     return ret;
/*      */   }
/*      */ 
/*      */   
/*      */   public int _process(float[] left_chan, float[] right_chan, boolean just_seeked) {
/* 1217 */     boolean dont_process = false;
/* 1218 */     int ret = 0;
/* 1219 */     float[][][] X = new float[32][64][2];
/*      */ 
/*      */     
/* 1222 */     if (!this.stereo) return 21;
/*      */     
/* 1224 */     if (this.ret != 0 || this.header_count == 0) {
/*      */       
/* 1226 */       dont_process = true;
/*      */ 
/*      */       
/* 1229 */       if (this.ret != 0 && this.Reset) {
/* 1230 */         this.bs_start_freq_prev = -1;
/*      */       }
/*      */     } 
/* 1233 */     if (just_seeked) {
/* 1234 */       this.just_seeked = true;
/*      */     } else {
/*      */       
/* 1237 */       this.just_seeked = false;
/*      */     } 
/*      */     
/* 1240 */     this.ret += sbr_process_channel(left_chan, X, 0, dont_process);
/*      */     
/* 1242 */     if (this.downSampledSBR) {
/* 1243 */       this.qmfs[0].sbr_qmf_synthesis_32(this, X, left_chan);
/*      */     } else {
/*      */       
/* 1246 */       this.qmfs[0].sbr_qmf_synthesis_64(this, X, left_chan);
/*      */     } 
/*      */     
/* 1249 */     this.ret += sbr_process_channel(right_chan, X, 1, dont_process);
/*      */     
/* 1251 */     if (this.downSampledSBR) {
/* 1252 */       this.qmfs[1].sbr_qmf_synthesis_32(this, X, right_chan);
/*      */     } else {
/*      */       
/* 1255 */       this.qmfs[1].sbr_qmf_synthesis_64(this, X, right_chan);
/*      */     } 
/*      */     
/* 1258 */     if (this.bs_header_flag) {
/* 1259 */       this.just_seeked = false;
/*      */     }
/* 1261 */     if (this.header_count != 0 && this.ret == 0) {
/* 1262 */       ret = sbr_save_prev_data(0);
/* 1263 */       if (ret != 0) return ret; 
/* 1264 */       ret = sbr_save_prev_data(1);
/* 1265 */       if (ret != 0) return ret;
/*      */     
/*      */     } 
/* 1268 */     sbr_save_matrix(0);
/* 1269 */     sbr_save_matrix(1);
/*      */     
/* 1271 */     this.frame++;
/*      */     
/* 1273 */     return 0;
/*      */   }
/*      */ 
/*      */   
/*      */   public int process(float[] channel, boolean just_seeked) {
/* 1278 */     boolean dont_process = false;
/* 1279 */     int ret = 0;
/* 1280 */     float[][][] X = new float[32][64][2];
/*      */ 
/*      */     
/* 1283 */     if (this.stereo) return 21;
/*      */     
/* 1285 */     if (this.ret != 0 || this.header_count == 0) {
/*      */       
/* 1287 */       dont_process = true;
/*      */ 
/*      */       
/* 1290 */       if (this.ret != 0 && this.Reset) {
/* 1291 */         this.bs_start_freq_prev = -1;
/*      */       }
/*      */     } 
/* 1294 */     if (just_seeked) {
/* 1295 */       this.just_seeked = true;
/*      */     } else {
/*      */       
/* 1298 */       this.just_seeked = false;
/*      */     } 
/*      */     
/* 1301 */     this.ret += sbr_process_channel(channel, X, 0, dont_process);
/*      */     
/* 1303 */     if (this.downSampledSBR) {
/* 1304 */       this.qmfs[0].sbr_qmf_synthesis_32(this, X, channel);
/*      */     } else {
/*      */       
/* 1307 */       this.qmfs[0].sbr_qmf_synthesis_64(this, X, channel);
/*      */     } 
/*      */     
/* 1310 */     if (this.bs_header_flag) {
/* 1311 */       this.just_seeked = false;
/*      */     }
/* 1313 */     if (this.header_count != 0 && this.ret == 0) {
/* 1314 */       ret = sbr_save_prev_data(0);
/* 1315 */       if (ret != 0) return ret;
/*      */     
/*      */     } 
/* 1318 */     sbr_save_matrix(0);
/*      */     
/* 1320 */     this.frame++;
/*      */     
/* 1322 */     return 0;
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public int processPS(float[] left_channel, float[] right_channel, boolean just_seeked) {
/* 1328 */     boolean dont_process = false;
/* 1329 */     int ret = 0;
/* 1330 */     float[][][] X_left = new float[38][64][2];
/* 1331 */     float[][][] X_right = new float[38][64][2];
/*      */ 
/*      */     
/* 1334 */     if (this.stereo) return 21;
/*      */     
/* 1336 */     if (this.ret != 0 || this.header_count == 0) {
/*      */       
/* 1338 */       dont_process = true;
/*      */ 
/*      */       
/* 1341 */       if (this.ret != 0 && this.Reset) {
/* 1342 */         this.bs_start_freq_prev = -1;
/*      */       }
/*      */     } 
/* 1345 */     if (just_seeked) {
/* 1346 */       this.just_seeked = true;
/*      */     } else {
/*      */       
/* 1349 */       this.just_seeked = false;
/*      */     } 
/*      */     
/* 1352 */     if (this.qmfs[1] == null) {
/* 1353 */       this.qmfs[1] = new SynthesisFilterbank(this.downSampledSBR ? 32 : 64);
/*      */     }
/*      */     
/* 1356 */     this.ret += sbr_process_channel(left_channel, X_left, 0, dont_process);
/*      */ 
/*      */     
/* 1359 */     for (int l = this.numTimeSlotsRate; l < this.numTimeSlotsRate + 6; l++) {
/* 1360 */       for (int k = 0; k < 5; k++) {
/* 1361 */         X_left[l][k][0] = this.Xsbr[0][this.tHFAdj + l][k][0];
/* 1362 */         X_left[l][k][1] = this.Xsbr[0][this.tHFAdj + l][k][1];
/*      */       } 
/*      */     } 
/*      */ 
/*      */     
/* 1367 */     this.ps.process(X_left, X_right);
/*      */ 
/*      */     
/* 1370 */     if (this.downSampledSBR) {
/* 1371 */       this.qmfs[0].sbr_qmf_synthesis_32(this, X_left, left_channel);
/* 1372 */       this.qmfs[1].sbr_qmf_synthesis_32(this, X_right, right_channel);
/*      */     } else {
/*      */       
/* 1375 */       this.qmfs[0].sbr_qmf_synthesis_64(this, X_left, left_channel);
/* 1376 */       this.qmfs[1].sbr_qmf_synthesis_64(this, X_right, right_channel);
/*      */     } 
/*      */     
/* 1379 */     if (this.bs_header_flag) {
/* 1380 */       this.just_seeked = false;
/*      */     }
/* 1382 */     if (this.header_count != 0 && this.ret == 0) {
/* 1383 */       ret = sbr_save_prev_data(0);
/* 1384 */       if (ret != 0) return ret;
/*      */     
/*      */     } 
/* 1387 */     sbr_save_matrix(0);
/*      */     
/* 1389 */     this.frame++;
/*      */     
/* 1391 */     return 0;
/*      */   }
/*      */   
/*      */   public boolean isPSUsed() {
/* 1395 */     return this.ps_used;
/*      */   }
/*      */ }


/* Location:              C:\Users\rapha\Downloads\aurora.jar!\META-INF\jars\jcodec-0.2.5.jar!\net\sourceforge\jaad\aac\sbr\SBR.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */