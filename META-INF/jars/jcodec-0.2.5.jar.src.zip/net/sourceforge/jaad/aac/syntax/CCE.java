/*     */ package net.sourceforge.jaad.aac.syntax;
/*     */ 
/*     */ import net.sourceforge.jaad.aac.AACDecoderConfig;
/*     */ import net.sourceforge.jaad.aac.AACException;
/*     */ import net.sourceforge.jaad.aac.huffman.Huffman;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ class CCE
/*     */   extends Element
/*     */   implements SyntaxConstants
/*     */ {
/*     */   public static final int BEFORE_TNS = 0;
/*     */   public static final int AFTER_TNS = 1;
/*     */   public static final int AFTER_IMDCT = 2;
/*  20 */   private static final float[] CCE_SCALE = new float[] { 1.0905077F, 1.1892071F, 1.4142135F, 2.0F };
/*     */   
/*     */   private final ICStream ics;
/*     */   
/*     */   private float[] iqData;
/*     */   
/*     */   private int couplingPoint;
/*     */   
/*     */   private int coupledCount;
/*     */   
/*     */   private final boolean[] channelPair;
/*     */   
/*     */   private final int[] idSelect;
/*     */   
/*     */   private final int[] chSelect;
/*     */   
/*     */   private final float[][] gain;
/*     */   
/*     */   CCE(int frameLength) {
/*  39 */     this.ics = new ICStream(frameLength);
/*  40 */     this.channelPair = new boolean[8];
/*  41 */     this.idSelect = new int[8];
/*  42 */     this.chSelect = new int[8];
/*  43 */     this.gain = new float[16][120];
/*     */   }
/*     */   
/*     */   int getCouplingPoint() {
/*  47 */     return this.couplingPoint;
/*     */   }
/*     */   
/*     */   int getCoupledCount() {
/*  51 */     return this.coupledCount;
/*     */   }
/*     */   
/*     */   boolean isChannelPair(int index) {
/*  55 */     return this.channelPair[index];
/*     */   }
/*     */   
/*     */   int getIDSelect(int index) {
/*  59 */     return this.idSelect[index];
/*     */   }
/*     */   
/*     */   int getCHSelect(int index) {
/*  63 */     return this.chSelect[index];
/*     */   }
/*     */   
/*     */   void decode(IBitStream _in, AACDecoderConfig conf) throws AACException {
/*  67 */     this.couplingPoint = 2 * _in.readBit();
/*  68 */     this.coupledCount = _in.readBits(3);
/*  69 */     int gainCount = 0;
/*     */     int i;
/*  71 */     for (i = 0; i <= this.coupledCount; i++) {
/*  72 */       gainCount++;
/*  73 */       this.channelPair[i] = _in.readBool();
/*  74 */       this.idSelect[i] = _in.readBits(4);
/*  75 */       if (this.channelPair[i]) {
/*  76 */         this.chSelect[i] = _in.readBits(2);
/*  77 */         if (this.chSelect[i] == 3) gainCount++; 
/*     */       } else {
/*  79 */         this.chSelect[i] = 2;
/*     */       } 
/*  81 */     }  this.couplingPoint += _in.readBit();
/*  82 */     this.couplingPoint |= this.couplingPoint >> 1;
/*     */     
/*  84 */     boolean sign = _in.readBool();
/*  85 */     double scale = CCE_SCALE[_in.readBits(2)];
/*     */     
/*  87 */     this.ics.decode(_in, false, conf);
/*  88 */     ICSInfo info = this.ics.getInfo();
/*  89 */     int windowGroupCount = info.getWindowGroupCount();
/*  90 */     int maxSFB = info.getMaxSFB();
/*     */     
/*  92 */     int[][] sfbCB = { {} };
/*     */     
/*  94 */     for (i = 0; i < gainCount; i++) {
/*  95 */       int idx = 0;
/*  96 */       int cge = 1;
/*  97 */       int xg = 0;
/*  98 */       float gainCache = 1.0F;
/*  99 */       if (i > 0) {
/* 100 */         cge = (this.couplingPoint == 2) ? 1 : _in.readBit();
/* 101 */         xg = (cge == 0) ? 0 : (Huffman.decodeScaleFactor(_in) - 60);
/* 102 */         gainCache = (float)Math.pow(scale, -xg);
/*     */       } 
/* 104 */       if (this.couplingPoint == 2) { this.gain[i][0] = gainCache; }
/*     */       else
/*     */       
/* 107 */       { for (int g = 0; g < windowGroupCount; g++) {
/* 108 */           for (int sfb = 0; sfb < maxSFB; sfb++, idx++) {
/* 109 */             if (sfbCB[g][sfb] != 0) {
/* 110 */               if (cge == 0) {
/* 111 */                 int t = Huffman.decodeScaleFactor(_in) - 60;
/* 112 */                 if (t != 0) {
/* 113 */                   int s = 1;
/* 114 */                   t = xg += t;
/* 115 */                   if (!sign) {
/* 116 */                     s -= 2 * (t & 0x1);
/* 117 */                     t >>= 1;
/*     */                   } 
/* 119 */                   gainCache = (float)(Math.pow(scale, -t) * s);
/*     */                 } 
/*     */               } 
/* 122 */               this.gain[i][idx] = gainCache;
/*     */             } 
/*     */           } 
/*     */         }  }
/*     */     
/*     */     } 
/*     */   }
/*     */   
/*     */   void process() throws AACException {
/* 131 */     this.iqData = this.ics.getInvQuantData();
/*     */   }
/*     */   
/*     */   void applyIndependentCoupling(int index, float[] data) {
/* 135 */     double g = this.gain[index][0];
/* 136 */     for (int i = 0; i < data.length; i++) {
/* 137 */       data[i] = (float)(data[i] + g * this.iqData[i]);
/*     */     }
/*     */   }
/*     */   
/*     */   void applyDependentCoupling(int index, float[] data) {
/* 142 */     ICSInfo info = this.ics.getInfo();
/* 143 */     int[] swbOffsets = info.getSWBOffsets();
/* 144 */     int windowGroupCount = info.getWindowGroupCount();
/* 145 */     int maxSFB = info.getMaxSFB();
/*     */     
/* 147 */     int[][] sfbCB = { {} };
/*     */     
/* 149 */     int srcOff = 0;
/* 150 */     int dstOff = 0;
/*     */     
/* 152 */     int idx = 0;
/*     */     
/* 154 */     for (int g = 0; g < windowGroupCount; g++) {
/* 155 */       int len = info.getWindowGroupLength(g);
/* 156 */       for (int sfb = 0; sfb < maxSFB; sfb++, idx++) {
/* 157 */         if (sfbCB[g][sfb] != 0) {
/* 158 */           float x = this.gain[index][idx];
/* 159 */           for (int group = 0; group < len; group++) {
/* 160 */             for (int k = swbOffsets[sfb]; k < swbOffsets[sfb + 1]; k++) {
/* 161 */               data[dstOff + group * 128 + k] = data[dstOff + group * 128 + k] + x * this.iqData[srcOff + group * 128 + k];
/*     */             }
/*     */           } 
/*     */         } 
/*     */       } 
/* 166 */       dstOff += len * 128;
/* 167 */       srcOff += len * 128;
/*     */     } 
/*     */   }
/*     */ }


/* Location:              C:\Users\rapha\Downloads\aurora.jar!\META-INF\jars\jcodec-0.2.5.jar!\net\sourceforge\jaad\aac\syntax\CCE.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */