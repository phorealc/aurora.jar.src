/*     */ package net.sourceforge.jaad.aac.syntax;
/*     */ 
/*     */ import net.sourceforge.jaad.aac.AACDecoderConfig;
/*     */ import net.sourceforge.jaad.aac.AACException;
/*     */ import net.sourceforge.jaad.aac.ChannelConfiguration;
/*     */ import net.sourceforge.jaad.aac.Profile;
/*     */ import net.sourceforge.jaad.aac.SampleBuffer;
/*     */ import net.sourceforge.jaad.aac.SampleFrequency;
/*     */ import net.sourceforge.jaad.aac.filterbank.FilterBank;
/*     */ import net.sourceforge.jaad.aac.sbr.SBR;
/*     */ import net.sourceforge.jaad.aac.tools.IS;
/*     */ import net.sourceforge.jaad.aac.tools.MS;
/*     */ import org.jcodec.common.logging.Logger;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class SyntacticElements
/*     */   implements SyntaxConstants
/*     */ {
/*     */   private AACDecoderConfig config;
/*     */   private boolean sbrPresent;
/*     */   private boolean psPresent;
/*     */   private int bitsRead;
/*     */   private PCE pce;
/*     */   private final Element[] elements;
/*     */   private final CCE[] cces;
/*     */   private final DSE[] dses;
/*     */   private final FIL[] fils;
/*     */   private int curElem;
/*     */   private int curCCE;
/*     */   private int curDSE;
/*     */   private int curFIL;
/*     */   private float[][] data;
/*     */   
/*     */   public SyntacticElements(AACDecoderConfig config) {
/*  47 */     this.config = config;
/*     */     
/*  49 */     this.pce = new PCE();
/*  50 */     this.elements = new Element[64];
/*  51 */     this.cces = new CCE[16];
/*  52 */     this.dses = new DSE[16];
/*  53 */     this.fils = new FIL[16];
/*     */     
/*  55 */     startNewFrame();
/*     */   }
/*     */   
/*     */   public final void startNewFrame() {
/*  59 */     this.curElem = 0;
/*  60 */     this.curCCE = 0;
/*  61 */     this.curDSE = 0;
/*  62 */     this.curFIL = 0;
/*  63 */     this.sbrPresent = false;
/*  64 */     this.psPresent = false;
/*  65 */     this.bitsRead = 0;
/*     */   }
/*     */   
/*     */   public void decode(IBitStream _in) throws AACException {
/*  69 */     int start = _in.getPosition();
/*     */ 
/*     */     
/*  72 */     Element prev = null;
/*  73 */     boolean content = true;
/*  74 */     if (!this.config.getProfile().isErrorResilientProfile()) {
/*  75 */       int type; while (content && (type = _in.readBits(3)) != 7) {
/*  76 */         switch (type) {
/*     */           case 0:
/*     */           case 3:
/*  79 */             Logger.debug("SCE");
/*  80 */             prev = decodeSCE_LFE(_in);
/*     */           
/*     */           case 1:
/*  83 */             Logger.debug("CPE");
/*  84 */             prev = decodeCPE(_in);
/*     */           
/*     */           case 2:
/*  87 */             Logger.debug("CCE");
/*  88 */             decodeCCE(_in);
/*  89 */             prev = null;
/*     */           
/*     */           case 4:
/*  92 */             Logger.debug("DSE");
/*  93 */             decodeDSE(_in);
/*  94 */             prev = null;
/*     */           
/*     */           case 5:
/*  97 */             Logger.debug("PCE");
/*  98 */             decodePCE(_in);
/*  99 */             prev = null;
/*     */           
/*     */           case 6:
/* 102 */             Logger.debug("FIL");
/* 103 */             decodeFIL(_in, prev);
/* 104 */             prev = null;
/*     */         } 
/*     */       
/*     */       } 
/* 108 */       Logger.debug("END");
/* 109 */       content = false;
/* 110 */       prev = null;
/*     */     }
/*     */     else {
/*     */       
/* 114 */       ChannelConfiguration cc = this.config.getChannelConfiguration();
/* 115 */       if (ChannelConfiguration.CHANNEL_CONFIG_MONO == cc) {
/* 116 */         decodeSCE_LFE(_in);
/* 117 */       } else if (ChannelConfiguration.CHANNEL_CONFIG_STEREO == cc) {
/* 118 */         decodeCPE(_in);
/* 119 */       } else if (ChannelConfiguration.CHANNEL_CONFIG_STEREO_PLUS_CENTER == cc) {
/* 120 */         decodeSCE_LFE(_in);
/* 121 */         decodeCPE(_in);
/* 122 */       } else if (ChannelConfiguration.CHANNEL_CONFIG_STEREO_PLUS_CENTER_PLUS_REAR_MONO == cc) {
/* 123 */         decodeSCE_LFE(_in);
/* 124 */         decodeCPE(_in);
/* 125 */         decodeSCE_LFE(_in);
/* 126 */       } else if (ChannelConfiguration.CHANNEL_CONFIG_FIVE == cc) {
/* 127 */         decodeSCE_LFE(_in);
/* 128 */         decodeCPE(_in);
/* 129 */         decodeCPE(_in);
/* 130 */       } else if (ChannelConfiguration.CHANNEL_CONFIG_FIVE_PLUS_ONE == cc) {
/* 131 */         decodeSCE_LFE(_in);
/* 132 */         decodeCPE(_in);
/* 133 */         decodeCPE(_in);
/* 134 */         decodeSCE_LFE(_in);
/* 135 */       } else if (ChannelConfiguration.CHANNEL_CONFIG_SEVEN_PLUS_ONE == cc) {
/* 136 */         decodeSCE_LFE(_in);
/* 137 */         decodeCPE(_in);
/* 138 */         decodeCPE(_in);
/* 139 */         decodeCPE(_in);
/* 140 */         decodeSCE_LFE(_in);
/*     */       } else {
/* 142 */         throw new AACException("unsupported channel configuration for error resilience: " + cc);
/*     */       } 
/*     */     } 
/* 145 */     _in.byteAlign();
/*     */     
/* 147 */     this.bitsRead = _in.getPosition() - start;
/*     */   }
/*     */   
/*     */   private Element decodeSCE_LFE(IBitStream _in) throws AACException {
/* 151 */     if (this.elements[this.curElem] == null) this.elements[this.curElem] = new SCE_LFE(this.config.getFrameLength()); 
/* 152 */     ((SCE_LFE)this.elements[this.curElem]).decode(_in, this.config);
/* 153 */     this.curElem++;
/* 154 */     return this.elements[this.curElem - 1];
/*     */   }
/*     */   
/*     */   private Element decodeCPE(IBitStream _in) throws AACException {
/* 158 */     if (this.elements[this.curElem] == null) this.elements[this.curElem] = new CPE(this.config.getFrameLength()); 
/* 159 */     ((CPE)this.elements[this.curElem]).decode(_in, this.config);
/* 160 */     this.curElem++;
/* 161 */     return this.elements[this.curElem - 1];
/*     */   }
/*     */   
/*     */   private void decodeCCE(IBitStream _in) throws AACException {
/* 165 */     if (this.curCCE == 16) throw new AACException("too much CCE elements"); 
/* 166 */     if (this.cces[this.curCCE] == null) this.cces[this.curCCE] = new CCE(this.config.getFrameLength()); 
/* 167 */     this.cces[this.curCCE].decode(_in, this.config);
/* 168 */     this.curCCE++;
/*     */   }
/*     */   
/*     */   private void decodeDSE(IBitStream _in) throws AACException {
/* 172 */     if (this.curDSE == 16) throw new AACException("too much CCE elements"); 
/* 173 */     if (this.dses[this.curDSE] == null) this.dses[this.curDSE] = new DSE(); 
/* 174 */     this.dses[this.curDSE].decode(_in);
/* 175 */     this.curDSE++;
/*     */   }
/*     */   
/*     */   private void decodePCE(IBitStream _in) throws AACException {
/* 179 */     this.pce.decode(_in);
/* 180 */     this.config.setProfile(this.pce.getProfile());
/* 181 */     this.config.setSampleFrequency(this.pce.getSampleFrequency());
/* 182 */     this.config.setChannelConfiguration(ChannelConfiguration.forInt(this.pce.getChannelCount()));
/*     */   }
/*     */   
/*     */   private void decodeFIL(IBitStream _in, Element prev) throws AACException {
/* 186 */     if (this.curFIL == 16) throw new AACException("too much FIL elements"); 
/* 187 */     if (this.fils[this.curFIL] == null) this.fils[this.curFIL] = new FIL(this.config.isSBRDownSampled()); 
/* 188 */     this.fils[this.curFIL].decode(_in, prev, this.config.getSampleFrequency(), this.config.isSBREnabled(), this.config.isSmallFrameUsed());
/* 189 */     this.curFIL++;
/*     */     
/* 191 */     if (prev != null && prev.isSBRPresent()) {
/* 192 */       this.sbrPresent = true;
/* 193 */       if (!this.psPresent && prev.getSBR().isPSUsed()) this.psPresent = true; 
/*     */     } 
/*     */   }
/*     */   
/*     */   public void process(FilterBank filterBank) throws AACException {
/* 198 */     Profile profile = this.config.getProfile();
/* 199 */     SampleFrequency sf = this.config.getSampleFrequency();
/*     */ 
/*     */     
/* 202 */     int chs = this.config.getChannelConfiguration().getChannelCount();
/* 203 */     if (chs == 1 && this.psPresent) chs++; 
/* 204 */     int mult = this.sbrPresent ? 2 : 1;
/*     */     
/* 206 */     if (this.data == null || chs != this.data.length || mult * this.config.getFrameLength() != (this.data[0]).length) this.data = new float[chs][mult * this.config.getFrameLength()];
/*     */     
/* 208 */     int channel = 0;
/*     */ 
/*     */ 
/*     */     
/* 212 */     for (int i = 0; i < this.elements.length && channel < chs; i++) {
/* 213 */       Element e = this.elements[i];
/* 214 */       if (e != null)
/* 215 */         if (e instanceof SCE_LFE) {
/* 216 */           SCE_LFE scelfe = (SCE_LFE)e;
/* 217 */           channel += processSingle(scelfe, filterBank, channel, profile, sf);
/*     */         }
/* 219 */         else if (e instanceof CPE) {
/* 220 */           CPE cpe = (CPE)e;
/* 221 */           processPair(cpe, filterBank, channel, profile, sf);
/* 222 */           channel += 2;
/*     */         }
/* 224 */         else if (e instanceof CCE) {
/*     */           
/* 226 */           ((CCE)e).process();
/* 227 */           channel++;
/*     */         }  
/*     */     } 
/*     */   }
/*     */   
/*     */   private int processSingle(SCE_LFE scelfe, FilterBank filterBank, int channel, Profile profile, SampleFrequency sf) throws AACException {
/* 233 */     ICStream ics = scelfe.getICStream();
/* 234 */     ICSInfo info = ics.getInfo();
/* 235 */     ICSInfo.LTPrediction ltp = info.getLTPrediction1();
/* 236 */     int elementID = scelfe.getElementInstanceTag();
/*     */ 
/*     */     
/* 239 */     float[] iqData = ics.getInvQuantData();
/*     */ 
/*     */     
/* 242 */     if (profile.equals(Profile.AAC_MAIN) && info.isICPredictionPresent()) info.getICPrediction().process(ics, iqData, sf); 
/* 243 */     if (ICSInfo.LTPrediction.isLTPProfile(profile) && info.isLTPrediction1Present()) ltp.process(ics, iqData, filterBank, sf);
/*     */ 
/*     */     
/* 246 */     processDependentCoupling(false, elementID, 0, iqData, null);
/*     */ 
/*     */     
/* 249 */     if (ics.isTNSDataPresent()) ics.getTNS().process(ics, iqData, sf, false);
/*     */ 
/*     */     
/* 252 */     processDependentCoupling(false, elementID, 1, iqData, null);
/*     */ 
/*     */     
/* 255 */     filterBank.process(info.getWindowSequence(), info.getWindowShape(1), info.getWindowShape(0), iqData, this.data[channel], channel);
/*     */     
/* 257 */     if (ICSInfo.LTPrediction.isLTPProfile(profile)) ltp.updateState(this.data[channel], filterBank.getOverlap(channel), profile);
/*     */ 
/*     */     
/* 260 */     processIndependentCoupling(false, elementID, this.data[channel], null);
/*     */ 
/*     */     
/* 263 */     if (ics.isGainControlPresent()) ics.getGainControl().process(iqData, info.getWindowShape(1), info.getWindowShape(0), info.getWindowSequence());
/*     */ 
/*     */     
/* 266 */     int chs = 1;
/* 267 */     if (this.sbrPresent && this.config.isSBREnabled()) {
/* 268 */       if ((this.data[channel]).length == this.config.getFrameLength())
/* 269 */         Logger.warn("SBR data present, but buffer has normal size!"); 
/* 270 */       SBR sbr = scelfe.getSBR();
/* 271 */       if (sbr.isPSUsed()) {
/* 272 */         chs = 2;
/* 273 */         scelfe.getSBR()._process(this.data[channel], this.data[channel + 1], false);
/*     */       } else {
/* 275 */         scelfe.getSBR().process(this.data[channel], false);
/*     */       } 
/* 277 */     }  return chs;
/*     */   }
/*     */   
/*     */   private void processPair(CPE cpe, FilterBank filterBank, int channel, Profile profile, SampleFrequency sf) throws AACException {
/* 281 */     ICStream ics1 = cpe.getLeftChannel();
/* 282 */     ICStream ics2 = cpe.getRightChannel();
/* 283 */     ICSInfo info1 = ics1.getInfo();
/* 284 */     ICSInfo info2 = ics2.getInfo();
/* 285 */     ICSInfo.LTPrediction ltp1 = info1.getLTPrediction1();
/* 286 */     ICSInfo.LTPrediction ltp2 = cpe.isCommonWindow() ? info1.getLTPrediction2() : info2.getLTPrediction1();
/* 287 */     int elementID = cpe.getElementInstanceTag();
/*     */ 
/*     */     
/* 290 */     float[] iqData1 = ics1.getInvQuantData();
/* 291 */     float[] iqData2 = ics2.getInvQuantData();
/*     */ 
/*     */     
/* 294 */     if (cpe.isCommonWindow() && cpe.isMSMaskPresent()) MS.process(cpe, iqData1, iqData2);
/*     */     
/* 296 */     if (profile.equals(Profile.AAC_MAIN)) {
/* 297 */       if (info1.isICPredictionPresent()) info1.getICPrediction().process(ics1, iqData1, sf); 
/* 298 */       if (info2.isICPredictionPresent()) info2.getICPrediction().process(ics2, iqData2, sf);
/*     */     
/*     */     } 
/* 301 */     IS.process(cpe, iqData1, iqData2);
/*     */ 
/*     */     
/* 304 */     if (ICSInfo.LTPrediction.isLTPProfile(profile)) {
/* 305 */       if (info1.isLTPrediction1Present()) ltp1.process(ics1, iqData1, filterBank, sf); 
/* 306 */       if (cpe.isCommonWindow() && info1.isLTPrediction2Present()) { ltp2.process(ics2, iqData2, filterBank, sf); }
/* 307 */       else if (info2.isLTPrediction1Present()) { ltp2.process(ics2, iqData2, filterBank, sf); }
/*     */     
/*     */     } 
/*     */     
/* 311 */     processDependentCoupling(true, elementID, 0, iqData1, iqData2);
/*     */ 
/*     */     
/* 314 */     if (ics1.isTNSDataPresent()) ics1.getTNS().process(ics1, iqData1, sf, false); 
/* 315 */     if (ics2.isTNSDataPresent()) ics2.getTNS().process(ics2, iqData2, sf, false);
/*     */ 
/*     */     
/* 318 */     processDependentCoupling(true, elementID, 1, iqData1, iqData2);
/*     */ 
/*     */     
/* 321 */     filterBank.process(info1.getWindowSequence(), info1.getWindowShape(1), info1.getWindowShape(0), iqData1, this.data[channel], channel);
/* 322 */     filterBank.process(info2.getWindowSequence(), info2.getWindowShape(1), info2.getWindowShape(0), iqData2, this.data[channel + 1], channel + 1);
/*     */     
/* 324 */     if (ICSInfo.LTPrediction.isLTPProfile(profile)) {
/* 325 */       ltp1.updateState(this.data[channel], filterBank.getOverlap(channel), profile);
/* 326 */       ltp2.updateState(this.data[channel + 1], filterBank.getOverlap(channel + 1), profile);
/*     */     } 
/*     */ 
/*     */     
/* 330 */     processIndependentCoupling(true, elementID, this.data[channel], this.data[channel + 1]);
/*     */ 
/*     */     
/* 333 */     if (ics1.isGainControlPresent()) ics1.getGainControl().process(iqData1, info1.getWindowShape(1), info1.getWindowShape(0), info1.getWindowSequence()); 
/* 334 */     if (ics2.isGainControlPresent()) ics2.getGainControl().process(iqData2, info2.getWindowShape(1), info2.getWindowShape(0), info2.getWindowSequence());
/*     */ 
/*     */     
/* 337 */     if (this.sbrPresent && this.config.isSBREnabled()) {
/* 338 */       if ((this.data[channel]).length == this.config.getFrameLength())
/* 339 */         Logger.warn("SBR data present, but buffer has normal size!"); 
/* 340 */       cpe.getSBR()._process(this.data[channel], this.data[channel + 1], false);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private void processIndependentCoupling(boolean channelPair, int elementID, float[] data1, float[] data2) {
/* 347 */     for (int i = 0; i < this.cces.length; i++) {
/* 348 */       CCE cce = this.cces[i];
/* 349 */       int index = 0;
/* 350 */       if (cce != null && cce.getCouplingPoint() == 2) {
/* 351 */         for (int c = 0; c <= cce.getCoupledCount(); c++) {
/* 352 */           int chSelect = cce.getCHSelect(c);
/* 353 */           if (cce.isChannelPair(c) == channelPair && cce.getIDSelect(c) == elementID) {
/* 354 */             if (chSelect != 1) {
/* 355 */               cce.applyIndependentCoupling(index, data1);
/* 356 */               if (chSelect != 0) index++; 
/*     */             } 
/* 358 */             if (chSelect != 2) {
/* 359 */               cce.applyIndependentCoupling(index, data2);
/* 360 */               index++;
/*     */             } 
/*     */           } else {
/* 363 */             index += 1 + ((chSelect == 3) ? 1 : 0);
/*     */           } 
/*     */         } 
/*     */       }
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   private void processDependentCoupling(boolean channelPair, int elementID, int couplingPoint, float[] data1, float[] data2) {
/* 372 */     for (int i = 0; i < this.cces.length; i++) {
/* 373 */       CCE cce = this.cces[i];
/* 374 */       int index = 0;
/* 375 */       if (cce != null && cce.getCouplingPoint() == couplingPoint)
/* 376 */         for (int c = 0; c <= cce.getCoupledCount(); c++) {
/* 377 */           int chSelect = cce.getCHSelect(c);
/* 378 */           if (cce.isChannelPair(c) == channelPair && cce.getIDSelect(c) == elementID) {
/* 379 */             if (chSelect != 1) {
/* 380 */               cce.applyDependentCoupling(index, data1);
/* 381 */               if (chSelect != 0) index++; 
/*     */             } 
/* 383 */             if (chSelect != 2) {
/* 384 */               cce.applyDependentCoupling(index, data2);
/* 385 */               index++;
/*     */             } 
/*     */           } else {
/* 388 */             index += 1 + ((chSelect == 3) ? 1 : 0);
/*     */           } 
/*     */         }  
/*     */     } 
/*     */   }
/*     */   
/*     */   public void sendToOutput(SampleBuffer buffer) {
/* 395 */     boolean be = buffer.isBigEndian();
/*     */     
/* 397 */     int chs = this.data.length;
/* 398 */     int mult = (this.sbrPresent && this.config.isSBREnabled()) ? 2 : 1;
/* 399 */     int length = mult * this.config.getFrameLength();
/* 400 */     int freq = mult * this.config.getSampleFrequency().getFrequency();
/*     */     
/* 402 */     byte[] b = buffer.getData();
/* 403 */     if (b.length != chs * length * 2) b = new byte[chs * length * 2];
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 408 */     for (int i = 0; i < chs; i++) {
/* 409 */       float[] cur = this.data[i];
/* 410 */       for (int j = 0; j < length; j++) {
/* 411 */         short s = (short)Math.max(Math.min(Math.round(cur[j]), 32767), -32768);
/* 412 */         int off = (j * chs + i) * 2;
/* 413 */         if (be) {
/* 414 */           b[off] = (byte)(s >> 8 & 0xFF);
/* 415 */           b[off + 1] = (byte)(s & 0xFF);
/*     */         } else {
/*     */           
/* 418 */           b[off + 1] = (byte)(s >> 8 & 0xFF);
/* 419 */           b[off] = (byte)(s & 0xFF);
/*     */         } 
/*     */       } 
/*     */     } 
/*     */     
/* 424 */     buffer.setData(b, freq, chs, 16, this.bitsRead);
/*     */   }
/*     */ }


/* Location:              C:\Users\rapha\Downloads\aurora.jar!\META-INF\jars\jcodec-0.2.5.jar!\net\sourceforge\jaad\aac\syntax\SyntacticElements.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */