/*     */ package net.sourceforge.jaad.aac.syntax;
/*     */ 
/*     */ import java.nio.ByteBuffer;
/*     */ import net.sourceforge.jaad.aac.AACException;
/*     */ import org.jcodec.common.io.BitReader;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class NIOBitStream
/*     */   implements IBitStream
/*     */ {
/*     */   private BitReader br;
/*     */   
/*     */   public NIOBitStream(BitReader br) {
/*  19 */     this.br = br;
/*     */   }
/*     */ 
/*     */   
/*     */   public void destroy() {
/*  24 */     reset();
/*  25 */     this.br = null;
/*     */   }
/*     */ 
/*     */   
/*     */   public void setData(byte[] data) {
/*  30 */     this.br = BitReader.createBitReader(ByteBuffer.wrap(data));
/*     */   }
/*     */ 
/*     */   
/*     */   public void byteAlign() throws AACException {
/*  35 */     this.br.align();
/*     */   }
/*     */ 
/*     */   
/*     */   public void reset() {
/*  40 */     throw new RuntimeException("todo");
/*     */   }
/*     */ 
/*     */   
/*     */   public int getPosition() {
/*  45 */     return this.br.position();
/*     */   }
/*     */ 
/*     */   
/*     */   public int getBitsLeft() {
/*  50 */     return this.br.remaining();
/*     */   }
/*     */ 
/*     */   
/*     */   public int readBits(int n) throws AACException {
/*  55 */     if (this.br.remaining() >= n) {
/*  56 */       return this.br.readNBit(n);
/*     */     }
/*  58 */     throw AACException.endOfStream();
/*     */   }
/*     */ 
/*     */   
/*     */   public int readBit() throws AACException {
/*  63 */     if (this.br.remaining() >= 1) {
/*  64 */       return this.br.read1Bit();
/*     */     }
/*  66 */     throw AACException.endOfStream();
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean readBool() throws AACException {
/*  71 */     int read1Bit = readBit();
/*  72 */     return (read1Bit != 0);
/*     */   }
/*     */ 
/*     */   
/*     */   public int peekBits(int n) throws AACException {
/*  77 */     int checkNBit = this.br.checkNBit(n);
/*  78 */     return checkNBit;
/*     */   }
/*     */ 
/*     */   
/*     */   public int peekBit() throws AACException {
/*  83 */     int curBit = this.br.curBit();
/*  84 */     return curBit;
/*     */   }
/*     */ 
/*     */   
/*     */   public void skipBits(int n) throws AACException {
/*  89 */     this.br.skip(n);
/*     */   }
/*     */ 
/*     */   
/*     */   public void skipBit() throws AACException {
/*  94 */     skipBits(1);
/*     */   }
/*     */ 
/*     */   
/*     */   public int maskBits(int n) {
/*     */     int i;
/* 100 */     if (n == 32) {
/* 101 */       i = -1;
/*     */     } else {
/* 103 */       i = (1 << n) - 1;
/* 104 */     }  return i;
/*     */   }
/*     */ }


/* Location:              C:\Users\rapha\Downloads\aurora.jar!\META-INF\jars\jcodec-0.2.5.jar!\net\sourceforge\jaad\aac\syntax\NIOBitStream.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */