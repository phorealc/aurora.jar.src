/*     */ package net.sourceforge.jaad.aac.syntax;
/*     */ 
/*     */ import net.sourceforge.jaad.aac.AACException;
/*     */ import net.sourceforge.jaad.aac.SampleFrequency;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ class FIL
/*     */   extends Element
/*     */   implements SyntaxConstants
/*     */ {
/*     */   private static final int TYPE_FILL = 0;
/*     */   private static final int TYPE_FILL_DATA = 1;
/*     */   private static final int TYPE_EXT_DATA_ELEMENT = 2;
/*     */   private static final int TYPE_DYNAMIC_RANGE = 11;
/*     */   private static final int TYPE_SBR_DATA = 13;
/*     */   private static final int TYPE_SBR_DATA_CRC = 14;
/*     */   private final boolean downSampledSBR;
/*     */   private DynamicRangeInfo dri;
/*     */   
/*     */   public static class DynamicRangeInfo
/*     */   {
/*     */     private static final int MAX_NBR_BANDS = 7;
/*  33 */     private final boolean[] excludeMask = new boolean[7];
/*  34 */     private final boolean[] additionalExcludedChannels = new boolean[7]; private boolean pceTagPresent; private int pceInstanceTag;
/*     */     private int tagReservedBits;
/*     */     private boolean excludedChannelsPresent;
/*     */     private boolean bandsPresent;
/*     */     private int bandsIncrement;
/*     */     private int interpolationScheme;
/*     */     private int[] bandTop;
/*     */     private boolean progRefLevelPresent;
/*     */     private int progRefLevel;
/*     */     private int progRefLevelReservedBits;
/*     */     private boolean[] dynRngSgn;
/*     */     private int[] dynRngCtl; }
/*     */   
/*     */   FIL(boolean downSampledSBR) {
/*  48 */     this.downSampledSBR = downSampledSBR;
/*     */   }
/*     */   
/*     */   void decode(IBitStream _in, Element prev, SampleFrequency sf, boolean sbrEnabled, boolean smallFrames) throws AACException {
/*  52 */     int count = _in.readBits(4);
/*  53 */     if (count == 15) count += _in.readBits(8) - 1; 
/*  54 */     count *= 8;
/*     */     
/*  56 */     int cpy = count;
/*  57 */     int pos = _in.getPosition();
/*     */     
/*  59 */     while (count > 0) {
/*  60 */       count = decodeExtensionPayload(_in, count, prev, sf, sbrEnabled, smallFrames);
/*     */     }
/*     */     
/*  63 */     int pos2 = _in.getPosition() - pos;
/*  64 */     int bitsLeft = cpy - pos2;
/*  65 */     if (bitsLeft > 0) { _in.skipBits(pos2); }
/*  66 */     else if (bitsLeft < 0) { throw new AACException("FIL element overread: " + bitsLeft); }
/*     */   
/*     */   }
/*     */   private int decodeExtensionPayload(IBitStream _in, int count, Element prev, SampleFrequency sf, boolean sbrEnabled, boolean smallFrames) throws AACException {
/*  70 */     int type = _in.readBits(4);
/*  71 */     int ret = count - 4;
/*  72 */     switch (type)
/*     */     { case 11:
/*  74 */         ret = decodeDynamicRangeInfo(_in, ret);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */         
/*  98 */         return ret;case 13: case 14: if (sbrEnabled) { if (prev instanceof SCE_LFE || prev instanceof CPE || prev instanceof CCE) { prev.decodeSBR(_in, sf, ret, prev instanceof CPE, (type == 14), this.downSampledSBR, smallFrames); ret = 0; } else { throw new AACException("SBR applied on unexpected element: " + prev); }  } else { _in.skipBits(ret); ret = 0; break; }  return ret; }  _in.skipBits(ret); ret = 0; return ret;
/*     */   }
/*     */   
/*     */   private int decodeDynamicRangeInfo(IBitStream _in, int count) throws AACException {
/* 102 */     if (this.dri == null) this.dri = new DynamicRangeInfo(); 
/* 103 */     int ret = count;
/*     */     
/* 105 */     int bandCount = 1;
/*     */ 
/*     */     
/* 108 */     if (this.dri.pceTagPresent = _in.readBool()) {
/* 109 */       this.dri.pceInstanceTag = _in.readBits(4);
/* 110 */       this.dri.tagReservedBits = _in.readBits(4);
/*     */     } 
/*     */ 
/*     */     
/* 114 */     if (this.dri.excludedChannelsPresent = _in.readBool()) {
/* 115 */       ret -= decodeExcludedChannels(_in);
/*     */     }
/*     */ 
/*     */     
/* 119 */     if (this.dri.bandsPresent = _in.readBool()) {
/* 120 */       this.dri.bandsIncrement = _in.readBits(4);
/* 121 */       this.dri.interpolationScheme = _in.readBits(4);
/* 122 */       ret -= 8;
/* 123 */       bandCount += this.dri.bandsIncrement;
/* 124 */       this.dri.bandTop = new int[bandCount];
/* 125 */       for (int j = 0; j < bandCount; j++) {
/* 126 */         this.dri.bandTop[j] = _in.readBits(8);
/* 127 */         ret -= 8;
/*     */       } 
/*     */     } 
/*     */ 
/*     */     
/* 132 */     if (this.dri.progRefLevelPresent = _in.readBool()) {
/* 133 */       this.dri.progRefLevel = _in.readBits(7);
/* 134 */       this.dri.progRefLevelReservedBits = _in.readBits(1);
/* 135 */       ret -= 8;
/*     */     } 
/*     */     
/* 138 */     this.dri.dynRngSgn = new boolean[bandCount];
/* 139 */     this.dri.dynRngCtl = new int[bandCount];
/* 140 */     for (int i = 0; i < bandCount; i++) {
/* 141 */       this.dri.dynRngSgn[i] = _in.readBool();
/* 142 */       this.dri.dynRngCtl[i] = _in.readBits(7);
/* 143 */       ret -= 8;
/*     */     } 
/* 145 */     return ret;
/*     */   }
/*     */ 
/*     */   
/*     */   private int decodeExcludedChannels(IBitStream _in) throws AACException {
/* 150 */     int exclChs = 0;
/*     */     
/*     */     do {
/* 153 */       for (int i = 0; i < 7; i++) {
/* 154 */         this.dri.excludeMask[exclChs] = _in.readBool();
/* 155 */         exclChs++;
/*     */       }
/*     */     
/* 158 */     } while (exclChs < 57 && _in.readBool());
/*     */     
/* 160 */     return exclChs / 7 * 8;
/*     */   }
/*     */ }


/* Location:              C:\Users\rapha\Downloads\aurora.jar!\META-INF\jars\jcodec-0.2.5.jar!\net\sourceforge\jaad\aac\syntax\FIL.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */