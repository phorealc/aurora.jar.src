/*     */ package net.sourceforge.jaad.aac.syntax;
/*     */ import net.sourceforge.jaad.aac.Profile;
/*     */ 
/*     */ public class ICSInfo implements SyntaxConstants, ScaleFactorBands {
/*     */   public static final int WINDOW_SHAPE_SINE = 0;
/*     */   public static final int WINDOW_SHAPE_KAISER = 1;
/*     */   public static final int PREVIOUS = 0;
/*     */   public static final int CURRENT = 1;
/*     */   private final int frameLength;
/*     */   private WindowSequence windowSequence;
/*     */   private int[] windowShape;
/*     */   private int maxSFB;
/*     */   private boolean predictionDataPresent;
/*     */   private ICPrediction icPredict;
/*     */   boolean ltpData1Present;
/*     */   boolean ltpData2Present;
/*     */   private LTPrediction ltPredict1;
/*     */   private LTPrediction ltPredict2;
/*     */   private int windowCount;
/*     */   private int windowGroupCount;
/*     */   private int[] windowGroupLength;
/*     */   private int swbCount;
/*     */   private int[] swbOffsets;
/*     */   
/*     */   public static class LTPrediction implements SyntaxConstants {
/*  26 */     private static final float[] CODEBOOK = new float[] { 0.570829F, 0.696616F, 0.813004F, 0.911304F, 0.9849F, 1.067894F, 1.194601F, 1.369533F };
/*     */     
/*     */     private final int frameLength;
/*     */     
/*     */     private final int[] states;
/*     */     
/*     */     private int coef;
/*     */     
/*     */     private int lag;
/*     */     
/*     */     private int lastBand;
/*     */     private boolean lagUpdate;
/*     */     private boolean[] shortUsed;
/*     */     private boolean[] shortLagPresent;
/*     */     private boolean[] longUsed;
/*     */     private int[] shortLag;
/*     */     
/*     */     public LTPrediction(int frameLength) {
/*  44 */       this.frameLength = frameLength;
/*  45 */       this.states = new int[4 * frameLength];
/*     */     }
/*     */     
/*     */     public void decode(IBitStream _in, ICSInfo info, Profile profile) throws AACException {
/*  49 */       this.lag = 0;
/*  50 */       if (profile.equals(Profile.AAC_LD)) {
/*  51 */         this.lagUpdate = _in.readBool();
/*  52 */         if (this.lagUpdate) this.lag = _in.readBits(10); 
/*     */       } else {
/*  54 */         this.lag = _in.readBits(11);
/*  55 */       }  if (this.lag > this.frameLength << 1) throw new AACException("LTP lag too large: " + this.lag); 
/*  56 */       this.coef = _in.readBits(3);
/*     */       
/*  58 */       int windowCount = info.getWindowCount();
/*     */       
/*  60 */       if (info.isEightShortFrame()) {
/*  61 */         this.shortUsed = new boolean[windowCount];
/*  62 */         this.shortLagPresent = new boolean[windowCount];
/*  63 */         this.shortLag = new int[windowCount];
/*  64 */         for (int w = 0; w < windowCount; w++) {
/*  65 */           this.shortUsed[w] = _in.readBool(); if (_in.readBool()) {
/*  66 */             this.shortLagPresent[w] = _in.readBool();
/*  67 */             if (this.shortLagPresent[w]) this.shortLag[w] = _in.readBits(4);
/*     */           
/*     */           } 
/*     */         } 
/*     */       } else {
/*  72 */         this.lastBand = Math.min(info.getMaxSFB(), 40);
/*  73 */         this.longUsed = new boolean[this.lastBand];
/*  74 */         for (int i = 0; i < this.lastBand; i++) {
/*  75 */           this.longUsed[i] = _in.readBool();
/*     */         }
/*     */       } 
/*     */     }
/*     */     
/*     */     public void setPredictionUnused(int sfb) {
/*  81 */       if (this.longUsed != null) this.longUsed[sfb] = false; 
/*     */     }
/*     */     
/*     */     public void process(ICStream ics, float[] data, FilterBank filterBank, SampleFrequency sf) {
/*  85 */       ICSInfo info = ics.getInfo();
/*     */       
/*  87 */       if (!info.isEightShortFrame()) {
/*  88 */         int samples = this.frameLength << 1;
/*  89 */         float[] _in = new float[2048];
/*  90 */         float[] out = new float[2048];
/*     */         
/*  92 */         for (int i = 0; i < samples; i++) {
/*  93 */           _in[i] = this.states[samples + i - this.lag] * CODEBOOK[this.coef];
/*     */         }
/*     */         
/*  96 */         filterBank.processLTP(info.getWindowSequence(), info.getWindowShape(1), info
/*  97 */             .getWindowShape(0), _in, out);
/*     */         
/*  99 */         if (ics.isTNSDataPresent()) ics.getTNS().process(ics, out, sf, true);
/*     */         
/* 101 */         int[] swbOffsets = info.getSWBOffsets();
/* 102 */         int swbOffsetMax = info.getSWBOffsetMax();
/*     */         
/* 104 */         for (int sfb = 0; sfb < this.lastBand; sfb++) {
/* 105 */           if (this.longUsed[sfb]) {
/* 106 */             int low = swbOffsets[sfb];
/* 107 */             int high = Math.min(swbOffsets[sfb + 1], swbOffsetMax);
/*     */             
/* 109 */             for (int bin = low; bin < high; bin++) {
/* 110 */               data[bin] = data[bin] + out[bin];
/*     */             }
/*     */           } 
/*     */         } 
/*     */       } 
/*     */     }
/*     */ 
/*     */     
/*     */     public void updateState(float[] time, float[] overlap, Profile profile) {
/* 119 */       if (profile.equals(Profile.AAC_LD)) {
/* 120 */         for (int i = 0; i < this.frameLength; i++) {
/* 121 */           this.states[i] = this.states[i + this.frameLength];
/* 122 */           this.states[this.frameLength + i] = this.states[i + this.frameLength * 2];
/* 123 */           this.states[this.frameLength * 2 + i] = Math.round(time[i]);
/* 124 */           this.states[this.frameLength * 3 + i] = Math.round(overlap[i]);
/*     */         } 
/*     */       } else {
/*     */         
/* 128 */         for (int i = 0; i < this.frameLength; i++) {
/* 129 */           this.states[i] = this.states[i + this.frameLength];
/* 130 */           this.states[this.frameLength + i] = Math.round(time[i]);
/* 131 */           this.states[this.frameLength * 2 + i] = Math.round(overlap[i]);
/*     */         } 
/*     */       } 
/*     */     }
/*     */     
/*     */     public static boolean isLTPProfile(Profile profile) {
/* 137 */       return (profile.equals(Profile.AAC_LTP) || profile.equals(Profile.ER_AAC_LTP) || profile.equals(Profile.AAC_LD));
/*     */     }
/*     */     
/*     */     public void copy(LTPrediction ltp) {
/* 141 */       System.arraycopy(ltp.states, 0, this.states, 0, this.states.length);
/* 142 */       this.coef = ltp.coef;
/* 143 */       this.lag = ltp.lag;
/* 144 */       this.lastBand = ltp.lastBand;
/* 145 */       this.lagUpdate = ltp.lagUpdate;
/* 146 */       this.shortUsed = Platform.copyOfBool(ltp.shortUsed, ltp.shortUsed.length);
/* 147 */       this.shortLagPresent = Platform.copyOfBool(ltp.shortLagPresent, ltp.shortLagPresent.length);
/* 148 */       this.shortLag = Platform.copyOfInt(ltp.shortLag, ltp.shortLag.length);
/* 149 */       this.longUsed = Platform.copyOfBool(ltp.longUsed, ltp.longUsed.length);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public enum WindowSequence
/*     */   {
/* 159 */     ONLY_LONG_SEQUENCE,
/* 160 */     LONG_START_SEQUENCE,
/* 161 */     EIGHT_SHORT_SEQUENCE,
/* 162 */     LONG_STOP_SEQUENCE;
/*     */   }
/*     */   
/*     */   public static WindowSequence windowSequenceFromInt(int i) throws AACException {
/* 166 */     WindowSequence[] values = WindowSequence.values();
/* 167 */     if (i >= values.length) {
/* 168 */       throw new AACException("unknown window sequence type");
/*     */     }
/* 170 */     return values[i];
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ICSInfo(int frameLength) {
/* 190 */     this.frameLength = frameLength;
/* 191 */     this.windowShape = new int[2];
/* 192 */     this.windowSequence = WindowSequence.ONLY_LONG_SEQUENCE;
/* 193 */     this.windowGroupLength = new int[8];
/* 194 */     this.ltpData1Present = false;
/* 195 */     this.ltpData2Present = false;
/*     */   }
/*     */ 
/*     */   
/*     */   public void decode(IBitStream _in, AACDecoderConfig conf, boolean commonWindow) throws AACException {
/* 200 */     SampleFrequency sf = conf.getSampleFrequency();
/* 201 */     if (sf.equals(SampleFrequency.SAMPLE_FREQUENCY_NONE)) throw new AACException("invalid sample frequency");
/*     */     
/* 203 */     _in.skipBit();
/* 204 */     this.windowSequence = windowSequenceFromInt(_in.readBits(2));
/* 205 */     this.windowShape[0] = this.windowShape[1];
/* 206 */     this.windowShape[1] = _in.readBit();
/*     */     
/* 208 */     this.windowGroupCount = 1;
/* 209 */     this.windowGroupLength[0] = 1;
/* 210 */     if (this.windowSequence.equals(WindowSequence.EIGHT_SHORT_SEQUENCE)) {
/* 211 */       this.maxSFB = _in.readBits(4);
/*     */       
/* 213 */       for (int i = 0; i < 7; i++) {
/* 214 */         if (_in.readBool()) { this.windowGroupLength[this.windowGroupCount - 1] = this.windowGroupLength[this.windowGroupCount - 1] + 1; }
/*     */         else
/* 216 */         { this.windowGroupCount++;
/* 217 */           this.windowGroupLength[this.windowGroupCount - 1] = 1; }
/*     */       
/*     */       } 
/* 220 */       this.windowCount = 8;
/* 221 */       this.swbOffsets = SWB_OFFSET_SHORT_WINDOW[sf.getIndex()];
/* 222 */       this.swbCount = SWB_SHORT_WINDOW_COUNT[sf.getIndex()];
/* 223 */       this.predictionDataPresent = false;
/*     */     } else {
/*     */       
/* 226 */       this.maxSFB = _in.readBits(6);
/* 227 */       this.windowCount = 1;
/* 228 */       this.swbOffsets = SWB_OFFSET_LONG_WINDOW[sf.getIndex()];
/* 229 */       this.swbCount = SWB_LONG_WINDOW_COUNT[sf.getIndex()];
/* 230 */       this.predictionDataPresent = _in.readBool();
/* 231 */       if (this.predictionDataPresent) readPredictionData(_in, conf.getProfile(), sf, commonWindow); 
/*     */     } 
/*     */   }
/*     */   
/*     */   private void readPredictionData(IBitStream _in, Profile profile, SampleFrequency sf, boolean commonWindow) throws AACException {
/* 236 */     if (Profile.AAC_MAIN == profile) {
/* 237 */       if (this.icPredict == null) this.icPredict = new ICPrediction(); 
/* 238 */       this.icPredict.decode(_in, this.maxSFB, sf);
/* 239 */     } else if (Profile.AAC_LTP == profile) {
/* 240 */       if (this.ltpData1Present = _in.readBool()) {
/* 241 */         if (this.ltPredict1 == null) this.ltPredict1 = new LTPrediction(this.frameLength); 
/* 242 */         this.ltPredict1.decode(_in, this, profile);
/*     */       } 
/* 244 */       if (commonWindow && (
/* 245 */         this.ltpData2Present = _in.readBool())) {
/* 246 */         if (this.ltPredict2 == null) this.ltPredict2 = new LTPrediction(this.frameLength); 
/* 247 */         this.ltPredict2.decode(_in, this, profile);
/*     */       }
/*     */     
/* 250 */     } else if (Profile.ER_AAC_LTP == profile) {
/* 251 */       if (!commonWindow && (
/* 252 */         this.ltpData1Present = _in.readBool())) {
/* 253 */         if (this.ltPredict1 == null) this.ltPredict1 = new LTPrediction(this.frameLength); 
/* 254 */         this.ltPredict1.decode(_in, this, profile);
/*     */       } 
/*     */     } else {
/*     */       
/* 258 */       throw new AACException("unexpected profile for LTP: " + profile);
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public int getMaxSFB() {
/* 264 */     return this.maxSFB;
/*     */   }
/*     */   
/*     */   public int getSWBCount() {
/* 268 */     return this.swbCount;
/*     */   }
/*     */   
/*     */   public int[] getSWBOffsets() {
/* 272 */     return this.swbOffsets;
/*     */   }
/*     */   
/*     */   public int getSWBOffsetMax() {
/* 276 */     return this.swbOffsets[this.swbCount];
/*     */   }
/*     */   
/*     */   public int getWindowCount() {
/* 280 */     return this.windowCount;
/*     */   }
/*     */   
/*     */   public int getWindowGroupCount() {
/* 284 */     return this.windowGroupCount;
/*     */   }
/*     */   
/*     */   public int getWindowGroupLength(int g) {
/* 288 */     return this.windowGroupLength[g];
/*     */   }
/*     */   
/*     */   public WindowSequence getWindowSequence() {
/* 292 */     return this.windowSequence;
/*     */   }
/*     */   
/*     */   public boolean isEightShortFrame() {
/* 296 */     return this.windowSequence.equals(WindowSequence.EIGHT_SHORT_SEQUENCE);
/*     */   }
/*     */   
/*     */   public int getWindowShape(int index) {
/* 300 */     return this.windowShape[index];
/*     */   }
/*     */   
/*     */   public boolean isICPredictionPresent() {
/* 304 */     return this.predictionDataPresent;
/*     */   }
/*     */   
/*     */   public ICPrediction getICPrediction() {
/* 308 */     return this.icPredict;
/*     */   }
/*     */   
/*     */   public boolean isLTPrediction1Present() {
/* 312 */     return this.ltpData1Present;
/*     */   }
/*     */   
/*     */   public LTPrediction getLTPrediction1() {
/* 316 */     return this.ltPredict1;
/*     */   }
/*     */   
/*     */   public boolean isLTPrediction2Present() {
/* 320 */     return this.ltpData2Present;
/*     */   }
/*     */   
/*     */   public LTPrediction getLTPrediction2() {
/* 324 */     return this.ltPredict2;
/*     */   }
/*     */   
/*     */   public void unsetPredictionSFB(int sfb) {
/* 328 */     if (this.predictionDataPresent) this.icPredict.setPredictionUnused(sfb); 
/* 329 */     if (this.ltpData1Present) this.ltPredict1.setPredictionUnused(sfb); 
/* 330 */     if (this.ltpData2Present) this.ltPredict2.setPredictionUnused(sfb); 
/*     */   }
/*     */   
/*     */   public void setData(ICSInfo info) {
/* 334 */     this.windowSequence = WindowSequence.valueOf(info.windowSequence.name());
/* 335 */     this.windowShape[0] = this.windowShape[1];
/* 336 */     this.windowShape[1] = info.windowShape[1];
/* 337 */     this.maxSFB = info.maxSFB;
/* 338 */     this.predictionDataPresent = info.predictionDataPresent;
/* 339 */     if (this.predictionDataPresent) this.icPredict = info.icPredict; 
/* 340 */     this.ltpData1Present = info.ltpData1Present;
/* 341 */     if (this.ltpData1Present) {
/* 342 */       this.ltPredict1.copy(info.ltPredict1);
/* 343 */       this.ltPredict2.copy(info.ltPredict2);
/*     */     } 
/* 345 */     this.windowCount = info.windowCount;
/* 346 */     this.windowGroupCount = info.windowGroupCount;
/* 347 */     this.windowGroupLength = Platform.copyOfInt(info.windowGroupLength, info.windowGroupLength.length);
/* 348 */     this.swbCount = info.swbCount;
/* 349 */     this.swbOffsets = Platform.copyOfInt(info.swbOffsets, info.swbOffsets.length);
/*     */   }
/*     */ }


/* Location:              C:\Users\rapha\Downloads\aurora.jar!\META-INF\jars\jcodec-0.2.5.jar!\net\sourceforge\jaad\aac\syntax\ICSInfo.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */