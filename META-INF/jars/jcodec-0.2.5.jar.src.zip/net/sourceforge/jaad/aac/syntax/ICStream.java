/*     */ package net.sourceforge.jaad.aac.syntax;
/*     */ 
/*     */ import java.util.Arrays;
/*     */ import net.sourceforge.jaad.aac.AACDecoderConfig;
/*     */ import net.sourceforge.jaad.aac.AACException;
/*     */ import net.sourceforge.jaad.aac.ChannelConfiguration;
/*     */ import net.sourceforge.jaad.aac.error.RVLC;
/*     */ import net.sourceforge.jaad.aac.gain.GainControl;
/*     */ import net.sourceforge.jaad.aac.huffman.HCB;
/*     */ import net.sourceforge.jaad.aac.huffman.Huffman;
/*     */ import net.sourceforge.jaad.aac.tools.TNS;
/*     */ import org.jcodec.common.logging.Logger;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ICStream
/*     */   implements SyntaxConstants, HCB, ScaleFactorTable, IQTable
/*     */ {
/*     */   private static final int SF_DELTA = 60;
/*     */   private static final int SF_OFFSET = 200;
/*  27 */   private static int randomState = 523124044;
/*     */   
/*     */   private final int frameLength;
/*     */   
/*     */   private final ICSInfo info;
/*     */   
/*     */   private final int[] sfbCB;
/*     */   
/*     */   private final int[] sectEnd;
/*     */   
/*     */   private final float[] data;
/*     */   
/*     */   private final float[] scaleFactors;
/*     */   
/*     */   private int globalGain;
/*     */   
/*     */   private boolean pulseDataPresent;
/*     */   
/*     */   private boolean tnsDataPresent;
/*     */   private boolean gainControlPresent;
/*     */   
/*     */   public ICStream(int frameLength) {
/*  49 */     this.frameLength = frameLength;
/*  50 */     this.info = new ICSInfo(frameLength);
/*  51 */     this.sfbCB = new int[120];
/*  52 */     this.sectEnd = new int[120];
/*  53 */     this.data = new float[frameLength];
/*  54 */     this.scaleFactors = new float[120];
/*     */   }
/*     */   private TNS tns; private GainControl gainControl; private int[] pulseOffset; private int[] pulseAmp; private int pulseCount; private int pulseStartSWB; private boolean noiseUsed; private int reorderedSpectralDataLen; private int longestCodewordLen; private RVLC rvlc;
/*     */   
/*     */   public void decode(IBitStream _in, boolean commonWindow, AACDecoderConfig conf) throws AACException {
/*  59 */     if (conf.isScalefactorResilienceUsed() && this.rvlc == null) this.rvlc = new RVLC(); 
/*  60 */     boolean er = conf.getProfile().isErrorResilientProfile();
/*     */     
/*  62 */     this.globalGain = _in.readBits(8);
/*     */     
/*  64 */     if (!commonWindow) this.info.decode(_in, conf, commonWindow);
/*     */     
/*  66 */     decodeSectionData(_in, conf.isSectionDataResilienceUsed());
/*     */ 
/*     */     
/*  69 */     decodeScaleFactors(_in);
/*     */     
/*  71 */     this.pulseDataPresent = _in.readBool();
/*  72 */     if (this.pulseDataPresent) {
/*  73 */       if (this.info.isEightShortFrame()) throw new AACException("pulse data not allowed for short frames"); 
/*  74 */       Logger.debug("PULSE");
/*  75 */       decodePulseData(_in);
/*     */     } 
/*     */     
/*  78 */     this.tnsDataPresent = _in.readBool();
/*  79 */     if (this.tnsDataPresent && !er) {
/*  80 */       if (this.tns == null) this.tns = new TNS(); 
/*  81 */       this.tns.decode(_in, this.info);
/*     */     } 
/*     */     
/*  84 */     this.gainControlPresent = _in.readBool();
/*  85 */     if (this.gainControlPresent) {
/*  86 */       if (this.gainControl == null) this.gainControl = new GainControl(this.frameLength); 
/*  87 */       Logger.debug("GAIN");
/*  88 */       this.gainControl.decode(_in, this.info.getWindowSequence());
/*     */     } 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*  94 */     if (conf.isSpectralDataResilienceUsed()) {
/*  95 */       int max = (conf.getChannelConfiguration() == ChannelConfiguration.CHANNEL_CONFIG_STEREO) ? 6144 : 12288;
/*  96 */       this.reorderedSpectralDataLen = Math.max(_in.readBits(14), max);
/*  97 */       this.longestCodewordLen = Math.max(_in.readBits(6), 49);
/*     */     } else {
/*     */       
/* 100 */       decodeSpectralData(_in);
/*     */     } 
/*     */   }
/*     */   public void decodeSectionData(IBitStream _in, boolean sectionDataResilienceUsed) throws AACException {
/* 104 */     Arrays.fill(this.sfbCB, 0);
/* 105 */     Arrays.fill(this.sectEnd, 0);
/* 106 */     int bits = this.info.isEightShortFrame() ? 3 : 5;
/* 107 */     int escVal = (1 << bits) - 1;
/*     */     
/* 109 */     int windowGroupCount = this.info.getWindowGroupCount();
/* 110 */     int maxSFB = this.info.getMaxSFB();
/*     */ 
/*     */     
/* 113 */     int idx = 0;
/*     */     
/* 115 */     for (int g = 0; g < windowGroupCount; g++) {
/* 116 */       int k = 0;
/* 117 */       while (k < maxSFB) {
/* 118 */         int end = k;
/* 119 */         int cb = _in.readBits(4);
/* 120 */         if (cb == 12) throw new AACException("invalid huffman codebook: 12");  int incr;
/* 121 */         while ((incr = _in.readBits(bits)) == escVal) {
/* 122 */           end += incr;
/*     */         }
/* 124 */         end += incr;
/* 125 */         if (end > maxSFB) throw new AACException("too many bands: " + end + ", allowed: " + maxSFB); 
/* 126 */         for (; k < end; k++) {
/* 127 */           this.sfbCB[idx] = cb;
/* 128 */           this.sectEnd[idx++] = end;
/*     */         } 
/*     */       } 
/*     */     } 
/*     */   }
/*     */   
/*     */   private void decodePulseData(IBitStream _in) throws AACException {
/* 135 */     this.pulseCount = _in.readBits(2) + 1;
/* 136 */     this.pulseStartSWB = _in.readBits(6);
/* 137 */     if (this.pulseStartSWB >= this.info.getSWBCount()) throw new AACException("pulse SWB out of range: " + this.pulseStartSWB + " > " + this.info.getSWBCount());
/*     */     
/* 139 */     if (this.pulseOffset == null || this.pulseCount != this.pulseOffset.length) {
/*     */       
/* 141 */       this.pulseOffset = new int[this.pulseCount];
/* 142 */       this.pulseAmp = new int[this.pulseCount];
/*     */     } 
/*     */     
/* 145 */     this.pulseOffset[0] = this.info.getSWBOffsets()[this.pulseStartSWB];
/* 146 */     this.pulseOffset[0] = this.pulseOffset[0] + _in.readBits(5);
/* 147 */     this.pulseAmp[0] = _in.readBits(4);
/* 148 */     for (int i = 1; i < this.pulseCount; i++) {
/* 149 */       this.pulseOffset[i] = _in.readBits(5) + this.pulseOffset[i - 1];
/* 150 */       if (this.pulseOffset[i] > 1023) throw new AACException("pulse offset out of range: " + this.pulseOffset[0]); 
/* 151 */       this.pulseAmp[i] = _in.readBits(4);
/*     */     } 
/*     */   }
/*     */   
/*     */   public void decodeScaleFactors(IBitStream _in) throws AACException {
/* 156 */     int windowGroups = this.info.getWindowGroupCount();
/* 157 */     int maxSFB = this.info.getMaxSFB();
/*     */     
/* 159 */     int[] offset = { this.globalGain, this.globalGain - 90, 0 };
/*     */ 
/*     */     
/* 162 */     boolean noiseFlag = true;
/*     */     
/* 164 */     int idx = 0;
/* 165 */     for (int g = 0; g < windowGroups; g++) {
/* 166 */       for (int sfb = 0; sfb < maxSFB; ) {
/* 167 */         int end = this.sectEnd[idx];
/* 168 */         switch (this.sfbCB[idx]) {
/*     */           case 0:
/* 170 */             for (; sfb < end; sfb++, idx++) {
/* 171 */               this.scaleFactors[idx] = 0.0F;
/*     */             }
/*     */             continue;
/*     */           case 14:
/*     */           case 15:
/* 176 */             for (; sfb < end; sfb++, idx++) {
/* 177 */               offset[2] = offset[2] + Huffman.decodeScaleFactor(_in) - 60;
/* 178 */               int tmp = Math.min(Math.max(offset[2], -155), 100);
/* 179 */               this.scaleFactors[idx] = SCALEFACTOR_TABLE[-tmp + 200];
/*     */             } 
/*     */             continue;
/*     */           case 13:
/* 183 */             for (; sfb < end; sfb++, idx++) {
/* 184 */               if (noiseFlag) {
/* 185 */                 offset[1] = offset[1] + _in.readBits(9) - 256;
/* 186 */                 noiseFlag = false;
/*     */               } else {
/* 188 */                 offset[1] = offset[1] + Huffman.decodeScaleFactor(_in) - 60;
/* 189 */               }  int tmp = Math.min(Math.max(offset[1], -100), 155);
/* 190 */               this.scaleFactors[idx] = -SCALEFACTOR_TABLE[tmp + 200];
/*     */             } 
/*     */             continue;
/*     */         } 
/* 194 */         for (; sfb < end; sfb++, idx++) {
/* 195 */           offset[0] = offset[0] + Huffman.decodeScaleFactor(_in) - 60;
/* 196 */           if (offset[0] > 255) throw new AACException("scalefactor out of range: " + offset[0]); 
/* 197 */           this.scaleFactors[idx] = SCALEFACTOR_TABLE[offset[0] - 100 + 200];
/*     */         } 
/*     */       } 
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private void decodeSpectralData(IBitStream _in) throws AACException {
/* 206 */     Arrays.fill(this.data, 0.0F);
/* 207 */     int maxSFB = this.info.getMaxSFB();
/* 208 */     int windowGroups = this.info.getWindowGroupCount();
/* 209 */     int[] offsets = this.info.getSWBOffsets();
/* 210 */     int[] buf = new int[4];
/*     */ 
/*     */     
/* 213 */     int groupOff = 0, idx = 0;
/* 214 */     for (int g = 0; g < windowGroups; g++) {
/* 215 */       int groupLen = this.info.getWindowGroupLength(g);
/*     */       
/* 217 */       for (int sfb = 0; sfb < maxSFB; sfb++, idx++) {
/* 218 */         int hcb = this.sfbCB[idx];
/* 219 */         int off = groupOff + offsets[sfb];
/* 220 */         int width = offsets[sfb + 1] - offsets[sfb];
/* 221 */         if (hcb == 0 || hcb == 15 || hcb == 14) {
/* 222 */           for (int w = 0; w < groupLen; w++, off += 128) {
/* 223 */             Arrays.fill(this.data, off, off + width, 0.0F);
/*     */           }
/*     */         }
/* 226 */         else if (hcb == 13) {
/*     */           
/* 228 */           for (int w = 0; w < groupLen; w++, off += 128) {
/* 229 */             float energy = 0.0F;
/*     */             int k;
/* 231 */             for (k = 0; k < width; k++) {
/* 232 */               randomState *= 1015568748;
/* 233 */               this.data[off + k] = randomState;
/* 234 */               energy += this.data[off + k] * this.data[off + k];
/*     */             } 
/*     */             
/* 237 */             float scale = (float)(this.scaleFactors[idx] / Math.sqrt(energy));
/* 238 */             for (k = 0; k < width; k++) {
/* 239 */               this.data[off + k] = this.data[off + k] * scale;
/*     */             }
/*     */           } 
/*     */         } else {
/*     */           
/* 244 */           for (int w = 0; w < groupLen; w++, off += 128) {
/* 245 */             int num = (hcb >= 5) ? 2 : 4; int k;
/* 246 */             for (k = 0; k < width; k += num) {
/* 247 */               Huffman.decodeSpectralData(_in, hcb, buf, 0);
/*     */ 
/*     */               
/* 250 */               for (int j = 0; j < num; j++) {
/* 251 */                 this.data[off + k + j] = (buf[j] > 0) ? IQ_TABLE[buf[j]] : -IQ_TABLE[-buf[j]];
/* 252 */                 this.data[off + k + j] = this.data[off + k + j] * this.scaleFactors[idx];
/*     */               } 
/*     */             } 
/*     */           } 
/*     */         } 
/*     */       } 
/* 258 */       groupOff += groupLen << 7;
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public float[] getInvQuantData() throws AACException {
/* 270 */     return this.data;
/*     */   }
/*     */   
/*     */   public ICSInfo getInfo() {
/* 274 */     return this.info;
/*     */   }
/*     */   
/*     */   public int[] getSectEnd() {
/* 278 */     return this.sectEnd;
/*     */   }
/*     */   
/*     */   public int[] getSfbCB() {
/* 282 */     return this.sfbCB;
/*     */   }
/*     */   
/*     */   public float[] getScaleFactors() {
/* 286 */     return this.scaleFactors;
/*     */   }
/*     */   
/*     */   public boolean isTNSDataPresent() {
/* 290 */     return this.tnsDataPresent;
/*     */   }
/*     */   
/*     */   public TNS getTNS() {
/* 294 */     return this.tns;
/*     */   }
/*     */   
/*     */   public int getGlobalGain() {
/* 298 */     return this.globalGain;
/*     */   }
/*     */   
/*     */   public boolean isNoiseUsed() {
/* 302 */     return this.noiseUsed;
/*     */   }
/*     */   
/*     */   public int getLongestCodewordLength() {
/* 306 */     return this.longestCodewordLen;
/*     */   }
/*     */   
/*     */   public int getReorderedSpectralDataLength() {
/* 310 */     return this.reorderedSpectralDataLen;
/*     */   }
/*     */   
/*     */   public boolean isGainControlPresent() {
/* 314 */     return this.gainControlPresent;
/*     */   }
/*     */   
/*     */   public GainControl getGainControl() {
/* 318 */     return this.gainControl;
/*     */   }
/*     */ }


/* Location:              C:\Users\rapha\Downloads\aurora.jar!\META-INF\jars\jcodec-0.2.5.jar!\net\sourceforge\jaad\aac\syntax\ICStream.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */