/*    */ package net.sourceforge.jaad.aac.syntax;
/*    */ 
/*    */ import java.util.Arrays;
/*    */ import net.sourceforge.jaad.aac.AACDecoderConfig;
/*    */ import net.sourceforge.jaad.aac.AACException;
/*    */ import net.sourceforge.jaad.aac.Profile;
/*    */ import net.sourceforge.jaad.aac.SampleFrequency;
/*    */ import net.sourceforge.jaad.aac.tools.MSMask;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class CPE
/*    */   extends Element
/*    */   implements SyntaxConstants
/*    */ {
/*    */   private MSMask msMask;
/*    */   private boolean[] msUsed;
/*    */   private boolean commonWindow;
/*    */   ICStream icsL;
/*    */   ICStream icsR;
/*    */   
/*    */   CPE(int frameLength) {
/* 26 */     this.msUsed = new boolean[128];
/* 27 */     this.icsL = new ICStream(frameLength);
/* 28 */     this.icsR = new ICStream(frameLength);
/*    */   }
/*    */   
/*    */   void decode(IBitStream _in, AACDecoderConfig conf) throws AACException {
/* 32 */     Profile profile = conf.getProfile();
/* 33 */     SampleFrequency sf = conf.getSampleFrequency();
/* 34 */     if (sf.equals(SampleFrequency.SAMPLE_FREQUENCY_NONE)) throw new AACException("invalid sample frequency");
/*    */     
/* 36 */     readElementInstanceTag(_in);
/*    */     
/* 38 */     this.commonWindow = _in.readBool();
/* 39 */     ICSInfo info = this.icsL.getInfo();
/* 40 */     if (this.commonWindow) {
/* 41 */       info.decode(_in, conf, this.commonWindow);
/* 42 */       this.icsR.getInfo().setData(info);
/*    */       
/* 44 */       this.msMask = msMaskFromInt(_in.readBits(2));
/* 45 */       if (this.msMask.equals(MSMask.TYPE_USED))
/* 46 */       { int maxSFB = info.getMaxSFB();
/* 47 */         int windowGroupCount = info.getWindowGroupCount();
/*    */         
/* 49 */         for (int idx = 0; idx < windowGroupCount * maxSFB; idx++) {
/* 50 */           this.msUsed[idx] = _in.readBool();
/*    */         } }
/*    */       
/* 53 */       else if (this.msMask.equals(MSMask.TYPE_ALL_1)) { Arrays.fill(this.msUsed, true); }
/* 54 */       else if (this.msMask.equals(MSMask.TYPE_ALL_0)) { Arrays.fill(this.msUsed, false); }
/* 55 */       else { throw new AACException("reserved MS mask type used"); }
/*    */     
/*    */     } else {
/* 58 */       this.msMask = MSMask.TYPE_ALL_0;
/* 59 */       Arrays.fill(this.msUsed, false);
/*    */     } 
/*    */     
/* 62 */     if (profile.isErrorResilientProfile() && info.isLTPrediction1Present() && (
/* 63 */       info.ltpData2Present = _in.readBool())) info.getLTPrediction2().decode(_in, info, profile);
/*    */ 
/*    */     
/* 66 */     this.icsL.decode(_in, this.commonWindow, conf);
/* 67 */     this.icsR.decode(_in, this.commonWindow, conf);
/*    */   }
/*    */   
/*    */   public ICStream getLeftChannel() {
/* 71 */     return this.icsL;
/*    */   }
/*    */   
/*    */   public ICStream getRightChannel() {
/* 75 */     return this.icsR;
/*    */   }
/*    */   
/*    */   public MSMask getMSMask() {
/* 79 */     return this.msMask;
/*    */   }
/*    */   
/*    */   public boolean isMSUsed(int off) {
/* 83 */     return this.msUsed[off];
/*    */   }
/*    */   
/*    */   public boolean isMSMaskPresent() {
/* 87 */     return !this.msMask.equals(MSMask.TYPE_ALL_0);
/*    */   }
/*    */   
/*    */   public boolean isCommonWindow() {
/* 91 */     return this.commonWindow;
/*    */   }
/*    */   
/*    */   public static MSMask msMaskFromInt(int i) throws AACException {
/* 95 */     MSMask[] values = MSMask.values();
/* 96 */     if (i >= values.length) {
/* 97 */       throw new AACException("unknown MS mask type");
/*    */     }
/* 99 */     return values[i];
/*    */   }
/*    */ }


/* Location:              C:\Users\rapha\Downloads\aurora.jar!\META-INF\jars\jcodec-0.2.5.jar!\net\sourceforge\jaad\aac\syntax\CPE.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */