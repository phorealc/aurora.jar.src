/*     */ package net.sourceforge.jaad.aac.syntax;
/*     */ 
/*     */ import net.sourceforge.jaad.aac.AACException;
/*     */ 
/*     */ 
/*     */ 
/*     */ public class BitStream
/*     */   implements IBitStream
/*     */ {
/*     */   private static final int WORD_BITS = 32;
/*     */   private static final int WORD_BYTES = 4;
/*     */   private static final int BYTE_MASK = 255;
/*     */   private byte[] buffer;
/*     */   private int pos;
/*     */   private int cache;
/*     */   protected int bitsCached;
/*     */   protected int position;
/*     */   
/*     */   public static BitStream createBitStream(byte[] data) {
/*  20 */     BitStream bs = new BitStream();
/*  21 */     bs.setData(data);
/*  22 */     return bs;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void destroy() {
/*  39 */     reset();
/*  40 */     this.buffer = null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final void setData(byte[] data) {
/*  49 */     int size = 4 * (data.length + 4 - 1) / 4;
/*     */     
/*  51 */     if (this.buffer == null || this.buffer.length != size) this.buffer = new byte[size]; 
/*  52 */     System.arraycopy(data, 0, this.buffer, 0, data.length);
/*  53 */     reset();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void byteAlign() throws AACException {
/*  61 */     int toFlush = this.bitsCached & 0x7;
/*  62 */     if (toFlush > 0) skipBits(toFlush);
/*     */   
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final void reset() {
/*  70 */     this.pos = 0;
/*  71 */     this.bitsCached = 0;
/*  72 */     this.cache = 0;
/*  73 */     this.position = 0;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int getPosition() {
/*  81 */     return this.position;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int getBitsLeft() {
/*  89 */     return (this.buffer != null) ? (8 * (this.buffer.length - this.pos) + this.bitsCached) : 0;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected int readCache(boolean peek) throws AACException {
/*  98 */     if (this.pos > this.buffer.length - 4) throw AACException.endOfStream(); 
/*  99 */     int i = (this.buffer[this.pos] & 0xFF) << 24 | (this.buffer[this.pos + 1] & 0xFF) << 16 | (this.buffer[this.pos + 2] & 0xFF) << 8 | this.buffer[this.pos + 3] & 0xFF;
/*     */ 
/*     */ 
/*     */     
/* 103 */     if (!peek) this.pos += 4; 
/* 104 */     return i;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int readBits(int n) throws AACException {
/*     */     int result;
/* 113 */     if (this.bitsCached >= n) {
/* 114 */       this.bitsCached -= n;
/* 115 */       result = this.cache >> this.bitsCached & maskBits(n);
/* 116 */       this.position += n;
/*     */     } else {
/*     */       
/* 119 */       this.position += n;
/* 120 */       int c = this.cache & maskBits(this.bitsCached);
/* 121 */       int left = n - this.bitsCached;
/* 122 */       this.cache = readCache(false);
/* 123 */       this.bitsCached = 32 - left;
/* 124 */       result = this.cache >> this.bitsCached & maskBits(left) | c << left;
/*     */     } 
/* 126 */     return result;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int readBit() throws AACException {
/*     */     int i;
/* 135 */     if (this.bitsCached > 0) {
/* 136 */       this.bitsCached--;
/* 137 */       i = this.cache >> this.bitsCached & 0x1;
/* 138 */       this.position++;
/*     */     } else {
/*     */       
/* 141 */       this.cache = readCache(false);
/* 142 */       this.bitsCached = 31;
/* 143 */       this.position++;
/* 144 */       i = this.cache >> this.bitsCached & 0x1;
/*     */     } 
/* 146 */     return i;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean readBool() throws AACException {
/* 154 */     return ((readBit() & 0x1) != 0);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int peekBits(int n) throws AACException {
/*     */     int ret;
/* 163 */     if (this.bitsCached >= n) {
/* 164 */       ret = this.cache >> this.bitsCached - n & maskBits(n);
/*     */     }
/*     */     else {
/*     */       
/* 168 */       int c = this.cache & maskBits(this.bitsCached);
/* 169 */       n -= this.bitsCached;
/*     */       
/* 171 */       ret = readCache(true) >> 32 - n & maskBits(n) | c << n;
/*     */     } 
/* 173 */     return ret;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int peekBit() throws AACException {
/*     */     int ret;
/* 182 */     if (this.bitsCached > 0) {
/* 183 */       ret = this.cache >> this.bitsCached - 1 & 0x1;
/*     */     } else {
/*     */       
/* 186 */       int word = readCache(true);
/* 187 */       ret = word >> 31 & 0x1;
/*     */     } 
/* 189 */     return ret;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void skipBits(int n) throws AACException {
/* 197 */     this.position += n;
/* 198 */     if (n <= this.bitsCached) {
/* 199 */       this.bitsCached -= n;
/*     */     } else {
/*     */       
/* 202 */       n -= this.bitsCached;
/* 203 */       while (n >= 32) {
/* 204 */         n -= 32;
/* 205 */         readCache(false);
/*     */       } 
/* 207 */       if (n > 0) {
/* 208 */         this.cache = readCache(false);
/* 209 */         this.bitsCached = 32 - n;
/*     */       } else {
/*     */         
/* 212 */         this.cache = 0;
/* 213 */         this.bitsCached = 0;
/*     */       } 
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void skipBit() throws AACException {
/* 223 */     this.position++;
/* 224 */     if (this.bitsCached > 0) {
/* 225 */       this.bitsCached--;
/*     */     } else {
/*     */       
/* 228 */       this.cache = readCache(false);
/* 229 */       this.bitsCached = 31;
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int maskBits(int n) {
/*     */     int i;
/* 239 */     if (n == 32) { i = -1; }
/* 240 */     else { i = (1 << n) - 1; }
/* 241 */      return i;
/*     */   }
/*     */ }


/* Location:              C:\Users\rapha\Downloads\aurora.jar!\META-INF\jars\jcodec-0.2.5.jar!\net\sourceforge\jaad\aac\syntax\BitStream.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */