/*    */ package net.sourceforge.jaad.aac.syntax;
/*    */ 
/*    */ import net.sourceforge.jaad.aac.AACException;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ class DSE
/*    */   extends Element
/*    */ {
/*    */   private byte[] dataStreamBytes;
/*    */   
/*    */   void decode(IBitStream _in) throws AACException {
/* 21 */     boolean byteAlign = _in.readBool();
/* 22 */     int count = _in.readBits(8);
/* 23 */     if (count == 255) count += _in.readBits(8);
/*    */     
/* 25 */     if (byteAlign) _in.byteAlign();
/*    */     
/* 27 */     this.dataStreamBytes = new byte[count];
/* 28 */     for (int i = 0; i < count; i++)
/* 29 */       this.dataStreamBytes[i] = (byte)_in.readBits(8); 
/*    */   }
/*    */ }


/* Location:              C:\Users\rapha\Downloads\aurora.jar!\META-INF\jars\jcodec-0.2.5.jar!\net\sourceforge\jaad\aac\syntax\DSE.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */