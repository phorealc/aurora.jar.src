/*     */ package net.sourceforge.jaad.aac.syntax;public class PCE extends Element { private static final int MAX_FRONT_CHANNEL_ELEMENTS = 16; private static final int MAX_SIDE_CHANNEL_ELEMENTS = 16; private static final int MAX_BACK_CHANNEL_ELEMENTS = 16;
/*     */   private static final int MAX_LFE_CHANNEL_ELEMENTS = 4;
/*     */   private static final int MAX_ASSOC_DATA_ELEMENTS = 8;
/*     */   private static final int MAX_VALID_CC_ELEMENTS = 16;
/*     */   private Profile profile;
/*     */   private SampleFrequency sampleFrequency;
/*     */   private int frontChannelElementsCount;
/*     */   private int sideChannelElementsCount;
/*     */   private int backChannelElementsCount;
/*     */   private int lfeChannelElementsCount;
/*     */   private int assocDataElementsCount;
/*     */   private int validCCElementsCount;
/*     */   private boolean monoMixdown;
/*     */   private boolean stereoMixdown;
/*     */   private boolean matrixMixdownIDXPresent;
/*     */   private int monoMixdownElementNumber;
/*     */   private int stereoMixdownElementNumber;
/*     */   private int matrixMixdownIDX;
/*     */   private boolean pseudoSurround;
/*     */   private final TaggedElement[] frontElements;
/*     */   private final TaggedElement[] sideElements;
/*     */   private final TaggedElement[] backElements;
/*     */   private final int[] lfeElementTags;
/*     */   private final int[] assocDataElementTags;
/*     */   private final CCE[] ccElements;
/*     */   private byte[] commentFieldData;
/*     */   
/*     */   public static class TaggedElement { private final boolean isCPE;
/*     */     
/*     */     public TaggedElement(boolean isCPE, int tag) {
/*  31 */       this.isCPE = isCPE;
/*  32 */       this.tag = tag;
/*     */     }
/*     */     private final int tag;
/*     */     public boolean isIsCPE() {
/*  36 */       return this.isCPE;
/*     */     }
/*     */     
/*     */     public int getTag() {
/*  40 */       return this.tag;
/*     */     } }
/*     */ 
/*     */   
/*     */   public static class CCE
/*     */   {
/*     */     private final boolean isIndSW;
/*     */     private final int tag;
/*     */     
/*     */     public CCE(boolean isIndSW, int tag) {
/*  50 */       this.isIndSW = isIndSW;
/*  51 */       this.tag = tag;
/*     */     }
/*     */     
/*     */     public boolean isIsIndSW() {
/*  55 */       return this.isIndSW;
/*     */     }
/*     */     
/*     */     public int getTag() {
/*  59 */       return this.tag;
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public PCE() {
/*  78 */     this.frontElements = new TaggedElement[16];
/*  79 */     this.sideElements = new TaggedElement[16];
/*  80 */     this.backElements = new TaggedElement[16];
/*  81 */     this.lfeElementTags = new int[4];
/*  82 */     this.assocDataElementTags = new int[8];
/*  83 */     this.ccElements = new CCE[16];
/*  84 */     this.sampleFrequency = SampleFrequency.SAMPLE_FREQUENCY_NONE;
/*     */   }
/*     */   
/*     */   public void decode(IBitStream _in) throws AACException {
/*  88 */     readElementInstanceTag(_in);
/*     */     
/*  90 */     this.profile = Profile.forInt(_in.readBits(2));
/*     */     
/*  92 */     this.sampleFrequency = SampleFrequency.forInt(_in.readBits(4));
/*     */     
/*  94 */     this.frontChannelElementsCount = _in.readBits(4);
/*  95 */     this.sideChannelElementsCount = _in.readBits(4);
/*  96 */     this.backChannelElementsCount = _in.readBits(4);
/*  97 */     this.lfeChannelElementsCount = _in.readBits(2);
/*  98 */     this.assocDataElementsCount = _in.readBits(3);
/*  99 */     this.validCCElementsCount = _in.readBits(4);
/*     */     
/* 101 */     if (this.monoMixdown = _in.readBool()) {
/* 102 */       Logger.warn("mono mixdown present, but not yet supported");
/* 103 */       this.monoMixdownElementNumber = _in.readBits(4);
/*     */     } 
/* 105 */     if (this.stereoMixdown = _in.readBool()) {
/* 106 */       Logger.warn("stereo mixdown present, but not yet supported");
/* 107 */       this.stereoMixdownElementNumber = _in.readBits(4);
/*     */     } 
/* 109 */     if (this.matrixMixdownIDXPresent = _in.readBool()) {
/* 110 */       Logger.warn("matrix mixdown present, but not yet supported");
/* 111 */       this.matrixMixdownIDX = _in.readBits(2);
/* 112 */       this.pseudoSurround = _in.readBool();
/*     */     } 
/*     */     
/* 115 */     readTaggedElementArray(this.frontElements, _in, this.frontChannelElementsCount);
/*     */     
/* 117 */     readTaggedElementArray(this.sideElements, _in, this.sideChannelElementsCount);
/*     */     
/* 119 */     readTaggedElementArray(this.backElements, _in, this.backChannelElementsCount);
/*     */     
/*     */     int i;
/* 122 */     for (i = 0; i < this.lfeChannelElementsCount; i++) {
/* 123 */       this.lfeElementTags[i] = _in.readBits(4);
/*     */     }
/*     */     
/* 126 */     for (i = 0; i < this.assocDataElementsCount; i++) {
/* 127 */       this.assocDataElementTags[i] = _in.readBits(4);
/*     */     }
/*     */     
/* 130 */     for (i = 0; i < this.validCCElementsCount; i++) {
/* 131 */       this.ccElements[i] = new CCE(_in.readBool(), _in.readBits(4));
/*     */     }
/*     */     
/* 134 */     _in.byteAlign();
/*     */     
/* 136 */     int commentFieldBytes = _in.readBits(8);
/* 137 */     this.commentFieldData = new byte[commentFieldBytes];
/* 138 */     for (i = 0; i < commentFieldBytes; i++) {
/* 139 */       this.commentFieldData[i] = (byte)_in.readBits(8);
/*     */     }
/*     */   }
/*     */   
/*     */   private void readTaggedElementArray(TaggedElement[] te, IBitStream _in, int len) throws AACException {
/* 144 */     for (int i = 0; i < len; i++) {
/* 145 */       te[i] = new TaggedElement(_in.readBool(), _in.readBits(4));
/*     */     }
/*     */   }
/*     */   
/*     */   public Profile getProfile() {
/* 150 */     return this.profile;
/*     */   }
/*     */   
/*     */   public SampleFrequency getSampleFrequency() {
/* 154 */     return this.sampleFrequency;
/*     */   }
/*     */   
/*     */   public int getChannelCount() {
/* 158 */     return this.frontChannelElementsCount + this.sideChannelElementsCount + this.backChannelElementsCount + this.lfeChannelElementsCount + this.assocDataElementsCount;
/*     */   } }


/* Location:              C:\Users\rapha\Downloads\aurora.jar!\META-INF\jars\jcodec-0.2.5.jar!\net\sourceforge\jaad\aac\syntax\PCE.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */