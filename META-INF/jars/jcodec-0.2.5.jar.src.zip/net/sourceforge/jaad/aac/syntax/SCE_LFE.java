/*    */ package net.sourceforge.jaad.aac.syntax;
/*    */ 
/*    */ import net.sourceforge.jaad.aac.AACDecoderConfig;
/*    */ import net.sourceforge.jaad.aac.AACException;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ class SCE_LFE
/*    */   extends Element
/*    */ {
/*    */   private final ICStream ics;
/*    */   
/*    */   SCE_LFE(int frameLength) {
/* 19 */     this.ics = new ICStream(frameLength);
/*    */   }
/*    */   
/*    */   void decode(IBitStream _in, AACDecoderConfig conf) throws AACException {
/* 23 */     readElementInstanceTag(_in);
/* 24 */     this.ics.decode(_in, false, conf);
/*    */   }
/*    */   
/*    */   public ICStream getICStream() {
/* 28 */     return this.ics;
/*    */   }
/*    */ }


/* Location:              C:\Users\rapha\Downloads\aurora.jar!\META-INF\jars\jcodec-0.2.5.jar!\net\sourceforge\jaad\aac\syntax\SCE_LFE.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */