package net.sourceforge.jaad.aac.syntax;

import net.sourceforge.jaad.aac.AACException;

public interface IBitStream {
  void destroy();
  
  void setData(byte[] paramArrayOfbyte);
  
  void byteAlign() throws AACException;
  
  void reset();
  
  int getPosition();
  
  int getBitsLeft();
  
  int readBits(int paramInt) throws AACException;
  
  int readBit() throws AACException;
  
  boolean readBool() throws AACException;
  
  int peekBits(int paramInt) throws AACException;
  
  int peekBit() throws AACException;
  
  void skipBits(int paramInt) throws AACException;
  
  void skipBit() throws AACException;
  
  int maskBits(int paramInt);
}


/* Location:              C:\Users\rapha\Downloads\aurora.jar!\META-INF\jars\jcodec-0.2.5.jar!\net\sourceforge\jaad\aac\syntax\IBitStream.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */