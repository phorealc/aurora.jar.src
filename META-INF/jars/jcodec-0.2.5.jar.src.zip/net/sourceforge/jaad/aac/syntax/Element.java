/*    */ package net.sourceforge.jaad.aac.syntax;
/*    */ 
/*    */ import net.sourceforge.jaad.aac.AACException;
/*    */ import net.sourceforge.jaad.aac.SampleFrequency;
/*    */ import net.sourceforge.jaad.aac.sbr.SBR;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public abstract class Element
/*    */   implements SyntaxConstants
/*    */ {
/*    */   private int elementInstanceTag;
/*    */   private SBR sbr;
/*    */   
/*    */   protected void readElementInstanceTag(IBitStream _in) throws AACException {
/* 20 */     this.elementInstanceTag = _in.readBits(4);
/*    */   }
/*    */   
/*    */   public int getElementInstanceTag() {
/* 24 */     return this.elementInstanceTag;
/*    */   }
/*    */   
/*    */   void decodeSBR(IBitStream _in, SampleFrequency sf, int count, boolean stereo, boolean crc, boolean downSampled, boolean smallFrames) throws AACException {
/* 28 */     if (this.sbr == null) this.sbr = new SBR(smallFrames, (this.elementInstanceTag == 1), sf, downSampled); 
/* 29 */     this.sbr.decode(_in, count);
/*    */   }
/*    */   
/*    */   boolean isSBRPresent() {
/* 33 */     return (this.sbr != null);
/*    */   }
/*    */   
/*    */   SBR getSBR() {
/* 37 */     return this.sbr;
/*    */   }
/*    */ }


/* Location:              C:\Users\rapha\Downloads\aurora.jar!\META-INF\jars\jcodec-0.2.5.jar!\net\sourceforge\jaad\aac\syntax\Element.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */