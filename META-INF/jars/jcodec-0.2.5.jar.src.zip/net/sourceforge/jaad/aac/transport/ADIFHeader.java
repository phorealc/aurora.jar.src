/*    */ package net.sourceforge.jaad.aac.transport;
/*    */ 
/*    */ import net.sourceforge.jaad.aac.AACException;
/*    */ import net.sourceforge.jaad.aac.syntax.IBitStream;
/*    */ import net.sourceforge.jaad.aac.syntax.PCE;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public final class ADIFHeader
/*    */ {
/*    */   private static final long ADIF_ID = 1094994246L;
/*    */   private long id;
/*    */   private boolean copyrightIDPresent;
/*    */   private byte[] copyrightID;
/*    */   private boolean originalCopy;
/*    */   private boolean home;
/*    */   private boolean bitstreamType;
/*    */   private int bitrate;
/*    */   private int pceCount;
/*    */   private int[] adifBufferFullness;
/*    */   private PCE[] pces;
/*    */   
/*    */   public static boolean isPresent(IBitStream _in) throws AACException {
/* 27 */     return (_in.peekBits(32) == 1094994246L);
/*    */   }
/*    */   
/*    */   private ADIFHeader() {
/* 31 */     this.copyrightID = new byte[9];
/*    */   }
/*    */   
/*    */   public static ADIFHeader readHeader(IBitStream _in) throws AACException {
/* 35 */     ADIFHeader h = new ADIFHeader();
/* 36 */     h.decode(_in);
/* 37 */     return h;
/*    */   }
/*    */ 
/*    */   
/*    */   private void decode(IBitStream _in) throws AACException {
/* 42 */     this.id = _in.readBits(32);
/* 43 */     this.copyrightIDPresent = _in.readBool();
/* 44 */     if (this.copyrightIDPresent) {
/* 45 */       for (int j = 0; j < 9; j++) {
/* 46 */         this.copyrightID[j] = (byte)_in.readBits(8);
/*    */       }
/*    */     }
/* 49 */     this.originalCopy = _in.readBool();
/* 50 */     this.home = _in.readBool();
/* 51 */     this.bitstreamType = _in.readBool();
/* 52 */     this.bitrate = _in.readBits(23);
/* 53 */     this.pceCount = _in.readBits(4) + 1;
/* 54 */     this.pces = new PCE[this.pceCount];
/* 55 */     this.adifBufferFullness = new int[this.pceCount];
/* 56 */     for (int i = 0; i < this.pceCount; i++) {
/* 57 */       if (this.bitstreamType) { this.adifBufferFullness[i] = -1; }
/* 58 */       else { this.adifBufferFullness[i] = _in.readBits(20); }
/* 59 */        this.pces[i] = new PCE();
/* 60 */       this.pces[i].decode(_in);
/*    */     } 
/*    */   }
/*    */   
/*    */   public PCE getFirstPCE() {
/* 65 */     return this.pces[0];
/*    */   }
/*    */ }


/* Location:              C:\Users\rapha\Downloads\aurora.jar!\META-INF\jars\jcodec-0.2.5.jar!\net\sourceforge\jaad\aac\transport\ADIFHeader.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */