package net.sourceforge.jaad.aac.huffman;

public interface HCB {
  public static final int ZERO_HCB = 0;
  
  public static final int ESCAPE_HCB = 11;
  
  public static final int NOISE_HCB = 13;
  
  public static final int INTENSITY_HCB2 = 14;
  
  public static final int INTENSITY_HCB = 15;
  
  public static final int FIRST_PAIR_HCB = 5;
}


/* Location:              C:\Users\rapha\Downloads\aurora.jar!\META-INF\jars\jcodec-0.2.5.jar!\net\sourceforge\jaad\aac\huffman\HCB.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */