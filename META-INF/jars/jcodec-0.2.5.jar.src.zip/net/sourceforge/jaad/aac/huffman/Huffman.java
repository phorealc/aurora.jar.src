/*    */ package net.sourceforge.jaad.aac.huffman;
/*    */ 
/*    */ import net.sourceforge.jaad.aac.AACException;
/*    */ import net.sourceforge.jaad.aac.syntax.IBitStream;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class Huffman
/*    */   implements Codebooks
/*    */ {
/* 16 */   private static final boolean[] UNSIGNED = new boolean[] { 
/*    */       false, false, true, true, false, false, true, true, true, true, 
/*    */       true };
/*    */   private static final int QUAD_LEN = 4;
/*    */   private static final int PAIR_LEN = 2;
/*    */   
/*    */   private static int findOffset(IBitStream _in, int[][] table) throws AACException {
/* 23 */     int off = 0;
/* 24 */     int len = table[off][0];
/* 25 */     int cw = _in.readBits(len);
/*    */     
/* 27 */     while (cw != table[off][1]) {
/* 28 */       off++;
/* 29 */       int j = table[off][0] - len;
/* 30 */       len = table[off][0];
/* 31 */       cw <<= j;
/* 32 */       cw |= _in.readBits(j);
/*    */     } 
/* 34 */     return off;
/*    */   }
/*    */   
/*    */   private static void signValues(IBitStream _in, int[] data, int off, int len) throws AACException {
/* 38 */     for (int i = off; i < off + len; i++) {
/* 39 */       if (data[i] != 0 && 
/* 40 */         _in.readBool()) data[i] = -data[i];
/*    */     
/*    */     } 
/*    */   }
/*    */   
/*    */   private static int getEscape(IBitStream _in, int s) throws AACException {
/* 46 */     boolean neg = (s < 0);
/*    */     
/* 48 */     int i = 4;
/* 49 */     while (_in.readBool()) {
/* 50 */       i++;
/*    */     }
/* 52 */     int j = _in.readBits(i) | 1 << i;
/*    */     
/* 54 */     return neg ? -j : j;
/*    */   }
/*    */   
/*    */   public static int decodeScaleFactor(IBitStream _in) throws AACException {
/* 58 */     int offset = findOffset(_in, HCB_SF);
/* 59 */     return HCB_SF[offset][2];
/*    */   }
/*    */   
/*    */   public static void decodeSpectralData(IBitStream _in, int cb, int[] data, int off) throws AACException {
/* 63 */     int[][] HCB = CODEBOOKS[cb - 1];
/*    */ 
/*    */     
/* 66 */     int offset = findOffset(_in, HCB);
/*    */ 
/*    */     
/* 69 */     data[off] = HCB[offset][2];
/* 70 */     data[off + 1] = HCB[offset][3];
/* 71 */     if (cb < 5) {
/* 72 */       data[off + 2] = HCB[offset][4];
/* 73 */       data[off + 3] = HCB[offset][5];
/*    */     } 
/*    */ 
/*    */     
/* 77 */     if (cb < 11) {
/* 78 */       if (UNSIGNED[cb - 1]) signValues(_in, data, off, (cb < 5) ? 4 : 2);
/*    */     
/* 80 */     } else if (cb == 11 || cb > 15) {
/* 81 */       signValues(_in, data, off, (cb < 5) ? 4 : 2);
/* 82 */       if (Math.abs(data[off]) == 16) data[off] = getEscape(_in, data[off]); 
/* 83 */       if (Math.abs(data[off + 1]) == 16) data[off + 1] = getEscape(_in, data[off + 1]); 
/*    */     } else {
/* 85 */       throw new AACException("Huffman: unknown spectral codebook: " + cb);
/*    */     } 
/*    */   }
/*    */ }


/* Location:              C:\Users\rapha\Downloads\aurora.jar!\META-INF\jars\jcodec-0.2.5.jar!\net\sourceforge\jaad\aac\huffman\Huffman.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */