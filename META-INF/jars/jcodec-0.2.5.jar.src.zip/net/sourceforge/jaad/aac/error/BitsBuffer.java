/*     */ package net.sourceforge.jaad.aac.error;
/*     */ 
/*     */ import net.sourceforge.jaad.aac.AACException;
/*     */ import net.sourceforge.jaad.aac.syntax.IBitStream;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class BitsBuffer
/*     */ {
/*  17 */   static final int[] S = new int[] { 1, 2, 4, 8, 16 };
/*  18 */   static final int[] B = new int[] { 1431655765, 858993459, 252645135, 16711935, 65535 };
/*     */ 
/*     */   
/*  21 */   int len = 0;
/*     */   int bufa;
/*     */   
/*     */   public int getLength() {
/*  25 */     return this.len;
/*     */   }
/*     */   int bufb;
/*     */   public int showBits(int bits) {
/*  29 */     if (bits == 0) return 0; 
/*  30 */     if (this.len <= 32) {
/*     */ 
/*     */       
/*  33 */       if (this.len >= bits) return this.bufa >> this.len - bits & -1 >> 32 - bits; 
/*  34 */       return this.bufa << bits - this.len & -1 >> 32 - bits;
/*     */     } 
/*     */     
/*  37 */     if (this.len - bits < 32) return (this.bufb & -1 >> 64 - this.len) << bits - this.len + 32 | this.bufa >> this.len - bits; 
/*  38 */     return this.bufb >> this.len - bits - 32 & -1 >> 32 - bits;
/*     */   }
/*     */   
/*     */   public boolean flushBits(int bits) {
/*     */     boolean b;
/*  43 */     this.len -= bits;
/*     */ 
/*     */     
/*  46 */     if (this.len < 0) {
/*  47 */       this.len = 0;
/*  48 */       b = false;
/*     */     } else {
/*  50 */       b = true;
/*  51 */     }  return b;
/*     */   }
/*     */   
/*     */   public int getBits(int n) {
/*  55 */     int i = showBits(n);
/*  56 */     if (!flushBits(n)) i = -1; 
/*  57 */     return i;
/*     */   }
/*     */   
/*     */   public int getBit() {
/*  61 */     int i = showBits(1);
/*  62 */     if (!flushBits(1)) i = -1; 
/*  63 */     return i;
/*     */   }
/*     */   
/*     */   public void rewindReverse() {
/*  67 */     if (this.len == 0)
/*  68 */       return;  int[] i = rewindReverse64(this.bufb, this.bufa, this.len);
/*  69 */     this.bufb = i[0];
/*  70 */     this.bufa = i[1];
/*     */   }
/*     */   
/*     */   public void concatBits(BitsBuffer a) {
/*     */     int bl, bh;
/*  75 */     if (a.len == 0)
/*  76 */       return;  int al = a.bufa;
/*  77 */     int ah = a.bufb;
/*     */ 
/*     */     
/*  80 */     if (this.len > 32) {
/*     */       
/*  82 */       bl = this.bufa;
/*  83 */       bh = this.bufb & (1 << this.len - 32) - 1;
/*     */       
/*  85 */       ah = al << this.len - 32;
/*  86 */       al = 0;
/*     */     } else {
/*     */       
/*  89 */       bl = this.bufa & (1 << this.len) - 1;
/*  90 */       bh = 0;
/*  91 */       ah = ah << this.len | al >> 32 - this.len;
/*  92 */       al <<= this.len;
/*     */     } 
/*     */ 
/*     */     
/*  96 */     this.bufa = bl | al;
/*  97 */     this.bufb = bh | ah;
/*     */     
/*  99 */     this.len += a.len;
/*     */   }
/*     */   
/*     */   public void readSegment(int segwidth, IBitStream _in) throws AACException {
/* 103 */     this.len = segwidth;
/*     */     
/* 105 */     if (segwidth > 32) {
/* 106 */       this.bufb = _in.readBits(segwidth - 32);
/* 107 */       this.bufa = _in.readBits(32);
/*     */     } else {
/*     */       
/* 110 */       this.bufa = _in.readBits(segwidth);
/* 111 */       this.bufb = 0;
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   static int rewindReverse32(int v, int len) {
/* 117 */     v = v >> S[0] & B[0] | v << S[0] & (B[0] ^ 0xFFFFFFFF);
/* 118 */     v = v >> S[1] & B[1] | v << S[1] & (B[1] ^ 0xFFFFFFFF);
/* 119 */     v = v >> S[2] & B[2] | v << S[2] & (B[2] ^ 0xFFFFFFFF);
/* 120 */     v = v >> S[3] & B[3] | v << S[3] & (B[3] ^ 0xFFFFFFFF);
/* 121 */     v = v >> S[4] & B[4] | v << S[4] & (B[4] ^ 0xFFFFFFFF);
/*     */ 
/*     */     
/* 124 */     v >>= 32 - len;
/*     */     
/* 126 */     return v;
/*     */   }
/*     */ 
/*     */   
/*     */   static int[] rewindReverse64(int hi, int lo, int len) {
/* 131 */     int[] i = new int[2];
/* 132 */     if (len <= 32) {
/* 133 */       i[0] = 0;
/* 134 */       i[1] = rewindReverse32(lo, len);
/*     */     } else {
/*     */       
/* 137 */       lo = lo >> S[0] & B[0] | lo << S[0] & (B[0] ^ 0xFFFFFFFF);
/* 138 */       hi = hi >> S[0] & B[0] | hi << S[0] & (B[0] ^ 0xFFFFFFFF);
/* 139 */       lo = lo >> S[1] & B[1] | lo << S[1] & (B[1] ^ 0xFFFFFFFF);
/* 140 */       hi = hi >> S[1] & B[1] | hi << S[1] & (B[1] ^ 0xFFFFFFFF);
/* 141 */       lo = lo >> S[2] & B[2] | lo << S[2] & (B[2] ^ 0xFFFFFFFF);
/* 142 */       hi = hi >> S[2] & B[2] | hi << S[2] & (B[2] ^ 0xFFFFFFFF);
/* 143 */       lo = lo >> S[3] & B[3] | lo << S[3] & (B[3] ^ 0xFFFFFFFF);
/* 144 */       hi = hi >> S[3] & B[3] | hi << S[3] & (B[3] ^ 0xFFFFFFFF);
/* 145 */       lo = lo >> S[4] & B[4] | lo << S[4] & (B[4] ^ 0xFFFFFFFF);
/* 146 */       hi = hi >> S[4] & B[4] | hi << S[4] & (B[4] ^ 0xFFFFFFFF);
/*     */ 
/*     */       
/* 149 */       i[1] = hi >> 64 - len | lo << len - 32;
/* 150 */       i[1] = lo >> 64 - len;
/*     */     } 
/* 152 */     return i;
/*     */   }
/*     */ }


/* Location:              C:\Users\rapha\Downloads\aurora.jar!\META-INF\jars\jcodec-0.2.5.jar!\net\sourceforge\jaad\aac\error\BitsBuffer.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */