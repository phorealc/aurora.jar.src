/*     */ package net.sourceforge.jaad.aac.error;
/*     */ 
/*     */ import net.sourceforge.jaad.aac.AACException;
/*     */ import net.sourceforge.jaad.aac.syntax.IBitStream;
/*     */ import net.sourceforge.jaad.aac.syntax.ICSInfo;
/*     */ import net.sourceforge.jaad.aac.syntax.ICStream;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class RVLC
/*     */   implements RVLCTables
/*     */ {
/*     */   private static final int ESCAPE_FLAG = 7;
/*     */   
/*     */   public void decode(IBitStream _in, ICStream ics, int[][] scaleFactors) throws AACException {
/*  24 */     int bits = ics.getInfo().isEightShortFrame() ? 11 : 9;
/*  25 */     boolean sfConcealment = _in.readBool();
/*  26 */     int revGlobalGain = _in.readBits(8);
/*  27 */     int rvlcSFLen = _in.readBits(bits);
/*     */     
/*  29 */     ICSInfo info = ics.getInfo();
/*  30 */     int windowGroupCount = info.getWindowGroupCount();
/*  31 */     int maxSFB = info.getMaxSFB();
/*  32 */     int[][] sfbCB = { {} };
/*     */     
/*  34 */     int sf = ics.getGlobalGain();
/*  35 */     int intensityPosition = 0;
/*  36 */     int noiseEnergy = sf - 90 - 256;
/*  37 */     boolean intensityUsed = false, noiseUsed = false;
/*     */ 
/*     */     
/*  40 */     for (int g = 0; g < windowGroupCount; g++) {
/*  41 */       for (int sfb = 0; sfb < maxSFB; sfb++) {
/*  42 */         switch (sfbCB[g][sfb]) {
/*     */           case 0:
/*  44 */             scaleFactors[g][sfb] = 0;
/*     */             break;
/*     */           case 14:
/*     */           case 15:
/*  48 */             if (!intensityUsed) intensityUsed = true; 
/*  49 */             intensityPosition += decodeHuffman(_in);
/*  50 */             scaleFactors[g][sfb] = intensityPosition;
/*     */             break;
/*     */           case 13:
/*  53 */             if (noiseUsed) {
/*  54 */               noiseEnergy += decodeHuffman(_in);
/*  55 */               scaleFactors[g][sfb] = noiseEnergy;
/*     */               break;
/*     */             } 
/*  58 */             noiseUsed = true;
/*  59 */             noiseEnergy = decodeHuffman(_in);
/*     */             break;
/*     */           
/*     */           default:
/*  63 */             sf += decodeHuffman(_in);
/*  64 */             scaleFactors[g][sfb] = sf;
/*     */             break;
/*     */         } 
/*     */       
/*     */       } 
/*     */     } 
/*  70 */     int lastIntensityPosition = 0;
/*  71 */     if (intensityUsed) lastIntensityPosition = decodeHuffman(_in); 
/*  72 */     noiseUsed = false;
/*  73 */     if (_in.readBool()) decodeEscapes(_in, ics, scaleFactors); 
/*     */   }
/*     */   
/*     */   private void decodeEscapes(IBitStream _in, ICStream ics, int[][] scaleFactors) throws AACException {
/*  77 */     ICSInfo info = ics.getInfo();
/*  78 */     int windowGroupCount = info.getWindowGroupCount();
/*  79 */     int maxSFB = info.getMaxSFB();
/*  80 */     int[][] sfbCB = { {} };
/*     */     
/*  82 */     int escapesLen = _in.readBits(8);
/*     */     
/*  84 */     boolean noiseUsed = false;
/*     */ 
/*     */     
/*  87 */     for (int g = 0; g < windowGroupCount; g++) {
/*  88 */       for (int sfb = 0; sfb < maxSFB; sfb++) {
/*  89 */         if (sfbCB[g][sfb] == 13 && !noiseUsed) { noiseUsed = true; }
/*  90 */         else if (Math.abs(sfbCB[g][sfb]) == 7)
/*  91 */         { int val = decodeHuffmanEscape(_in);
/*  92 */           if (sfbCB[g][sfb] == -7) { scaleFactors[g][sfb] = scaleFactors[g][sfb] - val; }
/*  93 */           else { scaleFactors[g][sfb] = scaleFactors[g][sfb] + val; }
/*     */            }
/*     */       
/*     */       } 
/*     */     } 
/*     */   }
/*     */   private int decodeHuffman(IBitStream _in) throws AACException {
/* 100 */     int off = 0;
/* 101 */     int i = RVLC_BOOK[off][1];
/* 102 */     int cw = _in.readBits(i);
/*     */ 
/*     */     
/* 105 */     while (cw != RVLC_BOOK[off][2] && i < 10) {
/* 106 */       off++;
/* 107 */       int j = RVLC_BOOK[off][1] - i;
/* 108 */       i += j;
/* 109 */       cw <<= j;
/* 110 */       cw |= _in.readBits(j);
/*     */     } 
/*     */     
/* 113 */     return RVLC_BOOK[off][0];
/*     */   }
/*     */   
/*     */   private int decodeHuffmanEscape(IBitStream _in) throws AACException {
/* 117 */     int off = 0;
/* 118 */     int i = ESCAPE_BOOK[off][1];
/* 119 */     int cw = _in.readBits(i);
/*     */ 
/*     */     
/* 122 */     while (cw != ESCAPE_BOOK[off][2] && i < 21) {
/* 123 */       off++;
/* 124 */       int j = ESCAPE_BOOK[off][1] - i;
/* 125 */       i += j;
/* 126 */       cw <<= j;
/* 127 */       cw |= _in.readBits(j);
/*     */     } 
/*     */     
/* 130 */     return ESCAPE_BOOK[off][0];
/*     */   }
/*     */ }


/* Location:              C:\Users\rapha\Downloads\aurora.jar!\META-INF\jars\jcodec-0.2.5.jar!\net\sourceforge\jaad\aac\error\RVLC.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */