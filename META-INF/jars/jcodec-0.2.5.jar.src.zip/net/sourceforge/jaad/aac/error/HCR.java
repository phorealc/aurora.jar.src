/*     */ package net.sourceforge.jaad.aac.error;
/*     */ 
/*     */ import net.sourceforge.jaad.aac.AACException;
/*     */ import net.sourceforge.jaad.aac.syntax.IBitStream;
/*     */ import net.sourceforge.jaad.aac.syntax.ICSInfo;
/*     */ import net.sourceforge.jaad.aac.syntax.ICStream;
/*     */ import net.sourceforge.jaad.aac.syntax.SyntaxConstants;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class HCR
/*     */   implements SyntaxConstants
/*     */ {
/*     */   private static final int NUM_CB = 6;
/*     */   private static final int NUM_CB_ER = 22;
/*     */   private static final int MAX_CB = 32;
/*     */   private static final int VCB11_FIRST = 16;
/*     */   private static final int VCB11_LAST = 31;
/*     */   
/*     */   private static class Codeword
/*     */   {
/*     */     int cb;
/*     */     int decoded;
/*     */     int sp_offset;
/*     */     BitsBuffer bits;
/*     */     
/*     */     private void fill(int sp, int cb) {
/*  30 */       this.sp_offset = sp;
/*  31 */       this.cb = cb;
/*  32 */       this.decoded = 0;
/*  33 */       this.bits = new BitsBuffer();
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  41 */   private static final int[] PRE_SORT_CB_STD = new int[] { 11, 9, 7, 5, 3, 1 };
/*  42 */   private static final int[] PRE_SORT_CB_ER = new int[] { 11, 31, 30, 29, 28, 27, 26, 25, 24, 23, 22, 21, 20, 19, 18, 17, 16, 9, 7, 5, 3, 1 };
/*  43 */   private static final int[] MAX_CW_LEN = new int[] { 0, 11, 9, 20, 16, 13, 11, 14, 12, 17, 14, 49, 0, 0, 0, 0, 14, 17, 21, 21, 25, 25, 29, 29, 29, 29, 33, 33, 33, 37, 37, 41 };
/*     */   
/*     */   private static boolean isGoodCB(int cb, int sectCB) {
/*  46 */     boolean b = false;
/*  47 */     if ((sectCB > 0 && sectCB <= 11) || (sectCB >= 16 && sectCB <= 31))
/*  48 */       if (cb < 11) { b = (sectCB == cb || sectCB == cb + 1); }
/*  49 */       else { b = (sectCB == cb); }
/*     */        
/*  51 */     return b;
/*     */   }
/*     */   
/*     */   public static void decodeReorderedSpectralData(ICStream ics, IBitStream _in, short[] spectralData, boolean sectionDataResilience) throws AACException {
/*     */     int lastCB, preSortCB[];
/*  56 */     ICSInfo info = ics.getInfo();
/*  57 */     int windowGroupCount = info.getWindowGroupCount();
/*  58 */     int maxSFB = info.getMaxSFB();
/*  59 */     int[] swbOffsets = info.getSWBOffsets();
/*  60 */     int swbOffsetMax = info.getSWBOffsetMax();
/*     */ 
/*     */     
/*  63 */     int[][] sectStart = new int[0][0];
/*  64 */     int[][] sectEnd = new int[0][0];
/*  65 */     int[] numSec = new int[0];
/*  66 */     int[][] sectCB = new int[0][0];
/*  67 */     int[][] sectSFBOffsets = new int[0][0];
/*     */ 
/*     */     
/*  70 */     int spDataLen = ics.getReorderedSpectralDataLength();
/*  71 */     if (spDataLen == 0)
/*     */       return; 
/*  73 */     int longestLen = ics.getLongestCodewordLength();
/*  74 */     if (longestLen == 0 || longestLen >= spDataLen) throw new AACException("length of longest HCR codeword out of range");
/*     */ 
/*     */     
/*  77 */     int[] spOffsets = new int[8];
/*  78 */     int shortFrameLen = spectralData.length / 8;
/*  79 */     spOffsets[0] = 0;
/*     */     int g;
/*  81 */     for (g = 1; g < windowGroupCount; g++) {
/*  82 */       spOffsets[g] = spOffsets[g - 1] + shortFrameLen * info.getWindowGroupLength(g - 1);
/*     */     }
/*     */     
/*  85 */     Codeword[] codeword = new Codeword[512];
/*  86 */     BitsBuffer[] segment = new BitsBuffer[512];
/*     */ 
/*     */ 
/*     */     
/*  90 */     if (sectionDataResilience) {
/*  91 */       preSortCB = PRE_SORT_CB_ER;
/*  92 */       lastCB = 22;
/*     */     } else {
/*     */       
/*  95 */       preSortCB = PRE_SORT_CB_STD;
/*  96 */       lastCB = 6;
/*     */     } 
/*     */     
/*  99 */     int PCWs_done = 0;
/* 100 */     int segmentsCount = 0;
/* 101 */     int numberOfCodewords = 0;
/* 102 */     int bitsread = 0;
/*     */ 
/*     */ 
/*     */     
/* 106 */     for (int sortloop = 0; sortloop < lastCB; sortloop++) {
/*     */       
/* 108 */       int thisCB = preSortCB[sortloop];
/*     */       
/* 110 */       for (int sfb = 0; sfb < maxSFB; sfb++) {
/* 111 */         for (int w_idx = 0; 4 * w_idx < Math.min(swbOffsets[sfb + 1], swbOffsetMax) - swbOffsets[sfb]; w_idx++) {
/* 112 */           for (g = 0; g < windowGroupCount; g++) {
/* 113 */             for (int i = 0; i < numSec[g]; i++) {
/* 114 */               if (sectStart[g][i] <= sfb && sectEnd[g][i] > sfb) {
/*     */                 
/* 116 */                 int thisSectCB = sectCB[g][i];
/*     */                 
/* 118 */                 if (isGoodCB(thisCB, thisSectCB)) {
/*     */                   
/* 120 */                   int sect_sfb_size = sectSFBOffsets[g][sfb + 1] - sectSFBOffsets[g][sfb];
/* 121 */                   int inc = (thisSectCB < 5) ? 4 : 2;
/* 122 */                   int group_cws_count = 4 * info.getWindowGroupLength(g) / inc;
/* 123 */                   int segwidth = Math.min(MAX_CW_LEN[thisSectCB], longestLen);
/*     */ 
/*     */                   
/* 126 */                   for (int cws = 0; cws < group_cws_count && cws + w_idx * group_cws_count < sect_sfb_size; cws++) {
/* 127 */                     int sp = spOffsets[g] + sectSFBOffsets[g][sfb] + inc * (cws + w_idx * group_cws_count);
/*     */ 
/*     */                     
/* 130 */                     if (PCWs_done == 0) {
/*     */                       
/* 132 */                       if (bitsread + segwidth <= spDataLen) {
/* 133 */                         segment[segmentsCount].readSegment(segwidth, _in);
/* 134 */                         bitsread += segwidth;
/*     */ 
/*     */ 
/*     */ 
/*     */                         
/* 139 */                         segment[segmentsCount].rewindReverse();
/*     */                         
/* 141 */                         segmentsCount++;
/*     */                       }
/*     */                       else {
/*     */                         
/* 145 */                         if (bitsread < spDataLen) {
/* 146 */                           int additional_bits = spDataLen - bitsread;
/*     */                           
/* 148 */                           segment[segmentsCount].readSegment(additional_bits, _in);
/* 149 */                           (segment[segmentsCount]).len += (segment[segmentsCount - 1]).len;
/* 150 */                           segment[segmentsCount].rewindReverse();
/*     */                           
/* 152 */                           if ((segment[segmentsCount - 1]).len > 32) {
/* 153 */                             (segment[segmentsCount]).bufb += segment[segmentsCount - 1]
/* 154 */                               .showBits((segment[segmentsCount - 1]).len - 32);
/* 155 */                             (segment[segmentsCount]).bufa += segment[segmentsCount - 1]
/* 156 */                               .showBits(32);
/*     */                           } else {
/*     */                             
/* 159 */                             (segment[segmentsCount]).bufa += segment[segmentsCount - 1]
/* 160 */                               .showBits((segment[segmentsCount - 1]).len);
/* 161 */                             (segment[segmentsCount - 1]).bufb = (segment[segmentsCount]).bufb;
/*     */                           } 
/* 163 */                           (segment[segmentsCount - 1]).len += additional_bits;
/*     */                         } 
/* 165 */                         bitsread = spDataLen;
/* 166 */                         PCWs_done = 1;
/*     */                         
/* 168 */                         codeword[0].fill(sp, thisSectCB);
/*     */                       } 
/*     */                     } else {
/*     */                       
/* 172 */                       codeword[numberOfCodewords - segmentsCount].fill(sp, thisSectCB);
/*     */                     } 
/* 174 */                     numberOfCodewords++;
/*     */                   } 
/*     */                 } 
/*     */               } 
/*     */             } 
/*     */           } 
/*     */         } 
/*     */       } 
/*     */     } 
/*     */     
/* 184 */     if (segmentsCount == 0) throw new AACException("no segments _in HCR");
/*     */     
/* 186 */     int numberOfSets = numberOfCodewords / segmentsCount;
/*     */ 
/*     */ 
/*     */     
/* 190 */     for (int set = 1; set <= numberOfSets; set++) {
/* 191 */       for (int trial = 0; trial < segmentsCount; trial++) {
/* 192 */         for (int codewordBase = 0; codewordBase < segmentsCount; codewordBase++) {
/* 193 */           int segmentID = (trial + codewordBase) % segmentsCount;
/* 194 */           int codewordID = codewordBase + set * segmentsCount - segmentsCount;
/*     */ 
/*     */           
/* 197 */           if (codewordID >= numberOfCodewords - segmentsCount)
/*     */             break; 
/* 199 */           if ((codeword[codewordID]).decoded == 0 && (segment[segmentID]).len > 0) {
/* 200 */             if ((codeword[codewordID]).bits.len != 0) segment[segmentID].concatBits((codeword[codewordID]).bits);
/*     */             
/* 202 */             int j = (segment[segmentID]).len;
/*     */           } 
/*     */         } 
/*     */       } 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 215 */       for (int i = 0; i < segmentsCount; i++)
/* 216 */         segment[i].rewindReverse(); 
/*     */     } 
/*     */   }
/*     */ }


/* Location:              C:\Users\rapha\Downloads\aurora.jar!\META-INF\jars\jcodec-0.2.5.jar!\net\sourceforge\jaad\aac\error\HCR.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */