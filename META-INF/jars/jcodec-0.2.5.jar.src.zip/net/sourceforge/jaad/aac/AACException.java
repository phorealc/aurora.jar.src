/*    */ package net.sourceforge.jaad.aac;
/*    */ 
/*    */ import java.io.IOException;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class AACException
/*    */   extends IOException
/*    */ {
/*    */   private boolean eos;
/*    */   
/*    */   public static AACException endOfStream() {
/* 17 */     AACException ex = new AACException("end of stream");
/* 18 */     ex.eos = true;
/* 19 */     return ex;
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public AACException(String message) {
/* 25 */     super(message);
/*    */   }
/*    */   
/*    */   public boolean isEndOfStream() {
/* 29 */     return this.eos;
/*    */   }
/*    */   
/*    */   public static AACException wrap(Exception e) {
/* 33 */     if (e != null && e instanceof AACException) {
/* 34 */       return (AACException)e;
/*    */     }
/* 36 */     if (e != null && e.getMessage() != null) {
/* 37 */       return new AACException(e.getMessage());
/*    */     }
/* 39 */     return new AACException("" + e);
/*    */   }
/*    */ }


/* Location:              C:\Users\rapha\Downloads\aurora.jar!\META-INF\jars\jcodec-0.2.5.jar!\net\sourceforge\jaad\aac\AACException.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */