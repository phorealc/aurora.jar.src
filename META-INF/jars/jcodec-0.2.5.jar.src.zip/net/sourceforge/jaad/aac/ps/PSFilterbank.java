/*     */ package net.sourceforge.jaad.aac.ps;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ class PSFilterbank
/*     */   implements PSTables
/*     */ {
/*     */   private int frame_len;
/*     */   private int[] resolution20;
/*     */   private int[] resolution34;
/*     */   private float[][] work;
/*     */   private float[][][] buffer;
/*     */   private float[][][] temp;
/*     */   
/*     */   PSFilterbank(int numTimeSlotsRate) {
/*  21 */     this.resolution20 = new int[3];
/*  22 */     this.resolution34 = new int[5];
/*     */ 
/*     */ 
/*     */     
/*  26 */     this.resolution34[0] = 12;
/*  27 */     this.resolution34[1] = 8;
/*  28 */     this.resolution34[2] = 4;
/*  29 */     this.resolution34[3] = 4;
/*  30 */     this.resolution34[4] = 4;
/*     */     
/*  32 */     this.resolution20[0] = 8;
/*  33 */     this.resolution20[1] = 2;
/*  34 */     this.resolution20[2] = 2;
/*     */     
/*  36 */     this.frame_len = numTimeSlotsRate;
/*     */     
/*  38 */     this.work = new float[this.frame_len + 12][2];
/*     */     
/*  40 */     this.buffer = new float[5][2][2];
/*     */     
/*  42 */     this.temp = new float[this.frame_len][12][2];
/*     */   }
/*     */ 
/*     */   
/*     */   void hybrid_analysis(float[][][] X, float[][][] X_hybrid, boolean use34, int numTimeSlotsRate) {
/*  47 */     int offset = 0;
/*  48 */     int qmf_bands = use34 ? 5 : 3;
/*  49 */     int[] resolution = use34 ? this.resolution34 : this.resolution20;
/*     */     
/*  51 */     for (int band = 0; band < qmf_bands; band++) {
/*     */       int i;
/*     */       
/*  54 */       for (i = 0; i < 12; i++) {
/*  55 */         this.work[i][0] = this.buffer[band][i][0];
/*  56 */         this.work[i][1] = this.buffer[band][i][1];
/*     */       } 
/*     */       
/*     */       int n;
/*  60 */       for (n = 0; n < this.frame_len; n++) {
/*  61 */         this.work[12 + n][0] = X[n + 6][band][0];
/*  62 */         this.work[12 + n][0] = X[n + 6][band][0];
/*     */       } 
/*     */ 
/*     */ 
/*     */       
/*  67 */       for (i = 0; i < 12; i++) {
/*  68 */         this.buffer[band][i][0] = this.work[this.frame_len + i][0];
/*  69 */         this.buffer[band][i][1] = this.work[this.frame_len + i][1];
/*     */       } 
/*     */       
/*  72 */       switch (resolution[band]) {
/*     */         
/*     */         case 2:
/*  75 */           channel_filter2(this.frame_len, p2_13_20, this.work, this.temp);
/*     */           break;
/*     */         
/*     */         case 4:
/*  79 */           channel_filter4(this.frame_len, p4_13_34, this.work, this.temp);
/*     */           break;
/*     */         
/*     */         case 8:
/*  83 */           channel_filter8(this.frame_len, use34 ? p8_13_34 : p8_13_20, this.work, this.temp);
/*     */           break;
/*     */ 
/*     */         
/*     */         case 12:
/*  88 */           channel_filter12(this.frame_len, p12_13_34, this.work, this.temp);
/*     */           break;
/*     */       } 
/*     */       
/*  92 */       for (n = 0; n < this.frame_len; n++) {
/*  93 */         for (int k = 0; k < resolution[band]; k++) {
/*  94 */           X_hybrid[n][offset + k][0] = this.temp[n][k][0];
/*  95 */           X_hybrid[n][offset + k][1] = this.temp[n][k][1];
/*     */         } 
/*     */       } 
/*  98 */       offset += resolution[band];
/*     */     } 
/*     */ 
/*     */     
/* 102 */     if (!use34) {
/* 103 */       for (int n = 0; n < numTimeSlotsRate; n++) {
/* 104 */         X_hybrid[n][3][0] = X_hybrid[n][3][0] + X_hybrid[n][4][0];
/* 105 */         X_hybrid[n][3][1] = X_hybrid[n][3][1] + X_hybrid[n][4][1];
/* 106 */         X_hybrid[n][4][0] = 0.0F;
/* 107 */         X_hybrid[n][4][1] = 0.0F;
/*     */         
/* 109 */         X_hybrid[n][2][0] = X_hybrid[n][2][0] + X_hybrid[n][5][0];
/* 110 */         X_hybrid[n][2][1] = X_hybrid[n][2][1] + X_hybrid[n][5][1];
/* 111 */         X_hybrid[n][5][0] = 0.0F;
/* 112 */         X_hybrid[n][5][1] = 0.0F;
/*     */       } 
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static void channel_filter2(int frame_len, float[] filter, float[][] buffer, float[][][] X_hybrid) {
/* 122 */     for (int i = 0; i < frame_len; i++) {
/* 123 */       float r0 = filter[0] * (buffer[0 + i][0] + buffer[12 + i][0]);
/* 124 */       float r1 = filter[1] * (buffer[1 + i][0] + buffer[11 + i][0]);
/* 125 */       float r2 = filter[2] * (buffer[2 + i][0] + buffer[10 + i][0]);
/* 126 */       float r3 = filter[3] * (buffer[3 + i][0] + buffer[9 + i][0]);
/* 127 */       float r4 = filter[4] * (buffer[4 + i][0] + buffer[8 + i][0]);
/* 128 */       float r5 = filter[5] * (buffer[5 + i][0] + buffer[7 + i][0]);
/* 129 */       float r6 = filter[6] * buffer[6 + i][0];
/* 130 */       float i0 = filter[0] * (buffer[0 + i][1] + buffer[12 + i][1]);
/* 131 */       float i1 = filter[1] * (buffer[1 + i][1] + buffer[11 + i][1]);
/* 132 */       float i2 = filter[2] * (buffer[2 + i][1] + buffer[10 + i][1]);
/* 133 */       float i3 = filter[3] * (buffer[3 + i][1] + buffer[9 + i][1]);
/* 134 */       float i4 = filter[4] * (buffer[4 + i][1] + buffer[8 + i][1]);
/* 135 */       float i5 = filter[5] * (buffer[5 + i][1] + buffer[7 + i][1]);
/* 136 */       float i6 = filter[6] * buffer[6 + i][1];
/*     */ 
/*     */       
/* 139 */       X_hybrid[i][0][0] = r0 + r1 + r2 + r3 + r4 + r5 + r6;
/* 140 */       X_hybrid[i][0][1] = i0 + i1 + i2 + i3 + i4 + i5 + i6;
/*     */ 
/*     */       
/* 143 */       X_hybrid[i][1][0] = r0 - r1 + r2 - r3 + r4 - r5 + r6;
/* 144 */       X_hybrid[i][1][1] = i0 - i1 + i2 - i3 + i4 - i5 + i6;
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static void channel_filter4(int frame_len, float[] filter, float[][] buffer, float[][][] X_hybrid) {
/* 152 */     float[] input_re1 = new float[2], input_re2 = new float[2];
/* 153 */     float[] input_im1 = new float[2], input_im2 = new float[2];
/*     */     
/* 155 */     for (int i = 0; i < frame_len; i++) {
/* 156 */       input_re1[0] = -(filter[2] * (buffer[i + 2][0] + buffer[i + 10][0])) + filter[6] * buffer[i + 6][0];
/*     */       
/* 158 */       input_re1[1] = -0.70710677F * (filter[1] * (buffer[i + 1][0] + buffer[i + 11][0]) + filter[3] * (buffer[i + 3][0] + buffer[i + 9][0]) - filter[5] * (buffer[i + 5][0] + buffer[i + 7][0]));
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 163 */       input_im1[0] = filter[0] * (buffer[i + 0][1] - buffer[i + 12][1]) - filter[4] * (buffer[i + 4][1] - buffer[i + 8][1]);
/*     */       
/* 165 */       input_im1[1] = 0.70710677F * (filter[1] * (buffer[i + 1][1] - buffer[i + 11][1]) - filter[3] * (buffer[i + 3][1] - buffer[i + 9][1]) - filter[5] * (buffer[i + 5][1] - buffer[i + 7][1]));
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 170 */       input_re2[0] = filter[0] * (buffer[i + 0][0] - buffer[i + 12][0]) - filter[4] * (buffer[i + 4][0] - buffer[i + 8][0]);
/*     */       
/* 172 */       input_re2[1] = 0.70710677F * (filter[1] * (buffer[i + 1][0] - buffer[i + 11][0]) - filter[3] * (buffer[i + 3][0] - buffer[i + 9][0]) - filter[5] * (buffer[i + 5][0] - buffer[i + 7][0]));
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 177 */       input_im2[0] = -(filter[2] * (buffer[i + 2][1] + buffer[i + 10][1])) + filter[6] * buffer[i + 6][1];
/*     */       
/* 179 */       input_im2[1] = -0.70710677F * (filter[1] * (buffer[i + 1][1] + buffer[i + 11][1]) + filter[3] * (buffer[i + 3][1] + buffer[i + 9][1]) - filter[5] * (buffer[i + 5][1] + buffer[i + 7][1]));
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 185 */       X_hybrid[i][0][0] = input_re1[0] + input_re1[1] + input_im1[0] + input_im1[1];
/* 186 */       X_hybrid[i][0][1] = -input_re2[0] - input_re2[1] + input_im2[0] + input_im2[1];
/*     */ 
/*     */       
/* 189 */       X_hybrid[i][1][0] = input_re1[0] - input_re1[1] - input_im1[0] + input_im1[1];
/* 190 */       X_hybrid[i][1][1] = input_re2[0] - input_re2[1] + input_im2[0] - input_im2[1];
/*     */ 
/*     */       
/* 193 */       X_hybrid[i][2][0] = input_re1[0] - input_re1[1] + input_im1[0] - input_im1[1];
/* 194 */       X_hybrid[i][2][1] = -input_re2[0] + input_re2[1] + input_im2[0] - input_im2[1];
/*     */ 
/*     */       
/* 197 */       X_hybrid[i][3][0] = input_re1[0] + input_re1[1] - input_im1[0] - input_im1[1];
/* 198 */       X_hybrid[i][3][1] = input_re2[0] + input_re2[1] + input_im2[0] + input_im2[1];
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   static void DCT3_4_unscaled(float[] y, float[] x) {
/* 205 */     float f0 = x[2] * 0.70710677F;
/* 206 */     float f1 = x[0] - f0;
/* 207 */     float f2 = x[0] + f0;
/* 208 */     float f3 = x[1] + x[3];
/* 209 */     float f4 = x[1] * 1.306563F;
/* 210 */     float f5 = f3 * -0.9238795F;
/* 211 */     float f6 = x[3] * -0.5411961F;
/* 212 */     float f7 = f4 + f5;
/* 213 */     float f8 = f6 - f5;
/* 214 */     y[3] = f2 - f8;
/* 215 */     y[0] = f2 + f8;
/* 216 */     y[2] = f1 - f7;
/* 217 */     y[1] = f1 + f7;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   void channel_filter8(int frame_len, float[] filter, float[][] buffer, float[][][] X_hybrid) {
/* 224 */     float[] input_re1 = new float[4], input_re2 = new float[4];
/* 225 */     float[] input_im1 = new float[4], input_im2 = new float[4];
/* 226 */     float[] x = new float[4];
/*     */     
/* 228 */     for (int i = 0; i < frame_len; i++) {
/* 229 */       input_re1[0] = filter[6] * buffer[6 + i][0];
/* 230 */       input_re1[1] = filter[5] * (buffer[5 + i][0] + buffer[7 + i][0]);
/* 231 */       input_re1[2] = -(filter[0] * (buffer[0 + i][0] + buffer[12 + i][0])) + filter[4] * (buffer[4 + i][0] + buffer[8 + i][0]);
/* 232 */       input_re1[3] = -(filter[1] * (buffer[1 + i][0] + buffer[11 + i][0])) + filter[3] * (buffer[3 + i][0] + buffer[9 + i][0]);
/*     */       
/* 234 */       input_im1[0] = filter[5] * (buffer[7 + i][1] - buffer[5 + i][1]);
/* 235 */       input_im1[1] = filter[0] * (buffer[12 + i][1] - buffer[0 + i][1]) + filter[4] * (buffer[8 + i][1] - buffer[4 + i][1]);
/* 236 */       input_im1[2] = filter[1] * (buffer[11 + i][1] - buffer[1 + i][1]) + filter[3] * (buffer[9 + i][1] - buffer[3 + i][1]);
/* 237 */       input_im1[3] = filter[2] * (buffer[10 + i][1] - buffer[2 + i][1]);
/*     */       int n;
/* 239 */       for (n = 0; n < 4; n++) {
/* 240 */         x[n] = input_re1[n] - input_im1[3 - n];
/*     */       }
/* 242 */       DCT3_4_unscaled(x, x);
/* 243 */       X_hybrid[i][7][0] = x[0];
/* 244 */       X_hybrid[i][5][0] = x[2];
/* 245 */       X_hybrid[i][3][0] = x[3];
/* 246 */       X_hybrid[i][1][0] = x[1];
/*     */       
/* 248 */       for (n = 0; n < 4; n++) {
/* 249 */         x[n] = input_re1[n] + input_im1[3 - n];
/*     */       }
/* 251 */       DCT3_4_unscaled(x, x);
/* 252 */       X_hybrid[i][6][0] = x[1];
/* 253 */       X_hybrid[i][4][0] = x[3];
/* 254 */       X_hybrid[i][2][0] = x[2];
/* 255 */       X_hybrid[i][0][0] = x[0];
/*     */       
/* 257 */       input_im2[0] = filter[6] * buffer[6 + i][1];
/* 258 */       input_im2[1] = filter[5] * (buffer[5 + i][1] + buffer[7 + i][1]);
/* 259 */       input_im2[2] = -(filter[0] * (buffer[0 + i][1] + buffer[12 + i][1])) + filter[4] * (buffer[4 + i][1] + buffer[8 + i][1]);
/* 260 */       input_im2[3] = -(filter[1] * (buffer[1 + i][1] + buffer[11 + i][1])) + filter[3] * (buffer[3 + i][1] + buffer[9 + i][1]);
/*     */       
/* 262 */       input_re2[0] = filter[5] * (buffer[7 + i][0] - buffer[5 + i][0]);
/* 263 */       input_re2[1] = filter[0] * (buffer[12 + i][0] - buffer[0 + i][0]) + filter[4] * (buffer[8 + i][0] - buffer[4 + i][0]);
/* 264 */       input_re2[2] = filter[1] * (buffer[11 + i][0] - buffer[1 + i][0]) + filter[3] * (buffer[9 + i][0] - buffer[3 + i][0]);
/* 265 */       input_re2[3] = filter[2] * (buffer[10 + i][0] - buffer[2 + i][0]);
/*     */       
/* 267 */       for (n = 0; n < 4; n++) {
/* 268 */         x[n] = input_im2[n] + input_re2[3 - n];
/*     */       }
/* 270 */       DCT3_4_unscaled(x, x);
/* 271 */       X_hybrid[i][7][1] = x[0];
/* 272 */       X_hybrid[i][5][1] = x[2];
/* 273 */       X_hybrid[i][3][1] = x[3];
/* 274 */       X_hybrid[i][1][1] = x[1];
/*     */       
/* 276 */       for (n = 0; n < 4; n++) {
/* 277 */         x[n] = input_im2[n] - input_re2[3 - n];
/*     */       }
/* 279 */       DCT3_4_unscaled(x, x);
/* 280 */       X_hybrid[i][6][1] = x[1];
/* 281 */       X_hybrid[i][4][1] = x[3];
/* 282 */       X_hybrid[i][2][1] = x[2];
/* 283 */       X_hybrid[i][0][1] = x[0];
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   void DCT3_6_unscaled(float[] y, float[] x) {
/* 290 */     float f0 = x[3] * 0.70710677F;
/* 291 */     float f1 = x[0] + f0;
/* 292 */     float f2 = x[0] - f0;
/* 293 */     float f3 = (x[1] - x[5]) * 0.70710677F;
/* 294 */     float f4 = x[2] * 0.8660254F + x[4] * 0.5F;
/* 295 */     float f5 = f4 - x[4];
/* 296 */     float f6 = x[1] * 0.9659258F + x[5] * 0.25881904F;
/* 297 */     float f7 = f6 - f3;
/* 298 */     y[0] = f1 + f6 + f4;
/* 299 */     y[1] = f2 + f3 - x[4];
/* 300 */     y[2] = f7 + f2 - f5;
/* 301 */     y[3] = f1 - f7 - f5;
/* 302 */     y[4] = f1 - f3 - x[4];
/* 303 */     y[5] = f2 - f6 + f4;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   void channel_filter12(int frame_len, float[] filter, float[][] buffer, float[][][] X_hybrid) {
/* 310 */     float[] input_re1 = new float[6], input_re2 = new float[6];
/* 311 */     float[] input_im1 = new float[6], input_im2 = new float[6];
/* 312 */     float[] out_re1 = new float[6], out_re2 = new float[6];
/* 313 */     float[] out_im1 = new float[6], out_im2 = new float[6];
/*     */     
/* 315 */     for (int i = 0; i < frame_len; i++) {
/* 316 */       int n; for (n = 0; n < 6; n++) {
/* 317 */         if (n == 0) {
/* 318 */           input_re1[0] = buffer[6 + i][0] * filter[6];
/* 319 */           input_re2[0] = buffer[6 + i][1] * filter[6];
/*     */         } else {
/*     */           
/* 322 */           input_re1[6 - n] = (buffer[n + i][0] + buffer[12 - n + i][0]) * filter[n];
/* 323 */           input_re2[6 - n] = (buffer[n + i][1] + buffer[12 - n + i][1]) * filter[n];
/*     */         } 
/* 325 */         input_im2[n] = (buffer[n + i][0] - buffer[12 - n + i][0]) * filter[n];
/* 326 */         input_im1[n] = (buffer[n + i][1] - buffer[12 - n + i][1]) * filter[n];
/*     */       } 
/*     */       
/* 329 */       DCT3_6_unscaled(out_re1, input_re1);
/* 330 */       DCT3_6_unscaled(out_re2, input_re2);
/*     */       
/* 332 */       DCT3_6_unscaled(out_im1, input_im1);
/* 333 */       DCT3_6_unscaled(out_im2, input_im2);
/*     */       
/* 335 */       for (n = 0; n < 6; n += 2) {
/* 336 */         X_hybrid[i][n][0] = out_re1[n] - out_im1[n];
/* 337 */         X_hybrid[i][n][1] = out_re2[n] + out_im2[n];
/* 338 */         X_hybrid[i][n + 1][0] = out_re1[n + 1] + out_im1[n + 1];
/* 339 */         X_hybrid[i][n + 1][1] = out_re2[n + 1] - out_im2[n + 1];
/*     */         
/* 341 */         X_hybrid[i][10 - n][0] = out_re1[n + 1] - out_im1[n + 1];
/* 342 */         X_hybrid[i][10 - n][1] = out_re2[n + 1] + out_im2[n + 1];
/* 343 */         X_hybrid[i][11 - n][0] = out_re1[n] + out_im1[n];
/* 344 */         X_hybrid[i][11 - n][1] = out_re2[n] - out_im2[n];
/*     */       } 
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   void hybrid_synthesis(float[][][] X, float[][][] X_hybrid, boolean use34, int numTimeSlotsRate) {
/* 352 */     int offset = 0;
/* 353 */     int qmf_bands = use34 ? 5 : 3;
/* 354 */     int[] resolution = use34 ? this.resolution34 : this.resolution20;
/*     */     
/* 356 */     for (int band = 0; band < qmf_bands; band++) {
/* 357 */       for (int n = 0; n < this.frame_len; n++) {
/* 358 */         X[n][band][0] = 0.0F;
/* 359 */         X[n][band][1] = 0.0F;
/*     */         
/* 361 */         for (int k = 0; k < resolution[band]; k++) {
/* 362 */           X[n][band][0] = X[n][band][0] + X_hybrid[n][offset + k][0];
/* 363 */           X[n][band][1] = X[n][band][1] + X_hybrid[n][offset + k][1];
/*     */         } 
/*     */       } 
/* 366 */       offset += resolution[band];
/*     */     } 
/*     */   }
/*     */ }


/* Location:              C:\Users\rapha\Downloads\aurora.jar!\META-INF\jars\jcodec-0.2.5.jar!\net\sourceforge\jaad\aac\ps\PSFilterbank.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */