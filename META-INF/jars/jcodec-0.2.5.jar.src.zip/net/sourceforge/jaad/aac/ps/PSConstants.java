package net.sourceforge.jaad.aac.ps;

interface PSConstants {
  public static final int MAX_PS_ENVELOPES = 5;
  
  public static final int NO_ALLPASS_LINKS = 3;
  
  public static final int NEGATE_IPD_MASK = 4096;
  
  public static final float DECAY_SLOPE = 0.05F;
  
  public static final float COEF_SQRT2 = 1.4142135F;
}


/* Location:              C:\Users\rapha\Downloads\aurora.jar!\META-INF\jars\jcodec-0.2.5.jar!\net\sourceforge\jaad\aac\ps\PSConstants.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */