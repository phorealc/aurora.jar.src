/*      */ package net.sourceforge.jaad.aac.ps;
/*      */ 
/*      */ import net.sourceforge.jaad.aac.AACException;
/*      */ import net.sourceforge.jaad.aac.SampleFrequency;
/*      */ import net.sourceforge.jaad.aac.syntax.IBitStream;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ public class PS
/*      */   implements PSConstants, PSTables, PSHuffmanTables
/*      */ {
/*      */   boolean enable_iid;
/*      */   boolean enable_icc;
/*      */   boolean enable_ext;
/*      */   int iid_mode;
/*      */   int icc_mode;
/*      */   int nr_iid_par;
/*      */   int nr_ipdopd_par;
/*      */   int nr_icc_par;
/*      */   int frame_class;
/*      */   int num_env;
/*      */   int[] border_position;
/*      */   boolean[] iid_dt;
/*      */   boolean[] icc_dt;
/*      */   boolean enable_ipdopd;
/*      */   int ipd_mode;
/*      */   boolean[] ipd_dt;
/*      */   boolean[] opd_dt;
/*      */   int[] iid_index_prev;
/*      */   int[] icc_index_prev;
/*      */   int[] ipd_index_prev;
/*      */   int[] opd_index_prev;
/*      */   int[][] iid_index;
/*      */   int[][] icc_index;
/*      */   int[][] ipd_index;
/*      */   int[][] opd_index;
/*      */   int[] ipd_index_1;
/*      */   int[] opd_index_1;
/*      */   int[] ipd_index_2;
/*      */   int[] opd_index_2;
/*      */   int ps_data_available;
/*      */   public boolean header_read;
/*      */   PSFilterbank hyb;
/*      */   boolean use34hybrid_bands;
/*      */   int numTimeSlotsRate;
/*      */   int num_groups;
/*      */   int num_hybrid_groups;
/*      */   int nr_par_bands;
/*      */   int nr_allpass_bands;
/*      */   int decay_cutoff;
/*      */   int[] group_border;
/*      */   int[] map_group2bk;
/*      */   int saved_delay;
/*      */   int[] delay_buf_index_ser;
/*      */   int[] num_sample_delay_ser;
/*      */   int[] delay_D;
/*      */   int[] delay_buf_index_delay;
/*      */   float[][][] delay_Qmf;
/*      */   float[][][] delay_SubQmf;
/*      */   float[][][][] delay_Qmf_ser;
/*      */   float[][][][] delay_SubQmf_ser;
/*      */   float alpha_decay;
/*      */   float alpha_smooth;
/*      */   float[] P_PeakDecayNrg;
/*      */   float[] P_prev;
/*      */   float[] P_SmoothPeakDecayDiffNrg_prev;
/*      */   float[][] h11_prev;
/*      */   float[][] h12_prev;
/*      */   float[][] h21_prev;
/*      */   float[][] h22_prev;
/*      */   int phase_hist;
/*      */   float[][][] ipd_prev;
/*      */   float[][][] opd_prev;
/*      */   
/*      */   public PS(SampleFrequency sr, int numTimeSlotsRate) {
/*   92 */     this.border_position = new int[6];
/*   93 */     this.iid_dt = new boolean[5];
/*   94 */     this.icc_dt = new boolean[5];
/*   95 */     this.ipd_dt = new boolean[5];
/*   96 */     this.opd_dt = new boolean[5];
/*   97 */     this.iid_index_prev = new int[34];
/*   98 */     this.icc_index_prev = new int[34];
/*   99 */     this.ipd_index_prev = new int[17];
/*  100 */     this.opd_index_prev = new int[17];
/*  101 */     this.iid_index = new int[5][34];
/*  102 */     this.icc_index = new int[5][34];
/*  103 */     this.ipd_index = new int[5][17];
/*  104 */     this.opd_index = new int[5][17];
/*  105 */     this.ipd_index_1 = new int[17];
/*  106 */     this.opd_index_1 = new int[17];
/*  107 */     this.ipd_index_2 = new int[17];
/*  108 */     this.opd_index_2 = new int[17];
/*  109 */     this.delay_buf_index_ser = new int[3];
/*  110 */     this.num_sample_delay_ser = new int[3];
/*  111 */     this.delay_D = new int[64];
/*  112 */     this.delay_buf_index_delay = new int[64];
/*  113 */     this.delay_Qmf = new float[14][64][2];
/*  114 */     this.delay_SubQmf = new float[2][32][2];
/*  115 */     this.delay_Qmf_ser = new float[3][5][64][2];
/*  116 */     this.delay_SubQmf_ser = new float[3][5][32][2];
/*  117 */     this.P_PeakDecayNrg = new float[34];
/*  118 */     this.P_prev = new float[34];
/*  119 */     this.P_SmoothPeakDecayDiffNrg_prev = new float[34];
/*  120 */     this.h11_prev = new float[50][2];
/*  121 */     this.h12_prev = new float[50][2];
/*  122 */     this.h21_prev = new float[50][2];
/*  123 */     this.h22_prev = new float[50][2];
/*  124 */     this.ipd_prev = new float[20][2][2];
/*  125 */     this.opd_prev = new float[20][2][2];
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  130 */     this.hyb = new PSFilterbank(numTimeSlotsRate);
/*  131 */     this.numTimeSlotsRate = numTimeSlotsRate;
/*      */     
/*  133 */     this.ps_data_available = 0;
/*      */ 
/*      */     
/*  136 */     this.saved_delay = 0;
/*      */     int i;
/*  138 */     for (i = 0; i < 64; i++) {
/*  139 */       this.delay_buf_index_delay[i] = 0;
/*      */     }
/*      */     
/*  142 */     for (i = 0; i < 3; i++) {
/*  143 */       this.delay_buf_index_ser[i] = 0;
/*      */       
/*  145 */       this.num_sample_delay_ser[i] = delay_length_d[i];
/*      */     } 
/*      */ 
/*      */     
/*  149 */     int short_delay_band = 35;
/*  150 */     this.nr_allpass_bands = 22;
/*  151 */     this.alpha_decay = 0.7659283F;
/*  152 */     this.alpha_smooth = 0.25F;
/*      */ 
/*      */     
/*  155 */     for (i = 0; i < short_delay_band; i++) {
/*  156 */       this.delay_D[i] = 14;
/*      */     }
/*  158 */     for (i = short_delay_band; i < 64; i++) {
/*  159 */       this.delay_D[i] = 1;
/*      */     }
/*      */ 
/*      */     
/*  163 */     for (i = 0; i < 50; i++) {
/*  164 */       this.h11_prev[i][0] = 1.0F;
/*  165 */       this.h12_prev[i][1] = 1.0F;
/*  166 */       this.h11_prev[i][0] = 1.0F;
/*  167 */       this.h12_prev[i][1] = 1.0F;
/*      */     } 
/*      */     
/*  170 */     this.phase_hist = 0;
/*      */     
/*  172 */     for (i = 0; i < 20; i++) {
/*  173 */       this.ipd_prev[i][0][0] = 0.0F;
/*  174 */       this.ipd_prev[i][0][1] = 0.0F;
/*  175 */       this.ipd_prev[i][1][0] = 0.0F;
/*  176 */       this.ipd_prev[i][1][1] = 0.0F;
/*  177 */       this.opd_prev[i][0][0] = 0.0F;
/*  178 */       this.opd_prev[i][0][1] = 0.0F;
/*  179 */       this.opd_prev[i][1][0] = 0.0F;
/*  180 */       this.opd_prev[i][1][1] = 0.0F;
/*      */     } 
/*      */   }
/*      */ 
/*      */   
/*      */   public int decode(IBitStream ld) throws AACException {
/*  186 */     long bits = ld.getPosition();
/*      */ 
/*      */     
/*  189 */     if (ld.readBool()) {
/*  190 */       this.header_read = true;
/*      */       
/*  192 */       this.use34hybrid_bands = false;
/*      */ 
/*      */       
/*  195 */       this.enable_iid = ld.readBool();
/*      */       
/*  197 */       if (this.enable_iid) {
/*  198 */         this.iid_mode = ld.readBits(3);
/*      */         
/*  200 */         this.nr_iid_par = nr_iid_par_tab[this.iid_mode];
/*  201 */         this.nr_ipdopd_par = nr_ipdopd_par_tab[this.iid_mode];
/*      */         
/*  203 */         if (this.iid_mode == 2 || this.iid_mode == 5) {
/*  204 */           this.use34hybrid_bands = true;
/*      */         }
/*      */         
/*  207 */         this.ipd_mode = this.iid_mode;
/*      */       } 
/*      */ 
/*      */       
/*  211 */       this.enable_icc = ld.readBool();
/*      */       
/*  213 */       if (this.enable_icc) {
/*  214 */         this.icc_mode = ld.readBits(3);
/*      */         
/*  216 */         this.nr_icc_par = nr_icc_par_tab[this.icc_mode];
/*      */         
/*  218 */         if (this.icc_mode == 2 || this.icc_mode == 5) {
/*  219 */           this.use34hybrid_bands = true;
/*      */         }
/*      */       } 
/*      */       
/*  223 */       this.enable_ext = ld.readBool();
/*      */     } 
/*      */ 
/*      */     
/*  227 */     if (!this.header_read) {
/*  228 */       this.ps_data_available = 0;
/*  229 */       return 1;
/*      */     } 
/*      */     
/*  232 */     this.frame_class = ld.readBit();
/*  233 */     int tmp = ld.readBits(2);
/*      */     
/*  235 */     this.num_env = num_env_tab[this.frame_class][tmp];
/*      */     
/*  237 */     if (this.frame_class != 0) {
/*  238 */       for (int n = 1; n < this.num_env + 1; n++) {
/*  239 */         this.border_position[n] = ld.readBits(5) + 1;
/*      */       }
/*      */     }
/*      */     
/*  243 */     if (this.enable_iid) {
/*  244 */       for (int n = 0; n < this.num_env; n++) {
/*  245 */         this.iid_dt[n] = ld.readBool();
/*      */ 
/*      */         
/*  248 */         if (this.iid_mode < 3) {
/*  249 */           huff_data(ld, this.iid_dt[n], this.nr_iid_par, t_huff_iid_def, f_huff_iid_def, this.iid_index[n]);
/*      */         }
/*      */         else {
/*      */           
/*  253 */           huff_data(ld, this.iid_dt[n], this.nr_iid_par, t_huff_iid_fine, f_huff_iid_fine, this.iid_index[n]);
/*      */         } 
/*      */       } 
/*      */     }
/*      */ 
/*      */     
/*  259 */     if (this.enable_icc) {
/*  260 */       for (int n = 0; n < this.num_env; n++) {
/*  261 */         this.icc_dt[n] = ld.readBool();
/*      */ 
/*      */         
/*  264 */         huff_data(ld, this.icc_dt[n], this.nr_icc_par, t_huff_icc, f_huff_icc, this.icc_index[n]);
/*      */       } 
/*      */     }
/*      */ 
/*      */     
/*  269 */     if (this.enable_ext) {
/*      */       
/*  271 */       int cnt = ld.readBits(4);
/*  272 */       if (cnt == 15) {
/*  273 */         cnt += ld.readBits(8);
/*      */       }
/*      */       
/*  276 */       int num_bits_left = 8 * cnt;
/*  277 */       while (num_bits_left > 7) {
/*  278 */         int ps_extension_id = ld.readBits(2);
/*      */         
/*  280 */         num_bits_left -= 2;
/*  281 */         num_bits_left -= ps_extension(ld, ps_extension_id, num_bits_left);
/*      */       } 
/*      */       
/*  284 */       ld.skipBits(num_bits_left);
/*      */     } 
/*      */     
/*  287 */     int bits2 = (int)(ld.getPosition() - bits);
/*      */     
/*  289 */     this.ps_data_available = 1;
/*      */     
/*  291 */     return bits2;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private int ps_extension(IBitStream ld, int ps_extension_id, int num_bits_left) throws AACException {
/*  298 */     long bits = ld.getPosition();
/*      */     
/*  300 */     if (ps_extension_id == 0) {
/*  301 */       this.enable_ipdopd = ld.readBool();
/*      */       
/*  303 */       if (this.enable_ipdopd) {
/*  304 */         for (int n = 0; n < this.num_env; n++) {
/*  305 */           this.ipd_dt[n] = ld.readBool();
/*      */ 
/*      */           
/*  308 */           huff_data(ld, this.ipd_dt[n], this.nr_ipdopd_par, t_huff_ipd, f_huff_ipd, this.ipd_index[n]);
/*      */ 
/*      */           
/*  311 */           this.opd_dt[n] = ld.readBool();
/*      */ 
/*      */           
/*  314 */           huff_data(ld, this.opd_dt[n], this.nr_ipdopd_par, t_huff_opd, f_huff_opd, this.opd_index[n]);
/*      */         } 
/*      */       }
/*      */       
/*  318 */       ld.readBit();
/*      */     } 
/*      */ 
/*      */     
/*  322 */     int bits2 = (int)(ld.getPosition() - bits);
/*      */     
/*  324 */     return bits2;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private void huff_data(IBitStream ld, boolean dt, int nr_par, int[][] t_huff, int[][] f_huff, int[] par) throws AACException {
/*  332 */     if (dt) {
/*      */       
/*  334 */       for (int n = 0; n < nr_par; n++) {
/*  335 */         par[n] = ps_huff_dec(ld, t_huff);
/*      */       }
/*      */     }
/*      */     else {
/*      */       
/*  340 */       par[0] = ps_huff_dec(ld, f_huff);
/*      */       
/*  342 */       for (int n = 1; n < nr_par; n++) {
/*  343 */         par[n] = ps_huff_dec(ld, f_huff);
/*      */       }
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   private int ps_huff_dec(IBitStream ld, int[][] t_huff) throws AACException {
/*  351 */     int index = 0;
/*      */     
/*  353 */     while (index >= 0) {
/*  354 */       int bit = ld.readBit();
/*  355 */       index = t_huff[index][bit];
/*      */     } 
/*      */     
/*  358 */     return index + 31;
/*      */   }
/*      */ 
/*      */   
/*      */   private int delta_clip(int i, int min, int max) {
/*  363 */     if (i < min) return min; 
/*  364 */     if (i > max) return max; 
/*  365 */     return i;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private void delta_decode(boolean enable, int[] index, int[] index_prev, boolean dt_flag, int nr_par, int stride, int min_index, int max_index) {
/*  375 */     if (enable) {
/*  376 */       if (!dt_flag) {
/*      */         
/*  378 */         index[0] = 0 + index[0];
/*  379 */         index[0] = delta_clip(index[0], min_index, max_index);
/*      */         
/*  381 */         for (int i = 1; i < nr_par; i++) {
/*  382 */           index[i] = index[i - 1] + index[i];
/*  383 */           index[i] = delta_clip(index[i], min_index, max_index);
/*      */         }
/*      */       
/*      */       } else {
/*      */         
/*  388 */         for (int i = 0; i < nr_par; i++)
/*      */         {
/*      */ 
/*      */ 
/*      */ 
/*      */           
/*  394 */           index[i] = index_prev[i * stride] + index[i];
/*      */           
/*  396 */           index[i] = delta_clip(index[i], min_index, max_index);
/*      */ 
/*      */         
/*      */         }
/*      */ 
/*      */ 
/*      */       
/*      */       }
/*      */ 
/*      */     
/*      */     }
/*      */     else {
/*      */ 
/*      */       
/*  410 */       for (int i = 0; i < nr_par; i++) {
/*  411 */         index[i] = 0;
/*      */       }
/*      */     } 
/*      */ 
/*      */     
/*  416 */     if (stride == 2) {
/*  417 */       for (int i = (nr_par << 1) - 1; i > 0; i--) {
/*  418 */         index[i] = index[i >> 1];
/*      */       }
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private void delta_modulo_decode(boolean enable, int[] index, int[] index_prev, boolean dt_flag, int nr_par, int stride, int and_modulo) {
/*  430 */     if (enable) {
/*  431 */       if (!dt_flag) {
/*      */         
/*  433 */         index[0] = 0 + index[0];
/*  434 */         index[0] = index[0] & and_modulo;
/*      */         
/*  436 */         for (int i = 1; i < nr_par; i++) {
/*  437 */           index[i] = index[i - 1] + index[i];
/*  438 */           index[i] = index[i] & and_modulo;
/*      */         }
/*      */       
/*      */       } else {
/*      */         
/*  443 */         for (int i = 0; i < nr_par; i++) {
/*  444 */           index[i] = index_prev[i * stride] + index[i];
/*  445 */           index[i] = index[i] & and_modulo;
/*      */         }
/*      */       
/*      */       } 
/*      */     } else {
/*      */       
/*  451 */       for (int i = 0; i < nr_par; i++) {
/*  452 */         index[i] = 0;
/*      */       }
/*      */     } 
/*      */ 
/*      */     
/*  457 */     if (stride == 2) {
/*  458 */       index[0] = 0;
/*  459 */       for (int i = (nr_par << 1) - 1; i > 0; i--) {
/*  460 */         index[i] = index[i >> 1];
/*      */       }
/*      */     } 
/*      */   }
/*      */ 
/*      */   
/*      */   private void map20indexto34(int[] index, int bins) {
/*  467 */     index[1] = (index[0] + index[1]) / 2;
/*  468 */     index[2] = index[1];
/*  469 */     index[3] = index[2];
/*  470 */     index[4] = (index[2] + index[3]) / 2;
/*  471 */     index[5] = index[3];
/*  472 */     index[6] = index[4];
/*  473 */     index[7] = index[4];
/*  474 */     index[8] = index[5];
/*  475 */     index[9] = index[5];
/*  476 */     index[10] = index[6];
/*  477 */     index[11] = index[7];
/*  478 */     index[12] = index[8];
/*  479 */     index[13] = index[8];
/*  480 */     index[14] = index[9];
/*  481 */     index[15] = index[9];
/*  482 */     index[16] = index[10];
/*      */     
/*  484 */     if (bins == 34) {
/*  485 */       index[17] = index[11];
/*  486 */       index[18] = index[12];
/*  487 */       index[19] = index[13];
/*  488 */       index[20] = index[14];
/*  489 */       index[21] = index[14];
/*  490 */       index[22] = index[15];
/*  491 */       index[23] = index[15];
/*  492 */       index[24] = index[16];
/*  493 */       index[25] = index[16];
/*  494 */       index[26] = index[17];
/*  495 */       index[27] = index[17];
/*  496 */       index[28] = index[18];
/*  497 */       index[29] = index[18];
/*  498 */       index[30] = index[18];
/*  499 */       index[31] = index[18];
/*  500 */       index[32] = index[19];
/*  501 */       index[33] = index[19];
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private void ps_data_decode() {
/*  510 */     if (this.ps_data_available == 0) {
/*  511 */       this.num_env = 0;
/*      */     }
/*      */     int env;
/*  514 */     for (env = 0; env < this.num_env; env++) {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*  520 */       int iid_index_prev[], icc_index_prev[], ipd_index_prev[], opd_index_prev[], num_iid_steps = (this.iid_mode < 3) ? 7 : 15;
/*      */       
/*  522 */       if (env == 0) {
/*      */         
/*  524 */         iid_index_prev = this.iid_index_prev;
/*  525 */         icc_index_prev = this.icc_index_prev;
/*  526 */         ipd_index_prev = this.ipd_index_prev;
/*  527 */         opd_index_prev = this.opd_index_prev;
/*      */       }
/*      */       else {
/*      */         
/*  531 */         iid_index_prev = this.iid_index[env - 1];
/*  532 */         icc_index_prev = this.icc_index[env - 1];
/*  533 */         ipd_index_prev = this.ipd_index[env - 1];
/*  534 */         opd_index_prev = this.opd_index[env - 1];
/*      */       } 
/*      */ 
/*      */ 
/*      */       
/*  539 */       delta_decode(this.enable_iid, this.iid_index[env], iid_index_prev, this.iid_dt[env], this.nr_iid_par, (this.iid_mode == 0 || this.iid_mode == 3) ? 2 : 1, -num_iid_steps, num_iid_steps);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*  546 */       delta_decode(this.enable_icc, this.icc_index[env], icc_index_prev, this.icc_dt[env], this.nr_icc_par, (this.icc_mode == 0 || this.icc_mode == 3) ? 2 : 1, 0, 7);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*  552 */       delta_modulo_decode(this.enable_ipdopd, this.ipd_index[env], ipd_index_prev, this.ipd_dt[env], this.nr_ipdopd_par, 1, 7);
/*      */ 
/*      */ 
/*      */       
/*  556 */       delta_modulo_decode(this.enable_ipdopd, this.opd_index[env], opd_index_prev, this.opd_dt[env], this.nr_ipdopd_par, 1, 7);
/*      */     } 
/*      */ 
/*      */ 
/*      */     
/*  561 */     if (this.num_env == 0) {
/*      */       
/*  563 */       this.num_env = 1;
/*      */       
/*  565 */       if (this.enable_iid) {
/*  566 */         for (int i = 0; i < 34; i++) {
/*  567 */           this.iid_index[0][i] = this.iid_index_prev[i];
/*      */         }
/*      */       } else {
/*      */         
/*  571 */         for (int i = 0; i < 34; i++) {
/*  572 */           this.iid_index[0][i] = 0;
/*      */         }
/*      */       } 
/*      */       
/*  576 */       if (this.enable_icc) {
/*  577 */         for (byte b = 0; b < 34; b++) {
/*  578 */           this.icc_index[0][b] = this.icc_index_prev[b];
/*      */         }
/*      */       } else {
/*      */         
/*  582 */         for (byte b = 0; b < 34; b++) {
/*  583 */           this.icc_index[0][b] = 0;
/*      */         }
/*      */       } 
/*      */       
/*  587 */       if (this.enable_ipdopd) {
/*  588 */         for (byte b = 0; b < 17; b++) {
/*  589 */           this.ipd_index[0][b] = this.ipd_index_prev[b];
/*  590 */           this.opd_index[0][b] = this.opd_index_prev[b];
/*      */         } 
/*      */       } else {
/*      */         
/*  594 */         for (byte b = 0; b < 17; b++) {
/*  595 */           this.ipd_index[0][b] = 0;
/*  596 */           this.opd_index[0][b] = 0;
/*      */         } 
/*      */       } 
/*      */     } 
/*      */     
/*      */     int bin;
/*  602 */     for (bin = 0; bin < 34; bin++) {
/*  603 */       this.iid_index_prev[bin] = this.iid_index[this.num_env - 1][bin];
/*      */     }
/*  605 */     for (bin = 0; bin < 34; bin++) {
/*  606 */       this.icc_index_prev[bin] = this.icc_index[this.num_env - 1][bin];
/*      */     }
/*  608 */     for (bin = 0; bin < 17; bin++) {
/*  609 */       this.ipd_index_prev[bin] = this.ipd_index[this.num_env - 1][bin];
/*  610 */       this.opd_index_prev[bin] = this.opd_index[this.num_env - 1][bin];
/*      */     } 
/*      */     
/*  613 */     this.ps_data_available = 0;
/*      */     
/*  615 */     if (this.frame_class == 0) {
/*  616 */       this.border_position[0] = 0;
/*  617 */       for (env = 1; env < this.num_env; env++) {
/*  618 */         this.border_position[env] = env * this.numTimeSlotsRate / this.num_env;
/*      */       }
/*  620 */       this.border_position[this.num_env] = this.numTimeSlotsRate;
/*      */     } else {
/*      */       
/*  623 */       this.border_position[0] = 0;
/*      */       
/*  625 */       if (this.border_position[this.num_env] < this.numTimeSlotsRate) {
/*  626 */         for (bin = 0; bin < 34; bin++) {
/*  627 */           this.iid_index[this.num_env][bin] = this.iid_index[this.num_env - 1][bin];
/*  628 */           this.icc_index[this.num_env][bin] = this.icc_index[this.num_env - 1][bin];
/*      */         } 
/*  630 */         for (bin = 0; bin < 17; bin++) {
/*  631 */           this.ipd_index[this.num_env][bin] = this.ipd_index[this.num_env - 1][bin];
/*  632 */           this.opd_index[this.num_env][bin] = this.opd_index[this.num_env - 1][bin];
/*      */         } 
/*  634 */         this.num_env++;
/*  635 */         this.border_position[this.num_env] = this.numTimeSlotsRate;
/*      */       } 
/*      */       
/*  638 */       for (env = 1; env < this.num_env; env++) {
/*  639 */         int thr = this.numTimeSlotsRate - this.num_env - env;
/*      */         
/*  641 */         if (this.border_position[env] > thr) {
/*  642 */           this.border_position[env] = thr;
/*      */         } else {
/*      */           
/*  645 */           thr = this.border_position[env - 1] + 1;
/*  646 */           if (this.border_position[env] < thr) {
/*  647 */             this.border_position[env] = thr;
/*      */           }
/*      */         } 
/*      */       } 
/*      */     } 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  656 */     if (this.use34hybrid_bands) {
/*  657 */       for (env = 0; env < this.num_env; env++) {
/*  658 */         if (this.iid_mode != 2 && this.iid_mode != 5)
/*  659 */           map20indexto34(this.iid_index[env], 34); 
/*  660 */         if (this.icc_mode != 2 && this.icc_mode != 5)
/*  661 */           map20indexto34(this.icc_index[env], 34); 
/*  662 */         if (this.ipd_mode != 2 && this.ipd_mode != 5) {
/*  663 */           map20indexto34(this.ipd_index[env], 17);
/*  664 */           map20indexto34(this.opd_index[env], 17);
/*      */         } 
/*      */       } 
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   private void ps_decorrelate(float[][][] X_left, float[][][] X_right, float[][][] X_hybrid_left, float[][][] X_hybrid_right) {
/*      */     float[][] Phi_Fract_SubQmf;
/*  674 */     int temp_delay = 0;
/*      */     
/*  676 */     int[] temp_delay_ser = new int[3];
/*      */     
/*  678 */     float[][] P = new float[32][34];
/*  679 */     float[][] G_TransientRatio = new float[32][34];
/*  680 */     float[] inputLeft = new float[2];
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  685 */     if (this.use34hybrid_bands) {
/*  686 */       Phi_Fract_SubQmf = Phi_Fract_SubQmf34;
/*      */     } else {
/*      */       
/*  689 */       Phi_Fract_SubQmf = Phi_Fract_SubQmf20;
/*      */     } 
/*      */     
/*      */     int n;
/*  693 */     for (n = 0; n < 32; n++) {
/*  694 */       for (int i = 0; i < 34; i++) {
/*  695 */         P[n][i] = 0.0F;
/*      */       }
/*      */     } 
/*      */     
/*      */     int gr;
/*  700 */     for (gr = 0; gr < this.num_groups; gr++) {
/*      */       
/*  702 */       int i = 0xFFFFEFFF & this.map_group2bk[gr];
/*      */ 
/*      */       
/*  705 */       int maxsb = (gr < this.num_hybrid_groups) ? (this.group_border[gr] + 1) : this.group_border[gr + 1];
/*      */       
/*  707 */       for (int sb = this.group_border[gr]; sb < maxsb; sb++) {
/*  708 */         for (n = this.border_position[0]; n < this.border_position[this.num_env]; n++) {
/*      */ 
/*      */           
/*  711 */           if (gr < this.num_hybrid_groups) {
/*  712 */             inputLeft[0] = X_hybrid_left[n][sb][0];
/*  713 */             inputLeft[1] = X_hybrid_left[n][sb][1];
/*      */           } else {
/*      */             
/*  716 */             inputLeft[0] = X_left[n][sb][0];
/*  717 */             inputLeft[1] = X_left[n][sb][1];
/*      */           } 
/*      */ 
/*      */           
/*  721 */           P[n][i] = P[n][i] + inputLeft[0] * inputLeft[0] + inputLeft[1] * inputLeft[1];
/*      */         } 
/*      */       } 
/*      */     } 
/*      */     
/*      */     int bk;
/*  727 */     for (bk = 0; bk < this.nr_par_bands; bk++) {
/*  728 */       for (n = this.border_position[0]; n < this.border_position[this.num_env]; n++) {
/*  729 */         float gamma = 1.5F;
/*      */         
/*  731 */         this.P_PeakDecayNrg[bk] = this.P_PeakDecayNrg[bk] * this.alpha_decay;
/*  732 */         if (this.P_PeakDecayNrg[bk] < P[n][bk]) {
/*  733 */           this.P_PeakDecayNrg[bk] = P[n][bk];
/*      */         }
/*      */         
/*  736 */         float P_SmoothPeakDecayDiffNrg = this.P_SmoothPeakDecayDiffNrg_prev[bk];
/*  737 */         P_SmoothPeakDecayDiffNrg += (this.P_PeakDecayNrg[bk] - P[n][bk] - this.P_SmoothPeakDecayDiffNrg_prev[bk]) * this.alpha_smooth;
/*  738 */         this.P_SmoothPeakDecayDiffNrg_prev[bk] = P_SmoothPeakDecayDiffNrg;
/*      */ 
/*      */         
/*  741 */         float nrg = this.P_prev[bk];
/*  742 */         nrg += (P[n][bk] - this.P_prev[bk]) * this.alpha_smooth;
/*  743 */         this.P_prev[bk] = nrg;
/*      */ 
/*      */         
/*  746 */         if (P_SmoothPeakDecayDiffNrg * gamma <= nrg) {
/*  747 */           G_TransientRatio[n][bk] = 1.0F;
/*      */         } else {
/*      */           
/*  750 */           G_TransientRatio[n][bk] = nrg / P_SmoothPeakDecayDiffNrg * gamma;
/*      */         } 
/*      */       } 
/*      */     } 
/*      */ 
/*      */     
/*  756 */     for (gr = 0; gr < this.num_groups; gr++) {
/*  757 */       int maxsb; if (gr < this.num_hybrid_groups) {
/*  758 */         maxsb = this.group_border[gr] + 1;
/*      */       } else {
/*  760 */         maxsb = this.group_border[gr + 1];
/*      */       } 
/*      */       
/*  763 */       for (int sb = this.group_border[gr]; sb < maxsb; sb++) {
/*      */         
/*  765 */         float g_DecaySlope, g_DecaySlope_filt[] = new float[3];
/*      */ 
/*      */         
/*  768 */         if (gr < this.num_hybrid_groups || sb <= this.decay_cutoff) {
/*  769 */           g_DecaySlope = 1.0F;
/*      */         } else {
/*      */           
/*  772 */           int decay = this.decay_cutoff - sb;
/*  773 */           if (decay <= -20) {
/*  774 */             g_DecaySlope = 0.0F;
/*      */           }
/*      */           else {
/*      */             
/*  778 */             g_DecaySlope = 1.0F + 0.05F * decay;
/*      */           } 
/*      */         } 
/*      */         
/*      */         int i;
/*  783 */         for (i = 0; i < 3; i++) {
/*  784 */           g_DecaySlope_filt[i] = g_DecaySlope * filter_a[i];
/*      */         }
/*      */ 
/*      */ 
/*      */         
/*  789 */         temp_delay = this.saved_delay;
/*  790 */         for (n = 0; n < 3; n++) {
/*  791 */           temp_delay_ser[n] = this.delay_buf_index_ser[n];
/*      */         }
/*      */         
/*  794 */         for (n = this.border_position[0]; n < this.border_position[this.num_env]; n++) {
/*  795 */           float[] tmp = new float[2], tmp0 = new float[2], R0 = new float[2];
/*      */           
/*  797 */           if (gr < this.num_hybrid_groups) {
/*      */             
/*  799 */             inputLeft[0] = X_hybrid_left[n][sb][0];
/*  800 */             inputLeft[1] = X_hybrid_left[n][sb][1];
/*      */           }
/*      */           else {
/*      */             
/*  804 */             inputLeft[0] = X_left[n][sb][0];
/*  805 */             inputLeft[1] = X_left[n][sb][1];
/*      */           } 
/*      */           
/*  808 */           if (sb > this.nr_allpass_bands && gr >= this.num_hybrid_groups) {
/*      */ 
/*      */ 
/*      */             
/*  812 */             tmp[0] = this.delay_Qmf[this.delay_buf_index_delay[sb]][sb][0];
/*  813 */             tmp[1] = this.delay_Qmf[this.delay_buf_index_delay[sb]][sb][1];
/*  814 */             R0[0] = tmp[0];
/*  815 */             R0[1] = tmp[1];
/*  816 */             this.delay_Qmf[this.delay_buf_index_delay[sb]][sb][0] = inputLeft[0];
/*  817 */             this.delay_Qmf[this.delay_buf_index_delay[sb]][sb][1] = inputLeft[1];
/*      */           
/*      */           }
/*      */           else {
/*      */             
/*  822 */             float[] Phi_Fract = new float[2];
/*      */ 
/*      */             
/*  825 */             if (gr < this.num_hybrid_groups) {
/*      */               
/*  827 */               tmp0[0] = this.delay_SubQmf[temp_delay][sb][0];
/*  828 */               tmp0[1] = this.delay_SubQmf[temp_delay][sb][1];
/*      */               
/*  830 */               this.delay_SubQmf[temp_delay][sb][0] = inputLeft[0];
/*  831 */               this.delay_SubQmf[temp_delay][sb][1] = inputLeft[1];
/*      */               
/*  833 */               Phi_Fract[0] = Phi_Fract_SubQmf[sb][0];
/*  834 */               Phi_Fract[1] = Phi_Fract_SubQmf[sb][1];
/*      */             }
/*      */             else {
/*      */               
/*  838 */               tmp0[0] = this.delay_Qmf[temp_delay][sb][0];
/*  839 */               tmp0[1] = this.delay_Qmf[temp_delay][sb][1];
/*      */               
/*  841 */               this.delay_Qmf[temp_delay][sb][0] = inputLeft[0];
/*  842 */               this.delay_Qmf[temp_delay][sb][1] = inputLeft[1];
/*      */               
/*  844 */               Phi_Fract[0] = Phi_Fract_Qmf[sb][0];
/*  845 */               Phi_Fract[1] = Phi_Fract_Qmf[sb][1];
/*      */             } 
/*      */ 
/*      */             
/*  849 */             tmp[0] = tmp[0] * Phi_Fract[0] + tmp0[1] * Phi_Fract[1];
/*  850 */             tmp[1] = tmp0[1] * Phi_Fract[0] - tmp0[0] * Phi_Fract[1];
/*      */             
/*  852 */             R0[0] = tmp[0];
/*  853 */             R0[1] = tmp[1];
/*  854 */             for (i = 0; i < 3; i++) {
/*  855 */               float[] Q_Fract_allpass = new float[2], tmp2 = new float[2];
/*      */ 
/*      */               
/*  858 */               if (gr < this.num_hybrid_groups) {
/*      */                 
/*  860 */                 tmp0[0] = this.delay_SubQmf_ser[i][temp_delay_ser[i]][sb][0];
/*  861 */                 tmp0[1] = this.delay_SubQmf_ser[i][temp_delay_ser[i]][sb][1];
/*      */                 
/*  863 */                 if (this.use34hybrid_bands) {
/*  864 */                   Q_Fract_allpass[0] = Q_Fract_allpass_SubQmf34[sb][i][0];
/*  865 */                   Q_Fract_allpass[1] = Q_Fract_allpass_SubQmf34[sb][i][1];
/*      */                 } else {
/*      */                   
/*  868 */                   Q_Fract_allpass[0] = Q_Fract_allpass_SubQmf20[sb][i][0];
/*  869 */                   Q_Fract_allpass[1] = Q_Fract_allpass_SubQmf20[sb][i][1];
/*      */                 }
/*      */               
/*      */               } else {
/*      */                 
/*  874 */                 tmp0[0] = this.delay_Qmf_ser[i][temp_delay_ser[i]][sb][0];
/*  875 */                 tmp0[1] = this.delay_Qmf_ser[i][temp_delay_ser[i]][sb][1];
/*      */                 
/*  877 */                 Q_Fract_allpass[0] = Q_Fract_allpass_Qmf[sb][i][0];
/*  878 */                 Q_Fract_allpass[1] = Q_Fract_allpass_Qmf[sb][i][1];
/*      */               } 
/*      */ 
/*      */ 
/*      */               
/*  883 */               tmp[0] = tmp0[0] * Q_Fract_allpass[0] + tmp0[1] * Q_Fract_allpass[1];
/*  884 */               tmp[1] = tmp0[1] * Q_Fract_allpass[0] - tmp0[0] * Q_Fract_allpass[1];
/*      */ 
/*      */               
/*  887 */               tmp[0] = tmp[0] + -(g_DecaySlope_filt[i] * R0[0]);
/*  888 */               tmp[1] = tmp[1] + -(g_DecaySlope_filt[i] * R0[1]);
/*      */ 
/*      */               
/*  891 */               tmp2[0] = R0[0] + g_DecaySlope_filt[i] * tmp[0];
/*  892 */               tmp2[1] = R0[1] + g_DecaySlope_filt[i] * tmp[1];
/*      */ 
/*      */               
/*  895 */               if (gr < this.num_hybrid_groups) {
/*  896 */                 this.delay_SubQmf_ser[i][temp_delay_ser[i]][sb][0] = tmp2[0];
/*  897 */                 this.delay_SubQmf_ser[i][temp_delay_ser[i]][sb][1] = tmp2[1];
/*      */               } else {
/*      */                 
/*  900 */                 this.delay_Qmf_ser[i][temp_delay_ser[i]][sb][0] = tmp2[0];
/*  901 */                 this.delay_Qmf_ser[i][temp_delay_ser[i]][sb][1] = tmp2[1];
/*      */               } 
/*      */ 
/*      */               
/*  905 */               R0[0] = tmp[0];
/*  906 */               R0[1] = tmp[1];
/*      */             } 
/*      */           } 
/*      */ 
/*      */           
/*  911 */           bk = 0xFFFFEFFF & this.map_group2bk[gr];
/*      */ 
/*      */           
/*  914 */           R0[0] = G_TransientRatio[n][bk] * R0[0];
/*  915 */           R0[1] = G_TransientRatio[n][bk] * R0[1];
/*      */           
/*  917 */           if (gr < this.num_hybrid_groups) {
/*      */             
/*  919 */             X_hybrid_right[n][sb][0] = R0[0];
/*  920 */             X_hybrid_right[n][sb][1] = R0[1];
/*      */           }
/*      */           else {
/*      */             
/*  924 */             X_right[n][sb][0] = R0[0];
/*  925 */             X_right[n][sb][1] = R0[1];
/*      */           } 
/*      */ 
/*      */           
/*  929 */           if (++temp_delay >= 2) {
/*  930 */             temp_delay = 0;
/*      */           }
/*      */ 
/*      */           
/*  934 */           if (sb > this.nr_allpass_bands && gr >= this.num_hybrid_groups) {
/*      */             
/*  936 */             this.delay_buf_index_delay[sb] = this.delay_buf_index_delay[sb] + 1; if (this.delay_buf_index_delay[sb] + 1 >= this.delay_D[sb]) {
/*  937 */               this.delay_buf_index_delay[sb] = 0;
/*      */             }
/*      */           } 
/*      */           
/*  941 */           for (i = 0; i < 3; i++) {
/*  942 */             temp_delay_ser[i] = temp_delay_ser[i] + 1; if (temp_delay_ser[i] + 1 >= this.num_sample_delay_ser[i]) {
/*  943 */               temp_delay_ser[i] = 0;
/*      */             }
/*      */           } 
/*      */         } 
/*      */       } 
/*      */     } 
/*      */ 
/*      */     
/*  951 */     this.saved_delay = temp_delay;
/*  952 */     for (int m = 0; m < 3; m++) {
/*  953 */       this.delay_buf_index_ser[m] = temp_delay_ser[m];
/*      */     }
/*      */   }
/*      */   
/*      */   private float magnitude_c(float[] c) {
/*  958 */     return (float)Math.sqrt((c[0] * c[0] + c[1] * c[1]));
/*      */   }
/*      */ 
/*      */   
/*      */   private void ps_mix_phase(float[][][] X_left, float[][][] X_right, float[][][] X_hybrid_left, float[][][] X_hybrid_right) {
/*      */     int nr_ipdopd_par;
/*      */     float[] sf_iid;
/*  965 */     int no_iid_steps, bk = 0;
/*      */ 
/*      */ 
/*      */     
/*  969 */     float[] h11 = new float[2], h12 = new float[2], h21 = new float[2], h22 = new float[2];
/*  970 */     float[] H11 = new float[2], H12 = new float[2], H21 = new float[2], H22 = new float[2];
/*  971 */     float[] deltaH11 = new float[2], deltaH12 = new float[2], deltaH21 = new float[2], deltaH22 = new float[2];
/*  972 */     float[] tempLeft = new float[2];
/*  973 */     float[] tempRight = new float[2];
/*  974 */     float[] phaseLeft = new float[2];
/*  975 */     float[] phaseRight = new float[2];
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  980 */     if (this.iid_mode >= 3) {
/*  981 */       no_iid_steps = 15;
/*  982 */       sf_iid = sf_iid_fine;
/*      */     } else {
/*      */       
/*  985 */       no_iid_steps = 7;
/*  986 */       sf_iid = sf_iid_normal;
/*      */     } 
/*      */     
/*  989 */     if (this.ipd_mode == 0 || this.ipd_mode == 3) {
/*  990 */       nr_ipdopd_par = 11;
/*      */     }
/*      */     else {
/*      */       
/*  994 */       nr_ipdopd_par = this.nr_ipdopd_par;
/*      */     } 
/*      */     
/*  997 */     for (int gr = 0; gr < this.num_groups; gr++) {
/*  998 */       bk = 0xFFFFEFFF & this.map_group2bk[gr];
/*      */ 
/*      */       
/* 1001 */       int maxsb = (gr < this.num_hybrid_groups) ? (this.group_border[gr] + 1) : this.group_border[gr + 1];
/*      */       
/* 1003 */       for (int env = 0; env < this.num_env; env++) {
/* 1004 */         if (this.icc_mode < 3) {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */           
/* 1021 */           float cosb, sinb, c_1 = sf_iid[no_iid_steps + this.iid_index[env][bk]];
/* 1022 */           float c_2 = sf_iid[no_iid_steps - this.iid_index[env][bk]];
/*      */ 
/*      */           
/* 1025 */           float cosa = cos_alphas[this.icc_index[env][bk]];
/* 1026 */           float sina = sin_alphas[this.icc_index[env][bk]];
/*      */           
/* 1028 */           if (this.iid_mode >= 3) {
/* 1029 */             if (this.iid_index[env][bk] < 0) {
/* 1030 */               cosb = cos_betas_fine[-this.iid_index[env][bk]][this.icc_index[env][bk]];
/* 1031 */               sinb = -sin_betas_fine[-this.iid_index[env][bk]][this.icc_index[env][bk]];
/*      */             } else {
/*      */               
/* 1034 */               cosb = cos_betas_fine[this.iid_index[env][bk]][this.icc_index[env][bk]];
/* 1035 */               sinb = sin_betas_fine[this.iid_index[env][bk]][this.icc_index[env][bk]];
/*      */             }
/*      */           
/*      */           }
/* 1039 */           else if (this.iid_index[env][bk] < 0) {
/* 1040 */             cosb = cos_betas_normal[-this.iid_index[env][bk]][this.icc_index[env][bk]];
/* 1041 */             sinb = -sin_betas_normal[-this.iid_index[env][bk]][this.icc_index[env][bk]];
/*      */           } else {
/*      */             
/* 1044 */             cosb = cos_betas_normal[this.iid_index[env][bk]][this.icc_index[env][bk]];
/* 1045 */             sinb = sin_betas_normal[this.iid_index[env][bk]][this.icc_index[env][bk]];
/*      */           } 
/*      */ 
/*      */           
/* 1049 */           float ab1 = cosb * cosa;
/* 1050 */           float ab2 = sinb * sina;
/* 1051 */           float ab3 = sinb * cosa;
/* 1052 */           float ab4 = cosb * sina;
/*      */ 
/*      */           
/* 1055 */           h11[0] = c_2 * (ab1 - ab2);
/* 1056 */           h12[0] = c_1 * (ab1 + ab2);
/* 1057 */           h21[0] = c_2 * (ab3 + ab4);
/* 1058 */           h22[0] = c_1 * (ab3 - ab4);
/*      */         } else {
/*      */           float sina, cosa, cosg, sing;
/*      */ 
/*      */ 
/*      */ 
/*      */           
/* 1065 */           if (this.iid_mode >= 3) {
/* 1066 */             int abs_iid = Math.abs(this.iid_index[env][bk]);
/*      */             
/* 1068 */             cosa = sincos_alphas_B_fine[no_iid_steps + this.iid_index[env][bk]][this.icc_index[env][bk]];
/* 1069 */             sina = sincos_alphas_B_fine[30 - no_iid_steps + this.iid_index[env][bk]][this.icc_index[env][bk]];
/* 1070 */             cosg = cos_gammas_fine[abs_iid][this.icc_index[env][bk]];
/* 1071 */             sing = sin_gammas_fine[abs_iid][this.icc_index[env][bk]];
/*      */           } else {
/*      */             
/* 1074 */             int abs_iid = Math.abs(this.iid_index[env][bk]);
/*      */             
/* 1076 */             cosa = sincos_alphas_B_normal[no_iid_steps + this.iid_index[env][bk]][this.icc_index[env][bk]];
/* 1077 */             sina = sincos_alphas_B_normal[14 - no_iid_steps + this.iid_index[env][bk]][this.icc_index[env][bk]];
/* 1078 */             cosg = cos_gammas_normal[abs_iid][this.icc_index[env][bk]];
/* 1079 */             sing = sin_gammas_normal[abs_iid][this.icc_index[env][bk]];
/*      */           } 
/*      */           
/* 1082 */           h11[0] = 1.4142135F * cosa * cosg;
/* 1083 */           h12[0] = 1.4142135F * sina * cosg;
/* 1084 */           h21[0] = 1.4142135F * -cosa * sing;
/* 1085 */           h22[0] = 1.4142135F * sina * sing;
/*      */         } 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/* 1092 */         if (this.enable_ipdopd && bk < nr_ipdopd_par) {
/*      */ 
/*      */ 
/*      */           
/* 1096 */           int i = this.phase_hist;
/*      */ 
/*      */           
/* 1099 */           tempLeft[0] = this.ipd_prev[bk][i][0] * 0.25F;
/* 1100 */           tempLeft[1] = this.ipd_prev[bk][i][1] * 0.25F;
/* 1101 */           tempRight[0] = this.opd_prev[bk][i][0] * 0.25F;
/* 1102 */           tempRight[1] = this.opd_prev[bk][i][1] * 0.25F;
/*      */ 
/*      */           
/* 1105 */           this.ipd_prev[bk][i][0] = ipdopd_cos_tab[Math.abs(this.ipd_index[env][bk])];
/* 1106 */           this.ipd_prev[bk][i][1] = ipdopd_sin_tab[Math.abs(this.ipd_index[env][bk])];
/* 1107 */           this.opd_prev[bk][i][0] = ipdopd_cos_tab[Math.abs(this.opd_index[env][bk])];
/* 1108 */           this.opd_prev[bk][i][1] = ipdopd_sin_tab[Math.abs(this.opd_index[env][bk])];
/*      */ 
/*      */           
/* 1111 */           tempLeft[0] = tempLeft[0] + this.ipd_prev[bk][i][0];
/* 1112 */           tempLeft[1] = tempLeft[1] + this.ipd_prev[bk][i][1];
/* 1113 */           tempRight[0] = tempRight[0] + this.opd_prev[bk][i][0];
/* 1114 */           tempRight[1] = tempRight[1] + this.opd_prev[bk][i][1];
/*      */ 
/*      */           
/* 1117 */           if (i == 0) {
/* 1118 */             i = 2;
/*      */           }
/* 1120 */           i--;
/*      */ 
/*      */           
/* 1123 */           tempLeft[0] = tempLeft[0] + this.ipd_prev[bk][i][0] * 0.5F;
/* 1124 */           tempLeft[1] = tempLeft[1] + this.ipd_prev[bk][i][1] * 0.5F;
/* 1125 */           tempRight[0] = tempRight[0] + this.opd_prev[bk][i][0] * 0.5F;
/* 1126 */           tempRight[1] = tempRight[1] + this.opd_prev[bk][i][1] * 0.5F;
/*      */           
/* 1128 */           float xy = magnitude_c(tempRight);
/* 1129 */           float pq = magnitude_c(tempLeft);
/*      */           
/* 1131 */           if (xy != 0.0F) {
/* 1132 */             phaseLeft[0] = tempRight[0] / xy;
/* 1133 */             phaseLeft[1] = tempRight[1] / xy;
/*      */           } else {
/*      */             
/* 1136 */             phaseLeft[0] = 0.0F;
/* 1137 */             phaseLeft[1] = 0.0F;
/*      */           } 
/*      */           
/* 1140 */           float xypq = xy * pq;
/*      */           
/* 1142 */           if (xypq != 0.0F) {
/* 1143 */             float tmp1 = tempRight[0] * tempLeft[0] + tempRight[1] * tempLeft[1];
/* 1144 */             float tmp2 = tempRight[1] * tempLeft[0] - tempRight[0] * tempLeft[1];
/*      */             
/* 1146 */             phaseRight[0] = tmp1 / xypq;
/* 1147 */             phaseRight[1] = tmp2 / xypq;
/*      */           } else {
/*      */             
/* 1150 */             phaseRight[0] = 0.0F;
/* 1151 */             phaseRight[1] = 0.0F;
/*      */           } 
/*      */ 
/*      */           
/* 1155 */           h11[1] = h11[0] * phaseLeft[1];
/* 1156 */           h12[1] = h12[0] * phaseRight[1];
/* 1157 */           h21[1] = h21[0] * phaseLeft[1];
/* 1158 */           h22[1] = h22[0] * phaseRight[1];
/*      */           
/* 1160 */           h11[0] = h11[0] * phaseLeft[0];
/* 1161 */           h12[0] = h12[0] * phaseRight[0];
/* 1162 */           h21[0] = h21[0] * phaseLeft[0];
/* 1163 */           h22[0] = h22[0] * phaseRight[0];
/*      */         } 
/*      */ 
/*      */ 
/*      */         
/* 1168 */         float L = (this.border_position[env + 1] - this.border_position[env]);
/*      */ 
/*      */         
/* 1171 */         deltaH11[0] = (h11[0] - this.h11_prev[gr][0]) / L;
/* 1172 */         deltaH12[0] = (h12[0] - this.h12_prev[gr][0]) / L;
/* 1173 */         deltaH21[0] = (h21[0] - this.h21_prev[gr][0]) / L;
/* 1174 */         deltaH22[0] = (h22[0] - this.h22_prev[gr][0]) / L;
/*      */         
/* 1176 */         H11[0] = this.h11_prev[gr][0];
/* 1177 */         H12[0] = this.h12_prev[gr][0];
/* 1178 */         H21[0] = this.h21_prev[gr][0];
/* 1179 */         H22[0] = this.h22_prev[gr][0];
/*      */         
/* 1181 */         this.h11_prev[gr][0] = h11[0];
/* 1182 */         this.h12_prev[gr][0] = h12[0];
/* 1183 */         this.h21_prev[gr][0] = h21[0];
/* 1184 */         this.h22_prev[gr][0] = h22[0];
/*      */ 
/*      */         
/* 1187 */         if (this.enable_ipdopd && bk < nr_ipdopd_par) {
/*      */           
/* 1189 */           deltaH11[1] = (h11[1] - this.h11_prev[gr][1]) / L;
/* 1190 */           deltaH12[1] = (h12[1] - this.h12_prev[gr][1]) / L;
/* 1191 */           deltaH21[1] = (h21[1] - this.h21_prev[gr][1]) / L;
/* 1192 */           deltaH22[1] = (h22[1] - this.h22_prev[gr][1]) / L;
/*      */           
/* 1194 */           H11[1] = this.h11_prev[gr][1];
/* 1195 */           H12[1] = this.h12_prev[gr][1];
/* 1196 */           H21[1] = this.h21_prev[gr][1];
/* 1197 */           H22[1] = this.h22_prev[gr][1];
/*      */           
/* 1199 */           if ((0x1000 & this.map_group2bk[gr]) != 0) {
/* 1200 */             deltaH11[1] = -deltaH11[1];
/* 1201 */             deltaH12[1] = -deltaH12[1];
/* 1202 */             deltaH21[1] = -deltaH21[1];
/* 1203 */             deltaH22[1] = -deltaH22[1];
/*      */             
/* 1205 */             H11[1] = -H11[1];
/* 1206 */             H12[1] = -H12[1];
/* 1207 */             H21[1] = -H21[1];
/* 1208 */             H22[1] = -H22[1];
/*      */           } 
/*      */           
/* 1211 */           this.h11_prev[gr][1] = h11[1];
/* 1212 */           this.h12_prev[gr][1] = h12[1];
/* 1213 */           this.h21_prev[gr][1] = h21[1];
/* 1214 */           this.h22_prev[gr][1] = h22[1];
/*      */         } 
/*      */ 
/*      */         
/* 1218 */         for (int n = this.border_position[env]; n < this.border_position[env + 1]; n++) {
/*      */           
/* 1220 */           H11[0] = H11[0] + deltaH11[0];
/* 1221 */           H12[0] = H12[0] + deltaH12[0];
/* 1222 */           H21[0] = H21[0] + deltaH21[0];
/* 1223 */           H22[0] = H22[0] + deltaH22[0];
/* 1224 */           if (this.enable_ipdopd && bk < nr_ipdopd_par) {
/* 1225 */             H11[1] = H11[1] + deltaH11[1];
/* 1226 */             H12[1] = H12[1] + deltaH12[1];
/* 1227 */             H21[1] = H21[1] + deltaH21[1];
/* 1228 */             H22[1] = H22[1] + deltaH22[1];
/*      */           } 
/*      */ 
/*      */           
/* 1232 */           for (int sb = this.group_border[gr]; sb < maxsb; sb++) {
/* 1233 */             float[] inLeft = new float[2], inRight = new float[2];
/*      */ 
/*      */             
/* 1236 */             if (gr < this.num_hybrid_groups) {
/* 1237 */               inLeft[0] = X_hybrid_left[n][sb][0];
/* 1238 */               inLeft[1] = X_hybrid_left[n][sb][1];
/* 1239 */               inRight[0] = X_hybrid_right[n][sb][0];
/* 1240 */               inRight[1] = X_hybrid_right[n][sb][1];
/*      */             } else {
/*      */               
/* 1243 */               inLeft[0] = X_left[n][sb][0];
/* 1244 */               inLeft[1] = X_left[n][sb][1];
/* 1245 */               inRight[0] = X_right[n][sb][0];
/* 1246 */               inRight[1] = X_right[n][sb][1];
/*      */             } 
/*      */ 
/*      */             
/* 1250 */             tempLeft[0] = H11[0] * inLeft[0] + H21[0] * inRight[0];
/* 1251 */             tempLeft[1] = H11[0] * inLeft[1] + H21[0] * inRight[1];
/* 1252 */             tempRight[0] = H12[0] * inLeft[0] + H22[0] * inRight[0];
/* 1253 */             tempRight[1] = H12[0] * inLeft[1] + H22[0] * inRight[1];
/*      */ 
/*      */             
/* 1256 */             if (this.enable_ipdopd && bk < nr_ipdopd_par) {
/*      */               
/* 1258 */               tempLeft[0] = tempLeft[0] - H11[1] * inLeft[1] + H21[1] * inRight[1];
/* 1259 */               tempLeft[1] = tempLeft[1] + H11[1] * inLeft[0] + H21[1] * inRight[0];
/* 1260 */               tempRight[0] = tempRight[0] - H12[1] * inLeft[1] + H22[1] * inRight[1];
/* 1261 */               tempRight[1] = tempRight[1] + H12[1] * inLeft[0] + H22[1] * inRight[0];
/*      */             } 
/*      */ 
/*      */             
/* 1265 */             if (gr < this.num_hybrid_groups) {
/* 1266 */               X_hybrid_left[n][sb][0] = tempLeft[0];
/* 1267 */               X_hybrid_left[n][sb][1] = tempLeft[1];
/* 1268 */               X_hybrid_right[n][sb][0] = tempRight[0];
/* 1269 */               X_hybrid_right[n][sb][1] = tempRight[1];
/*      */             } else {
/*      */               
/* 1272 */               X_left[n][sb][0] = tempLeft[0];
/* 1273 */               X_left[n][sb][1] = tempLeft[1];
/* 1274 */               X_right[n][sb][0] = tempRight[0];
/* 1275 */               X_right[n][sb][1] = tempRight[1];
/*      */             } 
/*      */           } 
/*      */         } 
/*      */ 
/*      */         
/* 1281 */         this.phase_hist++;
/* 1282 */         if (this.phase_hist == 2) {
/* 1283 */           this.phase_hist = 0;
/*      */         }
/*      */       } 
/*      */     } 
/*      */   }
/*      */ 
/*      */   
/*      */   public int process(float[][][] X_left, float[][][] X_right) {
/* 1291 */     float[][][] X_hybrid_left = new float[32][32][2];
/* 1292 */     float[][][] X_hybrid_right = new float[32][32][2];
/*      */ 
/*      */     
/* 1295 */     ps_data_decode();
/*      */ 
/*      */     
/* 1298 */     if (this.use34hybrid_bands) {
/* 1299 */       this.group_border = group_border34;
/* 1300 */       this.map_group2bk = map_group2bk34;
/* 1301 */       this.num_groups = 50;
/* 1302 */       this.num_hybrid_groups = 32;
/* 1303 */       this.nr_par_bands = 34;
/* 1304 */       this.decay_cutoff = 5;
/*      */     } else {
/*      */       
/* 1307 */       this.group_border = group_border20;
/* 1308 */       this.map_group2bk = map_group2bk20;
/* 1309 */       this.num_groups = 22;
/* 1310 */       this.num_hybrid_groups = 10;
/* 1311 */       this.nr_par_bands = 20;
/* 1312 */       this.decay_cutoff = 3;
/*      */     } 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 1318 */     this.hyb.hybrid_analysis(X_left, X_hybrid_left, this.use34hybrid_bands, this.numTimeSlotsRate);
/*      */ 
/*      */ 
/*      */     
/* 1322 */     ps_decorrelate(X_left, X_right, X_hybrid_left, X_hybrid_right);
/*      */ 
/*      */     
/* 1325 */     ps_mix_phase(X_left, X_right, X_hybrid_left, X_hybrid_right);
/*      */ 
/*      */     
/* 1328 */     this.hyb.hybrid_synthesis(X_left, X_hybrid_left, this.use34hybrid_bands, this.numTimeSlotsRate);
/*      */ 
/*      */     
/* 1331 */     this.hyb.hybrid_synthesis(X_right, X_hybrid_right, this.use34hybrid_bands, this.numTimeSlotsRate);
/*      */ 
/*      */     
/* 1334 */     return 0;
/*      */   }
/*      */ }


/* Location:              C:\Users\rapha\Downloads\aurora.jar!\META-INF\jars\jcodec-0.2.5.jar!\net\sourceforge\jaad\aac\ps\PS.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */