/*     */ package net.sourceforge.jaad.aac;
/*     */ 
/*     */ import net.sourceforge.jaad.aac.filterbank.FilterBank;
/*     */ import net.sourceforge.jaad.aac.syntax.BitStream;
/*     */ import net.sourceforge.jaad.aac.syntax.IBitStream;
/*     */ import net.sourceforge.jaad.aac.syntax.PCE;
/*     */ import net.sourceforge.jaad.aac.syntax.SyntacticElements;
/*     */ import net.sourceforge.jaad.aac.syntax.SyntaxConstants;
/*     */ import net.sourceforge.jaad.aac.transport.ADIFHeader;
/*     */ import org.jcodec.common.logging.Logger;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class Decoder
/*     */   implements SyntaxConstants
/*     */ {
/*     */   private final AACDecoderConfig config;
/*     */   private final SyntacticElements syntacticElements;
/*     */   private final FilterBank filterBank;
/*     */   private IBitStream _in;
/*     */   private ADIFHeader adifHeader;
/*     */   
/*     */   public static boolean canDecode(Profile profile) {
/*  37 */     return profile.isDecodingSupported();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Decoder(byte[] decoderSpecificInfo) throws AACException {
/*  53 */     this.config = AACDecoderConfig.parseMP4DecoderSpecificInfo(decoderSpecificInfo);
/*  54 */     if (this.config == null) {
/*  55 */       throw new IllegalArgumentException("illegal MP4 decoder specific info");
/*     */     }
/*  57 */     if (!canDecode(this.config.getProfile())) {
/*  58 */       throw new AACException("unsupported profile: " + this.config.getProfile().getDescription());
/*     */     }
/*  60 */     this.syntacticElements = new SyntacticElements(this.config);
/*  61 */     this.filterBank = new FilterBank(this.config.isSmallFrameUsed(), this.config.getChannelConfiguration().getChannelCount());
/*     */     
/*  63 */     this._in = (IBitStream)new BitStream();
/*     */     
/*  65 */     Logger.debug("profile: {0}", new Object[] { this.config.getProfile() });
/*  66 */     Logger.debug("sf: {0}", new Object[] { Integer.valueOf(this.config.getSampleFrequency().getFrequency()) });
/*  67 */     Logger.debug("channels: {0}", new Object[] { this.config.getChannelConfiguration().getDescription() });
/*     */   }
/*     */   
/*     */   public AACDecoderConfig getConfig() {
/*  71 */     return this.config;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void decodeFrame(byte[] frame, SampleBuffer buffer) throws AACException {
/*  85 */     if (frame != null)
/*  86 */       this._in.setData(frame); 
/*  87 */     Logger.debug("bits left " + this._in.getBitsLeft());
/*     */     try {
/*  89 */       decode(buffer);
/*  90 */     } catch (AACException e) {
/*  91 */       if (!e.isEndOfStream()) {
/*  92 */         throw e;
/*     */       }
/*  94 */       Logger.warn("unexpected end of frame");
/*     */     } 
/*     */   }
/*     */   
/*     */   private void decode(SampleBuffer buffer) throws AACException {
/*  99 */     if (ADIFHeader.isPresent(this._in)) {
/* 100 */       this.adifHeader = ADIFHeader.readHeader(this._in);
/* 101 */       PCE pce = this.adifHeader.getFirstPCE();
/* 102 */       this.config.setProfile(pce.getProfile());
/* 103 */       this.config.setSampleFrequency(pce.getSampleFrequency());
/* 104 */       this.config.setChannelConfiguration(ChannelConfiguration.forInt(pce.getChannelCount()));
/*     */     } 
/*     */     
/* 107 */     if (!canDecode(this.config.getProfile())) {
/* 108 */       throw new AACException("unsupported profile: " + this.config.getProfile().getDescription());
/*     */     }
/* 110 */     this.syntacticElements.startNewFrame();
/*     */ 
/*     */     
/*     */     try {
/* 114 */       this.syntacticElements.decode(this._in);
/*     */       
/* 116 */       this.syntacticElements.process(this.filterBank);
/*     */       
/* 118 */       this.syntacticElements.sendToOutput(buffer);
/* 119 */     } catch (Exception e) {
/* 120 */       buffer.setData(new byte[0], 0, 0, 0, 0);
/* 121 */       throw AACException.wrap(e);
/*     */     } 
/*     */   }
/*     */ }


/* Location:              C:\Users\rapha\Downloads\aurora.jar!\META-INF\jars\jcodec-0.2.5.jar!\net\sourceforge\jaad\aac\Decoder.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */