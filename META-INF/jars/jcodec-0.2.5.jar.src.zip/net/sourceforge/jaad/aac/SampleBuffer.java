/*     */ package net.sourceforge.jaad.aac;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class SampleBuffer
/*     */ {
/*  20 */   private byte[] data = new byte[0];
/*  21 */   private int sampleRate = 0;
/*  22 */   private int channels = 0;
/*  23 */   private int bitsPerSample = 0;
/*     */   
/*     */   private boolean bigEndian = true;
/*     */   
/*     */   private double length;
/*     */   private double bitrate;
/*     */   private double encodedBitrate;
/*     */   
/*     */   public byte[] getData() {
/*  32 */     return this.data;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int getSampleRate() {
/*  40 */     return this.sampleRate;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int getChannels() {
/*  48 */     return this.channels;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int getBitsPerSample() {
/*  57 */     return this.bitsPerSample;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public double getLength() {
/*  66 */     return this.length;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public double getBitrate() {
/*  75 */     return this.bitrate;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public double getEncodedBitrate() {
/*  83 */     return this.encodedBitrate;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isBigEndian() {
/*  92 */     return this.bigEndian;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setBigEndian(boolean bigEndian) {
/* 102 */     if (bigEndian != this.bigEndian) {
/*     */       
/* 104 */       for (int i = 0; i < this.data.length; i += 2) {
/* 105 */         byte tmp = this.data[i];
/* 106 */         this.data[i] = this.data[i + 1];
/* 107 */         this.data[i + 1] = tmp;
/*     */       } 
/* 109 */       this.bigEndian = bigEndian;
/*     */     } 
/*     */   }
/*     */   
/*     */   public void setData(byte[] data, int sampleRate, int channels, int bitsPerSample, int bitsRead) {
/* 114 */     this.data = data;
/* 115 */     this.sampleRate = sampleRate;
/* 116 */     this.channels = channels;
/* 117 */     this.bitsPerSample = bitsPerSample;
/*     */     
/* 119 */     if (sampleRate == 0) {
/* 120 */       this.length = 0.0D;
/* 121 */       this.bitrate = 0.0D;
/* 122 */       this.encodedBitrate = 0.0D;
/*     */     } else {
/*     */       
/* 125 */       int bytesPerSample = bitsPerSample / 8;
/* 126 */       int samplesPerChannel = data.length / bytesPerSample * channels;
/* 127 */       this.length = samplesPerChannel / sampleRate;
/* 128 */       this.bitrate = (samplesPerChannel * bitsPerSample * channels) / this.length;
/* 129 */       this.encodedBitrate = bitsRead / this.length;
/*     */     } 
/*     */   }
/*     */ }


/* Location:              C:\Users\rapha\Downloads\aurora.jar!\META-INF\jars\jcodec-0.2.5.jar!\net\sourceforge\jaad\aac\SampleBuffer.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */