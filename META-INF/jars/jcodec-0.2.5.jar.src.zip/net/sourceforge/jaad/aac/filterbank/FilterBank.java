/*     */ package net.sourceforge.jaad.aac.filterbank;
/*     */ 
/*     */ import net.sourceforge.jaad.aac.AACException;
/*     */ import net.sourceforge.jaad.aac.syntax.ICSInfo;
/*     */ import net.sourceforge.jaad.aac.syntax.SyntaxConstants;
/*     */ 
/*     */ 
/*     */ 
/*     */ public class FilterBank
/*     */   implements SyntaxConstants, SineWindows, KBDWindows
/*     */ {
/*     */   private final float[][] LONG_WINDOWS;
/*     */   private final float[][] SHORT_WINDOWS;
/*     */   private final int length;
/*     */   private final int shortLen;
/*     */   private final int mid;
/*     */   private final int trans;
/*     */   private final MDCT mdctShort;
/*     */   private final MDCT mdctLong;
/*     */   private final float[] buf;
/*     */   private final float[][] overlaps;
/*     */   
/*     */   public FilterBank(boolean smallFrames, int channels) throws AACException {
/*  24 */     if (smallFrames) {
/*  25 */       this.length = 960;
/*  26 */       this.shortLen = 120;
/*  27 */       this.LONG_WINDOWS = new float[][] { SINE_960, KBD_960 };
/*  28 */       this.SHORT_WINDOWS = new float[][] { SINE_120, KBD_120 };
/*     */     } else {
/*     */       
/*  31 */       this.length = 1024;
/*  32 */       this.shortLen = 128;
/*  33 */       this.LONG_WINDOWS = new float[][] { SINE_1024, KBD_1024 };
/*  34 */       this.SHORT_WINDOWS = new float[][] { SINE_128, KBD_128 };
/*     */     } 
/*  36 */     this.mid = (this.length - this.shortLen) / 2;
/*  37 */     this.trans = this.shortLen / 2;
/*     */     
/*  39 */     this.mdctShort = new MDCT(this.shortLen * 2);
/*  40 */     this.mdctLong = new MDCT(this.length * 2);
/*     */     
/*  42 */     this.overlaps = new float[channels][this.length];
/*  43 */     this.buf = new float[2 * this.length];
/*     */   }
/*     */   
/*     */   public void process(ICSInfo.WindowSequence windowSequence, int windowShape, int windowShapePrev, float[] _in, float[] out, int channel) {
/*     */     int i;
/*  48 */     float[] overlap = this.overlaps[channel];
/*  49 */     switch (windowSequence) {
/*     */       case ONLY_LONG_SEQUENCE:
/*  51 */         this.mdctLong.process(_in, 0, this.buf, 0);
/*     */         
/*  53 */         for (i = 0; i < this.length; i++) {
/*  54 */           out[i] = overlap[i] + this.buf[i] * this.LONG_WINDOWS[windowShapePrev][i];
/*     */         }
/*     */ 
/*     */         
/*  58 */         for (i = 0; i < this.length; i++) {
/*  59 */           overlap[i] = this.buf[this.length + i] * this.LONG_WINDOWS[windowShape][this.length - 1 - i];
/*     */         }
/*     */         break;
/*     */       case LONG_START_SEQUENCE:
/*  63 */         this.mdctLong.process(_in, 0, this.buf, 0);
/*     */         
/*  65 */         for (i = 0; i < this.length; i++) {
/*  66 */           out[i] = overlap[i] + this.buf[i] * this.LONG_WINDOWS[windowShapePrev][i];
/*     */         }
/*     */ 
/*     */         
/*  70 */         for (i = 0; i < this.mid; i++) {
/*  71 */           overlap[i] = this.buf[this.length + i];
/*     */         }
/*  73 */         for (i = 0; i < this.shortLen; i++) {
/*  74 */           overlap[this.mid + i] = this.buf[this.length + this.mid + i] * this.SHORT_WINDOWS[windowShape][this.shortLen - i - 1];
/*     */         }
/*  76 */         for (i = 0; i < this.mid; i++) {
/*  77 */           overlap[this.mid + this.shortLen + i] = 0.0F;
/*     */         }
/*     */         break;
/*     */       case EIGHT_SHORT_SEQUENCE:
/*  81 */         for (i = 0; i < 8; i++) {
/*  82 */           this.mdctShort.process(_in, i * this.shortLen, this.buf, 2 * i * this.shortLen);
/*     */         }
/*     */ 
/*     */         
/*  86 */         for (i = 0; i < this.mid; i++) {
/*  87 */           out[i] = overlap[i];
/*     */         }
/*  89 */         for (i = 0; i < this.shortLen; i++) {
/*  90 */           out[this.mid + i] = overlap[this.mid + i] + this.buf[i] * this.SHORT_WINDOWS[windowShapePrev][i];
/*  91 */           out[this.mid + 1 * this.shortLen + i] = overlap[this.mid + this.shortLen * 1 + i] + this.buf[this.shortLen * 1 + i] * this.SHORT_WINDOWS[windowShape][this.shortLen - 1 - i] + this.buf[this.shortLen * 2 + i] * this.SHORT_WINDOWS[windowShape][i];
/*  92 */           out[this.mid + 2 * this.shortLen + i] = overlap[this.mid + this.shortLen * 2 + i] + this.buf[this.shortLen * 3 + i] * this.SHORT_WINDOWS[windowShape][this.shortLen - 1 - i] + this.buf[this.shortLen * 4 + i] * this.SHORT_WINDOWS[windowShape][i];
/*  93 */           out[this.mid + 3 * this.shortLen + i] = overlap[this.mid + this.shortLen * 3 + i] + this.buf[this.shortLen * 5 + i] * this.SHORT_WINDOWS[windowShape][this.shortLen - 1 - i] + this.buf[this.shortLen * 6 + i] * this.SHORT_WINDOWS[windowShape][i];
/*  94 */           if (i < this.trans) out[this.mid + 4 * this.shortLen + i] = overlap[this.mid + this.shortLen * 4 + i] + this.buf[this.shortLen * 7 + i] * this.SHORT_WINDOWS[windowShape][this.shortLen - 1 - i] + this.buf[this.shortLen * 8 + i] * this.SHORT_WINDOWS[windowShape][i];
/*     */         
/*     */         } 
/*     */         
/*  98 */         for (i = 0; i < this.shortLen; i++) {
/*  99 */           if (i >= this.trans) overlap[this.mid + 4 * this.shortLen + i - this.length] = this.buf[this.shortLen * 7 + i] * this.SHORT_WINDOWS[windowShape][this.shortLen - 1 - i] + this.buf[this.shortLen * 8 + i] * this.SHORT_WINDOWS[windowShape][i]; 
/* 100 */           overlap[this.mid + 5 * this.shortLen + i - this.length] = this.buf[this.shortLen * 9 + i] * this.SHORT_WINDOWS[windowShape][this.shortLen - 1 - i] + this.buf[this.shortLen * 10 + i] * this.SHORT_WINDOWS[windowShape][i];
/* 101 */           overlap[this.mid + 6 * this.shortLen + i - this.length] = this.buf[this.shortLen * 11 + i] * this.SHORT_WINDOWS[windowShape][this.shortLen - 1 - i] + this.buf[this.shortLen * 12 + i] * this.SHORT_WINDOWS[windowShape][i];
/* 102 */           overlap[this.mid + 7 * this.shortLen + i - this.length] = this.buf[this.shortLen * 13 + i] * this.SHORT_WINDOWS[windowShape][this.shortLen - 1 - i] + this.buf[this.shortLen * 14 + i] * this.SHORT_WINDOWS[windowShape][i];
/* 103 */           overlap[this.mid + 8 * this.shortLen + i - this.length] = this.buf[this.shortLen * 15 + i] * this.SHORT_WINDOWS[windowShape][this.shortLen - 1 - i];
/*     */         } 
/* 105 */         for (i = 0; i < this.mid; i++) {
/* 106 */           overlap[this.mid + this.shortLen + i] = 0.0F;
/*     */         }
/*     */         break;
/*     */       case LONG_STOP_SEQUENCE:
/* 110 */         this.mdctLong.process(_in, 0, this.buf, 0);
/*     */ 
/*     */         
/* 113 */         for (i = 0; i < this.mid; i++) {
/* 114 */           out[i] = overlap[i];
/*     */         }
/* 116 */         for (i = 0; i < this.shortLen; i++) {
/* 117 */           out[this.mid + i] = overlap[this.mid + i] + this.buf[this.mid + i] * this.SHORT_WINDOWS[windowShapePrev][i];
/*     */         }
/* 119 */         for (i = 0; i < this.mid; i++) {
/* 120 */           out[this.mid + this.shortLen + i] = overlap[this.mid + this.shortLen + i] + this.buf[this.mid + this.shortLen + i];
/*     */         }
/*     */         
/* 123 */         for (i = 0; i < this.length; i++) {
/* 124 */           overlap[i] = this.buf[this.length + i] * this.LONG_WINDOWS[windowShape][this.length - 1 - i];
/*     */         }
/*     */         break;
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void processLTP(ICSInfo.WindowSequence windowSequence, int windowShape, int windowShapePrev, float[] _in, float[] out) {
/*     */     int i;
/* 134 */     switch (windowSequence) {
/*     */       case ONLY_LONG_SEQUENCE:
/* 136 */         for (i = this.length - 1; i >= 0; i--) {
/* 137 */           this.buf[i] = _in[i] * this.LONG_WINDOWS[windowShapePrev][i];
/* 138 */           this.buf[i + this.length] = _in[i + this.length] * this.LONG_WINDOWS[windowShape][this.length - 1 - i];
/*     */         } 
/*     */         break;
/*     */       
/*     */       case LONG_START_SEQUENCE:
/* 143 */         for (i = 0; i < this.length; i++) {
/* 144 */           this.buf[i] = _in[i] * this.LONG_WINDOWS[windowShapePrev][i];
/*     */         }
/* 146 */         for (i = 0; i < this.mid; i++) {
/* 147 */           this.buf[i + this.length] = _in[i + this.length];
/*     */         }
/* 149 */         for (i = 0; i < this.shortLen; i++) {
/* 150 */           this.buf[i + this.length + this.mid] = _in[i + this.length + this.mid] * this.SHORT_WINDOWS[windowShape][this.shortLen - 1 - i];
/*     */         }
/* 152 */         for (i = 0; i < this.mid; i++) {
/* 153 */           this.buf[i + this.length + this.mid + this.shortLen] = 0.0F;
/*     */         }
/*     */         break;
/*     */       
/*     */       case LONG_STOP_SEQUENCE:
/* 158 */         for (i = 0; i < this.mid; i++) {
/* 159 */           this.buf[i] = 0.0F;
/*     */         }
/* 161 */         for (i = 0; i < this.shortLen; i++) {
/* 162 */           this.buf[i + this.mid] = _in[i + this.mid] * this.SHORT_WINDOWS[windowShapePrev][i];
/*     */         }
/* 164 */         for (i = 0; i < this.mid; i++) {
/* 165 */           this.buf[i + this.mid + this.shortLen] = _in[i + this.mid + this.shortLen];
/*     */         }
/* 167 */         for (i = 0; i < this.length; i++) {
/* 168 */           this.buf[i + this.length] = _in[i + this.length] * this.LONG_WINDOWS[windowShape][this.length - 1 - i];
/*     */         }
/*     */         break;
/*     */     } 
/* 172 */     this.mdctLong.processForward(this.buf, out);
/*     */   }
/*     */   
/*     */   public float[] getOverlap(int channel) {
/* 176 */     return this.overlaps[channel];
/*     */   }
/*     */ }


/* Location:              C:\Users\rapha\Downloads\aurora.jar!\META-INF\jars\jcodec-0.2.5.jar!\net\sourceforge\jaad\aac\filterbank\FilterBank.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */