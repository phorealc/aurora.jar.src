/*     */ package net.sourceforge.jaad.aac.filterbank;
/*     */ 
/*     */ import net.sourceforge.jaad.aac.AACException;
/*     */ 
/*     */ 
/*     */ class FFT
/*     */   implements FFTTables
/*     */ {
/*     */   private final int length;
/*     */   private final float[][] roots;
/*     */   private final float[][] rev;
/*     */   private float[] a;
/*     */   private float[] b;
/*     */   private float[] c;
/*     */   private float[] d;
/*     */   private float[] e1;
/*     */   private float[] e2;
/*     */   
/*     */   FFT(int length) throws AACException {
/*  20 */     this.length = length;
/*     */     
/*  22 */     switch (length) {
/*     */       case 64:
/*  24 */         this.roots = FFT_TABLE_64;
/*     */         break;
/*     */       case 512:
/*  27 */         this.roots = FFT_TABLE_512;
/*     */         break;
/*     */       case 60:
/*  30 */         this.roots = FFT_TABLE_60;
/*     */         break;
/*     */       case 480:
/*  33 */         this.roots = FFT_TABLE_480;
/*     */         break;
/*     */       default:
/*  36 */         throw new AACException("unexpected FFT length: " + length);
/*     */     } 
/*     */ 
/*     */     
/*  40 */     this.rev = new float[length][2];
/*  41 */     this.a = new float[2];
/*  42 */     this.b = new float[2];
/*  43 */     this.c = new float[2];
/*  44 */     this.d = new float[2];
/*  45 */     this.e1 = new float[2];
/*  46 */     this.e2 = new float[2];
/*     */   }
/*     */   
/*     */   void process(float[][] _in, boolean forward) {
/*  50 */     int imOff = forward ? 2 : 1;
/*  51 */     int scale = forward ? this.length : 1;
/*     */     
/*  53 */     int ii = 0; int i;
/*  54 */     for (i = 0; i < this.length; i++) {
/*  55 */       this.rev[i][0] = _in[ii][0];
/*  56 */       this.rev[i][1] = _in[ii][1];
/*  57 */       int k = this.length >> 1;
/*  58 */       while (ii >= k && k > 0) {
/*  59 */         ii -= k;
/*  60 */         k >>= 1;
/*     */       } 
/*  62 */       ii += k;
/*     */     } 
/*  64 */     for (i = 0; i < this.length; i++) {
/*  65 */       _in[i][0] = this.rev[i][0];
/*  66 */       _in[i][1] = this.rev[i][1];
/*     */     } 
/*     */ 
/*     */     
/*  70 */     for (i = 0; i < this.length; i += 4) {
/*  71 */       this.a[0] = _in[i][0] + _in[i + 1][0];
/*  72 */       this.a[1] = _in[i][1] + _in[i + 1][1];
/*  73 */       this.b[0] = _in[i + 2][0] + _in[i + 3][0];
/*  74 */       this.b[1] = _in[i + 2][1] + _in[i + 3][1];
/*  75 */       this.c[0] = _in[i][0] - _in[i + 1][0];
/*  76 */       this.c[1] = _in[i][1] - _in[i + 1][1];
/*  77 */       this.d[0] = _in[i + 2][0] - _in[i + 3][0];
/*  78 */       this.d[1] = _in[i + 2][1] - _in[i + 3][1];
/*  79 */       _in[i][0] = this.a[0] + this.b[0];
/*  80 */       _in[i][1] = this.a[1] + this.b[1];
/*  81 */       _in[i + 2][0] = this.a[0] - this.b[0];
/*  82 */       _in[i + 2][1] = this.a[1] - this.b[1];
/*     */       
/*  84 */       this.e1[0] = this.c[0] - this.d[1];
/*  85 */       this.e1[1] = this.c[1] + this.d[0];
/*  86 */       this.e2[0] = this.c[0] + this.d[1];
/*  87 */       this.e2[1] = this.c[1] - this.d[0];
/*  88 */       if (forward) {
/*  89 */         _in[i + 1][0] = this.e2[0];
/*  90 */         _in[i + 1][1] = this.e2[1];
/*  91 */         _in[i + 3][0] = this.e1[0];
/*  92 */         _in[i + 3][1] = this.e1[1];
/*     */       } else {
/*     */         
/*  95 */         _in[i + 1][0] = this.e1[0];
/*  96 */         _in[i + 1][1] = this.e1[1];
/*  97 */         _in[i + 3][0] = this.e2[0];
/*  98 */         _in[i + 3][1] = this.e2[1];
/*     */       } 
/*     */     } 
/*     */ 
/*     */     
/*     */     int j;
/*     */     
/* 105 */     for (j = 4; j < this.length; j <<= 1) {
/* 106 */       int shift = j << 1;
/* 107 */       int m = this.length / shift; int k;
/* 108 */       for (k = 0; k < this.length; k += shift) {
/* 109 */         for (int n = 0; n < j; n++) {
/* 110 */           int km = n * m;
/* 111 */           float rootRe = this.roots[km][0];
/* 112 */           float rootIm = this.roots[km][imOff];
/* 113 */           float zRe = _in[j + k + n][0] * rootRe - _in[j + k + n][1] * rootIm;
/* 114 */           float zIm = _in[j + k + n][0] * rootIm + _in[j + k + n][1] * rootRe;
/*     */           
/* 116 */           _in[j + k + n][0] = (_in[k + n][0] - zRe) * scale;
/* 117 */           _in[j + k + n][1] = (_in[k + n][1] - zIm) * scale;
/* 118 */           _in[k + n][0] = (_in[k + n][0] + zRe) * scale;
/* 119 */           _in[k + n][1] = (_in[k + n][1] + zIm) * scale;
/*     */         } 
/*     */       } 
/*     */     } 
/*     */   }
/*     */ }


/* Location:              C:\Users\rapha\Downloads\aurora.jar!\META-INF\jars\jcodec-0.2.5.jar!\net\sourceforge\jaad\aac\filterbank\FFT.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */