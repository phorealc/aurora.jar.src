/*     */ package net.sourceforge.jaad.aac.filterbank;
/*     */ 
/*     */ import net.sourceforge.jaad.aac.AACException;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ class MDCT
/*     */   implements MDCTTables
/*     */ {
/*     */   private final int N;
/*     */   private final int N2;
/*     */   private final int N4;
/*     */   private final int N8;
/*     */   private final float[][] sincos;
/*     */   private final FFT fft;
/*     */   private final float[][] buf;
/*     */   private final float[] tmp;
/*     */   
/*     */   MDCT(int length) throws AACException {
/*  21 */     this.N = length;
/*  22 */     this.N2 = length >> 1;
/*  23 */     this.N4 = length >> 2;
/*  24 */     this.N8 = length >> 3;
/*  25 */     switch (length) {
/*     */       case 2048:
/*  27 */         this.sincos = MDCT_TABLE_2048;
/*     */         break;
/*     */       case 256:
/*  30 */         this.sincos = MDCT_TABLE_128;
/*     */         break;
/*     */       case 1920:
/*  33 */         this.sincos = MDCT_TABLE_1920;
/*     */         break;
/*     */       case 240:
/*  36 */         this.sincos = MDCT_TABLE_240;
/*     */       default:
/*  38 */         throw new AACException("unsupported MDCT length: " + length);
/*     */     } 
/*  40 */     this.fft = new FFT(this.N4);
/*  41 */     this.buf = new float[this.N4][2];
/*  42 */     this.tmp = new float[2];
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   void process(float[] _in, int inOff, float[] out, int outOff) {
/*     */     int k;
/*  49 */     for (k = 0; k < this.N4; k++) {
/*  50 */       this.buf[k][1] = _in[inOff + 2 * k] * this.sincos[k][0] + _in[inOff + this.N2 - 1 - 2 * k] * this.sincos[k][1];
/*  51 */       this.buf[k][0] = _in[inOff + this.N2 - 1 - 2 * k] * this.sincos[k][0] - _in[inOff + 2 * k] * this.sincos[k][1];
/*     */     } 
/*     */ 
/*     */     
/*  55 */     this.fft.process(this.buf, false);
/*     */ 
/*     */     
/*  58 */     for (k = 0; k < this.N4; k++) {
/*  59 */       this.tmp[0] = this.buf[k][0];
/*  60 */       this.tmp[1] = this.buf[k][1];
/*  61 */       this.buf[k][1] = this.tmp[1] * this.sincos[k][0] + this.tmp[0] * this.sincos[k][1];
/*  62 */       this.buf[k][0] = this.tmp[0] * this.sincos[k][0] - this.tmp[1] * this.sincos[k][1];
/*     */     } 
/*     */ 
/*     */     
/*  66 */     for (k = 0; k < this.N8; k += 2) {
/*  67 */       out[outOff + 2 * k] = this.buf[this.N8 + k][1];
/*  68 */       out[outOff + 2 + 2 * k] = this.buf[this.N8 + 1 + k][1];
/*     */       
/*  70 */       out[outOff + 1 + 2 * k] = -this.buf[this.N8 - 1 - k][0];
/*  71 */       out[outOff + 3 + 2 * k] = -this.buf[this.N8 - 2 - k][0];
/*     */       
/*  73 */       out[outOff + this.N4 + 2 * k] = this.buf[k][0];
/*  74 */       out[outOff + this.N4 + 2 + 2 * k] = this.buf[1 + k][0];
/*     */       
/*  76 */       out[outOff + this.N4 + 1 + 2 * k] = -this.buf[this.N4 - 1 - k][1];
/*  77 */       out[outOff + this.N4 + 3 + 2 * k] = -this.buf[this.N4 - 2 - k][1];
/*     */       
/*  79 */       out[outOff + this.N2 + 2 * k] = this.buf[this.N8 + k][0];
/*  80 */       out[outOff + this.N2 + 2 + 2 * k] = this.buf[this.N8 + 1 + k][0];
/*     */       
/*  82 */       out[outOff + this.N2 + 1 + 2 * k] = -this.buf[this.N8 - 1 - k][1];
/*  83 */       out[outOff + this.N2 + 3 + 2 * k] = -this.buf[this.N8 - 2 - k][1];
/*     */       
/*  85 */       out[outOff + this.N2 + this.N4 + 2 * k] = -this.buf[k][1];
/*  86 */       out[outOff + this.N2 + this.N4 + 2 + 2 * k] = -this.buf[1 + k][1];
/*     */       
/*  88 */       out[outOff + this.N2 + this.N4 + 1 + 2 * k] = this.buf[this.N4 - 1 - k][0];
/*  89 */       out[outOff + this.N2 + this.N4 + 3 + 2 * k] = this.buf[this.N4 - 2 - k][0];
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   void processForward(float[] _in, float[] out) {
/*     */     int k;
/*  96 */     for (k = 0; k < this.N8; k++) {
/*  97 */       int n = k << 1;
/*  98 */       this.tmp[0] = _in[this.N - this.N4 - 1 - n] + _in[this.N - this.N4 + n];
/*  99 */       this.tmp[1] = _in[this.N4 + n] - _in[this.N4 - 1 - n];
/*     */       
/* 101 */       this.buf[k][0] = this.tmp[0] * this.sincos[k][0] + this.tmp[1] * this.sincos[k][1];
/* 102 */       this.buf[k][1] = this.tmp[1] * this.sincos[k][0] - this.tmp[0] * this.sincos[k][1];
/*     */       
/* 104 */       this.buf[k][0] = this.buf[k][0] * this.N;
/* 105 */       this.buf[k][1] = this.buf[k][1] * this.N;
/*     */       
/* 107 */       this.tmp[0] = _in[this.N2 - 1 - n] - _in[n];
/* 108 */       this.tmp[1] = _in[this.N2 + n] + _in[this.N - 1 - n];
/*     */       
/* 110 */       this.buf[k + this.N8][0] = this.tmp[0] * this.sincos[k + this.N8][0] + this.tmp[1] * this.sincos[k + this.N8][1];
/* 111 */       this.buf[k + this.N8][1] = this.tmp[1] * this.sincos[k + this.N8][0] - this.tmp[0] * this.sincos[k + this.N8][1];
/*     */       
/* 113 */       this.buf[k + this.N8][0] = this.buf[k + this.N8][0] * this.N;
/* 114 */       this.buf[k + this.N8][1] = this.buf[k + this.N8][1] * this.N;
/*     */     } 
/*     */ 
/*     */     
/* 118 */     this.fft.process(this.buf, true);
/*     */ 
/*     */     
/* 121 */     for (k = 0; k < this.N4; k++) {
/* 122 */       int n = k << 1;
/*     */       
/* 124 */       this.tmp[0] = this.buf[k][0] * this.sincos[k][0] + this.buf[k][1] * this.sincos[k][1];
/* 125 */       this.tmp[1] = this.buf[k][1] * this.sincos[k][0] - this.buf[k][0] * this.sincos[k][1];
/*     */       
/* 127 */       out[n] = -this.tmp[0];
/* 128 */       out[this.N2 - 1 - n] = this.tmp[1];
/* 129 */       out[this.N2 + n] = -this.tmp[1];
/* 130 */       out[this.N - 1 - n] = this.tmp[0];
/*     */     } 
/*     */   }
/*     */ }


/* Location:              C:\Users\rapha\Downloads\aurora.jar!\META-INF\jars\jcodec-0.2.5.jar!\net\sourceforge\jaad\aac\filterbank\MDCT.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */