/*    */ package net.sourceforge.jaad.aac;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public final class ChannelConfiguration
/*    */ {
/* 14 */   public static final ChannelConfiguration CHANNEL_CONFIG_UNSUPPORTED = new ChannelConfiguration(-1, "invalid");
/* 15 */   public static final ChannelConfiguration CHANNEL_CONFIG_NONE = new ChannelConfiguration(0, "No channel");
/* 16 */   public static final ChannelConfiguration CHANNEL_CONFIG_MONO = new ChannelConfiguration(1, "Mono");
/* 17 */   public static final ChannelConfiguration CHANNEL_CONFIG_STEREO = new ChannelConfiguration(2, "Stereo");
/* 18 */   public static final ChannelConfiguration CHANNEL_CONFIG_STEREO_PLUS_CENTER = new ChannelConfiguration(3, "Stereo+Center");
/*    */   
/* 20 */   public static final ChannelConfiguration CHANNEL_CONFIG_STEREO_PLUS_CENTER_PLUS_REAR_MONO = new ChannelConfiguration(4, "Stereo+Center+Rear");
/*    */   
/* 22 */   public static final ChannelConfiguration CHANNEL_CONFIG_FIVE = new ChannelConfiguration(5, "Five channels");
/* 23 */   public static final ChannelConfiguration CHANNEL_CONFIG_FIVE_PLUS_ONE = new ChannelConfiguration(6, "Five channels+LF");
/*    */   
/* 25 */   public static final ChannelConfiguration CHANNEL_CONFIG_SEVEN_PLUS_ONE = new ChannelConfiguration(8, "Seven channels+LF");
/*    */   private final int chCount;
/*    */   private final String descr;
/*    */   
/*    */   public static ChannelConfiguration forInt(int i) {
/* 30 */     switch (i)
/*    */     { case 0:
/* 32 */         c = CHANNEL_CONFIG_NONE;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */         
/* 60 */         return c;case 1: c = CHANNEL_CONFIG_MONO; return c;case 2: c = CHANNEL_CONFIG_STEREO; return c;case 3: c = CHANNEL_CONFIG_STEREO_PLUS_CENTER; return c;case 4: c = CHANNEL_CONFIG_STEREO_PLUS_CENTER_PLUS_REAR_MONO; return c;case 5: c = CHANNEL_CONFIG_FIVE; return c;case 6: c = CHANNEL_CONFIG_FIVE_PLUS_ONE; return c;case 7: case 8: c = CHANNEL_CONFIG_SEVEN_PLUS_ONE; return c; }  ChannelConfiguration c = CHANNEL_CONFIG_UNSUPPORTED; return c;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   private ChannelConfiguration(int chCount, String descr) {
/* 67 */     this.chCount = chCount;
/* 68 */     this.descr = descr;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public int getChannelCount() {
/* 75 */     return this.chCount;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public String getDescription() {
/* 84 */     return this.descr;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public String toString() {
/* 95 */     return this.descr;
/*    */   }
/*    */ }


/* Location:              C:\Users\rapha\Downloads\aurora.jar!\META-INF\jars\jcodec-0.2.5.jar!\net\sourceforge\jaad\aac\ChannelConfiguration.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */