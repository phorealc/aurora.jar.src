/*     */ package net.sourceforge.jaad.aac;
/*     */ 
/*     */ import net.sourceforge.jaad.aac.syntax.BitStream;
/*     */ import net.sourceforge.jaad.aac.syntax.IBitStream;
/*     */ import net.sourceforge.jaad.aac.syntax.PCE;
/*     */ import net.sourceforge.jaad.aac.syntax.SyntaxConstants;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class AACDecoderConfig
/*     */   implements SyntaxConstants
/*     */ {
/*  36 */   private Profile profile = Profile.AAC_MAIN;
/*  37 */   private Profile extProfile = Profile.UNKNOWN;
/*  38 */   private SampleFrequency sampleFrequency = SampleFrequency.SAMPLE_FREQUENCY_NONE;
/*  39 */   private ChannelConfiguration channelConfiguration = ChannelConfiguration.CHANNEL_CONFIG_UNSUPPORTED;
/*     */   
/*     */   private boolean frameLengthFlag = false;
/*     */   
/*     */   private boolean dependsOnCoreCoder;
/*     */   
/*     */   private int coreCoderDelay;
/*     */   
/*     */   private boolean extensionFlag;
/*     */   private boolean sbrPresent = false;
/*     */   
/*     */   public ChannelConfiguration getChannelConfiguration() {
/*  51 */     return this.channelConfiguration;
/*     */   }
/*     */   private boolean downSampledSBR = false; private boolean sbrEnabled = true; private boolean sectionDataResilience = false; private boolean scalefactorResilience = false; private boolean spectralDataResilience = false;
/*     */   public void setChannelConfiguration(ChannelConfiguration channelConfiguration) {
/*  55 */     this.channelConfiguration = channelConfiguration;
/*     */   }
/*     */   
/*     */   public int getCoreCoderDelay() {
/*  59 */     return this.coreCoderDelay;
/*     */   }
/*     */   
/*     */   public void setCoreCoderDelay(int coreCoderDelay) {
/*  63 */     this.coreCoderDelay = coreCoderDelay;
/*     */   }
/*     */   
/*     */   public boolean isDependsOnCoreCoder() {
/*  67 */     return this.dependsOnCoreCoder;
/*     */   }
/*     */   
/*     */   public void setDependsOnCoreCoder(boolean dependsOnCoreCoder) {
/*  71 */     this.dependsOnCoreCoder = dependsOnCoreCoder;
/*     */   }
/*     */   
/*     */   public Profile getExtObjectType() {
/*  75 */     return this.extProfile;
/*     */   }
/*     */   
/*     */   public void setExtObjectType(Profile extObjectType) {
/*  79 */     this.extProfile = extObjectType;
/*     */   }
/*     */   
/*     */   public int getFrameLength() {
/*  83 */     return this.frameLengthFlag ? 960 : 1024;
/*     */   }
/*     */   
/*     */   public boolean isSmallFrameUsed() {
/*  87 */     return this.frameLengthFlag;
/*     */   }
/*     */   
/*     */   public void setSmallFrameUsed(boolean shortFrame) {
/*  91 */     this.frameLengthFlag = shortFrame;
/*     */   }
/*     */   
/*     */   public Profile getProfile() {
/*  95 */     return this.profile;
/*     */   }
/*     */   
/*     */   public void setProfile(Profile profile) {
/*  99 */     this.profile = profile;
/*     */   }
/*     */   
/*     */   public SampleFrequency getSampleFrequency() {
/* 103 */     return this.sampleFrequency;
/*     */   }
/*     */   
/*     */   public void setSampleFrequency(SampleFrequency sampleFrequency) {
/* 107 */     this.sampleFrequency = sampleFrequency;
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean isSBRPresent() {
/* 112 */     return this.sbrPresent;
/*     */   }
/*     */   
/*     */   public boolean isSBRDownSampled() {
/* 116 */     return this.downSampledSBR;
/*     */   }
/*     */   
/*     */   public boolean isSBREnabled() {
/* 120 */     return this.sbrEnabled;
/*     */   }
/*     */   
/*     */   public void setSBREnabled(boolean enabled) {
/* 124 */     this.sbrEnabled = enabled;
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean isScalefactorResilienceUsed() {
/* 129 */     return this.scalefactorResilience;
/*     */   }
/*     */   
/*     */   public boolean isSectionDataResilienceUsed() {
/* 133 */     return this.sectionDataResilience;
/*     */   }
/*     */   
/*     */   public boolean isSpectralDataResilienceUsed() {
/* 137 */     return this.spectralDataResilience;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static AACDecoderConfig parseMP4DecoderSpecificInfo(byte[] data) throws AACException {
/* 148 */     BitStream bitStream = BitStream.createBitStream(data);
/* 149 */     AACDecoderConfig config = new AACDecoderConfig();
/*     */     
/*     */     try {
/* 152 */       config.profile = readProfile((IBitStream)bitStream);
/*     */       
/* 154 */       int sf = bitStream.readBits(4);
/* 155 */       if (sf == 15) { config.sampleFrequency = SampleFrequency.forFrequency(bitStream.readBits(24)); }
/* 156 */       else { config.sampleFrequency = SampleFrequency.forInt(sf); }
/* 157 */        config.channelConfiguration = ChannelConfiguration.forInt(bitStream.readBits(4));
/*     */       
/* 159 */       Profile cp = config.profile;
/* 160 */       if (Profile.AAC_SBR == cp) {
/* 161 */         config.extProfile = cp;
/* 162 */         config.sbrPresent = true;
/* 163 */         sf = bitStream.readBits(4);
/*     */ 
/*     */ 
/*     */         
/* 167 */         config.downSampledSBR = (config.sampleFrequency.getIndex() == sf);
/* 168 */         config.sampleFrequency = SampleFrequency.forInt(sf);
/* 169 */         config.profile = readProfile((IBitStream)bitStream);
/* 170 */       } else if (Profile.AAC_MAIN == cp || Profile.AAC_LC == cp || Profile.AAC_SSR == cp || Profile.AAC_LTP == cp || Profile.ER_AAC_LC == cp || Profile.ER_AAC_LTP == cp || Profile.ER_AAC_LD == cp) {
/*     */         
/* 172 */         config.frameLengthFlag = bitStream.readBool();
/* 173 */         if (config.frameLengthFlag) throw new AACException("config uses 960-sample frames, not yet supported"); 
/* 174 */         config.dependsOnCoreCoder = bitStream.readBool();
/* 175 */         if (config.dependsOnCoreCoder) { config.coreCoderDelay = bitStream.readBits(14); }
/* 176 */         else { config.coreCoderDelay = 0; }
/* 177 */          config.extensionFlag = bitStream.readBool();
/*     */         
/* 179 */         if (config.extensionFlag) {
/* 180 */           if (cp.isErrorResilientProfile()) {
/* 181 */             config.sectionDataResilience = bitStream.readBool();
/* 182 */             config.scalefactorResilience = bitStream.readBool();
/* 183 */             config.spectralDataResilience = bitStream.readBool();
/*     */           } 
/*     */           
/* 186 */           bitStream.skipBit();
/*     */         } 
/*     */         
/* 189 */         if (config.channelConfiguration == ChannelConfiguration.CHANNEL_CONFIG_NONE) {
/*     */           
/* 191 */           bitStream.skipBits(3);
/* 192 */           PCE pce = new PCE();
/* 193 */           pce.decode((IBitStream)bitStream);
/* 194 */           config.profile = pce.getProfile();
/* 195 */           config.sampleFrequency = pce.getSampleFrequency();
/* 196 */           config.channelConfiguration = ChannelConfiguration.forInt(pce.getChannelCount());
/*     */         } 
/*     */         
/* 199 */         if (bitStream.getBitsLeft() > 10) readSyncExtension((IBitStream)bitStream, config); 
/*     */       } else {
/* 201 */         throw new AACException("profile not supported: " + cp.getIndex());
/*     */       } 
/* 203 */       return config;
/*     */     } finally {
/*     */       
/* 206 */       bitStream.destroy();
/*     */     } 
/*     */   }
/*     */   
/*     */   private static Profile readProfile(IBitStream _in) throws AACException {
/* 211 */     int i = _in.readBits(5);
/* 212 */     if (i == 31) i = 32 + _in.readBits(6); 
/* 213 */     return Profile.forInt(i);
/*     */   }
/*     */   private static void readSyncExtension(IBitStream _in, AACDecoderConfig config) throws AACException {
/*     */     Profile profile;
/* 217 */     int type = _in.readBits(11);
/* 218 */     switch (type) {
/*     */       case 695:
/* 220 */         profile = Profile.forInt(_in.readBits(5));
/*     */         
/* 222 */         if (profile.equals(Profile.AAC_SBR)) {
/* 223 */           config.sbrPresent = _in.readBool();
/* 224 */           if (config.sbrPresent) {
/* 225 */             config.profile = profile;
/*     */             
/* 227 */             int tmp = _in.readBits(4);
/*     */             
/* 229 */             if (tmp == config.sampleFrequency.getIndex()) config.downSampledSBR = true; 
/* 230 */             if (tmp == 15)
/* 231 */               throw new AACException("sample rate specified explicitly, not supported yet!"); 
/*     */           } 
/*     */         } 
/*     */         break;
/*     */     } 
/*     */   }
/*     */ }


/* Location:              C:\Users\rapha\Downloads\aurora.jar!\META-INF\jars\jcodec-0.2.5.jar!\net\sourceforge\jaad\aac\AACDecoderConfig.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */