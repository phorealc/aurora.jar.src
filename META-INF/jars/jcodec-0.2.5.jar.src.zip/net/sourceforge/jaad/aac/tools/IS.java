/*    */ package net.sourceforge.jaad.aac.tools;
/*    */ 
/*    */ import net.sourceforge.jaad.aac.huffman.HCB;
/*    */ import net.sourceforge.jaad.aac.syntax.CPE;
/*    */ import net.sourceforge.jaad.aac.syntax.ICSInfo;
/*    */ import net.sourceforge.jaad.aac.syntax.ICStream;
/*    */ import net.sourceforge.jaad.aac.syntax.SyntaxConstants;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public final class IS
/*    */   implements SyntaxConstants, ISScaleTable, HCB
/*    */ {
/*    */   public static void process(CPE cpe, float[] specL, float[] specR) {
/* 23 */     ICStream ics = cpe.getRightChannel();
/* 24 */     ICSInfo info = ics.getInfo();
/* 25 */     int[] offsets = info.getSWBOffsets();
/* 26 */     int windowGroups = info.getWindowGroupCount();
/* 27 */     int maxSFB = info.getMaxSFB();
/* 28 */     int[] sfbCB = ics.getSfbCB();
/* 29 */     int[] sectEnd = ics.getSectEnd();
/* 30 */     float[] scaleFactors = ics.getScaleFactors();
/*    */ 
/*    */     
/* 33 */     int idx = 0, groupOff = 0;
/*    */     
/* 35 */     for (int g = 0; g < windowGroups; g++) {
/* 36 */       int i; for (i = 0; i < maxSFB; ) {
/* 37 */         if (sfbCB[idx] == 15 || sfbCB[idx] == 14) {
/* 38 */           int j = sectEnd[idx];
/* 39 */           for (; i < j; i++, idx++) {
/* 40 */             int c = (sfbCB[idx] == 15) ? 1 : -1;
/* 41 */             if (cpe.isMSMaskPresent())
/* 42 */               c *= cpe.isMSUsed(idx) ? -1 : 1; 
/* 43 */             float scale = c * scaleFactors[idx];
/* 44 */             for (int w = 0; w < info.getWindowGroupLength(g); w++) {
/* 45 */               int off = groupOff + w * 128 + offsets[i];
/* 46 */               for (int k = 0; k < offsets[i + 1] - offsets[i]; k++) {
/* 47 */                 specR[off + k] = specL[off + k] * scale;
/*    */               }
/*    */             } 
/*    */           } 
/*    */           continue;
/*    */         } 
/* 53 */         int end = sectEnd[idx];
/* 54 */         idx += end - i;
/* 55 */         i = end;
/*    */       } 
/*    */       
/* 58 */       groupOff += info.getWindowGroupLength(g) * 128;
/*    */     } 
/*    */   }
/*    */ }


/* Location:              C:\Users\rapha\Downloads\aurora.jar!\META-INF\jars\jcodec-0.2.5.jar!\net\sourceforge\jaad\aac\tools\IS.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */