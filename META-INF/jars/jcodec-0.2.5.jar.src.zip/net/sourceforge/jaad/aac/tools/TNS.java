/*    */ package net.sourceforge.jaad.aac.tools;
/*    */ 
/*    */ import net.sourceforge.jaad.aac.AACException;
/*    */ import net.sourceforge.jaad.aac.SampleFrequency;
/*    */ import net.sourceforge.jaad.aac.syntax.IBitStream;
/*    */ import net.sourceforge.jaad.aac.syntax.ICSInfo;
/*    */ import net.sourceforge.jaad.aac.syntax.ICStream;
/*    */ import net.sourceforge.jaad.aac.syntax.SyntaxConstants;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class TNS
/*    */   implements SyntaxConstants, TNSTables
/*    */ {
/* 21 */   private static final int[] SHORT_BITS = new int[] { 1, 4, 3 }; private static final int[] LONG_BITS = new int[] { 2, 6, 5 };
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/* 29 */   private int[] nFilt = new int[8];
/* 30 */   private int[][] length = new int[8][4];
/* 31 */   private boolean[][] direction = new boolean[8][4];
/* 32 */   private int[][] order = new int[8][4];
/* 33 */   private float[][][] coef = new float[8][4][20];
/*    */   private static final int TNS_MAX_ORDER = 20;
/*    */   
/*    */   public void decode(IBitStream _in, ICSInfo info) throws AACException {
/* 37 */     int windowCount = info.getWindowCount();
/* 38 */     int[] bits = info.isEightShortFrame() ? SHORT_BITS : LONG_BITS;
/*    */ 
/*    */     
/* 41 */     for (int w = 0; w < windowCount; w++) {
/* 42 */       this.nFilt[w] = _in.readBits(bits[0]); if (_in.readBits(bits[0]) != 0) {
/* 43 */         int coefRes = _in.readBit();
/*    */         
/* 45 */         for (int filt = 0; filt < this.nFilt[w]; filt++) {
/* 46 */           this.length[w][filt] = _in.readBits(bits[1]);
/*    */           
/* 48 */           this.order[w][filt] = _in.readBits(bits[2]); if (_in.readBits(bits[2]) > 20) throw new AACException("TNS filter out of range: " + this.order[w][filt]); 
/* 49 */           if (this.order[w][filt] != 0) {
/* 50 */             this.direction[w][filt] = _in.readBool();
/* 51 */             int coefCompress = _in.readBit();
/* 52 */             int coefLen = coefRes + 3 - coefCompress;
/* 53 */             int tmp = 2 * coefCompress + coefRes;
/*    */             
/* 55 */             for (int i = 0; i < this.order[w][filt]; i++)
/* 56 */               this.coef[w][filt][i] = TNS_TABLES[tmp][_in.readBits(coefLen)]; 
/*    */           } 
/*    */         } 
/*    */       } 
/*    */     } 
/*    */   }
/*    */   
/*    */   public void process(ICStream ics, float[] spec, SampleFrequency sf, boolean decode) {}
/*    */ }


/* Location:              C:\Users\rapha\Downloads\aurora.jar!\META-INF\jars\jcodec-0.2.5.jar!\net\sourceforge\jaad\aac\tools\TNS.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */