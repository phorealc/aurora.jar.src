/*    */ package net.sourceforge.jaad.aac.tools;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public enum MSMask
/*    */ {
/* 13 */   TYPE_ALL_0, TYPE_USED, TYPE_ALL_1, TYPE_RESERVED;
/*    */ }


/* Location:              C:\Users\rapha\Downloads\aurora.jar!\META-INF\jars\jcodec-0.2.5.jar!\net\sourceforge\jaad\aac\tools\MSMask.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */