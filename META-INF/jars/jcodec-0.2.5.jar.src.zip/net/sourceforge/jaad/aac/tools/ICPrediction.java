/*     */ package net.sourceforge.jaad.aac.tools;
/*     */ 
/*     */ import net.sourceforge.jaad.aac.AACException;
/*     */ import net.sourceforge.jaad.aac.SampleFrequency;
/*     */ import net.sourceforge.jaad.aac.syntax.IBitStream;
/*     */ import net.sourceforge.jaad.aac.syntax.ICSInfo;
/*     */ import net.sourceforge.jaad.aac.syntax.ICStream;
/*     */ import org.jcodec.common.logging.Logger;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ICPrediction
/*     */ {
/*     */   private static final float SF_SCALE = -9.765625E-4F;
/*     */   private static final float INV_SF_SCALE = -1024.0F;
/*     */   private static final int MAX_PREDICTORS = 672;
/*     */   private static final float A = 0.953125F;
/*     */   private static final float ALPHA = 0.90625F;
/*     */   private boolean predictorReset;
/*     */   private int predictorResetGroup;
/*     */   private boolean[] predictionUsed;
/*     */   private PredictorState[] states;
/*     */   
/*     */   private static final class PredictorState
/*     */   {
/*     */     private PredictorState() {}
/*     */     
/*  32 */     float cor0 = 0.0F;
/*  33 */     float cor1 = 0.0F;
/*  34 */     float var0 = 0.0F;
/*  35 */     float var1 = 0.0F;
/*  36 */     float r0 = 1.0F;
/*  37 */     float r1 = 1.0F;
/*     */   }
/*     */   
/*     */   public ICPrediction() {
/*  41 */     this.states = new PredictorState[672];
/*  42 */     resetAllPredictors();
/*     */   }
/*     */   
/*     */   public void decode(IBitStream _in, int maxSFB, SampleFrequency sf) throws AACException {
/*  46 */     int predictorCount = sf.getPredictorCount();
/*     */     
/*  48 */     if (this.predictorReset = _in.readBool()) this.predictorResetGroup = _in.readBits(5);
/*     */     
/*  50 */     int maxPredSFB = sf.getMaximalPredictionSFB();
/*  51 */     int length = Math.min(maxSFB, maxPredSFB);
/*  52 */     this.predictionUsed = new boolean[length];
/*  53 */     for (int sfb = 0; sfb < length; sfb++) {
/*  54 */       this.predictionUsed[sfb] = _in.readBool();
/*     */     }
/*  56 */     Logger.warn("ICPrediction: maxSFB={0}, maxPredSFB={1}", new Object[] { { maxSFB, maxPredSFB } });
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setPredictionUnused(int sfb) {
/*  64 */     this.predictionUsed[sfb] = false;
/*     */   }
/*     */   
/*     */   public void process(ICStream ics, float[] data, SampleFrequency sf) {
/*  68 */     ICSInfo info = ics.getInfo();
/*     */     
/*  70 */     if (info.isEightShortFrame()) { resetAllPredictors(); }
/*     */     else
/*  72 */     { int len = Math.min(sf.getMaximalPredictionSFB(), info.getMaxSFB());
/*  73 */       int[] swbOffsets = info.getSWBOffsets();
/*     */       
/*  75 */       for (int sfb = 0; sfb < len; sfb++) {
/*  76 */         for (int k = swbOffsets[sfb]; k < swbOffsets[sfb + 1]; k++) {
/*  77 */           predict(data, k, this.predictionUsed[sfb]);
/*     */         }
/*     */       } 
/*  80 */       if (this.predictorReset) resetPredictorGroup(this.predictorResetGroup);  }
/*     */   
/*     */   }
/*     */   
/*     */   private void resetPredictState(int index) {
/*  85 */     if (this.states[index] == null) this.states[index] = new PredictorState(); 
/*  86 */     (this.states[index]).r0 = 0.0F;
/*  87 */     (this.states[index]).r1 = 0.0F;
/*  88 */     (this.states[index]).cor0 = 0.0F;
/*  89 */     (this.states[index]).cor1 = 0.0F;
/*  90 */     (this.states[index]).var0 = 16256.0F;
/*  91 */     (this.states[index]).var1 = 16256.0F;
/*     */   }
/*     */ 
/*     */   
/*     */   private void resetAllPredictors() {
/*  96 */     for (int i = 0; i < this.states.length; i++) {
/*  97 */       resetPredictState(i);
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   private void resetPredictorGroup(int group) {
/* 103 */     for (int i = group - 1; i < this.states.length; i += 30) {
/* 104 */       resetPredictState(i);
/*     */     }
/*     */   }
/*     */   
/*     */   private void predict(float[] data, int off, boolean output) {
/* 109 */     if (this.states[off] == null) this.states[off] = new PredictorState(); 
/* 110 */     PredictorState state = this.states[off];
/* 111 */     float r0 = state.r0, r1 = state.r1;
/* 112 */     float cor0 = state.cor0, cor1 = state.cor1;
/* 113 */     float var0 = state.var0, var1 = state.var1;
/*     */     
/* 115 */     float k1 = (var0 > 1.0F) ? (cor0 * even(0.953125F / var0)) : 0.0F;
/* 116 */     float k2 = (var1 > 1.0F) ? (cor1 * even(0.953125F / var1)) : 0.0F;
/*     */     
/* 118 */     float pv = round(k1 * r0 + k2 * r1);
/* 119 */     if (output) data[off] = data[off] + pv * -9.765625E-4F;
/*     */     
/* 121 */     float e0 = data[off] * -1024.0F;
/* 122 */     float e1 = e0 - k1 * r0;
/*     */     
/* 124 */     state.cor1 = trunc(0.90625F * cor1 + r1 * e1);
/* 125 */     state.var1 = trunc(0.90625F * var1 + 0.5F * (r1 * r1 + e1 * e1));
/* 126 */     state.cor0 = trunc(0.90625F * cor0 + r0 * e0);
/* 127 */     state.var0 = trunc(0.90625F * var0 + 0.5F * (r0 * r0 + e0 * e0));
/*     */     
/* 129 */     state.r1 = trunc(0.953125F * (r0 - k1 * e0));
/* 130 */     state.r0 = trunc(0.953125F * e0);
/*     */   }
/*     */   
/*     */   private float round(float pf) {
/* 134 */     return Float.intBitsToFloat(Float.floatToIntBits(pf) + 32768 & 0xFFFF0000);
/*     */   }
/*     */   
/*     */   private float even(float pf) {
/* 138 */     int i = Float.floatToIntBits(pf);
/* 139 */     i = i + 32767 + (i & 0x1) & 0xFFFF0000;
/* 140 */     return Float.intBitsToFloat(i);
/*     */   }
/*     */   
/*     */   private float trunc(float pf) {
/* 144 */     return Float.intBitsToFloat(Float.floatToIntBits(pf) & 0xFFFF0000);
/*     */   }
/*     */ }


/* Location:              C:\Users\rapha\Downloads\aurora.jar!\META-INF\jars\jcodec-0.2.5.jar!\net\sourceforge\jaad\aac\tools\ICPrediction.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */