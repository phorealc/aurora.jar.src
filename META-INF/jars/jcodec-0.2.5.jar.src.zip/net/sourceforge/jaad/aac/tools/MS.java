/*    */ package net.sourceforge.jaad.aac.tools;
/*    */ 
/*    */ import net.sourceforge.jaad.aac.huffman.HCB;
/*    */ import net.sourceforge.jaad.aac.syntax.CPE;
/*    */ import net.sourceforge.jaad.aac.syntax.ICSInfo;
/*    */ import net.sourceforge.jaad.aac.syntax.ICStream;
/*    */ import net.sourceforge.jaad.aac.syntax.SyntaxConstants;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public final class MS
/*    */   implements SyntaxConstants, HCB
/*    */ {
/*    */   public static void process(CPE cpe, float[] specL, float[] specR) {
/* 23 */     ICStream ics = cpe.getLeftChannel();
/* 24 */     ICSInfo info = ics.getInfo();
/* 25 */     int[] offsets = info.getSWBOffsets();
/* 26 */     int windowGroups = info.getWindowGroupCount();
/* 27 */     int maxSFB = info.getMaxSFB();
/* 28 */     int[] sfbCBl = ics.getSfbCB();
/* 29 */     int[] sfbCBr = cpe.getRightChannel().getSfbCB();
/* 30 */     int groupOff = 0;
/* 31 */     int idx = 0;
/*    */     
/* 33 */     for (int g = 0; g < windowGroups; g++) {
/* 34 */       for (int i = 0; i < maxSFB; i++, idx++) {
/* 35 */         if (cpe.isMSUsed(idx) && sfbCBl[idx] < 13 && sfbCBr[idx] < 13) {
/* 36 */           for (int w = 0; w < info.getWindowGroupLength(g); w++) {
/* 37 */             int off = groupOff + w * 128 + offsets[i];
/* 38 */             for (int j = 0; j < offsets[i + 1] - offsets[i]; j++) {
/* 39 */               float t = specL[off + j] - specR[off + j];
/* 40 */               specL[off + j] = specL[off + j] + specR[off + j];
/* 41 */               specR[off + j] = t;
/*    */             } 
/*    */           } 
/*    */         }
/*    */       } 
/* 46 */       groupOff += info.getWindowGroupLength(g) * 128;
/*    */     } 
/*    */   }
/*    */ }


/* Location:              C:\Users\rapha\Downloads\aurora.jar!\META-INF\jars\jcodec-0.2.5.jar!\net\sourceforge\jaad\aac\tools\MS.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */