/*    */ package net.sourceforge.jaad.aac.gain;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ interface GCConstants
/*    */ {
/*    */   public static final int BANDS = 4;
/*    */   public static final int MAX_CHANNELS = 5;
/*    */   public static final int NPQFTAPS = 96;
/*    */   public static final int NPEPARTS = 64;
/*    */   public static final int ID_GAIN = 16;
/* 17 */   public static final int[] LN_GAIN = new int[] { -4, -3, -2, -1, 0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11 };
/*    */ }


/* Location:              C:\Users\rapha\Downloads\aurora.jar!\META-INF\jars\jcodec-0.2.5.jar!\net\sourceforge\jaad\aac\gain\GCConstants.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */