/*    */ package net.sourceforge.jaad.aac.gain;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ class IPQF
/*    */   implements GCConstants, PQFTables
/*    */ {
/* 17 */   private final float[] buf = new float[4];
/* 18 */   private final float[][] tmp1 = new float[2][24];
/* 19 */   private final float[][] tmp2 = new float[2][24];
/*    */ 
/*    */   
/*    */   void process(float[][] _in, int frameLen, int maxBand, float[] out) {
/*    */     int i;
/* 24 */     for (i = 0; i < frameLen; i++) {
/* 25 */       out[i] = 0.0F;
/*    */     }
/*    */     
/* 28 */     for (i = 0; i < frameLen / 4; i++) {
/* 29 */       for (int j = 0; j < 4; j++) {
/* 30 */         this.buf[j] = _in[j][i];
/*    */       }
/* 32 */       performSynthesis(this.buf, out, i * 4);
/*    */     } 
/*    */   }
/*    */   
/*    */   private void performSynthesis(float[] _in, float[] out, int outOff) {
/* 37 */     int kk = 12;
/*    */     
/*    */     int n;
/*    */     
/* 41 */     for (n = 0; n < 2; n++) {
/* 42 */       for (int k = 0; k < 23; k++) {
/* 43 */         this.tmp1[n][k] = this.tmp1[n][k + 1];
/* 44 */         this.tmp2[n][k] = this.tmp2[n][k + 1];
/*    */       } 
/*    */     } 
/*    */     
/* 48 */     for (n = 0; n < 2; n++) {
/* 49 */       float acc = 0.0F; int i;
/* 50 */       for (i = 0; i < 4; i++) {
/* 51 */         acc += COEFS_Q0[n][i] * _in[i];
/*    */       }
/* 53 */       this.tmp1[n][23] = acc;
/*    */       
/* 55 */       acc = 0.0F;
/* 56 */       for (i = 0; i < 4; i++) {
/* 57 */         acc += COEFS_Q1[n][i] * _in[i];
/*    */       }
/* 59 */       this.tmp2[n][23] = acc;
/*    */     } 
/*    */     
/* 62 */     for (n = 0; n < 2; n++) {
/* 63 */       float acc = 0.0F; int k;
/* 64 */       for (k = 0; k < 12; k++) {
/* 65 */         acc += COEFS_T0[n][k] * this.tmp1[n][23 - 2 * k];
/*    */       }
/* 67 */       for (k = 0; k < 12; k++) {
/* 68 */         acc += COEFS_T1[n][k] * this.tmp2[n][22 - 2 * k];
/*    */       }
/* 70 */       out[outOff + n] = acc;
/*    */       
/* 72 */       acc = 0.0F;
/* 73 */       for (k = 0; k < 12; k++) {
/* 74 */         acc += COEFS_T0[3 - n][k] * this.tmp1[n][23 - 2 * k];
/*    */       }
/* 76 */       for (k = 0; k < 12; k++) {
/* 77 */         acc -= COEFS_T1[3 - n][k] * this.tmp2[n][22 - 2 * k];
/*    */       }
/* 79 */       out[outOff + 4 - 1 - n] = acc;
/*    */     } 
/*    */   }
/*    */ }


/* Location:              C:\Users\rapha\Downloads\aurora.jar!\META-INF\jars\jcodec-0.2.5.jar!\net\sourceforge\jaad\aac\gain\IPQF.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */