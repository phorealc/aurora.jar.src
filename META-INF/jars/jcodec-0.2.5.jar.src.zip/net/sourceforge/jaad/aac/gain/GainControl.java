/*     */ package net.sourceforge.jaad.aac.gain;
/*     */ 
/*     */ import net.sourceforge.jaad.aac.AACException;
/*     */ import net.sourceforge.jaad.aac.syntax.IBitStream;
/*     */ import net.sourceforge.jaad.aac.syntax.ICSInfo;
/*     */ import org.jcodec.platform.Platform;
/*     */ 
/*     */ 
/*     */ 
/*     */ public class GainControl
/*     */   implements GCConstants
/*     */ {
/*     */   private final int frameLen;
/*     */   private final int lbLong;
/*     */   private final int lbShort;
/*     */   private final IMDCT imdct;
/*     */   private final IPQF ipqf;
/*     */   private final float[] buffer1;
/*     */   private final float[] _function;
/*     */   private final float[][] buffer2;
/*     */   private final float[][] overlap;
/*     */   private int maxBand;
/*     */   private int[][][] level;
/*     */   private int[][][] levelPrev;
/*     */   private int[][][] location;
/*     */   private int[][][] locationPrev;
/*     */   
/*     */   public GainControl(int frameLen) {
/*  29 */     this.frameLen = frameLen;
/*  30 */     this.lbLong = frameLen / 4;
/*  31 */     this.lbShort = this.lbLong / 8;
/*  32 */     this.imdct = new IMDCT(frameLen);
/*  33 */     this.ipqf = new IPQF();
/*  34 */     this.levelPrev = new int[0][][];
/*  35 */     this.locationPrev = new int[0][][];
/*  36 */     this.buffer1 = new float[frameLen / 2];
/*  37 */     this.buffer2 = new float[4][this.lbLong];
/*  38 */     this._function = new float[this.lbLong * 2];
/*  39 */     this.overlap = new float[4][this.lbLong * 2];
/*     */   }
/*     */   public void decode(IBitStream _in, ICSInfo.WindowSequence winSeq) throws AACException {
/*     */     int wdLen, locBits;
/*  43 */     this.maxBand = _in.readBits(2) + 1;
/*     */     
/*  45 */     int locBits2 = 0;
/*  46 */     switch (winSeq) {
/*     */       case ONLY_LONG_SEQUENCE:
/*  48 */         wdLen = 1;
/*  49 */         locBits = 5;
/*  50 */         locBits2 = 5;
/*     */         break;
/*     */       case EIGHT_SHORT_SEQUENCE:
/*  53 */         wdLen = 8;
/*  54 */         locBits = 2;
/*  55 */         locBits2 = 2;
/*     */         break;
/*     */       case LONG_START_SEQUENCE:
/*  58 */         wdLen = 2;
/*  59 */         locBits = 4;
/*  60 */         locBits2 = 2;
/*     */         break;
/*     */       case LONG_STOP_SEQUENCE:
/*  63 */         wdLen = 2;
/*  64 */         locBits = 4;
/*  65 */         locBits2 = 5;
/*     */         break;
/*     */       default:
/*     */         return;
/*     */     } 
/*  70 */     this.level = new int[this.maxBand][wdLen][];
/*  71 */     this.location = new int[this.maxBand][wdLen][];
/*     */ 
/*     */     
/*  74 */     for (int bd = 1; bd < this.maxBand; bd++) {
/*  75 */       for (int wd = 0; wd < wdLen; wd++) {
/*  76 */         int len = _in.readBits(3);
/*  77 */         this.level[bd][wd] = new int[len];
/*  78 */         this.location[bd][wd] = new int[len];
/*  79 */         for (int k = 0; k < len; k++) {
/*  80 */           this.level[bd][wd][k] = _in.readBits(4);
/*  81 */           int bits = (wd == 0) ? locBits : locBits2;
/*  82 */           this.location[bd][wd][k] = _in.readBits(bits);
/*     */         } 
/*     */       } 
/*     */     } 
/*     */   }
/*     */   
/*     */   public void process(float[] data, int winShape, int winShapePrev, ICSInfo.WindowSequence winSeq) throws AACException {
/*  89 */     this.imdct.process(data, this.buffer1, winShape, winShapePrev, winSeq);
/*     */     
/*  91 */     for (int i = 0; i < 4; i++) {
/*  92 */       compensate(this.buffer1, this.buffer2, winSeq, i);
/*     */     }
/*     */     
/*  95 */     this.ipqf.process(this.buffer2, this.frameLen, this.maxBand, data);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void compensate(float[] _in, float[][] out, ICSInfo.WindowSequence winSeq, int band) {
/* 106 */     if (winSeq.equals(ICSInfo.WindowSequence.EIGHT_SHORT_SEQUENCE)) {
/*     */       
/* 108 */       for (int k = 0; k < 8; k++) {
/*     */         
/* 110 */         calculateFunctionData(this.lbShort * 2, band, winSeq, k);
/*     */         int j;
/* 112 */         for (j = 0; j < this.lbShort * 2; j++) {
/* 113 */           int a = band * this.lbLong * 2 + k * this.lbShort * 2 + j;
/* 114 */           _in[a] = _in[a] * this._function[j];
/*     */         } 
/*     */         
/* 117 */         for (j = 0; j < this.lbShort; j++) {
/* 118 */           int a = j + this.lbLong * 7 / 16 + this.lbShort * k;
/* 119 */           int b = band * this.lbLong * 2 + k * this.lbShort * 2 + j;
/* 120 */           this.overlap[band][a] = this.overlap[band][a] + _in[b];
/*     */         } 
/*     */         
/* 123 */         for (j = 0; j < this.lbShort; j++) {
/* 124 */           int a = j + this.lbLong * 7 / 16 + this.lbShort * (k + 1);
/* 125 */           int b = band * this.lbLong * 2 + k * this.lbShort * 2 + this.lbShort + j;
/*     */           
/* 127 */           this.overlap[band][a] = _in[b];
/*     */         } 
/* 129 */         this.locationPrev[band][0] = Platform.copyOfInt(this.location[band][k], (this.location[band][k]).length);
/* 130 */         this.levelPrev[band][0] = Platform.copyOfInt(this.level[band][k], (this.level[band][k]).length);
/*     */       } 
/* 132 */       System.arraycopy(this.overlap[band], 0, out[band], 0, this.lbLong);
/* 133 */       System.arraycopy(this.overlap[band], this.lbLong, this.overlap[band], 0, this.lbLong);
/*     */     }
/*     */     else {
/*     */       
/* 137 */       calculateFunctionData(this.lbLong * 2, band, winSeq, 0);
/*     */       int j;
/* 139 */       for (j = 0; j < this.lbLong * 2; j++) {
/* 140 */         _in[band * this.lbLong * 2 + j] = _in[band * this.lbLong * 2 + j] * this._function[j];
/*     */       }
/*     */       
/* 143 */       for (j = 0; j < this.lbLong; j++) {
/* 144 */         out[band][j] = this.overlap[band][j] + _in[band * this.lbLong * 2 + j];
/*     */       }
/*     */       
/* 147 */       for (j = 0; j < this.lbLong; j++) {
/* 148 */         this.overlap[band][j] = _in[band * this.lbLong * 2 + this.lbLong + j];
/*     */       }
/* 150 */       int lastBlock = winSeq.equals(ICSInfo.WindowSequence.ONLY_LONG_SEQUENCE) ? 1 : 0;
/* 151 */       this.locationPrev[band][0] = Platform.copyOfInt(this.location[band][lastBlock], (this.location[band][lastBlock]).length);
/* 152 */       this.levelPrev[band][0] = Platform.copyOfInt(this.level[band][lastBlock], (this.level[band][lastBlock]).length);
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   private void calculateFunctionData(int samples, int band, ICSInfo.WindowSequence winSeq, int blockID) {
/* 158 */     int[] locA = new int[10];
/* 159 */     float[] levA = new float[10];
/* 160 */     float[] modFunc = new float[samples];
/* 161 */     float[] buf1 = new float[samples / 2];
/* 162 */     float[] buf2 = new float[samples / 2];
/* 163 */     float[] buf3 = new float[samples / 2];
/*     */     
/* 165 */     int maxLocGain0 = 0, maxLocGain1 = 0, maxLocGain2 = 0;
/* 166 */     switch (winSeq) {
/*     */       case ONLY_LONG_SEQUENCE:
/*     */       case EIGHT_SHORT_SEQUENCE:
/* 169 */         maxLocGain0 = maxLocGain1 = samples / 2;
/* 170 */         maxLocGain2 = 0;
/*     */         break;
/*     */       case LONG_START_SEQUENCE:
/* 173 */         maxLocGain0 = samples / 2;
/* 174 */         maxLocGain1 = samples * 7 / 32;
/* 175 */         maxLocGain2 = samples / 16;
/*     */         break;
/*     */       case LONG_STOP_SEQUENCE:
/* 178 */         maxLocGain0 = samples / 16;
/* 179 */         maxLocGain1 = samples * 7 / 32;
/* 180 */         maxLocGain2 = samples / 2;
/*     */         break;
/*     */     } 
/*     */ 
/*     */ 
/*     */     
/* 186 */     calculateFMD(band, 0, true, maxLocGain0, samples, locA, levA, buf1);
/*     */ 
/*     */     
/* 189 */     int block = winSeq.equals(ICSInfo.WindowSequence.EIGHT_SHORT_SEQUENCE) ? blockID : 0;
/* 190 */     float secLevel = calculateFMD(band, block, false, maxLocGain1, samples, locA, levA, buf2);
/*     */ 
/*     */     
/* 193 */     if (winSeq.equals(ICSInfo.WindowSequence.LONG_START_SEQUENCE) || winSeq.equals(ICSInfo.WindowSequence.LONG_STOP_SEQUENCE)) {
/* 194 */       calculateFMD(band, 1, false, maxLocGain2, samples, locA, levA, buf3);
/*     */     }
/*     */ 
/*     */ 
/*     */     
/* 199 */     int flatLen = 0;
/* 200 */     if (winSeq.equals(ICSInfo.WindowSequence.LONG_STOP_SEQUENCE)) {
/* 201 */       flatLen = samples / 2 - maxLocGain0 - maxLocGain1;
/* 202 */       for (int j = 0; j < flatLen; j++) {
/* 203 */         modFunc[j] = 1.0F;
/*     */       }
/*     */     } 
/* 206 */     if (winSeq.equals(ICSInfo.WindowSequence.ONLY_LONG_SEQUENCE) || winSeq.equals(ICSInfo.WindowSequence.EIGHT_SHORT_SEQUENCE)) levA[0] = 1.0F; 
/*     */     int i;
/* 208 */     for (i = 0; i < maxLocGain0; i++) {
/* 209 */       modFunc[i + flatLen] = levA[0] * secLevel * buf1[i];
/*     */     }
/* 211 */     for (i = 0; i < maxLocGain1; i++) {
/* 212 */       modFunc[i + flatLen + maxLocGain0] = levA[0] * buf2[i];
/*     */     }
/*     */     
/* 215 */     if (winSeq.equals(ICSInfo.WindowSequence.LONG_START_SEQUENCE)) {
/* 216 */       for (i = 0; i < maxLocGain2; i++) {
/* 217 */         modFunc[i + maxLocGain0 + maxLocGain1] = buf3[i];
/*     */       }
/* 219 */       flatLen = samples / 2 - maxLocGain1 - maxLocGain2;
/* 220 */       for (i = 0; i < flatLen; i++) {
/* 221 */         modFunc[i + maxLocGain0 + maxLocGain1 + maxLocGain2] = 1.0F;
/*     */       }
/*     */     }
/* 224 */     else if (winSeq.equals(ICSInfo.WindowSequence.LONG_STOP_SEQUENCE)) {
/* 225 */       for (i = 0; i < maxLocGain2; i++) {
/* 226 */         modFunc[i + flatLen + maxLocGain0 + maxLocGain1] = buf3[i];
/*     */       }
/*     */     } 
/*     */ 
/*     */     
/* 231 */     for (i = 0; i < samples; i++) {
/* 232 */       this._function[i] = 1.0F / modFunc[i];
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private float calculateFMD(int bd, int wd, boolean prev, int maxLocGain, int samples, int[] loc, float[] lev, float[] fmd) {
/* 242 */     int[] m = new int[samples / 2];
/* 243 */     int[] lct = prev ? this.locationPrev[bd][wd] : this.location[bd][wd];
/* 244 */     int[] lvl = prev ? this.levelPrev[bd][wd] : this.level[bd][wd];
/* 245 */     int length = lct.length;
/*     */     
/*     */     int i;
/*     */     
/* 249 */     for (i = 0; i < length; i++) {
/* 250 */       loc[i + 1] = 8 * lct[i];
/* 251 */       int lngain = getGainChangePointID(lvl[i]);
/* 252 */       if (lngain < 0) { lev[i + 1] = 1.0F / (float)Math.pow(2.0D, -lngain); }
/* 253 */       else { lev[i + 1] = (float)Math.pow(2.0D, lngain); }
/*     */     
/*     */     } 
/*     */     
/* 257 */     loc[0] = 0;
/* 258 */     if (length == 0) { lev[0] = 1.0F; }
/* 259 */     else { lev[0] = lev[1]; }
/* 260 */      float secLevel = lev[0];
/*     */ 
/*     */     
/* 263 */     loc[length + 1] = maxLocGain;
/* 264 */     lev[length + 1] = 1.0F;
/*     */ 
/*     */     
/* 267 */     for (i = 0; i < maxLocGain; i++) {
/* 268 */       m[i] = 0;
/* 269 */       for (int j = 0; j <= length + 1; j++) {
/* 270 */         if (loc[j] <= i) m[i] = j;
/*     */       
/*     */       } 
/*     */     } 
/* 274 */     for (i = 0; i < maxLocGain; i++) {
/* 275 */       if (i >= loc[m[i]] && i <= loc[m[i]] + 7) { fmd[i] = interpolateGain(lev[m[i]], lev[m[i] + 1], i - loc[m[i]]); }
/* 276 */       else { fmd[i] = lev[m[i] + 1]; }
/*     */     
/*     */     } 
/* 279 */     return secLevel;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private int getGainChangePointID(int lngain) {
/* 287 */     for (int i = 0; i < 16; i++) {
/* 288 */       if (lngain == LN_GAIN[i]) return i; 
/*     */     } 
/* 290 */     return 0;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private float interpolateGain(float alev0, float alev1, int iloc) {
/* 300 */     float a0 = (float)(Math.log(alev0) / Math.log(2.0D));
/* 301 */     float a1 = (float)(Math.log(alev1) / Math.log(2.0D));
/* 302 */     return (float)Math.pow(2.0D, (((8 - iloc) * a0 + iloc * a1) / 8.0F));
/*     */   }
/*     */ }


/* Location:              C:\Users\rapha\Downloads\aurora.jar!\META-INF\jars\jcodec-0.2.5.jar!\net\sourceforge\jaad\aac\gain\GainControl.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */