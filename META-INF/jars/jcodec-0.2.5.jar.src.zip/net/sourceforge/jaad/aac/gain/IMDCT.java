/*     */ package net.sourceforge.jaad.aac.gain;
/*     */ 
/*     */ import net.sourceforge.jaad.aac.AACException;
/*     */ import net.sourceforge.jaad.aac.syntax.ICSInfo;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ class IMDCT
/*     */   implements GCConstants, IMDCTTables, Windows
/*     */ {
/*  17 */   private static final float[][] LONG_WINDOWS = new float[][] { SINE_256, KBD_256 };
/*  18 */   private static final float[][] SHORT_WINDOWS = new float[][] { SINE_32, KBD_32 }; private final int frameLen;
/*     */   private final int shortFrameLen;
/*     */   
/*     */   IMDCT(int frameLen) {
/*  22 */     this.frameLen = frameLen;
/*  23 */     this.lbLong = frameLen / 4;
/*  24 */     this.shortFrameLen = frameLen / 8;
/*  25 */     this.lbShort = this.shortFrameLen / 4;
/*  26 */     this.lbMid = (this.lbLong - this.lbShort) / 2;
/*     */   }
/*     */   private final int lbLong; private final int lbShort; private final int lbMid;
/*     */   void process(float[] _in, float[] out, int winShape, int winShapePrev, ICSInfo.WindowSequence winSeq) throws AACException {
/*  30 */     float[] buf = new float[this.frameLen];
/*     */ 
/*     */     
/*  33 */     if (winSeq.equals(ICSInfo.WindowSequence.EIGHT_SHORT_SEQUENCE)) {
/*  34 */       for (int i = 0; i < 4; i++) {
/*  35 */         for (int j = 0; j < 8; j++) {
/*  36 */           for (int k = 0; k < this.lbShort; k++) {
/*  37 */             if (i % 2 == 0) { buf[this.lbLong * i + this.lbShort * j + k] = _in[this.shortFrameLen * j + this.lbShort * i + k]; }
/*  38 */             else { buf[this.lbLong * i + this.lbShort * j + k] = _in[this.shortFrameLen * j + this.lbShort * i + this.lbShort - 1 - k]; }
/*     */           
/*     */           } 
/*     */         } 
/*     */       } 
/*     */     } else {
/*  44 */       for (int i = 0; i < 4; i++) {
/*  45 */         for (int j = 0; j < this.lbLong; j++) {
/*  46 */           if (i % 2 == 0) { buf[this.lbLong * i + j] = _in[this.lbLong * i + j]; }
/*  47 */           else { buf[this.lbLong * i + j] = _in[this.lbLong * i + this.lbLong - 1 - j]; }
/*     */         
/*     */         } 
/*     */       } 
/*     */     } 
/*  52 */     for (byte b = 0; b < 4; b++)
/*  53 */       process2(buf, out, winSeq, winShape, winShapePrev, b); 
/*     */   }
/*     */   
/*     */   private void process2(float[] _in, float[] out, ICSInfo.WindowSequence winSeq, int winShape, int winShapePrev, int band) throws AACException {
/*     */     int i;
/*  58 */     float[] bufIn = new float[this.lbLong];
/*  59 */     float[] bufOut = new float[this.lbLong * 2];
/*  60 */     float[] window = new float[this.lbLong * 2];
/*  61 */     float[] window1 = new float[this.lbShort * 2];
/*  62 */     float[] window2 = new float[this.lbShort * 2];
/*     */ 
/*     */ 
/*     */     
/*  66 */     switch (winSeq) {
/*     */       case ONLY_LONG_SEQUENCE:
/*  68 */         for (i = 0; i < this.lbLong; i++) {
/*  69 */           window[i] = LONG_WINDOWS[winShapePrev][i];
/*  70 */           window[this.lbLong * 2 - 1 - i] = LONG_WINDOWS[winShape][i];
/*     */         } 
/*     */         break;
/*     */       case EIGHT_SHORT_SEQUENCE:
/*  74 */         for (i = 0; i < this.lbShort; i++) {
/*  75 */           window1[i] = SHORT_WINDOWS[winShapePrev][i];
/*  76 */           window1[this.lbShort * 2 - 1 - i] = SHORT_WINDOWS[winShape][i];
/*  77 */           window2[i] = SHORT_WINDOWS[winShape][i];
/*  78 */           window2[this.lbShort * 2 - 1 - i] = SHORT_WINDOWS[winShape][i];
/*     */         } 
/*     */         break;
/*     */       case LONG_START_SEQUENCE:
/*  82 */         for (i = 0; i < this.lbLong; i++) {
/*  83 */           window[i] = LONG_WINDOWS[winShapePrev][i];
/*     */         }
/*  85 */         for (i = 0; i < this.lbMid; i++) {
/*  86 */           window[i + this.lbLong] = 1.0F;
/*     */         }
/*     */         
/*  89 */         for (i = 0; i < this.lbShort; i++) {
/*  90 */           window[i + this.lbMid + this.lbLong] = SHORT_WINDOWS[winShape][this.lbShort - 1 - i];
/*     */         }
/*  92 */         for (i = 0; i < this.lbMid; i++) {
/*  93 */           window[i + this.lbMid + this.lbLong + this.lbShort] = 0.0F;
/*     */         }
/*     */         break;
/*     */       case LONG_STOP_SEQUENCE:
/*  97 */         for (i = 0; i < this.lbMid; i++) {
/*  98 */           window[i] = 0.0F;
/*     */         }
/* 100 */         for (i = 0; i < this.lbShort; i++) {
/* 101 */           window[i + this.lbMid] = SHORT_WINDOWS[winShapePrev][i];
/*     */         }
/* 103 */         for (i = 0; i < this.lbMid; i++) {
/* 104 */           window[i + this.lbMid + this.lbShort] = 1.0F;
/*     */         }
/* 106 */         for (i = 0; i < this.lbLong; i++) {
/* 107 */           window[i + this.lbMid + this.lbShort + this.lbMid] = LONG_WINDOWS[winShape][this.lbLong - 1 - i];
/*     */         }
/*     */         break;
/*     */     } 
/*     */ 
/*     */     
/* 113 */     if (winSeq.equals(ICSInfo.WindowSequence.EIGHT_SHORT_SEQUENCE)) {
/*     */       
/* 115 */       for (int j = 0; j < 8; j++) {
/* 116 */         int k; for (k = 0; k < this.lbShort; k++) {
/* 117 */           bufIn[k] = _in[band * this.lbLong + j * this.lbShort + k];
/*     */         }
/* 119 */         if (j == 0) { System.arraycopy(window1, 0, window, 0, this.lbShort * 2); }
/* 120 */         else { System.arraycopy(window2, 0, window, 0, this.lbShort * 2); }
/* 121 */          imdct(bufIn, bufOut, window, this.lbShort);
/* 122 */         for (k = 0; k < this.lbShort * 2; k++) {
/* 123 */           out[band * this.lbLong * 2 + j * this.lbShort * 2 + k] = bufOut[k] / 32.0F;
/*     */         }
/*     */       } 
/*     */     } else {
/*     */       int j;
/* 128 */       for (j = 0; j < this.lbLong; j++) {
/* 129 */         bufIn[j] = _in[band * this.lbLong + j];
/*     */       }
/* 131 */       imdct(bufIn, bufOut, window, this.lbLong);
/* 132 */       for (j = 0; j < this.lbLong * 2; j++)
/* 133 */         out[band * this.lbLong * 2 + j] = bufOut[j] / 256.0F; 
/*     */     } 
/*     */   }
/*     */   
/*     */   private void imdct(float[] _in, float[] out, float[] window, int n) throws AACException {
/*     */     float[][] table, table2;
/* 139 */     int n2 = n / 2;
/*     */     
/* 141 */     if (n == 256) {
/* 142 */       table = IMDCT_TABLE_256;
/* 143 */       table2 = IMDCT_POST_TABLE_256;
/*     */     }
/* 145 */     else if (n == 32) {
/* 146 */       table = IMDCT_TABLE_32;
/* 147 */       table2 = IMDCT_POST_TABLE_32;
/*     */     } else {
/* 149 */       throw new AACException("gain control: unexpected IMDCT length");
/*     */     } 
/* 151 */     float[] tmp = new float[n];
/*     */     int i;
/* 153 */     for (i = 0; i < n2; i++) {
/* 154 */       tmp[i] = _in[2 * i];
/*     */     }
/* 156 */     for (i = n2; i < n; i++) {
/* 157 */       tmp[i] = -_in[2 * n - 1 - 2 * i];
/*     */     }
/*     */ 
/*     */     
/* 161 */     float[][] buf = new float[n2][2];
/* 162 */     for (i = 0; i < n2; i++) {
/* 163 */       buf[i][0] = table[i][0] * tmp[2 * i] - table[i][1] * tmp[2 * i + 1];
/* 164 */       buf[i][1] = table[i][0] * tmp[2 * i + 1] + table[i][1] * tmp[2 * i];
/*     */     } 
/*     */ 
/*     */     
/* 168 */     FFT.process(buf, n2);
/*     */ 
/*     */     
/* 171 */     for (i = 0; i < n2; i++) {
/* 172 */       tmp[i] = table2[i][0] * buf[i][0] + table2[i][1] * buf[n2 - 1 - i][0] + table2[i][2] * buf[i][1] + table2[i][3] * buf[n2 - 1 - i][1];
/*     */       
/* 174 */       tmp[n - 1 - i] = table2[i][2] * buf[i][0] - table2[i][3] * buf[n2 - 1 - i][0] - table2[i][0] * buf[i][1] + table2[i][1] * buf[n2 - 1 - i][1];
/*     */     } 
/*     */ 
/*     */ 
/*     */     
/* 179 */     System.arraycopy(tmp, n2, out, 0, n2);
/* 180 */     for (i = n2; i < n * 3 / 2; i++) {
/* 181 */       out[i] = -tmp[n * 3 / 2 - 1 - i];
/*     */     }
/* 183 */     for (i = n * 3 / 2; i < n * 2; i++) {
/* 184 */       out[i] = -tmp[i - n * 3 / 2];
/*     */     }
/*     */     
/* 187 */     for (i = 0; i < n; i++)
/* 188 */       out[i] = out[i] * window[i]; 
/*     */   }
/*     */ }


/* Location:              C:\Users\rapha\Downloads\aurora.jar!\META-INF\jars\jcodec-0.2.5.jar!\net\sourceforge\jaad\aac\gain\IMDCT.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */