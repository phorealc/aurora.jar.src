/*     */ package net.sourceforge.jaad.aac;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class SampleFrequency
/*     */ {
/*  15 */   public static final SampleFrequency SAMPLE_FREQUENCY_96000 = new SampleFrequency(0, 96000, new int[] { 33, 512 }, new int[] { 31, 9 });
/*     */   
/*  17 */   public static final SampleFrequency SAMPLE_FREQUENCY_88200 = new SampleFrequency(1, 88200, new int[] { 33, 512 }, new int[] { 31, 9 });
/*     */   
/*  19 */   public static final SampleFrequency SAMPLE_FREQUENCY_64000 = new SampleFrequency(2, 64000, new int[] { 38, 664 }, new int[] { 34, 10 });
/*     */   
/*  21 */   public static final SampleFrequency SAMPLE_FREQUENCY_48000 = new SampleFrequency(3, 48000, new int[] { 40, 672 }, new int[] { 40, 14 });
/*     */   
/*  23 */   public static final SampleFrequency SAMPLE_FREQUENCY_44100 = new SampleFrequency(4, 44100, new int[] { 40, 672 }, new int[] { 42, 14 });
/*     */   
/*  25 */   public static final SampleFrequency SAMPLE_FREQUENCY_32000 = new SampleFrequency(5, 32000, new int[] { 40, 672 }, new int[] { 51, 14 });
/*     */   
/*  27 */   public static final SampleFrequency SAMPLE_FREQUENCY_24000 = new SampleFrequency(6, 24000, new int[] { 41, 652 }, new int[] { 46, 14 });
/*     */   
/*  29 */   public static final SampleFrequency SAMPLE_FREQUENCY_22050 = new SampleFrequency(7, 22050, new int[] { 41, 652 }, new int[] { 46, 14 });
/*     */   
/*  31 */   public static final SampleFrequency SAMPLE_FREQUENCY_16000 = new SampleFrequency(8, 16000, new int[] { 37, 664 }, new int[] { 42, 14 });
/*     */   
/*  33 */   public static final SampleFrequency SAMPLE_FREQUENCY_12000 = new SampleFrequency(9, 12000, new int[] { 37, 664 }, new int[] { 42, 14 });
/*     */   
/*  35 */   public static final SampleFrequency SAMPLE_FREQUENCY_11025 = new SampleFrequency(10, 11025, new int[] { 37, 664 }, new int[] { 42, 14 });
/*     */   
/*  37 */   public static final SampleFrequency SAMPLE_FREQUENCY_8000 = new SampleFrequency(11, 8000, new int[] { 34, 664 }, new int[] { 39, 14 });
/*     */   
/*  39 */   public static final SampleFrequency SAMPLE_FREQUENCY_NONE = new SampleFrequency(-1, 0, new int[] { 0, 0 }, new int[] { 0, 0 });
/*     */ 
/*     */   
/*  42 */   private static final SampleFrequency[] _values = new SampleFrequency[] { SAMPLE_FREQUENCY_96000, SAMPLE_FREQUENCY_88200, SAMPLE_FREQUENCY_64000, SAMPLE_FREQUENCY_48000, SAMPLE_FREQUENCY_44100, SAMPLE_FREQUENCY_32000, SAMPLE_FREQUENCY_24000, SAMPLE_FREQUENCY_22050, SAMPLE_FREQUENCY_16000, SAMPLE_FREQUENCY_12000, SAMPLE_FREQUENCY_11025, SAMPLE_FREQUENCY_8000, SAMPLE_FREQUENCY_NONE }; private final int index;
/*     */   private final int frequency;
/*     */   private final int[] prediction;
/*     */   private final int[] maxTNS_SFB;
/*     */   
/*     */   public static SampleFrequency[] values() {
/*  48 */     return _values;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static SampleFrequency forInt(int i) {
/*     */     SampleFrequency freq;
/*  59 */     if (i >= 0 && i < 12) {
/*  60 */       freq = values()[i];
/*     */     } else {
/*  62 */       freq = SAMPLE_FREQUENCY_NONE;
/*  63 */     }  return freq;
/*     */   }
/*     */   
/*     */   public static SampleFrequency forFrequency(int i) {
/*  67 */     SampleFrequency[] all = values();
/*     */     
/*  69 */     SampleFrequency freq = null;
/*  70 */     for (int j = 0; freq == null && j < 12; j++) {
/*  71 */       if (i == (all[j]).frequency) {
/*  72 */         freq = all[j];
/*     */       }
/*     */     } 
/*  75 */     if (freq == null)
/*  76 */       freq = SAMPLE_FREQUENCY_NONE; 
/*  77 */     return freq;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private SampleFrequency(int index, int freqency, int[] prediction, int[] maxTNS_SFB) {
/*  84 */     this.index = index;
/*  85 */     this.frequency = freqency;
/*  86 */     this.prediction = prediction;
/*  87 */     this.maxTNS_SFB = maxTNS_SFB;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int getIndex() {
/*  97 */     return this.index;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int getFrequency() {
/* 107 */     return this.frequency;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int getMaximalPredictionSFB() {
/* 117 */     return this.prediction[0];
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int getPredictorCount() {
/* 127 */     return this.prediction[1];
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int getMaximalTNS_SFB(boolean shortWindow) {
/* 137 */     return this.maxTNS_SFB[shortWindow ? 1 : 0];
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String toString() {
/* 148 */     return Integer.toString(this.frequency);
/*     */   }
/*     */ }


/* Location:              C:\Users\rapha\Downloads\aurora.jar!\META-INF\jars\jcodec-0.2.5.jar!\net\sourceforge\jaad\aac\SampleFrequency.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */