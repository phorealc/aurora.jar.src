/*     */ package org.jcodec.algo;
/*     */ 
/*     */ import org.jcodec.api.NotSupportedException;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class DataConvert
/*     */ {
/*     */   public static int[] from16BE(byte[] b) {
/*  17 */     int[] result = new int[b.length >> 1];
/*  18 */     int off = 0;
/*  19 */     for (int i = 0; i < result.length; i++) {
/*  20 */       result[i] = (b[off++] & 0xFF) << 8 | b[off++] & 0xFF;
/*     */     }
/*     */     
/*  23 */     return result;
/*     */   }
/*     */   
/*     */   public static int[] from24BE(byte[] b) {
/*  27 */     int[] result = new int[b.length / 3];
/*  28 */     int off = 0;
/*  29 */     for (int i = 0; i < result.length; i++) {
/*  30 */       result[i] = (b[off++] & 0xFF) << 16 | (b[off++] & 0xFF) << 8 | b[off++] & 0xFF;
/*     */     }
/*     */     
/*  33 */     return result;
/*     */   }
/*     */   
/*     */   public static int[] from16LE(byte[] b) {
/*  37 */     int[] result = new int[b.length >> 1];
/*  38 */     int off = 0;
/*  39 */     for (int i = 0; i < result.length; i++) {
/*  40 */       result[i] = b[off++] & 0xFF | (b[off++] & 0xFF) << 8;
/*     */     }
/*     */     
/*  43 */     return result;
/*     */   }
/*     */   
/*     */   public static int[] from24LE(byte[] b) {
/*  47 */     int[] result = new int[b.length / 3];
/*  48 */     int off = 0;
/*  49 */     for (int i = 0; i < result.length; i++) {
/*  50 */       result[i] = b[off++] & 0xFF | (b[off++] & 0xFF) << 8 | (b[off++] & 0xFF) << 16;
/*     */     }
/*     */     
/*  53 */     return result;
/*     */   }
/*     */   
/*     */   public static byte[] to16BE(int[] ia) {
/*  57 */     byte[] result = new byte[ia.length << 1];
/*  58 */     int off = 0;
/*  59 */     for (int i = 0; i < ia.length; i++) {
/*  60 */       result[off++] = (byte)(ia[i] >> 8 & 0xFF);
/*  61 */       result[off++] = (byte)(ia[i] & 0xFF);
/*     */     } 
/*     */     
/*  64 */     return result;
/*     */   }
/*     */   
/*     */   public static byte[] to24BE(int[] ia) {
/*  68 */     byte[] result = new byte[ia.length * 3];
/*  69 */     int off = 0;
/*  70 */     for (int i = 0; i < ia.length; i++) {
/*  71 */       result[off++] = (byte)(ia[i] >> 16 & 0xFF);
/*  72 */       result[off++] = (byte)(ia[i] >> 8 & 0xFF);
/*  73 */       result[off++] = (byte)(ia[i] & 0xFF);
/*     */     } 
/*     */     
/*  76 */     return result;
/*     */   }
/*     */   
/*     */   public static byte[] to16LE(int[] ia) {
/*  80 */     byte[] result = new byte[ia.length << 1];
/*  81 */     int off = 0;
/*  82 */     for (int i = 0; i < ia.length; i++) {
/*  83 */       result[off++] = (byte)(ia[i] & 0xFF);
/*  84 */       result[off++] = (byte)(ia[i] >> 8 & 0xFF);
/*     */     } 
/*     */     
/*  87 */     return result;
/*     */   }
/*     */   
/*     */   public static byte[] to24LE(int[] ia) {
/*  91 */     byte[] result = new byte[ia.length * 3];
/*  92 */     int off = 0;
/*  93 */     for (int i = 0; i < ia.length; i++) {
/*  94 */       result[off++] = (byte)(ia[i] & 0xFF);
/*  95 */       result[off++] = (byte)(ia[i] >> 8 & 0xFF);
/*  96 */       result[off++] = (byte)(ia[i] >> 16 & 0xFF);
/*     */     } 
/*     */     
/*  99 */     return result;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static int[] fromByte(byte[] b, int depth, boolean isBe) {
/* 116 */     if (depth == 24) {
/* 117 */       if (isBe) {
/* 118 */         return from24BE(b);
/*     */       }
/* 120 */       return from24LE(b);
/* 121 */     }  if (depth == 16) {
/* 122 */       if (isBe) {
/* 123 */         return from16BE(b);
/*     */       }
/* 125 */       return from16LE(b);
/* 126 */     }  throw new NotSupportedException("Conversion from " + depth + "bit " + (isBe ? "big endian" : "little endian") + " is not supported.");
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static byte[] toByte(int[] ia, int depth, boolean isBe) {
/* 144 */     if (depth == 24) {
/* 145 */       if (isBe) {
/* 146 */         return to24BE(ia);
/*     */       }
/* 148 */       return to24LE(ia);
/* 149 */     }  if (depth == 16) {
/* 150 */       if (isBe) {
/* 151 */         return to16BE(ia);
/*     */       }
/* 153 */       return to16LE(ia);
/* 154 */     }  throw new NotSupportedException("Conversion to " + depth + "bit " + (isBe ? "big endian" : "little endian") + " is not supported.");
/*     */   }
/*     */ }


/* Location:              C:\Users\rapha\Downloads\aurora.jar!\META-INF\jars\jcodec-0.2.5.jar!\org\jcodec\algo\DataConvert.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */