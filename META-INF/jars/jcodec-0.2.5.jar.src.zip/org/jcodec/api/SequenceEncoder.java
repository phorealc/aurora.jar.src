/*     */ package org.jcodec.api;
/*     */ 
/*     */ import java.io.File;
/*     */ import java.io.IOException;
/*     */ import org.jcodec.api.transcode.PixelStore;
/*     */ import org.jcodec.api.transcode.PixelStoreImpl;
/*     */ import org.jcodec.api.transcode.Sink;
/*     */ import org.jcodec.api.transcode.SinkImpl;
/*     */ import org.jcodec.api.transcode.VideoFrameWithPacket;
/*     */ import org.jcodec.common.Codec;
/*     */ import org.jcodec.common.Format;
/*     */ import org.jcodec.common.io.NIOUtils;
/*     */ import org.jcodec.common.io.SeekableByteChannel;
/*     */ import org.jcodec.common.model.ColorSpace;
/*     */ import org.jcodec.common.model.Packet;
/*     */ import org.jcodec.common.model.Picture;
/*     */ import org.jcodec.common.model.Rational;
/*     */ import org.jcodec.scale.ColorUtil;
/*     */ import org.jcodec.scale.Transform;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class SequenceEncoder
/*     */ {
/*     */   private Transform transform;
/*     */   private int frameNo;
/*     */   private int timestamp;
/*     */   private Rational fps;
/*     */   private Sink sink;
/*     */   private PixelStore pixelStore;
/*     */   
/*     */   public static SequenceEncoder createSequenceEncoder(File out, int fps) throws IOException {
/*  45 */     return new SequenceEncoder((SeekableByteChannel)NIOUtils.writableChannel(out), Rational.R(fps, 1), Format.MOV, Codec.H264, null);
/*     */   }
/*     */   
/*     */   public static SequenceEncoder create25Fps(File out) throws IOException {
/*  49 */     return new SequenceEncoder((SeekableByteChannel)NIOUtils.writableChannel(out), Rational.R(25, 1), Format.MOV, Codec.H264, null);
/*     */   }
/*     */   
/*     */   public static SequenceEncoder create30Fps(File out) throws IOException {
/*  53 */     return new SequenceEncoder((SeekableByteChannel)NIOUtils.writableChannel(out), Rational.R(30, 1), Format.MOV, Codec.H264, null);
/*     */   }
/*     */   
/*     */   public static SequenceEncoder create2997Fps(File out) throws IOException {
/*  57 */     return new SequenceEncoder((SeekableByteChannel)NIOUtils.writableChannel(out), Rational.R(30000, 1001), Format.MOV, Codec.H264, null);
/*     */   }
/*     */   
/*     */   public static SequenceEncoder create24Fps(File out) throws IOException {
/*  61 */     return new SequenceEncoder((SeekableByteChannel)NIOUtils.writableChannel(out), Rational.R(24, 1), Format.MOV, Codec.H264, null);
/*     */   }
/*     */   
/*     */   public static SequenceEncoder createWithFps(SeekableByteChannel out, Rational fps) throws IOException {
/*  65 */     return new SequenceEncoder(out, fps, Format.MOV, Codec.H264, null);
/*     */   }
/*     */ 
/*     */   
/*     */   public SequenceEncoder(SeekableByteChannel out, Rational fps, Format outputFormat, Codec outputVideoCodec, Codec outputAudioCodec) throws IOException {
/*  70 */     this.fps = fps;
/*     */     
/*  72 */     this.sink = (Sink)SinkImpl.createWithStream(out, outputFormat, outputVideoCodec, outputAudioCodec);
/*  73 */     this.sink.init();
/*     */     
/*  75 */     if (this.sink.getInputColor() != null) {
/*  76 */       this.transform = ColorUtil.getTransform(ColorSpace.RGB, this.sink.getInputColor());
/*     */     }
/*  78 */     this.pixelStore = (PixelStore)new PixelStoreImpl();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void encodeNativeFrame(Picture pic) throws IOException {
/*     */     PixelStore.LoanerPicture toEncode;
/*  88 */     if (pic.getColor() != ColorSpace.RGB) {
/*  89 */       throw new IllegalArgumentException("The input images is expected in RGB color.");
/*     */     }
/*  91 */     ColorSpace sinkColor = this.sink.getInputColor();
/*     */     
/*  93 */     if (sinkColor != null) {
/*  94 */       toEncode = this.pixelStore.getPicture(pic.getWidth(), pic.getHeight(), sinkColor);
/*  95 */       this.transform.transform(pic, toEncode.getPicture());
/*     */     } else {
/*  97 */       toEncode = new PixelStore.LoanerPicture(pic, 0);
/*     */     } 
/*     */     
/* 100 */     Packet pkt = Packet.createPacket(null, this.timestamp, this.fps.getNum(), this.fps.getDen(), this.frameNo, Packet.FrameType.KEY, null);
/* 101 */     this.sink.outputVideoFrame(new VideoFrameWithPacket(pkt, toEncode));
/*     */     
/* 103 */     if (sinkColor != null) {
/* 104 */       this.pixelStore.putBack(toEncode);
/*     */     }
/* 106 */     this.timestamp += this.fps.getDen();
/* 107 */     this.frameNo++;
/*     */   }
/*     */   
/*     */   public void finish() throws IOException {
/* 111 */     this.sink.finish();
/*     */   }
/*     */ }


/* Location:              C:\Users\rapha\Downloads\aurora.jar!\META-INF\jars\jcodec-0.2.5.jar!\org\jcodec\api\SequenceEncoder.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */