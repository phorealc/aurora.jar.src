/*    */ package org.jcodec.api;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class JCodecException
/*    */   extends Exception
/*    */ {
/*    */   public JCodecException(String arg0) {
/* 13 */     super(arg0);
/*    */   }
/*    */ }


/* Location:              C:\Users\rapha\Downloads\aurora.jar!\META-INF\jars\jcodec-0.2.5.jar!\org\jcodec\api\JCodecException.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */