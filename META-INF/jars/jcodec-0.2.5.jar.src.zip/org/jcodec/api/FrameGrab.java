/*     */ package org.jcodec.api;
/*     */ 
/*     */ import java.io.Closeable;
/*     */ import java.io.File;
/*     */ import java.io.IOException;
/*     */ import java.nio.ByteBuffer;
/*     */ import org.jcodec.api.specific.AVCMP4Adaptor;
/*     */ import org.jcodec.api.specific.ContainerAdaptor;
/*     */ import org.jcodec.common.Codec;
/*     */ import org.jcodec.common.DemuxerTrackMeta;
/*     */ import org.jcodec.common.Format;
/*     */ import org.jcodec.common.JCodecUtil;
/*     */ import org.jcodec.common.SeekableDemuxerTrack;
/*     */ import org.jcodec.common.io.FileChannelWrapper;
/*     */ import org.jcodec.common.io.NIOUtils;
/*     */ import org.jcodec.common.io.SeekableByteChannel;
/*     */ import org.jcodec.common.model.Packet;
/*     */ import org.jcodec.common.model.Picture;
/*     */ import org.jcodec.containers.mp4.demuxer.MP4Demuxer;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class FrameGrab
/*     */ {
/*     */   private SeekableDemuxerTrack videoTrack;
/*     */   private ContainerAdaptor decoder;
/*     */   private final ThreadLocal<byte[][]> buffers;
/*     */   
/*     */   public static FrameGrab createFrameGrab(SeekableByteChannel _in) throws IOException, JCodecException {
/*     */     SeekableDemuxerTrack videoTrack_;
/*  50 */     ByteBuffer header = ByteBuffer.allocate(65536);
/*  51 */     _in.read(header);
/*  52 */     header.flip();
/*  53 */     Format detectFormat = JCodecUtil.detectFormatBuffer(header);
/*  54 */     if (detectFormat == null) {
/*  55 */       throw new UnsupportedFormatException("Could not detect the format of the input video.");
/*     */     }
/*     */ 
/*     */     
/*  59 */     if (Format.MOV == detectFormat)
/*  60 */     { MP4Demuxer d1 = MP4Demuxer.createMP4Demuxer(_in);
/*  61 */       videoTrack_ = (SeekableDemuxerTrack)d1.getVideoTrack(); }
/*  62 */     else { if (Format.MPEG_PS == detectFormat)
/*  63 */         throw new UnsupportedFormatException("MPEG PS is temporarily unsupported."); 
/*  64 */       if (Format.MPEG_TS == detectFormat) {
/*  65 */         throw new UnsupportedFormatException("MPEG TS is temporarily unsupported.");
/*     */       }
/*  67 */       throw new UnsupportedFormatException("Container format is not supported by JCodec"); }
/*     */     
/*  69 */     FrameGrab fg = new FrameGrab(videoTrack_, detectDecoder(videoTrack_));
/*  70 */     fg.decodeLeadingFrames();
/*  71 */     return fg;
/*     */   }
/*     */   
/*     */   public FrameGrab(SeekableDemuxerTrack videoTrack, ContainerAdaptor decoder) {
/*  75 */     this.videoTrack = videoTrack;
/*  76 */     this.decoder = decoder;
/*  77 */     this.buffers = (ThreadLocal)new ThreadLocal<byte>();
/*     */   }
/*     */   
/*     */   private SeekableDemuxerTrack sdt() throws JCodecException {
/*  81 */     if (!(this.videoTrack instanceof SeekableDemuxerTrack)) {
/*  82 */       throw new JCodecException("Not a seekable track");
/*     */     }
/*  84 */     return this.videoTrack;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public FrameGrab seekToSecondPrecise(double second) throws IOException, JCodecException {
/* 102 */     sdt().seek(second);
/* 103 */     decodeLeadingFrames();
/* 104 */     return this;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public FrameGrab seekToFramePrecise(int frameNumber) throws IOException, JCodecException {
/* 122 */     sdt().gotoFrame(frameNumber);
/* 123 */     decodeLeadingFrames();
/* 124 */     return this;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public FrameGrab seekToSecondSloppy(double second) throws IOException, JCodecException {
/* 142 */     sdt().seek(second);
/* 143 */     goToPrevKeyframe();
/* 144 */     return this;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public FrameGrab seekToFrameSloppy(int frameNumber) throws IOException, JCodecException {
/* 162 */     sdt().gotoFrame(frameNumber);
/* 163 */     goToPrevKeyframe();
/* 164 */     return this;
/*     */   }
/*     */   
/*     */   private void goToPrevKeyframe() throws IOException, JCodecException {
/* 168 */     sdt().gotoFrame(detectKeyFrame((int)sdt().getCurFrame()));
/*     */   }
/*     */   
/*     */   private void decodeLeadingFrames() throws IOException, JCodecException {
/* 172 */     SeekableDemuxerTrack sdt = sdt();
/*     */     
/* 174 */     int curFrame = (int)sdt.getCurFrame();
/* 175 */     int keyFrame = detectKeyFrame(curFrame);
/* 176 */     sdt.gotoFrame(keyFrame);
/*     */     
/* 178 */     Packet frame = sdt.nextFrame();
/* 179 */     if (this.decoder == null) {
/* 180 */       this.decoder = detectDecoder(sdt);
/*     */     }
/* 182 */     while (frame.getFrameNo() < curFrame) {
/* 183 */       this.decoder.decodeFrame(frame, getBuffer());
/* 184 */       frame = sdt.nextFrame();
/*     */     } 
/* 186 */     sdt.gotoFrame(curFrame);
/*     */   }
/*     */   
/*     */   private byte[][] getBuffer() {
/* 190 */     byte[][] buf = this.buffers.get();
/* 191 */     if (buf == null) {
/* 192 */       buf = this.decoder.allocatePicture();
/* 193 */       this.buffers.set(buf);
/*     */     } 
/* 195 */     return buf;
/*     */   }
/*     */   
/*     */   private int detectKeyFrame(int start) throws IOException {
/* 199 */     int[] seekFrames = this.videoTrack.getMeta().getSeekFrames();
/* 200 */     if (seekFrames == null)
/* 201 */       return start; 
/* 202 */     int prev = seekFrames[0];
/* 203 */     for (int i = 1; i < seekFrames.length && 
/* 204 */       seekFrames[i] <= start; i++)
/*     */     {
/* 206 */       prev = seekFrames[i];
/*     */     }
/* 208 */     return prev;
/*     */   }
/*     */   
/*     */   private static ContainerAdaptor detectDecoder(SeekableDemuxerTrack videoTrack) throws JCodecException {
/* 212 */     DemuxerTrackMeta meta = videoTrack.getMeta();
/* 213 */     if (Codec.H264 == meta.getCodec()) {
/* 214 */       return (ContainerAdaptor)new AVCMP4Adaptor(meta);
/*     */     }
/* 216 */     throw new UnsupportedFormatException("Codec is not supported");
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public PictureWithMetadata getNativeFrameWithMetadata() throws IOException {
/* 227 */     Packet frame = this.videoTrack.nextFrame();
/* 228 */     if (frame == null) {
/* 229 */       return null;
/*     */     }
/* 231 */     Picture picture = this.decoder.decodeFrame(frame, getBuffer());
/* 232 */     return new PictureWithMetadata(picture, frame.getPtsD(), frame.getDurationD(), this.videoTrack.getMeta().getOrientation());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Picture getNativeFrame() throws IOException {
/* 242 */     Packet frame = this.videoTrack.nextFrame();
/* 243 */     if (frame == null) {
/* 244 */       return null;
/*     */     }
/* 246 */     return this.decoder.decodeFrame(frame, getBuffer());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Picture getFrameAtSec(File file, double second) throws IOException, JCodecException {
/* 259 */     FileChannelWrapper ch = null;
/*     */     try {
/* 261 */       ch = NIOUtils.readableChannel(file);
/* 262 */       return createFrameGrab((SeekableByteChannel)ch).seekToSecondPrecise(second).getNativeFrame();
/*     */     } finally {
/* 264 */       NIOUtils.closeQuietly((Closeable)ch);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Picture getFrameFromChannelAtSec(SeekableByteChannel file, double second) throws JCodecException, IOException {
/* 279 */     return createFrameGrab(file).seekToSecondPrecise(second).getNativeFrame();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Picture getFrameFromFile(File file, int frameNumber) throws IOException, JCodecException {
/* 292 */     FileChannelWrapper ch = null;
/*     */     try {
/* 294 */       ch = NIOUtils.readableChannel(file);
/* 295 */       return createFrameGrab((SeekableByteChannel)ch).seekToFramePrecise(frameNumber).getNativeFrame();
/*     */     } finally {
/* 297 */       NIOUtils.closeQuietly((Closeable)ch);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Picture getFrameFromChannel(SeekableByteChannel file, int frameNumber) throws JCodecException, IOException {
/* 312 */     return createFrameGrab(file).seekToFramePrecise(frameNumber).getNativeFrame();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Picture getNativeFrameAtFrame(SeekableDemuxerTrack vt, ContainerAdaptor decoder, int frameNumber) throws IOException, JCodecException {
/* 327 */     return (new FrameGrab(vt, decoder)).seekToFramePrecise(frameNumber).getNativeFrame();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Picture getNativeFrameAtSec(SeekableDemuxerTrack vt, ContainerAdaptor decoder, double second) throws IOException, JCodecException {
/* 342 */     return (new FrameGrab(vt, decoder)).seekToSecondPrecise(second).getNativeFrame();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Picture getNativeFrameSloppy(SeekableDemuxerTrack vt, ContainerAdaptor decoder, int frameNumber) throws IOException, JCodecException {
/* 358 */     return (new FrameGrab(vt, decoder)).seekToFrameSloppy(frameNumber).getNativeFrame();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Picture getNativeFrameAtSecSloppy(SeekableDemuxerTrack vt, ContainerAdaptor decoder, double second) throws IOException, JCodecException {
/* 374 */     return (new FrameGrab(vt, decoder)).seekToSecondSloppy(second).getNativeFrame();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public MediaInfo getMediaInfo() {
/* 383 */     return this.decoder.getMediaInfo();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public SeekableDemuxerTrack getVideoTrack() {
/* 390 */     return this.videoTrack;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ContainerAdaptor getDecoder() {
/* 397 */     return this.decoder;
/*     */   }
/*     */ }


/* Location:              C:\Users\rapha\Downloads\aurora.jar!\META-INF\jars\jcodec-0.2.5.jar!\org\jcodec\api\FrameGrab.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */