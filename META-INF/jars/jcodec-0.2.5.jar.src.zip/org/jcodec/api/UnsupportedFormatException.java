/*    */ package org.jcodec.api;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class UnsupportedFormatException
/*    */   extends JCodecException
/*    */ {
/*    */   public UnsupportedFormatException(String arg0) {
/* 13 */     super(arg0);
/*    */   }
/*    */ }


/* Location:              C:\Users\rapha\Downloads\aurora.jar!\META-INF\jars\jcodec-0.2.5.jar!\org\jcodec\api\UnsupportedFormatException.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */