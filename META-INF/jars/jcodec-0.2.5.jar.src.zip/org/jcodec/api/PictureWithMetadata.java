/*    */ package org.jcodec.api;
/*    */ 
/*    */ import org.jcodec.common.DemuxerTrackMeta;
/*    */ import org.jcodec.common.model.Picture;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class PictureWithMetadata
/*    */ {
/*    */   private Picture picture;
/*    */   private double timestamp;
/*    */   private double duration;
/*    */   private DemuxerTrackMeta.Orientation orientation;
/*    */   
/*    */   public static PictureWithMetadata createPictureWithMetadata(Picture picture, double timestamp, double duration) {
/* 20 */     return new PictureWithMetadata(picture, timestamp, duration, DemuxerTrackMeta.Orientation.D_0);
/*    */   }
/*    */   
/*    */   public PictureWithMetadata(Picture picture, double timestamp, double duration, DemuxerTrackMeta.Orientation orientation) {
/* 24 */     this.picture = picture;
/* 25 */     this.timestamp = timestamp;
/* 26 */     this.duration = duration;
/* 27 */     this.orientation = orientation;
/*    */   }
/*    */   
/*    */   public Picture getPicture() {
/* 31 */     return this.picture;
/*    */   }
/*    */   
/*    */   public double getTimestamp() {
/* 35 */     return this.timestamp;
/*    */   }
/*    */   
/*    */   public double getDuration() {
/* 39 */     return this.duration;
/*    */   }
/*    */   
/*    */   public DemuxerTrackMeta.Orientation getOrientation() {
/* 43 */     return this.orientation;
/*    */   }
/*    */ }


/* Location:              C:\Users\rapha\Downloads\aurora.jar!\META-INF\jars\jcodec-0.2.5.jar!\org\jcodec\api\PictureWithMetadata.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */