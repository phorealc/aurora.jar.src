/*    */ package org.jcodec.api.transcode;
/*    */ 
/*    */ import org.jcodec.common.model.Packet;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class VideoFrameWithPacket
/*    */   implements Comparable<VideoFrameWithPacket>
/*    */ {
/*    */   private Packet packet;
/*    */   private PixelStore.LoanerPicture frame;
/*    */   
/*    */   public VideoFrameWithPacket(Packet inFrame, PixelStore.LoanerPicture dec2) {
/* 17 */     this.packet = inFrame;
/* 18 */     this.frame = dec2;
/*    */   }
/*    */ 
/*    */   
/*    */   public int compareTo(VideoFrameWithPacket arg) {
/* 23 */     if (arg == null) {
/* 24 */       return -1;
/*    */     }
/* 26 */     long pts1 = this.packet.getPts();
/* 27 */     long pts2 = arg.packet.getPts();
/* 28 */     return (pts1 > pts2) ? 1 : ((pts1 == pts2) ? 0 : -1);
/*    */   }
/*    */ 
/*    */   
/*    */   public Packet getPacket() {
/* 33 */     return this.packet;
/*    */   }
/*    */   
/*    */   public PixelStore.LoanerPicture getFrame() {
/* 37 */     return this.frame;
/*    */   }
/*    */ }


/* Location:              C:\Users\rapha\Downloads\aurora.jar!\META-INF\jars\jcodec-0.2.5.jar!\org\jcodec\api\transcode\VideoFrameWithPacket.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */