/*   */ package org.jcodec.api.transcode;
/*   */ 
/*   */ public enum Options {
/* 4 */   PROFILE, INTERLACED, DOWNSCALE;
/*   */ }


/* Location:              C:\Users\rapha\Downloads\aurora.jar!\META-INF\jars\jcodec-0.2.5.jar!\org\jcodec\api\transcode\Options.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */