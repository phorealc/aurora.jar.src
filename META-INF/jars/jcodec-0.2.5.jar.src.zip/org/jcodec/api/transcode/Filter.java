package org.jcodec.api.transcode;

import org.jcodec.common.model.ColorSpace;
import org.jcodec.common.model.Picture;

public interface Filter {
  PixelStore.LoanerPicture filter(Picture paramPicture, PixelStore paramPixelStore);
  
  ColorSpace getInputColor();
  
  ColorSpace getOutputColor();
}


/* Location:              C:\Users\rapha\Downloads\aurora.jar!\META-INF\jars\jcodec-0.2.5.jar!\org\jcodec\api\transcode\Filter.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */