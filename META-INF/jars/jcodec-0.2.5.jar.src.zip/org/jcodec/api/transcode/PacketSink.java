package org.jcodec.api.transcode;

import java.io.IOException;
import org.jcodec.common.AudioCodecMeta;
import org.jcodec.common.VideoCodecMeta;
import org.jcodec.common.model.Packet;

public interface PacketSink {
  void outputVideoPacket(Packet paramPacket, VideoCodecMeta paramVideoCodecMeta) throws IOException;
  
  void outputAudioPacket(Packet paramPacket, AudioCodecMeta paramAudioCodecMeta) throws IOException;
}


/* Location:              C:\Users\rapha\Downloads\aurora.jar!\META-INF\jars\jcodec-0.2.5.jar!\org\jcodec\api\transcode\PacketSink.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */