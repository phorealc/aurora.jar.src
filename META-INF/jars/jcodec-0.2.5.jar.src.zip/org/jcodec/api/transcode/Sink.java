package org.jcodec.api.transcode;

import java.io.IOException;
import org.jcodec.common.model.ColorSpace;

public interface Sink {
  void init() throws IOException;
  
  void outputVideoFrame(VideoFrameWithPacket paramVideoFrameWithPacket) throws IOException;
  
  void outputAudioFrame(AudioFrameWithPacket paramAudioFrameWithPacket) throws IOException;
  
  void finish() throws IOException;
  
  ColorSpace getInputColor();
  
  void setOption(Options paramOptions, Object paramObject);
  
  boolean isVideo();
  
  boolean isAudio();
}


/* Location:              C:\Users\rapha\Downloads\aurora.jar!\META-INF\jars\jcodec-0.2.5.jar!\org\jcodec\api\transcode\Sink.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */