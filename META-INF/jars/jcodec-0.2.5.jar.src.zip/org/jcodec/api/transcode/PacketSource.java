package org.jcodec.api.transcode;

import java.io.IOException;
import org.jcodec.common.model.Packet;

public interface PacketSource {
  Packet inputVideoPacket() throws IOException;
  
  Packet inputAudioPacket() throws IOException;
}


/* Location:              C:\Users\rapha\Downloads\aurora.jar!\META-INF\jars\jcodec-0.2.5.jar!\org\jcodec\api\transcode\PacketSource.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */