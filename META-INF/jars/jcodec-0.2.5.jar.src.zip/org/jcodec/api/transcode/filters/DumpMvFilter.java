/*    */ package org.jcodec.api.transcode.filters;
/*    */ 
/*    */ import org.jcodec.api.transcode.Filter;
/*    */ import org.jcodec.api.transcode.PixelStore;
/*    */ import org.jcodec.codecs.h264.H264Utils;
/*    */ import org.jcodec.codecs.h264.io.model.Frame;
/*    */ import org.jcodec.codecs.h264.io.model.SliceType;
/*    */ import org.jcodec.common.model.ColorSpace;
/*    */ import org.jcodec.common.model.Picture;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class DumpMvFilter
/*    */   implements Filter
/*    */ {
/*    */   private boolean js;
/*    */   
/*    */   public DumpMvFilter(boolean js) {
/* 20 */     this.js = js;
/*    */   }
/*    */ 
/*    */   
/*    */   public PixelStore.LoanerPicture filter(Picture picture, PixelStore pixelStore) {
/* 25 */     Frame dec = (Frame)picture;
/* 26 */     if (!this.js) {
/* 27 */       dumpMvTxt(dec);
/*    */     } else {
/* 29 */       dumpMvJs(dec);
/* 30 */     }  return null;
/*    */   }
/*    */   
/*    */   private void dumpMvTxt(Frame dec) {
/* 34 */     System.err.println("FRAME ================================================================");
/* 35 */     if (dec.getFrameType() == SliceType.I)
/*    */       return; 
/* 37 */     H264Utils.MvList2D mvs = dec.getMvs();
/* 38 */     for (int i = 0; i < 2; i++) {
/*    */       
/* 40 */       System.err.println(((i == 0) ? "BCK" : "FWD") + " ===========================================================================");
/*    */       
/* 42 */       for (int blkY = 0; blkY < mvs.getHeight(); blkY++) {
/* 43 */         StringBuilder line0 = new StringBuilder();
/* 44 */         StringBuilder line1 = new StringBuilder();
/* 45 */         StringBuilder line2 = new StringBuilder();
/* 46 */         StringBuilder line3 = new StringBuilder();
/* 47 */         line0.append("+");
/* 48 */         line1.append("|");
/* 49 */         line2.append("|");
/* 50 */         line3.append("|");
/* 51 */         for (int blkX = 0; blkX < mvs.getWidth(); blkX++) {
/* 52 */           line0.append("------+");
/* 53 */           line1.append(String.format("%6d|", new Object[] { Integer.valueOf(H264Utils.Mv.mvX(mvs.getMv(blkX, blkY, i))) }));
/* 54 */           line2.append(String.format("%6d|", new Object[] { Integer.valueOf(H264Utils.Mv.mvY(mvs.getMv(blkX, blkY, i))) }));
/* 55 */           line3.append(String.format("    %2d|", new Object[] { Integer.valueOf(H264Utils.Mv.mvRef(mvs.getMv(blkX, blkY, i))) }));
/*    */         } 
/* 57 */         System.err.println(line0.toString());
/* 58 */         System.err.println(line1.toString());
/* 59 */         System.err.println(line2.toString());
/* 60 */         System.err.println(line3.toString());
/*    */       } 
/* 62 */       if (dec.getFrameType() != SliceType.B)
/*    */         break; 
/*    */     } 
/*    */   }
/*    */   
/*    */   private void dumpMvJs(Frame dec) {
/* 68 */     System.err.println("{");
/* 69 */     if (dec.getFrameType() == SliceType.I)
/*    */       return; 
/* 71 */     H264Utils.MvList2D mvs = dec.getMvs();
/* 72 */     for (int i = 0; i < 2; i++) {
/*    */       
/* 74 */       System.err.println(((i == 0) ? "backRef" : "forwardRef") + ": [");
/* 75 */       for (int blkY = 0; blkY < mvs.getHeight(); blkY++) {
/* 76 */         for (int blkX = 0; blkX < mvs.getWidth(); blkX++) {
/* 77 */           System.err.println("{x: " + blkX + ", y: " + blkY + ", mx: " + H264Utils.Mv.mvX(mvs.getMv(blkX, blkY, i)) + ", my: " + 
/* 78 */               H264Utils.Mv.mvY(mvs.getMv(blkX, blkY, i)) + ", ridx:" + H264Utils.Mv.mvRef(mvs.getMv(blkX, blkY, i)) + "},");
/*    */         }
/*    */       } 
/*    */       
/* 82 */       System.err.println("],");
/* 83 */       if (dec.getFrameType() != SliceType.B)
/*    */         break; 
/*    */     } 
/* 86 */     System.err.println("}");
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public ColorSpace getInputColor() {
/* 92 */     return null;
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public ColorSpace getOutputColor() {
/* 98 */     return null;
/*    */   }
/*    */ }


/* Location:              C:\Users\rapha\Downloads\aurora.jar!\META-INF\jars\jcodec-0.2.5.jar!\org\jcodec\api\transcode\filters\DumpMvFilter.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */