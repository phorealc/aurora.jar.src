/*    */ package org.jcodec.api.transcode.filters;
/*    */ 
/*    */ import org.jcodec.api.transcode.Filter;
/*    */ import org.jcodec.api.transcode.PixelStore;
/*    */ import org.jcodec.common.model.ColorSpace;
/*    */ import org.jcodec.common.model.Picture;
/*    */ import org.jcodec.common.model.Size;
/*    */ import org.jcodec.scale.BaseResampler;
/*    */ import org.jcodec.scale.LanczosResampler;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class ScaleFilter
/*    */   implements Filter
/*    */ {
/*    */   private BaseResampler resampler;
/*    */   private ColorSpace currentColor;
/*    */   private Size currentSize;
/*    */   private Size targetSize;
/*    */   private int width;
/*    */   private int height;
/*    */   
/*    */   public ScaleFilter(int width, int height) {
/* 30 */     this.width = width;
/* 31 */     this.height = height;
/*    */   }
/*    */   
/*    */   public Size getTarget() {
/* 35 */     return new Size(this.width, this.height);
/*    */   }
/*    */ 
/*    */   
/*    */   public PixelStore.LoanerPicture filter(Picture picture, PixelStore store) {
/* 40 */     Size pictureSize = picture.getSize();
/* 41 */     if (this.resampler == null || this.currentColor != picture.getColor() || !pictureSize.equals(this.currentSize)) {
/* 42 */       this.currentColor = picture.getColor();
/* 43 */       this.currentSize = picture.getSize();
/* 44 */       this.targetSize = new Size(this.width & this.currentColor.getWidthMask(), this.height & this.currentColor.getHeightMask());
/* 45 */       this.resampler = (BaseResampler)new LanczosResampler(this.currentSize, this.targetSize);
/*    */     } 
/*    */     
/* 48 */     PixelStore.LoanerPicture dest = store.getPicture(this.targetSize.getWidth(), this.targetSize.getHeight(), this.currentColor);
/*    */     
/* 50 */     this.resampler.resample(picture, dest.getPicture());
/*    */     
/* 52 */     return dest;
/*    */   }
/*    */ 
/*    */   
/*    */   public ColorSpace getInputColor() {
/* 57 */     return ColorSpace.ANY_PLANAR;
/*    */   }
/*    */ 
/*    */   
/*    */   public ColorSpace getOutputColor() {
/* 62 */     return ColorSpace.SAME;
/*    */   }
/*    */ }


/* Location:              C:\Users\rapha\Downloads\aurora.jar!\META-INF\jars\jcodec-0.2.5.jar!\org\jcodec\api\transcode\filters\ScaleFilter.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */