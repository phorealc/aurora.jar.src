/*    */ package org.jcodec.api.transcode.filters;
/*    */ 
/*    */ import org.jcodec.api.transcode.Filter;
/*    */ import org.jcodec.api.transcode.PixelStore;
/*    */ import org.jcodec.common.logging.Logger;
/*    */ import org.jcodec.common.model.ColorSpace;
/*    */ import org.jcodec.common.model.Picture;
/*    */ import org.jcodec.scale.ColorUtil;
/*    */ import org.jcodec.scale.Transform;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class ColorTransformFilter
/*    */   implements Filter
/*    */ {
/*    */   private Transform transform;
/*    */   private ColorSpace outputColor;
/*    */   
/*    */   public ColorTransformFilter(ColorSpace outputColor) {
/* 25 */     this.outputColor = outputColor;
/*    */   }
/*    */ 
/*    */   
/*    */   public PixelStore.LoanerPicture filter(Picture picture, PixelStore store) {
/* 30 */     if (this.transform == null) {
/* 31 */       this.transform = ColorUtil.getTransform(picture.getColor(), this.outputColor);
/* 32 */       Logger.debug("Creating transform: " + this.transform);
/*    */     } 
/* 34 */     PixelStore.LoanerPicture outFrame = store.getPicture(picture.getWidth(), picture.getHeight(), this.outputColor);
/* 35 */     outFrame.getPicture().setCrop(picture.getCrop());
/* 36 */     this.transform.transform(picture, outFrame.getPicture());
/* 37 */     return outFrame;
/*    */   }
/*    */ 
/*    */   
/*    */   public ColorSpace getInputColor() {
/* 42 */     return ColorSpace.ANY_PLANAR;
/*    */   }
/*    */ 
/*    */   
/*    */   public ColorSpace getOutputColor() {
/* 47 */     return this.outputColor;
/*    */   }
/*    */ }


/* Location:              C:\Users\rapha\Downloads\aurora.jar!\META-INF\jars\jcodec-0.2.5.jar!\org\jcodec\api\transcode\filters\ColorTransformFilter.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */