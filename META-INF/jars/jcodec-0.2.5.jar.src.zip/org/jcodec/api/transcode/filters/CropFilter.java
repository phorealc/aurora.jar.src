/*    */ package org.jcodec.api.transcode.filters;
/*    */ 
/*    */ import org.jcodec.api.transcode.Filter;
/*    */ import org.jcodec.api.transcode.PixelStore;
/*    */ import org.jcodec.common.model.ColorSpace;
/*    */ import org.jcodec.common.model.Picture;
/*    */ 
/*    */ 
/*    */ public class CropFilter
/*    */   implements Filter
/*    */ {
/*    */   public PixelStore.LoanerPicture filter(Picture picture, PixelStore store) {
/* 13 */     return null;
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public ColorSpace getInputColor() {
/* 19 */     return null;
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public ColorSpace getOutputColor() {
/* 25 */     return null;
/*    */   }
/*    */ }


/* Location:              C:\Users\rapha\Downloads\aurora.jar!\META-INF\jars\jcodec-0.2.5.jar!\org\jcodec\api\transcode\filters\CropFilter.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */