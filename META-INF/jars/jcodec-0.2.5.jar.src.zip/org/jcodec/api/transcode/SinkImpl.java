/*     */ package org.jcodec.api.transcode;
/*     */ 
/*     */ import java.io.Closeable;
/*     */ import java.io.IOException;
/*     */ import java.nio.ByteBuffer;
/*     */ import java.nio.channels.WritableByteChannel;
/*     */ import org.jcodec.codecs.h264.H264Encoder;
/*     */ import org.jcodec.codecs.png.PNGEncoder;
/*     */ import org.jcodec.codecs.prores.ProresEncoder;
/*     */ import org.jcodec.codecs.raw.RAWVideoEncoder;
/*     */ import org.jcodec.codecs.vpx.IVFMuxer;
/*     */ import org.jcodec.codecs.vpx.VP8Encoder;
/*     */ import org.jcodec.codecs.wav.WavMuxer;
/*     */ import org.jcodec.codecs.y4m.Y4MMuxer;
/*     */ import org.jcodec.common.AudioCodecMeta;
/*     */ import org.jcodec.common.AudioEncoder;
/*     */ import org.jcodec.common.AudioFormat;
/*     */ import org.jcodec.common.Codec;
/*     */ import org.jcodec.common.Format;
/*     */ import org.jcodec.common.Muxer;
/*     */ import org.jcodec.common.MuxerTrack;
/*     */ import org.jcodec.common.VideoCodecMeta;
/*     */ import org.jcodec.common.VideoEncoder;
/*     */ import org.jcodec.common.io.IOUtils;
/*     */ import org.jcodec.common.io.NIOUtils;
/*     */ import org.jcodec.common.io.SeekableByteChannel;
/*     */ import org.jcodec.common.logging.Logger;
/*     */ import org.jcodec.common.model.AudioBuffer;
/*     */ import org.jcodec.common.model.ColorSpace;
/*     */ import org.jcodec.common.model.Packet;
/*     */ import org.jcodec.common.model.Picture;
/*     */ import org.jcodec.common.model.Size;
/*     */ import org.jcodec.containers.imgseq.ImageSequenceMuxer;
/*     */ import org.jcodec.containers.mkv.muxer.MKVMuxer;
/*     */ import org.jcodec.containers.mp4.muxer.MP4Muxer;
/*     */ import org.jcodec.containers.raw.RawMuxer;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class SinkImpl
/*     */   implements Sink, PacketSink
/*     */ {
/*     */   private String destName;
/*     */   private SeekableByteChannel destStream;
/*     */   private Muxer muxer;
/*     */   private MuxerTrack videoOutputTrack;
/*     */   private MuxerTrack audioOutputTrack;
/*     */   private boolean framesOutput;
/*     */   private Codec outputVideoCodec;
/*     */   private Codec outputAudioCodec;
/*     */   private Format outputFormat;
/*     */   private final ThreadLocal<ByteBuffer> bufferStore;
/*     */   private AudioEncoder audioEncoder;
/*     */   private VideoEncoder videoEncoder;
/*     */   private String profile;
/*     */   private boolean interlaced;
/*     */   
/*     */   public void outputVideoPacket(Packet packet, VideoCodecMeta codecMeta) throws IOException {
/*  70 */     if (!this.outputFormat.isVideo())
/*     */       return; 
/*  72 */     if (this.videoOutputTrack == null) {
/*  73 */       this.videoOutputTrack = this.muxer.addVideoTrack(this.outputVideoCodec, codecMeta);
/*     */     }
/*  75 */     this.videoOutputTrack.addFrame(packet);
/*  76 */     this.framesOutput = true;
/*     */   }
/*     */ 
/*     */   
/*     */   public void outputAudioPacket(Packet audioPkt, AudioCodecMeta audioCodecMeta) throws IOException {
/*  81 */     if (!this.outputFormat.isAudio())
/*     */       return; 
/*  83 */     if (this.audioOutputTrack == null) {
/*  84 */       this.audioOutputTrack = this.muxer.addAudioTrack(this.outputAudioCodec, audioCodecMeta);
/*     */     }
/*  86 */     this.audioOutputTrack.addFrame(audioPkt);
/*  87 */     this.framesOutput = true;
/*     */   }
/*     */   
/*     */   public void initMuxer() throws IOException {
/*  91 */     if (this.destStream == null && this.outputFormat != Format.IMG)
/*  92 */       this.destStream = (SeekableByteChannel)NIOUtils.writableFileChannel(this.destName); 
/*  93 */     if (Format.MKV == this.outputFormat) {
/*  94 */       this.muxer = (Muxer)new MKVMuxer(this.destStream);
/*  95 */     } else if (Format.MOV == this.outputFormat) {
/*  96 */       this.muxer = (Muxer)MP4Muxer.createMP4MuxerToChannel(this.destStream);
/*  97 */     } else if (Format.IVF == this.outputFormat) {
/*  98 */       this.muxer = (Muxer)new IVFMuxer(this.destStream);
/*  99 */     } else if (Format.IMG == this.outputFormat) {
/* 100 */       this.muxer = (Muxer)new ImageSequenceMuxer(this.destName);
/* 101 */     } else if (Format.WAV == this.outputFormat) {
/* 102 */       this.muxer = (Muxer)new WavMuxer(this.destStream);
/* 103 */     } else if (Format.Y4M == this.outputFormat) {
/* 104 */       this.muxer = (Muxer)new Y4MMuxer((WritableByteChannel)this.destStream);
/* 105 */     } else if (Format.RAW == this.outputFormat) {
/* 106 */       this.muxer = (Muxer)new RawMuxer(this.destStream);
/*     */     } else {
/* 108 */       throw new RuntimeException("The output format " + this.outputFormat + " is not supported.");
/*     */     } 
/*     */   }
/*     */   
/*     */   public void finish() throws IOException {
/* 113 */     if (this.framesOutput) {
/* 114 */       this.muxer.finish();
/*     */     } else {
/* 116 */       Logger.warn("No frames output.");
/*     */     } 
/* 118 */     if (this.destStream != null) {
/* 119 */       IOUtils.closeQuietly((Closeable)this.destStream);
/*     */     }
/*     */   }
/*     */   
/*     */   public SinkImpl(String destName, Format outputFormat, Codec outputVideoCodec, Codec outputAudioCodec) {
/* 124 */     if (destName == null && outputFormat == Format.IMG)
/* 125 */       throw new IllegalArgumentException("A destination file should be specified for the image muxer."); 
/* 126 */     this.destName = destName;
/* 127 */     this.outputFormat = outputFormat;
/* 128 */     this.outputVideoCodec = outputVideoCodec;
/* 129 */     this.outputAudioCodec = outputAudioCodec;
/* 130 */     this.outputFormat = outputFormat;
/* 131 */     this.bufferStore = new ThreadLocal<ByteBuffer>();
/*     */   }
/*     */   
/*     */   public static SinkImpl createWithStream(SeekableByteChannel destStream, Format outputFormat, Codec outputVideoCodec, Codec outputAudioCodec) {
/* 135 */     SinkImpl result = new SinkImpl(null, outputFormat, outputVideoCodec, outputAudioCodec);
/* 136 */     result.destStream = destStream;
/* 137 */     return result;
/*     */   }
/*     */ 
/*     */   
/*     */   public void init() throws IOException {
/* 142 */     initMuxer();
/* 143 */     if (this.outputFormat.isVideo() && this.outputVideoCodec != null) {
/* 144 */       if (Codec.PRORES == this.outputVideoCodec) {
/* 145 */         this.videoEncoder = (VideoEncoder)ProresEncoder.createProresEncoder(this.profile, this.interlaced);
/* 146 */       } else if (Codec.H264 == this.outputVideoCodec) {
/* 147 */         this.videoEncoder = (VideoEncoder)H264Encoder.createH264Encoder();
/* 148 */       } else if (Codec.VP8 == this.outputVideoCodec) {
/* 149 */         this.videoEncoder = (VideoEncoder)VP8Encoder.createVP8Encoder(10);
/* 150 */       } else if (Codec.PNG == this.outputVideoCodec) {
/* 151 */         this.videoEncoder = (VideoEncoder)new PNGEncoder();
/* 152 */       } else if (Codec.RAW == this.outputVideoCodec) {
/* 153 */         this.videoEncoder = (VideoEncoder)new RAWVideoEncoder();
/*     */       } else {
/* 155 */         throw new RuntimeException("Could not find encoder for the codec: " + this.outputVideoCodec);
/*     */       } 
/*     */     }
/*     */   }
/*     */   
/*     */   protected VideoEncoder.EncodedFrame encodeVideo(Picture frame, ByteBuffer _out) {
/* 161 */     if (!this.outputFormat.isVideo()) {
/* 162 */       return null;
/*     */     }
/* 164 */     return this.videoEncoder.encodeFrame(frame, _out);
/*     */   }
/*     */   
/*     */   private AudioEncoder createAudioEncoder(Codec codec, AudioFormat format) {
/* 168 */     if (codec != Codec.PCM) {
/* 169 */       throw new RuntimeException("Only PCM audio encoding (RAW audio) is supported.");
/*     */     }
/* 171 */     return new RawAudioEncoder();
/*     */   }
/*     */   
/*     */   private static class RawAudioEncoder
/*     */     implements AudioEncoder {
/*     */     public ByteBuffer encode(ByteBuffer audioPkt, ByteBuffer buf) {
/* 177 */       return audioPkt;
/*     */     }
/*     */     private RawAudioEncoder() {} }
/*     */   
/*     */   protected ByteBuffer encodeAudio(AudioBuffer audioBuffer) {
/* 182 */     if (this.audioEncoder == null) {
/* 183 */       AudioFormat format = audioBuffer.getFormat();
/* 184 */       this.audioEncoder = createAudioEncoder(this.outputAudioCodec, format);
/*     */     } 
/*     */     
/* 187 */     return this.audioEncoder.encode(audioBuffer.getData(), null);
/*     */   }
/*     */   
/*     */   public void setProfile(String profile) {
/* 191 */     this.profile = profile;
/*     */   }
/*     */   
/*     */   public void setInterlaced(Boolean interlaced) {
/* 195 */     this.interlaced = interlaced.booleanValue();
/*     */   }
/*     */ 
/*     */   
/*     */   public void outputVideoFrame(VideoFrameWithPacket videoFrame) throws IOException {
/* 200 */     if (!this.outputFormat.isVideo() || this.outputVideoCodec == null) {
/*     */       return;
/*     */     }
/* 203 */     ByteBuffer buffer = this.bufferStore.get();
/* 204 */     int bufferSize = this.videoEncoder.estimateBufferSize(videoFrame.getFrame().getPicture());
/* 205 */     if (buffer == null || bufferSize < buffer.capacity()) {
/* 206 */       buffer = ByteBuffer.allocate(bufferSize);
/* 207 */       this.bufferStore.set(buffer);
/*     */     } 
/* 209 */     buffer.clear();
/* 210 */     Picture frame = videoFrame.getFrame().getPicture();
/* 211 */     VideoEncoder.EncodedFrame enc = encodeVideo(frame, buffer);
/* 212 */     Packet outputVideoPacket = Packet.createPacketWithData(videoFrame.getPacket(), NIOUtils.clone(enc.getData()));
/* 213 */     outputVideoPacket.setFrameType(enc.isKeyFrame() ? Packet.FrameType.KEY : Packet.FrameType.INTER);
/* 214 */     outputVideoPacket(outputVideoPacket, 
/* 215 */         VideoCodecMeta.createSimpleVideoCodecMeta(new Size(frame.getWidth(), frame.getHeight()), frame.getColor()));
/*     */   }
/*     */ 
/*     */   
/*     */   public void outputAudioFrame(AudioFrameWithPacket audioFrame) throws IOException {
/* 220 */     if (!this.outputFormat.isAudio() || this.outputAudioCodec == null)
/*     */       return; 
/* 222 */     outputAudioPacket(Packet.createPacketWithData(audioFrame.getPacket(), encodeAudio(audioFrame.getAudio())), 
/* 223 */         AudioCodecMeta.fromAudioFormat(audioFrame.getAudio().getFormat()));
/*     */   }
/*     */ 
/*     */   
/*     */   public ColorSpace getInputColor() {
/* 228 */     if (this.videoEncoder == null)
/* 229 */       throw new IllegalStateException("Video encoder has not been initialized, init() must be called before using this class."); 
/* 230 */     ColorSpace[] colorSpaces = this.videoEncoder.getSupportedColorSpaces();
/* 231 */     return (colorSpaces == null) ? null : colorSpaces[0];
/*     */   }
/*     */ 
/*     */   
/*     */   public void setOption(Options option, Object value) {
/* 236 */     if (option == Options.PROFILE) {
/* 237 */       this.profile = (String)value;
/* 238 */     } else if (option == Options.INTERLACED) {
/* 239 */       this.interlaced = ((Boolean)value).booleanValue();
/*     */     } 
/*     */   }
/*     */   
/*     */   public boolean isVideo() {
/* 244 */     return this.outputFormat.isVideo();
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean isAudio() {
/* 249 */     return this.outputFormat.isAudio();
/*     */   }
/*     */ }


/* Location:              C:\Users\rapha\Downloads\aurora.jar!\META-INF\jars\jcodec-0.2.5.jar!\org\jcodec\api\transcode\SinkImpl.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */