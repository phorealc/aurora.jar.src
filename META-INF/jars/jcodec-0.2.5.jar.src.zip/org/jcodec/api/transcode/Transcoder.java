/*     */ package org.jcodec.api.transcode;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.util.ArrayList;
/*     */ import java.util.LinkedList;
/*     */ import java.util.List;
/*     */ import org.jcodec.api.transcode.filters.ColorTransformFilter;
/*     */ import org.jcodec.common.AudioCodecMeta;
/*     */ import org.jcodec.common.IntArrayList;
/*     */ import org.jcodec.common.VideoCodecMeta;
/*     */ import org.jcodec.common.model.ColorSpace;
/*     */ import org.jcodec.common.model.Packet;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class Transcoder
/*     */ {
/*     */   static final int REORDER_BUFFER_SIZE = 7;
/*     */   private Source[] sources;
/*     */   private Sink[] sinks;
/*     */   private List<Filter>[] extraFilters;
/*     */   private int[] seekFrames;
/*     */   private int[] maxFrames;
/*     */   private Mapping[] videoMappings;
/*     */   private Mapping[] audioMappings;
/*     */   
/*     */   private Transcoder(Source[] source, Sink[] sink, Mapping[] videoMappings, Mapping[] audioMappings, List<Filter>[] extraFilters, int[] seekFrames, int[] maxFrames) {
/*  51 */     this.extraFilters = extraFilters;
/*  52 */     this.videoMappings = videoMappings;
/*  53 */     this.audioMappings = audioMappings;
/*     */     
/*  55 */     this.seekFrames = seekFrames;
/*  56 */     this.maxFrames = maxFrames;
/*     */     
/*  58 */     this.sources = source;
/*  59 */     this.sinks = sink;
/*     */   }
/*     */   
/*     */   private static class Mapping {
/*     */     private int source;
/*     */     private boolean copy;
/*     */     
/*     */     public Mapping(int source, boolean copy) {
/*  67 */       this.source = source;
/*  68 */       this.copy = copy;
/*     */     }
/*     */   }
/*     */   
/*     */   private static class Stream
/*     */   {
/*     */     private static final double AUDIO_LEADING_TIME = 0.2D;
/*     */     private LinkedList<VideoFrameWithPacket> videoQueue;
/*     */     private LinkedList<AudioFrameWithPacket> audioQueue;
/*     */     private List<Filter> filters;
/*     */     private List<Filter> extraFilters;
/*     */     private Sink sink;
/*     */     private boolean videoCopy;
/*     */     private boolean audioCopy;
/*     */     private PixelStore pixelStore;
/*     */     private VideoCodecMeta videoCodecMeta;
/*     */     private AudioCodecMeta audioCodecMeta;
/*     */     private static final int REORDER_LENGTH = 5;
/*     */     
/*     */     public Stream(Sink sink, boolean videoCopy, boolean audioCopy, List<Filter> extraFilters, PixelStore pixelStore) {
/*  88 */       this.sink = sink;
/*  89 */       this.videoCopy = videoCopy;
/*  90 */       this.audioCopy = audioCopy;
/*  91 */       this.extraFilters = extraFilters;
/*  92 */       this.pixelStore = pixelStore;
/*  93 */       this.videoQueue = new LinkedList<VideoFrameWithPacket>();
/*  94 */       this.audioQueue = new LinkedList<AudioFrameWithPacket>();
/*     */     }
/*     */     
/*     */     private List<Filter> initColorTransform(ColorSpace sourceColor, List<Filter> extraFilters, Sink sink) {
/*  98 */       List<Filter> filters = new ArrayList<Filter>();
/*  99 */       for (Filter filter : extraFilters) {
/* 100 */         ColorSpace colorSpace = filter.getInputColor();
/* 101 */         if (!sourceColor.matches(colorSpace)) {
/* 102 */           filters.add(new ColorTransformFilter(colorSpace));
/*     */         }
/* 104 */         filters.add(filter);
/* 105 */         if (filter.getOutputColor() != ColorSpace.SAME)
/* 106 */           sourceColor = filter.getOutputColor(); 
/*     */       } 
/* 108 */       ColorSpace inputColor = sink.getInputColor();
/* 109 */       if (inputColor != null && inputColor != sourceColor)
/* 110 */         filters.add(new ColorTransformFilter(inputColor)); 
/* 111 */       return filters;
/*     */     }
/*     */ 
/*     */     
/*     */     public void tryFlushQueues() throws IOException {
/* 116 */       if (this.videoQueue.size() <= 0)
/*     */         return; 
/* 118 */       if (this.videoCopy && this.videoQueue.size() < 5)
/*     */         return; 
/* 120 */       if (!hasLeadingAudio()) {
/*     */         return;
/*     */       }
/* 123 */       VideoFrameWithPacket firstVideoFrame = this.videoQueue.get(0);
/*     */ 
/*     */ 
/*     */       
/* 127 */       if (this.videoCopy) {
/* 128 */         for (VideoFrameWithPacket videoFrame : this.videoQueue) {
/* 129 */           if (videoFrame.getPacket().getFrameNo() < firstVideoFrame.getPacket().getFrameNo()) {
/* 130 */             firstVideoFrame = videoFrame;
/*     */           }
/*     */         } 
/*     */       }
/*     */ 
/*     */       
/* 136 */       int aqSize = this.audioQueue.size();
/* 137 */       for (int af = 0; af < aqSize; af++) {
/* 138 */         AudioFrameWithPacket audioFrame = this.audioQueue.get(0);
/* 139 */         if (audioFrame.getPacket().getPtsD() >= firstVideoFrame.getPacket().getPtsD() + 0.2D)
/*     */           break; 
/* 141 */         this.audioQueue.remove(0);
/*     */         
/* 143 */         if (this.audioCopy && this.sink instanceof PacketSink) {
/* 144 */           ((PacketSink)this.sink).outputAudioPacket(audioFrame.getPacket(), this.audioCodecMeta);
/*     */         } else {
/* 146 */           this.sink.outputAudioFrame(audioFrame);
/*     */         } 
/*     */       } 
/* 149 */       this.videoQueue.remove(firstVideoFrame);
/* 150 */       if (this.videoCopy && this.sink instanceof PacketSink) {
/* 151 */         ((PacketSink)this.sink).outputVideoPacket(firstVideoFrame.getPacket(), this.videoCodecMeta);
/*     */       } else {
/*     */         
/* 154 */         PixelStore.LoanerPicture frame = filterFrame(firstVideoFrame);
/* 155 */         this.sink.outputVideoFrame(new VideoFrameWithPacket(firstVideoFrame.getPacket(), frame));
/* 156 */         this.pixelStore.putBack(frame);
/*     */       } 
/*     */     }
/*     */     
/*     */     private PixelStore.LoanerPicture filterFrame(VideoFrameWithPacket firstVideoFrame) {
/* 161 */       PixelStore.LoanerPicture frame = firstVideoFrame.getFrame();
/* 162 */       for (Filter filter : this.filters) {
/* 163 */         PixelStore.LoanerPicture old = frame;
/* 164 */         frame = filter.filter(frame.getPicture(), this.pixelStore);
/*     */ 
/*     */         
/* 167 */         if (frame == null) {
/* 168 */           frame = old; continue;
/*     */         } 
/* 170 */         this.pixelStore.putBack(old);
/*     */       } 
/*     */       
/* 173 */       return frame;
/*     */     }
/*     */     
/*     */     public void finalFlushQueues() throws IOException {
/* 177 */       VideoFrameWithPacket lastVideoFrame = null;
/* 178 */       for (VideoFrameWithPacket videoFrame : this.videoQueue) {
/* 179 */         if (lastVideoFrame == null || videoFrame.getPacket().getPtsD() >= lastVideoFrame.getPacket().getPtsD())
/* 180 */           lastVideoFrame = videoFrame; 
/*     */       } 
/* 182 */       if (lastVideoFrame != null) {
/* 183 */         for (AudioFrameWithPacket audioFrame : this.audioQueue) {
/*     */           
/* 185 */           if (audioFrame.getPacket().getPtsD() > lastVideoFrame.getPacket().getPtsD())
/*     */             break; 
/* 187 */           if (this.audioCopy && this.sink instanceof PacketSink) {
/* 188 */             ((PacketSink)this.sink).outputAudioPacket(audioFrame.getPacket(), this.audioCodecMeta); continue;
/*     */           } 
/* 190 */           this.sink.outputAudioFrame(audioFrame);
/*     */         } 
/*     */         
/* 193 */         for (VideoFrameWithPacket videoFrame : this.videoQueue) {
/* 194 */           if (videoFrame != null) {
/* 195 */             if (this.videoCopy && this.sink instanceof PacketSink) {
/* 196 */               ((PacketSink)this.sink).outputVideoPacket(videoFrame.getPacket(), this.videoCodecMeta); continue;
/*     */             } 
/* 198 */             PixelStore.LoanerPicture frame = filterFrame(videoFrame);
/* 199 */             this.sink.outputVideoFrame(new VideoFrameWithPacket(videoFrame.getPacket(), frame));
/* 200 */             this.pixelStore.putBack(frame);
/*     */           } 
/*     */         } 
/*     */       } else {
/*     */         
/* 205 */         for (AudioFrameWithPacket audioFrame : this.audioQueue) {
/* 206 */           if (this.audioCopy && this.sink instanceof PacketSink) {
/* 207 */             ((PacketSink)this.sink).outputAudioPacket(audioFrame.getPacket(), this.audioCodecMeta); continue;
/*     */           } 
/* 209 */           this.sink.outputAudioFrame(audioFrame);
/*     */         } 
/*     */       } 
/*     */     }
/*     */ 
/*     */     
/*     */     public void addVideoPacket(VideoFrameWithPacket videoFrame, VideoCodecMeta meta) {
/* 216 */       if (videoFrame.getFrame() != null)
/* 217 */         this.pixelStore.retake(videoFrame.getFrame()); 
/* 218 */       this.videoQueue.add(videoFrame);
/* 219 */       this.videoCodecMeta = meta;
/* 220 */       if (this.filters == null)
/* 221 */         this.filters = initColorTransform(this.videoCodecMeta.getColor(), this.extraFilters, this.sink); 
/*     */     }
/*     */     
/*     */     public void addAudioPacket(AudioFrameWithPacket videoFrame, AudioCodecMeta meta) {
/* 225 */       this.audioQueue.add(videoFrame);
/* 226 */       this.audioCodecMeta = meta;
/*     */     }
/*     */     
/*     */     public boolean needsVideoFrame() {
/* 230 */       if (this.videoQueue.size() <= 0)
/* 231 */         return true; 
/* 232 */       if (this.videoCopy && this.videoQueue.size() < 5)
/* 233 */         return true; 
/* 234 */       return false;
/*     */     }
/*     */     
/*     */     public boolean hasLeadingAudio() {
/* 238 */       VideoFrameWithPacket firstVideoFrame = this.videoQueue.get(0);
/* 239 */       for (AudioFrameWithPacket audioFrame : this.audioQueue) {
/* 240 */         if (audioFrame.getPacket().getPtsD() >= firstVideoFrame.getPacket().getPtsD() + 0.2D) {
/* 241 */           return true;
/*     */         }
/*     */       } 
/* 244 */       return false;
/*     */     }
/*     */   }
/*     */   
/*     */   public void transcode() throws IOException {
/* 249 */     PixelStore pixelStore = new PixelStoreImpl();
/*     */     
/* 251 */     List[] arrayOfList1 = new List[this.sources.length];
/* 252 */     List[] arrayOfList2 = new List[this.sources.length];
/* 253 */     boolean[] decodeVideo = new boolean[this.sources.length];
/* 254 */     boolean[] decodeAudio = new boolean[this.sources.length];
/* 255 */     boolean[] finishedVideo = new boolean[this.sources.length];
/* 256 */     boolean[] finishedAudio = new boolean[this.sources.length];
/* 257 */     Stream[] allStreams = new Stream[this.sinks.length];
/* 258 */     int[] videoFramesRead = new int[this.sources.length];
/*     */     
/* 260 */     for (int j = 0; j < this.sources.length; j++) {
/* 261 */       arrayOfList1[j] = new ArrayList();
/* 262 */       arrayOfList2[j] = new ArrayList();
/*     */     } 
/*     */     int i;
/* 265 */     for (i = 0; i < this.sinks.length; i++) {
/* 266 */       this.sinks[i].init();
/*     */     }
/* 268 */     for (i = 0; i < this.sources.length; i++) {
/* 269 */       this.sources[i].init(pixelStore);
/* 270 */       this.sources[i].seekFrames(this.seekFrames[i]);
/*     */     } 
/*     */     int s;
/* 273 */     for (s = 0; s < this.sinks.length; s++) {
/* 274 */       Stream stream = new Stream(this.sinks[s], (this.videoMappings[s]).copy, (this.audioMappings[s]).copy, this.extraFilters[s], pixelStore);
/*     */       
/* 276 */       allStreams[s] = stream;
/* 277 */       if (this.sources[(this.videoMappings[s]).source].isVideo()) {
/* 278 */         arrayOfList1[(this.videoMappings[s]).source].add(stream);
/* 279 */         if (!(this.videoMappings[s]).copy)
/* 280 */           decodeVideo[(this.videoMappings[s]).source] = true; 
/*     */       } else {
/* 282 */         finishedVideo[(this.videoMappings[s]).source] = true;
/*     */       } 
/*     */       
/* 285 */       if (this.sources[(this.audioMappings[s]).source].isAudio()) {
/* 286 */         arrayOfList2[(this.audioMappings[s]).source].add(stream);
/* 287 */         if (!(this.audioMappings[s]).copy)
/* 288 */           decodeAudio[(this.audioMappings[s]).source] = true; 
/*     */       } else {
/* 290 */         finishedAudio[(this.audioMappings[s]).source] = true;
/*     */       } 
/*     */     } 
/*     */     
/*     */     try {
/*     */       int n;
/*     */       
/*     */       do {
/* 298 */         for (s = 0; s < this.sources.length; s++) {
/* 299 */           int i2; Source source = this.sources[s];
/*     */ 
/*     */ 
/*     */ 
/*     */           
/* 304 */           boolean needsVideoFrame = !finishedVideo[s];
/* 305 */           for (Stream stream : arrayOfList1[s]) {
/* 306 */             i2 = needsVideoFrame & ((stream.needsVideoFrame() || stream.hasLeadingAudio() || finishedAudio[s]) ? 1 : 0);
/*     */           }
/*     */           
/* 309 */           if (i2 != 0) {
/*     */             VideoFrameWithPacket nextVideoFrame;
/*     */ 
/*     */             
/* 313 */             if (videoFramesRead[s] >= this.maxFrames[s]) {
/* 314 */               nextVideoFrame = null;
/* 315 */               finishedVideo[s] = true;
/* 316 */             } else if (decodeVideo[s] || !(source instanceof PacketSource)) {
/* 317 */               nextVideoFrame = source.getNextVideoFrame();
/* 318 */               if (nextVideoFrame == null) {
/* 319 */                 finishedVideo[s] = true;
/*     */               } else {
/* 321 */                 videoFramesRead[s] = videoFramesRead[s] + 1;
/* 322 */                 printLegend((int)nextVideoFrame.getPacket().getFrameNo(), 0, nextVideoFrame
/* 323 */                     .getPacket());
/*     */               } 
/*     */             } else {
/* 326 */               Packet packet = ((PacketSource)source).inputVideoPacket();
/* 327 */               if (packet == null) {
/* 328 */                 finishedVideo[s] = true;
/*     */               } else {
/* 330 */                 videoFramesRead[s] = videoFramesRead[s] + 1;
/*     */               } 
/* 332 */               nextVideoFrame = new VideoFrameWithPacket(packet, null);
/*     */             } 
/*     */ 
/*     */ 
/*     */ 
/*     */             
/* 338 */             if (finishedVideo[s]) {
/* 339 */               for (Stream stream : arrayOfList1[s]) {
/* 340 */                 for (int ss = 0; ss < arrayOfList2.length; ss++) {
/* 341 */                   arrayOfList2[ss].remove(stream);
/*     */                 }
/*     */               } 
/* 344 */               arrayOfList1[s].clear();
/*     */             } 
/*     */             
/* 347 */             if (nextVideoFrame != null) {
/* 348 */               for (Stream stream : arrayOfList1[s]) {
/* 349 */                 stream.addVideoPacket(nextVideoFrame, source.getVideoCodecMeta());
/*     */               }
/*     */ 
/*     */ 
/*     */               
/* 354 */               if (nextVideoFrame.getFrame() != null) {
/* 355 */                 pixelStore.putBack(nextVideoFrame.getFrame());
/*     */               }
/*     */             } 
/*     */           } 
/*     */           
/* 360 */           if (!arrayOfList2[s].isEmpty()) {
/*     */             AudioFrameWithPacket nextAudioFrame;
/*     */ 
/*     */             
/* 364 */             if (decodeAudio[s] || !(source instanceof PacketSource)) {
/* 365 */               nextAudioFrame = source.getNextAudioFrame();
/* 366 */               if (nextAudioFrame == null)
/* 367 */                 finishedAudio[s] = true; 
/*     */             } else {
/* 369 */               Packet packet = ((PacketSource)source).inputAudioPacket();
/* 370 */               if (packet == null) {
/* 371 */                 finishedAudio[s] = true;
/* 372 */                 nextAudioFrame = null;
/*     */               } else {
/* 374 */                 nextAudioFrame = new AudioFrameWithPacket(null, packet);
/*     */               } 
/*     */             } 
/* 377 */             if (nextAudioFrame != null) {
/* 378 */               for (Stream stream : arrayOfList2[s]) {
/* 379 */                 stream.addAudioPacket(nextAudioFrame, source.getAudioCodecMeta());
/*     */               }
/*     */             }
/*     */           } else {
/* 383 */             finishedAudio[s] = true;
/*     */           } 
/*     */         } 
/*     */ 
/*     */ 
/*     */         
/* 389 */         for (s = 0; s < allStreams.length; s++) {
/* 390 */           allStreams[s].tryFlushQueues();
/*     */         }
/*     */ 
/*     */         
/* 394 */         boolean allFinished = true;
/* 395 */         for (int i1 = 0; i1 < this.sources.length; i1++) {
/* 396 */           n = allFinished & finishedVideo[i1] & finishedAudio[i1];
/*     */         }
/*     */       }
/* 399 */       while (n == 0);
/*     */ 
/*     */ 
/*     */       
/* 403 */       for (int m = 0; m < allStreams.length; m++)
/* 404 */         allStreams[m].finalFlushQueues(); 
/*     */     } finally {
/*     */       int k;
/* 407 */       for (k = 0; k < this.sources.length; k++)
/* 408 */         this.sources[0].finish(); 
/* 409 */       for (k = 0; k < this.sinks.length; k++)
/* 410 */         this.sinks[k].finish(); 
/*     */     } 
/*     */   }
/*     */   
/*     */   private void printLegend(int frameNo, int maxFrames, Packet inVideoPacket) {
/* 415 */     if (frameNo % 100 == 0) {
/* 416 */       System.out.print(String.format("[%6d]\r", new Object[] { Integer.valueOf(frameNo) }));
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static class TranscoderBuilder
/*     */   {
/* 430 */     private List<Source> source = new ArrayList<Source>();
/* 431 */     private List<Sink> sink = new ArrayList<Sink>();
/* 432 */     private List<List<Filter>> filters = new ArrayList<List<Filter>>();
/* 433 */     private IntArrayList seekFrames = new IntArrayList(20);
/* 434 */     private IntArrayList maxFrames = new IntArrayList(20);
/* 435 */     private List<Transcoder.Mapping> videoMappings = new ArrayList<Transcoder.Mapping>();
/* 436 */     private List<Transcoder.Mapping> audioMappings = new ArrayList<Transcoder.Mapping>();
/*     */ 
/*     */     
/*     */     public TranscoderBuilder addFilter(int sink, Filter filter) {
/* 440 */       ((List<Filter>)this.filters.get(sink)).add(filter);
/* 441 */       return this;
/*     */     }
/*     */     
/*     */     public TranscoderBuilder setSeekFrames(int source, int seekFrames) {
/* 445 */       this.seekFrames.set(source, seekFrames);
/* 446 */       return this;
/*     */     }
/*     */     
/*     */     public TranscoderBuilder setMaxFrames(int source, int maxFrames) {
/* 450 */       this.maxFrames.set(source, maxFrames);
/* 451 */       return this;
/*     */     }
/*     */     
/*     */     public TranscoderBuilder addSource(Source source) {
/* 455 */       this.source.add(source);
/* 456 */       this.seekFrames.add(0);
/* 457 */       this.maxFrames.add(2147483647);
/* 458 */       return this;
/*     */     }
/*     */     
/*     */     public TranscoderBuilder addSink(Sink sink) {
/* 462 */       this.sink.add(sink);
/* 463 */       this.videoMappings.add(new Transcoder.Mapping(0, false));
/* 464 */       this.audioMappings.add(new Transcoder.Mapping(0, false));
/* 465 */       this.filters.add(new ArrayList<Filter>());
/* 466 */       return this;
/*     */     }
/*     */     
/*     */     public TranscoderBuilder setVideoMapping(int src, int sink, boolean copy) {
/* 470 */       this.videoMappings.set(sink, new Transcoder.Mapping(src, copy));
/* 471 */       return this;
/*     */     }
/*     */     
/*     */     public TranscoderBuilder setAudioMapping(int src, int sink, boolean copy) {
/* 475 */       this.audioMappings.set(sink, new Transcoder.Mapping(src, copy));
/* 476 */       return this;
/*     */     }
/*     */     
/*     */     public Transcoder create() {
/* 480 */       return new Transcoder(this.source.<Source>toArray(new Source[0]), this.sink.<Sink>toArray(new Sink[0]), this.videoMappings
/* 481 */           .<Transcoder.Mapping>toArray(new Transcoder.Mapping[0]), this.audioMappings.<Transcoder.Mapping>toArray(new Transcoder.Mapping[0]), this.filters
/* 482 */           .<List>toArray(new List[0]), this.seekFrames.toArray(), this.maxFrames.toArray());
/*     */     }
/*     */   }
/*     */   
/*     */   public static TranscoderBuilder newTranscoder() {
/* 487 */     return new TranscoderBuilder();
/*     */   }
/*     */ }


/* Location:              C:\Users\rapha\Downloads\aurora.jar!\META-INF\jars\jcodec-0.2.5.jar!\org\jcodec\api\transcode\Transcoder.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */