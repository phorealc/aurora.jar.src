package org.jcodec.api.transcode;

import java.io.IOException;
import org.jcodec.common.AudioCodecMeta;
import org.jcodec.common.VideoCodecMeta;

public interface Source {
  void init(PixelStore paramPixelStore) throws IOException;
  
  void seekFrames(int paramInt) throws IOException;
  
  VideoFrameWithPacket getNextVideoFrame() throws IOException;
  
  AudioFrameWithPacket getNextAudioFrame() throws IOException;
  
  void finish();
  
  boolean haveAudio();
  
  void setOption(Options paramOptions, Object paramObject);
  
  VideoCodecMeta getVideoCodecMeta();
  
  AudioCodecMeta getAudioCodecMeta();
  
  boolean isVideo();
  
  boolean isAudio();
}


/* Location:              C:\Users\rapha\Downloads\aurora.jar!\META-INF\jars\jcodec-0.2.5.jar!\org\jcodec\api\transcode\Source.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */