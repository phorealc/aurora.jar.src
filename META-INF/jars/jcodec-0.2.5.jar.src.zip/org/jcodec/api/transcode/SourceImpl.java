/*     */ package org.jcodec.api.transcode;
/*     */ 
/*     */ import java.io.Closeable;
/*     */ import java.io.FileNotFoundException;
/*     */ import java.io.IOException;
/*     */ import java.nio.ByteBuffer;
/*     */ import java.nio.channels.ReadableByteChannel;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Collections;
/*     */ import java.util.Iterator;
/*     */ import java.util.List;
/*     */ import net.sourceforge.jaad.aac.AACException;
/*     */ import org.jcodec.codecs.aac.AACDecoder;
/*     */ import org.jcodec.codecs.h264.BufferH264ES;
/*     */ import org.jcodec.codecs.h264.H264Decoder;
/*     */ import org.jcodec.codecs.h264.H264Utils;
/*     */ import org.jcodec.codecs.mjpeg.JpegDecoder;
/*     */ import org.jcodec.codecs.mjpeg.JpegToThumb2x2;
/*     */ import org.jcodec.codecs.mjpeg.JpegToThumb4x4;
/*     */ import org.jcodec.codecs.mpeg12.MPEGDecoder;
/*     */ import org.jcodec.codecs.mpeg12.Mpeg2Thumb2x2;
/*     */ import org.jcodec.codecs.mpeg12.Mpeg2Thumb4x4;
/*     */ import org.jcodec.codecs.mpeg4.MPEG4Decoder;
/*     */ import org.jcodec.codecs.png.PNGDecoder;
/*     */ import org.jcodec.codecs.prores.ProresDecoder;
/*     */ import org.jcodec.codecs.prores.ProresToThumb;
/*     */ import org.jcodec.codecs.prores.ProresToThumb2x2;
/*     */ import org.jcodec.codecs.prores.ProresToThumb4x4;
/*     */ import org.jcodec.codecs.raw.RAWVideoDecoder;
/*     */ import org.jcodec.codecs.vpx.VP8Decoder;
/*     */ import org.jcodec.codecs.wav.WavDemuxer;
/*     */ import org.jcodec.common.AudioCodecMeta;
/*     */ import org.jcodec.common.AudioDecoder;
/*     */ import org.jcodec.common.AudioFormat;
/*     */ import org.jcodec.common.Codec;
/*     */ import org.jcodec.common.Demuxer;
/*     */ import org.jcodec.common.DemuxerTrack;
/*     */ import org.jcodec.common.DemuxerTrackMeta;
/*     */ import org.jcodec.common.Format;
/*     */ import org.jcodec.common.SeekableDemuxerTrack;
/*     */ import org.jcodec.common.Tuple;
/*     */ import org.jcodec.common.VideoCodecMeta;
/*     */ import org.jcodec.common.VideoDecoder;
/*     */ import org.jcodec.common.io.IOUtils;
/*     */ import org.jcodec.common.io.NIOUtils;
/*     */ import org.jcodec.common.io.SeekableByteChannel;
/*     */ import org.jcodec.common.logging.Logger;
/*     */ import org.jcodec.common.model.AudioBuffer;
/*     */ import org.jcodec.common.model.Packet;
/*     */ import org.jcodec.common.model.Picture;
/*     */ import org.jcodec.common.model.Size;
/*     */ import org.jcodec.containers.imgseq.ImageSequenceDemuxer;
/*     */ import org.jcodec.containers.mkv.demuxer.MKVDemuxer;
/*     */ import org.jcodec.containers.mp3.MPEGAudioDemuxer;
/*     */ import org.jcodec.containers.mp4.demuxer.MP4Demuxer;
/*     */ import org.jcodec.containers.mps.MPEGDemuxer;
/*     */ import org.jcodec.containers.mps.MPSDemuxer;
/*     */ import org.jcodec.containers.mps.MTSDemuxer;
/*     */ import org.jcodec.containers.webp.WebpDemuxer;
/*     */ import org.jcodec.containers.y4m.Y4MDemuxer;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class SourceImpl
/*     */   implements Source, PacketSource
/*     */ {
/*     */   private String sourceName;
/*     */   private SeekableByteChannel sourceStream;
/*     */   private Demuxer demuxVideo;
/*     */   private Demuxer demuxAudio;
/*     */   private Format inputFormat;
/*     */   private DemuxerTrack videoInputTrack;
/*     */   private DemuxerTrack audioInputTrack;
/*     */   private Tuple._3<Integer, Integer, Codec> inputVideoCodec;
/*     */   private Tuple._3<Integer, Integer, Codec> inputAudioCodec;
/*     */   private List<VideoFrameWithPacket> frameReorderBuffer;
/*     */   private List<Packet> videoPacketReorderBuffer;
/*     */   private PixelStore pixelStore;
/*     */   private VideoCodecMeta videoCodecMeta;
/*     */   private AudioCodecMeta audioCodecMeta;
/*     */   private AudioDecoder audioDecoder;
/*     */   private VideoDecoder videoDecoder;
/*  99 */   private int downscale = 1;
/*     */   
/*     */   public static MPEGDecoder createMpegDecoder(int downscale) {
/* 102 */     if (downscale == 2)
/* 103 */       return (MPEGDecoder)new Mpeg2Thumb4x4(); 
/* 104 */     if (downscale == 4) {
/* 105 */       return (MPEGDecoder)new Mpeg2Thumb2x2();
/*     */     }
/* 107 */     return new MPEGDecoder();
/*     */   }
/*     */   
/*     */   public static ProresDecoder createProresDecoder(int downscale) {
/* 111 */     if (2 == downscale)
/* 112 */       return (ProresDecoder)new ProresToThumb4x4(); 
/* 113 */     if (4 == downscale)
/* 114 */       return (ProresDecoder)new ProresToThumb2x2(); 
/* 115 */     if (8 == downscale) {
/* 116 */       return (ProresDecoder)new ProresToThumb();
/*     */     }
/* 118 */     return new ProresDecoder();
/*     */   }
/*     */ 
/*     */   
/*     */   public void initDemuxer() throws FileNotFoundException, IOException {
/* 123 */     if (this.inputFormat != Format.IMG) {
/* 124 */       this.sourceStream = (SeekableByteChannel)NIOUtils.readableFileChannel(this.sourceName);
/*     */     }
/* 126 */     if (Format.MOV == this.inputFormat) {
/* 127 */       this.demuxVideo = this.demuxAudio = (Demuxer)MP4Demuxer.createMP4Demuxer(this.sourceStream);
/* 128 */     } else if (Format.MKV == this.inputFormat) {
/* 129 */       this.demuxVideo = this.demuxAudio = (Demuxer)new MKVDemuxer(this.sourceStream);
/* 130 */     } else if (Format.IMG == this.inputFormat) {
/* 131 */       this.demuxVideo = (Demuxer)new ImageSequenceDemuxer(this.sourceName, 2147483647);
/* 132 */     } else if (Format.WEBP == this.inputFormat) {
/* 133 */       this.demuxVideo = (Demuxer)new WebpDemuxer(this.sourceStream);
/* 134 */     } else if (Format.MPEG_PS == this.inputFormat) {
/* 135 */       this.demuxVideo = this.demuxAudio = (Demuxer)new MPSDemuxer((ReadableByteChannel)this.sourceStream);
/* 136 */     } else if (Format.Y4M == this.inputFormat) {
/* 137 */       Y4MDemuxer y4mDemuxer = new Y4MDemuxer(this.sourceStream);
/* 138 */       this.demuxVideo = this.demuxAudio = (Demuxer)y4mDemuxer;
/* 139 */       this.videoInputTrack = (DemuxerTrack)y4mDemuxer;
/* 140 */     } else if (Format.H264 == this.inputFormat) {
/* 141 */       this.demuxVideo = (Demuxer)new BufferH264ES(NIOUtils.fetchAllFromChannel(this.sourceStream));
/* 142 */     } else if (Format.WAV == this.inputFormat) {
/* 143 */       this.demuxAudio = (Demuxer)new WavDemuxer(this.sourceStream);
/* 144 */     } else if (Format.MPEG_AUDIO == this.inputFormat) {
/* 145 */       this.demuxAudio = (Demuxer)new MPEGAudioDemuxer(this.sourceStream);
/* 146 */     } else if (Format.MPEG_TS == this.inputFormat) {
/* 147 */       MTSDemuxer mtsDemuxer = new MTSDemuxer(this.sourceStream);
/* 148 */       MPSDemuxer mpsDemuxer = null;
/* 149 */       if (this.inputVideoCodec != null) {
/* 150 */         mpsDemuxer = new MPSDemuxer(mtsDemuxer.getProgram(((Integer)this.inputVideoCodec.v0).intValue()));
/* 151 */         this.videoInputTrack = (DemuxerTrack)openTSTrack(mpsDemuxer, (Integer)this.inputVideoCodec.v1);
/* 152 */         this.demuxVideo = (Demuxer)mpsDemuxer;
/*     */       } 
/* 154 */       if (this.inputAudioCodec != null) {
/* 155 */         if (this.inputVideoCodec == null || this.inputVideoCodec.v0 != this.inputAudioCodec.v0) {
/* 156 */           mpsDemuxer = new MPSDemuxer(mtsDemuxer.getProgram(((Integer)this.inputAudioCodec.v0).intValue()));
/*     */         }
/* 158 */         this.audioInputTrack = (DemuxerTrack)openTSTrack(mpsDemuxer, (Integer)this.inputAudioCodec.v1);
/* 159 */         this.demuxAudio = (Demuxer)mpsDemuxer;
/*     */       } 
/* 161 */       for (Iterator<Integer> iterator = mtsDemuxer.getPrograms().iterator(); iterator.hasNext(); ) { int pid = ((Integer)iterator.next()).intValue();
/* 162 */         if ((this.inputVideoCodec == null || pid != ((Integer)this.inputVideoCodec.v0).intValue()) && (this.inputAudioCodec == null || pid != ((Integer)this.inputAudioCodec.v0)
/* 163 */           .intValue())) {
/* 164 */           Logger.info("Unused program: " + pid);
/* 165 */           mtsDemuxer.getProgram(pid).close();
/*     */         }  }
/*     */     
/*     */     } else {
/* 169 */       throw new RuntimeException("Input format: " + this.inputFormat + " is not supported.");
/*     */     } 
/*     */     
/* 172 */     if (this.demuxVideo != null && this.inputVideoCodec != null) {
/* 173 */       List<? extends DemuxerTrack> videoTracks = this.demuxVideo.getVideoTracks();
/* 174 */       if (videoTracks.size() > 0) {
/* 175 */         this.videoInputTrack = videoTracks.get(((Integer)this.inputVideoCodec.v1).intValue());
/*     */       }
/*     */     } 
/* 178 */     if (this.demuxAudio != null && this.inputAudioCodec != null) {
/* 179 */       List<? extends DemuxerTrack> audioTracks = this.demuxAudio.getAudioTracks();
/* 180 */       if (audioTracks.size() > 0) {
/* 181 */         this.audioInputTrack = audioTracks.get(((Integer)this.inputAudioCodec.v1).intValue());
/*     */       }
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected int seekToKeyFrame(int frame) throws IOException {
/* 196 */     if (this.videoInputTrack instanceof SeekableDemuxerTrack) {
/* 197 */       SeekableDemuxerTrack seekable = (SeekableDemuxerTrack)this.videoInputTrack;
/* 198 */       seekable.gotoSyncFrame(frame);
/* 199 */       return (int)seekable.getCurFrame();
/*     */     } 
/* 201 */     Logger.warn("Can not seek in " + this.videoInputTrack + " container.");
/* 202 */     return -1;
/*     */   }
/*     */ 
/*     */   
/*     */   private MPEGDemuxer.MPEGDemuxerTrack openTSTrack(MPSDemuxer demuxerVideo, Integer selectedTrack) {
/* 207 */     int trackNo = 0;
/* 208 */     for (MPEGDemuxer.MPEGDemuxerTrack track : demuxerVideo.getTracks()) {
/* 209 */       if (trackNo == selectedTrack.intValue()) {
/* 210 */         return track;
/*     */       }
/* 212 */       track.ignore();
/* 213 */       trackNo++;
/*     */     } 
/* 215 */     return null;
/*     */   }
/*     */   
/*     */   public Packet inputVideoPacket() throws IOException {
/*     */     Packet packet;
/*     */     do {
/* 221 */       packet = getNextVideoPacket();
/* 222 */       if (packet == null)
/* 223 */         continue;  this.videoPacketReorderBuffer.add(packet);
/* 224 */     } while (packet != null && this.videoPacketReorderBuffer.size() <= 7);
/* 225 */     if (this.videoPacketReorderBuffer.size() == 0)
/* 226 */       return null; 
/* 227 */     Packet out = this.videoPacketReorderBuffer.remove(0);
/* 228 */     int duration = Integer.MAX_VALUE;
/* 229 */     for (Packet packet2 : this.videoPacketReorderBuffer) {
/* 230 */       int cand = (int)(packet2.getPts() - out.getPts());
/* 231 */       if (cand > 0 && cand < duration)
/* 232 */         duration = cand; 
/*     */     } 
/* 234 */     if (duration != Integer.MAX_VALUE)
/* 235 */       out.setDuration(duration); 
/* 236 */     return out;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private Packet getNextVideoPacket() throws IOException {
/* 242 */     if (this.videoInputTrack == null)
/* 243 */       return null; 
/* 244 */     Packet nextFrame = this.videoInputTrack.nextFrame();
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 249 */     if (this.videoDecoder == null) {
/* 250 */       this.videoDecoder = createVideoDecoder((Codec)this.inputVideoCodec.v2, this.downscale, nextFrame.getData(), null);
/* 251 */       if (this.videoDecoder != null) {
/* 252 */         this.videoCodecMeta = this.videoDecoder.getCodecMeta(nextFrame.getData());
/*     */       }
/*     */     } 
/*     */     
/* 256 */     return nextFrame;
/*     */   }
/*     */ 
/*     */   
/*     */   public Packet inputAudioPacket() throws IOException {
/* 261 */     if (this.audioInputTrack == null)
/* 262 */       return null; 
/* 263 */     Packet audioPkt = this.audioInputTrack.nextFrame();
/* 264 */     if (this.audioDecoder == null && audioPkt != null) {
/* 265 */       this.audioDecoder = createAudioDecoder(audioPkt.getData());
/* 266 */       if (this.audioDecoder != null) {
/* 267 */         this.audioCodecMeta = this.audioDecoder.getCodecMeta(audioPkt.getData());
/*     */       }
/*     */     } 
/* 270 */     return audioPkt;
/*     */   }
/*     */   
/*     */   public DemuxerTrackMeta getTrackVideoMeta() {
/* 274 */     if (this.videoInputTrack == null)
/* 275 */       return null; 
/* 276 */     return this.videoInputTrack.getMeta();
/*     */   }
/*     */   
/*     */   public DemuxerTrackMeta getAudioMeta() {
/* 280 */     if (this.audioInputTrack == null)
/* 281 */       return null; 
/* 282 */     return this.audioInputTrack.getMeta();
/*     */   }
/*     */   
/*     */   public boolean haveAudio() {
/* 286 */     return (this.audioInputTrack != null);
/*     */   }
/*     */ 
/*     */   
/*     */   public void finish() {
/* 291 */     if (this.sourceStream != null) {
/* 292 */       IOUtils.closeQuietly((Closeable)this.sourceStream);
/*     */     }
/*     */   }
/*     */   
/*     */   public SourceImpl(String sourceName, Format inputFormat, Tuple._3<Integer, Integer, Codec> inputVideoCodec, Tuple._3<Integer, Integer, Codec> inputAudioCodec) {
/* 297 */     this.sourceName = sourceName;
/* 298 */     this.inputFormat = inputFormat;
/* 299 */     this.inputVideoCodec = inputVideoCodec;
/* 300 */     this.inputAudioCodec = inputAudioCodec;
/* 301 */     this.frameReorderBuffer = new ArrayList<VideoFrameWithPacket>();
/* 302 */     this.videoPacketReorderBuffer = new ArrayList<Packet>();
/*     */   }
/*     */ 
/*     */   
/*     */   public void init(PixelStore pixelStore) throws IOException {
/* 307 */     this.pixelStore = pixelStore;
/*     */     
/* 309 */     initDemuxer();
/*     */   }
/*     */   
/*     */   private AudioDecoder createAudioDecoder(ByteBuffer codecPrivate) throws AACException {
/* 313 */     if (Codec.AAC == this.inputAudioCodec.v2)
/* 314 */       return (AudioDecoder)new AACDecoder(codecPrivate); 
/* 315 */     if (Codec.PCM == this.inputAudioCodec.v2) {
/* 316 */       return new RawAudioDecoder(getAudioMeta().getAudioCodecMeta().getFormat());
/*     */     }
/* 318 */     return null;
/*     */   }
/*     */ 
/*     */   
/*     */   private VideoDecoder createVideoDecoder(Codec codec, int downscale, ByteBuffer codecPrivate, VideoCodecMeta videoCodecMeta) {
/* 323 */     if (Codec.H264 == codec)
/* 324 */       return (VideoDecoder)H264Decoder.createH264DecoderFromCodecPrivate(codecPrivate); 
/* 325 */     if (Codec.PNG == codec)
/* 326 */       return (VideoDecoder)new PNGDecoder(); 
/* 327 */     if (Codec.MPEG2 == codec)
/* 328 */       return (VideoDecoder)createMpegDecoder(downscale); 
/* 329 */     if (Codec.PRORES == codec)
/* 330 */       return (VideoDecoder)createProresDecoder(downscale); 
/* 331 */     if (Codec.VP8 == codec)
/* 332 */       return (VideoDecoder)new VP8Decoder(); 
/* 333 */     if (Codec.JPEG == codec)
/* 334 */       return (VideoDecoder)createJpegDecoder(downscale); 
/* 335 */     if (Codec.MPEG4 == codec)
/* 336 */       return (VideoDecoder)new MPEG4Decoder(); 
/* 337 */     if (Codec.RAW == codec) {
/* 338 */       Size dim = videoCodecMeta.getSize();
/* 339 */       return (VideoDecoder)new RAWVideoDecoder(dim.getWidth(), dim.getHeight());
/*     */     } 
/* 341 */     return null;
/*     */   }
/*     */   
/*     */   public Picture decodeVideo(ByteBuffer data, Picture target1) {
/* 345 */     return this.videoDecoder.decodeFrame(data, target1.getData());
/*     */   }
/*     */   
/*     */   protected ByteBuffer decodeAudio(ByteBuffer audioPkt) throws IOException {
/* 349 */     if (this.inputAudioCodec.v2 == Codec.PCM) {
/* 350 */       return audioPkt;
/*     */     }
/* 352 */     AudioBuffer decodeFrame = this.audioDecoder.decodeFrame(audioPkt, null);
/* 353 */     return decodeFrame.getData();
/*     */   }
/*     */   
/*     */   private static class RawAudioDecoder
/*     */     implements AudioDecoder {
/*     */     private AudioFormat format;
/*     */     
/*     */     public RawAudioDecoder(AudioFormat format) {
/* 361 */       this.format = format;
/*     */     }
/*     */ 
/*     */     
/*     */     public AudioBuffer decodeFrame(ByteBuffer frame, ByteBuffer dst) throws IOException {
/* 366 */       return new AudioBuffer(frame, this.format, frame.remaining() / this.format.getFrameSize());
/*     */     }
/*     */ 
/*     */     
/*     */     public AudioCodecMeta getCodecMeta(ByteBuffer data) throws IOException {
/* 371 */       return AudioCodecMeta.fromAudioFormat(this.format);
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   public void seekFrames(int seekFrames) throws IOException {
/* 377 */     if (seekFrames == 0) {
/*     */       return;
/*     */     }
/*     */ 
/*     */     
/* 382 */     int skipFrames = seekFrames - seekToKeyFrame(seekFrames);
/*     */ 
/*     */     
/*     */     Packet inVideoPacket;
/*     */     
/* 387 */     while (skipFrames > 0 && (inVideoPacket = getNextVideoPacket()) != null) {
/* 388 */       PixelStore.LoanerPicture loanerBuffer = getPixelBuffer(inVideoPacket.getData());
/* 389 */       Picture decodedFrame = decodeVideo(inVideoPacket.getData(), loanerBuffer.getPicture());
/* 390 */       if (decodedFrame == null) {
/* 391 */         this.pixelStore.putBack(loanerBuffer);
/*     */         continue;
/*     */       } 
/* 394 */       this.frameReorderBuffer.add(new VideoFrameWithPacket(inVideoPacket, new PixelStore.LoanerPicture(decodedFrame, 1)));
/* 395 */       if (this.frameReorderBuffer.size() > 7) {
/* 396 */         Collections.sort(this.frameReorderBuffer);
/* 397 */         VideoFrameWithPacket removed = this.frameReorderBuffer.remove(0);
/* 398 */         skipFrames--;
/* 399 */         if (removed.getFrame() != null)
/* 400 */           this.pixelStore.putBack(removed.getFrame()); 
/*     */       } 
/*     */     } 
/*     */   }
/*     */   
/*     */   private void detectFrameType(Packet inVideoPacket) {
/* 406 */     if (this.inputVideoCodec.v2 != Codec.H264) {
/*     */       return;
/*     */     }
/* 409 */     inVideoPacket.setFrameType(
/* 410 */         H264Utils.isByteBufferIDRSlice(inVideoPacket.getData()) ? Packet.FrameType.KEY : Packet.FrameType.INTER);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected PixelStore.LoanerPicture getPixelBuffer(ByteBuffer firstFrame) {
/* 422 */     VideoCodecMeta videoMeta = getVideoCodecMeta();
/* 423 */     Size size = videoMeta.getSize();
/* 424 */     return this.pixelStore.getPicture(size.getWidth() + 15 & 0xFFFFFFF0, size.getHeight() + 15 & 0xFFFFFFF0, videoMeta
/* 425 */         .getColor());
/*     */   }
/*     */ 
/*     */   
/*     */   public VideoCodecMeta getVideoCodecMeta() {
/* 430 */     if (this.videoCodecMeta != null)
/* 431 */       return this.videoCodecMeta; 
/* 432 */     DemuxerTrackMeta meta = getTrackVideoMeta();
/* 433 */     if (meta != null && meta.getVideoCodecMeta() != null) {
/* 434 */       this.videoCodecMeta = meta.getVideoCodecMeta();
/*     */     }
/* 436 */     return this.videoCodecMeta;
/*     */   }
/*     */ 
/*     */   
/*     */   public VideoFrameWithPacket getNextVideoFrame() throws IOException {
/*     */     Packet inVideoPacket;
/* 442 */     while ((inVideoPacket = getNextVideoPacket()) != null) {
/* 443 */       if (inVideoPacket.getFrameType() == Packet.FrameType.UNKNOWN) {
/* 444 */         detectFrameType(inVideoPacket);
/*     */       }
/* 446 */       Picture decodedFrame = null;
/* 447 */       PixelStore.LoanerPicture pixelBuffer = getPixelBuffer(inVideoPacket.getData());
/* 448 */       decodedFrame = decodeVideo(inVideoPacket.getData(), pixelBuffer.getPicture());
/* 449 */       if (decodedFrame == null) {
/* 450 */         this.pixelStore.putBack(pixelBuffer);
/*     */         continue;
/*     */       } 
/* 453 */       this.frameReorderBuffer.add(new VideoFrameWithPacket(inVideoPacket, new PixelStore.LoanerPicture(decodedFrame, 1)));
/* 454 */       if (this.frameReorderBuffer.size() > 7) {
/* 455 */         return removeFirstFixDuration(this.frameReorderBuffer);
/*     */       }
/*     */     } 
/*     */ 
/*     */     
/* 460 */     if (this.frameReorderBuffer.size() > 0) {
/* 461 */       return removeFirstFixDuration(this.frameReorderBuffer);
/*     */     }
/*     */ 
/*     */ 
/*     */     
/* 466 */     return null;
/*     */   }
/*     */   
/*     */   private VideoFrameWithPacket removeFirstFixDuration(List<VideoFrameWithPacket> reorderBuffer) {
/* 470 */     Collections.sort(reorderBuffer);
/* 471 */     VideoFrameWithPacket frame = reorderBuffer.remove(0);
/* 472 */     if (!reorderBuffer.isEmpty()) {
/*     */       
/* 474 */       VideoFrameWithPacket nextFrame = reorderBuffer.get(0);
/* 475 */       frame.getPacket().setDuration(nextFrame.getPacket().getPts() - frame.getPacket().getPts());
/*     */     } 
/* 477 */     return frame;
/*     */   }
/*     */   
/*     */   public AudioFrameWithPacket getNextAudioFrame() throws IOException {
/*     */     AudioBuffer audioBuffer;
/* 482 */     Packet audioPkt = inputAudioPacket();
/* 483 */     if (audioPkt == null) {
/* 484 */       return null;
/*     */     }
/* 486 */     if (this.inputAudioCodec.v2 == Codec.PCM) {
/* 487 */       DemuxerTrackMeta audioMeta = getAudioMeta();
/*     */       
/* 489 */       audioBuffer = new AudioBuffer(audioPkt.getData(), audioMeta.getAudioCodecMeta().getFormat(), audioMeta.getTotalFrames());
/*     */     } else {
/* 491 */       audioBuffer = this.audioDecoder.decodeFrame(audioPkt.getData(), null);
/*     */     } 
/* 493 */     return new AudioFrameWithPacket(audioBuffer, audioPkt);
/*     */   }
/*     */   
/*     */   public Tuple._3<Integer, Integer, Codec> getIntputVideoCodec() {
/* 497 */     return this.inputVideoCodec;
/*     */   }
/*     */   
/*     */   public Tuple._3<Integer, Integer, Codec> getInputAudioCode() {
/* 501 */     return this.inputAudioCodec;
/*     */   }
/*     */ 
/*     */   
/*     */   public void setOption(Options option, Object value) {
/* 506 */     if (option == Options.DOWNSCALE) {
/* 507 */       this.downscale = ((Integer)value).intValue();
/*     */     }
/*     */   }
/*     */   
/*     */   public AudioCodecMeta getAudioCodecMeta() {
/* 512 */     if (this.audioInputTrack != null && this.audioInputTrack.getMeta() != null && this.audioInputTrack
/* 513 */       .getMeta().getAudioCodecMeta() != null) {
/* 514 */       return this.audioInputTrack.getMeta().getAudioCodecMeta();
/*     */     }
/* 516 */     return this.audioCodecMeta;
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean isVideo() {
/* 521 */     if (!this.inputFormat.isVideo())
/* 522 */       return false; 
/* 523 */     List<? extends DemuxerTrack> tracks = this.demuxVideo.getVideoTracks();
/* 524 */     return (tracks != null && tracks.size() > 0);
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean isAudio() {
/* 529 */     if (!this.inputFormat.isAudio())
/* 530 */       return false; 
/* 531 */     List<? extends DemuxerTrack> tracks = this.demuxAudio.getAudioTracks();
/* 532 */     return (tracks != null && tracks.size() > 0);
/*     */   }
/*     */   
/*     */   public static JpegDecoder createJpegDecoder(int downscale) {
/* 536 */     if (downscale == 2)
/* 537 */       return (JpegDecoder)new JpegToThumb4x4(); 
/* 538 */     if (downscale == 4) {
/* 539 */       return (JpegDecoder)new JpegToThumb2x2();
/*     */     }
/* 541 */     return new JpegDecoder();
/*     */   }
/*     */ }


/* Location:              C:\Users\rapha\Downloads\aurora.jar!\META-INF\jars\jcodec-0.2.5.jar!\org\jcodec\api\transcode\SourceImpl.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */