/*    */ package org.jcodec.api.transcode;
/*    */ 
/*    */ import org.jcodec.common.model.AudioBuffer;
/*    */ import org.jcodec.common.model.Packet;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class AudioFrameWithPacket
/*    */ {
/*    */   private AudioBuffer audio;
/*    */   private Packet packet;
/*    */   
/*    */   public AudioFrameWithPacket(AudioBuffer audio, Packet packet) {
/* 18 */     this.audio = audio;
/* 19 */     this.packet = packet;
/*    */   }
/*    */ 
/*    */   
/*    */   public AudioBuffer getAudio() {
/* 24 */     return this.audio;
/*    */   }
/*    */ 
/*    */   
/*    */   public Packet getPacket() {
/* 29 */     return this.packet;
/*    */   }
/*    */ }


/* Location:              C:\Users\rapha\Downloads\aurora.jar!\META-INF\jars\jcodec-0.2.5.jar!\org\jcodec\api\transcode\AudioFrameWithPacket.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */