/*    */ package org.jcodec.api.transcode;public interface PixelStore {
/*    */   LoanerPicture getPicture(int paramInt1, int paramInt2, ColorSpace paramColorSpace);
/*    */   
/*    */   void putBack(LoanerPicture paramLoanerPicture);
/*    */   
/*    */   void retake(LoanerPicture paramLoanerPicture);
/*    */   
/*    */   public static class LoanerPicture {
/*    */     private Picture picture;
/*    */     
/*    */     public LoanerPicture(Picture picture, int refCnt) {
/* 12 */       this.picture = picture;
/* 13 */       this.refCnt = refCnt;
/*    */     }
/*    */     private int refCnt;
/*    */     public Picture getPicture() {
/* 17 */       return this.picture;
/*    */     }
/*    */     
/*    */     public int getRefCnt() {
/* 21 */       return this.refCnt;
/*    */     }
/*    */     
/*    */     public void decRefCnt() {
/* 25 */       this.refCnt--;
/*    */     }
/*    */     
/*    */     public boolean unused() {
/* 29 */       return (this.refCnt <= 0);
/*    */     }
/*    */     
/*    */     public void incRefCnt() {
/* 33 */       this.refCnt++;
/*    */     }
/*    */   }
/*    */ }


/* Location:              C:\Users\rapha\Downloads\aurora.jar!\META-INF\jars\jcodec-0.2.5.jar!\org\jcodec\api\transcode\PixelStore.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */