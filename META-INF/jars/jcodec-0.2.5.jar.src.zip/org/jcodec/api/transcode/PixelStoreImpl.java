/*    */ package org.jcodec.api.transcode;
/*    */ 
/*    */ import java.util.ArrayList;
/*    */ import java.util.List;
/*    */ import org.jcodec.common.model.ColorSpace;
/*    */ import org.jcodec.common.model.Picture;
/*    */ 
/*    */ 
/*    */ 
/*    */ public class PixelStoreImpl
/*    */   implements PixelStore
/*    */ {
/* 13 */   private List<Picture> buffers = new ArrayList<Picture>();
/*    */ 
/*    */ 
/*    */   
/*    */   public PixelStore.LoanerPicture getPicture(int width, int height, ColorSpace color) {
/* 18 */     for (Picture picture : this.buffers) {
/* 19 */       if (picture.getWidth() == width && picture.getHeight() == height && picture
/* 20 */         .getColor() == color) {
/* 21 */         this.buffers.remove(picture);
/* 22 */         return new PixelStore.LoanerPicture(picture, 1);
/*    */       } 
/*    */     } 
/* 25 */     return new PixelStore.LoanerPicture(Picture.create(width, height, color), 1);
/*    */   }
/*    */ 
/*    */   
/*    */   public void putBack(PixelStore.LoanerPicture frame) {
/* 30 */     frame.decRefCnt();
/* 31 */     if (frame.unused()) {
/* 32 */       Picture pixels = frame.getPicture();
/* 33 */       pixels.setCrop(null);
/* 34 */       this.buffers.add(pixels);
/*    */     } 
/*    */   }
/*    */ 
/*    */   
/*    */   public void retake(PixelStore.LoanerPicture frame) {
/* 40 */     frame.incRefCnt();
/*    */   }
/*    */ }


/* Location:              C:\Users\rapha\Downloads\aurora.jar!\META-INF\jars\jcodec-0.2.5.jar!\org\jcodec\api\transcode\PixelStoreImpl.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */