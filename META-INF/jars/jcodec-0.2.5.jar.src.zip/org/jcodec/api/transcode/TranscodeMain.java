/*     */ package org.jcodec.api.transcode;
/*     */ 
/*     */ import java.io.File;
/*     */ import java.io.IOException;
/*     */ import java.util.ArrayList;
/*     */ import java.util.HashMap;
/*     */ import java.util.HashSet;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import java.util.Set;
/*     */ import org.jcodec.api.transcode.filters.DumpMvFilter;
/*     */ import org.jcodec.api.transcode.filters.ScaleFilter;
/*     */ import org.jcodec.common.Codec;
/*     */ import org.jcodec.common.Demuxer;
/*     */ import org.jcodec.common.DemuxerTrack;
/*     */ import org.jcodec.common.DemuxerTrackMeta;
/*     */ import org.jcodec.common.Format;
/*     */ import org.jcodec.common.JCodecUtil;
/*     */ import org.jcodec.common.TrackType;
/*     */ import org.jcodec.common.Tuple;
/*     */ import org.jcodec.common.logging.LogLevel;
/*     */ import org.jcodec.common.logging.LogSink;
/*     */ import org.jcodec.common.logging.Logger;
/*     */ import org.jcodec.common.logging.OutLogSink;
/*     */ import org.jcodec.common.model.Packet;
/*     */ import org.jcodec.common.tools.MainUtils;
/*     */ import org.jcodec.common.tools.MathUtil;
/*     */ import org.jcodec.platform.Platform;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class TranscodeMain
/*     */ {
/*  49 */   private static final MainUtils.Flag FLAG_INPUT = new MainUtils.Flag("input", "i", "Designates an input argument", MainUtils.FlagType.VOID);
/*  50 */   private static final MainUtils.Flag FLAG_MAP_VIDEO = MainUtils.Flag.flag("map:v", "mv", "Map a video from a specified input into this output");
/*     */   
/*  52 */   private static final MainUtils.Flag FLAG_MAP_AUDIO = MainUtils.Flag.flag("map:a", "ma", "Map a audio from a specified input into this output");
/*     */   
/*  54 */   private static final MainUtils.Flag FLAG_SEEK_FRAMES = MainUtils.Flag.flag("seek-frames", null, "Seek frames");
/*  55 */   private static final MainUtils.Flag FLAG_MAX_FRAMES = MainUtils.Flag.flag("max-frames", "limit", "Max frames");
/*     */   
/*  57 */   private static final MainUtils.Flag FLAG_AUDIO_CODEC = MainUtils.Flag.flag("codec:audio", "acodec", "Audio codec [default=auto].");
/*  58 */   private static final MainUtils.Flag FLAG_VIDEO_CODEC = MainUtils.Flag.flag("codec:video", "vcodec", "Video codec [default=auto].");
/*  59 */   private static final MainUtils.Flag FLAG_FORMAT = MainUtils.Flag.flag("format", "f", "Format [default=auto].");
/*     */   
/*  61 */   private static final MainUtils.Flag FLAG_PROFILE = MainUtils.Flag.flag("profile", null, "Profile to use (supported by some encoders).");
/*  62 */   private static final MainUtils.Flag FLAG_INTERLACED = MainUtils.Flag.flag("interlaced", null, "Encode output as interlaced (supported by Prores encoder).");
/*     */   
/*  64 */   private static final MainUtils.Flag FLAG_DUMPMV = MainUtils.Flag.flag("dumpMv", null, "Dump motion vectors (supported by h.264 decoder).");
/*  65 */   private static final MainUtils.Flag FLAG_DUMPMVJS = MainUtils.Flag.flag("dumpMvJs", null, "Dump motion vectors in form of JASON file (supported by h.264 decoder).");
/*     */   
/*  67 */   private static final MainUtils.Flag FLAG_DOWNSCALE = MainUtils.Flag.flag("downscale", null, "Decode frames in downscale (supported by MPEG, Prores and Jpeg decoders).");
/*     */   
/*  69 */   private static final MainUtils.Flag FLAG_VIDEO_FILTER = MainUtils.Flag.flag("videoFilter", "vf", "Contains a comma separated list of video filters with arguments.");
/*     */ 
/*     */   
/*  72 */   private static final MainUtils.Flag[] ALL_FLAGS = new MainUtils.Flag[] { FLAG_INPUT, FLAG_FORMAT, FLAG_VIDEO_CODEC, FLAG_AUDIO_CODEC, FLAG_SEEK_FRAMES, FLAG_MAX_FRAMES, FLAG_PROFILE, FLAG_INTERLACED, FLAG_DUMPMV, FLAG_DUMPMVJS, FLAG_DOWNSCALE, FLAG_MAP_VIDEO, FLAG_MAP_AUDIO, FLAG_VIDEO_FILTER };
/*     */ 
/*     */ 
/*     */   
/*  76 */   private static Map<String, Format> extensionToF = new HashMap<String, Format>();
/*  77 */   private static Map<String, Codec> extensionToC = new HashMap<String, Codec>();
/*  78 */   private static Map<Format, Codec> videoCodecsForF = new HashMap<Format, Codec>();
/*  79 */   private static Map<Format, Codec> audioCodecsForF = new HashMap<Format, Codec>();
/*  80 */   private static Set<Codec> supportedDecoders = new HashSet<Codec>();
/*  81 */   private static Map<String, Class<? extends Filter>> knownFilters = new HashMap<String, Class<? extends Filter>>();
/*     */   
/*     */   static {
/*  84 */     extensionToF.put("mp3", Format.MPEG_AUDIO);
/*  85 */     extensionToF.put("mp2", Format.MPEG_AUDIO);
/*  86 */     extensionToF.put("mp1", Format.MPEG_AUDIO);
/*  87 */     extensionToF.put("mpg", Format.MPEG_PS);
/*  88 */     extensionToF.put("mpeg", Format.MPEG_PS);
/*  89 */     extensionToF.put("m2p", Format.MPEG_PS);
/*  90 */     extensionToF.put("ps", Format.MPEG_PS);
/*  91 */     extensionToF.put("vob", Format.MPEG_PS);
/*  92 */     extensionToF.put("evo", Format.MPEG_PS);
/*  93 */     extensionToF.put("mod", Format.MPEG_PS);
/*  94 */     extensionToF.put("tod", Format.MPEG_PS);
/*     */     
/*  96 */     extensionToF.put("ts", Format.MPEG_TS);
/*  97 */     extensionToF.put("m2t", Format.MPEG_TS);
/*     */     
/*  99 */     extensionToF.put("mp4", Format.MOV);
/* 100 */     extensionToF.put("m4a", Format.MOV);
/* 101 */     extensionToF.put("m4v", Format.MOV);
/* 102 */     extensionToF.put("mov", Format.MOV);
/* 103 */     extensionToF.put("3gp", Format.MOV);
/*     */     
/* 105 */     extensionToF.put("mkv", Format.MKV);
/* 106 */     extensionToF.put("webm", Format.MKV);
/*     */     
/* 108 */     extensionToF.put("264", Format.H264);
/* 109 */     extensionToF.put("jsv", Format.H264);
/* 110 */     extensionToF.put("h264", Format.H264);
/* 111 */     extensionToF.put("raw", Format.RAW);
/* 112 */     extensionToF.put("", Format.RAW);
/* 113 */     extensionToF.put("flv", Format.FLV);
/* 114 */     extensionToF.put("avi", Format.AVI);
/* 115 */     extensionToF.put("jpg", Format.IMG);
/* 116 */     extensionToF.put("jpeg", Format.IMG);
/* 117 */     extensionToF.put("png", Format.IMG);
/*     */     
/* 119 */     extensionToF.put("mjp", Format.MJPEG);
/*     */     
/* 121 */     extensionToF.put("ivf", Format.IVF);
/* 122 */     extensionToF.put("y4m", Format.Y4M);
/* 123 */     extensionToF.put("wav", Format.WAV);
/*     */     
/* 125 */     extensionToC.put("mpg", Codec.MPEG2);
/* 126 */     extensionToC.put("mpeg", Codec.MPEG2);
/* 127 */     extensionToC.put("m2p", Codec.MPEG2);
/* 128 */     extensionToC.put("ps", Codec.MPEG2);
/* 129 */     extensionToC.put("vob", Codec.MPEG2);
/* 130 */     extensionToC.put("evo", Codec.MPEG2);
/* 131 */     extensionToC.put("mod", Codec.MPEG2);
/* 132 */     extensionToC.put("tod", Codec.MPEG2);
/* 133 */     extensionToC.put("ts", Codec.MPEG2);
/* 134 */     extensionToC.put("m2t", Codec.MPEG2);
/* 135 */     extensionToC.put("m4a", Codec.AAC);
/* 136 */     extensionToC.put("mkv", Codec.H264);
/* 137 */     extensionToC.put("webm", Codec.VP8);
/* 138 */     extensionToC.put("264", Codec.H264);
/* 139 */     extensionToC.put("raw", Codec.RAW);
/* 140 */     extensionToC.put("jpg", Codec.JPEG);
/* 141 */     extensionToC.put("jpeg", Codec.JPEG);
/* 142 */     extensionToC.put("png", Codec.PNG);
/* 143 */     extensionToC.put("mjp", Codec.JPEG);
/* 144 */     extensionToC.put("y4m", Codec.RAW);
/*     */     
/* 146 */     videoCodecsForF.put(Format.MPEG_PS, Codec.MPEG2);
/* 147 */     audioCodecsForF.put(Format.MPEG_PS, Codec.MP2);
/* 148 */     videoCodecsForF.put(Format.MOV, Codec.H264);
/* 149 */     audioCodecsForF.put(Format.MOV, Codec.AAC);
/* 150 */     videoCodecsForF.put(Format.MKV, Codec.VP8);
/* 151 */     audioCodecsForF.put(Format.MKV, Codec.VORBIS);
/* 152 */     audioCodecsForF.put(Format.WAV, Codec.PCM);
/* 153 */     videoCodecsForF.put(Format.H264, Codec.H264);
/* 154 */     videoCodecsForF.put(Format.RAW, Codec.RAW);
/* 155 */     videoCodecsForF.put(Format.FLV, Codec.H264);
/* 156 */     videoCodecsForF.put(Format.AVI, Codec.MPEG4);
/* 157 */     videoCodecsForF.put(Format.IMG, Codec.PNG);
/* 158 */     videoCodecsForF.put(Format.MJPEG, Codec.JPEG);
/* 159 */     videoCodecsForF.put(Format.IVF, Codec.VP8);
/* 160 */     videoCodecsForF.put(Format.Y4M, Codec.RAW);
/*     */     
/* 162 */     supportedDecoders.add(Codec.AAC);
/* 163 */     supportedDecoders.add(Codec.H264);
/* 164 */     supportedDecoders.add(Codec.JPEG);
/* 165 */     supportedDecoders.add(Codec.MPEG2);
/* 166 */     supportedDecoders.add(Codec.PCM);
/* 167 */     supportedDecoders.add(Codec.PNG);
/* 168 */     supportedDecoders.add(Codec.MPEG4);
/* 169 */     supportedDecoders.add(Codec.PRORES);
/* 170 */     supportedDecoders.add(Codec.RAW);
/* 171 */     supportedDecoders.add(Codec.VP8);
/* 172 */     supportedDecoders.add(Codec.MP3);
/* 173 */     supportedDecoders.add(Codec.MP2);
/* 174 */     supportedDecoders.add(Codec.MP1);
/*     */     
/* 176 */     knownFilters.put("scale", ScaleFilter.class);
/*     */   }
/*     */   
/*     */   public static void main(String[] args) throws Exception {
/* 180 */     Logger.addSink((LogSink)new OutLogSink(System.out, (OutLogSink.MessageFormat)new OutLogSink.SimpleFormat("#message"), LogLevel.INFO));
/*     */     
/* 182 */     MainUtils.Cmd cmd = MainUtils.parseArguments(args, ALL_FLAGS);
/*     */     
/* 184 */     Transcoder.TranscoderBuilder builder = Transcoder.newTranscoder();
/*     */     
/* 186 */     List<Source> sources = new ArrayList<Source>();
/* 187 */     List<Tuple._3<Integer, Integer, Codec>> inputCodecsVideo = new ArrayList<Tuple._3<Integer, Integer, Codec>>();
/* 188 */     List<Tuple._3<Integer, Integer, Codec>> inputCodecsAudio = new ArrayList<Tuple._3<Integer, Integer, Codec>>();
/*     */     
/* 190 */     for (int index = 0; index < cmd.argsLength(); index++) {
/* 191 */       if (cmd.getBooleanFlagI(index, FLAG_INPUT).booleanValue()) {
/*     */         Format inputFormat;
/* 193 */         Tuple._3<Integer, Integer, Codec> inputCodecVideo = null, inputCodecAudio = null;
/* 194 */         String input = cmd.getArg(index);
/*     */         
/* 196 */         String inputFormatRaw = cmd.getStringFlagI(index, FLAG_FORMAT);
/*     */         
/* 198 */         if (inputFormatRaw == null) {
/* 199 */           inputFormat = getFormatFromExtension(input);
/* 200 */           if (inputFormat != Format.IMG) {
/* 201 */             Format detectFormat = JCodecUtil.detectFormat(new File(input));
/* 202 */             if (detectFormat != null) {
/* 203 */               inputFormat = detectFormat;
/*     */             }
/*     */           } 
/*     */         } else {
/* 207 */           inputFormat = Format.valueOf(inputFormatRaw.toUpperCase());
/*     */         } 
/* 209 */         if (inputFormat == null) {
/* 210 */           Logger.error("Input format could not be detected");
/*     */           return;
/*     */         } 
/* 213 */         Logger.info(String.format("Input stream %d: %s", new Object[] { Integer.valueOf(index), String.valueOf(inputFormat) }));
/*     */ 
/*     */         
/* 216 */         int videoTrackNo = -1;
/* 217 */         String inputCodecVideoRaw = cmd.getStringFlagI(index, FLAG_VIDEO_CODEC);
/* 218 */         if (inputCodecVideoRaw == null) {
/* 219 */           if (inputFormat == Format.IMG) {
/* 220 */             inputCodecVideo = Tuple.triple(Integer.valueOf(0), Integer.valueOf(0), getCodecFromExtension(input));
/* 221 */           } else if (inputFormat.isVideo()) {
/* 222 */             inputCodecVideo = selectSuitableTrack(input, inputFormat, TrackType.VIDEO);
/*     */           } 
/*     */         } else {
/* 225 */           inputCodecVideo = Tuple.triple(Integer.valueOf(0), Integer.valueOf(0), Codec.valueOf(inputCodecVideoRaw.toUpperCase()));
/*     */         } 
/*     */         
/* 228 */         if (inputCodecVideo != null) {
/* 229 */           if (inputFormat == Format.MPEG_TS) {
/* 230 */             Logger.info(String.format("Video codec: %s[pid=%d,stream=%d]", new Object[] { String.valueOf(inputCodecVideo.v2), inputCodecVideo.v0, inputCodecVideo.v1 }));
/*     */           } else {
/* 232 */             Logger.info(String.format("Video codec: %s", new Object[] { String.valueOf(inputCodecVideo.v2) }));
/*     */           } 
/*     */         }
/*     */         
/* 236 */         String inputCodecAudioRaw = cmd.getStringFlagI(index, FLAG_AUDIO_CODEC);
/* 237 */         if (inputCodecAudioRaw == null) {
/* 238 */           if (inputFormat.isAudio()) {
/* 239 */             inputCodecAudio = selectSuitableTrack(input, inputFormat, TrackType.AUDIO);
/*     */           }
/*     */         } else {
/* 242 */           inputCodecAudio = Tuple.triple(Integer.valueOf(0), Integer.valueOf(0), Codec.valueOf(inputCodecAudioRaw.toUpperCase()));
/*     */         } 
/*     */         
/* 245 */         if (inputCodecAudio != null) {
/* 246 */           if (inputFormat == Format.MPEG_TS) {
/* 247 */             Logger.info(String.format("Audio codec: %s[pid=%d,stream=%d]", new Object[] { String.valueOf(inputCodecAudio.v2), inputCodecAudio.v0, inputCodecAudio.v1 }));
/*     */           } else {
/*     */             
/* 250 */             Logger.info(String.format("Audio codec: %s", new Object[] { String.valueOf(inputCodecAudio.v2) }));
/*     */           } 
/*     */         }
/*     */         
/* 254 */         Source source = new SourceImpl(input, inputFormat, inputCodecVideo, inputCodecAudio);
/* 255 */         Integer downscale = cmd.getIntegerFlagID(index, FLAG_DOWNSCALE, Integer.valueOf(1));
/* 256 */         if (downscale != null && 1 << MathUtil.log2(downscale.intValue()) != downscale.intValue()) {
/* 257 */           Logger.error("Only values [2, 4, 8] are supported for " + FLAG_DOWNSCALE + ", the option will have no effect.");
/*     */         } else {
/*     */           
/* 260 */           source.setOption(Options.DOWNSCALE, downscale);
/*     */         } 
/* 262 */         source.setOption(Options.PROFILE, cmd.getStringFlagI(index, FLAG_PROFILE));
/* 263 */         source.setOption(Options.INTERLACED, cmd.getBooleanFlagID(index, FLAG_INTERLACED, Boolean.valueOf(false)));
/* 264 */         sources.add(source);
/* 265 */         inputCodecsVideo.add(inputCodecVideo);
/* 266 */         inputCodecsAudio.add(inputCodecAudio);
/* 267 */         builder.addSource(source);
/* 268 */         builder.setSeekFrames(sources.size() - 1, cmd.getIntegerFlagID(index, FLAG_SEEK_FRAMES, Integer.valueOf(0)).intValue())
/* 269 */           .setMaxFrames(sources.size() - 1, cmd.getIntegerFlagID(index, FLAG_MAX_FRAMES, Integer.valueOf(2147483647)).intValue());
/*     */       } 
/*     */     } 
/* 272 */     if (sources.isEmpty()) {
/* 273 */       MainUtils.printHelpArgs(ALL_FLAGS, new String[] { "input", "output" });
/*     */       
/*     */       return;
/*     */     } 
/*     */     
/* 278 */     List<Sink> sinks = new ArrayList<Sink>();
/* 279 */     for (int i = 0; i < cmd.argsLength(); i++) {
/* 280 */       if (!cmd.getBooleanFlagI(i, FLAG_INPUT).booleanValue()) {
/*     */         Format outputFormat;
/* 282 */         String output = cmd.getArg(i);
/* 283 */         String outputFormatRaw = cmd.getStringFlagI(i, FLAG_FORMAT);
/*     */         
/* 285 */         if (outputFormatRaw == null) {
/* 286 */           outputFormat = getFormatFromExtension(output);
/*     */         } else {
/* 288 */           outputFormat = Format.valueOf(outputFormatRaw.toUpperCase());
/*     */         } 
/* 290 */         String outputCodecVideoRaw = cmd.getStringFlagI(i, FLAG_VIDEO_CODEC);
/* 291 */         Codec outputCodecVideo = null;
/* 292 */         boolean videoCopy = false;
/* 293 */         if (outputCodecVideoRaw == null) {
/* 294 */           outputCodecVideo = getCodecFromExtension(output);
/* 295 */           if (outputCodecVideo == null) {
/* 296 */             outputCodecVideo = getFirstVideoCodecForFormat(outputFormat);
/*     */           }
/* 298 */         } else if ("copy".equalsIgnoreCase(outputCodecVideoRaw)) {
/* 299 */           videoCopy = true;
/* 300 */         } else if ("none".equalsIgnoreCase(outputCodecVideoRaw)) {
/* 301 */           outputCodecVideo = null;
/*     */         } else {
/* 303 */           outputCodecVideo = Codec.valueOf(outputCodecVideoRaw.toUpperCase());
/*     */         } 
/*     */ 
/*     */         
/* 307 */         String outputCodecAudioRaw = cmd.getStringFlagI(i, FLAG_AUDIO_CODEC);
/* 308 */         Codec outputCodecAudio = null;
/* 309 */         boolean audioCopy = false;
/* 310 */         if (outputCodecAudioRaw == null) {
/* 311 */           if (outputFormat.isAudio()) {
/* 312 */             outputCodecAudio = getFirstAudioCodecForFormat(outputFormat);
/*     */           }
/* 314 */         } else if ("copy".equalsIgnoreCase(outputCodecAudioRaw)) {
/* 315 */           audioCopy = true;
/* 316 */         } else if ("none".equalsIgnoreCase(outputCodecVideoRaw)) {
/* 317 */           outputCodecAudio = null;
/*     */         } else {
/* 319 */           outputCodecAudio = Codec.valueOf(outputCodecAudioRaw.toUpperCase());
/*     */         } 
/*     */ 
/*     */         
/* 323 */         int audioMap = cmd.getIntegerFlagID(i, FLAG_MAP_AUDIO, Integer.valueOf(0)).intValue();
/* 324 */         if (audioMap > sources.size()) {
/* 325 */           Logger.error("Can not map audio from source " + audioMap + ", " + sources
/* 326 */               .size() + " sources specified.");
/*     */         }
/* 328 */         int videoMap = cmd.getIntegerFlagID(i, FLAG_MAP_VIDEO, Integer.valueOf(0)).intValue();
/* 329 */         if (videoMap > sources.size()) {
/* 330 */           Logger.error("Can not map video from source " + videoMap + ", " + sources
/* 331 */               .size() + " sources specified.");
/*     */         }
/* 333 */         if (videoCopy) {
/* 334 */           Tuple._3<Integer, Integer, Codec> inputCodecVideo = inputCodecsVideo.get(videoMap);
/* 335 */           outputCodecVideo = (inputCodecVideo != null) ? (Codec)inputCodecVideo.v2 : null;
/*     */         } 
/* 337 */         if (audioCopy) {
/* 338 */           Tuple._3<Integer, Integer, Codec> inputCodecAudio = inputCodecsAudio.get(audioMap);
/* 339 */           outputCodecAudio = (inputCodecAudio != null) ? (Codec)inputCodecAudio.v2 : null;
/*     */         } 
/*     */         
/* 342 */         Sink sink = new SinkImpl(output, outputFormat, outputCodecVideo, outputCodecAudio);
/* 343 */         sinks.add(sink);
/* 344 */         builder.addSink(sink);
/* 345 */         builder.setAudioMapping(audioMap, sinks.size() - 1, audioCopy);
/* 346 */         builder.setVideoMapping(videoMap, sinks.size() - 1, videoCopy);
/*     */ 
/*     */         
/* 349 */         if (cmd.getBooleanFlagI(i, FLAG_DUMPMV).booleanValue()) {
/* 350 */           builder.addFilter(sinks.size() - 1, (Filter)new DumpMvFilter(false));
/* 351 */         } else if (cmd.getBooleanFlagI(i, FLAG_DUMPMVJS).booleanValue()) {
/* 352 */           builder.addFilter(sinks.size() - 1, (Filter)new DumpMvFilter(true));
/*     */         } 
/* 354 */         String vf = cmd.getStringFlagI(i, FLAG_VIDEO_FILTER);
/* 355 */         if (vf != null) {
/* 356 */           addVideoFilters(vf, builder, sinks.size() - 1);
/*     */         }
/*     */       } 
/*     */     } 
/* 360 */     if (sources.isEmpty() || sinks.isEmpty()) {
/* 361 */       MainUtils.printHelpArgs(ALL_FLAGS, new String[] { "input", "output" });
/*     */       
/*     */       return;
/*     */     } 
/* 365 */     Transcoder transcoder = builder.create();
/*     */     
/* 367 */     transcoder.transcode();
/*     */   }
/*     */   
/*     */   private static void addVideoFilters(String vf, Transcoder.TranscoderBuilder builder, int sinkIndex) {
/* 371 */     if (vf == null)
/*     */       return; 
/* 373 */     for (String filter : vf.split(",")) {
/* 374 */       String[] parts = filter.split("=");
/* 375 */       String filterName = parts[0];
/* 376 */       Class<? extends Filter> filterClass = knownFilters.get(filterName);
/* 377 */       if (filterClass == null) {
/* 378 */         Logger.error("Unknown filter: " + filterName);
/* 379 */         throw new RuntimeException("Unknown filter: " + filterName);
/*     */       } 
/* 381 */       if (parts.length > 1) {
/* 382 */         String filterArgs = parts[1];
/* 383 */         String[] split = filterArgs.split(":");
/* 384 */         Integer[] params = new Integer[split.length];
/* 385 */         for (int i = 0; i < split.length; i++) {
/* 386 */           params[i] = Integer.valueOf(Integer.parseInt(split[i]));
/*     */         }
/*     */         try {
/* 389 */           Filter f = (Filter)Platform.newInstance(filterClass, (Object[])params);
/* 390 */           builder.addFilter(sinkIndex, f);
/* 391 */         } catch (Exception e) {
/* 392 */           String message = "The filter " + filterName + " doesn't take " + split.length + " arguments.";
/* 393 */           Logger.error(message);
/* 394 */           throw new RuntimeException(message);
/*     */         } 
/*     */       } 
/*     */     } 
/*     */   }
/*     */   
/*     */   private static Codec getFirstAudioCodecForFormat(Format inputFormat) {
/* 401 */     return audioCodecsForF.get(inputFormat);
/*     */   }
/*     */   
/*     */   private static Codec getFirstVideoCodecForFormat(Format inputFormat) {
/* 405 */     return videoCodecsForF.get(inputFormat);
/*     */   }
/*     */   
/*     */   private static Codec detectVideoDecoder(DemuxerTrack track) throws IOException {
/* 409 */     DemuxerTrackMeta meta = track.getMeta();
/* 410 */     if (meta != null) {
/* 411 */       Codec codec = meta.getCodec();
/* 412 */       if (codec != null)
/* 413 */         return codec; 
/*     */     } 
/* 415 */     Packet packet = track.nextFrame();
/* 416 */     if (packet == null) {
/* 417 */       return null;
/*     */     }
/* 419 */     return JCodecUtil.detectDecoder(packet.getData());
/*     */   }
/*     */ 
/*     */   
/*     */   private static Tuple._3<Integer, Integer, Codec> selectSuitableTrack(String input, Format format, TrackType targetType) throws IOException {
/*     */     Tuple._2<Integer, Demuxer> demuxerPid;
/* 425 */     if (format == Format.MPEG_TS) {
/* 426 */       demuxerPid = JCodecUtil.createM2TSDemuxer(new File(input), targetType);
/*     */     } else {
/* 428 */       demuxerPid = Tuple.pair(Integer.valueOf(0), JCodecUtil.createDemuxer(format, new File(input)));
/*     */     } 
/* 430 */     if (demuxerPid == null || demuxerPid.v1 == null)
/* 431 */       return null; 
/* 432 */     int trackNo = 0;
/*     */     
/* 434 */     List<? extends DemuxerTrack> tracks = (targetType == TrackType.VIDEO) ? ((Demuxer)demuxerPid.v1).getVideoTracks() : ((Demuxer)demuxerPid.v1).getAudioTracks();
/* 435 */     for (DemuxerTrack demuxerTrack : tracks) {
/* 436 */       Codec codec = detectVideoDecoder(demuxerTrack);
/* 437 */       if (supportedDecoders.contains(codec)) {
/* 438 */         return Tuple.triple(demuxerPid.v0, Integer.valueOf(trackNo), codec);
/*     */       }
/* 440 */       trackNo++;
/*     */     } 
/* 442 */     return null;
/*     */   }
/*     */   
/*     */   private static Format getFormatFromExtension(String output) {
/* 446 */     String extension = output.replaceFirst(".*\\.([^\\.]+$)", "$1");
/* 447 */     return extensionToF.get(extension);
/*     */   }
/*     */   
/*     */   private static Codec getCodecFromExtension(String output) {
/* 451 */     String extension = output.replaceFirst(".*\\.([^\\.]+$)", "$1");
/* 452 */     return extensionToC.get(extension);
/*     */   }
/*     */ }


/* Location:              C:\Users\rapha\Downloads\aurora.jar!\META-INF\jars\jcodec-0.2.5.jar!\org\jcodec\api\transcode\TranscodeMain.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */