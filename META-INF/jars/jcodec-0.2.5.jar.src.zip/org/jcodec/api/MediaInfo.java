/*    */ package org.jcodec.api;
/*    */ 
/*    */ import org.jcodec.common.model.Size;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class MediaInfo
/*    */ {
/*    */   private Size dim;
/*    */   
/*    */   public MediaInfo(Size dim) {
/* 16 */     this.dim = dim;
/*    */   }
/*    */   
/*    */   public Size getDim() {
/* 20 */     return this.dim;
/*    */   }
/*    */   
/*    */   public void setDim(Size dim) {
/* 24 */     this.dim = dim;
/*    */   }
/*    */ }


/* Location:              C:\Users\rapha\Downloads\aurora.jar!\META-INF\jars\jcodec-0.2.5.jar!\org\jcodec\api\MediaInfo.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */