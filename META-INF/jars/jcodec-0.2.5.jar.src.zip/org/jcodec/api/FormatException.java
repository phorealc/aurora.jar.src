/*   */ package org.jcodec.api;
/*   */ 
/*   */ public class FormatException extends RuntimeException {
/*   */   public FormatException(String msg) {
/* 5 */     super(msg);
/*   */   }
/*   */ }


/* Location:              C:\Users\rapha\Downloads\aurora.jar!\META-INF\jars\jcodec-0.2.5.jar!\org\jcodec\api\FormatException.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */