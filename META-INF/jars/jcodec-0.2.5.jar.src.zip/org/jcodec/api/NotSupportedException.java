/*   */ package org.jcodec.api;
/*   */ 
/*   */ public class NotSupportedException
/*   */   extends RuntimeException {
/*   */   public NotSupportedException(String msg) {
/* 6 */     super(msg);
/*   */   }
/*   */ }


/* Location:              C:\Users\rapha\Downloads\aurora.jar!\META-INF\jars\jcodec-0.2.5.jar!\org\jcodec\api\NotSupportedException.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */