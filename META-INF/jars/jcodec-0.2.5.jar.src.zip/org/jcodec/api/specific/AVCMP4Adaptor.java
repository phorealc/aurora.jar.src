/*     */ package org.jcodec.api.specific;
/*     */ 
/*     */ import java.nio.ByteBuffer;
/*     */ import org.jcodec.api.MediaInfo;
/*     */ import org.jcodec.codecs.h264.H264Decoder;
/*     */ import org.jcodec.codecs.h264.H264Utils;
/*     */ import org.jcodec.codecs.h264.io.model.Frame;
/*     */ import org.jcodec.codecs.h264.io.model.NALUnit;
/*     */ import org.jcodec.codecs.h264.io.model.NALUnitType;
/*     */ import org.jcodec.codecs.h264.io.model.SeqParameterSet;
/*     */ import org.jcodec.common.DemuxerTrackMeta;
/*     */ import org.jcodec.common.model.ColorSpace;
/*     */ import org.jcodec.common.model.Packet;
/*     */ import org.jcodec.common.model.Picture;
/*     */ import org.jcodec.common.model.Rational;
/*     */ import org.jcodec.common.model.Size;
/*     */ import org.jcodec.containers.mp4.MP4Packet;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class AVCMP4Adaptor
/*     */   implements ContainerAdaptor
/*     */ {
/*     */   private H264Decoder decoder;
/*     */   private int curENo;
/*     */   private Size size;
/*     */   private DemuxerTrackMeta meta;
/*     */   
/*     */   public AVCMP4Adaptor(DemuxerTrackMeta meta) {
/*  36 */     this.meta = meta;
/*  37 */     this.curENo = -1;
/*     */     
/*  39 */     calcBufferSize();
/*     */   }
/*     */   
/*     */   private void calcBufferSize() {
/*  43 */     int w = Integer.MIN_VALUE, h = Integer.MIN_VALUE;
/*     */     
/*  45 */     ByteBuffer bb = this.meta.getCodecPrivate().duplicate();
/*     */     ByteBuffer b;
/*  47 */     while ((b = H264Utils.nextNALUnit(bb)) != null) {
/*  48 */       NALUnit nu = NALUnit.read(b);
/*  49 */       if (nu.type != NALUnitType.SPS)
/*     */         continue; 
/*  51 */       SeqParameterSet sps = H264Utils.readSPS(b);
/*     */       
/*  53 */       int ww = sps.picWidthInMbsMinus1 + 1;
/*  54 */       if (ww > w)
/*  55 */         w = ww; 
/*  56 */       int hh = SeqParameterSet.getPicHeightInMbs(sps);
/*  57 */       if (hh > h) {
/*  58 */         h = hh;
/*     */       }
/*     */     } 
/*  61 */     this.size = new Size(w << 4, h << 4);
/*     */   }
/*     */ 
/*     */   
/*     */   public Picture decodeFrame(Packet packet, byte[][] data) {
/*  66 */     updateState(packet);
/*     */     
/*  68 */     Frame frame = this.decoder.decodeFrame(packet.getData(), data);
/*  69 */     Rational pasp = this.meta.getVideoCodecMeta().getPixelAspectRatio();
/*     */     
/*  71 */     if (pasp != null);
/*     */ 
/*     */ 
/*     */     
/*  75 */     return (Picture)frame;
/*     */   }
/*     */   
/*     */   private void updateState(Packet packet) {
/*  79 */     int eNo = ((MP4Packet)packet).getEntryNo();
/*  80 */     if (eNo != this.curENo) {
/*  81 */       this.curENo = eNo;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*  87 */     if (this.decoder == null) {
/*  88 */       this.decoder = H264Decoder.createH264DecoderFromCodecPrivate(this.meta.getCodecPrivate());
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean canSeek(Packet pkt) {
/*  94 */     updateState(pkt);
/*  95 */     return H264Utils.idrSlice(H264Utils.splitFrame(pkt.getData()));
/*     */   }
/*     */ 
/*     */   
/*     */   public byte[][] allocatePicture() {
/* 100 */     return Picture.create(this.size.getWidth(), this.size.getHeight(), ColorSpace.YUV444).getData();
/*     */   }
/*     */ 
/*     */   
/*     */   public MediaInfo getMediaInfo() {
/* 105 */     return new MediaInfo(this.size);
/*     */   }
/*     */ }


/* Location:              C:\Users\rapha\Downloads\aurora.jar!\META-INF\jars\jcodec-0.2.5.jar!\org\jcodec\api\specific\AVCMP4Adaptor.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */