/*    */ package org.jcodec.api.specific;
/*    */ 
/*    */ import org.jcodec.api.MediaInfo;
/*    */ import org.jcodec.common.VideoDecoder;
/*    */ import org.jcodec.common.model.ColorSpace;
/*    */ import org.jcodec.common.model.Packet;
/*    */ import org.jcodec.common.model.Picture;
/*    */ import org.jcodec.common.model.Size;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class GenericAdaptor
/*    */   implements ContainerAdaptor
/*    */ {
/*    */   private VideoDecoder decoder;
/*    */   
/*    */   public GenericAdaptor(VideoDecoder detect) {
/* 24 */     this.decoder = detect;
/*    */   }
/*    */ 
/*    */   
/*    */   public Picture decodeFrame(Packet packet, byte[][] data) {
/* 29 */     return this.decoder.decodeFrame(packet.getData(), data);
/*    */   }
/*    */ 
/*    */   
/*    */   public boolean canSeek(Packet data) {
/* 34 */     return true;
/*    */   }
/*    */ 
/*    */   
/*    */   public MediaInfo getMediaInfo() {
/* 39 */     return new MediaInfo(new Size(0, 0));
/*    */   }
/*    */ 
/*    */   
/*    */   public byte[][] allocatePicture() {
/* 44 */     return Picture.create(1920, 1088, ColorSpace.YUV444).getData();
/*    */   }
/*    */ }


/* Location:              C:\Users\rapha\Downloads\aurora.jar!\META-INF\jars\jcodec-0.2.5.jar!\org\jcodec\api\specific\GenericAdaptor.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */