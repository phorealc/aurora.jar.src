package org.jcodec.api.specific;

import org.jcodec.api.MediaInfo;
import org.jcodec.common.model.Packet;
import org.jcodec.common.model.Picture;

public interface ContainerAdaptor {
  Picture decodeFrame(Packet paramPacket, byte[][] paramArrayOfbyte);
  
  boolean canSeek(Packet paramPacket);
  
  byte[][] allocatePicture();
  
  MediaInfo getMediaInfo();
}


/* Location:              C:\Users\rapha\Downloads\aurora.jar!\META-INF\jars\jcodec-0.2.5.jar!\org\jcodec\api\specific\ContainerAdaptor.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */