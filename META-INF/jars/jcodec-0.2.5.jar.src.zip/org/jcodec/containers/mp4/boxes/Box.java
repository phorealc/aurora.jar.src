/*     */ package org.jcodec.containers.mp4.boxes;
/*     */ 
/*     */ import java.nio.ByteBuffer;
/*     */ import org.jcodec.common.Preconditions;
/*     */ import org.jcodec.common.StringUtils;
/*     */ import org.jcodec.common.UsedViaReflection;
/*     */ import org.jcodec.common.io.NIOUtils;
/*     */ import org.jcodec.containers.mp4.IBoxFactory;
/*     */ import org.jcodec.platform.Platform;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class Box
/*     */ {
/*     */   public Header header;
/*     */   public static final int MAX_BOX_SIZE = 134217728;
/*     */   
/*     */   @UsedViaReflection
/*     */   public Box(Header header) {
/*  31 */     this.header = header;
/*     */   }
/*     */   
/*     */   public Header getHeader() {
/*  35 */     return this.header;
/*     */   }
/*     */   
/*     */   public abstract void parse(ByteBuffer paramByteBuffer);
/*     */   
/*     */   public void write(ByteBuffer buf) {
/*  41 */     ByteBuffer dup = buf.duplicate();
/*  42 */     NIOUtils.skip(buf, 8);
/*  43 */     doWrite(buf);
/*     */     
/*  45 */     this.header.setBodySize(buf.position() - dup.position() - 8);
/*  46 */     Preconditions.checkState((this.header.headerSize() == 8L));
/*  47 */     this.header.write(dup);
/*     */   }
/*     */   
/*     */   protected abstract void doWrite(ByteBuffer paramByteBuffer);
/*     */   
/*     */   public abstract int estimateSize();
/*     */   
/*     */   public String getFourcc() {
/*  55 */     return this.header.getFourcc();
/*     */   }
/*     */   
/*     */   public String toString() {
/*  59 */     StringBuilder sb = new StringBuilder();
/*  60 */     dump(sb);
/*  61 */     return sb.toString();
/*     */   }
/*     */ 
/*     */   
/*     */   protected void dump(StringBuilder sb) {
/*  66 */     sb.append("{\"tag\":\"" + this.header.getFourcc() + "\"}");
/*     */   }
/*     */   
/*     */   public static Box terminatorAtom() {
/*  70 */     return createLeafBox(new Header(Platform.stringFromBytes(new byte[4])), ByteBuffer.allocate(0));
/*     */   }
/*     */   
/*     */   public static String[] path(String path) {
/*  74 */     return StringUtils.splitC(path, '.');
/*     */   }
/*     */   
/*     */   public static LeafBox createLeafBox(Header atom, ByteBuffer data) {
/*  78 */     LeafBox leaf = new LeafBox(atom);
/*  79 */     leaf.data = data;
/*  80 */     return leaf;
/*     */   }
/*     */   
/*     */   public static Box parseBox(ByteBuffer input, Header childAtom, IBoxFactory factory) {
/*  84 */     Box box = factory.newBox(childAtom);
/*     */     
/*  86 */     if (childAtom.getBodySize() < 134217728L) {
/*  87 */       box.parse(input);
/*  88 */       return box;
/*     */     } 
/*  90 */     return new LeafBox(Header.createHeader("free", 8L));
/*     */   }
/*     */ 
/*     */   
/*     */   public static <T extends Box> T asBox(Class<T> class1, Box box) {
/*     */     try {
/*  96 */       Box box1 = (Box)Platform.newInstance(class1, new Object[] { box.getHeader() });
/*  97 */       ByteBuffer buffer = ByteBuffer.allocate((int)box.getHeader().getBodySize());
/*  98 */       box.doWrite(buffer);
/*  99 */       buffer.flip();
/* 100 */       box1.parse(buffer);
/* 101 */       return (T)box1;
/* 102 */     } catch (Exception e) {
/* 103 */       throw new RuntimeException(e);
/*     */     } 
/*     */   }
/*     */   
/*     */   public static class LeafBox extends Box {
/*     */     ByteBuffer data;
/*     */     
/*     */     public LeafBox(Header atom) {
/* 111 */       super(atom);
/*     */     }
/*     */     
/*     */     public void parse(ByteBuffer input) {
/* 115 */       this.data = NIOUtils.read(input, (int)this.header.getBodySize());
/*     */     }
/*     */     
/*     */     public ByteBuffer getData() {
/* 119 */       return this.data.duplicate();
/*     */     }
/*     */ 
/*     */     
/*     */     protected void doWrite(ByteBuffer out) {
/* 124 */       NIOUtils.write(out, this.data);
/*     */     }
/*     */ 
/*     */     
/*     */     public int estimateSize() {
/* 129 */       return this.data.remaining() + Header.estimateHeaderSize(this.data.remaining());
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\rapha\Downloads\aurora.jar!\META-INF\jars\jcodec-0.2.5.jar!\org\jcodec\containers\mp4\boxes\Box.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */