/*    */ package org.jcodec.containers.mp4.boxes;
/*    */ 
/*    */ import java.nio.ByteBuffer;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class CompositionOffsetsBox
/*    */   extends FullBox
/*    */ {
/*    */   private Entry[] entries;
/*    */   
/*    */   public static class Entry
/*    */   {
/*    */     public int count;
/*    */     public int offset;
/*    */     
/*    */     public Entry(int count, int offset) {
/* 23 */       this.count = count;
/* 24 */       this.offset = offset;
/*    */     }
/*    */     
/*    */     public int getCount() {
/* 28 */       return this.count;
/*    */     }
/*    */     
/*    */     public int getOffset() {
/* 32 */       return this.offset;
/*    */     }
/*    */   }
/*    */   
/*    */   public static class LongEntry {
/*    */     public long count;
/*    */     public long offset;
/*    */     
/*    */     public LongEntry(long count, long offset) {
/* 41 */       this.count = count;
/* 42 */       this.offset = offset;
/*    */     }
/*    */     
/*    */     public long getCount() {
/* 46 */       return this.count;
/*    */     }
/*    */     
/*    */     public long getOffset() {
/* 50 */       return this.offset;
/*    */     }
/*    */   }
/*    */   
/*    */   public CompositionOffsetsBox(Header header) {
/* 55 */     super(header);
/*    */   }
/*    */   
/*    */   public static String fourcc() {
/* 59 */     return "ctts";
/*    */   }
/*    */   
/*    */   public static CompositionOffsetsBox createCompositionOffsetsBox(Entry[] entries) {
/* 63 */     CompositionOffsetsBox ctts = new CompositionOffsetsBox(new Header(fourcc()));
/* 64 */     ctts.entries = entries;
/* 65 */     return ctts;
/*    */   }
/*    */ 
/*    */   
/*    */   public void parse(ByteBuffer input) {
/* 70 */     super.parse(input);
/* 71 */     int num = input.getInt();
/*    */     
/* 73 */     this.entries = new Entry[num];
/* 74 */     for (int i = 0; i < num; i++) {
/* 75 */       this.entries[i] = new Entry(input.getInt(), input.getInt());
/*    */     }
/*    */   }
/*    */ 
/*    */   
/*    */   protected void doWrite(ByteBuffer out) {
/* 81 */     super.doWrite(out);
/*    */     
/* 83 */     out.putInt(this.entries.length);
/* 84 */     for (int i = 0; i < this.entries.length; i++) {
/* 85 */       out.putInt((this.entries[i]).count);
/* 86 */       out.putInt((this.entries[i]).offset);
/*    */     } 
/*    */   }
/*    */ 
/*    */   
/*    */   public int estimateSize() {
/* 92 */     return 16 + this.entries.length * 8;
/*    */   }
/*    */   
/*    */   public Entry[] getEntries() {
/* 96 */     return this.entries;
/*    */   }
/*    */ }


/* Location:              C:\Users\rapha\Downloads\aurora.jar!\META-INF\jars\jcodec-0.2.5.jar!\org\jcodec\containers\mp4\boxes\CompositionOffsetsBox.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */