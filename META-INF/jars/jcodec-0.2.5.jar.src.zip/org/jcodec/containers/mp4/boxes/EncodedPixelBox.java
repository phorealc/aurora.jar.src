/*    */ package org.jcodec.containers.mp4.boxes;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class EncodedPixelBox
/*    */   extends ClearApertureBox
/*    */ {
/*    */   public static final String ENOF = "enof";
/*    */   
/*    */   public static EncodedPixelBox createEncodedPixelBox(int width, int height) {
/* 15 */     EncodedPixelBox enof = new EncodedPixelBox(new Header("enof"));
/* 16 */     enof.width = width;
/* 17 */     enof.height = height;
/* 18 */     return enof;
/*    */   }
/*    */   
/*    */   public EncodedPixelBox(Header atom) {
/* 22 */     super(atom);
/*    */   }
/*    */ }


/* Location:              C:\Users\rapha\Downloads\aurora.jar!\META-INF\jars\jcodec-0.2.5.jar!\org\jcodec\containers\mp4\boxes\EncodedPixelBox.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */