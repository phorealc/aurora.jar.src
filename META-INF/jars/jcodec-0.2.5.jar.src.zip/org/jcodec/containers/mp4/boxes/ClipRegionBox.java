/*    */ package org.jcodec.containers.mp4.boxes;
/*    */ 
/*    */ import java.nio.ByteBuffer;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class ClipRegionBox
/*    */   extends Box
/*    */ {
/*    */   private short rgnSize;
/*    */   private short y;
/*    */   private short x;
/*    */   private short height;
/*    */   private short width;
/*    */   
/*    */   public static String fourcc() {
/* 21 */     return "crgn";
/*    */   }
/*    */   
/*    */   public static ClipRegionBox createClipRegionBox(short x, short y, short width, short height) {
/* 25 */     ClipRegionBox b = new ClipRegionBox(new Header(fourcc()));
/* 26 */     b.rgnSize = 10;
/* 27 */     b.x = x;
/* 28 */     b.y = y;
/* 29 */     b.width = width;
/* 30 */     b.height = height;
/* 31 */     return b;
/*    */   }
/*    */   
/*    */   public ClipRegionBox(Header atom) {
/* 35 */     super(atom);
/*    */   }
/*    */   
/*    */   public void parse(ByteBuffer input) {
/* 39 */     this.rgnSize = input.getShort();
/* 40 */     this.y = input.getShort();
/* 41 */     this.x = input.getShort();
/* 42 */     this.height = input.getShort();
/* 43 */     this.width = input.getShort();
/*    */   }
/*    */   
/*    */   protected void doWrite(ByteBuffer out) {
/* 47 */     out.putShort(this.rgnSize);
/* 48 */     out.putShort(this.y);
/* 49 */     out.putShort(this.x);
/* 50 */     out.putShort(this.height);
/* 51 */     out.putShort(this.width);
/*    */   }
/*    */ 
/*    */   
/*    */   public int estimateSize() {
/* 56 */     return 18;
/*    */   }
/*    */   
/*    */   public short getRgnSize() {
/* 60 */     return this.rgnSize;
/*    */   }
/*    */   
/*    */   public short getY() {
/* 64 */     return this.y;
/*    */   }
/*    */   
/*    */   public short getX() {
/* 68 */     return this.x;
/*    */   }
/*    */   
/*    */   public short getHeight() {
/* 72 */     return this.height;
/*    */   }
/*    */   
/*    */   public short getWidth() {
/* 76 */     return this.width;
/*    */   }
/*    */ }


/* Location:              C:\Users\rapha\Downloads\aurora.jar!\META-INF\jars\jcodec-0.2.5.jar!\org\jcodec\containers\mp4\boxes\ClipRegionBox.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */