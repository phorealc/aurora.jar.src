/*    */ package org.jcodec.containers.mp4.boxes;
/*    */ 
/*    */ import java.nio.ByteBuffer;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class ChunkOffsets64Box
/*    */   extends FullBox
/*    */ {
/*    */   private long[] chunkOffsets;
/*    */   
/*    */   public static String fourcc() {
/* 18 */     return "co64";
/*    */   }
/*    */   
/*    */   public static ChunkOffsets64Box createChunkOffsets64Box(long[] offsets) {
/* 22 */     ChunkOffsets64Box co64 = new ChunkOffsets64Box(Header.createHeader(fourcc(), 0L));
/* 23 */     co64.chunkOffsets = offsets;
/* 24 */     return co64;
/*    */   }
/*    */   
/*    */   public ChunkOffsets64Box(Header atom) {
/* 28 */     super(atom);
/*    */   }
/*    */   
/*    */   public void parse(ByteBuffer input) {
/* 32 */     super.parse(input);
/* 33 */     int length = input.getInt();
/* 34 */     this.chunkOffsets = new long[length];
/* 35 */     for (int i = 0; i < length; i++) {
/* 36 */       this.chunkOffsets[i] = input.getLong();
/*    */     }
/*    */   }
/*    */   
/*    */   protected void doWrite(ByteBuffer out) {
/* 41 */     super.doWrite(out);
/* 42 */     out.putInt(this.chunkOffsets.length);
/* 43 */     for (int i = 0; i < this.chunkOffsets.length; i++) {
/* 44 */       long offset = this.chunkOffsets[i];
/* 45 */       out.putLong(offset);
/*    */     } 
/*    */   }
/*    */ 
/*    */   
/*    */   public int estimateSize() {
/* 51 */     return 16 + this.chunkOffsets.length * 8;
/*    */   }
/*    */   
/*    */   public long[] getChunkOffsets() {
/* 55 */     return this.chunkOffsets;
/*    */   }
/*    */   
/*    */   public void setChunkOffsets(long[] chunkOffsets) {
/* 59 */     this.chunkOffsets = chunkOffsets;
/*    */   }
/*    */ }


/* Location:              C:\Users\rapha\Downloads\aurora.jar!\META-INF\jars\jcodec-0.2.5.jar!\org\jcodec\containers\mp4\boxes\ChunkOffsets64Box.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */