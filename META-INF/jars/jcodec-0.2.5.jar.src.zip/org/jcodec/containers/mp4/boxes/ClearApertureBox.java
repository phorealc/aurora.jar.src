/*    */ package org.jcodec.containers.mp4.boxes;
/*    */ 
/*    */ import java.nio.ByteBuffer;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class ClearApertureBox
/*    */   extends FullBox
/*    */ {
/*    */   public static final String CLEF = "clef";
/*    */   protected float width;
/*    */   protected float height;
/*    */   
/*    */   public static ClearApertureBox createClearApertureBox(int width, int height) {
/* 18 */     ClearApertureBox clef = new ClearApertureBox(new Header("clef"));
/* 19 */     clef.width = width;
/* 20 */     clef.height = height;
/* 21 */     return clef;
/*    */   }
/*    */   
/*    */   public ClearApertureBox(Header atom) {
/* 25 */     super(atom);
/*    */   }
/*    */   
/*    */   public void parse(ByteBuffer input) {
/* 29 */     super.parse(input);
/* 30 */     this.width = input.getInt() / 65536.0F;
/* 31 */     this.height = input.getInt() / 65536.0F;
/*    */   }
/*    */   
/*    */   protected void doWrite(ByteBuffer out) {
/* 35 */     super.doWrite(out);
/* 36 */     out.putInt((int)(this.width * 65536.0F));
/* 37 */     out.putInt((int)(this.height * 65536.0F));
/*    */   }
/*    */ 
/*    */   
/*    */   public int estimateSize() {
/* 42 */     return 20;
/*    */   }
/*    */   
/*    */   public float getWidth() {
/* 46 */     return this.width;
/*    */   }
/*    */   
/*    */   public float getHeight() {
/* 50 */     return this.height;
/*    */   }
/*    */ }


/* Location:              C:\Users\rapha\Downloads\aurora.jar!\META-INF\jars\jcodec-0.2.5.jar!\org\jcodec\containers\mp4\boxes\ClearApertureBox.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */