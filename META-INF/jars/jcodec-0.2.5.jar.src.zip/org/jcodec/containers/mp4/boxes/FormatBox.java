/*    */ package org.jcodec.containers.mp4.boxes;
/*    */ 
/*    */ import java.nio.ByteBuffer;
/*    */ import org.jcodec.common.JCodecUtil2;
/*    */ import org.jcodec.common.io.NIOUtils;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class FormatBox
/*    */   extends Box
/*    */ {
/*    */   private String fmt;
/*    */   
/*    */   public FormatBox(Header header) {
/* 20 */     super(header);
/*    */   }
/*    */   
/*    */   public static String fourcc() {
/* 24 */     return "frma";
/*    */   }
/*    */   
/*    */   public static FormatBox createFormatBox(String fmt) {
/* 28 */     FormatBox frma = new FormatBox(new Header(fourcc()));
/* 29 */     frma.fmt = fmt;
/* 30 */     return frma;
/*    */   }
/*    */   
/*    */   public void parse(ByteBuffer input) {
/* 34 */     this.fmt = NIOUtils.readString(input, 4);
/*    */   }
/*    */   
/*    */   protected void doWrite(ByteBuffer out) {
/* 38 */     out.put(JCodecUtil2.asciiString(this.fmt));
/*    */   }
/*    */ 
/*    */   
/*    */   public int estimateSize() {
/* 43 */     return (JCodecUtil2.asciiString(this.fmt)).length + 8;
/*    */   }
/*    */ }


/* Location:              C:\Users\rapha\Downloads\aurora.jar!\META-INF\jars\jcodec-0.2.5.jar!\org\jcodec\containers\mp4\boxes\FormatBox.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */