/*    */ package org.jcodec.containers.mp4.boxes;
/*    */ 
/*    */ import java.nio.ByteBuffer;
/*    */ import org.jcodec.common.JCodecUtil2;
/*    */ import org.jcodec.common.io.NIOUtils;
/*    */ 
/*    */ 
/*    */ 
/*    */ public class HandlerBox
/*    */   extends FullBox
/*    */ {
/*    */   private String componentType;
/*    */   private String componentSubType;
/*    */   private String componentManufacturer;
/*    */   private int componentFlags;
/*    */   private int componentFlagsMask;
/*    */   private String componentName;
/*    */   
/*    */   public HandlerBox(Header atom) {
/* 20 */     super(atom);
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public static String fourcc() {
/* 31 */     return "hdlr";
/*    */   }
/*    */ 
/*    */   
/*    */   public static HandlerBox createHandlerBox(String componentType, String componentSubType, String componentManufacturer, int componentFlags, int componentFlagsMask) {
/* 36 */     HandlerBox hdlr = new HandlerBox(new Header(fourcc()));
/* 37 */     hdlr.componentType = componentType;
/* 38 */     hdlr.componentSubType = componentSubType;
/* 39 */     hdlr.componentManufacturer = componentManufacturer;
/* 40 */     hdlr.componentFlags = componentFlags;
/* 41 */     hdlr.componentFlagsMask = componentFlagsMask;
/* 42 */     hdlr.componentName = "";
/* 43 */     return hdlr;
/*    */   }
/*    */   
/*    */   public void parse(ByteBuffer input) {
/* 47 */     super.parse(input);
/*    */     
/* 49 */     this.componentType = NIOUtils.readString(input, 4);
/* 50 */     this.componentSubType = NIOUtils.readString(input, 4);
/* 51 */     this.componentManufacturer = NIOUtils.readString(input, 4);
/*    */     
/* 53 */     this.componentFlags = input.getInt();
/* 54 */     this.componentFlagsMask = input.getInt();
/* 55 */     this.componentName = NIOUtils.readString(input, input.remaining());
/*    */   }
/*    */   
/*    */   public void doWrite(ByteBuffer out) {
/* 59 */     super.doWrite(out);
/*    */     
/* 61 */     out.put(JCodecUtil2.asciiString(this.componentType));
/* 62 */     out.put(JCodecUtil2.asciiString(this.componentSubType));
/* 63 */     out.put(JCodecUtil2.asciiString(this.componentManufacturer));
/*    */     
/* 65 */     out.putInt(this.componentFlags);
/* 66 */     out.putInt(this.componentFlagsMask);
/* 67 */     if (this.componentName != null) {
/* 68 */       out.put(JCodecUtil2.asciiString(this.componentName));
/*    */     }
/*    */   }
/*    */ 
/*    */   
/*    */   public int estimateSize() {
/* 74 */     return 12 + (JCodecUtil2.asciiString(this.componentType)).length + (JCodecUtil2.asciiString(this.componentSubType)).length + (
/* 75 */       JCodecUtil2.asciiString(this.componentManufacturer)).length + 9;
/*    */   }
/*    */   
/*    */   public String getComponentType() {
/* 79 */     return this.componentType;
/*    */   }
/*    */   
/*    */   public String getComponentSubType() {
/* 83 */     return this.componentSubType;
/*    */   }
/*    */   
/*    */   public String getComponentManufacturer() {
/* 87 */     return this.componentManufacturer;
/*    */   }
/*    */   
/*    */   public int getComponentFlags() {
/* 91 */     return this.componentFlags;
/*    */   }
/*    */   
/*    */   public int getComponentFlagsMask() {
/* 95 */     return this.componentFlagsMask;
/*    */   }
/*    */ }


/* Location:              C:\Users\rapha\Downloads\aurora.jar!\META-INF\jars\jcodec-0.2.5.jar!\org\jcodec\containers\mp4\boxes\HandlerBox.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */