/*     */ package org.jcodec.containers.mp4.boxes;
/*     */ 
/*     */ import java.nio.ByteBuffer;
/*     */ import java.util.ArrayList;
/*     */ import java.util.List;
/*     */ import org.jcodec.common.JCodecUtil2;
/*     */ import org.jcodec.common.io.NIOUtils;
/*     */ import org.jcodec.platform.Platform;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class AliasBox
/*     */   extends FullBox
/*     */ {
/*     */   public static final int DirectoryName = 0;
/*     */   public static final int DirectoryIDs = 1;
/*     */   public static final int AbsolutePath = 2;
/*     */   public static final int AppleShareZoneName = 3;
/*     */   public static final int AppleShareServerName = 4;
/*     */   public static final int AppleShareUserName = 5;
/*     */   public static final int DriverName = 6;
/*     */   public static final int RevisedAppleShare = 9;
/*     */   public static final int AppleRemoteAccessDialup = 10;
/*     */   public static final int UNIXAbsolutePath = 18;
/*     */   public static final int UTF16AbsolutePath = 14;
/*     */   public static final int UFT16VolumeName = 15;
/*     */   public static final int VolumeMountPoint = 19;
/*     */   private String type;
/*     */   private short recordSize;
/*     */   private short version;
/*     */   private short kind;
/*     */   private String volumeName;
/*     */   private int volumeCreateDate;
/*     */   private short volumeSignature;
/*     */   private short volumeType;
/*     */   private int parentDirId;
/*     */   private String fileName;
/*     */   private int fileNumber;
/*     */   private int createdLocalDate;
/*     */   private String fileTypeName;
/*     */   private String creatorName;
/*     */   private short nlvlFrom;
/*     */   private short nlvlTo;
/*     */   private int volumeAttributes;
/*     */   private short fsId;
/*     */   private List<ExtraField> extra;
/*     */   
/*     */   public static String fourcc() {
/*  57 */     return "alis";
/*     */   }
/*     */   
/*     */   public static class ExtraField {
/*     */     short type;
/*     */     int len;
/*     */     byte[] data;
/*     */     
/*     */     public ExtraField(short type, int len, byte[] bs) {
/*  66 */       this.type = type;
/*  67 */       this.len = len;
/*  68 */       this.data = bs;
/*     */     }
/*     */     
/*     */     public String toString() {
/*  72 */       return Platform.stringFromCharset4(this.data, 0, this.len, (this.type == 14 || this.type == 15) ? "UTF-16" : "UTF-8");
/*     */     }
/*     */   }
/*     */   
/*     */   public AliasBox(Header atom) {
/*  77 */     super(atom);
/*     */   }
/*     */   
/*     */   public void parse(ByteBuffer is) {
/*  81 */     super.parse(is);
/*  82 */     if ((this.flags & 0x1) != 0)
/*     */       return; 
/*  84 */     this.type = NIOUtils.readString(is, 4);
/*  85 */     this.recordSize = is.getShort();
/*  86 */     this.version = is.getShort();
/*  87 */     this.kind = is.getShort();
/*  88 */     this.volumeName = NIOUtils.readPascalStringL(is, 27);
/*  89 */     this.volumeCreateDate = is.getInt();
/*  90 */     this.volumeSignature = is.getShort();
/*  91 */     this.volumeType = is.getShort();
/*  92 */     this.parentDirId = is.getInt();
/*  93 */     this.fileName = NIOUtils.readPascalStringL(is, 63);
/*  94 */     this.fileNumber = is.getInt();
/*  95 */     this.createdLocalDate = is.getInt();
/*  96 */     this.fileTypeName = NIOUtils.readString(is, 4);
/*  97 */     this.creatorName = NIOUtils.readString(is, 4);
/*  98 */     this.nlvlFrom = is.getShort();
/*  99 */     this.nlvlTo = is.getShort();
/* 100 */     this.volumeAttributes = is.getInt();
/* 101 */     this.fsId = is.getShort();
/* 102 */     NIOUtils.skip(is, 10);
/*     */     
/* 104 */     this.extra = new ArrayList<ExtraField>();
/*     */     while (true) {
/* 106 */       short type = is.getShort();
/* 107 */       if (type == -1)
/*     */         break; 
/* 109 */       int len = is.getShort();
/* 110 */       byte[] bs = NIOUtils.toArray(NIOUtils.read(is, len + 1 & 0xFFFFFFFE));
/* 111 */       if (bs == null)
/*     */         break; 
/* 113 */       this.extra.add(new ExtraField(type, len, bs));
/*     */     } 
/*     */   }
/*     */   
/*     */   protected void doWrite(ByteBuffer out) {
/* 118 */     super.doWrite(out);
/* 119 */     if ((this.flags & 0x1) != 0)
/*     */       return; 
/* 121 */     out.put(JCodecUtil2.asciiString(this.type), 0, 4);
/* 122 */     out.putShort(this.recordSize);
/* 123 */     out.putShort(this.version);
/* 124 */     out.putShort(this.kind);
/* 125 */     NIOUtils.writePascalStringL(out, this.volumeName, 27);
/* 126 */     out.putInt(this.volumeCreateDate);
/* 127 */     out.putShort(this.volumeSignature);
/* 128 */     out.putShort(this.volumeType);
/* 129 */     out.putInt(this.parentDirId);
/* 130 */     NIOUtils.writePascalStringL(out, this.fileName, 63);
/* 131 */     out.putInt(this.fileNumber);
/* 132 */     out.putInt(this.createdLocalDate);
/* 133 */     out.put(JCodecUtil2.asciiString(this.fileTypeName), 0, 4);
/* 134 */     out.put(JCodecUtil2.asciiString(this.creatorName), 0, 4);
/* 135 */     out.putShort(this.nlvlFrom);
/* 136 */     out.putShort(this.nlvlTo);
/* 137 */     out.putInt(this.volumeAttributes);
/* 138 */     out.putShort(this.fsId);
/* 139 */     out.put(new byte[10]);
/* 140 */     for (ExtraField extraField : this.extra) {
/* 141 */       out.putShort(extraField.type);
/* 142 */       out.putShort((short)extraField.len);
/* 143 */       out.put(extraField.data);
/*     */     } 
/* 145 */     out.putShort((short)-1);
/* 146 */     out.putShort((short)0);
/*     */   }
/*     */ 
/*     */   
/*     */   public int estimateSize() {
/* 151 */     int sz = 166;
/* 152 */     if ((this.flags & 0x1) == 0) {
/* 153 */       for (ExtraField extraField : this.extra) {
/* 154 */         sz += 4 + extraField.data.length;
/*     */       }
/*     */     }
/* 157 */     return 12 + sz;
/*     */   }
/*     */   
/*     */   public int getRecordSize() {
/* 161 */     return this.recordSize;
/*     */   }
/*     */   
/*     */   public String getFileName() {
/* 165 */     return this.fileName;
/*     */   }
/*     */   
/*     */   public List<ExtraField> getExtras() {
/* 169 */     return this.extra;
/*     */   }
/*     */   
/*     */   public ExtraField getExtra(int type) {
/* 173 */     for (ExtraField extraField : this.extra) {
/* 174 */       if (extraField.type == type)
/* 175 */         return extraField; 
/*     */     } 
/* 177 */     return null;
/*     */   }
/*     */   
/*     */   public boolean isSelfRef() {
/* 181 */     return ((this.flags & 0x1) != 0);
/*     */   }
/*     */   
/*     */   public static AliasBox createSelfRef() {
/* 185 */     AliasBox alis = new AliasBox(new Header(fourcc()));
/* 186 */     alis.setFlags(1);
/* 187 */     return alis;
/*     */   }
/*     */   
/*     */   public String getUnixPath() {
/* 191 */     ExtraField extraField = getExtra(18);
/* 192 */     return (extraField == null) ? null : ("/" + extraField.toString());
/*     */   }
/*     */ }


/* Location:              C:\Users\rapha\Downloads\aurora.jar!\META-INF\jars\jcodec-0.2.5.jar!\org\jcodec\containers\mp4\boxes\AliasBox.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */