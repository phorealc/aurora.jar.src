/*     */ package org.jcodec.containers.mp4.boxes;
/*     */ 
/*     */ import java.io.ByteArrayOutputStream;
/*     */ import java.io.IOException;
/*     */ import java.io.InputStream;
/*     */ import java.nio.ByteBuffer;
/*     */ import org.jcodec.common.JCodecUtil2;
/*     */ import org.jcodec.common.io.NIOUtils;
/*     */ import org.jcodec.common.io.SeekableByteChannel;
/*     */ import org.jcodec.common.io.StringReader;
/*     */ import org.jcodec.common.logging.Logger;
/*     */ import org.jcodec.platform.Platform;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class Header
/*     */ {
/*  26 */   public static final byte[] FOURCC_FREE = new byte[] { 102, 114, 101, 101 };
/*     */   private static final long MAX_UNSIGNED_INT = 4294967296L;
/*     */   private String fourcc;
/*     */   private long size;
/*     */   private boolean lng;
/*     */   
/*     */   public Header(String fourcc) {
/*  33 */     this.fourcc = fourcc;
/*     */   }
/*     */   
/*     */   public static Header createHeader(String fourcc, long size) {
/*  37 */     Header header = new Header(fourcc);
/*  38 */     header.size = size;
/*  39 */     return header;
/*     */   }
/*     */   
/*     */   public static Header newHeader(String fourcc, long size, boolean lng) {
/*  43 */     Header header = new Header(fourcc);
/*  44 */     header.size = size;
/*  45 */     header.lng = lng;
/*  46 */     return header;
/*     */   }
/*     */   
/*     */   public static Header read(ByteBuffer input) {
/*  50 */     long size = 0L;
/*  51 */     while (input.remaining() >= 4 && (size = Platform.unsignedInt(input.getInt())) == 0L);
/*     */     
/*  53 */     if (input.remaining() < 4 || (size < 8L && size != 1L)) {
/*  54 */       Logger.error("Broken atom of size " + size);
/*  55 */       return null;
/*     */     } 
/*     */     
/*  58 */     String fourcc = NIOUtils.readString(input, 4);
/*  59 */     boolean lng = false;
/*  60 */     if (size == 1L) {
/*  61 */       if (input.remaining() >= 8) {
/*  62 */         lng = true;
/*  63 */         size = input.getLong();
/*     */       } else {
/*  65 */         Logger.error("Broken atom of size " + size);
/*  66 */         return null;
/*     */       } 
/*     */     }
/*     */     
/*  70 */     return newHeader(fourcc, size, lng);
/*     */   }
/*     */ 
/*     */   
/*     */   public void skip(InputStream di) throws IOException {
/*  75 */     StringReader.sureSkip(di, this.size - headerSize());
/*     */   }
/*     */   
/*     */   public long headerSize() {
/*  79 */     return (this.lng || this.size > 4294967296L) ? 16L : 8L;
/*     */   }
/*     */   
/*     */   public static int estimateHeaderSize(int size) {
/*  83 */     return ((size + 8) > 4294967296L) ? 16 : 8;
/*     */   }
/*     */   
/*     */   public byte[] readContents(InputStream di) throws IOException {
/*  87 */     ByteArrayOutputStream baos = new ByteArrayOutputStream();
/*  88 */     for (int i = 0; i < this.size - headerSize(); i++) {
/*  89 */       baos.write(di.read());
/*     */     }
/*  91 */     return baos.toByteArray();
/*     */   }
/*     */   
/*     */   public String getFourcc() {
/*  95 */     return this.fourcc;
/*     */   }
/*     */   
/*     */   public long getBodySize() {
/*  99 */     return this.size - headerSize();
/*     */   }
/*     */   
/*     */   public void setBodySize(int length) {
/* 103 */     this.size = length + headerSize();
/*     */   }
/*     */   
/*     */   public void write(ByteBuffer out) {
/* 107 */     if (this.size > 4294967296L) {
/* 108 */       out.putInt(1);
/*     */     } else {
/* 110 */       out.putInt((int)this.size);
/* 111 */     }  byte[] bt = JCodecUtil2.asciiString(this.fourcc);
/* 112 */     if (bt != null && bt.length == 4) {
/* 113 */       out.put(bt);
/*     */     } else {
/* 115 */       out.put(FOURCC_FREE);
/* 116 */     }  if (this.size > 4294967296L) {
/* 117 */       out.putLong(this.size);
/*     */     }
/*     */   }
/*     */   
/*     */   public void writeChannel(SeekableByteChannel output) throws IOException {
/* 122 */     ByteBuffer bb = ByteBuffer.allocate(16);
/* 123 */     write(bb);
/* 124 */     bb.flip();
/* 125 */     output.write(bb);
/*     */   }
/*     */   
/*     */   public long getSize() {
/* 129 */     return this.size;
/*     */   }
/*     */ 
/*     */   
/*     */   public int hashCode() {
/* 134 */     int prime = 31;
/* 135 */     int result = 1;
/* 136 */     result = 31 * result + ((this.fourcc == null) ? 0 : this.fourcc.hashCode());
/* 137 */     return result;
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean equals(Object obj) {
/* 142 */     if (this == obj)
/* 143 */       return true; 
/* 144 */     if (obj == null)
/* 145 */       return false; 
/* 146 */     if (getClass() != obj.getClass())
/* 147 */       return false; 
/* 148 */     Header other = (Header)obj;
/* 149 */     if (this.fourcc == null) {
/* 150 */       if (other.fourcc != null)
/* 151 */         return false; 
/* 152 */     } else if (!this.fourcc.equals(other.fourcc)) {
/* 153 */       return false;
/* 154 */     }  return true;
/*     */   }
/*     */ }


/* Location:              C:\Users\rapha\Downloads\aurora.jar!\META-INF\jars\jcodec-0.2.5.jar!\org\jcodec\containers\mp4\boxes\Header.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */