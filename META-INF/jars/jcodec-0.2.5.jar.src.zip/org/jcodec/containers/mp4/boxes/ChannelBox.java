/*     */ package org.jcodec.containers.mp4.boxes;
/*     */ 
/*     */ import java.nio.ByteBuffer;
/*     */ import org.jcodec.common.model.Label;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ChannelBox
/*     */   extends FullBox
/*     */ {
/*     */   private int channelLayout;
/*     */   private int channelBitmap;
/*     */   private ChannelDescription[] descriptions;
/*     */   
/*     */   public static class ChannelDescription
/*     */   {
/*     */     private int channelLabel;
/*     */     private int channelFlags;
/*     */     private float[] coordinates;
/*     */     
/*     */     public ChannelDescription(int channelLabel, int channelFlags, float[] coordinates) {
/*  25 */       this.coordinates = new float[3];
/*  26 */       this.channelLabel = channelLabel;
/*  27 */       this.channelFlags = channelFlags;
/*  28 */       this.coordinates = coordinates;
/*     */     }
/*     */     
/*     */     public int getChannelLabel() {
/*  32 */       return this.channelLabel;
/*     */     }
/*     */     
/*     */     public int getChannelFlags() {
/*  36 */       return this.channelFlags;
/*     */     }
/*     */     
/*     */     public float[] getCoordinates() {
/*  40 */       return this.coordinates;
/*     */     }
/*     */     
/*     */     public Label getLabel() {
/*  44 */       return Label.getByVal(this.channelLabel);
/*     */     }
/*     */   }
/*     */   
/*     */   public ChannelBox(Header atom) {
/*  49 */     super(atom);
/*     */   }
/*     */   
/*     */   public static String fourcc() {
/*  53 */     return "chan";
/*     */   }
/*     */   
/*     */   public static ChannelBox createChannelBox() {
/*  57 */     return new ChannelBox(new Header(fourcc()));
/*     */   }
/*     */   
/*     */   public void parse(ByteBuffer input) {
/*  61 */     super.parse(input);
/*     */     
/*  63 */     this.channelLayout = input.getInt();
/*  64 */     this.channelBitmap = input.getInt();
/*  65 */     int numDescriptions = input.getInt();
/*     */     
/*  67 */     this.descriptions = new ChannelDescription[numDescriptions];
/*  68 */     for (int i = 0; i < numDescriptions; i++) {
/*  69 */       this.descriptions[i] = new ChannelDescription(input.getInt(), input.getInt(), new float[] {
/*  70 */             Float.intBitsToFloat(input.getInt()), Float.intBitsToFloat(input.getInt()), 
/*  71 */             Float.intBitsToFloat(input.getInt()) });
/*     */     } 
/*     */   }
/*     */   
/*     */   protected void doWrite(ByteBuffer out) {
/*  76 */     super.doWrite(out);
/*  77 */     out.putInt(this.channelLayout);
/*  78 */     out.putInt(this.channelBitmap);
/*  79 */     out.putInt(this.descriptions.length);
/*     */     
/*  81 */     for (int i = 0; i < this.descriptions.length; i++) {
/*  82 */       ChannelDescription channelDescription = this.descriptions[i];
/*  83 */       out.putInt(channelDescription.getChannelLabel());
/*  84 */       out.putInt(channelDescription.getChannelFlags());
/*     */       
/*  86 */       out.putFloat(channelDescription.getCoordinates()[0]);
/*  87 */       out.putFloat(channelDescription.getCoordinates()[1]);
/*  88 */       out.putFloat(channelDescription.getCoordinates()[2]);
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public int estimateSize() {
/*  94 */     return 24 + this.descriptions.length * 20;
/*     */   }
/*     */   
/*     */   public int getChannelLayout() {
/*  98 */     return this.channelLayout;
/*     */   }
/*     */   
/*     */   public int getChannelBitmap() {
/* 102 */     return this.channelBitmap;
/*     */   }
/*     */   
/*     */   public ChannelDescription[] getDescriptions() {
/* 106 */     return this.descriptions;
/*     */   }
/*     */   
/*     */   public void setChannelLayout(int channelLayout) {
/* 110 */     this.channelLayout = channelLayout;
/*     */   }
/*     */   
/*     */   public void setDescriptions(ChannelDescription[] descriptions) {
/* 114 */     this.descriptions = descriptions;
/*     */   }
/*     */ }


/* Location:              C:\Users\rapha\Downloads\aurora.jar!\META-INF\jars\jcodec-0.2.5.jar!\org\jcodec\containers\mp4\boxes\ChannelBox.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */