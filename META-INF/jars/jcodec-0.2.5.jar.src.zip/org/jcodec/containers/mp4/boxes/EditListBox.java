/*    */ package org.jcodec.containers.mp4.boxes;
/*    */ 
/*    */ import java.nio.ByteBuffer;
/*    */ import java.util.ArrayList;
/*    */ import java.util.List;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class EditListBox
/*    */   extends FullBox
/*    */ {
/*    */   private List<Edit> edits;
/*    */   
/*    */   public static String fourcc() {
/* 18 */     return "elst";
/*    */   }
/*    */   
/*    */   public static EditListBox createEditListBox(List<Edit> edits) {
/* 22 */     EditListBox elst = new EditListBox(new Header(fourcc()));
/* 23 */     elst.edits = edits;
/* 24 */     return elst;
/*    */   }
/*    */   
/*    */   public EditListBox(Header atom) {
/* 28 */     super(atom);
/*    */   }
/*    */   
/*    */   public void parse(ByteBuffer input) {
/* 32 */     super.parse(input);
/*    */     
/* 34 */     this.edits = new ArrayList<Edit>();
/* 35 */     long num = input.getInt();
/* 36 */     for (int i = 0; i < num; i++) {
/* 37 */       int duration = input.getInt();
/* 38 */       int mediaTime = input.getInt();
/* 39 */       float rate = input.getInt() / 65536.0F;
/* 40 */       this.edits.add(new Edit(duration, mediaTime, rate));
/*    */     } 
/*    */   }
/*    */   
/*    */   protected void doWrite(ByteBuffer out) {
/* 45 */     super.doWrite(out);
/*    */     
/* 47 */     out.putInt(this.edits.size());
/* 48 */     for (Edit edit : this.edits) {
/* 49 */       out.putInt((int)edit.getDuration());
/* 50 */       out.putInt((int)edit.getMediaTime());
/* 51 */       out.putInt((int)(edit.getRate() * 65536.0F));
/*    */     } 
/*    */   }
/*    */ 
/*    */   
/*    */   public int estimateSize() {
/* 57 */     return 16 + this.edits.size() * 12;
/*    */   }
/*    */   
/*    */   public List<Edit> getEdits() {
/* 61 */     return this.edits;
/*    */   }
/*    */ }


/* Location:              C:\Users\rapha\Downloads\aurora.jar!\META-INF\jars\jcodec-0.2.5.jar!\org\jcodec\containers\mp4\boxes\EditListBox.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */