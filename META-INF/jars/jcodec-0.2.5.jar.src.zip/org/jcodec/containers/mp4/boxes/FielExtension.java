/*    */ package org.jcodec.containers.mp4.boxes;
/*    */ 
/*    */ import java.nio.ByteBuffer;
/*    */ 
/*    */ 
/*    */ 
/*    */ public class FielExtension
/*    */   extends Box
/*    */ {
/*    */   private int type;
/*    */   private int order;
/*    */   
/*    */   public FielExtension(Header header) {
/* 14 */     super(header);
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public static String fourcc() {
/* 21 */     return "fiel";
/*    */   }
/*    */   
/*    */   public boolean isInterlaced() {
/* 25 */     return (this.type == 2);
/*    */   }
/*    */   
/*    */   public boolean topFieldFirst() {
/* 29 */     return (this.order == 1 || this.order == 6);
/*    */   }
/*    */   
/*    */   public String getOrderInterpretation() {
/* 33 */     if (isInterlaced())
/*    */     {
/*    */ 
/*    */       
/* 37 */       switch (this.order) {
/*    */         
/*    */         case 1:
/* 40 */           return "top";
/*    */         
/*    */         case 6:
/* 43 */           return "bottom";
/*    */         
/*    */         case 9:
/* 46 */           return "bottomtop";
/*    */ 
/*    */         
/*    */         case 14:
/* 50 */           return "topbottom";
/*    */       } 
/*    */     }
/* 53 */     return "";
/*    */   }
/*    */ 
/*    */   
/*    */   public void parse(ByteBuffer input) {
/* 58 */     this.type = input.get() & 0xFF;
/* 59 */     if (isInterlaced()) {
/* 60 */       this.order = input.get() & 0xFF;
/*    */     }
/*    */   }
/*    */ 
/*    */   
/*    */   public void doWrite(ByteBuffer out) {
/* 66 */     out.put((byte)this.type);
/* 67 */     out.put((byte)this.order);
/*    */   }
/*    */ 
/*    */   
/*    */   public int estimateSize() {
/* 72 */     return 10;
/*    */   }
/*    */ }


/* Location:              C:\Users\rapha\Downloads\aurora.jar!\META-INF\jars\jcodec-0.2.5.jar!\org\jcodec\containers\mp4\boxes\FielExtension.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */