/*    */ package org.jcodec.containers.mp4.boxes;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class AVC1Box
/*    */   extends VideoSampleEntry
/*    */ {
/*    */   public AVC1Box() {
/* 14 */     super(new Header("avc1"));
/*    */   }
/*    */ }


/* Location:              C:\Users\rapha\Downloads\aurora.jar!\META-INF\jars\jcodec-0.2.5.jar!\org\jcodec\containers\mp4\boxes\AVC1Box.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */