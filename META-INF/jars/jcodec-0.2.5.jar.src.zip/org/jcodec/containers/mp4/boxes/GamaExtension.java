/*    */ package org.jcodec.containers.mp4.boxes;
/*    */ 
/*    */ import java.nio.ByteBuffer;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class GamaExtension
/*    */   extends Box
/*    */ {
/*    */   private float gamma;
/*    */   
/*    */   public static GamaExtension createGamaExtension(float gamma) {
/* 18 */     GamaExtension gamaExtension = new GamaExtension(new Header(fourcc()));
/* 19 */     gamaExtension.gamma = gamma;
/* 20 */     return gamaExtension;
/*    */   }
/*    */   
/*    */   public GamaExtension(Header header) {
/* 24 */     super(header);
/*    */   }
/*    */   
/*    */   public void parse(ByteBuffer input) {
/* 28 */     float g = input.getInt();
/* 29 */     this.gamma = g / 65536.0F;
/*    */   }
/*    */   
/*    */   protected void doWrite(ByteBuffer out) {
/* 33 */     out.putInt((int)(this.gamma * 65536.0F));
/*    */   }
/*    */   
/*    */   public float getGamma() {
/* 37 */     return this.gamma;
/*    */   }
/*    */   
/*    */   public static String fourcc() {
/* 41 */     return "gama";
/*    */   }
/*    */ 
/*    */   
/*    */   public int estimateSize() {
/* 46 */     return 12;
/*    */   }
/*    */ }


/* Location:              C:\Users\rapha\Downloads\aurora.jar!\META-INF\jars\jcodec-0.2.5.jar!\org\jcodec\containers\mp4\boxes\GamaExtension.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */