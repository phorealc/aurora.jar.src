/*    */ package org.jcodec.containers.mp4.boxes;
/*    */ 
/*    */ import java.nio.ByteBuffer;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class CleanApertureExtension
/*    */   extends Box
/*    */ {
/*    */   private int vertOffsetDenominator;
/*    */   private int vertOffsetNumerator;
/*    */   private int horizOffsetDenominator;
/*    */   private int horizOffsetNumerator;
/*    */   private int apertureHeightDenominator;
/*    */   private int apertureHeightNumerator;
/*    */   private int apertureWidthDenominator;
/*    */   private int apertureWidthNumerator;
/*    */   
/*    */   public CleanApertureExtension(Header header) {
/* 22 */     super(header);
/*    */   }
/*    */ 
/*    */   
/*    */   public static CleanApertureExtension createCleanApertureExtension(int apertureWidthN, int apertureWidthD, int apertureHeightN, int apertureHeightD, int horizOffN, int horizOffD, int vertOffN, int vertOffD) {
/* 27 */     CleanApertureExtension clap = new CleanApertureExtension(new Header(fourcc()));
/* 28 */     clap.apertureWidthNumerator = apertureWidthN;
/* 29 */     clap.apertureWidthDenominator = apertureWidthD;
/* 30 */     clap.apertureHeightNumerator = apertureHeightN;
/* 31 */     clap.apertureHeightDenominator = apertureHeightD;
/* 32 */     clap.horizOffsetNumerator = horizOffN;
/* 33 */     clap.horizOffsetDenominator = horizOffD;
/* 34 */     clap.vertOffsetNumerator = vertOffN;
/* 35 */     clap.vertOffsetDenominator = vertOffD;
/* 36 */     return clap;
/*    */   }
/*    */ 
/*    */   
/*    */   public void parse(ByteBuffer is) {
/* 41 */     this.apertureWidthNumerator = is.getInt();
/* 42 */     this.apertureWidthDenominator = is.getInt();
/*    */     
/* 44 */     this.apertureHeightNumerator = is.getInt();
/* 45 */     this.apertureHeightDenominator = is.getInt();
/*    */     
/* 47 */     this.horizOffsetNumerator = is.getInt();
/* 48 */     this.horizOffsetDenominator = is.getInt();
/*    */     
/* 50 */     this.vertOffsetNumerator = is.getInt();
/* 51 */     this.vertOffsetDenominator = is.getInt();
/*    */   }
/*    */   
/*    */   public static String fourcc() {
/* 55 */     return "clap";
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public void doWrite(ByteBuffer out) {
/* 61 */     out.putInt(this.apertureWidthNumerator);
/* 62 */     out.putInt(this.apertureWidthDenominator);
/*    */     
/* 64 */     out.putInt(this.apertureHeightNumerator);
/* 65 */     out.putInt(this.apertureHeightDenominator);
/*    */     
/* 67 */     out.putInt(this.horizOffsetNumerator);
/* 68 */     out.putInt(this.horizOffsetDenominator);
/*    */     
/* 70 */     out.putInt(this.vertOffsetNumerator);
/* 71 */     out.putInt(this.vertOffsetDenominator);
/*    */   }
/*    */ 
/*    */   
/*    */   public int estimateSize() {
/* 76 */     return 40;
/*    */   }
/*    */ }


/* Location:              C:\Users\rapha\Downloads\aurora.jar!\META-INF\jars\jcodec-0.2.5.jar!\org\jcodec\containers\mp4\boxes\CleanApertureExtension.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */