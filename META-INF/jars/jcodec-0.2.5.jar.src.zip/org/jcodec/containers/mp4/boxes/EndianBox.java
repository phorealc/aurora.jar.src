/*    */ package org.jcodec.containers.mp4.boxes;
/*    */ 
/*    */ import java.nio.ByteBuffer;
/*    */ import java.nio.ByteOrder;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class EndianBox
/*    */   extends Box
/*    */ {
/*    */   private ByteOrder endian;
/*    */   
/*    */   public static String fourcc() {
/* 18 */     return "enda";
/*    */   }
/*    */   
/*    */   public static EndianBox createEndianBox(ByteOrder endian) {
/* 22 */     EndianBox endianBox = new EndianBox(new Header(fourcc()));
/* 23 */     endianBox.endian = endian;
/* 24 */     return endianBox;
/*    */   }
/*    */   
/*    */   public EndianBox(Header header) {
/* 28 */     super(header);
/*    */   }
/*    */   
/*    */   public void parse(ByteBuffer input) {
/* 32 */     long end = input.getShort();
/* 33 */     if (end == 1L) {
/* 34 */       this.endian = ByteOrder.LITTLE_ENDIAN;
/*    */     } else {
/* 36 */       this.endian = ByteOrder.BIG_ENDIAN;
/*    */     } 
/*    */   }
/*    */   
/*    */   protected void doWrite(ByteBuffer out) {
/* 41 */     out.putShort((short)((this.endian == ByteOrder.LITTLE_ENDIAN) ? 1 : 0));
/*    */   }
/*    */ 
/*    */   
/*    */   public int estimateSize() {
/* 46 */     return 10;
/*    */   }
/*    */   
/*    */   public ByteOrder getEndian() {
/* 50 */     return this.endian;
/*    */   }
/*    */   
/*    */   protected int calcSize() {
/* 54 */     return 2;
/*    */   }
/*    */ }


/* Location:              C:\Users\rapha\Downloads\aurora.jar!\META-INF\jars\jcodec-0.2.5.jar!\org\jcodec\containers\mp4\boxes\EndianBox.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */