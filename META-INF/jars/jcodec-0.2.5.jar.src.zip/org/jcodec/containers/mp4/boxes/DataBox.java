/*    */ package org.jcodec.containers.mp4.boxes;
/*    */ 
/*    */ import java.nio.ByteBuffer;
/*    */ import org.jcodec.common.io.NIOUtils;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class DataBox
/*    */   extends Box
/*    */ {
/*    */   private static final String FOURCC = "data";
/*    */   private int type;
/*    */   private int locale;
/*    */   private byte[] data;
/*    */   
/*    */   public DataBox(Header header) {
/* 21 */     super(header);
/*    */   }
/*    */   
/*    */   public static DataBox createDataBox(int type, int locale, byte[] data) {
/* 25 */     DataBox box = new DataBox(Header.createHeader("data", 0L));
/* 26 */     box.type = type;
/* 27 */     box.locale = locale;
/* 28 */     box.data = data;
/* 29 */     return box;
/*    */   }
/*    */ 
/*    */   
/*    */   public void parse(ByteBuffer buf) {
/* 34 */     this.type = buf.getInt();
/* 35 */     this.locale = buf.getInt();
/* 36 */     this.data = NIOUtils.toArray(NIOUtils.readBuf(buf));
/*    */   }
/*    */   
/*    */   public int getType() {
/* 40 */     return this.type;
/*    */   }
/*    */   
/*    */   public int getLocale() {
/* 44 */     return this.locale;
/*    */   }
/*    */   
/*    */   public byte[] getData() {
/* 48 */     return this.data;
/*    */   }
/*    */ 
/*    */   
/*    */   protected void doWrite(ByteBuffer out) {
/* 53 */     out.putInt(this.type);
/* 54 */     out.putInt(this.locale);
/* 55 */     out.put(this.data);
/*    */   }
/*    */ 
/*    */   
/*    */   public int estimateSize() {
/* 60 */     return 16 + this.data.length;
/*    */   }
/*    */   
/*    */   public static String fourcc() {
/* 64 */     return "data";
/*    */   }
/*    */ }


/* Location:              C:\Users\rapha\Downloads\aurora.jar!\META-INF\jars\jcodec-0.2.5.jar!\org\jcodec\containers\mp4\boxes\DataBox.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */