/*    */ package org.jcodec.containers.mp4.boxes;
/*    */ 
/*    */ import java.nio.ByteBuffer;
/*    */ import org.jcodec.common.JCodecUtil2;
/*    */ import org.jcodec.platform.Platform;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class ColorExtension
/*    */   extends Box
/*    */ {
/*    */   private short primariesIndex;
/*    */   private short transferFunctionIndex;
/*    */   private short matrixIndex;
/* 22 */   private String type = "nclc";
/*    */   
/*    */   static final byte RANGE_UNSPECIFIED = 0;
/*    */   static final byte AVCOL_RANGE_MPEG = 1;
/*    */   static final byte AVCOL_RANGE_JPEG = 2;
/* 27 */   private Byte colorRange = null;
/*    */   
/*    */   public ColorExtension(Header header) {
/* 30 */     super(header);
/*    */   }
/*    */   
/*    */   public void setColorRange(Byte colorRange) {
/* 34 */     this.colorRange = colorRange;
/*    */   }
/*    */ 
/*    */   
/*    */   public void parse(ByteBuffer input) {
/* 39 */     byte[] dst = new byte[4];
/* 40 */     input.get(dst);
/* 41 */     this.type = Platform.stringFromBytes(dst);
/* 42 */     this.primariesIndex = input.getShort();
/* 43 */     this.transferFunctionIndex = input.getShort();
/* 44 */     this.matrixIndex = input.getShort();
/* 45 */     if (input.hasRemaining()) {
/* 46 */       this.colorRange = Byte.valueOf(input.get());
/*    */     }
/*    */   }
/*    */ 
/*    */   
/*    */   public void doWrite(ByteBuffer out) {
/* 52 */     out.put(JCodecUtil2.asciiString(this.type));
/* 53 */     out.putShort(this.primariesIndex);
/* 54 */     out.putShort(this.transferFunctionIndex);
/* 55 */     out.putShort(this.matrixIndex);
/* 56 */     if (this.colorRange != null) {
/* 57 */       out.put(this.colorRange.byteValue());
/*    */     }
/*    */   }
/*    */ 
/*    */   
/*    */   public int estimateSize() {
/* 63 */     return 16;
/*    */   }
/*    */   
/*    */   public static String fourcc() {
/* 67 */     return "colr";
/*    */   }
/*    */ 
/*    */   
/*    */   public static ColorExtension createColorExtension(short primariesIndex, short transferFunctionIndex, short matrixIndex) {
/* 72 */     ColorExtension c = new ColorExtension(new Header(fourcc()));
/* 73 */     c.primariesIndex = primariesIndex;
/* 74 */     c.transferFunctionIndex = transferFunctionIndex;
/* 75 */     c.matrixIndex = matrixIndex;
/* 76 */     return c;
/*    */   }
/*    */   
/*    */   public static ColorExtension createColr() {
/* 80 */     return new ColorExtension(new Header(fourcc()));
/*    */   }
/*    */   
/*    */   public short getPrimariesIndex() {
/* 84 */     return this.primariesIndex;
/*    */   }
/*    */   
/*    */   public short getTransferFunctionIndex() {
/* 88 */     return this.transferFunctionIndex;
/*    */   }
/*    */   
/*    */   public short getMatrixIndex() {
/* 92 */     return this.matrixIndex;
/*    */   }
/*    */ }


/* Location:              C:\Users\rapha\Downloads\aurora.jar!\META-INF\jars\jcodec-0.2.5.jar!\org\jcodec\containers\mp4\boxes\ColorExtension.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */