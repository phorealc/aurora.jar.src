/*    */ package org.jcodec.containers.mp4.boxes;
/*    */ 
/*    */ 
/*    */ 
/*    */ public class Edit
/*    */ {
/*    */   private long duration;
/*    */   private long mediaTime;
/*    */   private float rate;
/*    */   
/*    */   public static Edit createEdit(Edit edit) {
/* 12 */     return new Edit(edit.duration, edit.mediaTime, edit.rate);
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public Edit(long duration, long mediaTime, float rate) {
/* 20 */     this.duration = duration;
/* 21 */     this.mediaTime = mediaTime;
/* 22 */     this.rate = rate;
/*    */   }
/*    */   
/*    */   public long getDuration() {
/* 26 */     return this.duration;
/*    */   }
/*    */   
/*    */   public long getMediaTime() {
/* 30 */     return this.mediaTime;
/*    */   }
/*    */   
/*    */   public float getRate() {
/* 34 */     return this.rate;
/*    */   }
/*    */   
/*    */   public void shift(long shift) {
/* 38 */     this.mediaTime += shift;
/*    */   }
/*    */   
/*    */   public void setMediaTime(long l) {
/* 42 */     this.mediaTime = l;
/*    */   }
/*    */   
/*    */   public void setDuration(long duration) {
/* 46 */     this.duration = duration;
/*    */   }
/*    */ }


/* Location:              C:\Users\rapha\Downloads\aurora.jar!\META-INF\jars\jcodec-0.2.5.jar!\org\jcodec\containers\mp4\boxes\Edit.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */