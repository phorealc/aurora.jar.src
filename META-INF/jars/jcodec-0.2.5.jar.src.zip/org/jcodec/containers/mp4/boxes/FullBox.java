/*    */ package org.jcodec.containers.mp4.boxes;
/*    */ 
/*    */ import java.nio.ByteBuffer;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public abstract class FullBox
/*    */   extends Box
/*    */ {
/*    */   protected byte version;
/*    */   protected int flags;
/*    */   
/*    */   public FullBox(Header atom) {
/* 17 */     super(atom);
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public void parse(ByteBuffer input) {
/* 24 */     int vf = input.getInt();
/* 25 */     this.version = (byte)(vf >> 24 & 0xFF);
/* 26 */     this.flags = vf & 0xFFFFFF;
/*    */   }
/*    */   
/*    */   protected void doWrite(ByteBuffer out) {
/* 30 */     out.putInt(this.version << 24 | this.flags & 0xFFFFFF);
/*    */   }
/*    */   
/*    */   public byte getVersion() {
/* 34 */     return this.version;
/*    */   }
/*    */   
/*    */   public int getFlags() {
/* 38 */     return this.flags;
/*    */   }
/*    */   
/*    */   public void setVersion(byte version) {
/* 42 */     this.version = version;
/*    */   }
/*    */   
/*    */   public void setFlags(int flags) {
/* 46 */     this.flags = flags;
/*    */   }
/*    */ }


/* Location:              C:\Users\rapha\Downloads\aurora.jar!\META-INF\jars\jcodec-0.2.5.jar!\org\jcodec\containers\mp4\boxes\FullBox.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */