/*    */ package org.jcodec.containers.mp4.boxes;
/*    */ 
/*    */ import java.nio.ByteBuffer;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class GenericMediaInfoBox
/*    */   extends FullBox
/*    */ {
/*    */   private short graphicsMode;
/*    */   private short rOpColor;
/*    */   private short gOpColor;
/*    */   private short bOpColor;
/*    */   private short balance;
/*    */   
/*    */   public static String fourcc() {
/* 20 */     return "gmin";
/*    */   }
/*    */   
/*    */   public static GenericMediaInfoBox createGenericMediaInfoBox() {
/* 24 */     return new GenericMediaInfoBox(new Header(fourcc()));
/*    */   }
/*    */   
/*    */   public GenericMediaInfoBox(Header atom) {
/* 28 */     super(atom);
/*    */   }
/*    */   
/*    */   public void parse(ByteBuffer input) {
/* 32 */     super.parse(input);
/* 33 */     this.graphicsMode = input.getShort();
/* 34 */     this.rOpColor = input.getShort();
/* 35 */     this.gOpColor = input.getShort();
/* 36 */     this.bOpColor = input.getShort();
/* 37 */     this.balance = input.getShort();
/* 38 */     input.getShort();
/*    */   }
/*    */   
/*    */   protected void doWrite(ByteBuffer out) {
/* 42 */     super.doWrite(out);
/* 43 */     out.putShort(this.graphicsMode);
/* 44 */     out.putShort(this.rOpColor);
/* 45 */     out.putShort(this.gOpColor);
/* 46 */     out.putShort(this.bOpColor);
/* 47 */     out.putShort(this.balance);
/* 48 */     out.putShort((short)0);
/*    */   }
/*    */ 
/*    */   
/*    */   public int estimateSize() {
/* 53 */     return 24;
/*    */   }
/*    */ }


/* Location:              C:\Users\rapha\Downloads\aurora.jar!\META-INF\jars\jcodec-0.2.5.jar!\org\jcodec\containers\mp4\boxes\GenericMediaInfoBox.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */