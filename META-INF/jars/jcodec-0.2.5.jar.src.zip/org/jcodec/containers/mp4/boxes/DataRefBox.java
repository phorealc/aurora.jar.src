/*    */ package org.jcodec.containers.mp4.boxes;
/*    */ 
/*    */ import java.nio.ByteBuffer;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class DataRefBox
/*    */   extends NodeBox
/*    */ {
/*    */   public static String fourcc() {
/* 15 */     return "dref";
/*    */   }
/*    */   
/*    */   public static DataRefBox createDataRefBox() {
/* 19 */     return new DataRefBox(new Header(fourcc()));
/*    */   }
/*    */   
/*    */   public DataRefBox(Header atom) {
/* 23 */     super(atom);
/*    */   }
/*    */ 
/*    */   
/*    */   public void parse(ByteBuffer input) {
/* 28 */     input.getInt();
/* 29 */     input.getInt();
/* 30 */     super.parse(input);
/*    */   }
/*    */ 
/*    */   
/*    */   public void doWrite(ByteBuffer out) {
/* 35 */     out.putInt(0);
/* 36 */     out.putInt(this.boxes.size());
/* 37 */     super.doWrite(out);
/*    */   }
/*    */ 
/*    */   
/*    */   public int estimateSize() {
/* 42 */     return 8 + super.estimateSize();
/*    */   }
/*    */ }


/* Location:              C:\Users\rapha\Downloads\aurora.jar!\META-INF\jars\jcodec-0.2.5.jar!\org\jcodec\containers\mp4\boxes\DataRefBox.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */