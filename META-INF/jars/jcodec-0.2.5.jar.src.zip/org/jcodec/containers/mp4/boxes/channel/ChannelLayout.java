/*     */ package org.jcodec.containers.mp4.boxes.channel;
/*     */ 
/*     */ import java.util.ArrayList;
/*     */ import java.util.List;
/*     */ import org.jcodec.common.model.Label;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class ChannelLayout
/*     */ {
/*  46 */   private static final List<ChannelLayout> _values = new ArrayList<ChannelLayout>();
/*     */   
/*  48 */   public static final ChannelLayout kCAFChannelLayoutTag_UseChannelDescriptions = new ChannelLayout(0, new Label[0]);
/*     */   
/*  50 */   public static final ChannelLayout kCAFChannelLayoutTag_UseChannelBitmap = new ChannelLayout(65536, new Label[0]);
/*     */   
/*  52 */   public static final ChannelLayout kCAFChannelLayoutTag_Mono = new ChannelLayout(6553601, new Label[] { Label.Mono });
/*     */   
/*  54 */   public static final ChannelLayout kCAFChannelLayoutTag_Stereo = new ChannelLayout(6619138, new Label[] { Label.Left, Label.Right });
/*     */   
/*  56 */   public static final ChannelLayout kCAFChannelLayoutTag_StereoHeadphones = new ChannelLayout(6684674, new Label[] { Label.HeadphonesLeft, Label.HeadphonesRight });
/*     */   
/*  58 */   public static final ChannelLayout kCAFChannelLayoutTag_MatrixStereo = new ChannelLayout(6750210, new Label[] { Label.LeftTotal, Label.RightTotal });
/*     */   
/*  60 */   public static final ChannelLayout kCAFChannelLayoutTag_MidSide = new ChannelLayout(6815746, new Label[] { Label.MS_Mid, Label.MS_Side });
/*     */   
/*  62 */   public static final ChannelLayout kCAFChannelLayoutTag_XY = new ChannelLayout(6881282, new Label[] { Label.XY_X, Label.XY_Y });
/*     */   
/*  64 */   public static final ChannelLayout kCAFChannelLayoutTag_Binaural = new ChannelLayout(6946818, new Label[] { Label.HeadphonesLeft, Label.HeadphonesRight });
/*     */   
/*  66 */   public static final ChannelLayout kCAFChannelLayoutTag_Ambisonic_B_Format = new ChannelLayout(7012356, new Label[] { Label.Ambisonic_W, Label.Ambisonic_X, Label.Ambisonic_Y, Label.Ambisonic_Z });
/*     */   
/*  68 */   public static final ChannelLayout kCAFChannelLayoutTag_Quadraphonic = new ChannelLayout(7077892, new Label[] { Label.Left, Label.Right, Label.LeftSurround, Label.RightSurround });
/*     */   
/*  70 */   public static final ChannelLayout kCAFChannelLayoutTag_Pentagonal = new ChannelLayout(7143429, new Label[] { Label.Left, Label.Right, Label.LeftSurround, Label.RightSurround, Label.Center });
/*     */   
/*  72 */   public static final ChannelLayout kCAFChannelLayoutTag_Hexagonal = new ChannelLayout(7208966, new Label[] { Label.Left, Label.Right, Label.LeftSurround, Label.RightSurround, Label.Center, Label.CenterSurround });
/*     */   
/*  74 */   public static final ChannelLayout kCAFChannelLayoutTag_Octagonal = new ChannelLayout(7274504, new Label[] { Label.Left, Label.Right, Label.LeftSurround, Label.RightSurround, Label.Center, Label.CenterSurround, Label.LeftCenter, Label.RightCenter });
/*     */   
/*  76 */   public static final ChannelLayout kCAFChannelLayoutTag_Cube = new ChannelLayout(7340040, new Label[] { Label.Left, Label.Right, Label.LeftSurround, Label.RightSurround, Label.TopBackLeft, Label.TopBackRight, Label.TopBackCenter, Label.TopCenterSurround });
/*     */   
/*  78 */   public static final ChannelLayout kCAFChannelLayoutTag_MPEG_3_0_A = new ChannelLayout(7405571, new Label[] { Label.Left, Label.Right, Label.Center });
/*     */   
/*  80 */   public static final ChannelLayout kCAFChannelLayoutTag_MPEG_3_0_B = new ChannelLayout(7471107, new Label[] { Label.Center, Label.Left, Label.Right });
/*     */   
/*  82 */   public static final ChannelLayout kCAFChannelLayoutTag_MPEG_4_0_A = new ChannelLayout(7536644, new Label[] { Label.Left, Label.Right, Label.Center, Label.CenterSurround });
/*     */   
/*  84 */   public static final ChannelLayout kCAFChannelLayoutTag_MPEG_4_0_B = new ChannelLayout(7602180, new Label[] { Label.Center, Label.Left, Label.Right, Label.CenterSurround });
/*     */   
/*  86 */   public static final ChannelLayout kCAFChannelLayoutTag_MPEG_5_0_A = new ChannelLayout(7667717, new Label[] { Label.Left, Label.Right, Label.Center, Label.LeftSurround, Label.RightSurround });
/*     */   
/*  88 */   public static final ChannelLayout kCAFChannelLayoutTag_MPEG_5_0_B = new ChannelLayout(7733253, new Label[] { Label.Left, Label.Right, Label.LeftSurround, Label.RightSurround, Label.Center });
/*     */   
/*  90 */   public static final ChannelLayout kCAFChannelLayoutTag_MPEG_5_0_C = new ChannelLayout(7798789, new Label[] { Label.Left, Label.Center, Label.Right, Label.LeftSurround, Label.RightSurround });
/*     */   
/*  92 */   public static final ChannelLayout kCAFChannelLayoutTag_MPEG_5_0_D = new ChannelLayout(7864325, new Label[] { Label.Center, Label.Left, Label.Right, Label.LeftSurround, Label.RightSurround });
/*     */   
/*  94 */   public static final ChannelLayout kCAFChannelLayoutTag_MPEG_5_1_A = new ChannelLayout(7929862, new Label[] { Label.Left, Label.Right, Label.Center, Label.LFEScreen, Label.LeftSurround, Label.RightSurround });
/*     */   
/*  96 */   public static final ChannelLayout kCAFChannelLayoutTag_MPEG_5_1_B = new ChannelLayout(7995398, new Label[] { Label.Left, Label.Right, Label.LeftSurround, Label.RightSurround, Label.Center, Label.LFEScreen });
/*     */   
/*  98 */   public static final ChannelLayout kCAFChannelLayoutTag_MPEG_5_1_C = new ChannelLayout(8060934, new Label[] { Label.Left, Label.Center, Label.Right, Label.LeftSurround, Label.RightSurround, Label.LFEScreen });
/*     */   
/* 100 */   public static final ChannelLayout kCAFChannelLayoutTag_MPEG_5_1_D = new ChannelLayout(8126470, new Label[] { Label.Center, Label.Left, Label.Right, Label.LeftSurround, Label.RightSurround, Label.LFEScreen });
/*     */   
/* 102 */   public static final ChannelLayout kCAFChannelLayoutTag_MPEG_6_1_A = new ChannelLayout(8192007, new Label[] { Label.Left, Label.Right, Label.Center, Label.LFEScreen, Label.LeftSurround, Label.RightSurround, Label.Right });
/*     */   
/* 104 */   public static final ChannelLayout kCAFChannelLayoutTag_MPEG_7_1_A = new ChannelLayout(8257544, new Label[] { Label.Left, Label.Right, Label.Center, Label.LFEScreen, Label.LeftSurround, Label.RightSurround, Label.LeftCenter, Label.RightCenter });
/*     */   
/* 106 */   public static final ChannelLayout kCAFChannelLayoutTag_MPEG_7_1_B = new ChannelLayout(8323080, new Label[] { Label.Center, Label.LeftCenter, Label.RightCenter, Label.Left, Label.Right, Label.LeftSurround, Label.RightSurround, Label.LFEScreen });
/*     */   
/* 108 */   public static final ChannelLayout kCAFChannelLayoutTag_MPEG_7_1_C = new ChannelLayout(8388616, new Label[] { Label.Left, Label.Right, Label.Center, Label.LFEScreen, Label.LeftSurround, Label.RightSurround, Label.RearSurroundLeft, Label.RearSurroundRight });
/*     */   
/* 110 */   public static final ChannelLayout kCAFChannelLayoutTag_Emagic_Default_7_1 = new ChannelLayout(8454152, new Label[] { Label.Left, Label.Right, Label.LeftSurround, Label.RightSurround, Label.Center, Label.LFEScreen, Label.LeftCenter, Label.RightCenter });
/*     */   
/* 112 */   public static final ChannelLayout kCAFChannelLayoutTag_SMPTE_DTV = new ChannelLayout(8519688, new Label[] { Label.Left, Label.Right, Label.Center, Label.LFEScreen, Label.LeftSurround, Label.RightSurround, Label.LeftTotal, Label.RightTotal });
/*     */   
/* 114 */   public static final ChannelLayout kCAFChannelLayoutTag_ITU_2_1 = new ChannelLayout(8585219, new Label[] { Label.Left, Label.Right, Label.CenterSurround });
/*     */   
/* 116 */   public static final ChannelLayout kCAFChannelLayoutTag_ITU_2_2 = new ChannelLayout(8650756, new Label[] { Label.Left, Label.Right, Label.LeftSurround, Label.RightSurround });
/*     */   
/* 118 */   public static final ChannelLayout kCAFChannelLayoutTag_DVD_4 = new ChannelLayout(8716291, new Label[] { Label.Left, Label.Right, Label.LFEScreen });
/*     */   
/* 120 */   public static final ChannelLayout kCAFChannelLayoutTag_DVD_5 = new ChannelLayout(8781828, new Label[] { Label.Left, Label.Right, Label.LFEScreen, Label.CenterSurround });
/*     */   
/* 122 */   public static final ChannelLayout kCAFChannelLayoutTag_DVD_6 = new ChannelLayout(8847365, new Label[] { Label.Left, Label.Right, Label.LFEScreen, Label.LeftSurround, Label.RightSurround });
/*     */   
/* 124 */   public static final ChannelLayout kCAFChannelLayoutTag_DVD_10 = new ChannelLayout(8912900, new Label[] { Label.Left, Label.Right, Label.Center, Label.LFEScreen });
/*     */   
/* 126 */   public static final ChannelLayout kCAFChannelLayoutTag_DVD_11 = new ChannelLayout(8978437, new Label[] { Label.Left, Label.Right, Label.Center, Label.LFEScreen, Label.CenterSurround });
/*     */   
/* 128 */   public static final ChannelLayout kCAFChannelLayoutTag_DVD_18 = new ChannelLayout(9043973, new Label[] { Label.Left, Label.Right, Label.LeftSurround, Label.RightSurround, Label.LFEScreen });
/*     */   
/* 130 */   public static final ChannelLayout kCAFChannelLayoutTag_AudioUnit_6_0 = new ChannelLayout(9109510, new Label[] { Label.Left, Label.Right, Label.LeftSurround, Label.RightSurround, Label.Center, Label.CenterSurround });
/*     */   
/* 132 */   public static final ChannelLayout kCAFChannelLayoutTag_AudioUnit_7_0 = new ChannelLayout(9175047, new Label[] { Label.Left, Label.Right, Label.LeftSurround, Label.RightSurround, Label.Center, Label.RearSurroundLeft, Label.RearSurroundRight });
/*     */   
/* 134 */   public static final ChannelLayout kCAFChannelLayoutTag_AAC_6_0 = new ChannelLayout(9240582, new Label[] { Label.Center, Label.Left, Label.Right, Label.LeftSurround, Label.RightSurround, Label.CenterSurround });
/*     */   
/* 136 */   public static final ChannelLayout kCAFChannelLayoutTag_AAC_6_1 = new ChannelLayout(9306119, new Label[] { Label.Center, Label.Left, Label.Right, Label.LeftSurround, Label.RightSurround, Label.CenterSurround, Label.LFEScreen });
/*     */   
/* 138 */   public static final ChannelLayout kCAFChannelLayoutTag_AAC_7_0 = new ChannelLayout(9371655, new Label[] { Label.Center, Label.Left, Label.Right, Label.LeftSurround, Label.RightSurround, Label.RearSurroundLeft, Label.RearSurroundRight });
/*     */   
/* 140 */   public static final ChannelLayout kCAFChannelLayoutTag_AAC_Octagonal = new ChannelLayout(9437192, new Label[] { Label.Center, Label.Left, Label.Right, Label.LeftSurround, Label.RightSurround, Label.RearSurroundLeft, Label.RearSurroundRight, Label.CenterSurround });
/*     */ 
/*     */   
/* 143 */   public static final ChannelLayout kCAFChannelLayoutTag_TMH_10_2_std = new ChannelLayout(9502736, new Label[] { Label.Left, Label.Right, Label.Center, Label.Mono, Label.Mono, Label.Mono, Label.LeftSurround, Label.RightSurround, Label.Mono, Label.Mono, Label.Mono, Label.Mono, Label.Mono, Label.CenterSurround, Label.LFEScreen, Label.LFE2 });
/*     */ 
/*     */   
/* 146 */   public static final ChannelLayout kCAFChannelLayoutTag_TMH_10_2_full = new ChannelLayout(9568277, new Label[] { Label.LeftCenter, Label.RightCenter, Label.Mono, Label.Mono, Label.Mono });
/*     */   
/* 148 */   public static final ChannelLayout kCAFChannelLayoutTag_RESERVED_DO_NOT_USE = new ChannelLayout(9633792, new Label[0]);
/*     */   
/*     */   private int code;
/*     */   
/*     */   private Label[] labels;
/*     */   
/*     */   private ChannelLayout(int code, Label[] labels) {
/* 155 */     this.code = code;
/* 156 */     this.labels = labels;
/* 157 */     _values.add(this);
/*     */   }
/*     */   
/*     */   public int getCode() {
/* 161 */     return this.code;
/*     */   }
/*     */   
/*     */   public Label[] getLabels() {
/* 165 */     return this.labels;
/*     */   }
/*     */   
/*     */   public static ChannelLayout[] values() {
/* 169 */     return _values.<ChannelLayout>toArray(new ChannelLayout[0]);
/*     */   }
/*     */ }


/* Location:              C:\Users\rapha\Downloads\aurora.jar!\META-INF\jars\jcodec-0.2.5.jar!\org\jcodec\containers\mp4\boxes\channel\ChannelLayout.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */