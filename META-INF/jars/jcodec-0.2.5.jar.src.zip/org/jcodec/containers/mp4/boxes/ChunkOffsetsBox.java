/*    */ package org.jcodec.containers.mp4.boxes;
/*    */ 
/*    */ import java.nio.ByteBuffer;
/*    */ import org.jcodec.platform.Platform;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class ChunkOffsetsBox
/*    */   extends FullBox
/*    */ {
/*    */   private long[] chunkOffsets;
/*    */   
/*    */   public ChunkOffsetsBox(Header atom) {
/* 20 */     super(atom);
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public static String fourcc() {
/* 26 */     return "stco";
/*    */   }
/*    */   
/*    */   public static ChunkOffsetsBox createChunkOffsetsBox(long[] chunkOffsets) {
/* 30 */     ChunkOffsetsBox stco = new ChunkOffsetsBox(new Header(fourcc()));
/* 31 */     stco.chunkOffsets = chunkOffsets;
/* 32 */     return stco;
/*    */   }
/*    */   
/*    */   public void parse(ByteBuffer input) {
/* 36 */     super.parse(input);
/* 37 */     int length = input.getInt();
/* 38 */     this.chunkOffsets = new long[length];
/* 39 */     for (int i = 0; i < length; i++) {
/* 40 */       this.chunkOffsets[i] = Platform.unsignedInt(input.getInt());
/*    */     }
/*    */   }
/*    */ 
/*    */   
/*    */   public void doWrite(ByteBuffer out) {
/* 46 */     super.doWrite(out);
/* 47 */     out.putInt(this.chunkOffsets.length);
/* 48 */     for (int i = 0; i < this.chunkOffsets.length; i++) {
/* 49 */       long offset = this.chunkOffsets[i];
/* 50 */       out.putInt((int)offset);
/*    */     } 
/*    */   }
/*    */ 
/*    */   
/*    */   public int estimateSize() {
/* 56 */     return 16 + this.chunkOffsets.length * 4;
/*    */   }
/*    */   
/*    */   public long[] getChunkOffsets() {
/* 60 */     return this.chunkOffsets;
/*    */   }
/*    */   
/*    */   public void setChunkOffsets(long[] chunkOffsets) {
/* 64 */     this.chunkOffsets = chunkOffsets;
/*    */   }
/*    */ }


/* Location:              C:\Users\rapha\Downloads\aurora.jar!\META-INF\jars\jcodec-0.2.5.jar!\org\jcodec\containers\mp4\boxes\ChunkOffsetsBox.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */