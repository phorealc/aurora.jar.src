/*    */ package org.jcodec.containers.mp4.boxes;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class DataInfoBox
/*    */   extends NodeBox
/*    */ {
/*    */   public static String fourcc() {
/* 15 */     return "dinf";
/*    */   }
/*    */   
/*    */   public static DataInfoBox createDataInfoBox() {
/* 19 */     return new DataInfoBox(new Header(fourcc()));
/*    */   }
/*    */   
/*    */   public DataInfoBox(Header atom) {
/* 23 */     super(atom);
/*    */   }
/*    */   
/*    */   public DataRefBox getDref() {
/* 27 */     return NodeBox.<DataRefBox>findFirst(this, DataRefBox.class, "dref");
/*    */   }
/*    */ }


/* Location:              C:\Users\rapha\Downloads\aurora.jar!\META-INF\jars\jcodec-0.2.5.jar!\org\jcodec\containers\mp4\boxes\DataInfoBox.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */