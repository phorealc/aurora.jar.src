/*    */ package org.jcodec.containers.mp4.boxes;
/*    */ 
/*    */ import java.nio.ByteBuffer;
/*    */ import java.util.Collection;
/*    */ import java.util.LinkedList;
/*    */ import org.jcodec.common.JCodecUtil2;
/*    */ import org.jcodec.common.io.NIOUtils;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class FileTypeBox
/*    */   extends Box
/*    */ {
/*    */   private String majorBrand;
/*    */   private int minorVersion;
/*    */   private Collection<String> compBrands;
/*    */   
/*    */   public FileTypeBox(Header header) {
/* 22 */     super(header);
/* 23 */     this.compBrands = new LinkedList<String>();
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public static String fourcc() {
/* 31 */     return "ftyp";
/*    */   }
/*    */   
/*    */   public static FileTypeBox createFileTypeBox(String majorBrand, int minorVersion, Collection<String> compBrands) {
/* 35 */     FileTypeBox ftyp = new FileTypeBox(new Header(fourcc()));
/* 36 */     ftyp.majorBrand = majorBrand;
/* 37 */     ftyp.minorVersion = minorVersion;
/* 38 */     ftyp.compBrands = compBrands;
/* 39 */     return ftyp;
/*    */   }
/*    */   
/*    */   public void parse(ByteBuffer input) {
/* 43 */     this.majorBrand = NIOUtils.readString(input, 4);
/* 44 */     this.minorVersion = input.getInt();
/*    */     
/*    */     String brand;
/* 47 */     while (input.hasRemaining() && (brand = NIOUtils.readString(input, 4)) != null) {
/* 48 */       this.compBrands.add(brand);
/*    */     }
/*    */   }
/*    */   
/*    */   public String getMajorBrand() {
/* 53 */     return this.majorBrand;
/*    */   }
/*    */   
/*    */   public Collection<String> getCompBrands() {
/* 57 */     return this.compBrands;
/*    */   }
/*    */   
/*    */   public void doWrite(ByteBuffer out) {
/* 61 */     out.put(JCodecUtil2.asciiString(this.majorBrand));
/* 62 */     out.putInt(this.minorVersion);
/*    */     
/* 64 */     for (String string : this.compBrands) {
/* 65 */       out.put(JCodecUtil2.asciiString(string));
/*    */     }
/*    */   }
/*    */ 
/*    */   
/*    */   public int estimateSize() {
/* 71 */     int size = 13;
/*    */     
/* 73 */     for (String string : this.compBrands) {
/* 74 */       size += (JCodecUtil2.asciiString(string)).length;
/*    */     }
/*    */     
/* 77 */     return size;
/*    */   }
/*    */ }


/* Location:              C:\Users\rapha\Downloads\aurora.jar!\META-INF\jars\jcodec-0.2.5.jar!\org\jcodec\containers\mp4\boxes\FileTypeBox.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */