/*     */ package org.jcodec.containers.mp4.boxes;
/*     */ 
/*     */ import java.nio.ByteBuffer;
/*     */ import java.nio.ByteOrder;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Arrays;
/*     */ import java.util.HashMap;
/*     */ import java.util.HashSet;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import java.util.Set;
/*     */ import org.jcodec.api.NotSupportedException;
/*     */ import org.jcodec.common.AudioFormat;
/*     */ import org.jcodec.common.model.ChannelLabel;
/*     */ import org.jcodec.common.model.Label;
/*     */ import org.jcodec.containers.mp4.boxes.channel.ChannelLayout;
/*     */ import org.jcodec.platform.Platform;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class AudioSampleEntry
/*     */   extends SampleEntry
/*     */ {
/*  37 */   public static int kAudioFormatFlagIsFloat = 1;
/*  38 */   public static int kAudioFormatFlagIsBigEndian = 2;
/*  39 */   public static int kAudioFormatFlagIsSignedInteger = 4;
/*  40 */   public static int kAudioFormatFlagIsPacked = 8;
/*  41 */   public static int kAudioFormatFlagIsAlignedHigh = 16;
/*  42 */   public static int kAudioFormatFlagIsNonInterleaved = 32;
/*  43 */   public static int kAudioFormatFlagIsNonMixable = 64;
/*     */   private short channelCount;
/*     */   private short sampleSize;
/*     */   private float sampleRate;
/*     */   
/*     */   public static AudioSampleEntry createAudioSampleEntry(Header header, short drefInd, short channelCount, short sampleSize, int sampleRate, short revision, int vendor, int compressionId, int pktSize, int samplesPerPkt, int bytesPerPkt, int bytesPerFrame, int bytesPerSample, short version) {
/*  49 */     AudioSampleEntry audio = new AudioSampleEntry(header);
/*  50 */     audio.drefInd = drefInd;
/*  51 */     audio.channelCount = channelCount;
/*  52 */     audio.sampleSize = sampleSize;
/*  53 */     audio.sampleRate = sampleRate;
/*  54 */     audio.revision = revision;
/*  55 */     audio.vendor = vendor;
/*  56 */     audio.compressionId = compressionId;
/*  57 */     audio.pktSize = pktSize;
/*  58 */     audio.samplesPerPkt = samplesPerPkt;
/*  59 */     audio.bytesPerPkt = bytesPerPkt;
/*  60 */     audio.bytesPerFrame = bytesPerFrame;
/*  61 */     audio.bytesPerSample = bytesPerSample;
/*  62 */     audio.version = version;
/*  63 */     return audio;
/*     */   }
/*     */ 
/*     */   
/*     */   private short revision;
/*     */   
/*     */   private int vendor;
/*     */   
/*     */   private int compressionId;
/*     */   
/*     */   private int pktSize;
/*     */   private int samplesPerPkt;
/*     */   private int bytesPerPkt;
/*     */   private int bytesPerFrame;
/*     */   private int bytesPerSample;
/*     */   private short version;
/*     */   private int lpcmFlags;
/*  80 */   private static final List<Label> MONO = Arrays.asList(new Label[] { Label.Mono });
/*  81 */   private static final List<Label> STEREO = Arrays.asList(new Label[] { Label.Left, Label.Right });
/*  82 */   private static final List<Label> MATRIX_STEREO = Arrays.asList(new Label[] { Label.LeftTotal, Label.RightTotal });
/*  83 */   public static final Label[] EMPTY = new Label[0];
/*     */   
/*     */   public AudioSampleEntry(Header atom) {
/*  86 */     super(atom);
/*     */   }
/*     */   
/*     */   public void parse(ByteBuffer input) {
/*  90 */     super.parse(input);
/*     */     
/*  92 */     this.version = input.getShort();
/*  93 */     this.revision = input.getShort();
/*  94 */     this.vendor = input.getInt();
/*     */     
/*  96 */     this.channelCount = input.getShort();
/*  97 */     this.sampleSize = input.getShort();
/*     */     
/*  99 */     this.compressionId = input.getShort();
/* 100 */     this.pktSize = input.getShort();
/*     */     
/* 102 */     long sr = Platform.unsignedInt(input.getInt());
/* 103 */     this.sampleRate = (float)sr / 65536.0F;
/*     */     
/* 105 */     if (this.version == 1) {
/* 106 */       this.samplesPerPkt = input.getInt();
/* 107 */       this.bytesPerPkt = input.getInt();
/* 108 */       this.bytesPerFrame = input.getInt();
/* 109 */       this.bytesPerSample = input.getInt();
/* 110 */     } else if (this.version == 2) {
/* 111 */       input.getInt();
/* 112 */       this.sampleRate = (float)Double.longBitsToDouble(input.getLong());
/* 113 */       this.channelCount = (short)input.getInt();
/* 114 */       input.getInt();
/* 115 */       this.sampleSize = (short)input.getInt();
/* 116 */       this.lpcmFlags = input.getInt();
/* 117 */       this.bytesPerFrame = input.getInt();
/* 118 */       this.samplesPerPkt = input.getInt();
/*     */     } 
/* 120 */     parseExtensions(input);
/*     */   }
/*     */   
/*     */   protected void doWrite(ByteBuffer out) {
/* 124 */     super.doWrite(out);
/*     */     
/* 126 */     out.putShort(this.version);
/* 127 */     out.putShort(this.revision);
/* 128 */     out.putInt(this.vendor);
/*     */     
/* 130 */     if (this.version < 2) {
/* 131 */       out.putShort(this.channelCount);
/* 132 */       if (this.version == 0) {
/* 133 */         out.putShort(this.sampleSize);
/*     */       } else {
/* 135 */         out.putShort((short)16);
/*     */       } 
/* 137 */       out.putShort((short)this.compressionId);
/* 138 */       out.putShort((short)this.pktSize);
/*     */       
/* 140 */       out.putInt((int)Math.round(this.sampleRate * 65536.0D));
/*     */       
/* 142 */       if (this.version == 1) {
/* 143 */         out.putInt(this.samplesPerPkt);
/* 144 */         out.putInt(this.bytesPerPkt);
/* 145 */         out.putInt(this.bytesPerFrame);
/* 146 */         out.putInt(this.bytesPerSample);
/*     */       } 
/* 148 */     } else if (this.version == 2) {
/* 149 */       out.putShort((short)3);
/* 150 */       out.putShort((short)16);
/* 151 */       out.putShort((short)-2);
/* 152 */       out.putShort((short)0);
/* 153 */       out.putInt(65536);
/* 154 */       out.putInt(72);
/* 155 */       out.putLong(Double.doubleToLongBits(this.sampleRate));
/* 156 */       out.putInt(this.channelCount);
/* 157 */       out.putInt(2130706432);
/* 158 */       out.putInt(this.sampleSize);
/* 159 */       out.putInt(this.lpcmFlags);
/* 160 */       out.putInt(this.bytesPerFrame);
/* 161 */       out.putInt(this.samplesPerPkt);
/*     */     } 
/*     */     
/* 164 */     writeExtensions(out);
/*     */   }
/*     */   
/*     */   public short getChannelCount() {
/* 168 */     return this.channelCount;
/*     */   }
/*     */   
/*     */   public int calcFrameSize() {
/* 172 */     if (this.version == 0 || this.bytesPerFrame == 0) {
/* 173 */       return (this.sampleSize >> 3) * this.channelCount;
/*     */     }
/* 175 */     return this.bytesPerFrame;
/*     */   }
/*     */   
/*     */   public int calcSampleSize() {
/* 179 */     return calcFrameSize() / this.channelCount;
/*     */   }
/*     */   
/*     */   public short getSampleSize() {
/* 183 */     return this.sampleSize;
/*     */   }
/*     */   
/*     */   public float getSampleRate() {
/* 187 */     return this.sampleRate;
/*     */   }
/*     */   
/*     */   public int getBytesPerFrame() {
/* 191 */     return this.bytesPerFrame;
/*     */   }
/*     */   
/*     */   public int getBytesPerSample() {
/* 195 */     return this.bytesPerSample;
/*     */   }
/*     */   
/*     */   public short getVersion() {
/* 199 */     return this.version;
/*     */   }
/*     */   
/*     */   public ByteOrder getEndian() {
/* 203 */     EndianBox endianBox = NodeBox.<EndianBox>findFirstPath(this, EndianBox.class, new String[] { WaveExtension.fourcc(), EndianBox.fourcc() });
/* 204 */     if (endianBox == null) {
/* 205 */       if ("twos".equals(this.header.getFourcc()))
/* 206 */         return ByteOrder.BIG_ENDIAN; 
/* 207 */       if ("lpcm".equals(this.header.getFourcc()))
/* 208 */         return ((this.lpcmFlags & kAudioFormatFlagIsBigEndian) != 0) ? ByteOrder.BIG_ENDIAN : ByteOrder.LITTLE_ENDIAN; 
/* 209 */       if ("sowt".equals(this.header.getFourcc())) {
/* 210 */         return ByteOrder.LITTLE_ENDIAN;
/*     */       }
/* 212 */       return ByteOrder.BIG_ENDIAN;
/*     */     } 
/* 214 */     return endianBox.getEndian();
/*     */   }
/*     */   
/*     */   public boolean isFloat() {
/* 218 */     return ("fl32".equals(this.header.getFourcc()) || "fl64".equals(this.header.getFourcc()) || ("lpcm"
/* 219 */       .equals(this.header.getFourcc()) && (this.lpcmFlags & kAudioFormatFlagIsFloat) != 0));
/*     */   }
/*     */   
/* 222 */   public static Set<String> pcms = new HashSet<String>();
/*     */   
/*     */   static {
/* 225 */     pcms.add("raw ");
/* 226 */     pcms.add("twos");
/* 227 */     pcms.add("sowt");
/* 228 */     pcms.add("fl32");
/* 229 */     pcms.add("fl64");
/* 230 */     pcms.add("in24");
/* 231 */     pcms.add("in32");
/* 232 */     pcms.add("lpcm");
/*     */   }
/*     */   
/*     */   public boolean isPCM() {
/* 236 */     return pcms.contains(this.header.getFourcc());
/*     */   }
/*     */   
/*     */   public AudioFormat getFormat() {
/* 240 */     return new AudioFormat((int)this.sampleRate, calcSampleSize() << 3, this.channelCount, true, 
/* 241 */         (getEndian() == ByteOrder.BIG_ENDIAN));
/*     */   }
/*     */   
/*     */   public ChannelLabel[] getLabels() {
/* 245 */     ChannelBox channelBox = NodeBox.<ChannelBox>findFirst(this, ChannelBox.class, "chan");
/* 246 */     if (channelBox != null) {
/* 247 */       Label[] labels = getLabelsFromChan(channelBox);
/* 248 */       if (this.channelCount == 2) {
/* 249 */         return translate(translationStereo, labels);
/*     */       }
/* 251 */       return translate(translationSurround, labels);
/*     */     } 
/* 253 */     switch (this.channelCount) {
/*     */       case 1:
/* 255 */         return new ChannelLabel[] { ChannelLabel.MONO };
/*     */       case 2:
/* 257 */         return new ChannelLabel[] { ChannelLabel.STEREO_LEFT, ChannelLabel.STEREO_RIGHT };
/*     */       case 6:
/* 259 */         return new ChannelLabel[] { ChannelLabel.FRONT_LEFT, ChannelLabel.FRONT_RIGHT, ChannelLabel.CENTER, ChannelLabel.LFE, ChannelLabel.REAR_LEFT, ChannelLabel.REAR_RIGHT };
/*     */     } 
/*     */     
/* 262 */     ChannelLabel[] lbl = new ChannelLabel[this.channelCount];
/* 263 */     Arrays.fill((Object[])lbl, ChannelLabel.MONO);
/* 264 */     return lbl;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private ChannelLabel[] translate(Map<Label, ChannelLabel> translation, Label[] labels) {
/* 270 */     ChannelLabel[] result = new ChannelLabel[labels.length];
/* 271 */     int i = 0;
/* 272 */     for (int j = 0; j < labels.length; j++) {
/* 273 */       Label label = labels[j];
/* 274 */       result[i++] = translation.get(label);
/*     */     } 
/* 276 */     return result;
/*     */   }
/*     */ 
/*     */   
/*     */   public static AudioSampleEntry compressedAudioSampleEntry(String fourcc, int drefId, int sampleSize, int channels, int sampleRate, int samplesPerPacket, int bytesPerPacket, int bytesPerFrame) {
/* 281 */     AudioSampleEntry ase = createAudioSampleEntry(Header.createHeader(fourcc, 0L), (short)drefId, (short)channels, (short)16, sampleRate, (short)0, 0, 65534, 0, samplesPerPacket, bytesPerPacket, bytesPerFrame, 2, (short)0);
/*     */ 
/*     */     
/* 284 */     return ase;
/*     */   }
/*     */ 
/*     */   
/*     */   public static AudioSampleEntry audioSampleEntry(String fourcc, int drefId, int sampleSize, int channels, int sampleRate, ByteOrder endian) {
/* 289 */     AudioSampleEntry ase = createAudioSampleEntry(Header.createHeader(fourcc, 0L), (short)drefId, (short)channels, (short)16, sampleRate, (short)0, 0, 65535, 0, 1, sampleSize, channels * sampleSize, sampleSize, (short)1);
/*     */ 
/*     */ 
/*     */     
/* 293 */     NodeBox wave = new NodeBox(new Header("wave"));
/* 294 */     ase.add(wave);
/*     */     
/* 296 */     wave.add(FormatBox.createFormatBox(fourcc));
/* 297 */     wave.add(EndianBox.createEndianBox(endian));
/* 298 */     wave.add(Box.terminatorAtom());
/*     */ 
/*     */     
/* 301 */     return ase;
/*     */   }
/*     */   
/*     */   public static String lookupFourcc(AudioFormat format) {
/* 305 */     if (format.getSampleSizeInBits() == 16 && !format.isBigEndian())
/* 306 */       return "sowt"; 
/* 307 */     if (format.getSampleSizeInBits() == 24) {
/* 308 */       return "in24";
/*     */     }
/* 310 */     throw new NotSupportedException("Audio format " + format + " is not supported.");
/*     */   }
/*     */   
/*     */   public static AudioSampleEntry audioSampleEntryPCM(AudioFormat format) {
/* 314 */     return audioSampleEntry(lookupFourcc(format), 1, format.getSampleSizeInBits() >> 3, format
/* 315 */         .getChannels(), format.getSampleRate(), 
/* 316 */         format.isBigEndian() ? ByteOrder.BIG_ENDIAN : ByteOrder.LITTLE_ENDIAN);
/*     */   }
/*     */   
/* 319 */   private static Map<Label, ChannelLabel> translationStereo = new HashMap<Label, ChannelLabel>();
/* 320 */   private static Map<Label, ChannelLabel> translationSurround = new HashMap<Label, ChannelLabel>();
/*     */   
/*     */   static {
/* 323 */     translationStereo.put(Label.Left, ChannelLabel.STEREO_LEFT);
/* 324 */     translationStereo.put(Label.Right, ChannelLabel.STEREO_RIGHT);
/* 325 */     translationStereo.put(Label.HeadphonesLeft, ChannelLabel.STEREO_LEFT);
/* 326 */     translationStereo.put(Label.HeadphonesRight, ChannelLabel.STEREO_RIGHT);
/* 327 */     translationStereo.put(Label.LeftTotal, ChannelLabel.STEREO_LEFT);
/* 328 */     translationStereo.put(Label.RightTotal, ChannelLabel.STEREO_RIGHT);
/* 329 */     translationStereo.put(Label.LeftWide, ChannelLabel.STEREO_LEFT);
/* 330 */     translationStereo.put(Label.RightWide, ChannelLabel.STEREO_RIGHT);
/*     */     
/* 332 */     translationSurround.put(Label.Left, ChannelLabel.FRONT_LEFT);
/* 333 */     translationSurround.put(Label.Right, ChannelLabel.FRONT_RIGHT);
/* 334 */     translationSurround.put(Label.LeftCenter, ChannelLabel.FRONT_CENTER_LEFT);
/* 335 */     translationSurround.put(Label.RightCenter, ChannelLabel.FRONT_CENTER_RIGHT);
/* 336 */     translationSurround.put(Label.Center, ChannelLabel.CENTER);
/* 337 */     translationSurround.put(Label.CenterSurround, ChannelLabel.REAR_CENTER);
/* 338 */     translationSurround.put(Label.CenterSurroundDirect, ChannelLabel.REAR_CENTER);
/* 339 */     translationSurround.put(Label.LeftSurround, ChannelLabel.REAR_LEFT);
/* 340 */     translationSurround.put(Label.LeftSurroundDirect, ChannelLabel.REAR_LEFT);
/* 341 */     translationSurround.put(Label.RightSurround, ChannelLabel.REAR_RIGHT);
/* 342 */     translationSurround.put(Label.RightSurroundDirect, ChannelLabel.REAR_RIGHT);
/* 343 */     translationSurround.put(Label.RearSurroundLeft, ChannelLabel.SIDE_LEFT);
/* 344 */     translationSurround.put(Label.RearSurroundRight, ChannelLabel.SIDE_RIGHT);
/* 345 */     translationSurround.put(Label.LFE2, ChannelLabel.LFE);
/* 346 */     translationSurround.put(Label.LFEScreen, ChannelLabel.LFE);
/* 347 */     translationSurround.put(Label.LeftTotal, ChannelLabel.STEREO_LEFT);
/* 348 */     translationSurround.put(Label.RightTotal, ChannelLabel.STEREO_RIGHT);
/* 349 */     translationSurround.put(Label.LeftWide, ChannelLabel.STEREO_LEFT);
/* 350 */     translationSurround.put(Label.RightWide, ChannelLabel.STEREO_RIGHT);
/*     */   }
/*     */   
/*     */   public static Label[] getLabelsFromSampleEntry(AudioSampleEntry se) {
/* 354 */     ChannelBox channel = NodeBox.<ChannelBox>findFirst(se, ChannelBox.class, "chan");
/* 355 */     if (channel != null) {
/* 356 */       return getLabelsFromChan(channel);
/*     */     }
/* 358 */     short channelCount = se.getChannelCount();
/* 359 */     switch (channelCount) {
/*     */       case 1:
/* 361 */         return new Label[] { Label.Mono };
/*     */       case 2:
/* 363 */         return new Label[] { Label.Left, Label.Right };
/*     */       case 3:
/* 365 */         return new Label[] { Label.Left, Label.Right, Label.Center };
/*     */       case 4:
/* 367 */         return new Label[] { Label.Left, Label.Right, Label.LeftSurround, Label.RightSurround };
/*     */       case 5:
/* 369 */         return new Label[] { Label.Left, Label.Right, Label.Center, Label.LeftSurround, Label.RightSurround };
/*     */       case 6:
/* 371 */         return new Label[] { Label.Left, Label.Right, Label.Center, Label.LFEScreen, Label.LeftSurround, Label.RightSurround };
/*     */     } 
/*     */     
/* 374 */     Label[] res = new Label[channelCount];
/* 375 */     Arrays.fill((Object[])res, Label.Mono);
/* 376 */     return res;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public static Label[] getLabelsFromTrack(TrakBox trakBox) {
/* 382 */     return getLabelsFromSampleEntry((AudioSampleEntry)trakBox.getSampleEntries()[0]);
/*     */   }
/*     */   
/*     */   public static void setLabel(TrakBox trakBox, int channel, Label label) {
/* 386 */     Label[] labels = getLabelsFromTrack(trakBox);
/* 387 */     labels[channel] = label;
/* 388 */     _setLabels(trakBox, labels);
/*     */   }
/*     */   
/*     */   public static void _setLabels(TrakBox trakBox, Label[] labels) {
/* 392 */     ChannelBox channel = NodeBox.<ChannelBox>findFirstPath(trakBox, ChannelBox.class, new String[] { "mdia", "minf", "stbl", "stsd", null, "chan" });
/* 393 */     if (channel == null) {
/* 394 */       channel = ChannelBox.createChannelBox();
/* 395 */       ((SampleEntry)NodeBox.<SampleEntry>findFirstPath(trakBox, SampleEntry.class, new String[] { "mdia", "minf", "stbl", "stsd", null })).add(channel);
/*     */     } 
/* 397 */     setLabels(labels, channel);
/*     */   }
/*     */   
/*     */   public static void setLabels(Label[] labels, ChannelBox channel) {
/* 401 */     channel.setChannelLayout(ChannelLayout.kCAFChannelLayoutTag_UseChannelDescriptions.getCode());
/* 402 */     ChannelBox.ChannelDescription[] list = new ChannelBox.ChannelDescription[labels.length];
/* 403 */     for (int i = 0; i < labels.length; i++) {
/* 404 */       list[i] = new ChannelBox.ChannelDescription(labels[i].getVal(), 0, new float[] { 0.0F, 0.0F, 0.0F });
/* 405 */     }  channel.setDescriptions(list);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Label[] getLabelsByBitmap(long channelBitmap) {
/* 437 */     List<Label> result = new ArrayList<Label>();
/* 438 */     Label[] values = Label.values();
/* 439 */     for (int i = 0; i < values.length; i++) {
/* 440 */       Label label = values[i];
/* 441 */       if ((label.bitmapVal & channelBitmap) != 0L)
/* 442 */         result.add(label); 
/*     */     } 
/* 444 */     return result.<Label>toArray(new Label[0]);
/*     */   }
/*     */   
/*     */   public static Label[] extractLabels(ChannelBox.ChannelDescription[] descriptions) {
/* 448 */     Label[] result = new Label[descriptions.length];
/* 449 */     for (int i = 0; i < descriptions.length; i++)
/* 450 */       result[i] = descriptions[i].getLabel(); 
/* 451 */     return result;
/*     */   }
/*     */   
/*     */   public static Label[] getLabelsFromChan(ChannelBox box) {
/* 455 */     long tag = box.getChannelLayout();
/* 456 */     if (tag >> 16L == 147L) {
/* 457 */       int n = (int)tag & 0xFFFF;
/* 458 */       Label[] res = new Label[n];
/* 459 */       for (int j = 0; j < n; j++)
/* 460 */         res[j] = Label.getByVal(0x10000 | j); 
/* 461 */       return res;
/*     */     } 
/* 463 */     ChannelLayout[] values = ChannelLayout.values();
/* 464 */     for (int i = 0; i < values.length; i++) {
/* 465 */       ChannelLayout layout = values[i];
/* 466 */       if (layout.getCode() == tag) {
/* 467 */         if (layout == ChannelLayout.kCAFChannelLayoutTag_UseChannelDescriptions)
/* 468 */           return extractLabels(box.getDescriptions()); 
/* 469 */         if (layout == ChannelLayout.kCAFChannelLayoutTag_UseChannelBitmap) {
/* 470 */           return getLabelsByBitmap(box.getChannelBitmap());
/*     */         }
/* 472 */         return layout.getLabels();
/*     */       } 
/*     */     } 
/*     */     
/* 476 */     return EMPTY;
/*     */   }
/*     */ }


/* Location:              C:\Users\rapha\Downloads\aurora.jar!\META-INF\jars\jcodec-0.2.5.jar!\org\jcodec\containers\mp4\boxes\AudioSampleEntry.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */