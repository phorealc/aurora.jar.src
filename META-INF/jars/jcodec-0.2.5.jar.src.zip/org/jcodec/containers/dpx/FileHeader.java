package org.jcodec.containers.dpx;

import java.util.Date;

public class FileHeader {
  public int magic;
  
  public int imageOffset;
  
  public String version;
  
  public int ditto;
  
  public String filename;
  
  public Date created;
  
  public int filesize;
  
  public String creator;
  
  public String projectName;
  
  public String copyright;
  
  public int encKey;
  
  public int genericHeaderLength;
  
  public int industryHeaderLength;
  
  public int userHeaderLength;
}


/* Location:              C:\Users\rapha\Downloads\aurora.jar!\META-INF\jars\jcodec-0.2.5.jar!\org\jcodec\containers\dpx\FileHeader.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */