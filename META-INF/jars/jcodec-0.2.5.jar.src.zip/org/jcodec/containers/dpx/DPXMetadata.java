/*    */ package org.jcodec.containers.dpx;
/*    */ 
/*    */ import org.jcodec.common.StringUtils;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class DPXMetadata
/*    */ {
/*    */   public static final String V2 = "V2.0";
/*    */   public static final String V1 = "V1.0";
/*    */   public FileHeader file;
/*    */   public ImageHeader image;
/*    */   public ImageSourceHeader imageSource;
/*    */   public FilmHeader film;
/*    */   public TelevisionHeader television;
/*    */   public String userId;
/*    */   
/*    */   private static String smpteTC(int tcsmpte, boolean prevent_dropframe) {
/* 20 */     int ff = bcd2uint(tcsmpte & 0x3F);
/* 21 */     int ss = bcd2uint(tcsmpte >> 8 & 0x7F);
/* 22 */     int mm = bcd2uint(tcsmpte >> 16 & 0x7F);
/* 23 */     int hh = bcd2uint(tcsmpte >> 24 & 0x3F);
/* 24 */     boolean drop = ((tcsmpte & 0x40000000) > 0L && !prevent_dropframe);
/* 25 */     return StringUtils.zeroPad2(hh) + ":" + 
/* 26 */       StringUtils.zeroPad2(mm) + ":" + 
/* 27 */       StringUtils.zeroPad2(ss) + (drop ? ";" : ":") + 
/* 28 */       StringUtils.zeroPad2(ff);
/*    */   }
/*    */   
/*    */   private static int bcd2uint(int bcd) {
/* 32 */     int low = bcd & 0xF;
/* 33 */     int high = bcd >> 4;
/* 34 */     if (low > 9 || high > 9)
/* 35 */       return 0; 
/* 36 */     return low + 10 * high;
/*    */   }
/*    */   
/*    */   public String getTimecodeString() {
/* 40 */     return smpteTC(this.television.timecode, false);
/*    */   }
/*    */ }


/* Location:              C:\Users\rapha\Downloads\aurora.jar!\META-INF\jars\jcodec-0.2.5.jar!\org\jcodec\containers\dpx\DPXMetadata.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */