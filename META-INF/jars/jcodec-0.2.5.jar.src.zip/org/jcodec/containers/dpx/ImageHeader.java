package org.jcodec.containers.dpx;

public class ImageHeader {
  public short orientation;
  
  public short numberOfImageElements;
  
  public int linesPerImageElement;
  
  public int pixelsPerLine;
  
  public ImageElement imageElement1;
}


/* Location:              C:\Users\rapha\Downloads\aurora.jar!\META-INF\jars\jcodec-0.2.5.jar!\org\jcodec\containers\dpx\ImageHeader.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */