package org.jcodec.containers.dpx;

public class ImageElement {
  public int dataSign;
}


/* Location:              C:\Users\rapha\Downloads\aurora.jar!\META-INF\jars\jcodec-0.2.5.jar!\org\jcodec\containers\dpx\ImageElement.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */