package org.jcodec.containers.dpx;

public class FilmHeader {
  public String idCode;
  
  public String type;
  
  public String offset;
  
  public String prefix;
  
  public String count;
  
  public String format;
}


/* Location:              C:\Users\rapha\Downloads\aurora.jar!\META-INF\jars\jcodec-0.2.5.jar!\org\jcodec\containers\dpx\FilmHeader.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */