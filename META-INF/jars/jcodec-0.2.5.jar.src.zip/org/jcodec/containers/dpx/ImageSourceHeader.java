package org.jcodec.containers.dpx;

import java.util.Date;

public class ImageSourceHeader {
  public int xOffset;
  
  public int yOffset;
  
  public float xCenter;
  
  public float yCenter;
  
  public int xOriginal;
  
  public int yOriginal;
  
  public String sourceImageFilename;
  
  public Date sourceImageDate;
  
  public String deviceName;
  
  public String deviceSerial;
  
  public short[] borderValidity;
  
  public int[] aspectRatio;
}


/* Location:              C:\Users\rapha\Downloads\aurora.jar!\META-INF\jars\jcodec-0.2.5.jar!\org\jcodec\containers\dpx\ImageSourceHeader.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */