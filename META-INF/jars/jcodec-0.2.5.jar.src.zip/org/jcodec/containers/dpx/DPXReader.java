/*     */ package org.jcodec.containers.dpx;
/*     */ 
/*     */ import java.io.Closeable;
/*     */ import java.io.File;
/*     */ import java.io.IOException;
/*     */ import java.nio.ByteBuffer;
/*     */ import java.nio.ByteOrder;
/*     */ import java.nio.channels.ReadableByteChannel;
/*     */ import java.text.ParseException;
/*     */ import java.text.SimpleDateFormat;
/*     */ import java.util.Date;
/*     */ import java.util.Locale;
/*     */ import org.jcodec.common.StringUtils;
/*     */ import org.jcodec.common.io.FileChannelWrapper;
/*     */ import org.jcodec.common.io.IOUtils;
/*     */ import org.jcodec.common.io.NIOUtils;
/*     */ import org.jcodec.common.io.SeekableByteChannel;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class DPXReader
/*     */ {
/*     */   private static final int READ_BUFFER_SIZE = 3072;
/*     */   static final int IMAGEINFO_OFFSET = 768;
/*     */   static final int IMAGESOURCE_OFFSET = 1408;
/*     */   static final int FILM_OFFSET = 1664;
/*     */   static final int TVINFO_OFFSET = 1920;
/*     */   public static final int SDPX = 1396985944;
/*     */   private final ByteBuffer readBuf;
/*     */   private final int magic;
/*     */   private boolean eof;
/*     */   
/*     */   public DPXReader(SeekableByteChannel ch) throws IOException {
/*  35 */     this.readBuf = ByteBuffer.allocate(3072);
/*  36 */     initialRead((ReadableByteChannel)ch);
/*  37 */     this.magic = this.readBuf.getInt();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*  45 */     if (this.magic == 1396985944) {
/*  46 */       this.readBuf.order(ByteOrder.BIG_ENDIAN);
/*     */     } else {
/*  48 */       this.readBuf.order(ByteOrder.LITTLE_ENDIAN);
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public DPXMetadata parseMetadata() {
/*  54 */     DPXMetadata dpx = new DPXMetadata();
/*  55 */     dpx.file = readFileInfo(this.readBuf);
/*  56 */     dpx.file.magic = this.magic;
/*     */ 
/*     */     
/*  59 */     this.readBuf.position(768);
/*  60 */     dpx.image = readImageInfoHeader(this.readBuf);
/*     */ 
/*     */     
/*  63 */     this.readBuf.position(1408);
/*  64 */     dpx.imageSource = readImageSourceHeader(this.readBuf);
/*     */ 
/*     */     
/*  67 */     this.readBuf.position(1664);
/*  68 */     dpx.film = readFilmInformationHeader(this.readBuf);
/*     */ 
/*     */     
/*  71 */     this.readBuf.position(1920);
/*  72 */     dpx.television = readTelevisionInfoHeader(this.readBuf);
/*     */     
/*  74 */     dpx.userId = readNullTermString(this.readBuf, 32);
/*  75 */     return dpx;
/*     */   }
/*     */   
/*     */   private void initialRead(ReadableByteChannel ch) throws IOException {
/*  79 */     this.readBuf.clear();
/*  80 */     if (ch.read(this.readBuf) == -1)
/*  81 */       this.eof = true; 
/*  82 */     this.readBuf.flip();
/*     */   }
/*     */   
/*     */   private static FileHeader readFileInfo(ByteBuffer bb) {
/*  86 */     FileHeader h = new FileHeader();
/*  87 */     h.imageOffset = bb.getInt();
/*  88 */     h.version = readNullTermString(bb, 8);
/*  89 */     h.filesize = bb.getInt();
/*  90 */     h.ditto = bb.getInt();
/*     */     
/*  92 */     h.genericHeaderLength = bb.getInt();
/*  93 */     h.industryHeaderLength = bb.getInt();
/*  94 */     h.userHeaderLength = bb.getInt();
/*     */     
/*  96 */     h.filename = readNullTermString(bb, 100);
/*  97 */     h.created = tryParseISO8601Date(readNullTermString(bb, 24));
/*  98 */     h.creator = readNullTermString(bb, 100);
/*  99 */     h.projectName = readNullTermString(bb, 200);
/* 100 */     h.copyright = readNullTermString(bb, 200);
/* 101 */     h.encKey = bb.getInt();
/* 102 */     return h;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static Date tryParseISO8601Date(String dateString) {
/* 120 */     if (StringUtils.isEmpty(dateString)) {
/* 121 */       return null;
/*     */     }
/*     */     
/* 124 */     String noTZ = "yyyy:MM:dd:HH:mm:ss";
/* 125 */     if (dateString.length() == noTZ.length())
/* 126 */       return date(dateString, noTZ); 
/* 127 */     if (dateString.length() == noTZ.length() + 4)
/*     */     {
/* 129 */       dateString = dateString + "00";
/*     */     }
/*     */ 
/*     */     
/* 133 */     return date(dateString, "yyyy:MM:dd:HH:mm:ss:Z");
/*     */   }
/*     */   
/*     */   private static Date date(String dateString, String dateFormat) {
/* 137 */     SimpleDateFormat format = new SimpleDateFormat(dateFormat, Locale.US);
/*     */     try {
/* 139 */       return format.parse(dateString);
/* 140 */     } catch (ParseException e) {
/* 141 */       return null;
/*     */     } 
/*     */   }
/*     */   
/*     */   private static String readNullTermString(ByteBuffer bb, int length) {
/* 146 */     ByteBuffer b = ByteBuffer.allocate(length);
/* 147 */     bb.get(b.array(), 0, length);
/* 148 */     return NIOUtils.readNullTermString(b);
/*     */   }
/*     */   
/*     */   public static DPXReader readFile(File file) throws IOException {
/* 152 */     FileChannelWrapper fileChannelWrapper = NIOUtils.readableChannel(file);
/*     */     
/*     */     try {
/* 155 */       return new DPXReader((SeekableByteChannel)fileChannelWrapper);
/*     */     } finally {
/* 157 */       IOUtils.closeQuietly((Closeable)fileChannelWrapper);
/*     */     } 
/*     */   }
/*     */   
/*     */   private static TelevisionHeader readTelevisionInfoHeader(ByteBuffer r) {
/* 162 */     TelevisionHeader h = new TelevisionHeader();
/* 163 */     h.timecode = r.getInt();
/* 164 */     h.userBits = r.getInt();
/* 165 */     h.interlace = r.get();
/* 166 */     h.filedNumber = r.get();
/* 167 */     h.videoSignalStarted = r.get();
/* 168 */     h.zero = r.get();
/* 169 */     h.horSamplingRateHz = r.getInt();
/* 170 */     h.vertSampleRateHz = r.getInt();
/* 171 */     h.frameRate = r.getInt();
/* 172 */     h.timeOffset = r.getInt();
/* 173 */     h.gamma = r.getInt();
/* 174 */     h.blackLevel = r.getInt();
/* 175 */     h.blackGain = r.getInt();
/* 176 */     h.breakpoint = r.getInt();
/* 177 */     h.referenceWhiteLevel = r.getInt();
/* 178 */     h.integrationTime = r.getInt();
/*     */     
/* 180 */     return h;
/*     */   }
/*     */   
/*     */   private static FilmHeader readFilmInformationHeader(ByteBuffer r) {
/* 184 */     FilmHeader h = new FilmHeader();
/* 185 */     h.idCode = readNullTermString(r, 2);
/* 186 */     h.type = readNullTermString(r, 2);
/* 187 */     h.offset = readNullTermString(r, 2);
/* 188 */     h.prefix = readNullTermString(r, 6);
/* 189 */     h.count = readNullTermString(r, 4);
/* 190 */     h.format = readNullTermString(r, 32);
/*     */     
/* 192 */     return h;
/*     */   }
/*     */   
/*     */   private static ImageSourceHeader readImageSourceHeader(ByteBuffer r) {
/* 196 */     ImageSourceHeader h = new ImageSourceHeader();
/* 197 */     h.xOffset = r.getInt();
/* 198 */     h.yOffset = r.getInt();
/* 199 */     h.xCenter = r.getFloat();
/* 200 */     h.yCenter = r.getFloat();
/* 201 */     h.xOriginal = r.getInt();
/* 202 */     h.yOriginal = r.getInt();
/* 203 */     h.sourceImageFilename = readNullTermString(r, 100);
/* 204 */     h.sourceImageDate = tryParseISO8601Date(readNullTermString(r, 24));
/* 205 */     h.deviceName = readNullTermString(r, 32);
/* 206 */     h.deviceSerial = readNullTermString(r, 32);
/* 207 */     h.borderValidity = new short[] { r.getShort(), r.getShort(), r.getShort(), r.getShort() };
/* 208 */     h.aspectRatio = new int[] { r.getInt(), r.getInt() };
/* 209 */     return h;
/*     */   }
/*     */ 
/*     */   
/*     */   private static ImageHeader readImageInfoHeader(ByteBuffer r) {
/* 214 */     ImageHeader h = new ImageHeader();
/*     */     
/* 216 */     h.orientation = r.getShort();
/* 217 */     h.numberOfImageElements = r.getShort();
/* 218 */     h.pixelsPerLine = r.getInt();
/* 219 */     h.linesPerImageElement = r.getInt();
/* 220 */     h.imageElement1 = new ImageElement();
/*     */ 
/*     */     
/* 223 */     h.imageElement1.dataSign = r.getInt();
/* 224 */     return h;
/*     */   }
/*     */ }


/* Location:              C:\Users\rapha\Downloads\aurora.jar!\META-INF\jars\jcodec-0.2.5.jar!\org\jcodec\containers\dpx\DPXReader.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */