package org.jcodec.containers.dpx;

public class TelevisionHeader {
  public int timecode;
  
  public int userBits;
  
  public byte interlace;
  
  public byte filedNumber;
  
  public byte videoSignalStarted;
  
  public byte zero;
  
  public int horSamplingRateHz;
  
  public int vertSampleRateHz;
  
  public int frameRate;
  
  public int timeOffset;
  
  public int gamma;
  
  public int blackLevel;
  
  public int blackGain;
  
  public int breakpoint;
  
  public int referenceWhiteLevel;
  
  public int integrationTime;
}


/* Location:              C:\Users\rapha\Downloads\aurora.jar!\META-INF\jars\jcodec-0.2.5.jar!\org\jcodec\containers\dpx\TelevisionHeader.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */