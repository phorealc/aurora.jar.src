/*     */ package org.jcodec.containers.mp3;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.nio.ByteBuffer;
/*     */ import java.nio.ByteOrder;
/*     */ import java.util.ArrayList;
/*     */ import java.util.List;
/*     */ import org.jcodec.common.AudioCodecMeta;
/*     */ import org.jcodec.common.Codec;
/*     */ import org.jcodec.common.Demuxer;
/*     */ import org.jcodec.common.DemuxerTrack;
/*     */ import org.jcodec.common.DemuxerTrackMeta;
/*     */ import org.jcodec.common.TrackType;
/*     */ import org.jcodec.common.UsedViaReflection;
/*     */ import org.jcodec.common.io.NIOUtils;
/*     */ import org.jcodec.common.io.SeekableByteChannel;
/*     */ import org.jcodec.common.logging.Logger;
/*     */ import org.jcodec.common.model.Packet;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class MPEGAudioDemuxer
/*     */   implements Demuxer, DemuxerTrack
/*     */ {
/*     */   private static final int MAX_FRAME_SIZE = 1728;
/*     */   private static final int MIN_FRAME_SIZE = 52;
/*     */   
/*     */   private static int field(int off, int size) {
/*  33 */     return (1 << size) - 1 << 16 | off;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*  38 */   private static final int CHANNELS = field(6, 2);
/*  39 */   private static final int PADDING = field(9, 1);
/*  40 */   private static final int SAMPLE_RATE = field(10, 2);
/*  41 */   private static final int BITRATE = field(12, 4);
/*  42 */   private static final int VERSION = field(19, 2);
/*  43 */   private static final int LAYER = field(17, 2);
/*  44 */   private static final int SYNC = field(21, 11);
/*     */   
/*     */   private static final int MPEG1 = 3;
/*     */   
/*     */   private static final int MPEG2 = 2;
/*     */   private static final int MPEG25 = 0;
/*  50 */   private static int[][][] bitrateTable = new int[][][] { { { 0, 32, 64, 96, 128, 160, 192, 224, 256, 288, 320, 352, 384, 416, 448 }, { 0, 32, 48, 56, 64, 80, 96, 112, 128, 160, 192, 224, 256, 320, 384 }, { 0, 32, 40, 48, 56, 64, 80, 96, 112, 128, 160, 192, 224, 256, 320 } }, { { 0, 32, 48, 56, 64, 80, 96, 112, 128, 144, 160, 176, 192, 224, 256 }, { 0, 8, 16, 24, 32, 40, 48, 56, 64, 80, 96, 112, 128, 144, 160 }, { 0, 8, 16, 24, 32, 40, 48, 56, 64, 80, 96, 112, 128, 144, 160 } } };
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  57 */   private static int[] freqTab = new int[] { 44100, 48000, 32000 };
/*  58 */   private static int[] rateReductTab = new int[] { 2, 0, 1, 0 }; private SeekableByteChannel ch;
/*     */   
/*     */   private static int getField(int header, int field) {
/*  61 */     return header >> (field & 0xFFFF) & field >> 16;
/*     */   }
/*     */ 
/*     */   
/*     */   private List<DemuxerTrack> tracks;
/*     */   private int frameNo;
/*     */   private ByteBuffer readBuffer;
/*     */   private int runningFour;
/*     */   private boolean eof;
/*     */   private DemuxerTrackMeta meta;
/*     */   private int sampleRate;
/*     */   
/*     */   public MPEGAudioDemuxer(SeekableByteChannel ch) throws IOException {
/*  74 */     this.ch = ch;
/*  75 */     this.readBuffer = ByteBuffer.allocate(262144);
/*  76 */     readMoreData();
/*  77 */     if (this.readBuffer.remaining() < 4) {
/*  78 */       this.eof = true;
/*     */     } else {
/*  80 */       this.runningFour = this.readBuffer.getInt();
/*  81 */       if (!validHeader(this.runningFour)) {
/*  82 */         this.eof = skipJunk();
/*     */       }
/*  84 */       extractMeta();
/*     */     } 
/*     */     
/*  87 */     this.tracks = new ArrayList<DemuxerTrack>();
/*  88 */     this.tracks.add(this);
/*     */   }
/*     */   
/*     */   private void extractMeta() {
/*  92 */     if (!validHeader(this.runningFour))
/*     */       return; 
/*  94 */     int layer = 3 - getField(this.runningFour, LAYER);
/*  95 */     int channelCount = (getField(this.runningFour, CHANNELS) == 3) ? 1 : 2;
/*     */     
/*  97 */     int version = getField(this.runningFour, VERSION);
/*  98 */     this.sampleRate = freqTab[getField(this.runningFour, SAMPLE_RATE)] >> rateReductTab[version];
/*  99 */     AudioCodecMeta codecMeta = AudioCodecMeta.createAudioCodecMeta(".mp3", 16, channelCount, this.sampleRate, ByteOrder.LITTLE_ENDIAN, false, null, null);
/*     */     
/* 101 */     Codec codec = (layer == 2) ? Codec.MP3 : ((layer == 1) ? Codec.MP2 : Codec.MP1);
/* 102 */     this.meta = new DemuxerTrackMeta(TrackType.AUDIO, codec, 0.0D, null, 0, null, null, codecMeta);
/*     */   }
/*     */ 
/*     */   
/*     */   public void close() throws IOException {
/* 107 */     this.ch.close();
/*     */   }
/*     */ 
/*     */   
/*     */   public List<? extends DemuxerTrack> getTracks() {
/* 112 */     return this.tracks;
/*     */   }
/*     */ 
/*     */   
/*     */   public List<? extends DemuxerTrack> getVideoTracks() {
/* 117 */     return null;
/*     */   }
/*     */ 
/*     */   
/*     */   public List<? extends DemuxerTrack> getAudioTracks() {
/* 122 */     return this.tracks;
/*     */   }
/*     */ 
/*     */   
/*     */   public Packet nextFrame() throws IOException {
/* 127 */     if (this.eof)
/* 128 */       return null; 
/* 129 */     if (!validHeader(this.runningFour)) {
/* 130 */       this.eof = skipJunk();
/*     */     }
/* 132 */     int frameSize = calcFrameSize(this.runningFour);
/* 133 */     ByteBuffer frame = ByteBuffer.allocate(frameSize);
/* 134 */     this.eof = readFrame(frame);
/* 135 */     frame.flip();
/*     */     
/* 137 */     Packet pkt = new Packet(frame, (this.frameNo * 1152), this.sampleRate, 1152L, this.frameNo, Packet.FrameType.KEY, null, 0);
/*     */     
/* 139 */     this.frameNo++;
/*     */     
/* 141 */     return pkt;
/*     */   }
/*     */   
/*     */   private static boolean validHeader(int four) {
/* 145 */     if (getField(four, SYNC) != 2047)
/* 146 */       return false; 
/* 147 */     if (getField(four, LAYER) == 0)
/* 148 */       return false; 
/* 149 */     if (getField(four, SAMPLE_RATE) == 3)
/* 150 */       return false; 
/* 151 */     if (getField(four, BITRATE) == 15)
/* 152 */       return false; 
/* 153 */     return true;
/*     */   }
/*     */   
/*     */   private void readMoreData() throws IOException {
/* 157 */     this.readBuffer.clear();
/* 158 */     this.ch.read(this.readBuffer);
/* 159 */     this.readBuffer.flip();
/*     */   }
/*     */   
/*     */   private static int calcFrameSize(int header) {
/* 163 */     int bitrateIdx = getField(header, BITRATE);
/* 164 */     int layer = 3 - getField(header, LAYER);
/* 165 */     int version = getField(header, VERSION);
/* 166 */     int mpeg2 = (version != 3) ? 1 : 0;
/* 167 */     int bitRate = bitrateTable[mpeg2][layer][bitrateIdx] * 1000;
/* 168 */     int sampleRate = freqTab[getField(header, SAMPLE_RATE)] >> rateReductTab[version];
/* 169 */     int padding = getField(header, PADDING);
/* 170 */     int lsf = (version == 0 || version == 2) ? 1 : 0;
/* 171 */     switch (layer) {
/*     */       case 0:
/* 173 */         return (bitRate * 12 / sampleRate + padding) * 4;
/*     */       case 1:
/* 175 */         return bitRate * 144 / sampleRate + padding;
/*     */     } 
/*     */     
/* 178 */     return bitRate * 144 / (sampleRate << lsf) + padding;
/*     */   }
/*     */ 
/*     */   
/*     */   private boolean readFrame(ByteBuffer frame) throws IOException {
/* 183 */     boolean eof = false;
/* 184 */     while (frame.hasRemaining()) {
/* 185 */       frame.put((byte)(this.runningFour >> 24));
/* 186 */       this.runningFour <<= 8;
/* 187 */       if (!this.readBuffer.hasRemaining())
/* 188 */         readMoreData(); 
/* 189 */       if (this.readBuffer.hasRemaining()) {
/* 190 */         this.runningFour |= this.readBuffer.get() & 0xFF; continue;
/*     */       } 
/* 192 */       eof = true;
/*     */     } 
/* 194 */     return eof;
/*     */   }
/*     */   
/*     */   private boolean skipJunk() throws IOException {
/* 198 */     boolean eof = false;
/* 199 */     int total = 0;
/* 200 */     while (!validHeader(this.runningFour)) {
/* 201 */       if (!this.readBuffer.hasRemaining())
/* 202 */         readMoreData(); 
/* 203 */       if (!this.readBuffer.hasRemaining()) {
/* 204 */         eof = true;
/*     */         break;
/*     */       } 
/* 207 */       this.runningFour <<= 8;
/* 208 */       this.runningFour |= this.readBuffer.get() & 0xFF;
/* 209 */       total++;
/*     */     } 
/* 211 */     Logger.warn(String.format("[mp3demuxer] Skipped %d bytes of junk", new Object[] { Integer.valueOf(total) }));
/* 212 */     return eof;
/*     */   }
/*     */ 
/*     */   
/*     */   public DemuxerTrackMeta getMeta() {
/* 217 */     return this.meta;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @UsedViaReflection
/*     */   public static int probe(ByteBuffer b) {
/* 229 */     ByteBuffer fork = b.duplicate();
/*     */     
/* 231 */     int valid = 0, total = 0;
/* 232 */     int header = fork.getInt();
/*     */     do {
/* 234 */       if (!validHeader(header))
/* 235 */         header = skipJunkBB(header, fork); 
/* 236 */       int size = calcFrameSize(header);
/* 237 */       if (fork.remaining() < size)
/*     */         break; 
/* 239 */       total++;
/* 240 */       if (size > 0) {
/* 241 */         NIOUtils.skip(fork, size - 4);
/*     */       } else {
/* 243 */         header = skipJunkBB(header, fork);
/* 244 */       }  if (fork.remaining() < 4)
/* 245 */         continue;  header = fork.getInt();
/* 246 */       if (size < 52 || size > 1728 || !validHeader(header))
/* 247 */         continue;  valid++;
/*     */     }
/* 249 */     while (fork.remaining() >= 4);
/*     */     
/* 251 */     return 100 * valid / total;
/*     */   }
/*     */   
/*     */   private static int skipJunkBB(int header, ByteBuffer fork) {
/* 255 */     while (!validHeader(header) && fork.hasRemaining()) {
/* 256 */       header <<= 8;
/* 257 */       header |= fork.get() & 0xFF;
/*     */     } 
/* 259 */     return header;
/*     */   }
/*     */ }


/* Location:              C:\Users\rapha\Downloads\aurora.jar!\META-INF\jars\jcodec-0.2.5.jar!\org\jcodec\containers\mp3\MPEGAudioDemuxer.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */