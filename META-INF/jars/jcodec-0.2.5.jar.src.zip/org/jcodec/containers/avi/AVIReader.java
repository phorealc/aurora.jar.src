/*      */ package org.jcodec.containers.avi;
/*      */ 
/*      */ import java.io.IOException;
/*      */ import java.io.PrintStream;
/*      */ import java.nio.ByteBuffer;
/*      */ import java.nio.ByteOrder;
/*      */ import java.util.ArrayList;
/*      */ import java.util.List;
/*      */ import org.jcodec.api.FormatException;
/*      */ import org.jcodec.common.io.DataReader;
/*      */ import org.jcodec.common.io.SeekableByteChannel;
/*      */ import org.jcodec.common.logging.Logger;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ public class AVIReader
/*      */ {
/*      */   public static final int FOURCC_RIFF = 1179011410;
/*      */   public static final int FOURCC_AVI = 541677121;
/*      */   public static final int FOURCC_AVIX = 1481201217;
/*      */   public static final int FOURCC_AVIH = 1751742049;
/*      */   public static final int FOURCC_LIST = 1414744396;
/*      */   public static final int FOURCC_HDRL = 1819436136;
/*      */   public static final int FOURCC_JUNK = 1263424842;
/*      */   public static final int FOURCC_INDX = 2019847785;
/*      */   public static final int FOURCC_IDXL = 829973609;
/*      */   public static final int FOURCC_STRL = 1819440243;
/*      */   public static final int FOURCC_STRH = 1752331379;
/*      */   public static final int FOURCC_STRF = 1718776947;
/*      */   public static final int FOURCC_MOVI = 1769369453;
/*      */   public static final int FOURCC_REC = 543384946;
/*      */   public static final int FOURCC_SEGM = 1835492723;
/*      */   public static final int FOURCC_ODML = 1819108463;
/*      */   public static final int FOURCC_VIDS = 1935960438;
/*      */   public static final int FOURCC_AUDS = 1935963489;
/*      */   public static final int FOURCC_MIDS = 1935960429;
/*      */   public static final int FOURCC_TXTS = 1937012852;
/*      */   public static final int FOURCC_strd = 1685222515;
/*      */   public static final int FOURCC_strn = 1852994675;
/*      */   public static final int AVIF_HASINDEX = 16;
/*      */   public static final int AVIF_MUSTUSEINDEX = 32;
/*      */   public static final int AVIF_ISINTERLEAVED = 256;
/*      */   public static final int AVIF_TRUSTCKTYPE = 2048;
/*      */   public static final int AVIF_WASCAPTUREFILE = 65536;
/*      */   public static final int AVIF_COPYRIGHTED = 131072;
/*      */   public static final int AVIIF_LIST = 1;
/*      */   public static final int AVIIF_KEYFRAME = 16;
/*      */   public static final int AVIIF_FIRSTPART = 32;
/*      */   public static final int AVIIF_LASTPART = 64;
/*      */   public static final int AVIIF_NOTIME = 256;
/*      */   public static final int AUDIO_FORMAT_PCM = 1;
/*      */   public static final int AUDIO_FORMAT_MP3 = 85;
/*      */   public static final int AUDIO_FORMAT_AC3 = 8192;
/*      */   public static final int AUDIO_FORMAT_DTS = 8193;
/*      */   public static final int AUDIO_FORMAT_VORBIS = 22127;
/*      */   public static final int AUDIO_FORMAT_EXTENSIBLE = 65534;
/*   96 */   public final int AVI_INDEX_OF_INDEXES = 0;
/*   97 */   public final int AVI_INDEX_OF_CHUNKS = 1;
/*   98 */   public final int AVI_INDEX_OF_TIMED_CHUNKS = 2;
/*   99 */   public final int AVI_INDEX_OF_SUB_2FIELD = 3;
/*  100 */   public final int AVI_INDEX_IS_DATA = 128;
/*      */ 
/*      */   
/*      */   public static final int STDINDEXSIZE = 16384;
/*      */ 
/*      */   
/*      */   private static final long SIZE_MASK = 4294967295L;
/*      */   
/*  108 */   private DataReader raf = null;
/*  109 */   private long fileLeft = 0L;
/*      */   
/*      */   private AVITag_AVIH aviHeader;
/*      */   
/*      */   private AVITag_STRH[] streamHeaders;
/*      */   
/*      */   private AVIChunk[] streamFormats;
/*      */   private List<AVITag_AviIndex> aviIndexes;
/*      */   private AVITag_AviDmlSuperIndex[] openDmlSuperIndex;
/*  118 */   private PrintStream ps = null;
/*      */   
/*      */   private boolean skipFrames = true;
/*      */ 
/*      */   
/*      */   public AVIReader(SeekableByteChannel src) {
/*  124 */     this.raf = DataReader.createDataReader(src, ByteOrder.LITTLE_ENDIAN);
/*  125 */     this.aviIndexes = new ArrayList<AVITag_AviIndex>();
/*      */   }
/*      */ 
/*      */   
/*      */   public static int fromFourCC(String str) {
/*  130 */     byte[] strBytes = str.getBytes();
/*  131 */     if (strBytes.length != 4) {
/*  132 */       throw new IllegalArgumentException("Expected 4 bytes not " + strBytes.length);
/*      */     }
/*  134 */     int fourCCInt = strBytes[3];
/*  135 */     fourCCInt = (fourCCInt <<= 8) | strBytes[2];
/*  136 */     fourCCInt = (fourCCInt <<= 8) | strBytes[1];
/*  137 */     fourCCInt = (fourCCInt <<= 8) | strBytes[0];
/*      */     
/*  139 */     return fourCCInt;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static String toFourCC(int fourcc) {
/*  148 */     StringBuilder sb = new StringBuilder();
/*  149 */     for (int i = 0; i < 4; i++) {
/*  150 */       int c = fourcc & 0xFF;
/*  151 */       sb.append(Character.toString((char)c));
/*  152 */       fourcc >>= 8;
/*      */     } 
/*  154 */     return sb.toString();
/*      */   }
/*      */   
/*      */   public long getFileLeft() throws IOException {
/*  158 */     return this.fileLeft;
/*      */   }
/*      */   
/*      */   public List<AVITag_AviIndex> getAviIndexes() {
/*  162 */     return this.aviIndexes;
/*      */   }
/*      */   
/*      */   public void parse() throws IOException {
/*      */     try {
/*  167 */       long t1 = System.currentTimeMillis();
/*      */       
/*  169 */       long fileSize = this.raf.size();
/*  170 */       this.fileLeft = fileSize;
/*      */       
/*  172 */       int numStreams = 0;
/*  173 */       int streamIndex = -1;
/*  174 */       int videoFrameNo = 1;
/*      */ 
/*      */ 
/*      */       
/*  178 */       int dwFourCC = this.raf.readInt();
/*  179 */       if (dwFourCC != 1179011410) {
/*  180 */         throw new FormatException("No RIFF header found");
/*      */       }
/*  182 */       AVIChunk aviItem = new AVIList();
/*  183 */       aviItem.read(dwFourCC, this.raf);
/*  184 */       Logger.debug(aviItem.toString());
/*      */       
/*  186 */       int previousStreamType = 0;
/*      */       do {
/*  188 */         dwFourCC = this.raf.readInt();
/*  189 */         String dwFourCCStr = toFourCC(dwFourCC);
/*      */         
/*  191 */         switch (dwFourCC) {
/*      */           case 1179011410:
/*  193 */             aviItem = new AVIList();
/*  194 */             aviItem.read(dwFourCC, this.raf);
/*      */             break;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */           
/*      */           case 1414744396:
/*  204 */             aviItem = new AVIList();
/*  205 */             aviItem.read(dwFourCC, this.raf);
/*      */             
/*  207 */             if (((AVIList)aviItem).getListType() == 1769369453)
/*      */             {
/*  209 */               aviItem.skip(this.raf);
/*      */             }
/*      */             break;
/*      */ 
/*      */           
/*      */           case 1819440243:
/*  215 */             aviItem = new AVIList();
/*  216 */             aviItem.read(dwFourCC, this.raf);
/*      */             break;
/*      */ 
/*      */           
/*      */           case 1751742049:
/*  221 */             aviItem = this.aviHeader = new AVITag_AVIH();
/*  222 */             aviItem.read(dwFourCC, this.raf);
/*      */             
/*  224 */             numStreams = this.aviHeader.getStreams();
/*      */             
/*  226 */             this.streamHeaders = new AVITag_STRH[numStreams];
/*  227 */             this.streamFormats = new AVIChunk[numStreams];
/*  228 */             this.openDmlSuperIndex = new AVITag_AviDmlSuperIndex[numStreams];
/*      */             break;
/*      */ 
/*      */           
/*      */           case 1752331379:
/*  233 */             if (streamIndex >= numStreams) {
/*  234 */               throw new IllegalStateException("Read more stream headers than expected, expected [" + numStreams + "]");
/*      */             }
/*      */ 
/*      */             
/*  238 */             streamIndex++;
/*      */             
/*  240 */             aviItem = this.streamHeaders[streamIndex] = new AVITag_STRH();
/*  241 */             aviItem.read(dwFourCC, this.raf);
/*  242 */             previousStreamType = ((AVITag_STRH)aviItem).getType();
/*      */             break;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */           
/*      */           case 1718776947:
/*  250 */             switch (previousStreamType) {
/*      */               case 1935960438:
/*  252 */                 aviItem = this.streamFormats[streamIndex] = new AVITag_BitmapInfoHeader();
/*  253 */                 aviItem.read(dwFourCC, this.raf);
/*      */                 break;
/*      */ 
/*      */               
/*      */               case 1935963489:
/*  258 */                 aviItem = this.streamFormats[streamIndex] = new AVITag_WaveFormatEx();
/*  259 */                 aviItem.read(dwFourCC, this.raf);
/*      */                 break;
/*      */             } 
/*      */ 
/*      */             
/*  264 */             throw new IOException("Expected vids or auds got [" + toFourCC(previousStreamType) + "]");
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */           
/*      */           case 1835492723:
/*  271 */             aviItem = new AVI_SEGM();
/*  272 */             aviItem.read(dwFourCC, this.raf);
/*      */             
/*  274 */             aviItem.skip(this.raf);
/*      */             break;
/*      */ 
/*      */ 
/*      */           
/*      */           case 829973609:
/*  280 */             aviItem = new AVITag_AviIndex();
/*  281 */             aviItem.read(dwFourCC, this.raf);
/*      */             
/*  283 */             this.aviIndexes.add((AVITag_AviIndex)aviItem);
/*      */             break;
/*      */ 
/*      */ 
/*      */ 
/*      */           
/*      */           case 2019847785:
/*  290 */             this.openDmlSuperIndex[streamIndex] = new AVITag_AviDmlSuperIndex();
/*  291 */             this.openDmlSuperIndex[streamIndex].read(dwFourCC, this.raf);
/*      */             
/*  293 */             aviItem = this.openDmlSuperIndex[streamIndex];
/*      */             break;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */           
/*      */           default:
/*  301 */             if (dwFourCCStr.endsWith("db")) {
/*      */               
/*  303 */               aviItem = new AVITag_VideoChunk(false, this.raf);
/*  304 */               aviItem.read(dwFourCC, this.raf);
/*      */               
/*  306 */               if (this.skipFrames) {
/*  307 */                 aviItem.skip(this.raf); break;
/*      */               } 
/*  309 */               byte[] videoFrameData = ((AVITag_VideoChunk)aviItem).getVideoPacket();
/*  310 */               ByteBuffer byteBuffer = ByteBuffer.wrap(videoFrameData);
/*      */               
/*      */               break;
/*      */             } 
/*  314 */             if (dwFourCCStr.endsWith("dc")) {
/*      */               
/*  316 */               aviItem = new AVITag_VideoChunk(true, this.raf);
/*  317 */               aviItem.read(dwFourCC, this.raf);
/*      */               
/*  319 */               ((AVITag_VideoChunk)aviItem).setFrameNo(videoFrameNo);
/*  320 */               videoFrameNo++;
/*      */               
/*  322 */               String fourccStr = toFourCC(dwFourCC);
/*  323 */               int streamNo = Integer.parseInt(fourccStr.substring(0, 2));
/*      */               
/*  325 */               if (this.skipFrames) {
/*  326 */                 aviItem.skip(this.raf); break;
/*      */               } 
/*  328 */               byte[] videoFrameData = ((AVITag_VideoChunk)aviItem).getVideoPacket();
/*  329 */               ByteBuffer byteBuffer = ByteBuffer.wrap(videoFrameData);
/*      */ 
/*      */               
/*      */               break;
/*      */             } 
/*      */             
/*  335 */             if (dwFourCCStr.endsWith("wb")) {
/*      */               
/*  337 */               aviItem = new AVITag_AudioChunk();
/*  338 */               aviItem.read(dwFourCC, this.raf);
/*  339 */               aviItem.skip(this.raf); break;
/*  340 */             }  if (dwFourCCStr.endsWith("tx")) {
/*      */               
/*  342 */               aviItem = new AVIChunk();
/*  343 */               aviItem.read(dwFourCC, this.raf);
/*  344 */               aviItem.skip(this.raf); break;
/*  345 */             }  if (dwFourCCStr.startsWith("ix")) {
/*      */               
/*  347 */               aviItem = new AVITag_AviDmlStandardIndex();
/*  348 */               aviItem.read(dwFourCC, this.raf);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */               
/*      */               break;
/*      */             } 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */             
/*  361 */             aviItem = new AVIChunk();
/*  362 */             aviItem.read(dwFourCC, this.raf);
/*  363 */             aviItem.skip(this.raf);
/*      */             break;
/*      */         } 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*  370 */         Logger.debug(aviItem.toString());
/*      */         
/*  372 */         this.fileLeft = fileSize - this.raf.position();
/*      */       }
/*  374 */       while (this.fileLeft > 0L);
/*      */       
/*  376 */       long t2 = System.currentTimeMillis();
/*      */       
/*  378 */       Logger.debug("\tFile Left [" + this.fileLeft + "]");
/*  379 */       Logger.debug("\tParse time : " + (t2 - t1) + "ms");
/*      */     } finally {
/*      */       
/*  382 */       if (this.ps != null) {
/*  383 */         this.ps.close();
/*      */       }
/*      */     } 
/*      */   }
/*      */ 
/*      */   
/*      */   static class AVIChunk
/*      */   {
/*      */     protected int dwFourCC;
/*      */     
/*      */     protected String fwFourCCStr;
/*      */     protected int dwChunkSize;
/*      */     protected long startOfChunk;
/*      */     
/*      */     public void read(int dwFourCC, DataReader raf) throws IOException {
/*  398 */       this.startOfChunk = raf.position() - 4L;
/*      */ 
/*      */ 
/*      */       
/*  402 */       this.dwFourCC = dwFourCC;
/*  403 */       this.fwFourCCStr = AVIReader.toFourCC(dwFourCC);
/*  404 */       this.dwChunkSize = raf.readInt();
/*      */     }
/*      */     
/*      */     public long getStartOfChunk() {
/*  408 */       return this.startOfChunk;
/*      */     }
/*      */     
/*      */     public long getEndOfChunk() {
/*  412 */       return this.startOfChunk + 8L + getChunkSize();
/*      */     }
/*      */ 
/*      */     
/*      */     public int getFourCC() {
/*  417 */       return this.dwFourCC;
/*      */     }
/*      */     
/*      */     public void skip(DataReader raf) throws IOException {
/*  421 */       int chunkSize = getChunkSize();
/*  422 */       if (chunkSize < 0) {
/*  423 */         throw new IOException("Negative chunk size for chunk [" + AVIReader.toFourCC(this.dwFourCC) + "]");
/*      */       }
/*  425 */       raf.skipBytes(chunkSize);
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public int getChunkSize() {
/*  433 */       if ((this.dwChunkSize & 0x1) == 1) {
/*  434 */         return this.dwChunkSize + 1;
/*      */       }
/*  436 */       return this.dwChunkSize;
/*      */     }
/*      */ 
/*      */ 
/*      */     
/*      */     public String toString() {
/*  442 */       String chunkStr = AVIReader.toFourCC(this.dwFourCC);
/*  443 */       if (chunkStr.trim().length() == 0) {
/*  444 */         chunkStr = Integer.toHexString(this.dwFourCC);
/*      */       }
/*      */       
/*  447 */       return "\tCHUNK [" + chunkStr + "], Size [" + this.dwChunkSize + "], StartOfChunk [" + getStartOfChunk() + "]";
/*      */     }
/*      */   }
/*      */ 
/*      */   
/*      */   static class AVIList
/*      */     extends AVIChunk
/*      */   {
/*      */     protected int dwListTypeFourCC;
/*      */     
/*      */     protected String dwListTypeFourCCStr;
/*      */     
/*      */     public void read(int dwFourCC, DataReader raf) throws IOException {
/*  460 */       super.read(dwFourCC, raf);
/*      */       
/*  462 */       this.dwChunkSize -= 4;
/*      */       
/*  464 */       this.dwListTypeFourCC = raf.readInt();
/*  465 */       this.dwListTypeFourCCStr = AVIReader.toFourCC(this.dwListTypeFourCC);
/*      */     }
/*      */     
/*      */     public int getListType() {
/*  469 */       return this.dwListTypeFourCC;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public String toString() {
/*  480 */       String dwFourCCStr = AVIReader.toFourCC(this.dwFourCC);
/*      */       
/*  482 */       return dwFourCCStr + " [" + this.dwListTypeFourCCStr + "], Size [" + this.dwChunkSize + "], StartOfChunk [" + 
/*  483 */         getStartOfChunk() + "]";
/*      */     }
/*      */   }
/*      */   
/*      */   static class AVI_SEGM
/*      */     extends AVIChunk {
/*      */     public void read(int dwFourCC, DataReader raf) throws IOException {
/*  490 */       super.read(dwFourCC, raf);
/*      */     }
/*      */ 
/*      */ 
/*      */     
/*      */     public int getChunkSize() {
/*  496 */       if (this.dwChunkSize == 0) {
/*  497 */         return 0;
/*      */       }
/*  499 */       return this.dwChunkSize + 1;
/*      */     }
/*      */ 
/*      */ 
/*      */     
/*      */     public String toString() {
/*  505 */       return "SEGMENT Align, Size [" + this.dwChunkSize + "], StartOfChunk [" + getStartOfChunk() + "]";
/*      */     }
/*      */   }
/*      */ 
/*      */   
/*      */   static class AVITag_AVIH
/*      */     extends AVIChunk
/*      */   {
/*      */     public String _getHeight;
/*      */     
/*      */     static final int AVIF_HASINDEX = 16;
/*      */     
/*      */     static final int AVIF_MUSTUSEINDEX = 32;
/*      */     
/*      */     static final int AVIF_ISINTERLEAVED = 256;
/*      */     
/*      */     static final int AVIF_TRUSTCKTYPE = 2048;
/*      */     
/*      */     static final int AVIF_WASCAPTUREFILE = 65536;
/*      */     static final int AVIF_COPYRIGHTED = 131072;
/*      */     private int dwMicroSecPerFrame;
/*      */     private int dwMaxBytesPerSec;
/*      */     private int dwPaddingGranularity;
/*      */     private int dwFlags;
/*      */     private int dwTotalFrames;
/*      */     private int dwInitialFrames;
/*      */     private int dwStreams;
/*      */     private int dwSuggestedBufferSize;
/*      */     private int dwWidth;
/*      */     private int dwHeight;
/*  535 */     private int[] dwReserved = new int[4];
/*      */ 
/*      */ 
/*      */     
/*      */     public void read(int dwFourCC, DataReader raf) throws IOException {
/*  540 */       super.read(dwFourCC, raf);
/*  541 */       if (dwFourCC != 1751742049) {
/*  542 */         throw new IOException("Unexpected AVI header : " + AVIReader.toFourCC(dwFourCC));
/*      */       }
/*  544 */       if (getChunkSize() != 56) {
/*  545 */         throw new IOException("Expected dwSize=56");
/*      */       }
/*  547 */       this.dwMicroSecPerFrame = raf.readInt();
/*  548 */       this.dwMaxBytesPerSec = raf.readInt();
/*  549 */       this.dwPaddingGranularity = raf.readInt();
/*  550 */       this.dwFlags = raf.readInt();
/*  551 */       this.dwTotalFrames = raf.readInt();
/*  552 */       this.dwInitialFrames = raf.readInt();
/*  553 */       this.dwStreams = raf.readInt();
/*  554 */       this.dwSuggestedBufferSize = raf.readInt();
/*  555 */       this.dwWidth = raf.readInt();
/*  556 */       this.dwHeight = raf.readInt();
/*  557 */       this.dwReserved[0] = raf.readInt();
/*  558 */       this.dwReserved[1] = raf.readInt();
/*  559 */       this.dwReserved[2] = raf.readInt();
/*  560 */       this.dwReserved[3] = raf.readInt();
/*      */     }
/*      */     
/*      */     public int getWidth() {
/*  564 */       return this.dwWidth;
/*      */     }
/*      */     
/*      */     public int getHeight() {
/*  568 */       return this.dwHeight;
/*      */     }
/*      */     
/*      */     public int getStreams() {
/*  572 */       return this.dwStreams;
/*      */     }
/*      */     
/*      */     public int getTotalFrames() {
/*  576 */       return this.dwTotalFrames;
/*      */     }
/*      */ 
/*      */     
/*      */     public String toString() {
/*  581 */       StringBuilder sb = new StringBuilder();
/*      */       
/*  583 */       if ((this.dwFlags & 0x10) != 0)
/*  584 */         sb.append("HASINDEX "); 
/*  585 */       if ((this.dwFlags & 0x20) != 0)
/*  586 */         sb.append("MUSTUSEINDEX "); 
/*  587 */       if ((this.dwFlags & 0x100) != 0)
/*  588 */         sb.append("ISINTERLEAVED "); 
/*  589 */       if ((this.dwFlags & 0x10000) != 0)
/*  590 */         sb.append("AVIF_WASCAPTUREFILE "); 
/*  591 */       if ((this.dwFlags & 0x20000) != 0) {
/*  592 */         sb.append("AVIF_COPYRIGHTED ");
/*      */       }
/*  594 */       return "AVIH Resolution [" + this.dwWidth + "x" + this.dwHeight + "], NumFrames [" + this.dwTotalFrames + "], Flags [" + 
/*  595 */         Integer.toHexString(this.dwFlags) + "] - [" + sb.toString().trim() + "]";
/*      */     }
/*      */   }
/*      */ 
/*      */   
/*      */   static class AVITag_STRH
/*      */     extends AVIChunk
/*      */   {
/*      */     static final int AVISF_DISABLED = 1;
/*      */     static final int AVISF_VIDEO_PALCHANGES = 65536;
/*      */     private int fccType;
/*      */     private int fccCodecHandler;
/*  607 */     private int dwFlags = 0;
/*  608 */     private short wPriority = 0;
/*  609 */     private short wLanguage = 0;
/*  610 */     private int dwInitialFrames = 0;
/*  611 */     private int dwScale = 0;
/*  612 */     private int dwRate = 1000000;
/*  613 */     private int dwStart = 0;
/*  614 */     private int dwLength = 0;
/*  615 */     private int dwSuggestedBufferSize = 0;
/*  616 */     private int dwQuality = -1;
/*  617 */     private int dwSampleSize = 0;
/*  618 */     private short left = 0;
/*  619 */     private short top = 0;
/*  620 */     private short right = 0;
/*  621 */     private short bottom = 0;
/*      */ 
/*      */     
/*      */     public void read(int dwFourCC, DataReader raf) throws IOException {
/*  625 */       super.read(dwFourCC, raf);
/*  626 */       if (dwFourCC != 1752331379) {
/*  627 */         throw new IOException("Expected 'strh' fourcc got [" + AVIReader.toFourCC(this.dwFourCC) + "]");
/*      */       }
/*  629 */       this.fccType = raf.readInt();
/*      */       
/*  631 */       this.fccCodecHandler = raf.readInt();
/*  632 */       this.dwFlags = raf.readInt();
/*      */       
/*  634 */       this.wPriority = raf.readShort();
/*  635 */       this.wLanguage = raf.readShort();
/*      */       
/*  637 */       this.dwInitialFrames = raf.readInt();
/*  638 */       this.dwScale = raf.readInt();
/*  639 */       this.dwRate = raf.readInt();
/*  640 */       this.dwStart = raf.readInt();
/*  641 */       this.dwLength = raf.readInt();
/*  642 */       this.dwSuggestedBufferSize = raf.readInt();
/*  643 */       this.dwQuality = raf.readInt();
/*  644 */       this.dwSampleSize = raf.readInt();
/*      */       
/*  646 */       this.left = raf.readShort();
/*  647 */       this.top = raf.readShort();
/*  648 */       this.right = raf.readShort();
/*  649 */       this.bottom = raf.readShort();
/*      */     }
/*      */     
/*      */     public int getType() {
/*  653 */       return this.fccType;
/*      */     }
/*      */     
/*      */     public int getHandler() {
/*  657 */       return this.fccCodecHandler;
/*      */     }
/*      */     
/*      */     public String getHandlerStr() {
/*  661 */       if (this.fccCodecHandler != 0) {
/*  662 */         return AVIReader.toFourCC(this.fccCodecHandler);
/*      */       }
/*  664 */       return "";
/*      */     }
/*      */     
/*      */     public int getInitialFrames() {
/*  668 */       return this.dwInitialFrames;
/*      */     }
/*      */ 
/*      */     
/*      */     public String toString() {
/*  673 */       return "\tCHUNK [" + AVIReader.toFourCC(this.dwFourCC) + "], Type[" + ((this.fccType > 0) ? AVIReader.toFourCC(this.fccType) : "    ") + "], Handler [" + ((this.fccCodecHandler > 0) ? 
/*  674 */         AVIReader.toFourCC(this.fccCodecHandler) : "    ") + "]";
/*      */     }
/*      */   }
/*      */ 
/*      */   
/*      */   static class AVITag_BitmapInfoHeader
/*      */     extends AVIChunk
/*      */   {
/*      */     private int biSize;
/*      */     
/*      */     private int biWidth;
/*      */     
/*      */     private int biHeight;
/*      */     
/*      */     private short biPlanes;
/*      */     
/*      */     private short biBitCount;
/*      */     
/*      */     private int biCompression;
/*      */     
/*      */     private int biSizeImage;
/*      */     private int biXPelsPerMeter;
/*      */     private int biYPelsPerMeter;
/*      */     private int biClrUsed;
/*      */     private int biClrImportant;
/*      */     private byte r;
/*      */     private byte g;
/*      */     private byte b;
/*      */     private byte x;
/*      */     
/*      */     public void read(int dwFourCC, DataReader raf) throws IOException {
/*  705 */       super.read(dwFourCC, raf);
/*      */       
/*  707 */       this.biSize = raf.readInt();
/*  708 */       this.biWidth = raf.readInt();
/*  709 */       this.biHeight = raf.readInt();
/*  710 */       this.biPlanes = raf.readShort();
/*  711 */       this.biBitCount = raf.readShort();
/*  712 */       this.biCompression = raf.readInt();
/*  713 */       this.biSizeImage = raf.readInt();
/*  714 */       this.biXPelsPerMeter = raf.readInt();
/*  715 */       this.biYPelsPerMeter = raf.readInt();
/*  716 */       this.biClrUsed = raf.readInt();
/*  717 */       this.biClrImportant = raf.readInt();
/*      */       
/*  719 */       if (getChunkSize() == 56) {
/*      */ 
/*      */ 
/*      */         
/*  723 */         this.r = raf.readByte();
/*  724 */         this.g = raf.readByte();
/*  725 */         this.b = raf.readByte();
/*  726 */         this.x = raf.readByte();
/*      */       } 
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public int getChunkSize() {
/*  740 */       return this.biSize;
/*      */     }
/*      */ 
/*      */     
/*      */     public String toString() {
/*  745 */       return "\tCHUNK [" + AVIReader.toFourCC(this.dwFourCC) + "], BitsPerPixel [" + this.biBitCount + "], Resolution [" + (this.biWidth & 0xFFFFFFFFL) + " x " + (this.biHeight & 0xFFFFFFFFL) + "], Planes [" + this.biPlanes + "]";
/*      */     }
/*      */   }
/*      */ 
/*      */   
/*      */   static class AVITag_WaveFormatEx
/*      */     extends AVIChunk
/*      */   {
/*      */     public static final int SPEAKER_FRONT_LEFT = 1;
/*      */     
/*      */     public static final int SPEAKER_FRONT_RIGHT = 2;
/*      */     
/*      */     public static final int SPEAKER_FRONT_CENTER = 4;
/*      */     
/*      */     public static final int SPEAKER_LOW_FREQUENCY = 8;
/*      */     
/*      */     public static final int SPEAKER_BACK_LEFT = 16;
/*      */     
/*      */     public static final int SPEAKER_BACK_RIGHT = 32;
/*      */     
/*      */     public static final int SPEAKER_FRONT_LEFT_OF_CENTER = 64;
/*      */     
/*      */     public static final int SPEAKER_FRONT_RIGHT_OF_CENTER = 128;
/*      */     
/*      */     public static final int SPEAKER_BACK_CENTER = 256;
/*      */     
/*      */     public static final int SPEAKER_SIDE_LEFT = 512;
/*      */     
/*      */     public static final int SPEAKER_SIDE_RIGHT = 1024;
/*      */     
/*      */     public static final int SPEAKER_TOP_CENTER = 2048;
/*      */     
/*      */     public static final int SPEAKER_TOP_FRONT_LEFT = 4096;
/*      */     
/*      */     public static final int SPEAKER_TOP_FRONT_CENTER = 8192;
/*      */     
/*      */     public static final int SPEAKER_TOP_FRONT_RIGHT = 16384;
/*      */     
/*      */     public static final int SPEAKER_TOP_BACK_LEFT = 32768;
/*      */     
/*      */     public static final int SPEAKER_TOP_BACK_CENTER = 65536;
/*      */     
/*      */     public static final int SPEAKER_TOP_BACK_RIGHT = 131072;
/*      */     
/*      */     protected short wFormatTag;
/*      */     
/*      */     protected short channels;
/*      */     
/*      */     protected int nSamplesPerSec;
/*      */     
/*      */     protected int nAvgBytesPerSec;
/*      */     
/*      */     protected short nBlockAlign;
/*      */     
/*      */     protected short wBitsPerSample;
/*      */     
/*      */     protected short cbSize;
/*      */     
/*      */     protected short wValidBitsPerSample;
/*      */     
/*      */     protected short samplesValidBitsPerSample;
/*      */     
/*      */     protected short wReserved;
/*      */     
/*      */     protected int channelMask;
/*      */     
/*      */     protected int guid_data1;
/*      */     
/*      */     protected short guid_data2;
/*      */     protected short guid_data3;
/*      */     protected byte[] guid_data4;
/*      */     protected boolean mp3Flag = false;
/*      */     protected short wID;
/*      */     protected int fdwFlags;
/*      */     protected short nBlockSize;
/*      */     protected short nFramesPerBlock;
/*      */     protected short nCodecDelay;
/*  822 */     private String audioFormat = "?";
/*      */     
/*      */     public AVITag_WaveFormatEx() {
/*  825 */       this.guid_data4 = new byte[8];
/*      */     }
/*      */ 
/*      */     
/*      */     public void read(int dwFourCC, DataReader raf) throws IOException {
/*  830 */       super.read(dwFourCC, raf);
/*      */ 
/*      */       
/*  833 */       this.wFormatTag = raf.readShort();
/*  834 */       this.channels = raf.readShort();
/*  835 */       this.nSamplesPerSec = raf.readInt();
/*  836 */       this.nAvgBytesPerSec = raf.readInt();
/*  837 */       this.nBlockAlign = raf.readShort();
/*      */       
/*  839 */       switch (this.wFormatTag) {
/*      */ 
/*      */         
/*      */         case 1:
/*  843 */           this.wBitsPerSample = raf.readShort();
/*      */           
/*  845 */           if (this.dwChunkSize == 40) {
/*      */             
/*  847 */             this.wValidBitsPerSample = this.samplesValidBitsPerSample = this.wReserved = raf.readShort();
/*  848 */             this.cbSize = raf.readShort();
/*      */             
/*  850 */             this.channelMask = raf.readInt();
/*      */ 
/*      */             
/*  853 */             this.guid_data1 = raf.readInt();
/*  854 */             this.guid_data2 = raf.readShort();
/*  855 */             this.guid_data3 = raf.readShort();
/*  856 */             raf.readFully(this.guid_data4);
/*      */           } 
/*  858 */           this.audioFormat = "PCM";
/*      */           return;
/*      */ 
/*      */ 
/*      */         
/*      */         case 85:
/*  864 */           this.wBitsPerSample = raf.readShort();
/*  865 */           this.cbSize = raf.readShort();
/*      */           
/*  867 */           this.wID = raf.readShort();
/*  868 */           this.fdwFlags = raf.readInt();
/*  869 */           this.nBlockSize = raf.readShort();
/*  870 */           this.nFramesPerBlock = raf.readShort();
/*  871 */           this.nCodecDelay = raf.readShort();
/*      */           
/*  873 */           this.mp3Flag = true;
/*  874 */           this.audioFormat = "MP3";
/*      */           return;
/*      */ 
/*      */         
/*      */         case 8192:
/*  879 */           this.audioFormat = "AC3";
/*      */           return;
/*      */ 
/*      */         
/*      */         case 8193:
/*  884 */           this.audioFormat = "DTS";
/*      */           return;
/*      */ 
/*      */         
/*      */         case 22127:
/*  889 */           this.audioFormat = "VORBIS";
/*      */           return;
/*      */ 
/*      */ 
/*      */         
/*      */         case 65534:
/*  895 */           this.wBitsPerSample = raf.readShort();
/*  896 */           this.cbSize = raf.readShort();
/*      */ 
/*      */ 
/*      */ 
/*      */           
/*  901 */           this.wValidBitsPerSample = this.samplesValidBitsPerSample = this.wReserved = raf.readShort();
/*      */           
/*  903 */           this.channelMask = raf.readInt();
/*      */ 
/*      */           
/*  906 */           this.guid_data1 = raf.readInt();
/*  907 */           this.guid_data2 = raf.readShort();
/*  908 */           this.guid_data3 = raf.readShort();
/*  909 */           raf.readFully(this.guid_data4);
/*      */           
/*  911 */           this.audioFormat = "EXTENSIBLE";
/*      */           return;
/*      */       } 
/*      */ 
/*      */       
/*  916 */       this.audioFormat = "Unknown : " + Integer.toHexString(this.wFormatTag);
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public boolean isMP3() {
/*  924 */       return this.mp3Flag;
/*      */     }
/*      */     
/*      */     public short getCbSize() {
/*  928 */       return this.cbSize;
/*      */     }
/*      */ 
/*      */     
/*      */     public String toString() {
/*  933 */       return String.format("\tCHUNK [%s], ChunkSize [%d], Format [%s], Channels [%d], Channel Mask [%s], MP3 [%b], SamplesPerSec [%d], nBlockAlign [%d]", new Object[] {
/*      */             
/*  935 */             AVIReader.toFourCC(this.dwFourCC), Integer.valueOf(getChunkSize()), this.audioFormat, Short.valueOf(this.channels), Integer.toHexString(this.channelMask), 
/*  936 */             Boolean.valueOf(this.mp3Flag), Integer.valueOf(this.nSamplesPerSec), Long.valueOf(getStartOfChunk()), Short.valueOf(this.nBlockAlign)
/*      */           });
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   static class AVITag_VideoChunk
/*      */     extends AVIChunk
/*      */   {
/*      */     protected int streamNo;
/*      */ 
/*      */     
/*      */     protected boolean compressed = false;
/*      */ 
/*      */     
/*  952 */     protected int frameNo = -1;
/*      */     
/*      */     private DataReader raf;
/*      */ 
/*      */     
/*      */     public AVITag_VideoChunk(boolean compressed, DataReader raf) {
/*  958 */       this.compressed = compressed;
/*  959 */       this.raf = raf;
/*      */     }
/*      */     
/*      */     public int getStreamNo() {
/*  963 */       return this.streamNo;
/*      */     }
/*      */     
/*      */     public void setFrameNo(int frameNo) {
/*  967 */       this.frameNo = frameNo;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public int getChunkSize() {
/*  976 */       if ((this.dwChunkSize & 0x1) == 1) {
/*  977 */         return this.dwChunkSize + 1;
/*      */       }
/*  979 */       return this.dwChunkSize;
/*      */     }
/*      */ 
/*      */     
/*      */     public void read(int dwFourCC, DataReader raf) throws IOException {
/*  984 */       super.read(dwFourCC, raf);
/*      */       
/*  986 */       String fourccStr = AVIReader.toFourCC(dwFourCC);
/*  987 */       this.streamNo = Integer.parseInt(fourccStr.substring(0, 2));
/*      */     }
/*      */     
/*      */     public byte[] getVideoPacket() throws IOException {
/*  991 */       byte[] videoFrameData = new byte[this.dwChunkSize];
/*      */       
/*  993 */       int bytesRead = this.raf.readFully(videoFrameData);
/*  994 */       if (bytesRead != this.dwChunkSize) {
/*  995 */         throw new IOException("Read mismatch expected chunksize [" + this.dwChunkSize + "], Actual read [" + bytesRead + "]");
/*      */       }
/*      */       
/*  998 */       int alignment = getChunkSize() - this.dwChunkSize;
/*  999 */       if (alignment > 0) {
/* 1000 */         this.raf.skipBytes(alignment);
/*      */       }
/* 1002 */       return videoFrameData;
/*      */     }
/*      */ 
/*      */ 
/*      */     
/*      */     public String toString() {
/* 1008 */       return "\tVIDEO CHUNK - Stream " + this.streamNo + ",  chunkStart=" + getStartOfChunk() + ", " + (this.compressed ? "compressed" : "uncompressed") + ", ChunkSize=" + 
/* 1009 */         getChunkSize() + ", FrameNo=" + this.frameNo;
/*      */     }
/*      */   }
/*      */   
/*      */   static class AVITag_AudioChunk
/*      */     extends AVIChunk
/*      */   {
/*      */     protected int streamNo;
/*      */     private DataReader raf;
/*      */     
/*      */     public void read(int dwFourCC, DataReader raf) throws IOException {
/* 1020 */       this.raf = raf;
/* 1021 */       super.read(dwFourCC, raf);
/*      */       
/* 1023 */       String fourccStr = AVIReader.toFourCC(dwFourCC);
/* 1024 */       this.streamNo = Integer.parseInt(fourccStr.substring(0, 2));
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public int getChunkSize() {
/* 1033 */       if ((this.dwChunkSize & 0x1) == 1) {
/* 1034 */         return this.dwChunkSize + 1;
/*      */       }
/* 1036 */       return this.dwChunkSize;
/*      */     }
/*      */     
/*      */     public byte[] getAudioPacket() throws IOException {
/* 1040 */       byte[] audioFrameData = new byte[this.dwChunkSize];
/*      */       
/* 1042 */       int bytesRead = this.raf.readFully(audioFrameData);
/* 1043 */       if (bytesRead != this.dwChunkSize) {
/* 1044 */         throw new IOException("Read mismatch expected chunksize [" + this.dwChunkSize + "], Actual read [" + bytesRead + "]");
/*      */       }
/*      */       
/* 1047 */       int alignment = getChunkSize() - this.dwChunkSize;
/* 1048 */       if (alignment > 0) {
/* 1049 */         this.raf.skipBytes(alignment);
/*      */       }
/* 1051 */       return audioFrameData;
/*      */     }
/*      */ 
/*      */     
/*      */     public String toString() {
/* 1056 */       return "\tAUDIO CHUNK - Stream " + this.streamNo + ", StartOfChunk=" + getStartOfChunk() + ", ChunkSize=" + 
/* 1057 */         getChunkSize();
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   static class AVITag_AviIndex
/*      */     extends AVIChunk
/*      */   {
/* 1072 */     protected int numIndexes = 0;
/*      */     
/*      */     protected int[] ckid;
/*      */     protected int[] dwFlags;
/*      */     protected int[] dwChunkOffset;
/*      */     protected int[] dwChunkLength;
/*      */     
/*      */     public void read(int dwFourCC, DataReader raf) throws IOException {
/* 1080 */       super.read(dwFourCC, raf);
/*      */       
/* 1082 */       this.numIndexes = getChunkSize() >> 4;
/*      */       
/* 1084 */       this.ckid = new int[this.numIndexes];
/* 1085 */       this.dwFlags = new int[this.numIndexes];
/* 1086 */       this.dwChunkOffset = new int[this.numIndexes];
/* 1087 */       this.dwChunkLength = new int[this.numIndexes];
/*      */       
/* 1089 */       for (int i = 0; i < this.numIndexes; i++) {
/* 1090 */         this.ckid[i] = raf.readInt();
/* 1091 */         this.dwFlags[i] = raf.readInt();
/* 1092 */         this.dwChunkOffset[i] = raf.readInt();
/* 1093 */         this.dwChunkLength[i] = raf.readInt();
/*      */       } 
/*      */       
/* 1096 */       raf.setPosition(getEndOfChunk());
/*      */       
/* 1098 */       int alignment = getChunkSize() - this.dwChunkSize;
/* 1099 */       if (alignment > 0)
/* 1100 */         raf.skipBytes(alignment); 
/*      */     }
/*      */     
/*      */     public int getNumIndexes() {
/* 1104 */       return this.numIndexes;
/*      */     }
/*      */     
/*      */     public int[] getCkid() {
/* 1108 */       return this.ckid;
/*      */     }
/*      */     
/*      */     public int[] getDwFlags() {
/* 1112 */       return this.dwFlags;
/*      */     }
/*      */     
/*      */     public int[] getDwChunkOffset() {
/* 1116 */       return this.dwChunkOffset;
/*      */     }
/*      */     
/*      */     public int[] getDwChunkLength() {
/* 1120 */       return this.dwChunkLength;
/*      */     }
/*      */     
/*      */     public void debugOut() {
/* 1124 */       for (int i = 0; i < this.numIndexes; i++) {
/* 1125 */         Logger.debug("\t");
/*      */       }
/*      */     }
/*      */ 
/*      */ 
/*      */     
/*      */     public String toString() {
/* 1132 */       return String.format("\tAvi Index List, StartOfChunk [%d], ChunkSize [%d], NumIndexes [%d]", new Object[] {
/* 1133 */             Long.valueOf(getStartOfChunk()), Integer.valueOf(this.dwChunkSize), Integer.valueOf(getChunkSize() >> 4)
/*      */           });
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   static class AVITag_AviDmlSuperIndex
/*      */     extends AVIChunk
/*      */   {
/*      */     protected short wLongsPerEntry;
/*      */ 
/*      */     
/*      */     protected byte bIndexSubType;
/*      */ 
/*      */     
/*      */     protected byte bIndexType;
/*      */     
/*      */     protected int nEntriesInUse;
/*      */     
/*      */     protected int dwChunkId;
/*      */     
/*      */     protected int[] dwReserved;
/*      */     
/*      */     protected long[] qwOffset;
/*      */     
/*      */     protected int[] dwSize;
/*      */     
/*      */     protected int[] dwDuration;
/*      */     
/*      */     private int numIndex;
/*      */     
/*      */     private int numIndexFill;
/*      */     
/*      */     StringBuilder sb;
/*      */     
/* 1169 */     private int streamNo = 0;
/*      */ 
/*      */     
/*      */     public AVITag_AviDmlSuperIndex() {
/* 1173 */       this.dwReserved = new int[3];
/* 1174 */       this.sb = new StringBuilder();
/*      */     }
/*      */ 
/*      */ 
/*      */     
/*      */     public void read(int dwFourCC, DataReader raf) throws IOException {
/* 1180 */       super.read(dwFourCC, raf);
/*      */       
/* 1182 */       this.wLongsPerEntry = raf.readShort();
/* 1183 */       this.bIndexSubType = raf.readByte();
/* 1184 */       this.bIndexType = raf.readByte();
/* 1185 */       this.nEntriesInUse = raf.readInt();
/* 1186 */       this.dwChunkId = raf.readInt();
/*      */       
/* 1188 */       this.dwReserved[0] = raf.readInt();
/* 1189 */       this.dwReserved[1] = raf.readInt();
/* 1190 */       this.dwReserved[2] = raf.readInt();
/*      */       
/* 1192 */       this.qwOffset = new long[this.nEntriesInUse];
/* 1193 */       this.dwSize = new int[this.nEntriesInUse];
/* 1194 */       this.dwDuration = new int[this.nEntriesInUse];
/*      */       
/* 1196 */       String chunkIdStr = AVIReader.toFourCC(this.dwChunkId);
/* 1197 */       this.sb.append(String.format("\tAvi DML Super Index List - ChunkSize=%d, NumIndexes = %d, longsPerEntry = %d, Stream = %s, Type = %s", new Object[] {
/*      */               
/* 1199 */               Integer.valueOf(getChunkSize()), Integer.valueOf(this.nEntriesInUse), Short.valueOf(this.wLongsPerEntry), chunkIdStr.substring(0, 2), chunkIdStr
/* 1200 */               .substring(2)
/*      */             }));
/* 1202 */       for (int i = 0; i < this.nEntriesInUse; i++) {
/* 1203 */         this.qwOffset[i] = raf.readLong();
/* 1204 */         this.dwSize[i] = raf.readInt();
/* 1205 */         this.dwDuration[i] = raf.readInt();
/*      */         
/* 1207 */         this.sb.append(String.format("\n\t\tStandard Index - Offset [%d], Size [%d], Duration [%d]", new Object[] { Long.valueOf(this.qwOffset[i]), 
/* 1208 */                 Integer.valueOf(this.dwSize[i]), Integer.valueOf(this.dwDuration[i]) }));
/*      */       } 
/*      */       
/* 1211 */       raf.setPosition(getEndOfChunk());
/*      */     }
/*      */ 
/*      */     
/*      */     public String toString() {
/* 1216 */       return this.sb.toString();
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   static class AVITag_AviDmlStandardIndex
/*      */     extends AVIChunk
/*      */   {
/*      */     protected short wLongsPerEntry;
/*      */ 
/*      */     
/*      */     protected byte bIndexSubType;
/*      */ 
/*      */     
/*      */     protected byte bIndexType;
/*      */ 
/*      */     
/*      */     protected int nEntriesInUse;
/*      */ 
/*      */     
/*      */     protected int dwChunkId;
/*      */ 
/*      */     
/*      */     protected long qwBaseOffset;
/*      */ 
/*      */     
/*      */     protected int dwReserved2;
/*      */ 
/*      */     
/*      */     protected int[] dwOffset;
/*      */ 
/*      */     
/*      */     protected int[] dwDuration;
/*      */ 
/*      */     
/* 1253 */     int lastOffset = -1, lastDuration = -1;
/*      */ 
/*      */     
/*      */     public int getChunkSize() {
/* 1257 */       return this.dwChunkSize;
/*      */     }
/*      */ 
/*      */     
/*      */     public void read(int dwFourCC, DataReader raf) throws IOException {
/* 1262 */       super.read(dwFourCC, raf);
/*      */       
/* 1264 */       this.wLongsPerEntry = raf.readShort();
/* 1265 */       this.bIndexSubType = raf.readByte();
/* 1266 */       this.bIndexType = raf.readByte();
/* 1267 */       this.nEntriesInUse = raf.readInt();
/* 1268 */       this.dwChunkId = raf.readInt();
/* 1269 */       this.qwBaseOffset = raf.readLong();
/* 1270 */       this.dwReserved2 = raf.readInt();
/*      */       
/* 1272 */       this.dwOffset = new int[this.nEntriesInUse];
/* 1273 */       this.dwDuration = new int[this.nEntriesInUse];
/*      */       
/*      */       try {
/* 1276 */         for (int i = 0; i < this.nEntriesInUse; i++) {
/* 1277 */           this.dwOffset[i] = raf.readInt();
/* 1278 */           this.dwDuration[i] = raf.readInt();
/*      */           
/* 1280 */           this.lastOffset = this.dwOffset[i];
/* 1281 */           this.lastDuration = this.dwDuration[i];
/*      */         } 
/* 1283 */       } catch (Exception e) {
/* 1284 */         Logger.debug("Failed to read : " + toString());
/*      */       } 
/*      */       
/* 1287 */       raf.setPosition(getEndOfChunk());
/*      */     }
/*      */ 
/*      */     
/*      */     public String toString() {
/* 1292 */       return String.format("\tAvi DML Standard Index List Type=%d, SubType=%d, ChunkId=%s, StartOfChunk=%d, NumIndexes=%d, LongsPerEntry=%d, ChunkSize=%d, FirstOffset=%d, FirstDuration=%d,LastOffset=%d, LastDuration=%d", new Object[] {
/*      */             
/* 1294 */             Byte.valueOf(this.bIndexType), Byte.valueOf(this.bIndexSubType), AVIReader.toFourCC(this.dwChunkId), Long.valueOf(getStartOfChunk()), Integer.valueOf(this.nEntriesInUse), 
/* 1295 */             Short.valueOf(this.wLongsPerEntry), Integer.valueOf(getChunkSize()), Integer.valueOf(this.dwOffset[0]), Integer.valueOf(this.dwDuration[0]), Integer.valueOf(this.lastOffset), Integer.valueOf(this.lastDuration)
/*      */           });
/*      */     }
/*      */   }
/*      */ }


/* Location:              C:\Users\rapha\Downloads\aurora.jar!\META-INF\jars\jcodec-0.2.5.jar!\org\jcodec\containers\avi\AVIReader.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */