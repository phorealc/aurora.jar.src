/*     */ package org.jcodec.containers.mkv;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.nio.ByteBuffer;
/*     */ import java.util.ArrayList;
/*     */ import java.util.LinkedList;
/*     */ import java.util.List;
/*     */ import org.jcodec.common.io.SeekableByteChannel;
/*     */ import org.jcodec.containers.mkv.boxes.EbmlBase;
/*     */ import org.jcodec.containers.mkv.boxes.EbmlBin;
/*     */ import org.jcodec.containers.mkv.boxes.EbmlMaster;
/*     */ import org.jcodec.containers.mkv.boxes.EbmlVoid;
/*     */ import org.jcodec.containers.mkv.util.EbmlUtil;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class MKVParser
/*     */ {
/*     */   private SeekableByteChannel channel;
/*     */   private LinkedList<EbmlMaster> trace;
/*     */   
/*     */   public MKVParser(SeekableByteChannel channel) {
/*  41 */     this.channel = channel;
/*  42 */     this.trace = new LinkedList<EbmlMaster>();
/*     */   }
/*     */ 
/*     */   
/*     */   public List<EbmlMaster> parse() throws IOException {
/*  47 */     List<EbmlMaster> tree = new ArrayList<EbmlMaster>();
/*  48 */     EbmlBase e = null;
/*     */     
/*  50 */     while ((e = nextElement()) != null) {
/*  51 */       if (!isKnownType(e.id)) {
/*  52 */         System.err.println("Unspecified header: " + EbmlUtil.toHexString(e.id) + " at " + e.offset);
/*     */       }
/*  54 */       while (!possibleChild(this.trace.peekFirst(), e)) {
/*  55 */         closeElem(this.trace.removeFirst(), tree);
/*     */       }
/*  57 */       openElem(e);
/*     */       
/*  59 */       if (e instanceof EbmlMaster) {
/*  60 */         this.trace.push((EbmlMaster)e); continue;
/*  61 */       }  if (e instanceof EbmlBin) {
/*  62 */         EbmlBin bin = (EbmlBin)e;
/*  63 */         EbmlMaster traceTop = this.trace.peekFirst();
/*  64 */         if (traceTop.dataOffset + traceTop.dataLen < e.dataOffset + e.dataLen) {
/*  65 */           this.channel.setPosition(traceTop.dataOffset + traceTop.dataLen);
/*     */         } else {
/*     */           try {
/*  68 */             bin.readChannel(this.channel);
/*  69 */           } catch (OutOfMemoryError oome) {
/*  70 */             throw new RuntimeException(e.type + " 0x" + EbmlUtil.toHexString(bin.id) + " size: " + Long.toHexString(bin.dataLen) + " offset: 0x" + Long.toHexString(e.offset), oome);
/*     */           } 
/*  72 */         }  ((EbmlMaster)this.trace.peekFirst()).add(e); continue;
/*  73 */       }  if (e instanceof EbmlVoid) {
/*  74 */         ((EbmlVoid)e).skip(this.channel); continue;
/*     */       } 
/*  76 */       throw new RuntimeException("Currently there are no elements that are neither Master nor Binary, should never actually get here");
/*     */     } 
/*     */ 
/*     */ 
/*     */     
/*  81 */     while (this.trace.peekFirst() != null) {
/*  82 */       closeElem(this.trace.removeFirst(), tree);
/*     */     }
/*  84 */     return tree;
/*     */   }
/*     */   
/*     */   private boolean possibleChild(EbmlMaster parent, EbmlBase child) {
/*  88 */     if (parent != null && MKVType.Cluster.equals(parent.type) && child != null && !MKVType.Cluster.equals(child.type) && !MKVType.Info.equals(child.type) && !MKVType.SeekHead.equals(child.type) && !MKVType.Tracks.equals(child.type) && 
/*  89 */       !MKVType.Cues.equals(child.type) && !MKVType.Attachments.equals(child.type) && !MKVType.Tags.equals(child.type) && !MKVType.Chapters.equals(child.type)) {
/*  90 */       return true;
/*     */     }
/*  92 */     return MKVType.possibleChild(parent, child);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void openElem(EbmlBase e) {}
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void closeElem(EbmlMaster e, List<EbmlMaster> tree) {
/* 104 */     if (this.trace.peekFirst() == null) {
/* 105 */       tree.add(e);
/*     */     } else {
/* 107 */       ((EbmlMaster)this.trace.peekFirst()).add((EbmlBase)e);
/*     */     } 
/*     */   }
/*     */   
/*     */   private EbmlBase nextElement() throws IOException {
/* 112 */     long offset = this.channel.position();
/* 113 */     if (offset >= this.channel.size()) {
/* 114 */       return null;
/*     */     }
/* 116 */     byte[] typeId = readEbmlId(this.channel);
/*     */     
/* 118 */     while (typeId == null && !isKnownType(typeId) && offset < this.channel.size()) {
/* 119 */       offset++;
/* 120 */       this.channel.setPosition(offset);
/* 121 */       typeId = readEbmlId(this.channel);
/*     */     } 
/*     */     
/* 124 */     long dataLen = readEbmlInt(this.channel);
/*     */     
/* 126 */     EbmlBase elem = MKVType.createById(typeId, offset);
/* 127 */     elem.offset = offset;
/* 128 */     elem.typeSizeLength = (int)(this.channel.position() - offset);
/* 129 */     elem.dataOffset = this.channel.position();
/*     */     
/* 131 */     elem.dataLen = (int)dataLen;
/*     */     
/* 133 */     return elem;
/*     */   }
/*     */   
/*     */   public boolean isKnownType(byte[] b) {
/* 137 */     if (!this.trace.isEmpty() && MKVType.Cluster.equals(((EbmlMaster)this.trace.peekFirst()).type)) {
/* 138 */       return true;
/*     */     }
/* 140 */     return MKVType.isSpecifiedHeader(b);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static byte[] readEbmlId(SeekableByteChannel source) throws IOException {
/* 151 */     if (source.position() == source.size()) {
/* 152 */       return null;
/*     */     }
/* 154 */     ByteBuffer buffer = ByteBuffer.allocate(8);
/* 155 */     buffer.limit(1);
/* 156 */     source.read(buffer);
/* 157 */     buffer.flip();
/*     */     
/* 159 */     byte firstByte = buffer.get();
/* 160 */     int numBytes = EbmlUtil.computeLength(firstByte);
/*     */     
/* 162 */     if (numBytes == 0) {
/* 163 */       return null;
/*     */     }
/* 165 */     if (numBytes > 1) {
/* 166 */       buffer.limit(numBytes);
/* 167 */       source.read(buffer);
/*     */     } 
/*     */     
/* 170 */     buffer.flip();
/* 171 */     ByteBuffer val = ByteBuffer.allocate(buffer.remaining());
/* 172 */     val.put(buffer);
/* 173 */     return val.array();
/*     */   }
/*     */ 
/*     */   
/*     */   public static long readEbmlInt(SeekableByteChannel source) throws IOException {
/* 178 */     ByteBuffer buffer = ByteBuffer.allocate(8);
/* 179 */     buffer.limit(1);
/*     */     
/* 181 */     source.read(buffer);
/* 182 */     buffer.flip();
/*     */ 
/*     */     
/* 185 */     byte firstByte = buffer.get();
/* 186 */     int length = EbmlUtil.computeLength(firstByte);
/*     */     
/* 188 */     if (length == 0) {
/* 189 */       throw new RuntimeException("Invalid ebml integer size.");
/*     */     }
/*     */     
/* 192 */     buffer.limit(length);
/* 193 */     source.read(buffer);
/* 194 */     buffer.position(1);
/*     */ 
/*     */     
/* 197 */     long value = (firstByte & 255 >>> length);
/* 198 */     length--;
/*     */ 
/*     */     
/* 201 */     while (length > 0) {
/* 202 */       value = value << 8L | (buffer.get() & 0xFF);
/* 203 */       length--;
/*     */     } 
/*     */     
/* 206 */     return value;
/*     */   }
/*     */ }


/* Location:              C:\Users\rapha\Downloads\aurora.jar!\META-INF\jars\jcodec-0.2.5.jar!\org\jcodec\containers\mkv\MKVParser.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */