/*     */ package org.jcodec.containers.mkv;
/*     */ 
/*     */ import java.nio.ByteBuffer;
/*     */ import java.util.ArrayList;
/*     */ import java.util.List;
/*     */ import org.jcodec.containers.mkv.boxes.EbmlBase;
/*     */ import org.jcodec.containers.mkv.boxes.EbmlBin;
/*     */ import org.jcodec.containers.mkv.boxes.EbmlMaster;
/*     */ import org.jcodec.containers.mkv.boxes.EbmlUint;
/*     */ import org.jcodec.containers.mkv.util.EbmlUtil;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class SeekHeadFactory
/*     */ {
/*     */   List<SeekMock> a;
/*  30 */   long currentDataOffset = 0L;
/*     */   
/*     */   public SeekHeadFactory() {
/*  33 */     this.a = new ArrayList<SeekMock>();
/*     */   }
/*     */   
/*     */   public void add(EbmlBase e) {
/*  37 */     SeekMock z = SeekMock.make(e);
/*  38 */     z.dataOffset = this.currentDataOffset;
/*  39 */     z.seekPointerSize = EbmlUint.calculatePayloadSize(z.dataOffset);
/*  40 */     this.currentDataOffset += z.size;
/*     */     
/*  42 */     this.a.add(z);
/*     */   }
/*     */   
/*     */   public EbmlMaster indexSeekHead() {
/*  46 */     int seekHeadSize = computeSeekHeadSize();
/*     */     
/*  48 */     EbmlMaster seekHead = MKVType.<EbmlMaster>createByType(MKVType.SeekHead);
/*  49 */     for (SeekMock z : this.a) {
/*  50 */       EbmlMaster seek = MKVType.<EbmlMaster>createByType(MKVType.Seek);
/*     */       
/*  52 */       EbmlBin seekId = MKVType.<EbmlBin>createByType(MKVType.SeekID);
/*  53 */       seekId.setBuf(ByteBuffer.wrap(z.id));
/*  54 */       seek.add((EbmlBase)seekId);
/*     */       
/*  56 */       EbmlUint seekPosition = MKVType.<EbmlUint>createByType(MKVType.SeekPosition);
/*  57 */       seekPosition.setUint(z.dataOffset + seekHeadSize);
/*  58 */       if (seekPosition.data.limit() != z.seekPointerSize)
/*  59 */         System.err.println("estimated size of seekPosition differs from the one actually used. ElementId: " + EbmlUtil.toHexString(z.id) + " " + seekPosition.getData().limit() + " vs " + z.seekPointerSize); 
/*  60 */       seek.add((EbmlBase)seekPosition);
/*     */       
/*  62 */       seekHead.add((EbmlBase)seek);
/*     */     } 
/*  64 */     ByteBuffer mux = seekHead.getData();
/*  65 */     if (mux.limit() != seekHeadSize) {
/*  66 */       System.err.println("estimated size of seekHead differs from the one actually used. " + mux.limit() + " vs " + seekHeadSize);
/*     */     }
/*  68 */     return seekHead;
/*     */   }
/*     */   
/*     */   public int computeSeekHeadSize() {
/*  72 */     int seekHeadSize = estimateSize();
/*  73 */     boolean reindex = false;
/*     */     while (true) {
/*  75 */       reindex = false;
/*  76 */       for (SeekMock z : this.a) {
/*  77 */         int minSize = EbmlUint.calculatePayloadSize(z.dataOffset + seekHeadSize);
/*  78 */         if (minSize > z.seekPointerSize) {
/*  79 */           System.out.println("Size " + seekHeadSize + " seems too small for element " + EbmlUtil.toHexString(z.id) + " increasing size by one.");
/*  80 */           z.seekPointerSize++;
/*  81 */           seekHeadSize++;
/*  82 */           reindex = true; break;
/*     */         } 
/*  84 */         if (minSize < z.seekPointerSize) {
/*  85 */           throw new RuntimeException("Downsizing the index is not well thought through.");
/*     */         }
/*     */       } 
/*  88 */       if (!reindex)
/*  89 */         return seekHeadSize; 
/*     */     } 
/*     */   }
/*     */   int estimateSize() {
/*  93 */     int s = MKVType.SeekHead.id.length + 1;
/*  94 */     s += estimeteSeekSize(((SeekMock)this.a.get(0)).id.length, 1);
/*  95 */     for (int i = 1; i < this.a.size(); i++) {
/*  96 */       s += estimeteSeekSize(((SeekMock)this.a.get(i)).id.length, ((SeekMock)this.a.get(i)).seekPointerSize);
/*     */     }
/*  98 */     return s;
/*     */   }
/*     */   
/*     */   public static int estimeteSeekSize(int idLength, int offsetSizeInBytes) {
/* 102 */     int seekIdSize = MKVType.SeekID.id.length + EbmlUtil.ebmlLength(idLength) + idLength;
/* 103 */     int seekPositionSize = MKVType.SeekPosition.id.length + EbmlUtil.ebmlLength(offsetSizeInBytes) + offsetSizeInBytes;
/* 104 */     int seekSize = MKVType.Seek.id.length + EbmlUtil.ebmlLength((seekIdSize + seekPositionSize)) + seekIdSize + seekPositionSize;
/* 105 */     return seekSize;
/*     */   }
/*     */   
/*     */   public static class SeekMock {
/*     */     public long dataOffset;
/*     */     byte[] id;
/*     */     int size;
/*     */     int seekPointerSize;
/*     */     
/*     */     public static SeekMock make(EbmlBase e) {
/* 115 */       SeekMock z = new SeekMock();
/* 116 */       z.id = e.id;
/* 117 */       z.size = (int)e.size();
/* 118 */       return z;
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\rapha\Downloads\aurora.jar!\META-INF\jars\jcodec-0.2.5.jar!\org\jcodec\containers\mkv\SeekHeadFactory.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */