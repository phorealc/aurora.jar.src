/*     */ package org.jcodec.containers.mkv.util;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class EbmlUtil
/*     */ {
/*     */   public static byte[] ebmlEncodeLen(long value, int length) {
/*  23 */     byte[] b = new byte[length];
/*  24 */     for (int idx = 0; idx < length; idx++)
/*     */     {
/*  26 */       b[length - idx - 1] = (byte)(int)(value >>> 8 * idx & 0xFFL);
/*     */     }
/*     */     
/*  29 */     b[0] = (byte)(b[0] | 128 >>> length - 1);
/*  30 */     return b;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static byte[] ebmlEncode(long value) {
/*  41 */     return ebmlEncodeLen(value, ebmlLength(value));
/*     */   }
/*     */   
/*  44 */   public static final byte[] lengthOptions = new byte[] { 0, Byte.MIN_VALUE, 64, 32, 16, 8, 4, 2, 1 };
/*     */   
/*     */   public static final long one = 127L;
/*     */   
/*     */   public static final long two = 16256L;
/*     */   public static final long three = 2080768L;
/*     */   public static final long four = 266338304L;
/*     */   
/*     */   public static int computeLength(byte b) {
/*  53 */     if (b == 0) {
/*  54 */       throw new RuntimeException("Invalid head element for ebml sequence");
/*     */     }
/*  56 */     int i = 1;
/*  57 */     while ((b & lengthOptions[i]) == 0) {
/*  58 */       i++;
/*     */     }
/*  60 */     return i;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static final long five = 34091302912L;
/*     */ 
/*     */   
/*     */   public static final long six = 4363686772736L;
/*     */ 
/*     */   
/*     */   public static final long seven = 558551906910208L;
/*     */ 
/*     */   
/*     */   public static final long eight = 71494644084506624L;
/*     */ 
/*     */   
/*  78 */   public static final long[] ebmlLengthMasks = new long[] { 0L, 127L, 16256L, 2080768L, 266338304L, 34091302912L, 4363686772736L, 558551906910208L, 71494644084506624L };
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static int ebmlLength(long v) {
/*  88 */     if (v == 0L) {
/*  89 */       return 1;
/*     */     }
/*  91 */     int length = 8;
/*     */     
/*  93 */     while (length > 0 && (v & ebmlLengthMasks[length]) == 0L) {
/*  94 */       length--;
/*     */     }
/*  96 */     return length;
/*     */   }
/*     */   
/*     */   public static String toHexString(byte[] a) {
/* 100 */     StringBuilder sb = new StringBuilder();
/* 101 */     for (byte b : a) {
/* 102 */       sb.append(String.format("0x%02x ", new Object[] { Integer.valueOf(b & 0xFF) }));
/* 103 */     }  return sb.toString();
/*     */   }
/*     */ }


/* Location:              C:\Users\rapha\Downloads\aurora.jar!\META-INF\jars\jcodec-0.2.5.jar!\org\jcodec\containers\mk\\util\EbmlUtil.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */