/*     */ package org.jcodec.containers.mkv.muxer;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.nio.ByteBuffer;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Date;
/*     */ import java.util.HashMap;
/*     */ import java.util.LinkedList;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import org.jcodec.common.AudioCodecMeta;
/*     */ import org.jcodec.common.Codec;
/*     */ import org.jcodec.common.Muxer;
/*     */ import org.jcodec.common.MuxerTrack;
/*     */ import org.jcodec.common.VideoCodecMeta;
/*     */ import org.jcodec.common.io.SeekableByteChannel;
/*     */ import org.jcodec.containers.mkv.CuesFactory;
/*     */ import org.jcodec.containers.mkv.MKVType;
/*     */ import org.jcodec.containers.mkv.SeekHeadFactory;
/*     */ import org.jcodec.containers.mkv.boxes.EbmlBase;
/*     */ import org.jcodec.containers.mkv.boxes.EbmlBin;
/*     */ import org.jcodec.containers.mkv.boxes.EbmlDate;
/*     */ import org.jcodec.containers.mkv.boxes.EbmlFloat;
/*     */ import org.jcodec.containers.mkv.boxes.EbmlMaster;
/*     */ import org.jcodec.containers.mkv.boxes.EbmlString;
/*     */ import org.jcodec.containers.mkv.boxes.EbmlUint;
/*     */ import org.jcodec.containers.mkv.boxes.MkvBlock;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class MKVMuxer
/*     */   implements Muxer
/*     */ {
/*     */   private List<MKVMuxerTrack> tracks;
/*     */   private MKVMuxerTrack audioTrack;
/*     */   private MKVMuxerTrack videoTrack;
/*     */   private EbmlMaster mkvInfo;
/*     */   private EbmlMaster mkvTracks;
/*     */   private EbmlMaster mkvCues;
/*     */   private EbmlMaster mkvSeekHead;
/*     */   private List<EbmlMaster> clusterList;
/*     */   private SeekableByteChannel sink;
/*  76 */   private static Map<Codec, String> codec2mkv = new HashMap<Codec, String>();
/*     */   static {
/*  78 */     codec2mkv.put(Codec.H264, "V_MPEG4/ISO/AVC");
/*  79 */     codec2mkv.put(Codec.VP8, "V_VP8");
/*  80 */     codec2mkv.put(Codec.VP9, "V_VP9");
/*     */   }
/*     */   
/*     */   public MKVMuxer(SeekableByteChannel s) {
/*  84 */     this.sink = s;
/*  85 */     this.tracks = new ArrayList<MKVMuxerTrack>();
/*  86 */     this.clusterList = new LinkedList<EbmlMaster>();
/*     */   }
/*     */   
/*     */   public MKVMuxerTrack createVideoTrack(VideoCodecMeta meta, String codecId) {
/*  90 */     if (this.videoTrack == null) {
/*  91 */       this.videoTrack = new MKVMuxerTrack();
/*  92 */       this.tracks.add(this.videoTrack);
/*  93 */       this.videoTrack.codecId = codecId;
/*  94 */       this.videoTrack.videoMeta = meta;
/*  95 */       this.videoTrack.trackNo = this.tracks.size();
/*     */     } 
/*  97 */     return this.videoTrack;
/*     */   }
/*     */   
/*     */   public void finish() throws IOException {
/* 101 */     List<EbmlMaster> mkvFile = new ArrayList<EbmlMaster>();
/* 102 */     EbmlMaster ebmlHeader = defaultEbmlHeader();
/* 103 */     mkvFile.add(ebmlHeader);
/*     */     
/* 105 */     EbmlMaster segmentElem = (EbmlMaster)MKVType.createByType(MKVType.Segment);
/* 106 */     this.mkvInfo = muxInfo();
/* 107 */     this.mkvTracks = muxTracks();
/* 108 */     this.mkvCues = (EbmlMaster)MKVType.createByType(MKVType.Cues);
/* 109 */     this.mkvSeekHead = muxSeekHead();
/* 110 */     muxCues();
/*     */     
/* 112 */     segmentElem.add((EbmlBase)this.mkvSeekHead);
/* 113 */     segmentElem.add((EbmlBase)this.mkvInfo);
/* 114 */     segmentElem.add((EbmlBase)this.mkvTracks);
/* 115 */     segmentElem.add((EbmlBase)this.mkvCues);
/* 116 */     for (EbmlMaster aCluster : this.clusterList)
/* 117 */       segmentElem.add((EbmlBase)aCluster); 
/* 118 */     mkvFile.add(segmentElem);
/*     */     
/* 120 */     for (EbmlMaster el : mkvFile)
/* 121 */       el.mux(this.sink); 
/*     */   }
/*     */   
/*     */   private EbmlMaster defaultEbmlHeader() {
/* 125 */     EbmlMaster master = (EbmlMaster)MKVType.createByType(MKVType.EBML);
/*     */     
/* 127 */     createLong(master, MKVType.EBMLVersion, 1L);
/* 128 */     createLong(master, MKVType.EBMLReadVersion, 1L);
/* 129 */     createLong(master, MKVType.EBMLMaxIDLength, 4L);
/* 130 */     createLong(master, MKVType.EBMLMaxSizeLength, 8L);
/*     */     
/* 132 */     createString(master, MKVType.DocType, "webm");
/* 133 */     createLong(master, MKVType.DocTypeVersion, 2L);
/* 134 */     createLong(master, MKVType.DocTypeReadVersion, 2L);
/*     */     
/* 136 */     return master;
/*     */   }
/*     */   
/*     */   private EbmlMaster muxInfo() {
/* 140 */     EbmlMaster master = (EbmlMaster)MKVType.createByType(MKVType.Info);
/* 141 */     int frameDurationInNanoseconds = 40000000;
/* 142 */     createLong(master, MKVType.TimecodeScale, frameDurationInNanoseconds);
/* 143 */     createString(master, MKVType.WritingApp, "JCodec");
/* 144 */     createString(master, MKVType.MuxingApp, "JCodec");
/*     */     
/* 146 */     List<MKVMuxerTrack> tracks2 = this.tracks;
/* 147 */     long max = 0L;
/* 148 */     for (MKVMuxerTrack track : tracks2) {
/* 149 */       MkvBlock lastBlock = track.trackBlocks.get(track.trackBlocks.size() - 1);
/* 150 */       if (lastBlock.absoluteTimecode > max)
/* 151 */         max = lastBlock.absoluteTimecode; 
/*     */     } 
/* 153 */     createDouble(master, MKVType.Duration, ((max + 1L) * frameDurationInNanoseconds) * 1.0D);
/* 154 */     createDate(master, MKVType.DateUTC, new Date());
/* 155 */     return master;
/*     */   }
/*     */   
/*     */   private EbmlMaster muxTracks() {
/* 159 */     EbmlMaster master = (EbmlMaster)MKVType.createByType(MKVType.Tracks);
/* 160 */     for (int i = 0; i < this.tracks.size(); i++) {
/* 161 */       MKVMuxerTrack track = this.tracks.get(i);
/* 162 */       EbmlMaster trackEntryElem = (EbmlMaster)MKVType.createByType(MKVType.TrackEntry);
/*     */       
/* 164 */       createLong(trackEntryElem, MKVType.TrackNumber, track.trackNo);
/*     */       
/* 166 */       createLong(trackEntryElem, MKVType.TrackUID, track.trackNo);
/* 167 */       if (MKVMuxerTrack.MKVMuxerTrackType.VIDEO.equals(track.type)) {
/* 168 */         createLong(trackEntryElem, MKVType.TrackType, 1L);
/* 169 */         createString(trackEntryElem, MKVType.Name, "Track " + (i + 1) + " Video");
/* 170 */         createString(trackEntryElem, MKVType.CodecID, track.codecId);
/*     */ 
/*     */ 
/*     */         
/* 174 */         EbmlMaster trackVideoElem = (EbmlMaster)MKVType.createByType(MKVType.Video);
/* 175 */         createLong(trackVideoElem, MKVType.PixelWidth, track.videoMeta.getSize().getWidth());
/* 176 */         createLong(trackVideoElem, MKVType.PixelHeight, track.videoMeta.getSize().getHeight());
/*     */         
/* 178 */         trackEntryElem.add((EbmlBase)trackVideoElem);
/*     */       } else {
/*     */         
/* 181 */         createLong(trackEntryElem, MKVType.TrackType, 2L);
/* 182 */         createString(trackEntryElem, MKVType.Name, "Track " + (i + 1) + " Audio");
/* 183 */         createString(trackEntryElem, MKVType.CodecID, track.codecId);
/*     */       } 
/*     */ 
/*     */       
/* 187 */       master.add((EbmlBase)trackEntryElem);
/*     */     } 
/* 189 */     return master;
/*     */   }
/*     */   
/*     */   private void muxCues() {
/* 193 */     CuesFactory cf = new CuesFactory(this.mkvSeekHead.size() + this.mkvInfo.size() + this.mkvTracks.size(), this.videoTrack.trackNo);
/*     */     
/* 195 */     for (MkvBlock aBlock : this.videoTrack.trackBlocks) {
/* 196 */       EbmlMaster mkvCluster = singleBlockedCluster(aBlock);
/* 197 */       this.clusterList.add(mkvCluster);
/* 198 */       cf.add(CuesFactory.CuePointMock.make(mkvCluster));
/*     */     } 
/*     */     
/* 201 */     EbmlMaster indexedCues = cf.createCues();
/*     */     
/* 203 */     for (EbmlBase aCuePoint : indexedCues.children)
/* 204 */       this.mkvCues.add(aCuePoint); 
/*     */   }
/*     */   
/*     */   private EbmlMaster singleBlockedCluster(MkvBlock aBlock) {
/* 208 */     EbmlMaster mkvCluster = (EbmlMaster)MKVType.createByType(MKVType.Cluster);
/* 209 */     createLong(mkvCluster, MKVType.Timecode, aBlock.absoluteTimecode - aBlock.timecode);
/* 210 */     mkvCluster.add((EbmlBase)aBlock);
/* 211 */     return mkvCluster;
/*     */   }
/*     */   
/*     */   private EbmlMaster muxSeekHead() {
/* 215 */     SeekHeadFactory shi = new SeekHeadFactory();
/* 216 */     shi.add((EbmlBase)this.mkvInfo);
/* 217 */     shi.add((EbmlBase)this.mkvTracks);
/* 218 */     shi.add((EbmlBase)this.mkvCues);
/* 219 */     return shi.indexSeekHead();
/*     */   }
/*     */   
/*     */   public static void createLong(EbmlMaster parent, MKVType type, long value) {
/* 223 */     EbmlUint se = (EbmlUint)MKVType.createByType(type);
/* 224 */     se.setUint(value);
/* 225 */     parent.add((EbmlBase)se);
/*     */   }
/*     */   
/*     */   public static void createString(EbmlMaster parent, MKVType type, String value) {
/* 229 */     EbmlString se = (EbmlString)MKVType.createByType(type);
/* 230 */     se.setString(value);
/* 231 */     parent.add((EbmlBase)se);
/*     */   }
/*     */   
/*     */   public static void createDate(EbmlMaster parent, MKVType type, Date value) {
/* 235 */     EbmlDate se = (EbmlDate)MKVType.createByType(type);
/* 236 */     se.setDate(value);
/* 237 */     parent.add((EbmlBase)se);
/*     */   }
/*     */   
/*     */   public static void createBuffer(EbmlMaster parent, MKVType type, ByteBuffer value) {
/* 241 */     EbmlBin se = (EbmlBin)MKVType.createByType(type);
/* 242 */     se.setBuf(value);
/* 243 */     parent.add((EbmlBase)se);
/*     */   }
/*     */   
/*     */   public static void createDouble(EbmlMaster parent, MKVType type, double value) {
/*     */     try {
/* 248 */       EbmlFloat se = (EbmlFloat)MKVType.createByType(type);
/* 249 */       se.setDouble(value);
/* 250 */       parent.add((EbmlBase)se);
/* 251 */     } catch (ClassCastException cce) {
/* 252 */       throw new RuntimeException("Element of type " + type + " can't be cast to EbmlFloat", cce);
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public MuxerTrack addVideoTrack(Codec codec, VideoCodecMeta meta) {
/* 258 */     return createVideoTrack(meta, codec2mkv.get(codec));
/*     */   }
/*     */ 
/*     */   
/*     */   public MuxerTrack addAudioTrack(Codec codec, AudioCodecMeta meta) {
/* 263 */     this.audioTrack = new MKVMuxerTrack();
/* 264 */     this.tracks.add(this.audioTrack);
/* 265 */     this.audioTrack.codecId = codec2mkv.get(codec);
/* 266 */     this.audioTrack.trackNo = this.tracks.size();
/* 267 */     return this.audioTrack;
/*     */   }
/*     */ }


/* Location:              C:\Users\rapha\Downloads\aurora.jar!\META-INF\jars\jcodec-0.2.5.jar!\org\jcodec\containers\mkv\muxer\MKVMuxer.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */