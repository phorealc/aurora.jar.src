/*    */ package org.jcodec.containers.mkv.muxer;
/*    */ import java.util.ArrayList;
/*    */ import java.util.List;
/*    */ import org.jcodec.common.MuxerTrack;
/*    */ import org.jcodec.common.VideoCodecMeta;
/*    */ import org.jcodec.common.model.Packet;
/*    */ import org.jcodec.containers.mkv.boxes.MkvBlock;
/*    */ 
/*    */ public class MKVMuxerTrack implements MuxerTrack {
/*    */   public MKVMuxerTrackType type;
/*    */   public VideoCodecMeta videoMeta;
/*    */   public String codecId;
/*    */   public int trackNo;
/*    */   private int frameDuration;
/*    */   List<MkvBlock> trackBlocks;
/*    */   static final int DEFAULT_TIMESCALE = 1000000000;
/*    */   static final int NANOSECONDS_IN_A_MILISECOND = 1000000;
/*    */   static final int MULTIPLIER = 1000;
/*    */   
/*    */   public enum MKVMuxerTrackType {
/* 21 */     VIDEO;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public MKVMuxerTrack() {
/* 31 */     this.trackBlocks = new ArrayList<MkvBlock>();
/* 32 */     this.type = MKVMuxerTrackType.VIDEO;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public int getTimescale() {
/* 41 */     return 1000000;
/*    */   }
/*    */ 
/*    */   
/*    */   public void addFrame(Packet outPacket) {
/* 46 */     MkvBlock frame = MkvBlock.keyFrame(this.trackNo, 0, outPacket.getData());
/* 47 */     frame.absoluteTimecode = outPacket.getPts() - 1L;
/* 48 */     this.trackBlocks.add(frame);
/*    */   }
/*    */   
/*    */   public long getTrackNo() {
/* 52 */     return this.trackNo;
/*    */   }
/*    */ }


/* Location:              C:\Users\rapha\Downloads\aurora.jar!\META-INF\jars\jcodec-0.2.5.jar!\org\jcodec\containers\mkv\muxer\MKVMuxerTrack.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */