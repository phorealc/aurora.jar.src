/*     */ package org.jcodec.containers.mkv.demuxer;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.nio.ByteBuffer;
/*     */ import java.util.ArrayList;
/*     */ import java.util.HashMap;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import org.jcodec.codecs.h264.H264Utils;
/*     */ import org.jcodec.codecs.h264.mp4.AvcCBox;
/*     */ import org.jcodec.common.Codec;
/*     */ import org.jcodec.common.Demuxer;
/*     */ import org.jcodec.common.DemuxerTrack;
/*     */ import org.jcodec.common.DemuxerTrackMeta;
/*     */ import org.jcodec.common.SeekableDemuxerTrack;
/*     */ import org.jcodec.common.TrackType;
/*     */ import org.jcodec.common.VideoCodecMeta;
/*     */ import org.jcodec.common.io.SeekableByteChannel;
/*     */ import org.jcodec.common.model.ColorSpace;
/*     */ import org.jcodec.common.model.Packet;
/*     */ import org.jcodec.common.model.Size;
/*     */ import org.jcodec.common.model.TapeTimecode;
/*     */ import org.jcodec.containers.mkv.MKVParser;
/*     */ import org.jcodec.containers.mkv.MKVType;
/*     */ import org.jcodec.containers.mkv.boxes.EbmlBase;
/*     */ import org.jcodec.containers.mkv.boxes.EbmlBin;
/*     */ import org.jcodec.containers.mkv.boxes.EbmlFloat;
/*     */ import org.jcodec.containers.mkv.boxes.EbmlMaster;
/*     */ import org.jcodec.containers.mkv.boxes.EbmlString;
/*     */ import org.jcodec.containers.mkv.boxes.EbmlUint;
/*     */ import org.jcodec.containers.mkv.boxes.MkvBlock;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class MKVDemuxer
/*     */   implements Demuxer
/*     */ {
/*  61 */   private VideoTrack vTrack = null;
/*     */   private List<AudioTrack> aTracks;
/*     */   private List<SubtitlesTrack> subsTracks;
/*     */   private List<EbmlMaster> t;
/*     */   private SeekableByteChannel channel;
/*  66 */   int timescale = 1;
/*     */   
/*     */   int pictureWidth;
/*     */   int pictureHeight;
/*  70 */   private static Map<String, Codec> codecMapping = new HashMap<String, Codec>();
/*     */   static {
/*  72 */     codecMapping.put("V_VP8", Codec.VP8);
/*  73 */     codecMapping.put("V_VP9", Codec.VP9);
/*  74 */     codecMapping.put("V_MPEG4/ISO/AVC", Codec.H264);
/*     */   }
/*     */   
/*     */   public MKVDemuxer(SeekableByteChannel fileChannelWrapper) throws IOException {
/*  78 */     this.channel = fileChannelWrapper;
/*  79 */     this.aTracks = new ArrayList<AudioTrack>();
/*  80 */     this.subsTracks = new ArrayList<SubtitlesTrack>();
/*  81 */     MKVParser parser = new MKVParser(this.channel);
/*  82 */     this.t = parser.parse();
/*  83 */     demux();
/*     */   }
/*     */   
/*     */   private void demux() {
/*  87 */     MKVType[] path = { MKVType.Segment, MKVType.Info, MKVType.TimecodeScale };
/*  88 */     EbmlUint ts = (EbmlUint)MKVType.findFirstTree(this.t, path);
/*  89 */     if (ts != null)
/*  90 */       this.timescale = (int)ts.getUint(); 
/*  91 */     MKVType[] path9 = { MKVType.Segment, MKVType.Tracks, MKVType.TrackEntry };
/*     */     
/*  93 */     for (EbmlMaster aTrack : MKVType.findList(this.t, EbmlMaster.class, path9)) {
/*  94 */       MKVType[] path1 = { MKVType.TrackEntry, MKVType.TrackType };
/*  95 */       long type = ((EbmlUint)MKVType.findFirst((EbmlBase)aTrack, path1)).getUint();
/*  96 */       MKVType[] arrayOfMKVType1 = { MKVType.TrackEntry, MKVType.TrackNumber };
/*  97 */       long id = ((EbmlUint)MKVType.findFirst((EbmlBase)aTrack, arrayOfMKVType1)).getUint();
/*  98 */       if (type == 1L) {
/*     */         
/* 100 */         if (this.vTrack != null)
/* 101 */           throw new RuntimeException("More then 1 video track, can not compute..."); 
/* 102 */         MKVType[] path3 = { MKVType.TrackEntry, MKVType.CodecPrivate };
/* 103 */         MKVType[] path10 = { MKVType.TrackEntry, MKVType.CodecID };
/* 104 */         EbmlString codecId = (EbmlString)MKVType.findFirst((EbmlBase)aTrack, path10);
/* 105 */         Codec codec = codecMapping.get(codecId.getString());
/*     */         
/* 107 */         EbmlBin videoCodecState = (EbmlBin)MKVType.findFirst((EbmlBase)aTrack, path3);
/* 108 */         ByteBuffer state = null;
/* 109 */         if (videoCodecState != null) {
/* 110 */           state = videoCodecState.data;
/*     */         }
/* 112 */         MKVType[] path4 = { MKVType.TrackEntry, MKVType.Video, MKVType.PixelWidth };
/*     */         
/* 114 */         EbmlUint width = (EbmlUint)MKVType.findFirst((EbmlBase)aTrack, path4);
/* 115 */         MKVType[] path5 = { MKVType.TrackEntry, MKVType.Video, MKVType.PixelHeight };
/* 116 */         EbmlUint height = (EbmlUint)MKVType.findFirst((EbmlBase)aTrack, path5);
/* 117 */         MKVType[] path6 = { MKVType.TrackEntry, MKVType.Video, MKVType.DisplayWidth };
/* 118 */         EbmlUint dwidth = (EbmlUint)MKVType.findFirst((EbmlBase)aTrack, path6);
/* 119 */         MKVType[] path7 = { MKVType.TrackEntry, MKVType.Video, MKVType.DisplayHeight };
/* 120 */         EbmlUint dheight = (EbmlUint)MKVType.findFirst((EbmlBase)aTrack, path7);
/* 121 */         MKVType[] path8 = { MKVType.TrackEntry, MKVType.Video, MKVType.DisplayUnit };
/* 122 */         EbmlUint unit = (EbmlUint)MKVType.findFirst((EbmlBase)aTrack, path8);
/* 123 */         if (width != null && height != null) {
/* 124 */           this.pictureWidth = (int)width.getUint();
/* 125 */           this.pictureHeight = (int)height.getUint();
/* 126 */         } else if (dwidth != null && dheight != null) {
/* 127 */           if (unit == null || unit.getUint() == 0L) {
/* 128 */             this.pictureHeight = (int)dheight.getUint();
/* 129 */             this.pictureWidth = (int)dwidth.getUint();
/*     */           } else {
/* 131 */             throw new RuntimeException("DisplayUnits other then 0 are not implemented yet");
/*     */           } 
/*     */         } 
/*     */         
/* 135 */         this.vTrack = new VideoTrack(this, (int)id, state, codec); continue;
/*     */       } 
/* 137 */       if (type == 2L) {
/* 138 */         AudioTrack audioTrack = new AudioTrack((int)id, this);
/* 139 */         MKVType[] path3 = { MKVType.TrackEntry, MKVType.Audio, MKVType.SamplingFrequency };
/* 140 */         EbmlFloat sf = (EbmlFloat)MKVType.findFirst((EbmlBase)aTrack, path3);
/* 141 */         if (sf != null) {
/* 142 */           audioTrack.samplingFrequency = sf.getDouble();
/*     */         }
/* 144 */         this.aTracks.add(audioTrack); continue;
/* 145 */       }  if (type == 17L) {
/* 146 */         SubtitlesTrack subsTrack = new SubtitlesTrack((int)id, this);
/* 147 */         this.subsTracks.add(subsTrack);
/*     */       } 
/*     */     } 
/* 150 */     MKVType[] path2 = { MKVType.Segment, MKVType.Cluster };
/* 151 */     for (EbmlMaster aCluster : MKVType.findList(this.t, EbmlMaster.class, path2)) {
/* 152 */       MKVType[] path1 = { MKVType.Cluster, MKVType.Timecode };
/* 153 */       long baseTimecode = ((EbmlUint)MKVType.findFirst((EbmlBase)aCluster, path1)).getUint();
/* 154 */       for (EbmlBase child : aCluster.children) {
/* 155 */         if (MKVType.SimpleBlock.equals(child.type)) {
/* 156 */           MkvBlock b = (MkvBlock)child;
/* 157 */           b.absoluteTimecode = b.timecode + baseTimecode;
/* 158 */           putIntoRightBasket(b); continue;
/* 159 */         }  if (MKVType.BlockGroup.equals(child.type)) {
/* 160 */           EbmlMaster group = (EbmlMaster)child;
/* 161 */           for (EbmlBase grandChild : group.children) {
/* 162 */             if (grandChild.type == MKVType.Block) {
/* 163 */               MkvBlock b = (MkvBlock)grandChild;
/* 164 */               b.absoluteTimecode = b.timecode + baseTimecode;
/* 165 */               putIntoRightBasket(b);
/*     */             } 
/*     */           } 
/*     */         } 
/*     */       } 
/*     */     } 
/*     */   }
/*     */   private void putIntoRightBasket(MkvBlock b) {
/* 173 */     if (b.trackNumber == this.vTrack.trackNo) {
/* 174 */       this.vTrack.blocks.add(b);
/*     */     } else {
/*     */       int i;
/* 177 */       for (i = 0; i < this.aTracks.size(); i++) {
/* 178 */         AudioTrack audio = this.aTracks.get(i);
/* 179 */         if (b.trackNumber == audio.trackNo) {
/* 180 */           audio.blocks.add(IndexedBlock.make(audio.framesCount, b));
/* 181 */           audio.framesCount += b.frameSizes.length;
/*     */         } 
/*     */       } 
/* 184 */       for (i = 0; i < this.subsTracks.size(); i++) {
/* 185 */         SubtitlesTrack subs = this.subsTracks.get(i);
/* 186 */         if (b.trackNumber == subs.trackNo) {
/* 187 */           subs.blocks.add(IndexedBlock.make(subs.framesCount, b));
/* 188 */           subs.framesCount += b.frameSizes.length;
/*     */         } 
/*     */       } 
/*     */     } 
/*     */   }
/*     */   
/*     */   public static class VideoTrack implements SeekableDemuxerTrack {
/*     */     private ByteBuffer state;
/*     */     public final int trackNo;
/* 197 */     private int frameIdx = 0;
/*     */     List<MkvBlock> blocks;
/*     */     private MKVDemuxer demuxer;
/*     */     private Codec codec;
/*     */     private AvcCBox avcC;
/*     */     
/*     */     public VideoTrack(MKVDemuxer demuxer, int trackNo, ByteBuffer state, Codec codec) {
/* 204 */       this.blocks = new ArrayList<MkvBlock>();
/* 205 */       this.demuxer = demuxer;
/* 206 */       this.trackNo = trackNo;
/* 207 */       this.codec = codec;
/* 208 */       if (codec == Codec.H264) {
/* 209 */         this.avcC = H264Utils.parseAVCCFromBuffer(state);
/* 210 */         this.state = H264Utils.avcCToAnnexB(this.avcC);
/*     */       } else {
/* 212 */         this.state = state;
/*     */       } 
/*     */     }
/*     */ 
/*     */     
/*     */     public Packet nextFrame() throws IOException {
/* 218 */       if (this.frameIdx >= this.blocks.size()) {
/* 219 */         return null;
/*     */       }
/* 221 */       MkvBlock b = this.blocks.get(this.frameIdx);
/* 222 */       if (b == null)
/* 223 */         throw new RuntimeException("Something somewhere went wrong."); 
/* 224 */       this.frameIdx++;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 230 */       this.demuxer.channel.setPosition(b.dataOffset);
/* 231 */       ByteBuffer data = ByteBuffer.allocate(b.dataLen);
/* 232 */       this.demuxer.channel.read(data);
/* 233 */       data.flip();
/* 234 */       b.readFrames(data.duplicate());
/* 235 */       long duration = 1L;
/* 236 */       if (this.frameIdx < this.blocks.size())
/* 237 */         duration = ((MkvBlock)this.blocks.get(this.frameIdx)).absoluteTimecode - b.absoluteTimecode; 
/* 238 */       ByteBuffer result = b.frames[0].duplicate();
/* 239 */       if (this.codec == Codec.H264) {
/* 240 */         result = H264Utils.decodeMOVPacket(result, this.avcC);
/*     */       }
/* 242 */       return Packet.createPacket(result, b.absoluteTimecode, this.demuxer.timescale, duration, (this.frameIdx - 1), b._keyFrame ? Packet.FrameType.KEY : Packet.FrameType.INTER, TapeTimecode.ZERO_TAPE_TIMECODE);
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     public boolean gotoFrame(long i) {
/* 248 */       if (i > 2147483647L)
/* 249 */         return false; 
/* 250 */       if (i > this.blocks.size()) {
/* 251 */         return false;
/*     */       }
/* 253 */       this.frameIdx = (int)i;
/* 254 */       return true;
/*     */     }
/*     */ 
/*     */     
/*     */     public long getCurFrame() {
/* 259 */       return this.frameIdx;
/*     */     }
/*     */ 
/*     */     
/*     */     public void seek(double second) {
/* 264 */       throw new RuntimeException("Not implemented yet");
/*     */     }
/*     */ 
/*     */     
/*     */     public int getFrameCount() {
/* 269 */       return this.blocks.size();
/*     */     }
/*     */     
/*     */     public ByteBuffer getCodecState() {
/* 273 */       return this.state;
/*     */     }
/*     */ 
/*     */     
/*     */     public DemuxerTrackMeta getMeta() {
/* 278 */       return new DemuxerTrackMeta(TrackType.VIDEO, this.codec, 0.0D, null, 0, this.state, 
/* 279 */           VideoCodecMeta.createSimpleVideoCodecMeta(new Size(this.demuxer.pictureWidth, this.demuxer.pictureHeight), ColorSpace.YUV420), null);
/*     */     }
/*     */ 
/*     */     
/*     */     public boolean gotoSyncFrame(long i) {
/* 284 */       throw new RuntimeException("Unsupported");
/*     */     }
/*     */   }
/*     */   
/*     */   public static class IndexedBlock {
/*     */     public int firstFrameNo;
/*     */     public MkvBlock block;
/*     */     
/*     */     public static IndexedBlock make(int no, MkvBlock b) {
/* 293 */       IndexedBlock ib = new IndexedBlock();
/* 294 */       ib.firstFrameNo = no;
/* 295 */       ib.block = b;
/* 296 */       return ib;
/*     */     }
/*     */   }
/*     */   
/*     */   public static class SubtitlesTrack extends MkvTrack {
/*     */     SubtitlesTrack(int trackNo, MKVDemuxer demuxer) {
/* 302 */       super(trackNo, demuxer);
/*     */     }
/*     */   }
/*     */   
/*     */   private static class MkvBlockData {
/*     */     final MkvBlock block;
/*     */     final ByteBuffer data;
/*     */     final int count;
/*     */     
/*     */     MkvBlockData(MkvBlock block, ByteBuffer data, int count) {
/* 312 */       this.block = block;
/* 313 */       this.data = data;
/* 314 */       this.count = count;
/*     */     }
/*     */   }
/*     */   
/*     */   public static class MkvTrack implements SeekableDemuxerTrack {
/*     */     public final int trackNo;
/*     */     List<MKVDemuxer.IndexedBlock> blocks;
/* 321 */     int framesCount = 0;
/* 322 */     private int frameIdx = 0;
/* 323 */     private int blockIdx = 0;
/* 324 */     private int frameInBlockIdx = 0;
/*     */     private MKVDemuxer demuxer;
/*     */     
/*     */     public MkvTrack(int trackNo, MKVDemuxer demuxer) {
/* 328 */       this.blocks = new ArrayList<MKVDemuxer.IndexedBlock>();
/*     */       
/* 330 */       this.trackNo = trackNo;
/* 331 */       this.demuxer = demuxer;
/*     */     }
/*     */ 
/*     */     
/*     */     public Packet nextFrame() throws IOException {
/* 336 */       MKVDemuxer.MkvBlockData bd = nextBlock();
/* 337 */       if (bd == null) return null; 
/* 338 */       return Packet.createPacket(bd.data, bd.block.absoluteTimecode, this.demuxer.timescale, 1L, (this.frameIdx - 1), Packet.FrameType.KEY, TapeTimecode.ZERO_TAPE_TIMECODE);
/*     */     }
/*     */ 
/*     */     
/*     */     protected MKVDemuxer.MkvBlockData nextBlock() throws IOException {
/* 343 */       if (this.frameIdx >= this.blocks.size() || this.blockIdx >= this.blocks.size()) {
/* 344 */         return null;
/*     */       }
/* 346 */       MkvBlock b = ((MKVDemuxer.IndexedBlock)this.blocks.get(this.blockIdx)).block;
/* 347 */       if (b == null) {
/* 348 */         throw new RuntimeException("Something somewhere went wrong.");
/*     */       }
/* 350 */       if (b.frames == null || b.frames.length == 0) {
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */         
/* 356 */         this.demuxer.channel.setPosition(b.dataOffset);
/* 357 */         ByteBuffer byteBuffer = ByteBuffer.allocate(b.dataLen);
/* 358 */         this.demuxer.channel.read(byteBuffer);
/* 359 */         b.readFrames(byteBuffer);
/*     */       } 
/* 361 */       ByteBuffer data = b.frames[this.frameInBlockIdx].duplicate();
/* 362 */       this.frameInBlockIdx++;
/* 363 */       this.frameIdx++;
/* 364 */       if (this.frameInBlockIdx >= b.frames.length) {
/* 365 */         this.blockIdx++;
/* 366 */         this.frameInBlockIdx = 0;
/*     */       } 
/*     */       
/* 369 */       return new MKVDemuxer.MkvBlockData(b, data, 1);
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     public boolean gotoFrame(long i) {
/* 375 */       if (i > 2147483647L)
/* 376 */         return false; 
/* 377 */       if (i > this.framesCount) {
/* 378 */         return false;
/*     */       }
/* 380 */       int frameBlockIdx = findBlockIndex(i);
/* 381 */       if (frameBlockIdx == -1) {
/* 382 */         return false;
/*     */       }
/* 384 */       this.frameIdx = (int)i;
/* 385 */       this.blockIdx = frameBlockIdx;
/* 386 */       this.frameInBlockIdx = (int)i - ((MKVDemuxer.IndexedBlock)this.blocks.get(this.blockIdx)).firstFrameNo;
/*     */       
/* 388 */       return true;
/*     */     }
/*     */     
/*     */     private int findBlockIndex(long i) {
/* 392 */       for (int blockIndex = 0; blockIndex < this.blocks.size(); blockIndex++) {
/* 393 */         if (i < ((MKVDemuxer.IndexedBlock)this.blocks.get(blockIndex)).block.frameSizes.length) {
/* 394 */           return blockIndex;
/*     */         }
/* 396 */         i -= ((MKVDemuxer.IndexedBlock)this.blocks.get(blockIndex)).block.frameSizes.length;
/*     */       } 
/*     */       
/* 399 */       return -1;
/*     */     }
/*     */ 
/*     */     
/*     */     public long getCurFrame() {
/* 404 */       return this.frameIdx;
/*     */     }
/*     */ 
/*     */     
/*     */     public void seek(double second) {
/* 409 */       throw new RuntimeException("Not implemented yet");
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public Packet getFrames(int count) {
/* 420 */       MKVDemuxer.MkvBlockData frameBlock = getFrameBlock(count);
/* 421 */       if (frameBlock == null) return null;
/*     */ 
/*     */       
/* 424 */       return Packet.createPacket(frameBlock.data, frameBlock.block.absoluteTimecode, this.demuxer.timescale, frameBlock.count, 0L, Packet.FrameType.KEY, TapeTimecode.ZERO_TAPE_TIMECODE);
/*     */     }
/*     */ 
/*     */     
/*     */     MKVDemuxer.MkvBlockData getFrameBlock(int count) {
/* 429 */       if (count + this.frameIdx >= this.framesCount)
/* 430 */         return null; 
/* 431 */       List<ByteBuffer> packetFrames = new ArrayList<ByteBuffer>();
/* 432 */       MkvBlock firstBlockInAPacket = ((MKVDemuxer.IndexedBlock)this.blocks.get(this.blockIdx)).block;
/* 433 */       while (count > 0) {
/* 434 */         MkvBlock b = ((MKVDemuxer.IndexedBlock)this.blocks.get(this.blockIdx)).block;
/* 435 */         if (b.frames == null || b.frames.length == 0) {
/*     */           
/*     */           try {
/*     */ 
/*     */ 
/*     */ 
/*     */             
/* 442 */             this.demuxer.channel.setPosition(b.dataOffset);
/* 443 */             ByteBuffer byteBuffer = ByteBuffer.allocate(b.dataLen);
/* 444 */             this.demuxer.channel.read(byteBuffer);
/* 445 */             b.readFrames(byteBuffer);
/* 446 */           } catch (IOException ioe) {
/* 447 */             throw new RuntimeException("while reading frames of a Block at offset 0x" + 
/* 448 */                 Long.toHexString(b.dataOffset).toUpperCase() + ")", ioe);
/*     */           } 
/*     */         }
/* 451 */         packetFrames.add(b.frames[this.frameInBlockIdx].duplicate());
/* 452 */         this.frameIdx++;
/* 453 */         this.frameInBlockIdx++;
/* 454 */         if (this.frameInBlockIdx >= b.frames.length) {
/* 455 */           this.frameInBlockIdx = 0;
/* 456 */           this.blockIdx++;
/*     */         } 
/* 458 */         count--;
/*     */       } 
/*     */       
/* 461 */       int size = 0;
/* 462 */       for (ByteBuffer aFrame : packetFrames) {
/* 463 */         size += aFrame.limit();
/*     */       }
/* 465 */       ByteBuffer data = ByteBuffer.allocate(size);
/* 466 */       for (ByteBuffer aFrame : packetFrames) {
/* 467 */         data.put(aFrame);
/*     */       }
/* 469 */       return new MKVDemuxer.MkvBlockData(firstBlockInAPacket, data, packetFrames.size());
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     public DemuxerTrackMeta getMeta() {
/* 475 */       return null;
/*     */     }
/*     */ 
/*     */     
/*     */     public boolean gotoSyncFrame(long frame) {
/* 480 */       return gotoFrame(frame);
/*     */     }
/*     */   }
/*     */   
/*     */   public static class AudioTrack extends MkvTrack {
/*     */     public double samplingFrequency;
/*     */     
/*     */     public AudioTrack(int trackNo, MKVDemuxer demuxer) {
/* 488 */       super(trackNo, demuxer);
/*     */     }
/*     */ 
/*     */     
/*     */     public Packet nextFrame() throws IOException {
/* 493 */       MKVDemuxer.MkvBlockData b = nextBlock();
/* 494 */       if (b == null) return null;
/*     */       
/* 496 */       return Packet.createPacket(b.data, b.block.absoluteTimecode, (int)Math.round(this.samplingFrequency), 1L, 0L, Packet.FrameType.KEY, TapeTimecode.ZERO_TAPE_TIMECODE);
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public Packet getFrames(int count) {
/* 507 */       MKVDemuxer.MkvBlockData frameBlock = getFrameBlock(count);
/* 508 */       if (frameBlock == null) return null;
/*     */       
/* 510 */       return Packet.createPacket(frameBlock.data, frameBlock.block.absoluteTimecode, (int)Math.round(this.samplingFrequency), frameBlock.count, 0L, Packet.FrameType.KEY, TapeTimecode.ZERO_TAPE_TIMECODE);
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     public DemuxerTrackMeta getMeta() {
/* 516 */       return null;
/*     */     }
/*     */ 
/*     */     
/*     */     public boolean gotoSyncFrame(long frame) {
/* 521 */       return gotoFrame(frame);
/*     */     }
/*     */   }
/*     */   
/*     */   public int getPictureWidth() {
/* 526 */     return this.pictureWidth;
/*     */   }
/*     */   
/*     */   public int getPictureHeight() {
/* 530 */     return this.pictureHeight;
/*     */   }
/*     */ 
/*     */   
/*     */   public List<DemuxerTrack> getAudioTracks() {
/* 535 */     return (List)this.aTracks;
/*     */   }
/*     */ 
/*     */   
/*     */   public List<DemuxerTrack> getTracks() {
/* 540 */     ArrayList<DemuxerTrack> tracks = new ArrayList(this.aTracks);
/* 541 */     tracks.add(this.vTrack);
/* 542 */     tracks.addAll(this.subsTracks);
/* 543 */     return tracks;
/*     */   }
/*     */ 
/*     */   
/*     */   public List<DemuxerTrack> getVideoTracks() {
/* 548 */     ArrayList<DemuxerTrack> tracks = new ArrayList<DemuxerTrack>();
/* 549 */     tracks.add(this.vTrack);
/* 550 */     return tracks;
/*     */   }
/*     */   
/*     */   public List<DemuxerTrack> getSubtitleTracks() {
/* 554 */     return (List)this.subsTracks;
/*     */   }
/*     */   
/*     */   public List<? extends EbmlBase> getTree() {
/* 558 */     return (List)this.t;
/*     */   }
/*     */ 
/*     */   
/*     */   public void close() throws IOException {
/* 563 */     this.channel.close();
/*     */   }
/*     */ }


/* Location:              C:\Users\rapha\Downloads\aurora.jar!\META-INF\jars\jcodec-0.2.5.jar!\org\jcodec\containers\mkv\demuxer\MKVDemuxer.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */