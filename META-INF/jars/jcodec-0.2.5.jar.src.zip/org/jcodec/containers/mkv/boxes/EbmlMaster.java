/*    */ package org.jcodec.containers.mkv.boxes;
/*    */ 
/*    */ import java.nio.ByteBuffer;
/*    */ import java.util.ArrayList;
/*    */ import org.jcodec.containers.mkv.util.EbmlUtil;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class EbmlMaster
/*    */   extends EbmlBase
/*    */ {
/*    */   protected long usedSize;
/*    */   public final ArrayList<EbmlBase> children;
/* 24 */   public static final byte[] CLUSTER_ID = new byte[] { 31, 67, -74, 117 };
/*    */   
/*    */   public EbmlMaster(byte[] id) {
/* 27 */     super(id);
/* 28 */     this.children = new ArrayList<EbmlBase>();
/* 29 */     this.id = id;
/*    */   }
/*    */   
/*    */   public void add(EbmlBase elem) {
/* 33 */     if (elem == null) {
/*    */       return;
/*    */     }
/* 36 */     elem.parent = this;
/* 37 */     this.children.add(elem);
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public ByteBuffer getData() {
/* 43 */     long size = getDataLen();
/*    */     
/* 45 */     if (size > 2147483647L)
/* 46 */       System.out.println("EbmlMaster.getData: id.length " + this.id.length + "  EbmlUtil.ebmlLength(" + size + "): " + EbmlUtil.ebmlLength(size) + " size: " + size); 
/* 47 */     ByteBuffer bb = ByteBuffer.allocate((int)((this.id.length + EbmlUtil.ebmlLength(size)) + size));
/*    */     
/* 49 */     bb.put(this.id);
/* 50 */     bb.put(EbmlUtil.ebmlEncode(size));
/*    */     
/* 52 */     for (int i = 0; i < this.children.size(); i++) {
/* 53 */       bb.put(((EbmlBase)this.children.get(i)).getData());
/*    */     }
/*    */     
/* 56 */     bb.flip();
/*    */     
/* 58 */     return bb;
/*    */   }
/*    */   
/*    */   protected long getDataLen() {
/* 62 */     if (this.children == null || this.children.isEmpty()) {
/* 63 */       return this.dataLen;
/*    */     }
/* 65 */     long dataLength = 0L;
/* 66 */     for (EbmlBase e : this.children)
/* 67 */       dataLength += e.size(); 
/* 68 */     return dataLength;
/*    */   }
/*    */ 
/*    */   
/*    */   public long size() {
/* 73 */     long size = getDataLen();
/*    */     
/* 75 */     size += EbmlUtil.ebmlLength(size);
/*    */     
/* 77 */     size += this.id.length;
/* 78 */     return size;
/*    */   }
/*    */ }


/* Location:              C:\Users\rapha\Downloads\aurora.jar!\META-INF\jars\jcodec-0.2.5.jar!\org\jcodec\containers\mkv\boxes\EbmlMaster.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */