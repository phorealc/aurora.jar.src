/*    */ package org.jcodec.containers.mkv.boxes;
/*    */ 
/*    */ import java.nio.ByteBuffer;
/*    */ import java.util.Date;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class EbmlDate
/*    */   extends EbmlSint
/*    */ {
/*    */   private static final int NANOSECONDS_IN_A_SECOND = 1000000000;
/*    */   private static final int MILISECONDS_IN_A_SECOND = 1000;
/*    */   private static final int NANOSECONDS_IN_A_MILISECOND = 1000000;
/* 17 */   public static long MILISECONDS_SINCE_UNIX_EPOCH_START = 978307200L;
/*    */   
/*    */   public EbmlDate(byte[] id) {
/* 20 */     super(id);
/*    */   }
/*    */   
/*    */   public void setDate(Date value) {
/* 24 */     setMiliseconds(value.getTime());
/*    */   }
/*    */   
/*    */   public Date getDate() {
/* 28 */     long val = getLong();
/* 29 */     val = val / 1000000L + MILISECONDS_SINCE_UNIX_EPOCH_START;
/* 30 */     return new Date(val);
/*    */   }
/*    */   
/*    */   private void setMiliseconds(long milliseconds) {
/* 34 */     setLong((milliseconds - MILISECONDS_SINCE_UNIX_EPOCH_START) * 1000000L);
/*    */   }
/*    */ 
/*    */   
/*    */   public void setLong(long value) {
/* 39 */     this.data = ByteBuffer.allocate(8);
/* 40 */     this.data.putLong(value);
/* 41 */     this.data.flip();
/*    */   }
/*    */ }


/* Location:              C:\Users\rapha\Downloads\aurora.jar!\META-INF\jars\jcodec-0.2.5.jar!\org\jcodec\containers\mkv\boxes\EbmlDate.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */