/*    */ package org.jcodec.containers.mkv.boxes;
/*    */ 
/*    */ import java.nio.ByteBuffer;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class EbmlFloat
/*    */   extends EbmlBin
/*    */ {
/*    */   public EbmlFloat(byte[] id) {
/* 16 */     super(id);
/*    */   }
/*    */   
/*    */   public void setDouble(double value) {
/* 20 */     if (value < 3.4028234663852886E38D) {
/* 21 */       ByteBuffer bb = ByteBuffer.allocate(4);
/* 22 */       bb.putFloat((float)value);
/* 23 */       bb.flip();
/* 24 */       this.data = bb;
/*    */     }
/* 26 */     else if (value < Double.MAX_VALUE) {
/* 27 */       ByteBuffer bb = ByteBuffer.allocate(8);
/* 28 */       bb.putDouble(value);
/* 29 */       bb.flip();
/* 30 */       this.data = bb;
/*    */     } 
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public double getDouble() {
/* 37 */     if (this.data.limit() == 4) {
/* 38 */       return this.data.duplicate().getFloat();
/*    */     }
/*    */     
/* 41 */     return this.data.duplicate().getDouble();
/*    */   }
/*    */ }


/* Location:              C:\Users\rapha\Downloads\aurora.jar!\META-INF\jars\jcodec-0.2.5.jar!\org\jcodec\containers\mkv\boxes\EbmlFloat.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */