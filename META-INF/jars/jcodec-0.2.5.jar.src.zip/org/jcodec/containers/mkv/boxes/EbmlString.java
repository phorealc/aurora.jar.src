/*    */ package org.jcodec.containers.mkv.boxes;
/*    */ 
/*    */ import java.io.UnsupportedEncodingException;
/*    */ import java.nio.ByteBuffer;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class EbmlString
/*    */   extends EbmlBin
/*    */ {
/* 14 */   public String charset = "UTF-8";
/*    */   
/*    */   public EbmlString(byte[] id) {
/* 17 */     super(id);
/*    */   }
/*    */   
/*    */   public static EbmlString createEbmlString(byte[] id, String value) {
/* 21 */     EbmlString e = new EbmlString(id);
/* 22 */     e.setString(value);
/* 23 */     return e;
/*    */   }
/*    */   
/*    */   public String getString() {
/*    */     try {
/* 28 */       return new String(this.data.array(), this.charset);
/* 29 */     } catch (UnsupportedEncodingException ex) {
/* 30 */       ex.printStackTrace();
/* 31 */       return "";
/*    */     } 
/*    */   }
/*    */   
/*    */   public void setString(String value) {
/*    */     try {
/* 37 */       this.data = ByteBuffer.wrap(value.getBytes(this.charset));
/* 38 */     } catch (UnsupportedEncodingException ex) {
/* 39 */       ex.printStackTrace();
/*    */     } 
/*    */   }
/*    */ }


/* Location:              C:\Users\rapha\Downloads\aurora.jar!\META-INF\jars\jcodec-0.2.5.jar!\org\jcodec\containers\mkv\boxes\EbmlString.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */