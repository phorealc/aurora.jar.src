/*    */ package org.jcodec.containers.mkv.boxes;
/*    */ 
/*    */ import java.nio.ByteBuffer;
/*    */ import org.jcodec.containers.mkv.util.EbmlUtil;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class EbmlSint
/*    */   extends EbmlBin
/*    */ {
/*    */   public EbmlSint(byte[] id) {
/* 17 */     super(id);
/*    */   }
/*    */   
/*    */   public void setLong(long value) {
/* 21 */     this.data = ByteBuffer.wrap(convertToBytes(value));
/*    */   }
/*    */   
/*    */   public long getLong() {
/* 25 */     if (this.data.limit() - this.data.position() == 8) {
/* 26 */       return this.data.duplicate().getLong();
/*    */     }
/* 28 */     byte[] b = this.data.array();
/* 29 */     long l = 0L;
/* 30 */     for (int i = b.length - 1; i >= 0; i--) {
/* 31 */       l |= (b[i] & 0xFFL) << 8 * (b.length - 1 - i);
/*    */     }
/* 33 */     return l;
/*    */   }
/*    */   
/*    */   public static int ebmlSignedLength(long val) {
/* 37 */     if (val <= 64L && val >= -63L)
/* 38 */       return 1; 
/* 39 */     if (val <= 8192L && val >= -8191L)
/* 40 */       return 2; 
/* 41 */     if (val <= 1048576L && val >= -1048575L)
/* 42 */       return 3; 
/* 43 */     if (val <= 134217728L && val >= -134217727L)
/* 44 */       return 4; 
/* 45 */     if (val <= 17179869184L && val >= -17179869183L)
/* 46 */       return 5; 
/* 47 */     if (val <= 2199023255552L && val >= -2199023255551L)
/* 48 */       return 6; 
/* 49 */     if (val <= 281474976710656L && val >= -281474976710655L) {
/* 50 */       return 7;
/*    */     }
/* 52 */     return 8;
/*    */   }
/*    */ 
/*    */   
/* 56 */   public static final long[] signedComplement = new long[] { 0L, 63L, 8191L, 1048575L, 134217727L, 17179869183L, 2199023255551L, 281474976710655L, 36028797018963967L };
/*    */   
/*    */   public static byte[] convertToBytes(long val) {
/* 59 */     int num = ebmlSignedLength(val);
/* 60 */     val += signedComplement[num];
/*    */     
/* 62 */     return EbmlUtil.ebmlEncodeLen(val, num);
/*    */   }
/*    */ }


/* Location:              C:\Users\rapha\Downloads\aurora.jar!\META-INF\jars\jcodec-0.2.5.jar!\org\jcodec\containers\mkv\boxes\EbmlSint.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */