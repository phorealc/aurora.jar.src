/*     */ package org.jcodec.containers.mkv.boxes;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.nio.ByteBuffer;
/*     */ import java.nio.channels.FileChannel;
/*     */ import java.util.Arrays;
/*     */ import org.jcodec.common.ByteArrayList;
/*     */ import org.jcodec.common.io.SeekableByteChannel;
/*     */ import org.jcodec.containers.mkv.util.EbmlUtil;
/*     */ import org.jcodec.platform.Platform;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class MkvBlock
/*     */   extends EbmlBin
/*     */ {
/*     */   private static final String XIPH = "Xiph";
/*     */   private static final String EBML = "EBML";
/*     */   private static final String FIXED = "Fixed";
/*     */   private static final int MAX_BLOCK_HEADER_SIZE = 512;
/*     */   public int[] frameOffsets;
/*     */   public int[] frameSizes;
/*     */   public long trackNumber;
/*     */   public int timecode;
/*     */   public long absoluteTimecode;
/*     */   public boolean _keyFrame;
/*     */   public int headerSize;
/*     */   public String lacing;
/*     */   public boolean discardable;
/*     */   public boolean lacingPresent;
/*     */   public ByteBuffer[] frames;
/*  42 */   public static final byte[] BLOCK_ID = new byte[] { -95 };
/*  43 */   public static final byte[] SIMPLEBLOCK_ID = new byte[] { -93 };
/*     */   
/*     */   public static MkvBlock copy(MkvBlock old) {
/*  46 */     MkvBlock be = new MkvBlock(old.id);
/*  47 */     be.trackNumber = old.trackNumber;
/*  48 */     be.timecode = old.timecode;
/*  49 */     be.absoluteTimecode = old.absoluteTimecode;
/*  50 */     be._keyFrame = old._keyFrame;
/*  51 */     be.headerSize = old.headerSize;
/*  52 */     be.lacing = old.lacing;
/*  53 */     be.discardable = old.discardable;
/*  54 */     be.lacingPresent = old.lacingPresent;
/*  55 */     be.frameOffsets = new int[old.frameOffsets.length];
/*  56 */     be.frameSizes = new int[old.frameSizes.length];
/*  57 */     be.dataOffset = old.dataOffset;
/*  58 */     be.offset = old.offset;
/*  59 */     be.type = old.type;
/*  60 */     System.arraycopy(old.frameOffsets, 0, be.frameOffsets, 0, be.frameOffsets.length);
/*  61 */     System.arraycopy(old.frameSizes, 0, be.frameSizes, 0, be.frameSizes.length);
/*  62 */     return be;
/*     */   }
/*     */   
/*     */   public static MkvBlock keyFrame(long trackNumber, int timecode, ByteBuffer frame) {
/*  66 */     MkvBlock be = new MkvBlock(SIMPLEBLOCK_ID);
/*  67 */     be.frames = new ByteBuffer[] { frame };
/*  68 */     be.frameSizes = new int[] { frame.limit() };
/*  69 */     be._keyFrame = true;
/*  70 */     be.trackNumber = trackNumber;
/*  71 */     be.timecode = timecode;
/*  72 */     return be;
/*     */   }
/*     */   
/*     */   public MkvBlock(byte[] type) {
/*  76 */     super(type);
/*  77 */     if (!Platform.arrayEqualsByte(SIMPLEBLOCK_ID, type) && !Platform.arrayEqualsByte(BLOCK_ID, type)) {
/*  78 */       throw new IllegalArgumentException("Block initiated with invalid id: " + EbmlUtil.toHexString(type));
/*     */     }
/*     */   }
/*     */   
/*     */   public void readChannel(SeekableByteChannel is) throws IOException {
/*  83 */     ByteBuffer bb = ByteBuffer.allocate(100);
/*  84 */     is.read(bb);
/*  85 */     bb.flip();
/*  86 */     read(bb);
/*  87 */     is.setPosition(this.dataOffset + this.dataLen);
/*     */   }
/*     */ 
/*     */   
/*     */   public void read(ByteBuffer source) {
/*  92 */     ByteBuffer bb = source.slice();
/*     */     
/*  94 */     this.trackNumber = ebmlDecode(bb);
/*  95 */     int tcPart1 = bb.get() & 0xFF;
/*  96 */     int tcPart2 = bb.get() & 0xFF;
/*  97 */     this.timecode = (short)((short)tcPart1 << 8 | (short)tcPart2);
/*     */     
/*  99 */     int flags = bb.get() & 0xFF;
/* 100 */     this._keyFrame = ((flags & 0x80) > 0);
/* 101 */     this.discardable = ((flags & 0x1) > 0);
/* 102 */     int laceFlags = flags & 0x6;
/*     */     
/* 104 */     this.lacingPresent = (laceFlags != 0);
/* 105 */     if (this.lacingPresent) {
/* 106 */       int lacesCount = bb.get() & 0xFF;
/* 107 */       this.frameSizes = new int[lacesCount + 1];
/* 108 */       if (laceFlags == 2) {
/*     */         
/* 110 */         this.lacing = "Xiph";
/* 111 */         this.headerSize = readXiphLaceSizes(bb, this.frameSizes, this.dataLen, bb.position());
/*     */       }
/* 113 */       else if (laceFlags == 6) {
/*     */         
/* 115 */         this.lacing = "EBML";
/* 116 */         this.headerSize = readEBMLLaceSizes(bb, this.frameSizes, this.dataLen, bb.position());
/*     */       }
/* 118 */       else if (laceFlags == 4) {
/*     */         
/* 120 */         this.lacing = "Fixed";
/* 121 */         this.headerSize = bb.position();
/* 122 */         int aLaceSize = (this.dataLen - this.headerSize) / (lacesCount + 1);
/* 123 */         Arrays.fill(this.frameSizes, aLaceSize);
/*     */       } else {
/*     */         
/* 126 */         throw new RuntimeException("Unsupported lacing type flag.");
/*     */       } 
/* 128 */       turnSizesToFrameOffsets(this.frameSizes);
/*     */     } else {
/*     */       
/* 131 */       this.lacing = "";
/* 132 */       int frameOffset = bb.position();
/* 133 */       this.frameOffsets = new int[1];
/* 134 */       this.frameOffsets[0] = frameOffset;
/*     */       
/* 136 */       this.headerSize = bb.position();
/*     */       
/* 138 */       this.frameSizes = new int[1];
/* 139 */       this.frameSizes[0] = this.dataLen - this.headerSize;
/*     */     } 
/*     */   }
/*     */   
/*     */   private void turnSizesToFrameOffsets(int[] sizes) {
/* 144 */     this.frameOffsets = new int[sizes.length];
/* 145 */     this.frameOffsets[0] = this.headerSize;
/* 146 */     for (int i = 1; i < sizes.length; i++) {
/* 147 */       this.frameOffsets[i] = this.frameOffsets[i - 1] + sizes[i - 1];
/*     */     }
/*     */   }
/*     */   
/*     */   public static int readXiphLaceSizes(ByteBuffer bb, int[] sizes, int size, int preLacingHeaderSize) {
/* 152 */     int startPos = bb.position();
/* 153 */     int lastIndex = sizes.length - 1;
/* 154 */     sizes[lastIndex] = size;
/*     */     
/* 156 */     for (int l = 0; l < lastIndex; l++) {
/* 157 */       int laceSize = 255;
/* 158 */       while (laceSize == 255) {
/* 159 */         laceSize = bb.get() & 0xFF;
/* 160 */         sizes[l] = sizes[l] + laceSize;
/*     */       } 
/*     */       
/* 163 */       sizes[lastIndex] = sizes[lastIndex] - sizes[l];
/*     */     } 
/*     */     
/* 166 */     int headerSize = bb.position() - startPos + preLacingHeaderSize;
/* 167 */     sizes[lastIndex] = sizes[lastIndex] - headerSize;
/*     */     
/* 169 */     return headerSize;
/*     */   }
/*     */ 
/*     */   
/*     */   public static int readEBMLLaceSizes(ByteBuffer source, int[] sizes, int size, int preLacingHeaderSize) {
/* 174 */     int lastIndex = sizes.length - 1;
/* 175 */     sizes[lastIndex] = size;
/*     */     
/* 177 */     int startPos = source.position();
/* 178 */     sizes[0] = (int)ebmlDecode(source);
/*     */     
/* 180 */     sizes[lastIndex] = sizes[lastIndex] - sizes[0];
/*     */     
/* 182 */     int laceSize = sizes[0];
/* 183 */     long laceSizeDiff = 0L;
/* 184 */     for (int l = 1; l < lastIndex; l++) {
/* 185 */       laceSizeDiff = ebmlDecodeSigned(source);
/*     */       
/* 187 */       laceSize = (int)(laceSize + laceSizeDiff);
/* 188 */       sizes[l] = laceSize;
/*     */ 
/*     */       
/* 191 */       sizes[lastIndex] = sizes[lastIndex] - sizes[l];
/*     */     } 
/*     */     
/* 194 */     int headerSize = source.position() - startPos + preLacingHeaderSize;
/* 195 */     sizes[lastIndex] = sizes[lastIndex] - headerSize;
/* 196 */     return headerSize;
/*     */   }
/*     */ 
/*     */   
/*     */   public String toString() {
/* 201 */     StringBuilder sb = new StringBuilder();
/* 202 */     sb.append("{dataOffset: ").append(this.dataOffset);
/* 203 */     sb.append(", trackNumber: ").append(this.trackNumber);
/* 204 */     sb.append(", timecode: ").append(this.timecode);
/* 205 */     sb.append(", keyFrame: ").append(this._keyFrame);
/* 206 */     sb.append(", headerSize: ").append(this.headerSize);
/* 207 */     sb.append(", lacing: ").append(this.lacing);
/* 208 */     for (int i = 0; i < this.frameSizes.length; i++) {
/* 209 */       sb.append(", frame[").append(i).append("]  offset ").append(this.frameOffsets[i]).append(" size ").append(this.frameSizes[i]);
/*     */     }
/* 211 */     sb.append(" }");
/*     */     
/* 213 */     return sb.toString();
/*     */   }
/*     */   
/*     */   public ByteBuffer[] getFrames(ByteBuffer source) throws IOException {
/* 217 */     ByteBuffer[] frames = new ByteBuffer[this.frameSizes.length];
/* 218 */     for (int i = 0; i < this.frameSizes.length; i++) {
/* 219 */       if (this.frameOffsets[i] > source.limit())
/* 220 */         System.err.println("frame offset: " + this.frameOffsets[i] + " limit: " + source.limit()); 
/* 221 */       source.position(this.frameOffsets[i]);
/* 222 */       ByteBuffer bb = source.slice();
/* 223 */       bb.limit(this.frameSizes[i]);
/* 224 */       frames[i] = bb;
/*     */     } 
/* 226 */     return frames;
/*     */   }
/*     */   
/*     */   public void readFrames(ByteBuffer source) throws IOException {
/* 230 */     this.frames = getFrames(source);
/*     */   }
/*     */ 
/*     */   
/*     */   public ByteBuffer getData() {
/* 235 */     int dataSize = getDataSize();
/* 236 */     ByteBuffer bb = ByteBuffer.allocate(dataSize + EbmlUtil.ebmlLength(dataSize) + this.id.length);
/* 237 */     bb.put(this.id);
/* 238 */     bb.put(EbmlUtil.ebmlEncode(dataSize));
/*     */     
/* 240 */     bb.put(EbmlUtil.ebmlEncode(this.trackNumber));
/* 241 */     bb.put((byte)(this.timecode >>> 8 & 0xFF));
/* 242 */     bb.put((byte)(this.timecode & 0xFF));
/*     */     
/* 244 */     byte flags = 0;
/* 245 */     if ("Xiph".equals(this.lacing)) {
/* 246 */       flags = 2;
/* 247 */     } else if ("EBML".equals(this.lacing)) {
/* 248 */       flags = 6;
/* 249 */     } else if ("Fixed".equals(this.lacing)) {
/* 250 */       flags = 4;
/*     */     } 
/*     */     
/* 253 */     if (this.discardable)
/* 254 */       flags = (byte)(flags | 0x1); 
/* 255 */     if (this._keyFrame) {
/* 256 */       flags = (byte)(flags | 0x80);
/*     */     }
/* 258 */     bb.put(flags);
/*     */     
/* 260 */     if ((flags & 0x6) != 0) {
/* 261 */       bb.put((byte)(this.frames.length - 1 & 0xFF));
/* 262 */       bb.put(muxLacingInfo());
/*     */     } 
/*     */     
/* 265 */     for (int i = 0; i < this.frames.length; i++) {
/* 266 */       ByteBuffer frame = this.frames[i];
/* 267 */       bb.put(frame);
/*     */     } 
/*     */     
/* 270 */     bb.flip();
/* 271 */     return bb;
/*     */   }
/*     */   
/*     */   public void seekAndReadContent(FileChannel source) throws IOException {
/* 275 */     this.data = ByteBuffer.allocate(this.dataLen);
/* 276 */     source.position(this.dataOffset);
/* 277 */     source.read(this.data);
/* 278 */     this.data.flip();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public long size() {
/* 286 */     long size = getDataSize();
/* 287 */     size += EbmlUtil.ebmlLength(size);
/* 288 */     size += this.id.length;
/* 289 */     return size;
/*     */   }
/*     */   
/*     */   public int getDataSize() {
/* 293 */     int size = 0; int arrayOfInt[], i;
/*     */     byte b;
/* 295 */     for (arrayOfInt = this.frameSizes, i = arrayOfInt.length, b = 0; b < i; ) { long fsize = arrayOfInt[b];
/* 296 */       size = (int)(size + fsize); b++; }
/*     */     
/* 298 */     if (this.lacingPresent) {
/* 299 */       size += (muxLacingInfo()).length;
/* 300 */       size++;
/*     */     } 
/*     */     
/* 303 */     size += 3;
/* 304 */     size += EbmlUtil.ebmlLength(this.trackNumber);
/* 305 */     return size;
/*     */   }
/*     */   
/*     */   private byte[] muxLacingInfo() {
/* 309 */     if ("EBML".equals(this.lacing)) {
/* 310 */       return muxEbmlLacing(this.frameSizes);
/*     */     }
/* 312 */     if ("Xiph".equals(this.lacing)) {
/* 313 */       return muxXiphLacing(this.frameSizes);
/*     */     }
/* 315 */     if ("Fixed".equals(this.lacing)) {
/* 316 */       return new byte[0];
/*     */     }
/* 318 */     return null;
/*     */   }
/*     */   
/*     */   public static long ebmlDecode(ByteBuffer bb) {
/* 322 */     byte firstByte = bb.get();
/* 323 */     int length = EbmlUtil.computeLength(firstByte);
/* 324 */     if (length == 0) {
/* 325 */       throw new RuntimeException("Invalid ebml integer size.");
/*     */     }
/* 327 */     long value = (firstByte & 255 >>> length);
/*     */     
/* 329 */     length--;
/* 330 */     while (length > 0) {
/* 331 */       value = value << 8L | (bb.get() & 0xFF);
/* 332 */       length--;
/*     */     } 
/*     */     
/* 335 */     return value;
/*     */   }
/*     */   
/*     */   public static long ebmlDecodeSigned(ByteBuffer source) {
/* 339 */     byte firstByte = source.get();
/* 340 */     int size = EbmlUtil.computeLength(firstByte);
/*     */     
/* 342 */     if (size == 0) {
/* 343 */       throw new RuntimeException("Invalid ebml integer size.");
/*     */     }
/* 345 */     long value = (firstByte & 255 >>> size);
/* 346 */     int remaining = size - 1;
/* 347 */     while (remaining > 0) {
/* 348 */       value = value << 8L | (source.get() & 0xFF);
/* 349 */       remaining--;
/*     */     } 
/*     */     
/* 352 */     return value - EbmlSint.signedComplement[size];
/*     */   }
/*     */   
/*     */   public static long[] calcEbmlLacingDiffs(int[] laceSizes) {
/* 356 */     int lacesCount = laceSizes.length - 1;
/* 357 */     long[] out = new long[lacesCount];
/* 358 */     out[0] = laceSizes[0];
/* 359 */     for (int i = 1; i < lacesCount; i++) {
/* 360 */       out[i] = (laceSizes[i] - laceSizes[i - 1]);
/*     */     }
/* 362 */     return out;
/*     */   }
/*     */   
/*     */   public static byte[] muxEbmlLacing(int[] laceSizes) {
/* 366 */     ByteArrayList bytes = ByteArrayList.createByteArrayList();
/*     */     
/* 368 */     long[] laceSizeDiffs = calcEbmlLacingDiffs(laceSizes);
/* 369 */     bytes.addAll(EbmlUtil.ebmlEncode(laceSizeDiffs[0]));
/*     */     
/* 371 */     for (int i = 1; i < laceSizeDiffs.length; i++) {
/* 372 */       bytes.addAll(EbmlSint.convertToBytes(laceSizeDiffs[i]));
/*     */     }
/* 374 */     return bytes.toArray();
/*     */   }
/*     */   
/*     */   public static byte[] muxXiphLacing(int[] laceSizes) {
/* 378 */     ByteArrayList bytes = ByteArrayList.createByteArrayList();
/* 379 */     for (int i = 0; i < laceSizes.length - 1; i++) {
/* 380 */       long laceSize = laceSizes[i];
/* 381 */       while (laceSize >= 255L) {
/* 382 */         bytes.add((byte)-1);
/* 383 */         laceSize -= 255L;
/*     */       } 
/* 385 */       bytes.add((byte)(int)laceSize);
/*     */     } 
/* 387 */     return bytes.toArray();
/*     */   }
/*     */ }


/* Location:              C:\Users\rapha\Downloads\aurora.jar!\META-INF\jars\jcodec-0.2.5.jar!\org\jcodec\containers\mkv\boxes\MkvBlock.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */