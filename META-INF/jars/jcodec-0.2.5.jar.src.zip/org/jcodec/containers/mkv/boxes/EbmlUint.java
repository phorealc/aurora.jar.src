/*    */ package org.jcodec.containers.mkv.boxes;
/*    */ 
/*    */ import java.nio.ByteBuffer;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class EbmlUint
/*    */   extends EbmlBin
/*    */ {
/*    */   public EbmlUint(byte[] id) {
/* 15 */     super(id);
/*    */   }
/*    */   
/*    */   public static EbmlUint createEbmlUint(byte[] id, long value) {
/* 19 */     EbmlUint e = new EbmlUint(id);
/* 20 */     e.setUint(value);
/* 21 */     return e;
/*    */   }
/*    */   
/*    */   public void setUint(long value) {
/* 25 */     this.data = ByteBuffer.wrap(longToBytes(value));
/* 26 */     this.dataLen = this.data.limit();
/*    */   }
/*    */   
/*    */   public long getUint() {
/* 30 */     long l = 0L;
/* 31 */     long tmp = 0L;
/* 32 */     for (int i = 0; i < this.data.limit(); i++) {
/* 33 */       tmp = this.data.get(this.data.limit() - 1 - i) << 56L;
/* 34 */       tmp >>>= 56 - i * 8;
/* 35 */       l |= tmp;
/*    */     } 
/* 37 */     return l;
/*    */   }
/*    */   
/*    */   public static byte[] longToBytes(long value) {
/* 41 */     byte[] b = new byte[calculatePayloadSize(value)];
/* 42 */     for (int i = b.length - 1; i >= 0; i--) {
/* 43 */       b[i] = (byte)(int)(value >>> 8 * (b.length - i - 1));
/*    */     }
/* 45 */     return b;
/*    */   }
/*    */   
/*    */   public static int calculatePayloadSize(long value) {
/* 49 */     if (value == 0L)
/* 50 */       return 1; 
/* 51 */     if (value <= 2147483647L) {
/* 52 */       return 4 - (Integer.numberOfLeadingZeros((int)value) >> 3);
/*    */     }
/* 54 */     return 8 - (Long.numberOfLeadingZeros(value) >> 3);
/*    */   }
/*    */ }


/* Location:              C:\Users\rapha\Downloads\aurora.jar!\META-INF\jars\jcodec-0.2.5.jar!\org\jcodec\containers\mkv\boxes\EbmlUint.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */