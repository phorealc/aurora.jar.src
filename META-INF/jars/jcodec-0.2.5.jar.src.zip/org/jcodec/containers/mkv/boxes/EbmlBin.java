/*    */ package org.jcodec.containers.mkv.boxes;
/*    */ 
/*    */ import java.io.IOException;
/*    */ import java.nio.ByteBuffer;
/*    */ import org.jcodec.common.io.SeekableByteChannel;
/*    */ import org.jcodec.containers.mkv.util.EbmlUtil;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class EbmlBin
/*    */   extends EbmlBase
/*    */ {
/*    */   public ByteBuffer data;
/*    */   protected boolean dataRead = false;
/*    */   
/*    */   public EbmlBin(byte[] id) {
/* 22 */     super(id);
/*    */   }
/*    */   
/*    */   public void readChannel(SeekableByteChannel is) throws IOException {
/* 26 */     ByteBuffer bb = ByteBuffer.allocate(this.dataLen);
/* 27 */     is.read(bb);
/* 28 */     bb.flip();
/* 29 */     read(bb);
/*    */   }
/*    */   
/*    */   public void read(ByteBuffer source) {
/* 33 */     this.data = source.slice();
/* 34 */     this.data.limit(this.dataLen);
/* 35 */     this.dataRead = true;
/*    */   }
/*    */   
/*    */   public void skip(ByteBuffer source) {
/* 39 */     if (!this.dataRead) {
/* 40 */       source.position((int)(this.dataOffset + this.dataLen));
/* 41 */       this.dataRead = true;
/*    */     } 
/*    */   }
/*    */   
/*    */   public long size() {
/* 46 */     if (this.data == null || this.data.limit() == 0) {
/* 47 */       return super.size();
/*    */     }
/* 49 */     long totalSize = this.data.limit();
/* 50 */     totalSize += EbmlUtil.ebmlLength(this.data.limit());
/* 51 */     totalSize += this.id.length;
/* 52 */     return totalSize;
/*    */   }
/*    */   
/*    */   public void setBuf(ByteBuffer data) {
/* 56 */     this.data = data.slice();
/* 57 */     this.dataLen = this.data.limit();
/*    */   }
/*    */   
/*    */   public ByteBuffer getData() {
/* 61 */     int sizeSize = EbmlUtil.ebmlLength(this.data.limit());
/* 62 */     byte[] size = EbmlUtil.ebmlEncodeLen(this.data.limit(), sizeSize);
/*    */     
/* 64 */     ByteBuffer bb = ByteBuffer.allocate(this.id.length + sizeSize + this.data.limit());
/* 65 */     bb.put(this.id);
/* 66 */     bb.put(size);
/* 67 */     bb.put(this.data);
/*    */     
/* 69 */     bb.flip();
/* 70 */     this.data.flip();
/*    */     
/* 72 */     return bb;
/*    */   }
/*    */ }


/* Location:              C:\Users\rapha\Downloads\aurora.jar!\META-INF\jars\jcodec-0.2.5.jar!\org\jcodec\containers\mkv\boxes\EbmlBin.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */