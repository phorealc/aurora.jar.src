/*    */ package org.jcodec.containers.mkv.boxes;
/*    */ 
/*    */ import java.nio.ByteBuffer;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class EbmlUlong
/*    */   extends EbmlBin
/*    */ {
/*    */   public EbmlUlong(byte[] id) {
/* 16 */     super(id);
/* 17 */     this.data = ByteBuffer.allocate(8);
/*    */   }
/*    */   
/*    */   public static EbmlUlong createEbmlUlong(byte[] id, long value) {
/* 21 */     EbmlUlong e = new EbmlUlong(id);
/* 22 */     e.setUlong(value);
/* 23 */     return e;
/*    */   }
/*    */   
/*    */   public void setUlong(long value) {
/* 27 */     this.data.putLong(value);
/* 28 */     this.data.flip();
/*    */   }
/*    */   
/*    */   public long getUlong() {
/* 32 */     return this.data.duplicate().getLong();
/*    */   }
/*    */ }


/* Location:              C:\Users\rapha\Downloads\aurora.jar!\META-INF\jars\jcodec-0.2.5.jar!\org\jcodec\containers\mkv\boxes\EbmlUlong.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */