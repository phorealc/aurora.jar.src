/*    */ package org.jcodec.containers.mkv.boxes;
/*    */ 
/*    */ import java.io.IOException;
/*    */ import java.nio.ByteBuffer;
/*    */ import org.jcodec.common.UsedViaReflection;
/*    */ import org.jcodec.common.io.SeekableByteChannel;
/*    */ import org.jcodec.containers.mkv.MKVType;
/*    */ import org.jcodec.containers.mkv.util.EbmlUtil;
/*    */ import org.jcodec.platform.Platform;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public abstract class EbmlBase
/*    */ {
/*    */   protected EbmlMaster parent;
/*    */   public MKVType type;
/*    */   public byte[] id;
/* 24 */   public int dataLen = 0;
/*    */   public long offset;
/*    */   public long dataOffset;
/*    */   public int typeSizeLength;
/*    */   
/*    */   @UsedViaReflection
/*    */   public EbmlBase(byte[] id) {
/* 31 */     this.id = id;
/*    */   }
/*    */   
/*    */   public boolean equalId(byte[] typeId) {
/* 35 */     return Platform.arrayEqualsByte(this.id, typeId);
/*    */   }
/*    */   
/*    */   public abstract ByteBuffer getData();
/*    */   
/*    */   public long size() {
/* 41 */     return (this.dataLen + EbmlUtil.ebmlLength(this.dataLen) + this.id.length);
/*    */   }
/*    */   
/*    */   public long mux(SeekableByteChannel os) throws IOException {
/* 45 */     ByteBuffer bb = getData();
/* 46 */     return os.write(bb);
/*    */   }
/*    */ }


/* Location:              C:\Users\rapha\Downloads\aurora.jar!\META-INF\jars\jcodec-0.2.5.jar!\org\jcodec\containers\mkv\boxes\EbmlBase.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */