/*    */ package org.jcodec.containers.mkv.boxes;
/*    */ 
/*    */ import java.nio.ByteBuffer;
/*    */ import org.jcodec.containers.mkv.util.EbmlUtil;
/*    */ import org.jcodec.platform.Platform;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class MkvSegment
/*    */   extends EbmlMaster
/*    */ {
/* 24 */   int headerSize = 0;
/* 25 */   public static final byte[] SEGMENT_ID = new byte[] { 24, 83, Byte.MIN_VALUE, 103 };
/*    */   
/*    */   public MkvSegment(byte[] id) {
/* 28 */     super(id);
/*    */   }
/*    */   
/*    */   public static MkvSegment createMkvSegment() {
/* 32 */     return new MkvSegment(SEGMENT_ID);
/*    */   }
/*    */   
/*    */   public ByteBuffer getHeader() {
/* 36 */     long headerSize = getHeaderSize();
/*    */     
/* 38 */     if (headerSize > 2147483647L)
/* 39 */       System.out.println("MkvSegment.getHeader: id.length " + this.id.length + "  Element.getEbmlSize(" + this.dataLen + "): " + EbmlUtil.ebmlLength(this.dataLen) + " size: " + this.dataLen); 
/* 40 */     ByteBuffer bb = ByteBuffer.allocate((int)headerSize);
/*    */     
/* 42 */     bb.put(this.id);
/* 43 */     bb.put(EbmlUtil.ebmlEncode(getDataLen()));
/*    */     
/* 45 */     if (this.children != null && !this.children.isEmpty())
/*    */     {
/* 47 */       for (EbmlBase e : this.children) {
/* 48 */         if (Platform.arrayEqualsByte(CLUSTER_ID, e.type.id)) {
/*    */           continue;
/*    */         }
/* 51 */         bb.put(e.getData());
/*    */       } 
/*    */     }
/*    */     
/* 55 */     bb.flip();
/*    */     
/* 57 */     return bb;
/*    */   }
/*    */   
/*    */   public long getHeaderSize() {
/* 61 */     long returnValue = this.id.length;
/* 62 */     returnValue += EbmlUtil.ebmlLength(getDataLen());
/* 63 */     if (this.children != null && !this.children.isEmpty()) {
/* 64 */       for (EbmlBase e : this.children) {
/* 65 */         if (Platform.arrayEqualsByte(CLUSTER_ID, e.type.id)) {
/*    */           continue;
/*    */         }
/* 68 */         returnValue += e.size();
/*    */       } 
/*    */     }
/*    */     
/* 72 */     return returnValue;
/*    */   }
/*    */ }


/* Location:              C:\Users\rapha\Downloads\aurora.jar!\META-INF\jars\jcodec-0.2.5.jar!\org\jcodec\containers\mkv\boxes\MkvSegment.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */