/*    */ package org.jcodec.containers.mkv.boxes;
/*    */ 
/*    */ import java.io.IOException;
/*    */ import java.nio.ByteBuffer;
/*    */ import org.jcodec.common.io.SeekableByteChannel;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class EbmlVoid
/*    */   extends EbmlBase
/*    */ {
/*    */   public EbmlVoid(byte[] id) {
/* 17 */     super(id);
/*    */   }
/*    */ 
/*    */   
/*    */   public ByteBuffer getData() {
/* 22 */     return null;
/*    */   }
/*    */   
/*    */   public void skip(SeekableByteChannel is) throws IOException {
/* 26 */     is.setPosition(this.dataOffset + this.dataLen);
/*    */   }
/*    */ }


/* Location:              C:\Users\rapha\Downloads\aurora.jar!\META-INF\jars\jcodec-0.2.5.jar!\org\jcodec\containers\mkv\boxes\EbmlVoid.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */