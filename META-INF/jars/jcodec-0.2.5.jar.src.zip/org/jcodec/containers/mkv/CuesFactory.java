/*     */ package org.jcodec.containers.mkv;
/*     */ 
/*     */ import java.util.ArrayList;
/*     */ import java.util.List;
/*     */ import org.jcodec.containers.mkv.boxes.EbmlBase;
/*     */ import org.jcodec.containers.mkv.boxes.EbmlMaster;
/*     */ import org.jcodec.containers.mkv.boxes.EbmlUint;
/*     */ import org.jcodec.containers.mkv.util.EbmlUtil;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class CuesFactory
/*     */ {
/*     */   List<CuePointMock> a;
/*     */   private final long offsetBase;
/*  33 */   private long currentDataOffset = 0L;
/*     */   private long videoTrackNr;
/*     */   
/*     */   public CuesFactory(long offset, long videoTrack) {
/*  37 */     this.a = new ArrayList<CuePointMock>();
/*  38 */     this.offsetBase = offset;
/*  39 */     this.videoTrackNr = videoTrack;
/*  40 */     this.currentDataOffset += this.offsetBase;
/*     */   }
/*     */   
/*     */   public void addFixedSize(CuePointMock z) {
/*  44 */     z.elementOffset = this.currentDataOffset;
/*  45 */     z.cueClusterPositionSize = 8;
/*  46 */     this.currentDataOffset += z.size;
/*  47 */     this.a.add(z);
/*     */   }
/*     */   
/*     */   public void add(CuePointMock z) {
/*  51 */     z.elementOffset = this.currentDataOffset;
/*  52 */     z.cueClusterPositionSize = EbmlUint.calculatePayloadSize(z.elementOffset);
/*  53 */     this.currentDataOffset += z.size;
/*  54 */     this.a.add(z);
/*     */   }
/*     */   
/*     */   public EbmlMaster createCues() {
/*  58 */     int estimatedSize = computeCuesSize();
/*  59 */     EbmlMaster cues = MKVType.<EbmlMaster>createByType(MKVType.Cues);
/*  60 */     for (CuePointMock cpm : this.a) {
/*  61 */       EbmlMaster cuePoint = MKVType.<EbmlMaster>createByType(MKVType.CuePoint);
/*     */       
/*  63 */       EbmlUint cueTime = MKVType.<EbmlUint>createByType(MKVType.CueTime);
/*  64 */       cueTime.setUint(cpm.timecode);
/*  65 */       cuePoint.add((EbmlBase)cueTime);
/*     */       
/*  67 */       EbmlMaster cueTrackPositions = MKVType.<EbmlMaster>createByType(MKVType.CueTrackPositions);
/*     */       
/*  69 */       EbmlUint cueTrack = MKVType.<EbmlUint>createByType(MKVType.CueTrack);
/*  70 */       cueTrack.setUint(this.videoTrackNr);
/*  71 */       cueTrackPositions.add((EbmlBase)cueTrack);
/*     */       
/*  73 */       EbmlUint cueClusterPosition = MKVType.<EbmlUint>createByType(MKVType.CueClusterPosition);
/*  74 */       cueClusterPosition.setUint(cpm.elementOffset + estimatedSize);
/*  75 */       if (cueClusterPosition.data.limit() != cpm.cueClusterPositionSize)
/*  76 */         System.err.println("estimated size of CueClusterPosition differs from the one actually used. ElementId: " + EbmlUtil.toHexString(cpm.id) + " " + cueClusterPosition.getData().limit() + " vs " + cpm.cueClusterPositionSize); 
/*  77 */       cueTrackPositions.add((EbmlBase)cueClusterPosition);
/*     */       
/*  79 */       cuePoint.add((EbmlBase)cueTrackPositions);
/*     */       
/*  81 */       cues.add((EbmlBase)cuePoint);
/*     */     } 
/*  83 */     return cues;
/*     */   }
/*     */   
/*     */   public int computeCuesSize() {
/*  87 */     int cuesSize = estimateSize();
/*  88 */     boolean reindex = false;
/*     */     while (true) {
/*  90 */       reindex = false;
/*  91 */       for (CuePointMock z : this.a) {
/*  92 */         int minByteSize = EbmlUint.calculatePayloadSize(z.elementOffset + cuesSize);
/*  93 */         if (minByteSize > z.cueClusterPositionSize) {
/*  94 */           System.out.println(minByteSize + ">" + z.cueClusterPositionSize);
/*  95 */           System.err.println("Size " + cuesSize + " seems too small for element " + EbmlUtil.toHexString(z.id) + " increasing size by one.");
/*  96 */           z.cueClusterPositionSize++;
/*  97 */           cuesSize++;
/*  98 */           reindex = true; break;
/*     */         } 
/* 100 */         if (minByteSize < z.cueClusterPositionSize) {
/* 101 */           throw new RuntimeException("Downsizing the index is not well thought through");
/*     */         }
/*     */       } 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 111 */       if (!reindex)
/* 112 */         return cuesSize; 
/*     */     } 
/*     */   }
/*     */   public int estimateFixedSize(int numberOfClusters) {
/* 116 */     int s = 34 * numberOfClusters;
/*     */ 
/*     */ 
/*     */     
/* 120 */     s += MKVType.Cues.id.length + EbmlUtil.ebmlLength(s);
/* 121 */     return s;
/*     */   }
/*     */   
/*     */   public int estimateSize() {
/* 125 */     int s = 0;
/* 126 */     for (CuePointMock cpm : this.a) {
/* 127 */       s += estimateCuePointSize(EbmlUint.calculatePayloadSize(cpm.timecode), EbmlUint.calculatePayloadSize(this.videoTrackNr), EbmlUint.calculatePayloadSize(cpm.elementOffset));
/*     */     }
/* 129 */     s += MKVType.Cues.id.length + EbmlUtil.ebmlLength(s);
/* 130 */     return s;
/*     */   }
/*     */   
/*     */   public static int estimateCuePointSize(int timecodeSizeInBytes, int trackNrSizeInBytes, int clusterPositionSizeInBytes) {
/* 134 */     int cueTimeSize = MKVType.CueTime.id.length + EbmlUtil.ebmlLength(timecodeSizeInBytes) + timecodeSizeInBytes;
/*     */     
/* 136 */     int cueTrackPositionSize = MKVType.CueTrack.id.length + EbmlUtil.ebmlLength(trackNrSizeInBytes) + trackNrSizeInBytes + MKVType.CueClusterPosition.id.length + EbmlUtil.ebmlLength(clusterPositionSizeInBytes) + clusterPositionSizeInBytes;
/* 137 */     cueTrackPositionSize += MKVType.CueTrackPositions.id.length + EbmlUtil.ebmlLength(cueTrackPositionSize);
/*     */     
/* 139 */     int cuePointSize = MKVType.CuePoint.id.length + EbmlUtil.ebmlLength((cueTimeSize + cueTrackPositionSize)) + cueTimeSize + cueTrackPositionSize;
/* 140 */     return cuePointSize;
/*     */   }
/*     */   
/*     */   public static class CuePointMock
/*     */   {
/*     */     public int cueClusterPositionSize;
/*     */     public long elementOffset;
/*     */     private long timecode;
/*     */     private long size;
/*     */     private byte[] id;
/*     */     
/*     */     public static CuePointMock make(EbmlMaster c) {
/* 152 */       MKVType[] path = { MKVType.Cluster, MKVType.Timecode };
/* 153 */       EbmlUint tc = (EbmlUint)MKVType.findFirst((EbmlBase)c, path);
/* 154 */       return doMake(c.id, tc.getUint(), c.size());
/*     */     }
/*     */     
/*     */     public static CuePointMock doMake(byte[] id, long timecode, long size) {
/* 158 */       CuePointMock mock = new CuePointMock();
/* 159 */       mock.id = id;
/* 160 */       mock.timecode = timecode;
/* 161 */       mock.size = size;
/* 162 */       return mock;
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\rapha\Downloads\aurora.jar!\META-INF\jars\jcodec-0.2.5.jar!\org\jcodec\containers\mkv\CuesFactory.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */