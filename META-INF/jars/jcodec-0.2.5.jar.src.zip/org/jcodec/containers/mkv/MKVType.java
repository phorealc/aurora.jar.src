/*     */ package org.jcodec.containers.mkv;
/*     */ 
/*     */ import java.lang.reflect.Array;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Arrays;
/*     */ import java.util.Collection;
/*     */ import java.util.HashMap;
/*     */ import java.util.HashSet;
/*     */ import java.util.Iterator;
/*     */ import java.util.LinkedList;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import java.util.Set;
/*     */ import org.jcodec.containers.mkv.boxes.EbmlBase;
/*     */ import org.jcodec.containers.mkv.boxes.EbmlBin;
/*     */ import org.jcodec.containers.mkv.boxes.EbmlDate;
/*     */ import org.jcodec.containers.mkv.boxes.EbmlFloat;
/*     */ import org.jcodec.containers.mkv.boxes.EbmlMaster;
/*     */ import org.jcodec.containers.mkv.boxes.EbmlSint;
/*     */ import org.jcodec.containers.mkv.boxes.EbmlString;
/*     */ import org.jcodec.containers.mkv.boxes.EbmlUint;
/*     */ import org.jcodec.containers.mkv.boxes.EbmlVoid;
/*     */ import org.jcodec.containers.mkv.boxes.MkvBlock;
/*     */ import org.jcodec.containers.mkv.boxes.MkvSegment;
/*     */ import org.jcodec.containers.mkv.util.EbmlUtil;
/*     */ import org.jcodec.platform.Platform;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class MKVType
/*     */ {
/*  41 */   private static final List<MKVType> _values = new ArrayList<MKVType>();
/*     */   
/*  43 */   public static final MKVType Void = new MKVType("Void", new byte[] { -20 }, (Class)EbmlVoid.class);
/*  44 */   public static final MKVType CRC32 = new MKVType("CRC32", new byte[] { -65 }, (Class)EbmlBin.class);
/*  45 */   public static final MKVType EBML = new MKVType("EBML", new byte[] { 26, 69, -33, -93 }, (Class)EbmlMaster.class);
/*  46 */   public static final MKVType EBMLVersion = new MKVType("EBMLVersion", new byte[] { 66, -122 }, (Class)EbmlUint.class);
/*  47 */   public static final MKVType EBMLReadVersion = new MKVType("EBMLReadVersion", new byte[] { 66, -9 }, (Class)EbmlUint.class);
/*  48 */   public static final MKVType EBMLMaxIDLength = new MKVType("EBMLMaxIDLength", new byte[] { 66, -14 }, (Class)EbmlUint.class);
/*  49 */   public static final MKVType EBMLMaxSizeLength = new MKVType("EBMLMaxSizeLength", new byte[] { 66, -13 }, (Class)EbmlUint.class);
/*     */   
/*  51 */   public static final MKVType DocType = new MKVType("DocType", new byte[] { 66, -126 }, (Class)EbmlString.class);
/*  52 */   public static final MKVType DocTypeVersion = new MKVType("DocTypeVersion", new byte[] { 66, -121 }, (Class)EbmlUint.class);
/*  53 */   public static final MKVType DocTypeReadVersion = new MKVType("DocTypeReadVersion", new byte[] { 66, -123 }, (Class)EbmlUint.class);
/*     */   
/*  55 */   public static final MKVType Segment = new MKVType("Segment", MkvSegment.SEGMENT_ID, (Class)MkvSegment.class);
/*  56 */   public static final MKVType SeekHead = new MKVType("SeekHead", new byte[] { 17, 77, -101, 116 }, (Class)EbmlMaster.class);
/*  57 */   public static final MKVType Seek = new MKVType("Seek", new byte[] { 77, -69 }, (Class)EbmlMaster.class);
/*  58 */   public static final MKVType SeekID = new MKVType("SeekID", new byte[] { 83, -85 }, (Class)EbmlBin.class);
/*  59 */   public static final MKVType SeekPosition = new MKVType("SeekPosition", new byte[] { 83, -84 }, (Class)EbmlUint.class);
/*  60 */   public static final MKVType Info = new MKVType("Info", new byte[] { 21, 73, -87, 102 }, (Class)EbmlMaster.class);
/*  61 */   public static final MKVType SegmentUID = new MKVType("SegmentUID", new byte[] { 115, -92 }, (Class)EbmlBin.class);
/*     */   
/*  63 */   public static final MKVType SegmentFilename = new MKVType("SegmentFilename", new byte[] { 115, -124 }, (Class)EbmlString.class);
/*  64 */   public static final MKVType PrevUID = new MKVType("PrevUID", new byte[] { 60, -71, 35 }, (Class)EbmlBin.class);
/*  65 */   public static final MKVType PrevFilename = new MKVType("PrevFilename", new byte[] { 60, -125, -85 }, (Class)EbmlString.class);
/*  66 */   public static final MKVType NextUID = new MKVType("NextUID", new byte[] { 62, -71, 35 }, (Class)EbmlBin.class);
/*     */   
/*  68 */   public static final MKVType NextFilenam = new MKVType("NextFilenam", new byte[] { 62, -125, -69 }, (Class)EbmlString.class);
/*     */   
/*  70 */   public static final MKVType SegmentFamily = new MKVType("SegmentFamily", new byte[] { 68, 68 }, (Class)EbmlBin.class);
/*     */   
/*  72 */   public static final MKVType ChapterTranslate = new MKVType("ChapterTranslate", new byte[] { 105, 36 }, (Class)EbmlMaster.class);
/*     */   
/*  74 */   public static final MKVType ChapterTranslateEditionUID = new MKVType("ChapterTranslateEditionUID", new byte[] { 105, -4 }, (Class)EbmlUint.class);
/*     */   
/*  76 */   public static final MKVType ChapterTranslateCodec = new MKVType("ChapterTranslateCodec", new byte[] { 105, -65 }, (Class)EbmlUint.class);
/*     */   
/*  78 */   public static final MKVType ChapterTranslateID = new MKVType("ChapterTranslateID", new byte[] { 105, -91 }, (Class)EbmlBin.class);
/*     */ 
/*     */   
/*  81 */   public static final MKVType TimecodeScale = new MKVType("TimecodeScale", new byte[] { 42, -41, -79 }, (Class)EbmlUint.class);
/*     */   
/*  83 */   public static final MKVType Duration = new MKVType("Duration", new byte[] { 68, -119 }, (Class)EbmlFloat.class);
/*  84 */   public static final MKVType DateUTC = new MKVType("DateUTC", new byte[] { 68, 97 }, (Class)EbmlDate.class);
/*  85 */   public static final MKVType Title = new MKVType("Title", new byte[] { 123, -87 }, (Class)EbmlString.class);
/*  86 */   public static final MKVType MuxingApp = new MKVType("MuxingApp", new byte[] { 77, Byte.MIN_VALUE }, (Class)EbmlString.class);
/*  87 */   public static final MKVType WritingApp = new MKVType("WritingApp", new byte[] { 87, 65 }, (Class)EbmlString.class);
/*     */ 
/*     */   
/*  90 */   public static final MKVType Cluster = new MKVType("Cluster", EbmlMaster.CLUSTER_ID, (Class)EbmlMaster.class);
/*     */   
/*  92 */   public static final MKVType Timecode = new MKVType("Timecode", new byte[] { -25 }, (Class)EbmlUint.class);
/*     */   
/*  94 */   public static final MKVType SilentTracks = new MKVType("SilentTracks", new byte[] { 88, 84 }, (Class)EbmlMaster.class);
/*     */   
/*  96 */   public static final MKVType SilentTrackNumber = new MKVType("SilentTrackNumber", new byte[] { 88, -41 }, (Class)EbmlUint.class);
/*     */   
/*  98 */   public static final MKVType Position = new MKVType("Position", new byte[] { -89 }, (Class)EbmlUint.class);
/*     */   
/* 100 */   public static final MKVType PrevSize = new MKVType("PrevSize", new byte[] { -85 }, (Class)EbmlUint.class);
/*     */   
/* 102 */   public static final MKVType SimpleBlock = new MKVType("SimpleBlock", MkvBlock.SIMPLEBLOCK_ID, (Class)MkvBlock.class);
/*     */   
/* 104 */   public static final MKVType BlockGroup = new MKVType("BlockGroup", new byte[] { -96 }, (Class)EbmlMaster.class);
/*     */   
/* 106 */   public static final MKVType Block = new MKVType("Block", MkvBlock.BLOCK_ID, (Class)MkvBlock.class);
/*     */   
/* 108 */   public static final MKVType BlockAdditions = new MKVType("BlockAdditions", new byte[] { 117, -95 }, (Class)EbmlMaster.class);
/*     */   
/* 110 */   public static final MKVType BlockMore = new MKVType("BlockMore", new byte[] { -90 }, (Class)EbmlMaster.class);
/*     */   
/* 112 */   public static final MKVType BlockAddID = new MKVType("BlockAddID", new byte[] { -18 }, (Class)EbmlUint.class);
/*     */   
/* 114 */   public static final MKVType BlockAdditional = new MKVType("BlockAdditional", new byte[] { -91 }, (Class)EbmlBin.class);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 124 */   public static final MKVType BlockDuration = new MKVType("BlockDuration", new byte[] { -101 }, (Class)EbmlUint.class);
/*     */   
/* 126 */   public static final MKVType ReferencePriority = new MKVType("ReferencePriority", new byte[] { -6 }, (Class)EbmlUint.class);
/*     */   
/* 128 */   public static final MKVType ReferenceBlock = new MKVType("ReferenceBlock", new byte[] { -5 }, (Class)EbmlSint.class);
/*     */   
/* 130 */   public static final MKVType CodecState = new MKVType("CodecState", new byte[] { -92 }, (Class)EbmlBin.class);
/*     */   
/* 132 */   public static final MKVType Slices = new MKVType("Slices", new byte[] { -114 }, (Class)EbmlMaster.class);
/*     */   
/* 134 */   public static final MKVType TimeSlice = new MKVType("TimeSlice", new byte[] { -24 }, (Class)EbmlMaster.class);
/*     */   
/* 136 */   public static final MKVType LaceNumber = new MKVType("LaceNumber", new byte[] { -52 }, (Class)EbmlUint.class);
/*     */ 
/*     */   
/* 139 */   public static final MKVType Tracks = new MKVType("Tracks", new byte[] { 22, 84, -82, 107 }, (Class)EbmlMaster.class);
/*     */   
/* 141 */   public static final MKVType TrackEntry = new MKVType("TrackEntry", new byte[] { -82 }, (Class)EbmlMaster.class);
/*     */   
/* 143 */   public static final MKVType TrackNumber = new MKVType("TrackNumber", new byte[] { -41 }, (Class)EbmlUint.class);
/*     */   
/* 145 */   public static final MKVType TrackUID = new MKVType("TrackUID", new byte[] { 115, -59 }, (Class)EbmlUint.class);
/*     */   
/* 147 */   public static final MKVType TrackType = new MKVType("TrackType", new byte[] { -125 }, (Class)EbmlUint.class);
/*     */   
/* 149 */   public static final MKVType FlagEnabled = new MKVType("FlagEnabled", new byte[] { -71 }, (Class)EbmlUint.class);
/*     */   
/* 151 */   public static final MKVType FlagDefault = new MKVType("FlagDefault", new byte[] { -120 }, (Class)EbmlUint.class);
/*     */   
/* 153 */   public static final MKVType FlagForced = new MKVType("FlagForced", new byte[] { 85, -86 }, (Class)EbmlUint.class);
/*     */   
/* 155 */   public static final MKVType FlagLacing = new MKVType("FlagLacing", new byte[] { -100 }, (Class)EbmlUint.class);
/*     */   
/* 157 */   public static final MKVType MinCache = new MKVType("MinCache", new byte[] { 109, -25 }, (Class)EbmlUint.class);
/*     */   
/* 159 */   public static final MKVType MaxCache = new MKVType("MaxCache", new byte[] { 109, -8 }, (Class)EbmlUint.class);
/*     */   
/* 161 */   public static final MKVType DefaultDuration = new MKVType("DefaultDuration", new byte[] { 35, -29, -125 }, (Class)EbmlUint.class);
/*     */   
/* 163 */   public static final MKVType MaxBlockAdditionID = new MKVType("MaxBlockAdditionID", new byte[] { 85, -18 }, (Class)EbmlUint.class);
/*     */   
/* 165 */   public static final MKVType Name = new MKVType("Name", new byte[] { 83, 110 }, (Class)EbmlString.class);
/*     */   
/* 167 */   public static final MKVType Language = new MKVType("Language", new byte[] { 34, -75, -100 }, (Class)EbmlString.class);
/*     */   
/* 169 */   public static final MKVType CodecID = new MKVType("CodecID", new byte[] { -122 }, (Class)EbmlString.class);
/*     */   
/* 171 */   public static final MKVType CodecPrivate = new MKVType("CodecPrivate", new byte[] { 99, -94 }, (Class)EbmlBin.class);
/*     */   
/* 173 */   public static final MKVType CodecName = new MKVType("CodecName", new byte[] { 37, -122, -120 }, (Class)EbmlString.class);
/*     */   
/* 175 */   public static final MKVType AttachmentLink = new MKVType("AttachmentLink", new byte[] { 116, 70 }, (Class)EbmlUint.class);
/*     */   
/* 177 */   public static final MKVType CodecDecodeAll = new MKVType("CodecDecodeAll", new byte[] { -86 }, (Class)EbmlUint.class);
/*     */   
/* 179 */   public static final MKVType TrackOverlay = new MKVType("TrackOverlay", new byte[] { 111, -85 }, (Class)EbmlUint.class);
/*     */   
/* 181 */   public static final MKVType TrackTranslate = new MKVType("TrackTranslate", new byte[] { 102, 36 }, (Class)EbmlMaster.class);
/*     */   
/* 183 */   public static final MKVType TrackTranslateEditionUID = new MKVType("TrackTranslateEditionUID", new byte[] { 102, -4 }, (Class)EbmlUint.class);
/*     */   
/* 185 */   public static final MKVType TrackTranslateCodec = new MKVType("TrackTranslateCodec", new byte[] { 102, -65 }, (Class)EbmlUint.class);
/*     */   
/* 187 */   public static final MKVType TrackTranslateTrackID = new MKVType("TrackTranslateTrackID", new byte[] { 102, -91 }, (Class)EbmlBin.class);
/* 188 */   public static final MKVType Video = new MKVType("Video", new byte[] { -32 }, (Class)EbmlMaster.class);
/*     */   
/* 190 */   public static final MKVType FlagInterlaced = new MKVType("FlagInterlaced", new byte[] { -102 }, (Class)EbmlUint.class);
/*     */   
/* 192 */   public static final MKVType StereoMode = new MKVType("StereoMode", new byte[] { 83, -72 }, (Class)EbmlUint.class);
/*     */   
/* 194 */   public static final MKVType AlphaMode = new MKVType("AlphaMode", new byte[] { 83, -64 }, (Class)EbmlUint.class);
/* 195 */   public static final MKVType PixelWidth = new MKVType("PixelWidth", new byte[] { -80 }, (Class)EbmlUint.class);
/* 196 */   public static final MKVType PixelHeight = new MKVType("PixelHeight", new byte[] { -70 }, (Class)EbmlUint.class);
/*     */   
/* 198 */   public static final MKVType PixelCropBottom = new MKVType("PixelCropBottom", new byte[] { 84, -86 }, (Class)EbmlUint.class);
/*     */   
/* 200 */   public static final MKVType PixelCropTop = new MKVType("PixelCropTop", new byte[] { 84, -69 }, (Class)EbmlUint.class);
/*     */   
/* 202 */   public static final MKVType PixelCropLeft = new MKVType("PixelCropLeft", new byte[] { 84, -52 }, (Class)EbmlUint.class);
/*     */   
/* 204 */   public static final MKVType PixelCropRight = new MKVType("PixelCropRight", new byte[] { 84, -35 }, (Class)EbmlUint.class);
/* 205 */   public static final MKVType DisplayWidth = new MKVType("DisplayWidth", new byte[] { 84, -80 }, (Class)EbmlUint.class);
/* 206 */   public static final MKVType DisplayHeight = new MKVType("DisplayHeight", new byte[] { 84, -70 }, (Class)EbmlUint.class);
/*     */   
/* 208 */   public static final MKVType DisplayUnit = new MKVType("DisplayUnit", new byte[] { 84, -78 }, (Class)EbmlUint.class);
/*     */   
/* 210 */   public static final MKVType AspectRatioType = new MKVType("AspectRatioType", new byte[] { 84, -77 }, (Class)EbmlUint.class);
/*     */   
/* 212 */   public static final MKVType ColourSpace = new MKVType("ColourSpace", new byte[] { 46, -75, 36 }, (Class)EbmlBin.class);
/* 213 */   public static final MKVType Audio = new MKVType("Audio", new byte[] { -31 }, (Class)EbmlMaster.class);
/* 214 */   public static final MKVType SamplingFrequency = new MKVType("SamplingFrequency", new byte[] { -75 }, (Class)EbmlFloat.class);
/* 215 */   public static final MKVType OutputSamplingFrequency = new MKVType("OutputSamplingFrequency", new byte[] { 120, -75 }, (Class)EbmlFloat.class);
/* 216 */   public static final MKVType Channels = new MKVType("Channels", new byte[] { -97 }, (Class)EbmlUint.class);
/* 217 */   public static final MKVType BitDepth = new MKVType("BitDepth", new byte[] { 98, 100 }, (Class)EbmlUint.class);
/*     */   
/* 219 */   public static final MKVType TrackOperation = new MKVType("TrackOperation", new byte[] { -30 }, (Class)EbmlMaster.class);
/*     */   
/* 221 */   public static final MKVType TrackCombinePlanes = new MKVType("TrackCombinePlanes", new byte[] { -29 }, (Class)EbmlMaster.class);
/*     */   
/* 223 */   public static final MKVType TrackPlane = new MKVType("TrackPlane", new byte[] { -28 }, (Class)EbmlMaster.class);
/*     */   
/* 225 */   public static final MKVType TrackPlaneUID = new MKVType("TrackPlaneUID", new byte[] { -27 }, (Class)EbmlUint.class);
/*     */   
/* 227 */   public static final MKVType TrackPlaneType = new MKVType("TrackPlaneType", new byte[] { -26 }, (Class)EbmlUint.class);
/*     */   
/* 229 */   public static final MKVType TrackJoinBlocks = new MKVType("TrackJoinBlocks", new byte[] { -23 }, (Class)EbmlMaster.class);
/*     */   
/* 231 */   public static final MKVType TrackJoinUID = new MKVType("TrackJoinUID", new byte[] { -19 }, (Class)EbmlUint.class);
/*     */   
/* 233 */   public static final MKVType ContentEncodings = new MKVType("ContentEncodings", new byte[] { 109, Byte.MIN_VALUE }, (Class)EbmlMaster.class);
/*     */   
/* 235 */   public static final MKVType ContentEncoding = new MKVType("ContentEncoding", new byte[] { 98, 64 }, (Class)EbmlMaster.class);
/*     */   
/* 237 */   public static final MKVType ContentEncodingOrder = new MKVType("ContentEncodingOrder", new byte[] { 80, 49 }, (Class)EbmlUint.class);
/*     */   
/* 239 */   public static final MKVType ContentEncodingScope = new MKVType("ContentEncodingScope", new byte[] { 80, 50 }, (Class)EbmlUint.class);
/*     */   
/* 241 */   public static final MKVType ContentEncodingType = new MKVType("ContentEncodingType", new byte[] { 80, 51 }, (Class)EbmlUint.class);
/*     */   
/* 243 */   public static final MKVType ContentCompression = new MKVType("ContentCompression", new byte[] { 80, 52 }, (Class)EbmlMaster.class);
/*     */   
/* 245 */   public static final MKVType ContentCompAlgo = new MKVType("ContentCompAlgo", new byte[] { 66, 84 }, (Class)EbmlUint.class);
/*     */   
/* 247 */   public static final MKVType ContentCompSettings = new MKVType("ContentCompSettings", new byte[] { 66, 85 }, (Class)EbmlBin.class);
/*     */   
/* 249 */   public static final MKVType ContentEncryption = new MKVType("ContentEncryption", new byte[] { 80, 53 }, (Class)EbmlMaster.class);
/*     */   
/* 251 */   public static final MKVType ContentEncAlgo = new MKVType("ContentEncAlgo", new byte[] { 71, -31 }, (Class)EbmlUint.class);
/*     */   
/* 253 */   public static final MKVType ContentEncKeyID = new MKVType("ContentEncKeyID", new byte[] { 71, -30 }, (Class)EbmlBin.class);
/*     */   
/* 255 */   public static final MKVType ContentSignature = new MKVType("ContentSignature", new byte[] { 71, -29 }, (Class)EbmlBin.class);
/*     */   
/* 257 */   public static final MKVType ContentSigKeyID = new MKVType("ContentSigKeyID", new byte[] { 71, -28 }, (Class)EbmlBin.class);
/*     */   
/* 259 */   public static final MKVType ContentSigAlgo = new MKVType("ContentSigAlgo", new byte[] { 71, -27 }, (Class)EbmlUint.class);
/*     */   
/* 261 */   public static final MKVType ContentSigHashAlgo = new MKVType("ContentSigHashAlgo", new byte[] { 71, -26 }, (Class)EbmlUint.class);
/*     */   
/* 263 */   public static final MKVType Cues = new MKVType("Cues", new byte[] { 28, 83, -69, 107 }, (Class)EbmlMaster.class);
/* 264 */   public static final MKVType CuePoint = new MKVType("CuePoint", new byte[] { -69 }, (Class)EbmlMaster.class);
/* 265 */   public static final MKVType CueTime = new MKVType("CueTime", new byte[] { -77 }, (Class)EbmlUint.class);
/* 266 */   public static final MKVType CueTrackPositions = new MKVType("CueTrackPositions", new byte[] { -73 }, (Class)EbmlMaster.class);
/* 267 */   public static final MKVType CueTrack = new MKVType("CueTrack", new byte[] { -9 }, (Class)EbmlUint.class);
/* 268 */   public static final MKVType CueClusterPosition = new MKVType("CueClusterPosition", new byte[] { -15 }, (Class)EbmlUint.class);
/*     */   
/* 270 */   public static final MKVType CueRelativePosition = new MKVType("CueRelativePosition", new byte[] { -16 }, (Class)EbmlUint.class);
/*     */   
/* 272 */   public static final MKVType CueDuration = new MKVType("CueDuration", new byte[] { -78 }, (Class)EbmlUint.class);
/*     */   
/* 274 */   public static final MKVType CueBlockNumber = new MKVType("CueBlockNumber", new byte[] { 83, 120 }, (Class)EbmlUint.class);
/*     */   
/* 276 */   public static final MKVType CueCodecState = new MKVType("CueCodecState", new byte[] { -22 }, (Class)EbmlUint.class);
/*     */   
/* 278 */   public static final MKVType CueReference = new MKVType("CueReference", new byte[] { -37 }, (Class)EbmlMaster.class);
/*     */   
/* 280 */   public static final MKVType CueRefTime = new MKVType("CueRefTime", new byte[] { -106 }, (Class)EbmlUint.class);
/*     */   
/* 282 */   public static final MKVType Attachments = new MKVType("Attachments", new byte[] { 25, 65, -92, 105 }, (Class)EbmlMaster.class);
/* 283 */   public static final MKVType AttachedFile = new MKVType("AttachedFile", new byte[] { 97, -89 }, (Class)EbmlMaster.class);
/* 284 */   public static final MKVType FileDescription = new MKVType("FileDescription", new byte[] { 70, 126 }, (Class)EbmlString.class);
/* 285 */   public static final MKVType FileName = new MKVType("FileName", new byte[] { 70, 110 }, (Class)EbmlString.class);
/* 286 */   public static final MKVType FileMimeType = new MKVType("FileMimeType", new byte[] { 70, 96 }, (Class)EbmlString.class);
/* 287 */   public static final MKVType FileData = new MKVType("FileData", new byte[] { 70, 92 }, (Class)EbmlBin.class);
/* 288 */   public static final MKVType FileUID = new MKVType("FileUID", new byte[] { 70, -82 }, (Class)EbmlUint.class);
/*     */   
/* 290 */   public static final MKVType Chapters = new MKVType("Chapters", new byte[] { 16, 67, -89, 112 }, (Class)EbmlMaster.class);
/* 291 */   public static final MKVType EditionEntry = new MKVType("EditionEntry", new byte[] { 69, -71 }, (Class)EbmlMaster.class);
/* 292 */   public static final MKVType EditionUID = new MKVType("EditionUID", new byte[] { 69, -68 }, (Class)EbmlUint.class);
/* 293 */   public static final MKVType EditionFlagHidden = new MKVType("EditionFlagHidden", new byte[] { 69, -67 }, (Class)EbmlUint.class);
/* 294 */   public static final MKVType EditionFlagDefault = new MKVType("EditionFlagDefault", new byte[] { 69, -37 }, (Class)EbmlUint.class);
/* 295 */   public static final MKVType EditionFlagOrdered = new MKVType("EditionFlagOrdered", new byte[] { 69, -35 }, (Class)EbmlUint.class);
/* 296 */   public static final MKVType ChapterAtom = new MKVType("ChapterAtom", new byte[] { -74 }, (Class)EbmlMaster.class);
/* 297 */   public static final MKVType ChapterUID = new MKVType("ChapterUID", new byte[] { 115, -60 }, (Class)EbmlUint.class);
/*     */   
/* 299 */   public static final MKVType ChapterStringUID = new MKVType("ChapterStringUID", new byte[] { 86, 84 }, (Class)EbmlString.class);
/* 300 */   public static final MKVType ChapterTimeStart = new MKVType("ChapterTimeStart", new byte[] { -111 }, (Class)EbmlUint.class);
/* 301 */   public static final MKVType ChapterTimeEnd = new MKVType("ChapterTimeEnd", new byte[] { -110 }, (Class)EbmlUint.class);
/* 302 */   public static final MKVType ChapterFlagHidden = new MKVType("ChapterFlagHidden", new byte[] { -104 }, (Class)EbmlUint.class);
/* 303 */   public static final MKVType ChapterFlagEnabled = new MKVType("ChapterFlagEnabled", new byte[] { 69, -104 }, (Class)EbmlUint.class);
/*     */   
/* 305 */   public static final MKVType ChapterSegmentUID = new MKVType("ChapterSegmentUID", new byte[] { 110, 103 }, (Class)EbmlBin.class);
/*     */   
/* 307 */   public static final MKVType ChapterSegmentEditionUID = new MKVType("ChapterSegmentEditionUID", new byte[] { 110, -68 }, (Class)EbmlUint.class);
/* 308 */   public static final MKVType ChapterPhysicalEquiv = new MKVType("ChapterPhysicalEquiv", new byte[] { 99, -61 }, (Class)EbmlUint.class);
/* 309 */   public static final MKVType ChapterTrack = new MKVType("ChapterTrack", new byte[] { -113 }, (Class)EbmlMaster.class);
/* 310 */   public static final MKVType ChapterTrackNumber = new MKVType("ChapterTrackNumber", new byte[] { -119 }, (Class)EbmlUint.class);
/* 311 */   public static final MKVType ChapterDisplay = new MKVType("ChapterDisplay", new byte[] { Byte.MIN_VALUE }, (Class)EbmlMaster.class);
/* 312 */   public static final MKVType ChapString = new MKVType("ChapString", new byte[] { -123 }, (Class)EbmlString.class);
/* 313 */   public static final MKVType ChapLanguage = new MKVType("ChapLanguage", new byte[] { 67, 124 }, (Class)EbmlString.class);
/* 314 */   public static final MKVType ChapCountry = new MKVType("ChapCountry", new byte[] { 67, 126 }, (Class)EbmlString.class);
/*     */   
/* 316 */   public static final MKVType ChapProcess = new MKVType("ChapProcess", new byte[] { 105, 68 }, (Class)EbmlMaster.class);
/*     */   
/* 318 */   public static final MKVType ChapProcessCodecID = new MKVType("ChapProcessCodecID", new byte[] { 105, 85 }, (Class)EbmlUint.class);
/*     */   
/* 320 */   public static final MKVType ChapProcessPrivate = new MKVType("ChapProcessPrivate", new byte[] { 69, 13 }, (Class)EbmlBin.class);
/*     */   
/* 322 */   public static final MKVType ChapProcessCommand = new MKVType("ChapProcessCommand", new byte[] { 105, 17 }, (Class)EbmlMaster.class);
/*     */   
/* 324 */   public static final MKVType ChapProcessTime = new MKVType("ChapProcessTime", new byte[] { 105, 34 }, (Class)EbmlUint.class);
/*     */   
/* 326 */   public static final MKVType ChapProcessData = new MKVType("ChapProcessData", new byte[] { 105, 51 }, (Class)EbmlBin.class);
/*     */   
/* 328 */   public static final MKVType Tags = new MKVType("Tags", new byte[] { 18, 84, -61, 103 }, (Class)EbmlMaster.class);
/* 329 */   public static final MKVType Tag = new MKVType("Tag", new byte[] { 115, 115 }, (Class)EbmlMaster.class);
/* 330 */   public static final MKVType Targets = new MKVType("Targets", new byte[] { 99, -64 }, (Class)EbmlMaster.class);
/* 331 */   public static final MKVType TargetTypeValue = new MKVType("TargetTypeValue", new byte[] { 104, -54 }, (Class)EbmlUint.class);
/* 332 */   public static final MKVType TargetType = new MKVType("TargetType", new byte[] { 99, -54 }, (Class)EbmlString.class);
/* 333 */   public static final MKVType TagTrackUID = new MKVType("TagTrackUID", new byte[] { 99, -59 }, (Class)EbmlUint.class);
/*     */   
/* 335 */   public static final MKVType TagEditionUID = new MKVType("TagEditionUID", new byte[] { 99, -55 }, (Class)EbmlUint.class);
/* 336 */   public static final MKVType TagChapterUID = new MKVType("TagChapterUID", new byte[] { 99, -60 }, (Class)EbmlUint.class);
/* 337 */   public static final MKVType TagAttachmentUID = new MKVType("TagAttachmentUID", new byte[] { 99, -58 }, (Class)EbmlUint.class);
/* 338 */   public static final MKVType SimpleTag = new MKVType("SimpleTag", new byte[] { 103, -56 }, (Class)EbmlMaster.class);
/* 339 */   public static final MKVType TagName = new MKVType("TagName", new byte[] { 69, -93 }, (Class)EbmlString.class);
/* 340 */   public static final MKVType TagLanguage = new MKVType("TagLanguage", new byte[] { 68, 122 }, (Class)EbmlString.class);
/* 341 */   public static final MKVType TagDefault = new MKVType("TagDefault", new byte[] { 68, -124 }, (Class)EbmlUint.class);
/* 342 */   public static final MKVType TagString = new MKVType("TagString", new byte[] { 68, -121 }, (Class)EbmlString.class);
/* 343 */   public static final MKVType TagBinary = new MKVType("TagBinary", new byte[] { 68, -123 }, (Class)EbmlBin.class);
/*     */   
/* 345 */   public static MKVType[] firstLevelHeaders = new MKVType[] { SeekHead, Info, Cluster, Tracks, Cues, Attachments, Chapters, Tags, EBMLVersion, EBMLReadVersion, EBMLMaxIDLength, EBMLMaxSizeLength, DocType, DocTypeVersion, DocTypeReadVersion };
/*     */   public final byte[] id;
/*     */   public final Class<? extends EbmlBase> clazz;
/*     */   private String _name;
/*     */   
/*     */   private MKVType(String name, byte[] id, Class<? extends EbmlBase> clazz) {
/* 351 */     this._name = name;
/* 352 */     this.id = id;
/* 353 */     this.clazz = clazz;
/* 354 */     _values.add(this);
/*     */   }
/*     */   public String name() {
/* 357 */     return this._name;
/*     */   }
/*     */   public String toString() {
/* 360 */     return this._name;
/*     */   }
/*     */   
/*     */   public static MKVType[] values() {
/* 364 */     return _values.<MKVType>toArray(new MKVType[0]);
/*     */   }
/*     */ 
/*     */   
/*     */   public static <T extends EbmlBase> T createByType(MKVType g) {
/*     */     try {
/* 370 */       EbmlBase ebmlBase = (EbmlBase)Platform.newInstance(g.clazz, new Object[] { g.id });
/* 371 */       ebmlBase.type = g;
/* 372 */       return (T)ebmlBase;
/* 373 */     } catch (Exception e) {
/* 374 */       e.printStackTrace();
/* 375 */       return (T)new EbmlBin(g.id);
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public static <T extends EbmlBase> T createById(byte[] id, long offset) {
/* 381 */     MKVType[] values = values();
/* 382 */     for (int i = 0; i < values.length; i++) {
/* 383 */       MKVType t = values[i];
/* 384 */       if (Platform.arrayEqualsByte(t.id, id))
/* 385 */         return createByType(t); 
/*     */     } 
/* 387 */     System.err.println("WARNING: unspecified ebml ID (" + EbmlUtil.toHexString(id) + ") encountered at position 0x" + 
/* 388 */         Long.toHexString(offset).toUpperCase());
/* 389 */     EbmlVoid ebmlVoid = new EbmlVoid(id);
/* 390 */     ((EbmlBase)ebmlVoid).type = Void;
/* 391 */     return (T)ebmlVoid;
/*     */   }
/*     */   
/*     */   public static boolean isHeaderFirstByte(byte b) {
/* 395 */     MKVType[] values = values();
/* 396 */     for (int i = 0; i < values.length; i++) {
/* 397 */       MKVType t = values[i];
/* 398 */       if (t.id[0] == b) {
/* 399 */         return true;
/*     */       }
/*     */     } 
/* 402 */     return false;
/*     */   }
/*     */   
/*     */   public static boolean isSpecifiedHeader(byte[] b) {
/* 406 */     MKVType[] values = values();
/* 407 */     for (int i = 0; i < values.length; i++) {
/* 408 */       MKVType firstLevelHeader = values[i];
/* 409 */       if (Platform.arrayEqualsByte(firstLevelHeader.id, b))
/* 410 */         return true; 
/*     */     } 
/* 412 */     return false;
/*     */   }
/*     */   
/*     */   public static boolean isFirstLevelHeader(byte[] b) {
/* 416 */     for (MKVType firstLevelHeader : firstLevelHeaders) {
/* 417 */       if (Platform.arrayEqualsByte(firstLevelHeader.id, b))
/* 418 */         return true; 
/* 419 */     }  return false;
/*     */   }
/*     */   
/* 422 */   public static final Map<MKVType, Set<MKVType>> children = new HashMap<MKVType, Set<MKVType>>();
/*     */   static {
/* 424 */     children.put(EBML, new HashSet<MKVType>(Arrays.asList(new MKVType[] { EBMLVersion, EBMLReadVersion, EBMLMaxIDLength, EBMLMaxSizeLength, DocType, DocTypeVersion, DocTypeReadVersion })));
/* 425 */     children.put(Segment, new HashSet<MKVType>(Arrays.asList(new MKVType[] { SeekHead, Info, Cluster, Tracks, Cues, Attachments, Chapters, Tags })));
/*     */     
/* 427 */     children.put(SeekHead, new HashSet<MKVType>(Arrays.asList(new MKVType[] { Seek })));
/* 428 */     children.put(Seek, new HashSet<MKVType>(Arrays.asList(new MKVType[] { SeekID, SeekPosition })));
/* 429 */     children.put(Info, new HashSet<MKVType>(Arrays.asList(new MKVType[] { SegmentUID, SegmentFilename, PrevUID, PrevFilename, NextUID, NextFilenam, SegmentFamily, ChapterTranslate, TimecodeScale, Duration, DateUTC, Title, MuxingApp, WritingApp })));
/* 430 */     children.put(ChapterTranslate, new HashSet<MKVType>(Arrays.asList(new MKVType[] { ChapterTranslateEditionUID, ChapterTranslateCodec, ChapterTranslateID })));
/*     */     
/* 432 */     children.put(Cluster, new HashSet<MKVType>(Arrays.asList(new MKVType[] { Timecode, SilentTracks, Position, PrevSize, SimpleBlock, BlockGroup })));
/* 433 */     children.put(SilentTracks, new HashSet<MKVType>(Arrays.asList(new MKVType[] { SilentTrackNumber })));
/* 434 */     children.put(BlockGroup, new HashSet<MKVType>(Arrays.asList(new MKVType[] { Block, BlockAdditions, BlockDuration, ReferencePriority, ReferenceBlock, CodecState, Slices })));
/* 435 */     children.put(BlockAdditions, new HashSet<MKVType>(Arrays.asList(new MKVType[] { BlockMore })));
/* 436 */     children.put(BlockMore, new HashSet<MKVType>(Arrays.asList(new MKVType[] { BlockAddID, BlockAdditional })));
/* 437 */     children.put(Slices, new HashSet<MKVType>(Arrays.asList(new MKVType[] { TimeSlice })));
/* 438 */     children.put(TimeSlice, new HashSet<MKVType>(Arrays.asList(new MKVType[] { LaceNumber })));
/*     */     
/* 440 */     children.put(Tracks, new HashSet<MKVType>(Arrays.asList(new MKVType[] { TrackEntry })));
/* 441 */     children.put(TrackEntry, new HashSet<MKVType>(Arrays.asList(new MKVType[] { TrackNumber, TrackUID, TrackType, TrackType, FlagDefault, FlagForced, FlagLacing, MinCache, MaxCache, DefaultDuration, MaxBlockAdditionID, Name, Language, CodecID, CodecPrivate, CodecName, AttachmentLink, CodecDecodeAll, TrackOverlay, TrackTranslate, Video, Audio, TrackOperation, ContentEncodings })));
/* 442 */     children.put(TrackTranslate, new HashSet<MKVType>(Arrays.asList(new MKVType[] { TrackTranslateEditionUID, TrackTranslateCodec, TrackTranslateTrackID })));
/* 443 */     children.put(Video, new HashSet<MKVType>(Arrays.asList(new MKVType[] { FlagInterlaced, StereoMode, AlphaMode, PixelWidth, PixelHeight, PixelCropBottom, PixelCropTop, PixelCropLeft, PixelCropRight, DisplayWidth, DisplayHeight, DisplayUnit, AspectRatioType, ColourSpace })));
/* 444 */     children.put(Audio, new HashSet<MKVType>(Arrays.asList(new MKVType[] { SamplingFrequency, OutputSamplingFrequency, Channels, BitDepth })));
/* 445 */     children.put(TrackOperation, new HashSet<MKVType>(Arrays.asList(new MKVType[] { TrackCombinePlanes, TrackJoinBlocks })));
/* 446 */     children.put(TrackCombinePlanes, new HashSet<MKVType>(Arrays.asList(new MKVType[] { TrackPlane })));
/* 447 */     children.put(TrackPlane, new HashSet<MKVType>(Arrays.asList(new MKVType[] { TrackPlaneUID, TrackPlaneType })));
/* 448 */     children.put(TrackJoinBlocks, new HashSet<MKVType>(Arrays.asList(new MKVType[] { TrackJoinUID })));
/* 449 */     children.put(ContentEncodings, new HashSet<MKVType>(Arrays.asList(new MKVType[] { ContentEncoding })));
/* 450 */     children.put(ContentEncoding, new HashSet<MKVType>(Arrays.asList(new MKVType[] { ContentEncodingOrder, ContentEncodingScope, ContentEncodingType, ContentCompression, ContentEncryption })));
/* 451 */     children.put(ContentCompression, new HashSet<MKVType>(Arrays.asList(new MKVType[] { ContentCompAlgo, ContentCompSettings })));
/* 452 */     children.put(ContentEncryption, new HashSet<MKVType>(Arrays.asList(new MKVType[] { ContentEncAlgo, ContentEncKeyID, ContentSignature, ContentSigKeyID, ContentSigAlgo, ContentSigHashAlgo })));
/*     */     
/* 454 */     children.put(Cues, new HashSet<MKVType>(Arrays.asList(new MKVType[] { CuePoint })));
/* 455 */     children.put(CuePoint, new HashSet<MKVType>(Arrays.asList(new MKVType[] { CueTime, CueTrackPositions })));
/* 456 */     children.put(CueTrackPositions, new HashSet<MKVType>(Arrays.asList(new MKVType[] { CueTrack, CueClusterPosition, CueRelativePosition, CueDuration, CueBlockNumber, CueCodecState, CueReference })));
/* 457 */     children.put(CueReference, new HashSet<MKVType>(Arrays.asList(new MKVType[] { CueRefTime })));
/*     */     
/* 459 */     children.put(Attachments, new HashSet<MKVType>(Arrays.asList(new MKVType[] { AttachedFile })));
/* 460 */     children.put(AttachedFile, new HashSet<MKVType>(Arrays.asList(new MKVType[] { FileDescription, FileName, FileMimeType, FileData, FileUID })));
/*     */     
/* 462 */     children.put(Chapters, new HashSet<MKVType>(Arrays.asList(new MKVType[] { EditionEntry })));
/* 463 */     children.put(EditionEntry, new HashSet<MKVType>(Arrays.asList(new MKVType[] { EditionUID, EditionFlagHidden, EditionFlagDefault, EditionFlagOrdered, ChapterAtom })));
/* 464 */     children.put(ChapterAtom, new HashSet<MKVType>(Arrays.asList(new MKVType[] { ChapterUID, ChapterStringUID, ChapterTimeStart, ChapterTimeEnd, ChapterFlagHidden, ChapterFlagEnabled, ChapterSegmentUID, ChapterSegmentEditionUID, ChapterPhysicalEquiv, ChapterTrack, ChapterDisplay, ChapProcess })));
/* 465 */     children.put(ChapterTrack, new HashSet<MKVType>(Arrays.asList(new MKVType[] { ChapterTrackNumber })));
/* 466 */     children.put(ChapterDisplay, new HashSet<MKVType>(Arrays.asList(new MKVType[] { ChapString, ChapLanguage, ChapCountry })));
/* 467 */     children.put(ChapProcess, new HashSet<MKVType>(Arrays.asList(new MKVType[] { ChapProcessCodecID, ChapProcessPrivate, ChapProcessCommand })));
/* 468 */     children.put(ChapProcessCommand, new HashSet<MKVType>(Arrays.asList(new MKVType[] { ChapProcessTime, ChapProcessData })));
/*     */     
/* 470 */     children.put(Tags, new HashSet<MKVType>(Arrays.asList(new MKVType[] { Tag })));
/* 471 */     children.put(Tag, new HashSet<MKVType>(Arrays.asList(new MKVType[] { Targets, SimpleTag })));
/* 472 */     children.put(Targets, new HashSet<MKVType>(Arrays.asList(new MKVType[] { TargetTypeValue, TargetType, TagTrackUID, TagEditionUID, TagChapterUID, TagAttachmentUID })));
/* 473 */     children.put(SimpleTag, new HashSet<MKVType>(Arrays.asList(new MKVType[] { TagName, TagLanguage, TagDefault, TagString, TagBinary })));
/*     */   }
/*     */ 
/*     */   
/*     */   public static MKVType getParent(MKVType t) {
/* 478 */     for (Map.Entry<MKVType, Set<MKVType>> ent : children.entrySet()) {
/* 479 */       if (((Set)ent.getValue()).contains(t))
/* 480 */         return ent.getKey(); 
/*     */     } 
/* 482 */     return null;
/*     */   }
/*     */   
/*     */   public static boolean possibleChild(EbmlMaster parent, EbmlBase child) {
/* 486 */     if (parent == null) {
/* 487 */       if (child.type == EBML || child.type == Segment) {
/* 488 */         return true;
/*     */       }
/* 490 */       return false;
/*     */     } 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 497 */     if (Platform.arrayEqualsByte(child.id, Void.id) || Platform.arrayEqualsByte(child.id, CRC32.id)) {
/* 498 */       return (child.offset != parent.dataOffset + parent.dataLen);
/*     */     }
/*     */ 
/*     */     
/* 502 */     if (child.type == Void || child.type == CRC32) {
/* 503 */       return true;
/*     */     }
/* 505 */     Set<MKVType> candidates = children.get(parent.type);
/* 506 */     return (candidates != null && candidates.contains(child.type));
/*     */   }
/*     */ 
/*     */   
/*     */   public static boolean possibleChildById(EbmlMaster parent, byte[] typeId) {
/* 511 */     if (parent == null && (Platform.arrayEqualsByte(EBML.id, typeId) || Platform.arrayEqualsByte(Segment.id, typeId))) {
/* 512 */       return true;
/*     */     }
/*     */     
/* 515 */     if (parent == null) {
/* 516 */       return false;
/*     */     }
/*     */     
/* 519 */     if (Platform.arrayEqualsByte(Void.id, typeId) || Platform.arrayEqualsByte(CRC32.id, typeId)) {
/* 520 */       return true;
/*     */     }
/*     */     
/* 523 */     for (MKVType aCandidate : children.get(parent.type)) {
/* 524 */       if (Platform.arrayEqualsByte(aCandidate.id, typeId))
/* 525 */         return true; 
/*     */     } 
/* 527 */     return false;
/*     */   }
/*     */   
/*     */   public static EbmlBase findFirst(EbmlBase master, MKVType[] path) {
/* 531 */     List<MKVType> tlist = new LinkedList<MKVType>(Arrays.asList(path));
/* 532 */     return findFirstSub(master, tlist);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public static <T> T findFirstTree(List<? extends EbmlBase> tree, MKVType[] path) {
/* 538 */     List<MKVType> tlist = new LinkedList<MKVType>(Arrays.asList(path));
/* 539 */     for (EbmlBase e : tree) {
/* 540 */       EbmlBase z = findFirstSub(e, tlist);
/* 541 */       if (z != null) {
/* 542 */         return (T)z;
/*     */       }
/*     */     } 
/* 545 */     return null;
/*     */   }
/*     */ 
/*     */   
/*     */   private static EbmlBase findFirstSub(EbmlBase elem, List<MKVType> path) {
/* 550 */     if (path.size() == 0) {
/* 551 */       return null;
/*     */     }
/* 553 */     if (!elem.type.equals(path.get(0))) {
/* 554 */       return null;
/*     */     }
/* 556 */     if (path.size() == 1) {
/* 557 */       return elem;
/*     */     }
/* 559 */     MKVType head = path.remove(0);
/* 560 */     EbmlBase result = null;
/* 561 */     if (elem instanceof EbmlMaster) {
/* 562 */       Iterator<EbmlBase> iter = ((EbmlMaster)elem).children.iterator();
/* 563 */       while (iter.hasNext() && result == null) {
/* 564 */         result = findFirstSub(iter.next(), path);
/*     */       }
/*     */     } 
/*     */     
/* 568 */     path.add(0, head);
/* 569 */     return result;
/*     */   }
/*     */ 
/*     */   
/*     */   public static <T> List<T> findList(List<? extends EbmlBase> tree, Class<T> class1, MKVType[] path) {
/* 574 */     List<T> result = new LinkedList<T>();
/* 575 */     List<MKVType> tlist = new LinkedList<MKVType>(Arrays.asList(path));
/* 576 */     if (tlist.size() > 0) {
/* 577 */       for (EbmlBase node : tree) {
/* 578 */         MKVType head = tlist.remove(0);
/* 579 */         if (head == null || head.equals(node.type)) {
/* 580 */           findSubList(node, tlist, result);
/*     */         }
/* 582 */         tlist.add(0, head);
/*     */       } 
/*     */     }
/* 585 */     return result;
/*     */   }
/*     */ 
/*     */   
/*     */   private static <T> void findSubList(EbmlBase element, List<MKVType> path, Collection<T> result) {
/* 590 */     if (path.size() > 0) {
/* 591 */       MKVType head = path.remove(0);
/* 592 */       if (element instanceof EbmlMaster) {
/* 593 */         EbmlMaster nb = (EbmlMaster)element;
/* 594 */         for (EbmlBase candidate : nb.children) {
/* 595 */           if (head == null || head.equals(candidate.type)) {
/* 596 */             findSubList(candidate, path, result);
/*     */           }
/*     */         } 
/*     */       } 
/* 600 */       path.add(0, head);
/*     */     } else {
/* 602 */       result.add((T)element);
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public static <T> T[] findAllTree(List<? extends EbmlBase> tree, Class<T> class1, MKVType[] path) {
/* 608 */     List<EbmlBase> result = new LinkedList<EbmlBase>();
/* 609 */     List<MKVType> tlist = new LinkedList<MKVType>(Arrays.asList(path));
/* 610 */     if (tlist.size() > 0) {
/* 611 */       for (EbmlBase node : tree) {
/* 612 */         MKVType head = tlist.remove(0);
/* 613 */         if (head == null || head.equals(node.type)) {
/* 614 */           findSub(node, tlist, result);
/*     */         }
/* 616 */         tlist.add(0, head);
/*     */       } 
/*     */     }
/* 619 */     return result.toArray((T[])Array.newInstance(class1, 0));
/*     */   }
/*     */ 
/*     */   
/*     */   public static <T> T[] findAll(EbmlBase master, Class<T> class1, boolean ga, MKVType[] path) {
/* 624 */     List<EbmlBase> result = new LinkedList<EbmlBase>();
/* 625 */     List<MKVType> tlist = new LinkedList<MKVType>(Arrays.asList(path));
/* 626 */     if (!master.type.equals(tlist.get(0))) {
/* 627 */       return result.toArray((T[])Array.newInstance(class1, 0));
/*     */     }
/* 629 */     tlist.remove(0);
/* 630 */     findSub(master, tlist, result);
/* 631 */     return result.toArray((T[])Array.newInstance(class1, 0));
/*     */   }
/*     */ 
/*     */   
/*     */   private static void findSub(EbmlBase master, List<MKVType> path, Collection<EbmlBase> result) {
/* 636 */     if (path.size() > 0) {
/* 637 */       MKVType head = path.remove(0);
/* 638 */       if (master instanceof EbmlMaster) {
/* 639 */         EbmlMaster nb = (EbmlMaster)master;
/* 640 */         for (EbmlBase candidate : nb.children) {
/* 641 */           if (head == null || head.equals(candidate.type)) {
/* 642 */             findSub(candidate, path, result);
/*     */           }
/*     */         } 
/*     */       } 
/* 646 */       path.add(0, head);
/*     */     } else {
/* 648 */       result.add(master);
/*     */     } 
/*     */   }
/*     */ }


/* Location:              C:\Users\rapha\Downloads\aurora.jar!\META-INF\jars\jcodec-0.2.5.jar!\org\jcodec\containers\mkv\MKVType.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */