/*     */ package org.jcodec.containers.flv;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.nio.ByteBuffer;
/*     */ import java.nio.ByteOrder;
/*     */ import java.nio.channels.ReadableByteChannel;
/*     */ import java.util.Date;
/*     */ import java.util.HashMap;
/*     */ import java.util.Map;
/*     */ import org.jcodec.common.AudioFormat;
/*     */ import org.jcodec.common.Codec;
/*     */ import org.jcodec.common.io.NIOUtils;
/*     */ import org.jcodec.common.io.SeekableByteChannel;
/*     */ import org.jcodec.common.logging.Logger;
/*     */ import org.jcodec.common.tools.MathUtil;
/*     */ import org.jcodec.platform.Platform;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class FLVReader
/*     */ {
/*     */   private static final int REPOSITION_BUFFER_READS = 10;
/*     */   private static final int TAG_HEADER_SIZE = 15;
/*     */   private static final int READ_BUFFER_SIZE = 1024;
/*     */   private int frameNo;
/*     */   private ByteBuffer readBuf;
/*     */   private SeekableByteChannel ch;
/*     */   private boolean eof;
/*  45 */   private static boolean platformBigEndian = (ByteBuffer.allocate(0).order() == ByteOrder.BIG_ENDIAN);
/*     */   
/*  47 */   public static Codec[] audioCodecMapping = new Codec[] { Codec.PCM, Codec.ADPCM, Codec.MP3, Codec.PCM, Codec.NELLYMOSER, Codec.NELLYMOSER, Codec.NELLYMOSER, Codec.G711, Codec.G711, null, Codec.AAC, Codec.SPEEX, Codec.MP3, null };
/*     */ 
/*     */   
/*  50 */   public static Codec[] videoCodecMapping = new Codec[] { null, null, Codec.SORENSON, Codec.FLASH_SCREEN_VIDEO, Codec.VP6, Codec.VP6, Codec.FLASH_SCREEN_V2, Codec.H264 };
/*     */ 
/*     */   
/*  53 */   public static int[] sampleRates = new int[] { 5500, 11000, 22000, 44100 };
/*     */   
/*     */   public FLVReader(SeekableByteChannel ch) throws IOException {
/*  56 */     this.ch = ch;
/*  57 */     this.readBuf = ByteBuffer.allocate(1024);
/*  58 */     this.readBuf.order(ByteOrder.BIG_ENDIAN);
/*     */     
/*  60 */     initialRead((ReadableByteChannel)ch);
/*     */     
/*  62 */     if (!readHeader(this.readBuf)) {
/*     */ 
/*     */       
/*  65 */       this.readBuf.position(0);
/*  66 */       if (!repositionFile()) {
/*  67 */         throw new RuntimeException("Invalid FLV file");
/*     */       }
/*  69 */       Logger.warn(String.format("Parsing a corrupt FLV file, first tag found at %d. %s", new Object[] { Integer.valueOf(this.readBuf.position()), 
/*  70 */               (this.readBuf.position() == 0) ? "Did you forget the FLV 9-byte header?" : "" }));
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   private void initialRead(ReadableByteChannel ch) throws IOException {
/*  76 */     this.readBuf.clear();
/*  77 */     if (ch.read(this.readBuf) == -1)
/*  78 */       this.eof = true; 
/*  79 */     this.readBuf.flip();
/*     */   }
/*     */   
/*     */   public FLVTag readNextPacket() throws IOException {
/*  83 */     if (this.eof) {
/*  84 */       return null;
/*     */     }
/*  86 */     FLVTag pkt = parsePacket(this.readBuf);
/*     */     
/*  88 */     if (pkt == null && !this.eof) {
/*  89 */       moveRemainderToTheStart(this.readBuf);
/*  90 */       if (this.ch.read(this.readBuf) == -1) {
/*  91 */         this.eof = true;
/*  92 */         return null;
/*     */       } 
/*     */       
/*  95 */       while (MathUtil.log2(this.readBuf.capacity()) <= 22) {
/*  96 */         this.readBuf.flip();
/*  97 */         pkt = parsePacket(this.readBuf);
/*  98 */         if (pkt != null || this.readBuf.position() > 0) {
/*     */           break;
/*     */         }
/* 101 */         ByteBuffer newBuf = ByteBuffer.allocate(this.readBuf.capacity() << 2);
/* 102 */         newBuf.put(this.readBuf);
/* 103 */         this.readBuf = newBuf;
/* 104 */         if (this.ch.read(this.readBuf) == -1) {
/* 105 */           this.eof = true;
/* 106 */           return null;
/*     */         } 
/*     */       } 
/*     */     } 
/*     */     
/* 111 */     return pkt;
/*     */   }
/*     */   
/*     */   public FLVTag readPrevPacket() throws IOException {
/* 115 */     int startOfLastPacket = this.readBuf.getInt();
/* 116 */     this.readBuf.position(this.readBuf.position() - 4);
/* 117 */     if (this.readBuf.position() > startOfLastPacket) {
/*     */       
/* 119 */       this.readBuf.position(this.readBuf.position() - startOfLastPacket);
/* 120 */       return parsePacket(this.readBuf);
/*     */     } 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 126 */     long oldPos = this.ch.position() - this.readBuf.remaining();
/* 127 */     if (oldPos <= 9L)
/*     */     {
/* 129 */       return null;
/*     */     }
/* 131 */     long newPos = Math.max(0L, oldPos - (this.readBuf.capacity() / 2));
/*     */     
/* 133 */     this.ch.setPosition(newPos);
/* 134 */     this.readBuf.clear();
/* 135 */     this.ch.read(this.readBuf);
/* 136 */     this.readBuf.flip();
/* 137 */     this.readBuf.position((int)(oldPos - newPos));
/* 138 */     return readPrevPacket();
/*     */   }
/*     */ 
/*     */   
/*     */   private static void moveRemainderToTheStart(ByteBuffer readBuf) {
/* 143 */     int rem = readBuf.remaining();
/* 144 */     for (int i = 0; i < rem; i++) {
/* 145 */       readBuf.put(i, readBuf.get());
/*     */     }
/* 147 */     readBuf.clear();
/* 148 */     readBuf.position(rem); } public FLVTag parsePacket(ByteBuffer readBuf) throws IOException { long packetPos; int prevPacketSize, packetType, timestamp, streamId; ByteBuffer payload;
/*     */     FLVTag.Type type;
/*     */     FLVTag.TagHeader tagHeader;
/*     */     int i;
/*     */     while (true) {
/* 153 */       if (readBuf.remaining() < 15) {
/* 154 */         return null;
/*     */       }
/*     */       
/* 157 */       int pos = readBuf.position();
/* 158 */       packetPos = this.ch.position() - readBuf.remaining();
/* 159 */       prevPacketSize = readBuf.getInt();
/* 160 */       packetType = readBuf.get() & 0xFF;
/* 161 */       int payloadSize = (readBuf.getShort() & 0xFFFF) << 8 | readBuf.get() & 0xFF;
/*     */       
/* 163 */       timestamp = (readBuf.getShort() & 0xFFFF) << 8 | readBuf.get() & 0xFF | (readBuf.get() & 0xFF) << 24;
/* 164 */       streamId = (readBuf.getShort() & 0xFFFF) << 8 | readBuf.get() & 0xFF;
/*     */ 
/*     */       
/* 167 */       if (readBuf.remaining() >= payloadSize + 4) {
/* 168 */         int thisPacketSize = readBuf.getInt(readBuf.position() + payloadSize);
/* 169 */         if (thisPacketSize != payloadSize + 11) {
/* 170 */           readBuf.position(readBuf.position() - 15);
/* 171 */           if (!repositionFile()) {
/* 172 */             Logger.error(String.format("Corrupt FLV stream at %d, failed to reposition!", new Object[] { Long.valueOf(packetPos) }));
/* 173 */             this.ch.setPosition(this.ch.size());
/* 174 */             this.eof = true;
/* 175 */             return null;
/*     */           } 
/* 177 */           Logger.warn(String.format("Corrupt FLV stream at %d, repositioned to %d.", new Object[] { Long.valueOf(packetPos), Long.valueOf(this.ch.position() - readBuf
/* 178 */                     .remaining()) }));
/*     */           
/*     */           continue;
/*     */         } 
/*     */       } 
/* 183 */       if (readBuf.remaining() < payloadSize) {
/* 184 */         readBuf.position(pos);
/* 185 */         return null;
/*     */       } 
/*     */       
/* 188 */       if (packetType != 8 && packetType != 9 && packetType != 18) {
/* 189 */         NIOUtils.skip(readBuf, payloadSize);
/*     */         
/*     */         continue;
/*     */       } 
/* 193 */       payload = NIOUtils.clone(NIOUtils.read(readBuf, payloadSize));
/*     */ 
/*     */ 
/*     */       
/* 197 */       if (packetType == 8) {
/* 198 */         type = FLVTag.Type.AUDIO;
/* 199 */         tagHeader = parseAudioTagHeader(payload.duplicate()); break;
/* 200 */       }  if (packetType == 9) {
/* 201 */         type = FLVTag.Type.VIDEO;
/* 202 */         tagHeader = parseVideoTagHeader(payload.duplicate()); break;
/* 203 */       }  if (packetType == 18) {
/* 204 */         type = FLVTag.Type.SCRIPT;
/* 205 */         tagHeader = null; break;
/*     */       } 
/* 207 */       System.out.println("NON AV packet");
/*     */     } 
/*     */     
/* 210 */     boolean keyFrame = false;
/* 211 */     if (tagHeader != null && tagHeader instanceof FLVTag.VideoTagHeader) {
/* 212 */       FLVTag.VideoTagHeader vth = (FLVTag.VideoTagHeader)tagHeader;
/* 213 */       i = keyFrame & ((vth.getFrameType() == 1) ? 1 : 0);
/*     */     } 
/* 215 */     i &= (packetType == 8 || packetType == 9) ? 1 : 0;
/*     */     
/* 217 */     return new FLVTag(type, packetPos, tagHeader, timestamp, payload, i, this.frameNo++, streamId, prevPacketSize); }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static boolean readHeader(ByteBuffer readBuf) {
/* 223 */     if (readBuf.remaining() < 9 || readBuf.get() != 70 || readBuf.get() != 76 || readBuf.get() != 86 || readBuf
/* 224 */       .get() != 1 || (readBuf.get() & 0x5) == 0 || readBuf.getInt() != 9) {
/* 225 */       return false;
/*     */     }
/* 227 */     return true;
/*     */   }
/*     */   
/*     */   public static FLVMetadata parseMetadata(ByteBuffer bb) {
/* 231 */     if ("onMetaData".equals(readAMFData(bb, -1)))
/* 232 */       return new FLVMetadata((Map<String, Object>)readAMFData(bb, -1)); 
/* 233 */     return null;
/*     */   }
/*     */   private static Object readAMFData(ByteBuffer input, int type) {
/*     */     Date date;
/* 237 */     if (type == -1) {
/* 238 */       type = input.get() & 0xFF;
/*     */     }
/* 240 */     switch (type) {
/*     */       case 0:
/* 242 */         return Double.valueOf(input.getDouble());
/*     */       case 1:
/* 244 */         return Boolean.valueOf((input.get() == 1));
/*     */       case 2:
/* 246 */         return readAMFString(input);
/*     */       case 3:
/* 248 */         return readAMFObject(input);
/*     */       case 8:
/* 250 */         return readAMFEcmaArray(input);
/*     */       case 10:
/* 252 */         return readAMFStrictArray(input);
/*     */       case 11:
/* 254 */         date = new Date((long)input.getDouble());
/* 255 */         input.getShort();
/* 256 */         return date;
/*     */       case 13:
/* 258 */         return "UNDEFINED";
/*     */     } 
/* 260 */     return null;
/*     */   }
/*     */ 
/*     */   
/*     */   private static Object readAMFStrictArray(ByteBuffer input) {
/* 265 */     int count = input.getInt();
/* 266 */     Object[] result = new Object[count];
/* 267 */     for (int i = 0; i < count; i++) {
/* 268 */       result[i] = readAMFData(input, -1);
/*     */     }
/* 270 */     return result;
/*     */   }
/*     */   
/*     */   private static String readAMFString(ByteBuffer input) {
/* 274 */     int size = input.getShort() & 0xFFFF;
/* 275 */     return Platform.stringFromCharset(NIOUtils.toArray(NIOUtils.read(input, size)), "UTF-8");
/*     */   }
/*     */   
/*     */   private static Object readAMFObject(ByteBuffer input) {
/* 279 */     Map<String, Object> array = new HashMap<String, Object>();
/*     */     while (true) {
/* 281 */       String key = readAMFString(input);
/* 282 */       int dataType = input.get() & 0xFF;
/* 283 */       if (dataType == 9) {
/*     */         break;
/*     */       }
/* 286 */       array.put(key, readAMFData(input, dataType));
/*     */     } 
/* 288 */     return array;
/*     */   }
/*     */   
/*     */   private static Object readAMFEcmaArray(ByteBuffer input) {
/* 292 */     long size = input.getInt();
/* 293 */     Map<String, Object> array = new HashMap<String, Object>();
/* 294 */     for (int i = 0; i < size; i++) {
/* 295 */       String key = readAMFString(input);
/* 296 */       int dataType = input.get() & 0xFF;
/* 297 */       array.put(key, readAMFData(input, dataType));
/*     */     } 
/* 299 */     return array;
/*     */   }
/*     */   
/*     */   public static FLVTag.VideoTagHeader parseVideoTagHeader(ByteBuffer dup) {
/* 303 */     byte b0 = dup.get();
/* 304 */     int frameType = (b0 & 0xFF) >> 4;
/* 305 */     int codecId = b0 & 0xF;
/* 306 */     Codec codec = videoCodecMapping[codecId];
/*     */     
/* 308 */     if (codecId == 7) {
/* 309 */       byte avcPacketType = dup.get();
/* 310 */       int compOffset = dup.getShort() << 8 | dup.get() & 0xFF;
/* 311 */       return new FLVTag.AvcVideoTagHeader(codec, frameType, avcPacketType, compOffset);
/*     */     } 
/*     */     
/* 314 */     return new FLVTag.VideoTagHeader(codec, frameType);
/*     */   }
/*     */   
/*     */   public static FLVTag.TagHeader parseAudioTagHeader(ByteBuffer dup) {
/* 318 */     byte b = dup.get();
/*     */     
/* 320 */     int codecId = (b & 0xFF) >> 4;
/* 321 */     int sampleRate = sampleRates[b >> 2 & 0x3];
/* 322 */     if (codecId == 4 || codecId == 11)
/* 323 */       sampleRate = 16000; 
/* 324 */     if (codecId == 5 || codecId == 14) {
/* 325 */       sampleRate = 8000;
/*     */     }
/* 327 */     int sampleSizeInBits = ((b & 0x2) == 0) ? 8 : 16;
/* 328 */     boolean signed = ((codecId != 3 && codecId != 0) || sampleSizeInBits == 16);
/* 329 */     int channelCount = 1 + (b & 0x1);
/* 330 */     if (codecId == 11) {
/* 331 */       channelCount = 1;
/*     */     }
/* 333 */     AudioFormat audioFormat = new AudioFormat(sampleRate, sampleSizeInBits, channelCount, signed, (codecId == 3) ? false : platformBigEndian);
/*     */     
/* 335 */     Codec codec = audioCodecMapping[codecId];
/* 336 */     if (codecId == 10) {
/* 337 */       byte packetType = dup.get();
/* 338 */       return new FLVTag.AacAudioTagHeader(codec, audioFormat, packetType);
/*     */     } 
/*     */     
/* 341 */     return new FLVTag.AudioTagHeader(codec, audioFormat);
/*     */   }
/*     */   
/*     */   public static int probe(ByteBuffer buf) {
/*     */     try {
/* 346 */       readHeader(buf);
/* 347 */       return 100;
/* 348 */     } catch (RuntimeException e) {
/* 349 */       return 0;
/*     */     } 
/*     */   }
/*     */   
/*     */   public void reset() throws IOException {
/* 354 */     initialRead((ReadableByteChannel)this.ch);
/*     */   }
/*     */   
/*     */   public void reposition() throws IOException {
/* 358 */     reset();
/*     */     
/* 360 */     if (!positionAtPacket(this.readBuf)) {
/* 361 */       throw new RuntimeException("Could not find at FLV tag start");
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public static boolean positionAtPacket(ByteBuffer readBuf) {
/* 368 */     ByteBuffer dup = readBuf.duplicate();
/* 369 */     int payloadSize = 0;
/* 370 */     NIOUtils.skip(dup, 5);
/* 371 */     while (dup.hasRemaining()) {
/* 372 */       payloadSize = (payloadSize & 0xFFFF) << 8 | dup.get() & 0xFF;
/* 373 */       int pointerPos = dup.position() + 7 + payloadSize;
/* 374 */       if (dup.position() >= 8 && pointerPos < dup.limit() - 4 && dup.getInt(pointerPos) - payloadSize == 11) {
/* 375 */         readBuf.position(dup.position() - 8);
/* 376 */         return true;
/*     */       } 
/*     */     } 
/* 379 */     return false;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean repositionFile() throws IOException {
/* 389 */     int payloadSize = 0;
/* 390 */     for (int i = 0; i < 10; i++) {
/* 391 */       while (this.readBuf.hasRemaining()) {
/* 392 */         payloadSize = (payloadSize & 0xFFFF) << 8 | this.readBuf.get() & 0xFF;
/* 393 */         int pointerPos = this.readBuf.position() + 7 + payloadSize;
/* 394 */         if (this.readBuf.position() >= 8 && pointerPos < this.readBuf.limit() - 4 && this.readBuf
/* 395 */           .getInt(pointerPos) - payloadSize == 11) {
/* 396 */           this.readBuf.position(this.readBuf.position() - 8);
/* 397 */           return true;
/*     */         } 
/*     */       } 
/* 400 */       initialRead((ReadableByteChannel)this.ch);
/* 401 */       if (!this.readBuf.hasRemaining())
/*     */         break; 
/*     */     } 
/* 404 */     return false;
/*     */   }
/*     */ }


/* Location:              C:\Users\rapha\Downloads\aurora.jar!\META-INF\jars\jcodec-0.2.5.jar!\org\jcodec\containers\flv\FLVReader.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */