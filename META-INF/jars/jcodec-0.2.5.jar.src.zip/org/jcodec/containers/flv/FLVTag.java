/*     */ package org.jcodec.containers.flv;
/*     */ 
/*     */ import java.nio.ByteBuffer;
/*     */ import org.jcodec.common.AudioFormat;
/*     */ import org.jcodec.common.Codec;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class FLVTag
/*     */ {
/*     */   private Type type;
/*     */   private long position;
/*     */   private TagHeader tagHeader;
/*     */   private int pts;
/*     */   private ByteBuffer data;
/*     */   private boolean keyFrame;
/*     */   private long frameNo;
/*     */   private int streamId;
/*     */   private int prevPacketSize;
/*     */   
/*     */   public FLVTag(Type type, long position, TagHeader tagHeader, int pts, ByteBuffer data, boolean keyFrame, long frameNo, int streamId, int prevPacketSize) {
/*  29 */     this.type = type;
/*  30 */     this.position = position;
/*  31 */     this.tagHeader = tagHeader;
/*  32 */     this.pts = pts;
/*  33 */     this.data = data;
/*  34 */     this.keyFrame = keyFrame;
/*  35 */     this.frameNo = frameNo;
/*  36 */     this.streamId = streamId;
/*  37 */     this.prevPacketSize = prevPacketSize;
/*     */   }
/*     */   
/*     */   public enum Type {
/*  41 */     VIDEO, AUDIO, SCRIPT;
/*     */   }
/*     */   
/*     */   public Type getType() {
/*  45 */     return this.type;
/*     */   }
/*     */   
/*     */   public long getPosition() {
/*  49 */     return this.position;
/*     */   }
/*     */   
/*     */   public TagHeader getTagHeader() {
/*  53 */     return this.tagHeader;
/*     */   }
/*     */   
/*     */   public int getPts() {
/*  57 */     return this.pts;
/*     */   }
/*     */   
/*     */   public void setPts(int pts) {
/*  61 */     this.pts = pts;
/*     */   }
/*     */   
/*     */   public int getStreamId() {
/*  65 */     return this.streamId;
/*     */   }
/*     */   
/*     */   public void setStreamId(int streamId) {
/*  69 */     this.streamId = streamId;
/*     */   }
/*     */   
/*     */   public int getPrevPacketSize() {
/*  73 */     return this.prevPacketSize;
/*     */   }
/*     */   
/*     */   public void setPrevPacketSize(int prevPacketSize) {
/*  77 */     this.prevPacketSize = prevPacketSize;
/*     */   }
/*     */   
/*     */   public ByteBuffer getData() {
/*  81 */     return this.data;
/*     */   }
/*     */   
/*     */   public double getPtsD() {
/*  85 */     return this.pts / 1000.0D;
/*     */   }
/*     */   
/*     */   public boolean isKeyFrame() {
/*  89 */     return this.keyFrame;
/*     */   }
/*     */   
/*     */   public long getFrameNo() {
/*  93 */     return this.frameNo;
/*     */   }
/*     */   
/*     */   public static class TagHeader
/*     */   {
/*     */     private Codec codec;
/*     */     
/*     */     public TagHeader(Codec codec) {
/* 101 */       this.codec = codec;
/*     */     }
/*     */     
/*     */     public Codec getCodec() {
/* 105 */       return this.codec;
/*     */     }
/*     */   }
/*     */   
/*     */   public static class VideoTagHeader
/*     */     extends TagHeader {
/*     */     private int frameType;
/*     */     
/*     */     public VideoTagHeader(Codec codec, int frameType) {
/* 114 */       super(codec);
/* 115 */       this.frameType = frameType;
/*     */     }
/*     */     
/*     */     public int getFrameType() {
/* 119 */       return this.frameType;
/*     */     }
/*     */   }
/*     */   
/*     */   public static class AvcVideoTagHeader
/*     */     extends VideoTagHeader {
/*     */     private int compOffset;
/*     */     private byte avcPacketType;
/*     */     
/*     */     public AvcVideoTagHeader(Codec codec, int frameType, byte avcPacketType, int compOffset) {
/* 129 */       super(codec, frameType);
/* 130 */       this.avcPacketType = avcPacketType;
/* 131 */       this.compOffset = compOffset;
/*     */     }
/*     */     
/*     */     public int getCompOffset() {
/* 135 */       return this.compOffset;
/*     */     }
/*     */     
/*     */     public byte getAvcPacketType() {
/* 139 */       return this.avcPacketType;
/*     */     }
/*     */   }
/*     */   
/*     */   public static class AudioTagHeader
/*     */     extends TagHeader {
/*     */     private AudioFormat audioFormat;
/*     */     
/*     */     public AudioTagHeader(Codec codec, AudioFormat audioFormat) {
/* 148 */       super(codec);
/* 149 */       this.audioFormat = audioFormat;
/*     */     }
/*     */     
/*     */     public AudioFormat getAudioFormat() {
/* 153 */       return this.audioFormat;
/*     */     }
/*     */   }
/*     */   
/*     */   public static class AacAudioTagHeader
/*     */     extends AudioTagHeader {
/*     */     private int packetType;
/*     */     
/*     */     public AacAudioTagHeader(Codec codec, AudioFormat audioFormat, int packetType) {
/* 162 */       super(codec, audioFormat);
/* 163 */       this.packetType = packetType;
/*     */     }
/*     */     
/*     */     public int getPacketType() {
/* 167 */       return this.packetType;
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\rapha\Downloads\aurora.jar!\META-INF\jars\jcodec-0.2.5.jar!\org\jcodec\containers\flv\FLVTag.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */