/*     */ package org.jcodec.containers.flv;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.nio.ByteBuffer;
/*     */ import java.util.Iterator;
/*     */ import java.util.LinkedList;
/*     */ import java.util.ListIterator;
/*     */ import org.jcodec.common.Codec;
/*     */ import org.jcodec.common.DemuxerTrack;
/*     */ import org.jcodec.common.DemuxerTrackMeta;
/*     */ import org.jcodec.common.LongArrayList;
/*     */ import org.jcodec.common.SeekableDemuxerTrack;
/*     */ import org.jcodec.common.TrackType;
/*     */ import org.jcodec.common.io.SeekableByteChannel;
/*     */ import org.jcodec.common.model.Packet;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class FLVTrackDemuxer
/*     */ {
/*     */   private static final int MAX_CRAWL_DISTANCE_SEC = 10;
/*     */   private FLVReader demuxer;
/*     */   private FLVDemuxerTrack video;
/*     */   private FLVDemuxerTrack audio;
/*     */   private LinkedList<FLVTag> packets;
/*     */   private SeekableByteChannel _in;
/*     */   
/*     */   public static class FLVDemuxerTrack
/*     */     implements SeekableDemuxerTrack
/*     */   {
/*     */     private FLVTag.Type type;
/*     */     private int curFrame;
/*     */     private Codec codec;
/*     */     private LongArrayList framePositions;
/*     */     private byte[] codecPrivate;
/*     */     private FLVTrackDemuxer demuxer;
/*     */     
/*     */     public FLVDemuxerTrack(FLVTrackDemuxer demuxer, FLVTag.Type type) throws IOException {
/*  50 */       this.framePositions = LongArrayList.createLongArrayList();
/*  51 */       this.demuxer = demuxer;
/*  52 */       this.type = type;
/*  53 */       FLVTag frame = demuxer.nextFrameI(type, false);
/*  54 */       this.codec = frame.getTagHeader().getCodec();
/*     */     }
/*     */ 
/*     */     
/*     */     public Packet nextFrame() throws IOException {
/*  59 */       FLVTag frame = this.demuxer.nextFrameI(this.type, true);
/*  60 */       this.framePositions.add(frame.getPosition());
/*  61 */       return toPacket(frame);
/*     */     }
/*     */     
/*     */     public Packet prevFrame() throws IOException {
/*  65 */       FLVTag frame = this.demuxer.prevFrameI(this.type, true);
/*     */       
/*  67 */       return toPacket(frame);
/*     */     }
/*     */     
/*     */     public Packet pickFrame() throws IOException {
/*  71 */       FLVTag frame = this.demuxer.nextFrameI(this.type, false);
/*     */       
/*  73 */       return toPacket(frame);
/*     */     }
/*     */     
/*     */     private Packet toPacket(FLVTag frame) {
/*  77 */       return null;
/*     */     }
/*     */ 
/*     */     
/*     */     public DemuxerTrackMeta getMeta() {
/*  82 */       TrackType t = (this.type == FLVTag.Type.VIDEO) ? TrackType.VIDEO : TrackType.AUDIO;
/*  83 */       return new DemuxerTrackMeta(t, this.codec, 0.0D, null, 0, ByteBuffer.wrap(this.codecPrivate), null, null);
/*     */     }
/*     */ 
/*     */     
/*     */     public boolean gotoFrame(long i) throws IOException {
/*  88 */       if (i >= this.framePositions.size())
/*  89 */         return false; 
/*  90 */       this.demuxer.resetToPosition(this.framePositions.get((int)i));
/*  91 */       return true;
/*     */     }
/*     */ 
/*     */     
/*     */     public boolean gotoSyncFrame(long i) {
/*  96 */       throw new RuntimeException();
/*     */     }
/*     */ 
/*     */     
/*     */     public long getCurFrame() {
/* 101 */       return this.curFrame;
/*     */     }
/*     */ 
/*     */     
/*     */     public void seek(double second) throws IOException {
/* 106 */       this.demuxer.seekI(second);
/*     */     }
/*     */   }
/*     */   
/*     */   public FLVTrackDemuxer(SeekableByteChannel _in) throws IOException {
/* 111 */     this.packets = new LinkedList<FLVTag>();
/* 112 */     this._in = _in;
/* 113 */     _in.setPosition(0L);
/* 114 */     this.demuxer = new FLVReader(_in);
/* 115 */     this.video = new FLVDemuxerTrack(this, FLVTag.Type.VIDEO);
/* 116 */     this.audio = new FLVDemuxerTrack(this, FLVTag.Type.AUDIO);
/*     */   }
/*     */   
/*     */   private void resetToPosition(long position) throws IOException {
/* 120 */     this._in.setPosition(position);
/* 121 */     this.demuxer.reset();
/* 122 */     this.packets.clear();
/*     */   }
/*     */   
/*     */   private void seekI(double second) throws IOException {
/* 126 */     this.packets.clear();
/*     */     FLVTag base;
/* 128 */     while ((base = this.demuxer.readNextPacket()) != null && base.getPtsD() == 0.0D);
/*     */ 
/*     */     
/* 131 */     if (base == null) {
/*     */       return;
/*     */     }
/*     */ 
/*     */     
/* 136 */     this._in.setPosition(base.getPosition() + 1048576L);
/* 137 */     this.demuxer.reposition();
/* 138 */     FLVTag off = this.demuxer.readNextPacket();
/*     */     
/* 140 */     int byteRate = (int)((off.getPosition() - base.getPosition()) / (off.getPtsD() - base.getPtsD()));
/* 141 */     long offset = base.getPosition() + (long)((second - base.getPtsD()) * byteRate);
/*     */     
/* 143 */     this._in.setPosition(offset);
/* 144 */     this.demuxer.reposition();
/*     */ 
/*     */     
/* 147 */     for (int i = 0; i < 5; i++) {
/* 148 */       FLVTag pkt = this.demuxer.readNextPacket();
/* 149 */       double distance = second - pkt.getPtsD();
/* 150 */       if (distance > 0.0D && distance < 10.0D) {
/*     */         
/* 152 */         System.out.println("Crawling forward: " + distance);
/*     */         FLVTag testPkt;
/* 154 */         while ((testPkt = this.demuxer.readNextPacket()) != null && testPkt.getPtsD() < second);
/*     */         
/* 156 */         if (testPkt != null)
/* 157 */           this.packets.add(pkt);  return;
/*     */       } 
/* 159 */       if (distance < 0.0D && distance > -10.0D) {
/*     */         
/* 161 */         System.out.println("Overshoot by: " + -distance);
/* 162 */         this._in.setPosition(pkt.getPosition() + (long)((distance - 1.0D) * byteRate));
/* 163 */         this.demuxer.reposition();
/*     */       } 
/*     */     } 
/*     */   }
/*     */   
/*     */   private FLVTag nextFrameI(FLVTag.Type type, boolean remove) throws IOException {
/* 169 */     for (Iterator<FLVTag> it = this.packets.iterator(); it.hasNext(); ) {
/* 170 */       FLVTag fLVTag = it.next();
/* 171 */       if (fLVTag.getType() == type) {
/* 172 */         if (remove)
/* 173 */           it.remove(); 
/* 174 */         return fLVTag;
/*     */       } 
/*     */     } 
/*     */     FLVTag pkt;
/* 178 */     while ((pkt = this.demuxer.readNextPacket()) != null && pkt.getType() != type)
/* 179 */       this.packets.add(pkt); 
/* 180 */     if (!remove) {
/* 181 */       this.packets.add(pkt);
/*     */     }
/* 183 */     return pkt;
/*     */   }
/*     */   
/*     */   private FLVTag prevFrameI(FLVTag.Type type, boolean remove) throws IOException {
/* 187 */     for (ListIterator<FLVTag> it = this.packets.listIterator(); it.hasPrevious(); ) {
/* 188 */       FLVTag fLVTag = it.previous();
/* 189 */       if (fLVTag.getType() == type) {
/* 190 */         if (remove)
/* 191 */           it.remove(); 
/* 192 */         return fLVTag;
/*     */       } 
/*     */     } 
/*     */     FLVTag pkt;
/* 196 */     while ((pkt = this.demuxer.readPrevPacket()) != null && pkt.getType() != type)
/* 197 */       this.packets.add(0, pkt); 
/* 198 */     if (!remove) {
/* 199 */       this.packets.add(0, pkt);
/*     */     }
/* 201 */     return pkt;
/*     */   }
/*     */ 
/*     */   
/*     */   public DemuxerTrack[] getTracks() {
/* 206 */     return new DemuxerTrack[] { (DemuxerTrack)this.video, (DemuxerTrack)this.audio };
/*     */   }
/*     */   
/*     */   public DemuxerTrack getVideoTrack() {
/* 210 */     return (DemuxerTrack)this.video;
/*     */   }
/*     */   
/*     */   public DemuxerTrack getAudioTrack() {
/* 214 */     return (DemuxerTrack)this.video;
/*     */   }
/*     */ }


/* Location:              C:\Users\rapha\Downloads\aurora.jar!\META-INF\jars\jcodec-0.2.5.jar!\org\jcodec\containers\flv\FLVTrackDemuxer.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */