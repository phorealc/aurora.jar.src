/*     */ package org.jcodec.containers.flv;
/*     */ 
/*     */ import java.io.Closeable;
/*     */ import java.io.File;
/*     */ import java.io.IOException;
/*     */ import java.nio.ByteBuffer;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Arrays;
/*     */ import java.util.HashMap;
/*     */ import java.util.LinkedList;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import org.jcodec.codecs.h264.H264Utils;
/*     */ import org.jcodec.codecs.h264.io.model.PictureParameterSet;
/*     */ import org.jcodec.codecs.h264.io.model.SeqParameterSet;
/*     */ import org.jcodec.codecs.h264.mp4.AvcCBox;
/*     */ import org.jcodec.common.AudioFormat;
/*     */ import org.jcodec.common.Codec;
/*     */ import org.jcodec.common.StringUtils;
/*     */ import org.jcodec.common.io.FileChannelWrapper;
/*     */ import org.jcodec.common.io.IOUtils;
/*     */ import org.jcodec.common.io.NIOUtils;
/*     */ import org.jcodec.common.io.SeekableByteChannel;
/*     */ import org.jcodec.common.logging.Logger;
/*     */ import org.jcodec.common.tools.MainUtils;
/*     */ import org.jcodec.platform.Platform;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class FLVTool
/*     */ {
/*  51 */   private static Map<String, PacketProcessorFactory> processors = new HashMap<String, PacketProcessorFactory>();
/*     */   static {
/*  53 */     processors.put("clip", new ClipPacketProcessor.Factory());
/*  54 */     processors.put("fix_pts", new FixPtsProcessor.Factory());
/*  55 */     processors.put("info", new InfoPacketProcessor.Factory());
/*  56 */     processors.put("shift_pts", new ShiftPtsProcessor.Factory());
/*     */   }
/*     */   
/*  59 */   private static final MainUtils.Flag FLAG_MAX_PACKETS = MainUtils.Flag.flag("max-packets", "m", "Maximum number of packets to process");
/*     */   public static void main1(String[] args) throws IOException {
/*     */     FileChannelWrapper fileChannelWrapper1, fileChannelWrapper2;
/*  62 */     if (args.length < 1) {
/*  63 */       printGenericHelp();
/*     */       return;
/*     */     } 
/*  66 */     String command = args[0];
/*  67 */     PacketProcessorFactory processorFactory = processors.get(command);
/*  68 */     if (processorFactory == null) {
/*  69 */       System.err.println("Unknown command: " + command);
/*  70 */       printGenericHelp();
/*     */       
/*     */       return;
/*     */     } 
/*  74 */     MainUtils.Cmd cmd = MainUtils.parseArguments((String[])Platform.copyOfRangeO((Object[])args, 1, args.length), processorFactory.getFlags());
/*  75 */     if (cmd.args.length < 1) {
/*  76 */       MainUtils.printHelpCmd(command, processorFactory.getFlags(), Arrays.asList(new String[] { "file in", "?file out" }));
/*     */       return;
/*     */     } 
/*  79 */     PacketProcessor processor = processorFactory.newPacketProcessor(cmd);
/*  80 */     int maxPackets = cmd.getIntegerFlagD(FLAG_MAX_PACKETS, Integer.valueOf(2147483647)).intValue();
/*     */     
/*  82 */     SeekableByteChannel _in = null;
/*  83 */     SeekableByteChannel out = null;
/*     */     try {
/*  85 */       fileChannelWrapper1 = NIOUtils.readableChannel(new File(cmd.getArg(0)));
/*  86 */       if (processor.hasOutput())
/*  87 */         fileChannelWrapper2 = NIOUtils.writableChannel(new File(cmd.getArg(1))); 
/*  88 */       FLVReader demuxer = new FLVReader((SeekableByteChannel)fileChannelWrapper1);
/*  89 */       FLVWriter muxer = new FLVWriter((SeekableByteChannel)fileChannelWrapper2);
/*  90 */       FLVTag pkt = null;
/*  91 */       for (int i = 0; i < maxPackets && (pkt = demuxer.readNextPacket()) != null && 
/*  92 */         processor.processPacket(pkt, muxer); i++);
/*     */ 
/*     */       
/*  95 */       processor.finish(muxer);
/*  96 */       if (processor.hasOutput())
/*  97 */         muxer.finish(); 
/*     */     } finally {
/*  99 */       IOUtils.closeQuietly((Closeable)fileChannelWrapper1);
/* 100 */       IOUtils.closeQuietly((Closeable)fileChannelWrapper2);
/*     */     } 
/*     */   }
/*     */   
/*     */   private static void printGenericHelp() {
/* 105 */     System.err.println("Syntax: <command> [flags] <file in> [file out]\nWhere command is: [" + 
/* 106 */         StringUtils.joinS(processors.keySet().toArray((Object[])new String[0]), ", ") + "].");
/*     */   }
/*     */   
/*     */   private static PacketProcessor getProcessor(String command, MainUtils.Cmd cmd) {
/* 110 */     PacketProcessorFactory factory = processors.get(command);
/* 111 */     if (factory == null)
/* 112 */       return null; 
/* 113 */     return factory.newPacketProcessor(cmd);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static class ClipPacketProcessor
/*     */     implements PacketProcessor
/*     */   {
/*     */     private static FLVTag h264Config;
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     private boolean copying = false;
/*     */ 
/*     */ 
/*     */     
/*     */     private Double from;
/*     */ 
/*     */ 
/*     */     
/*     */     private Double to;
/*     */ 
/*     */ 
/*     */     
/* 140 */     private static final MainUtils.Flag FLAG_FROM = MainUtils.Flag.flag("from", null, "From timestamp (in seconds, i.e 67.49)");
/* 141 */     private static final MainUtils.Flag FLAG_TO = MainUtils.Flag.flag("to", null, "To timestamp");
/*     */     
/*     */     public static class Factory
/*     */       implements FLVTool.PacketProcessorFactory {
/*     */       public FLVTool.PacketProcessor newPacketProcessor(MainUtils.Cmd flags) {
/* 146 */         return new FLVTool.ClipPacketProcessor(flags.getDoubleFlag(FLVTool.ClipPacketProcessor.FLAG_FROM), flags.getDoubleFlag(FLVTool.ClipPacketProcessor.FLAG_TO));
/*     */       }
/*     */ 
/*     */       
/*     */       public MainUtils.Flag[] getFlags() {
/* 151 */         return new MainUtils.Flag[] { FLVTool.ClipPacketProcessor.access$000(), FLVTool.ClipPacketProcessor.access$100() };
/*     */       }
/*     */     }
/*     */     
/*     */     public ClipPacketProcessor(Double from, Double to) {
/* 156 */       this.from = from;
/* 157 */       this.to = to;
/*     */     }
/*     */     
/*     */     public boolean processPacket(FLVTag pkt, FLVWriter writer) throws IOException {
/* 161 */       if (pkt.getType() == FLVTag.Type.VIDEO && pkt.getTagHeader().getCodec() == Codec.H264 && (
/* 162 */         (FLVTag.AvcVideoTagHeader)pkt.getTagHeader()).getAvcPacketType() == 0) {
/* 163 */         h264Config = pkt;
/* 164 */         System.out.println("GOT AVCC");
/*     */       } 
/*     */ 
/*     */       
/* 168 */       if (!this.copying && (this.from == null || pkt.getPtsD() > this.from.doubleValue()) && pkt.getType() == FLVTag.Type.VIDEO && pkt.isKeyFrame() && h264Config != null) {
/*     */         
/* 170 */         System.out.println("Starting at packet: " + Platform.toJSON(pkt));
/* 171 */         this.copying = true;
/* 172 */         h264Config.setPts(pkt.getPts());
/* 173 */         writer.addPacket(h264Config);
/*     */       } 
/*     */       
/* 176 */       if (this.to != null && pkt.getPtsD() >= this.to.doubleValue()) {
/* 177 */         System.out.println("Stopping at packet: " + Platform.toJSON(pkt));
/* 178 */         return false;
/*     */       } 
/* 180 */       if (this.copying)
/* 181 */         writer.addPacket(pkt); 
/* 182 */       return true;
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     public void finish(FLVWriter muxer) {}
/*     */ 
/*     */     
/*     */     public boolean hasOutput() {
/* 191 */       return true;
/*     */     }
/*     */   }
/*     */   public static class Factory implements PacketProcessorFactory { public FLVTool.PacketProcessor newPacketProcessor(MainUtils.Cmd flags) {
/*     */       return new FLVTool.ClipPacketProcessor(flags.getDoubleFlag(FLVTool.ClipPacketProcessor.FLAG_FROM), flags.getDoubleFlag(FLVTool.ClipPacketProcessor.FLAG_TO));
/*     */     }
/*     */     public MainUtils.Flag[] getFlags() {
/*     */       return new MainUtils.Flag[] { FLVTool.ClipPacketProcessor.access$000(), FLVTool.ClipPacketProcessor.access$100() };
/*     */     } }
/* 200 */   public static class FixPtsProcessor implements PacketProcessor { private double lastPtsAudio = 0.0D;
/* 201 */     private double lastPtsVideo = 0.0D;
/*     */     private List<FLVTag> tags;
/*     */     private int audioTagsInQueue;
/*     */     private int videoTagsInQueue;
/*     */     private static final double CORRECTION_PACE = 0.33D;
/*     */     
/*     */     public static class Factory
/*     */       implements FLVTool.PacketProcessorFactory {
/*     */       public FLVTool.PacketProcessor newPacketProcessor(MainUtils.Cmd flags) {
/* 210 */         return new FLVTool.FixPtsProcessor();
/*     */       }
/*     */ 
/*     */       
/*     */       public MainUtils.Flag[] getFlags() {
/* 215 */         return new MainUtils.Flag[0];
/*     */       }
/*     */     }
/*     */     
/*     */     public FixPtsProcessor() {
/* 220 */       this.tags = new ArrayList<FLVTag>();
/*     */     }
/*     */     
/*     */     public boolean processPacket(FLVTag pkt, FLVWriter writer) throws IOException {
/* 224 */       this.tags.add(pkt);
/* 225 */       if (pkt.getType() == FLVTag.Type.AUDIO) {
/* 226 */         this.audioTagsInQueue++;
/* 227 */       } else if (pkt.getType() == FLVTag.Type.VIDEO) {
/* 228 */         this.videoTagsInQueue++;
/*     */       } 
/*     */       
/* 231 */       if (this.tags.size() < 600) {
/* 232 */         return true;
/*     */       }
/* 234 */       processOneTag(writer);
/* 235 */       return true;
/*     */     }
/*     */     
/*     */     private void processOneTag(FLVWriter writer) throws IOException {
/* 239 */       FLVTag tag = this.tags.remove(0);
/*     */       
/* 241 */       if (tag.getType() == FLVTag.Type.AUDIO) {
/* 242 */         tag.setPts((int)Math.round(this.lastPtsAudio * 1000.0D));
/* 243 */         this.lastPtsAudio += audioFrameDuration((FLVTag.AudioTagHeader)tag.getTagHeader());
/* 244 */         this.audioTagsInQueue--;
/* 245 */       } else if (tag.getType() == FLVTag.Type.VIDEO) {
/* 246 */         double duration = 1024.0D * this.audioTagsInQueue / (48000 * this.videoTagsInQueue);
/* 247 */         tag.setPts((int)Math.round(this.lastPtsVideo * 1000.0D));
/* 248 */         this.lastPtsVideo += Math.min(1.33D * duration, Math.max(0.6699999999999999D * duration, duration + 
/* 249 */               Math.min(1.0D, Math.abs(this.lastPtsAudio - this.lastPtsVideo)) * (this.lastPtsAudio - this.lastPtsVideo)));
/* 250 */         this.videoTagsInQueue--;
/* 251 */         System.out.println(this.lastPtsVideo + " - " + this.lastPtsAudio);
/*     */       } else {
/* 253 */         tag.setPts((int)Math.round(this.lastPtsVideo * 1000.0D));
/*     */       } 
/*     */       
/* 256 */       writer.addPacket(tag);
/*     */     }
/*     */     
/*     */     private double audioFrameDuration(FLVTag.AudioTagHeader audioTagHeader) {
/* 260 */       if (Codec.AAC == audioTagHeader.getCodec())
/* 261 */         return 1024.0D / audioTagHeader.getAudioFormat().getSampleRate(); 
/* 262 */       if (Codec.MP3 == audioTagHeader.getCodec()) {
/* 263 */         return 1152.0D / audioTagHeader.getAudioFormat().getSampleRate();
/*     */       }
/* 265 */       throw new RuntimeException("Audio codec:" + audioTagHeader.getCodec() + " is not supported.");
/*     */     }
/*     */ 
/*     */     
/*     */     public void finish(FLVWriter muxer) throws IOException {
/* 270 */       while (this.tags.size() > 0) {
/* 271 */         processOneTag(muxer);
/*     */       }
/*     */     }
/*     */ 
/*     */     
/*     */     public boolean hasOutput() {
/* 277 */       return true;
/*     */     } }
/*     */   public static class Factory implements PacketProcessorFactory { public FLVTool.PacketProcessor newPacketProcessor(MainUtils.Cmd flags) {
/*     */       return new FLVTool.FixPtsProcessor();
/*     */     }
/*     */     public MainUtils.Flag[] getFlags() {
/*     */       return new MainUtils.Flag[0];
/*     */     } }
/*     */   public static class InfoPacketProcessor implements PacketProcessor {
/*     */     private FLVTag prevVideoTag; private FLVTag prevAudioTag;
/*     */     private boolean checkOnly;
/*     */     private FLVTag.Type streamType;
/*     */     
/* 290 */     public static class Factory implements FLVTool.PacketProcessorFactory { private static final MainUtils.Flag FLAG_CHECK = MainUtils.Flag.flag("check", null, "Check sanity and report errors only, no packet dump will be generated.");
/* 291 */       private static final MainUtils.Flag FLAG_STREAM = MainUtils.Flag.flag("stream", null, "Stream selector, can be one of: ['video', 'audio', 'script'].");
/*     */ 
/*     */       
/*     */       public FLVTool.PacketProcessor newPacketProcessor(MainUtils.Cmd flags) {
/* 295 */         return new FLVTool.InfoPacketProcessor(flags.getBooleanFlagD(FLAG_CHECK, Boolean.valueOf(false)).booleanValue(), (FLVTag.Type)flags
/* 296 */             .getEnumFlagD(FLAG_STREAM, null, FLVTag.Type.class));
/*     */       }
/*     */ 
/*     */       
/*     */       public MainUtils.Flag[] getFlags() {
/* 301 */         return new MainUtils.Flag[] { FLAG_CHECK, FLAG_STREAM };
/*     */       } }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public InfoPacketProcessor(boolean checkOnly, FLVTag.Type streamType) {
/* 309 */       this.checkOnly = checkOnly;
/* 310 */       this.streamType = streamType;
/*     */     }
/*     */ 
/*     */     
/*     */     public boolean processPacket(FLVTag pkt, FLVWriter writer) throws IOException {
/* 315 */       if (this.checkOnly)
/* 316 */         return true; 
/* 317 */       if (pkt.getType() == FLVTag.Type.VIDEO) {
/* 318 */         if (this.streamType == FLVTag.Type.VIDEO || this.streamType == null) {
/* 319 */           if (this.prevVideoTag != null)
/* 320 */             dumpOnePacket(this.prevVideoTag, pkt.getPts() - this.prevVideoTag.getPts()); 
/* 321 */           this.prevVideoTag = pkt;
/*     */         } 
/* 323 */       } else if (pkt.getType() == FLVTag.Type.AUDIO) {
/* 324 */         if (this.streamType == FLVTag.Type.AUDIO || this.streamType == null) {
/* 325 */           if (this.prevAudioTag != null)
/* 326 */             dumpOnePacket(this.prevAudioTag, pkt.getPts() - this.prevAudioTag.getPts()); 
/* 327 */           this.prevAudioTag = pkt;
/*     */         } 
/*     */       } else {
/* 330 */         dumpOnePacket(pkt, 0);
/*     */       } 
/*     */       
/* 333 */       return true;
/*     */     }
/*     */     
/*     */     private void dumpOnePacket(FLVTag pkt, int duration) {
/* 337 */       System.out.print("T=" + typeString(pkt.getType()) + "|PTS=" + pkt.getPts() + "|DUR=" + duration + "|" + (
/* 338 */           pkt.isKeyFrame() ? "K" : " ") + "|POS=" + pkt.getPosition());
/* 339 */       if (pkt.getTagHeader() instanceof FLVTag.VideoTagHeader) {
/* 340 */         FLVTag.VideoTagHeader vt = (FLVTag.VideoTagHeader)pkt.getTagHeader();
/* 341 */         System.out.print("|C=" + vt.getCodec() + "|FT=" + vt.getFrameType());
/* 342 */         if (vt instanceof FLVTag.AvcVideoTagHeader) {
/* 343 */           FLVTag.AvcVideoTagHeader avct = (FLVTag.AvcVideoTagHeader)vt;
/* 344 */           System.out.print("|PKT_TYPE=" + avct.getAvcPacketType() + "|COMP_OFF=" + avct.getCompOffset());
/* 345 */           if (avct.getAvcPacketType() == 0) {
/* 346 */             ByteBuffer frameData = pkt.getData().duplicate();
/* 347 */             FLVReader.parseVideoTagHeader(frameData);
/* 348 */             AvcCBox avcc = H264Utils.parseAVCCFromBuffer(frameData);
/* 349 */             for (SeqParameterSet sps : H264Utils.readSPSFromBufferList(avcc.getSpsList())) {
/* 350 */               System.out.println();
/* 351 */               System.out.print("  SPS[" + sps.getSeqParameterSetId() + "]:" + Platform.toJSON(sps));
/*     */             } 
/* 353 */             for (PictureParameterSet pps : H264Utils.readPPSFromBufferList(avcc.getPpsList())) {
/* 354 */               System.out.println();
/* 355 */               System.out.print("  PPS[" + pps.getPicParameterSetId() + "]:" + Platform.toJSON(pps));
/*     */             } 
/*     */           } 
/*     */         } 
/* 359 */       } else if (pkt.getTagHeader() instanceof FLVTag.AudioTagHeader) {
/* 360 */         FLVTag.AudioTagHeader at = (FLVTag.AudioTagHeader)pkt.getTagHeader();
/* 361 */         AudioFormat format = at.getAudioFormat();
/* 362 */         System.out.print("|C=" + at.getCodec() + "|SR=" + format.getSampleRate() + "|SS=" + (format
/* 363 */             .getSampleSizeInBits() >> 3) + "|CH=" + format.getChannels());
/* 364 */       } else if (pkt.getType() == FLVTag.Type.SCRIPT) {
/* 365 */         FLVMetadata metadata = FLVReader.parseMetadata(pkt.getData().duplicate());
/* 366 */         if (metadata != null) {
/* 367 */           System.out.println();
/* 368 */           System.out.print("  Metadata:" + Platform.toJSON(metadata));
/*     */         } 
/*     */       } 
/* 371 */       System.out.println();
/*     */     }
/*     */     
/*     */     private String typeString(FLVTag.Type type) {
/* 375 */       return type.toString().substring(0, 1);
/*     */     }
/*     */ 
/*     */     
/*     */     public void finish(FLVWriter muxer) throws IOException {
/* 380 */       if (this.prevVideoTag != null)
/* 381 */         dumpOnePacket(this.prevVideoTag, 0); 
/* 382 */       if (this.prevAudioTag != null) {
/* 383 */         dumpOnePacket(this.prevAudioTag, 0);
/*     */       }
/*     */     }
/*     */     
/*     */     public boolean hasOutput() {
/* 388 */       return false;
/*     */     }
/*     */   }
/*     */   public static class Factory implements PacketProcessorFactory { private static final MainUtils.Flag FLAG_CHECK = MainUtils.Flag.flag("check", null, "Check sanity and report errors only, no packet dump will be generated."); private static final MainUtils.Flag FLAG_STREAM = MainUtils.Flag.flag("stream", null, "Stream selector, can be one of: ['video', 'audio', 'script'].");
/*     */     public FLVTool.PacketProcessor newPacketProcessor(MainUtils.Cmd flags) {
/*     */       return new FLVTool.InfoPacketProcessor(flags.getBooleanFlagD(FLAG_CHECK, Boolean.valueOf(false)).booleanValue(), (FLVTag.Type)flags.getEnumFlagD(FLAG_STREAM, null, FLVTag.Type.class));
/*     */     }
/*     */     public MainUtils.Flag[] getFlags() {
/*     */       return new MainUtils.Flag[] { FLAG_CHECK, FLAG_STREAM };
/*     */     } }
/*     */   
/*     */   public static class ShiftPtsProcessor implements PacketProcessor { private static final long WRAP_AROUND_VALUE = 2147483648L;
/*     */     private static final int HALF_WRAP_AROUND_VALUE = 1073741824;
/* 401 */     private static final MainUtils.Flag FLAG_TO = MainUtils.Flag.flag("to", null, "Shift first pts to this value, and all subsequent pts accordingly.");
/* 402 */     private static final MainUtils.Flag FLAG_BY = MainUtils.Flag.flag("by", null, "Shift all pts by this value.");
/* 403 */     private static final MainUtils.Flag FLAG_WRAP_AROUND = MainUtils.Flag.flag("wrap-around", null, "Expect wrap around of timestamps."); private int shiftTo; private Integer shiftBy; private long ptsDelta; private boolean firstPtsSeen; private List<FLVTag> savedTags;
/*     */     private boolean expectWrapAround;
/*     */     private int prevPts;
/*     */     
/*     */     public static class Factory implements FLVTool.PacketProcessorFactory { public FLVTool.PacketProcessor newPacketProcessor(MainUtils.Cmd flags) {
/* 408 */         return new FLVTool.ShiftPtsProcessor(flags.getIntegerFlagD(FLVTool.ShiftPtsProcessor.FLAG_TO, Integer.valueOf(0)).intValue(), flags.getIntegerFlag(FLVTool.ShiftPtsProcessor.FLAG_BY), flags
/* 409 */             .getBooleanFlagD(FLVTool.ShiftPtsProcessor.FLAG_WRAP_AROUND, Boolean.valueOf(false)).booleanValue());
/*     */       }
/*     */ 
/*     */       
/*     */       public MainUtils.Flag[] getFlags() {
/* 414 */         return new MainUtils.Flag[] { FLVTool.ShiftPtsProcessor.access$200(), FLVTool.ShiftPtsProcessor.access$300(), FLVTool.ShiftPtsProcessor.access$400() };
/*     */       } }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public ShiftPtsProcessor(int shiftTo, Integer shiftBy, boolean expectWrapAround) {
/* 427 */       this.savedTags = new LinkedList<FLVTag>();
/* 428 */       this.shiftTo = shiftTo;
/* 429 */       this.shiftBy = shiftBy;
/* 430 */       this.expectWrapAround = true;
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     public boolean processPacket(FLVTag pkt, FLVWriter writer) throws IOException {
/* 436 */       boolean avcPrivatePacket = (pkt.getType() == FLVTag.Type.VIDEO && ((FLVTag.VideoTagHeader)pkt.getTagHeader()).getCodec() == Codec.H264 && ((FLVTag.AvcVideoTagHeader)pkt.getTagHeader()).getAvcPacketType() == 0);
/*     */ 
/*     */       
/* 439 */       boolean aacPrivatePacket = (pkt.getType() == FLVTag.Type.AUDIO && ((FLVTag.AudioTagHeader)pkt.getTagHeader()).getCodec() == Codec.AAC && ((FLVTag.AacAudioTagHeader)pkt.getTagHeader()).getPacketType() == 0);
/*     */       
/* 441 */       boolean validPkt = (pkt.getType() != FLVTag.Type.SCRIPT && !avcPrivatePacket && !aacPrivatePacket);
/* 442 */       if (this.expectWrapAround && validPkt && pkt.getPts() < this.prevPts && this.prevPts - pkt
/* 443 */         .getPts() > 1073741824L) {
/* 444 */         Logger.warn("Wrap around detected: " + this.prevPts + " -> " + pkt.getPts());
/*     */         
/* 446 */         if (pkt.getPts() < -1073741824) {
/* 447 */           this.ptsDelta += 4294967296L;
/* 448 */         } else if (pkt.getPts() >= 0) {
/* 449 */           this.ptsDelta += 2147483648L;
/*     */         } 
/*     */       } 
/* 452 */       if (validPkt) {
/* 453 */         this.prevPts = pkt.getPts();
/*     */       }
/* 455 */       if (this.firstPtsSeen) {
/* 456 */         writePacket(pkt, writer);
/*     */       }
/* 458 */       else if (!validPkt) {
/* 459 */         this.savedTags.add(pkt);
/*     */       } else {
/* 461 */         if (this.shiftBy != null) {
/* 462 */           this.ptsDelta = this.shiftBy.intValue();
/* 463 */           if (this.ptsDelta + pkt.getPts() < 0L)
/* 464 */             this.ptsDelta = -pkt.getPts(); 
/*     */         } else {
/* 466 */           this.ptsDelta = (this.shiftTo - pkt.getPts());
/*     */         } 
/* 468 */         this.firstPtsSeen = true;
/* 469 */         emptySavedTags(writer);
/* 470 */         writePacket(pkt, writer);
/*     */       } 
/*     */ 
/*     */       
/* 474 */       return true;
/*     */     }
/*     */     
/*     */     private void writePacket(FLVTag pkt, FLVWriter writer) throws IOException {
/* 478 */       long newPts = pkt.getPts() + this.ptsDelta;
/* 479 */       if (newPts < 0L) {
/* 480 */         Logger.warn("Preventing negative pts for tag @" + pkt.getPosition());
/* 481 */         if (this.shiftBy != null)
/* 482 */         { newPts = 0L; }
/*     */         else
/* 484 */         { newPts = this.shiftTo; } 
/* 485 */       } else if (newPts >= 2147483648L) {
/* 486 */         Logger.warn("PTS wrap around @" + pkt.getPosition());
/* 487 */         newPts -= 2147483648L;
/* 488 */         this.ptsDelta = newPts - pkt.getPts();
/*     */       } 
/* 490 */       pkt.setPts((int)newPts);
/* 491 */       writer.addPacket(pkt);
/*     */     }
/*     */     
/*     */     private void emptySavedTags(FLVWriter muxer) throws IOException {
/* 495 */       while (this.savedTags.size() > 0) {
/* 496 */         writePacket(this.savedTags.remove(0), muxer);
/*     */       }
/*     */     }
/*     */ 
/*     */     
/*     */     public void finish(FLVWriter muxer) throws IOException {
/* 502 */       emptySavedTags(muxer);
/*     */     }
/*     */ 
/*     */     
/*     */     public boolean hasOutput() {
/* 507 */       return true;
/*     */     } }
/*     */ 
/*     */   
/*     */   public static class Factory implements PacketProcessorFactory {
/*     */     public FLVTool.PacketProcessor newPacketProcessor(MainUtils.Cmd flags) {
/*     */       return new FLVTool.ShiftPtsProcessor(flags.getIntegerFlagD(FLVTool.ShiftPtsProcessor.FLAG_TO, Integer.valueOf(0)).intValue(), flags.getIntegerFlag(FLVTool.ShiftPtsProcessor.FLAG_BY), flags.getBooleanFlagD(FLVTool.ShiftPtsProcessor.FLAG_WRAP_AROUND, Boolean.valueOf(false)).booleanValue());
/*     */     }
/*     */     
/*     */     public MainUtils.Flag[] getFlags() {
/*     */       return new MainUtils.Flag[] { FLVTool.ShiftPtsProcessor.access$200(), FLVTool.ShiftPtsProcessor.access$300(), FLVTool.ShiftPtsProcessor.access$400() };
/*     */     }
/*     */   }
/*     */   
/*     */   public static interface PacketProcessorFactory {
/*     */     FLVTool.PacketProcessor newPacketProcessor(MainUtils.Cmd param1Cmd);
/*     */     
/*     */     MainUtils.Flag[] getFlags();
/*     */   }
/*     */   
/*     */   public static interface PacketProcessor {
/*     */     boolean processPacket(FLVTag param1FLVTag, FLVWriter param1FLVWriter) throws IOException;
/*     */     
/*     */     boolean hasOutput();
/*     */     
/*     */     void finish(FLVWriter param1FLVWriter) throws IOException;
/*     */   }
/*     */ }


/* Location:              C:\Users\rapha\Downloads\aurora.jar!\META-INF\jars\jcodec-0.2.5.jar!\org\jcodec\containers\flv\FLVTool.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */