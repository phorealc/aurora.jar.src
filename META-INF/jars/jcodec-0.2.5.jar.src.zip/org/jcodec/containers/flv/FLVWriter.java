/*    */ package org.jcodec.containers.flv;
/*    */ 
/*    */ import java.io.IOException;
/*    */ import java.nio.ByteBuffer;
/*    */ import org.jcodec.common.io.NIOUtils;
/*    */ import org.jcodec.common.io.SeekableByteChannel;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class FLVWriter
/*    */ {
/*    */   private static final int WRITE_BUFFER_SIZE = 1048576;
/* 22 */   private int startOfLastPacket = 9;
/*    */   private SeekableByteChannel out;
/*    */   private ByteBuffer writeBuf;
/*    */   
/*    */   public FLVWriter(SeekableByteChannel out) {
/* 27 */     this.out = out;
/* 28 */     this.writeBuf = ByteBuffer.allocate(1048576);
/* 29 */     writeHeader(this.writeBuf);
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public void addPacket(FLVTag pkt) throws IOException {
/* 39 */     if (!writePacket(this.writeBuf, pkt)) {
/* 40 */       this.writeBuf.flip();
/* 41 */       this.startOfLastPacket -= this.out.write(this.writeBuf);
/* 42 */       this.writeBuf.clear();
/* 43 */       if (!writePacket(this.writeBuf, pkt)) {
/* 44 */         throw new RuntimeException("Unexpected");
/*    */       }
/*    */     } 
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public void finish() throws IOException {
/* 54 */     this.writeBuf.flip();
/* 55 */     this.out.write(this.writeBuf);
/*    */   }
/*    */   
/*    */   private boolean writePacket(ByteBuffer writeBuf, FLVTag pkt) {
/* 59 */     int pktType = (pkt.getType() == FLVTag.Type.VIDEO) ? 9 : ((pkt.getType() == FLVTag.Type.SCRIPT) ? 18 : 8);
/* 60 */     int dataLen = pkt.getData().remaining();
/*    */     
/* 62 */     if (writeBuf.remaining() < 15 + dataLen) {
/* 63 */       return false;
/*    */     }
/* 65 */     writeBuf.putInt(writeBuf.position() - this.startOfLastPacket);
/* 66 */     this.startOfLastPacket = writeBuf.position();
/*    */     
/* 68 */     writeBuf.put((byte)pktType);
/* 69 */     writeBuf.putShort((short)(dataLen >> 8));
/* 70 */     writeBuf.put((byte)(dataLen & 0xFF));
/*    */     
/* 72 */     writeBuf.putShort((short)(pkt.getPts() >> 8 & 0xFFFF));
/* 73 */     writeBuf.put((byte)(pkt.getPts() & 0xFF));
/* 74 */     writeBuf.put((byte)(pkt.getPts() >> 24 & 0xFF));
/*    */     
/* 76 */     writeBuf.putShort((short)0);
/* 77 */     writeBuf.put((byte)0);
/*    */     
/* 79 */     NIOUtils.write(writeBuf, pkt.getData().duplicate());
/*    */     
/* 81 */     return true;
/*    */   }
/*    */   
/*    */   private static void writeHeader(ByteBuffer writeBuf) {
/* 85 */     writeBuf.put((byte)70);
/* 86 */     writeBuf.put((byte)76);
/* 87 */     writeBuf.put((byte)86);
/* 88 */     writeBuf.put((byte)1);
/* 89 */     writeBuf.put((byte)5);
/* 90 */     writeBuf.putInt(9);
/*    */   }
/*    */ }


/* Location:              C:\Users\rapha\Downloads\aurora.jar!\META-INF\jars\jcodec-0.2.5.jar!\org\jcodec\containers\flv\FLVWriter.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */