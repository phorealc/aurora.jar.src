/*     */ package org.jcodec.containers.flv;
/*     */ 
/*     */ import java.lang.reflect.Field;
/*     */ import java.util.Date;
/*     */ import java.util.Map;
/*     */ import org.jcodec.platform.Platform;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class FLVMetadata
/*     */ {
/*     */   private double duration;
/*     */   private double width;
/*     */   private double height;
/*     */   private double framerate;
/*     */   private String audiocodecid;
/*     */   private double videokeyframe_frequency;
/*     */   private String videodevice;
/*     */   private double avclevel;
/*     */   private double audiosamplerate;
/*     */   private double audiochannels;
/*     */   private String presetname;
/*     */   private double videodatarate;
/*     */   private double audioinputvolume;
/*     */   private Date creationdate;
/*     */   private String videocodecid;
/*     */   private double avcprofile;
/*     */   private String audiodevice;
/*     */   private double audiodatarate;
/*     */   
/*     */   public FLVMetadata(Map<String, Object> md) {
/*  42 */     Field[] declaredFields = Platform.getDeclaredFields(getClass());
/*  43 */     for (int i = 0; i < declaredFields.length; i++) {
/*  44 */       Field field = declaredFields[i];
/*  45 */       Object object = md.get(field.getName());
/*     */       try {
/*  47 */         if (object instanceof Double) {
/*  48 */           field.setDouble(this, ((Double)object).doubleValue());
/*  49 */         } else if (object instanceof Boolean) {
/*  50 */           field.setBoolean(this, ((Boolean)object).booleanValue());
/*     */         } else {
/*  52 */           field.set(this, object);
/*     */         } 
/*  54 */       } catch (Exception exception) {}
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public double getDuration() {
/*  60 */     return this.duration;
/*     */   }
/*     */   
/*     */   public double getWidth() {
/*  64 */     return this.width;
/*     */   }
/*     */   
/*     */   public double getHeight() {
/*  68 */     return this.height;
/*     */   }
/*     */   
/*     */   public double getFramerate() {
/*  72 */     return this.framerate;
/*     */   }
/*     */   
/*     */   public String getAudiocodecid() {
/*  76 */     return this.audiocodecid;
/*     */   }
/*     */   
/*     */   public double getVideokeyframe_frequency() {
/*  80 */     return this.videokeyframe_frequency;
/*     */   }
/*     */   
/*     */   public String getVideodevice() {
/*  84 */     return this.videodevice;
/*     */   }
/*     */   
/*     */   public double getAvclevel() {
/*  88 */     return this.avclevel;
/*     */   }
/*     */   
/*     */   public double getAudiosamplerate() {
/*  92 */     return this.audiosamplerate;
/*     */   }
/*     */   
/*     */   public double getAudiochannels() {
/*  96 */     return this.audiochannels;
/*     */   }
/*     */   
/*     */   public String getPresetname() {
/* 100 */     return this.presetname;
/*     */   }
/*     */   
/*     */   public double getVideodatarate() {
/* 104 */     return this.videodatarate;
/*     */   }
/*     */   
/*     */   public double getAudioinputvolume() {
/* 108 */     return this.audioinputvolume;
/*     */   }
/*     */   
/*     */   public Date getCreationdate() {
/* 112 */     return this.creationdate;
/*     */   }
/*     */   
/*     */   public String getVideocodecid() {
/* 116 */     return this.videocodecid;
/*     */   }
/*     */   
/*     */   public double getAvcprofile() {
/* 120 */     return this.avcprofile;
/*     */   }
/*     */   
/*     */   public String getAudiodevice() {
/* 124 */     return this.audiodevice;
/*     */   }
/*     */   
/*     */   public double getAudiodatarate() {
/* 128 */     return this.audiodatarate;
/*     */   }
/*     */ }


/* Location:              C:\Users\rapha\Downloads\aurora.jar!\META-INF\jars\jcodec-0.2.5.jar!\org\jcodec\containers\flv\FLVMetadata.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */