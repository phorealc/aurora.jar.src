/*     */ package org.jcodec.containers.imgseq;
/*     */ 
/*     */ import java.io.File;
/*     */ import java.io.IOException;
/*     */ import java.util.ArrayList;
/*     */ import java.util.List;
/*     */ import org.jcodec.common.Codec;
/*     */ import org.jcodec.common.Demuxer;
/*     */ import org.jcodec.common.DemuxerTrack;
/*     */ import org.jcodec.common.DemuxerTrackMeta;
/*     */ import org.jcodec.common.TrackType;
/*     */ import org.jcodec.common.io.NIOUtils;
/*     */ import org.jcodec.common.logging.Logger;
/*     */ import org.jcodec.common.model.Packet;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ImageSequenceDemuxer
/*     */   implements Demuxer, DemuxerTrack
/*     */ {
/*     */   private static final int VIDEO_FPS = 25;
/*     */   private String namePattern;
/*     */   private int frameNo;
/*     */   private Packet curFrame;
/*     */   private Codec codec;
/*     */   private int maxAvailableFrame;
/*     */   private int maxFrames;
/*     */   private String prevName;
/*     */   private static final int MAX_MAX = 5184000;
/*     */   
/*     */   public ImageSequenceDemuxer(String namePattern, int maxFrames) throws IOException {
/*  41 */     this.namePattern = namePattern;
/*  42 */     this.maxFrames = maxFrames;
/*  43 */     this.maxAvailableFrame = -1;
/*  44 */     this.curFrame = loadFrame();
/*     */     
/*  46 */     String lowerCase = namePattern.toLowerCase();
/*  47 */     if (lowerCase.endsWith(".png")) {
/*  48 */       this.codec = Codec.PNG;
/*  49 */     } else if (lowerCase.endsWith(".jpg") || lowerCase.endsWith(".jpeg")) {
/*  50 */       this.codec = Codec.JPEG;
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void close() throws IOException {}
/*     */ 
/*     */   
/*     */   public List<? extends DemuxerTrack> getTracks() {
/*  60 */     ArrayList<DemuxerTrack> tracks = new ArrayList<DemuxerTrack>();
/*  61 */     tracks.add(this);
/*  62 */     return tracks;
/*     */   }
/*     */ 
/*     */   
/*     */   public List<? extends DemuxerTrack> getVideoTracks() {
/*  67 */     return getTracks();
/*     */   }
/*     */ 
/*     */   
/*     */   public List<? extends DemuxerTrack> getAudioTracks() {
/*  72 */     return new ArrayList<DemuxerTrack>();
/*     */   }
/*     */ 
/*     */   
/*     */   public Packet nextFrame() throws IOException {
/*     */     try {
/*  78 */       return this.curFrame;
/*     */     } finally {
/*  80 */       this.curFrame = loadFrame();
/*     */     } 
/*     */   }
/*     */   
/*     */   private Packet loadFrame() throws IOException {
/*  85 */     if (this.frameNo > this.maxFrames) {
/*  86 */       return null;
/*     */     }
/*     */     
/*  89 */     File file = null;
/*     */     do {
/*  91 */       String name = String.format(this.namePattern, new Object[] { Integer.valueOf(this.frameNo) });
/*     */ 
/*     */       
/*  94 */       if (name.equals(this.prevName)) {
/*  95 */         return null;
/*     */       }
/*  97 */       this.prevName = name;
/*  98 */       file = new File(name);
/*  99 */       if (file.exists() || this.frameNo > 0)
/*     */         break; 
/* 101 */       this.frameNo++;
/* 102 */     } while (this.frameNo < 2);
/*     */     
/* 104 */     if (file == null || !file.exists()) {
/* 105 */       return null;
/*     */     }
/* 107 */     Packet ret = new Packet(NIOUtils.fetchFromFile(file), this.frameNo, 25, 1L, this.frameNo, Packet.FrameType.KEY, null, this.frameNo);
/* 108 */     this.frameNo++;
/* 109 */     return ret;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int getMaxAvailableFrame() {
/* 123 */     if (this.maxAvailableFrame == -1) {
/*     */       
/* 125 */       int firstPoint = 0;
/* 126 */       for (int i = 5184000; i > 0; i /= 2) {
/* 127 */         if ((new File(String.format(this.namePattern, new Object[] { Integer.valueOf(i) }))).exists()) {
/* 128 */           firstPoint = i;
/*     */           break;
/*     */         } 
/*     */       } 
/* 132 */       int pos = firstPoint;
/* 133 */       for (int interv = firstPoint / 2; interv > 1; interv /= 2) {
/* 134 */         if ((new File(String.format(this.namePattern, new Object[] { Integer.valueOf(pos + interv) }))).exists()) {
/* 135 */           pos += interv;
/*     */         }
/*     */       } 
/* 138 */       this.maxAvailableFrame = pos;
/* 139 */       Logger.info("Max frame found: " + this.maxAvailableFrame);
/*     */     } 
/* 141 */     return Math.min(this.maxAvailableFrame, this.maxFrames);
/*     */   }
/*     */ 
/*     */   
/*     */   public DemuxerTrackMeta getMeta() {
/* 146 */     int durationFrames = getMaxAvailableFrame();
/* 147 */     return new DemuxerTrackMeta(TrackType.VIDEO, this.codec, ((durationFrames + 1) * 25), null, durationFrames + 1, null, null, null);
/*     */   }
/*     */ }


/* Location:              C:\Users\rapha\Downloads\aurora.jar!\META-INF\jars\jcodec-0.2.5.jar!\org\jcodec\containers\imgseq\ImageSequenceDemuxer.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */