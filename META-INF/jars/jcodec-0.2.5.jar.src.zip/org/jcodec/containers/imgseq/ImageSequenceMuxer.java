/*    */ package org.jcodec.containers.imgseq;
/*    */ 
/*    */ import java.io.IOException;
/*    */ import org.jcodec.common.AudioCodecMeta;
/*    */ import org.jcodec.common.Codec;
/*    */ import org.jcodec.common.Muxer;
/*    */ import org.jcodec.common.MuxerTrack;
/*    */ import org.jcodec.common.VideoCodecMeta;
/*    */ import org.jcodec.common.io.NIOUtils;
/*    */ import org.jcodec.common.logging.Logger;
/*    */ import org.jcodec.common.model.Packet;
/*    */ import org.jcodec.common.tools.MainUtils;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class ImageSequenceMuxer
/*    */   implements Muxer, MuxerTrack
/*    */ {
/*    */   private String fileNamePattern;
/*    */   private int frameNo;
/*    */   
/*    */   public ImageSequenceMuxer(String fileNamePattern) {
/* 26 */     this.fileNamePattern = fileNamePattern;
/*    */   }
/*    */ 
/*    */   
/*    */   public void addFrame(Packet packet) throws IOException {
/* 31 */     NIOUtils.writeTo(packet.getData(), MainUtils.tildeExpand(String.format(this.fileNamePattern, new Object[] { Integer.valueOf(this.frameNo++) })));
/*    */   }
/*    */ 
/*    */   
/*    */   public MuxerTrack addVideoTrack(Codec codec, VideoCodecMeta meta) {
/* 36 */     return this;
/*    */   }
/*    */ 
/*    */   
/*    */   public MuxerTrack addAudioTrack(Codec codec, AudioCodecMeta meta) {
/* 41 */     Logger.warn("Audio is not supported for image sequence muxer.");
/* 42 */     return null;
/*    */   }
/*    */   
/*    */   public void finish() throws IOException {}
/*    */ }


/* Location:              C:\Users\rapha\Downloads\aurora.jar!\META-INF\jars\jcodec-0.2.5.jar!\org\jcodec\containers\imgseq\ImageSequenceMuxer.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */