/*    */ package org.jcodec.audio;
/*    */ 
/*    */ import java.nio.FloatBuffer;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class LanczosInterpolator
/*    */   implements AudioFilter
/*    */ {
/*    */   private double rateStep;
/*    */   
/*    */   public static double lanczos(double x, int a) {
/* 17 */     return (x < -a) ? 0.0D : ((x > a) ? 0.0D : (a * Math.sin(Math.PI * x) * Math.sin(Math.PI * x / a) / 9.869604401089358D * x * x));
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public LanczosInterpolator(int fromRate, int toRate) {
/* 24 */     this.rateStep = fromRate / toRate;
/*    */   }
/*    */   
/*    */   public void filter(FloatBuffer[] _in, long[] pos, FloatBuffer[] out) {
/* 28 */     if (_in.length != 1) {
/* 29 */       throw new IllegalArgumentException(getClass().getName() + " filter is designed to work only on one input");
/*    */     }
/* 31 */     if (out.length != 1) {
/* 32 */       throw new IllegalArgumentException(getClass().getName() + " filter is designed to work only on one output");
/*    */     }
/*    */     
/* 35 */     FloatBuffer in0 = _in[0];
/* 36 */     FloatBuffer out0 = out[0];
/*    */     
/* 38 */     if (out0.remaining() < (in0.remaining() - 6) / this.rateStep)
/* 39 */       throw new IllegalArgumentException("Output buffer is too small"); 
/* 40 */     if (in0.remaining() <= 6) {
/* 41 */       throw new IllegalArgumentException("Input buffer should contain > 6 samples.");
/*    */     }
/* 43 */     for (int outSample = 0;; outSample++) {
/* 44 */       double inSample = 3.0D + outSample * this.rateStep + Math.ceil(pos[0] / this.rateStep) * this.rateStep - pos[0];
/*    */       
/* 46 */       int p0i = (int)Math.floor(inSample);
/* 47 */       int q0i = (int)Math.ceil(inSample);
/* 48 */       if (p0i >= in0.limit() - 3) {
/* 49 */         in0.position(p0i - 3);
/*    */         
/*    */         break;
/*    */       } 
/* 53 */       double p0d = p0i - inSample;
/* 54 */       if (p0d < -0.001D) {
/* 55 */         double q0d = q0i - inSample;
/*    */         
/* 57 */         double p0c = lanczos(p0d, 3);
/* 58 */         double q0c = lanczos(q0d, 3);
/*    */         
/* 60 */         double p1c = lanczos(p0d - 1.0D, 3);
/* 61 */         double q1c = lanczos(q0d + 1.0D, 3);
/*    */         
/* 63 */         double p2c = lanczos(p0d - 2.0D, 3);
/* 64 */         double q2c = lanczos(q0d + 2.0D, 3);
/*    */         
/* 66 */         double factor = 1.0D / (p0c + p1c + p2c + q0c + q1c + q2c);
/*    */         
/* 68 */         out0.put(
/* 69 */             (float)((in0.get(q0i) * q0c + in0.get(q0i + 1) * q1c + in0.get(q0i + 2) * q2c + in0.get(p0i) * p0c + in0.get(p0i - 1) * p1c + in0.get(p0i - 2) * p2c) * factor));
/*    */       } else {
/* 71 */         out0.put(in0.get(p0i));
/*    */       } 
/*    */     } 
/*    */   }
/*    */ 
/*    */   
/*    */   public int getDelay() {
/* 78 */     return 3;
/*    */   }
/*    */ 
/*    */   
/*    */   public int getNInputs() {
/* 83 */     return 1;
/*    */   }
/*    */ 
/*    */   
/*    */   public int getNOutputs() {
/* 88 */     return 1;
/*    */   }
/*    */ }


/* Location:              C:\Users\rapha\Downloads\aurora.jar!\META-INF\jars\jcodec-0.2.5.jar!\org\jcodec\audio\LanczosInterpolator.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */