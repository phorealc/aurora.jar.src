/*    */ package org.jcodec.audio;
/*    */ 
/*    */ import java.nio.FloatBuffer;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public abstract class ConvolutionFilter
/*    */   implements AudioFilter
/*    */ {
/*    */   private double[] kernel;
/*    */   
/*    */   protected abstract double[] buildKernel();
/*    */   
/*    */   public void filter(FloatBuffer[] _in, long[] pos, FloatBuffer[] out) {
/* 22 */     if (_in.length != 1) {
/* 23 */       throw new IllegalArgumentException(getClass().getName() + " filter is designed to work only on one input");
/*    */     }
/* 25 */     if (out.length != 1) {
/* 26 */       throw new IllegalArgumentException(getClass().getName() + " filter is designed to work only on one output");
/*    */     }
/*    */     
/* 29 */     FloatBuffer in0 = _in[0];
/* 30 */     FloatBuffer out0 = out[0];
/*    */     
/* 32 */     if (this.kernel == null) {
/* 33 */       this.kernel = buildKernel();
/*    */     }
/*    */     
/* 36 */     if (out0.remaining() < in0.remaining() - this.kernel.length)
/* 37 */       throw new IllegalArgumentException("Output buffer is too small"); 
/* 38 */     if (in0.remaining() <= this.kernel.length) {
/* 39 */       throw new IllegalArgumentException("Input buffer should contain > kernel lenght (" + this.kernel.length + ") samples.");
/*    */     }
/*    */     
/* 42 */     int halfKernel = this.kernel.length / 2;
/*    */     
/*    */     int i;
/* 45 */     for (i = in0.position() + halfKernel; i < in0.limit() - halfKernel; i++) {
/* 46 */       double result = 0.0D;
/* 47 */       for (int j = 0; j < this.kernel.length; j++) {
/* 48 */         result += this.kernel[j] * in0.get(i + j - halfKernel);
/*    */       }
/* 50 */       out0.put((float)result);
/*    */     } 
/* 52 */     in0.position(i - halfKernel);
/*    */   }
/*    */ 
/*    */   
/*    */   public int getDelay() {
/* 57 */     if (this.kernel == null) {
/* 58 */       this.kernel = buildKernel();
/*    */     }
/* 60 */     return this.kernel.length / 2;
/*    */   }
/*    */ 
/*    */   
/*    */   public int getNInputs() {
/* 65 */     return 1;
/*    */   }
/*    */ 
/*    */   
/*    */   public int getNOutputs() {
/* 70 */     return 1;
/*    */   }
/*    */ }


/* Location:              C:\Users\rapha\Downloads\aurora.jar!\META-INF\jars\jcodec-0.2.5.jar!\org\jcodec\audio\ConvolutionFilter.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */