/*    */ package org.jcodec.audio;
/*    */ 
/*    */ import java.nio.FloatBuffer;
/*    */ import org.jcodec.common.AudioFormat;
/*    */ import org.jcodec.common.Preconditions;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class ChannelMerge
/*    */   implements AudioFilter
/*    */ {
/*    */   private AudioFormat format;
/*    */   
/*    */   public ChannelMerge(AudioFormat format) {
/* 22 */     this.format = format;
/*    */   }
/*    */ 
/*    */   
/*    */   public void filter(FloatBuffer[] _in, long[] inPos, FloatBuffer[] out) {
/* 27 */     if (_in.length != this.format.getChannels()) {
/* 28 */       throw new IllegalArgumentException("Channel merge must be supplied with " + this.format.getChannels() + " input buffers to hold the channels.");
/*    */     }
/*    */ 
/*    */     
/* 32 */     if (out.length != 1) {
/* 33 */       throw new IllegalArgumentException("Channel merget invoked on more then one output");
/*    */     }
/*    */     
/* 36 */     FloatBuffer out0 = out[0];
/*    */     
/* 38 */     int min = Integer.MAX_VALUE; int i;
/* 39 */     for (i = 0; i < _in.length; i++) {
/* 40 */       if (_in[i].remaining() < min)
/* 41 */         min = _in[i].remaining(); 
/*    */     } 
/* 43 */     for (i = 0; i < _in.length; i++) {
/* 44 */       Preconditions.checkState((_in[i].remaining() == min));
/*    */     }
/*    */     
/* 47 */     if (out0.remaining() < min * _in.length) {
/* 48 */       throw new IllegalArgumentException("Supplied output buffer is not big enough to hold " + min + " * " + _in.length + " = " + (min * _in.length) + " output samples.");
/*    */     }
/*    */     
/* 51 */     for (i = 0; i < min; i++) {
/* 52 */       for (int j = 0; j < _in.length; j++) {
/* 53 */         out0.put(_in[j].get());
/*    */       }
/*    */     } 
/*    */   }
/*    */   
/*    */   public int getDelay() {
/* 59 */     return 0;
/*    */   }
/*    */ 
/*    */   
/*    */   public int getNInputs() {
/* 64 */     return this.format.getChannels();
/*    */   }
/*    */ 
/*    */   
/*    */   public int getNOutputs() {
/* 69 */     return 1;
/*    */   }
/*    */ }


/* Location:              C:\Users\rapha\Downloads\aurora.jar!\META-INF\jars\jcodec-0.2.5.jar!\org\jcodec\audio\ChannelMerge.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */