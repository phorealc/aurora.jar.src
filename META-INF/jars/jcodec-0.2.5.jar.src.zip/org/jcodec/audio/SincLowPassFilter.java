/*    */ package org.jcodec.audio;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class SincLowPassFilter
/*    */   extends ConvolutionFilter
/*    */ {
/*    */   private int kernelSize;
/*    */   private double cutoffFreq;
/*    */   
/*    */   public static SincLowPassFilter createSincLowPassFilter(double cutoffFreq) {
/* 26 */     return new SincLowPassFilter(40, cutoffFreq);
/*    */   }
/*    */   
/*    */   public static SincLowPassFilter createSincLowPassFilter2(int cutoffFreq, int samplingRate) {
/* 30 */     return new SincLowPassFilter(40, cutoffFreq / samplingRate);
/*    */   }
/*    */   
/*    */   public SincLowPassFilter(int kernelSize, double cutoffFreq) {
/* 34 */     this.kernelSize = kernelSize;
/* 35 */     this.cutoffFreq = cutoffFreq;
/*    */   }
/*    */ 
/*    */   
/*    */   protected double[] buildKernel() {
/* 40 */     double[] kernel = new double[this.kernelSize];
/* 41 */     double sum = 0.0D; int i;
/* 42 */     for (i = 0; i < this.kernelSize; i++) {
/* 43 */       int a = i - this.kernelSize / 2;
/* 44 */       if (a != 0) {
/*    */ 
/*    */ 
/*    */ 
/*    */         
/* 49 */         kernel[i] = Math.sin(6.283185307179586D * this.cutoffFreq * (i - this.kernelSize / 2)) / (i - this.kernelSize / 2) * (0.54D - 0.46D * 
/* 50 */           Math.cos(6.283185307179586D * i / this.kernelSize));
/*    */       } else {
/*    */         
/* 53 */         kernel[i] = 6.283185307179586D * this.cutoffFreq;
/* 54 */       }  sum += kernel[i];
/*    */     } 
/* 56 */     for (i = 0; i < this.kernelSize; i++) {
/* 57 */       kernel[i] = kernel[i] / sum;
/*    */     }
/* 59 */     return kernel;
/*    */   }
/*    */ }


/* Location:              C:\Users\rapha\Downloads\aurora.jar!\META-INF\jars\jcodec-0.2.5.jar!\org\jcodec\audio\SincLowPassFilter.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */