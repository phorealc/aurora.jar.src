/*    */ package org.jcodec.audio;
/*    */ 
/*    */ import java.nio.FloatBuffer;
/*    */ import org.jcodec.common.AudioFormat;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class ChannelSplit
/*    */   implements AudioFilter
/*    */ {
/*    */   private AudioFormat format;
/*    */   
/*    */   public ChannelSplit(AudioFormat format) {
/* 21 */     this.format = format;
/*    */   }
/*    */ 
/*    */   
/*    */   public void filter(FloatBuffer[] _in, long[] inPos, FloatBuffer[] out) {
/* 26 */     if (_in.length != 1) {
/* 27 */       throw new IllegalArgumentException("Channel split invoked on more then one input");
/*    */     }
/* 29 */     if (out.length != this.format.getChannels()) {
/* 30 */       throw new IllegalArgumentException("Channel split must be supplied with " + this.format.getChannels() + " output buffers to hold the channels.");
/*    */     }
/*    */ 
/*    */     
/* 34 */     FloatBuffer in0 = _in[0];
/*    */     
/* 36 */     int outSampleCount = in0.remaining() / out.length; int i;
/* 37 */     for (i = 0; i < out.length; i++) {
/* 38 */       if (out[i].remaining() < outSampleCount) {
/* 39 */         throw new IllegalArgumentException("Supplied buffer for " + i + "th channel doesn't have sufficient space to put the samples ( required: " + outSampleCount + ", actual: " + out[i]
/*    */             
/* 41 */             .remaining() + ")");
/*    */       }
/*    */     } 
/* 44 */     while (in0.remaining() >= this.format.getChannels()) {
/* 45 */       for (i = 0; i < out.length; i++) {
/* 46 */         out[i].put(in0.get());
/*    */       }
/*    */     } 
/*    */   }
/*    */ 
/*    */   
/*    */   public int getDelay() {
/* 53 */     return 0;
/*    */   }
/*    */ 
/*    */   
/*    */   public int getNInputs() {
/* 58 */     return 1;
/*    */   }
/*    */ 
/*    */   
/*    */   public int getNOutputs() {
/* 63 */     return this.format.getChannels();
/*    */   }
/*    */ }


/* Location:              C:\Users\rapha\Downloads\aurora.jar!\META-INF\jars\jcodec-0.2.5.jar!\org\jcodec\audio\ChannelSplit.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */