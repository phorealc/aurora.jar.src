/*    */ package org.jcodec.audio;
/*    */ 
/*    */ import java.io.IOException;
/*    */ import java.nio.FloatBuffer;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class Audio
/*    */ {
/*    */   public static void transfer(AudioSource src, AudioSink sink) throws IOException {
/* 19 */     filterTransfer(src, new DummyFilter(1), sink);
/*    */   }
/*    */   
/*    */   public static void filterTransfer(AudioSource src, AudioFilter filter, AudioSink sink) throws IOException {
/* 23 */     if (filter.getNInputs() != 1)
/* 24 */       throw new IllegalArgumentException("Audio filter has # inputs != 1"); 
/* 25 */     if (filter.getNOutputs() != 1)
/* 26 */       throw new IllegalArgumentException("Audio filter has # outputs != 1"); 
/* 27 */     if (filter.getDelay() != 0) {
/* 28 */       throw new IllegalArgumentException("Audio filter has delay");
/*    */     }
/* 30 */     FloatBuffer[] ins = { FloatBuffer.allocate(4096) };
/* 31 */     FloatBuffer[] outs = { FloatBuffer.allocate(8192) };
/* 32 */     long[] pos = new long[1];
/*    */     
/* 34 */     while (src.readFloat(ins[0]) != -1) {
/* 35 */       ins[0].flip();
/* 36 */       filter.filter(ins, pos, outs);
/* 37 */       pos[0] = pos[0] + ins[0].position();
/* 38 */       rotate(ins[0]);
/* 39 */       outs[0].flip();
/* 40 */       sink.writeFloat(outs[0]);
/* 41 */       outs[0].clear();
/*    */     } 
/*    */   }
/*    */   
/*    */   public static void print(FloatBuffer buf) {
/* 46 */     FloatBuffer dup = buf.duplicate();
/* 47 */     while (dup.hasRemaining()) {
/* 48 */       System.out.print(String.format("%.3f,", new Object[] { Float.valueOf(dup.get()) }));
/* 49 */     }  System.out.println();
/*    */   }
/*    */   
/*    */   public static void rotate(FloatBuffer buf) {
/*    */     int pos;
/* 54 */     for (pos = 0; buf.hasRemaining(); pos++)
/* 55 */       buf.put(pos, buf.get()); 
/* 56 */     buf.position(pos);
/* 57 */     buf.limit(buf.capacity());
/*    */   }
/*    */   
/*    */   public static class DummyFilter
/*    */     implements AudioFilter {
/*    */     private int nInputs;
/*    */     
/*    */     public DummyFilter(int nInputs) {
/* 65 */       this.nInputs = nInputs;
/*    */     }
/*    */ 
/*    */     
/*    */     public void filter(FloatBuffer[] _in, long[] inPos, FloatBuffer[] out) {
/* 70 */       for (int i = 0; i < _in.length; i++) {
/* 71 */         if (out[i].remaining() >= _in[i].remaining()) {
/* 72 */           out[i].put(_in[i]);
/*    */         } else {
/* 74 */           FloatBuffer duplicate = _in[i].duplicate();
/* 75 */           duplicate.limit(_in[i].position() + out[i].remaining());
/* 76 */           out[i].put(duplicate);
/*    */         } 
/*    */       } 
/*    */     }
/*    */ 
/*    */ 
/*    */     
/*    */     public int getDelay() {
/* 84 */       return 0;
/*    */     }
/*    */ 
/*    */     
/*    */     public int getNInputs() {
/* 89 */       return this.nInputs;
/*    */     }
/*    */ 
/*    */     
/*    */     public int getNOutputs() {
/* 94 */       return this.nInputs;
/*    */     }
/*    */   }
/*    */ }


/* Location:              C:\Users\rapha\Downloads\aurora.jar!\META-INF\jars\jcodec-0.2.5.jar!\org\jcodec\audio\Audio.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */