package org.jcodec.audio;

import java.nio.FloatBuffer;

public interface AudioFilter {
  void filter(FloatBuffer[] paramArrayOfFloatBuffer1, long[] paramArrayOflong, FloatBuffer[] paramArrayOfFloatBuffer2);
  
  int getDelay();
  
  int getNInputs();
  
  int getNOutputs();
}


/* Location:              C:\Users\rapha\Downloads\aurora.jar!\META-INF\jars\jcodec-0.2.5.jar!\org\jcodec\audio\AudioFilter.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */