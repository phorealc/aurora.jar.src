/*     */ package org.jcodec.audio;
/*     */ 
/*     */ import java.nio.FloatBuffer;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Arrays;
/*     */ import java.util.List;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class FilterGraph
/*     */   implements AudioFilter
/*     */ {
/*     */   private FilterSocket[] sockets;
/*     */   
/*     */   public static Factory addLevel(AudioFilter first) {
/*  24 */     return new Factory(first);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public static class Factory
/*     */   {
/*  31 */     private List<FilterSocket> sockets = new ArrayList<FilterSocket>();
/*     */     protected Factory(AudioFilter firstFilter) {
/*  33 */       if (firstFilter.getDelay() != 0) {
/*     */ 
/*     */         
/*  36 */         this.sockets.add(FilterSocket.createFilterSocket((AudioFilter[])new Audio.DummyFilter[] { new Audio.DummyFilter(firstFilter.getNInputs()) }));
/*  37 */         addLevel(new AudioFilter[] { firstFilter });
/*     */       } else {
/*  39 */         this.sockets.add(FilterSocket.createFilterSocket(new AudioFilter[] { firstFilter }));
/*     */       } 
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public Factory addLevel(AudioFilter[] filters) {
/*  61 */       FilterSocket socket = FilterSocket.createFilterSocket(filters);
/*  62 */       socket.allocateBuffers(4096);
/*  63 */       this.sockets.add(socket);
/*  64 */       return this;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public Factory addLevels(AudioFilter filter, int n) {
/*  75 */       AudioFilter[] filters = new AudioFilter[n];
/*  76 */       Arrays.fill((Object[])filters, filter);
/*  77 */       return addLevel(filters);
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public Factory addLevelSpan(AudioFilter filter) {
/*  89 */       int prevLevelOuts = ((FilterSocket)this.sockets.get(this.sockets.size() - 1)).getTotalOutputs();
/*  90 */       if (prevLevelOuts % filter.getNInputs() != 0) {
/*  91 */         throw new IllegalArgumentException("Can't fill " + prevLevelOuts + " with multiple of " + filter
/*  92 */             .getNInputs());
/*     */       }
/*  94 */       return addLevels(filter, prevLevelOuts / filter.getNInputs());
/*     */     }
/*     */     
/*     */     public FilterGraph create() {
/*  98 */       return new FilterGraph(this.sockets.<FilterSocket>toArray(new FilterSocket[0]));
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private FilterGraph(FilterSocket[] sockets) {
/* 105 */     this.sockets = sockets;
/*     */   }
/*     */ 
/*     */   
/*     */   public void filter(FloatBuffer[] ins, long[] pos, FloatBuffer[] outs) {
/* 110 */     this.sockets[0].setBuffers(ins, pos);
/* 111 */     for (int i = 0; i < this.sockets.length; i++) {
/* 112 */       FloatBuffer[] curOut = (i < this.sockets.length - 1) ? this.sockets[i + 1].getBuffers() : outs;
/*     */       
/* 114 */       this.sockets[i].filter(curOut);
/*     */       
/* 116 */       if (i > 0) {
/* 117 */         this.sockets[i].rotate();
/*     */       }
/*     */       
/* 120 */       if (i < this.sockets.length - 1) {
/* 121 */         for (FloatBuffer b : curOut) {
/* 122 */           b.flip();
/*     */         }
/*     */       }
/*     */     } 
/*     */   }
/*     */   
/*     */   public int getDelay() {
/* 129 */     return this.sockets[0].getFilters()[0].getDelay();
/*     */   }
/*     */ 
/*     */   
/*     */   public int getNInputs() {
/* 134 */     return this.sockets[0].getTotalInputs();
/*     */   }
/*     */ 
/*     */   
/*     */   public int getNOutputs() {
/* 139 */     return this.sockets[this.sockets.length - 1].getTotalOutputs();
/*     */   }
/*     */ }


/* Location:              C:\Users\rapha\Downloads\aurora.jar!\META-INF\jars\jcodec-0.2.5.jar!\org\jcodec\audio\FilterGraph.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */