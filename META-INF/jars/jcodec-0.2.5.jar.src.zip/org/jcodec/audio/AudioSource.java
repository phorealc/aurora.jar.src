package org.jcodec.audio;

import java.io.IOException;
import java.nio.FloatBuffer;
import org.jcodec.common.AudioFormat;

public interface AudioSource {
  AudioFormat getFormat();
  
  int readFloat(FloatBuffer paramFloatBuffer) throws IOException;
}


/* Location:              C:\Users\rapha\Downloads\aurora.jar!\META-INF\jars\jcodec-0.2.5.jar!\org\jcodec\audio\AudioSource.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */