/*     */ package org.jcodec.audio;
/*     */ 
/*     */ import java.nio.FloatBuffer;
/*     */ import org.jcodec.platform.Platform;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class FilterSocket
/*     */ {
/*     */   private FloatBuffer[] buffers;
/*     */   private long[] positions;
/*     */   private int[] delays;
/*     */   private AudioFilter[] filters;
/*     */   private int totalInputs;
/*     */   private int totalOutputs;
/*     */   
/*     */   public static FilterSocket createFilterSocket(AudioFilter[] filters) {
/*  23 */     FilterSocket fs = new FilterSocket();
/*  24 */     fs.totalInputs = 0;
/*  25 */     fs.totalOutputs = 0;
/*     */     int i;
/*  27 */     for (i = 0; i < filters.length; i++) {
/*  28 */       fs.totalInputs += filters[i].getNInputs();
/*  29 */       fs.totalOutputs += filters[i].getNOutputs();
/*     */     } 
/*     */     
/*  32 */     fs.buffers = new FloatBuffer[fs.totalInputs];
/*  33 */     fs.positions = new long[fs.totalInputs];
/*  34 */     fs.delays = new int[fs.totalInputs]; int b;
/*  35 */     for (i = 0, b = 0; i < filters.length; i++) {
/*  36 */       for (int j = 0; j < filters[i].getNInputs(); j++, b++) {
/*  37 */         fs.delays[b] = filters[i].getDelay();
/*     */       }
/*     */     } 
/*  40 */     fs.filters = filters;
/*  41 */     return fs;
/*     */   }
/*     */   
/*     */   public void allocateBuffers(int bufferSize) {
/*  45 */     for (int i = 0; i < this.totalInputs; i++) {
/*  46 */       this.buffers[i] = FloatBuffer.allocate(bufferSize + this.delays[i] * 2);
/*  47 */       this.buffers[i].position(this.delays[i]);
/*     */     } 
/*     */   }
/*     */   
/*     */   public static FilterSocket createFilterSocket2(AudioFilter filter, FloatBuffer[] buffers, long[] positions) {
/*  52 */     FilterSocket fs = new FilterSocket();
/*  53 */     fs.filters = new AudioFilter[] { filter };
/*  54 */     fs.buffers = buffers;
/*  55 */     fs.positions = positions;
/*  56 */     fs.delays = new int[] { filter.getDelay() };
/*  57 */     fs.totalInputs = filter.getNInputs();
/*  58 */     fs.totalOutputs = filter.getNOutputs();
/*  59 */     return fs;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void filter(FloatBuffer[] outputs) {
/*  66 */     if (outputs.length != this.totalOutputs) {
/*  67 */       throw new IllegalArgumentException("Can not output to provided filter socket inputs != outputs (" + outputs.length + "!=" + this.totalOutputs + ")");
/*     */     }
/*  69 */     for (int i = 0, ii = 0, oi = 0; i < this.filters.length; ii += this.filters[i].getNInputs(), oi += this.filters[i]
/*  70 */       .getNOutputs(), i++) {
/*  71 */       this.filters[i].filter((FloatBuffer[])Platform.copyOfRangeO((Object[])this.buffers, ii, this.filters[i].getNInputs() + ii), 
/*  72 */           Platform.copyOfRangeL(this.positions, ii, this.filters[i].getNInputs() + ii), 
/*  73 */           (FloatBuffer[])Platform.copyOfRangeO((Object[])outputs, oi, this.filters[i].getNOutputs() + oi));
/*     */     }
/*     */   }
/*     */   
/*     */   FloatBuffer[] getBuffers() {
/*  78 */     return this.buffers;
/*     */   }
/*     */   
/*     */   public void rotate() {
/*  82 */     for (int i = 0; i < this.buffers.length; i++) {
/*  83 */       this.positions[i] = this.positions[i] + this.buffers[i].position();
/*  84 */       Audio.rotate(this.buffers[i]);
/*     */     } 
/*     */   }
/*     */   
/*     */   public void setBuffers(FloatBuffer[] ins, long[] pos) {
/*  89 */     if (ins.length != this.totalInputs) {
/*  90 */       throw new IllegalArgumentException("Number of input buffers provided is less then the number of filter inputs.");
/*     */     }
/*  92 */     if (pos.length != this.totalInputs) {
/*  93 */       throw new IllegalArgumentException("Number of input buffer positions provided is less then the number of filter inputs.");
/*     */     }
/*  95 */     this.buffers = ins;
/*  96 */     this.positions = pos;
/*     */   }
/*     */   
/*     */   public int getTotalInputs() {
/* 100 */     return this.totalInputs;
/*     */   }
/*     */   
/*     */   public int getTotalOutputs() {
/* 104 */     return this.totalOutputs;
/*     */   }
/*     */   
/*     */   AudioFilter[] getFilters() {
/* 108 */     return this.filters;
/*     */   }
/*     */   
/*     */   public long[] getPositions() {
/* 112 */     return this.positions;
/*     */   }
/*     */ }


/* Location:              C:\Users\rapha\Downloads\aurora.jar!\META-INF\jars\jcodec-0.2.5.jar!\org\jcodec\audio\FilterSocket.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */