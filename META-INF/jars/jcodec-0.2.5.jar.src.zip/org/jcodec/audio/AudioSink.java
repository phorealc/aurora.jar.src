package org.jcodec.audio;

import java.io.IOException;
import java.nio.FloatBuffer;

public interface AudioSink {
  void writeFloat(FloatBuffer paramFloatBuffer) throws IOException;
}


/* Location:              C:\Users\rapha\Downloads\aurora.jar!\META-INF\jars\jcodec-0.2.5.jar!\org\jcodec\audio\AudioSink.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */