/*     */ package org.jcodec.codecs.mpeg4;
/*     */ 
/*     */ import org.jcodec.common.model.Picture;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class MPEG4Renderer
/*     */ {
/*     */   private static void checkMV(Macroblock.Vector mv, int xHigh, int xLow, int yHigh, int yLow) {
/*  28 */     if (mv.x > xHigh) {
/*  29 */       mv.x = xHigh;
/*  30 */     } else if (mv.x < xLow) {
/*  31 */       mv.x = xLow;
/*     */     } 
/*     */     
/*  34 */     if (mv.y > yHigh) {
/*  35 */       mv.y = yHigh;
/*  36 */     } else if (mv.y < yLow) {
/*  37 */       mv.y = yLow;
/*     */     } 
/*     */   }
/*     */   
/*     */   static void validateVector(Macroblock.Vector[] mvs, MPEG4DecodingContext ctx, int xPos, int yPos) {
/*  42 */     int shift = 5 + (ctx.quarterPel ? 1 : 0);
/*  43 */     int xHigh = ctx.mbWidth - xPos << shift;
/*  44 */     int xLow = -xPos - 1 << shift;
/*  45 */     int yHigh = ctx.mbHeight - yPos << shift;
/*  46 */     int yLow = -yPos - 1 << shift;
/*     */     
/*  48 */     checkMV(mvs[0], xHigh, xLow, yHigh, yLow);
/*  49 */     checkMV(mvs[1], xHigh, xLow, yHigh, yLow);
/*  50 */     checkMV(mvs[2], xHigh, xLow, yHigh, yLow);
/*  51 */     checkMV(mvs[3], xHigh, xLow, yHigh, yLow);
/*     */   }
/*     */   
/*     */   public static void renderIntra(Macroblock mb, MPEG4DecodingContext ctx) {
/*  55 */     MPEG4DCT.idctPut(mb.pred, mb.block, (ctx.interlacing && mb.fieldDCT));
/*     */   }
/*     */ 
/*     */   
/*     */   public static void renderInter(MPEG4DecodingContext ctx, Picture[] refs, Macroblock mb, int fcode, int ref, boolean bvop) {
/*  60 */     if (mb.coded) {
/*  61 */       if (mb.mcsel)
/*  62 */         throw new RuntimeException("GMC"); 
/*  63 */       if (mb.mode == 0 || mb.mode == 1 || mb.mode == 2) {
/*  64 */         if (!mb.fieldPred) {
/*  65 */           renderMBInter(ctx, refs, mb, ref, bvop);
/*     */         } else {
/*  67 */           throw new RuntimeException("interlaced");
/*     */         } 
/*     */       } else {
/*  70 */         renderIntra(mb, ctx);
/*     */       } 
/*     */     } else {
/*  73 */       renderMBInter(ctx, refs, mb, ref, bvop);
/*     */     } 
/*     */   }
/*     */   
/*     */   static void renderMBInter(MPEG4DecodingContext ctx, Picture[] refs, Macroblock mb, int ref, boolean bvop) {
/*     */     int uv_dx, uv_dy;
/*  79 */     Macroblock.Vector[] mv = new Macroblock.Vector[4];
/*     */     
/*  81 */     for (int i = 0; i < 4; i++) {
/*  82 */       mv[i] = new Macroblock.Vector((mb.mvs[i]).x, (mb.mvs[i]).y);
/*     */     }
/*     */     
/*  85 */     validateVector(mv, ctx, mb.x, mb.y);
/*     */     
/*  87 */     int mbX = mb.x << 4;
/*  88 */     int mbY = mb.y << 4;
/*  89 */     int codedW = ctx.mbWidth << 4;
/*  90 */     int codedH = ctx.mbHeight << 4;
/*  91 */     int codedWcr = ctx.mbWidth << 3;
/*  92 */     int codedHcr = ctx.mbHeight << 3;
/*     */     
/*  94 */     if (mb.mode != 2 || bvop) {
/*  95 */       Picture backward = refs[ref];
/*     */       
/*  97 */       uv_dx = calcChromaMv(ctx, (mv[0]).x);
/*  98 */       uv_dy = calcChromaMv(ctx, (mv[0]).y);
/*     */       
/* 100 */       if (ctx.quarterPel) {
/* 101 */         MPEG4Interpolator.interpolate16x16QP(mb.pred[0], backward.getPlaneData(0), mbX, mbY, codedW, codedH, (mv[0]).x, (mv[0]).y, backward
/* 102 */             .getWidth(), ctx.rounding);
/*     */       } else {
/* 104 */         MPEG4Interpolator.interpolate16x16Planar(mb.pred[0], backward.getPlaneData(0), mbX, mbY, codedW, codedH, (mv[0]).x, (mv[0]).y, backward
/* 105 */             .getWidth(), ctx.rounding);
/*     */       } 
/*     */     } else {
/* 108 */       uv_dx = calcChromaMvAvg(ctx, mv, true);
/* 109 */       uv_dy = calcChromaMvAvg(ctx, mv, false);
/*     */       
/* 111 */       Picture backward = refs[0];
/*     */       
/* 113 */       byte[] lumaPlane = backward.getPlaneData(0);
/* 114 */       int lumaStride = backward.getWidth();
/* 115 */       if (ctx.quarterPel) {
/* 116 */         MPEG4Interpolator.interpolate8x8QP(mb.pred[0], 0, lumaPlane, mbX, mbY, codedW, codedH, (mv[0]).x, (mv[0]).y, lumaStride, ctx.rounding);
/*     */         
/* 118 */         MPEG4Interpolator.interpolate8x8QP(mb.pred[0], 8, lumaPlane, mbX + 8, mbY, codedW, codedH, (mv[1]).x, (mv[1]).y, lumaStride, ctx.rounding);
/*     */         
/* 120 */         MPEG4Interpolator.interpolate8x8QP(mb.pred[0], 128, lumaPlane, mbX, mbY + 8, codedW, codedH, (mv[2]).x, (mv[2]).y, lumaStride, ctx.rounding);
/*     */         
/* 122 */         MPEG4Interpolator.interpolate8x8QP(mb.pred[0], 136, lumaPlane, mbX + 8, mbY + 8, codedW, codedH, (mv[3]).x, (mv[3]).y, lumaStride, ctx.rounding);
/*     */       } else {
/*     */         
/* 125 */         MPEG4Interpolator.interpolate8x8Planar(mb.pred[0], 0, 16, lumaPlane, mbX, mbY, codedW, codedH, (mv[0]).x, (mv[0]).y, lumaStride, ctx.rounding);
/*     */         
/* 127 */         MPEG4Interpolator.interpolate8x8Planar(mb.pred[0], 8, 16, lumaPlane, mbX + 8, mbY, codedW, codedH, (mv[1]).x, (mv[1]).y, lumaStride, ctx.rounding);
/*     */         
/* 129 */         MPEG4Interpolator.interpolate8x8Planar(mb.pred[0], 128, 16, lumaPlane, mbX, mbY + 8, codedW, codedH, (mv[2]).x, (mv[2]).y, lumaStride, ctx.rounding);
/*     */         
/* 131 */         MPEG4Interpolator.interpolate8x8Planar(mb.pred[0], 136, 16, lumaPlane, mbX + 8, mbY + 8, codedW, codedH, (mv[3]).x, (mv[3]).y, lumaStride, ctx.rounding);
/*     */       } 
/*     */     } 
/*     */ 
/*     */ 
/*     */     
/* 137 */     MPEG4Interpolator.interpolate8x8Planar(mb.pred[1], 0, 8, refs[ref].getPlaneData(1), 8 * mb.x, 8 * mb.y, codedWcr, codedHcr, uv_dx, uv_dy, refs[ref]
/* 138 */         .getPlaneWidth(1), ctx.rounding);
/* 139 */     MPEG4Interpolator.interpolate8x8Planar(mb.pred[2], 0, 8, refs[ref].getPlaneData(2), 8 * mb.x, 8 * mb.y, codedWcr, codedHcr, uv_dx, uv_dy, refs[ref]
/* 140 */         .getPlaneWidth(2), ctx.rounding);
/*     */     
/* 142 */     if (mb.cbp != 0) {
/* 143 */       for (int j = 0; j < 6; j++) {
/* 144 */         short[] block = mb.block[j];
/* 145 */         if ((mb.cbp & 1 << 5 - j) != 0) {
/* 146 */           MPEG4DCT.idctAdd(mb.pred, block, j, (ctx.interlacing && mb.fieldDCT));
/*     */         }
/*     */       } 
/*     */     }
/*     */   }
/*     */   
/*     */   static int calcChromaMv(MPEG4DecodingContext ctx, int ret) {
/* 153 */     if (ctx.quarterPel) {
/* 154 */       if (ctx.bsVersion <= 1) {
/* 155 */         ret = ret >> 1 | ret & 0x1;
/*     */       } else {
/* 157 */         ret /= 2;
/*     */       } 
/*     */     }
/*     */     
/* 161 */     return (ret >> 1) + MPEG4Consts.ROUNDTAB_79[ret & 0x3];
/*     */   }
/*     */ 
/*     */   
/*     */   static int calcChromaMvAvg(MPEG4DecodingContext ctx, Macroblock.Vector[] mv, boolean x) {
/* 166 */     if (ctx.quarterPel) {
/* 167 */       if (ctx.bsVersion <= 1) {
/* 168 */         ret = 0;
/*     */         
/* 170 */         for (int z = 0; z < 4; z++) {
/* 171 */           if (x) {
/* 172 */             ret += (mv[z]).x >> 1 | (mv[z]).x & 0x1;
/*     */           } else {
/* 174 */             ret += (mv[z]).y >> 1 | (mv[z]).y & 0x1;
/*     */           } 
/*     */         } 
/* 177 */       } else if (x) {
/* 178 */         ret = (mv[0]).x / 2 + (mv[1]).x / 2 + (mv[2]).x / 2 + (mv[3]).x / 2;
/*     */       } else {
/* 180 */         ret = (mv[0]).y / 2 + (mv[1]).y / 2 + (mv[2]).y / 2 + (mv[3]).y / 2;
/*     */       }
/*     */     
/* 183 */     } else if (x) {
/* 184 */       ret = (mv[0]).x + (mv[1]).x + (mv[2]).x + (mv[3]).x;
/*     */     } else {
/* 186 */       ret = (mv[0]).y + (mv[1]).y + (mv[2]).y + (mv[3]).y;
/*     */     } 
/*     */     
/* 189 */     int ret = (ret >> 3) + MPEG4Consts.ROUNDTAB_76[ret & 0xF];
/* 190 */     return ret;
/*     */   }
/*     */   
/*     */   public static final int sanitize(int value, boolean quarterPel, int fcode) {
/* 194 */     int length = 1 << fcode + 4;
/*     */     
/* 196 */     if (value < -length)
/* 197 */       return -length; 
/* 198 */     if (value >= length) {
/* 199 */       return length - 1;
/*     */     }
/* 201 */     return value;
/*     */   }
/*     */ }


/* Location:              C:\Users\rapha\Downloads\aurora.jar!\META-INF\jars\jcodec-0.2.5.jar!\org\jcodec\codecs\mpeg4\MPEG4Renderer.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */