/*    */ package org.jcodec.codecs.mpeg4;public class Macroblock { public static final int MBPRED_SIZE = 15; public Vector[] mvs; public short[][] predValues;
/*    */   public int[] acpredDirections;
/*    */   public int mode;
/*    */   public int quant;
/*    */   public boolean fieldDCT;
/*    */   public boolean fieldPred;
/*    */   public boolean fieldForTop;
/*    */   public boolean fieldForBottom;
/*    */   private Vector[] pmvs;
/*    */   private Vector[] qmvs;
/*    */   public int cbp;
/*    */   
/*    */   public static Vector vec() {
/* 14 */     return new Vector(0, 0);
/*    */   }
/*    */   public Vector[] bmvs; public Vector[] bqmvs; public Vector amv; public Vector mvsAvg; public int x; public int y; public int bound; public boolean acpredFlag; public short[] predictors; public short[][] block; public boolean coded; public boolean mcsel; public byte[][] pred;
/*    */   public static class Vector { public int x; public int y;
/*    */     public Vector(int x, int y) {
/* 19 */       this.x = x;
/* 20 */       this.y = y;
/*    */     } }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public Macroblock() {
/* 69 */     this.mvs = new Vector[4];
/* 70 */     this.pmvs = new Vector[4];
/* 71 */     this.qmvs = new Vector[4];
/* 72 */     this.bmvs = new Vector[4];
/* 73 */     this.bqmvs = new Vector[4];
/*    */     
/* 75 */     for (int i = 0; i < 4; i++) {
/* 76 */       this.mvs[i] = vec();
/* 77 */       this.pmvs[i] = vec();
/* 78 */       this.qmvs[i] = vec();
/* 79 */       this.bmvs[i] = vec();
/* 80 */       this.bqmvs[i] = vec();
/*    */     } 
/* 82 */     this.pred = new byte[][] { new byte[256], new byte[64], new byte[64], new byte[256], new byte[64], new byte[64] };
/* 83 */     this.predValues = new short[6][15];
/* 84 */     this.acpredDirections = new int[6];
/* 85 */     this.amv = vec();
/* 86 */     this.predictors = new short[8];
/* 87 */     this.block = new short[6][64];
/*    */   }
/*    */   
/*    */   public void reset(int x2, int y2, int bound2) {
/* 91 */     this.x = x2;
/* 92 */     this.y = y2;
/* 93 */     this.bound = bound2;
/*    */   } }


/* Location:              C:\Users\rapha\Downloads\aurora.jar!\META-INF\jars\jcodec-0.2.5.jar!\org\jcodec\codecs\mpeg4\Macroblock.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */