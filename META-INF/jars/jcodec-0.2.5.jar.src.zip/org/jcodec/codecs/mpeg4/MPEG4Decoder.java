/*     */ package org.jcodec.codecs.mpeg4;
/*     */ 
/*     */ import java.nio.ByteBuffer;
/*     */ import org.jcodec.common.UsedViaReflection;
/*     */ import org.jcodec.common.VideoCodecMeta;
/*     */ import org.jcodec.common.VideoDecoder;
/*     */ import org.jcodec.common.io.BitReader;
/*     */ import org.jcodec.common.model.ColorSpace;
/*     */ import org.jcodec.common.model.Picture;
/*     */ import org.jcodec.common.model.Rect;
/*     */ import org.jcodec.common.model.Size;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class MPEG4Decoder
/*     */   extends VideoDecoder
/*     */ {
/*  42 */   private Picture[] refs = new Picture[2];
/*     */   
/*     */   private Macroblock[] prevMBs;
/*     */   
/*     */   public Picture decodeFrame(ByteBuffer data, byte[][] buffer) {
/*  47 */     if (this.ctx == null)
/*  48 */       this.ctx = new MPEG4DecodingContext(); 
/*  49 */     if (!this.ctx.readHeaders(data)) {
/*  50 */       return null;
/*     */     }
/*  52 */     this.ctx.fcodeForward = this.ctx.fcodeBackward = this.ctx.intraDCThreshold = 0;
/*     */     
/*  54 */     BitReader br = BitReader.createBitReader(data);
/*     */     
/*  56 */     if (!this.ctx.readVOPHeader(br)) {
/*  57 */       return null;
/*     */     }
/*  59 */     this.mbs = new Macroblock[this.ctx.mbWidth * this.ctx.mbHeight];
/*  60 */     for (int i = 0; i < this.mbs.length; i++) {
/*  61 */       this.mbs[i] = new Macroblock();
/*     */     }
/*     */     
/*  64 */     Picture decoded = null;
/*  65 */     if (this.ctx.codingType != 2) {
/*  66 */       switch (this.ctx.codingType) {
/*     */         case 0:
/*  68 */           decoded = decodeIFrame(br, this.ctx, buffer);
/*     */           break;
/*     */         case 1:
/*  71 */           decoded = decodePFrame(br, this.ctx, buffer, this.ctx.fcodeForward);
/*     */           break;
/*     */         case 3:
/*  74 */           throw new RuntimeException("GMC not supported.");
/*     */         case 4:
/*  76 */           return null;
/*     */       } 
/*     */       
/*  79 */       this.refs[1] = this.refs[0];
/*  80 */       this.refs[0] = decoded;
/*     */       
/*  82 */       this.prevMBs = this.mbs;
/*     */     } else {
/*  84 */       decoded = decodeBFrame(br, this.ctx, buffer, this.ctx.quant, this.ctx.fcodeForward, this.ctx.fcodeBackward);
/*     */     } 
/*     */     
/*  87 */     br.terminate();
/*     */     
/*  89 */     return decoded;
/*     */   }
/*     */   private Macroblock[] mbs; private MPEG4DecodingContext ctx;
/*     */   private Picture decodeIFrame(BitReader br, MPEG4DecodingContext ctx, byte[][] buffer) {
/*  93 */     Picture p = new Picture(ctx.mbWidth << 4, ctx.mbHeight << 4, buffer, (byte[][])null, ColorSpace.YUV420, 0, new Rect(0, 0, ctx.width, ctx.height));
/*     */     
/*  95 */     int bound = 0;
/*     */     
/*  97 */     for (int y = 0; y < ctx.mbHeight; y++) {
/*  98 */       for (int x = 0; x < ctx.mbWidth; x++) {
/*  99 */         Macroblock mb = this.mbs[y * ctx.mbWidth + x];
/* 100 */         mb.reset(x, y, bound);
/*     */         
/* 102 */         MPEG4Bitstream.readIntraMode(br, ctx, mb);
/* 103 */         int index = x + y * ctx.mbWidth;
/* 104 */         Macroblock aboveMb = null;
/* 105 */         Macroblock aboveLeftMb = null;
/* 106 */         Macroblock leftMb = null;
/* 107 */         int apos = index - ctx.mbWidth;
/* 108 */         int lpos = index - 1;
/* 109 */         int alpos = index - 1 - ctx.mbWidth;
/* 110 */         if (apos >= bound)
/* 111 */           aboveMb = this.mbs[apos]; 
/* 112 */         if (alpos >= bound)
/* 113 */           aboveLeftMb = this.mbs[alpos]; 
/* 114 */         if (x > 0 && lpos >= bound)
/* 115 */           leftMb = this.mbs[lpos]; 
/* 116 */         MPEG4Bitstream.readCoeffIntra(br, ctx, mb, aboveMb, leftMb, aboveLeftMb);
/*     */         
/* 118 */         x = mb.x;
/* 119 */         y = mb.y;
/* 120 */         bound = mb.bound;
/*     */         
/* 122 */         MPEG4Renderer.renderIntra(mb, ctx);
/*     */         
/* 124 */         putPix(p, mb, x, y);
/*     */       } 
/*     */     } 
/*     */     
/* 128 */     return p;
/*     */   }
/*     */   
/*     */   Picture decodePFrame(BitReader br, MPEG4DecodingContext ctx, byte[][] buffers, int fcode) {
/* 132 */     int bound = 0;
/* 133 */     int mbWidth = ctx.mbWidth;
/* 134 */     int mbHeight = ctx.mbHeight;
/*     */     
/* 136 */     Picture p = new Picture(ctx.mbWidth << 4, ctx.mbHeight << 4, buffers, (byte[][])null, ColorSpace.YUV420, 0, new Rect(0, 0, ctx.width, ctx.height));
/*     */ 
/*     */     
/* 139 */     for (int y = 0; y < mbHeight; y++) {
/* 140 */       for (int x = 0; x < mbWidth; x++) {
/*     */         
/* 142 */         while (br.checkNBit(10) == 1) {
/* 143 */           br.skip(10);
/*     */         }
/* 145 */         if (MPEG4Bitstream.checkResyncMarker(br, fcode - 1)) {
/* 146 */           bound = MPEG4Bitstream.readVideoPacketHeader(br, ctx, fcode - 1, true, false, true);
/* 147 */           x = bound % mbWidth;
/* 148 */           y = bound / mbWidth;
/*     */         } 
/*     */         
/* 151 */         int index = x + y * ctx.mbWidth;
/* 152 */         Macroblock aboveMb = null;
/* 153 */         Macroblock aboveLeftMb = null;
/* 154 */         Macroblock leftMb = null;
/* 155 */         Macroblock aboveRightMb = null;
/* 156 */         int apos = index - ctx.mbWidth;
/* 157 */         int lpos = index - 1;
/* 158 */         int alpos = index - 1 - ctx.mbWidth;
/* 159 */         int arpos = index + 1 - ctx.mbWidth;
/* 160 */         if (apos >= bound)
/* 161 */           aboveMb = this.mbs[apos]; 
/* 162 */         if (alpos >= bound)
/* 163 */           aboveLeftMb = this.mbs[alpos]; 
/* 164 */         if (x > 0 && lpos >= bound)
/* 165 */           leftMb = this.mbs[lpos]; 
/* 166 */         if (arpos >= bound && x < ctx.mbWidth - 1) {
/* 167 */           aboveRightMb = this.mbs[arpos];
/*     */         }
/* 169 */         Macroblock mb = this.mbs[y * ctx.mbWidth + x];
/*     */         
/* 171 */         mb.reset(x, y, bound);
/*     */         
/* 173 */         MPEG4Bitstream.readInterModeCoeffs(br, ctx, fcode, mb, aboveMb, leftMb, aboveLeftMb, aboveRightMb);
/*     */         
/* 175 */         MPEG4Renderer.renderInter(ctx, this.refs, mb, fcode, 0, false);
/*     */         
/* 177 */         putPix(p, mb, x, y);
/*     */       } 
/*     */     } 
/*     */     
/* 181 */     return p;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private Picture decodeBFrame(BitReader br, MPEG4DecodingContext ctx, byte[][] buffers, int quant, int fcodeForward, int fcodeBackward) {
/* 187 */     Picture p = new Picture(ctx.mbWidth << 4, ctx.mbHeight << 4, buffers, (byte[][])null, ColorSpace.YUV420, 0, new Rect(0, 0, ctx.width, ctx.height));
/*     */ 
/*     */     
/* 190 */     Macroblock.Vector pFMV = Macroblock.vec(), pBMV = Macroblock.vec();
/*     */     
/* 192 */     int fcodeMax = (fcodeForward > fcodeBackward) ? fcodeForward : fcodeBackward;
/* 193 */     for (int y = 0; y < ctx.mbHeight; y++) {
/* 194 */       pBMV.x = pBMV.y = pFMV.x = pFMV.y = 0;
/*     */       
/* 196 */       for (int x = 0; x < ctx.mbWidth; x++) {
/* 197 */         Macroblock mb = this.mbs[y * ctx.mbWidth + x];
/* 198 */         Macroblock lastMB = this.prevMBs[y * ctx.mbWidth + x];
/*     */         
/* 200 */         if (MPEG4Bitstream.checkResyncMarker(br, fcodeMax - 1)) {
/* 201 */           int bound = MPEG4Bitstream.readVideoPacketHeader(br, ctx, fcodeMax - 1, (fcodeForward != 0), (fcodeBackward != 0), (ctx.intraDCThreshold != 0));
/*     */           
/* 203 */           x = bound % ctx.mbWidth;
/* 204 */           y = bound / ctx.mbWidth;
/* 205 */           pBMV.x = pBMV.y = pFMV.x = pFMV.y = 0;
/*     */         } 
/* 207 */         mb.x = x;
/* 208 */         mb.y = y;
/*     */         
/* 210 */         mb.quant = quant;
/*     */         
/* 212 */         if (lastMB.mode == 16) {
/* 213 */           mb.cbp = 0;
/* 214 */           mb.mode = 3;
/* 215 */           MPEG4Bitstream.readInterCoeffs(br, ctx, mb);
/* 216 */           MPEG4Renderer.renderInter(ctx, this.refs, lastMB, fcodeForward, 1, true);
/* 217 */           putPix(p, lastMB, x, y);
/*     */         }
/*     */         else {
/*     */           
/* 221 */           MPEG4Bitstream.readBi(br, ctx, fcodeForward, fcodeBackward, mb, lastMB, pFMV, pBMV);
/* 222 */           MPEG4BiRenderer.renderBi(ctx, this.refs, fcodeForward, fcodeBackward, mb);
/*     */           
/* 224 */           putPix(p, mb, x, y);
/*     */         } 
/*     */       } 
/*     */     } 
/* 228 */     return p;
/*     */   }
/*     */   
/*     */   public static void putPix(Picture p, Macroblock mb, int x, int y) {
/* 232 */     byte[] plane0 = p.getPlaneData(0);
/* 233 */     int dsto0 = (y << 4) * p.getWidth() + (x << 4);
/* 234 */     for (int row = 0, srco = 0; row < 16; row++, dsto0 += p.getWidth()) {
/* 235 */       for (int col = 0; col < 16; col++, srco++) {
/* 236 */         plane0[dsto0 + col] = mb.pred[0][srco];
/*     */       }
/*     */     } 
/* 239 */     for (int pl = 1; pl < 3; pl++) {
/* 240 */       byte[] plane = p.getPlaneData(pl);
/* 241 */       int dsto = (y << 3) * p.getPlaneWidth(pl) + (x << 3);
/* 242 */       for (int i = 0, j = 0; i < 8; i++, dsto += p.getPlaneWidth(pl)) {
/* 243 */         for (int col = 0; col < 8; col++, j++) {
/* 244 */           plane[dsto + col] = mb.pred[pl][j];
/*     */         }
/*     */       } 
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public VideoCodecMeta getCodecMeta(ByteBuffer data) {
/* 252 */     MPEG4DecodingContext ctx = MPEG4DecodingContext.readFromHeaders(data.duplicate());
/* 253 */     if (ctx == null) {
/* 254 */       return null;
/*     */     }
/* 256 */     return VideoCodecMeta.createSimpleVideoCodecMeta(new Size(ctx.width, ctx.height), ColorSpace.YUV420J);
/*     */   }
/*     */   
/*     */   @UsedViaReflection
/*     */   public static int probe(ByteBuffer data) {
/* 261 */     MPEG4DecodingContext ctx = MPEG4DecodingContext.readFromHeaders(data.duplicate());
/* 262 */     if (ctx == null)
/* 263 */       return 0; 
/* 264 */     return Math.min((ctx.width > 320) ? ((ctx.width < 1280) ? 100 : 50) : 50, (ctx.height > 240) ? ((ctx.height < 720) ? 100 : 50) : 50);
/*     */   }
/*     */ }


/* Location:              C:\Users\rapha\Downloads\aurora.jar!\META-INF\jars\jcodec-0.2.5.jar!\org\jcodec\codecs\mpeg4\MPEG4Decoder.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */