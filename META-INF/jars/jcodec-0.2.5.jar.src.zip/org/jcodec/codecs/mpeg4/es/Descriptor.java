/*    */ package org.jcodec.codecs.mpeg4.es;
/*    */ 
/*    */ import java.nio.ByteBuffer;
/*    */ import org.jcodec.common.JCodecUtil2;
/*    */ import org.jcodec.common.io.NIOUtils;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public abstract class Descriptor
/*    */ {
/*    */   private int _tag;
/*    */   private int size;
/*    */   
/*    */   public Descriptor(int tag, int size) {
/* 20 */     this._tag = tag;
/* 21 */     this.size = size;
/*    */   }
/*    */   
/*    */   public void write(ByteBuffer out) {
/* 25 */     ByteBuffer fork = out.duplicate();
/* 26 */     NIOUtils.skip(out, 5);
/* 27 */     doWrite(out);
/*    */     
/* 29 */     int length = out.position() - fork.position() - 5;
/* 30 */     fork.put((byte)this._tag);
/* 31 */     JCodecUtil2.writeBER32(fork, length);
/*    */   }
/*    */   
/*    */   protected abstract void doWrite(ByteBuffer paramByteBuffer);
/*    */   
/*    */   int getTag() {
/* 37 */     return this._tag;
/*    */   }
/*    */ }


/* Location:              C:\Users\rapha\Downloads\aurora.jar!\META-INF\jars\jcodec-0.2.5.jar!\org\jcodec\codecs\mpeg4\es\Descriptor.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */