/*    */ package org.jcodec.codecs.mpeg4.es;
/*    */ 
/*    */ import java.nio.ByteBuffer;
/*    */ import org.jcodec.common.io.NIOUtils;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class DecoderSpecific
/*    */   extends Descriptor
/*    */ {
/*    */   private ByteBuffer data;
/*    */   
/*    */   public DecoderSpecific(ByteBuffer data) {
/* 18 */     super(tag(), 0);
/* 19 */     this.data = data;
/*    */   }
/*    */   
/*    */   protected void doWrite(ByteBuffer out) {
/* 23 */     NIOUtils.write(out, this.data);
/*    */   }
/*    */   
/*    */   public static int tag() {
/* 27 */     return 5;
/*    */   }
/*    */   
/*    */   public ByteBuffer getData() {
/* 31 */     return this.data;
/*    */   }
/*    */ }


/* Location:              C:\Users\rapha\Downloads\aurora.jar!\META-INF\jars\jcodec-0.2.5.jar!\org\jcodec\codecs\mpeg4\es\DecoderSpecific.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */