/*    */ package org.jcodec.codecs.mpeg4.es;
/*    */ 
/*    */ import java.nio.ByteBuffer;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class SL
/*    */   extends Descriptor
/*    */ {
/*    */   public SL() {
/* 17 */     super(tag(), 0);
/*    */   }
/*    */   
/*    */   protected void doWrite(ByteBuffer out) {
/* 21 */     out.put((byte)2);
/*    */   }
/*    */   
/*    */   public static int tag() {
/* 25 */     return 6;
/*    */   }
/*    */ }


/* Location:              C:\Users\rapha\Downloads\aurora.jar!\META-INF\jars\jcodec-0.2.5.jar!\org\jcodec\codecs\mpeg4\es\SL.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */