/*    */ package org.jcodec.codecs.mpeg4.es;
/*    */ 
/*    */ import java.nio.ByteBuffer;
/*    */ import java.util.Collection;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class DecoderConfig
/*    */   extends NodeDescriptor
/*    */ {
/*    */   private int objectType;
/*    */   private int bufSize;
/*    */   private int maxBitrate;
/*    */   private int avgBitrate;
/*    */   
/*    */   public DecoderConfig(int objectType, int bufSize, int maxBitrate, int avgBitrate, Collection<Descriptor> children) {
/* 19 */     super(tag(), children);
/* 20 */     this.objectType = objectType;
/* 21 */     this.bufSize = bufSize;
/* 22 */     this.maxBitrate = maxBitrate;
/* 23 */     this.avgBitrate = avgBitrate;
/*    */   }
/*    */   
/*    */   protected void doWrite(ByteBuffer out) {
/* 27 */     out.put((byte)this.objectType);
/*    */     
/* 29 */     out.put((byte)21);
/* 30 */     out.put((byte)(this.bufSize >> 16));
/* 31 */     out.putShort((short)this.bufSize);
/* 32 */     out.putInt(this.maxBitrate);
/* 33 */     out.putInt(this.avgBitrate);
/*    */     
/* 35 */     super.doWrite(out);
/*    */   }
/*    */   
/*    */   public static int tag() {
/* 39 */     return 4;
/*    */   }
/*    */   
/*    */   public int getObjectType() {
/* 43 */     return this.objectType;
/*    */   }
/*    */   
/*    */   public int getBufSize() {
/* 47 */     return this.bufSize;
/*    */   }
/*    */   
/*    */   public int getMaxBitrate() {
/* 51 */     return this.maxBitrate;
/*    */   }
/*    */   
/*    */   public int getAvgBitrate() {
/* 55 */     return this.avgBitrate;
/*    */   }
/*    */ }


/* Location:              C:\Users\rapha\Downloads\aurora.jar!\META-INF\jars\jcodec-0.2.5.jar!\org\jcodec\codecs\mpeg4\es\DecoderConfig.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */