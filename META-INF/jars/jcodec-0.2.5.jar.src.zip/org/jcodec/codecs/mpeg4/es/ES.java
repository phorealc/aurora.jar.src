/*    */ package org.jcodec.codecs.mpeg4.es;
/*    */ 
/*    */ import java.nio.ByteBuffer;
/*    */ import java.util.Collection;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class ES
/*    */   extends NodeDescriptor
/*    */ {
/*    */   private int trackId;
/*    */   
/*    */   public ES(int trackId, Collection<Descriptor> children) {
/* 16 */     super(tag(), children);
/* 17 */     this.trackId = trackId;
/*    */   }
/*    */   
/*    */   public static int tag() {
/* 21 */     return 3;
/*    */   }
/*    */   
/*    */   protected void doWrite(ByteBuffer out) {
/* 25 */     out.putShort((short)this.trackId);
/* 26 */     out.put((byte)0);
/* 27 */     super.doWrite(out);
/*    */   }
/*    */   
/*    */   public int getTrackId() {
/* 31 */     return this.trackId;
/*    */   }
/*    */ }


/* Location:              C:\Users\rapha\Downloads\aurora.jar!\META-INF\jars\jcodec-0.2.5.jar!\org\jcodec\codecs\mpeg4\es\ES.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */