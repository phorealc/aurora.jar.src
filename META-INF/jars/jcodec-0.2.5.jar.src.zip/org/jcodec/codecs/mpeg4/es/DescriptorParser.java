/*    */ package org.jcodec.codecs.mpeg4.es;
/*    */ 
/*    */ import java.nio.ByteBuffer;
/*    */ import java.util.ArrayList;
/*    */ import java.util.Collection;
/*    */ import org.jcodec.common.JCodecUtil2;
/*    */ import org.jcodec.common.Preconditions;
/*    */ import org.jcodec.common.UsedViaReflection;
/*    */ import org.jcodec.common.io.NIOUtils;
/*    */ 
/*    */ 
/*    */ 
/*    */ public class DescriptorParser
/*    */ {
/*    */   private static final int ES_TAG = 3;
/*    */   private static final int DC_TAG = 4;
/*    */   private static final int DS_TAG = 5;
/*    */   private static final int SL_TAG = 6;
/*    */   
/*    */   public static Descriptor read(ByteBuffer input) {
/* 21 */     if (input.remaining() < 2)
/* 22 */       return null; 
/* 23 */     int tag = input.get() & 0xFF;
/* 24 */     int size = JCodecUtil2.readBER32(input);
/*    */     
/* 26 */     ByteBuffer byteBuffer = NIOUtils.read(input, size);
/*    */     
/* 28 */     switch (tag) {
/*    */       case 3:
/* 30 */         return parseES(byteBuffer);
/*    */       case 6:
/* 32 */         return parseSL(byteBuffer);
/*    */       case 4:
/* 34 */         return parseDecoderConfig(byteBuffer);
/*    */       case 5:
/* 36 */         return parseDecoderSpecific(byteBuffer);
/*    */     } 
/* 38 */     throw new RuntimeException("unknown tag " + tag);
/*    */   }
/*    */ 
/*    */   
/*    */   @UsedViaReflection
/*    */   private static NodeDescriptor parseNodeDesc(ByteBuffer input) {
/* 44 */     Collection<Descriptor> children = new ArrayList<Descriptor>();
/*    */     
/*    */     while (true) {
/* 47 */       Descriptor d = read(input);
/* 48 */       if (d != null)
/* 49 */         children.add(d); 
/* 50 */       if (d == null)
/* 51 */         return new NodeDescriptor(0, children); 
/*    */     } 
/*    */   }
/*    */   private static ES parseES(ByteBuffer input) {
/* 55 */     int trackId = input.getShort();
/* 56 */     input.get();
/* 57 */     NodeDescriptor node = parseNodeDesc(input);
/* 58 */     return new ES(trackId, node.getChildren());
/*    */   }
/*    */   
/*    */   private static SL parseSL(ByteBuffer input) {
/* 62 */     Preconditions.checkState((2 == (input.get() & 0xFF)));
/* 63 */     return new SL();
/*    */   }
/*    */   
/*    */   private static DecoderSpecific parseDecoderSpecific(ByteBuffer input) {
/* 67 */     ByteBuffer data = NIOUtils.readBuf(input);
/* 68 */     return new DecoderSpecific(data);
/*    */   }
/*    */   
/*    */   private static DecoderConfig parseDecoderConfig(ByteBuffer input) {
/* 72 */     int objectType = input.get() & 0xFF;
/* 73 */     input.get();
/* 74 */     int bufSize = (input.get() & 0xFF) << 16 | input.getShort() & 0xFFFF;
/* 75 */     int maxBitrate = input.getInt();
/* 76 */     int avgBitrate = input.getInt();
/*    */     
/* 78 */     NodeDescriptor node = parseNodeDesc(input);
/* 79 */     return new DecoderConfig(objectType, bufSize, maxBitrate, avgBitrate, node.getChildren());
/*    */   }
/*    */ }


/* Location:              C:\Users\rapha\Downloads\aurora.jar!\META-INF\jars\jcodec-0.2.5.jar!\org\jcodec\codecs\mpeg4\es\DescriptorParser.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */