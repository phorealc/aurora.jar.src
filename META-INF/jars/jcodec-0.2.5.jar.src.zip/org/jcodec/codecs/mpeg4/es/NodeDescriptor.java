/*    */ package org.jcodec.codecs.mpeg4.es;
/*    */ 
/*    */ import java.nio.ByteBuffer;
/*    */ import java.util.Collection;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class NodeDescriptor
/*    */   extends Descriptor
/*    */ {
/*    */   private Collection<Descriptor> children;
/*    */   
/*    */   public NodeDescriptor(int tag, Collection<Descriptor> children) {
/* 17 */     super(tag, 0);
/* 18 */     this.children = children;
/*    */   }
/*    */   
/*    */   protected void doWrite(ByteBuffer out) {
/* 22 */     for (Descriptor descr : this.children) {
/* 23 */       descr.write(out);
/*    */     }
/*    */   }
/*    */   
/*    */   public Collection<Descriptor> getChildren() {
/* 28 */     return this.children;
/*    */   }
/*    */   
/*    */   public static <T> T findByTag(Descriptor es, int tag) {
/* 32 */     if (es.getTag() == tag) {
/* 33 */       return (T)es;
/*    */     }
/* 35 */     if (es instanceof NodeDescriptor) {
/* 36 */       for (Descriptor descriptor : ((NodeDescriptor)es).getChildren()) {
/* 37 */         T res = findByTag(descriptor, tag);
/* 38 */         if (res != null) {
/* 39 */           return res;
/*    */         }
/*    */       } 
/*    */     }
/* 43 */     return null;
/*    */   }
/*    */ }


/* Location:              C:\Users\rapha\Downloads\aurora.jar!\META-INF\jars\jcodec-0.2.5.jar!\org\jcodec\codecs\mpeg4\es\NodeDescriptor.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */