/*     */ package org.jcodec.codecs.mpeg4;
/*     */ 
/*     */ import org.jcodec.common.tools.MathUtil;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class MPEG4DCT
/*     */ {
/*     */   private static final int W1 = 2841;
/*     */   private static final int W2 = 2676;
/*     */   private static final int W3 = 2408;
/*     */   private static final int W5 = 1609;
/*     */   private static final int W6 = 1108;
/*     */   private static final int W7 = 565;
/*     */   
/*     */   public static void idctPut(byte[][] p, short[][] block, boolean interlacing) {
/*  26 */     idctRows(block[0]);
/*  27 */     idctRows(block[1]);
/*  28 */     idctRows(block[2]);
/*  29 */     idctRows(block[3]);
/*  30 */     idctRows(block[4]);
/*  31 */     idctRows(block[5]);
/*     */     
/*  33 */     int stride = 16;
/*  34 */     int stride2 = 8;
/*  35 */     int nextBlock = 128;
/*  36 */     if (interlacing) {
/*  37 */       nextBlock = stride;
/*  38 */       stride *= 2;
/*     */     } 
/*     */     
/*  41 */     idctColumnsPut(block[0], p[0], 0, stride);
/*  42 */     idctColumnsPut(block[1], p[0], 8, stride);
/*  43 */     idctColumnsPut(block[2], p[0], nextBlock, stride);
/*  44 */     idctColumnsPut(block[3], p[0], nextBlock + 8, stride);
/*  45 */     idctColumnsPut(block[4], p[1], 0, stride2);
/*  46 */     idctColumnsPut(block[5], p[2], 0, stride2);
/*     */   }
/*     */   
/*     */   public static void idctAdd(byte[][] p, short[] block, int index, boolean interlacing) {
/*  50 */     idctRows(block);
/*     */     
/*  52 */     switch (index) {
/*     */       case 0:
/*  54 */         idctColumnsAdd(block, p[0], 0, 16);
/*     */         break;
/*     */       
/*     */       case 1:
/*  58 */         idctColumnsAdd(block, p[0], 8, 16);
/*     */         break;
/*     */       
/*     */       case 2:
/*  62 */         if (interlacing) {
/*  63 */           idctColumnsAdd(block, p[0], 16, 32); break;
/*     */         } 
/*  65 */         idctColumnsAdd(block, p[0], 128, 16);
/*     */         break;
/*     */ 
/*     */       
/*     */       case 3:
/*  70 */         if (interlacing) {
/*  71 */           idctColumnsAdd(block, p[0], 24, 32); break;
/*     */         } 
/*  73 */         idctColumnsAdd(block, p[0], 136, 16);
/*     */         break;
/*     */ 
/*     */       
/*     */       case 4:
/*  78 */         idctColumnsAdd(block, p[1], 0, 8);
/*     */         break;
/*     */       
/*     */       case 5:
/*  82 */         idctColumnsAdd(block, p[2], 0, 8);
/*     */         break;
/*     */     } 
/*     */   }
/*     */   
/*     */   private static final byte clamp255(int val) {
/*  88 */     val -= 255;
/*  89 */     val = -(255 + (val >> 31 & val));
/*  90 */     return (byte)(-(val >> 31 & val) - 128);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public static void idctColumnsPut(short[] block, byte[] dst, int dstOffset, int stride) {
/*  96 */     for (int i = 0; i < 8; i++) {
/*  97 */       int offset = dstOffset + i;
/*     */       int X1, X2, X3, X4, X5, X6, X7;
/*  99 */       if (((X1 = block[i + 32] << 8) | (X2 = block[i + 48]) | (X3 = block[i + 16]) | (X4 = block[i + 8]) | (X5 = block[i + 56]) | (X6 = block[i + 40]) | (X7 = block[i + 24])) == 0) {
/*     */ 
/*     */         
/* 102 */         dst[offset + stride * 7] = 
/*     */           
/* 104 */           clamp255(block[i + 0] + 32 >> 6); dst[offset + stride * 6] = clamp255(block[i + 0] + 32 >> 6); dst[offset + stride * 5] = clamp255(block[i + 0] + 32 >> 6); dst[offset + stride * 4] = clamp255(block[i + 0] + 32 >> 6); dst[offset + stride * 3] = clamp255(block[i + 0] + 32 >> 6); dst[offset + stride * 2] = clamp255(block[i + 0] + 32 >> 6); dst[offset + stride * 1] = clamp255(block[i + 0] + 32 >> 6); dst[offset + stride * 0] = clamp255(block[i + 0] + 32 >> 6);
/*     */       
/*     */       }
/*     */       else {
/*     */         
/* 109 */         int X0 = (block[i + 0] << 8) + 8192;
/*     */         
/* 111 */         int X8 = 565 * (X4 + X5) + 4;
/* 112 */         X4 = X8 + 2276 * X4 >> 3;
/* 113 */         X5 = X8 - 3406 * X5 >> 3;
/* 114 */         X8 = 2408 * (X6 + X7) + 4;
/* 115 */         X6 = X8 - 799 * X6 >> 3;
/* 116 */         X7 = X8 - 4017 * X7 >> 3;
/*     */         
/* 118 */         X8 = X0 + X1;
/* 119 */         X0 -= X1;
/* 120 */         X1 = 1108 * (X3 + X2) + 4;
/* 121 */         X2 = X1 - 3784 * X2 >> 3;
/* 122 */         X3 = X1 + 1568 * X3 >> 3;
/* 123 */         X1 = X4 + X6;
/* 124 */         X4 -= X6;
/* 125 */         X6 = X5 + X7;
/* 126 */         X5 -= X7;
/*     */         
/* 128 */         X7 = X8 + X3;
/* 129 */         X8 -= X3;
/* 130 */         X3 = X0 + X2;
/* 131 */         X0 -= X2;
/* 132 */         X2 = 181 * (X4 + X5) + 128 >> 8;
/* 133 */         X4 = 181 * (X4 - X5) + 128 >> 8;
/*     */         
/* 135 */         dst[offset + stride * 0] = clamp255(X7 + X1 >> 14);
/* 136 */         dst[offset + stride * 1] = clamp255(X3 + X2 >> 14);
/* 137 */         dst[offset + stride * 2] = clamp255(X0 + X4 >> 14);
/* 138 */         dst[offset + stride * 3] = clamp255(X8 + X6 >> 14);
/* 139 */         dst[offset + stride * 4] = clamp255(X8 - X6 >> 14);
/* 140 */         dst[offset + stride * 5] = clamp255(X0 - X4 >> 14);
/* 141 */         dst[offset + stride * 6] = clamp255(X3 - X2 >> 14);
/* 142 */         dst[offset + stride * 7] = clamp255(X7 - X1 >> 14);
/*     */       } 
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public static void idctColumnsAdd(short[] block, byte[] dst, int dstOffset, int stride) {
/* 149 */     for (int i = 0; i < 8; i++) {
/* 150 */       int offset = dstOffset + i;
/*     */       int X1, X2, X3, X4, X5, X6, X7;
/* 152 */       if (((X1 = block[i + 32] << 8) | (X2 = block[i + 48]) | (X3 = block[i + 16]) | (X4 = block[i + 8]) | (X5 = block[i + 56]) | (X6 = block[i + 40]) | (X7 = block[i + 24])) == 0) {
/*     */ 
/*     */         
/* 155 */         int pixel = block[i + 0] + 32 >> 6;
/*     */         
/* 157 */         dst[offset + stride * 0] = (byte)MathUtil.clip(dst[offset + stride * 0] + pixel, -128, 127);
/* 158 */         dst[offset + stride * 1] = (byte)MathUtil.clip(dst[offset + stride * 1] + pixel, -128, 127);
/* 159 */         dst[offset + stride * 2] = (byte)MathUtil.clip(dst[offset + stride * 2] + pixel, -128, 127);
/* 160 */         dst[offset + stride * 3] = (byte)MathUtil.clip(dst[offset + stride * 3] + pixel, -128, 127);
/* 161 */         dst[offset + stride * 4] = (byte)MathUtil.clip(dst[offset + stride * 4] + pixel, -128, 127);
/* 162 */         dst[offset + stride * 5] = (byte)MathUtil.clip(dst[offset + stride * 5] + pixel, -128, 127);
/* 163 */         dst[offset + stride * 6] = (byte)MathUtil.clip(dst[offset + stride * 6] + pixel, -128, 127);
/* 164 */         dst[offset + stride * 7] = (byte)MathUtil.clip(dst[offset + stride * 7] + pixel, -128, 127);
/*     */       
/*     */       }
/*     */       else {
/*     */         
/* 169 */         int X0 = (block[i + 0] << 8) + 8192;
/*     */         
/* 171 */         int X8 = 565 * (X4 + X5) + 4;
/* 172 */         X4 = X8 + 2276 * X4 >> 3;
/* 173 */         X5 = X8 - 3406 * X5 >> 3;
/* 174 */         X8 = 2408 * (X6 + X7) + 4;
/* 175 */         X6 = X8 - 799 * X6 >> 3;
/* 176 */         X7 = X8 - 4017 * X7 >> 3;
/*     */         
/* 178 */         X8 = X0 + X1;
/* 179 */         X0 -= X1;
/* 180 */         X1 = 1108 * (X3 + X2) + 4;
/* 181 */         X2 = X1 - 3784 * X2 >> 3;
/* 182 */         X3 = X1 + 1568 * X3 >> 3;
/* 183 */         X1 = X4 + X6;
/* 184 */         X4 -= X6;
/* 185 */         X6 = X5 + X7;
/* 186 */         X5 -= X7;
/*     */         
/* 188 */         X7 = X8 + X3;
/* 189 */         X8 -= X3;
/* 190 */         X3 = X0 + X2;
/* 191 */         X0 -= X2;
/* 192 */         X2 = 181 * (X4 + X5) + 128 >> 8;
/* 193 */         X4 = 181 * (X4 - X5) + 128 >> 8;
/*     */         
/* 195 */         dst[offset + stride * 0] = (byte)MathUtil.clip(dst[offset + stride * 0] + (X7 + X1 >> 14), -128, 127);
/* 196 */         dst[offset + stride * 1] = (byte)MathUtil.clip(dst[offset + stride * 1] + (X3 + X2 >> 14), -128, 127);
/* 197 */         dst[offset + stride * 2] = (byte)MathUtil.clip(dst[offset + stride * 2] + (X0 + X4 >> 14), -128, 127);
/* 198 */         dst[offset + stride * 3] = (byte)MathUtil.clip(dst[offset + stride * 3] + (X8 + X6 >> 14), -128, 127);
/* 199 */         dst[offset + stride * 4] = (byte)MathUtil.clip(dst[offset + stride * 4] + (X8 - X6 >> 14), -128, 127);
/* 200 */         dst[offset + stride * 5] = (byte)MathUtil.clip(dst[offset + stride * 5] + (X0 - X4 >> 14), -128, 127);
/* 201 */         dst[offset + stride * 6] = (byte)MathUtil.clip(dst[offset + stride * 6] + (X3 - X2 >> 14), -128, 127);
/* 202 */         dst[offset + stride * 7] = (byte)MathUtil.clip(dst[offset + stride * 7] + (X7 - X1 >> 14), -128, 127);
/*     */       } 
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public static void idctRows(short[] block) {
/* 209 */     for (int i = 0; i < 8; i++) {
/* 210 */       int offset = i << 3;
/*     */       int X1, X2, X3, X4, X5, X6, X7;
/* 212 */       if (((X1 = block[offset + 4] << 11) | (X2 = block[offset + 6]) | (X3 = block[offset + 2]) | (X4 = block[offset + 1]) | (X5 = block[offset + 7]) | (X6 = block[offset + 5]) | (X7 = block[offset + 3])) == 0) {
/*     */ 
/*     */         
/* 215 */         block[offset + 7] = (short)(block[offset] << 3); block[offset + 6] = (short)(block[offset] << 3); block[offset + 5] = (short)(block[offset] << 3); block[offset + 4] = (short)(block[offset] << 3); block[offset + 3] = (short)(block[offset] << 3); block[offset + 2] = (short)(block[offset] << 3); block[offset + 1] = (short)(block[offset] << 3); block[offset] = (short)(block[offset] << 3);
/*     */       
/*     */       }
/*     */       else {
/*     */         
/* 220 */         int X0 = (block[offset] << 11) + 128;
/*     */         
/* 222 */         int X8 = 565 * (X4 + X5);
/* 223 */         X4 = X8 + 2276 * X4;
/* 224 */         X5 = X8 - 3406 * X5;
/* 225 */         X8 = 2408 * (X6 + X7);
/* 226 */         X6 = X8 - 799 * X6;
/* 227 */         X7 = X8 - 4017 * X7;
/*     */         
/* 229 */         X8 = X0 + X1;
/* 230 */         X0 -= X1;
/* 231 */         X1 = 1108 * (X3 + X2);
/* 232 */         X2 = X1 - 3784 * X2;
/* 233 */         X3 = X1 + 1568 * X3;
/* 234 */         X1 = X4 + X6;
/* 235 */         X4 -= X6;
/* 236 */         X6 = X5 + X7;
/* 237 */         X5 -= X7;
/*     */         
/* 239 */         X7 = X8 + X3;
/* 240 */         X8 -= X3;
/* 241 */         X3 = X0 + X2;
/* 242 */         X0 -= X2;
/* 243 */         X2 = 181 * (X4 + X5) + 128 >> 8;
/* 244 */         X4 = 181 * (X4 - X5) + 128 >> 8;
/*     */         
/* 246 */         block[offset] = (short)(X7 + X1 >> 8);
/* 247 */         block[offset + 1] = (short)(X3 + X2 >> 8);
/* 248 */         block[offset + 2] = (short)(X0 + X4 >> 8);
/* 249 */         block[offset + 3] = (short)(X8 + X6 >> 8);
/* 250 */         block[offset + 4] = (short)(X8 - X6 >> 8);
/* 251 */         block[offset + 5] = (short)(X0 - X4 >> 8);
/* 252 */         block[offset + 6] = (short)(X3 - X2 >> 8);
/* 253 */         block[offset + 7] = (short)(X7 - X1 >> 8);
/*     */       } 
/*     */     } 
/*     */   }
/*     */ }


/* Location:              C:\Users\rapha\Downloads\aurora.jar!\META-INF\jars\jcodec-0.2.5.jar!\org\jcodec\codecs\mpeg4\MPEG4DCT.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */