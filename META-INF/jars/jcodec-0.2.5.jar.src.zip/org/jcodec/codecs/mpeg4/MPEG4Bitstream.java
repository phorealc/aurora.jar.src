/*      */ package org.jcodec.codecs.mpeg4;
/*      */ 
/*      */ import java.util.Arrays;
/*      */ import org.jcodec.common.io.BitReader;
/*      */ import org.jcodec.common.logging.Logger;
/*      */ import org.jcodec.common.tools.MathUtil;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ class MPEG4Bitstream
/*      */ {
/*      */   public static final int I_VOP = 0;
/*      */   public static final int P_VOP = 1;
/*      */   public static final int B_VOP = 2;
/*      */   public static final int S_VOP = 3;
/*      */   public static final int N_VOP = 4;
/*      */   private static final int REVERSE_EVENT_LEN = 0;
/*      */   private static final int REVERSE_EVENT_LAST = 1;
/*      */   private static final int REVERSE_EVENT_RUN = 2;
/*      */   private static final int REVERSE_EVENT_LEVEL = 3;
/*      */   private static final int VLC_TABLE_VLC_CODE = 0;
/*      */   private static final int VLC_TABLE_VLC_LEN = 1;
/*      */   private static final int VLC_TABLE_EVENT_LAST = 2;
/*      */   private static final int VLC_TABLE_EVENT_RUN = 3;
/*      */   private static final int VLC_TABLE_EVENT_LEVEL = 4;
/*      */   private static final int VLC_CODE = 0;
/*      */   private static final int VLC_LEN = 1;
/*      */   private static final int ESCAPE = 3;
/*      */   private static final int NUMBITS_VP_RESYNC_MARKER = 17;
/*      */   private static final int RESYNC_MARKER = 1;
/*      */   private static final int VIDOBJLAY_SHAPE_RECTANGULAR = 0;
/*      */   private static final int VIDOBJLAY_SHAPE_BINARY_ONLY = 2;
/*      */   private static final int SPRITE_STATIC = 1;
/*      */   private static final int SPRITE_GMC = 2;
/*   70 */   private static final int[] DQUANT_TABLE = new int[] { -1, -2, 1, 2 };
/*      */   
/*   72 */   private static final byte[][][] vlcTab = new byte[2][4096][4];
/*      */   
/*      */   static {
/*   75 */     initVLCTables();
/*      */   }
/*      */   private static final void initVLCTables() {
/*      */     int intra;
/*   79 */     for (intra = 0; intra < 2; intra++) {
/*   80 */       for (int i = 0; i < 4096; i++)
/*   81 */         vlcTab[intra][i][3] = 0; 
/*      */     } 
/*   83 */     for (intra = 0; intra < 2; intra++) {
/*   84 */       for (int i = 0; i < 102; i++) {
/*   85 */         int len = MPEG4Consts.COEFF_TAB[intra][i][1];
/*   86 */         int last = MPEG4Consts.COEFF_TAB[intra][i][2];
/*   87 */         int run = MPEG4Consts.COEFF_TAB[intra][i][3];
/*   88 */         int level = MPEG4Consts.COEFF_TAB[intra][i][4];
/*   89 */         int code = MPEG4Consts.COEFF_TAB[intra][i][0];
/*   90 */         int lowBits = 12 - len;
/*      */         
/*   92 */         for (int j = 0; j < 1 << lowBits; j++) {
/*   93 */           int entry = code << lowBits | j;
/*   94 */           vlcTab[intra][entry][0] = (byte)len;
/*   95 */           vlcTab[intra][entry][1] = (byte)last;
/*   96 */           vlcTab[intra][entry][2] = (byte)run;
/*   97 */           vlcTab[intra][entry][3] = (byte)level;
/*      */         } 
/*      */       } 
/*      */     } 
/*      */   }
/*      */   
/*      */   static void readMatrix(BitReader br, short[] matrix) {
/*  104 */     int last, value = 0;
/*  105 */     int i = 0;
/*      */     
/*      */     do {
/*  108 */       last = value;
/*  109 */       value = br.readNBit(8);
/*  110 */       matrix[MPEG4Consts.SCAN_TABLES[0][i++]] = (short)value;
/*  111 */     } while (value != 0 && i < 64);
/*      */     
/*  113 */     i--;
/*      */     
/*  115 */     while (i < 64) {
/*  116 */       matrix[MPEG4Consts.SCAN_TABLES[0][i++]] = (short)last;
/*      */     }
/*      */   }
/*      */   
/*      */   static int readMcbpcIntra(BitReader br) {
/*  121 */     int index = br.checkNBit(9);
/*  122 */     index >>= 3;
/*  123 */     br.skip(MPEG4Consts.MCBPC_INTRA_TABLE[index][1]);
/*      */     
/*  125 */     return MPEG4Consts.MCBPC_INTRA_TABLE[index][0];
/*      */   }
/*      */   
/*      */   static int readMcbpcInter(BitReader br) {
/*  129 */     int index = Math.min(br.checkNBit(9), 256);
/*  130 */     br.skip(MPEG4Consts.MCBPC_INTER_TABLE[index][1]);
/*      */     
/*  132 */     return MPEG4Consts.MCBPC_INTER_TABLE[index][0];
/*      */   }
/*      */   
/*      */   static int readCbpy(BitReader br, boolean intra) {
/*  136 */     int index = br.checkNBit(6);
/*      */     
/*  138 */     br.skip(MPEG4Consts.CBPY_TABLE[index][1]);
/*  139 */     int cbpy = MPEG4Consts.CBPY_TABLE[index][0];
/*      */     
/*  141 */     if (!intra) {
/*  142 */       cbpy = 15 - cbpy;
/*      */     }
/*  144 */     return cbpy;
/*      */   }
/*      */   static void readIntraBlock(BitReader br, short[] block, int direction, int coeff) {
/*      */     int c;
/*  148 */     short[] scan = MPEG4Consts.SCAN_TABLES[direction];
/*      */     
/*      */     do {
/*  151 */       c = readCoeffs(br, true, false);
/*  152 */       int level = level(c);
/*  153 */       coeff += run(c);
/*  154 */       if ((coeff & 0xFFFFFFC0) != 0) {
/*  155 */         Logger.error("invalid run or index");
/*      */         
/*      */         break;
/*      */       } 
/*  159 */       block[scan[coeff]] = (short)level;
/*      */       
/*  161 */       if (level < -2047 || level > 2047) {
/*  162 */         Logger.error("intra_overflow: " + level);
/*      */       }
/*      */       
/*  165 */       coeff++;
/*  166 */     } while (last(c) == 0);
/*      */   }
/*      */   static void readInterBlockH263(BitReader br, short[] block, int direction, int quant) {
/*      */     int coeff;
/*  170 */     short[] scan = MPEG4Consts.SCAN_TABLES[direction];
/*  171 */     int quant_m_2 = quant << 1;
/*  172 */     int quant_add = ((quant & 0x1) != 0) ? quant : (quant - 1);
/*  173 */     int p = 0;
/*      */     
/*  175 */     p = 0;
/*      */     
/*      */     do {
/*  178 */       coeff = readCoeffs(br, false, false);
/*  179 */       int level = level(coeff);
/*  180 */       p += run(coeff);
/*  181 */       if ((p & 0xFFFFFFC0) != 0) {
/*  182 */         Logger.error("invalid run or index");
/*      */         
/*      */         break;
/*      */       } 
/*  186 */       if (level < 0) {
/*  187 */         level = level * quant_m_2 - quant_add;
/*  188 */         block[scan[p]] = (short)((level >= -2048) ? level : -2048);
/*      */       } else {
/*  190 */         level = level * quant_m_2 + quant_add;
/*  191 */         block[scan[p]] = (short)((level <= 2047) ? level : 2047);
/*      */       } 
/*  193 */       p++;
/*  194 */     } while (last(coeff) == 0);
/*      */   }
/*      */   static void readInterBlockMPEG(BitReader br, short[] block, int direction, int quant, short[] matrix) {
/*      */     int coeff;
/*  198 */     short[] scan = MPEG4Consts.SCAN_TABLES[direction];
/*  199 */     int p = 0;
/*  200 */     int sum = 0;
/*      */ 
/*      */     
/*      */     do {
/*  204 */       coeff = readCoeffs(br, false, false);
/*  205 */       int level = level(coeff);
/*  206 */       p += run(coeff);
/*  207 */       if ((p & 0xFFFFFFC0) != 0) {
/*  208 */         Logger.error("invalid run or index");
/*      */         
/*      */         break;
/*      */       } 
/*  212 */       if (level < 0) {
/*  213 */         level = (2 * -level + 1) * matrix[scan[p]] * quant >> 4;
/*  214 */         block[scan[p]] = (short)((level <= 2048) ? -level : -2048);
/*      */       } else {
/*  216 */         level = (2 * level + 1) * matrix[scan[p]] * quant >> 4;
/*  217 */         block[scan[p]] = (short)((level <= 2047) ? level : 2047);
/*      */       } 
/*      */       
/*  220 */       sum ^= block[scan[p]];
/*      */       
/*  222 */       p++;
/*  223 */     } while (last(coeff) == 0);
/*      */     
/*  225 */     if ((sum & 0x1) == 0) {
/*  226 */       block[63] = (short)(block[63] ^ 0x1);
/*      */     }
/*      */   }
/*      */   
/*      */   static int packCoeff(int level, int run, int last) {
/*  231 */     return (last & 0xFF) << 24 | (run & 0xFF) << 16 | level & 0xFFFF;
/*      */   }
/*      */   
/*      */   static int last(int coeff) {
/*  235 */     return coeff >> 24;
/*      */   }
/*      */   
/*      */   static int run(int coeff) {
/*  239 */     return coeff >> 16 & 0xFF;
/*      */   }
/*      */   
/*      */   static int level(int coeff) {
/*  243 */     return (short)coeff;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   static int readCoeffs(BitReader br, boolean intra, boolean shortVideoHeader) {
/*  252 */     if (shortVideoHeader) {
/*  253 */       intra = false;
/*      */     }
/*  255 */     int intraIndex = intra ? 1 : 0;
/*      */     
/*  257 */     if (br.checkNBit(7) != 3) {
/*  258 */       byte[] reverse = vlcTab[intraIndex][br.checkNBit(12)];
/*      */       short s;
/*  260 */       if ((s = (short)reverse[3]) == 0) {
/*  261 */         int k = 64;
/*  262 */         return packCoeff(0, k, 1);
/*      */       } 
/*      */       
/*  265 */       int j = reverse[1];
/*  266 */       int i = reverse[2];
/*      */       
/*  268 */       br.skip(reverse[0]);
/*      */       
/*  270 */       return packCoeff(br.readBool() ? -s : s, i, j);
/*      */     } 
/*      */     
/*  273 */     br.skip(7);
/*      */     
/*  275 */     if (shortVideoHeader) {
/*  276 */       int j = br.readNBit(1);
/*  277 */       int i = br.readNBit(6);
/*  278 */       short s = (short)(byte)br.readNBit(8);
/*      */       
/*  280 */       if (s == 0 || s == 128) {
/*  281 */         Logger.error("Illegal LEVEL for ESCAPE mode 4: " + s);
/*      */       }
/*  283 */       return packCoeff(s, i, j);
/*      */     } 
/*      */     
/*  286 */     int mode = br.checkNBit(2);
/*      */     
/*  288 */     if (mode < 3) {
/*  289 */       br.skip((mode == 2) ? 2 : 1);
/*      */       
/*  291 */       byte[] reverse = vlcTab[intraIndex][br.checkNBit(12)];
/*      */       short s;
/*  293 */       if ((s = (short)reverse[3]) == 0) {
/*  294 */         int k = 64;
/*  295 */         return packCoeff(0, k, 1);
/*      */       } 
/*      */       
/*  298 */       int j = reverse[1];
/*  299 */       int i = reverse[2];
/*      */       
/*  301 */       br.skip(reverse[0]);
/*      */       
/*  303 */       if (mode < 2) {
/*  304 */         s = (short)(s + MPEG4Consts.MAX_LEVEL[intraIndex][j][i]);
/*      */       } else {
/*  306 */         i += MPEG4Consts.MAX_RUN[intraIndex][j][s] + 1;
/*      */       } 
/*  308 */       return packCoeff(br.readBool() ? -s : s, i, j);
/*      */     } 
/*      */     
/*  311 */     br.skip(2);
/*  312 */     int last = br.read1Bit();
/*  313 */     int run = br.readNBit(6);
/*  314 */     br.skip(1);
/*  315 */     short level = (short)(br.readNBit(12) << 20 >> 20);
/*  316 */     br.skip(1);
/*      */     
/*  318 */     return packCoeff(level, run, last);
/*      */   }
/*      */   static int readMVData(BitReader br) {
/*      */     int[] tab;
/*  322 */     if (br.readBool()) {
/*  323 */       return 0;
/*      */     }
/*      */ 
/*      */ 
/*      */     
/*  328 */     int index = br.checkNBit(12);
/*      */     
/*  330 */     if (index >= 512) {
/*  331 */       tab = MPEG4Consts.TMNMV_TAB_0[(index >> 8) - 2];
/*  332 */     } else if (index >= 128) {
/*  333 */       tab = MPEG4Consts.TMNMV_TAB_1[(index >> 2) - 32];
/*      */     } else {
/*  335 */       if (index < 4) {
/*  336 */         return 0;
/*      */       }
/*      */       
/*  339 */       tab = MPEG4Consts.TMNMV_TAB_2[index - 4];
/*      */     } 
/*      */     
/*  342 */     br.skip(tab[1]);
/*      */     
/*  344 */     return tab[0];
/*      */   }
/*      */   
/*      */   static int readMVComponent(BitReader br, int fcode) {
/*  348 */     int scaleFac = 1 << fcode - 1;
/*      */     
/*  350 */     int data = readMVData(br);
/*      */     
/*  352 */     if (scaleFac == 1 || data == 0) {
/*  353 */       return data;
/*      */     }
/*      */     
/*  356 */     int res = br.readNBit(fcode - 1);
/*      */     
/*  358 */     int mv = (Math.abs(data) - 1) * scaleFac + res + 1;
/*      */     
/*  360 */     return (data < 0) ? -mv : mv;
/*      */   }
/*      */   
/*      */   static int readMBType(BitReader br) {
/*  364 */     for (int mbType = 0; mbType <= 3; mbType++) {
/*  365 */       if (br.readBool()) {
/*  366 */         return mbType;
/*      */       }
/*      */     } 
/*      */     
/*  370 */     return -1;
/*      */   }
/*      */   
/*      */   static int readDBQuant(BitReader br) {
/*  374 */     if (!br.readBool())
/*  375 */       return 0; 
/*  376 */     if (!br.readBool()) {
/*  377 */       return -2;
/*      */     }
/*      */     
/*  380 */     return 2;
/*      */   }
/*      */   
/*      */   static int readDCSizeLum(BitReader br) {
/*  384 */     int code = br.checkNBit(11);
/*      */     
/*  386 */     for (int i = 11; i > 3; i--) {
/*  387 */       if (code == 1) {
/*  388 */         br.skip(i);
/*  389 */         return i + 1;
/*      */       } 
/*  391 */       code >>= 1;
/*      */     } 
/*      */     
/*  394 */     br.skip(MPEG4Consts.DC_LUM_TAB[code][1]);
/*      */     
/*  396 */     return MPEG4Consts.DC_LUM_TAB[code][0];
/*      */   }
/*      */   
/*      */   static int readDCSizeChrom(BitReader br) {
/*  400 */     int code = br.checkNBit(12);
/*      */     
/*  402 */     for (int i = 12; i > 2; i--) {
/*  403 */       if (code == 1) {
/*  404 */         br.skip(i);
/*  405 */         return i;
/*      */       } 
/*  407 */       code >>= 1;
/*      */     } 
/*      */     
/*  410 */     return 3 - br.readNBit(2);
/*      */   }
/*      */   
/*      */   static short readDCDif(BitReader br, int dcSize) {
/*  414 */     int code = br.readNBit(dcSize);
/*  415 */     int msb = code >> dcSize - 1;
/*      */     
/*  417 */     if (msb == 0) {
/*  418 */       return (short)(-1 * (code ^ (1 << dcSize) - 1));
/*      */     }
/*  420 */     return (short)code;
/*      */   }
/*      */ 
/*      */   
/*      */   static int readVideoPacketHeader(BitReader br, MPEG4DecodingContext ctx, int addBits, boolean fcodeForwardEnabled, boolean fcodeBackwardEnabled, boolean intraDCThresholdEnabled) {
/*  425 */     int startcodeBits = 17 + addBits;
/*  426 */     int mbNumBits = MathUtil.log2(ctx.mbWidth * ctx.mbHeight - 1) + 1;
/*      */     
/*  428 */     boolean hec = false;
/*      */     
/*  430 */     br.align();
/*  431 */     br.skip(startcodeBits);
/*      */     
/*  433 */     if (ctx.shape != 0) {
/*  434 */       hec = br.readBool();
/*  435 */       if (hec && ctx.spriteEnable != 1) {
/*  436 */         br.skip(13);
/*  437 */         br.skip(1);
/*  438 */         br.skip(13);
/*  439 */         br.skip(1);
/*  440 */         br.skip(13);
/*  441 */         br.skip(1);
/*  442 */         br.skip(13);
/*  443 */         br.skip(1);
/*      */       } 
/*      */     } 
/*      */     
/*  447 */     int mbnum = br.readNBit(mbNumBits);
/*      */     
/*  449 */     if (ctx.shape != 2) {
/*  450 */       ctx.quant = br.readNBit(ctx.quantBits);
/*      */     }
/*      */     
/*  453 */     if (ctx.shape == 0) {
/*  454 */       hec = br.readBool();
/*      */     }
/*  456 */     if (hec) {
/*      */       
/*  458 */       int timeIncrement = 0;
/*      */ 
/*      */       
/*  461 */       for (int timeBase = 0; br.readBool(); timeBase++);
/*      */       
/*  463 */       br.skip(1);
/*  464 */       if (ctx.timeIncrementBits != 0)
/*  465 */         timeIncrement = br.readNBit(ctx.timeIncrementBits); 
/*  466 */       br.skip(1);
/*      */       
/*  468 */       int codingType = br.readNBit(2);
/*      */       
/*  470 */       if (ctx.shape != 0) {
/*  471 */         br.skip(1);
/*  472 */         if (codingType != 0) {
/*  473 */           br.skip(1);
/*      */         }
/*      */       } 
/*  476 */       if (ctx.shape != 2) {
/*  477 */         if (intraDCThresholdEnabled) {
/*  478 */           ctx.intraDCThreshold = MPEG4Consts.INTRA_DC_THRESHOLD_TABLE[br.readNBit(3)];
/*      */         }
/*      */         
/*  481 */         if (ctx.spriteEnable != 2 || codingType != 3 || ctx.spriteWarpingPoints > 0);
/*      */         
/*  483 */         if (ctx.reducedResolutionEnable && ctx.shape == 0 && (codingType == 1 || codingType == 0))
/*      */         {
/*  485 */           br.skip(1);
/*      */         }
/*      */         
/*  488 */         if (codingType != 0 && fcodeForwardEnabled) {
/*  489 */           ctx.fcodeForward = br.readNBit(3);
/*      */         }
/*      */         
/*  492 */         if (codingType == 2 && fcodeBackwardEnabled) {
/*  493 */           ctx.fcodeBackward = br.readNBit(3);
/*      */         }
/*      */       } 
/*      */     } 
/*      */     
/*  498 */     if (ctx.newPredEnable) {
/*      */ 
/*      */ 
/*      */       
/*  502 */       int vopId = br.readNBit(Math.min(ctx.timeIncrementBits + 3, 15));
/*  503 */       if (br.readBool()) {
/*  504 */         int i = br.readNBit(Math.min(ctx.timeIncrementBits + 3, 15));
/*      */       }
/*  506 */       br.skip(1);
/*      */     } 
/*      */     
/*  509 */     return mbnum;
/*      */   }
/*      */   
/*      */   static boolean checkResyncMarker(BitReader br, int addBits) {
/*  513 */     int nbits = br.bitsToAlign();
/*  514 */     int nbitResyncMarker = 17 + addBits;
/*  515 */     int code = br.checkNBitDontCare(nbitResyncMarker + nbits);
/*      */     
/*  517 */     int MASK1 = (1 << nbits - 1) - 1;
/*  518 */     int MASK2 = (1 << nbitResyncMarker) - 1;
/*      */     
/*  520 */     if (code >> nbitResyncMarker == MASK1) {
/*  521 */       return ((code & MASK2) == 1);
/*      */     }
/*      */     
/*  524 */     return false;
/*      */   }
/*      */   
/*      */   static void readIntraMode(BitReader br, MPEG4DecodingContext ctx, Macroblock mb) {
/*  528 */     while (br.checkNBit(9) == 1) {
/*  529 */       br.skip(9);
/*      */     }
/*  531 */     if (checkResyncMarker(br, 0)) {
/*  532 */       mb.bound = readVideoPacketHeader(br, ctx, 0, false, false, true);
/*      */       
/*  534 */       mb.x = mb.bound % ctx.mbWidth;
/*  535 */       mb.y = mb.bound / ctx.mbWidth;
/*      */     } 
/*      */     
/*  538 */     int mcbpc = readMcbpcIntra(br);
/*  539 */     mb.mode = mcbpc & 0x7;
/*  540 */     int cbpc = mcbpc >>> 4;
/*      */     
/*  542 */     mb.acpredFlag = br.readBool();
/*      */     
/*  544 */     int cbpy = readCbpy(br, true);
/*  545 */     mb.cbp = cbpy << 2 | cbpc;
/*      */     
/*  547 */     if (mb.mode == 4) {
/*  548 */       ctx.quant += DQUANT_TABLE[br.readNBit(2)];
/*  549 */       if (ctx.quant > 31) {
/*  550 */         ctx.quant = 31;
/*  551 */       } else if (ctx.quant < 1) {
/*  552 */         ctx.quant = 1;
/*      */       } 
/*      */     } 
/*      */     
/*  556 */     mb.quant = ctx.quant;
/*  557 */     (mb.mvs[0]).x = (mb.mvs[0]).y = (mb.mvs[1]).x = (mb.mvs[1]).y = (mb.mvs[2]).x = (mb.mvs[2]).y = (mb.mvs[3]).x = (mb.mvs[3]).y = 0;
/*      */     
/*  559 */     if (ctx.interlacing) {
/*  560 */       mb.fieldDCT = br.readBool();
/*      */     }
/*      */   }
/*      */ 
/*      */   
/*      */   static void readCoeffIntra(BitReader br, MPEG4DecodingContext ctx, Macroblock mb, Macroblock aboveMb, Macroblock leftMb, Macroblock aboveLeftMb) {
/*  566 */     for (int i = 0; i < 6; i++) {
/*  567 */       int startCoeff; Arrays.fill(mb.block[i], (short)0);
/*  568 */       int iDcScaler = getDCScaler(mb.quant, (i < 4));
/*      */ 
/*      */       
/*  571 */       predictAcdc(ctx, mb.x, mb.y, i, mb.quant, iDcScaler, mb.predictors, mb.bound, mb, aboveMb, leftMb, aboveLeftMb);
/*      */ 
/*      */       
/*  574 */       if (!mb.acpredFlag) {
/*  575 */         mb.acpredDirections[i] = 0;
/*      */       }
/*      */       
/*  578 */       if (mb.quant < ctx.intraDCThreshold) {
/*  579 */         int dcSize = (i < 4) ? readDCSizeLum(br) : readDCSizeChrom(br);
/*  580 */         short dcDif = (dcSize != 0) ? readDCDif(br, dcSize) : 0;
/*      */         
/*  582 */         if (dcSize > 8) {
/*  583 */           br.skip(1);
/*      */         }
/*      */         
/*  586 */         mb.block[i][0] = dcDif;
/*  587 */         startCoeff = 1;
/*      */       } else {
/*  589 */         startCoeff = 0;
/*      */       } 
/*      */       
/*  592 */       if ((mb.cbp & 1 << 5 - i) != 0) {
/*  593 */         int direction = ctx.alternateVerticalScan ? 2 : mb.acpredDirections[i];
/*      */         
/*  595 */         readIntraBlock(br, mb.block[i], direction, startCoeff);
/*      */       } 
/*      */       
/*  598 */       addAcdc(mb, ctx.bsVersion, i, iDcScaler);
/*      */       
/*  600 */       if (!ctx.quantType) {
/*  601 */         dequantH263Intra(ctx, mb.block[i], mb.quant, iDcScaler);
/*      */       } else {
/*  603 */         dequantMpegIntra(ctx, mb.block[i], mb.quant, iDcScaler);
/*      */       } 
/*      */     } 
/*      */   }
/*      */   
/*      */   static void addAcdc(Macroblock mb, int bsVersion, int block, int iDcScaler) {
/*  609 */     short[] coeffs = mb.block[block];
/*  610 */     byte acpredDirection = (byte)mb.acpredDirections[block];
/*  611 */     short[] current = mb.predValues[block];
/*      */     
/*  613 */     coeffs[0] = (short)(coeffs[0] + mb.predictors[0]);
/*  614 */     current[0] = (short)(coeffs[0] * iDcScaler);
/*      */     
/*  616 */     if (bsVersion == 0 || bsVersion > 34) {
/*  617 */       current[0] = (current[0] < -2048) ? -2048 : ((current[0] > 2047) ? 2047 : current[0]);
/*      */     }
/*      */     
/*  620 */     if (acpredDirection == 1) {
/*  621 */       for (int i = 1; i < 8; i++) {
/*  622 */         short level = (short)(coeffs[i] + mb.predictors[i]);
/*      */         
/*  624 */         coeffs[i] = level;
/*  625 */         current[i] = level;
/*  626 */         current[i + 7] = coeffs[i * 8];
/*      */       } 
/*  628 */     } else if (acpredDirection == 2) {
/*  629 */       for (int i = 1; i < 8; i++) {
/*  630 */         short level = (short)(coeffs[i * 8] + mb.predictors[i]);
/*      */         
/*  632 */         coeffs[i * 8] = level;
/*  633 */         current[i + 7] = level;
/*  634 */         current[i] = coeffs[i];
/*      */       } 
/*      */     } else {
/*  637 */       for (int i = 1; i < 8; i++) {
/*  638 */         current[i] = coeffs[i];
/*  639 */         current[i + 7] = coeffs[i * 8];
/*      */       } 
/*      */     } 
/*      */   }
/*      */ 
/*      */   
/*      */   static void readInterModeCoeffs(BitReader br, MPEG4DecodingContext ctx, int fcode, Macroblock mb, Macroblock aboveMb, Macroblock leftMb, Macroblock aboveLeftMb, Macroblock aboveRightMb) {
/*  646 */     if (!br.readBool()) {
/*  647 */       mb.coded = true;
/*      */       
/*  649 */       boolean intra = false;
/*  650 */       boolean mcsel = false;
/*      */       
/*  652 */       int mcbpc = readMcbpcInter(br);
/*  653 */       mb.mode = mcbpc & 0x7;
/*  654 */       int cbpc = mcbpc >>> 4;
/*      */       
/*  656 */       intra = (mb.mode == 3 || mb.mode == 4);
/*      */       
/*  658 */       if (intra) {
/*  659 */         mb.acpredFlag = br.readBool();
/*      */       }
/*  661 */       mb.mcsel = mcsel;
/*      */       
/*  663 */       int cbpy = readCbpy(br, intra);
/*      */       
/*  665 */       mb.cbp = cbpy << 2 | cbpc;
/*      */       
/*  667 */       if (mb.mode == 1 || mb.mode == 4) {
/*  668 */         int dquant = DQUANT_TABLE[br.readNBit(2)];
/*  669 */         ctx.quant += dquant;
/*  670 */         if (ctx.quant > 31) {
/*  671 */           ctx.quant = 31;
/*  672 */         } else if (ctx.quant < 1) {
/*  673 */           ctx.quant = 1;
/*      */         } 
/*      */       } 
/*  676 */       mb.quant = ctx.quant;
/*      */       
/*  678 */       if (ctx.interlacing) {
/*  679 */         if (mb.cbp != 0 || intra) {
/*  680 */           mb.fieldDCT = br.readBool();
/*      */         }
/*      */         
/*  683 */         if ((mb.mode == 0 || mb.mode == 1) && !mcsel) {
/*  684 */           mb.fieldPred = br.readBool();
/*      */           
/*  686 */           if (mb.fieldPred) {
/*  687 */             mb.fieldForTop = br.readBool();
/*  688 */             mb.fieldForBottom = br.readBool();
/*      */           } 
/*      */         } 
/*      */       } 
/*      */       
/*  693 */       if (mcsel) {
/*  694 */         readInterCoeffs(br, ctx, mb);
/*  695 */       } else if (mb.mode == 0 || mb.mode == 1 || mb.mode == 2) {
/*  696 */         if (mb.mode == 0 || mb.mode == 1) {
/*  697 */           if (ctx.interlacing && mb.fieldPred) {
/*  698 */             readMVInterlaced(br, ctx, mb.x, mb.y, 0, mb, fcode, mb.bound, mb, aboveMb, leftMb, aboveRightMb);
/*      */           } else {
/*      */             
/*  701 */             readMV(br, ctx, mb.x, mb.y, 0, mb.mvs[0], fcode, mb.bound, mb, aboveMb, leftMb, aboveRightMb);
/*  702 */             (mb.mvs[3]).x = (mb.mvs[0]).x;
/*  703 */             (mb.mvs[3]).y = (mb.mvs[0]).y;
/*      */           } 
/*  705 */         } else if (mb.mode == 2) {
/*  706 */           readMV(br, ctx, mb.x, mb.y, 0, mb.mvs[0], fcode, mb.bound, mb, aboveMb, leftMb, aboveRightMb);
/*  707 */           readMV(br, ctx, mb.x, mb.y, 1, mb.mvs[1], fcode, mb.bound, mb, aboveMb, leftMb, aboveRightMb);
/*  708 */           readMV(br, ctx, mb.x, mb.y, 2, mb.mvs[2], fcode, mb.bound, mb, aboveMb, leftMb, aboveRightMb);
/*  709 */           readMV(br, ctx, mb.x, mb.y, 3, mb.mvs[3], fcode, mb.bound, mb, aboveMb, leftMb, aboveRightMb);
/*      */         } 
/*  711 */         if (!mb.fieldPred) {
/*  712 */           readInterCoeffs(br, ctx, mb);
/*      */         } else {
/*  714 */           readInterCoeffs(br, ctx, mb);
/*      */         } 
/*      */       } else {
/*  717 */         (mb.mvs[3]).x = 0;
/*  718 */         (mb.mvs[3]).y = 0;
/*  719 */         readCoeffIntra(br, ctx, mb, aboveMb, leftMb, aboveLeftMb);
/*      */       } 
/*      */     } else {
/*  722 */       mb.mode = 16;
/*  723 */       mb.quant = ctx.quant;
/*      */       
/*  725 */       (mb.mvs[3]).x = 0;
/*  726 */       (mb.mvs[3]).y = 0;
/*  727 */       mb.cbp = 0;
/*      */       
/*  729 */       readInterCoeffs(br, ctx, mb);
/*      */     } 
/*      */   }
/*      */   
/*      */   private static void dequantH263Intra(MPEG4DecodingContext ctx, short[] block, int quant, int dcscalar) {
/*  734 */     int quantM2 = quant << 1;
/*  735 */     int quantAdd = ((quant & 0x1) != 0) ? quant : (quant - 1);
/*      */     
/*  737 */     block[0] = (short)MathUtil.clip(block[0] * dcscalar, -2048, 2047);
/*      */     
/*  739 */     for (int i = 1; i < 64; i++) {
/*  740 */       int acLevel = block[i];
/*      */       
/*  742 */       if (acLevel == 0) {
/*  743 */         block[i] = 0;
/*  744 */       } else if (acLevel < 0) {
/*  745 */         acLevel = quantM2 * -acLevel + quantAdd;
/*  746 */         block[i] = (short)((acLevel <= 2048) ? -acLevel : -2048);
/*      */       } else {
/*  748 */         acLevel = quantM2 * acLevel + quantAdd;
/*  749 */         block[i] = (short)((acLevel <= 2047) ? acLevel : 2047);
/*      */       } 
/*      */     } 
/*      */   }
/*      */   
/*      */   private static void dequantMpegIntra(MPEG4DecodingContext ctx, short[] block, int quant, int dcscalar) {
/*  755 */     block[0] = (short)MathUtil.clip(block[0] * dcscalar, -2048, 2047);
/*      */     
/*  757 */     for (int i = 1; i < 64; i++) {
/*  758 */       if (block[i] == 0) {
/*  759 */         block[i] = 0;
/*  760 */       } else if (block[i] < 0) {
/*  761 */         int level = -block[i] * ctx.intraMpegQuantMatrix[i] * quant >> 3;
/*      */         
/*  763 */         block[i] = (short)((level <= 2048) ? -((short)level) : -2048);
/*      */       } else {
/*  765 */         int level = block[i] * ctx.intraMpegQuantMatrix[i] * quant >> 3;
/*      */         
/*  767 */         block[i] = (short)((level <= 2047) ? level : 2047);
/*      */       } 
/*      */     } 
/*      */   }
/*      */ 
/*      */   
/*      */   private static void readMV(BitReader br, MPEG4DecodingContext ctx, int x, int y, int k, Macroblock.Vector retMV, int fcode, int bound, Macroblock mb, Macroblock aboveMb, Macroblock leftMb, Macroblock aboveRightMb) {
/*  774 */     int scaleFac = 1 << fcode - 1;
/*  775 */     int high = 32 * scaleFac - 1;
/*  776 */     int low = -32 * scaleFac;
/*  777 */     int range = 64 * scaleFac;
/*      */     
/*  779 */     Macroblock.Vector pmv = getPMV2(ctx, bound, x, y, k, mb, aboveMb, leftMb, aboveRightMb);
/*  780 */     Macroblock.Vector mv = Macroblock.vec();
/*      */     
/*  782 */     mv.x = readMVComponent(br, fcode);
/*  783 */     mv.y = readMVComponent(br, fcode);
/*      */     
/*  785 */     mv.x += pmv.x;
/*  786 */     mv.y += pmv.y;
/*      */     
/*  788 */     if (mv.x < low) {
/*  789 */       mv.x += range;
/*  790 */     } else if (mv.x > high) {
/*  791 */       mv.x -= range;
/*      */     } 
/*      */     
/*  794 */     if (mv.y < low) {
/*  795 */       mv.y += range;
/*  796 */     } else if (mv.y > high) {
/*  797 */       mv.y -= range;
/*      */     } 
/*      */     
/*  800 */     retMV.x = mv.x;
/*  801 */     retMV.y = mv.y;
/*      */   }
/*      */ 
/*      */   
/*      */   private static void readMVInterlaced(BitReader br, MPEG4DecodingContext ctx, int x, int y, int k, Macroblock pMB, int fcode, int bound, Macroblock mb, Macroblock aboveMb, Macroblock leftMb, Macroblock aboveRightMb) {
/*  806 */     int scaleFac = 1 << fcode - 1;
/*  807 */     int high = 32 * scaleFac - 1;
/*  808 */     int low = -32 * scaleFac;
/*  809 */     int range = 64 * scaleFac;
/*      */     
/*  811 */     Macroblock.Vector pmv = getPMV2Interlaced(ctx, bound, mb, aboveMb, leftMb, aboveRightMb);
/*  812 */     Macroblock.Vector mv = Macroblock.vec();
/*  813 */     Macroblock.Vector mvf1 = Macroblock.vec();
/*  814 */     Macroblock.Vector mvf2 = Macroblock.vec();
/*      */     
/*  816 */     if (!pMB.fieldPred) {
/*  817 */       mv.x = readMVComponent(br, fcode);
/*  818 */       mv.y = readMVComponent(br, fcode);
/*      */       
/*  820 */       mv.x += pmv.x;
/*  821 */       mv.y += pmv.y;
/*      */       
/*  823 */       if (mv.x < low) {
/*  824 */         mv.x += range;
/*  825 */       } else if (mv.x > high) {
/*  826 */         mv.x -= range;
/*      */       } 
/*      */       
/*  829 */       if (mv.y < low) {
/*  830 */         mv.y += range;
/*  831 */       } else if (mv.y > high) {
/*  832 */         mv.y -= range;
/*      */       } 
/*      */       
/*  835 */       pMB.mvs[3] = mv; pMB.mvs[2] = mv; pMB.mvs[1] = mv; pMB.mvs[0] = mv;
/*      */     } else {
/*  837 */       mvf1.x = readMVComponent(br, fcode);
/*  838 */       mvf1.y = readMVComponent(br, fcode);
/*      */       
/*  840 */       mvf1.x += pmv.x;
/*  841 */       mvf1.y = 2 * (mvf1.y + pmv.y / 2);
/*      */       
/*  843 */       if (mvf1.x < low) {
/*  844 */         mvf1.x += range;
/*  845 */       } else if (mvf1.x > high) {
/*  846 */         mvf1.x -= range;
/*      */       } 
/*      */       
/*  849 */       if (mvf1.y < low) {
/*  850 */         mvf1.y += range;
/*  851 */       } else if (mvf1.y > high) {
/*  852 */         mvf1.y -= range;
/*      */       } 
/*      */       
/*  855 */       mvf2.x = readMVComponent(br, fcode);
/*  856 */       mvf2.y = readMVComponent(br, fcode);
/*      */       
/*  858 */       mvf2.x += pmv.x;
/*  859 */       mvf2.y = 2 * (mvf2.y + pmv.y / 2);
/*      */       
/*  861 */       if (mvf2.x < low) {
/*  862 */         mvf2.x += range;
/*  863 */       } else if (mvf2.x > high) {
/*  864 */         mvf2.x -= range;
/*      */       } 
/*      */       
/*  867 */       if (mvf2.y < low) {
/*  868 */         mvf2.y += range;
/*  869 */       } else if (mvf2.y > high) {
/*  870 */         mvf2.y -= range;
/*      */       } 
/*      */       
/*  873 */       pMB.mvs[0] = mvf1;
/*  874 */       pMB.mvs[1] = mvf2;
/*  875 */       (pMB.mvs[3]).x = 0;
/*  876 */       (pMB.mvs[3]).y = 0;
/*      */       
/*  878 */       int n = (pMB.mvs[0]).x + (pMB.mvs[1]).x;
/*  879 */       pMB.mvsAvg.x = n >> 1 | n & 0x1;
/*  880 */       n = (pMB.mvs[0]).y + (pMB.mvs[1]).y;
/*  881 */       pMB.mvsAvg.y = n >> 1 | n & 0x1;
/*      */     } 
/*      */   }
/*      */ 
/*      */   
/*      */   private static Macroblock.Vector getPMV2Interlaced(MPEG4DecodingContext ctx, int bound, Macroblock mb, Macroblock aboveMb, Macroblock leftMb, Macroblock aboveRightMb) {
/*  887 */     int num_cand = 0, last_cand = 1;
/*      */     
/*  889 */     Macroblock.Vector[] pmv = new Macroblock.Vector[4];
/*  890 */     for (int i = 0; i < 4; i++) {
/*  891 */       pmv[i] = Macroblock.vec();
/*      */     }
/*      */     
/*  894 */     int lz = 1;
/*  895 */     int tz = 2;
/*  896 */     int rz = 2;
/*      */     
/*  898 */     if (leftMb != null) {
/*  899 */       num_cand++;
/*      */       
/*  901 */       if (leftMb.fieldPred) {
/*  902 */         pmv[1] = leftMb.mvsAvg;
/*      */       } else {
/*  904 */         pmv[1] = leftMb.mvs[lz];
/*      */       } 
/*      */     } else {
/*  907 */       pmv[1] = MPEG4Consts.ZERO_MV;
/*      */     } 
/*      */     
/*  910 */     if (aboveMb != null) {
/*  911 */       num_cand++;
/*  912 */       last_cand = 2;
/*  913 */       if (aboveMb.fieldPred) {
/*  914 */         pmv[2] = aboveMb.mvsAvg;
/*      */       } else {
/*  916 */         pmv[2] = aboveMb.mvs[tz];
/*      */       } 
/*      */     } else {
/*  919 */       pmv[2] = MPEG4Consts.ZERO_MV;
/*      */     } 
/*      */     
/*  922 */     if (aboveRightMb != null) {
/*  923 */       num_cand++;
/*  924 */       last_cand = 3;
/*  925 */       if (aboveRightMb.fieldPred) {
/*  926 */         pmv[3] = aboveRightMb.mvsAvg;
/*      */       } else {
/*  928 */         pmv[3] = aboveRightMb.mvs[rz];
/*      */       } 
/*      */     } else {
/*  931 */       pmv[3] = MPEG4Consts.ZERO_MV;
/*      */     } 
/*      */     
/*  934 */     if (num_cand > 1) {
/*  935 */       (pmv[0]).x = Math.min(Math.max((pmv[1]).x, (pmv[2]).x), Math.min(Math.max((pmv[2]).x, (pmv[3]).x), Math.max((pmv[1]).x, (pmv[3]).x)));
/*  936 */       (pmv[0]).y = Math.min(Math.max((pmv[1]).y, (pmv[2]).y), Math.min(Math.max((pmv[2]).y, (pmv[3]).y), Math.max((pmv[1]).y, (pmv[3]).y)));
/*  937 */       return pmv[0];
/*      */     } 
/*      */     
/*  940 */     return pmv[last_cand];
/*      */   }
/*      */   
/*      */   private static int getDCScaler(int quant, boolean lum) {
/*  944 */     if (quant < 5) {
/*  945 */       return 8;
/*      */     }
/*  947 */     if (quant < 25 && !lum) {
/*  948 */       return (quant + 13) / 2;
/*      */     }
/*  950 */     if (quant < 9) {
/*  951 */       return 2 * quant;
/*      */     }
/*  953 */     if (quant < 25) {
/*  954 */       return quant + 8;
/*      */     }
/*  956 */     if (lum) {
/*  957 */       return 2 * quant - 16;
/*      */     }
/*  959 */     return quant - 6;
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   private static void predictAcdc(MPEG4DecodingContext ctx, int x, int y, int block, int currentQuant, int iDcScaler, short[] predictors, int bound, Macroblock mb, Macroblock aboveMb, Macroblock leftMb, Macroblock aboveLeftMb) {
/*  965 */     int mbpos = y * ctx.mbWidth + x;
/*  966 */     short[] leftPred = null, topPred = null, diag = null, current = null;
/*      */     
/*  968 */     int leftQuant = currentQuant;
/*  969 */     int topQuant = currentQuant;
/*      */     
/*  971 */     short[] pLeft = MPEG4Consts.DEFAULT_ACDC_VALUES;
/*  972 */     short[] pTop = MPEG4Consts.DEFAULT_ACDC_VALUES;
/*  973 */     short[] pDiag = MPEG4Consts.DEFAULT_ACDC_VALUES;
/*      */     
/*  975 */     if (x != 0 && mbpos >= bound + 1 && (leftMb.mode == 3 || leftMb.mode == 4)) {
/*  976 */       leftPred = leftMb.predValues[0];
/*  977 */       leftQuant = leftMb.quant;
/*      */     } 
/*      */     
/*  980 */     if (mbpos >= bound + ctx.mbWidth && (aboveMb.mode == 3 || aboveMb.mode == 4)) {
/*  981 */       topPred = aboveMb.predValues[0];
/*  982 */       topQuant = aboveMb.quant;
/*      */     } 
/*      */     
/*  985 */     if (x != 0 && mbpos >= bound + ctx.mbWidth + 1 && (aboveLeftMb.mode == 3 || aboveLeftMb.mode == 4))
/*      */     {
/*  987 */       diag = aboveLeftMb.predValues[0];
/*      */     }
/*      */     
/*  990 */     current = mb.predValues[0];
/*      */     
/*  992 */     switch (block) {
/*      */       case 0:
/*  994 */         if (leftPred != null) {
/*  995 */           pLeft = leftMb.predValues[1];
/*      */         }
/*  997 */         if (topPred != null) {
/*  998 */           pTop = aboveMb.predValues[2];
/*      */         }
/* 1000 */         if (diag != null) {
/* 1001 */           pDiag = aboveLeftMb.predValues[3];
/*      */         }
/*      */         break;
/*      */       
/*      */       case 1:
/* 1006 */         pLeft = current;
/* 1007 */         leftQuant = currentQuant;
/*      */         
/* 1009 */         if (topPred != null) {
/* 1010 */           pTop = aboveMb.predValues[3];
/* 1011 */           pDiag = aboveMb.predValues[2];
/*      */         } 
/*      */         break;
/*      */       
/*      */       case 2:
/* 1016 */         if (leftPred != null) {
/* 1017 */           pLeft = leftMb.predValues[3];
/* 1018 */           pDiag = leftMb.predValues[1];
/*      */         } 
/*      */         
/* 1021 */         pTop = current;
/* 1022 */         topQuant = currentQuant;
/*      */         break;
/*      */ 
/*      */       
/*      */       case 3:
/* 1027 */         pLeft = mb.predValues[2];
/* 1028 */         leftQuant = currentQuant;
/*      */         
/* 1030 */         pTop = mb.predValues[1];
/* 1031 */         topQuant = currentQuant;
/*      */         
/* 1033 */         pDiag = current;
/*      */         break;
/*      */ 
/*      */       
/*      */       case 4:
/* 1038 */         if (leftPred != null) {
/* 1039 */           pLeft = leftMb.predValues[4];
/*      */         }
/* 1041 */         if (topPred != null) {
/* 1042 */           pTop = aboveMb.predValues[4];
/*      */         }
/* 1044 */         if (diag != null) {
/* 1045 */           pDiag = aboveLeftMb.predValues[4];
/*      */         }
/*      */         break;
/*      */       
/*      */       case 5:
/* 1050 */         if (leftPred != null) {
/* 1051 */           pLeft = leftMb.predValues[5];
/*      */         }
/* 1053 */         if (topPred != null) {
/* 1054 */           pTop = aboveMb.predValues[5];
/*      */         }
/* 1056 */         if (diag != null) {
/* 1057 */           pDiag = aboveLeftMb.predValues[5];
/*      */         }
/*      */         break;
/*      */     } 
/*      */     
/* 1062 */     if (MathUtil.abs(pLeft[0] - pDiag[0]) < MathUtil.abs(pDiag[0] - pTop[0])) {
/* 1063 */       mb.acpredDirections[block] = 1;
/* 1064 */       predictors[0] = (short)((pTop[0] > 0) ? ((pTop[0] + (iDcScaler >>> 1)) / iDcScaler) : ((pTop[0] - (iDcScaler >>> 1)) / iDcScaler));
/*      */       
/* 1066 */       for (int i = 1; i < 8; i++) {
/* 1067 */         int a = pTop[i] * topQuant;
/* 1068 */         predictors[i] = (pTop[i] != 0) ? (short)((a > 0) ? ((a + (currentQuant >>> 1)) / currentQuant) : ((a - (currentQuant >>> 1)) / currentQuant)) : 0;
/*      */       }
/*      */     
/*      */     }
/*      */     else {
/*      */       
/* 1074 */       mb.acpredDirections[block] = 2;
/* 1075 */       predictors[0] = (short)((pLeft[0] > 0) ? ((pLeft[0] + (iDcScaler >>> 1)) / iDcScaler) : ((pLeft[0] - (iDcScaler >>> 1)) / iDcScaler));
/*      */       
/* 1077 */       for (int i = 1; i < 8; i++) {
/* 1078 */         int a = pLeft[i + 7] * leftQuant;
/* 1079 */         predictors[i] = (pLeft[i + 7] != 0) ? (short)((a > 0) ? ((a + (currentQuant >>> 1)) / currentQuant) : ((a - (currentQuant >>> 1)) / currentQuant)) : 0;
/*      */       } 
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private static Macroblock.Vector getPMV2(MPEG4DecodingContext ctx, int bound, int x, int y, int block, Macroblock mb, Macroblock aboveMb, Macroblock leftMb, Macroblock aboveRightMb) {
/* 1089 */     int lz, tz, rz, num_cand = 0, last_cand = 1;
/*      */     
/* 1091 */     Macroblock.Vector[] pmv = new Macroblock.Vector[4];
/* 1092 */     for (int i = 0; i < 4; i++) {
/* 1093 */       pmv[i] = Macroblock.vec();
/*      */     }
/*      */     
/* 1096 */     switch (block) {
/*      */       case 0:
/* 1098 */         lz = 1;
/* 1099 */         tz = 2;
/* 1100 */         rz = 2;
/*      */         break;
/*      */       case 1:
/* 1103 */         leftMb = mb;
/* 1104 */         lz = 0;
/* 1105 */         tz = 3;
/* 1106 */         rz = 2;
/*      */         break;
/*      */       case 2:
/* 1109 */         aboveMb = mb;
/* 1110 */         aboveRightMb = mb;
/* 1111 */         lz = 3;
/* 1112 */         tz = 0;
/* 1113 */         rz = 1;
/*      */         break;
/*      */       default:
/* 1116 */         leftMb = mb;
/* 1117 */         aboveMb = mb;
/* 1118 */         aboveRightMb = mb;
/* 1119 */         lz = 2;
/* 1120 */         tz = 0;
/* 1121 */         rz = 1;
/*      */         break;
/*      */     } 
/* 1124 */     if (leftMb != null) {
/* 1125 */       num_cand++;
/* 1126 */       pmv[1] = leftMb.mvs[lz];
/*      */     } else {
/* 1128 */       pmv[1] = MPEG4Consts.ZERO_MV;
/*      */     } 
/*      */     
/* 1131 */     if (aboveMb != null) {
/* 1132 */       num_cand++;
/* 1133 */       last_cand = 2;
/* 1134 */       pmv[2] = aboveMb.mvs[tz];
/*      */     } else {
/* 1136 */       pmv[2] = MPEG4Consts.ZERO_MV;
/*      */     } 
/*      */     
/* 1139 */     if (aboveRightMb != null) {
/* 1140 */       num_cand++;
/* 1141 */       last_cand = 3;
/* 1142 */       pmv[3] = aboveRightMb.mvs[rz];
/*      */     } else {
/* 1144 */       pmv[3] = MPEG4Consts.ZERO_MV;
/*      */     } 
/*      */     
/* 1147 */     if (num_cand > 1) {
/* 1148 */       (pmv[0]).x = selectCand((pmv[1]).x, (pmv[2]).x, (pmv[3]).x);
/* 1149 */       (pmv[0]).y = selectCand((pmv[1]).y, (pmv[2]).y, (pmv[3]).y);
/* 1150 */       return pmv[0];
/*      */     } 
/*      */     
/* 1153 */     return pmv[last_cand];
/*      */   }
/*      */   
/*      */   private static int selectCand(int p1x, int p2x, int p3x) {
/* 1157 */     int neg12x = neg(p1x - p2x);
/* 1158 */     int neg13x = neg(p1x - p3x);
/* 1159 */     int neg23x = neg(p2x - p3x);
/* 1160 */     int neg1x = neg(p1x - p2x + neg23x - neg13x);
/* 1161 */     int neg2x = neg(p2x - p1x + neg1x + neg12x - neg23x);
/* 1162 */     return p1x - neg12x + neg2x;
/*      */   }
/*      */   
/*      */   static int neg(int v) {
/* 1166 */     return (v < 0) ? v : 0;
/*      */   }
/*      */   
/*      */   static void readBi(BitReader br, MPEG4DecodingContext ctx, int fcodeForward, int fcodeBackward, Macroblock mb, Macroblock lastMB, Macroblock.Vector pFMV, Macroblock.Vector pBMV) {
/*      */     int i;
/* 1171 */     if (!br.readBool()) {
/* 1172 */       boolean modb2 = br.readBool();
/*      */       
/* 1174 */       mb.mode = readMBType(br);
/*      */       
/* 1176 */       if (!modb2) {
/* 1177 */         mb.cbp = br.readNBit(6);
/*      */       } else {
/* 1179 */         mb.cbp = 0;
/*      */       } 
/*      */       
/* 1182 */       if (mb.mode != 0 && mb.cbp != 0) {
/* 1183 */         mb.quant += readDBQuant(br);
/* 1184 */         if (mb.quant > 31) {
/* 1185 */           mb.quant = 31;
/* 1186 */         } else if (mb.quant < 1) {
/* 1187 */           mb.quant = 1;
/*      */         } 
/*      */       } 
/* 1190 */       if (ctx.interlacing) {
/* 1191 */         if (mb.cbp != 0) {
/* 1192 */           mb.fieldDCT = br.readBool();
/*      */         }
/*      */         
/* 1195 */         if (mb.mode != 0) {
/* 1196 */           mb.fieldPred = br.readBool();
/*      */           
/* 1198 */           if (mb.fieldPred) {
/* 1199 */             mb.fieldForTop = br.readBool();
/* 1200 */             mb.fieldForBottom = br.readBool();
/*      */           } 
/*      */         } 
/*      */       } 
/*      */     } else {
/*      */       
/* 1206 */       mb.mode = 4;
/* 1207 */       mb.cbp = 0;
/*      */     } 
/*      */     
/* 1210 */     Macroblock.Vector mv = Macroblock.vec();
/* 1211 */     switch (mb.mode) {
/*      */       case 0:
/* 1213 */         getBMotionVector(br, mv, 1, MPEG4Consts.ZERO_MV, mb.x, mb.y);
/*      */       
/*      */       case 4:
/* 1216 */         for (i = 0; i < 4; i++) {
/* 1217 */           (mb.mvs[i]).x = (lastMB.mvs[i]).x * ctx.bframeTs / ctx.pframeTs + mv.x;
/* 1218 */           (mb.mvs[i]).y = (lastMB.mvs[i]).y * ctx.bframeTs / ctx.pframeTs + mv.y;
/*      */           
/* 1220 */           (mb.bmvs[i]).x = (mv.x != 0) ? ((mb.mvs[i]).x - (lastMB.mvs[i]).x) : ((lastMB.mvs[i]).x * (ctx.bframeTs - ctx.pframeTs) / ctx.pframeTs);
/*      */           
/* 1222 */           (mb.bmvs[i]).y = (mv.y != 0) ? ((mb.mvs[i]).y - (lastMB.mvs[i]).y) : ((lastMB.mvs[i]).y * (ctx.bframeTs - ctx.pframeTs) / ctx.pframeTs);
/*      */         } 
/*      */ 
/*      */         
/* 1226 */         readInterCoeffs(br, ctx, mb);
/*      */         break;
/*      */       
/*      */       case 1:
/* 1230 */         getBMotionVector(br, mb.mvs[0], fcodeForward, pFMV, mb.x, mb.y);
/* 1231 */         (mb.mvs[3]).x = (mb.mvs[0]).x;
/* 1232 */         (mb.mvs[3]).y = (mb.mvs[0]).y;
/*      */         
/* 1234 */         getBMotionVector(br, mb.bmvs[0], fcodeBackward, pBMV, mb.x, mb.y);
/* 1235 */         (mb.bmvs[3]).x = (mb.bmvs[0]).x;
/* 1236 */         (mb.bmvs[3]).y = (mb.bmvs[0]).y;
/*      */         
/* 1238 */         readInterCoeffs(br, ctx, mb);
/*      */         break;
/*      */       
/*      */       case 2:
/* 1242 */         getBMotionVector(br, mb.mvs[0], fcodeBackward, pBMV, mb.x, mb.y);
/* 1243 */         (mb.mvs[3]).x = (mb.mvs[0]).x;
/* 1244 */         (mb.mvs[3]).y = (mb.mvs[0]).y;
/*      */         
/* 1246 */         readInterCoeffs(br, ctx, mb);
/*      */         break;
/*      */       
/*      */       case 3:
/* 1250 */         getBMotionVector(br, mb.mvs[0], fcodeForward, pFMV, mb.x, mb.y);
/* 1251 */         (mb.mvs[3]).x = (mb.mvs[0]).x;
/* 1252 */         (mb.mvs[3]).y = (mb.mvs[0]).y;
/*      */         
/* 1254 */         readInterCoeffs(br, ctx, mb);
/*      */         break;
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   private static void getBMotionVector(BitReader br, Macroblock.Vector mv, int fcode, Macroblock.Vector pmv, int x, int y) {
/* 1262 */     int scaleFac = 1 << fcode - 1;
/* 1263 */     int high = 32 * scaleFac - 1;
/* 1264 */     int low = -32 * scaleFac;
/* 1265 */     int range = 64 * scaleFac;
/*      */     
/* 1267 */     int mvX = readMVComponent(br, fcode);
/* 1268 */     int mvY = readMVComponent(br, fcode);
/*      */     
/* 1270 */     mvX += pmv.x;
/* 1271 */     mvY += pmv.y;
/*      */     
/* 1273 */     if (mvX < low) {
/* 1274 */       mvX += range;
/* 1275 */     } else if (mvX > high) {
/* 1276 */       mvX -= range;
/*      */     } 
/* 1278 */     if (mvY < low) {
/* 1279 */       mvY += range;
/* 1280 */     } else if (mvY > high) {
/* 1281 */       mvY -= range;
/*      */     } 
/* 1283 */     mv.x = mvX;
/* 1284 */     mv.y = mvY;
/*      */   }
/*      */   
/*      */   static void readInterCoeffs(BitReader br, MPEG4DecodingContext ctx, Macroblock mb) {
/* 1288 */     int iQuant = mb.quant;
/* 1289 */     int direction = ctx.alternateVerticalScan ? 2 : 0;
/*      */     
/* 1291 */     for (int i = 0; i < 6; i++) {
/* 1292 */       short[] block = mb.block[i];
/* 1293 */       Arrays.fill(block, (short)0);
/* 1294 */       if ((mb.cbp & 1 << 5 - i) != 0)
/* 1295 */         if (ctx.quantType) {
/* 1296 */           readInterBlockMPEG(br, block, direction, iQuant, ctx.interMpegQuantMatrix);
/*      */         } else {
/* 1298 */           readInterBlockH263(br, block, direction, iQuant);
/*      */         }  
/*      */     } 
/*      */   }
/*      */ }


/* Location:              C:\Users\rapha\Downloads\aurora.jar!\META-INF\jars\jcodec-0.2.5.jar!\org\jcodec\codecs\mpeg4\MPEG4Bitstream.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */