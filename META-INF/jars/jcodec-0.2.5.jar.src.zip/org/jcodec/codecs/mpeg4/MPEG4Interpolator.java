/*     */ package org.jcodec.codecs.mpeg4;
/*     */ 
/*     */ import org.jcodec.common.tools.MathUtil;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class MPEG4Interpolator
/*     */ {
/*  13 */   private static byte[] qpi = new byte[272];
/*     */ 
/*     */   
/*     */   public static final void fulpel8x8(byte[] dst, int dstOff, int dstStride, byte[] src, int srcCol, int srcRow, int srcWidth, int srcHeight, int srcStride) {
/*  17 */     if (srcCol < 0 || srcRow < 0 || srcCol > srcWidth - 8 || srcRow > srcHeight - 8) {
/*     */       
/*  19 */       for (int j = 0; j < 8; j++, dstOff += dstStride) {
/*  20 */         for (int i = 0; i < 8; i++) {
/*  21 */           int y = MathUtil.clip(srcRow + j, 0, srcHeight - 1);
/*  22 */           int x = MathUtil.clip(srcCol + i, 0, srcWidth - 1);
/*  23 */           dst[dstOff + i] = src[srcStride * y + x];
/*     */         } 
/*     */       } 
/*     */     } else {
/*  27 */       int srcOffset = srcRow * srcStride + srcCol;
/*  28 */       for (int j = 0; j < 8; j++, dstOff += dstStride, srcOffset += srcStride) {
/*  29 */         for (int i = 0; i < 8; i++) {
/*  30 */           dst[dstOff + i] = src[srcOffset + i];
/*     */         }
/*     */       } 
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public static final void fulpel16x16(byte[] dst, byte[] src, int srcCol, int srcRow, int srcWidth, int srcHeight, int srcStride) {
/*  38 */     if (srcCol < 0 || srcRow < 0 || srcCol > srcWidth - 16 || srcRow > srcHeight - 16) {
/*     */       
/*  40 */       for (int j = 0; j < 16; j++) {
/*  41 */         for (int i = 0; i < 16; i++) {
/*  42 */           int y = MathUtil.clip(srcRow + j, 0, srcHeight - 1);
/*  43 */           int x = MathUtil.clip(srcCol + i, 0, srcWidth - 1);
/*  44 */           dst[(j << 4) + i] = src[srcStride * y + x];
/*     */         } 
/*     */       } 
/*     */     } else {
/*  48 */       int srcOffset = srcRow * srcStride + srcCol;
/*  49 */       for (int j = 0; j < 16; j++) {
/*  50 */         for (int i = 0; i < 16; i++) {
/*  51 */           dst[(j << 4) + i] = src[srcOffset + j * srcStride + i];
/*     */         }
/*     */       } 
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public static final void interpolate16x16QP(byte[] dst, byte[] ref, int x, int y, int w, int h, int dx, int dy, int refs, boolean rounding) {
/*  59 */     int xRef = x * 4 + dx;
/*  60 */     int yRef = y * 4 + dy;
/*     */     
/*  62 */     int location = dx & 0x3 | (dy & 0x3) << 2;
/*     */     
/*  64 */     int xFull = xRef / 4;
/*  65 */     if (xRef < 0 && (xRef & 0x3) != 0) {
/*  66 */       xFull--;
/*     */     }
/*     */     
/*  69 */     int yFull = yRef / 4;
/*  70 */     if (yRef < 0 && (yRef & 0x3) != 0) {
/*  71 */       yFull--;
/*     */     }
/*     */     
/*  74 */     switch (location) {
/*     */       case 0:
/*  76 */         fulpel16x16(dst, ref, xFull, yFull, w, h, refs);
/*     */         break;
/*     */       case 1:
/*  79 */         horzMiddle16(dst, ref, xFull, yFull, w, h, 16, refs, rounding ? 1 : 0);
/*  80 */         qOff(dst, ref, xFull, yFull, w, h, 16, refs, rounding ? 1 : 0);
/*     */         break;
/*     */       case 2:
/*  83 */         horzMiddle16(dst, ref, xFull, yFull, w, h, 16, refs, rounding ? 1 : 0);
/*     */         break;
/*     */       case 3:
/*  86 */         horzMiddle16(dst, ref, xFull, yFull, w, h, 16, refs, rounding ? 1 : 0);
/*  87 */         qOff(dst, ref, xFull + 1, yFull, w, h, 16, refs, rounding ? 1 : 0);
/*     */         break;
/*     */       case 4:
/*  90 */         vertMiddle16(dst, ref, xFull, yFull, w, h, 16, refs, rounding ? 1 : 0);
/*  91 */         qOff(dst, ref, xFull, yFull, w, h, 16, refs, rounding ? 1 : 0);
/*     */         break;
/*     */       case 5:
/*  94 */         horzMiddle16(qpi, ref, xFull, yFull, w, h, 17, refs, rounding ? 1 : 0);
/*  95 */         qOff(qpi, ref, xFull, yFull, w, h, 17, refs, rounding ? 1 : 0);
/*  96 */         vertMiddle16Safe(dst, qpi, 0, 16, 16, rounding ? 1 : 0);
/*  97 */         qOffSafe(dst, qpi, 0, 16, 16, rounding ? 1 : 0);
/*     */         break;
/*     */       case 6:
/* 100 */         horzMiddle16(qpi, ref, xFull, yFull, w, h, 17, refs, rounding ? 1 : 0);
/* 101 */         vertMiddle16Safe(dst, qpi, 0, 16, 16, rounding ? 1 : 0);
/* 102 */         qOffSafe(dst, qpi, 0, 16, 16, rounding ? 1 : 0);
/*     */         break;
/*     */       case 7:
/* 105 */         horzMiddle16(qpi, ref, xFull, yFull, w, h, 17, refs, rounding ? 1 : 0);
/* 106 */         qOff(qpi, ref, xFull + 1, yFull, w, h, 17, refs, rounding ? 1 : 0);
/* 107 */         vertMiddle16Safe(dst, qpi, 0, 16, 16, rounding ? 1 : 0);
/* 108 */         qOffSafe(dst, qpi, 0, 16, 16, rounding ? 1 : 0);
/*     */         break;
/*     */       case 8:
/* 111 */         vertMiddle16(dst, ref, xFull, yFull, w, h, 16, refs, rounding ? 1 : 0);
/*     */         break;
/*     */       case 9:
/* 114 */         horzMiddle16(qpi, ref, xFull, yFull, w, h, 17, refs, rounding ? 1 : 0);
/* 115 */         qOff(qpi, ref, xFull, yFull, w, h, 17, refs, rounding ? 1 : 0);
/* 116 */         vertMiddle16Safe(dst, qpi, 0, 16, 16, rounding ? 1 : 0);
/*     */         break;
/*     */       case 10:
/* 119 */         horzMiddle16(qpi, ref, xFull, yFull, w, h, 17, refs, rounding ? 1 : 0);
/* 120 */         vertMiddle16Safe(dst, qpi, 0, 16, 16, rounding ? 1 : 0);
/*     */         break;
/*     */       case 11:
/* 123 */         horzMiddle16(qpi, ref, xFull, yFull, w, h, 17, refs, rounding ? 1 : 0);
/* 124 */         qOff(qpi, ref, xFull + 1, yFull, w, h, 17, refs, rounding ? 1 : 0);
/* 125 */         vertMiddle16Safe(dst, qpi, 0, 16, 16, rounding ? 1 : 0);
/*     */         break;
/*     */       case 12:
/* 128 */         vertMiddle16(dst, ref, xFull, yFull, w, h, 16, refs, rounding ? 1 : 0);
/* 129 */         qOff(dst, ref, xFull, yFull + 1, w, h, 16, refs, rounding ? 1 : 0);
/*     */         break;
/*     */       case 13:
/* 132 */         horzMiddle16(qpi, ref, xFull, yFull, w, h, 17, refs, rounding ? 1 : 0);
/* 133 */         qOff(qpi, ref, xFull, yFull, w, h, 17, refs, rounding ? 1 : 0);
/* 134 */         vertMiddle16Safe(dst, qpi, 0, 16, 16, rounding ? 1 : 0);
/* 135 */         qOffSafe(dst, qpi, 16, 16, 16, rounding ? 1 : 0);
/*     */         break;
/*     */       case 14:
/* 138 */         horzMiddle16(qpi, ref, xFull, yFull, w, h, 17, refs, rounding ? 1 : 0);
/* 139 */         vertMiddle16Safe(dst, qpi, 0, 16, 16, rounding ? 1 : 0);
/* 140 */         qOffSafe(dst, qpi, 16, 16, 16, rounding ? 1 : 0);
/*     */         break;
/*     */       case 15:
/* 143 */         horzMiddle16(qpi, ref, xFull, yFull, w, h, 17, refs, rounding ? 1 : 0);
/* 144 */         qOff(qpi, ref, xFull + 1, yFull, w, h, 17, refs, rounding ? 1 : 0);
/* 145 */         vertMiddle16Safe(dst, qpi, 0, 16, 16, rounding ? 1 : 0);
/* 146 */         qOffSafe(dst, qpi, 16, 16, 16, rounding ? 1 : 0);
/*     */         break;
/*     */     } 
/*     */   }
/*     */   
/*     */   private static void qOffSafe(byte[] dst, byte[] src, int srcOffset, int height, int srcStride, int round) {
/* 152 */     for (int row = 0, dstOff = 0; row < height; row++, srcOffset += srcStride) {
/* 153 */       for (int col = 0; col < 16; col++, dstOff++) {
/* 154 */         dst[dstOff] = (byte)(dst[dstOff] + src[srcOffset + col] + 1 >> 1);
/*     */       }
/*     */     } 
/*     */   }
/*     */   
/*     */   private static void qOff(byte[] dst, byte[] src, int x, int y, int w, int h, int height, int srcStride, int round) {
/* 160 */     if (x < 0 || y < 0 || x > w - 16 || y > h - height) {
/*     */       
/* 162 */       for (int row = 0, dstOff = 0; row < height; row++) {
/* 163 */         int o0 = MathUtil.clip(y + row, 0, h - 1) * srcStride;
/* 164 */         for (int col = 0; col < 16; col++, dstOff++) {
/* 165 */           int srcOffset = o0 + MathUtil.clip(x + col, 0, w - 1);
/* 166 */           dst[dstOff] = (byte)(dst[dstOff] + src[srcOffset] + 1 >> 1);
/*     */         } 
/*     */       } 
/*     */     } else {
/* 170 */       qOffSafe(dst, src, y * srcStride + x, height, srcStride, round);
/*     */     } 
/*     */   }
/*     */   
/*     */   private static void qOff8x8Safe(byte[] dst, int dstOff, byte[] src, int srcOffset, int height, int srcStride, int round) {
/* 175 */     for (int row = 0; row < height; row++, srcOffset += srcStride, dstOff += 8) {
/* 176 */       for (int col = 0; col < 8; col++, dstOff++) {
/* 177 */         dst[dstOff] = (byte)(dst[dstOff] + src[srcOffset + col] + 1 >> 1);
/*     */       }
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   private static void qOff8x8(byte[] dst, int dstOff, byte[] src, int x, int y, int w, int h, int height, int srcStride, int round) {
/* 184 */     if (x < 0 || y < 0 || x > w - 8 || y > h - height) {
/*     */       
/* 186 */       for (int row = 0; row < height; row++, dstOff += 8) {
/* 187 */         int o0 = MathUtil.clip(y + row, 0, h - 1) * srcStride;
/* 188 */         for (int col = 0; col < 8; col++, dstOff++) {
/* 189 */           int srcOffset = o0 + MathUtil.clip(x + col, 0, w - 1);
/* 190 */           dst[dstOff] = (byte)(dst[dstOff] + src[srcOffset] + 1 >> 1);
/*     */         } 
/*     */       } 
/*     */     } else {
/* 194 */       qOff8x8Safe(dst, dstOff, src, y * srcStride + x, height, srcStride, round);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public static final void interpolate8x8QP(byte[] dst, int dstO, byte[] ref, int x, int y, int w, int h, int dx, int dy, int refs, boolean rounding) {
/* 201 */     int xRef = x * 4 + dx;
/* 202 */     int yRef = y * 4 + dy;
/*     */     
/* 204 */     int quads = dx & 0x3 | (dy & 0x3) << 2;
/*     */     
/* 206 */     int xInt = xRef / 4;
/* 207 */     if (xRef < 0 && xRef % 4 != 0) {
/* 208 */       xInt--;
/*     */     }
/*     */     
/* 211 */     int yInt = yRef / 4;
/* 212 */     if (yRef < 0 && yRef % 4 != 0) {
/* 213 */       yInt--;
/*     */     }
/*     */     
/* 216 */     switch (quads) {
/*     */       case 0:
/* 218 */         fulpel8x8(dst, dstO, 16, ref, xInt, yInt, w, h, refs);
/*     */         break;
/*     */       case 1:
/* 221 */         horzMiddle8(dst, dstO, ref, xInt, yInt, w, h, 8, refs, rounding ? 1 : 0);
/* 222 */         qOff8x8(dst, dstO, ref, xInt, yInt, w, h, 8, refs, rounding ? 1 : 0);
/*     */         break;
/*     */       case 2:
/* 225 */         horzMiddle8(dst, dstO, ref, xInt, yInt, w, h, 8, refs, rounding ? 1 : 0);
/*     */         break;
/*     */       case 3:
/* 228 */         horzMiddle8(dst, dstO, ref, xInt, yInt, w, h, 8, refs, rounding ? 1 : 0);
/* 229 */         qOff8x8(dst, dstO, ref, xInt + 1, yInt, w, h, 8, refs, rounding ? 1 : 0);
/*     */         break;
/*     */       case 4:
/* 232 */         vertMiddle8(dst, dstO, ref, xInt, yInt, w, h, 8, refs, rounding ? 1 : 0);
/* 233 */         qOff8x8(dst, dstO, ref, xInt, yInt, w, h, 8, refs, rounding ? 1 : 0);
/*     */         break;
/*     */       case 5:
/* 236 */         horzMiddle8(qpi, 0, ref, xInt, yInt, w, h, 9, refs, rounding ? 1 : 0);
/* 237 */         qOff8x8(qpi, 0, ref, xInt, yInt, w, h, 9, refs, rounding ? 1 : 0);
/* 238 */         vertMiddle8Safe(dst, dstO, qpi, 0, 8, 16, rounding ? 1 : 0);
/* 239 */         qOff8x8Safe(dst, dstO, qpi, 0, 8, 16, rounding ? 1 : 0);
/*     */         break;
/*     */       case 6:
/* 242 */         horzMiddle8(qpi, 0, ref, xInt, yInt, w, h, 9, refs, rounding ? 1 : 0);
/* 243 */         vertMiddle8Safe(dst, dstO, qpi, 0, 8, 16, rounding ? 1 : 0);
/* 244 */         qOff8x8Safe(dst, dstO, qpi, 0, 8, 16, rounding ? 1 : 0);
/*     */         break;
/*     */       case 7:
/* 247 */         horzMiddle8(qpi, 0, ref, xInt, yInt, w, h, 9, refs, rounding ? 1 : 0);
/* 248 */         qOff8x8(qpi, 0, ref, xInt + 1, yInt, w, h, 9, refs, rounding ? 1 : 0);
/* 249 */         vertMiddle8Safe(dst, dstO, qpi, 0, 8, 16, rounding ? 1 : 0);
/* 250 */         qOff8x8Safe(dst, dstO, qpi, 0, 8, 16, rounding ? 1 : 0);
/*     */         break;
/*     */       case 8:
/* 253 */         vertMiddle8(dst, dstO, ref, xInt, yInt, w, h, 8, refs, rounding ? 1 : 0);
/*     */         break;
/*     */       case 9:
/* 256 */         horzMiddle8(qpi, 0, ref, xInt, yInt, w, h, 9, refs, rounding ? 1 : 0);
/* 257 */         qOff8x8(qpi, 0, ref, xInt, yInt, w, h, 9, refs, rounding ? 1 : 0);
/* 258 */         vertMiddle8Safe(dst, dstO, qpi, 0, 8, 16, rounding ? 1 : 0);
/*     */         break;
/*     */       case 10:
/* 261 */         horzMiddle8(qpi, 0, ref, xInt, yInt, w, h, 9, refs, rounding ? 1 : 0);
/* 262 */         vertMiddle8Safe(dst, dstO, qpi, 0, 8, 16, rounding ? 1 : 0);
/*     */         break;
/*     */       case 11:
/* 265 */         horzMiddle8(qpi, 0, ref, xInt, yInt, w, h, 9, refs, rounding ? 1 : 0);
/* 266 */         qOff8x8(qpi, 0, ref, xInt + 1, yInt, w, h, 9, refs, rounding ? 1 : 0);
/* 267 */         vertMiddle8Safe(dst, dstO, qpi, 0, 8, 16, rounding ? 1 : 0);
/*     */         break;
/*     */       case 12:
/* 270 */         vertMiddle8(dst, dstO, ref, xInt, yInt, w, h, 8, refs, rounding ? 1 : 0);
/* 271 */         qOff8x8(dst, dstO, ref, xInt, yInt + 1, w, h, 8, refs, rounding ? 1 : 0);
/*     */         break;
/*     */       case 13:
/* 274 */         horzMiddle8(qpi, 0, ref, xInt, yInt, w, h, 9, refs, rounding ? 1 : 0);
/* 275 */         qOff8x8(qpi, 0, ref, xInt, yInt, w, h, 9, refs, rounding ? 1 : 0);
/* 276 */         vertMiddle8Safe(dst, dstO, qpi, 0, 8, 16, rounding ? 1 : 0);
/* 277 */         qOff8x8Safe(dst, dstO, qpi, 16, 8, 16, rounding ? 1 : 0);
/*     */         break;
/*     */       case 14:
/* 280 */         horzMiddle8(qpi, 0, ref, xInt, yInt, w, h, 9, refs, rounding ? 1 : 0);
/* 281 */         vertMiddle8Safe(dst, dstO, qpi, 0, 8, 16, rounding ? 1 : 0);
/* 282 */         qOff8x8Safe(dst, dstO, qpi, 16, 8, 16, rounding ? 1 : 0);
/*     */         break;
/*     */       case 15:
/* 285 */         horzMiddle8(qpi, 0, ref, xInt, yInt, w, h, 9, refs, rounding ? 1 : 0);
/* 286 */         qOff8x8(qpi, 0, ref, xInt + 1, yInt, w, h, 9, refs, rounding ? 1 : 0);
/* 287 */         vertMiddle8Safe(dst, dstO, qpi, 0, 8, 16, rounding ? 1 : 0);
/* 288 */         qOff8x8Safe(dst, dstO, qpi, 16, 8, 16, rounding ? 1 : 0);
/*     */         break;
/*     */     } 
/*     */   }
/*     */   
/*     */   private static final void horzMiddle8(byte[] dst, int dstOffset, byte[] src, int x, int y, int w, int h, int height, int srcStride, int rounding) {
/* 294 */     if (x < 0 || y < 0 || x > w - 9 || y > h - height) {
/*     */       
/* 296 */       for (int row = 0; row < height; row++) {
/* 297 */         for (int i = 0; i < 4; i++) {
/* 298 */           int sum0 = 0;
/* 299 */           int sum1 = 0;
/* 300 */           int o0 = MathUtil.clip(y + row, 0, h - 1) * srcStride;
/* 301 */           for (int k = 0; k < 5 + i; k++) {
/* 302 */             int o1 = MathUtil.clip(x + k, 0, w - 1);
/* 303 */             int o2 = MathUtil.clip(x + 8 - k, 0, w - 1);
/* 304 */             sum0 += MPEG4Consts.FILTER_TAB[i][k] * src[o0 + o1];
/* 305 */             sum1 += MPEG4Consts.FILTER_TAB[i][k] * src[o0 + o2];
/*     */           } 
/* 307 */           dst[dstOffset + i] = (byte)MathUtil.clip(sum0 + 16 - rounding >> 5, -128, 127);
/* 308 */           dst[dstOffset + 7 - i] = (byte)MathUtil.clip(sum1 + 16 - rounding >> 5, -128, 127);
/*     */         } 
/*     */         
/* 311 */         dstOffset += 16;
/*     */       } 
/*     */     } else {
/*     */       
/* 315 */       int srcOffset = y * srcStride + x;
/* 316 */       for (int row = 0; row < height; row++) {
/* 317 */         for (int i = 0; i < 4; i++) {
/* 318 */           int sum0 = 0;
/* 319 */           int sum1 = 0;
/* 320 */           for (int k = 0; k < 5 + i; k++) {
/* 321 */             sum0 += MPEG4Consts.FILTER_TAB[i][k] * src[srcOffset + k];
/* 322 */             sum1 += MPEG4Consts.FILTER_TAB[i][k] * src[srcOffset + 8 - k];
/*     */           } 
/* 324 */           dst[dstOffset + i] = (byte)MathUtil.clip(sum0 + 16 - rounding >> 5, -128, 127);
/* 325 */           dst[dstOffset + 7 - i] = (byte)MathUtil.clip(sum1 + 16 - rounding >> 5, -128, 127);
/*     */         } 
/*     */         
/* 328 */         srcOffset += srcStride;
/* 329 */         dstOffset += 16;
/*     */       } 
/*     */     } 
/*     */   }
/*     */   
/*     */   private static final void horzMiddle16(byte[] dst, byte[] src, int x, int y, int w, int h, int height, int srcStride, int rounding) {
/* 335 */     if (x < 0 || y < 0 || x > w - 17 || y > h - height) {
/*     */       
/* 337 */       int dstOffset = 0;
/* 338 */       for (int row = 0; row < height; row++) {
/* 339 */         int o0 = MathUtil.clip(y + row, 0, h - 1) * srcStride; int i;
/* 340 */         for (i = 0; i < 4; i++) {
/* 341 */           int sum0 = 0;
/* 342 */           int sum1 = 0;
/* 343 */           for (int k = 0; k < 5 + i; k++) {
/* 344 */             int srcOffset0 = o0 + MathUtil.clip(x + k, 0, w - 1);
/* 345 */             int srcOffset1 = o0 + MathUtil.clip(x + 16 - k, 0, w - 1);
/* 346 */             sum0 += MPEG4Consts.FILTER_TAB[i][k] * src[srcOffset0];
/* 347 */             sum1 += MPEG4Consts.FILTER_TAB[i][k] * src[srcOffset1];
/*     */           } 
/* 349 */           dst[dstOffset + i] = (byte)MathUtil.clip(sum0 + 16 - rounding >> 5, -128, 127);
/* 350 */           dst[dstOffset + 15 - i] = (byte)MathUtil.clip(sum1 + 16 - rounding >> 5, -128, 127);
/*     */         } 
/* 352 */         for (i = 0; i < 8; i++) {
/* 353 */           int sum = 0;
/* 354 */           for (int k = 0; k < 8; k++) {
/* 355 */             int srcOffset = o0 + MathUtil.clip(x + k + i + 1, 0, w - 1);
/* 356 */             sum += MPEG4Consts.FILTER_TAB[3][k] * src[srcOffset];
/*     */           } 
/* 358 */           dst[dstOffset + i + 4] = (byte)MathUtil.clip(sum + 16 - rounding >> 5, -128, 127);
/*     */         } 
/*     */         
/* 361 */         dstOffset += 16;
/*     */       } 
/*     */     } else {
/*     */       
/* 365 */       int srcOffset = y * srcStride + x;
/* 366 */       int dstOffset = 0;
/* 367 */       for (int row = 0; row < height; row++) {
/* 368 */         int i; for (i = 0; i < 4; i++) {
/* 369 */           int sum0 = 0;
/* 370 */           int sum1 = 0;
/* 371 */           for (int k = 0; k < 5 + i; k++) {
/* 372 */             sum0 += MPEG4Consts.FILTER_TAB[i][k] * src[srcOffset + k];
/* 373 */             sum1 += MPEG4Consts.FILTER_TAB[i][k] * src[srcOffset + 16 - k];
/*     */           } 
/* 375 */           dst[dstOffset + i] = (byte)MathUtil.clip(sum0 + 16 - rounding >> 5, -128, 127);
/* 376 */           dst[dstOffset + 15 - i] = (byte)MathUtil.clip(sum1 + 16 - rounding >> 5, -128, 127);
/*     */         } 
/* 378 */         for (i = 0; i < 8; i++) {
/* 379 */           int sum = 0;
/* 380 */           for (int k = 0; k < 8; k++) {
/* 381 */             sum += MPEG4Consts.FILTER_TAB[3][k] * src[srcOffset + k + i + 1];
/*     */           }
/* 383 */           dst[dstOffset + i + 4] = (byte)MathUtil.clip(sum + 16 - rounding >> 5, -128, 127);
/*     */         } 
/*     */         
/* 386 */         srcOffset += srcStride;
/* 387 */         dstOffset += 16;
/*     */       } 
/*     */     } 
/*     */   }
/*     */   
/*     */   private static final void vertMiddle16Safe(byte[] dst, byte[] src, int srcOffset, int width, int srcStride, int rounding) {
/* 393 */     int dstOffset = 0;
/* 394 */     for (int col = 0; col < width; col++) {
/* 395 */       int dstStart = dstOffset, dstEnd = dstOffset + 240;
/* 396 */       for (int i = 0; i < 4; i++, dstStart += 16, dstEnd -= 16) {
/* 397 */         int sum0 = 0;
/* 398 */         int sum1 = 0;
/* 399 */         int ss = srcOffset;
/* 400 */         int es = srcOffset + (srcStride << 4);
/* 401 */         for (int k = 0; k < 5 + i; k++) {
/* 402 */           sum0 += MPEG4Consts.FILTER_TAB[i][k] * src[ss];
/* 403 */           sum1 += MPEG4Consts.FILTER_TAB[i][k] * src[es];
/* 404 */           ss += srcStride;
/* 405 */           es -= srcStride;
/*     */         } 
/* 407 */         dst[dstStart] = (byte)MathUtil.clip(sum0 + 16 - rounding >> 5, -128, 127);
/* 408 */         dst[dstEnd] = (byte)MathUtil.clip(sum1 + 16 - rounding >> 5, -128, 127);
/*     */       } 
/* 410 */       dstStart = dstOffset + 64;
/* 411 */       int srcCoeff0Pos = srcOffset + srcStride;
/* 412 */       for (int j = 0; j < 8; j++, dstStart += 16, srcCoeff0Pos += srcStride) {
/* 413 */         int sum = 0;
/* 414 */         int srcPos = srcCoeff0Pos;
/* 415 */         for (int k = 0; k < 8; k++, srcPos += srcStride) {
/* 416 */           sum += MPEG4Consts.FILTER_TAB[3][k] * src[srcPos];
/*     */         }
/* 418 */         dst[dstStart] = (byte)MathUtil.clip(sum + 16 - rounding >> 5, -128, 127);
/*     */       } 
/*     */       
/* 421 */       srcOffset++;
/* 422 */       dstOffset++;
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   private static final void vertMiddle16(byte[] dst, byte[] src, int x, int y, int w, int h, int width, int srcStride, int rounding) {
/* 428 */     if (x < 0 || y < 0 || x > w - width || y > h - 17) {
/*     */       
/* 430 */       int dstOffset = 0;
/* 431 */       for (int col = 0; col < width; col++) {
/* 432 */         int dstStart = dstOffset, dstEnd = dstOffset + 240; int i;
/* 433 */         for (i = 0; i < 4; i++, dstStart += 16, dstEnd -= 16) {
/* 434 */           int sum0 = 0;
/* 435 */           int sum1 = 0;
/* 436 */           for (int k = 0; k < 5 + i; k++) {
/* 437 */             int ss = MathUtil.clip(y + k, 0, h - 1) * srcStride + MathUtil.clip(x + col, 0, w - 1);
/* 438 */             int es = MathUtil.clip(y - k + 16, 0, h - 1) * srcStride + MathUtil.clip(x + col, 0, w - 1);
/*     */             
/* 440 */             sum0 += MPEG4Consts.FILTER_TAB[i][k] * src[ss];
/* 441 */             sum1 += MPEG4Consts.FILTER_TAB[i][k] * src[es];
/*     */           } 
/* 443 */           dst[dstStart] = (byte)MathUtil.clip(sum0 + 16 - rounding >> 5, -128, 127);
/* 444 */           dst[dstEnd] = (byte)MathUtil.clip(sum1 + 16 - rounding >> 5, -128, 127);
/*     */         } 
/* 446 */         dstStart = dstOffset + 64;
/* 447 */         for (i = 0; i < 8; i++, dstStart += 16) {
/* 448 */           int sum = 0;
/* 449 */           for (int k = 0; k < 8; k++) {
/*     */             
/* 451 */             int srcPos = MathUtil.clip(y + i + k + 1, 0, h - 1) * srcStride + MathUtil.clip(x + col, 0, w - 1);
/* 452 */             sum += MPEG4Consts.FILTER_TAB[3][k] * src[srcPos];
/*     */           } 
/* 454 */           dst[dstStart] = (byte)MathUtil.clip(sum + 16 - rounding >> 5, -128, 127);
/*     */         } 
/*     */         
/* 457 */         dstOffset++;
/*     */       } 
/*     */     } else {
/* 460 */       vertMiddle16Safe(dst, src, y * srcStride + x, width, srcStride, rounding);
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   private static final void vertMiddle8Safe(byte[] dst, int dstOffset, byte[] src, int srcOffset, int width, int srcStride, int rounding) {
/* 466 */     for (int col = 0; col < width; col++) {
/* 467 */       for (int i = 0; i < 4; i++) {
/* 468 */         int sum0 = 0;
/* 469 */         int sum1 = 0;
/* 470 */         int os = srcOffset;
/* 471 */         int of = srcOffset + (srcStride << 3);
/* 472 */         for (int k = 0; k < 5 + i; k++) {
/* 473 */           sum0 += MPEG4Consts.FILTER_TAB[i][k] * src[os];
/* 474 */           sum1 += MPEG4Consts.FILTER_TAB[i][k] * src[of];
/* 475 */           os += srcStride;
/* 476 */           of -= srcStride;
/*     */         } 
/* 478 */         dst[dstOffset + i * 16] = (byte)MathUtil.clip(sum0 + 16 - rounding >> 5, -128, 127);
/* 479 */         dst[dstOffset + (7 - i) * 16] = (byte)MathUtil.clip(sum1 + 16 - rounding >> 5, -128, 127);
/*     */       } 
/*     */       
/* 482 */       srcOffset++;
/* 483 */       dstOffset++;
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   private static final void vertMiddle8(byte[] dst, int dstOffset, byte[] src, int x, int y, int w, int h, int width, int srcStride, int rounding) {
/* 489 */     if (x < 0 || y < 0 || x > w - width || y > h - 9) {
/*     */       
/* 491 */       for (int col = 0; col < width; col++) {
/* 492 */         for (int i = 0; i < 4; i++) {
/* 493 */           int sum0 = 0;
/* 494 */           int sum1 = 0;
/* 495 */           for (int k = 0; k < 5 + i; k++) {
/* 496 */             int os = MathUtil.clip(y + k, 0, h - 1) * srcStride + MathUtil.clip(x + col, 0, w - 1);
/* 497 */             int of = MathUtil.clip(y + 8 - k, 0, h - 1) * srcStride + MathUtil.clip(x + col, 0, w - 1);
/* 498 */             sum0 += MPEG4Consts.FILTER_TAB[i][k] * src[os];
/* 499 */             sum1 += MPEG4Consts.FILTER_TAB[i][k] * src[of];
/*     */           } 
/* 501 */           dst[dstOffset + i * 16] = (byte)MathUtil.clip(sum0 + 16 - rounding >> 5, -128, 127);
/* 502 */           dst[dstOffset + (7 - i) * 16] = (byte)MathUtil.clip(sum1 + 16 - rounding >> 5, -128, 127);
/*     */         } 
/*     */         
/* 505 */         dstOffset++;
/*     */       } 
/*     */     } else {
/* 508 */       vertMiddle8Safe(dst, dstOffset, src, y * srcStride + x, width, srcStride, rounding);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public static final void interpolate16x16Planar(byte[] dst, byte[] refn, int x, int y, int w, int h, int dx, int dy, int stride, boolean rounding) {
/* 515 */     interpolate8x8Planar(dst, 0, 16, refn, x, y, w, h, dx, dy, stride, rounding);
/* 516 */     interpolate8x8Planar(dst, 8, 16, refn, x + 8, y, w, h, dx, dy, stride, rounding);
/* 517 */     interpolate8x8Planar(dst, 128, 16, refn, x, y + 8, w, h, dx, dy, stride, rounding);
/* 518 */     interpolate8x8Planar(dst, 136, 16, refn, x + 8, y + 8, w, h, dx, dy, stride, rounding);
/*     */   }
/*     */ 
/*     */   
/*     */   public static final void interpolate8x8Planar(byte[] dst, int dstOff, int dstStride, byte[] refn, int x, int y, int w, int h, int dx, int dy, int stride, boolean rounding) {
/* 523 */     int x_ = x + (dx >> 1);
/* 524 */     int y_ = y + (dy >> 1);
/*     */     
/* 526 */     switch (((dx & 0x1) << 1) + (dy & 0x1)) {
/*     */       case 0:
/* 528 */         fulpel8x8(dst, dstOff, dstStride, refn, x_, y_, w, h, stride);
/*     */         return;
/*     */       case 1:
/* 531 */         interpolate8PlanarVer(dst, dstOff, dstStride, refn, x_, y_, w, h, stride, rounding);
/*     */         return;
/*     */       case 2:
/* 534 */         interpolate8x8PlanarHor(dst, dstOff, dstStride, refn, x_, y_, w, h, stride, rounding);
/*     */         return;
/*     */     } 
/* 537 */     interpolate8x8PlanarBoth(dst, dstOff, dstStride, refn, x_, y_, w, h, stride, rounding);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static final void interpolate8x8PlanarHor(byte[] dst, int dstOffset, int dstStride, byte[] src, int x, int y, int w, int h, int stride, boolean rounding) {
/* 544 */     int rnd = rounding ? 0 : 1;
/* 545 */     if (x < 0 || y < 0 || x > w - 9 || y > h - 8) {
/*     */       int d;
/* 547 */       for (int j = 0; j < 8; j++, d += dstStride) {
/* 548 */         for (int i = 0; i < 8; i++) {
/* 549 */           int srcOffset0 = MathUtil.clip(y + j, 0, h - 1) * stride + MathUtil.clip(x + i, 0, w - 1);
/* 550 */           int srcOffset1 = MathUtil.clip(y + j, 0, h - 1) * stride + MathUtil.clip(x + i + 1, 0, w - 1);
/* 551 */           dst[d + i] = (byte)(src[srcOffset0] + src[srcOffset1] + rnd >> 1);
/*     */         } 
/*     */       } 
/*     */     } else {
/*     */       
/* 556 */       int srcOffset = y * stride + x; int d;
/* 557 */       for (int j = 0; j < 8 * stride; j += stride, d += dstStride) {
/* 558 */         for (int i = 0; i < 8; i++) {
/* 559 */           dst[d + i] = (byte)(src[srcOffset + j + i] + src[srcOffset + j + i + 1] + rnd >> 1);
/*     */         }
/*     */       } 
/*     */     } 
/*     */   }
/*     */   
/*     */   private static final void interpolate8PlanarVer(byte[] dst, int dstOff, int dstStride, byte[] src, int x, int y, int w, int h, int stride, boolean rounding) {
/* 566 */     int rnd = rounding ? 0 : 1;
/* 567 */     if (x < 0 || y < 0 || x > w - 8 || y > h - 9) {
/*     */       int d;
/* 569 */       for (int j = 0; j < 8; j++, d += dstStride) {
/* 570 */         for (int i = 0; i < 8; i++) {
/* 571 */           int srcOffset0 = MathUtil.clip(y + j, 0, h - 1) * stride + MathUtil.clip(x + i, 0, w - 1);
/* 572 */           int srcOffset1 = MathUtil.clip(y + j + 1, 0, h - 1) * stride + MathUtil.clip(x + i, 0, w - 1);
/* 573 */           dst[d + i] = (byte)(src[srcOffset0] + src[srcOffset1] + rnd >> 1);
/*     */         } 
/*     */       } 
/*     */     } else {
/*     */       
/* 578 */       int srcOffset = y * stride + x; int d;
/* 579 */       for (int j = 0; j < 8 * stride; j += stride, d += dstStride) {
/* 580 */         for (int i = 0; i < 8; i++) {
/* 581 */           dst[d + i] = (byte)(src[srcOffset + j + i] + src[srcOffset + j + stride + i] + rnd >> 1);
/*     */         }
/*     */       } 
/*     */     } 
/*     */   }
/*     */   
/*     */   private static final void interpolate8x8PlanarBoth(byte[] dst, int dstOff, int dstStride, byte[] src, int x, int y, int w, int h, int stride, boolean rounding) {
/* 588 */     int rnd = rounding ? 1 : 2;
/* 589 */     if (x < 0 || y < 0 || x > w - 9 || y > h - 9) {
/*     */       int d;
/* 591 */       for (int j = 0; j < 8; j++, d += dstStride) {
/* 592 */         for (int i = 0; i < 8; i++) {
/* 593 */           int srcOffset0 = MathUtil.clip(y + j, 0, h - 1) * stride + MathUtil.clip(x + i, 0, w - 1);
/* 594 */           int srcOffset1 = MathUtil.clip(y + j, 0, h - 1) * stride + MathUtil.clip(x + i + 1, 0, w - 1);
/* 595 */           int srcOffset2 = MathUtil.clip(y + j + 1, 0, h - 1) * stride + MathUtil.clip(x + i, 0, w - 1);
/* 596 */           int srcOffset3 = MathUtil.clip(y + j + 1, 0, h - 1) * stride + MathUtil.clip(x + i + 1, 0, w - 1);
/* 597 */           dst[d + i] = (byte)(src[srcOffset0] + src[srcOffset1] + src[srcOffset2] + src[srcOffset3] + rnd >> 2);
/*     */         }
/*     */       
/*     */       }
/*     */     
/*     */     } else {
/*     */       
/* 604 */       int srcOffset = y * stride + x; int d;
/* 605 */       for (int j = 0; j < 8 * stride; j += stride, d += dstStride) {
/* 606 */         for (int i = 0; i < 8; i++)
/* 607 */           dst[d + i] = (byte)(src[srcOffset + j + i] + src[srcOffset + j + i + 1] + src[srcOffset + j + stride + i] + src[srcOffset + j + stride + i + 1] + rnd >> 2); 
/*     */       } 
/*     */     } 
/*     */   }
/*     */ }


/* Location:              C:\Users\rapha\Downloads\aurora.jar!\META-INF\jars\jcodec-0.2.5.jar!\org\jcodec\codecs\mpeg4\MPEG4Interpolator.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */