/*     */ package org.jcodec.codecs.mpeg4.mp4;
/*     */ 
/*     */ import java.nio.ByteBuffer;
/*     */ import java.util.ArrayList;
/*     */ import org.jcodec.codecs.aac.ADTSParser;
/*     */ import org.jcodec.codecs.mpeg4.es.DecoderConfig;
/*     */ import org.jcodec.codecs.mpeg4.es.DecoderSpecific;
/*     */ import org.jcodec.codecs.mpeg4.es.Descriptor;
/*     */ import org.jcodec.codecs.mpeg4.es.DescriptorParser;
/*     */ import org.jcodec.codecs.mpeg4.es.ES;
/*     */ import org.jcodec.codecs.mpeg4.es.NodeDescriptor;
/*     */ import org.jcodec.codecs.mpeg4.es.SL;
/*     */ import org.jcodec.containers.mp4.boxes.FullBox;
/*     */ import org.jcodec.containers.mp4.boxes.Header;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class EsdsBox
/*     */   extends FullBox
/*     */ {
/*     */   private ByteBuffer streamInfo;
/*     */   private int objectType;
/*     */   private int bufSize;
/*     */   private int maxBitrate;
/*     */   private int avgBitrate;
/*     */   private int trackId;
/*     */   
/*     */   public static String fourcc() {
/*  36 */     return "esds";
/*     */   }
/*     */   
/*     */   public EsdsBox(Header atom) {
/*  40 */     super(atom);
/*     */   }
/*     */ 
/*     */   
/*     */   protected void doWrite(ByteBuffer out) {
/*  45 */     super.doWrite(out);
/*     */     
/*  47 */     if (this.streamInfo != null && this.streamInfo.remaining() > 0) {
/*  48 */       ArrayList<Descriptor> l = new ArrayList<Descriptor>();
/*  49 */       ArrayList<Descriptor> l1 = new ArrayList<Descriptor>();
/*  50 */       l1.add(new DecoderSpecific(this.streamInfo));
/*  51 */       l.add(new DecoderConfig(this.objectType, this.bufSize, this.maxBitrate, this.avgBitrate, l1));
/*  52 */       l.add(new SL());
/*  53 */       (new ES(this.trackId, l)).write(out);
/*     */     } else {
/*  55 */       ArrayList<Descriptor> l = new ArrayList<Descriptor>();
/*  56 */       l.add(new DecoderConfig(this.objectType, this.bufSize, this.maxBitrate, this.avgBitrate, new ArrayList()));
/*  57 */       l.add(new SL());
/*  58 */       (new ES(this.trackId, l)).write(out);
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public int estimateSize() {
/*  64 */     return 64;
/*     */   }
/*     */   
/*     */   public void parse(ByteBuffer input) {
/*  68 */     super.parse(input);
/*  69 */     ES es = (ES)DescriptorParser.read(input);
/*     */     
/*  71 */     this.trackId = es.getTrackId();
/*  72 */     DecoderConfig decoderConfig = (DecoderConfig)NodeDescriptor.findByTag((Descriptor)es, DecoderConfig.tag());
/*  73 */     this.objectType = decoderConfig.getObjectType();
/*  74 */     this.bufSize = decoderConfig.getBufSize();
/*  75 */     this.maxBitrate = decoderConfig.getMaxBitrate();
/*  76 */     this.avgBitrate = decoderConfig.getAvgBitrate();
/*  77 */     DecoderSpecific decoderSpecific = (DecoderSpecific)NodeDescriptor.findByTag((Descriptor)decoderConfig, DecoderSpecific.tag());
/*  78 */     this.streamInfo = decoderSpecific.getData();
/*     */   }
/*     */   
/*     */   public ByteBuffer getStreamInfo() {
/*  82 */     return this.streamInfo;
/*     */   }
/*     */   
/*     */   public int getObjectType() {
/*  86 */     return this.objectType;
/*     */   }
/*     */   
/*     */   public int getBufSize() {
/*  90 */     return this.bufSize;
/*     */   }
/*     */   
/*     */   public int getMaxBitrate() {
/*  94 */     return this.maxBitrate;
/*     */   }
/*     */   
/*     */   public int getAvgBitrate() {
/*  98 */     return this.avgBitrate;
/*     */   }
/*     */   
/*     */   public int getTrackId() {
/* 102 */     return this.trackId;
/*     */   }
/*     */   
/*     */   public static EsdsBox fromADTS(ADTSParser.Header hdr) {
/* 106 */     return createEsdsBox(ADTSParser.adtsToStreamInfo(hdr), hdr.getObjectType() << 5, 0, 210750, 133350, 2);
/*     */   }
/*     */ 
/*     */   
/*     */   public static EsdsBox createEsdsBox(ByteBuffer streamInfo, int objectType, int bufSize, int maxBitrate, int avgBitrate, int trackId) {
/* 111 */     EsdsBox esds = new EsdsBox(new Header(fourcc()));
/* 112 */     esds.objectType = objectType;
/* 113 */     esds.bufSize = bufSize;
/* 114 */     esds.maxBitrate = maxBitrate;
/* 115 */     esds.avgBitrate = avgBitrate;
/* 116 */     esds.trackId = trackId;
/* 117 */     esds.streamInfo = streamInfo;
/* 118 */     return esds;
/*     */   }
/*     */   
/*     */   public static EsdsBox newEsdsBox() {
/* 122 */     return new EsdsBox(new Header(fourcc()));
/*     */   }
/*     */ }


/* Location:              C:\Users\rapha\Downloads\aurora.jar!\META-INF\jars\jcodec-0.2.5.jar!\org\jcodec\codecs\mpeg4\mp4\EsdsBox.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */