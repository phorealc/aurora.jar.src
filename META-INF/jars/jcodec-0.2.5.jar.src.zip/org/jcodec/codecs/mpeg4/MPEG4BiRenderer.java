/*     */ package org.jcodec.codecs.mpeg4;
/*     */ 
/*     */ import org.jcodec.common.model.Picture;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class MPEG4BiRenderer
/*     */ {
/*     */   public static void renderBi(MPEG4DecodingContext ctx, Picture[] refs, int fcodeForward, int fcodeBackward, Macroblock mb) {
/*  31 */     switch (mb.mode) {
/*     */       case 0:
/*     */       case 4:
/*  34 */         renderBiDir(ctx, refs, mb, true);
/*     */         break;
/*     */       
/*     */       case 1:
/*  38 */         renderBiDir(ctx, refs, mb, false);
/*     */         break;
/*     */       
/*     */       case 2:
/*  42 */         MPEG4Renderer.renderInter(ctx, refs, mb, fcodeBackward, 0, true);
/*     */         break;
/*     */       
/*     */       case 3:
/*  46 */         MPEG4Renderer.renderInter(ctx, refs, mb, fcodeForward, 1, true);
/*     */         break;
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   private static void renderBiDir(MPEG4DecodingContext ctx, Picture[] refs, Macroblock mb, boolean direct) {
/*  53 */     int cbp = mb.cbp;
/*     */     
/*  55 */     MPEG4Renderer.validateVector(mb.mvs, ctx, mb.x, mb.y);
/*  56 */     MPEG4Renderer.validateVector(mb.bmvs, ctx, mb.x, mb.y);
/*     */     
/*  58 */     renderOneDir(ctx, mb, direct, refs[1], mb.mvs, 0);
/*  59 */     renderOneDir(ctx, mb, direct, refs[0], mb.bmvs, 3);
/*     */     
/*  61 */     mergePred(mb);
/*     */     
/*  63 */     if (cbp != 0) {
/*  64 */       for (int i = 0; i < 6; i++) {
/*  65 */         short[] block = mb.block[i];
/*  66 */         if ((mb.cbp & 1 << 5 - i) != 0) {
/*  67 */           MPEG4DCT.idctAdd(mb.pred, block, i, (ctx.interlacing && mb.fieldDCT));
/*     */         }
/*     */       } 
/*     */     }
/*     */   }
/*     */   
/*     */   private static void mergePred(Macroblock mb) {
/*  74 */     for (int i = 0; i < 256; i++) {
/*  75 */       mb.pred[0][i] = (byte)(mb.pred[0][i] + mb.pred[3][i] + 1 >> 1);
/*     */     }
/*  77 */     for (int pl = 1; pl < 3; pl++) {
/*  78 */       for (int j = 0; j < 64; j++) {
/*  79 */         mb.pred[pl][j] = (byte)(mb.pred[pl][j] + mb.pred[pl + 3][j] + 1 >> 1);
/*     */       }
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   private static void renderOneDir(MPEG4DecodingContext ctx, Macroblock mb, boolean direct, Picture forward, Macroblock.Vector[] mvs, int pred) {
/*  86 */     int mx_chr, my_chr, mbX = 16 * mb.x;
/*  87 */     int mbY = 16 * mb.y;
/*  88 */     int codedW = ctx.mbWidth << 4;
/*  89 */     int codedH = ctx.mbHeight << 4;
/*  90 */     int codedWcr = ctx.mbWidth << 3;
/*  91 */     int codedHcr = ctx.mbHeight << 3;
/*     */     
/*  93 */     if (ctx.quarterPel) {
/*  94 */       if (!direct) {
/*  95 */         MPEG4Interpolator.interpolate16x16QP(mb.pred[pred], forward.getPlaneData(0), mbX, mbY, codedW, codedH, (mvs[0]).x, (mvs[0]).y, forward
/*  96 */             .getWidth(), false);
/*     */       } else {
/*  98 */         MPEG4Interpolator.interpolate8x8QP(mb.pred[pred], 0, forward.getPlaneData(0), mbX, mbY, codedW, codedH, (mvs[0]).x, (mvs[0]).y, forward
/*  99 */             .getWidth(), false);
/* 100 */         MPEG4Interpolator.interpolate8x8QP(mb.pred[pred], 8, forward.getPlaneData(0), mbX + 8, mbY, codedW, codedH, (mvs[1]).x, (mvs[1]).y, forward
/* 101 */             .getWidth(), false);
/* 102 */         MPEG4Interpolator.interpolate8x8QP(mb.pred[pred], 128, forward.getPlaneData(0), mbX, mbY + 8, codedW, codedH, (mvs[2]).x, (mvs[2]).y, forward
/* 103 */             .getWidth(), false);
/* 104 */         MPEG4Interpolator.interpolate8x8QP(mb.pred[pred], 136, forward.getPlaneData(0), mbX + 8, mbY + 8, codedW, codedH, (mvs[3]).x, (mvs[3]).y, forward
/* 105 */             .getWidth(), false);
/*     */       } 
/*     */     } else {
/* 108 */       MPEG4Interpolator.interpolate8x8Planar(mb.pred[pred], 0, 16, forward.getPlaneData(0), mbX, mbY, codedW, codedH, (mvs[0]).x, (mvs[0]).y, forward
/* 109 */           .getWidth(), false);
/* 110 */       MPEG4Interpolator.interpolate8x8Planar(mb.pred[pred], 8, 16, forward.getPlaneData(0), mbX + 8, mbY, codedW, codedH, (mvs[1]).x, (mvs[1]).y, forward
/* 111 */           .getWidth(), false);
/* 112 */       MPEG4Interpolator.interpolate8x8Planar(mb.pred[pred], 128, 16, forward.getPlaneData(0), mbX, mbY + 8, codedW, codedH, (mvs[2]).x, (mvs[2]).y, forward
/* 113 */           .getWidth(), false);
/* 114 */       MPEG4Interpolator.interpolate8x8Planar(mb.pred[pred], 136, 16, forward.getPlaneData(0), mbX + 8, mbY + 8, codedW, codedH, (mvs[3]).x, (mvs[3]).y, forward
/* 115 */           .getWidth(), false);
/*     */     } 
/*     */ 
/*     */     
/* 119 */     if (!direct) {
/* 120 */       mx_chr = MPEG4Renderer.calcChromaMv(ctx, (mvs[0]).x);
/* 121 */       my_chr = MPEG4Renderer.calcChromaMv(ctx, (mvs[0]).y);
/*     */     } else {
/* 123 */       mx_chr = MPEG4Renderer.calcChromaMvAvg(ctx, mvs, true);
/* 124 */       my_chr = MPEG4Renderer.calcChromaMvAvg(ctx, mvs, false);
/*     */     } 
/* 126 */     MPEG4Interpolator.interpolate8x8Planar(mb.pred[pred + 1], 0, 8, forward.getPlaneData(1), 8 * mb.x, 8 * mb.y, codedWcr, codedHcr, mx_chr, my_chr, forward
/* 127 */         .getPlaneWidth(1), false);
/* 128 */     MPEG4Interpolator.interpolate8x8Planar(mb.pred[pred + 2], 0, 8, forward.getPlaneData(2), 8 * mb.x, 8 * mb.y, codedWcr, codedHcr, mx_chr, my_chr, forward
/* 129 */         .getPlaneWidth(2), false);
/*     */   }
/*     */ }


/* Location:              C:\Users\rapha\Downloads\aurora.jar!\META-INF\jars\jcodec-0.2.5.jar!\org\jcodec\codecs\mpeg4\MPEG4BiRenderer.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */