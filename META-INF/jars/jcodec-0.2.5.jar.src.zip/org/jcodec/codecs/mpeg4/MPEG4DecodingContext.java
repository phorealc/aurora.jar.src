/*     */ package org.jcodec.codecs.mpeg4;
/*     */ 
/*     */ import java.nio.ByteBuffer;
/*     */ import java.nio.ByteOrder;
/*     */ import org.jcodec.common.io.BitReader;
/*     */ import org.jcodec.common.logging.Logger;
/*     */ import org.jcodec.common.tools.MathUtil;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class MPEG4DecodingContext
/*     */ {
/*     */   public int width;
/*     */   public int height;
/*     */   public int horiz_mc_ref;
/*     */   public int vert_mc_ref;
/*  65 */   public short[] intraMpegQuantMatrix = new short[64];
/*  66 */   public short[] interMpegQuantMatrix = new short[64]; public int mbWidth; public int mbHeight; public int spriteEnable; public int shape; public int quant; public int quantBits; public int timeIncrementBits; public int intraDCThreshold; public int spriteWarpingPoints; public boolean reducedResolutionEnable; public int fcodeForward; public int fcodeBackward; public boolean newPredEnable; public boolean rounding; public boolean quarterPel; public boolean cartoonMode;
/*  67 */   public int[][] gmcWarps = new int[3][2]; public int lastTimeBase; public int timeBase; public int time; public int lastNonBTime; public int pframeTs; public int bframeTs; public boolean topFieldFirst; public boolean alternateVerticalScan; int volVersionId; int timestampMSB; int timestampLSB; boolean complexityEstimationDisable; boolean interlacing; boolean spriteBrightnessChange; boolean scalability;
/*  68 */   Estimation estimation = new Estimation(); private static final int VIDOBJ_START_CODE = 256; private static final int VIDOBJLAY_START_CODE = 288; private static final int VISOBJSEQ_START_CODE = 432; private static final int VISOBJSEQ_STOP_CODE = 433; private static final int USERDATA_START_CODE = 434; private static final int GRPOFVOP_START_CODE = 435; private static final int VISOBJ_START_CODE = 437; private static final int VISOBJ_TYPE_VIDEO = 1; private static final int VIDOBJLAY_AR_EXTPAR = 15; private static final int VIDOBJLAY_SHAPE_RECTANGULAR = 0; private static final int VIDOBJLAY_SHAPE_BINARY = 1; private static final int VIDOBJLAY_SHAPE_BINARY_ONLY = 2; private static final int VIDOBJLAY_SHAPE_GRAYSCALE = 3; private static final int VOP_START_CODE = 438; private static final int VIDOBJ_START_CODE_MASK = 31; private static final int VIDOBJLAY_START_CODE_MASK = 15; private static final int SPRITE_STATIC = 1; private static final int SPRITE_GMC = 2; private static final int VLC_CODE = 0; private static final int VLC_LEN = 1; private int timeIncrementResolution; private boolean packedMode;
/*     */   public int codingType;
/*     */   public boolean quantType;
/*     */   
/*     */   private static class Estimation {
/*     */     public int method;
/*     */     public boolean opaque;
/*     */     public boolean transparent;
/*     */     public boolean intraCae;
/*     */     public boolean interCae;
/*     */     public boolean noUpdate;
/*     */     public boolean upsampling;
/*     */     public boolean intraBlocks;
/*     */     public boolean interBlocks;
/*     */     public boolean inter4vBlocks;
/*     */     public boolean notCodedBlocks;
/*     */     public boolean dctCoefs;
/*     */     public boolean dctLines;
/*     */     public boolean vlcSymbols;
/*     */     public boolean vlcBits;
/*     */     public boolean apm;
/*     */     public boolean npm;
/*     */     public boolean interpolateMcQ;
/*     */     public boolean forwBackMcQ;
/*     */     public boolean halfpel2;
/*     */     public boolean halfpel4;
/*     */     public boolean sadct;
/*     */     public boolean quarterpel;
/*     */     
/*     */     private Estimation() {} }
/*     */   
/*     */   public static MPEG4DecodingContext readFromHeaders(ByteBuffer bb) {
/* 100 */     MPEG4DecodingContext ret = new MPEG4DecodingContext();
/* 101 */     if (ret.readHeaders(bb))
/* 102 */       return ret; 
/* 103 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 142 */   public int bsVersion = 65535;
/*     */   
/*     */   public static void getMatrix(BitReader br, short[] matrix) {
/* 145 */     int last, value = 0;
/* 146 */     int i = 0;
/*     */     
/*     */     do {
/* 149 */       last = value;
/* 150 */       value = br.readNBit(8);
/* 151 */       matrix[MPEG4Consts.SCAN_TABLES[0][i++]] = (short)value;
/* 152 */     } while (value != 0 && i < 64);
/*     */     
/* 154 */     i--;
/*     */     
/* 156 */     while (i < 64) {
/* 157 */       matrix[MPEG4Consts.SCAN_TABLES[0][i++]] = (short)last;
/*     */     }
/*     */   }
/*     */   
/*     */   public boolean readHeaders(ByteBuffer bb) {
/* 162 */     bb.order(ByteOrder.BIG_ENDIAN);
/*     */     
/* 164 */     while (bb.remaining() >= 4) {
/* 165 */       int startCode = bb.getInt();
/* 166 */       while ((startCode & 0xFFFFFF00) != 256 && bb.hasRemaining()) {
/* 167 */         startCode <<= 8;
/* 168 */         startCode |= bb.get() & 0xFF;
/*     */       } 
/*     */       
/* 171 */       if (startCode == 432) {
/*     */ 
/*     */         
/* 174 */         byte b = bb.get(); continue;
/*     */       } 
/* 176 */       if (startCode == 433)
/* 177 */         continue;  if (startCode == 437) {
/*     */ 
/*     */         
/* 180 */         BitReader br = BitReader.createBitReader(bb);
/*     */         
/* 182 */         if (br.readBool()) {
/* 183 */           int verId = br.readNBit(4);
/*     */           
/* 185 */           br.skip(3);
/*     */         } else {
/* 187 */           int verId = 1;
/*     */         } 
/*     */         
/* 190 */         int visual_object_type = br.readNBit(4);
/* 191 */         if (visual_object_type != 1) {
/* 192 */           return false;
/*     */         }
/*     */         
/* 195 */         if (br.readBool()) {
/* 196 */           br.skip(3);
/* 197 */           br.skip(1);
/*     */           
/* 199 */           if (br.readBool()) {
/* 200 */             br.skip(8);
/* 201 */             br.skip(8);
/* 202 */             br.skip(8);
/*     */           } 
/*     */         } 
/* 205 */         br.terminate(); continue;
/* 206 */       }  if ((startCode & 0xFFFFFFE0) == 256)
/* 207 */         continue;  if ((startCode & 0xFFFFFFF0) == 288) {
/* 208 */         BitReader br = BitReader.createBitReader(bb);
/* 209 */         br.skip(1);
/*     */         
/* 211 */         br.skip(8);
/*     */         
/* 213 */         if (br.readBool()) {
/* 214 */           this.volVersionId = br.readNBit(4);
/*     */           
/* 216 */           br.skip(3);
/*     */         } else {
/* 218 */           this.volVersionId = 1;
/*     */         } 
/*     */         
/* 221 */         int aspectRatio = br.readNBit(4);
/*     */         
/* 223 */         if (aspectRatio == 15) {
/* 224 */           br.readNBit(8);
/* 225 */           br.readNBit(8);
/*     */         } 
/*     */         
/* 228 */         if (br.readBool()) {
/* 229 */           br.skip(2);
/*     */           
/* 231 */           boolean lowDelay = br.readBool();
/*     */           
/* 233 */           if (br.readBool()) {
/*     */             
/* 235 */             int bitrate = br.readNBit(15) << 15;
/* 236 */             br.skip(1);
/* 237 */             bitrate |= br.readNBit(15);
/* 238 */             br.skip(1);
/*     */             
/* 240 */             int bufferSize = br.readNBit(15) << 3;
/* 241 */             br.skip(1);
/* 242 */             bufferSize |= br.readNBit(3);
/*     */             
/* 244 */             int occupancy = br.readNBit(11) << 15;
/* 245 */             br.skip(1);
/* 246 */             occupancy |= br.readNBit(15);
/* 247 */             br.skip(1);
/*     */           } 
/*     */         } 
/*     */         
/* 251 */         this.shape = br.readNBit(2);
/*     */         
/* 253 */         if (this.shape != 0);
/*     */ 
/*     */         
/* 256 */         if (this.shape == 3 && this.volVersionId != 1) {
/* 257 */           br.skip(4);
/*     */         }
/*     */         
/* 260 */         br.skip(1);
/*     */         
/* 262 */         this.timeIncrementResolution = br.readNBit(16);
/*     */         
/* 264 */         if (this.timeIncrementResolution > 0) {
/* 265 */           this.timeIncrementBits = Math.max(MathUtil.log2(this.timeIncrementResolution - 1) + 1, 1);
/*     */         } else {
/* 267 */           this.timeIncrementBits = 1;
/*     */         } 
/*     */         
/* 270 */         br.skip(1);
/*     */         
/* 272 */         if (br.readBool()) {
/* 273 */           br.skip(this.timeIncrementBits);
/*     */         }
/*     */         
/* 276 */         if (this.shape != 2) {
/* 277 */           if (this.shape == 0) {
/* 278 */             br.skip(1);
/* 279 */             this.width = br.readNBit(13);
/* 280 */             br.skip(1);
/* 281 */             this.height = br.readNBit(13);
/* 282 */             br.skip(1);
/* 283 */             calcSizes();
/*     */           } 
/*     */           
/* 286 */           this.interlacing = br.readBool();
/*     */           
/* 288 */           if (!br.readBool());
/*     */ 
/*     */           
/* 291 */           this.spriteEnable = br.readNBit((this.volVersionId == 1) ? 1 : 2);
/*     */           
/* 293 */           if (this.spriteEnable == 1 || this.spriteEnable == 2) {
/* 294 */             if (this.spriteEnable != 2) {
/* 295 */               br.readNBit(13);
/* 296 */               br.skip(1);
/* 297 */               br.readNBit(13);
/* 298 */               br.skip(1);
/* 299 */               br.readNBit(13);
/* 300 */               br.skip(1);
/* 301 */               br.readNBit(13);
/* 302 */               br.skip(1);
/*     */             } 
/*     */             
/* 305 */             this.spriteWarpingPoints = br.readNBit(6);
/* 306 */             br.readNBit(2);
/* 307 */             this.spriteBrightnessChange = br.readBool();
/*     */             
/* 309 */             if (this.spriteEnable != 2) {
/* 310 */               br.readNBit(1);
/*     */             }
/*     */           } 
/*     */           
/* 314 */           if (this.volVersionId != 1 && this.shape != 0) {
/* 315 */             br.skip(1);
/*     */           }
/*     */           
/* 318 */           if (br.readBool()) {
/* 319 */             this.quantBits = br.readNBit(4);
/* 320 */             br.skip(4);
/*     */           } else {
/* 322 */             this.quantBits = 5;
/*     */           } 
/*     */           
/* 325 */           if (this.shape == 3) {
/* 326 */             br.skip(1);
/* 327 */             br.skip(1);
/* 328 */             br.skip(1);
/*     */           } 
/*     */           
/* 331 */           this.quantType = br.readBool();
/*     */           
/* 333 */           if (this.quantType) {
/* 334 */             if (br.readBool()) {
/* 335 */               getMatrix(br, this.intraMpegQuantMatrix);
/*     */             } else {
/* 337 */               System.arraycopy(MPEG4Consts.DEFAULT_INTRA_MATRIX, 0, this.intraMpegQuantMatrix, 0, this.intraMpegQuantMatrix.length);
/*     */             } 
/*     */ 
/*     */             
/* 341 */             if (br.readBool()) {
/* 342 */               getMatrix(br, this.interMpegQuantMatrix);
/*     */             } else {
/* 344 */               System.arraycopy(MPEG4Consts.DEFAULT_INTER_MATRIX, 0, this.interMpegQuantMatrix, 0, this.interMpegQuantMatrix.length);
/*     */             } 
/*     */ 
/*     */             
/* 348 */             if (this.shape == 3) {
/* 349 */               return false;
/*     */             }
/*     */           } 
/*     */           
/* 353 */           if (this.volVersionId != 1) {
/* 354 */             this.quarterPel = br.readBool();
/*     */           } else {
/* 356 */             this.quarterPel = false;
/*     */           } 
/*     */           
/* 359 */           this.complexityEstimationDisable = br.readBool();
/* 360 */           if (!this.complexityEstimationDisable) {
/* 361 */             readVolComplexityEstimationHeader(br, this.estimation);
/*     */           }
/*     */           
/* 364 */           br.skip(1);
/*     */           
/* 366 */           if (br.readBool()) {
/* 367 */             br.skip(1);
/*     */           }
/*     */           
/* 370 */           if (this.volVersionId != 1) {
/* 371 */             this.newPredEnable = br.readBool();
/*     */             
/* 373 */             if (this.newPredEnable) {
/* 374 */               br.skip(2);
/* 375 */               br.skip(1);
/*     */             } 
/*     */             
/* 378 */             this.reducedResolutionEnable = br.readBool();
/*     */           } else {
/* 380 */             this.newPredEnable = false;
/* 381 */             this.reducedResolutionEnable = false;
/*     */           } 
/*     */           
/* 384 */           this.scalability = br.readBool();
/*     */           
/* 386 */           if (this.scalability) {
/* 387 */             br.skip(1);
/* 388 */             br.skip(4);
/* 389 */             br.skip(1);
/* 390 */             br.skip(5);
/* 391 */             br.skip(5);
/* 392 */             br.skip(5);
/* 393 */             br.skip(5);
/* 394 */             br.skip(1);
/*     */             
/* 396 */             if (this.shape == 1) {
/* 397 */               br.skip(1);
/* 398 */               br.skip(1);
/* 399 */               br.skip(5);
/* 400 */               br.skip(5);
/* 401 */               br.skip(5);
/* 402 */               br.skip(5);
/*     */             } 
/*     */             
/* 405 */             return false;
/*     */           } 
/*     */         } else {
/* 408 */           if (this.volVersionId != 1) {
/* 409 */             this.scalability = br.readBool();
/*     */             
/* 411 */             if (this.scalability) {
/* 412 */               br.skip(4);
/* 413 */               br.skip(5);
/* 414 */               br.skip(5);
/* 415 */               br.skip(5);
/* 416 */               br.skip(5);
/*     */               
/* 418 */               return false;
/*     */             } 
/*     */           } 
/*     */           
/* 422 */           br.skip(1);
/*     */         } 
/* 424 */         br.terminate(); continue;
/* 425 */       }  if (startCode == 435) {
/* 426 */         BitReader br = BitReader.createBitReader(bb);
/*     */ 
/*     */ 
/*     */         
/* 430 */         int hours = br.readNBit(5);
/* 431 */         int minutes = br.readNBit(6);
/* 432 */         br.skip(1);
/* 433 */         int seconds = br.readNBit(6);
/*     */         
/* 435 */         br.skip(1);
/* 436 */         br.skip(1);
/* 437 */         br.terminate(); continue;
/* 438 */       }  if (startCode == 438)
/* 439 */         return true; 
/* 440 */       if (startCode == 434) {
/* 441 */         byte[] tmp = new byte[256];
/*     */         
/* 443 */         int i = 0;
/* 444 */         tmp[i++] = bb.get();
/* 445 */         for (tmp[i] = bb.get(); bb.get() != 0; i++);
/*     */         
/* 447 */         bb.position(bb.position() - 1);
/*     */         
/* 449 */         String userData = new String(tmp, 0, i);
/*     */         
/* 451 */         if (userData.startsWith("XviD")) {
/* 452 */           if (tmp[userData.length() - 1] == 67) {
/* 453 */             this.bsVersion = Integer.parseInt(userData.substring(4, userData.length() - 1));
/* 454 */             this.cartoonMode = true;
/*     */           } else {
/* 456 */             this.bsVersion = Integer.parseInt(userData.substring(4));
/*     */           } 
/*     */         }
/*     */         
/* 460 */         if (userData.startsWith("DivX")) {
/*     */ 
/*     */ 
/*     */           
/* 464 */           int buildIndex = userData.indexOf("Build");
/*     */           
/* 466 */           if (buildIndex == -1) {
/* 467 */             buildIndex = userData.indexOf("b");
/*     */           }
/*     */           
/*     */           try {
/* 471 */             int version = Integer.parseInt(userData.substring(4, buildIndex));
/* 472 */             int build = Integer.parseInt(userData.substring(buildIndex + 1, userData.length() - 1));
/* 473 */             char packed = userData.charAt(userData.length() - 1);
/* 474 */             this.packedMode = (packed == 'p');
/*     */           }
/* 476 */           catch (Exception exception) {}
/*     */         } 
/*     */         continue;
/*     */       } 
/* 480 */       Logger.debug("Unknown");
/*     */     } 
/*     */ 
/*     */     
/* 484 */     return false;
/*     */   }
/*     */   
/*     */   private void calcSizes() {
/* 488 */     this.mbWidth = (this.width + 15) / 16;
/* 489 */     this.mbHeight = (this.height + 15) / 16;
/*     */   }
/*     */   
/*     */   private void readVolComplexityEstimationHeader(BitReader br, Estimation estimation) {
/* 493 */     estimation.method = br.readNBit(2);
/*     */     
/* 495 */     if (estimation.method == 0 || estimation.method == 1) {
/* 496 */       if (!br.readBool()) {
/* 497 */         estimation.opaque = br.readBool();
/* 498 */         estimation.transparent = br.readBool();
/* 499 */         estimation.intraCae = br.readBool();
/* 500 */         estimation.interCae = br.readBool();
/* 501 */         estimation.noUpdate = br.readBool();
/* 502 */         estimation.upsampling = br.readBool();
/*     */       } 
/*     */       
/* 505 */       if (!br.readBool()) {
/* 506 */         estimation.intraBlocks = br.readBool();
/* 507 */         estimation.interBlocks = br.readBool();
/* 508 */         estimation.inter4vBlocks = br.readBool();
/* 509 */         estimation.notCodedBlocks = br.readBool();
/*     */       } 
/*     */     } 
/*     */     
/* 513 */     br.skip(1);
/*     */     
/* 515 */     if (!br.readBool()) {
/* 516 */       estimation.dctCoefs = br.readBool();
/* 517 */       estimation.dctLines = br.readBool();
/* 518 */       estimation.vlcSymbols = br.readBool();
/* 519 */       estimation.vlcBits = br.readBool();
/*     */     } 
/*     */     
/* 522 */     if (!br.readBool()) {
/* 523 */       estimation.apm = br.readBool();
/* 524 */       estimation.npm = br.readBool();
/* 525 */       estimation.interpolateMcQ = br.readBool();
/* 526 */       estimation.forwBackMcQ = br.readBool();
/* 527 */       estimation.halfpel2 = br.readBool();
/* 528 */       estimation.halfpel4 = br.readBool();
/*     */     } 
/*     */     
/* 531 */     br.skip(1);
/*     */     
/* 533 */     if (estimation.method == 1 && 
/* 534 */       !br.readBool()) {
/* 535 */       estimation.sadct = br.readBool();
/* 536 */       estimation.quarterpel = br.readBool();
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean readVOPHeader(BitReader br) {
/* 542 */     this.rounding = false;
/* 543 */     this.quant = 2;
/*     */     
/* 545 */     this.codingType = br.readNBit(2);
/*     */     
/* 547 */     while (br.readBool()) {
/* 548 */       this.timestampMSB++;
/*     */     }
/*     */     
/* 551 */     br.skip(1);
/*     */     
/* 553 */     if (getTimeIncrementBits() != 0) {
/* 554 */       this.timestampLSB = br.readNBit(getTimeIncrementBits());
/*     */     }
/*     */     
/* 557 */     br.skip(1);
/*     */     
/* 559 */     if (!br.readBool()) {
/* 560 */       return false;
/*     */     }
/*     */     
/* 563 */     if (this.newPredEnable) {
/*     */ 
/*     */ 
/*     */       
/* 567 */       int vopId = br.readNBit(Math.min(getTimeIncrementBits() + 3, 15));
/*     */       
/* 569 */       if (br.readBool()) {
/* 570 */         int i = br.readNBit(Math.min(getTimeIncrementBits() + 3, 15));
/*     */       }
/*     */       
/* 573 */       br.skip(1);
/*     */     } 
/*     */     
/* 576 */     if (this.shape != 2 && (this.codingType == 1 || (this.codingType == 3 && this.spriteEnable == 2)))
/*     */     {
/* 578 */       this.rounding = br.readBool();
/*     */     }
/*     */     
/* 581 */     if (this.reducedResolutionEnable && this.shape == 0 && (this.codingType == 1 || this.codingType == 0))
/*     */     {
/* 583 */       if (br.readBool());
/*     */     }
/*     */ 
/*     */     
/* 587 */     if (this.shape != 0) {
/* 588 */       if (this.spriteEnable != 1 || this.codingType != 0) {
/* 589 */         this.width = br.readNBit(13);
/* 590 */         br.skip(1);
/* 591 */         this.height = br.readNBit(13);
/* 592 */         br.skip(1);
/* 593 */         this.horiz_mc_ref = br.readNBit(13);
/* 594 */         br.skip(1);
/* 595 */         this.vert_mc_ref = br.readNBit(13);
/* 596 */         br.skip(1);
/* 597 */         calcSizes();
/*     */       } 
/*     */       
/* 600 */       br.skip(1);
/*     */       
/* 602 */       if (br.readBool()) {
/* 603 */         br.skip(8);
/*     */       }
/*     */     } 
/* 606 */     Estimation estimation = new Estimation();
/*     */     
/* 608 */     if (this.shape != 2) {
/* 609 */       if (!this.complexityEstimationDisable) {
/* 610 */         readVopComplexityEstimationHeader(br, estimation, this.spriteEnable, this.codingType);
/*     */       }
/*     */       
/* 613 */       this.intraDCThreshold = MPEG4Consts.INTRA_DC_THRESHOLD_TABLE[br.readNBit(3)];
/*     */       
/* 615 */       if (this.interlacing) {
/* 616 */         this.topFieldFirst = br.readBool();
/* 617 */         this.alternateVerticalScan = br.readBool();
/*     */       } 
/*     */     } 
/*     */     
/* 621 */     if ((this.spriteEnable == 1 || this.spriteEnable == 2) && this.codingType == 3) {
/* 622 */       for (int i = 0; i < this.spriteWarpingPoints; i++) {
/*     */         
/* 624 */         int x = 0, y = 0;
/*     */         
/* 626 */         int length = getSpriteTrajectory(br);
/*     */         
/* 628 */         if (length > 0) {
/* 629 */           x = br.readNBit(length);
/*     */           
/* 631 */           if (x >> length - 1 == 0) {
/* 632 */             x = -(x ^ (1 << length) - 1);
/*     */           }
/*     */         } 
/*     */         
/* 636 */         br.skip(1);
/*     */         
/* 638 */         length = getSpriteTrajectory(br);
/*     */         
/* 640 */         if (length > 0) {
/* 641 */           y = br.readNBit(length);
/*     */           
/* 643 */           if (y >> length - 1 == 0) {
/* 644 */             y = -(y ^ (1 << length) - 1);
/*     */           }
/*     */         } 
/*     */         
/* 648 */         br.skip(1);
/*     */         
/* 650 */         this.gmcWarps[i][0] = x;
/* 651 */         this.gmcWarps[i][1] = y;
/*     */       } 
/*     */       
/* 654 */       if (this.spriteBrightnessChange);
/*     */       
/* 656 */       if (this.spriteEnable == 1);
/*     */     } 
/*     */ 
/*     */ 
/*     */     
/* 661 */     if ((this.quant = br.readNBit(this.quantBits)) < 1) {
/* 662 */       this.quant = 1;
/*     */     }
/*     */     
/* 665 */     if (this.codingType != 0) {
/* 666 */       this.fcodeForward = br.readNBit(3);
/*     */     }
/*     */     
/* 669 */     if (this.codingType == 2) {
/* 670 */       this.fcodeBackward = br.readNBit(3);
/*     */     }
/*     */     
/* 673 */     if (!this.scalability && 
/* 674 */       this.shape != 0 && this.codingType != 0) {
/* 675 */       br.skip(1);
/*     */     }
/*     */ 
/*     */     
/* 679 */     if (this.codingType != 2) {
/* 680 */       this.lastTimeBase = this.timeBase;
/* 681 */       this.timeBase += this.timestampMSB;
/* 682 */       this.time = this.timeBase * getTimeIncrementResolution() + this.timestampLSB;
/* 683 */       this.pframeTs = this.time - this.lastNonBTime;
/* 684 */       this.lastNonBTime = this.time;
/*     */     } else {
/* 686 */       this.time = (this.lastTimeBase + this.timestampMSB) * getTimeIncrementResolution() + this.timestampLSB;
/* 687 */       this.bframeTs = this.pframeTs - this.lastNonBTime - this.time;
/*     */     } 
/* 689 */     return true;
/*     */   }
/*     */   
/*     */   private int getSpriteTrajectory(BitReader br) {
/* 693 */     for (int i = 0; i < 12; i++) {
/* 694 */       if (br.checkNBit(MPEG4Consts.SPRITE_TRAJECTORY_LEN[i][1]) == MPEG4Consts.SPRITE_TRAJECTORY_LEN[i][0]) {
/* 695 */         br.skip(MPEG4Consts.SPRITE_TRAJECTORY_LEN[i][1]);
/* 696 */         return i;
/*     */       } 
/*     */     } 
/*     */     
/* 700 */     return -1;
/*     */   }
/*     */ 
/*     */   
/*     */   private void readVopComplexityEstimationHeader(BitReader br, Estimation estimation, int spriteEnable, int codingType) {
/* 705 */     if (estimation.method == 0 || estimation.method == 1) {
/* 706 */       if (codingType == 0) {
/* 707 */         if (estimation.opaque)
/* 708 */           br.skip(8); 
/* 709 */         if (estimation.transparent)
/* 710 */           br.skip(8); 
/* 711 */         if (estimation.intraCae)
/* 712 */           br.skip(8); 
/* 713 */         if (estimation.interCae)
/* 714 */           br.skip(8); 
/* 715 */         if (estimation.noUpdate)
/* 716 */           br.skip(8); 
/* 717 */         if (estimation.upsampling)
/* 718 */           br.skip(8); 
/* 719 */         if (estimation.intraBlocks)
/* 720 */           br.skip(8); 
/* 721 */         if (estimation.notCodedBlocks)
/* 722 */           br.skip(8); 
/* 723 */         if (estimation.dctCoefs)
/* 724 */           br.skip(8); 
/* 725 */         if (estimation.dctLines)
/* 726 */           br.skip(8); 
/* 727 */         if (estimation.vlcSymbols)
/* 728 */           br.skip(8); 
/* 729 */         if (estimation.vlcBits)
/* 730 */           br.skip(8); 
/* 731 */         if (estimation.sadct) {
/* 732 */           br.skip(8);
/*     */         }
/*     */       } 
/* 735 */       if (codingType == 1) {
/* 736 */         if (estimation.opaque)
/* 737 */           br.skip(8); 
/* 738 */         if (estimation.transparent)
/* 739 */           br.skip(8); 
/* 740 */         if (estimation.intraCae)
/* 741 */           br.skip(8); 
/* 742 */         if (estimation.interCae)
/* 743 */           br.skip(8); 
/* 744 */         if (estimation.noUpdate)
/* 745 */           br.skip(8); 
/* 746 */         if (estimation.upsampling)
/* 747 */           br.skip(8); 
/* 748 */         if (estimation.intraBlocks)
/* 749 */           br.skip(8); 
/* 750 */         if (estimation.notCodedBlocks)
/* 751 */           br.skip(8); 
/* 752 */         if (estimation.dctCoefs)
/* 753 */           br.skip(8); 
/* 754 */         if (estimation.dctLines)
/* 755 */           br.skip(8); 
/* 756 */         if (estimation.vlcSymbols)
/* 757 */           br.skip(8); 
/* 758 */         if (estimation.vlcBits)
/* 759 */           br.skip(8); 
/* 760 */         if (estimation.interBlocks)
/* 761 */           br.skip(8); 
/* 762 */         if (estimation.inter4vBlocks)
/* 763 */           br.skip(8); 
/* 764 */         if (estimation.apm)
/* 765 */           br.skip(8); 
/* 766 */         if (estimation.npm)
/* 767 */           br.skip(8); 
/* 768 */         if (estimation.forwBackMcQ)
/* 769 */           br.skip(8); 
/* 770 */         if (estimation.halfpel2)
/* 771 */           br.skip(8); 
/* 772 */         if (estimation.halfpel4)
/* 773 */           br.skip(8); 
/* 774 */         if (estimation.sadct)
/* 775 */           br.skip(8); 
/* 776 */         if (estimation.quarterpel) {
/* 777 */           br.skip(8);
/*     */         }
/*     */       } 
/* 780 */       if (codingType == 2) {
/* 781 */         if (estimation.opaque)
/* 782 */           br.skip(8); 
/* 783 */         if (estimation.transparent)
/* 784 */           br.skip(8); 
/* 785 */         if (estimation.intraCae)
/* 786 */           br.skip(8); 
/* 787 */         if (estimation.interCae)
/* 788 */           br.skip(8); 
/* 789 */         if (estimation.noUpdate)
/* 790 */           br.skip(8); 
/* 791 */         if (estimation.upsampling)
/* 792 */           br.skip(8); 
/* 793 */         if (estimation.intraBlocks)
/* 794 */           br.skip(8); 
/* 795 */         if (estimation.notCodedBlocks)
/* 796 */           br.skip(8); 
/* 797 */         if (estimation.dctCoefs)
/* 798 */           br.skip(8); 
/* 799 */         if (estimation.dctLines)
/* 800 */           br.skip(8); 
/* 801 */         if (estimation.vlcSymbols)
/* 802 */           br.skip(8); 
/* 803 */         if (estimation.vlcBits)
/* 804 */           br.skip(8); 
/* 805 */         if (estimation.interBlocks)
/* 806 */           br.skip(8); 
/* 807 */         if (estimation.inter4vBlocks)
/* 808 */           br.skip(8); 
/* 809 */         if (estimation.apm)
/* 810 */           br.skip(8); 
/* 811 */         if (estimation.npm)
/* 812 */           br.skip(8); 
/* 813 */         if (estimation.forwBackMcQ)
/* 814 */           br.skip(8); 
/* 815 */         if (estimation.halfpel2)
/* 816 */           br.skip(8); 
/* 817 */         if (estimation.halfpel4)
/* 818 */           br.skip(8); 
/* 819 */         if (estimation.interpolateMcQ)
/* 820 */           br.skip(8); 
/* 821 */         if (estimation.sadct)
/* 822 */           br.skip(8); 
/* 823 */         if (estimation.quarterpel) {
/* 824 */           br.skip(8);
/*     */         }
/*     */       } 
/* 827 */       if (codingType == 3 && spriteEnable == 1) {
/* 828 */         if (estimation.intraBlocks)
/* 829 */           br.skip(8); 
/* 830 */         if (estimation.notCodedBlocks)
/* 831 */           br.skip(8); 
/* 832 */         if (estimation.dctCoefs)
/* 833 */           br.skip(8); 
/* 834 */         if (estimation.dctLines)
/* 835 */           br.skip(8); 
/* 836 */         if (estimation.vlcSymbols)
/* 837 */           br.skip(8); 
/* 838 */         if (estimation.vlcBits)
/* 839 */           br.skip(8); 
/* 840 */         if (estimation.interBlocks)
/* 841 */           br.skip(8); 
/* 842 */         if (estimation.inter4vBlocks)
/* 843 */           br.skip(8); 
/* 844 */         if (estimation.apm)
/* 845 */           br.skip(8); 
/* 846 */         if (estimation.npm)
/* 847 */           br.skip(8); 
/* 848 */         if (estimation.forwBackMcQ)
/* 849 */           br.skip(8); 
/* 850 */         if (estimation.halfpel2)
/* 851 */           br.skip(8); 
/* 852 */         if (estimation.halfpel4)
/* 853 */           br.skip(8); 
/* 854 */         if (estimation.interpolateMcQ)
/* 855 */           br.skip(8); 
/*     */       } 
/*     */     } 
/*     */   }
/*     */   
/*     */   public boolean getPackedMode() {
/* 861 */     return this.packedMode;
/*     */   }
/*     */   
/*     */   public int getTimeIncrementBits() {
/* 865 */     return this.timeIncrementBits;
/*     */   }
/*     */   
/*     */   public int getTimeIncrementResolution() {
/* 869 */     return this.timeIncrementResolution;
/*     */   }
/*     */ }


/* Location:              C:\Users\rapha\Downloads\aurora.jar!\META-INF\jars\jcodec-0.2.5.jar!\org\jcodec\codecs\mpeg4\MPEG4DecodingContext.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */