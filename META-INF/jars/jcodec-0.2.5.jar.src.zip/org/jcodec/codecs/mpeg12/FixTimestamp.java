/*     */ package org.jcodec.codecs.mpeg12;
/*     */ 
/*     */ import java.io.File;
/*     */ import java.io.IOException;
/*     */ import java.io.RandomAccessFile;
/*     */ import java.nio.ByteBuffer;
/*     */ import org.jcodec.common.io.FileChannelWrapper;
/*     */ import org.jcodec.common.io.SeekableByteChannel;
/*     */ import org.jcodec.containers.mps.MTSUtils;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class FixTimestamp
/*     */ {
/*     */   public void fix(File file) throws IOException {
/*  21 */     RandomAccessFile ra = null;
/*     */     try {
/*  23 */       ra = new RandomAccessFile(file, "rw");
/*  24 */       FileChannelWrapper fileChannelWrapper = new FileChannelWrapper(ra.getChannel());
/*  25 */       final FixTimestamp self = this;
/*  26 */       (new MTSUtils.TSReader(true)
/*     */         {
/*     */           public boolean onPkt(int guid, boolean payloadStart, ByteBuffer bb, long filePos, boolean sectionSyntax, ByteBuffer fullPkt)
/*     */           {
/*  30 */             return self.processPacket(payloadStart, bb, sectionSyntax, fullPkt);
/*     */           }
/*  32 */         }).readTsFile((SeekableByteChannel)fileChannelWrapper);
/*     */     } finally {
/*  34 */       if (ra != null)
/*  35 */         ra.close(); 
/*     */     } 
/*     */   }
/*     */   
/*     */   private boolean processPacket(boolean payloadStart, ByteBuffer bb, boolean sectionSyntax, ByteBuffer fullPkt) {
/*  40 */     if (!payloadStart || sectionSyntax) {
/*  41 */       return true;
/*     */     }
/*  43 */     int streamId = bb.getInt();
/*  44 */     if (streamId == 445 || (streamId >= 448 && streamId < 495)) {
/*  45 */       int len = bb.getShort();
/*  46 */       int b0 = bb.get() & 0xFF;
/*     */       
/*  48 */       bb.position(bb.position() - 1);
/*  49 */       if ((b0 & 0xC0) == 128) {
/*  50 */         fixMpeg2(streamId & 0xFF, bb);
/*     */       } else {
/*  52 */         fixMpeg1(streamId & 0xFF, bb);
/*     */       } 
/*     */     } 
/*  55 */     return true;
/*     */   }
/*     */   
/*     */   public void fixMpeg1(int streamId, ByteBuffer is) {
/*  59 */     int c = is.getInt() & 0xFF;
/*  60 */     while (c == 255) {
/*  61 */       c = is.get() & 0xFF;
/*     */     }
/*     */     
/*  64 */     if ((c & 0xC0) == 64) {
/*  65 */       is.get();
/*  66 */       c = is.get() & 0xFF;
/*     */     } 
/*  68 */     if ((c & 0xF0) == 32) {
/*  69 */       is.position(is.position() - 1);
/*  70 */       fixTs(streamId, is, true);
/*  71 */     } else if ((c & 0xF0) == 48) {
/*  72 */       is.position(is.position() - 1);
/*  73 */       fixTs(streamId, is, true);
/*  74 */       fixTs(streamId, is, false);
/*     */     }
/*  76 */     else if (c != 15) {
/*  77 */       throw new RuntimeException("Invalid data");
/*     */     } 
/*     */   }
/*     */   
/*     */   public long fixTs(int streamId, ByteBuffer is, boolean isPts) {
/*  82 */     byte b0 = is.get();
/*  83 */     byte b1 = is.get();
/*  84 */     byte b2 = is.get();
/*  85 */     byte b3 = is.get();
/*  86 */     byte b4 = is.get();
/*     */     
/*  88 */     long pts = (b0 & 0xEL) << 29L | ((b1 & 0xFF) << 22) | ((b2 & 0xFF) >> 1 << 15) | ((b3 & 0xFF) << 7) | ((b4 & 0xFF) >> 1);
/*     */ 
/*     */     
/*  91 */     pts = doWithTimestamp(streamId, pts, isPts);
/*     */     
/*  93 */     is.position(is.position() - 5);
/*     */     
/*  95 */     is.put((byte)(int)((b0 & 0xF0) | pts >>> 29L | 0x1L));
/*  96 */     is.put((byte)(int)(pts >>> 22L));
/*  97 */     is.put((byte)(int)(pts >>> 14L | 0x1L));
/*  98 */     is.put((byte)(int)(pts >>> 7L));
/*  99 */     is.put((byte)(int)(pts << 1L | 0x1L));
/*     */     
/* 101 */     return pts;
/*     */   }
/*     */   
/*     */   public void fixMpeg2(int streamId, ByteBuffer is) {
/* 105 */     int flags1 = is.get() & 0xFF;
/* 106 */     int flags2 = is.get() & 0xFF;
/* 107 */     int header_len = is.get() & 0xFF;
/*     */     
/* 109 */     if ((flags2 & 0xC0) == 128) {
/* 110 */       fixTs(streamId, is, true);
/* 111 */     } else if ((flags2 & 0xC0) == 192) {
/* 112 */       fixTs(streamId, is, true);
/* 113 */       fixTs(streamId, is, false);
/*     */     } 
/*     */   }
/*     */   
/*     */   public boolean isVideo(int streamId) {
/* 118 */     return (streamId >= 224 && streamId <= 239);
/*     */   }
/*     */   
/*     */   public boolean isAudio(int streamId) {
/* 122 */     return (streamId >= 191 && streamId <= 223);
/*     */   }
/*     */   
/*     */   protected abstract long doWithTimestamp(int paramInt, long paramLong, boolean paramBoolean);
/*     */ }


/* Location:              C:\Users\rapha\Downloads\aurora.jar!\META-INF\jars\jcodec-0.2.5.jar!\org\jcodec\codecs\mpeg12\FixTimestamp.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */