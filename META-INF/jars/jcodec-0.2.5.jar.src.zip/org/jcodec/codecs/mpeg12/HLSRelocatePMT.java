/*     */ package org.jcodec.codecs.mpeg12;
/*     */ 
/*     */ import java.io.Closeable;
/*     */ import java.io.File;
/*     */ import java.io.IOException;
/*     */ import java.nio.ByteBuffer;
/*     */ import java.nio.channels.ReadableByteChannel;
/*     */ import java.nio.channels.WritableByteChannel;
/*     */ import java.util.ArrayList;
/*     */ import java.util.HashSet;
/*     */ import java.util.List;
/*     */ import java.util.Set;
/*     */ import org.jcodec.common.Preconditions;
/*     */ import org.jcodec.common.io.FileChannelWrapper;
/*     */ import org.jcodec.common.io.NIOUtils;
/*     */ import org.jcodec.common.tools.MainUtils;
/*     */ import org.jcodec.containers.mps.psi.PATSection;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class HLSRelocatePMT
/*     */ {
/*     */   private static final int TS_START_CODE = 71;
/*     */   private static final int CHUNK_SIZE_PKT = 1024;
/*     */   private static final int TS_PKT_SIZE = 188;
/*     */   
/*     */   public static void main1(String[] args) throws IOException {
/*     */     FileChannelWrapper fileChannelWrapper1, fileChannelWrapper2;
/*  37 */     MainUtils.Cmd cmd = MainUtils.parseArguments(args, new MainUtils.Flag[0]);
/*  38 */     if (cmd.args.length < 2) {
/*  39 */       MainUtils.printHelpNoFlags(new String[] { "file _in", "file out" });
/*     */       
/*     */       return;
/*     */     } 
/*  43 */     ReadableByteChannel _in = null;
/*  44 */     WritableByteChannel out = null;
/*     */     try {
/*  46 */       fileChannelWrapper1 = NIOUtils.readableChannel(new File(cmd.args[0]));
/*  47 */       fileChannelWrapper2 = NIOUtils.writableChannel(new File(cmd.args[1]));
/*  48 */       System.err.println("Processed: " + replocatePMT((ReadableByteChannel)fileChannelWrapper1, (WritableByteChannel)fileChannelWrapper2) + " packets.");
/*     */     } finally {
/*  50 */       NIOUtils.closeQuietly((Closeable)fileChannelWrapper1);
/*  51 */       NIOUtils.closeQuietly((Closeable)fileChannelWrapper2);
/*     */     } 
/*     */   }
/*     */   
/*     */   private static int replocatePMT(ReadableByteChannel _in, WritableByteChannel out) throws IOException {
/*  56 */     ByteBuffer buf = ByteBuffer.allocate(192512);
/*  57 */     Set<Integer> pmtPids = new HashSet<Integer>();
/*  58 */     List<ByteBuffer> held = new ArrayList<ByteBuffer>();
/*  59 */     ByteBuffer patPkt = null;
/*  60 */     ByteBuffer pmtPkt = null;
/*     */     
/*  62 */     int totalPkt = 0;
/*  63 */     while (_in.read(buf) != -1) {
/*  64 */       buf.flip();
/*  65 */       buf.limit(buf.limit() / 188 * 188);
/*     */       
/*  67 */       while (buf.hasRemaining()) {
/*  68 */         ByteBuffer pkt = NIOUtils.read(buf, 188);
/*  69 */         ByteBuffer pktRead = pkt.duplicate();
/*  70 */         Preconditions.checkState((71 == (pktRead.get() & 0xFF)));
/*  71 */         totalPkt++;
/*  72 */         int guidFlags = (pktRead.get() & 0xFF) << 8 | pktRead.get() & 0xFF;
/*  73 */         int guid = guidFlags & 0x1FFF;
/*  74 */         int payloadStart = guidFlags >> 14 & 0x1;
/*  75 */         int b0 = pktRead.get() & 0xFF;
/*  76 */         int counter = b0 & 0xF;
/*  77 */         if ((b0 & 0x20) != 0) {
/*  78 */           NIOUtils.skip(pktRead, pktRead.get() & 0xFF);
/*     */         }
/*     */         
/*  81 */         if (guid == 0 || pmtPids.contains(Integer.valueOf(guid))) {
/*  82 */           if (payloadStart == 1) {
/*  83 */             NIOUtils.skip(pktRead, pktRead.get() & 0xFF);
/*     */           }
/*     */           
/*  86 */           if (guid == 0) {
/*  87 */             patPkt = pkt;
/*  88 */             PATSection pat = PATSection.parsePAT(pktRead);
/*  89 */             int[] values = pat.getPrograms().values();
/*  90 */             for (int i = 0; i < values.length; i++) {
/*  91 */               int pmtPid = values[i];
/*  92 */               pmtPids.add(Integer.valueOf(pmtPid));
/*     */             }  continue;
/*  94 */           }  if (pmtPids.contains(Integer.valueOf(guid))) {
/*  95 */             pmtPkt = pkt;
/*  96 */             out.write(patPkt);
/*  97 */             out.write(pmtPkt);
/*  98 */             for (ByteBuffer heldPkt : held) {
/*  99 */               out.write(heldPkt);
/*     */             }
/* 101 */             held.clear();
/*     */           }  continue;
/*     */         } 
/* 104 */         if (pmtPkt == null) {
/* 105 */           held.add(pkt); continue;
/*     */         } 
/* 107 */         out.write(pkt);
/*     */       } 
/*     */       
/* 110 */       buf.clear();
/*     */     } 
/* 112 */     return totalPkt;
/*     */   }
/*     */ }


/* Location:              C:\Users\rapha\Downloads\aurora.jar!\META-INF\jars\jcodec-0.2.5.jar!\org\jcodec\codecs\mpeg12\HLSRelocatePMT.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */