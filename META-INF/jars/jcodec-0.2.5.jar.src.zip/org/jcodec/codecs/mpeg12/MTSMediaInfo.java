/*     */ package org.jcodec.codecs.mpeg12;
/*     */ 
/*     */ import java.io.Closeable;
/*     */ import java.io.File;
/*     */ import java.io.IOException;
/*     */ import java.nio.ByteBuffer;
/*     */ import java.util.ArrayList;
/*     */ import java.util.HashMap;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import org.jcodec.common.io.FileChannelWrapper;
/*     */ import org.jcodec.common.io.NIOUtils;
/*     */ import org.jcodec.common.io.SeekableByteChannel;
/*     */ import org.jcodec.containers.mps.MTSUtils;
/*     */ import org.jcodec.containers.mps.psi.PMTSection;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class MTSMediaInfo
/*     */ {
/*     */   public List<MPSMediaInfo.MPEGTrackMetadata> getMediaInfo(File f) throws IOException {
/*  32 */     FileChannelWrapper ch = null;
/*  33 */     final List<PMTSection> pmtSections = new ArrayList<PMTSection>();
/*  34 */     final Map<Integer, MPSMediaInfo> pids = new HashMap<Integer, MPSMediaInfo>();
/*  35 */     final List<MPSMediaInfo.MPEGTrackMetadata> result = new ArrayList<MPSMediaInfo.MPEGTrackMetadata>();
/*     */     try {
/*  37 */       ch = NIOUtils.readableChannel(f);
/*  38 */       (new MTSUtils.TSReader(false) {
/*     */           private ByteBuffer pmtBuffer;
/*  40 */           private int pmtPid = -1;
/*     */           
/*     */           private boolean pmtDone;
/*     */ 
/*     */           
/*     */           protected boolean onPkt(int guid, boolean payloadStart, ByteBuffer tsBuf, long filePos, boolean sectionSyntax, ByteBuffer fullPkt) {
/*  46 */             if (guid == 0) {
/*  47 */               this.pmtPid = MTSUtils.parsePAT(tsBuf);
/*  48 */             } else if (guid == this.pmtPid && !this.pmtDone) {
/*  49 */               if (this.pmtBuffer == null) {
/*  50 */                 this.pmtBuffer = ByteBuffer.allocate((tsBuf.duplicate().getInt() >> 8 & 0x3FF) + 3);
/*  51 */               } else if (this.pmtBuffer.hasRemaining()) {
/*  52 */                 NIOUtils.writeL(this.pmtBuffer, tsBuf, Math.min(this.pmtBuffer.remaining(), tsBuf.remaining()));
/*     */               } 
/*     */               
/*  55 */               if (!this.pmtBuffer.hasRemaining()) {
/*  56 */                 this.pmtBuffer.flip();
/*  57 */                 PMTSection pmt = MTSUtils.parsePMT(this.pmtBuffer);
/*  58 */                 pmtSections.add(pmt);
/*  59 */                 PMTSection.PMTStream[] streams = pmt.getStreams();
/*  60 */                 for (int i = 0; i < streams.length; i++) {
/*  61 */                   PMTSection.PMTStream stream = streams[i];
/*  62 */                   if (!pids.containsKey(Integer.valueOf(stream.getPid())))
/*  63 */                     pids.put(Integer.valueOf(stream.getPid()), new MPSMediaInfo()); 
/*     */                 } 
/*  65 */                 this.pmtDone = (pmt.getSectionNumber() == pmt.getLastSectionNumber());
/*  66 */                 this.pmtBuffer = null;
/*     */               } 
/*  68 */             } else if (pids.containsKey(Integer.valueOf(guid))) {
/*     */               try {
/*  70 */                 ((MPSMediaInfo)pids.get(Integer.valueOf(guid))).analyseBuffer(tsBuf, filePos);
/*  71 */               } catch (MediaInfoDone e) {
/*  72 */                 result.addAll(((MPSMediaInfo)pids.get(Integer.valueOf(guid))).getInfos());
/*  73 */                 pids.remove(Integer.valueOf(guid));
/*  74 */                 if (pids.size() == 0)
/*  75 */                   return false; 
/*     */               } 
/*     */             } 
/*  78 */             return true;
/*     */           }
/*  80 */         }).readTsFile((SeekableByteChannel)ch);
/*     */     } finally {
/*  82 */       NIOUtils.closeQuietly((Closeable)ch);
/*     */     } 
/*     */     
/*  85 */     return result;
/*     */   }
/*     */   
/*     */   public static void main1(String[] args) throws IOException {
/*  89 */     List<MPSMediaInfo.MPEGTrackMetadata> info = (new MTSMediaInfo()).getMediaInfo(new File(args[0]));
/*  90 */     for (MPSMediaInfo.MPEGTrackMetadata stream : info) {
/*  91 */       System.out.println(stream.codec);
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   public static MTSMediaInfo extract(SeekableByteChannel input) {
/*  97 */     return null;
/*     */   }
/*     */ 
/*     */   
/*     */   public MPSMediaInfo.MPEGTrackMetadata getVideoTrack() {
/* 102 */     return null;
/*     */   }
/*     */ 
/*     */   
/*     */   public List<MPSMediaInfo.MPEGTrackMetadata> getAudioTracks() {
/* 107 */     return null;
/*     */   }
/*     */ }


/* Location:              C:\Users\rapha\Downloads\aurora.jar!\META-INF\jars\jcodec-0.2.5.jar!\org\jcodec\codecs\mpeg12\MTSMediaInfo.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */