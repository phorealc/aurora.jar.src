/*    */ package org.jcodec.codecs.mpeg12;
/*    */ 
/*    */ import java.io.File;
/*    */ import java.io.IOException;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class SetBaseTimestamp
/*    */   extends FixTimestamp
/*    */ {
/*    */   private int baseTs;
/* 14 */   private long firstPts = -1L;
/*    */   private boolean video;
/*    */   
/*    */   public SetBaseTimestamp(boolean video, int baseTs) {
/* 18 */     this.video = video;
/* 19 */     this.baseTs = baseTs;
/*    */   }
/*    */   
/*    */   public static void main1(String[] args) throws IOException {
/* 23 */     File file = new File(args[0]);
/* 24 */     (new SetBaseTimestamp("video".equalsIgnoreCase(args[1]), Integer.parseInt(args[2]))).fix(file);
/*    */   }
/*    */   
/*    */   protected long doWithTimestamp(int streamId, long pts, boolean isPts) {
/* 28 */     if ((this.video && isVideo(streamId)) || (!this.video && isAudio(streamId))) {
/* 29 */       if (this.firstPts == -1L) {
/* 30 */         this.firstPts = pts;
/*    */       }
/* 32 */       return pts - this.firstPts + this.baseTs;
/*    */     } 
/* 34 */     return pts;
/*    */   }
/*    */ }


/* Location:              C:\Users\rapha\Downloads\aurora.jar!\META-INF\jars\jcodec-0.2.5.jar!\org\jcodec\codecs\mpeg12\SetBaseTimestamp.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */