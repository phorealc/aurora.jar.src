/*     */ package org.jcodec.codecs.mpeg12;
/*     */ 
/*     */ import java.util.Arrays;
/*     */ import org.jcodec.codecs.mpeg12.bitstream.PictureHeader;
/*     */ import org.jcodec.codecs.mpeg12.bitstream.SequenceHeader;
/*     */ import org.jcodec.common.dct.IDCT4x4;
/*     */ import org.jcodec.common.io.BitReader;
/*     */ import org.jcodec.common.io.VLC;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class Mpeg2Thumb4x4
/*     */   extends MPEGDecoder
/*     */ {
/*     */   private MPEGPred localPred;
/*     */   private MPEGPred oldPred;
/*     */   
/*     */   protected void blockIntra(BitReader bits, VLC vlcCoeff, int[] block, int[] intra_dc_predictor, int blkIdx, int[] scan, int escSize, int intra_dc_mult, int qScale, int[] qmat) {
/*  33 */     int cc = MPEGConst.BLOCK_TO_CC[blkIdx];
/*  34 */     int size = ((cc == 0) ? MPEGConst.vlcDCSizeLuma : MPEGConst.vlcDCSizeChroma).readVLC(bits);
/*  35 */     int delta = (size != 0) ? mpegSigned(bits, size) : 0;
/*  36 */     intra_dc_predictor[cc] = intra_dc_predictor[cc] + delta;
/*  37 */     Arrays.fill(block, 1, 16, 0);
/*  38 */     block[0] = intra_dc_predictor[cc] * intra_dc_mult;
/*     */     
/*  40 */     int readVLC = 0; int idx;
/*  41 */     for (idx = 0; idx < 19 + ((scan == scan4x4[1]) ? 7 : 0); ) {
/*  42 */       int level; readVLC = vlcCoeff.readVLC(bits);
/*     */ 
/*     */       
/*  45 */       if (readVLC == 2048)
/*     */         break; 
/*  47 */       if (readVLC == 2049) {
/*  48 */         idx += bits.readNBit(6) + 1;
/*  49 */         level = twosSigned(bits, escSize) * qScale * qmat[idx];
/*  50 */         level = (level >= 0) ? (level >> 4) : -(-level >> 4);
/*     */       } else {
/*  52 */         idx += (readVLC >> 6) + 1;
/*  53 */         level = toSigned((readVLC & 0x3F) * qScale * qmat[idx] >> 4, bits.read1Bit());
/*     */       } 
/*  55 */       block[scan[idx]] = level;
/*     */     } 
/*  57 */     if (readVLC != 2048)
/*  58 */       finishOff(bits, idx, vlcCoeff, escSize); 
/*  59 */     IDCT4x4.idct(block, 0);
/*     */   }
/*     */   
/*     */   private void finishOff(BitReader bits, int idx, VLC vlcCoeff, int escSize) {
/*  63 */     while (idx < 64) {
/*  64 */       int readVLC = vlcCoeff.readVLC(bits);
/*     */       
/*  66 */       if (readVLC == 2048)
/*     */         break; 
/*  68 */       if (readVLC == 2049) {
/*  69 */         idx += bits.readNBit(6) + 1;
/*  70 */         bits.readNBit(escSize); continue;
/*     */       } 
/*  72 */       bits.read1Bit();
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   protected void blockInter(BitReader bits, VLC vlcCoeff, int[] block, int[] scan, int escSize, int qScale, int[] qmat) {
/*  78 */     Arrays.fill(block, 1, 16, 0);
/*     */     
/*  80 */     int idx = -1;
/*  81 */     if (vlcCoeff == MPEGConst.vlcCoeff0 && bits.checkNBit(1) == 1) {
/*  82 */       bits.read1Bit();
/*  83 */       block[0] = toSigned(quantInter(1, qScale * qmat[0]), bits.read1Bit());
/*  84 */       idx++;
/*     */     } else {
/*  86 */       block[0] = 0;
/*     */     } 
/*     */     
/*  89 */     int readVLC = 0;
/*  90 */     while (idx < 19 + ((scan == scan4x4[1]) ? 7 : 0)) {
/*  91 */       int ac; readVLC = vlcCoeff.readVLC(bits);
/*     */       
/*  93 */       if (readVLC == 2048)
/*     */         break; 
/*  95 */       if (readVLC == 2049) {
/*  96 */         idx += bits.readNBit(6) + 1;
/*  97 */         ac = quantInterSigned(twosSigned(bits, escSize), qScale * qmat[idx]);
/*     */       } else {
/*  99 */         idx += (readVLC >> 6) + 1;
/* 100 */         ac = toSigned(quantInter(readVLC & 0x3F, qScale * qmat[idx]), bits.read1Bit());
/*     */       } 
/* 102 */       block[scan[idx]] = ac;
/*     */     } 
/* 104 */     if (readVLC != 2048)
/* 105 */       finishOff(bits, idx, vlcCoeff, escSize); 
/* 106 */     IDCT4x4.idct(block, 0);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public int decodeMacroblock(PictureHeader ph, MPEGDecoder.Context context, int prevAddr, int[] qScaleCode, byte[][] buf, int stride, BitReader bits, int vertOff, int vertStep, MPEGPred pred) {
/* 112 */     if (this.localPred == null || this.oldPred != pred) {
/* 113 */       this.localPred = new MPEGPredDbl(pred);
/* 114 */       this.oldPred = pred;
/*     */     } 
/*     */     
/* 117 */     return super.decodeMacroblock(ph, context, prevAddr, qScaleCode, buf, stride, bits, vertOff, vertStep, this.localPred);
/*     */   }
/*     */ 
/*     */   
/* 121 */   public static int[] BLOCK_POS_X = new int[] { 0, 4, 0, 4, 0, 0, 0, 0, 4, 4, 4, 4, 0, 0, 0, 0, 0, 4, 0, 4, 0, 0, 0, 0, 4, 4, 4, 4 };
/*     */   
/* 123 */   public static int[] BLOCK_POS_Y = new int[] { 0, 0, 4, 4, 0, 0, 4, 4, 0, 0, 4, 4, 0, 0, 0, 0, 0, 0, 1, 1, 0, 0, 1, 1, 0, 0, 1, 1 };
/*     */ 
/*     */   
/*     */   protected void mapBlock(int[] block, int[] out, int blkIdx, int dctType, int chromaFormat) {
/* 127 */     int stepVert = (chromaFormat == 1 && (blkIdx == 4 || blkIdx == 5)) ? 0 : dctType;
/* 128 */     int log2stride = (blkIdx < 4) ? 3 : (3 - MPEGConst.SQUEEZE_X[chromaFormat]);
/*     */     
/* 130 */     int blkIdxExt = blkIdx + (dctType << 4);
/* 131 */     int x = BLOCK_POS_X[blkIdxExt];
/* 132 */     int y = BLOCK_POS_Y[blkIdxExt];
/* 133 */     int off = (y << log2stride) + x, stride = 1 << log2stride + stepVert;
/*     */     
/* 135 */     for (int i = 0; i < 16; i += 4, off += stride) {
/* 136 */       out[off] = out[off] + block[i];
/* 137 */       out[off + 1] = out[off + 1] + block[i + 1];
/* 138 */       out[off + 2] = out[off + 2] + block[i + 2];
/* 139 */       out[off + 3] = out[off + 3] + block[i + 3];
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   protected void put(int[][] mbPix, byte[][] buf, int stride, int chromaFormat, int mbX, int mbY, int width, int height, int vertOff, int vertStep) {
/* 146 */     int chromaStride = stride + (1 << MPEGConst.SQUEEZE_X[chromaFormat]) - 1 >> MPEGConst.SQUEEZE_X[chromaFormat];
/* 147 */     int chromaMBW = 3 - MPEGConst.SQUEEZE_X[chromaFormat];
/* 148 */     int chromaMBH = 3 - MPEGConst.SQUEEZE_Y[chromaFormat];
/*     */     
/* 150 */     putSub(buf[0], (mbY << 3) * (stride << vertStep) + vertOff * stride + (mbX << 3), stride << vertStep, mbPix[0], 3, 3);
/*     */     
/* 152 */     putSub(buf[1], (mbY << chromaMBH) * (chromaStride << vertStep) + vertOff * chromaStride + (mbX << chromaMBW), chromaStride << vertStep, mbPix[1], chromaMBW, chromaMBH);
/*     */     
/* 154 */     putSub(buf[2], (mbY << chromaMBH) * (chromaStride << vertStep) + vertOff * chromaStride + (mbX << chromaMBW), chromaStride << vertStep, mbPix[2], chromaMBW, chromaMBH);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   protected void putSub(byte[] big, int off, int stride, int[] block, int mbW, int mbH) {
/* 160 */     int blOff = 0;
/*     */     
/* 162 */     if (mbW == 2) {
/* 163 */       for (int i = 0; i < 1 << mbH; i++) {
/* 164 */         big[off] = clipTo8Bit(block[blOff]);
/* 165 */         big[off + 1] = clipTo8Bit(block[blOff + 1]);
/* 166 */         big[off + 2] = clipTo8Bit(block[blOff + 2]);
/* 167 */         big[off + 3] = clipTo8Bit(block[blOff + 3]);
/*     */         
/* 169 */         blOff += 4;
/* 170 */         off += stride;
/*     */       } 
/*     */     } else {
/* 173 */       for (int i = 0; i < 1 << mbH; i++) {
/* 174 */         big[off] = clipTo8Bit(block[blOff]);
/* 175 */         big[off + 1] = clipTo8Bit(block[blOff + 1]);
/* 176 */         big[off + 2] = clipTo8Bit(block[blOff + 2]);
/* 177 */         big[off + 3] = clipTo8Bit(block[blOff + 3]);
/* 178 */         big[off + 4] = clipTo8Bit(block[blOff + 4]);
/* 179 */         big[off + 5] = clipTo8Bit(block[blOff + 5]);
/* 180 */         big[off + 6] = clipTo8Bit(block[blOff + 6]);
/* 181 */         big[off + 7] = clipTo8Bit(block[blOff + 7]);
/*     */         
/* 183 */         blOff += 8;
/* 184 */         off += stride;
/*     */       } 
/*     */     } 
/*     */   }
/*     */   
/* 189 */   public static int[][] scan4x4 = new int[][] { { 0, 1, 4, 8, 5, 2, 3, 6, 9, 12, 16, 13, 10, 7, 16, 16, 16, 11, 14, 16, 16, 16, 16, 16, 15, 16, 16, 16, 16, 16, 16, 16, 16, 16, 16, 16, 16, 16, 16, 16, 16, 16, 16, 16, 16, 16, 16, 16, 16, 16, 16, 16, 16, 16, 16, 16, 16, 16, 16, 16, 16, 16, 16, 16 }, { 0, 4, 8, 12, 1, 5, 2, 6, 9, 13, 16, 16, 16, 16, 16, 16, 16, 16, 14, 10, 3, 7, 16, 16, 11, 15, 16, 16, 16, 16, 16, 16, 16, 16, 16, 16, 16, 16, 16, 16, 16, 16, 16, 16, 16, 16, 16, 16, 16, 16, 16, 16, 16, 16, 16, 16, 16, 16, 16, 16, 16, 16, 16, 16 } };
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected MPEGDecoder.Context initContext(SequenceHeader sh, PictureHeader ph) {
/* 198 */     MPEGDecoder.Context context = super.initContext(sh, ph);
/* 199 */     context.codedWidth >>= 1;
/* 200 */     context.codedHeight >>= 1;
/* 201 */     context.picWidth >>= 1;
/* 202 */     context.picHeight >>= 1;
/*     */     
/* 204 */     context.scan = scan4x4[(ph.pictureCodingExtension == null) ? 0 : ph.pictureCodingExtension.alternate_scan];
/*     */     
/* 206 */     return context;
/*     */   }
/*     */ }


/* Location:              C:\Users\rapha\Downloads\aurora.jar!\META-INF\jars\jcodec-0.2.5.jar!\org\jcodec\codecs\mpeg12\Mpeg2Thumb4x4.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */