/*     */ package org.jcodec.codecs.mpeg12;
/*     */ 
/*     */ import java.io.File;
/*     */ import java.io.IOException;
/*     */ import java.nio.ByteBuffer;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Collection;
/*     */ import java.util.HashMap;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import org.jcodec.common.AudioFormat;
/*     */ import org.jcodec.common.Codec;
/*     */ import org.jcodec.common.IntArrayList;
/*     */ import org.jcodec.common.io.NIOUtils;
/*     */ import org.jcodec.common.io.SeekableByteChannel;
/*     */ import org.jcodec.common.logging.Logger;
/*     */ import org.jcodec.common.model.ChannelLabel;
/*     */ import org.jcodec.common.model.Rational;
/*     */ import org.jcodec.common.model.Size;
/*     */ import org.jcodec.containers.mps.MPSUtils;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class MPSMediaInfo
/*     */   extends MPSUtils.PESReader
/*     */ {
/*  41 */   private Map<Integer, MPEGTrackMetadata> infos = new HashMap<Integer, MPEGTrackMetadata>();
/*     */   private int pesTried;
/*     */   private PSM psm;
/*     */   
/*     */   public static class MPEGTimecodeMetadata
/*     */   {
/*     */     public String getNumFrames() {
/*  48 */       return null;
/*     */     }
/*     */ 
/*     */     
/*     */     public String isDropFrame() {
/*  53 */       return null;
/*     */     }
/*     */ 
/*     */     
/*     */     public String getStartCounter() {
/*  58 */       return null;
/*     */     }
/*     */   }
/*     */   
/*     */   public static class MPEGTrackMetadata
/*     */   {
/*     */     int streamId;
/*     */     Codec codec;
/*     */     ByteBuffer probeData;
/*     */     
/*     */     public MPEGTrackMetadata(int streamId) {
/*  69 */       this.streamId = streamId;
/*     */     }
/*     */ 
/*     */     
/*     */     public AudioFormat getAudioFormat() {
/*  74 */       return null;
/*     */     }
/*     */     
/*     */     public ChannelLabel[] getChannelLables() {
/*  78 */       return null;
/*     */     }
/*     */ 
/*     */     
/*     */     public Size getDisplaySize() {
/*  83 */       return null;
/*     */     }
/*     */ 
/*     */     
/*     */     public Size getCodedSize() {
/*  88 */       return null;
/*     */     }
/*     */ 
/*     */     
/*     */     public float getFps() {
/*  93 */       return 0.0F;
/*     */     }
/*     */ 
/*     */     
/*     */     public float getDuration() {
/*  98 */       return 0.0F;
/*     */     }
/*     */ 
/*     */     
/*     */     public String getFourcc() {
/* 103 */       return null;
/*     */     }
/*     */ 
/*     */     
/*     */     public Rational getFpsR() {
/* 108 */       return null;
/*     */     }
/*     */ 
/*     */     
/*     */     public int getNumFrames() {
/* 113 */       return 0;
/*     */     }
/*     */     
/*     */     public MPSMediaInfo.MPEGTimecodeMetadata getTimecode() {
/* 117 */       return null;
/*     */     }
/*     */   }
/*     */   
/*     */   public List<MPEGTrackMetadata> getMediaInfo(File f) throws IOException {
/*     */     try {
/* 123 */       (new NIOUtils.FileReader()
/*     */         {
/*     */           protected void data(ByteBuffer data, long filePos) {
/* 126 */             MPSMediaInfo.this.analyseBuffer(data, filePos);
/*     */           }
/*     */ 
/*     */ 
/*     */ 
/*     */           
/*     */           protected void done() {}
/* 133 */         }).readFile(f, 65536, null);
/* 134 */     } catch (MediaInfoDone e) {
/* 135 */       Logger.info("Media info done");
/*     */     } 
/* 137 */     return getInfos();
/*     */   }
/*     */ 
/*     */   
/*     */   public static class MediaInfoDone
/*     */     extends RuntimeException {}
/*     */   
/*     */   protected void pes(ByteBuffer pesBuffer, long start, int pesLen, int stream) {
/* 145 */     if (!MPSUtils.mediaStream(stream))
/*     */       return; 
/* 147 */     MPEGTrackMetadata info = this.infos.get(Integer.valueOf(stream));
/* 148 */     if (info == null) {
/* 149 */       info = new MPEGTrackMetadata(stream);
/* 150 */       this.infos.put(Integer.valueOf(stream), info);
/*     */     } 
/* 152 */     if (info.probeData == null) {
/* 153 */       info.probeData = NIOUtils.cloneBuffer(pesBuffer);
/*     */     }
/* 155 */     if (++this.pesTried >= 100) {
/* 156 */       deriveMediaInfo();
/* 157 */       throw new MediaInfoDone();
/*     */     } 
/*     */   }
/*     */   
/*     */   private void deriveMediaInfo() {
/* 162 */     Collection<MPEGTrackMetadata> values = this.infos.values();
/* 163 */     for (MPEGTrackMetadata stream : values) {
/* 164 */       int streamId = 0x100 | stream.streamId;
/* 165 */       if (streamId >= 448 && streamId <= 479) {
/* 166 */         stream.codec = Codec.MP2; continue;
/* 167 */       }  if (streamId == 445) {
/* 168 */         ByteBuffer dup = stream.probeData.duplicate();
/* 169 */         MPSUtils.readPESHeader(dup, 0L);
/* 170 */         int type = dup.get() & 0xFF;
/*     */         
/* 172 */         if (type >= 128 && type <= 135) {
/* 173 */           stream.codec = Codec.AC3; continue;
/* 174 */         }  if ((type >= 136 && type <= 143) || (type >= 152 && type <= 159)) {
/* 175 */           stream.codec = Codec.DTS; continue;
/* 176 */         }  if (type >= 160 && type <= 175) {
/* 177 */           stream.codec = Codec.PCM_DVD; continue;
/* 178 */         }  if (type >= 176 && type <= 191) {
/* 179 */           stream.codec = Codec.TRUEHD; continue;
/* 180 */         }  if (type >= 192 && type <= 207)
/* 181 */           stream.codec = Codec.AC3; 
/*     */         continue;
/*     */       } 
/* 184 */       if (streamId >= 480 && streamId <= 495) {
/* 185 */         stream.codec = Codec.MPEG2;
/*     */       }
/*     */     } 
/*     */   }
/*     */   
/*     */   private int[] parseSystem(ByteBuffer pesBuffer) {
/* 191 */     NIOUtils.skip(pesBuffer, 12);
/* 192 */     IntArrayList result = IntArrayList.createIntArrayList();
/* 193 */     while (pesBuffer.remaining() >= 3 && (pesBuffer.get(pesBuffer.position()) & 0x80) == 128) {
/* 194 */       result.add(pesBuffer.get() & 0xFF);
/* 195 */       pesBuffer.getShort();
/*     */     } 
/* 197 */     return result.toArray();
/*     */   }
/*     */ 
/*     */   
/*     */   public static class PSM {}
/*     */ 
/*     */   
/*     */   private PSM parsePSM(ByteBuffer pesBuffer) {
/* 205 */     pesBuffer.getInt();
/* 206 */     short psmLen = pesBuffer.getShort();
/* 207 */     if (psmLen > 1018)
/* 208 */       throw new RuntimeException("Invalid PSM"); 
/* 209 */     byte b0 = pesBuffer.get();
/* 210 */     byte b1 = pesBuffer.get();
/* 211 */     if ((b1 & 0x1) != 1)
/* 212 */       throw new RuntimeException("Invalid PSM"); 
/* 213 */     short psiLen = pesBuffer.getShort();
/* 214 */     ByteBuffer psi = NIOUtils.read(pesBuffer, psiLen & 0xFFFF);
/* 215 */     short elStreamLen = pesBuffer.getShort();
/* 216 */     parseElStreams(NIOUtils.read(pesBuffer, elStreamLen & 0xFFFF));
/* 217 */     int crc = pesBuffer.getInt();
/*     */     
/* 219 */     return new PSM();
/*     */   }
/*     */   
/*     */   private void parseElStreams(ByteBuffer buf) {
/* 223 */     while (buf.hasRemaining()) {
/* 224 */       byte streamType = buf.get();
/* 225 */       byte streamId = buf.get();
/* 226 */       short strInfoLen = buf.getShort();
/* 227 */       ByteBuffer byteBuffer = NIOUtils.read(buf, strInfoLen & 0xFFFF);
/*     */     } 
/*     */   }
/*     */   
/*     */   public List<MPEGTrackMetadata> getInfos() {
/* 232 */     return new ArrayList<MPEGTrackMetadata>(this.infos.values());
/*     */   }
/*     */   
/*     */   public static void main1(String[] args) throws IOException {
/* 236 */     (new MPSMediaInfo()).getMediaInfo(new File(args[0]));
/*     */   }
/*     */ 
/*     */   
/*     */   public static MPSMediaInfo extract(SeekableByteChannel input) {
/* 241 */     return null;
/*     */   }
/*     */   
/*     */   public List<MPEGTrackMetadata> getAudioTracks() {
/* 245 */     return null;
/*     */   }
/*     */   
/*     */   public MPEGTrackMetadata getVideoTrack() {
/* 249 */     return null;
/*     */   }
/*     */ }


/* Location:              C:\Users\rapha\Downloads\aurora.jar!\META-INF\jars\jcodec-0.2.5.jar!\org\jcodec\codecs\mpeg12\MPSMediaInfo.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */