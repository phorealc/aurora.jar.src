/*     */ package org.jcodec.codecs.mpeg12;
/*     */ 
/*     */ import org.jcodec.common.io.BitReader;
/*     */ import org.jcodec.common.model.Picture;
/*     */ import org.jcodec.common.tools.MathUtil;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class MPEGPred
/*     */ {
/*     */   protected int[][][] mvPred;
/*     */   protected int chromaFormat;
/*     */   protected int[][] fCode;
/*     */   protected boolean topFieldFirst;
/*     */   
/*     */   public MPEGPred(int[][] fCode, int chromaFormat, boolean topFieldFirst) {
/*  26 */     this.mvPred = new int[2][2][2];
/*  27 */     this.fCode = fCode;
/*  28 */     this.chromaFormat = chromaFormat;
/*  29 */     this.topFieldFirst = topFieldFirst;
/*     */   }
/*     */ 
/*     */   
/*     */   public void predictFullXFullYSafe(byte[] ref, int refX, int refY, int refW, int refH, int refVertStep, int refVertOff, int[] tgt, int tgtY, int tgtW, int tgtH, int tgtVertStep) {
/*  34 */     int offRef = ((refY << refVertStep) + refVertOff) * refW + refX, offTgt = tgtW * tgtY, lfRef = (refW << refVertStep) - tgtW;
/*  35 */     int lfTgt = tgtVertStep * tgtW;
/*     */     
/*  37 */     for (int i = 0; i < tgtH; i++) {
/*  38 */       for (int j = 0; j < tgtW; j++)
/*  39 */         tgt[offTgt++] = ref[offRef++] + 128; 
/*  40 */       offRef += lfRef;
/*  41 */       offTgt += lfTgt;
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public void predictEvenOddSafe(byte[] ref, int refX, int refY, int refW, int refH, int refVertStep, int refVertOff, int[] tgt, int tgtY, int tgtW, int tgtH, int tgtVertStep) {
/*  47 */     int offRef = ((refY << refVertStep) + refVertOff) * refW + refX, offTgt = tgtW * tgtY, lfRef = (refW << refVertStep) - tgtW;
/*  48 */     int lfTgt = tgtVertStep * tgtW;
/*     */     
/*  50 */     for (int i = 0; i < tgtH; i++) {
/*  51 */       for (int j = 0; j < tgtW; j++) {
/*  52 */         tgt[offTgt++] = (ref[offRef] + ref[offRef + 1] + 1 >> 1) + 128;
/*  53 */         offRef++;
/*     */       } 
/*  55 */       offRef += lfRef;
/*  56 */       offTgt += lfTgt;
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public void predictOddEvenSafe(byte[] ref, int refX, int refY, int refW, int refH, int refVertStep, int refVertOff, int[] tgt, int tgtY, int tgtW, int tgtH, int tgtVertStep) {
/*  62 */     int offRef = ((refY << refVertStep) + refVertOff) * refW + refX, offTgt = tgtW * tgtY, lfRef = (refW << refVertStep) - tgtW;
/*  63 */     int lfTgt = tgtVertStep * tgtW, stride = refW << refVertStep;
/*     */     
/*  65 */     for (int i = 0; i < tgtH; i++) {
/*  66 */       for (int j = 0; j < tgtW; j++) {
/*  67 */         tgt[offTgt++] = (ref[offRef] + ref[offRef + stride] + 1 >> 1) + 128;
/*  68 */         offRef++;
/*     */       } 
/*  70 */       offRef += lfRef;
/*  71 */       offTgt += lfTgt;
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public void predictOddOddSafe(byte[] ref, int refX, int refY, int refW, int refH, int refVertStep, int refVertOff, int[] tgt, int tgtY, int tgtW, int tgtH, int tgtVertStep) {
/*  77 */     int offRef = ((refY << refVertStep) + refVertOff) * refW + refX, offTgt = tgtW * tgtY, lfRef = (refW << refVertStep) - tgtW;
/*  78 */     int lfTgt = tgtVertStep * tgtW, stride = refW << refVertStep;
/*     */     
/*  80 */     for (int i = 0; i < tgtH; i++) {
/*  81 */       for (int j = 0; j < tgtW; j++) {
/*  82 */         tgt[offTgt++] = (ref[offRef] + ref[offRef + 1] + ref[offRef + stride] + ref[offRef + stride + 1] + 3 >> 2) + 128;
/*  83 */         offRef++;
/*     */       } 
/*  85 */       offRef += lfRef;
/*  86 */       offTgt += lfTgt;
/*     */     } 
/*     */   }
/*     */   
/*     */   protected final int getPix1(byte[] ref, int refW, int refH, int x, int y, int refVertStep, int refVertOff) {
/*  91 */     x = MathUtil.clip(x, 0, refW - 1);
/*  92 */     y = MathUtil.clip(y, 0, refH - (1 << refVertStep) + refVertOff);
/*     */     
/*  94 */     return ref[y * refW + x] + 128;
/*     */   }
/*     */ 
/*     */   
/*     */   protected final int getPix2(byte[] ref, int refW, int refH, int x1, int y1, int x2, int y2, int refVertStep, int refVertOff) {
/*  99 */     x1 = MathUtil.clip(x1, 0, refW - 1);
/* 100 */     int lastLine = refH - (1 << refVertStep) + refVertOff;
/* 101 */     y1 = MathUtil.clip(y1, 0, lastLine);
/* 102 */     x2 = MathUtil.clip(x2, 0, refW - 1);
/* 103 */     y2 = MathUtil.clip(y2, 0, lastLine);
/*     */     
/* 105 */     return (ref[y1 * refW + x1] + ref[y2 * refW + x2] + 1 >> 1) + 128;
/*     */   }
/*     */ 
/*     */   
/*     */   protected final int getPix4(byte[] ref, int refW, int refH, int x1, int y1, int x2, int y2, int x3, int y3, int x4, int y4, int refVertStep, int refVertOff) {
/* 110 */     int lastLine = refH - (1 << refVertStep) + refVertOff;
/* 111 */     x1 = MathUtil.clip(x1, 0, refW - 1);
/* 112 */     y1 = MathUtil.clip(y1, 0, lastLine);
/* 113 */     x2 = MathUtil.clip(x2, 0, refW - 1);
/* 114 */     y2 = MathUtil.clip(y2, 0, lastLine);
/* 115 */     x3 = MathUtil.clip(x3, 0, refW - 1);
/* 116 */     y3 = MathUtil.clip(y3, 0, lastLine);
/* 117 */     x4 = MathUtil.clip(x4, 0, refW - 1);
/* 118 */     y4 = MathUtil.clip(y4, 0, lastLine);
/*     */     
/* 120 */     return (ref[y1 * refW + x1] + ref[y2 * refW + x2] + ref[y3 * refW + x3] + ref[y4 * refW + x4] + 3 >> 2) + 128;
/*     */   }
/*     */ 
/*     */   
/*     */   public void predictFullXFullYUnSafe(byte[] ref, int refX, int refY, int refW, int refH, int refVertStep, int refVertOff, int[] tgt, int tgtY, int tgtW, int tgtH, int tgtVertStep) {
/* 125 */     int tgtOff = tgtW * tgtY, jump = tgtVertStep * tgtW;
/* 126 */     for (int j = 0; j < tgtH; j++) {
/* 127 */       int y = (j + refY << refVertStep) + refVertOff;
/* 128 */       for (int i = 0; i < tgtW; i++) {
/* 129 */         tgt[tgtOff++] = getPix1(ref, refW, refH, i + refX, y, refVertStep, refVertOff);
/*     */       }
/* 131 */       tgtOff += jump;
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public void predictEvenOddUnSafe(byte[] ref, int refX, int refY, int refW, int refH, int refVertStep, int refVertOff, int[] tgt, int tgtY, int tgtW, int tgtH, int tgtVertStep) {
/* 137 */     int tgtOff = tgtW * tgtY, jump = tgtVertStep * tgtW;
/* 138 */     for (int j = 0; j < tgtH; j++) {
/* 139 */       int y = (j + refY << refVertStep) + refVertOff;
/* 140 */       for (int i = 0; i < tgtW; i++) {
/* 141 */         tgt[tgtOff++] = getPix2(ref, refW, refH, i + refX, y, i + refX + 1, y, refVertStep, refVertOff);
/*     */       }
/* 143 */       tgtOff += jump;
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public void predictOddEvenUnSafe(byte[] ref, int refX, int refY, int refW, int refH, int refVertStep, int refVertOff, int[] tgt, int tgtY, int tgtW, int tgtH, int tgtVertStep) {
/* 149 */     int tgtOff = tgtW * tgtY, jump = tgtVertStep * tgtW;
/* 150 */     for (int j = 0; j < tgtH; j++) {
/* 151 */       int y1 = (j + refY << refVertStep) + refVertOff;
/* 152 */       int y2 = (j + refY + 1 << refVertStep) + refVertOff;
/* 153 */       for (int i = 0; i < tgtW; i++) {
/* 154 */         tgt[tgtOff++] = getPix2(ref, refW, refH, i + refX, y1, i + refX, y2, refVertStep, refVertOff);
/*     */       }
/* 156 */       tgtOff += jump;
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public void predictOddOddUnSafe(byte[] ref, int refX, int refY, int refW, int refH, int refVertStep, int refVertOff, int[] tgt, int tgtY, int tgtW, int tgtH, int tgtVertStep) {
/* 162 */     int tgtOff = tgtW * tgtY, jump = tgtVertStep * tgtW;
/* 163 */     for (int j = 0; j < tgtH; j++) {
/* 164 */       int y1 = (j + refY << refVertStep) + refVertOff;
/* 165 */       int y2 = (j + refY + 1 << refVertStep) + refVertOff;
/* 166 */       for (int i = 0; i < tgtW; i++) {
/* 167 */         int ptX = i + refX;
/* 168 */         tgt[tgtOff++] = getPix4(ref, refW, refH, ptX, y1, ptX + 1, y1, ptX, y2, ptX + 1, y2, refVertStep, refVertOff);
/*     */       } 
/*     */       
/* 171 */       tgtOff += jump;
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public void predictPlane(byte[] ref, int refX, int refY, int refW, int refH, int refVertStep, int refVertOff, int[] tgt, int tgtY, int tgtW, int tgtH, int tgtVertStep) {
/* 177 */     int rx = refX >> 1, ry = refY >> 1;
/*     */     
/* 179 */     boolean safe = (rx >= 0 && ry >= 0 && rx + tgtW < refW && ry + tgtH << refVertStep < refH);
/* 180 */     if ((refX & 0x1) == 0) {
/* 181 */       if ((refY & 0x1) == 0) {
/* 182 */         if (safe) {
/* 183 */           predictFullXFullYSafe(ref, rx, ry, refW, refH, refVertStep, refVertOff, tgt, tgtY, tgtW, tgtH, tgtVertStep);
/*     */         } else {
/*     */           
/* 186 */           predictFullXFullYUnSafe(ref, rx, ry, refW, refH, refVertStep, refVertOff, tgt, tgtY, tgtW, tgtH, tgtVertStep);
/*     */         }
/*     */       
/* 189 */       } else if (safe) {
/* 190 */         predictOddEvenSafe(ref, rx, ry, refW, refH, refVertStep, refVertOff, tgt, tgtY, tgtW, tgtH, tgtVertStep);
/*     */       } else {
/*     */         
/* 193 */         predictOddEvenUnSafe(ref, rx, ry, refW, refH, refVertStep, refVertOff, tgt, tgtY, tgtW, tgtH, tgtVertStep);
/*     */       }
/*     */     
/* 196 */     } else if ((refY & 0x1) == 0) {
/* 197 */       if (safe) {
/* 198 */         predictEvenOddSafe(ref, rx, ry, refW, refH, refVertStep, refVertOff, tgt, tgtY, tgtW, tgtH, tgtVertStep);
/*     */       } else {
/* 200 */         predictEvenOddUnSafe(ref, rx, ry, refW, refH, refVertStep, refVertOff, tgt, tgtY, tgtW, tgtH, tgtVertStep);
/*     */       }
/*     */     
/* 203 */     } else if (safe) {
/* 204 */       predictOddOddSafe(ref, rx, ry, refW, refH, refVertStep, refVertOff, tgt, tgtY, tgtW, tgtH, tgtVertStep);
/*     */     } else {
/* 206 */       predictOddOddUnSafe(ref, rx, ry, refW, refH, refVertStep, refVertOff, tgt, tgtY, tgtW, tgtH, tgtVertStep);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void predictInField(Picture[] reference, int x, int y, int[][] mbPix, BitReader bits, int motionType, int backward, int fieldNo) {
/* 213 */     switch (motionType) {
/*     */       case 1:
/* 215 */         predict16x16Field(reference, x, y, bits, backward, mbPix);
/*     */         break;
/*     */       case 2:
/* 218 */         predict16x8MC(reference, x, y, bits, backward, mbPix, 0, 0);
/* 219 */         predict16x8MC(reference, x, y, bits, backward, mbPix, 8, 1);
/*     */         break;
/*     */       case 3:
/* 222 */         predict16x16DualPrimeField(reference, x, y, bits, mbPix, fieldNo);
/*     */         break;
/*     */     } 
/*     */   }
/*     */   
/*     */   public void predictInFrame(Picture reference, int x, int y, int[][] mbPix, BitReader _in, int motionType, int backward, int spatial_temporal_weight_code) {
/* 228 */     Picture[] refs = { reference, reference };
/* 229 */     switch (motionType) {
/*     */       case 1:
/* 231 */         predictFieldInFrame(reference, x, y, mbPix, _in, backward, spatial_temporal_weight_code);
/*     */         break;
/*     */       case 2:
/* 234 */         predict16x16Frame(reference, x, y, _in, backward, mbPix);
/*     */         break;
/*     */       case 3:
/* 237 */         predict16x16DualPrimeFrame(refs, x, y, _in, backward, mbPix);
/*     */         break;
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   private void predict16x16DualPrimeField(Picture[] reference, int x, int y, BitReader bits, int[][] mbPix, int fieldNo) {
/* 244 */     int vect1X = mvectDecode(bits, this.fCode[0][0], this.mvPred[0][0][0]);
/* 245 */     int dmX = MPEGConst.vlcDualPrime.readVLC(bits) - 1;
/*     */     
/* 247 */     int vect1Y = mvectDecode(bits, this.fCode[0][1], this.mvPred[0][0][1]);
/* 248 */     int dmY = MPEGConst.vlcDualPrime.readVLC(bits) - 1;
/*     */     
/* 250 */     int vect2X = dpXField(vect1X, dmX, 1 - fieldNo);
/* 251 */     int vect2Y = dpYField(vect1Y, dmY, 1 - fieldNo);
/*     */     
/* 253 */     int ch = (this.chromaFormat == 1) ? 1 : 0;
/* 254 */     int cw = (this.chromaFormat == 3) ? 0 : 1;
/* 255 */     int sh = (this.chromaFormat == 1) ? 2 : 1;
/* 256 */     int sw = (this.chromaFormat == 3) ? 1 : 2;
/*     */     
/* 258 */     int[][] mbPix1 = new int[3][256], mbPix2 = new int[3][256];
/*     */     
/* 260 */     int refX1 = (x << 1) + vect1X;
/* 261 */     int refY1 = (y << 1) + vect1Y;
/* 262 */     int refX1Chr = (x << 1 >> cw) + vect1X / sw;
/* 263 */     int refY1Chr = (y << 1 >> ch) + vect1Y / sh;
/*     */     
/* 265 */     predictPlane(reference[fieldNo].getPlaneData(0), refX1, refY1, reference[fieldNo].getPlaneWidth(0), reference[fieldNo]
/* 266 */         .getPlaneHeight(0), 1, fieldNo, mbPix1[0], 0, 16, 16, 0);
/* 267 */     predictPlane(reference[fieldNo].getPlaneData(1), refX1Chr, refY1Chr, reference[fieldNo].getPlaneWidth(1), reference[fieldNo]
/* 268 */         .getPlaneHeight(1), 1, fieldNo, mbPix1[1], 0, 16 >> cw, 16 >> ch, 0);
/* 269 */     predictPlane(reference[fieldNo].getPlaneData(2), refX1Chr, refY1Chr, reference[fieldNo].getPlaneWidth(2), reference[fieldNo]
/* 270 */         .getPlaneHeight(2), 1, fieldNo, mbPix1[2], 0, 16 >> cw, 16 >> ch, 0);
/*     */     
/* 272 */     int refX2 = (x << 1) + vect2X;
/* 273 */     int refY2 = (y << 1) + vect2Y;
/* 274 */     int refX2Chr = (x << 1 >> cw) + vect2X / sw;
/* 275 */     int refY2Chr = (y << 1 >> ch) + vect2Y / sh;
/* 276 */     int opposite = 1 - fieldNo;
/* 277 */     predictPlane(reference[opposite].getPlaneData(0), refX2, refY2, reference[opposite].getPlaneWidth(0), reference[opposite]
/* 278 */         .getPlaneHeight(0), 1, opposite, mbPix2[0], 0, 16, 16, 0);
/* 279 */     predictPlane(reference[opposite].getPlaneData(1), refX2Chr, refY2Chr, reference[opposite].getPlaneWidth(1), reference[opposite]
/* 280 */         .getPlaneHeight(1), 1, opposite, mbPix2[1], 0, 16 >> cw, 16 >> ch, 0);
/* 281 */     predictPlane(reference[opposite].getPlaneData(2), refX2Chr, refY2Chr, reference[opposite].getPlaneWidth(2), reference[opposite]
/* 282 */         .getPlaneHeight(2), 1, opposite, mbPix2[2], 0, 16 >> cw, 16 >> ch, 0);
/*     */     
/* 284 */     for (int i = 0; i < 3; i++) {
/* 285 */       for (int j = 0; j < (mbPix[i]).length; j++) {
/* 286 */         mbPix[i][j] = mbPix1[i][j] + mbPix2[i][j] + 1 >> 1;
/*     */       }
/*     */     } 
/* 289 */     this.mvPred[0][0][0] = vect1X; this.mvPred[1][0][0] = vect1X;
/* 290 */     this.mvPred[0][0][1] = vect1Y; this.mvPred[1][0][1] = vect1Y;
/*     */   }
/*     */   
/*     */   private final int dpYField(int vect1y, int dmY, int topField) {
/* 294 */     return (vect1y + ((vect1y > 0) ? 1 : 0) >> 1) + 1 - (topField << 1) + dmY;
/*     */   }
/*     */   
/*     */   private final int dpXField(int vect1x, int dmX, int topField) {
/* 298 */     return (vect1x + ((vect1x > 0) ? 1 : 0) >> 1) + dmX;
/*     */   }
/*     */ 
/*     */   
/*     */   private void predict16x8MC(Picture[] reference, int x, int y, BitReader bits, int backward, int[][] mbPix, int vertPos, int vectIdx) {
/* 303 */     int field = bits.read1Bit();
/*     */     
/* 305 */     predictGeneric(reference[field], x, y + vertPos, bits, backward, mbPix, vertPos, 16, 8, 1, field, 0, vectIdx, 0);
/*     */   }
/*     */   
/*     */   protected void predict16x16Field(Picture[] reference, int x, int y, BitReader bits, int backward, int[][] mbPix) {
/* 309 */     int field = bits.read1Bit();
/*     */     
/* 311 */     predictGeneric(reference[field], x, y, bits, backward, mbPix, 0, 16, 16, 1, field, 0, 0, 0);
/*     */     
/* 313 */     this.mvPred[1][backward][0] = this.mvPred[0][backward][0];
/* 314 */     this.mvPred[1][backward][1] = this.mvPred[0][backward][1];
/*     */   }
/*     */ 
/*     */   
/*     */   private void predict16x16DualPrimeFrame(Picture[] reference, int x, int y, BitReader bits, int backward, int[][] mbPix) {
/* 319 */     int vect1X = mvectDecode(bits, this.fCode[0][0], this.mvPred[0][0][0]);
/* 320 */     int dmX = MPEGConst.vlcDualPrime.readVLC(bits) - 1;
/*     */     
/* 322 */     int vect1Y = mvectDecode(bits, this.fCode[0][1], this.mvPred[0][0][1] >> 1);
/* 323 */     int dmY = MPEGConst.vlcDualPrime.readVLC(bits) - 1;
/*     */     
/* 325 */     int m = this.topFieldFirst ? 1 : 3;
/*     */     
/* 327 */     int vect2X = (vect1X * m + ((vect1X > 0) ? 1 : 0) >> 1) + dmX;
/* 328 */     int vect2Y = (vect1Y * m + ((vect1Y > 0) ? 1 : 0) >> 1) + dmY - 1;
/* 329 */     m = 4 - m;
/* 330 */     int vect3X = (vect1X * m + ((vect1X > 0) ? 1 : 0) >> 1) + dmX;
/* 331 */     int vect3Y = (vect1Y * m + ((vect1Y > 0) ? 1 : 0) >> 1) + dmY + 1;
/*     */     
/* 333 */     int ch = (this.chromaFormat == 1) ? 1 : 0;
/* 334 */     int cw = (this.chromaFormat == 3) ? 0 : 1;
/* 335 */     int sh = (this.chromaFormat == 1) ? 2 : 1;
/* 336 */     int sw = (this.chromaFormat == 3) ? 1 : 2;
/*     */     
/* 338 */     int[][] mbPix1 = new int[3][256], mbPix2 = new int[3][256];
/*     */     
/* 340 */     int refX1 = (x << 1) + vect1X;
/* 341 */     int refY1 = y + vect1Y;
/* 342 */     int refX1Chr = (x << 1 >> cw) + vect1X / sw;
/* 343 */     int refY1Chr = (y >> ch) + vect1Y / sh;
/*     */     
/* 345 */     predictPlane(reference[0].getPlaneData(0), refX1, refY1, reference[0].getPlaneWidth(0), reference[0]
/* 346 */         .getPlaneHeight(0), 1, 0, mbPix1[0], 0, 16, 8, 1);
/* 347 */     predictPlane(reference[0].getPlaneData(1), refX1Chr, refY1Chr, reference[0].getPlaneWidth(1), reference[0]
/* 348 */         .getPlaneHeight(1), 1, 0, mbPix1[1], 0, 16 >> cw, 8 >> ch, 1);
/* 349 */     predictPlane(reference[0].getPlaneData(2), refX1Chr, refY1Chr, reference[0].getPlaneWidth(2), reference[0]
/* 350 */         .getPlaneHeight(2), 1, 0, mbPix1[2], 0, 16 >> cw, 8 >> ch, 1);
/*     */     
/* 352 */     predictPlane(reference[1].getPlaneData(0), refX1, refY1, reference[1].getPlaneWidth(0), reference[1]
/* 353 */         .getPlaneHeight(0), 1, 1, mbPix1[0], 1, 16, 8, 1);
/* 354 */     predictPlane(reference[1].getPlaneData(1), refX1Chr, refY1Chr, reference[1].getPlaneWidth(1), reference[1]
/* 355 */         .getPlaneHeight(1), 1, 1, mbPix1[1], 1, 16 >> cw, 8 >> ch, 1);
/* 356 */     predictPlane(reference[1].getPlaneData(2), refX1Chr, refY1Chr, reference[1].getPlaneWidth(2), reference[1]
/* 357 */         .getPlaneHeight(2), 1, 1, mbPix1[2], 1, 16 >> cw, 8 >> ch, 1);
/*     */     
/* 359 */     int refX2 = (x << 1) + vect2X;
/* 360 */     int refY2 = y + vect2Y;
/* 361 */     int refX2Chr = (x << 1 >> cw) + vect2X / sw;
/* 362 */     int refY2Chr = (y >> ch) + vect2Y / sh;
/* 363 */     predictPlane(reference[1].getPlaneData(0), refX2, refY2, reference[1].getPlaneWidth(0), reference[1]
/* 364 */         .getPlaneHeight(0), 1, 1, mbPix2[0], 0, 16, 8, 1);
/* 365 */     predictPlane(reference[1].getPlaneData(1), refX2Chr, refY2Chr, reference[1].getPlaneWidth(1), reference[1]
/* 366 */         .getPlaneHeight(1), 1, 1, mbPix2[1], 0, 16 >> cw, 8 >> ch, 1);
/* 367 */     predictPlane(reference[1].getPlaneData(2), refX2Chr, refY2Chr, reference[1].getPlaneWidth(2), reference[1]
/* 368 */         .getPlaneHeight(2), 1, 1, mbPix2[2], 0, 16 >> cw, 8 >> ch, 1);
/*     */     
/* 370 */     int refX3 = (x << 1) + vect3X;
/* 371 */     int refY3 = y + vect3Y;
/* 372 */     int refX3Chr = (x << 1 >> cw) + vect3X / sw;
/* 373 */     int refY3Chr = (y >> ch) + vect3Y / sh;
/* 374 */     predictPlane(reference[0].getPlaneData(0), refX3, refY3, reference[0].getPlaneWidth(0), reference[0]
/* 375 */         .getPlaneHeight(0), 1, 0, mbPix2[0], 1, 16, 8, 1);
/* 376 */     predictPlane(reference[0].getPlaneData(1), refX3Chr, refY3Chr, reference[0].getPlaneWidth(1), reference[0]
/* 377 */         .getPlaneHeight(1), 1, 0, mbPix2[1], 1, 16 >> cw, 8 >> ch, 1);
/* 378 */     predictPlane(reference[0].getPlaneData(2), refX3Chr, refY3Chr, reference[0].getPlaneWidth(2), reference[0]
/* 379 */         .getPlaneHeight(2), 1, 0, mbPix2[2], 1, 16 >> cw, 8 >> ch, 1);
/*     */     
/* 381 */     for (int i = 0; i < 3; i++) {
/* 382 */       for (int j = 0; j < (mbPix[i]).length; j++) {
/* 383 */         mbPix[i][j] = mbPix1[i][j] + mbPix2[i][j] + 1 >> 1;
/*     */       }
/*     */     } 
/* 386 */     this.mvPred[0][0][0] = vect1X; this.mvPred[1][0][0] = vect1X;
/* 387 */     this.mvPred[0][0][1] = vect1Y << 1; this.mvPred[1][0][1] = vect1Y << 1;
/*     */   }
/*     */   
/*     */   protected void predict16x16Frame(Picture reference, int x, int y, BitReader bits, int backward, int[][] mbPix) {
/* 391 */     predictGeneric(reference, x, y, bits, backward, mbPix, 0, 16, 16, 0, 0, 0, 0, 0);
/*     */     
/* 393 */     this.mvPred[1][backward][0] = this.mvPred[0][backward][0];
/* 394 */     this.mvPred[1][backward][1] = this.mvPred[0][backward][1];
/*     */   }
/*     */   
/*     */   private final int mvectDecode(BitReader bits, int fcode, int pred) {
/* 398 */     int code = MPEGConst.vlcMotionCode.readVLC(bits);
/* 399 */     if (code == 0) {
/* 400 */       return pred;
/*     */     }
/* 402 */     if (code < 0) {
/* 403 */       return 65535;
/*     */     }
/*     */ 
/*     */     
/* 407 */     int sign = bits.read1Bit();
/* 408 */     int shift = fcode - 1;
/* 409 */     int val = code;
/* 410 */     if (shift > 0) {
/* 411 */       val = val - 1 << shift;
/* 412 */       val |= bits.readNBit(shift);
/* 413 */       val++;
/*     */     } 
/* 415 */     if (sign != 0)
/* 416 */       val = -val; 
/* 417 */     val += pred;
/*     */     
/* 419 */     return sign_extend(val, 5 + shift);
/*     */   }
/*     */   
/*     */   private final int sign_extend(int val, int bits) {
/* 423 */     int shift = 32 - bits;
/* 424 */     return val << shift >> shift;
/*     */   }
/*     */ 
/*     */   
/*     */   protected void predictGeneric(Picture reference, int x, int y, BitReader bits, int backward, int[][] mbPix, int tgtY, int blkW, int blkH, int isSrcField, int srcField, int isDstField, int vectIdx, int predScale) {
/* 429 */     int vectX = mvectDecode(bits, this.fCode[backward][0], this.mvPred[vectIdx][backward][0]);
/* 430 */     int vectY = mvectDecode(bits, this.fCode[backward][1], this.mvPred[vectIdx][backward][1] >> predScale);
/*     */     
/* 432 */     predictMB(reference, x << 1, vectX, y << 1, vectY, blkW, blkH, isSrcField, srcField, mbPix, tgtY, isDstField);
/*     */ 
/*     */     
/* 435 */     this.mvPred[vectIdx][backward][0] = vectX;
/* 436 */     this.mvPred[vectIdx][backward][1] = vectY << predScale;
/*     */   }
/*     */ 
/*     */   
/*     */   private void predictFieldInFrame(Picture reference, int x, int y, int[][] mbPix, BitReader bits, int backward, int spatial_temporal_weight_code) {
/* 441 */     y >>= 1;
/* 442 */     int field = bits.read1Bit();
/* 443 */     predictGeneric(reference, x, y, bits, backward, mbPix, 0, 16, 8, 1, field, 1, 0, 1);
/* 444 */     if (spatial_temporal_weight_code == 0 || spatial_temporal_weight_code == 1) {
/* 445 */       field = bits.read1Bit();
/* 446 */       predictGeneric(reference, x, y, bits, backward, mbPix, 1, 16, 8, 1, field, 1, 1, 1);
/*     */     } else {
/* 448 */       this.mvPred[1][backward][0] = this.mvPred[0][backward][0];
/* 449 */       this.mvPred[1][backward][1] = this.mvPred[0][backward][1];
/* 450 */       predictMB(reference, this.mvPred[1][backward][0], 0, this.mvPred[1][backward][1], 0, 16, 8, 1, 1 - field, mbPix, 1, 1);
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public void predictMB(Picture ref, int refX, int vectX, int refY, int vectY, int blkW, int blkH, int refVertStep, int refVertOff, int[][] tgt, int tgtY, int tgtVertStep) {
/* 456 */     int ch = (this.chromaFormat == 1) ? 1 : 0;
/* 457 */     int cw = (this.chromaFormat == 3) ? 0 : 1;
/*     */     
/* 459 */     int sh = (this.chromaFormat == 1) ? 2 : 1;
/* 460 */     int sw = (this.chromaFormat == 3) ? 1 : 2;
/*     */     
/* 462 */     predictPlane(ref.getPlaneData(0), refX + vectX, refY + vectY, ref.getPlaneWidth(0), ref.getPlaneHeight(0), refVertStep, refVertOff, tgt[0], tgtY, blkW, blkH, tgtVertStep);
/*     */     
/* 464 */     predictPlane(ref.getPlaneData(1), (refX >> cw) + vectX / sw, (refY >> ch) + vectY / sh, ref.getPlaneWidth(1), ref
/* 465 */         .getPlaneHeight(1), refVertStep, refVertOff, tgt[1], tgtY, blkW >> cw, blkH >> ch, tgtVertStep);
/* 466 */     predictPlane(ref.getPlaneData(2), (refX >> cw) + vectX / sw, (refY >> ch) + vectY / sh, ref.getPlaneWidth(2), ref
/* 467 */         .getPlaneHeight(2), refVertStep, refVertOff, tgt[2], tgtY, blkW >> cw, blkH >> ch, tgtVertStep);
/*     */   }
/*     */   
/*     */   public void predict16x16NoMV(Picture picture, int x, int y, int pictureStructure, int backward, int[][] mbPix) {
/* 471 */     if (pictureStructure == 3) {
/* 472 */       predictMB(picture, x << 1, this.mvPred[0][backward][0], y << 1, this.mvPred[0][backward][1], 16, 16, 0, 0, mbPix, 0, 0);
/*     */     } else {
/*     */       
/* 475 */       predictMB(picture, x << 1, this.mvPred[0][backward][0], y << 1, this.mvPred[0][backward][1], 16, 16, 1, pictureStructure - 1, mbPix, 0, 0);
/*     */     } 
/*     */   }
/*     */   
/*     */   public void reset() {
/* 480 */     this.mvPred[1][1][1] = 0; this.mvPred[1][1][0] = 0; this.mvPred[1][0][1] = 0; this.mvPred[1][0][0] = 0; this.mvPred[0][1][1] = 0; this.mvPred[0][1][0] = 0; this.mvPred[0][0][1] = 0; this.mvPred[0][0][0] = 0;
/*     */   }
/*     */ }


/* Location:              C:\Users\rapha\Downloads\aurora.jar!\META-INF\jars\jcodec-0.2.5.jar!\org\jcodec\codecs\mpeg12\MPEGPred.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */