/*     */ package org.jcodec.codecs.mpeg12;
/*     */ 
/*     */ import org.jcodec.codecs.mpeg12.bitstream.PictureHeader;
/*     */ import org.jcodec.codecs.mpeg12.bitstream.SequenceHeader;
/*     */ import org.jcodec.common.dct.IDCT2x2;
/*     */ import org.jcodec.common.io.BitReader;
/*     */ import org.jcodec.common.io.VLC;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class Mpeg2Thumb2x2
/*     */   extends MPEGDecoder
/*     */ {
/*     */   private MPEGPred localPred;
/*     */   private MPEGPred oldPred;
/*     */   
/*     */   protected void blockIntra(BitReader bits, VLC vlcCoeff, int[] block, int[] intra_dc_predictor, int blkIdx, int[] scan, int escSize, int intra_dc_mult, int qScale, int[] qmat) {
/*  31 */     int cc = MPEGConst.BLOCK_TO_CC[blkIdx];
/*  32 */     int size = ((cc == 0) ? MPEGConst.vlcDCSizeLuma : MPEGConst.vlcDCSizeChroma).readVLC(bits);
/*  33 */     int delta = (size != 0) ? mpegSigned(bits, size) : 0;
/*  34 */     intra_dc_predictor[cc] = intra_dc_predictor[cc] + delta;
/*  35 */     block[0] = intra_dc_predictor[cc] * intra_dc_mult;
/*  36 */     block[3] = 0; block[2] = 0; block[1] = 0;
/*  37 */     int readVLC = 0; int idx;
/*  38 */     for (idx = 0; idx < 6; ) {
/*  39 */       int level; readVLC = vlcCoeff.readVLC(bits);
/*     */ 
/*     */       
/*  42 */       if (readVLC == 2048)
/*     */         break; 
/*  44 */       if (readVLC == 2049) {
/*  45 */         idx += bits.readNBit(6) + 1;
/*  46 */         level = twosSigned(bits, escSize) * qScale * qmat[idx];
/*  47 */         level = (level >= 0) ? (level >> 4) : -(-level >> 4);
/*     */       } else {
/*  49 */         idx += (readVLC >> 6) + 1;
/*  50 */         level = toSigned((readVLC & 0x3F) * qScale * qmat[idx] >> 4, bits.read1Bit());
/*     */       } 
/*  52 */       block[scan[idx]] = level;
/*     */     } 
/*  54 */     if (readVLC != 2048)
/*  55 */       finishOff(bits, idx, vlcCoeff, escSize); 
/*  56 */     IDCT2x2.idct(block, 0);
/*     */   }
/*     */   
/*     */   private void finishOff(BitReader bits, int idx, VLC vlcCoeff, int escSize) {
/*  60 */     while (idx < 64) {
/*  61 */       int readVLC = vlcCoeff.readVLC(bits);
/*     */       
/*  63 */       if (readVLC == 2048)
/*     */         break; 
/*  65 */       if (readVLC == 2049) {
/*  66 */         idx += bits.readNBit(6) + 1;
/*  67 */         bits.readNBit(escSize); continue;
/*     */       } 
/*  69 */       bits.read1Bit();
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   protected void blockInter(BitReader bits, VLC vlcCoeff, int[] block, int[] scan, int escSize, int qScale, int[] qmat) {
/*  75 */     block[3] = 0; block[2] = 0; block[1] = 0;
/*     */     
/*  77 */     int idx = -1;
/*  78 */     if (vlcCoeff == MPEGConst.vlcCoeff0 && bits.checkNBit(1) == 1) {
/*  79 */       bits.read1Bit();
/*  80 */       block[0] = toSigned(quantInter(1, qScale * qmat[0]), bits.read1Bit());
/*  81 */       idx++;
/*     */     } else {
/*  83 */       block[0] = 0;
/*     */     } 
/*     */     
/*  86 */     int readVLC = 0;
/*  87 */     while (idx < 6) {
/*  88 */       int ac; readVLC = vlcCoeff.readVLC(bits);
/*     */       
/*  90 */       if (readVLC == 2048)
/*     */         break; 
/*  92 */       if (readVLC == 2049) {
/*  93 */         idx += bits.readNBit(6) + 1;
/*  94 */         ac = quantInterSigned(twosSigned(bits, escSize), qScale * qmat[idx]);
/*     */       } else {
/*  96 */         idx += (readVLC >> 6) + 1;
/*  97 */         ac = toSigned(quantInter(readVLC & 0x3F, qScale * qmat[idx]), bits.read1Bit());
/*     */       } 
/*  99 */       block[scan[idx]] = ac;
/*     */     } 
/* 101 */     if (readVLC != 2048)
/* 102 */       finishOff(bits, idx, vlcCoeff, escSize); 
/* 103 */     IDCT2x2.idct(block, 0);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int decodeMacroblock(PictureHeader ph, MPEGDecoder.Context context, int prevAddr, int[] qScaleCode, byte[][] buf, int stride, BitReader bits, int vertOff, int vertStep, MPEGPred pred) {
/* 110 */     if (this.localPred == null || this.oldPred != pred) {
/* 111 */       this.localPred = new MPEGPredQuad(pred);
/* 112 */       this.oldPred = pred;
/*     */     } 
/*     */     
/* 115 */     return super.decodeMacroblock(ph, context, prevAddr, qScaleCode, buf, stride, bits, vertOff, vertStep, this.localPred);
/*     */   }
/*     */ 
/*     */   
/* 119 */   public static int[] BLOCK_POS_X = new int[] { 0, 2, 0, 2, 0, 0, 0, 0, 2, 2, 2, 2, 0, 0, 0, 0, 0, 2, 0, 2, 0, 0, 0, 0, 2, 2, 2, 2 };
/*     */   
/* 121 */   public static int[] BLOCK_POS_Y = new int[] { 0, 0, 2, 2, 0, 0, 2, 2, 0, 0, 2, 2, 0, 0, 0, 0, 0, 0, 1, 1, 0, 0, 1, 1, 0, 0, 1, 1 };
/*     */ 
/*     */   
/*     */   protected void mapBlock(int[] block, int[] out, int blkIdx, int dctType, int chromaFormat) {
/* 125 */     int stepVert = (chromaFormat == 1 && (blkIdx == 4 || blkIdx == 5)) ? 0 : dctType;
/* 126 */     int log2stride = (blkIdx < 4) ? 2 : (2 - MPEGConst.SQUEEZE_X[chromaFormat]);
/*     */     
/* 128 */     int blkIdxExt = blkIdx + (dctType << 4);
/* 129 */     int x = BLOCK_POS_X[blkIdxExt];
/* 130 */     int y = BLOCK_POS_Y[blkIdxExt];
/* 131 */     int off = (y << log2stride) + x, stride = 1 << log2stride + stepVert;
/*     */     
/* 133 */     out[off] = out[off] + block[0];
/* 134 */     out[off + 1] = out[off + 1] + block[1];
/* 135 */     out[off + stride] = out[off + stride] + block[2];
/* 136 */     out[off + stride + 1] = out[off + stride + 1] + block[3];
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void put(int[][] mbPix, byte[][] buf, int stride, int chromaFormat, int mbX, int mbY, int width, int height, int vertOff, int vertStep) {
/* 143 */     int chromaStride = stride + (1 << MPEGConst.SQUEEZE_X[chromaFormat]) - 1 >> MPEGConst.SQUEEZE_X[chromaFormat];
/* 144 */     int chromaMBW = 2 - MPEGConst.SQUEEZE_X[chromaFormat];
/* 145 */     int chromaMBH = 2 - MPEGConst.SQUEEZE_Y[chromaFormat];
/*     */     
/* 147 */     putSub(buf[0], (mbY << 2) * (stride << vertStep) + vertOff * stride + (mbX << 2), stride << vertStep, mbPix[0], 2, 2);
/*     */     
/* 149 */     putSub(buf[1], (mbY << chromaMBH) * (chromaStride << vertStep) + vertOff * chromaStride + (mbX << chromaMBW), chromaStride << vertStep, mbPix[1], chromaMBW, chromaMBH);
/*     */     
/* 151 */     putSub(buf[2], (mbY << chromaMBH) * (chromaStride << vertStep) + vertOff * chromaStride + (mbX << chromaMBW), chromaStride << vertStep, mbPix[2], chromaMBW, chromaMBH);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   protected void putSub(byte[] big, int off, int stride, int[] block, int mbW, int mbH) {
/* 157 */     int blOff = 0;
/*     */     
/* 159 */     if (mbW == 1) {
/* 160 */       big[off] = clipTo8Bit(block[blOff]);
/* 161 */       big[off + 1] = clipTo8Bit(block[blOff + 1]);
/* 162 */       big[off + stride] = clipTo8Bit(block[blOff + 2]);
/* 163 */       big[off + stride + 1] = clipTo8Bit(block[blOff + 3]);
/*     */       
/* 165 */       if (mbH == 2) {
/* 166 */         off += stride << 1;
/*     */         
/* 168 */         big[off] = clipTo8Bit(block[blOff + 4]);
/* 169 */         big[off + 1] = clipTo8Bit(block[blOff + 5]);
/* 170 */         big[off + stride] = clipTo8Bit(block[blOff + 6]);
/* 171 */         big[off + stride + 1] = clipTo8Bit(block[blOff + 7]);
/*     */       } 
/*     */     } else {
/* 174 */       for (int i = 0; i < 4; i++) {
/* 175 */         big[off] = clipTo8Bit(block[blOff]);
/* 176 */         big[off + 1] = clipTo8Bit(block[blOff + 1]);
/* 177 */         big[off + 2] = clipTo8Bit(block[blOff + 2]);
/* 178 */         big[off + 3] = clipTo8Bit(block[blOff + 3]);
/*     */         
/* 180 */         off += stride;
/* 181 */         blOff += 4;
/*     */       } 
/*     */     } 
/*     */   }
/*     */   
/* 186 */   public static int[][] scan2x2 = new int[][] { { 0, 1, 2, 4, 3, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4 }, { 0, 2, 4, 4, 1, 3, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4 } };
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected MPEGDecoder.Context initContext(SequenceHeader sh, PictureHeader ph) {
/* 193 */     MPEGDecoder.Context context = super.initContext(sh, ph);
/* 194 */     context.codedWidth >>= 2;
/* 195 */     context.codedHeight >>= 2;
/* 196 */     context.picWidth >>= 2;
/* 197 */     context.picHeight >>= 2;
/*     */     
/* 199 */     context.scan = scan2x2[(ph.pictureCodingExtension == null) ? 0 : ph.pictureCodingExtension.alternate_scan];
/*     */     
/* 201 */     return context;
/*     */   }
/*     */ }


/* Location:              C:\Users\rapha\Downloads\aurora.jar!\META-INF\jars\jcodec-0.2.5.jar!\org\jcodec\codecs\mpeg12\Mpeg2Thumb2x2.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */