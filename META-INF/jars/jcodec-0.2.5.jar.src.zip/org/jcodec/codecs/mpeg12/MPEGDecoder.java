/*     */ package org.jcodec.codecs.mpeg12;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.nio.ByteBuffer;
/*     */ import java.nio.ByteOrder;
/*     */ import org.jcodec.codecs.mpeg12.bitstream.GOPHeader;
/*     */ import org.jcodec.codecs.mpeg12.bitstream.PictureHeader;
/*     */ import org.jcodec.codecs.mpeg12.bitstream.SequenceHeader;
/*     */ import org.jcodec.codecs.mpeg12.bitstream.SequenceScalableExtension;
/*     */ import org.jcodec.common.Preconditions;
/*     */ import org.jcodec.common.UsedViaReflection;
/*     */ import org.jcodec.common.VideoCodecMeta;
/*     */ import org.jcodec.common.VideoDecoder;
/*     */ import org.jcodec.common.dct.SparseIDCT;
/*     */ import org.jcodec.common.io.BitReader;
/*     */ import org.jcodec.common.io.VLC;
/*     */ import org.jcodec.common.model.ColorSpace;
/*     */ import org.jcodec.common.model.Picture;
/*     */ import org.jcodec.common.model.Rect;
/*     */ import org.jcodec.common.model.Size;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class MPEGDecoder
/*     */   extends VideoDecoder
/*     */ {
/*     */   protected SequenceHeader sh;
/*     */   protected GOPHeader gh;
/*  73 */   private Picture[] refFrames = new Picture[2];
/*  74 */   private Picture[] refFields = new Picture[2];
/*     */ 
/*     */   
/*     */   public static class Context
/*     */   {
/*     */     public int mbWidth;
/*     */     
/*     */     int mbNo;
/*     */     
/*     */     public int codedWidth;
/*     */     
/*     */     public int codedHeight;
/*     */     
/*     */     public int mbHeight;
/*     */     public ColorSpace color;
/*     */     public MPEGConst.MBType lastPredB;
/*     */     public int[][] qMats;
/*     */     public int[] scan;
/*  92 */     int[] intra_dc_predictor = new int[3];
/*     */     
/*     */     public int picWidth;
/*     */     public int picHeight;
/*     */   }
/*     */   
/*     */   public Picture decodeFrame(ByteBuffer buffer, byte[][] buf) {
/*  99 */     PictureHeader ph = readHeader(buffer);
/* 100 */     if ((this.refFrames[0] == null && ph.picture_coding_type > 1) || (this.refFrames[1] == null && ph.picture_coding_type > 2)) {
/* 101 */       throw new RuntimeException("Not enough references to decode " + ((ph.picture_coding_type == 1) ? "P" : "B") + " frame");
/*     */     }
/*     */     
/* 104 */     Context context = initContext(this.sh, ph);
/* 105 */     Picture pic = new Picture(context.codedWidth, context.codedHeight, buf, (byte[][])null, context.color, 0, new Rect(0, 0, context.picWidth, context.picHeight));
/*     */     
/* 107 */     if (ph.pictureCodingExtension != null && ph.pictureCodingExtension.picture_structure != 3) {
/* 108 */       decodePicture(context, ph, buffer, buf, ph.pictureCodingExtension.picture_structure - 1, 1);
/* 109 */       ph = readHeader(buffer);
/* 110 */       context = initContext(this.sh, ph);
/* 111 */       decodePicture(context, ph, buffer, buf, ph.pictureCodingExtension.picture_structure - 1, 1);
/*     */     } else {
/* 113 */       decodePicture(context, ph, buffer, buf, 0, 0);
/*     */     } 
/*     */     
/* 116 */     if (ph.picture_coding_type == 1 || ph.picture_coding_type == 2) {
/* 117 */       Picture unused = this.refFrames[1];
/* 118 */       this.refFrames[1] = this.refFrames[0];
/* 119 */       this.refFrames[0] = copyAndCreateIfNeeded(pic, unused);
/*     */     } 
/*     */     
/* 122 */     return pic;
/*     */   }
/*     */   
/*     */   private Picture copyAndCreateIfNeeded(Picture src, Picture dst) {
/* 126 */     if (dst == null || !dst.compatible(src)) {
/* 127 */       dst = src.createCompatible();
/*     */     }
/* 129 */     dst.copyFrom(src);
/* 130 */     return dst;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private PictureHeader readHeader(ByteBuffer buffer) {
/*     */     // Byte code:
/*     */     //   0: aconst_null
/*     */     //   1: astore_2
/*     */     //   2: aload_1
/*     */     //   3: invokevirtual duplicate : ()Ljava/nio/ByteBuffer;
/*     */     //   6: astore #4
/*     */     //   8: aload #4
/*     */     //   10: invokestatic nextSegment : (Ljava/nio/ByteBuffer;)Ljava/nio/ByteBuffer;
/*     */     //   13: dup
/*     */     //   14: astore_3
/*     */     //   15: ifnull -> 178
/*     */     //   18: aload_3
/*     */     //   19: invokevirtual getInt : ()I
/*     */     //   22: sipush #255
/*     */     //   25: iand
/*     */     //   26: istore #5
/*     */     //   28: iload #5
/*     */     //   30: sipush #179
/*     */     //   33: if_icmpne -> 67
/*     */     //   36: aload_3
/*     */     //   37: invokestatic read : (Ljava/nio/ByteBuffer;)Lorg/jcodec/codecs/mpeg12/bitstream/SequenceHeader;
/*     */     //   40: astore #6
/*     */     //   42: aload_0
/*     */     //   43: getfield sh : Lorg/jcodec/codecs/mpeg12/bitstream/SequenceHeader;
/*     */     //   46: ifnull -> 58
/*     */     //   49: aload #6
/*     */     //   51: aload_0
/*     */     //   52: getfield sh : Lorg/jcodec/codecs/mpeg12/bitstream/SequenceHeader;
/*     */     //   55: invokevirtual copyExtensions : (Lorg/jcodec/codecs/mpeg12/bitstream/SequenceHeader;)V
/*     */     //   58: aload_0
/*     */     //   59: aload #6
/*     */     //   61: putfield sh : Lorg/jcodec/codecs/mpeg12/bitstream/SequenceHeader;
/*     */     //   64: goto -> 165
/*     */     //   67: iload #5
/*     */     //   69: sipush #184
/*     */     //   72: if_icmpne -> 86
/*     */     //   75: aload_0
/*     */     //   76: aload_3
/*     */     //   77: invokestatic read : (Ljava/nio/ByteBuffer;)Lorg/jcodec/codecs/mpeg12/bitstream/GOPHeader;
/*     */     //   80: putfield gh : Lorg/jcodec/codecs/mpeg12/bitstream/GOPHeader;
/*     */     //   83: goto -> 165
/*     */     //   86: iload #5
/*     */     //   88: ifne -> 99
/*     */     //   91: aload_3
/*     */     //   92: invokestatic read : (Ljava/nio/ByteBuffer;)Lorg/jcodec/codecs/mpeg12/bitstream/PictureHeader;
/*     */     //   95: astore_2
/*     */     //   96: goto -> 165
/*     */     //   99: iload #5
/*     */     //   101: sipush #181
/*     */     //   104: if_icmpne -> 157
/*     */     //   107: aload_3
/*     */     //   108: iconst_4
/*     */     //   109: invokevirtual get : (I)B
/*     */     //   112: iconst_4
/*     */     //   113: ishr
/*     */     //   114: istore #6
/*     */     //   116: iload #6
/*     */     //   118: iconst_1
/*     */     //   119: if_icmpeq -> 134
/*     */     //   122: iload #6
/*     */     //   124: iconst_5
/*     */     //   125: if_icmpeq -> 134
/*     */     //   128: iload #6
/*     */     //   130: iconst_2
/*     */     //   131: if_icmpne -> 145
/*     */     //   134: aload_3
/*     */     //   135: aload_0
/*     */     //   136: getfield sh : Lorg/jcodec/codecs/mpeg12/bitstream/SequenceHeader;
/*     */     //   139: invokestatic readExtension : (Ljava/nio/ByteBuffer;Lorg/jcodec/codecs/mpeg12/bitstream/SequenceHeader;)V
/*     */     //   142: goto -> 154
/*     */     //   145: aload_3
/*     */     //   146: aload_2
/*     */     //   147: aload_0
/*     */     //   148: getfield sh : Lorg/jcodec/codecs/mpeg12/bitstream/SequenceHeader;
/*     */     //   151: invokestatic readExtension : (Ljava/nio/ByteBuffer;Lorg/jcodec/codecs/mpeg12/bitstream/PictureHeader;Lorg/jcodec/codecs/mpeg12/bitstream/SequenceHeader;)V
/*     */     //   154: goto -> 165
/*     */     //   157: iload #5
/*     */     //   159: sipush #178
/*     */     //   162: if_icmpne -> 178
/*     */     //   165: aload_1
/*     */     //   166: aload #4
/*     */     //   168: invokevirtual position : ()I
/*     */     //   171: invokevirtual position : (I)Ljava/nio/Buffer;
/*     */     //   174: pop
/*     */     //   175: goto -> 8
/*     */     //   178: aload_2
/*     */     //   179: areturn
/*     */     // Line number table:
/*     */     //   Java source line number -> byte code offset
/*     */     //   #134	-> 0
/*     */     //   #136	-> 2
/*     */     //   #138	-> 8
/*     */     //   #139	-> 18
/*     */     //   #140	-> 28
/*     */     //   #141	-> 36
/*     */     //   #142	-> 42
/*     */     //   #143	-> 49
/*     */     //   #145	-> 58
/*     */     //   #146	-> 64
/*     */     //   #147	-> 75
/*     */     //   #148	-> 86
/*     */     //   #149	-> 91
/*     */     //   #150	-> 99
/*     */     //   #151	-> 107
/*     */     //   #152	-> 116
/*     */     //   #155	-> 134
/*     */     //   #157	-> 145
/*     */     //   #158	-> 154
/*     */     //   #163	-> 165
/*     */     //   #164	-> 175
/*     */     //   #165	-> 178
/*     */     // Local variable table:
/*     */     //   start	length	slot	name	descriptor
/*     */     //   42	22	6	newSh	Lorg/jcodec/codecs/mpeg12/bitstream/SequenceHeader;
/*     */     //   116	38	6	extType	I
/*     */     //   28	147	5	code	I
/*     */     //   0	180	0	this	Lorg/jcodec/codecs/mpeg12/MPEGDecoder;
/*     */     //   0	180	1	buffer	Ljava/nio/ByteBuffer;
/*     */     //   2	178	2	ph	Lorg/jcodec/codecs/mpeg12/bitstream/PictureHeader;
/*     */     //   15	165	3	segment	Ljava/nio/ByteBuffer;
/*     */     //   8	172	4	fork	Ljava/nio/ByteBuffer;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected Context initContext(SequenceHeader sh, PictureHeader ph) {
/* 169 */     Context context = new Context();
/* 170 */     context.codedWidth = sh.horizontal_size + 15 & 0xFFFFFFF0;
/* 171 */     context.codedHeight = getCodedHeight(sh, ph);
/* 172 */     context.mbWidth = sh.horizontal_size + 15 >> 4;
/* 173 */     context.mbHeight = sh.vertical_size + 15 >> 4;
/* 174 */     context.picWidth = sh.horizontal_size;
/* 175 */     context.picHeight = sh.vertical_size;
/*     */     
/* 177 */     int chromaFormat = 1;
/* 178 */     if (sh.sequenceExtension != null) {
/* 179 */       chromaFormat = sh.sequenceExtension.chroma_format;
/*     */     }
/* 181 */     context.color = getColor(chromaFormat);
/*     */     
/* 183 */     context.scan = MPEGConst.scan[(ph.pictureCodingExtension == null) ? 0 : ph.pictureCodingExtension.alternate_scan];
/*     */     
/* 185 */     int[] inter = (sh.non_intra_quantiser_matrix == null) ? zigzag(MPEGConst.defaultQMatInter, context.scan) : sh.non_intra_quantiser_matrix;
/*     */     
/* 187 */     int[] intra = (sh.intra_quantiser_matrix == null) ? zigzag(MPEGConst.defaultQMatIntra, context.scan) : sh.intra_quantiser_matrix;
/*     */     
/* 189 */     context.qMats = new int[][] { inter, inter, intra, intra };
/*     */     
/* 191 */     if (ph.quantMatrixExtension != null) {
/* 192 */       if (ph.quantMatrixExtension.non_intra_quantiser_matrix != null)
/* 193 */         context.qMats[0] = ph.quantMatrixExtension.non_intra_quantiser_matrix; 
/* 194 */       if (ph.quantMatrixExtension.chroma_non_intra_quantiser_matrix != null)
/* 195 */         context.qMats[1] = ph.quantMatrixExtension.chroma_non_intra_quantiser_matrix; 
/* 196 */       if (ph.quantMatrixExtension.intra_quantiser_matrix != null)
/* 197 */         context.qMats[2] = ph.quantMatrixExtension.intra_quantiser_matrix; 
/* 198 */       if (ph.quantMatrixExtension.chroma_intra_quantiser_matrix != null)
/* 199 */         context.qMats[3] = ph.quantMatrixExtension.chroma_intra_quantiser_matrix; 
/*     */     } 
/* 201 */     return context;
/*     */   }
/*     */   
/*     */   private int[] zigzag(int[] array, int[] scan) {
/* 205 */     int[] result = new int[64];
/* 206 */     for (int i = 0; i < scan.length; i++)
/* 207 */       result[i] = array[scan[i]]; 
/* 208 */     return result;
/*     */   }
/*     */   
/*     */   public static int getCodedHeight(SequenceHeader sh, PictureHeader ph) {
/* 212 */     int field = (ph.pictureCodingExtension != null && ph.pictureCodingExtension.picture_structure != 3) ? 1 : 0;
/*     */     
/* 214 */     return ((sh.vertical_size >> field) + 15 & 0xFFFFFFF0) << field;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public Picture decodePicture(Context context, PictureHeader ph, ByteBuffer buffer, byte[][] buf, int vertOff, int vertStep) {
/* 220 */     int planeSize = context.codedWidth * context.codedHeight;
/* 221 */     if (buf.length < 3 || (buf[0]).length < planeSize || (buf[1]).length < planeSize || (buf[2]).length < planeSize) {
/* 222 */       throw new RuntimeException("ByteBuffer too small to hold output picture [" + context.codedWidth + "x" + context.codedHeight + "]");
/*     */     }
/*     */     
/*     */     try {
/*     */       ByteBuffer segment;
/*     */       
/* 228 */       while ((segment = MPEGUtil.nextSegment(buffer)) != null) {
/* 229 */         int startCode = segment.get(3) & 0xFF;
/* 230 */         if (startCode >= 1 && startCode <= 175) {
/* 231 */           doDecodeSlice(context, ph, buf, vertOff, vertStep, segment); continue;
/* 232 */         }  if (startCode >= 179 && startCode != 182 && startCode != 183)
/* 233 */           throw new RuntimeException("Unexpected start code " + startCode); 
/* 234 */         if (startCode == 0) {
/* 235 */           buffer.reset();
/*     */           
/*     */           break;
/*     */         } 
/*     */       } 
/* 240 */       Picture pic = Picture.createPicture(context.codedWidth, context.codedHeight, buf, context.color);
/*     */       
/* 242 */       if ((ph.picture_coding_type == 1 || ph.picture_coding_type == 2) && ph.pictureCodingExtension != null && ph.pictureCodingExtension.picture_structure != 3)
/*     */       {
/* 244 */         this.refFields[ph.pictureCodingExtension.picture_structure - 1] = copyAndCreateIfNeeded(pic, this.refFields[ph.pictureCodingExtension.picture_structure - 1]);
/*     */       }
/*     */ 
/*     */       
/* 248 */       return pic;
/* 249 */     } catch (IOException e) {
/* 250 */       throw new RuntimeException(e);
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   private void doDecodeSlice(Context context, PictureHeader ph, byte[][] buf, int vertOff, int vertStep, ByteBuffer segment) throws IOException {
/* 256 */     int startCode = segment.get(3) & 0xFF;
/* 257 */     ByteBuffer dup = segment.duplicate();
/* 258 */     dup.position(4);
/*     */     try {
/* 260 */       decodeSlice(ph, startCode, context, buf, BitReader.createBitReader(dup), vertOff, vertStep);
/* 261 */     } catch (RuntimeException e) {
/* 262 */       e.printStackTrace();
/*     */     } 
/*     */   }
/*     */   
/*     */   private ColorSpace getColor(int chromaFormat) {
/* 267 */     switch (chromaFormat) {
/*     */       case 1:
/* 269 */         return ColorSpace.YUV420;
/*     */       case 2:
/* 271 */         return ColorSpace.YUV422;
/*     */       case 3:
/* 273 */         return ColorSpace.YUV444;
/*     */     } 
/*     */     
/* 276 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void decodeSlice(PictureHeader ph, int verticalPos, Context context, byte[][] buf, BitReader _in, int vertOff, int vertStep) throws IOException {
/* 282 */     int stride = context.codedWidth;
/*     */     
/* 284 */     resetDCPredictors(context, ph);
/*     */     
/* 286 */     int mbRow = verticalPos - 1;
/* 287 */     if (this.sh.vertical_size > 2800) {
/* 288 */       mbRow += _in.readNBit(3) << 7;
/*     */     }
/* 290 */     if (this.sh.sequenceScalableExtension != null && this.sh.sequenceScalableExtension.scalable_mode == 0)
/*     */     {
/* 292 */       int i = _in.readNBit(7);
/*     */     }
/* 294 */     int qScaleCode = _in.readNBit(5);
/* 295 */     if (_in.read1Bit() == 1) {
/* 296 */       int intraSlice = _in.read1Bit();
/* 297 */       _in.skip(7);
/* 298 */       while (_in.read1Bit() == 1) {
/* 299 */         _in.readNBit(8);
/*     */       }
/*     */     } 
/* 302 */     (new int[2])[0] = ph.forward_f_code; (new int[2])[1] = ph.forward_f_code; (new int[2][])[0] = new int[2]; (new int[2])[0] = ph.backward_f_code; (new int[2])[1] = ph.backward_f_code; (new int[2][])[1] = new int[2]; MPEGPred pred = new MPEGPred((ph.pictureCodingExtension != null) ? ph.pictureCodingExtension.f_code : new int[2][], (this.sh.sequenceExtension != null) ? this.sh.sequenceExtension.chroma_format : 1, !(ph.pictureCodingExtension != null && ph.pictureCodingExtension.top_field_first == 0));
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 309 */     int[] ctx = { qScaleCode };
/*     */     
/* 311 */     for (int prevAddr = mbRow * context.mbWidth - 1; _in.checkNBit(23) != 0; ) {
/*     */       
/* 313 */       prevAddr = decodeMacroblock(ph, context, prevAddr, ctx, buf, stride, _in, vertOff, vertStep, pred);
/* 314 */       context.mbNo++;
/*     */     } 
/*     */   }
/*     */   
/*     */   private void resetDCPredictors(Context context, PictureHeader ph) {
/* 319 */     int rval = 128;
/* 320 */     if (ph.pictureCodingExtension != null)
/* 321 */       rval = 1 << 7 + ph.pictureCodingExtension.intra_dc_precision; 
/* 322 */     context.intra_dc_predictor[2] = rval; context.intra_dc_predictor[1] = rval; context.intra_dc_predictor[0] = rval;
/*     */   }
/*     */ 
/*     */   
/*     */   public int decodeMacroblock(PictureHeader ph, Context context, int prevAddr, int[] qScaleCode, byte[][] buf, int stride, BitReader bits, int vertOff, int vertStep, MPEGPred pred) {
/* 327 */     int mbAddr = prevAddr;
/* 328 */     while (bits.checkNBit(11) == 8) {
/* 329 */       bits.skip(11);
/* 330 */       mbAddr += 33;
/*     */     } 
/* 332 */     mbAddr += MPEGConst.vlcAddressIncrement.readVLC(bits) + 1;
/*     */     
/* 334 */     int chromaFormat = 1;
/* 335 */     if (this.sh.sequenceExtension != null) {
/* 336 */       chromaFormat = this.sh.sequenceExtension.chroma_format;
/*     */     }
/* 338 */     for (int i = prevAddr + 1; i < mbAddr; i++) {
/* 339 */       int[][] arrayOfInt = { new int[256], new int[1 << chromaFormat + 5], new int[1 << chromaFormat + 5] };
/*     */       
/* 341 */       int k = i % context.mbWidth;
/* 342 */       int m = i / context.mbWidth;
/* 343 */       if (ph.picture_coding_type == 2)
/* 344 */         pred.reset(); 
/* 345 */       mvZero(context, ph, pred, k, m, arrayOfInt);
/* 346 */       put(arrayOfInt, buf, stride, chromaFormat, k, m, context.codedWidth, context.codedHeight >> vertStep, vertOff, vertStep);
/*     */     } 
/*     */ 
/*     */     
/* 350 */     VLC vlcMBType = SequenceScalableExtension.vlcMBType(ph.picture_coding_type, this.sh.sequenceScalableExtension);
/* 351 */     MPEGConst.MBType[] mbTypeVal = SequenceScalableExtension.mbTypeVal(ph.picture_coding_type, this.sh.sequenceScalableExtension);
/*     */     
/* 353 */     MPEGConst.MBType mbType = mbTypeVal[vlcMBType.readVLC(bits)];
/*     */     
/* 355 */     if (mbType.macroblock_intra != 1 || mbAddr - prevAddr > 1) {
/* 356 */       resetDCPredictors(context, ph);
/*     */     }
/*     */     
/* 359 */     int spatial_temporal_weight_code = 0;
/* 360 */     if (mbType.spatial_temporal_weight_code_flag == 1 && ph.pictureSpatialScalableExtension != null && ph.pictureSpatialScalableExtension.spatial_temporal_weight_code_table_index != 0)
/*     */     {
/* 362 */       spatial_temporal_weight_code = bits.readNBit(2);
/*     */     }
/*     */     
/* 365 */     int motion_type = -1;
/* 366 */     if (mbType.macroblock_motion_forward != 0 || mbType.macroblock_motion_backward != 0) {
/* 367 */       if (ph.pictureCodingExtension == null || (ph.pictureCodingExtension.picture_structure == 3 && ph.pictureCodingExtension.frame_pred_frame_dct == 1)) {
/*     */         
/* 369 */         motion_type = 2;
/*     */       } else {
/* 371 */         motion_type = bits.readNBit(2);
/*     */       } 
/*     */     }
/* 374 */     int dctType = 0;
/* 375 */     if (ph.pictureCodingExtension != null && ph.pictureCodingExtension.picture_structure == 3 && ph.pictureCodingExtension.frame_pred_frame_dct == 0 && (mbType.macroblock_intra != 0 || mbType.macroblock_pattern != 0))
/*     */     {
/*     */       
/* 378 */       dctType = bits.read1Bit();
/*     */     }
/*     */ 
/*     */     
/* 382 */     if (mbType.macroblock_quant != 0) {
/* 383 */       qScaleCode[0] = bits.readNBit(5);
/*     */     }
/* 385 */     boolean concealmentMv = (ph.pictureCodingExtension != null && ph.pictureCodingExtension.concealment_motion_vectors != 0);
/*     */ 
/*     */     
/* 388 */     int[][] predFwd = (int[][])null;
/* 389 */     int mbX = mbAddr % context.mbWidth;
/* 390 */     int mbY = mbAddr / context.mbWidth;
/* 391 */     if (mbType.macroblock_intra == 1) {
/* 392 */       if (!concealmentMv)
/*     */       {
/*     */         
/* 395 */         pred.reset(); } 
/* 396 */     } else if (mbType.macroblock_motion_forward != 0) {
/* 397 */       int refIdx = (ph.picture_coding_type == 2) ? 0 : 1;
/* 398 */       predFwd = new int[][] { new int[256], new int[1 << chromaFormat + 5], new int[1 << chromaFormat + 5] };
/* 399 */       if (ph.pictureCodingExtension == null || ph.pictureCodingExtension.picture_structure == 3) {
/* 400 */         pred.predictInFrame(this.refFrames[refIdx], mbX << 4, mbY << 4, predFwd, bits, motion_type, 0, spatial_temporal_weight_code);
/*     */       
/*     */       }
/* 403 */       else if (ph.picture_coding_type == 2) {
/* 404 */         pred.predictInField(this.refFields, mbX << 4, mbY << 4, predFwd, bits, motion_type, 0, ph.pictureCodingExtension.picture_structure - 1);
/*     */       } else {
/*     */         
/* 407 */         pred.predictInField(new Picture[] { this.refFrames[refIdx], this.refFrames[refIdx] }, mbX << 4, mbY << 4, predFwd, bits, motion_type, 0, ph.pictureCodingExtension.picture_structure - 1);
/*     */       }
/*     */     
/*     */     }
/* 411 */     else if (ph.picture_coding_type == 2) {
/* 412 */       predFwd = new int[][] { new int[256], new int[1 << chromaFormat + 5], new int[1 << chromaFormat + 5] };
/* 413 */       pred.reset();
/* 414 */       mvZero(context, ph, pred, mbX, mbY, predFwd);
/*     */     } 
/*     */     
/* 417 */     int[][] predBack = (int[][])null;
/* 418 */     if (mbType.macroblock_motion_backward != 0) {
/* 419 */       predBack = new int[][] { new int[256], new int[1 << chromaFormat + 5], new int[1 << chromaFormat + 5] };
/* 420 */       if (ph.pictureCodingExtension == null || ph.pictureCodingExtension.picture_structure == 3) {
/* 421 */         pred.predictInFrame(this.refFrames[0], mbX << 4, mbY << 4, predBack, bits, motion_type, 1, spatial_temporal_weight_code);
/*     */       } else {
/*     */         
/* 424 */         pred.predictInField(new Picture[] { this.refFrames[0], this.refFrames[0] }, mbX << 4, mbY << 4, predBack, bits, motion_type, 1, ph.pictureCodingExtension.picture_structure - 1);
/*     */       } 
/*     */     } 
/*     */     
/* 428 */     context.lastPredB = mbType;
/* 429 */     (new int[3][])[0] = new int[256]; (new int[3][])[1] = new int[1 << chromaFormat + 5]; (new int[3][])[2] = new int[1 << chromaFormat + 5];
/*     */     
/* 431 */     int[][] pp = (mbType.macroblock_intra == 1) ? new int[3][] : buildPred(predFwd, predBack);
/*     */     
/* 433 */     if (mbType.macroblock_intra != 0 && concealmentMv) {
/* 434 */       Preconditions.checkState((1 == bits.read1Bit()));
/*     */     }
/* 436 */     int cbp = (mbType.macroblock_intra == 1) ? 4095 : 0;
/* 437 */     if (mbType.macroblock_pattern != 0) {
/* 438 */       cbp = readCbPattern(bits);
/*     */     }
/*     */     
/* 441 */     VLC vlcCoeff = MPEGConst.vlcCoeff0;
/* 442 */     if (ph.pictureCodingExtension != null && mbType.macroblock_intra == 1 && ph.pictureCodingExtension.intra_vlc_format == 1)
/*     */     {
/* 444 */       vlcCoeff = MPEGConst.vlcCoeff1;
/*     */     }
/* 446 */     int[] qScaleTab = (ph.pictureCodingExtension != null && ph.pictureCodingExtension.q_scale_type == 1) ? MPEGConst.qScaleTab2 : MPEGConst.qScaleTab1;
/*     */     
/* 448 */     int qScale = qScaleTab[qScaleCode[0]];
/*     */     
/* 450 */     int intra_dc_mult = 8;
/* 451 */     if (ph.pictureCodingExtension != null) {
/* 452 */       intra_dc_mult = 8 >> ph.pictureCodingExtension.intra_dc_precision;
/*     */     }
/* 454 */     int blkCount = 6 + ((chromaFormat == 1) ? 0 : ((chromaFormat == 2) ? 2 : 6));
/* 455 */     int[] block = new int[64];
/*     */     int cbpMask;
/* 457 */     for (int j = 0; j < blkCount; j++, cbpMask >>= 1) {
/* 458 */       if ((cbp & cbpMask) != 0) {
/*     */         
/* 460 */         int[] qmat = context.qMats[((j >= 4) ? 1 : 0) + (mbType.macroblock_intra << 1)];
/*     */         
/* 462 */         if (mbType.macroblock_intra == 1) {
/* 463 */           blockIntra(bits, vlcCoeff, block, context.intra_dc_predictor, j, context.scan, (this.sh
/* 464 */               .hasExtensions() || ph.hasExtensions()) ? 12 : 8, intra_dc_mult, qScale, qmat);
/*     */         } else {
/* 466 */           blockInter(bits, vlcCoeff, block, context.scan, (this.sh.hasExtensions() || ph.hasExtensions()) ? 12 : 8, qScale, qmat);
/*     */         } 
/*     */         
/* 469 */         mapBlock(block, pp[MPEGConst.BLOCK_TO_CC[j]], j, dctType, chromaFormat);
/*     */       } 
/*     */     } 
/* 472 */     put(pp, buf, stride, chromaFormat, mbX, mbY, context.codedWidth, context.codedHeight >> vertStep, vertOff, vertStep);
/*     */ 
/*     */     
/* 475 */     return mbAddr;
/*     */   }
/*     */   
/*     */   protected void mapBlock(int[] block, int[] out, int blkIdx, int dctType, int chromaFormat) {
/* 479 */     int stepVert = (chromaFormat == 1 && (blkIdx == 4 || blkIdx == 5)) ? 0 : dctType;
/* 480 */     int log2stride = (blkIdx < 4) ? 4 : (4 - MPEGConst.SQUEEZE_X[chromaFormat]);
/*     */     
/* 482 */     int blkIdxExt = blkIdx + (dctType << 4);
/* 483 */     int x = MPEGConst.BLOCK_POS_X[blkIdxExt];
/* 484 */     int y = MPEGConst.BLOCK_POS_Y[blkIdxExt];
/* 485 */     int off = (y << log2stride) + x, stride = 1 << log2stride + stepVert;
/* 486 */     for (int i = 0, coeff = 0; i < 8; i++, coeff += 8) {
/* 487 */       out[off] = out[off] + block[coeff];
/* 488 */       out[off + 1] = out[off + 1] + block[coeff + 1];
/* 489 */       out[off + 2] = out[off + 2] + block[coeff + 2];
/* 490 */       out[off + 3] = out[off + 3] + block[coeff + 3];
/* 491 */       out[off + 4] = out[off + 4] + block[coeff + 4];
/* 492 */       out[off + 5] = out[off + 5] + block[coeff + 5];
/* 493 */       out[off + 6] = out[off + 6] + block[coeff + 6];
/* 494 */       out[off + 7] = out[off + 7] + block[coeff + 7];
/*     */       
/* 496 */       off += stride;
/*     */     } 
/*     */   }
/*     */   
/*     */   private static final int[][] buildPred(int[][] predFwd, int[][] predBack) {
/* 501 */     if (predFwd != null && predBack != null) {
/* 502 */       avgPred(predFwd, predBack);
/* 503 */       return predFwd;
/* 504 */     }  if (predFwd != null)
/* 505 */       return predFwd; 
/* 506 */     if (predBack != null) {
/* 507 */       return predBack;
/*     */     }
/* 509 */     throw new RuntimeException("Omited pred _in B-frames --> invalid");
/*     */   }
/*     */   
/*     */   private static final void avgPred(int[][] predFwd, int[][] predBack) {
/* 513 */     for (int i = 0; i < predFwd.length; i++) {
/* 514 */       for (int j = 0; j < (predFwd[i]).length; j += 4) {
/* 515 */         predFwd[i][j] = predFwd[i][j] + predBack[i][j] + 1 >> 1;
/* 516 */         predFwd[i][j + 1] = predFwd[i][j + 1] + predBack[i][j + 1] + 1 >> 1;
/* 517 */         predFwd[i][j + 2] = predFwd[i][j + 2] + predBack[i][j + 2] + 1 >> 1;
/* 518 */         predFwd[i][j + 3] = predFwd[i][j + 3] + predBack[i][j + 3] + 1 >> 1;
/*     */       } 
/*     */     } 
/*     */   }
/*     */   
/*     */   private void mvZero(Context context, PictureHeader ph, MPEGPred pred, int mbX, int mbY, int[][] mbPix) {
/* 524 */     if (ph.picture_coding_type == 2) {
/* 525 */       pred.predict16x16NoMV(this.refFrames[0], mbX << 4, mbY << 4, (ph.pictureCodingExtension == null) ? 3 : ph.pictureCodingExtension.picture_structure, 0, mbPix);
/*     */     } else {
/*     */       
/* 528 */       int[][] pp = mbPix;
/* 529 */       if (context.lastPredB.macroblock_motion_backward == 1) {
/* 530 */         pred.predict16x16NoMV(this.refFrames[0], mbX << 4, mbY << 4, (ph.pictureCodingExtension == null) ? 3 : ph.pictureCodingExtension.picture_structure, 1, pp);
/*     */         
/* 532 */         pp = new int[][] { new int[(mbPix[0]).length], new int[(mbPix[1]).length], new int[(mbPix[2]).length] };
/*     */       } 
/* 534 */       if (context.lastPredB.macroblock_motion_forward == 1) {
/* 535 */         pred.predict16x16NoMV(this.refFrames[1], mbX << 4, mbY << 4, (ph.pictureCodingExtension == null) ? 3 : ph.pictureCodingExtension.picture_structure, 0, pp);
/*     */         
/* 537 */         if (mbPix != pp) {
/* 538 */           avgPred(mbPix, pp);
/*     */         }
/*     */       } 
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   protected void put(int[][] mbPix, byte[][] buf, int stride, int chromaFormat, int mbX, int mbY, int width, int height, int vertOff, int vertStep) {
/* 546 */     int chromaStride = stride + (1 << MPEGConst.SQUEEZE_X[chromaFormat]) - 1 >> MPEGConst.SQUEEZE_X[chromaFormat];
/* 547 */     int chromaMBW = 4 - MPEGConst.SQUEEZE_X[chromaFormat];
/* 548 */     int chromaMBH = 4 - MPEGConst.SQUEEZE_Y[chromaFormat];
/*     */     
/* 550 */     putSub(buf[0], (mbY << 4) * (stride << vertStep) + vertOff * stride + (mbX << 4), stride << vertStep, mbPix[0], 4, 4);
/*     */     
/* 552 */     putSub(buf[1], (mbY << chromaMBH) * (chromaStride << vertStep) + vertOff * chromaStride + (mbX << chromaMBW), chromaStride << vertStep, mbPix[1], chromaMBW, chromaMBH);
/*     */     
/* 554 */     putSub(buf[2], (mbY << chromaMBH) * (chromaStride << vertStep) + vertOff * chromaStride + (mbX << chromaMBW), chromaStride << vertStep, mbPix[2], chromaMBW, chromaMBH);
/*     */   }
/*     */ 
/*     */   
/*     */   protected void putSub(byte[] big, int off, int stride, int[] block, int mbW, int mbH) {
/* 559 */     int blOff = 0;
/*     */     
/* 561 */     if (mbW == 3) {
/* 562 */       for (int i = 0; i < 1 << mbH; i++) {
/* 563 */         big[off] = clipTo8Bit(block[blOff]);
/* 564 */         big[off + 1] = clipTo8Bit(block[blOff + 1]);
/* 565 */         big[off + 2] = clipTo8Bit(block[blOff + 2]);
/* 566 */         big[off + 3] = clipTo8Bit(block[blOff + 3]);
/* 567 */         big[off + 4] = clipTo8Bit(block[blOff + 4]);
/* 568 */         big[off + 5] = clipTo8Bit(block[blOff + 5]);
/* 569 */         big[off + 6] = clipTo8Bit(block[blOff + 6]);
/* 570 */         big[off + 7] = clipTo8Bit(block[blOff + 7]);
/*     */         
/* 572 */         blOff += 8;
/* 573 */         off += stride;
/*     */       } 
/*     */     } else {
/* 576 */       for (int i = 0; i < 1 << mbH; i++) {
/* 577 */         big[off] = clipTo8Bit(block[blOff]);
/* 578 */         big[off + 1] = clipTo8Bit(block[blOff + 1]);
/* 579 */         big[off + 2] = clipTo8Bit(block[blOff + 2]);
/* 580 */         big[off + 3] = clipTo8Bit(block[blOff + 3]);
/* 581 */         big[off + 4] = clipTo8Bit(block[blOff + 4]);
/* 582 */         big[off + 5] = clipTo8Bit(block[blOff + 5]);
/* 583 */         big[off + 6] = clipTo8Bit(block[blOff + 6]);
/* 584 */         big[off + 7] = clipTo8Bit(block[blOff + 7]);
/* 585 */         big[off + 8] = clipTo8Bit(block[blOff + 8]);
/* 586 */         big[off + 9] = clipTo8Bit(block[blOff + 9]);
/* 587 */         big[off + 10] = clipTo8Bit(block[blOff + 10]);
/* 588 */         big[off + 11] = clipTo8Bit(block[blOff + 11]);
/* 589 */         big[off + 12] = clipTo8Bit(block[blOff + 12]);
/* 590 */         big[off + 13] = clipTo8Bit(block[blOff + 13]);
/* 591 */         big[off + 14] = clipTo8Bit(block[blOff + 14]);
/* 592 */         big[off + 15] = clipTo8Bit(block[blOff + 15]);
/*     */         
/* 594 */         blOff += 16;
/* 595 */         off += stride;
/*     */       } 
/*     */     } 
/*     */   }
/*     */   
/*     */   protected static final byte clipTo8Bit(int val) {
/* 601 */     return (byte)(((val < 0) ? 0 : ((val > 255) ? 255 : val)) - 128);
/*     */   }
/*     */   
/*     */   protected static final int clip(int val) {
/* 605 */     return (val < 0) ? 0 : ((val > 255) ? 255 : val);
/*     */   }
/*     */   
/*     */   protected static final int quantInter(int level, int quant) {
/* 609 */     return ((level << 1) + 1) * quant >> 5;
/*     */   }
/*     */   
/*     */   protected static final int quantInterSigned(int level, int quant) {
/* 613 */     return (level >= 0) ? quantInter(level, quant) : -quantInter(-level, quant);
/*     */   }
/*     */ 
/*     */   
/*     */   protected void blockIntra(BitReader bits, VLC vlcCoeff, int[] block, int[] intra_dc_predictor, int blkIdx, int[] scan, int escSize, int intra_dc_mult, int qScale, int[] qmat) {
/* 618 */     int cc = MPEGConst.BLOCK_TO_CC[blkIdx];
/* 619 */     int size = ((cc == 0) ? MPEGConst.vlcDCSizeLuma : MPEGConst.vlcDCSizeChroma).readVLC(bits);
/* 620 */     int delta = (size != 0) ? mpegSigned(bits, size) : 0;
/* 621 */     intra_dc_predictor[cc] = intra_dc_predictor[cc] + delta;
/* 622 */     int dc = intra_dc_predictor[cc] * intra_dc_mult;
/* 623 */     SparseIDCT.start(block, dc);
/*     */     
/* 625 */     for (int idx = 0; idx < 64; ) {
/* 626 */       int level, readVLC = vlcCoeff.readVLC(bits);
/*     */ 
/*     */       
/* 629 */       if (readVLC == 2048)
/*     */         break; 
/* 631 */       if (readVLC == 2049) {
/* 632 */         idx += bits.readNBit(6) + 1;
/* 633 */         level = twosSigned(bits, escSize) * qScale * qmat[idx];
/* 634 */         level = (level >= 0) ? (level >> 4) : -(-level >> 4);
/*     */       } else {
/* 636 */         idx += (readVLC >> 6) + 1;
/* 637 */         level = toSigned((readVLC & 0x3F) * qScale * qmat[idx] >> 4, bits.read1Bit());
/*     */       } 
/* 639 */       SparseIDCT.coeff(block, scan[idx], level);
/*     */     } 
/* 641 */     SparseIDCT.finish(block);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void blockInter(BitReader bits, VLC vlcCoeff, int[] block, int[] scan, int escSize, int qScale, int[] qmat) {
/* 649 */     int idx = -1;
/* 650 */     if (vlcCoeff == MPEGConst.vlcCoeff0 && bits.checkNBit(1) == 1) {
/* 651 */       bits.read1Bit();
/* 652 */       int dc = toSigned(quantInter(1, qScale * qmat[0]), bits.read1Bit());
/* 653 */       SparseIDCT.start(block, dc);
/* 654 */       idx++;
/*     */     } else {
/* 656 */       SparseIDCT.start(block, 0);
/*     */     } 
/*     */     
/* 659 */     while (idx < 64) {
/* 660 */       int ac, readVLC = vlcCoeff.readVLC(bits);
/*     */       
/* 662 */       if (readVLC == 2048)
/*     */         break; 
/* 664 */       if (readVLC == 2049) {
/* 665 */         idx += bits.readNBit(6) + 1;
/* 666 */         ac = quantInterSigned(twosSigned(bits, escSize), qScale * qmat[idx]);
/*     */       } else {
/* 668 */         idx += (readVLC >> 6) + 1;
/* 669 */         ac = toSigned(quantInter(readVLC & 0x3F, qScale * qmat[idx]), bits.read1Bit());
/*     */       } 
/* 671 */       SparseIDCT.coeff(block, scan[idx], ac);
/*     */     } 
/*     */     
/* 674 */     SparseIDCT.finish(block);
/*     */   }
/*     */   
/*     */   public static final int twosSigned(BitReader bits, int size) {
/* 678 */     int shift = 32 - size;
/* 679 */     return bits.readNBit(size) << shift >> shift;
/*     */   }
/*     */   
/*     */   public static final int mpegSigned(BitReader bits, int size) {
/* 683 */     int val = bits.readNBit(size);
/* 684 */     int sign = val >>> size - 1 ^ 0x1;
/* 685 */     return val + sign - (sign << size);
/*     */   }
/*     */   
/*     */   public static final int toSigned(int val, int s) {
/* 689 */     int sign = s << 31 >> 31;
/* 690 */     return (val ^ sign) - sign;
/*     */   }
/*     */   
/*     */   private final int readCbPattern(BitReader bits) {
/* 694 */     int cbp420 = MPEGConst.vlcCBP.readVLC(bits);
/* 695 */     if (this.sh.sequenceExtension == null || this.sh.sequenceExtension.chroma_format == 1)
/* 696 */       return cbp420; 
/* 697 */     if (this.sh.sequenceExtension.chroma_format == 2)
/* 698 */       return cbp420 << 2 | bits.readNBit(2); 
/* 699 */     if (this.sh.sequenceExtension.chroma_format == 3)
/* 700 */       return cbp420 << 6 | bits.readNBit(6); 
/* 701 */     throw new RuntimeException("Unsupported chroma format: " + this.sh.sequenceExtension.chroma_format);
/*     */   }
/*     */   
/*     */   @UsedViaReflection
/*     */   public static int probe(ByteBuffer data) {
/* 706 */     data = data.duplicate();
/* 707 */     data.order(ByteOrder.BIG_ENDIAN);
/*     */     
/* 709 */     for (int i = 0; i < 2 && 
/* 710 */       MPEGUtil.gotoNextMarker(data) != null; i++) {
/*     */       
/* 712 */       if (!data.hasRemaining())
/*     */         break; 
/* 714 */       int marker = data.getInt();
/*     */       
/* 716 */       if (marker == 256 || (marker >= 432 && marker <= 440))
/* 717 */         return 50 - i * 10; 
/* 718 */       if (marker > 256 && marker < 432)
/* 719 */         return 20 - i * 10; 
/*     */     } 
/* 721 */     return 0;
/*     */   }
/*     */   
/*     */   private static ByteBuffer getSequenceHeader(ByteBuffer data) {
/* 725 */     ByteBuffer segment = MPEGUtil.nextSegment(data);
/* 726 */     while (segment != null) {
/* 727 */       int marker = segment.getInt();
/* 728 */       if (marker == 435) {
/* 729 */         return segment;
/*     */       }
/* 731 */       segment = MPEGUtil.nextSegment(data);
/*     */     } 
/* 733 */     return null;
/*     */   }
/*     */   
/*     */   private static ByteBuffer getRawPictureHeader(ByteBuffer data) {
/* 737 */     ByteBuffer segment = MPEGUtil.nextSegment(data);
/* 738 */     while (segment != null) {
/* 739 */       int marker = segment.getInt();
/* 740 */       if (marker == 256) {
/* 741 */         return segment;
/*     */       }
/* 743 */       segment = MPEGUtil.nextSegment(data);
/*     */     } 
/* 745 */     return null;
/*     */   }
/*     */   
/*     */   public static int getSequenceNumber(ByteBuffer data) {
/* 749 */     PictureHeader ph = getPictureHeader(data);
/* 750 */     if (ph == null)
/* 751 */       return -1; 
/* 752 */     return ph.temporal_reference;
/*     */   }
/*     */   
/*     */   public static PictureHeader getPictureHeader(ByteBuffer data) {
/* 756 */     ByteBuffer bb = getRawPictureHeader(data);
/* 757 */     if (bb == null)
/* 758 */       return null; 
/* 759 */     PictureHeader ph = PictureHeader.read(bb);
/* 760 */     return ph;
/*     */   }
/*     */ 
/*     */   
/*     */   public VideoCodecMeta getCodecMeta(ByteBuffer data) {
/* 765 */     ByteBuffer codecPrivate = getSequenceHeader(data.duplicate());
/* 766 */     SequenceHeader sh = SequenceHeader.read(codecPrivate.duplicate());
/* 767 */     return VideoCodecMeta.createSimpleVideoCodecMeta(new Size(sh.horizontal_size, sh.vertical_size), ColorSpace.YUV420);
/*     */   }
/*     */ }


/* Location:              C:\Users\rapha\Downloads\aurora.jar!\META-INF\jars\jcodec-0.2.5.jar!\org\jcodec\codecs\mpeg12\MPEGDecoder.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */