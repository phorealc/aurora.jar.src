/*    */ package org.jcodec.codecs.mpeg12;
/*    */ 
/*    */ import java.io.File;
/*    */ import java.io.IOException;
/*    */ import java.util.Arrays;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class FixHLSTimestamps
/*    */   extends FixTimestamp
/*    */ {
/* 18 */   private long[] lastPts = new long[256];
/*    */ 
/*    */   
/*    */   public static void main1(String[] args) throws IOException {
/* 22 */     String wildCard = args[0];
/* 23 */     int startIdx = Integer.parseInt(args[1]);
/*    */     
/* 25 */     (new FixHLSTimestamps()).doIt(wildCard, startIdx);
/*    */   }
/*    */   
/*    */   private void doIt(String wildCard, int startIdx) throws IOException {
/* 29 */     Arrays.fill(this.lastPts, -1L);
/* 30 */     for (int i = startIdx;; i++) {
/* 31 */       File file = new File(String.format(wildCard, new Object[] { Integer.valueOf(i) }));
/* 32 */       System.out.println(file.getAbsolutePath());
/* 33 */       if (!file.exists())
/*    */         break; 
/* 35 */       fix(file);
/*    */     } 
/*    */   }
/*    */   
/*    */   protected long doWithTimestamp(int streamId, long pts, boolean isPts) {
/* 40 */     if (!isPts)
/* 41 */       return pts; 
/* 42 */     if (this.lastPts[streamId] == -1L) {
/* 43 */       this.lastPts[streamId] = pts;
/* 44 */       return pts;
/*    */     } 
/* 46 */     if (isVideo(streamId)) {
/* 47 */       this.lastPts[streamId] = this.lastPts[streamId] + 3003L;
/* 48 */       return this.lastPts[streamId];
/* 49 */     }  if (isAudio(streamId)) {
/* 50 */       this.lastPts[streamId] = this.lastPts[streamId] + 1920L;
/* 51 */       return this.lastPts[streamId];
/*    */     } 
/* 53 */     throw new RuntimeException("Unexpected!!!");
/*    */   }
/*    */ }


/* Location:              C:\Users\rapha\Downloads\aurora.jar!\META-INF\jars\jcodec-0.2.5.jar!\org\jcodec\codecs\mpeg12\FixHLSTimestamps.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */