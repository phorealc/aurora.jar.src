/*    */ package org.jcodec.codecs.mpeg12;
/*    */ 
/*    */ public class MPEGPredDbl extends MPEGPredOct {
/*    */   public MPEGPredDbl(MPEGPred other) {
/*  5 */     super(other);
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public void predictPlane(byte[] ref, int refX, int refY, int refW, int refH, int refVertStep, int refVertOff, int[] tgt, int tgtY, int tgtW, int tgtH, int tgtVertStep) {
/* 13 */     super.predictPlane(ref, refX << 1, refY << 1, refW, refH, refVertStep, refVertOff, tgt, tgtY, tgtW << 2, tgtH << 2, tgtVertStep);
/*    */   }
/*    */ }


/* Location:              C:\Users\rapha\Downloads\aurora.jar!\META-INF\jars\jcodec-0.2.5.jar!\org\jcodec\codecs\mpeg12\MPEGPredDbl.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */