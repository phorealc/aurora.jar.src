/*     */ package org.jcodec.codecs.mpeg12;
/*     */ 
/*     */ import java.io.File;
/*     */ import java.io.FilenameFilter;
/*     */ import java.io.IOException;
/*     */ import java.io.RandomAccessFile;
/*     */ import java.nio.ByteBuffer;
/*     */ import java.util.zip.CRC32;
/*     */ import org.jcodec.common.Preconditions;
/*     */ import org.jcodec.common.io.NIOUtils;
/*     */ import org.jcodec.containers.mps.MTSUtils;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class HLSFixPMT
/*     */ {
/*     */   public void fix(File file) throws IOException {
/*  25 */     RandomAccessFile ra = null;
/*     */     
/*     */     try {
/*  28 */       ra = new RandomAccessFile(file, "rw");
/*  29 */       byte[] tsPkt = new byte[188];
/*     */       
/*  31 */       while (ra.read(tsPkt) == 188) {
/*     */         
/*  33 */         Preconditions.checkState((71 == (tsPkt[0] & 0xFF)));
/*  34 */         int guidFlags = (tsPkt[1] & 0xFF) << 8 | tsPkt[2] & 0xFF;
/*  35 */         int guid = guidFlags & 0x1FFF;
/*  36 */         int payloadStart = guidFlags >> 14 & 0x1;
/*  37 */         int b0 = tsPkt[3] & 0xFF;
/*  38 */         int counter = b0 & 0xF;
/*  39 */         int payloadOff = 0;
/*  40 */         if ((b0 & 0x20) != 0) {
/*  41 */           payloadOff = (tsPkt[4 + payloadOff] & 0xFF) + 1;
/*     */         }
/*  43 */         if (payloadStart == 1) {
/*  44 */           payloadOff += (tsPkt[4 + payloadOff] & 0xFF) + 1;
/*     */         }
/*     */         
/*  47 */         if (guid == 0) {
/*  48 */           if (payloadStart == 0)
/*  49 */             throw new RuntimeException("PAT spans multiple TS packets, not supported!!!!!!"); 
/*  50 */           ByteBuffer bb = ByteBuffer.wrap(tsPkt, 4 + payloadOff, 184 - payloadOff);
/*  51 */           fixPAT(bb);
/*  52 */           ra.seek(ra.getFilePointer() - 188L);
/*  53 */           ra.write(tsPkt);
/*     */         } 
/*     */       } 
/*     */     } finally {
/*  57 */       if (ra != null)
/*  58 */         ra.close(); 
/*     */     } 
/*     */   }
/*     */   
/*     */   public static void fixPAT(ByteBuffer data) {
/*  63 */     ByteBuffer table = data.duplicate();
/*  64 */     MTSUtils.parseSection(data);
/*  65 */     ByteBuffer newPmt = data.duplicate();
/*     */     
/*  67 */     while (data.remaining() > 4) {
/*  68 */       short num = data.getShort();
/*  69 */       short pid = data.getShort();
/*  70 */       if (num != 0) {
/*  71 */         newPmt.putShort(num);
/*  72 */         newPmt.putShort(pid);
/*     */       } 
/*     */     } 
/*  75 */     if (newPmt.position() != data.position()) {
/*     */       
/*  77 */       ByteBuffer section = table.duplicate();
/*  78 */       section.get();
/*  79 */       int sectionLen = newPmt.position() - table.position() + 1;
/*  80 */       section.putShort((short)(sectionLen & 0xFFF | 0xB000));
/*     */       
/*  82 */       CRC32 crc32 = new CRC32();
/*  83 */       table.limit(newPmt.position());
/*  84 */       crc32.update(NIOUtils.toArray(table));
/*  85 */       newPmt.putInt((int)crc32.getValue());
/*     */       
/*  87 */       while (newPmt.hasRemaining())
/*  88 */         newPmt.put((byte)-1); 
/*     */     } 
/*     */   }
/*     */   
/*     */   public static void main1(String[] args) throws IOException {
/*  93 */     if (args.length < 1) {
/*  94 */       exit("Please specify package location");
/*     */     }
/*  96 */     File hlsPkg = new File(args[0]);
/*     */     
/*  98 */     if (!hlsPkg.isDirectory()) {
/*  99 */       exit("Not an HLS package, expected a folder");
/*     */     }
/* 101 */     File[] listFiles = hlsPkg.listFiles(new FilenameFilter() {
/*     */           public boolean accept(File dir, String name) {
/* 103 */             return name.endsWith(".ts");
/*     */           }
/*     */         });
/* 106 */     HLSFixPMT fix = new HLSFixPMT();
/* 107 */     for (int i = 0; i < listFiles.length; i++) {
/* 108 */       File file = listFiles[i];
/* 109 */       System.err.println("Processing: " + file.getName());
/* 110 */       fix.fix(file);
/*     */     } 
/*     */   }
/*     */   
/*     */   private static void exit(String message) {
/* 115 */     System.err.println("Syntax: hls_fixpmt <hls package location>");
/* 116 */     System.err.println(message);
/* 117 */     System.exit(-1);
/*     */   }
/*     */ }


/* Location:              C:\Users\rapha\Downloads\aurora.jar!\META-INF\jars\jcodec-0.2.5.jar!\org\jcodec\codecs\mpeg12\HLSFixPMT.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */