/*     */ package org.jcodec.codecs.mpeg12;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.nio.BufferOverflowException;
/*     */ import java.nio.ByteBuffer;
/*     */ import java.nio.channels.ReadableByteChannel;
/*     */ import java.util.ArrayList;
/*     */ import java.util.List;
/*     */ import org.jcodec.common.io.NIOUtils;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class SegmentReader
/*     */ {
/*     */   private ReadableByteChannel channel;
/*     */   private ByteBuffer buf;
/*     */   protected int curMarker;
/*     */   private int fetchSize;
/*     */   protected boolean done;
/*     */   private long pos;
/*     */   private int bytesInMarker;
/*  29 */   private int bufferIncrement = 32768;
/*     */   
/*     */   public SegmentReader(ReadableByteChannel channel, int fetchSize) throws IOException {
/*  32 */     this.channel = channel;
/*  33 */     this.fetchSize = fetchSize;
/*  34 */     this.buf = NIOUtils.fetchFromChannel(channel, 4);
/*  35 */     this.pos = this.buf.remaining();
/*  36 */     this.curMarker = this.buf.getInt();
/*  37 */     this.bytesInMarker = 4;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int getBufferIncrement() {
/*  44 */     return this.bufferIncrement;
/*     */   }
/*     */ 
/*     */   
/*     */   public void setBufferIncrement(int bufferIncrement) {
/*  49 */     this.bufferIncrement = bufferIncrement;
/*     */   }
/*     */ 
/*     */   
/*     */   public enum State
/*     */   {
/*  55 */     MORE_DATA, DONE, STOP;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final State readToNextMarkerPartial(ByteBuffer out) throws IOException {
/*  68 */     if (this.done)
/*  69 */       return State.STOP; 
/*  70 */     int skipOneMarker = (this.curMarker >= 256 && this.curMarker <= 511) ? 1 : 0;
/*  71 */     int written = out.position();
/*     */     do {
/*  73 */       while (this.buf.hasRemaining()) {
/*  74 */         if (this.curMarker >= 256 && this.curMarker <= 511) {
/*  75 */           if (skipOneMarker == 0) {
/*  76 */             return State.DONE;
/*     */           }
/*  78 */           skipOneMarker--;
/*     */         } 
/*  80 */         if (!out.hasRemaining())
/*  81 */           return State.MORE_DATA; 
/*  82 */         out.put((byte)(this.curMarker >>> 24));
/*  83 */         this.curMarker = this.curMarker << 8 | this.buf.get() & 0xFF;
/*     */       } 
/*  85 */       this.buf = NIOUtils.fetchFromChannel(this.channel, this.fetchSize);
/*  86 */       this.pos += this.buf.remaining();
/*  87 */     } while (this.buf.hasRemaining());
/*     */     
/*  89 */     written = out.position() - written;
/*  90 */     if (written > 0 && this.curMarker >= 256 && this.curMarker <= 511) {
/*  91 */       return State.DONE;
/*     */     }
/*  93 */     while (this.bytesInMarker > 0 && out.hasRemaining()) {
/*  94 */       out.put((byte)(this.curMarker >>> 24));
/*  95 */       this.curMarker <<= 8;
/*  96 */       this.bytesInMarker--;
/*  97 */       if (this.curMarker >= 256 && this.curMarker <= 511) {
/*  98 */         return State.DONE;
/*     */       }
/*     */     } 
/* 101 */     if (this.bytesInMarker == 0) {
/* 102 */       this.done = true;
/* 103 */       return State.STOP;
/*     */     } 
/* 105 */     return State.MORE_DATA;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ByteBuffer readToNextMarkerNewBuffer() throws IOException {
/* 119 */     if (this.done)
/* 120 */       return null; 
/* 121 */     List<ByteBuffer> buffers = new ArrayList<ByteBuffer>();
/* 122 */     readToNextMarkerBuffers(buffers);
/*     */     
/* 124 */     return NIOUtils.combineBuffers(buffers);
/*     */   }
/*     */ 
/*     */   
/*     */   public void readToNextMarkerBuffers(List<ByteBuffer> buffers) throws IOException {
/*     */     State state;
/*     */     do {
/* 131 */       ByteBuffer curBuffer = ByteBuffer.allocate(this.bufferIncrement);
/* 132 */       state = readToNextMarkerPartial(curBuffer);
/* 133 */       curBuffer.flip();
/* 134 */       buffers.add(curBuffer);
/* 135 */     } while (state == State.MORE_DATA);
/*     */   }
/*     */   
/*     */   public final boolean readToNextMarker(ByteBuffer out) throws IOException {
/* 139 */     State state = readToNextMarkerPartial(out);
/* 140 */     if (state == State.MORE_DATA)
/* 141 */       throw new BufferOverflowException(); 
/* 142 */     return (state == State.DONE);
/*     */   }
/*     */   
/*     */   public final boolean skipToMarker() throws IOException {
/* 146 */     if (this.done)
/* 147 */       return false; 
/*     */     while (true) {
/* 149 */       while (this.buf.hasRemaining()) {
/* 150 */         this.curMarker = this.curMarker << 8 | this.buf.get() & 0xFF;
/* 151 */         if (this.curMarker >= 256 && this.curMarker <= 511) {
/* 152 */           return true;
/*     */         }
/*     */       } 
/* 155 */       this.buf = NIOUtils.fetchFromChannel(this.channel, this.fetchSize);
/* 156 */       this.pos += this.buf.remaining();
/* 157 */       if (!this.buf.hasRemaining()) {
/* 158 */         this.done = true;
/*     */         
/* 160 */         return false;
/*     */       } 
/*     */     } 
/*     */   } public final boolean read(ByteBuffer out, int length) throws IOException {
/* 164 */     if (this.done)
/* 165 */       return false; 
/*     */     while (true) {
/* 167 */       while (this.buf.hasRemaining()) {
/* 168 */         if (length-- == 0)
/* 169 */           return true; 
/* 170 */         out.put((byte)(this.curMarker >>> 24));
/* 171 */         this.curMarker = this.curMarker << 8 | this.buf.get() & 0xFF;
/*     */       } 
/* 173 */       this.buf = NIOUtils.fetchFromChannel(this.channel, this.fetchSize);
/* 174 */       this.pos += this.buf.remaining();
/* 175 */       if (!this.buf.hasRemaining()) {
/* 176 */         out.putInt(this.curMarker);
/* 177 */         this.done = true;
/*     */         
/* 179 */         return false;
/*     */       } 
/*     */     } 
/*     */   } public final long curPos() {
/* 183 */     return this.pos - this.buf.remaining() - 4L;
/*     */   }
/*     */ }


/* Location:              C:\Users\rapha\Downloads\aurora.jar!\META-INF\jars\jcodec-0.2.5.jar!\org\jcodec\codecs\mpeg12\SegmentReader.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */