/*     */ package org.jcodec.codecs.mpeg12.bitstream;
/*     */ 
/*     */ import java.nio.ByteBuffer;
/*     */ import org.jcodec.codecs.mpeg12.MPEGConst;
/*     */ import org.jcodec.common.io.BitReader;
/*     */ import org.jcodec.common.io.BitWriter;
/*     */ import org.jcodec.common.io.VLC;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class SequenceScalableExtension
/*     */   implements MPEGHeader
/*     */ {
/*     */   public static final int DATA_PARTITIONING = 0;
/*     */   public static final int SPATIAL_SCALABILITY = 1;
/*     */   public static final int SNR_SCALABILITY = 2;
/*     */   public static final int TEMPORAL_SCALABILITY = 3;
/*     */   public int scalable_mode;
/*     */   public int layer_id;
/*     */   public int lower_layer_prediction_horizontal_size;
/*     */   public int lower_layer_prediction_vertical_size;
/*     */   public int horizontal_subsampling_factor_m;
/*     */   public int horizontal_subsampling_factor_n;
/*     */   public int vertical_subsampling_factor_m;
/*     */   public int vertical_subsampling_factor_n;
/*     */   public int picture_mux_enable;
/*     */   public int mux_to_progressive_sequence;
/*     */   public int picture_mux_order;
/*     */   public int picture_mux_factor;
/*     */   public static final int Sequence_Scalable_Extension = 5;
/*     */   
/*     */   public static SequenceScalableExtension read(BitReader _in) {
/*  54 */     SequenceScalableExtension sse = new SequenceScalableExtension();
/*  55 */     sse.scalable_mode = _in.readNBit(2);
/*  56 */     sse.layer_id = _in.readNBit(4);
/*     */     
/*  58 */     if (sse.scalable_mode == 1) {
/*  59 */       sse.lower_layer_prediction_horizontal_size = _in.readNBit(14);
/*  60 */       _in.read1Bit();
/*  61 */       sse.lower_layer_prediction_vertical_size = _in.readNBit(14);
/*  62 */       sse.horizontal_subsampling_factor_m = _in.readNBit(5);
/*  63 */       sse.horizontal_subsampling_factor_n = _in.readNBit(5);
/*  64 */       sse.vertical_subsampling_factor_m = _in.readNBit(5);
/*  65 */       sse.vertical_subsampling_factor_n = _in.readNBit(5);
/*     */     } 
/*     */     
/*  68 */     if (sse.scalable_mode == 3) {
/*  69 */       sse.picture_mux_enable = _in.read1Bit();
/*  70 */       if (sse.picture_mux_enable != 0)
/*  71 */         sse.mux_to_progressive_sequence = _in.read1Bit(); 
/*  72 */       sse.picture_mux_order = _in.readNBit(3);
/*  73 */       sse.picture_mux_factor = _in.readNBit(3);
/*     */     } 
/*     */     
/*  76 */     return sse;
/*     */   }
/*     */ 
/*     */   
/*     */   public void write(ByteBuffer bb) {
/*  81 */     BitWriter bw = new BitWriter(bb);
/*  82 */     bw.writeNBit(5, 4);
/*     */     
/*  84 */     bw.writeNBit(this.scalable_mode, 2);
/*  85 */     bw.writeNBit(this.layer_id, 4);
/*     */     
/*  87 */     if (this.scalable_mode == 1) {
/*  88 */       bw.writeNBit(this.lower_layer_prediction_horizontal_size, 14);
/*  89 */       bw.write1Bit(1);
/*  90 */       bw.writeNBit(this.lower_layer_prediction_vertical_size, 14);
/*  91 */       bw.writeNBit(this.horizontal_subsampling_factor_m, 5);
/*  92 */       bw.writeNBit(this.horizontal_subsampling_factor_n, 5);
/*  93 */       bw.writeNBit(this.vertical_subsampling_factor_m, 5);
/*  94 */       bw.writeNBit(this.vertical_subsampling_factor_n, 5);
/*     */     } 
/*     */     
/*  97 */     if (this.scalable_mode == 3) {
/*  98 */       bw.write1Bit(this.picture_mux_enable);
/*  99 */       if (this.picture_mux_enable != 0)
/* 100 */         bw.write1Bit(this.mux_to_progressive_sequence); 
/* 101 */       bw.writeNBit(this.picture_mux_order, 3);
/* 102 */       bw.writeNBit(this.picture_mux_factor, 3);
/*     */     } 
/* 104 */     bw.flush();
/*     */   }
/*     */   
/*     */   public static MPEGConst.MBType[] mbTypeVal(int picture_coding_type, SequenceScalableExtension sse) {
/* 108 */     if (sse != null && sse.scalable_mode == 2)
/* 109 */       return MPEGConst.mbTypeValSNR; 
/* 110 */     if (sse != null && sse.scalable_mode == 1) {
/* 111 */       return (picture_coding_type == 1) ? MPEGConst.mbTypeValISpat : ((picture_coding_type == 2) ? MPEGConst.mbTypeValPSpat : MPEGConst.mbTypeValBSpat);
/*     */     }
/*     */     
/* 114 */     return (picture_coding_type == 1) ? MPEGConst.mbTypeValI : ((picture_coding_type == 2) ? MPEGConst.mbTypeValP : MPEGConst.mbTypeValB);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public static VLC vlcMBType(int picture_coding_type, SequenceScalableExtension sse) {
/* 120 */     if (sse != null && sse.scalable_mode == 2)
/* 121 */       return MPEGConst.vlcMBTypeSNR; 
/* 122 */     if (sse != null && sse.scalable_mode == 1) {
/* 123 */       return (picture_coding_type == 1) ? MPEGConst.vlcMBTypeISpat : ((picture_coding_type == 2) ? MPEGConst.vlcMBTypePSpat : MPEGConst.vlcMBTypeBSpat);
/*     */     }
/*     */     
/* 126 */     return (picture_coding_type == 1) ? MPEGConst.vlcMBTypeI : ((picture_coding_type == 2) ? MPEGConst.vlcMBTypeP : MPEGConst.vlcMBTypeB);
/*     */   }
/*     */ }


/* Location:              C:\Users\rapha\Downloads\aurora.jar!\META-INF\jars\jcodec-0.2.5.jar!\org\jcodec\codecs\mpeg12\bitstream\SequenceScalableExtension.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */