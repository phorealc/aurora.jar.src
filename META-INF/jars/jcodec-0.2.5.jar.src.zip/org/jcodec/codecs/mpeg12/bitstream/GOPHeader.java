/*    */ package org.jcodec.codecs.mpeg12.bitstream;
/*    */ 
/*    */ import java.nio.ByteBuffer;
/*    */ import org.jcodec.common.io.BitReader;
/*    */ import org.jcodec.common.io.BitWriter;
/*    */ import org.jcodec.common.model.TapeTimecode;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class GOPHeader
/*    */   implements MPEGHeader
/*    */ {
/*    */   private TapeTimecode timeCode;
/*    */   private boolean closedGop;
/*    */   private boolean brokenLink;
/*    */   
/*    */   public GOPHeader(TapeTimecode timeCode, boolean closedGop, boolean brokenLink) {
/* 22 */     this.timeCode = timeCode;
/* 23 */     this.closedGop = closedGop;
/* 24 */     this.brokenLink = brokenLink;
/*    */   }
/*    */   
/*    */   public static GOPHeader read(ByteBuffer bb) {
/* 28 */     BitReader _in = BitReader.createBitReader(bb);
/* 29 */     boolean dropFrame = (_in.read1Bit() == 1);
/* 30 */     short hours = (short)_in.readNBit(5);
/* 31 */     byte minutes = (byte)_in.readNBit(6);
/* 32 */     _in.skip(1);
/*    */     
/* 34 */     byte seconds = (byte)_in.readNBit(6);
/* 35 */     byte frames = (byte)_in.readNBit(6);
/*    */     
/* 37 */     boolean closedGop = (_in.read1Bit() == 1);
/* 38 */     boolean brokenLink = (_in.read1Bit() == 1);
/*    */     
/* 40 */     return new GOPHeader(new TapeTimecode(hours, minutes, seconds, frames, dropFrame, 0), closedGop, brokenLink);
/*    */   }
/*    */ 
/*    */   
/*    */   public void write(ByteBuffer bb) {
/* 45 */     BitWriter bw = new BitWriter(bb);
/* 46 */     if (this.timeCode == null) {
/* 47 */       bw.writeNBit(0, 25);
/*    */     } else {
/* 49 */       bw.write1Bit(this.timeCode.isDropFrame() ? 1 : 0);
/* 50 */       bw.writeNBit(this.timeCode.getHour(), 5);
/* 51 */       bw.writeNBit(this.timeCode.getMinute(), 6);
/* 52 */       bw.write1Bit(1);
/* 53 */       bw.writeNBit(this.timeCode.getSecond(), 6);
/* 54 */       bw.writeNBit(this.timeCode.getFrame(), 6);
/*    */     } 
/* 56 */     bw.write1Bit(this.closedGop ? 1 : 0);
/* 57 */     bw.write1Bit(this.brokenLink ? 1 : 0);
/* 58 */     bw.flush();
/*    */   }
/*    */   
/*    */   public TapeTimecode getTimeCode() {
/* 62 */     return this.timeCode;
/*    */   }
/*    */   
/*    */   public boolean isClosedGop() {
/* 66 */     return this.closedGop;
/*    */   }
/*    */   
/*    */   public boolean isBrokenLink() {
/* 70 */     return this.brokenLink;
/*    */   }
/*    */ }


/* Location:              C:\Users\rapha\Downloads\aurora.jar!\META-INF\jars\jcodec-0.2.5.jar!\org\jcodec\codecs\mpeg12\bitstream\GOPHeader.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */