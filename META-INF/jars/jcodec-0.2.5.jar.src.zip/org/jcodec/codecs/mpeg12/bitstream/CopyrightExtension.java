/*    */ package org.jcodec.codecs.mpeg12.bitstream;
/*    */ 
/*    */ import java.nio.ByteBuffer;
/*    */ import org.jcodec.common.io.BitReader;
/*    */ import org.jcodec.common.io.BitWriter;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class CopyrightExtension
/*    */   implements MPEGHeader
/*    */ {
/*    */   public int copyright_flag;
/*    */   public int copyright_identifier;
/*    */   public int original_or_copy;
/*    */   public int copyright_number_1;
/*    */   public int copyright_number_2;
/*    */   public int copyright_number_3;
/*    */   public static final int Copyright_Extension = 4;
/*    */   
/*    */   public static CopyrightExtension read(BitReader _in) {
/* 24 */     CopyrightExtension ce = new CopyrightExtension();
/* 25 */     ce.copyright_flag = _in.read1Bit();
/* 26 */     ce.copyright_identifier = _in.readNBit(8);
/* 27 */     ce.original_or_copy = _in.read1Bit();
/* 28 */     _in.skip(7);
/* 29 */     _in.read1Bit();
/* 30 */     ce.copyright_number_1 = _in.readNBit(20);
/* 31 */     _in.read1Bit();
/* 32 */     ce.copyright_number_2 = _in.readNBit(22);
/* 33 */     _in.read1Bit();
/* 34 */     ce.copyright_number_3 = _in.readNBit(22);
/* 35 */     return ce;
/*    */   }
/*    */ 
/*    */   
/*    */   public void write(ByteBuffer bb) {
/* 40 */     BitWriter bw = new BitWriter(bb);
/* 41 */     bw.writeNBit(4, 4);
/*    */     
/* 43 */     bw.write1Bit(this.copyright_flag);
/* 44 */     bw.writeNBit(this.copyright_identifier, 8);
/* 45 */     bw.write1Bit(this.original_or_copy);
/* 46 */     bw.writeNBit(0, 7);
/* 47 */     bw.write1Bit(1);
/* 48 */     bw.writeNBit(this.copyright_number_1, 20);
/* 49 */     bw.write1Bit(1);
/* 50 */     bw.writeNBit(this.copyright_number_2, 22);
/* 51 */     bw.write1Bit(1);
/* 52 */     bw.writeNBit(this.copyright_number_3, 22);
/*    */     
/* 54 */     bw.flush();
/*    */   }
/*    */ }


/* Location:              C:\Users\rapha\Downloads\aurora.jar!\META-INF\jars\jcodec-0.2.5.jar!\org\jcodec\codecs\mpeg12\bitstream\CopyrightExtension.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */