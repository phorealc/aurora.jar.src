/*     */ package org.jcodec.codecs.mpeg12.bitstream;
/*     */ 
/*     */ import java.nio.ByteBuffer;
/*     */ import org.jcodec.common.io.BitReader;
/*     */ import org.jcodec.common.io.BitWriter;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class PictureHeader
/*     */   implements MPEGHeader
/*     */ {
/*     */   public int temporal_reference;
/*     */   public int picture_coding_type;
/*     */   public int vbv_delay;
/*     */   public int full_pel_forward_vector;
/*     */   public int forward_f_code;
/*     */   public int full_pel_backward_vector;
/*     */   public int backward_f_code;
/*     */   public QuantMatrixExtension quantMatrixExtension;
/*     */   public CopyrightExtension copyrightExtension;
/*     */   public PictureDisplayExtension pictureDisplayExtension;
/*     */   public PictureCodingExtension pictureCodingExtension;
/*     */   public PictureSpatialScalableExtension pictureSpatialScalableExtension;
/*     */   public PictureTemporalScalableExtension pictureTemporalScalableExtension;
/*     */   private boolean _hasExtensions;
/*     */   
/*     */   public static PictureHeader createPictureHeader(int temporal_reference, int picture_coding_type, int vbv_delay, int full_pel_forward_vector, int forward_f_code, int full_pel_backward_vector, int backward_f_code) {
/*  42 */     PictureHeader p = new PictureHeader();
/*  43 */     p.temporal_reference = temporal_reference;
/*  44 */     p.picture_coding_type = picture_coding_type;
/*  45 */     p.vbv_delay = vbv_delay;
/*  46 */     p.full_pel_forward_vector = full_pel_forward_vector;
/*  47 */     p.forward_f_code = forward_f_code;
/*  48 */     p.full_pel_backward_vector = full_pel_backward_vector;
/*  49 */     p.backward_f_code = backward_f_code;
/*  50 */     return p;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static PictureHeader read(ByteBuffer bb) {
/*  57 */     BitReader _in = BitReader.createBitReader(bb);
/*  58 */     PictureHeader ph = new PictureHeader();
/*  59 */     ph.temporal_reference = _in.readNBit(10);
/*  60 */     ph.picture_coding_type = _in.readNBit(3);
/*  61 */     ph.vbv_delay = _in.readNBit(16);
/*  62 */     if (ph.picture_coding_type == 2 || ph.picture_coding_type == 3) {
/*  63 */       ph.full_pel_forward_vector = _in.read1Bit();
/*  64 */       ph.forward_f_code = _in.readNBit(3);
/*     */     } 
/*  66 */     if (ph.picture_coding_type == 3) {
/*  67 */       ph.full_pel_backward_vector = _in.read1Bit();
/*  68 */       ph.backward_f_code = _in.readNBit(3);
/*     */     } 
/*  70 */     while (_in.read1Bit() == 1) {
/*  71 */       _in.readNBit(8);
/*     */     }
/*     */     
/*  74 */     return ph;
/*     */   }
/*     */   
/*     */   public static void readExtension(ByteBuffer bb, PictureHeader ph, SequenceHeader sh) {
/*  78 */     ph._hasExtensions = true;
/*  79 */     BitReader _in = BitReader.createBitReader(bb);
/*  80 */     int extType = _in.readNBit(4);
/*  81 */     switch (extType) {
/*     */       case 3:
/*  83 */         ph.quantMatrixExtension = QuantMatrixExtension.read(_in);
/*     */         return;
/*     */       case 4:
/*  86 */         ph.copyrightExtension = CopyrightExtension.read(_in);
/*     */         return;
/*     */       case 7:
/*  89 */         ph.pictureDisplayExtension = PictureDisplayExtension.read(_in, sh.sequenceExtension, ph.pictureCodingExtension);
/*     */         return;
/*     */       
/*     */       case 8:
/*  93 */         ph.pictureCodingExtension = PictureCodingExtension.read(_in);
/*     */         return;
/*     */       case 9:
/*  96 */         ph.pictureSpatialScalableExtension = PictureSpatialScalableExtension.read(_in);
/*     */         return;
/*     */       case 16:
/*  99 */         ph.pictureTemporalScalableExtension = PictureTemporalScalableExtension.read(_in);
/*     */         return;
/*     */     } 
/* 102 */     throw new RuntimeException("Unsupported extension: " + extType);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void write(ByteBuffer os) {
/* 108 */     BitWriter out = new BitWriter(os);
/* 109 */     out.writeNBit(this.temporal_reference, 10);
/* 110 */     out.writeNBit(this.picture_coding_type, 3);
/* 111 */     out.writeNBit(this.vbv_delay, 16);
/* 112 */     if (this.picture_coding_type == 2 || this.picture_coding_type == 3) {
/* 113 */       out.write1Bit(this.full_pel_forward_vector);
/* 114 */       out.write1Bit(this.forward_f_code);
/*     */     } 
/* 116 */     if (this.picture_coding_type == 3) {
/* 117 */       out.write1Bit(this.full_pel_backward_vector);
/* 118 */       out.writeNBit(this.backward_f_code, 3);
/*     */     } 
/* 120 */     out.write1Bit(0);
/* 121 */     out.flush();
/*     */     
/* 123 */     writeExtensions(os);
/*     */   }
/*     */   
/*     */   private void writeExtensions(ByteBuffer out) {
/* 127 */     if (this.quantMatrixExtension != null) {
/* 128 */       out.putInt(181);
/* 129 */       this.quantMatrixExtension.write(out);
/*     */     } 
/*     */     
/* 132 */     if (this.copyrightExtension != null) {
/* 133 */       out.putInt(181);
/* 134 */       this.copyrightExtension.write(out);
/*     */     } 
/*     */     
/* 137 */     if (this.pictureCodingExtension != null) {
/* 138 */       out.putInt(181);
/* 139 */       this.pictureCodingExtension.write(out);
/*     */     } 
/*     */     
/* 142 */     if (this.pictureDisplayExtension != null) {
/* 143 */       out.putInt(181);
/* 144 */       this.pictureDisplayExtension.write(out);
/*     */     } 
/*     */     
/* 147 */     if (this.pictureSpatialScalableExtension != null) {
/* 148 */       out.putInt(181);
/* 149 */       this.pictureSpatialScalableExtension.write(out);
/*     */     } 
/*     */     
/* 152 */     if (this.pictureTemporalScalableExtension != null) {
/* 153 */       out.putInt(181);
/* 154 */       this.pictureTemporalScalableExtension.write(out);
/*     */     } 
/*     */   }
/*     */   
/*     */   public boolean hasExtensions() {
/* 159 */     return this._hasExtensions;
/*     */   }
/*     */ }


/* Location:              C:\Users\rapha\Downloads\aurora.jar!\META-INF\jars\jcodec-0.2.5.jar!\org\jcodec\codecs\mpeg12\bitstream\PictureHeader.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */