/*     */ package org.jcodec.codecs.mpeg12.bitstream;
/*     */ 
/*     */ import java.nio.ByteBuffer;
/*     */ import org.jcodec.common.io.BitReader;
/*     */ import org.jcodec.common.io.BitWriter;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class PictureCodingExtension
/*     */   implements MPEGHeader
/*     */ {
/*     */   public static final int Top_Field = 1;
/*     */   public static final int Bottom_Field = 2;
/*     */   public static final int Frame = 3;
/*  36 */   public int[][] f_code = new int[2][2]; public int intra_dc_precision; public int picture_structure; public int top_field_first; public int frame_pred_frame_dct; public int concealment_motion_vectors; public int q_scale_type; public int intra_vlc_format; public int alternate_scan;
/*     */   public int repeat_first_field;
/*     */   public int chroma_420_type;
/*     */   public int progressive_frame;
/*     */   public CompositeDisplay compositeDisplay;
/*     */   public static final int Picture_Coding_Extension = 8;
/*     */   
/*     */   public static class CompositeDisplay { public int v_axis;
/*     */     public int field_sequence;
/*     */     
/*     */     public static CompositeDisplay read(BitReader _in) {
/*  47 */       CompositeDisplay cd = new CompositeDisplay();
/*  48 */       cd.v_axis = _in.read1Bit();
/*  49 */       cd.field_sequence = _in.readNBit(3);
/*  50 */       cd.sub_carrier = _in.read1Bit();
/*  51 */       cd.burst_amplitude = _in.readNBit(7);
/*  52 */       cd.sub_carrier_phase = _in.readNBit(8);
/*  53 */       return cd;
/*     */     }
/*     */     public int sub_carrier; public int burst_amplitude; public int sub_carrier_phase;
/*     */     public void write(BitWriter out) {
/*  57 */       out.write1Bit(this.v_axis);
/*  58 */       out.writeNBit(this.field_sequence, 3);
/*  59 */       out.write1Bit(this.sub_carrier);
/*  60 */       out.writeNBit(this.burst_amplitude, 7);
/*  61 */       out.writeNBit(this.sub_carrier_phase, 8);
/*     */     } }
/*     */ 
/*     */   
/*     */   public static PictureCodingExtension read(BitReader _in) {
/*  66 */     PictureCodingExtension pce = new PictureCodingExtension();
/*  67 */     pce.f_code[0][0] = _in.readNBit(4);
/*  68 */     pce.f_code[0][1] = _in.readNBit(4);
/*  69 */     pce.f_code[1][0] = _in.readNBit(4);
/*  70 */     pce.f_code[1][1] = _in.readNBit(4);
/*  71 */     pce.intra_dc_precision = _in.readNBit(2);
/*  72 */     pce.picture_structure = _in.readNBit(2);
/*  73 */     pce.top_field_first = _in.read1Bit();
/*  74 */     pce.frame_pred_frame_dct = _in.read1Bit();
/*  75 */     pce.concealment_motion_vectors = _in.read1Bit();
/*  76 */     pce.q_scale_type = _in.read1Bit();
/*  77 */     pce.intra_vlc_format = _in.read1Bit();
/*  78 */     pce.alternate_scan = _in.read1Bit();
/*  79 */     pce.repeat_first_field = _in.read1Bit();
/*  80 */     pce.chroma_420_type = _in.read1Bit();
/*  81 */     pce.progressive_frame = _in.read1Bit();
/*  82 */     if (_in.read1Bit() != 0) {
/*  83 */       pce.compositeDisplay = CompositeDisplay.read(_in);
/*     */     }
/*     */     
/*  86 */     return pce;
/*     */   }
/*     */ 
/*     */   
/*     */   public void write(ByteBuffer bb) {
/*  91 */     BitWriter bw = new BitWriter(bb);
/*  92 */     bw.writeNBit(8, 4);
/*  93 */     bw.writeNBit(this.f_code[0][0], 4);
/*  94 */     bw.writeNBit(this.f_code[0][1], 4);
/*  95 */     bw.writeNBit(this.f_code[1][0], 4);
/*  96 */     bw.writeNBit(this.f_code[1][1], 4);
/*  97 */     bw.writeNBit(this.intra_dc_precision, 2);
/*  98 */     bw.writeNBit(this.picture_structure, 2);
/*  99 */     bw.write1Bit(this.top_field_first);
/* 100 */     bw.write1Bit(this.frame_pred_frame_dct);
/* 101 */     bw.write1Bit(this.concealment_motion_vectors);
/* 102 */     bw.write1Bit(this.q_scale_type);
/* 103 */     bw.write1Bit(this.intra_vlc_format);
/* 104 */     bw.write1Bit(this.alternate_scan);
/* 105 */     bw.write1Bit(this.repeat_first_field);
/* 106 */     bw.write1Bit(this.chroma_420_type);
/* 107 */     bw.write1Bit(this.progressive_frame);
/* 108 */     bw.write1Bit((this.compositeDisplay != null) ? 1 : 0);
/* 109 */     if (this.compositeDisplay != null)
/* 110 */       this.compositeDisplay.write(bw); 
/* 111 */     bw.flush();
/*     */   }
/*     */ }


/* Location:              C:\Users\rapha\Downloads\aurora.jar!\META-INF\jars\jcodec-0.2.5.jar!\org\jcodec\codecs\mpeg12\bitstream\PictureCodingExtension.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */