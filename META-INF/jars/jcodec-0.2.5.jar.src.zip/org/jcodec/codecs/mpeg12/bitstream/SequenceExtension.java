/*    */ package org.jcodec.codecs.mpeg12.bitstream;
/*    */ 
/*    */ import java.nio.ByteBuffer;
/*    */ import org.jcodec.common.io.BitReader;
/*    */ import org.jcodec.common.io.BitWriter;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class SequenceExtension
/*    */   implements MPEGHeader
/*    */ {
/*    */   public static final int Chroma420 = 1;
/*    */   public static final int Chroma422 = 2;
/*    */   public static final int Chroma444 = 3;
/*    */   public int profile_and_level;
/*    */   public int progressive_sequence;
/*    */   public int chroma_format;
/*    */   public int horizontal_size_extension;
/*    */   public int vertical_size_extension;
/*    */   public int bit_rate_extension;
/*    */   public int vbv_buffer_size_extension;
/*    */   public int low_delay;
/*    */   public int frame_rate_extension_n;
/*    */   public int frame_rate_extension_d;
/*    */   public static final int Sequence_Extension = 1;
/*    */   
/*    */   public static SequenceExtension createSequenceExtension(int profile_and_level, int progressive_sequence, int chroma_format, int horizontal_size_extension, int vertical_size_extension, int bit_rate_extension, int vbv_buffer_size_extension, int low_delay, int frame_rate_extension_n, int frame_rate_extension_d) {
/* 35 */     SequenceExtension se = new SequenceExtension();
/* 36 */     se.profile_and_level = profile_and_level;
/* 37 */     se.progressive_sequence = progressive_sequence;
/* 38 */     se.chroma_format = chroma_format;
/* 39 */     se.horizontal_size_extension = horizontal_size_extension;
/* 40 */     se.vertical_size_extension = vertical_size_extension;
/* 41 */     se.bit_rate_extension = bit_rate_extension;
/* 42 */     se.vbv_buffer_size_extension = vbv_buffer_size_extension;
/* 43 */     se.low_delay = low_delay;
/* 44 */     se.frame_rate_extension_n = frame_rate_extension_n;
/* 45 */     se.frame_rate_extension_d = frame_rate_extension_d;
/* 46 */     return se;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public static SequenceExtension read(BitReader _in) {
/* 53 */     SequenceExtension se = new SequenceExtension();
/* 54 */     se.profile_and_level = _in.readNBit(8);
/* 55 */     se.progressive_sequence = _in.read1Bit();
/* 56 */     se.chroma_format = _in.readNBit(2);
/* 57 */     se.horizontal_size_extension = _in.readNBit(2);
/* 58 */     se.vertical_size_extension = _in.readNBit(2);
/* 59 */     se.bit_rate_extension = _in.readNBit(12);
/* 60 */     se.vbv_buffer_size_extension = _in.readNBit(8);
/* 61 */     se.low_delay = _in.read1Bit();
/* 62 */     se.frame_rate_extension_n = _in.readNBit(2);
/* 63 */     se.frame_rate_extension_d = _in.readNBit(5);
/*    */     
/* 65 */     return se;
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public void write(ByteBuffer bb) {
/* 71 */     BitWriter bw = new BitWriter(bb);
/* 72 */     bw.writeNBit(1, 4);
/* 73 */     bw.writeNBit(this.profile_and_level, 8);
/* 74 */     bw.write1Bit(this.progressive_sequence);
/* 75 */     bw.writeNBit(this.chroma_format, 2);
/* 76 */     bw.writeNBit(this.horizontal_size_extension, 2);
/* 77 */     bw.writeNBit(this.vertical_size_extension, 2);
/* 78 */     bw.writeNBit(this.bit_rate_extension, 12);
/* 79 */     bw.write1Bit(1);
/* 80 */     bw.writeNBit(this.vbv_buffer_size_extension, 8);
/* 81 */     bw.write1Bit(this.low_delay);
/* 82 */     bw.writeNBit(this.frame_rate_extension_n, 2);
/* 83 */     bw.writeNBit(this.frame_rate_extension_d, 5);
/*    */     
/* 85 */     bw.flush();
/*    */   }
/*    */ }


/* Location:              C:\Users\rapha\Downloads\aurora.jar!\META-INF\jars\jcodec-0.2.5.jar!\org\jcodec\codecs\mpeg12\bitstream\SequenceExtension.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */