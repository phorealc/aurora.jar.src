/*    */ package org.jcodec.codecs.mpeg12.bitstream;
/*    */ 
/*    */ import java.nio.ByteBuffer;
/*    */ import org.jcodec.common.io.BitReader;
/*    */ import org.jcodec.common.io.BitWriter;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class PictureSpatialScalableExtension
/*    */   implements MPEGHeader
/*    */ {
/*    */   public int lower_layer_temporal_reference;
/*    */   public int lower_layer_horizontal_offset;
/*    */   public int lower_layer_vertical_offset;
/*    */   public int spatial_temporal_weight_code_table_index;
/*    */   public int lower_layer_progressive_frame;
/*    */   public int lower_layer_deinterlaced_field_select;
/*    */   public static final int Picture_Spatial_Scalable_Extension = 9;
/*    */   
/*    */   public static PictureSpatialScalableExtension read(BitReader _in) {
/* 24 */     PictureSpatialScalableExtension psse = new PictureSpatialScalableExtension();
/*    */     
/* 26 */     psse.lower_layer_temporal_reference = _in.readNBit(10);
/* 27 */     _in.read1Bit();
/* 28 */     psse.lower_layer_horizontal_offset = _in.readNBit(15);
/* 29 */     _in.read1Bit();
/* 30 */     psse.lower_layer_vertical_offset = _in.readNBit(15);
/* 31 */     psse.spatial_temporal_weight_code_table_index = _in.readNBit(2);
/* 32 */     psse.lower_layer_progressive_frame = _in.read1Bit();
/* 33 */     psse.lower_layer_deinterlaced_field_select = _in.read1Bit();
/*    */     
/* 35 */     return psse;
/*    */   }
/*    */ 
/*    */   
/*    */   public void write(ByteBuffer bb) {
/* 40 */     BitWriter bw = new BitWriter(bb);
/* 41 */     bw.writeNBit(9, 4);
/*    */     
/* 43 */     bw.writeNBit(this.lower_layer_temporal_reference, 10);
/* 44 */     bw.write1Bit(1);
/* 45 */     bw.writeNBit(this.lower_layer_horizontal_offset, 15);
/* 46 */     bw.write1Bit(1);
/* 47 */     bw.writeNBit(this.lower_layer_vertical_offset, 15);
/* 48 */     bw.writeNBit(this.spatial_temporal_weight_code_table_index, 2);
/* 49 */     bw.write1Bit(this.lower_layer_progressive_frame);
/* 50 */     bw.write1Bit(this.lower_layer_deinterlaced_field_select);
/*    */     
/* 52 */     bw.flush();
/*    */   }
/*    */ }


/* Location:              C:\Users\rapha\Downloads\aurora.jar!\META-INF\jars\jcodec-0.2.5.jar!\org\jcodec\codecs\mpeg12\bitstream\PictureSpatialScalableExtension.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */