/*     */ package org.jcodec.codecs.mpeg12.bitstream;
/*     */ 
/*     */ import java.nio.ByteBuffer;
/*     */ import org.jcodec.common.io.BitReader;
/*     */ import org.jcodec.common.io.BitWriter;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class SequenceHeader
/*     */   implements MPEGHeader
/*     */ {
/*     */   private static boolean _hasExtensions;
/*     */   public int horizontal_size;
/*     */   public int vertical_size;
/*     */   public int aspect_ratio_information;
/*     */   public int frame_rate_code;
/*     */   public int bit_rate;
/*     */   public int vbv_buffer_size_value;
/*     */   public int constrained_parameters_flag;
/*     */   public int[] intra_quantiser_matrix;
/*     */   public int[] non_intra_quantiser_matrix;
/*     */   public SequenceExtension sequenceExtension;
/*     */   public SequenceScalableExtension sequenceScalableExtension;
/*     */   public SequenceDisplayExtension sequenceDisplayExtension;
/*     */   
/*     */   public static SequenceHeader createSequenceHeader(int horizontal_size, int vertical_size, int aspect_ratio_information, int frame_rate_code, int bit_rate, int vbv_buffer_size_value, int constrained_parameters_flag, int[] intra_quantiser_matrix, int[] non_intra_quantiser_matrix) {
/*  37 */     SequenceHeader sh = new SequenceHeader();
/*  38 */     sh.horizontal_size = horizontal_size;
/*  39 */     sh.vertical_size = vertical_size;
/*  40 */     sh.aspect_ratio_information = aspect_ratio_information;
/*  41 */     sh.frame_rate_code = frame_rate_code;
/*  42 */     sh.bit_rate = bit_rate;
/*  43 */     sh.vbv_buffer_size_value = vbv_buffer_size_value;
/*  44 */     sh.constrained_parameters_flag = constrained_parameters_flag;
/*  45 */     sh.intra_quantiser_matrix = intra_quantiser_matrix;
/*  46 */     sh.non_intra_quantiser_matrix = non_intra_quantiser_matrix;
/*  47 */     return sh;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static SequenceHeader read(ByteBuffer bb) {
/*  54 */     BitReader _in = BitReader.createBitReader(bb);
/*  55 */     SequenceHeader sh = new SequenceHeader();
/*  56 */     sh.horizontal_size = _in.readNBit(12);
/*  57 */     sh.vertical_size = _in.readNBit(12);
/*  58 */     sh.aspect_ratio_information = _in.readNBit(4);
/*  59 */     sh.frame_rate_code = _in.readNBit(4);
/*  60 */     sh.bit_rate = _in.readNBit(18);
/*  61 */     _in.read1Bit();
/*  62 */     sh.vbv_buffer_size_value = _in.readNBit(10);
/*  63 */     sh.constrained_parameters_flag = _in.read1Bit();
/*  64 */     if (_in.read1Bit() != 0) {
/*  65 */       sh.intra_quantiser_matrix = new int[64];
/*  66 */       for (int i = 0; i < 64; i++) {
/*  67 */         sh.intra_quantiser_matrix[i] = _in.readNBit(8);
/*     */       }
/*     */     } 
/*  70 */     if (_in.read1Bit() != 0) {
/*  71 */       sh.non_intra_quantiser_matrix = new int[64];
/*  72 */       for (int i = 0; i < 64; i++) {
/*  73 */         sh.non_intra_quantiser_matrix[i] = _in.readNBit(8);
/*     */       }
/*     */     } 
/*     */     
/*  77 */     return sh;
/*     */   }
/*     */   
/*     */   public static void readExtension(ByteBuffer bb, SequenceHeader sh) {
/*  81 */     _hasExtensions = true;
/*     */     
/*  83 */     BitReader _in = BitReader.createBitReader(bb);
/*  84 */     int extType = _in.readNBit(4);
/*  85 */     switch (extType) {
/*     */       case 1:
/*  87 */         sh.sequenceExtension = SequenceExtension.read(_in);
/*     */         return;
/*     */       case 5:
/*  90 */         sh.sequenceScalableExtension = SequenceScalableExtension.read(_in);
/*     */         return;
/*     */       case 2:
/*  93 */         sh.sequenceDisplayExtension = SequenceDisplayExtension.read(_in);
/*     */         return;
/*     */     } 
/*  96 */     throw new RuntimeException("Unsupported extension: " + extType);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void write(ByteBuffer bb) {
/* 102 */     BitWriter bw = new BitWriter(bb);
/* 103 */     bw.writeNBit(this.horizontal_size, 12);
/* 104 */     bw.writeNBit(this.vertical_size, 12);
/* 105 */     bw.writeNBit(this.aspect_ratio_information, 4);
/* 106 */     bw.writeNBit(this.frame_rate_code, 4);
/* 107 */     bw.writeNBit(this.bit_rate, 18);
/* 108 */     bw.write1Bit(1);
/* 109 */     bw.writeNBit(this.vbv_buffer_size_value, 10);
/* 110 */     bw.write1Bit(this.constrained_parameters_flag);
/* 111 */     bw.write1Bit((this.intra_quantiser_matrix != null) ? 1 : 0);
/* 112 */     if (this.intra_quantiser_matrix != null) {
/* 113 */       for (int i = 0; i < 64; i++) {
/* 114 */         bw.writeNBit(this.intra_quantiser_matrix[i], 8);
/*     */       }
/*     */     }
/* 117 */     bw.write1Bit((this.non_intra_quantiser_matrix != null) ? 1 : 0);
/* 118 */     if (this.non_intra_quantiser_matrix != null) {
/* 119 */       for (int i = 0; i < 64; i++) {
/* 120 */         bw.writeNBit(this.non_intra_quantiser_matrix[i], 8);
/*     */       }
/*     */     }
/*     */     
/* 124 */     bw.flush();
/*     */     
/* 126 */     writeExtensions(bb);
/*     */   }
/*     */   
/*     */   private void writeExtensions(ByteBuffer out) {
/* 130 */     if (this.sequenceExtension != null) {
/* 131 */       out.putInt(181);
/* 132 */       this.sequenceExtension.write(out);
/*     */     } 
/*     */     
/* 135 */     if (this.sequenceScalableExtension != null) {
/* 136 */       out.putInt(181);
/* 137 */       this.sequenceScalableExtension.write(out);
/*     */     } 
/*     */     
/* 140 */     if (this.sequenceDisplayExtension != null) {
/* 141 */       out.putInt(181);
/* 142 */       this.sequenceDisplayExtension.write(out);
/*     */     } 
/*     */   }
/*     */   
/*     */   public boolean hasExtensions() {
/* 147 */     return _hasExtensions;
/*     */   }
/*     */   
/*     */   public void copyExtensions(SequenceHeader sh) {
/* 151 */     this.sequenceExtension = sh.sequenceExtension;
/* 152 */     this.sequenceScalableExtension = sh.sequenceScalableExtension;
/* 153 */     this.sequenceDisplayExtension = sh.sequenceDisplayExtension;
/*     */   }
/*     */ }


/* Location:              C:\Users\rapha\Downloads\aurora.jar!\META-INF\jars\jcodec-0.2.5.jar!\org\jcodec\codecs\mpeg12\bitstream\SequenceHeader.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */