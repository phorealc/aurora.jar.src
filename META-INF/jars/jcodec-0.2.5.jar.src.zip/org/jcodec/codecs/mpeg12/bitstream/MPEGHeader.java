package org.jcodec.codecs.mpeg12.bitstream;

import java.nio.ByteBuffer;

public interface MPEGHeader {
  void write(ByteBuffer paramByteBuffer);
}


/* Location:              C:\Users\rapha\Downloads\aurora.jar!\META-INF\jars\jcodec-0.2.5.jar!\org\jcodec\codecs\mpeg12\bitstream\MPEGHeader.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */