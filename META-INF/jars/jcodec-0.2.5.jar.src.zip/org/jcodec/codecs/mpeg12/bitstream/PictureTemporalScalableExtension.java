/*    */ package org.jcodec.codecs.mpeg12.bitstream;
/*    */ 
/*    */ import java.nio.ByteBuffer;
/*    */ import org.jcodec.common.io.BitReader;
/*    */ import org.jcodec.common.io.BitWriter;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class PictureTemporalScalableExtension
/*    */   implements MPEGHeader
/*    */ {
/*    */   public int reference_select_code;
/*    */   public int forward_temporal_reference;
/*    */   public int backward_temporal_reference;
/*    */   public static final int Picture_Temporal_Scalable_Extension = 16;
/*    */   
/*    */   public static PictureTemporalScalableExtension read(BitReader _in) {
/* 21 */     PictureTemporalScalableExtension ptse = new PictureTemporalScalableExtension();
/* 22 */     ptse.reference_select_code = _in.readNBit(2);
/* 23 */     ptse.forward_temporal_reference = _in.readNBit(10);
/* 24 */     _in.read1Bit();
/* 25 */     ptse.backward_temporal_reference = _in.readNBit(10);
/*    */     
/* 27 */     return ptse;
/*    */   }
/*    */ 
/*    */   
/*    */   public void write(ByteBuffer bb) {
/* 32 */     BitWriter bw = new BitWriter(bb);
/* 33 */     bw.writeNBit(16, 4);
/*    */     
/* 35 */     bw.writeNBit(this.reference_select_code, 2);
/* 36 */     bw.writeNBit(this.forward_temporal_reference, 10);
/* 37 */     bw.write1Bit(1);
/* 38 */     bw.writeNBit(this.backward_temporal_reference, 10);
/* 39 */     bw.flush();
/*    */   }
/*    */ }


/* Location:              C:\Users\rapha\Downloads\aurora.jar!\META-INF\jars\jcodec-0.2.5.jar!\org\jcodec\codecs\mpeg12\bitstream\PictureTemporalScalableExtension.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */