/*    */ package org.jcodec.codecs.mpeg12.bitstream;
/*    */ 
/*    */ import java.nio.ByteBuffer;
/*    */ import org.jcodec.common.io.BitReader;
/*    */ import org.jcodec.common.io.BitWriter;
/*    */ import org.jcodec.common.model.Point;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class PictureDisplayExtension
/*    */   implements MPEGHeader
/*    */ {
/*    */   public Point[] frame_centre_offsets;
/*    */   public static final int Picture_Display_Extension = 7;
/*    */   
/*    */   public static PictureDisplayExtension read(BitReader bits, SequenceExtension se, PictureCodingExtension pce) {
/* 21 */     PictureDisplayExtension pde = new PictureDisplayExtension();
/* 22 */     pde.frame_centre_offsets = new Point[numberOfFrameCentreOffsets(se, pce)];
/* 23 */     for (int i = 0; i < pde.frame_centre_offsets.length; i++) {
/* 24 */       int frame_centre_horizontal_offset = bits.readNBit(16);
/* 25 */       bits.read1Bit();
/* 26 */       int frame_centre_vertical_offset = bits.readNBit(16);
/* 27 */       bits.read1Bit();
/* 28 */       pde.frame_centre_offsets[i] = new Point(frame_centre_horizontal_offset, frame_centre_vertical_offset);
/*    */     } 
/* 30 */     return pde;
/*    */   }
/*    */   
/*    */   private static int numberOfFrameCentreOffsets(SequenceExtension se, PictureCodingExtension pce) {
/* 34 */     if (se == null || pce == null) {
/* 35 */       throw new IllegalArgumentException("PictureDisplayExtension requires SequenceExtension and PictureCodingExtension to be present");
/*    */     }
/* 37 */     if (se.progressive_sequence == 1) {
/* 38 */       if (pce.repeat_first_field == 1) {
/* 39 */         if (pce.top_field_first == 1) {
/* 40 */           return 3;
/*    */         }
/* 42 */         return 2;
/*    */       } 
/* 44 */       return 1;
/*    */     } 
/*    */     
/* 47 */     if (pce.picture_structure != 3) {
/* 48 */       return 1;
/*    */     }
/* 50 */     if (pce.repeat_first_field == 1) {
/* 51 */       return 3;
/*    */     }
/* 53 */     return 2;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public void write(ByteBuffer bb) {
/* 60 */     BitWriter bw = new BitWriter(bb);
/* 61 */     bw.writeNBit(7, 4);
/*    */     
/* 63 */     for (int i = 0; i < this.frame_centre_offsets.length; i++) {
/* 64 */       Point point = this.frame_centre_offsets[i];
/* 65 */       bw.writeNBit(point.getX(), 16);
/* 66 */       bw.writeNBit(point.getY(), 16);
/*    */     } 
/* 68 */     bw.flush();
/*    */   }
/*    */ }


/* Location:              C:\Users\rapha\Downloads\aurora.jar!\META-INF\jars\jcodec-0.2.5.jar!\org\jcodec\codecs\mpeg12\bitstream\PictureDisplayExtension.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */