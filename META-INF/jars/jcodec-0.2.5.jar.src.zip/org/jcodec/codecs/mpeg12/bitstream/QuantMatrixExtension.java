/*    */ package org.jcodec.codecs.mpeg12.bitstream;
/*    */ 
/*    */ import java.nio.ByteBuffer;
/*    */ import org.jcodec.common.io.BitReader;
/*    */ import org.jcodec.common.io.BitWriter;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class QuantMatrixExtension
/*    */   implements MPEGHeader
/*    */ {
/*    */   public int[] intra_quantiser_matrix;
/*    */   public int[] non_intra_quantiser_matrix;
/*    */   public int[] chroma_intra_quantiser_matrix;
/*    */   public int[] chroma_non_intra_quantiser_matrix;
/*    */   public static final int Quant_Matrix_Extension = 3;
/*    */   
/*    */   public static QuantMatrixExtension read(BitReader _in) {
/* 23 */     QuantMatrixExtension qme = new QuantMatrixExtension();
/* 24 */     if (_in.read1Bit() != 0)
/* 25 */       qme.intra_quantiser_matrix = readQMat(_in); 
/* 26 */     if (_in.read1Bit() != 0)
/* 27 */       qme.non_intra_quantiser_matrix = readQMat(_in); 
/* 28 */     if (_in.read1Bit() != 0)
/* 29 */       qme.chroma_intra_quantiser_matrix = readQMat(_in); 
/* 30 */     if (_in.read1Bit() != 0) {
/* 31 */       qme.chroma_non_intra_quantiser_matrix = readQMat(_in);
/*    */     }
/* 33 */     return qme;
/*    */   }
/*    */   
/*    */   private static int[] readQMat(BitReader _in) {
/* 37 */     int[] qmat = new int[64];
/* 38 */     for (int i = 0; i < 64; i++)
/* 39 */       qmat[i] = _in.readNBit(8); 
/* 40 */     return qmat;
/*    */   }
/*    */ 
/*    */   
/*    */   public void write(ByteBuffer bb) {
/* 45 */     BitWriter bw = new BitWriter(bb);
/* 46 */     bw.writeNBit(3, 4);
/*    */     
/* 48 */     bw.write1Bit((this.intra_quantiser_matrix != null) ? 1 : 0);
/* 49 */     if (this.intra_quantiser_matrix != null)
/* 50 */       writeQMat(this.intra_quantiser_matrix, bw); 
/* 51 */     bw.write1Bit((this.non_intra_quantiser_matrix != null) ? 1 : 0);
/* 52 */     if (this.non_intra_quantiser_matrix != null)
/* 53 */       writeQMat(this.non_intra_quantiser_matrix, bw); 
/* 54 */     bw.write1Bit((this.chroma_intra_quantiser_matrix != null) ? 1 : 0);
/* 55 */     if (this.chroma_intra_quantiser_matrix != null)
/* 56 */       writeQMat(this.chroma_intra_quantiser_matrix, bw); 
/* 57 */     bw.write1Bit((this.chroma_non_intra_quantiser_matrix != null) ? 1 : 0);
/* 58 */     if (this.chroma_non_intra_quantiser_matrix != null) {
/* 59 */       writeQMat(this.chroma_non_intra_quantiser_matrix, bw);
/*    */     }
/* 61 */     bw.flush();
/*    */   }
/*    */   
/*    */   private void writeQMat(int[] matrix, BitWriter ob) {
/* 65 */     for (int i = 0; i < 64; i++)
/* 66 */       ob.writeNBit(matrix[i], 8); 
/*    */   }
/*    */ }


/* Location:              C:\Users\rapha\Downloads\aurora.jar!\META-INF\jars\jcodec-0.2.5.jar!\org\jcodec\codecs\mpeg12\bitstream\QuantMatrixExtension.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */