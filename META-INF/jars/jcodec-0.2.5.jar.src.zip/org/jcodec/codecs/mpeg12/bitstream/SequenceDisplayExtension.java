/*    */ package org.jcodec.codecs.mpeg12.bitstream;
/*    */ 
/*    */ import java.nio.ByteBuffer;
/*    */ import org.jcodec.common.io.BitReader;
/*    */ import org.jcodec.common.io.BitWriter;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class SequenceDisplayExtension
/*    */   implements MPEGHeader
/*    */ {
/*    */   public int video_format;
/*    */   public int display_horizontal_size;
/*    */   public int display_vertical_size;
/*    */   public ColorDescription colorDescription;
/*    */   public static final int Sequence_Display_Extension = 2;
/*    */   
/*    */   public static class ColorDescription
/*    */   {
/*    */     int colour_primaries;
/*    */     int transfer_characteristics;
/*    */     int matrix_coefficients;
/*    */     
/*    */     public static ColorDescription read(BitReader _in) {
/* 27 */       ColorDescription cd = new ColorDescription();
/* 28 */       cd.colour_primaries = _in.readNBit(8);
/* 29 */       cd.transfer_characteristics = _in.readNBit(8);
/* 30 */       cd.matrix_coefficients = _in.readNBit(8);
/* 31 */       return cd;
/*    */     }
/*    */     
/*    */     public void write(BitWriter out) {
/* 35 */       out.writeNBit(this.colour_primaries, 8);
/* 36 */       out.writeNBit(this.transfer_characteristics, 8);
/* 37 */       out.writeNBit(this.matrix_coefficients, 8);
/*    */     }
/*    */   }
/*    */   
/*    */   public static SequenceDisplayExtension read(BitReader _in) {
/* 42 */     SequenceDisplayExtension sde = new SequenceDisplayExtension();
/* 43 */     sde.video_format = _in.readNBit(3);
/* 44 */     if (_in.read1Bit() == 1) {
/* 45 */       sde.colorDescription = ColorDescription.read(_in);
/*    */     }
/* 47 */     sde.display_horizontal_size = _in.readNBit(14);
/* 48 */     _in.read1Bit();
/* 49 */     sde.display_vertical_size = _in.readNBit(14);
/*    */     
/* 51 */     return sde;
/*    */   }
/*    */ 
/*    */   
/*    */   public void write(ByteBuffer bb) {
/* 56 */     BitWriter bw = new BitWriter(bb);
/* 57 */     bw.writeNBit(2, 4);
/*    */     
/* 59 */     bw.writeNBit(this.video_format, 3);
/* 60 */     bw.write1Bit((this.colorDescription != null) ? 1 : 0);
/* 61 */     if (this.colorDescription != null)
/* 62 */       this.colorDescription.write(bw); 
/* 63 */     bw.writeNBit(this.display_horizontal_size, 14);
/* 64 */     bw.write1Bit(1);
/* 65 */     bw.writeNBit(this.display_vertical_size, 14);
/* 66 */     bw.flush();
/*    */   }
/*    */ }


/* Location:              C:\Users\rapha\Downloads\aurora.jar!\META-INF\jars\jcodec-0.2.5.jar!\org\jcodec\codecs\mpeg12\bitstream\SequenceDisplayExtension.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */