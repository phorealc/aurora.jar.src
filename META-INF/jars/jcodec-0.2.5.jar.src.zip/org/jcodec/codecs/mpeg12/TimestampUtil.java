/*    */ package org.jcodec.codecs.mpeg12;
/*    */ 
/*    */ import java.io.File;
/*    */ import java.io.IOException;
/*    */ import java.util.Arrays;
/*    */ import org.jcodec.common.io.IOUtils;
/*    */ import org.jcodec.common.model.RationalLarge;
/*    */ import org.jcodec.common.tools.MainUtils;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class TimestampUtil
/*    */ {
/*    */   private static final String STREAM_ALL = "all";
/*    */   private static final String STREAM_AUDIO = "audio";
/*    */   private static final String STRAM_VIDEO = "video";
/* 26 */   private static final MainUtils.Flag FLAG_STREAM = MainUtils.Flag.flag("stream", "s", "A stream to shift, i.e. 'video' or 'audio' or 'all' [default]");
/*    */ 
/*    */   
/* 29 */   private static final MainUtils.Flag[] ALL_FLAGS = new MainUtils.Flag[] { FLAG_STREAM };
/*    */   
/*    */   private static final String COMMAND_SHIFT = "shift";
/*    */   private static final String COMMAND_SCALE = "scale";
/*    */   private static final String COMMAND_ROUND = "round";
/*    */   
/*    */   public static void main1(String[] args) throws IOException {
/* 36 */     MainUtils.Cmd cmd = MainUtils.parseArguments(args, ALL_FLAGS);
/* 37 */     if (cmd.args.length < 3) {
/* 38 */       System.out.println("A utility to tweak MPEG TS timestamps.");
/* 39 */       MainUtils.printHelp(ALL_FLAGS, Arrays.asList(new String[] { "command", "arg", "in name", "?out file" }));
/* 40 */       System.out.println("Where command is:\n\tshift\tShift timestamps of selected stream by arg.\n\tscale\tScale timestams of selected stream by arg [num:den].\n\tround\tRound timestamps of selected stream to multiples of arg.");
/*    */ 
/*    */ 
/*    */ 
/*    */       
/*    */       return;
/*    */     } 
/*    */ 
/*    */ 
/*    */     
/* 50 */     File src = new File(cmd.getArg(2));
/* 51 */     if (cmd.argsLength() > 3) {
/* 52 */       File dst = new File(cmd.getArg(3));
/* 53 */       IOUtils.copyFile(src, dst);
/* 54 */       src = dst;
/*    */     } 
/*    */     
/* 57 */     String command = cmd.getArg(0);
/*    */     
/* 59 */     String stream = cmd.getStringFlagD(FLAG_STREAM, "all");
/* 60 */     if ("shift".equalsIgnoreCase(command)) {
/* 61 */       final long shift = Long.parseLong(cmd.getArg(1));
/* 62 */       (new BaseCommand(stream) {
/*    */           protected long withTimestamp(long pts, boolean isPts) {
/* 64 */             return Math.max(pts + shift, 0L);
/*    */           }
/* 66 */         }).fix(src);
/* 67 */     } else if ("scale".equalsIgnoreCase(command)) {
/* 68 */       final RationalLarge scale = RationalLarge.parse(cmd.getArg(1));
/* 69 */       (new BaseCommand(stream) {
/*    */           protected long withTimestamp(long pts, boolean isPts) {
/* 71 */             return scale.multiplyS(pts);
/*    */           }
/* 73 */         }).fix(src);
/* 74 */     } else if ("round".equalsIgnoreCase(command)) {
/* 75 */       final int precision = Integer.parseInt(cmd.getArg(1));
/* 76 */       (new BaseCommand(stream) {
/*    */           protected long withTimestamp(long pts, boolean isPts) {
/* 78 */             return Math.round(pts / precision) * precision;
/*    */           }
/* 80 */         }).fix(src);
/*    */     } 
/*    */   }
/*    */   
/*    */   private static abstract class BaseCommand extends FixTimestamp {
/*    */     private String streamSelector;
/*    */     
/*    */     public BaseCommand(String stream) {
/* 88 */       this.streamSelector = stream;
/*    */     }
/*    */     
/*    */     protected long doWithTimestamp(int streamId, long pts, boolean isPts) {
/* 92 */       if ("all".equals(this.streamSelector) || ("video".equals(this.streamSelector) && isVideo(streamId)) || ("audio"
/* 93 */         .equals(this.streamSelector) && isAudio(streamId))) {
/* 94 */         return withTimestamp(pts, isPts);
/*    */       }
/* 96 */       return pts;
/*    */     }
/*    */     
/*    */     protected abstract long withTimestamp(long param1Long, boolean param1Boolean);
/*    */   }
/*    */ }


/* Location:              C:\Users\rapha\Downloads\aurora.jar!\META-INF\jars\jcodec-0.2.5.jar!\org\jcodec\codecs\mpeg12\TimestampUtil.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */