/*    */ package org.jcodec.codecs.mpeg12;
/*    */ 
/*    */ import java.nio.ByteBuffer;
/*    */ import java.nio.ByteOrder;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class MPEGUtil
/*    */ {
/*    */   public static final ByteBuffer gotoNextMarker(ByteBuffer buf) {
/* 24 */     return gotoMarker(buf, 0, 256, 511);
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public static final ByteBuffer gotoMarker(ByteBuffer buf, int n, int mmin, int mmax) {
/* 37 */     if (!buf.hasRemaining()) {
/* 38 */       return null;
/*    */     }
/* 40 */     int from = buf.position();
/* 41 */     ByteBuffer result = buf.slice();
/* 42 */     result.order(ByteOrder.BIG_ENDIAN);
/*    */     
/* 44 */     int val = -1;
/* 45 */     while (buf.hasRemaining()) {
/* 46 */       val = val << 8 | buf.get() & 0xFF;
/* 47 */       if (val >= mmin && val <= mmax) {
/* 48 */         if (n == 0) {
/* 49 */           buf.position(buf.position() - 4);
/* 50 */           result.limit(buf.position() - from);
/*    */           break;
/*    */         } 
/* 53 */         n--;
/*    */       } 
/*    */     } 
/* 56 */     return result;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public static final ByteBuffer nextSegment(ByteBuffer buf) {
/* 69 */     gotoMarker(buf, 0, 256, 511);
/* 70 */     return gotoMarker(buf, 1, 256, 511);
/*    */   }
/*    */ }


/* Location:              C:\Users\rapha\Downloads\aurora.jar!\META-INF\jars\jcodec-0.2.5.jar!\org\jcodec\codecs\mpeg12\MPEGUtil.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */