/*    */ package org.jcodec.codecs.mpeg12;
/*    */ 
/*    */ import java.io.IOException;
/*    */ import java.nio.ByteBuffer;
/*    */ import java.nio.channels.ReadableByteChannel;
/*    */ import java.util.ArrayList;
/*    */ import java.util.List;
/*    */ import org.jcodec.codecs.mpeg12.bitstream.PictureHeader;
/*    */ import org.jcodec.common.io.NIOUtils;
/*    */ import org.jcodec.containers.mps.MPEGPacket;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class MPEGES
/*    */   extends SegmentReader
/*    */ {
/*    */   private int frameNo;
/*    */   public long lastKnownDuration;
/*    */   
/*    */   public MPEGES(ReadableByteChannel channel, int fetchSize) throws IOException {
/* 28 */     super(channel, fetchSize);
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public MPEGPacket frame(ByteBuffer buffer) throws IOException {
/* 44 */     ByteBuffer dup = buffer.duplicate();
/*    */     
/* 46 */     while (this.curMarker != 256 && this.curMarker != 435 && skipToMarker());
/*    */ 
/*    */     
/* 49 */     while (this.curMarker != 256 && readToNextMarker(dup));
/*    */ 
/*    */     
/* 52 */     readToNextMarker(dup);
/*    */     
/* 54 */     while (this.curMarker != 256 && this.curMarker != 435 && readToNextMarker(dup));
/*    */ 
/*    */     
/* 57 */     dup.flip();
/*    */     
/* 59 */     PictureHeader ph = MPEGDecoder.getPictureHeader(dup.duplicate());
/*    */     
/* 61 */     if (dup.hasRemaining()) {  } else {  }  return null;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public MPEGPacket getFrame() throws IOException {
/* 73 */     while (this.curMarker != 256 && this.curMarker != 435 && skipToMarker());
/*    */ 
/*    */     
/* 76 */     List<ByteBuffer> buffers = new ArrayList<ByteBuffer>();
/*    */ 
/*    */     
/* 79 */     while (this.curMarker != 256 && !this.done) {
/* 80 */       readToNextMarkerBuffers(buffers);
/*    */     }
/*    */     
/* 83 */     readToNextMarkerBuffers(buffers);
/*    */ 
/*    */ 
/*    */     
/* 87 */     while (this.curMarker != 256 && this.curMarker != 435 && !this.done) {
/* 88 */       readToNextMarkerBuffers(buffers);
/*    */     }
/* 90 */     ByteBuffer dup = NIOUtils.combineBuffers(buffers);
/* 91 */     PictureHeader ph = MPEGDecoder.getPictureHeader(dup.duplicate());
/*    */     
/* 93 */     if (dup.hasRemaining()) {  } else {  }  return null;
/*    */   }
/*    */ }


/* Location:              C:\Users\rapha\Downloads\aurora.jar!\META-INF\jars\jcodec-0.2.5.jar!\org\jcodec\codecs\mpeg12\MPEGES.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */