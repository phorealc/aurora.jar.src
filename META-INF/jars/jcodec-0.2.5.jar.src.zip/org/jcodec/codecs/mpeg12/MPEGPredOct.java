/*     */ package org.jcodec.codecs.mpeg12;
/*     */ 
/*     */ import org.jcodec.common.tools.MathUtil;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class MPEGPredOct
/*     */   extends MPEGPred
/*     */ {
/*     */   private int[] tmp;
/*  19 */   private static final int[][] COEFF = new int[][] { { 0, 0, 128, 0, 0, 0 }, { 0, -6, 123, 12, -1, 0 }, { 2, -11, 108, 36, -8, 1 }, { 0, -9, 93, 50, -6, 0 }, { 3, -16, 77, 77, -16, 3 }, { 0, -6, 50, 93, -9, 0 }, { 1, -8, 36, 108, -11, 2 }, { 0, -1, 12, 123, -6, 0 } };
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public MPEGPredOct(MPEGPred other) {
/*  40 */     super(other.fCode, other.chromaFormat, other.topFieldFirst);
/*  41 */     this.tmp = new int[336];
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void predictPlane(byte[] ref, int refX, int refY, int refW, int refH, int refVertStep, int refVertOff, int[] tgt, int tgtY, int tgtW, int tgtH, int tgtVertStep) {
/*  47 */     int rx = refX >> 3, ry = refY >> 3;
/*  48 */     tgtW >>= 3;
/*  49 */     tgtH >>= 3;
/*     */     
/*  51 */     boolean safe = (rx >= 2 && ry >= 2 && rx + tgtW + 3 < refW && ry + tgtH + 3 << refVertStep < refH);
/*  52 */     if ((refX & 0x7) == 0) {
/*  53 */       if ((refY & 0x7) == 0) {
/*  54 */         if (safe) {
/*  55 */           predictFullXFullYSafe(ref, rx, ry, refW, refH, refVertStep, refVertOff, tgt, tgtY, tgtW, tgtH, tgtVertStep);
/*     */         } else {
/*     */           
/*  58 */           predictFullXFullYUnSafe(ref, rx, ry, refW, refH, refVertStep, refVertOff, tgt, tgtY, tgtW, tgtH, tgtVertStep);
/*     */         }
/*     */       
/*  61 */       } else if (safe) {
/*  62 */         predictFullXSubYSafe(ref, rx, ry, refY & 0x7, refW, refH, refVertStep, refVertOff, tgt, tgtY, tgtW, tgtH, tgtVertStep);
/*     */       } else {
/*     */         
/*  65 */         predictFullXSubYUnSafe(ref, rx, ry, refY & 0x7, refW, refH, refVertStep, refVertOff, tgt, tgtY, tgtW, tgtH, tgtVertStep);
/*     */       }
/*     */     
/*  68 */     } else if ((refY & 0x7) == 0) {
/*  69 */       if (safe) {
/*  70 */         predictSubXFullYSafe(ref, rx, refX & 0x7, ry, refW, refH, refVertStep, refVertOff, tgt, tgtY, tgtW, tgtH, tgtVertStep);
/*     */       } else {
/*     */         
/*  73 */         predictSubXFullYUnSafe(ref, rx, refX & 0x7, ry, refW, refH, refVertStep, refVertOff, tgt, tgtY, tgtW, tgtH, tgtVertStep);
/*     */       }
/*     */     
/*  76 */     } else if (safe) {
/*  77 */       predictSubXSubYSafe(ref, rx, refX & 0x7, ry, refY & 0x7, refW, refH, refVertStep, refVertOff, tgt, tgtY, tgtW, tgtH, tgtVertStep);
/*     */     } else {
/*     */       
/*  80 */       predictSubXSubYUnSafe(ref, rx, refX & 0x7, ry, refY & 0x7, refW, refH, refVertStep, refVertOff, tgt, tgtY, tgtW, tgtH, tgtVertStep);
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   protected int getPix6(byte[] ref, int refW, int refH, int x, int y, int refVertStep, int refVertOff, int[] coeff) {
/*  86 */     int lastLine = refH - (1 << refVertStep) + refVertOff;
/*  87 */     int x0 = MathUtil.clip(x - 2, 0, refW - 1);
/*  88 */     int x1 = MathUtil.clip(x - 1, 0, refW - 1);
/*  89 */     int x2 = MathUtil.clip(x, 0, refW - 1);
/*  90 */     int x3 = MathUtil.clip(x + 1, 0, refW - 1);
/*  91 */     int x4 = MathUtil.clip(x + 2, 0, refW - 1);
/*  92 */     int x5 = MathUtil.clip(x + 3, 0, refW - 1);
/*  93 */     int off = MathUtil.clip(y, refVertOff, lastLine) * refW;
/*     */     
/*  95 */     return ref[off + x0] * coeff[0] + ref[off + x1] * coeff[1] + ref[off + x2] * coeff[2] + ref[off + x3] * coeff[3] + ref[off + x4] * coeff[4] + ref[off + x5] * coeff[5] + 16384;
/*     */   }
/*     */ 
/*     */   
/*     */   protected int getPix6Vert(byte[] ref, int refW, int refH, int x, int y, int refVertStep, int refVertOff, int[] coeff) {
/* 100 */     int lastLine = refH - (1 << refVertStep) + refVertOff;
/* 101 */     int y0 = MathUtil.clip(y - (2 << refVertStep), refVertOff, lastLine);
/* 102 */     int y1 = MathUtil.clip(y - (1 << refVertStep), refVertOff, lastLine);
/* 103 */     int y2 = MathUtil.clip(y, 0, lastLine);
/* 104 */     int y3 = MathUtil.clip(y + (1 << refVertStep), refVertOff, lastLine);
/* 105 */     int y4 = MathUtil.clip(y + (2 << refVertStep), refVertOff, lastLine);
/* 106 */     int y5 = MathUtil.clip(y + (3 << refVertStep), refVertOff, lastLine);
/* 107 */     x = MathUtil.clip(x, 0, refW - 1);
/*     */     
/* 109 */     return ref[y0 * refW + x] * coeff[0] + ref[y1 * refW + x] * coeff[1] + ref[y2 * refW + x] * coeff[2] + ref[y3 * refW + x] * coeff[3] + ref[y4 * refW + x] * coeff[4] + ref[y5 * refW + x] * coeff[5] + 16384;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void predictSubXSubYUnSafe(byte[] ref, int rx, int ix, int ry, int iy, int refW, int refH, int refVertStep, int refVertOff, int[] tgt, int tgtY, int tgtW, int tgtH, int tgtVertStep) {
/* 116 */     int offTgt = tgtW * tgtY;
/* 117 */     int dblTgtW = tgtW << 1;
/* 118 */     int tripleTgtW = dblTgtW + tgtW;
/* 119 */     int lfTgt = tgtVertStep * tgtW;
/*     */     
/* 121 */     int[] coeff = COEFF[ix]; int i, offTmp;
/* 122 */     for (i = -2, offTmp = 0; i < tgtH + 3; i++) {
/* 123 */       int y = (i + ry << refVertStep) + refVertOff;
/* 124 */       for (int j = 0; j < tgtW; j++, offTmp++) {
/* 125 */         this.tmp[offTmp] = getPix6(ref, refW, refH, j + rx, y, refVertStep, refVertOff, coeff);
/*     */       }
/*     */     } 
/*     */     
/* 129 */     coeff = COEFF[iy];
/* 130 */     for (i = 0, offTmp = dblTgtW; i < tgtH; i++) {
/* 131 */       for (int j = 0; j < tgtW; j++, offTmp++, offTgt++) {
/* 132 */         tgt[offTgt] = this.tmp[offTmp - dblTgtW] * coeff[0] + this.tmp[offTmp - tgtW] * coeff[1] + this.tmp[offTmp] * coeff[2] + this.tmp[offTmp + tgtW] * coeff[3] + this.tmp[offTmp + dblTgtW] * coeff[4] + this.tmp[offTmp + tripleTgtW] * coeff[5] + 8192 >> 14;
/*     */       }
/*     */ 
/*     */       
/* 136 */       offTgt += lfTgt;
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private void predictSubXSubYSafe(byte[] ref, int rx, int ix, int ry, int iy, int refW, int refH, int refVertStep, int refVertOff, int[] tgt, int tgtY, int tgtW, int tgtH, int tgtVertStep) {
/* 143 */     int[] coeff = COEFF[ix];
/*     */     
/* 145 */     int offRef = ((ry - 2 << refVertStep) + refVertOff) * refW + rx;
/* 146 */     int offTgt = tgtW * tgtY;
/* 147 */     int lfRef = (refW << refVertStep) - tgtW;
/* 148 */     int lfTgt = tgtVertStep * tgtW;
/* 149 */     int dblTgtW = tgtW << 1;
/* 150 */     int tripleTgtW = dblTgtW + tgtW;
/*     */     int i, offTmp;
/* 152 */     for (i = 0, offTmp = 0; i < tgtH + 5; i++) {
/* 153 */       for (int j = 0; j < tgtW; j++, offTmp++, offRef++) {
/* 154 */         this.tmp[offTmp] = ref[offRef - 2] * coeff[0] + ref[offRef - 1] * coeff[1] + ref[offRef] * coeff[2] + ref[offRef + 1] * coeff[3] + ref[offRef + 2] * coeff[4] + ref[offRef + 3] * coeff[5];
/*     */       }
/*     */       
/* 157 */       offRef += lfRef;
/*     */     } 
/*     */     
/* 160 */     coeff = COEFF[iy];
/* 161 */     for (i = 0, offTmp = dblTgtW; i < tgtH; i++) {
/* 162 */       for (int j = 0; j < tgtW; j++, offTmp++, offTgt++) {
/* 163 */         tgt[offTgt] = (this.tmp[offTmp - dblTgtW] * coeff[0] + this.tmp[offTmp - tgtW] * coeff[1] + this.tmp[offTmp] * coeff[2] + this.tmp[offTmp + tgtW] * coeff[3] + this.tmp[offTmp + dblTgtW] * coeff[4] + this.tmp[offTmp + tripleTgtW] * coeff[5] + 8192 >> 14) + 128;
/*     */       }
/*     */ 
/*     */       
/* 167 */       offTgt += lfTgt;
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   private void predictSubXFullYUnSafe(byte[] ref, int rx, int ix, int ry, int refW, int refH, int refVertStep, int refVertOff, int[] tgt, int tgtY, int tgtW, int tgtH, int tgtVertStep) {
/* 173 */     int[] coeff = COEFF[ix];
/*     */     
/* 175 */     int tgtOff = tgtW * tgtY;
/* 176 */     int lfTgt = tgtVertStep * tgtW;
/*     */     
/* 178 */     for (int i = 0; i < tgtH; i++) {
/* 179 */       int y = (i + ry << refVertStep) + refVertOff;
/* 180 */       for (int j = 0; j < tgtW; j++) {
/* 181 */         tgt[tgtOff++] = getPix6(ref, refW, refH, j + rx, y, refVertStep, refVertOff, coeff) + 64 >> 7;
/*     */       }
/* 183 */       tgtOff += lfTgt;
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   private void predictSubXFullYSafe(byte[] ref, int rx, int ix, int ry, int refW, int refH, int refVertStep, int refVertOff, int[] tgt, int tgtY, int tgtW, int tgtH, int tgtVertStep) {
/* 189 */     int[] coeff = COEFF[ix];
/*     */     
/* 191 */     int offRef = ((ry << refVertStep) + refVertOff) * refW + rx;
/* 192 */     int offTgt = tgtW * tgtY;
/* 193 */     int lfRef = (refW << refVertStep) - tgtW;
/* 194 */     int lfTgt = tgtVertStep * tgtW;
/*     */     
/* 196 */     for (int i = 0; i < tgtH; i++) {
/* 197 */       for (int j = 0; j < tgtW; j++, offRef++) {
/* 198 */         tgt[offTgt++] = (ref[offRef - 2] * coeff[0] + ref[offRef - 1] * coeff[1] + ref[offRef] * coeff[2] + ref[offRef + 1] * coeff[3] + ref[offRef + 2] * coeff[4] + ref[offRef + 3] * coeff[5] + 64 >> 7) + 128;
/*     */       }
/*     */       
/* 201 */       offRef += lfRef;
/* 202 */       offTgt += lfTgt;
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   private void predictFullXSubYUnSafe(byte[] ref, int rx, int ry, int iy, int refW, int refH, int refVertStep, int refVertOff, int[] tgt, int tgtY, int tgtW, int tgtH, int tgtVertStep) {
/* 208 */     int[] coeff = COEFF[iy];
/*     */     
/* 210 */     int tgtOff = tgtW * tgtY;
/* 211 */     int lfTgt = tgtVertStep * tgtW;
/*     */     
/* 213 */     for (int i = 0; i < tgtH; i++) {
/* 214 */       int y = (i + ry << refVertStep) + refVertOff;
/* 215 */       for (int j = 0; j < tgtW; j++) {
/* 216 */         tgt[tgtOff++] = getPix6Vert(ref, refW, refH, j + rx, y, refVertStep, refVertOff, coeff) + 64 >> 7;
/*     */       }
/* 218 */       tgtOff += lfTgt;
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   private void predictFullXSubYSafe(byte[] ref, int rx, int ry, int iy, int refW, int refH, int refVertStep, int refVertOff, int[] tgt, int tgtY, int tgtW, int tgtH, int tgtVertStep) {
/* 224 */     int[] coeff = COEFF[iy];
/*     */     
/* 226 */     int offTgt = tgtW * tgtY;
/* 227 */     int offRef = ((ry << refVertStep) + refVertOff) * refW + rx;
/*     */     
/* 229 */     int singleRefW = refW << refVertStep;
/* 230 */     int dblRefW = refW << 1 + refVertStep;
/* 231 */     int tripleRefW = dblRefW + singleRefW;
/*     */     
/* 233 */     int lfTgt = tgtVertStep * tgtW;
/* 234 */     int lfRef = (refW << refVertStep) - tgtW;
/*     */     
/* 236 */     for (int i = 0; i < tgtH; i++) {
/* 237 */       for (int j = 0; j < tgtW; j++, offTgt++, offRef++) {
/* 238 */         tgt[offTgt] = (ref[offRef - dblRefW] * coeff[0] + ref[offRef - singleRefW] * coeff[1] + ref[offRef] * coeff[2] + ref[offRef + singleRefW] * coeff[3] + ref[offRef + dblRefW] * coeff[4] + ref[offRef + tripleRefW] * coeff[5] + 64 >> 7) + 128;
/*     */       }
/*     */ 
/*     */       
/* 242 */       offRef += lfRef;
/* 243 */       offTgt += lfTgt;
/*     */     } 
/*     */   }
/*     */ }


/* Location:              C:\Users\rapha\Downloads\aurora.jar!\META-INF\jars\jcodec-0.2.5.jar!\org\jcodec\codecs\mpeg12\MPEGPredOct.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */