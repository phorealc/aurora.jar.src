/*     */ package org.jcodec.codecs.mpeg12;
/*     */ 
/*     */ import org.jcodec.common.io.VLC;
/*     */ import org.jcodec.common.io.VLCBuilder;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class MPEGConst
/*     */ {
/*     */   public static final int PICTURE_START_CODE = 0;
/*     */   public static final int SLICE_START_CODE_FIRST = 1;
/*     */   public static final int SLICE_START_CODE_LAST = 175;
/*     */   public static final int USER_DATA_START_CODE = 178;
/*     */   public static final int SEQUENCE_HEADER_CODE = 179;
/*     */   public static final int SEQUENCE_ERROR_CODE = 180;
/*     */   public static final int EXTENSION_START_CODE = 181;
/*     */   public static final int SEQUENCE_END_CODE = 183;
/*     */   public static final int GROUP_START_CODE = 184;
/*     */   
/*     */   public static class MBType
/*     */   {
/*     */     public int macroblock_quant;
/*     */     public int macroblock_motion_forward;
/*     */     public int macroblock_motion_backward;
/*     */     public int macroblock_pattern;
/*     */     public int macroblock_intra;
/*     */     public int spatial_temporal_weight_code_flag;
/*     */     public int permitted_spatial_temporal_weight_classes;
/*     */     
/*     */     MBType(int macroblock_quant, int macroblock_motion_forward, int macroblock_motion_backward, int macroblock_pattern, int macroblock_intra, int spatial_temporal_weight_code_flag, int permitted_spatial_temporal_weight_classes) {
/*  61 */       this.macroblock_quant = macroblock_quant;
/*  62 */       this.macroblock_motion_forward = macroblock_motion_forward;
/*  63 */       this.macroblock_motion_backward = macroblock_motion_backward;
/*  64 */       this.macroblock_pattern = macroblock_pattern;
/*  65 */       this.macroblock_intra = macroblock_intra;
/*  66 */       this.spatial_temporal_weight_code_flag = spatial_temporal_weight_code_flag;
/*  67 */       this.permitted_spatial_temporal_weight_classes = permitted_spatial_temporal_weight_classes;
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  76 */   public static final VLC vlcAddressIncrement = VLC.createVLC(new String[] { "1", "011", "010", "0011", "0010", "00011", "00010", "0000111", "0000110", "00001011", "00001010", "00001001", "00001000", "00000111", "00000110", "0000010111", "0000010110", "0000010101", "0000010100", "0000010011", 
/*     */         "0000010010", "00000100011", "00000100010", "00000100001", "00000100000", "00000011111", "00000011110", "00000011101", "00000011100", "00000011011", 
/*  78 */         "00000011010", "00000011001", "00000011000" }); public static final VLC vlcMBTypeI = VLC.createVLC(new String[] { "1", "01" });
/*  79 */   public static final MBType[] mbTypeValI = new MBType[] { new MBType(0, 0, 0, 0, 1, 0, 0), new MBType(1, 0, 0, 0, 1, 0, 0) };
/*     */   
/*  81 */   public static final VLC vlcMBTypeP = VLC.createVLC(new String[] { "1", "01", "001", "00011", "00010", "00001", "000001" });
/*  82 */   public static final MBType[] mbTypeValP = new MBType[] { new MBType(0, 1, 0, 1, 0, 0, 0), new MBType(0, 0, 0, 1, 0, 0, 0), new MBType(0, 1, 0, 0, 0, 0, 0), new MBType(0, 0, 0, 0, 1, 0, 0), new MBType(1, 1, 0, 1, 0, 0, 0), new MBType(1, 0, 0, 1, 0, 0, 0), new MBType(1, 0, 0, 0, 1, 0, 0) };
/*     */ 
/*     */ 
/*     */   
/*  86 */   public static final VLC vlcMBTypeB = VLC.createVLC(new String[] { "10", "11", "010", "011", "0010", "0011", "00011", "00010", "000011", "000010", "000001" });
/*  87 */   public static final MBType[] mbTypeValB = new MBType[] { new MBType(0, 1, 1, 0, 0, 0, 0), new MBType(0, 1, 1, 1, 0, 0, 0), new MBType(0, 0, 1, 0, 0, 0, 0), new MBType(0, 0, 1, 1, 0, 0, 0), new MBType(0, 1, 0, 0, 0, 0, 0), new MBType(0, 1, 0, 1, 0, 0, 0), new MBType(0, 0, 0, 0, 1, 0, 0), new MBType(1, 1, 1, 1, 0, 0, 0), new MBType(1, 1, 0, 1, 0, 0, 0), new MBType(1, 0, 1, 1, 0, 0, 0), new MBType(1, 0, 0, 0, 1, 0, 0) };
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  92 */   public static final VLC vlcMBTypeISpat = VLC.createVLC(new String[] { "1", "01", "0011", "0010", "0001" });
/*  93 */   public static final MBType[] mbTypeValISpat = new MBType[] { new MBType(0, 0, 0, 0, 1, 0, 0), new MBType(1, 0, 0, 0, 1, 0, 0), new MBType(0, 0, 0, 0, 1, 0, 0), new MBType(1, 0, 0, 0, 1, 0, 0), new MBType(0, 0, 0, 0, 0, 0, 0) };
/*     */ 
/*     */   
/*  96 */   public static final VLC vlcMBTypePSpat = VLC.createVLC(new String[] { "10", "011", "0000100", "000111", "0010", "0000111", "0011", "010", "000100", "0000110", "11", "000101", "000110", "0000101", "0000010", "0000011" });
/*  97 */   public static final MBType[] mbTypeValPSpat = new MBType[] { new MBType(0, 1, 0, 1, 0, 0, 0), new MBType(0, 1, 0, 1, 0, 1, 0), new MBType(0, 0, 0, 1, 0, 0, 0), new MBType(0, 0, 0, 1, 0, 1, 0), new MBType(0, 1, 0, 0, 0, 0, 0), new MBType(0, 0, 0, 0, 1, 0, 0), new MBType(0, 1, 0, 0, 0, 1, 0), new MBType(1, 1, 0, 1, 0, 0, 0), new MBType(1, 0, 0, 1, 0, 0, 0), new MBType(1, 0, 0, 0, 1, 0, 0), new MBType(1, 1, 0, 1, 0, 1, 0), new MBType(1, 0, 0, 1, 0, 1, 0), new MBType(0, 0, 0, 0, 0, 1, 0), new MBType(0, 0, 0, 1, 0, 0, 0), new MBType(1, 0, 0, 1, 0, 0, 0), new MBType(0, 0, 0, 0, 0, 0, 0) };
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 104 */   public static final VLC vlcMBTypeBSpat = VLC.createVLC(new String[] { "10", "11", "010", "011", "0010", "0011", "000110", "000111", "000100", "000101", "0000110", "0000111", "0000100", "0000101", "00000100", "00000101", "000001100", "000001110", "000001101", "000001111" });
/* 105 */   public static final MBType[] mbTypeValBSpat = new MBType[] { new MBType(0, 1, 1, 0, 0, 0, 0), new MBType(0, 1, 1, 1, 0, 0, 0), new MBType(0, 0, 1, 0, 0, 0, 0), new MBType(0, 0, 1, 1, 0, 0, 0), new MBType(0, 1, 0, 0, 0, 0, 0), new MBType(0, 1, 0, 1, 0, 0, 0), new MBType(0, 0, 1, 0, 0, 1, 0), new MBType(0, 0, 1, 1, 0, 1, 0), new MBType(0, 1, 0, 0, 0, 1, 0), new MBType(0, 1, 0, 1, 0, 1, 0), new MBType(0, 0, 0, 0, 1, 0, 0), new MBType(1, 1, 1, 1, 0, 0, 0), new MBType(1, 1, 0, 1, 0, 0, 0), new MBType(1, 0, 1, 1, 0, 0, 0), new MBType(1, 0, 0, 0, 1, 0, 0), new MBType(1, 1, 0, 1, 0, 1, 0), new MBType(1, 0, 1, 1, 0, 1, 0), new MBType(0, 0, 0, 0, 0, 0, 0), new MBType(1, 0, 0, 1, 0, 0, 0), new MBType(0, 0, 0, 1, 0, 0, 0) };
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 113 */   public static final VLC vlcMBTypeSNR = VLC.createVLC(new String[] { "1", "01", "001" });
/* 114 */   public static final MBType[] mbTypeValSNR = new MBType[] { new MBType(0, 0, 0, 1, 0, 0, 0), new MBType(1, 0, 0, 1, 0, 0, 0), new MBType(0, 0, 0, 0, 0, 0, 0) };
/*     */ 
/*     */ 
/*     */   
/* 118 */   public static final VLC vlcCBP = VLC.createVLC(new String[] { "000000001", "01011", "01001", "001101", "1101", "0010111", "0010011", "00011111", "1100", "0010110", "0010010", "00011110", "10011", "00011011", "00010111", "00010011", "1011", "0010101", "0010001", "00011101", "10001", "00011001", "00010101", "00010001", "001111", "00001111", "00001101", "000000011", "01111", "00001011", "00000111", "000000111", "1010", "0010100", "0010000", "00011100", "001110", "00001110", "00001100", "000000010", "10000", "00011000", "00010100", "00010000", "01110", "00001010", "00000110", "000000110", "10010", "00011010", 
/*     */         "00010110", "00010010", "01101", "00001001", "00000101", "000000101", "01100", "00001000", "00000100", "000000100", 
/* 120 */         "111", "01010", "01000", "001100" }); public static final VLC vlcMotionCode = VLC.createVLC(new String[] { "1", "01", "001", "0001", "000011", "0000101", "0000100", "0000011", "000001011", "000001010", "000001001", "0000010001", "0000010000", "0000001111", "0000001110", "0000001101", "0000001100" });
/*     */   
/* 122 */   public static final VLC vlcDualPrime = VLC.createVLC(new String[] { "11", "0", "10" });
/*     */   
/* 124 */   public static final VLC vlcDCSizeLuma = VLC.createVLC(new String[] { "100", "00", "01", "101", "110", "1110", "11110", "111110", "1111110", "11111110", "111111110", "111111111" });
/* 125 */   public static final VLC vlcDCSizeChroma = VLC.createVLC(new String[] { "00", "01", "10", "110", "1110", "11110", "111110", "1111110", "11111110", "111111110", "1111111110", "1111111111" }); public static final VLC vlcCoeff0; public static final VLC vlcCoeff1; public static final int CODE_ESCAPE = 2049; public static final int CODE_END = 2048;
/*     */   static {
/* 127 */     VLCBuilder vlcCoeffBldr = new VLCBuilder();
/* 128 */     vlcCoeffBldr.set(2049, "000001");
/* 129 */     vlcCoeffBldr.set(2048, "10");
/* 130 */     vlcCoeffBldr.set(1, "11");
/* 131 */     vlcCoeffBldr.set(65, "011");
/* 132 */     vlcCoeffBldr.set(2, "0100");
/* 133 */     vlcCoeffBldr.set(129, "0101");
/* 134 */     vlcCoeffBldr.set(3, "00101");
/* 135 */     vlcCoeffBldr.set(193, "00111");
/* 136 */     vlcCoeffBldr.set(257, "00110");
/* 137 */     vlcCoeffBldr.set(66, "000110");
/* 138 */     vlcCoeffBldr.set(321, "000111");
/* 139 */     vlcCoeffBldr.set(385, "000101");
/* 140 */     vlcCoeffBldr.set(449, "000100");
/* 141 */     vlcCoeffBldr.set(4, "0000110");
/* 142 */     vlcCoeffBldr.set(130, "0000100");
/* 143 */     vlcCoeffBldr.set(513, "0000111");
/* 144 */     vlcCoeffBldr.set(577, "0000101");
/* 145 */     vlcCoeffBldr.set(5, "00100110");
/* 146 */     vlcCoeffBldr.set(6, "00100001");
/* 147 */     vlcCoeffBldr.set(67, "00100101");
/* 148 */     vlcCoeffBldr.set(194, "00100100");
/* 149 */     vlcCoeffBldr.set(641, "00100111");
/* 150 */     vlcCoeffBldr.set(705, "00100011");
/* 151 */     vlcCoeffBldr.set(769, "00100010");
/* 152 */     vlcCoeffBldr.set(833, "00100000");
/* 153 */     vlcCoeffBldr.set(7, "0000001010");
/* 154 */     vlcCoeffBldr.set(68, "0000001100");
/* 155 */     vlcCoeffBldr.set(131, "0000001011");
/* 156 */     vlcCoeffBldr.set(258, "0000001111");
/* 157 */     vlcCoeffBldr.set(322, "0000001001");
/* 158 */     vlcCoeffBldr.set(897, "0000001110");
/* 159 */     vlcCoeffBldr.set(961, "0000001101");
/* 160 */     vlcCoeffBldr.set(1025, "0000001000");
/* 161 */     vlcCoeffBldr.set(8, "000000011101");
/* 162 */     vlcCoeffBldr.set(9, "000000011000");
/* 163 */     vlcCoeffBldr.set(10, "000000010011");
/* 164 */     vlcCoeffBldr.set(11, "000000010000");
/* 165 */     vlcCoeffBldr.set(69, "000000011011");
/* 166 */     vlcCoeffBldr.set(132, "000000010100");
/* 167 */     vlcCoeffBldr.set(195, "000000011100");
/* 168 */     vlcCoeffBldr.set(259, "000000010010");
/* 169 */     vlcCoeffBldr.set(386, "000000011110");
/* 170 */     vlcCoeffBldr.set(450, "000000010101");
/* 171 */     vlcCoeffBldr.set(514, "000000010001");
/* 172 */     vlcCoeffBldr.set(1089, "000000011111");
/* 173 */     vlcCoeffBldr.set(1153, "000000011010");
/* 174 */     vlcCoeffBldr.set(1217, "000000011001");
/* 175 */     vlcCoeffBldr.set(1281, "000000010111");
/* 176 */     vlcCoeffBldr.set(1345, "000000010110");
/* 177 */     vlcCoeffBldr.set(12, "0000000011010");
/* 178 */     vlcCoeffBldr.set(13, "0000000011001");
/* 179 */     vlcCoeffBldr.set(14, "0000000011000");
/* 180 */     vlcCoeffBldr.set(15, "0000000010111");
/* 181 */     vlcCoeffBldr.set(70, "0000000010110");
/* 182 */     vlcCoeffBldr.set(71, "0000000010101");
/* 183 */     vlcCoeffBldr.set(133, "0000000010100");
/* 184 */     vlcCoeffBldr.set(196, "0000000010011");
/* 185 */     vlcCoeffBldr.set(323, "0000000010010");
/* 186 */     vlcCoeffBldr.set(578, "0000000010001");
/* 187 */     vlcCoeffBldr.set(642, "0000000010000");
/* 188 */     vlcCoeffBldr.set(1409, "0000000011111");
/* 189 */     vlcCoeffBldr.set(1473, "0000000011110");
/* 190 */     vlcCoeffBldr.set(1537, "0000000011101");
/* 191 */     vlcCoeffBldr.set(1601, "0000000011100");
/* 192 */     vlcCoeffBldr.set(1665, "0000000011011");
/* 193 */     vlcCoeffBldr.set(16, "00000000011111");
/* 194 */     vlcCoeffBldr.set(17, "00000000011110");
/* 195 */     vlcCoeffBldr.set(18, "00000000011101");
/* 196 */     vlcCoeffBldr.set(19, "00000000011100");
/* 197 */     vlcCoeffBldr.set(20, "00000000011011");
/* 198 */     vlcCoeffBldr.set(21, "00000000011010");
/* 199 */     vlcCoeffBldr.set(22, "00000000011001");
/* 200 */     vlcCoeffBldr.set(23, "00000000011000");
/* 201 */     vlcCoeffBldr.set(24, "00000000010111");
/* 202 */     vlcCoeffBldr.set(25, "00000000010110");
/* 203 */     vlcCoeffBldr.set(26, "00000000010101");
/* 204 */     vlcCoeffBldr.set(27, "00000000010100");
/* 205 */     vlcCoeffBldr.set(28, "00000000010011");
/* 206 */     vlcCoeffBldr.set(29, "00000000010010");
/* 207 */     vlcCoeffBldr.set(30, "00000000010001");
/* 208 */     vlcCoeffBldr.set(31, "00000000010000");
/* 209 */     vlcCoeffBldr.set(32, "000000000011000");
/* 210 */     vlcCoeffBldr.set(33, "000000000010111");
/* 211 */     vlcCoeffBldr.set(34, "000000000010110");
/* 212 */     vlcCoeffBldr.set(35, "000000000010101");
/* 213 */     vlcCoeffBldr.set(36, "000000000010100");
/* 214 */     vlcCoeffBldr.set(37, "000000000010011");
/* 215 */     vlcCoeffBldr.set(38, "000000000010010");
/* 216 */     vlcCoeffBldr.set(39, "000000000010001");
/* 217 */     vlcCoeffBldr.set(40, "000000000010000");
/* 218 */     vlcCoeffBldr.set(72, "000000000011111");
/* 219 */     vlcCoeffBldr.set(73, "000000000011110");
/* 220 */     vlcCoeffBldr.set(74, "000000000011101");
/* 221 */     vlcCoeffBldr.set(75, "000000000011100");
/* 222 */     vlcCoeffBldr.set(76, "000000000011011");
/* 223 */     vlcCoeffBldr.set(77, "000000000011010");
/* 224 */     vlcCoeffBldr.set(78, "000000000011001");
/* 225 */     vlcCoeffBldr.set(79, "0000000000010011");
/* 226 */     vlcCoeffBldr.set(80, "0000000000010010");
/* 227 */     vlcCoeffBldr.set(81, "0000000000010001");
/* 228 */     vlcCoeffBldr.set(82, "0000000000010000");
/* 229 */     vlcCoeffBldr.set(387, "0000000000010100");
/* 230 */     vlcCoeffBldr.set(706, "0000000000011010");
/* 231 */     vlcCoeffBldr.set(770, "0000000000011001");
/* 232 */     vlcCoeffBldr.set(834, "0000000000011000");
/* 233 */     vlcCoeffBldr.set(898, "0000000000010111");
/* 234 */     vlcCoeffBldr.set(962, "0000000000010110");
/* 235 */     vlcCoeffBldr.set(1026, "0000000000010101");
/* 236 */     vlcCoeffBldr.set(1729, "0000000000011111");
/* 237 */     vlcCoeffBldr.set(1793, "0000000000011110");
/* 238 */     vlcCoeffBldr.set(1857, "0000000000011101");
/* 239 */     vlcCoeffBldr.set(1921, "0000000000011100");
/* 240 */     vlcCoeffBldr.set(1985, "0000000000011011");
/* 241 */     vlcCoeff0 = vlcCoeffBldr.getVLC();
/*     */     
/* 243 */     vlcCoeffBldr = new VLCBuilder();
/* 244 */     vlcCoeffBldr.set(2049, "000001");
/* 245 */     vlcCoeffBldr.set(2048, "0110");
/* 246 */     vlcCoeffBldr.set(1, "10");
/* 247 */     vlcCoeffBldr.set(65, "010");
/* 248 */     vlcCoeffBldr.set(2, "110");
/* 249 */     vlcCoeffBldr.set(129, "00101");
/* 250 */     vlcCoeffBldr.set(3, "0111");
/* 251 */     vlcCoeffBldr.set(193, "00111");
/* 252 */     vlcCoeffBldr.set(257, "000110");
/* 253 */     vlcCoeffBldr.set(66, "00110");
/* 254 */     vlcCoeffBldr.set(321, "000111");
/* 255 */     vlcCoeffBldr.set(385, "0000110");
/* 256 */     vlcCoeffBldr.set(449, "0000100");
/* 257 */     vlcCoeffBldr.set(4, "11100");
/* 258 */     vlcCoeffBldr.set(130, "0000111");
/* 259 */     vlcCoeffBldr.set(513, "0000101");
/* 260 */     vlcCoeffBldr.set(577, "1111000");
/* 261 */     vlcCoeffBldr.set(5, "11101");
/* 262 */     vlcCoeffBldr.set(6, "000101");
/* 263 */     vlcCoeffBldr.set(67, "1111001");
/* 264 */     vlcCoeffBldr.set(194, "00100110");
/* 265 */     vlcCoeffBldr.set(641, "1111010");
/* 266 */     vlcCoeffBldr.set(705, "00100001");
/* 267 */     vlcCoeffBldr.set(769, "00100101");
/* 268 */     vlcCoeffBldr.set(833, "00100100");
/* 269 */     vlcCoeffBldr.set(7, "000100");
/* 270 */     vlcCoeffBldr.set(68, "00100111");
/* 271 */     vlcCoeffBldr.set(131, "11111100");
/* 272 */     vlcCoeffBldr.set(258, "11111101");
/* 273 */     vlcCoeffBldr.set(322, "000000100");
/* 274 */     vlcCoeffBldr.set(897, "000000101");
/* 275 */     vlcCoeffBldr.set(961, "000000111");
/* 276 */     vlcCoeffBldr.set(1025, "0000001101");
/* 277 */     vlcCoeffBldr.set(8, "1111011");
/* 278 */     vlcCoeffBldr.set(9, "1111100");
/* 279 */     vlcCoeffBldr.set(10, "00100011");
/* 280 */     vlcCoeffBldr.set(11, "00100010");
/* 281 */     vlcCoeffBldr.set(69, "00100000");
/* 282 */     vlcCoeffBldr.set(132, "0000001100");
/* 283 */     vlcCoeffBldr.set(195, "000000011100");
/* 284 */     vlcCoeffBldr.set(259, "000000010010");
/* 285 */     vlcCoeffBldr.set(386, "000000011110");
/* 286 */     vlcCoeffBldr.set(450, "000000010101");
/* 287 */     vlcCoeffBldr.set(514, "000000010001");
/* 288 */     vlcCoeffBldr.set(1089, "000000011111");
/* 289 */     vlcCoeffBldr.set(1153, "000000011010");
/* 290 */     vlcCoeffBldr.set(1217, "000000011001");
/* 291 */     vlcCoeffBldr.set(1281, "000000010111");
/* 292 */     vlcCoeffBldr.set(1345, "000000010110");
/* 293 */     vlcCoeffBldr.set(12, "11111010");
/* 294 */     vlcCoeffBldr.set(13, "11111011");
/* 295 */     vlcCoeffBldr.set(14, "11111110");
/* 296 */     vlcCoeffBldr.set(15, "11111111");
/* 297 */     vlcCoeffBldr.set(70, "0000000010110");
/* 298 */     vlcCoeffBldr.set(71, "0000000010101");
/* 299 */     vlcCoeffBldr.set(133, "0000000010100");
/* 300 */     vlcCoeffBldr.set(196, "0000000010011");
/* 301 */     vlcCoeffBldr.set(323, "0000000010010");
/* 302 */     vlcCoeffBldr.set(578, "0000000010001");
/* 303 */     vlcCoeffBldr.set(642, "0000000010000");
/* 304 */     vlcCoeffBldr.set(1409, "0000000011111");
/* 305 */     vlcCoeffBldr.set(1473, "0000000011110");
/* 306 */     vlcCoeffBldr.set(1537, "0000000011101");
/* 307 */     vlcCoeffBldr.set(1601, "0000000011100");
/* 308 */     vlcCoeffBldr.set(1665, "0000000011011");
/* 309 */     vlcCoeffBldr.set(16, "00000000011111");
/* 310 */     vlcCoeffBldr.set(17, "00000000011110");
/* 311 */     vlcCoeffBldr.set(18, "00000000011101");
/* 312 */     vlcCoeffBldr.set(19, "00000000011100");
/* 313 */     vlcCoeffBldr.set(20, "00000000011011");
/* 314 */     vlcCoeffBldr.set(21, "00000000011010");
/* 315 */     vlcCoeffBldr.set(22, "00000000011001");
/* 316 */     vlcCoeffBldr.set(23, "00000000011000");
/* 317 */     vlcCoeffBldr.set(24, "00000000010111");
/* 318 */     vlcCoeffBldr.set(25, "00000000010110");
/* 319 */     vlcCoeffBldr.set(26, "00000000010101");
/* 320 */     vlcCoeffBldr.set(27, "00000000010100");
/* 321 */     vlcCoeffBldr.set(28, "00000000010011");
/* 322 */     vlcCoeffBldr.set(29, "00000000010010");
/* 323 */     vlcCoeffBldr.set(30, "00000000010001");
/* 324 */     vlcCoeffBldr.set(31, "00000000010000");
/* 325 */     vlcCoeffBldr.set(32, "000000000011000");
/* 326 */     vlcCoeffBldr.set(33, "000000000010111");
/* 327 */     vlcCoeffBldr.set(34, "000000000010110");
/* 328 */     vlcCoeffBldr.set(35, "000000000010101");
/* 329 */     vlcCoeffBldr.set(36, "000000000010100");
/* 330 */     vlcCoeffBldr.set(37, "000000000010011");
/* 331 */     vlcCoeffBldr.set(38, "000000000010010");
/* 332 */     vlcCoeffBldr.set(39, "000000000010001");
/* 333 */     vlcCoeffBldr.set(40, "000000000010000");
/* 334 */     vlcCoeffBldr.set(72, "000000000011111");
/* 335 */     vlcCoeffBldr.set(73, "000000000011110");
/* 336 */     vlcCoeffBldr.set(74, "000000000011101");
/* 337 */     vlcCoeffBldr.set(75, "000000000011100");
/* 338 */     vlcCoeffBldr.set(76, "000000000011011");
/* 339 */     vlcCoeffBldr.set(77, "000000000011010");
/* 340 */     vlcCoeffBldr.set(78, "000000000011001");
/* 341 */     vlcCoeffBldr.set(79, "0000000000010011");
/* 342 */     vlcCoeffBldr.set(80, "0000000000010010");
/* 343 */     vlcCoeffBldr.set(81, "0000000000010001");
/* 344 */     vlcCoeffBldr.set(82, "0000000000010000");
/* 345 */     vlcCoeffBldr.set(387, "0000000000010100");
/* 346 */     vlcCoeffBldr.set(706, "0000000000011010");
/* 347 */     vlcCoeffBldr.set(770, "0000000000011001");
/* 348 */     vlcCoeffBldr.set(834, "0000000000011000");
/* 349 */     vlcCoeffBldr.set(898, "0000000000010111");
/* 350 */     vlcCoeffBldr.set(962, "0000000000010110");
/* 351 */     vlcCoeffBldr.set(1026, "0000000000010101");
/* 352 */     vlcCoeffBldr.set(1729, "0000000000011111");
/* 353 */     vlcCoeffBldr.set(1793, "0000000000011110");
/* 354 */     vlcCoeffBldr.set(1857, "0000000000011101");
/* 355 */     vlcCoeffBldr.set(1921, "0000000000011100");
/* 356 */     vlcCoeffBldr.set(1985, "0000000000011011");
/* 357 */     vlcCoeff1 = vlcCoeffBldr.getVLC();
/*     */   }
/*     */   
/* 360 */   public static final int[] qScaleTab1 = new int[] { 0, 2, 4, 6, 8, 10, 12, 14, 16, 18, 20, 22, 24, 26, 28, 30, 32, 34, 36, 38, 40, 42, 44, 46, 48, 50, 52, 54, 56, 58, 60, 62 };
/*     */   
/* 362 */   public static final int[] qScaleTab2 = new int[] { 0, 1, 2, 3, 4, 5, 6, 7, 8, 10, 12, 14, 16, 18, 20, 22, 24, 28, 32, 36, 40, 44, 48, 52, 56, 64, 72, 80, 88, 96, 104, 112 };
/*     */ 
/*     */   
/* 365 */   public static final int[] defaultQMatIntra = new int[] { 8, 16, 19, 22, 26, 27, 29, 34, 16, 16, 22, 24, 27, 29, 34, 37, 19, 22, 26, 27, 29, 34, 34, 38, 22, 22, 26, 27, 29, 34, 37, 40, 22, 26, 27, 29, 32, 35, 40, 48, 26, 27, 29, 32, 35, 40, 48, 58, 26, 27, 29, 34, 38, 46, 56, 69, 27, 29, 35, 38, 46, 56, 69, 83 };
/*     */ 
/*     */ 
/*     */   
/* 369 */   public static final int[] defaultQMatInter = new int[] { 16, 16, 16, 16, 16, 16, 16, 16, 16, 16, 16, 16, 16, 16, 16, 16, 16, 16, 16, 16, 16, 16, 16, 16, 16, 16, 16, 16, 16, 16, 16, 16, 16, 16, 16, 16, 16, 16, 16, 16, 16, 16, 16, 16, 16, 16, 16, 16, 16, 16, 16, 16, 16, 16, 16, 16, 16, 16, 16, 16, 16, 16, 16, 16 };
/*     */ 
/*     */ 
/*     */   
/* 373 */   public static final int[][] scan = new int[][] { { 0, 1, 8, 16, 9, 2, 3, 10, 17, 24, 32, 25, 18, 11, 4, 5, 12, 19, 26, 33, 40, 48, 41, 34, 27, 20, 13, 6, 7, 14, 21, 28, 35, 42, 49, 56, 57, 50, 43, 36, 29, 22, 15, 23, 30, 37, 44, 51, 58, 59, 52, 45, 38, 31, 39, 46, 53, 60, 61, 54, 47, 55, 62, 63 }, { 0, 8, 16, 24, 1, 9, 2, 10, 17, 25, 32, 40, 48, 56, 57, 49, 41, 33, 26, 18, 3, 11, 4, 12, 19, 27, 34, 42, 50, 58, 35, 43, 51, 59, 20, 28, 5, 13, 6, 14, 21, 29, 36, 44, 52, 60, 37, 45, 53, 61, 22, 30, 7, 15, 23, 31, 38, 46, 54, 62, 39, 47, 55, 63 } };
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 382 */   public static final int[] BLOCK_TO_CC = new int[] { 0, 0, 0, 0, 1, 2, 1, 2, 1, 2, 1, 2 };
/* 383 */   public static final int[] BLOCK_POS_X = new int[] { 0, 8, 0, 8, 0, 0, 0, 0, 8, 8, 8, 8, 0, 0, 0, 0, 0, 8, 0, 8, 0, 0, 0, 0, 8, 8, 8, 8 };
/*     */   
/* 385 */   public static final int[] BLOCK_POS_Y = new int[] { 0, 0, 8, 8, 0, 0, 8, 8, 0, 0, 8, 8, 0, 0, 0, 0, 0, 0, 1, 1, 0, 0, 1, 1, 0, 0, 1, 1 };
/*     */   
/* 387 */   public static final int[] STEP_Y = new int[] { 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1 };
/*     */   
/* 389 */   public static final int[] SQUEEZE_X = new int[] { 0, 1, 1, 0 };
/* 390 */   public static final int[] SQUEEZE_Y = new int[] { 0, 1, 0, 0 };
/*     */   public static final int IntraCoded = 1;
/*     */   public static final int PredictiveCoded = 2;
/*     */   public static final int BiPredictiveCoded = 3;
/*     */ }


/* Location:              C:\Users\rapha\Downloads\aurora.jar!\META-INF\jars\jcodec-0.2.5.jar!\org\jcodec\codecs\mpeg12\MPEGConst.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */