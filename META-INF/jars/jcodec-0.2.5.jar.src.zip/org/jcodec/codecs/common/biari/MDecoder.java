/*     */ package org.jcodec.codecs.common.biari;
/*     */ 
/*     */ import java.nio.ByteBuffer;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class MDecoder
/*     */ {
/*     */   private ByteBuffer _in;
/*     */   private int range;
/*     */   private int code;
/*     */   private int nBitsPending;
/*     */   private int[][] cm;
/*     */   
/*     */   public MDecoder(ByteBuffer _in, int[][] cm) {
/*  23 */     this._in = _in;
/*  24 */     this.range = 510;
/*  25 */     this.cm = cm;
/*     */     
/*  27 */     initCodeRegister();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void initCodeRegister() {
/*  38 */     readOneByte();
/*  39 */     if (this.nBitsPending != 8)
/*  40 */       throw new RuntimeException("Empty stream"); 
/*  41 */     this.code <<= 8;
/*  42 */     readOneByte();
/*  43 */     this.code <<= 1;
/*  44 */     this.nBitsPending -= 9;
/*     */   }
/*     */   
/*     */   protected void readOneByte() {
/*  48 */     if (!this._in.hasRemaining())
/*     */       return; 
/*  50 */     int b = this._in.get() & 0xFF;
/*  51 */     this.code |= b;
/*  52 */     this.nBitsPending += 8;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int decodeBin(int m) {
/*  65 */     int bin, qIdx = this.range >> 6 & 0x3;
/*  66 */     int rLPS = MConst.rangeLPS[qIdx][this.cm[0][m]];
/*  67 */     this.range -= rLPS;
/*  68 */     int rs8 = this.range << 8;
/*     */     
/*  70 */     if (this.code < rs8) {
/*     */       
/*  72 */       if (this.cm[0][m] < 62) {
/*  73 */         this.cm[0][m] = this.cm[0][m] + 1;
/*     */       }
/*  75 */       renormalize();
/*     */       
/*  77 */       bin = this.cm[1][m];
/*     */     } else {
/*     */       
/*  80 */       this.range = rLPS;
/*  81 */       this.code -= rs8;
/*     */       
/*  83 */       renormalize();
/*     */       
/*  85 */       bin = 1 - this.cm[1][m];
/*     */       
/*  87 */       if (this.cm[0][m] == 0) {
/*  88 */         this.cm[1][m] = 1 - this.cm[1][m];
/*     */       }
/*  90 */       this.cm[0][m] = MConst.transitLPS[this.cm[0][m]];
/*     */     } 
/*     */ 
/*     */     
/*  94 */     return bin;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int decodeFinalBin() {
/* 106 */     this.range -= 2;
/*     */     
/* 108 */     if (this.code < this.range << 8) {
/* 109 */       renormalize();
/*     */       
/* 111 */       return 0;
/*     */     } 
/*     */     
/* 114 */     return 1;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int decodeBinBypass() {
/* 125 */     this.code <<= 1;
/*     */     
/* 127 */     this.nBitsPending--;
/* 128 */     if (this.nBitsPending <= 0) {
/* 129 */       readOneByte();
/*     */     }
/* 131 */     int tmp = this.code - (this.range << 8);
/* 132 */     if (tmp < 0)
/*     */     {
/* 134 */       return 0;
/*     */     }
/*     */     
/* 137 */     this.code = tmp;
/* 138 */     return 1;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void renormalize() {
/* 152 */     while (this.range < 256) {
/* 153 */       this.range <<= 1;
/* 154 */       this.code <<= 1;
/* 155 */       this.code &= 0x1FFFF;
/*     */       
/* 157 */       this.nBitsPending--;
/* 158 */       if (this.nBitsPending <= 0)
/* 159 */         readOneByte(); 
/*     */     } 
/*     */   }
/*     */ }


/* Location:              C:\Users\rapha\Downloads\aurora.jar!\META-INF\jars\jcodec-0.2.5.jar!\org\jcodec\codecs\common\biari\MDecoder.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */