/*     */ package org.jcodec.codecs.common.biari;
/*     */ 
/*     */ import java.io.ByteArrayInputStream;
/*     */ import java.io.IOException;
/*     */ import java.io.InputStream;
/*     */ import java.io.OutputStream;
/*     */ import org.jcodec.platform.BaseOutputStream;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class BitIO
/*     */ {
/*     */   public static InputBits inputFromStream(InputStream is) {
/*  32 */     return new StreamInputBits(is);
/*     */   }
/*     */   
/*     */   public static OutputBits outputFromStream(OutputStream out) {
/*  36 */     return new StreamOutputBits(out);
/*     */   }
/*     */   
/*     */   public static InputBits inputFromArray(byte[] bytes) {
/*  40 */     return new StreamInputBits(new ByteArrayInputStream(bytes));
/*     */   }
/*     */   
/*     */   public static OutputBits outputFromArray(final byte[] bytes) {
/*  44 */     return new StreamOutputBits((OutputStream)new BaseOutputStream() {
/*     */           int ptr;
/*     */           
/*     */           protected void writeByte(int b) throws IOException {
/*  48 */             if (this.ptr >= bytes.length)
/*  49 */               throw new IOException("Buffer is full"); 
/*  50 */             bytes[this.ptr++] = (byte)b;
/*     */           }
/*     */         });
/*     */   }
/*     */   
/*     */   public static byte[] compressBits(int[] decompressed) {
/*  56 */     byte[] compressed = new byte[(decompressed.length >> 3) + 1];
/*  57 */     OutputBits out = outputFromArray(compressed);
/*     */     try {
/*  59 */       for (int i = 0; i < decompressed.length; i++) {
/*  60 */         int bit = decompressed[i];
/*  61 */         out.putBit(bit);
/*     */       } 
/*  63 */     } catch (IOException iOException) {}
/*     */ 
/*     */     
/*  66 */     return compressed;
/*     */   }
/*     */   
/*     */   public static int[] decompressBits(byte[] compressed) {
/*  70 */     int[] decompressed = new int[compressed.length << 3];
/*  71 */     InputBits inputFromArray = inputFromArray(compressed);
/*     */     try {
/*     */       int read;
/*  74 */       for (int i = 0; (read = inputFromArray.getBit()) != -1; i++) {
/*  75 */         decompressed[i] = read;
/*     */       }
/*  77 */     } catch (IOException iOException) {}
/*     */     
/*  79 */     return decompressed;
/*     */   }
/*     */   public static interface InputBits {
/*     */     int getBit() throws IOException; }
/*     */   public static interface OutputBits {
/*     */     void putBit(int param1Int) throws IOException;
/*     */     void flush() throws IOException; }
/*     */   public static class StreamInputBits implements InputBits { private InputStream _in;
/*     */     public StreamInputBits(InputStream _in) {
/*  88 */       this._in = _in;
/*  89 */       this.bit = 8;
/*     */     }
/*     */     private int cur; private int bit;
/*     */     public int getBit() throws IOException {
/*  93 */       if (this.bit > 7) {
/*  94 */         this.cur = this._in.read();
/*  95 */         if (this.cur == -1)
/*  96 */           return -1; 
/*  97 */         this.bit = 0;
/*     */       } 
/*  99 */       return this.cur >> 7 - this.bit++ & 0x1;
/*     */     } }
/*     */ 
/*     */   
/*     */   public static class StreamOutputBits implements OutputBits {
/*     */     private OutputStream out;
/*     */     private int cur;
/*     */     private int bit;
/*     */     
/*     */     public StreamOutputBits(OutputStream out) {
/* 109 */       this.out = out;
/*     */     }
/*     */     
/*     */     public void putBit(int symbol) throws IOException {
/* 113 */       if (this.bit > 7) {
/* 114 */         this.out.write(this.cur);
/* 115 */         this.cur = 0;
/* 116 */         this.bit = 0;
/*     */       } 
/* 118 */       this.cur |= (symbol & 0x1) << 7 - this.bit++;
/*     */     }
/*     */     
/*     */     public void flush() throws IOException {
/* 122 */       if (this.bit > 0)
/* 123 */         this.out.write(this.cur); 
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\rapha\Downloads\aurora.jar!\META-INF\jars\jcodec-0.2.5.jar!\org\jcodec\codecs\common\biari\BitIO.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */