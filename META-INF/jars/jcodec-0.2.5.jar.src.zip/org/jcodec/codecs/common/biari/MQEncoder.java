/*     */ package org.jcodec.codecs.common.biari;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.io.OutputStream;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class MQEncoder
/*     */ {
/*     */   public static final int CARRY_MASK = 134217728;
/*     */   private int range;
/*     */   private int offset;
/*     */   private int bitsToCode;
/*     */   private long bytesOutput;
/*     */   private int byteToGo;
/*     */   private OutputStream out;
/*     */   
/*     */   public MQEncoder(OutputStream out) {
/*  34 */     this.range = 32768;
/*  35 */     this.offset = 0;
/*  36 */     this.bitsToCode = 12;
/*  37 */     this.out = out;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void encode(int symbol, Context cm) throws IOException {
/*  48 */     int rangeLps = MQConst.pLps[cm.getState()];
/*  49 */     if (symbol == cm.getMps()) {
/*  50 */       this.range -= rangeLps;
/*  51 */       this.offset += rangeLps;
/*  52 */       if (this.range < 32768) {
/*  53 */         while (this.range < 32768)
/*  54 */           renormalize(); 
/*  55 */         cm.setState(MQConst.transitMPS[cm.getState()]);
/*     */       } 
/*     */     } else {
/*  58 */       this.range = rangeLps;
/*  59 */       while (this.range < 32768) {
/*  60 */         renormalize();
/*     */       }
/*  62 */       if (MQConst.mpsSwitch[cm.getState()] != 0)
/*  63 */         cm.setMps(1 - cm.getMps()); 
/*  64 */       cm.setState(MQConst.transitLPS[cm.getState()]);
/*     */     } 
/*     */   }
/*     */   
/*     */   public void finish() throws IOException {
/*  69 */     finalizeValue();
/*  70 */     this.offset <<= this.bitsToCode;
/*     */     
/*  72 */     int bitsToOutput = 12 - this.bitsToCode;
/*  73 */     outputByte();
/*  74 */     bitsToOutput -= this.bitsToCode;
/*  75 */     if (bitsToOutput > 0) {
/*  76 */       this.offset <<= this.bitsToCode;
/*  77 */       outputByte();
/*     */     } 
/*     */     
/*  80 */     this.out.write(this.byteToGo);
/*     */   }
/*     */   
/*     */   private void finalizeValue() {
/*  84 */     int halfBit = this.offset & 0x8000;
/*  85 */     this.offset &= 0xFFFF0000;
/*  86 */     if (halfBit == 0) {
/*  87 */       this.offset |= 0x8000;
/*     */     } else {
/*  89 */       this.offset += 65536;
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   private void renormalize() throws IOException {
/*  95 */     this.offset <<= 1;
/*  96 */     this.range <<= 1;
/*  97 */     this.range = (int)(this.range & 0xFFFFL);
/*     */     
/*  99 */     this.bitsToCode--;
/*     */     
/* 101 */     if (this.bitsToCode == 0)
/* 102 */       outputByte(); 
/*     */   }
/*     */   
/*     */   private void outputByte() throws IOException {
/* 106 */     if (this.bytesOutput == 0L)
/* 107 */     { outputByteNoStuffing(); }
/*     */     
/* 109 */     else if (this.byteToGo == 255)
/* 110 */     { outputByteWithStuffing(); }
/*     */     
/* 112 */     else if ((this.offset & 0x8000000) != 0)
/* 113 */     { this.byteToGo++;
/* 114 */       this.offset &= 0x7FFFFFF;
/* 115 */       if (this.byteToGo == 255) {
/* 116 */         outputByteWithStuffing();
/*     */       } else {
/* 118 */         outputByteNoStuffing();
/*     */       }  }
/* 120 */     else { outputByteNoStuffing(); }
/*     */   
/*     */   }
/*     */ 
/*     */   
/*     */   private void outputByteWithStuffing() throws IOException {
/* 126 */     this.bitsToCode = 7;
/* 127 */     if (this.bytesOutput > 0L) {
/* 128 */       this.out.write(this.byteToGo);
/*     */     }
/* 130 */     this.byteToGo = this.offset >> 20 & 0xFF;
/* 131 */     this.offset &= 0xFFFFF;
/*     */     
/* 133 */     this.bytesOutput++;
/*     */   }
/*     */   
/*     */   private void outputByteNoStuffing() throws IOException {
/* 137 */     this.bitsToCode = 8;
/* 138 */     if (this.bytesOutput > 0L) {
/* 139 */       this.out.write(this.byteToGo);
/*     */     }
/* 141 */     this.byteToGo = this.offset >> 19 & 0xFF;
/*     */     
/* 143 */     this.offset &= 0x7FFFF;
/*     */     
/* 145 */     this.bytesOutput++;
/*     */   }
/*     */ }


/* Location:              C:\Users\rapha\Downloads\aurora.jar!\META-INF\jars\jcodec-0.2.5.jar!\org\jcodec\codecs\common\biari\MQEncoder.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */