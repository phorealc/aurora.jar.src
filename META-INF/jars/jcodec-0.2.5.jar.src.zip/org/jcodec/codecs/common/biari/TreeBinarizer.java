/*    */ package org.jcodec.codecs.common.biari;
/*    */ 
/*    */ import java.io.IOException;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class TreeBinarizer
/*    */ {
/*    */   private Context[] models;
/*    */   
/*    */   public TreeBinarizer() {
/* 22 */     initContextModels();
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   private void initContextModels() {
/* 28 */     this.models = new Context[255];
/* 29 */     for (int i = 0; i < 255; i++) {
/* 30 */       this.models[i] = new Context(0, 0);
/*    */     }
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public void binarize(int symbol, MQEncoder encoder) throws IOException {
/* 38 */     int inverted = 0;
/* 39 */     int nextModel = 0;
/* 40 */     int levelOffset = 0;
/* 41 */     for (int i = 0; i < 8; i++) {
/* 42 */       int bin = symbol >> 7 - i & 0x1;
/* 43 */       encoder.encode(bin, this.models[nextModel]);
/*    */ 
/*    */       
/* 46 */       inverted |= bin << i;
/* 47 */       levelOffset += 1 << i;
/* 48 */       nextModel = levelOffset + inverted;
/*    */     } 
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public int debinarize(MQDecoder decoder) throws IOException {
/* 55 */     int symbol = 0;
/* 56 */     int inverted = 0;
/* 57 */     int nextModel = 0;
/* 58 */     int levelOffset = 0;
/* 59 */     for (int i = 0; i < 8; i++) {
/* 60 */       int bin = decoder.decode(this.models[nextModel]);
/* 61 */       symbol |= bin << 7 - i;
/*    */ 
/*    */       
/* 64 */       inverted |= bin << i;
/* 65 */       levelOffset += 1 << i;
/* 66 */       nextModel = levelOffset + inverted;
/*    */     } 
/*    */     
/* 69 */     return symbol;
/*    */   }
/*    */ }


/* Location:              C:\Users\rapha\Downloads\aurora.jar!\META-INF\jars\jcodec-0.2.5.jar!\org\jcodec\codecs\common\biari\TreeBinarizer.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */