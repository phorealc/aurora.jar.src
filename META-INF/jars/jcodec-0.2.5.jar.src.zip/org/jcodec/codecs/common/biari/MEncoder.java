/*     */ package org.jcodec.codecs.common.biari;
/*     */ 
/*     */ import java.nio.ByteBuffer;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class MEncoder
/*     */ {
/*     */   private ByteBuffer out;
/*     */   private int range;
/*     */   private int offset;
/*     */   private int onesOutstanding;
/*     */   private boolean zeroBorrowed;
/*     */   private int outReg;
/*     */   private int bitsInOutReg;
/*     */   private int[][] models;
/*     */   
/*     */   public MEncoder(ByteBuffer out, int[][] models) {
/*  32 */     this.range = 510;
/*     */     
/*  34 */     this.models = models;
/*  35 */     this.out = out;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void encodeBin(int model, int bin) {
/*  47 */     int qs = this.range >> 6 & 0x3;
/*  48 */     int rangeLPS = MConst.rangeLPS[qs][this.models[0][model]];
/*  49 */     this.range -= rangeLPS;
/*     */     
/*  51 */     if (bin != this.models[1][model]) {
/*  52 */       this.offset += this.range;
/*  53 */       this.range = rangeLPS;
/*  54 */       if (this.models[0][model] == 0) {
/*  55 */         this.models[1][model] = 1 - this.models[1][model];
/*     */       }
/*  57 */       this.models[0][model] = MConst.transitLPS[this.models[0][model]];
/*     */     }
/*  59 */     else if (this.models[0][model] < 62) {
/*  60 */       this.models[0][model] = this.models[0][model] + 1;
/*     */     } 
/*     */     
/*  63 */     renormalize();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void encodeBinBypass(int bin) {
/*  74 */     this.offset <<= 1;
/*  75 */     if (bin == 1) {
/*  76 */       this.offset += this.range;
/*     */     }
/*     */     
/*  79 */     if ((this.offset & 0x400) != 0) {
/*  80 */       flushOutstanding(1);
/*  81 */       this.offset &= 0x3FF;
/*  82 */     } else if ((this.offset & 0x200) != 0) {
/*  83 */       this.offset &= 0x1FF;
/*  84 */       this.onesOutstanding++;
/*     */     } else {
/*  86 */       flushOutstanding(0);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void encodeBinFinal(int bin) {
/*  97 */     this.range -= 2;
/*  98 */     if (bin == 0) {
/*  99 */       renormalize();
/*     */     } else {
/* 101 */       this.offset += this.range;
/* 102 */       this.range = 2;
/* 103 */       renormalize();
/*     */     } 
/*     */   }
/*     */   
/*     */   public void finishEncoding() {
/* 108 */     flushOutstanding(this.offset >> 9 & 0x1);
/* 109 */     putBit(this.offset >> 8 & 0x1);
/* 110 */     stuffBits();
/*     */   }
/*     */   
/*     */   private void renormalize() {
/* 114 */     while (this.range < 256) {
/* 115 */       if (this.offset < 256) {
/* 116 */         flushOutstanding(0);
/* 117 */       } else if (this.offset < 512) {
/* 118 */         this.offset &= 0xFF;
/* 119 */         this.onesOutstanding++;
/*     */       } else {
/* 121 */         this.offset &= 0x1FF;
/* 122 */         flushOutstanding(1);
/*     */       } 
/*     */       
/* 125 */       this.range <<= 1;
/* 126 */       this.offset <<= 1;
/*     */     } 
/*     */   }
/*     */   
/*     */   private void flushOutstanding(int hasCarry) {
/* 131 */     if (this.zeroBorrowed) {
/* 132 */       putBit(hasCarry);
/*     */     }
/* 134 */     int trailingBit = 1 - hasCarry;
/* 135 */     for (; this.onesOutstanding > 0; this.onesOutstanding--) {
/* 136 */       putBit(trailingBit);
/*     */     }
/* 138 */     this.zeroBorrowed = true;
/*     */   }
/*     */   
/*     */   private void putBit(int bit) {
/* 142 */     this.outReg = this.outReg << 1 | bit;
/* 143 */     this.bitsInOutReg++;
/*     */     
/* 145 */     if (this.bitsInOutReg == 8) {
/* 146 */       this.out.put((byte)this.outReg);
/* 147 */       this.outReg = 0;
/* 148 */       this.bitsInOutReg = 0;
/*     */     } 
/*     */   }
/*     */   
/*     */   private void stuffBits() {
/* 153 */     if (this.bitsInOutReg == 0) {
/* 154 */       this.out.put(-128);
/*     */     } else {
/* 156 */       this.outReg = this.outReg << 1 | 0x1;
/* 157 */       this.outReg <<= 8 - this.bitsInOutReg + 1;
/* 158 */       this.out.put((byte)this.outReg);
/* 159 */       this.outReg = 0;
/* 160 */       this.bitsInOutReg = 0;
/*     */     } 
/*     */   }
/*     */ }


/* Location:              C:\Users\rapha\Downloads\aurora.jar!\META-INF\jars\jcodec-0.2.5.jar!\org\jcodec\codecs\common\biari\MEncoder.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */