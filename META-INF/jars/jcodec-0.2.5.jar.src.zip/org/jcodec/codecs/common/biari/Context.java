/*    */ package org.jcodec.codecs.common.biari;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class Context
/*    */ {
/*    */   private int stateIdx;
/*    */   private int mps;
/*    */   
/*    */   public Context(int state, int mps) {
/* 19 */     this.stateIdx = state;
/* 20 */     this.mps = mps;
/*    */   }
/*    */   
/*    */   public int getState() {
/* 24 */     return this.stateIdx;
/*    */   }
/*    */   
/*    */   public int getMps() {
/* 28 */     return this.mps;
/*    */   }
/*    */   
/*    */   public void setMps(int mps) {
/* 32 */     this.mps = mps;
/*    */   }
/*    */   
/*    */   public void setState(int state) {
/* 36 */     this.stateIdx = state;
/*    */   }
/*    */ }


/* Location:              C:\Users\rapha\Downloads\aurora.jar!\META-INF\jars\jcodec-0.2.5.jar!\org\jcodec\codecs\common\biari\Context.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */