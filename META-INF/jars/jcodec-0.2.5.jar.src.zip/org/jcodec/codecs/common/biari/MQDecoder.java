/*    */ package org.jcodec.codecs.common.biari;
/*    */ 
/*    */ import java.io.IOException;
/*    */ import java.io.InputStream;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class MQDecoder
/*    */ {
/*    */   private int range;
/*    */   private int value;
/*    */   private int availableBits;
/*    */   private int lastByte;
/*    */   private int decodedBytes;
/*    */   private InputStream is;
/*    */   
/*    */   public MQDecoder(InputStream is) throws IOException {
/* 35 */     this.is = is;
/*    */     
/* 37 */     this.range = 32768;
/* 38 */     this.value = 0;
/*    */     
/* 40 */     fetchByte();
/* 41 */     this.value <<= 8;
/* 42 */     fetchByte();
/* 43 */     this.value <<= this.availableBits - 1;
/*    */     
/* 45 */     this.availableBits = 1;
/*    */   }
/*    */ 
/*    */   
/*    */   public int decode(Context cm) throws IOException {
/* 50 */     int decoded, rangeLps = MQConst.pLps[cm.getState()];
/*    */ 
/*    */     
/* 53 */     if (this.value > rangeLps) {
/*    */       
/* 55 */       this.range -= rangeLps;
/* 56 */       this.value -= rangeLps;
/* 57 */       if (this.range < 32768) {
/* 58 */         while (this.range < 32768) {
/* 59 */           renormalize();
/*    */         }
/* 61 */         cm.setState(MQConst.transitMPS[cm.getState()]);
/*    */       } 
/* 63 */       decoded = cm.getMps();
/*    */     } else {
/*    */       
/* 66 */       this.range = rangeLps;
/* 67 */       while (this.range < 32768) {
/* 68 */         renormalize();
/*    */       }
/* 70 */       if (MQConst.mpsSwitch[cm.getState()] != 0)
/* 71 */         cm.setMps(1 - cm.getMps()); 
/* 72 */       cm.setState(MQConst.transitLPS[cm.getState()]);
/*    */       
/* 74 */       decoded = 1 - cm.getMps();
/*    */     } 
/*    */     
/* 77 */     return decoded;
/*    */   }
/*    */   
/*    */   private void fetchByte() throws IOException {
/* 81 */     this.availableBits = 8;
/* 82 */     if (this.decodedBytes > 0 && this.lastByte == 255) {
/* 83 */       this.availableBits = 7;
/*    */     }
/* 85 */     this.lastByte = this.is.read();
/* 86 */     int shiftCarry = 8 - this.availableBits;
/* 87 */     this.value += this.lastByte << shiftCarry;
/*    */     
/* 89 */     this.decodedBytes++;
/*    */   }
/*    */   
/*    */   private void renormalize() throws IOException {
/* 93 */     this.value <<= 1;
/* 94 */     this.range <<= 1;
/* 95 */     this.range &= 0xFFFF;
/*    */     
/* 97 */     this.availableBits--;
/* 98 */     if (this.availableBits == 0)
/* 99 */       fetchByte(); 
/*    */   }
/*    */ }


/* Location:              C:\Users\rapha\Downloads\aurora.jar!\META-INF\jars\jcodec-0.2.5.jar!\org\jcodec\codecs\common\biari\MQDecoder.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */