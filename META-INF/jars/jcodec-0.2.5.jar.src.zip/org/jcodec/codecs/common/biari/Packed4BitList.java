/*    */ package org.jcodec.codecs.common.biari;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class Packed4BitList
/*    */ {
/* 12 */   private static int[] CLEAR_MASK = new int[] { 268435440, -16, -16, -16, -16, -16, -16 };
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public static int _7(int val0, int val1, int val2, int val3, int val4, int val5, int val6) {
/* 21 */     return 0x70000000 | (val0 & 0xF) << 24 | (val1 & 0xF) << 20 | (val2 & 0xF) << 16 | (val3 & 0xF) << 12 | (val4 & 0xF) << 8 | (val5 & 0xF) << 4 | val6 & 0xF;
/*    */   }
/*    */ 
/*    */   
/*    */   public static int _3(int val0, int val1, int val2) {
/* 26 */     return _7(val0, val1, val2, 0, 0, 0, 0);
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public static int set(int list, int val, int n) {
/* 38 */     int cnt = list >> 28 & 0xF;
/* 39 */     int newc = n + 1;
/* 40 */     cnt = (newc > cnt) ? newc : cnt;
/* 41 */     return list & CLEAR_MASK[n] | (val & 0xFF) << n << 2 | cnt << 28;
/*    */   }
/*    */   
/*    */   public static int get(int list, int n) {
/* 45 */     if (n > 6)
/* 46 */       return 0; 
/* 47 */     return list >> n << 2 & 0xFF;
/*    */   }
/*    */ }


/* Location:              C:\Users\rapha\Downloads\aurora.jar!\META-INF\jars\jcodec-0.2.5.jar!\org\jcodec\codecs\common\biari\Packed4BitList.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */