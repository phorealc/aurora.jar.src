/*     */ package org.jcodec.codecs.png;
/*     */ 
/*     */ import java.io.ByteArrayOutputStream;
/*     */ import java.nio.ByteBuffer;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Iterator;
/*     */ import java.util.List;
/*     */ import java.util.zip.DataFormatException;
/*     */ import java.util.zip.Inflater;
/*     */ import org.jcodec.common.VideoCodecMeta;
/*     */ import org.jcodec.common.VideoDecoder;
/*     */ import org.jcodec.common.io.NIOUtils;
/*     */ import org.jcodec.common.logging.Logger;
/*     */ import org.jcodec.common.model.ColorSpace;
/*     */ import org.jcodec.common.model.Picture;
/*     */ import org.jcodec.common.model.Size;
/*     */ import org.jcodec.common.tools.MathUtil;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class PNGDecoder
/*     */   extends VideoDecoder
/*     */ {
/*     */   private static final int FILTER_TYPE_LOCO = 64;
/*     */   private static final int FILTER_VALUE_NONE = 0;
/*     */   private static final int FILTER_VALUE_SUB = 1;
/*     */   private static final int FILTER_VALUE_UP = 2;
/*     */   private static final int FILTER_VALUE_AVG = 3;
/*     */   private static final int FILTER_VALUE_PAETH = 4;
/*     */   private static final int PNG_COLOR_TYPE_GRAY = 0;
/*     */   private static final int PNG_COLOR_TYPE_PALETTE = 3;
/*     */   private static final int PNG_COLOR_TYPE_RGB = 2;
/*     */   private static final int alphaR = 127;
/*     */   private static final int alphaG = 127;
/*     */   private static final int alphaB = 127;
/*  57 */   private static final int[] logPassStep = new int[] { 3, 3, 2, 2, 1, 1, 0 };
/*  58 */   private static final int[] logPassRowStep = new int[] { 3, 3, 3, 2, 2, 1, 1 };
/*  59 */   private static final int[] passOff = new int[] { 0, 4, 0, 2, 0, 1, 0 };
/*  60 */   private static final int[] passRowOff = new int[] { 0, 0, 4, 0, 2, 0, 1 };
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  65 */   private byte[] ca = new byte[4];
/*     */ 
/*     */ 
/*     */   
/*     */   public Picture decodeFrame(ByteBuffer data, byte[][] buffer) {
/*  70 */     if (!ispng(data)) {
/*  71 */       throw new RuntimeException("Not a PNG file.");
/*     */     }
/*  73 */     IHDR ihdr = null;
/*  74 */     PLTE plte = null;
/*  75 */     TRNS trns = null;
/*  76 */     List<ByteBuffer> list = new ArrayList<ByteBuffer>();
/*  77 */     while (data.remaining() >= 8) {
/*  78 */       int length = data.getInt();
/*  79 */       int tag = data.getInt();
/*     */       
/*  81 */       if (data.remaining() < length) {
/*     */         break;
/*     */       }
/*  84 */       switch (tag) {
/*     */         case 1229472850:
/*  86 */           ihdr = new IHDR();
/*  87 */           ihdr.parse(data);
/*     */           continue;
/*     */         case 1347179589:
/*  90 */           plte = new PLTE();
/*  91 */           plte.parse(data, length);
/*     */           continue;
/*     */         case 1951551059:
/*  94 */           if (ihdr == null) {
/*  95 */             throw new IllegalStateException("tRNS tag before IHDR");
/*     */           }
/*  97 */           trns = new TRNS(ihdr.colorType);
/*  98 */           trns.parse(data, length);
/*     */           continue;
/*     */         case 1229209940:
/* 101 */           list.add(NIOUtils.read(data, length));
/* 102 */           NIOUtils.skip(data, 4);
/*     */           continue;
/*     */         case 1229278788:
/* 105 */           NIOUtils.skip(data, 4);
/*     */           continue;
/*     */       } 
/* 108 */       data.position(data.position() + length + 4);
/*     */     } 
/*     */     
/* 111 */     if (ihdr != null) {
/*     */       try {
/* 113 */         decodeData(ihdr, plte, trns, list, buffer);
/* 114 */       } catch (DataFormatException e) {
/* 115 */         return null;
/*     */       } 
/* 117 */       return Picture.createPicture(ihdr.width, ihdr.height, buffer, ihdr.colorSpace());
/*     */     } 
/* 119 */     throw new IllegalStateException("no IHDR tag");
/*     */   }
/*     */ 
/*     */   
/*     */   private void decodeData(IHDR ihdr, PLTE plte, TRNS trns, List<ByteBuffer> list, byte[][] buffer) throws DataFormatException {
/* 124 */     int bpp = ihdr.getBitsPerPixel() + 7 >> 3;
/* 125 */     int passes = (ihdr.interlaceType == 0) ? 1 : 7;
/* 126 */     Inflater inflater = new Inflater();
/* 127 */     Iterator<ByteBuffer> it = list.iterator();
/*     */     
/* 129 */     for (int pass = 0; pass < passes; pass++) {
/*     */       int rowSize, rowStart, rowStep, colStart, colStep;
/* 131 */       if (ihdr.interlaceType == 0) {
/* 132 */         rowSize = ihdr.rowSize() + 1;
/* 133 */         colStart = rowStart = 0;
/* 134 */         colStep = rowStep = 1;
/*     */       } else {
/* 136 */         int round = (1 << logPassStep[pass]) - 1;
/* 137 */         rowSize = (ihdr.width + round >> logPassStep[pass]) + 1;
/* 138 */         rowStart = passRowOff[pass];
/* 139 */         rowStep = 1 << logPassRowStep[pass];
/* 140 */         colStart = passOff[pass];
/* 141 */         colStep = 1 << logPassStep[pass];
/*     */       } 
/* 143 */       byte[] lastRow = new byte[rowSize - 1];
/* 144 */       byte[] uncompressed = new byte[rowSize];
/* 145 */       int bptr = 3 * (ihdr.width * rowStart + colStart); int row;
/* 146 */       for (row = rowStart; row < ihdr.height; row += rowStep) {
/* 147 */         int count = inflater.inflate(uncompressed);
/* 148 */         if (count < uncompressed.length && inflater.needsInput()) {
/* 149 */           if (!it.hasNext()) {
/* 150 */             Logger.warn(String.format("Data truncation at row %d", new Object[] { Integer.valueOf(row) }));
/*     */             break;
/*     */           } 
/* 153 */           ByteBuffer next = it.next();
/* 154 */           inflater.setInput(NIOUtils.toArray(next));
/* 155 */           int toRead = uncompressed.length - count;
/* 156 */           count = inflater.inflate(uncompressed, count, toRead);
/* 157 */           if (count != toRead) {
/* 158 */             Logger.warn(String.format("Data truncation at row %d", new Object[] { Integer.valueOf(row) }));
/*     */             
/*     */             break;
/*     */           } 
/*     */         } 
/* 163 */         int filter = uncompressed[0];
/* 164 */         switch (filter) {
/*     */           case 0:
/* 166 */             System.arraycopy(uncompressed, 1, lastRow, 0, rowSize - 1);
/*     */             break;
/*     */           case 1:
/* 169 */             filterSub(uncompressed, rowSize - 1, lastRow, bpp);
/*     */             break;
/*     */           case 2:
/* 172 */             filterUp(uncompressed, rowSize - 1, lastRow);
/*     */             break;
/*     */           case 3:
/* 175 */             filterAvg(uncompressed, rowSize - 1, lastRow, bpp);
/*     */             break;
/*     */           case 4:
/* 178 */             filterPaeth(uncompressed, rowSize - 1, lastRow, bpp);
/*     */             break;
/*     */         } 
/*     */         
/* 182 */         int bptrWas = bptr;
/* 183 */         if ((ihdr.colorType & 0x1) != 0) {
/* 184 */           for (int i = 0; i < rowSize - 1; i += bpp, bptr += 3 * colStep) {
/* 185 */             int plt = plte.palette[lastRow[i] & 0xFF];
/* 186 */             buffer[0][bptr] = (byte)((plt >> 16 & 0xFF) - 128);
/* 187 */             buffer[0][bptr + 1] = (byte)((plt >> 8 & 0xFF) - 128);
/* 188 */             buffer[0][bptr + 2] = (byte)((plt & 0xFF) - 128);
/*     */           } 
/* 190 */         } else if ((ihdr.colorType & 0x2) != 0) {
/* 191 */           for (int i = 0; i < rowSize - 1; i += bpp, bptr += 3 * colStep) {
/* 192 */             buffer[0][bptr] = (byte)((lastRow[i] & 0xFF) - 128);
/* 193 */             buffer[0][bptr + 1] = (byte)((lastRow[i + 1] & 0xFF) - 128);
/* 194 */             buffer[0][bptr + 2] = (byte)((lastRow[i + 2] & 0xFF) - 128);
/*     */           } 
/*     */         } else {
/* 197 */           for (int i = 0; i < rowSize - 1; i += bpp, bptr += 3 * colStep) {
/* 198 */             buffer[0][bptr + 2] = (byte)((lastRow[i] & 0xFF) - 128); buffer[0][bptr + 1] = (byte)((lastRow[i] & 0xFF) - 128); buffer[0][bptr] = (byte)((lastRow[i] & 0xFF) - 128);
/*     */           } 
/*     */         } 
/*     */         
/* 202 */         if ((ihdr.colorType & 0x4) != 0) {
/* 203 */           int j; for (int i = bpp - 1; i < rowSize - 1; i += bpp, j += 3 * colStep) {
/* 204 */             int alpha = lastRow[i] & 0xFF, nalpha = 256 - alpha;
/* 205 */             buffer[0][j] = (byte)(127 * nalpha + buffer[0][j] * alpha >> 8);
/* 206 */             buffer[0][j + 1] = (byte)(127 * nalpha + buffer[0][j + 1] * alpha >> 8);
/* 207 */             buffer[0][j + 2] = (byte)(127 * nalpha + buffer[0][j + 2] * alpha >> 8);
/*     */           } 
/* 209 */         } else if (trns != null) {
/* 210 */           if (ihdr.colorType == 3) {
/* 211 */             int j; for (int i = 0; i < rowSize - 1; i++, j += 3 * colStep) {
/* 212 */               int alpha = trns.alphaPal[lastRow[i] & 0xFF] & 0xFF, nalpha = 256 - alpha;
/* 213 */               buffer[0][j] = (byte)(127 * nalpha + buffer[0][j] * alpha >> 8);
/* 214 */               buffer[0][j + 1] = (byte)(127 * nalpha + buffer[0][j + 1] * alpha >> 8);
/* 215 */               buffer[0][j + 2] = (byte)(127 * nalpha + buffer[0][j + 2] * alpha >> 8);
/*     */             } 
/* 217 */           } else if (ihdr.colorType == 2) {
/* 218 */             int ar = (trns.alphaR & 0xFF) - 128;
/* 219 */             int ag = (trns.alphaG & 0xFF) - 128;
/* 220 */             int ab = (trns.alphaB & 0xFF) - 128;
/* 221 */             if (ab != 127 || ag != 127 || ar != 127) {
/* 222 */               int j; for (int i = 0; i < rowSize - 1; i += bpp, j += 3 * colStep) {
/* 223 */                 if (buffer[0][j] == ar && buffer[0][j + 1] == ag && buffer[0][j + 2] == ab) {
/* 224 */                   buffer[0][j] = Byte.MAX_VALUE;
/* 225 */                   buffer[0][j + 1] = Byte.MAX_VALUE;
/* 226 */                   buffer[0][j + 2] = Byte.MAX_VALUE;
/*     */                 } 
/*     */               } 
/*     */             } 
/* 230 */           } else if (ihdr.colorType == 0) {
/* 231 */             int j; for (int i = 0; i < rowSize - 1; i++, j += 3 * colStep) {
/* 232 */               if (lastRow[i] == trns.alphaGrey) {
/* 233 */                 buffer[0][j] = Byte.MAX_VALUE;
/* 234 */                 buffer[0][j + 1] = Byte.MAX_VALUE;
/* 235 */                 buffer[0][j + 2] = Byte.MAX_VALUE;
/*     */               } 
/*     */             } 
/*     */           } 
/*     */         } 
/* 240 */         bptr = bptrWas + 3 * ihdr.width * rowStep;
/*     */       } 
/*     */     } 
/*     */   }
/*     */   private void filterPaeth(byte[] uncompressed, int rowSize, byte[] lastRow, int bpp) {
/*     */     int i;
/* 246 */     for (i = 0; i < bpp; i++) {
/* 247 */       this.ca[i] = lastRow[i];
/* 248 */       lastRow[i] = (byte)((uncompressed[i + 1] & 0xFF) + (lastRow[i] & 0xFF));
/*     */     } 
/* 250 */     for (i = bpp; i < rowSize; i++) {
/* 251 */       int a = lastRow[i - bpp] & 0xFF;
/* 252 */       int b = lastRow[i] & 0xFF;
/* 253 */       int c = this.ca[i % bpp] & 0xFF;
/* 254 */       int p = b - c;
/* 255 */       int pc = a - c;
/*     */       
/* 257 */       int pa = MathUtil.abs(p);
/* 258 */       int pb = MathUtil.abs(pc);
/* 259 */       pc = MathUtil.abs(p + pc);
/*     */       
/* 261 */       if (pa <= pb && pa <= pc) {
/* 262 */         p = a;
/* 263 */       } else if (pb <= pc) {
/* 264 */         p = b;
/*     */       } else {
/* 266 */         p = c;
/* 267 */       }  this.ca[i % bpp] = lastRow[i];
/* 268 */       lastRow[i] = (byte)(p + (uncompressed[i + 1] & 0xFF));
/*     */     } 
/*     */   }
/*     */   
/*     */   private static void filterSub(byte[] uncompressed, int rowSize, byte[] lastRow, int bpp) {
/* 273 */     switch (bpp) {
/*     */       case 1:
/* 275 */         filterSub1(uncompressed, lastRow, rowSize);
/*     */         return;
/*     */       case 2:
/* 278 */         filterSub2(uncompressed, lastRow, rowSize);
/*     */         return;
/*     */       case 3:
/* 281 */         filterSub3(uncompressed, lastRow, rowSize);
/*     */         return;
/*     */     } 
/* 284 */     filterSub4(uncompressed, lastRow, rowSize);
/*     */   }
/*     */ 
/*     */   
/*     */   private static void filterAvg(byte[] uncompressed, int rowSize, byte[] lastRow, int bpp) {
/* 289 */     switch (bpp) {
/*     */       case 1:
/* 291 */         filterAvg1(uncompressed, lastRow, rowSize);
/*     */         return;
/*     */       case 2:
/* 294 */         filterAvg2(uncompressed, lastRow, rowSize);
/*     */         return;
/*     */       case 3:
/* 297 */         filterAvg3(uncompressed, lastRow, rowSize);
/*     */         return;
/*     */     } 
/* 300 */     filterAvg4(uncompressed, lastRow, rowSize);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private static void filterSub1(byte[] uncompressed, byte[] lastRow, int rowSize) {
/* 306 */     byte p = lastRow[0] = uncompressed[1];
/* 307 */     for (int i = 1; i < rowSize; i++) {
/* 308 */       p = lastRow[i] = (byte)((p & 0xFF) + (uncompressed[i + 1] & 0xFF));
/*     */     }
/*     */   }
/*     */   
/*     */   private static void filterUp(byte[] uncompressed, int rowSize, byte[] lastRow) {
/* 313 */     for (int i = 0; i < rowSize; i++) {
/* 314 */       lastRow[i] = (byte)((lastRow[i] & 0xFF) + (uncompressed[i + 1] & 0xFF));
/*     */     }
/*     */   }
/*     */   
/*     */   private static void filterAvg1(byte[] uncompressed, byte[] lastRow, int rowSize) {
/* 319 */     byte p = lastRow[0] = (byte)((uncompressed[1] & 0xFF) + ((lastRow[0] & 0xFF) >> 1));
/* 320 */     for (int i = 1; i < rowSize; i++) {
/* 321 */       p = lastRow[i] = (byte)(((lastRow[i] & 0xFF) + (p & 0xFF) >> 1) + (uncompressed[i + 1] & 0xFF));
/*     */     }
/*     */   }
/*     */   
/*     */   private static void filterSub2(byte[] uncompressed, byte[] lastRow, int rowSize) {
/* 326 */     byte p0 = lastRow[0] = uncompressed[1];
/* 327 */     byte p1 = lastRow[1] = uncompressed[2];
/* 328 */     for (int i = 2; i < rowSize; i += 2) {
/* 329 */       p0 = lastRow[i] = (byte)((p0 & 0xFF) + (uncompressed[1 + i] & 0xFF));
/* 330 */       p1 = lastRow[i + 1] = (byte)((p1 & 0xFF) + (uncompressed[2 + i] & 0xFF));
/*     */     } 
/*     */   }
/*     */   
/*     */   private static void filterAvg2(byte[] uncompressed, byte[] lastRow, int rowSize) {
/* 335 */     byte p0 = lastRow[0] = (byte)((uncompressed[1] & 0xFF) + ((lastRow[0] & 0xFF) >> 1));
/* 336 */     byte p1 = lastRow[1] = (byte)((uncompressed[2] & 0xFF) + ((lastRow[1] & 0xFF) >> 1));
/* 337 */     for (int i = 2; i < rowSize; i += 2) {
/* 338 */       p0 = lastRow[i] = (byte)(((lastRow[i] & 0xFF) + (p0 & 0xFF) >> 1) + (uncompressed[1 + i] & 0xFF));
/* 339 */       p1 = lastRow[i + 1] = (byte)(((lastRow[i + 1] & 0xFF) + (p1 & 0xFF) >> 1) + (uncompressed[i + 2] & 0xFF));
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   private static void filterSub3(byte[] uncompressed, byte[] lastRow, int rowSize) {
/* 345 */     byte p0 = lastRow[0] = uncompressed[1];
/* 346 */     byte p1 = lastRow[1] = uncompressed[2];
/* 347 */     byte p2 = lastRow[2] = uncompressed[3];
/* 348 */     for (int i = 3; i < rowSize; i += 3) {
/* 349 */       p0 = lastRow[i] = (byte)((p0 & 0xFF) + (uncompressed[i + 1] & 0xFF));
/* 350 */       p1 = lastRow[i + 1] = (byte)((p1 & 0xFF) + (uncompressed[i + 2] & 0xFF));
/* 351 */       p2 = lastRow[i + 2] = (byte)((p2 & 0xFF) + (uncompressed[i + 3] & 0xFF));
/*     */     } 
/*     */   }
/*     */   
/*     */   private static void filterAvg3(byte[] uncompressed, byte[] lastRow, int rowSize) {
/* 356 */     byte p0 = lastRow[0] = (byte)((uncompressed[1] & 0xFF) + ((lastRow[0] & 0xFF) >> 1));
/* 357 */     byte p1 = lastRow[1] = (byte)((uncompressed[2] & 0xFF) + ((lastRow[1] & 0xFF) >> 1));
/* 358 */     byte p2 = lastRow[2] = (byte)((uncompressed[3] & 0xFF) + ((lastRow[2] & 0xFF) >> 1));
/* 359 */     for (int i = 3; i < rowSize; i += 3) {
/* 360 */       p0 = lastRow[i] = (byte)(((lastRow[i] & 0xFF) + (p0 & 0xFF) >> 1) + (uncompressed[i + 1] & 0xFF));
/* 361 */       p1 = lastRow[i + 1] = (byte)(((lastRow[i + 1] & 0xFF) + (p1 & 0xFF) >> 1) + (uncompressed[i + 2] & 0xFF));
/*     */       
/* 363 */       p2 = lastRow[i + 2] = (byte)(((lastRow[i + 2] & 0xFF) + (p2 & 0xFF) >> 1) + (uncompressed[i + 3] & 0xFF));
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   private static void filterSub4(byte[] uncompressed, byte[] lastRow, int rowSize) {
/* 369 */     byte p0 = lastRow[0] = uncompressed[1];
/* 370 */     byte p1 = lastRow[1] = uncompressed[2];
/* 371 */     byte p2 = lastRow[2] = uncompressed[3];
/* 372 */     byte p3 = lastRow[3] = uncompressed[4];
/* 373 */     for (int i = 4; i < rowSize; i += 4) {
/* 374 */       p0 = lastRow[i] = (byte)((p0 & 0xFF) + (uncompressed[i + 1] & 0xFF));
/* 375 */       p1 = lastRow[i + 1] = (byte)((p1 & 0xFF) + (uncompressed[i + 2] & 0xFF));
/* 376 */       p2 = lastRow[i + 2] = (byte)((p2 & 0xFF) + (uncompressed[i + 3] & 0xFF));
/* 377 */       p3 = lastRow[i + 3] = (byte)((p3 & 0xFF) + (uncompressed[i + 4] & 0xFF));
/*     */     } 
/*     */   }
/*     */   
/*     */   private static void filterAvg4(byte[] uncompressed, byte[] lastRow, int rowSize) {
/* 382 */     byte p0 = lastRow[0] = (byte)((uncompressed[1] & 0xFF) + ((lastRow[0] & 0xFF) >> 1));
/* 383 */     byte p1 = lastRow[1] = (byte)((uncompressed[2] & 0xFF) + ((lastRow[1] & 0xFF) >> 1));
/* 384 */     byte p2 = lastRow[2] = (byte)((uncompressed[3] & 0xFF) + ((lastRow[2] & 0xFF) >> 1));
/* 385 */     byte p3 = lastRow[3] = (byte)((uncompressed[4] & 0xFF) + ((lastRow[3] & 0xFF) >> 1));
/* 386 */     for (int i = 4; i < rowSize; i += 4) {
/* 387 */       p0 = lastRow[i] = (byte)(((lastRow[i] & 0xFF) + (p0 & 0xFF) >> 1) + (uncompressed[i + 1] & 0xFF));
/* 388 */       p1 = lastRow[i + 1] = (byte)(((lastRow[i + 1] & 0xFF) + (p1 & 0xFF) >> 1) + (uncompressed[i + 2] & 0xFF));
/*     */       
/* 390 */       p2 = lastRow[i + 2] = (byte)(((lastRow[i + 2] & 0xFF) + (p2 & 0xFF) >> 1) + (uncompressed[i + 3] & 0xFF));
/*     */       
/* 392 */       p3 = lastRow[i + 3] = (byte)(((lastRow[i + 3] & 0xFF) + (p3 & 0xFF) >> 1) + (uncompressed[i + 4] & 0xFF));
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   private static class PLTE
/*     */   {
/*     */     int[] palette;
/*     */ 
/*     */     
/*     */     private PLTE() {}
/*     */     
/*     */     public void parse(ByteBuffer data, int length) {
/* 405 */       if (length % 3 != 0 || length > 768)
/* 406 */         throw new RuntimeException("Invalid data"); 
/* 407 */       int n = length / 3;
/* 408 */       this.palette = new int[n];
/*     */       int i;
/* 410 */       for (i = 0; i < n; i++) {
/* 411 */         this.palette[i] = 0xFF000000 | (data.get() & 0xFF) << 16 | (data.get() & 0xFF) << 8 | data
/* 412 */           .get() & 0xFF;
/*     */       }
/* 414 */       for (; i < 256; i++)
/* 415 */         this.palette[i] = -16777216; 
/* 416 */       data.getInt();
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   public static class TRNS
/*     */   {
/*     */     private int colorType;
/*     */     
/*     */     byte[] alphaPal;
/*     */     byte alphaGrey;
/*     */     byte alphaR;
/*     */     byte alphaG;
/*     */     byte alphaB;
/*     */     
/*     */     TRNS(byte colorType) {
/* 432 */       this.colorType = colorType;
/*     */     }
/*     */     
/*     */     public void parse(ByteBuffer data, int length) {
/* 436 */       if (this.colorType == 3) {
/* 437 */         this.alphaPal = new byte[256];
/* 438 */         data.get(this.alphaPal, 0, length);
/* 439 */         for (int i = length; i < 256; i++) {
/* 440 */           this.alphaPal[i] = -1;
/*     */         }
/* 442 */       } else if (this.colorType == 0) {
/* 443 */         this.alphaGrey = data.get();
/* 444 */       } else if (this.colorType == 2) {
/* 445 */         this.alphaR = data.get();
/* 446 */         this.alphaG = data.get();
/* 447 */         this.alphaG = data.get();
/*     */       } 
/* 449 */       data.getInt();
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   public VideoCodecMeta getCodecMeta(ByteBuffer _data) {
/* 455 */     ByteBuffer data = _data.duplicate();
/* 456 */     if (!ispng(data)) {
/* 457 */       throw new RuntimeException("Not a PNG file.");
/*     */     }
/* 459 */     while (data.remaining() >= 8) {
/* 460 */       IHDR ihdr; int length = data.getInt();
/* 461 */       int tag = data.getInt();
/*     */       
/* 463 */       if (data.remaining() < length) {
/*     */         break;
/*     */       }
/* 466 */       switch (tag) {
/*     */         case 1229472850:
/* 468 */           ihdr = new IHDR();
/* 469 */           ihdr.parse(data);
/* 470 */           return VideoCodecMeta.createSimpleVideoCodecMeta(new Size(ihdr.width, ihdr.height), ColorSpace.RGB);
/*     */       } 
/* 472 */       data.position(data.position() + length + 4);
/*     */     } 
/*     */     
/* 475 */     return null;
/*     */   }
/*     */   
/*     */   private static boolean ispng(ByteBuffer data) {
/* 479 */     int sighi = data.getInt();
/* 480 */     int siglo = data.getInt();
/* 481 */     boolean ispng = ((sighi == -1991225785 || sighi == -1974645177) && (siglo == 218765834 || siglo == 218765834));
/* 482 */     return ispng;
/*     */   }
/*     */   
/*     */   public static int probe(ByteBuffer data) {
/* 486 */     if (!ispng(data))
/* 487 */       return 100; 
/* 488 */     return 0;
/*     */   }
/*     */   
/*     */   public static byte[] deflate(byte[] data, Inflater inflater) throws DataFormatException {
/* 492 */     inflater.setInput(data);
/* 493 */     ByteArrayOutputStream baos = new ByteArrayOutputStream(data.length);
/* 494 */     byte[] buffer = new byte[16384];
/* 495 */     while (!inflater.needsInput()) {
/* 496 */       int count = inflater.inflate(buffer);
/* 497 */       baos.write(buffer, 0, count);
/* 498 */       System.out.println(baos.size());
/*     */     } 
/* 500 */     return baos.toByteArray();
/*     */   }
/*     */ }


/* Location:              C:\Users\rapha\Downloads\aurora.jar!\META-INF\jars\jcodec-0.2.5.jar!\org\jcodec\codecs\png\PNGDecoder.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */