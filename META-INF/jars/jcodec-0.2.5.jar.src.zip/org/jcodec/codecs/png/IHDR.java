/*    */ package org.jcodec.codecs.png;
/*    */ 
/*    */ import java.nio.ByteBuffer;
/*    */ import org.jcodec.common.model.ColorSpace;
/*    */ 
/*    */ class IHDR
/*    */ {
/*    */   static final int PNG_COLOR_MASK_ALPHA = 4;
/*    */   static final int PNG_COLOR_MASK_COLOR = 2;
/*    */   static final int PNG_COLOR_MASK_PALETTE = 1;
/*    */   int width;
/*    */   int height;
/*    */   byte bitDepth;
/*    */   byte colorType;
/*    */   private byte compressionType;
/*    */   private byte filterType;
/*    */   byte interlaceType;
/*    */   
/*    */   void write(ByteBuffer data) {
/* 20 */     data.putInt(this.width);
/* 21 */     data.putInt(this.height);
/* 22 */     data.put(this.bitDepth);
/* 23 */     data.put(this.colorType);
/* 24 */     data.put(this.compressionType);
/* 25 */     data.put(this.filterType);
/* 26 */     data.put(this.interlaceType);
/*    */   }
/*    */   
/*    */   void parse(ByteBuffer data) {
/* 30 */     this.width = data.getInt();
/* 31 */     this.height = data.getInt();
/* 32 */     this.bitDepth = data.get();
/* 33 */     this.colorType = data.get();
/* 34 */     this.compressionType = data.get();
/* 35 */     this.filterType = data.get();
/* 36 */     this.interlaceType = data.get();
/* 37 */     data.getInt();
/*    */   }
/*    */   
/*    */   int rowSize() {
/* 41 */     return this.width * getBitsPerPixel() + 7 >> 3;
/*    */   }
/*    */ 
/*    */   
/*    */   private int getNBChannels() {
/* 46 */     int channels = 1;
/* 47 */     if ((this.colorType & 0x3) == 2)
/* 48 */       channels = 3; 
/* 49 */     if ((this.colorType & 0x4) != 0)
/* 50 */       channels++; 
/* 51 */     return channels;
/*    */   }
/*    */   
/*    */   int getBitsPerPixel() {
/* 55 */     return this.bitDepth * getNBChannels();
/*    */   }
/*    */   
/*    */   ColorSpace colorSpace() {
/* 59 */     return ColorSpace.RGB;
/*    */   }
/*    */ }


/* Location:              C:\Users\rapha\Downloads\aurora.jar!\META-INF\jars\jcodec-0.2.5.jar!\org\jcodec\codecs\png\IHDR.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */