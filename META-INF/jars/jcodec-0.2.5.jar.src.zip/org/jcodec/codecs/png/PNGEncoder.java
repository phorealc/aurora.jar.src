/*     */ package org.jcodec.codecs.png;
/*     */ 
/*     */ import java.nio.ByteBuffer;
/*     */ import java.util.zip.CRC32;
/*     */ import java.util.zip.Deflater;
/*     */ import org.jcodec.common.VideoEncoder;
/*     */ import org.jcodec.common.io.NIOUtils;
/*     */ import org.jcodec.common.model.ColorSpace;
/*     */ import org.jcodec.common.model.Picture;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class PNGEncoder
/*     */   extends VideoEncoder
/*     */ {
/*     */   private static int crc32(ByteBuffer from, ByteBuffer to) {
/*  28 */     from.limit(to.position());
/*     */     
/*  30 */     CRC32 crc32 = new CRC32();
/*  31 */     crc32.update(NIOUtils.toArray(from));
/*  32 */     return (int)crc32.getValue();
/*     */   }
/*     */ 
/*     */   
/*     */   public VideoEncoder.EncodedFrame encodeFrame(Picture pic, ByteBuffer out) {
/*  37 */     ByteBuffer _out = out.duplicate();
/*  38 */     _out.putInt(-1991225785);
/*  39 */     _out.putInt(218765834);
/*  40 */     IHDR ihdr = new IHDR();
/*  41 */     ihdr.width = pic.getCroppedWidth();
/*  42 */     ihdr.height = pic.getCroppedHeight();
/*  43 */     ihdr.bitDepth = 8;
/*  44 */     ihdr.colorType = 2;
/*  45 */     _out.putInt(13);
/*     */     
/*  47 */     ByteBuffer crcFrom = _out.duplicate();
/*  48 */     _out.putInt(1229472850);
/*  49 */     ihdr.write(_out);
/*  50 */     _out.putInt(crc32(crcFrom, _out));
/*     */     
/*  52 */     Deflater deflater = new Deflater();
/*  53 */     byte[] rowData = new byte[pic.getCroppedWidth() * 3 + 1];
/*  54 */     byte[] pix = pic.getPlaneData(0);
/*  55 */     byte[] buffer = new byte[32768];
/*  56 */     int ptr = 0, len = buffer.length;
/*     */ 
/*     */     
/*  59 */     int lineStep = (pic.getWidth() - pic.getCroppedWidth()) * 3;
/*  60 */     for (int row = 0, bptr = 0; row < pic.getCroppedHeight() + 1; row++) {
/*     */       int count;
/*  62 */       while ((count = deflater.deflate(buffer, ptr, len)) > 0) {
/*  63 */         ptr += count;
/*  64 */         len -= count;
/*     */         
/*  66 */         if (len == 0) {
/*  67 */           _out.putInt(ptr);
/*  68 */           crcFrom = _out.duplicate();
/*  69 */           _out.putInt(1229209940);
/*  70 */           _out.put(buffer, 0, ptr);
/*  71 */           _out.putInt(crc32(crcFrom, _out));
/*  72 */           ptr = 0;
/*  73 */           len = buffer.length;
/*     */         } 
/*     */       } 
/*     */       
/*  77 */       if (row >= pic.getCroppedHeight()) {
/*     */         break;
/*     */       }
/*  80 */       rowData[0] = 0;
/*  81 */       for (int i = 1; i <= pic.getCroppedWidth() * 3; i += 3, bptr += 3) {
/*  82 */         rowData[i] = (byte)(pix[bptr] + 128);
/*  83 */         rowData[i + 1] = (byte)(pix[bptr + 1] + 128);
/*  84 */         rowData[i + 2] = (byte)(pix[bptr + 2] + 128);
/*     */       } 
/*  86 */       bptr += lineStep;
/*  87 */       deflater.setInput(rowData);
/*  88 */       if (row >= pic.getCroppedHeight() - 1)
/*  89 */         deflater.finish(); 
/*     */     } 
/*  91 */     if (ptr > 0) {
/*  92 */       _out.putInt(ptr);
/*  93 */       crcFrom = _out.duplicate();
/*  94 */       _out.putInt(1229209940);
/*  95 */       _out.put(buffer, 0, ptr);
/*  96 */       _out.putInt(crc32(crcFrom, _out));
/*     */     } 
/*  98 */     _out.putInt(0);
/*  99 */     _out.putInt(1229278788);
/* 100 */     _out.putInt(-1371381630);
/* 101 */     _out.flip();
/*     */     
/* 103 */     return new VideoEncoder.EncodedFrame(_out, true);
/*     */   }
/*     */ 
/*     */   
/*     */   public ColorSpace[] getSupportedColorSpaces() {
/* 108 */     return new ColorSpace[] { ColorSpace.RGB };
/*     */   }
/*     */ 
/*     */   
/*     */   public int estimateBufferSize(Picture frame) {
/* 113 */     return frame.getCroppedWidth() * frame.getCroppedHeight() * 4;
/*     */   }
/*     */ }


/* Location:              C:\Users\rapha\Downloads\aurora.jar!\META-INF\jars\jcodec-0.2.5.jar!\org\jcodec\codecs\png\PNGEncoder.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */