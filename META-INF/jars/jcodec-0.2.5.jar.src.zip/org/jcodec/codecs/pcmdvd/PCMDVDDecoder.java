/*     */ package org.jcodec.codecs.pcmdvd;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.nio.ByteBuffer;
/*     */ import java.nio.ByteOrder;
/*     */ import org.jcodec.common.AudioCodecMeta;
/*     */ import org.jcodec.common.AudioDecoder;
/*     */ import org.jcodec.common.AudioFormat;
/*     */ import org.jcodec.common.io.NIOUtils;
/*     */ import org.jcodec.common.model.AudioBuffer;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class PCMDVDDecoder
/*     */   implements AudioDecoder
/*     */ {
/*  22 */   private static final int[] lpcm_freq_tab = new int[] { 48000, 96000, 44100, 32000 };
/*     */ 
/*     */   
/*     */   public AudioBuffer decodeFrame(ByteBuffer _frame, ByteBuffer _dst) throws IOException {
/*  26 */     ByteBuffer dst = _dst.duplicate();
/*  27 */     ByteBuffer frame = _frame.duplicate();
/*     */     
/*  29 */     frame.order(ByteOrder.BIG_ENDIAN);
/*  30 */     dst.order(ByteOrder.LITTLE_ENDIAN);
/*     */     
/*  32 */     int dvdaudioSubstreamType = frame.get() & 0xFF;
/*  33 */     NIOUtils.skip(frame, 3);
/*     */     
/*  35 */     if ((dvdaudioSubstreamType & 0xE0) == 160) {
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/*  46 */       int n, b0 = frame.get() & 0xFF;
/*     */       
/*  48 */       int b1 = frame.get() & 0xFF;
/*     */       
/*  50 */       int b2 = frame.get() & 0xFF;
/*  51 */       int freq = b1 >> 4 & 0x3;
/*  52 */       int sampleRate = lpcm_freq_tab[freq];
/*  53 */       int channelCount = 1 + (b1 & 0x7);
/*  54 */       int sampleSizeInBits = 16 + (b1 >> 6 & 0x3) * 4;
/*  55 */       int nFrames = frame.remaining() / channelCount * (sampleSizeInBits >> 3);
/*     */       
/*  57 */       switch (sampleSizeInBits) {
/*     */         case 20:
/*  59 */           for (n = 0; n < nFrames >> 1; n++) {
/*  60 */             for (int c = 0; c < channelCount; c++) {
/*  61 */               short s0 = frame.getShort();
/*  62 */               dst.putShort(s0);
/*  63 */               short s1 = frame.getShort();
/*  64 */               dst.putShort(s1);
/*     */             } 
/*  66 */             NIOUtils.skip(frame, channelCount);
/*     */           } 
/*     */           break;
/*     */         case 24:
/*  70 */           for (n = 0; n < nFrames >> 1; n++) {
/*  71 */             for (int c = 0; c < channelCount; c++) {
/*  72 */               short s0 = frame.getShort();
/*  73 */               dst.putShort(s0);
/*  74 */               short s1 = frame.getShort();
/*  75 */               dst.putShort(s1);
/*     */             } 
/*  77 */             NIOUtils.skip(frame, channelCount << 1);
/*     */           } 
/*     */           break;
/*     */       } 
/*  81 */       dst.flip();
/*     */       
/*  83 */       return new AudioBuffer(dst, new AudioFormat(sampleRate, sampleSizeInBits, channelCount, true, false), nFrames);
/*     */     }  if ((dvdaudioSubstreamType & 0xE0) == 128) {
/*     */       if ((dvdaudioSubstreamType & 0xF8) == 136)
/*     */         throw new RuntimeException("CODEC_ID_DTS");  throw new RuntimeException("CODEC_ID_AC3");
/*     */     } 
/*  88 */     throw new RuntimeException("MPEG DVD unknown coded"); } public AudioCodecMeta getCodecMeta(ByteBuffer _frame) throws IOException { ByteBuffer frame = _frame.duplicate();
/*     */     
/*  90 */     frame.order(ByteOrder.BIG_ENDIAN);
/*     */     
/*  92 */     int dvdaudioSubstreamType = frame.get() & 0xFF;
/*  93 */     NIOUtils.skip(frame, 3);
/*     */     
/*  95 */     if ((dvdaudioSubstreamType & 0xE0) == 160) {
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 106 */       int b0 = frame.get() & 0xFF;
/*     */       
/* 108 */       int b1 = frame.get() & 0xFF;
/*     */       
/* 110 */       int b2 = frame.get() & 0xFF;
/* 111 */       int freq = b1 >> 4 & 0x3;
/* 112 */       int sampleRate = lpcm_freq_tab[freq];
/* 113 */       int channelCount = 1 + (b1 & 0x7);
/* 114 */       int sampleSizeInBits = 16 + (b1 >> 6 & 0x3) * 4;
/* 115 */       return AudioCodecMeta.fromAudioFormat(new AudioFormat(sampleRate, sampleSizeInBits, channelCount, true, false));
/*     */     } 
/*     */     if ((dvdaudioSubstreamType & 0xE0) == 128) {
/*     */       if ((dvdaudioSubstreamType & 0xF8) == 136)
/*     */         throw new RuntimeException("CODEC_ID_DTS"); 
/*     */       throw new RuntimeException("CODEC_ID_AC3");
/*     */     } 
/*     */     throw new RuntimeException("MPEG DVD unknown coded"); }
/*     */ 
/*     */ }


/* Location:              C:\Users\rapha\Downloads\aurora.jar!\META-INF\jars\jcodec-0.2.5.jar!\org\jcodec\codecs\pcmdvd\PCMDVDDecoder.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */