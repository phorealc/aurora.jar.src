/*    */ package org.jcodec.codecs.raw;
/*    */ 
/*    */ import java.nio.ByteBuffer;
/*    */ import java.nio.ByteOrder;
/*    */ import java.nio.IntBuffer;
/*    */ import org.jcodec.common.model.ColorSpace;
/*    */ import org.jcodec.common.model.Picture;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class V210Decoder
/*    */ {
/*    */   private int width;
/*    */   private int height;
/*    */   
/*    */   public V210Decoder(int width, int height) {
/* 30 */     this.width = width;
/* 31 */     this.height = height;
/*    */   }
/*    */   
/*    */   public Picture decode(byte[] data) {
/* 35 */     ByteBuffer littleEndian = ByteBuffer.wrap(data).order(ByteOrder.LITTLE_ENDIAN);
/* 36 */     IntBuffer dat = littleEndian.asIntBuffer();
/* 37 */     ByteBuffer y = ByteBuffer.wrap(new byte[this.width * this.height]);
/* 38 */     ByteBuffer cb = ByteBuffer.wrap(new byte[this.width * this.height / 2]);
/* 39 */     ByteBuffer cr = ByteBuffer.wrap(new byte[this.width * this.height / 2]);
/*    */     
/* 41 */     while (dat.hasRemaining()) {
/* 42 */       int i = dat.get();
/* 43 */       cr.put(to8Bit(i >> 20));
/* 44 */       y.put(to8Bit(i >> 10 & 0x3FF));
/* 45 */       cb.put(to8Bit(i & 0x3FF));
/*    */       
/* 47 */       i = dat.get();
/* 48 */       y.put(to8Bit(i & 0x3FF));
/* 49 */       y.put(to8Bit(i >> 20));
/* 50 */       cb.put(to8Bit(i >> 10 & 0x3FF));
/*    */       
/* 52 */       i = dat.get();
/* 53 */       cb.put(to8Bit(i >> 20));
/* 54 */       y.put(to8Bit(i >> 10 & 0x3FF));
/* 55 */       cr.put(to8Bit(i & 0x3FF));
/*    */       
/* 57 */       i = dat.get();
/* 58 */       y.put(to8Bit(i & 0x3FF));
/* 59 */       y.put(to8Bit(i >> 20));
/* 60 */       cr.put(to8Bit(i >> 10 & 0x3FF));
/*    */     } 
/*    */     
/* 63 */     return Picture.createPicture(this.width, this.height, new byte[][] { y.array(), cb.array(), cr.array() }, ColorSpace.YUV422);
/*    */   }
/*    */   
/*    */   private byte to8Bit(int i) {
/* 67 */     return (byte)((i + 2 >> 2) - 128);
/*    */   }
/*    */ }


/* Location:              C:\Users\rapha\Downloads\aurora.jar!\META-INF\jars\jcodec-0.2.5.jar!\org\jcodec\codecs\raw\V210Decoder.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */