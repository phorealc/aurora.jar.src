/*    */ package org.jcodec.codecs.raw;
/*    */ 
/*    */ import java.io.IOException;
/*    */ import java.nio.ByteBuffer;
/*    */ import java.nio.ByteOrder;
/*    */ import org.jcodec.common.model.Picture;
/*    */ import org.jcodec.common.tools.MathUtil;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class V210Encoder
/*    */ {
/*    */   public ByteBuffer encodeFrame(ByteBuffer _out, Picture frame) throws IOException {
/* 26 */     ByteBuffer out = _out.duplicate();
/* 27 */     out.order(ByteOrder.LITTLE_ENDIAN);
/* 28 */     int tgtStride = (frame.getPlaneWidth(0) + 47) / 48 * 48;
/* 29 */     byte[][] data = frame.getData();
/*    */     
/* 31 */     byte[] tmpY = new byte[tgtStride];
/* 32 */     byte[] tmpCb = new byte[tgtStride >> 1];
/* 33 */     byte[] tmpCr = new byte[tgtStride >> 1];
/*    */     
/* 35 */     int yOff = 0, cbOff = 0, crOff = 0;
/* 36 */     for (int yy = 0; yy < frame.getHeight(); yy++) {
/* 37 */       System.arraycopy(data[0], yOff, tmpY, 0, frame.getPlaneWidth(0));
/* 38 */       System.arraycopy(data[1], cbOff, tmpCb, 0, frame.getPlaneWidth(1));
/* 39 */       System.arraycopy(data[2], crOff, tmpCr, 0, frame.getPlaneWidth(2));
/*    */       
/* 41 */       for (int yi = 0, cbi = 0, cri = 0; yi < tgtStride; ) {
/* 42 */         int i = 0;
/* 43 */         i |= clip(tmpCr[cri++]) << 20;
/* 44 */         i |= clip(tmpY[yi++]) << 10;
/* 45 */         i |= clip(tmpCb[cbi++]);
/* 46 */         out.putInt(i);
/*    */         
/* 48 */         i = 0;
/* 49 */         i |= clip(tmpY[yi++]);
/* 50 */         i |= clip(tmpY[yi++]) << 20;
/* 51 */         i |= clip(tmpCb[cbi++]) << 10;
/* 52 */         out.putInt(i);
/*    */         
/* 54 */         i = 0;
/* 55 */         i |= clip(tmpCb[cbi++]) << 20;
/* 56 */         i |= clip(tmpY[yi++]) << 10;
/* 57 */         i |= clip(tmpCr[cri++]);
/* 58 */         out.putInt(i);
/*    */         
/* 60 */         i = 0;
/* 61 */         i |= clip(tmpY[yi++]);
/* 62 */         i |= clip(tmpY[yi++]) << 20;
/* 63 */         i |= clip(tmpCr[cri++]) << 10;
/* 64 */         out.putInt(i);
/*    */       } 
/* 66 */       yOff += frame.getPlaneWidth(0);
/* 67 */       cbOff += frame.getPlaneWidth(1);
/* 68 */       crOff += frame.getPlaneWidth(2);
/*    */     } 
/* 70 */     out.flip();
/*    */     
/* 72 */     return out;
/*    */   }
/*    */   
/*    */   static final int clip(byte val) {
/* 76 */     return MathUtil.clip(val + 128 << 2, 8, 1019);
/*    */   }
/*    */ }


/* Location:              C:\Users\rapha\Downloads\aurora.jar!\META-INF\jars\jcodec-0.2.5.jar!\org\jcodec\codecs\raw\V210Encoder.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */