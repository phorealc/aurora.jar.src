/*    */ package org.jcodec.codecs.raw;
/*    */ 
/*    */ import java.nio.ByteBuffer;
/*    */ import org.jcodec.common.VideoEncoder;
/*    */ import org.jcodec.common.model.ColorSpace;
/*    */ import org.jcodec.common.model.Picture;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class RAWVideoEncoder
/*    */   extends VideoEncoder
/*    */ {
/*    */   public VideoEncoder.EncodedFrame encodeFrame(Picture pic, ByteBuffer _out) {
/* 22 */     ByteBuffer dup = _out.duplicate();
/*    */     
/* 24 */     ColorSpace color = pic.getColor();
/* 25 */     if (color.planar) {
/* 26 */       for (int plane = 0; plane < color.nComp; plane++) {
/* 27 */         int width = pic.getWidth() >> color.compWidth[plane];
/* 28 */         int startX = pic.getStartX();
/* 29 */         int startY = pic.getStartY();
/* 30 */         int cropW = pic.getCroppedWidth() >> color.compWidth[plane];
/* 31 */         int cropH = pic.getCroppedHeight() >> color.compHeight[plane];
/* 32 */         byte[] planeData = pic.getPlaneData(plane);
/*    */         
/* 34 */         int pos = width * startY + startX;
/* 35 */         for (int y = 0; y < cropH; y++) {
/* 36 */           for (int x = 0; x < cropW; x++) {
/* 37 */             dup.put((byte)(planeData[pos + x] + 128));
/*    */           }
/* 39 */           pos += width;
/*    */         } 
/*    */       } 
/*    */     } else {
/* 43 */       int bytesPerPixel = color.bitsPerPixel + 7 >> 3;
/* 44 */       int stride = pic.getWidth() * bytesPerPixel;
/* 45 */       int startX = pic.getStartX();
/* 46 */       int startY = pic.getStartY();
/* 47 */       int cropW = pic.getCroppedWidth();
/* 48 */       int cropH = pic.getCroppedHeight();
/* 49 */       byte[] planeData = pic.getPlaneData(0);
/*    */       
/* 51 */       int pos = stride * startY + startX * bytesPerPixel;
/* 52 */       for (int y = 0; y < cropH; y++) {
/* 53 */         int off; for (int x = 0; x < cropW; x++, off += bytesPerPixel) {
/* 54 */           for (int b = 0; b < bytesPerPixel; b++)
/* 55 */             dup.put((byte)(planeData[pos + off + b] + 128)); 
/*    */         } 
/* 57 */         pos += stride;
/*    */       } 
/*    */     } 
/* 60 */     dup.flip();
/* 61 */     return new VideoEncoder.EncodedFrame(dup, true);
/*    */   }
/*    */ 
/*    */   
/*    */   public ColorSpace[] getSupportedColorSpaces() {
/* 66 */     return null;
/*    */   }
/*    */ 
/*    */   
/*    */   public int estimateBufferSize(Picture frame) {
/* 71 */     int fullPlaneSize = frame.getWidth() * frame.getCroppedHeight();
/* 72 */     ColorSpace color = frame.getColor();
/* 73 */     int totalSize = 0;
/* 74 */     for (int i = 0; i < color.nComp; i++) {
/* 75 */       totalSize += fullPlaneSize >> color.compWidth[i] >> color.compHeight[i];
/*    */     }
/* 77 */     return totalSize;
/*    */   }
/*    */ }


/* Location:              C:\Users\rapha\Downloads\aurora.jar!\META-INF\jars\jcodec-0.2.5.jar!\org\jcodec\codecs\raw\RAWVideoEncoder.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */