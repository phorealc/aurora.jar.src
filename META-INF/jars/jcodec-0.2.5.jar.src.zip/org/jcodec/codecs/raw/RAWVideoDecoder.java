/*    */ package org.jcodec.codecs.raw;
/*    */ 
/*    */ import java.nio.ByteBuffer;
/*    */ import org.jcodec.common.VideoCodecMeta;
/*    */ import org.jcodec.common.VideoDecoder;
/*    */ import org.jcodec.common.model.ColorSpace;
/*    */ import org.jcodec.common.model.Picture;
/*    */ import org.jcodec.common.model.Size;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class RAWVideoDecoder
/*    */   extends VideoDecoder
/*    */ {
/*    */   private int width;
/*    */   private int height;
/*    */   
/*    */   public RAWVideoDecoder(int width, int height) {
/* 23 */     this.width = width;
/* 24 */     this.height = height;
/*    */   }
/*    */ 
/*    */   
/*    */   public Picture decodeFrame(ByteBuffer data, byte[][] buffer) {
/* 29 */     Picture create = Picture.createPicture(this.width, this.height, buffer, ColorSpace.YUV420);
/*    */     
/* 31 */     ByteBuffer pix = data.duplicate();
/* 32 */     copy(pix, create.getPlaneData(0), this.width * this.height);
/* 33 */     copy(pix, create.getPlaneData(1), this.width * this.height / 4);
/* 34 */     copy(pix, create.getPlaneData(2), this.width * this.height / 4);
/*    */     
/* 36 */     return create;
/*    */   }
/*    */   
/*    */   void copy(ByteBuffer b, byte[] ii, int size) {
/* 40 */     for (int i = 0; b.hasRemaining() && i < size; i++) {
/* 41 */       ii[i] = (byte)((b.get() & 0xFF) - 128);
/*    */     }
/*    */   }
/*    */ 
/*    */   
/*    */   public VideoCodecMeta getCodecMeta(ByteBuffer data) {
/* 47 */     return VideoCodecMeta.createSimpleVideoCodecMeta(new Size(this.width, this.height), ColorSpace.YUV420);
/*    */   }
/*    */ }


/* Location:              C:\Users\rapha\Downloads\aurora.jar!\META-INF\jars\jcodec-0.2.5.jar!\org\jcodec\codecs\raw\RAWVideoDecoder.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */