/*    */ package org.jcodec.codecs.s302;
/*    */ 
/*    */ import org.jcodec.common.model.ChannelLabel;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class S302MUtils
/*    */ {
/*    */   public static String name(int channels) {
/* 14 */     switch (channels) {
/*    */       case 1:
/* 16 */         return "Mono";
/*    */       case 2:
/* 18 */         return "Stereo 2.0";
/*    */       case 4:
/* 20 */         return "Surround 4.0";
/*    */       case 8:
/* 22 */         return "Stereo 2.0 + Surround 5.1";
/*    */     } 
/* 24 */     return null;
/*    */   }
/*    */   
/*    */   public static ChannelLabel[] labels(int channels) {
/* 28 */     switch (channels) {
/*    */       case 1:
/* 30 */         return new ChannelLabel[] { ChannelLabel.MONO };
/*    */       case 2:
/* 32 */         return new ChannelLabel[] { ChannelLabel.STEREO_LEFT, ChannelLabel.STEREO_RIGHT };
/*    */       case 4:
/* 34 */         return new ChannelLabel[] { ChannelLabel.FRONT_LEFT, ChannelLabel.FRONT_RIGHT, ChannelLabel.REAR_LEFT, ChannelLabel.REAR_RIGHT };
/*    */       
/*    */       case 8:
/* 37 */         return new ChannelLabel[] { ChannelLabel.STEREO_LEFT, ChannelLabel.STEREO_RIGHT, ChannelLabel.FRONT_LEFT, ChannelLabel.FRONT_RIGHT, ChannelLabel.REAR_LEFT, ChannelLabel.REAR_RIGHT, ChannelLabel.CENTER, ChannelLabel.LFE };
/*    */     } 
/*    */ 
/*    */     
/* 41 */     return null;
/*    */   }
/*    */ }


/* Location:              C:\Users\rapha\Downloads\aurora.jar!\META-INF\jars\jcodec-0.2.5.jar!\org\jcodec\codecs\s302\S302MUtils.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */