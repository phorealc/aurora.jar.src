/*     */ package org.jcodec.codecs.s302;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.nio.ByteBuffer;
/*     */ import java.nio.ByteOrder;
/*     */ import org.jcodec.common.AudioCodecMeta;
/*     */ import org.jcodec.common.AudioDecoder;
/*     */ import org.jcodec.common.AudioFormat;
/*     */ import org.jcodec.common.model.AudioBuffer;
/*     */ import org.jcodec.common.tools.MathUtil;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class S302MDecoder
/*     */   implements AudioDecoder
/*     */ {
/*  23 */   public static int SAMPLE_RATE = 48000;
/*     */   
/*     */   public AudioBuffer decodeFrame(ByteBuffer frame, ByteBuffer dst) {
/*  26 */     frame.order(ByteOrder.BIG_ENDIAN);
/*  27 */     ByteBuffer dup = dst.duplicate();
/*     */     
/*  29 */     int h = frame.getInt();
/*  30 */     int frameSize = h >> 16 & 0xFFFF;
/*  31 */     if (frame.remaining() != frameSize)
/*  32 */       throw new IllegalArgumentException("Wrong s302m frame"); 
/*  33 */     int channels = (h >> 14 & 0x3) * 2 + 2;
/*  34 */     int sampleSizeInBits = (h >> 4 & 0x3) * 4 + 16;
/*     */     
/*  36 */     if (sampleSizeInBits == 24) {
/*  37 */       int i = frame.remaining() / 7 * 2;
/*  38 */       while (frame.remaining() > 6) {
/*     */         
/*  40 */         byte c = (byte)MathUtil.reverse(frame.get() & 0xFF);
/*  41 */         byte b = (byte)MathUtil.reverse(frame.get() & 0xFF);
/*  42 */         byte a = (byte)MathUtil.reverse(frame.get() & 0xFF);
/*  43 */         int g = MathUtil.reverse(frame.get() & 0xF);
/*  44 */         int f = MathUtil.reverse(frame.get() & 0xFF);
/*  45 */         int e = MathUtil.reverse(frame.get() & 0xFF);
/*  46 */         int d = MathUtil.reverse(frame.get() & 0xF0);
/*     */         
/*  48 */         dup.put(a);
/*  49 */         dup.put(b);
/*  50 */         dup.put(c);
/*  51 */         dup.put((byte)(d << 4 | e >> 4));
/*  52 */         dup.put((byte)(e << 4 | f >> 4));
/*  53 */         dup.put((byte)(f << 4 | g >> 4));
/*     */       } 
/*     */       
/*  56 */       dup.flip();
/*  57 */       return new AudioBuffer(dup, new AudioFormat(SAMPLE_RATE, 24, channels, true, true), i / channels);
/*  58 */     }  if (sampleSizeInBits == 20) {
/*  59 */       int i = frame.remaining() / 6 * 2;
/*  60 */       while (frame.remaining() > 5) {
/*  61 */         int c = MathUtil.reverse(frame.get() & 0xFF);
/*  62 */         int b = MathUtil.reverse(frame.get() & 0xFF);
/*  63 */         int a = MathUtil.reverse(frame.get() & 0xF0);
/*  64 */         dup.put((byte)(a << 4 | b >> 4));
/*  65 */         dup.put((byte)(b << 4 | c >> 4));
/*  66 */         dup.put((byte)(c << 4));
/*     */         
/*  68 */         int cc = MathUtil.reverse(frame.get() & 0xFF);
/*  69 */         int bb = MathUtil.reverse(frame.get() & 0xFF);
/*  70 */         int aa = MathUtil.reverse(frame.get() & 0xF0);
/*  71 */         dup.put((byte)(aa << 4 | bb >> 4));
/*  72 */         dup.put((byte)(bb << 4 | cc >> 4));
/*  73 */         dup.put((byte)(cc << 4));
/*     */       } 
/*     */       
/*  76 */       dup.flip();
/*  77 */       return new AudioBuffer(dup, new AudioFormat(SAMPLE_RATE, 24, channels, true, true), i / channels);
/*     */     } 
/*  79 */     int nSamples = frame.remaining() / 5 * 2;
/*  80 */     while (frame.remaining() > 4) {
/*  81 */       byte bb = (byte)MathUtil.reverse(frame.get() & 0xFF);
/*  82 */       byte aa = (byte)MathUtil.reverse(frame.get() & 0xFF);
/*  83 */       int c = MathUtil.reverse(frame.get() & 0xFF);
/*  84 */       int b = MathUtil.reverse(frame.get() & 0xFF);
/*  85 */       int a = MathUtil.reverse(frame.get() & 0xF0);
/*     */       
/*  87 */       dst.put(aa);
/*  88 */       dst.put(bb);
/*  89 */       dst.put((byte)(a << 4 | b >> 4));
/*  90 */       dst.put((byte)(b << 4 | c >> 4));
/*     */     } 
/*     */     
/*  93 */     dup.flip();
/*  94 */     return new AudioBuffer(dup, new AudioFormat(SAMPLE_RATE, 16, channels, true, true), nSamples / channels);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public AudioCodecMeta getCodecMeta(ByteBuffer _data) throws IOException {
/* 100 */     ByteBuffer frame = _data.duplicate();
/* 101 */     frame.order(ByteOrder.BIG_ENDIAN);
/*     */     
/* 103 */     int h = frame.getInt();
/* 104 */     int frameSize = h >> 16 & 0xFFFF;
/* 105 */     if (frame.remaining() != frameSize)
/* 106 */       throw new IllegalArgumentException("Wrong s302m frame"); 
/* 107 */     int channels = (h >> 14 & 0x3) * 2 + 2;
/* 108 */     int sampleSizeInBits = (h >> 4 & 0x3) * 4 + 16;
/* 109 */     return AudioCodecMeta.fromAudioFormat(new AudioFormat(SAMPLE_RATE, sampleSizeInBits, channels, true, true));
/*     */   }
/*     */ }


/* Location:              C:\Users\rapha\Downloads\aurora.jar!\META-INF\jars\jcodec-0.2.5.jar!\org\jcodec\codecs\s302\S302MDecoder.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */