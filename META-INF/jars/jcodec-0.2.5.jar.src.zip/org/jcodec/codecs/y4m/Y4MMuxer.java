/*    */ package org.jcodec.codecs.y4m;
/*    */ 
/*    */ import java.io.IOException;
/*    */ import java.nio.ByteBuffer;
/*    */ import java.nio.channels.WritableByteChannel;
/*    */ import org.jcodec.common.AudioCodecMeta;
/*    */ import org.jcodec.common.Codec;
/*    */ import org.jcodec.common.Muxer;
/*    */ import org.jcodec.common.MuxerTrack;
/*    */ import org.jcodec.common.VideoCodecMeta;
/*    */ import org.jcodec.common.model.Packet;
/*    */ import org.jcodec.common.model.Size;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class Y4MMuxer
/*    */   implements Muxer, MuxerTrack
/*    */ {
/*    */   private WritableByteChannel ch;
/*    */   private boolean headerWritten;
/*    */   private VideoCodecMeta meta;
/* 25 */   public static final byte[] frameTag = "FRAME\n".getBytes();
/*    */   
/*    */   public Y4MMuxer(WritableByteChannel ch) {
/* 28 */     this.ch = ch;
/*    */   }
/*    */   
/*    */   protected void writeHeader() throws IOException {
/* 32 */     Size size = this.meta.getSize();
/*    */ 
/*    */     
/* 35 */     byte[] bytes = String.format("YUV4MPEG2 W%d H%d F25:1 Ip A0:0 C420jpeg XYSCSS=420JPEG\n", new Object[] { Integer.valueOf(size.getWidth()), Integer.valueOf(size.getHeight()) }).getBytes();
/* 36 */     this.ch.write(ByteBuffer.wrap(bytes));
/*    */   }
/*    */ 
/*    */   
/*    */   public void addFrame(Packet outPacket) throws IOException {
/* 41 */     if (!this.headerWritten) {
/* 42 */       writeHeader();
/* 43 */       this.headerWritten = true;
/*    */     } 
/* 45 */     this.ch.write(ByteBuffer.wrap(frameTag));
/* 46 */     this.ch.write(outPacket.data.duplicate());
/*    */   }
/*    */ 
/*    */   
/*    */   public MuxerTrack addVideoTrack(Codec codec, VideoCodecMeta meta) {
/* 51 */     this.meta = meta;
/* 52 */     return this;
/*    */   }
/*    */ 
/*    */   
/*    */   public MuxerTrack addAudioTrack(Codec codec, AudioCodecMeta meta) {
/* 57 */     throw new RuntimeException("Y4M doesn't support audio");
/*    */   }
/*    */   
/*    */   public void finish() throws IOException {}
/*    */ }


/* Location:              C:\Users\rapha\Downloads\aurora.jar!\META-INF\jars\jcodec-0.2.5.jar!\org\jcodec\codecs\y4m\Y4MMuxer.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */