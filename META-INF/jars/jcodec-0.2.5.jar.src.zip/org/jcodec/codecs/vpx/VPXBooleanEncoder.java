/*    */ package org.jcodec.codecs.vpx;
/*    */ 
/*    */ import java.nio.ByteBuffer;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class VPXBooleanEncoder
/*    */ {
/*    */   private ByteBuffer out;
/*    */   private int lowvalue;
/*    */   private int range;
/*    */   private int count;
/*    */   
/*    */   public VPXBooleanEncoder(ByteBuffer out) {
/* 22 */     this.out = out;
/* 23 */     this.lowvalue = 0;
/* 24 */     this.range = 255;
/* 25 */     this.count = -24;
/*    */   }
/*    */   
/*    */   public void writeBit(int prob, int bb) {
/* 29 */     int split = 1 + ((this.range - 1) * prob >> 8);
/*    */     
/* 31 */     if (bb != 0) {
/* 32 */       this.lowvalue += split;
/* 33 */       this.range -= split;
/*    */     } else {
/* 35 */       this.range = split;
/*    */     } 
/*    */     
/* 38 */     int shift = VPXConst.vp8Norm[this.range];
/* 39 */     this.range <<= shift;
/* 40 */     this.count += shift;
/*    */     
/* 42 */     if (this.count >= 0) {
/* 43 */       int offset = shift - this.count;
/*    */       
/* 45 */       if ((this.lowvalue << offset - 1 & Integer.MIN_VALUE) != 0) {
/* 46 */         int x = this.out.position() - 1;
/*    */         
/* 48 */         while (x >= 0 && this.out.get(x) == -1) {
/* 49 */           this.out.put(x, (byte)0);
/* 50 */           x--;
/*    */         } 
/*    */         
/* 53 */         this.out.put(x, (byte)((this.out.get(x) & 0xFF) + 1));
/*    */       } 
/*    */       
/* 56 */       this.out.put((byte)(this.lowvalue >> 24 - offset));
/* 57 */       this.lowvalue <<= offset;
/* 58 */       shift = this.count;
/* 59 */       this.lowvalue &= 0xFFFFFF;
/* 60 */       this.count -= 8;
/*    */     } 
/*    */     
/* 63 */     this.lowvalue <<= shift;
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public void stop() {
/* 69 */     for (int i = 0; i < 32; i++)
/* 70 */       writeBit(128, 0); 
/*    */   }
/*    */   
/*    */   public int position() {
/* 74 */     return this.out.position() + (this.count + 24 >> 3);
/*    */   }
/*    */ }


/* Location:              C:\Users\rapha\Downloads\aurora.jar!\META-INF\jars\jcodec-0.2.5.jar!\org\jcodec\codecs\vpx\VPXBooleanEncoder.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */