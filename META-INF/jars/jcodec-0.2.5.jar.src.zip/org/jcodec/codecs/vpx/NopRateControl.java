/*    */ package org.jcodec.codecs.vpx;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class NopRateControl
/*    */   implements RateControl
/*    */ {
/*    */   private int qp;
/*    */   
/*    */   public NopRateControl(int qp) {
/* 17 */     this.qp = qp;
/*    */   }
/*    */ 
/*    */   
/*    */   public int[] getSegmentQps() {
/* 22 */     return new int[] { this.qp };
/*    */   }
/*    */ 
/*    */   
/*    */   public int getSegment() {
/* 27 */     return 0;
/*    */   }
/*    */   
/*    */   public void report(int bits) {}
/*    */   
/*    */   public void reset() {}
/*    */ }


/* Location:              C:\Users\rapha\Downloads\aurora.jar!\META-INF\jars\jcodec-0.2.5.jar!\org\jcodec\codecs\vpx\NopRateControl.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */