/*     */ package org.jcodec.codecs.vpx;
/*     */ 
/*     */ import org.jcodec.api.NotImplementedException;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class FilterUtil
/*     */ {
/*     */   private static int clipPlus128(int v) {
/*  22 */     return clipSigned(v) + 128;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public static class Segment
/*     */   {
/*     */     int p0;
/*     */ 
/*     */     
/*     */     int p1;
/*     */     
/*     */     int p2;
/*     */     
/*     */     int p3;
/*     */     
/*     */     int q0;
/*     */     
/*     */     int q1;
/*     */     
/*     */     int q2;
/*     */     
/*     */     int q3;
/*     */ 
/*     */     
/*     */     public boolean isFilterRequired(int interior, int edge) {
/*  48 */       return ((Math.abs(this.p0 - this.q0) << 2) + (Math.abs(this.p1 - this.q1) >> 2) <= edge && 
/*  49 */         Math.abs(this.p3 - this.p2) <= interior && 
/*  50 */         Math.abs(this.p2 - this.p1) <= interior && 
/*  51 */         Math.abs(this.p1 - this.p0) <= interior && 
/*  52 */         Math.abs(this.q3 - this.q2) <= interior && 
/*  53 */         Math.abs(this.q2 - this.q1) <= interior && 
/*  54 */         Math.abs(this.q1 - this.q0) <= interior);
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public boolean isHighVariance(int threshold) {
/*  69 */       return (Math.abs(this.p1 - this.p0) > threshold || Math.abs(this.q1 - this.q0) > threshold);
/*     */     }
/*     */     
/*     */     public Segment getSigned() {
/*  73 */       Segment seg = new Segment();
/*  74 */       seg.p3 = FilterUtil.minus128(this.p3);
/*  75 */       seg.p2 = FilterUtil.minus128(this.p2);
/*  76 */       seg.p1 = FilterUtil.minus128(this.p1);
/*  77 */       seg.p0 = FilterUtil.minus128(this.p0);
/*  78 */       seg.q0 = FilterUtil.minus128(this.q0);
/*  79 */       seg.q1 = FilterUtil.minus128(this.q1);
/*  80 */       seg.q2 = FilterUtil.minus128(this.q2);
/*  81 */       seg.q3 = FilterUtil.minus128(this.q3);
/*  82 */       return seg;
/*     */     }
/*     */     
/*     */     public static Segment horizontal(VPXMacroblock.Subblock right, VPXMacroblock.Subblock left, int a) {
/*  86 */       Segment seg = new Segment();
/*  87 */       seg.p0 = left.val[12 + a];
/*  88 */       seg.p1 = left.val[8 + a];
/*  89 */       seg.p2 = left.val[4 + a];
/*  90 */       seg.p3 = left.val[0 + a];
/*  91 */       seg.q0 = right.val[0 + a];
/*  92 */       seg.q1 = right.val[4 + a];
/*  93 */       seg.q2 = right.val[8 + a];
/*  94 */       seg.q3 = right.val[12 + a];
/*  95 */       return seg;
/*     */     }
/*     */     
/*     */     public static Segment vertical(VPXMacroblock.Subblock lower, VPXMacroblock.Subblock upper, int a) {
/*  99 */       Segment seg = new Segment();
/* 100 */       seg.p0 = upper.val[a * 4 + 3];
/* 101 */       seg.p1 = upper.val[a * 4 + 2];
/* 102 */       seg.p2 = upper.val[a * 4 + 1];
/* 103 */       seg.p3 = upper.val[a * 4 + 0];
/* 104 */       seg.q0 = lower.val[a * 4 + 0];
/* 105 */       seg.q1 = lower.val[a * 4 + 1];
/* 106 */       seg.q2 = lower.val[a * 4 + 2];
/* 107 */       seg.q3 = lower.val[a * 4 + 3];
/* 108 */       return seg;
/*     */     }
/*     */     
/*     */     public void applyHorizontally(VPXMacroblock.Subblock right, VPXMacroblock.Subblock left, int a) {
/* 112 */       left.val[12 + a] = this.p0;
/* 113 */       left.val[8 + a] = this.p1;
/* 114 */       left.val[4 + a] = this.p2;
/* 115 */       left.val[0 + a] = this.p3;
/* 116 */       right.val[0 + a] = this.q0;
/* 117 */       right.val[4 + a] = this.q1;
/* 118 */       right.val[8 + a] = this.q2;
/* 119 */       right.val[12 + a] = this.q3;
/*     */     }
/*     */ 
/*     */     
/*     */     public void applyVertically(VPXMacroblock.Subblock lower, VPXMacroblock.Subblock upper, int a) {
/* 124 */       upper.val[a * 4 + 3] = this.p0;
/* 125 */       upper.val[a * 4 + 2] = this.p1;
/* 126 */       upper.val[a * 4 + 1] = this.p2;
/* 127 */       upper.val[a * 4 + 0] = this.p3;
/* 128 */       lower.val[a * 4 + 0] = this.q0;
/* 129 */       lower.val[a * 4 + 1] = this.q1;
/* 130 */       lower.val[a * 4 + 2] = this.q2;
/* 131 */       lower.val[a * 4 + 3] = this.q3;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     void filterMb(int hevThreshold, int interiorLimit, int edgeLimit) {
/* 143 */       Segment signedSeg = getSigned();
/* 144 */       if (signedSeg.isFilterRequired(interiorLimit, edgeLimit)) {
/* 145 */         if (!signedSeg.isHighVariance(hevThreshold)) {
/*     */ 
/*     */           
/* 148 */           int w = FilterUtil.clipSigned(FilterUtil.clipSigned(signedSeg.p1 - signedSeg.q1) + 3 * (signedSeg.q0 - signedSeg.p0));
/*     */ 
/*     */ 
/*     */ 
/*     */           
/* 153 */           int a = 27 * w + 63 >> 7;
/*     */           
/* 155 */           this.q0 = FilterUtil.clipPlus128(signedSeg.q0 - a);
/* 156 */           this.p0 = FilterUtil.clipPlus128(signedSeg.p0 + a);
/*     */           
/* 158 */           a = 18 * w + 63 >> 7;
/*     */           
/* 160 */           this.q1 = FilterUtil.clipPlus128(signedSeg.q1 - a);
/* 161 */           this.p1 = FilterUtil.clipPlus128(signedSeg.p1 + a);
/*     */           
/* 163 */           a = 9 * w + 63 >> 7;
/* 164 */           this.q2 = FilterUtil.clipPlus128(signedSeg.q2 - a);
/* 165 */           this.p2 = FilterUtil.clipPlus128(signedSeg.p2 + a);
/*     */         } else {
/*     */           
/* 168 */           adjust(true);
/*     */         } 
/*     */       }
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public void filterSb(int hev_threshold, int interior_limit, int edge_limit) {
/* 182 */       Segment signedSeg = getSigned();
/* 183 */       if (signedSeg.isFilterRequired(interior_limit, edge_limit)) {
/* 184 */         boolean hv = signedSeg.isHighVariance(hev_threshold);
/* 185 */         int a = adjust(hv) + 1 >> 1;
/* 186 */         if (!hv) {
/* 187 */           this.q1 = FilterUtil.clipPlus128(signedSeg.q1 - a);
/* 188 */           this.p1 = FilterUtil.clipPlus128(signedSeg.p1 + a);
/*     */         } 
/*     */       } 
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     private int adjust(boolean use_outer_taps) {
/* 200 */       int p1 = FilterUtil.minus128(this.p1);
/* 201 */       int p0 = FilterUtil.minus128(this.p0);
/* 202 */       int q0 = FilterUtil.minus128(this.q0);
/* 203 */       int q1 = FilterUtil.minus128(this.q1);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 213 */       int a = FilterUtil.clipSigned((use_outer_taps ? FilterUtil.clipSigned(p1 - q1) : 0) + 3 * (q0 - p0));
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 219 */       int b = FilterUtil.clipSigned(a + 3) >> 3;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 225 */       a = FilterUtil.clipSigned(a + 4) >> 3;
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 230 */       this.q0 = FilterUtil.clipPlus128(q0 - a);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 237 */       this.p0 = FilterUtil.clipPlus128(p0 + b);
/*     */       
/* 239 */       return a;
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   private static int clipSigned(int v) {
/* 245 */     return (v < -128) ? -128 : ((v > 127) ? 127 : v);
/*     */   }
/*     */ 
/*     */   
/*     */   private static int minus128(int v) {
/* 250 */     return v - 128;
/*     */   }
/*     */   
/*     */   public static void loopFilterUV(VPXMacroblock[][] mbs, int sharpnessLevel, boolean keyFrame) {
/* 254 */     for (int y = 0; y < mbs.length - 2; y++) {
/* 255 */       for (int x = 0; x < (mbs[0]).length - 2; x++) {
/* 256 */         VPXMacroblock rmb = mbs[y + 1][x + 1];
/* 257 */         VPXMacroblock bmb = mbs[y + 1][x + 1];
/* 258 */         int loop_filter_level = rmb.filterLevel;
/* 259 */         if (loop_filter_level != 0) {
/* 260 */           int interior_limit = rmb.filterLevel;
/* 261 */           if (sharpnessLevel > 0) {
/* 262 */             interior_limit >>= (sharpnessLevel > 4) ? 2 : 1;
/* 263 */             if (interior_limit > 9 - sharpnessLevel)
/* 264 */               interior_limit = 9 - sharpnessLevel; 
/*     */           } 
/* 266 */           if (interior_limit == 0) {
/* 267 */             interior_limit = 1;
/*     */           }
/* 269 */           int hev_threshold = 0;
/* 270 */           if (keyFrame)
/* 271 */           { if (loop_filter_level >= 40) {
/* 272 */               hev_threshold = 2;
/* 273 */             } else if (loop_filter_level >= 15) {
/* 274 */               hev_threshold = 1;
/*     */             }  }
/* 276 */           else { throw new NotImplementedException("TODO: non-key frames are not supported yet."); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */           
/* 286 */           int mbedge_limit = (loop_filter_level + 2) * 2 + interior_limit;
/*     */           
/* 288 */           int sub_bedge_limit = loop_filter_level * 2 + interior_limit;
/*     */           
/* 290 */           if (x > 0) {
/* 291 */             VPXMacroblock lmb = mbs[y + 1][x + 1 - 1];
/* 292 */             for (int b = 0; b < 2; b++) {
/* 293 */               VPXMacroblock.Subblock rsbU = rmb.uSubblocks[b][0];
/* 294 */               VPXMacroblock.Subblock lsbU = lmb.uSubblocks[b][1];
/* 295 */               VPXMacroblock.Subblock rsbV = rmb.vSubblocks[b][0];
/* 296 */               VPXMacroblock.Subblock lsbV = lmb.vSubblocks[b][1];
/* 297 */               for (int a = 0; a < 4; a++) {
/* 298 */                 Segment seg = Segment.horizontal(rsbU, lsbU, a);
/* 299 */                 seg.filterMb(hev_threshold, interior_limit, mbedge_limit);
/* 300 */                 seg.applyHorizontally(rsbU, lsbU, a);
/* 301 */                 seg = Segment.horizontal(rsbV, lsbV, a);
/* 302 */                 seg.filterMb(hev_threshold, interior_limit, mbedge_limit);
/* 303 */                 seg.applyHorizontally(rsbV, lsbV, a);
/*     */               } 
/*     */             } 
/*     */           } 
/*     */ 
/*     */ 
/*     */           
/* 310 */           if (!rmb.skipFilter) {
/* 311 */             for (int a = 1; a < 2; a++) {
/* 312 */               for (int b = 0; b < 2; b++) {
/* 313 */                 VPXMacroblock.Subblock lsbU = rmb.uSubblocks[b][a - 1];
/* 314 */                 VPXMacroblock.Subblock rsbU = rmb.uSubblocks[b][a];
/* 315 */                 VPXMacroblock.Subblock lsbV = rmb.vSubblocks[b][a - 1];
/* 316 */                 VPXMacroblock.Subblock rsbV = rmb.vSubblocks[b][a];
/* 317 */                 for (int c = 0; c < 4; c++) {
/* 318 */                   Segment seg = Segment.horizontal(rsbU, lsbU, c);
/* 319 */                   seg.filterSb(hev_threshold, interior_limit, sub_bedge_limit);
/* 320 */                   seg.applyHorizontally(rsbU, lsbU, c);
/* 321 */                   seg = Segment.horizontal(rsbV, lsbV, c);
/* 322 */                   seg.filterSb(hev_threshold, interior_limit, sub_bedge_limit);
/* 323 */                   seg.applyHorizontally(rsbV, lsbV, c);
/*     */                 } 
/*     */               } 
/*     */             } 
/*     */           }
/*     */           
/* 329 */           if (y > 0) {
/* 330 */             VPXMacroblock tmb = mbs[y + 1 - 1][x + 1];
/* 331 */             for (int b = 0; b < 2; b++) {
/* 332 */               VPXMacroblock.Subblock tsbU = tmb.uSubblocks[1][b];
/* 333 */               VPXMacroblock.Subblock bsbU = bmb.uSubblocks[0][b];
/* 334 */               VPXMacroblock.Subblock tsbV = tmb.vSubblocks[1][b];
/* 335 */               VPXMacroblock.Subblock bsbV = bmb.vSubblocks[0][b];
/* 336 */               for (int a = 0; a < 4; a++) {
/*     */                 
/* 338 */                 Segment seg = Segment.vertical(bsbU, tsbU, a);
/* 339 */                 seg.filterMb(hev_threshold, interior_limit, mbedge_limit);
/* 340 */                 seg.applyVertically(bsbU, tsbU, a);
/* 341 */                 seg = Segment.vertical(bsbV, tsbV, a);
/* 342 */                 seg.filterMb(hev_threshold, interior_limit, mbedge_limit);
/* 343 */                 seg.applyVertically(bsbV, tsbV, a);
/*     */               } 
/*     */             } 
/*     */           } 
/*     */ 
/*     */           
/* 349 */           if (!rmb.skipFilter) {
/* 350 */             for (int a = 1; a < 2; a++) {
/* 351 */               for (int b = 0; b < 2; b++) {
/* 352 */                 VPXMacroblock.Subblock tsbU = bmb.uSubblocks[a - 1][b];
/* 353 */                 VPXMacroblock.Subblock bsbU = bmb.uSubblocks[a][b];
/* 354 */                 VPXMacroblock.Subblock tsbV = bmb.vSubblocks[a - 1][b];
/* 355 */                 VPXMacroblock.Subblock bsbV = bmb.vSubblocks[a][b];
/* 356 */                 for (int c = 0; c < 4; c++) {
/* 357 */                   Segment seg = Segment.vertical(bsbU, tsbU, c);
/* 358 */                   seg.filterSb(hev_threshold, interior_limit, sub_bedge_limit);
/* 359 */                   seg.applyVertically(bsbU, tsbU, c);
/* 360 */                   seg = Segment.vertical(bsbV, tsbV, c);
/* 361 */                   seg.filterSb(hev_threshold, interior_limit, sub_bedge_limit);
/* 362 */                   seg.applyVertically(bsbV, tsbV, c);
/*     */                 } 
/*     */               } 
/*     */             } 
/*     */           }
/*     */         } 
/*     */       } 
/*     */     } 
/*     */   }
/*     */   
/*     */   public static void loopFilterY(VPXMacroblock[][] mbs, int sharpnessLevel, boolean keyFrame) {
/* 373 */     for (int y = 0; y < mbs.length - 2; y++) {
/* 374 */       for (int x = 0; x < (mbs[0]).length - 2; x++) {
/* 375 */         VPXMacroblock rmb = mbs[y + 1][x + 1];
/* 376 */         VPXMacroblock bmb = mbs[y + 1][x + 1];
/* 377 */         int loopFilterLevel = rmb.filterLevel;
/*     */         
/* 379 */         if (loopFilterLevel != 0) {
/* 380 */           int interiorLimit = rmb.filterLevel;
/*     */           
/* 382 */           if (sharpnessLevel > 0) {
/* 383 */             interiorLimit >>= (sharpnessLevel > 4) ? 2 : 1;
/* 384 */             if (interiorLimit > 9 - sharpnessLevel)
/* 385 */               interiorLimit = 9 - sharpnessLevel; 
/*     */           } 
/* 387 */           if (interiorLimit == 0) {
/* 388 */             interiorLimit = 1;
/*     */           }
/* 390 */           int varianceThreshold = 0;
/* 391 */           if (keyFrame)
/* 392 */           { if (loopFilterLevel >= 40) {
/* 393 */               varianceThreshold = 2;
/* 394 */             } else if (loopFilterLevel >= 15) {
/* 395 */               varianceThreshold = 1;
/*     */             }  }
/* 397 */           else { throw new NotImplementedException("TODO: non-key frames are not supported yet"); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */           
/* 409 */           int edgeLimitMb = (loopFilterLevel + 2) * 2 + interiorLimit;
/*     */ 
/*     */ 
/*     */           
/* 413 */           int edgeLimitSb = loopFilterLevel * 2 + interiorLimit;
/*     */ 
/*     */           
/* 416 */           if (x > 0) {
/* 417 */             VPXMacroblock lmb = mbs[y + 1][x - 1 + 1];
/* 418 */             for (int b = 0; b < 4; b++) {
/* 419 */               VPXMacroblock.Subblock rsb = rmb.ySubblocks[b][0];
/* 420 */               VPXMacroblock.Subblock lsb = lmb.ySubblocks[b][3];
/* 421 */               for (int a = 0; a < 4; a++) {
/* 422 */                 Segment seg = Segment.horizontal(rsb, lsb, a);
/* 423 */                 seg.filterMb(varianceThreshold, interiorLimit, edgeLimitMb);
/* 424 */                 seg.applyHorizontally(rsb, lsb, a);
/*     */               } 
/*     */             } 
/*     */           } 
/*     */           
/* 429 */           if (!rmb.skipFilter) {
/* 430 */             for (int a = 1; a < 4; a++) {
/* 431 */               for (int b = 0; b < 4; b++) {
/* 432 */                 VPXMacroblock.Subblock lsb = rmb.ySubblocks[b][a - 1];
/* 433 */                 VPXMacroblock.Subblock rsb = rmb.ySubblocks[b][a];
/* 434 */                 for (int c = 0; c < 4; c++) {
/* 435 */                   Segment seg = Segment.horizontal(rsb, lsb, c);
/* 436 */                   seg.filterSb(varianceThreshold, interiorLimit, edgeLimitSb);
/* 437 */                   seg.applyHorizontally(rsb, lsb, c);
/*     */                 } 
/*     */               } 
/*     */             } 
/*     */           }
/*     */           
/* 443 */           if (y > 0) {
/* 444 */             VPXMacroblock tmb = mbs[y - 1 + 1][x + 1];
/* 445 */             for (int b = 0; b < 4; b++) {
/* 446 */               VPXMacroblock.Subblock tsb = tmb.ySubblocks[3][b];
/* 447 */               VPXMacroblock.Subblock bsb = bmb.ySubblocks[0][b];
/* 448 */               for (int a = 0; a < 4; a++) {
/* 449 */                 Segment seg = Segment.vertical(bsb, tsb, a);
/* 450 */                 seg.filterMb(varianceThreshold, interiorLimit, edgeLimitMb);
/* 451 */                 seg.applyVertically(bsb, tsb, a);
/*     */               } 
/*     */             } 
/*     */           } 
/*     */           
/* 456 */           if (!rmb.skipFilter)
/* 457 */             for (int a = 1; a < 4; a++) {
/* 458 */               for (int b = 0; b < 4; b++) {
/* 459 */                 VPXMacroblock.Subblock tsb = bmb.ySubblocks[a - 1][b];
/* 460 */                 VPXMacroblock.Subblock bsb = bmb.ySubblocks[a][b];
/* 461 */                 for (int c = 0; c < 4; c++) {
/* 462 */                   Segment seg = Segment.vertical(bsb, tsb, c);
/* 463 */                   seg.filterSb(varianceThreshold, interiorLimit, edgeLimitSb);
/* 464 */                   seg.applyVertically(bsb, tsb, c);
/*     */                 } 
/*     */               } 
/*     */             }  
/*     */         } 
/*     */       } 
/*     */     } 
/*     */   }
/*     */ }


/* Location:              C:\Users\rapha\Downloads\aurora.jar!\META-INF\jars\jcodec-0.2.5.jar!\org\jcodec\codecs\vpx\FilterUtil.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */