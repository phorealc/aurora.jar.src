/*     */ package org.jcodec.codecs.vpx;
/*     */ 
/*     */ import java.nio.ByteBuffer;
/*     */ import java.nio.ByteOrder;
/*     */ import java.util.Arrays;
/*     */ import org.jcodec.common.ArrayUtil;
/*     */ import org.jcodec.common.VideoEncoder;
/*     */ import org.jcodec.common.model.ColorSpace;
/*     */ import org.jcodec.common.model.Picture;
/*     */ import org.jcodec.common.tools.MathUtil;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class VP8Encoder
/*     */   extends VideoEncoder
/*     */ {
/*     */   private VPXBitstream bitstream;
/*     */   private byte[][] leftRow;
/*     */   private byte[][] topLine;
/*     */   private VPXQuantizer quantizer;
/*     */   private int[] tmp;
/*     */   private RateControl rc;
/*     */   private ByteBuffer headerBuffer;
/*     */   private ByteBuffer dataBuffer;
/*     */   
/*     */   public static VP8Encoder createVP8Encoder(int qp) {
/*  35 */     return new VP8Encoder(new NopRateControl(qp));
/*     */   }
/*     */   
/*     */   public VP8Encoder(RateControl rc) {
/*  39 */     this.rc = rc;
/*  40 */     this.tmp = new int[16];
/*     */   }
/*     */ 
/*     */   
/*     */   public VideoEncoder.EncodedFrame encodeFrame(Picture pic, ByteBuffer _buf) {
/*  45 */     ByteBuffer out = _buf.duplicate();
/*  46 */     int mbWidth = pic.getWidth() + 15 >> 4;
/*  47 */     int mbHeight = pic.getHeight() + 15 >> 4;
/*     */     
/*  49 */     prepareBuffers(mbWidth, mbHeight);
/*     */     
/*  51 */     this.bitstream = new VPXBitstream(VPXConst.tokenDefaultBinProbs, mbWidth);
/*  52 */     this.leftRow = new byte[][] { new byte[16], new byte[8], new byte[8] };
/*  53 */     this.topLine = new byte[][] { new byte[mbWidth << 4], new byte[mbWidth << 3], new byte[mbWidth << 3] };
/*  54 */     initValue(this.leftRow, (byte)1);
/*  55 */     initValue(this.topLine, (byte)-1);
/*     */     
/*  57 */     this.quantizer = new VPXQuantizer();
/*     */     
/*  59 */     Picture outMB = Picture.create(16, 16, ColorSpace.YUV420);
/*     */     
/*  61 */     int[] segmentQps = this.rc.getSegmentQps();
/*     */     
/*  63 */     VPXBooleanEncoder boolEnc = new VPXBooleanEncoder(this.dataBuffer);
/*     */     
/*  65 */     int[] segmentMap = new int[mbWidth * mbHeight];
/*     */ 
/*     */     
/*  68 */     for (int mbY = 0, mbAddr = 0; mbY < mbHeight; mbY++) {
/*  69 */       initValue(this.leftRow, (byte)1);
/*     */       
/*  71 */       for (int mbX = 0; mbX < mbWidth; mbX++, mbAddr++) {
/*     */         
/*  73 */         int before = boolEnc.position();
/*  74 */         int segment = this.rc.getSegment();
/*  75 */         segmentMap[mbAddr] = segment;
/*     */         
/*  77 */         luma(pic, mbX, mbY, boolEnc, segmentQps[segment], outMB);
/*  78 */         chroma(pic, mbX, mbY, boolEnc, segmentQps[segment], outMB);
/*     */         
/*  80 */         this.rc.report(boolEnc.position() - before);
/*     */         
/*  82 */         collectPredictors(outMB, mbX);
/*     */       } 
/*     */     } 
/*  85 */     boolEnc.stop();
/*  86 */     this.dataBuffer.flip();
/*     */     
/*  88 */     boolEnc = new VPXBooleanEncoder(this.headerBuffer);
/*  89 */     int[] probs = calcSegmentProbs(segmentMap);
/*     */     
/*  91 */     writeHeader2(boolEnc, segmentQps, probs);
/*     */ 
/*     */     
/*  94 */     for (int i = 0, j = 0; i < mbHeight; i++) {
/*  95 */       for (int mbX = 0; mbX < mbWidth; mbX++, j++) {
/*  96 */         writeSegmetId(boolEnc, segmentMap[j], probs);
/*     */ 
/*     */         
/*  99 */         boolEnc.writeBit(145, 1);
/* 100 */         boolEnc.writeBit(156, 0);
/* 101 */         boolEnc.writeBit(163, 0);
/*     */ 
/*     */         
/* 104 */         boolEnc.writeBit(142, 0);
/*     */       } 
/*     */     } 
/* 107 */     boolEnc.stop();
/* 108 */     this.headerBuffer.flip();
/*     */     
/* 110 */     out.order(ByteOrder.LITTLE_ENDIAN);
/* 111 */     writeHeader(out, pic.getWidth(), pic.getHeight(), this.headerBuffer.remaining());
/* 112 */     out.put(this.headerBuffer);
/* 113 */     out.put(this.dataBuffer);
/*     */     
/* 115 */     out.flip();
/*     */     
/* 117 */     return new VideoEncoder.EncodedFrame(out, true);
/*     */   }
/*     */   
/*     */   private void prepareBuffers(int mbWidth, int mbHeight) {
/* 121 */     int dataBufSize = mbHeight * mbHeight << 10;
/* 122 */     int headerBufSize = 256 + mbWidth * mbHeight;
/*     */     
/* 124 */     if (this.headerBuffer == null || this.headerBuffer.capacity() < headerBufSize) {
/* 125 */       this.headerBuffer = ByteBuffer.allocate(headerBufSize);
/*     */     } else {
/* 127 */       this.headerBuffer.clear();
/*     */     } 
/* 129 */     if (this.dataBuffer == null || this.dataBuffer.capacity() < dataBufSize) {
/* 130 */       this.dataBuffer = ByteBuffer.allocate(dataBufSize);
/*     */     } else {
/* 132 */       this.dataBuffer.clear();
/*     */     } 
/*     */   }
/*     */   private void writeSegmetId(VPXBooleanEncoder boolEnc, int id, int[] probs) {
/* 136 */     int bit1 = id >> 1 & 0x1;
/* 137 */     boolEnc.writeBit(probs[0], bit1);
/* 138 */     boolEnc.writeBit(probs[1 + bit1], id & 0x1);
/*     */   }
/*     */   
/*     */   private int[] calcSegmentProbs(int[] segmentMap) {
/* 142 */     int[] result = new int[3]; int i;
/* 143 */     for (i = 0; i < segmentMap.length; i++) {
/* 144 */       switch (segmentMap[i]) {
/*     */         case 0:
/* 146 */           result[0] = result[0] + 1;
/* 147 */           result[1] = result[1] + 1;
/*     */           break;
/*     */         case 1:
/* 150 */           result[0] = result[0] + 1;
/*     */           break;
/*     */         case 2:
/* 153 */           result[2] = result[2] + 1; break;
/*     */       } 
/*     */     } 
/* 156 */     for (i = 0; i < 3; i++) {
/* 157 */       result[i] = MathUtil.clip((result[i] << 8) / segmentMap.length, 1, 255);
/*     */     }
/* 159 */     return result;
/*     */   }
/*     */   
/*     */   private void initValue(byte[][] leftRow2, byte val) {
/* 163 */     Arrays.fill(leftRow2[0], val);
/* 164 */     Arrays.fill(leftRow2[1], val);
/* 165 */     Arrays.fill(leftRow2[2], val);
/*     */   }
/*     */   
/*     */   private void writeHeader2(VPXBooleanEncoder boolEnc, int[] segmentQps, int[] probs) {
/* 169 */     boolEnc.writeBit(128, 0);
/* 170 */     boolEnc.writeBit(128, 0);
/* 171 */     boolEnc.writeBit(128, 1);
/*     */     
/* 173 */     boolEnc.writeBit(128, 1);
/* 174 */     boolEnc.writeBit(128, 1);
/*     */     
/* 176 */     boolEnc.writeBit(128, 1);
/*     */     int i;
/* 178 */     for (i = 0; i < segmentQps.length; i++) {
/* 179 */       boolEnc.writeBit(128, 1);
/* 180 */       writeInt(boolEnc, segmentQps[i], 7);
/* 181 */       boolEnc.writeBit(128, 0);
/*     */     } 
/* 183 */     for (i = segmentQps.length; i < 4; i++) {
/* 184 */       boolEnc.writeBit(128, 0);
/*     */     }
/* 186 */     boolEnc.writeBit(128, 0);
/* 187 */     boolEnc.writeBit(128, 0);
/* 188 */     boolEnc.writeBit(128, 0);
/* 189 */     boolEnc.writeBit(128, 0);
/*     */     
/* 191 */     for (i = 0; i < 3; i++) {
/* 192 */       boolEnc.writeBit(128, 1);
/* 193 */       writeInt(boolEnc, probs[i], 8);
/*     */     } 
/*     */     
/* 196 */     boolEnc.writeBit(128, 0);
/* 197 */     writeInt(boolEnc, 1, 6);
/* 198 */     writeInt(boolEnc, 0, 3);
/* 199 */     boolEnc.writeBit(128, 0);
/* 200 */     writeInt(boolEnc, 0, 2);
/* 201 */     writeInt(boolEnc, segmentQps[0], 7);
/* 202 */     boolEnc.writeBit(128, 0);
/* 203 */     boolEnc.writeBit(128, 0);
/* 204 */     boolEnc.writeBit(128, 0);
/* 205 */     boolEnc.writeBit(128, 0);
/* 206 */     boolEnc.writeBit(128, 0);
/* 207 */     boolEnc.writeBit(128, 0);
/*     */     
/* 209 */     int[][][][] probFlags = VPXConst.tokenProbUpdateFlagProbs;
/* 210 */     for (int j = 0; j < probFlags.length; j++) {
/* 211 */       for (int k = 0; k < (probFlags[j]).length; k++) {
/* 212 */         for (int m = 0; m < (probFlags[j][k]).length; m++) {
/* 213 */           for (int l = 0; l < (probFlags[j][k][m]).length; l++) {
/* 214 */             boolEnc.writeBit(probFlags[j][k][m][l], 0);
/*     */           }
/*     */         } 
/*     */       } 
/*     */     } 
/* 219 */     boolEnc.writeBit(128, 0);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   void writeInt(VPXBooleanEncoder boolEnc, int data, int bits) {
/* 225 */     for (int bit = bits - 1; bit >= 0; bit--)
/* 226 */       boolEnc.writeBit(128, 0x1 & data >> bit); 
/*     */   }
/*     */   
/*     */   private void writeHeader(ByteBuffer out, int width, int height, int firstPart) {
/* 230 */     int version = 0, type = 0, showFrame = 1;
/* 231 */     int header = firstPart << 5 | showFrame << 4 | version << 1 | type;
/*     */     
/* 233 */     out.put((byte)(header & 0xFF));
/* 234 */     out.put((byte)(header >> 8 & 0xFF));
/* 235 */     out.put((byte)(header >> 16 & 0xFF));
/*     */     
/* 237 */     out.put((byte)-99);
/* 238 */     out.put((byte)1);
/* 239 */     out.put((byte)42);
/*     */     
/* 241 */     out.putShort((short)width);
/* 242 */     out.putShort((short)height);
/*     */   }
/*     */   
/*     */   private void collectPredictors(Picture outMB, int mbX) {
/* 246 */     System.arraycopy(outMB.getPlaneData(0), 240, this.topLine[0], mbX << 4, 16);
/* 247 */     System.arraycopy(outMB.getPlaneData(1), 56, this.topLine[1], mbX << 3, 8);
/* 248 */     System.arraycopy(outMB.getPlaneData(2), 56, this.topLine[2], mbX << 3, 8);
/*     */     
/* 250 */     copyCol(outMB.getPlaneData(0), 15, 16, this.leftRow[0]);
/* 251 */     copyCol(outMB.getPlaneData(1), 7, 8, this.leftRow[1]);
/* 252 */     copyCol(outMB.getPlaneData(2), 7, 8, this.leftRow[2]);
/*     */   }
/*     */   
/*     */   private void copyCol(byte[] planeData, int off, int stride, byte[] out) {
/* 256 */     for (int i = 0; i < out.length; i++) {
/* 257 */       out[i] = planeData[off];
/* 258 */       off += stride;
/*     */     } 
/*     */   }
/*     */   
/*     */   private void luma(Picture pic, int mbX, int mbY, VPXBooleanEncoder out, int qp, Picture outMB) {
/* 263 */     int x = mbX << 4;
/* 264 */     int y = mbY << 4;
/* 265 */     int[][] ac = transform(pic, 0, qp, x, y);
/* 266 */     int[] dc = extractDC(ac);
/* 267 */     writeLumaDC(mbX, mbY, out, qp, dc);
/* 268 */     writeLumaAC(mbX, mbY, out, ac, qp);
/*     */     
/* 270 */     restorePlaneLuma(dc, ac, qp);
/* 271 */     putLuma(outMB.getPlaneData(0), lumaDCPred(x, y), ac, 4);
/*     */   }
/*     */   
/*     */   private void writeLumaAC(int mbX, int mbY, VPXBooleanEncoder out, int[][] ac, int qp) {
/* 275 */     for (int i = 0; i < 16; i++) {
/* 276 */       this.quantizer.quantizeY(ac[i], qp);
/* 277 */       this.bitstream.encodeCoeffsDCT15(out, zigzag(ac[i], this.tmp), mbX, i & 0x3, i >> 2);
/*     */     } 
/*     */   }
/*     */   
/*     */   private void writeLumaDC(int mbX, int mbY, VPXBooleanEncoder out, int qp, int[] dc) {
/* 282 */     VPXDCT.walsh4x4(dc);
/* 283 */     this.quantizer.quantizeY2(dc, qp);
/* 284 */     this.bitstream.encodeCoeffsWHT(out, zigzag(dc, this.tmp), mbX);
/*     */   }
/*     */   
/*     */   private void writeChroma(int comp, int mbX, int mbY, VPXBooleanEncoder boolEnc, int[][] ac, int qp) {
/* 288 */     for (int i = 0; i < 4; i++) {
/* 289 */       this.quantizer.quantizeUV(ac[i], qp);
/* 290 */       this.bitstream.encodeCoeffsDCTUV(boolEnc, zigzag(ac[i], this.tmp), comp, mbX, i & 0x1, i >> 1);
/*     */     } 
/*     */   }
/*     */   
/*     */   private int[] zigzag(int[] zz, int[] tmp2) {
/* 295 */     for (int i = 0; i < 16; i++)
/* 296 */       tmp2[i] = zz[VPXConst.zigzag[i]]; 
/* 297 */     return tmp2;
/*     */   }
/*     */   
/*     */   private void chroma(Picture pic, int mbX, int mbY, VPXBooleanEncoder boolEnc, int qp, Picture outMB) {
/* 301 */     int x = mbX << 3;
/* 302 */     int y = mbY << 3;
/* 303 */     int chromaPred1 = chromaPredBlk(1, x, y);
/* 304 */     int chromaPred2 = chromaPredBlk(2, x, y);
/*     */     
/* 306 */     int[][] ac1 = transformChroma(pic, 1, qp, x, y, outMB, chromaPred1);
/* 307 */     int[][] ac2 = transformChroma(pic, 2, qp, x, y, outMB, chromaPred2);
/*     */     
/* 309 */     writeChroma(1, mbX, mbY, boolEnc, ac1, qp);
/* 310 */     writeChroma(2, mbX, mbY, boolEnc, ac2, qp);
/*     */     
/* 312 */     restorePlaneChroma(ac1, qp);
/* 313 */     putChroma(outMB.getData()[1], 1, x, y, ac1, chromaPred1);
/* 314 */     restorePlaneChroma(ac2, qp);
/* 315 */     putChroma(outMB.getData()[2], 2, x, y, ac2, chromaPred2);
/*     */   }
/*     */   
/*     */   private int[][] transformChroma(Picture pic, int comp, int qp, int x, int y, Picture outMB, int chromaPred) {
/* 319 */     int[][] ac = new int[4][16];
/*     */     
/* 321 */     for (int blk = 0; blk < ac.length; blk++) {
/*     */       
/* 323 */       int blkOffX = (blk & 0x1) << 2;
/* 324 */       int blkOffY = blk >> 1 << 2;
/* 325 */       takeSubtract(pic.getPlaneData(comp), pic.getPlaneWidth(comp), pic.getPlaneHeight(comp), x + blkOffX, y + blkOffY, ac[blk], chromaPred);
/*     */       
/* 327 */       VPXDCT.fdct4x4(ac[blk]);
/*     */     } 
/*     */     
/* 330 */     return ac;
/*     */   }
/*     */   
/*     */   private void putChroma(byte[] mb, int comp, int x, int y, int[][] ac, int chromaPred) {
/* 334 */     for (int blk = 0; blk < 4; blk++)
/* 335 */       putBlk(mb, chromaPred, ac[blk], 3, (blk & 0x1) << 2, blk >> 1 << 2); 
/*     */   }
/*     */   
/*     */   private final byte chromaPredOne(byte[] pix, int x) {
/* 339 */     return (byte)(pix[x] + pix[x + 1] + pix[x + 2] + pix[x + 3] + pix[x + 4] + pix[x + 5] + pix[x + 6] + pix[x + 7] + 4 >> 3);
/*     */   }
/*     */   
/*     */   private final byte chromaPredTwo(byte[] pix1, byte[] pix2, int x, int y) {
/* 343 */     return (byte)(pix1[x] + pix1[x + 1] + pix1[x + 2] + pix1[x + 3] + pix1[x + 4] + pix1[x + 5] + pix1[x + 6] + pix1[x + 7] + pix2[y] + pix2[y + 1] + pix2[y + 2] + pix2[y + 3] + pix2[y + 4] + pix2[y + 5] + pix2[y + 6] + pix2[y + 7] + 8 >> 4);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private byte chromaPredBlk(int comp, int x, int y) {
/* 349 */     int predY = y & 0x7;
/* 350 */     if (x != 0 && y != 0)
/* 351 */       return chromaPredTwo(this.leftRow[comp], this.topLine[comp], predY, x); 
/* 352 */     if (x != 0)
/* 353 */       return chromaPredOne(this.leftRow[comp], predY); 
/* 354 */     if (y != 0) {
/* 355 */       return chromaPredOne(this.topLine[comp], x);
/*     */     }
/* 357 */     return 0;
/*     */   }
/*     */   
/*     */   private void putLuma(byte[] planeData, int pred, int[][] ac, int log2stride) {
/* 361 */     for (int blk = 0; blk < ac.length; blk++) {
/* 362 */       int blkOffX = (blk & 0x3) << 2;
/* 363 */       int blkOffY = blk & 0xFFFFFFFC;
/* 364 */       putBlk(planeData, pred, ac[blk], log2stride, blkOffX, blkOffY);
/*     */     } 
/*     */   }
/*     */   
/*     */   private void putBlk(byte[] planeData, int pred, int[] block, int log2stride, int blkX, int blkY) {
/* 369 */     int stride = 1 << log2stride;
/* 370 */     for (int line = 0, srcOff = 0, dstOff = (blkY << log2stride) + blkX; line < 4; line++) {
/* 371 */       planeData[dstOff] = (byte)MathUtil.clip(block[srcOff] + pred, -128, 127);
/* 372 */       planeData[dstOff + 1] = (byte)MathUtil.clip(block[srcOff + 1] + pred, -128, 127);
/* 373 */       planeData[dstOff + 2] = (byte)MathUtil.clip(block[srcOff + 2] + pred, -128, 127);
/* 374 */       planeData[dstOff + 3] = (byte)MathUtil.clip(block[srcOff + 3] + pred, -128, 127);
/* 375 */       srcOff += 4;
/* 376 */       dstOff += stride;
/*     */     } 
/*     */   }
/*     */   
/*     */   private void restorePlaneChroma(int[][] ac, int qp) {
/* 381 */     for (int i = 0; i < 4; i++) {
/* 382 */       this.quantizer.dequantizeUV(ac[i], qp);
/* 383 */       VPXDCT.idct4x4(ac[i]);
/*     */     } 
/*     */   }
/*     */   
/*     */   private void restorePlaneLuma(int[] dc, int[][] ac, int qp) {
/* 388 */     this.quantizer.dequantizeY2(dc, qp);
/* 389 */     VPXDCT.iwalsh4x4(dc);
/* 390 */     for (int i = 0; i < 16; i++) {
/* 391 */       this.quantizer.dequantizeY(ac[i], qp);
/* 392 */       ac[i][0] = dc[i];
/* 393 */       VPXDCT.idct4x4(ac[i]);
/*     */     } 
/*     */   }
/*     */   
/*     */   private int[] extractDC(int[][] ac) {
/* 398 */     int[] dc = new int[ac.length];
/* 399 */     for (int i = 0; i < ac.length; i++) {
/* 400 */       dc[i] = ac[i][0];
/*     */     }
/* 402 */     return dc;
/*     */   }
/*     */   
/*     */   private byte lumaDCPred(int x, int y) {
/* 406 */     if (x == 0 && y == 0) {
/* 407 */       return 0;
/*     */     }
/* 409 */     if (y == 0)
/* 410 */       return (byte)(ArrayUtil.sumByte(this.leftRow[0]) + 8 >> 4); 
/* 411 */     if (x == 0) {
/* 412 */       return (byte)(ArrayUtil.sumByte3(this.topLine[0], x, 16) + 8 >> 4);
/*     */     }
/* 414 */     return (byte)(ArrayUtil.sumByte(this.leftRow[0]) + ArrayUtil.sumByte3(this.topLine[0], x, 16) + 16 >> 5);
/*     */   }
/*     */   
/*     */   private int[][] transform(Picture pic, int comp, int qp, int x, int y) {
/* 418 */     int dcc = lumaDCPred(x, y);
/*     */     
/* 420 */     int[][] ac = new int[16][16];
/* 421 */     for (int i = 0; i < ac.length; i++) {
/* 422 */       int[] coeff = ac[i];
/* 423 */       int blkOffX = (i & 0x3) << 2;
/* 424 */       int blkOffY = i & 0xFFFFFFFC;
/* 425 */       takeSubtract(pic.getPlaneData(comp), pic.getPlaneWidth(comp), pic.getPlaneHeight(comp), x + blkOffX, y + blkOffY, coeff, dcc);
/*     */       
/* 427 */       VPXDCT.fdct4x4(coeff);
/*     */     } 
/* 429 */     return ac;
/*     */   }
/*     */   
/*     */   private final void takeSubtract(byte[] planeData, int planeWidth, int planeHeight, int x, int y, int[] coeff, int dc) {
/* 433 */     if (x + 4 < planeWidth && y + 4 < planeHeight) {
/* 434 */       takeSubtractSafe(planeData, planeWidth, planeHeight, x, y, coeff, dc);
/*     */     } else {
/* 436 */       takeSubtractUnsafe(planeData, planeWidth, planeHeight, x, y, coeff, dc);
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   private final void takeSubtractSafe(byte[] planeData, int planeWidth, int planeHeight, int x, int y, int[] coeff, int dc) {
/* 442 */     for (int i = 0, srcOff = y * planeWidth + x, dstOff = 0; i < 4; i++, srcOff += planeWidth, dstOff += 4) {
/* 443 */       coeff[dstOff] = planeData[srcOff] - dc;
/* 444 */       coeff[dstOff + 1] = planeData[srcOff + 1] - dc;
/* 445 */       coeff[dstOff + 2] = planeData[srcOff + 2] - dc;
/* 446 */       coeff[dstOff + 3] = planeData[srcOff + 3] - dc;
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   private final void takeSubtractUnsafe(byte[] planeData, int planeWidth, int planeHeight, int x, int y, int[] coeff, int dc) {
/* 452 */     int outOff = 0;
/*     */     
/*     */     int i;
/* 455 */     for (i = y; i < Math.min(y + 4, planeHeight); i++) {
/* 456 */       int off = i * planeWidth + Math.min(x, planeWidth);
/*     */       int j;
/* 458 */       for (j = x; j < Math.min(x + 4, planeWidth); j++)
/* 459 */         coeff[outOff++] = planeData[off++] - dc; 
/* 460 */       off--;
/* 461 */       for (; j < x + 4; j++)
/* 462 */         coeff[outOff++] = planeData[off] - dc; 
/*     */     } 
/* 464 */     for (; i < y + 4; i++) {
/* 465 */       int off = planeHeight * planeWidth - planeWidth + Math.min(x, planeWidth);
/*     */       int j;
/* 467 */       for (j = x; j < Math.min(x + 4, planeWidth); j++)
/* 468 */         coeff[outOff++] = planeData[off++] - dc; 
/* 469 */       off--;
/* 470 */       for (; j < x + 4; j++) {
/* 471 */         coeff[outOff++] = planeData[off] - dc;
/*     */       }
/*     */     } 
/*     */   }
/*     */   
/*     */   public ColorSpace[] getSupportedColorSpaces() {
/* 477 */     return new ColorSpace[] { ColorSpace.YUV420J };
/*     */   }
/*     */ 
/*     */   
/*     */   public int estimateBufferSize(Picture frame) {
/* 482 */     return frame.getWidth() * frame.getHeight() / 2;
/*     */   }
/*     */ }


/* Location:              C:\Users\rapha\Downloads\aurora.jar!\META-INF\jars\jcodec-0.2.5.jar!\org\jcodec\codecs\vpx\VP8Encoder.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */