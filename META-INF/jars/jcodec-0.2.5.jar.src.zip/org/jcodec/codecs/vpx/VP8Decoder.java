/*     */ package org.jcodec.codecs.vpx;
/*     */ 
/*     */ import java.nio.ByteBuffer;
/*     */ import org.jcodec.common.Preconditions;
/*     */ import org.jcodec.common.UsedViaReflection;
/*     */ import org.jcodec.common.VideoCodecMeta;
/*     */ import org.jcodec.common.VideoDecoder;
/*     */ import org.jcodec.common.io.NIOUtils;
/*     */ import org.jcodec.common.model.ColorSpace;
/*     */ import org.jcodec.common.model.Picture;
/*     */ import org.jcodec.common.model.Size;
/*     */ import org.jcodec.common.tools.MathUtil;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class VP8Decoder
/*     */   extends VideoDecoder
/*     */ {
/*     */   private byte[][] segmentationMap;
/*  40 */   private int[] refLoopFilterDeltas = new int[4];
/*  41 */   private int[] modeLoopFilterDeltas = new int[4];
/*     */ 
/*     */ 
/*     */   
/*     */   public Picture decodeFrame(ByteBuffer frame, byte[][] buffer) {
/*  46 */     byte[] firstThree = new byte[3];
/*  47 */     frame.get(firstThree);
/*     */     
/*  49 */     boolean keyFrame = (VP8Util.getBitInBytes(firstThree, 0) == 0);
/*  50 */     if (!keyFrame)
/*  51 */       return null; 
/*  52 */     int version = VP8Util.getBitsInBytes(firstThree, 1, 3);
/*  53 */     boolean showFrame = (VP8Util.getBitInBytes(firstThree, 4) > 0);
/*  54 */     int partitionSize = VP8Util.getBitsInBytes(firstThree, 5, 19);
/*     */     
/*  56 */     String threeByteToken = printHexByte(frame.get()) + " " + printHexByte(frame.get()) + " " + printHexByte(frame.get());
/*     */     
/*  58 */     int twoBytesWidth = frame.get() & 0xFF | (frame.get() & 0xFF) << 8;
/*  59 */     int twoBytesHeight = frame.get() & 0xFF | (frame.get() & 0xFF) << 8;
/*  60 */     int width = twoBytesWidth & 0x3FFF;
/*  61 */     int height = twoBytesHeight & 0x3FFF;
/*  62 */     int numberOfMBRows = VP8Util.getMacroblockCount(height);
/*  63 */     int numberOfMBCols = VP8Util.getMacroblockCount(width);
/*     */ 
/*     */     
/*  66 */     if (this.segmentationMap == null)
/*  67 */       this.segmentationMap = new byte[numberOfMBRows][numberOfMBCols]; 
/*  68 */     VPXMacroblock[][] mbs = new VPXMacroblock[numberOfMBRows + 2][numberOfMBCols + 2];
/*  69 */     for (int row = 0; row < numberOfMBRows + 2; row++) {
/*  70 */       for (int col = 0; col < numberOfMBCols + 2; col++) {
/*  71 */         mbs[row][col] = new VPXMacroblock(row, col);
/*     */       }
/*     */     } 
/*     */     
/*  75 */     int headerOffset = frame.position();
/*  76 */     VPXBooleanDecoder headerDecoder = new VPXBooleanDecoder(frame, 0);
/*  77 */     boolean isYUVColorSpace = (headerDecoder.readBitEq() == 0);
/*     */     
/*  79 */     boolean clampingRequired = (headerDecoder.readBitEq() == 0);
/*  80 */     int segmentation = headerDecoder.readBitEq();
/*  81 */     SegmentBasedAdjustments segmentBased = null;
/*  82 */     if (segmentation != 0) {
/*  83 */       segmentBased = updateSegmentation(headerDecoder);
/*     */       
/*  85 */       for (int k = 0; k < numberOfMBRows; k++) {
/*  86 */         for (int col = 0; col < numberOfMBCols; col++) {
/*  87 */           (mbs[k + 1][col + 1]).segment = this.segmentationMap[k][col];
/*     */         }
/*     */       } 
/*     */     } 
/*  91 */     int simpleFilter = headerDecoder.readBitEq();
/*  92 */     int filterLevel = headerDecoder.decodeInt(6);
/*  93 */     int filterType = (filterLevel == 0) ? 0 : ((simpleFilter > 0) ? 1 : 2);
/*  94 */     int sharpnessLevel = headerDecoder.decodeInt(3);
/*  95 */     int loopFilterDeltaFlag = headerDecoder.readBitEq();
/*  96 */     if (loopFilterDeltaFlag == 1) {
/*  97 */       int loopFilterDeltaUpdate = headerDecoder.readBitEq();
/*  98 */       if (loopFilterDeltaUpdate == 1) {
/*  99 */         int k; for (k = 0; k < 4; k++) {
/*     */           
/* 101 */           if (headerDecoder.readBitEq() > 0) {
/* 102 */             this.refLoopFilterDeltas[k] = headerDecoder.decodeInt(6);
/*     */             
/* 104 */             if (headerDecoder.readBitEq() > 0)
/* 105 */               this.refLoopFilterDeltas[k] = this.refLoopFilterDeltas[k] * -1; 
/*     */           } 
/*     */         } 
/* 108 */         for (k = 0; k < 4; k++) {
/*     */           
/* 110 */           if (headerDecoder.readBitEq() > 0) {
/* 111 */             this.modeLoopFilterDeltas[k] = headerDecoder.decodeInt(6);
/* 112 */             if (headerDecoder.readBitEq() > 0)
/* 113 */               this.modeLoopFilterDeltas[k] = this.modeLoopFilterDeltas[k] * -1; 
/*     */           } 
/*     */         } 
/*     */       } 
/*     */     } 
/* 118 */     int log2OfPartCnt = headerDecoder.decodeInt(2);
/*     */     
/* 120 */     Preconditions.checkState((0 == log2OfPartCnt));
/* 121 */     int partitionsCount = 1;
/* 122 */     long runningSize = 0L;
/* 123 */     long zSize = (frame.limit() - partitionSize + headerOffset);
/* 124 */     ByteBuffer tokenBuffer = frame.duplicate();
/* 125 */     tokenBuffer.position(partitionSize + headerOffset);
/* 126 */     VPXBooleanDecoder decoder = new VPXBooleanDecoder(tokenBuffer, 0);
/*     */     
/* 128 */     int yacIndex = headerDecoder.decodeInt(7);
/* 129 */     int ydcDelta = (headerDecoder.readBitEq() > 0) ? VP8Util.delta(headerDecoder) : 0;
/* 130 */     int y2dcDelta = (headerDecoder.readBitEq() > 0) ? VP8Util.delta(headerDecoder) : 0;
/* 131 */     int y2acDelta = (headerDecoder.readBitEq() > 0) ? VP8Util.delta(headerDecoder) : 0;
/* 132 */     int chromaDCDelta = (headerDecoder.readBitEq() > 0) ? VP8Util.delta(headerDecoder) : 0;
/* 133 */     int chromaACDelta = (headerDecoder.readBitEq() > 0) ? VP8Util.delta(headerDecoder) : 0;
/* 134 */     boolean refreshProbs = (headerDecoder.readBitEq() == 0);
/* 135 */     VP8Util.QuantizationParams quants = new VP8Util.QuantizationParams(yacIndex, ydcDelta, y2dcDelta, y2acDelta, chromaDCDelta, chromaACDelta);
/*     */ 
/*     */     
/* 138 */     int[][][][] coefProbs = VP8Util.getDefaultCoefProbs();
/* 139 */     for (int i = 0; i < 4; i++) {
/* 140 */       for (int k = 0; k < 8; k++) {
/* 141 */         for (int m = 0; m < 3; m++) {
/* 142 */           for (int l = 0; l < 11; l++) {
/*     */             
/* 144 */             if (headerDecoder.readBit(VP8Util.vp8CoefUpdateProbs[i][k][m][l]) > 0)
/* 145 */             { int newp = headerDecoder.decodeInt(8);
/* 146 */               coefProbs[i][k][m][l] = newp; } 
/*     */           } 
/*     */         } 
/*     */       } 
/* 150 */     }  int macroBlockNoCoeffSkip = headerDecoder.readBitEq();
/* 151 */     Preconditions.checkState((1 == macroBlockNoCoeffSkip));
/* 152 */     int probSkipFalse = headerDecoder.decodeInt(8); int mbRow;
/* 153 */     for (mbRow = 0; mbRow < numberOfMBRows; mbRow++) {
/* 154 */       for (int mbCol = 0; mbCol < numberOfMBCols; mbCol++) {
/* 155 */         VPXMacroblock mb = mbs[mbRow + 1][mbCol + 1];
/* 156 */         if (segmentation != 0 && segmentBased != null && segmentBased.segmentProbs != null) {
/*     */           
/* 158 */           mb.segment = headerDecoder.readTree(VP8Util.segmentTree, segmentBased.segmentProbs);
/* 159 */           this.segmentationMap[mbRow][mbCol] = (byte)mb.segment;
/*     */         } 
/* 161 */         if (segmentation != 0 && segmentBased != null && segmentBased.qp != null) {
/* 162 */           int qIndex = yacIndex;
/* 163 */           if (segmentBased.abs != 0) {
/* 164 */             qIndex = segmentBased.qp[mb.segment];
/*     */           } else {
/* 166 */             qIndex += segmentBased.qp[mb.segment];
/* 167 */           }  quants = new VP8Util.QuantizationParams(qIndex, ydcDelta, y2dcDelta, y2acDelta, chromaDCDelta, chromaACDelta);
/*     */         } 
/*     */         
/* 170 */         mb.quants = quants;
/*     */ 
/*     */         
/* 173 */         if (loopFilterDeltaFlag != 0) {
/* 174 */           int level = filterLevel;
/* 175 */           level += this.refLoopFilterDeltas[0];
/* 176 */           level = MathUtil.clip(level, 0, 63);
/* 177 */           mb.filterLevel = level;
/*     */         } else {
/* 179 */           mb.filterLevel = filterLevel;
/*     */         } 
/*     */ 
/*     */         
/* 183 */         if (segmentation != 0 && segmentBased != null && segmentBased.lf != null) {
/* 184 */           if (segmentBased.abs != 0) {
/* 185 */             mb.filterLevel = segmentBased.lf[mb.segment];
/*     */           } else {
/* 187 */             mb.filterLevel += segmentBased.lf[mb.segment];
/* 188 */             mb.filterLevel = MathUtil.clip(mb.filterLevel, 0, 63);
/*     */           } 
/*     */         }
/*     */         
/* 192 */         if (macroBlockNoCoeffSkip > 0) {
/* 193 */           mb.skipCoeff = headerDecoder.readBit(probSkipFalse);
/*     */         }
/* 195 */         mb.lumaMode = headerDecoder.readTree(VP8Util.keyFrameYModeTree, VP8Util.keyFrameYModeProb);
/*     */ 
/*     */         
/* 198 */         if (mb.lumaMode == 4) {
/* 199 */           for (int sbRow = 0; sbRow < 4; sbRow++) {
/* 200 */             for (int sbCol = 0; sbCol < 4; sbCol++) {
/*     */               
/* 202 */               VPXMacroblock.Subblock sb = mb.ySubblocks[sbRow][sbCol];
/* 203 */               VPXMacroblock.Subblock A = sb.getAbove(VP8Util.PLANE.Y1, mbs);
/*     */               
/* 205 */               VPXMacroblock.Subblock L = sb.getLeft(VP8Util.PLANE.Y1, mbs);
/*     */               
/* 207 */               sb.mode = headerDecoder.readTree(VP8Util.SubblockConstants.subblockModeTree, VP8Util.SubblockConstants.keyFrameSubblockModeProb[A.mode][L.mode]);
/*     */             } 
/*     */           } 
/*     */         } else {
/*     */           int fixedMode;
/*     */ 
/*     */ 
/*     */ 
/*     */           
/* 216 */           switch (mb.lumaMode) {
/*     */             case 0:
/* 218 */               fixedMode = 0;
/*     */               break;
/*     */             case 1:
/* 221 */               fixedMode = 2;
/*     */               break;
/*     */             case 2:
/* 224 */               fixedMode = 3;
/*     */               break;
/*     */             case 3:
/* 227 */               fixedMode = 1;
/*     */               break;
/*     */             default:
/* 230 */               fixedMode = 0;
/*     */               break;
/*     */           } 
/* 233 */           mb.lumaMode = edgeEmu(mb.lumaMode, mbCol, mbRow);
/* 234 */           for (int x = 0; x < 4; x++) {
/* 235 */             for (int y = 0; y < 4; y++)
/* 236 */               (mb.ySubblocks[y][x]).mode = fixedMode; 
/*     */           } 
/* 238 */         }  mb.chromaMode = headerDecoder.readTree(VP8Util.vp8UVModeTree, VP8Util.vp8KeyFrameUVModeProb);
/*     */       } 
/*     */     } 
/*     */     
/* 242 */     for (mbRow = 0; mbRow < numberOfMBRows; mbRow++) {
/* 243 */       for (int mbCol = 0; mbCol < numberOfMBCols; mbCol++) {
/* 244 */         VPXMacroblock mb = mbs[mbRow + 1][mbCol + 1];
/* 245 */         mb.decodeMacroBlock(mbs, decoder, coefProbs);
/* 246 */         mb.dequantMacroBlock(mbs);
/*     */       } 
/*     */     } 
/*     */     
/* 250 */     if (filterType > 0 && filterLevel != 0) {
/* 251 */       if (filterType == 2) {
/* 252 */         FilterUtil.loopFilterUV(mbs, sharpnessLevel, keyFrame);
/* 253 */         FilterUtil.loopFilterY(mbs, sharpnessLevel, keyFrame);
/* 254 */       } else if (filterType == 1) {
/*     */       
/*     */       } 
/*     */     }
/*     */     
/* 259 */     Picture p = Picture.createPicture(width, height, buffer, ColorSpace.YUV420);
/*     */     
/* 261 */     int mbWidth = VP8Util.getMacroblockCount(width);
/* 262 */     int mbHeight = VP8Util.getMacroblockCount(height);
/*     */     
/* 264 */     for (int j = 0; j < mbHeight; j++) {
/* 265 */       for (int mbCol = 0; mbCol < mbWidth; mbCol++) {
/* 266 */         VPXMacroblock mb = mbs[j + 1][mbCol + 1];
/* 267 */         mb.put(j, mbCol, p);
/*     */       } 
/*     */     } 
/* 270 */     return p;
/*     */   }
/*     */   
/*     */   private int edgeEmu(int mode, int mbCol, int mbRow) {
/* 274 */     switch (mode) {
/*     */       case 1:
/* 276 */         return (mbRow == 0) ? 0 : mode;
/*     */       case 2:
/* 278 */         return (mbCol == 0) ? 0 : mode;
/*     */       case 3:
/* 280 */         return edgeEmuTm(mode, mbCol, mbRow);
/*     */     } 
/* 282 */     return mode;
/*     */   }
/*     */ 
/*     */   
/*     */   private int edgeEmuTm(int mode, int mbCol, int mbRow) {
/* 287 */     if (mbCol == 0) {
/* 288 */       return (mbRow != 0) ? 1 : 0;
/*     */     }
/* 290 */     return (mbRow != 0) ? mode : 2;
/*     */   }
/*     */   
/*     */   private static class SegmentBasedAdjustments {
/*     */     private int[] segmentProbs;
/*     */     private int[] qp;
/*     */     private int[] lf;
/*     */     private int abs;
/*     */     
/*     */     public SegmentBasedAdjustments(int[] segmentProbs, int[] qp, int[] lf, int abs) {
/* 300 */       this.segmentProbs = segmentProbs;
/* 301 */       this.qp = qp;
/* 302 */       this.lf = lf;
/* 303 */       this.abs = abs;
/*     */     }
/*     */   }
/*     */   
/*     */   private SegmentBasedAdjustments updateSegmentation(VPXBooleanDecoder headerDecoder) {
/* 308 */     int updateMBSegmentationMap = headerDecoder.readBitEq();
/* 309 */     int updateSegmentFeatureData = headerDecoder.readBitEq();
/*     */     
/* 311 */     int[] qp = null;
/* 312 */     int[] lf = null;
/* 313 */     int abs = 0;
/* 314 */     if (updateSegmentFeatureData != 0) {
/* 315 */       qp = new int[4];
/* 316 */       lf = new int[4];
/* 317 */       abs = headerDecoder.readBitEq(); int i;
/* 318 */       for (i = 0; i < 4; i++) {
/* 319 */         int quantizerUpdate = headerDecoder.readBitEq();
/* 320 */         if (quantizerUpdate != 0) {
/* 321 */           qp[i] = headerDecoder.decodeInt(7);
/* 322 */           qp[i] = (headerDecoder.readBitEq() != 0) ? -qp[i] : qp[i];
/*     */         } 
/*     */       } 
/* 325 */       for (i = 0; i < 4; i++) {
/* 326 */         int loopFilterUpdate = headerDecoder.readBitEq();
/* 327 */         if (loopFilterUpdate != 0) {
/* 328 */           lf[i] = headerDecoder.decodeInt(6);
/* 329 */           lf[i] = (headerDecoder.readBitEq() != 0) ? -lf[i] : lf[i];
/*     */         } 
/*     */       } 
/*     */     } 
/* 333 */     int[] segmentProbs = new int[3];
/* 334 */     if (updateMBSegmentationMap != 0)
/* 335 */       for (int i = 0; i < 3; i++) {
/* 336 */         int segmentProbUpdate = headerDecoder.readBitEq();
/* 337 */         if (segmentProbUpdate != 0) {
/* 338 */           segmentProbs[i] = headerDecoder.decodeInt(8);
/*     */         } else {
/* 340 */           segmentProbs[i] = 255;
/*     */         } 
/*     */       }  
/* 343 */     return new SegmentBasedAdjustments(segmentProbs, qp, lf, abs);
/*     */   }
/*     */   
/*     */   @UsedViaReflection
/*     */   public static int probe(ByteBuffer data) {
/* 348 */     if ((data.get(3) & 0xFF) == 157 && (data.get(4) & 0xFF) == 1 && (data.get(5) & 0xFF) == 42)
/* 349 */       return 100; 
/* 350 */     return 0;
/*     */   }
/*     */   
/*     */   public static String printHexByte(byte b) {
/* 354 */     return "0x" + Integer.toHexString(b & 0xFF);
/*     */   }
/*     */ 
/*     */   
/*     */   public VideoCodecMeta getCodecMeta(ByteBuffer frame) {
/* 359 */     NIOUtils.skip(frame, 6);
/*     */     
/* 361 */     int twoBytesWidth = frame.get() & 0xFF | (frame.get() & 0xFF) << 8;
/* 362 */     int twoBytesHeight = frame.get() & 0xFF | (frame.get() & 0xFF) << 8;
/* 363 */     int width = twoBytesWidth & 0x3FFF;
/* 364 */     int height = twoBytesHeight & 0x3FFF;
/*     */     
/* 366 */     return VideoCodecMeta.createSimpleVideoCodecMeta(new Size(width, height), ColorSpace.YUV420);
/*     */   }
/*     */ }


/* Location:              C:\Users\rapha\Downloads\aurora.jar!\META-INF\jars\jcodec-0.2.5.jar!\org\jcodec\codecs\vpx\VP8Decoder.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */