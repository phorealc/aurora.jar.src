/*     */ package org.jcodec.codecs.vpx;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class VP8DCT
/*     */ {
/*     */   private static final int cospi8sqrt2minus1 = 20091;
/*     */   private static final int sinpi8sqrt2 = 35468;
/*     */   
/*     */   public static int[] decodeDCT(int[] input) {
/*  26 */     int offset = 0;
/*     */     
/*  28 */     int[] output = new int[16];
/*     */     
/*     */     int i;
/*  31 */     for (i = 0; i < 4; i++) {
/*  32 */       int a1 = input[offset + 0] + input[offset + 8];
/*  33 */       int b1 = input[offset + 0] - input[offset + 8];
/*     */       
/*  35 */       int temp1 = input[offset + 4] * 35468 >> 16;
/*  36 */       int temp2 = input[offset + 12] + (input[offset + 12] * 20091 >> 16);
/*     */ 
/*     */       
/*  39 */       int c1 = temp1 - temp2;
/*     */       
/*  41 */       temp1 = input[offset + 4] + (input[offset + 4] * 20091 >> 16);
/*     */       
/*  43 */       temp2 = input[offset + 12] * 35468 >> 16;
/*  44 */       int d1 = temp1 + temp2;
/*     */       
/*  46 */       output[offset + 0] = a1 + d1;
/*  47 */       output[offset + 12] = a1 - d1;
/*  48 */       output[offset + 4] = b1 + c1;
/*  49 */       output[offset + 8] = b1 - c1;
/*     */       
/*  51 */       offset++;
/*     */     } 
/*     */     
/*  54 */     offset = 0;
/*  55 */     for (i = 0; i < 4; i++) {
/*  56 */       int a1 = output[offset * 4 + 0] + output[offset * 4 + 2];
/*  57 */       int b1 = output[offset * 4 + 0] - output[offset * 4 + 2];
/*     */       
/*  59 */       int temp1 = output[offset * 4 + 1] * 35468 >> 16;
/*  60 */       int temp2 = output[offset * 4 + 3] + (output[offset * 4 + 3] * 20091 >> 16);
/*     */       
/*  62 */       int c1 = temp1 - temp2;
/*     */       
/*  64 */       temp1 = output[offset * 4 + 1] + (output[offset * 4 + 1] * 20091 >> 16);
/*     */       
/*  66 */       temp2 = output[offset * 4 + 3] * 35468 >> 16;
/*  67 */       int d1 = temp1 + temp2;
/*     */       
/*  69 */       output[offset * 4 + 0] = a1 + d1 + 4 >> 3;
/*  70 */       output[offset * 4 + 3] = a1 - d1 + 4 >> 3;
/*  71 */       output[offset * 4 + 1] = b1 + c1 + 4 >> 3;
/*  72 */       output[offset * 4 + 2] = b1 - c1 + 4 >> 3;
/*     */       
/*  74 */       offset++;
/*     */     } 
/*     */     
/*  77 */     return output;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static int[] encodeDCT(int[] input) {
/*  84 */     int ip = 0;
/*  85 */     int[] output = new int[input.length];
/*  86 */     int op = 0;
/*     */     int i;
/*  88 */     for (i = 0; i < 4; i++) {
/*  89 */       int a1 = input[ip + 0] + input[ip + 3] << 3;
/*  90 */       int b1 = input[ip + 1] + input[ip + 2] << 3;
/*  91 */       int c1 = input[ip + 1] - input[ip + 2] << 3;
/*  92 */       int d1 = input[ip + 0] - input[ip + 3] << 3;
/*     */       
/*  94 */       output[op + 0] = a1 + b1;
/*  95 */       output[op + 2] = a1 - b1;
/*     */       
/*  97 */       output[op + 1] = c1 * 2217 + d1 * 5352 + 14500 >> 12;
/*  98 */       output[op + 3] = d1 * 2217 - c1 * 5352 + 7500 >> 12;
/*     */       
/* 100 */       ip += 4;
/* 101 */       op += 4;
/*     */     } 
/*     */     
/* 104 */     ip = 0;
/* 105 */     op = 0;
/* 106 */     for (i = 0; i < 4; i++) {
/* 107 */       int a1 = output[ip + 0] + output[ip + 12];
/* 108 */       int b1 = output[ip + 4] + output[ip + 8];
/* 109 */       int c1 = output[ip + 4] - output[ip + 8];
/* 110 */       int d1 = output[ip + 0] - output[ip + 12];
/*     */       
/* 112 */       output[op + 0] = a1 + b1 + 7 >> 4;
/* 113 */       output[op + 8] = a1 - b1 + 7 >> 4;
/*     */       
/* 115 */       output[op + 4] = (c1 * 2217 + d1 * 5352 + 12000 >> 16) + ((d1 != 0) ? 1 : 0);
/* 116 */       output[op + 12] = d1 * 2217 - c1 * 5352 + 51000 >> 16;
/*     */       
/* 118 */       ip++;
/* 119 */       op++;
/*     */     } 
/* 121 */     return output;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static int[] decodeWHT(int[] input) {
/* 129 */     int[] output = new int[16];
/* 130 */     int[][] diff = new int[4][4];
/* 131 */     int offset = 0; int i;
/* 132 */     for (i = 0; i < 4; i++) {
/* 133 */       int a1 = input[offset + 0] + input[offset + 12];
/* 134 */       int b1 = input[offset + 4] + input[offset + 8];
/* 135 */       int c1 = input[offset + 4] - input[offset + 8];
/* 136 */       int d1 = input[offset + 0] - input[offset + 12];
/*     */       
/* 138 */       output[offset + 0] = a1 + b1;
/* 139 */       output[offset + 4] = c1 + d1;
/* 140 */       output[offset + 8] = a1 - b1;
/* 141 */       output[offset + 12] = d1 - c1;
/* 142 */       offset++;
/*     */     } 
/*     */     
/* 145 */     offset = 0;
/*     */     
/* 147 */     for (i = 0; i < 4; i++) {
/* 148 */       int a1 = output[offset + 0] + output[offset + 3];
/* 149 */       int b1 = output[offset + 1] + output[offset + 2];
/* 150 */       int c1 = output[offset + 1] - output[offset + 2];
/* 151 */       int d1 = output[offset + 0] - output[offset + 3];
/*     */       
/* 153 */       int a2 = a1 + b1;
/* 154 */       int b2 = c1 + d1;
/* 155 */       int c2 = a1 - b1;
/* 156 */       int d2 = d1 - c1;
/* 157 */       output[offset + 0] = a2 + 3 >> 3;
/* 158 */       output[offset + 1] = b2 + 3 >> 3;
/* 159 */       output[offset + 2] = c2 + 3 >> 3;
/* 160 */       output[offset + 3] = d2 + 3 >> 3;
/* 161 */       diff[0][i] = a2 + 3 >> 3;
/* 162 */       diff[1][i] = b2 + 3 >> 3;
/* 163 */       diff[2][i] = c2 + 3 >> 3;
/* 164 */       diff[3][i] = d2 + 3 >> 3;
/* 165 */       offset += 4;
/*     */     } 
/*     */     
/* 168 */     return output;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static int[] encodeWHT(int[] input) {
/* 176 */     int inputOffset = 0;
/* 177 */     int outputOffset = 0;
/* 178 */     int[] output = new int[input.length];
/*     */     
/*     */     int i;
/* 181 */     for (i = 0; i < 4; i++) {
/*     */ 
/*     */ 
/*     */       
/* 185 */       int a1 = input[inputOffset + 0] + input[inputOffset + 2] << 2;
/* 186 */       int d1 = input[inputOffset + 1] + input[inputOffset + 3] << 2;
/* 187 */       int c1 = input[inputOffset + 1] - input[inputOffset + 3] << 2;
/* 188 */       int b1 = input[inputOffset + 0] - input[inputOffset + 2] << 2;
/*     */       
/* 190 */       output[outputOffset + 0] = a1 + d1 + ((a1 != 0) ? 1 : 0);
/* 191 */       output[outputOffset + 1] = b1 + c1;
/* 192 */       output[outputOffset + 2] = b1 - c1;
/* 193 */       output[outputOffset + 3] = a1 - d1;
/* 194 */       inputOffset += 4;
/* 195 */       outputOffset += 4;
/*     */     } 
/*     */     
/* 198 */     inputOffset = 0;
/* 199 */     outputOffset = 0;
/*     */     
/* 201 */     for (i = 0; i < 4; i++) {
/* 202 */       int a1 = output[inputOffset + 0] + output[inputOffset + 8];
/* 203 */       int d1 = output[inputOffset + 4] + output[inputOffset + 12];
/* 204 */       int c1 = output[inputOffset + 4] - output[inputOffset + 12];
/* 205 */       int b1 = output[inputOffset + 0] - output[inputOffset + 8];
/*     */       
/* 207 */       int a2 = a1 + d1;
/* 208 */       int b2 = b1 + c1;
/* 209 */       int c2 = b1 - c1;
/* 210 */       int d2 = a1 - d1;
/*     */       
/* 212 */       a2 += (a2 < 0) ? 1 : 0;
/* 213 */       b2 += (b2 < 0) ? 1 : 0;
/* 214 */       c2 += (c2 < 0) ? 1 : 0;
/* 215 */       d2 += (d2 < 0) ? 1 : 0;
/*     */       
/* 217 */       output[outputOffset + 0] = a2 + 3 >> 3;
/* 218 */       output[outputOffset + 4] = b2 + 3 >> 3;
/* 219 */       output[outputOffset + 8] = c2 + 3 >> 3;
/* 220 */       output[outputOffset + 12] = d2 + 3 >> 3;
/*     */       
/* 222 */       inputOffset++;
/* 223 */       outputOffset++;
/*     */     } 
/* 225 */     return output;
/*     */   }
/*     */ }


/* Location:              C:\Users\rapha\Downloads\aurora.jar!\META-INF\jars\jcodec-0.2.5.jar!\org\jcodec\codecs\vpx\VP8DCT.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */