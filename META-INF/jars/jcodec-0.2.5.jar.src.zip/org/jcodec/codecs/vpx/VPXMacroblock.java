/*     */ package org.jcodec.codecs.vpx;
/*     */ 
/*     */ import java.util.Arrays;
/*     */ import org.jcodec.api.NotImplementedException;
/*     */ import org.jcodec.api.NotSupportedException;
/*     */ import org.jcodec.common.model.Picture;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class VPXMacroblock
/*     */ {
/*     */   public int filterLevel;
/*     */   public int chromaMode;
/*     */   public int skipCoeff;
/*     */   public final Subblock[][] ySubblocks;
/*     */   public final Subblock y2;
/*     */   public final Subblock[][] uSubblocks;
/*     */   public final Subblock[][] vSubblocks;
/*     */   public final int Rrow;
/*     */   public final int column;
/*     */   public int lumaMode;
/*     */   boolean skipFilter;
/*  34 */   public int segment = 0;
/*     */   public boolean debug = true;
/*     */   public VP8Util.QuantizationParams quants;
/*     */   
/*     */   public VPXMacroblock(int y, int x) {
/*  39 */     this.ySubblocks = new Subblock[4][4];
/*  40 */     this.y2 = new Subblock(this, 0, 0, VP8Util.PLANE.Y2);
/*  41 */     this.uSubblocks = new Subblock[2][2];
/*  42 */     this.vSubblocks = new Subblock[2][2];
/*     */     
/*  44 */     this.Rrow = y;
/*  45 */     this.column = x; int row;
/*  46 */     for (row = 0; row < 4; row++) {
/*  47 */       for (int col = 0; col < 4; col++)
/*  48 */         this.ySubblocks[row][col] = new Subblock(this, row, col, VP8Util.PLANE.Y1); 
/*  49 */     }  for (row = 0; row < 2; row++) {
/*  50 */       for (int col = 0; col < 2; col++) {
/*  51 */         this.uSubblocks[row][col] = new Subblock(this, row, col, VP8Util.PLANE.U);
/*  52 */         this.vSubblocks[row][col] = new Subblock(this, row, col, VP8Util.PLANE.V);
/*     */       } 
/*     */     } 
/*     */   }
/*     */   public void dequantMacroBlock(VPXMacroblock[][] mbs) {
/*  57 */     VP8Util.QuantizationParams p = this.quants;
/*  58 */     if (this.lumaMode != 4) {
/*  59 */       int acQValue = p.y2AC;
/*  60 */       int dcQValue = p.y2DC;
/*     */       
/*  62 */       int[] input = new int[16];
/*  63 */       input[0] = this.y2.tokens[0] * dcQValue;
/*     */       
/*  65 */       for (int x = 1; x < 16; x++) {
/*  66 */         input[x] = this.y2.tokens[x] * acQValue;
/*     */       }
/*     */ 
/*     */ 
/*     */       
/*  71 */       this.y2.residue = VP8DCT.decodeWHT(input); int row;
/*  72 */       for (row = 0; row < 4; row++) {
/*  73 */         for (int col = 0; col < 4; col++)
/*  74 */           this.ySubblocks[row][col].dequantSubblock(p.yDC, p.yAC, Integer.valueOf(this.y2.residue[row * 4 + col])); 
/*     */       } 
/*  76 */       predictY(mbs);
/*  77 */       predictUV(mbs);
/*  78 */       for (row = 0; row < 2; row++) {
/*  79 */         for (int col = 0; col < 2; col++) {
/*  80 */           this.uSubblocks[row][col].dequantSubblock(p.chromaDC, p.chromaAC, null);
/*  81 */           this.vSubblocks[row][col].dequantSubblock(p.chromaDC, p.chromaAC, null);
/*     */         } 
/*     */       } 
/*  84 */       reconstruct();
/*     */     } else {
/*     */       int row;
/*  87 */       for (row = 0; row < 4; row++) {
/*  88 */         for (int col = 0; col < 4; col++) {
/*  89 */           Subblock sb = this.ySubblocks[row][col];
/*  90 */           sb.dequantSubblock(p.yDC, p.yAC, null);
/*  91 */           sb.predict(mbs);
/*  92 */           sb.reconstruct();
/*     */         } 
/*     */       } 
/*  95 */       predictUV(mbs);
/*  96 */       for (row = 0; row < 2; row++) {
/*  97 */         for (int col = 0; col < 2; col++) {
/*  98 */           Subblock sb = this.uSubblocks[row][col];
/*  99 */           sb.dequantSubblock(p.chromaDC, p.chromaAC, null);
/* 100 */           sb.reconstruct();
/*     */         } 
/*     */       } 
/* 103 */       for (row = 0; row < 2; row++) {
/* 104 */         for (int col = 0; col < 2; col++) {
/* 105 */           Subblock sb = this.vSubblocks[row][col];
/* 106 */           sb.dequantSubblock(p.chromaDC, p.chromaAC, null);
/* 107 */           sb.reconstruct();
/*     */         } 
/*     */       } 
/*     */     } 
/*     */   }
/*     */   
/*     */   public void reconstruct() {
/*     */     int row;
/* 115 */     for (row = 0; row < 4; row++) {
/* 116 */       for (int col = 0; col < 4; col++) {
/* 117 */         this.ySubblocks[row][col].reconstruct();
/*     */       }
/*     */     } 
/* 120 */     for (row = 0; row < 2; row++) {
/* 121 */       for (int col = 0; col < 2; col++)
/* 122 */         this.uSubblocks[row][col].reconstruct(); 
/*     */     } 
/* 124 */     for (row = 0; row < 2; row++) {
/* 125 */       for (int col = 0; col < 2; col++)
/* 126 */         this.vSubblocks[row][col].reconstruct(); 
/*     */     }  } public void predictUV(VPXMacroblock[][] mbs) { boolean up_available, left_available; int uAvg, vAvg, expected_udc, expected_vdc, ufill[], aRow, vfill[], i; Subblock[] aboveUSb, aboveVSb; int aCol, j; Subblock[] leftUSb, leftVSb; int m, k; VPXMacroblock ALMb;
/*     */     Subblock ALUSb;
/*     */     int alu;
/*     */     Subblock ALVSb;
/*     */     int alv, x, sbRow;
/* 132 */     VPXMacroblock aboveMb = mbs[this.Rrow - 1][this.column];
/* 133 */     VPXMacroblock leftMb = mbs[this.Rrow][this.column - 1];
/*     */     
/* 135 */     switch (this.chromaMode) {
/*     */ 
/*     */       
/*     */       case 0:
/* 139 */         up_available = false;
/* 140 */         left_available = false;
/* 141 */         uAvg = 0;
/* 142 */         vAvg = 0;
/* 143 */         expected_udc = 128;
/* 144 */         expected_vdc = 128;
/* 145 */         if (this.column > 1)
/* 146 */           left_available = true; 
/* 147 */         if (this.Rrow > 1)
/* 148 */           up_available = true; 
/* 149 */         if (up_available || left_available) {
/* 150 */           if (up_available) {
/* 151 */             for (int n = 0; n < 2; n++) {
/* 152 */               Subblock usb = aboveMb.uSubblocks[1][n];
/* 153 */               Subblock vsb = aboveMb.vSubblocks[1][n];
/* 154 */               for (int i1 = 0; i1 < 4; i1++) {
/* 155 */                 uAvg += usb.val[12 + i1];
/* 156 */                 vAvg += vsb.val[12 + i1];
/*     */               } 
/*     */             } 
/*     */           }
/*     */           
/* 161 */           if (left_available) {
/* 162 */             for (int n = 0; n < 2; n++) {
/* 163 */               Subblock usb = leftMb.uSubblocks[n][1];
/* 164 */               Subblock vsb = leftMb.vSubblocks[n][1];
/* 165 */               for (int i1 = 0; i1 < 4; i1++) {
/* 166 */                 uAvg += usb.val[i1 * 4 + 3];
/* 167 */                 vAvg += vsb.val[i1 * 4 + 3];
/*     */               } 
/*     */             } 
/*     */           }
/*     */           
/* 172 */           int shift = 2;
/* 173 */           if (up_available)
/* 174 */             shift++; 
/* 175 */           if (left_available) {
/* 176 */             shift++;
/*     */           }
/* 178 */           expected_udc = uAvg + (1 << shift - 1) >> shift;
/* 179 */           expected_vdc = vAvg + (1 << shift - 1) >> shift;
/*     */         } 
/*     */         
/* 182 */         ufill = new int[16];
/* 183 */         for (aRow = 0; aRow < 4; aRow++) {
/* 184 */           for (int n = 0; n < 4; n++)
/* 185 */             ufill[aRow * 4 + n] = expected_udc; 
/*     */         } 
/* 187 */         vfill = new int[16];
/* 188 */         for (i = 0; i < 4; i++) {
/* 189 */           for (int n = 0; n < 4; n++)
/* 190 */             vfill[i * 4 + n] = expected_vdc; 
/*     */         } 
/* 192 */         for (i = 0; i < 2; i++) {
/* 193 */           for (int n = 0; n < 2; n++) {
/* 194 */             Subblock usb = this.uSubblocks[i][n];
/* 195 */             Subblock vsb = this.vSubblocks[i][n];
/* 196 */             usb._predict = ufill;
/* 197 */             vsb._predict = vfill;
/*     */           } 
/*     */         } 
/*     */         return;
/*     */ 
/*     */ 
/*     */       
/*     */       case 1:
/* 205 */         aboveUSb = new Subblock[2];
/* 206 */         aboveVSb = new Subblock[2];
/* 207 */         for (aCol = 0; aCol < 2; aCol++) {
/* 208 */           aboveUSb[aCol] = aboveMb.uSubblocks[1][aCol];
/* 209 */           aboveVSb[aCol] = aboveMb.vSubblocks[1][aCol];
/*     */         } 
/*     */         
/* 212 */         for (j = 0; j < 2; j++) {
/* 213 */           for (int n = 0; n < 2; n++) {
/* 214 */             Subblock usb = this.uSubblocks[j][n];
/* 215 */             Subblock vsb = this.vSubblocks[j][n];
/* 216 */             int[] ublock = new int[16];
/* 217 */             int[] vblock = new int[16];
/* 218 */             for (int pRow = 0; pRow < 4; pRow++) {
/*     */               
/* 220 */               for (int pCol = 0; pCol < 4; pCol++) {
/* 221 */                 ublock[pRow * 4 + pCol] = ((aboveUSb[n]).val != null) ? (aboveUSb[n]).val[12 + pCol] : 127;
/* 222 */                 vblock[pRow * 4 + pCol] = ((aboveVSb[n]).val != null) ? (aboveVSb[n]).val[12 + pCol] : 127;
/*     */               } 
/* 224 */             }  usb._predict = ublock;
/* 225 */             vsb._predict = vblock;
/*     */           } 
/*     */         } 
/*     */         return;
/*     */ 
/*     */ 
/*     */       
/*     */       case 2:
/* 233 */         leftUSb = new Subblock[2];
/* 234 */         leftVSb = new Subblock[2];
/* 235 */         for (m = 0; m < 2; m++) {
/* 236 */           leftUSb[m] = leftMb.uSubblocks[m][1];
/* 237 */           leftVSb[m] = leftMb.vSubblocks[m][1];
/*     */         } 
/*     */         
/* 240 */         for (k = 0; k < 2; k++) {
/* 241 */           for (int n = 0; n < 2; n++) {
/* 242 */             Subblock usb = this.uSubblocks[k][n];
/* 243 */             Subblock vsb = this.vSubblocks[k][n];
/* 244 */             int[] ublock = new int[16];
/* 245 */             int[] vblock = new int[16];
/* 246 */             for (int pRow = 0; pRow < 4; pRow++) {
/* 247 */               for (int pCol = 0; pCol < 4; pCol++) {
/* 248 */                 ublock[pRow * 4 + pCol] = ((leftUSb[k]).val != null) ? (leftUSb[k]).val[pRow * 4 + 3] : 129;
/* 249 */                 vblock[pRow * 4 + pCol] = ((leftVSb[k]).val != null) ? (leftVSb[k]).val[pRow * 4 + 3] : 129;
/*     */               } 
/* 251 */             }  usb._predict = ublock;
/* 252 */             vsb._predict = vblock;
/*     */           } 
/*     */         } 
/*     */         return;
/*     */ 
/*     */       
/*     */       case 3:
/* 259 */         ALMb = mbs[this.Rrow - 1][this.column - 1];
/* 260 */         ALUSb = ALMb.uSubblocks[1][1];
/* 261 */         alu = ALUSb.val[15];
/* 262 */         ALVSb = ALMb.vSubblocks[1][1];
/* 263 */         alv = ALVSb.val[15];
/*     */         
/* 265 */         aboveUSb = new Subblock[2];
/* 266 */         leftUSb = new Subblock[2];
/* 267 */         aboveVSb = new Subblock[2];
/* 268 */         leftVSb = new Subblock[2];
/* 269 */         for (x = 0; x < 2; x++) {
/* 270 */           aboveUSb[x] = aboveMb.uSubblocks[1][x];
/* 271 */           leftUSb[x] = leftMb.uSubblocks[x][1];
/* 272 */           aboveVSb[x] = aboveMb.vSubblocks[1][x];
/* 273 */           leftVSb[x] = leftMb.vSubblocks[x][1];
/*     */         } 
/*     */         
/* 276 */         for (sbRow = 0; sbRow < 2; sbRow++) {
/* 277 */           for (int pRow = 0; pRow < 4; pRow++) {
/* 278 */             for (int sbCol = 0; sbCol < 2; sbCol++) {
/* 279 */               if ((this.uSubblocks[sbRow][sbCol]).val == null)
/* 280 */                 (this.uSubblocks[sbRow][sbCol]).val = new int[16]; 
/* 281 */               if ((this.vSubblocks[sbRow][sbCol]).val == null)
/* 282 */                 (this.vSubblocks[sbRow][sbCol]).val = new int[16]; 
/* 283 */               for (int pCol = 0; pCol < 4; pCol++) {
/*     */                 
/* 285 */                 int upred = (leftUSb[sbRow]).val[pRow * 4 + 3] + (aboveUSb[sbCol]).val[12 + pCol] - alu;
/* 286 */                 upred = VP8Util.QuantizationParams.clip255(upred);
/* 287 */                 (this.uSubblocks[sbRow][sbCol]).val[pRow * 4 + pCol] = upred;
/*     */                 
/* 289 */                 int vpred = (leftVSb[sbRow]).val[pRow * 4 + 3] + (aboveVSb[sbCol]).val[12 + pCol] - alv;
/* 290 */                 vpred = VP8Util.QuantizationParams.clip255(vpred);
/* 291 */                 (this.vSubblocks[sbRow][sbCol]).val[pRow * 4 + pCol] = vpred;
/*     */               } 
/*     */             } 
/*     */           } 
/*     */         } 
/*     */         return;
/*     */     } 
/*     */ 
/*     */ 
/*     */     
/* 301 */     System.err.println("TODO predict_mb_uv: " + this.lumaMode);
/* 302 */     System.exit(0); }
/*     */    private void predictY(VPXMacroblock[][] mbs) {
/*     */     VPXMacroblock upperLeft;
/*     */     Subblock ALSb;
/*     */     int aboveLeft;
/* 307 */     VPXMacroblock aboveMb = mbs[this.Rrow - 1][this.column];
/* 308 */     VPXMacroblock leftMb = mbs[this.Rrow][this.column - 1];
/*     */     
/* 310 */     switch (this.lumaMode) {
/*     */       case 0:
/* 312 */         predictLumaDC(aboveMb, leftMb);
/*     */         return;
/*     */       
/*     */       case 1:
/* 316 */         predictLumaV(aboveMb);
/*     */         return;
/*     */       
/*     */       case 2:
/* 320 */         predictLumaH(leftMb);
/*     */         return;
/*     */       
/*     */       case 3:
/* 324 */         upperLeft = mbs[this.Rrow - 1][this.column - 1];
/* 325 */         ALSb = upperLeft.ySubblocks[3][3];
/* 326 */         aboveLeft = ALSb.val[15];
/* 327 */         predictLumaTM(aboveMb, leftMb, aboveLeft);
/*     */         return;
/*     */     } 
/*     */     
/* 331 */     System.err.println("TODO predict_mb_y: " + this.lumaMode);
/* 332 */     System.exit(0);
/*     */   }
/*     */ 
/*     */   
/*     */   private void predictLumaDC(VPXMacroblock above, VPXMacroblock left) {
/* 337 */     boolean hasAbove = (this.Rrow > 1);
/* 338 */     boolean hasLeft = (this.column > 1);
/*     */     
/* 340 */     int expected_dc = 128;
/*     */     
/* 342 */     if (hasAbove || hasLeft) {
/* 343 */       int average = 0;
/* 344 */       if (hasAbove) {
/* 345 */         for (int j = 0; j < 4; j++) {
/* 346 */           Subblock sb = above.ySubblocks[3][j];
/* 347 */           for (int k = 0; k < 4; k++) {
/* 348 */             average += sb.val[12 + k];
/*     */           }
/*     */         } 
/*     */       }
/*     */       
/* 353 */       if (hasLeft) {
/* 354 */         for (int j = 0; j < 4; j++) {
/* 355 */           Subblock sb = left.ySubblocks[j][3];
/* 356 */           for (int k = 0; k < 4; k++) {
/* 357 */             average += sb.val[k * 4 + 3];
/*     */           }
/*     */         } 
/*     */       }
/*     */       
/* 362 */       int shift = 3;
/* 363 */       if (hasAbove)
/* 364 */         shift++; 
/* 365 */       if (hasLeft) {
/* 366 */         shift++;
/*     */       }
/* 368 */       expected_dc = average + (1 << shift - 1) >> shift;
/*     */     } 
/*     */     
/* 371 */     int[] fill = new int[16];
/* 372 */     for (int i = 0; i < 16; i++) {
/* 373 */       fill[i] = expected_dc;
/*     */     }
/* 375 */     for (int y = 0; y < 4; y++) {
/* 376 */       for (int x = 0; x < 4; x++)
/* 377 */         (this.ySubblocks[y][x])._predict = fill; 
/*     */     } 
/*     */   }
/*     */   private void predictLumaH(VPXMacroblock leftMb) {
/* 381 */     Subblock[] leftYSb = new Subblock[4]; int row;
/* 382 */     for (row = 0; row < 4; row++) {
/* 383 */       leftYSb[row] = leftMb.ySubblocks[row][3];
/*     */     }
/* 385 */     for (row = 0; row < 4; row++) {
/* 386 */       for (int col = 0; col < 4; col++) {
/* 387 */         Subblock sb = this.ySubblocks[row][col];
/* 388 */         int[] block = new int[16];
/* 389 */         for (int bRow = 0; bRow < 4; bRow++) {
/* 390 */           for (int bCol = 0; bCol < 4; bCol++)
/* 391 */             block[bRow * 4 + bCol] = ((leftYSb[row]).val != null) ? (leftYSb[row]).val[bRow * 4 + 3] : 129; 
/*     */         } 
/* 393 */         sb._predict = block;
/*     */       } 
/*     */     } 
/*     */   }
/*     */   
/*     */   private void predictLumaTM(VPXMacroblock above, VPXMacroblock left, int aboveLeft) {
/* 399 */     Subblock[] aboveYSb = new Subblock[4];
/* 400 */     Subblock[] leftYSb = new Subblock[4];
/* 401 */     for (int col = 0; col < 4; col++)
/* 402 */       aboveYSb[col] = above.ySubblocks[3][col];  int row;
/* 403 */     for (row = 0; row < 4; row++) {
/* 404 */       leftYSb[row] = left.ySubblocks[row][3];
/*     */     }
/* 406 */     for (row = 0; row < 4; row++) {
/* 407 */       for (int pRow = 0; pRow < 4; pRow++) {
/* 408 */         for (int i = 0; i < 4; i++) {
/* 409 */           if ((this.ySubblocks[row][i]).val == null) {
/* 410 */             (this.ySubblocks[row][i]).val = new int[16];
/*     */           }
/* 412 */           for (int pCol = 0; pCol < 4; pCol++) {
/*     */             
/* 414 */             int pred = (leftYSb[row]).val[pRow * 4 + 3] + (aboveYSb[i]).val[12 + pCol] - aboveLeft;
/*     */             
/* 416 */             (this.ySubblocks[row][i]).val[pRow * 4 + pCol] = VP8Util.QuantizationParams.clip255(pred);
/*     */           } 
/*     */         } 
/*     */       } 
/*     */     } 
/*     */   }
/*     */   private void predictLumaV(VPXMacroblock above) {
/* 423 */     Subblock[] aboveYSb = new Subblock[4];
/* 424 */     for (int col = 0; col < 4; col++) {
/* 425 */       aboveYSb[col] = above.ySubblocks[3][col];
/*     */     }
/* 427 */     for (int row = 0; row < 4; row++) {
/* 428 */       for (int i = 0; i < 4; i++) {
/* 429 */         Subblock sb = this.ySubblocks[row][i];
/* 430 */         int[] block = new int[16];
/* 431 */         for (int j = 0; j < 4; j++) {
/* 432 */           for (int k = 0; k < 4; k++) {
/* 433 */             block[j * 4 + k] = ((aboveYSb[i]).val != null) ? (aboveYSb[i]).val[12 + k] : 127;
/*     */           }
/*     */         } 
/* 436 */         sb._predict = block;
/*     */       } 
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public Subblock getBottomSubblock(int x, VP8Util.PLANE plane) {
/* 443 */     if (plane == VP8Util.PLANE.Y1)
/* 444 */       return this.ySubblocks[3][x]; 
/* 445 */     if (plane == VP8Util.PLANE.U)
/* 446 */       return this.uSubblocks[1][x]; 
/* 447 */     if (plane == VP8Util.PLANE.V)
/* 448 */       return this.vSubblocks[1][x]; 
/* 449 */     if (plane == VP8Util.PLANE.Y2) {
/* 450 */       return this.y2;
/*     */     }
/* 452 */     return null;
/*     */   }
/*     */   
/*     */   public Subblock getRightSubBlock(int y, VP8Util.PLANE plane) {
/* 456 */     if (plane == VP8Util.PLANE.Y1)
/* 457 */       return this.ySubblocks[y][3]; 
/* 458 */     if (plane == VP8Util.PLANE.U)
/* 459 */       return this.uSubblocks[y][1]; 
/* 460 */     if (plane == VP8Util.PLANE.V)
/* 461 */       return this.vSubblocks[y][1]; 
/* 462 */     if (plane == VP8Util.PLANE.Y2) {
/* 463 */       return this.y2;
/*     */     }
/* 465 */     return null;
/*     */   }
/*     */   
/*     */   public void decodeMacroBlock(VPXMacroblock[][] mbs, VPXBooleanDecoder tockenDecoder, int[][][][] coefProbs) {
/* 469 */     if (this.skipCoeff > 0) {
/* 470 */       this.skipFilter = (this.lumaMode != 4);
/* 471 */     } else if (this.lumaMode != 4) {
/* 472 */       decodeMacroBlockTokens(true, mbs, tockenDecoder, coefProbs);
/*     */     } else {
/* 474 */       decodeMacroBlockTokens(false, mbs, tockenDecoder, coefProbs);
/*     */     } 
/*     */   }
/*     */   private void decodeMacroBlockTokens(boolean withY2, VPXMacroblock[][] mbs, VPXBooleanDecoder decoder, int[][][][] coefProbs) {
/* 478 */     this.skipFilter = false;
/* 479 */     if (withY2) {
/* 480 */       this.skipFilter |= decodePlaneTokens(1, VP8Util.PLANE.Y2, false, mbs, decoder, coefProbs);
/*     */     }
/* 482 */     this.skipFilter |= decodePlaneTokens(4, VP8Util.PLANE.Y1, withY2, mbs, decoder, coefProbs);
/* 483 */     this.skipFilter |= decodePlaneTokens(2, VP8Util.PLANE.U, false, mbs, decoder, coefProbs);
/* 484 */     this.skipFilter |= decodePlaneTokens(2, VP8Util.PLANE.V, false, mbs, decoder, coefProbs);
/* 485 */     this.skipFilter = !this.skipFilter;
/*     */   }
/*     */   
/*     */   private boolean decodePlaneTokens(int dimentions, VP8Util.PLANE plane, boolean withY2, VPXMacroblock[][] mbs, VPXBooleanDecoder decoder, int[][][][] coefProbs) {
/* 489 */     boolean r = false;
/* 490 */     for (int row = 0; row < dimentions; row++) {
/* 491 */       for (int col = 0; col < dimentions; col++) {
/* 492 */         int lc = 0;
/* 493 */         Subblock sb = null;
/* 494 */         if (VP8Util.PLANE.Y1.equals(plane)) {
/* 495 */           sb = this.ySubblocks[row][col];
/* 496 */         } else if (VP8Util.PLANE.U.equals(plane)) {
/* 497 */           sb = this.uSubblocks[row][col];
/* 498 */         } else if (VP8Util.PLANE.V.equals(plane)) {
/* 499 */           sb = this.vSubblocks[row][col];
/* 500 */         } else if (VP8Util.PLANE.Y2.equals(plane)) {
/* 501 */           sb = this.y2;
/*     */         } else {
/* 503 */           throw new IllegalStateException("unknown plane type " + plane);
/*     */         } 
/*     */ 
/*     */ 
/*     */         
/* 508 */         Subblock l = sb.getLeft(plane, mbs);
/* 509 */         Subblock a = sb.getAbove(plane, mbs);
/*     */         
/* 511 */         lc = (l.someValuePresent ? 1 : 0) + (a.someValuePresent ? 1 : 0);
/*     */         
/* 513 */         sb.decodeSubBlock(decoder, coefProbs, lc, VP8Util.planeToType(plane, Boolean.valueOf(withY2)), withY2);
/*     */ 
/*     */         
/* 516 */         r |= sb.someValuePresent;
/*     */       } 
/*     */     } 
/* 519 */     return r;
/*     */   }
/*     */   
/*     */   public static class Subblock
/*     */   {
/*     */     public int[] val;
/*     */     public int[] _predict;
/*     */     public int[] residue;
/*     */     private int col;
/*     */     private int row;
/*     */     private VP8Util.PLANE plane;
/*     */     public int mode;
/*     */     public boolean someValuePresent;
/*     */     private int[] tokens;
/*     */     private VPXMacroblock self;
/*     */     
/*     */     public Subblock(VPXMacroblock self, int row, int col, VP8Util.PLANE plane) {
/* 536 */       this.self = self;
/* 537 */       this.row = row;
/* 538 */       this.col = col;
/* 539 */       this.plane = plane;
/* 540 */       this.tokens = new int[16];
/*     */     }
/*     */     public void predict(VPXMacroblock[][] mbs) {
/*     */       int aboveLeft;
/* 544 */       Subblock aboveSb = getAbove(this.plane, mbs);
/* 545 */       Subblock leftSb = getLeft(this.plane, mbs);
/*     */       
/* 547 */       int[] above = new int[4];
/* 548 */       int[] left = new int[4];
/*     */       
/* 550 */       int[] aboveValues = (aboveSb.val != null) ? aboveSb.val : VP8Util.PRED_BLOCK_127;
/* 551 */       above[0] = aboveValues[12];
/* 552 */       above[1] = aboveValues[13];
/* 553 */       above[2] = aboveValues[14];
/* 554 */       above[3] = aboveValues[15];
/* 555 */       int[] leftValues = (leftSb.val != null) ? leftSb.val : VP8Util.pickDefaultPrediction(this.mode);
/* 556 */       left[0] = leftValues[3];
/* 557 */       left[1] = leftValues[7];
/* 558 */       left[2] = leftValues[11];
/* 559 */       left[3] = leftValues[15];
/* 560 */       Subblock aboveLeftSb = aboveSb.getLeft(this.plane, mbs);
/*     */ 
/*     */       
/* 563 */       if (leftSb.val == null && aboveSb.val == null) {
/*     */         
/* 565 */         aboveLeft = 127;
/* 566 */       } else if (aboveSb.val == null) {
/*     */         
/* 568 */         aboveLeft = 127;
/*     */       } else {
/* 570 */         aboveLeft = (aboveLeftSb.val != null) ? aboveLeftSb.val[15] : VP8Util.pickDefaultPrediction(this.mode)[15];
/*     */       } 
/* 572 */       int[] ar = getAboveRightLowestRow(mbs);
/*     */       
/* 574 */       switch (this.mode) {
/*     */         case 0:
/* 576 */           this._predict = VP8Util.predictDC(above, left);
/*     */           return;
/*     */         
/*     */         case 1:
/* 580 */           this._predict = VP8Util.predictTM(above, left, aboveLeft);
/*     */           return;
/*     */         
/*     */         case 2:
/* 584 */           this._predict = VP8Util.predictVE(above, aboveLeft, ar);
/*     */           return;
/*     */         
/*     */         case 3:
/* 588 */           this._predict = VP8Util.predictHE(left, aboveLeft);
/*     */           return;
/*     */         
/*     */         case 4:
/* 592 */           this._predict = VP8Util.predictLD(above, ar);
/*     */           return;
/*     */         
/*     */         case 5:
/* 596 */           this._predict = VP8Util.predictRD(above, left, aboveLeft);
/*     */           return;
/*     */         
/*     */         case 6:
/* 600 */           this._predict = VP8Util.predictVR(above, left, aboveLeft);
/*     */           return;
/*     */         
/*     */         case 7:
/* 604 */           this._predict = VP8Util.predictVL(above, ar);
/*     */           return;
/*     */         
/*     */         case 8:
/* 608 */           this._predict = VP8Util.predictHD(above, left, aboveLeft);
/*     */           return;
/*     */         
/*     */         case 9:
/* 612 */           this._predict = VP8Util.predictHU(left);
/*     */           return;
/*     */       } 
/*     */       
/* 616 */       throw new NotSupportedException("TODO: unknowwn mode: " + this.mode);
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public void reconstruct() {
/* 624 */       int[] p = (this.val != null) ? this.val : this._predict;
/* 625 */       int[] dest = new int[16];
/*     */       
/* 627 */       for (int aRow = 0; aRow < 4; aRow++) {
/* 628 */         for (int aCol = 0; aCol < 4; aCol++) {
/* 629 */           int a = VP8Util.QuantizationParams.clip255(this.residue[aRow * 4 + aCol] + p[aRow * 4 + aCol]);
/* 630 */           dest[aRow * 4 + aCol] = a;
/*     */         } 
/*     */       } 
/*     */       
/* 634 */       this.val = dest;
/*     */     }
/*     */     
/*     */     public Subblock getAbove(VP8Util.PLANE plane, VPXMacroblock[][] mbs) {
/* 638 */       if (this.row > 0) {
/* 639 */         if (VP8Util.PLANE.Y1.equals(this.plane))
/* 640 */           return this.self.ySubblocks[this.row - 1][this.col]; 
/* 641 */         if (VP8Util.PLANE.U.equals(this.plane))
/* 642 */           return this.self.uSubblocks[this.row - 1][this.col]; 
/* 643 */         if (VP8Util.PLANE.V.equals(this.plane))
/* 644 */           return this.self.vSubblocks[this.row - 1][this.col]; 
/*     */       } 
/* 646 */       int x = this.col;
/*     */       
/* 648 */       VPXMacroblock mb2 = mbs[this.self.Rrow - 1][this.self.column];
/* 649 */       if (plane == VP8Util.PLANE.Y2)
/* 650 */         while (mb2.lumaMode == 4) {
/* 651 */           mb2 = mbs[mb2.Rrow - 1][mb2.column];
/*     */         } 
/* 653 */       return mb2.getBottomSubblock(x, plane);
/*     */     }
/*     */ 
/*     */     
/*     */     public Subblock getLeft(VP8Util.PLANE p, VPXMacroblock[][] mbs) {
/* 658 */       if (this.col > 0) {
/* 659 */         if (VP8Util.PLANE.Y1.equals(this.plane))
/* 660 */           return this.self.ySubblocks[this.row][this.col - 1]; 
/* 661 */         if (VP8Util.PLANE.U.equals(this.plane))
/* 662 */           return this.self.uSubblocks[this.row][this.col - 1]; 
/* 663 */         if (VP8Util.PLANE.V.equals(this.plane))
/* 664 */           return this.self.vSubblocks[this.row][this.col - 1]; 
/*     */       } 
/* 666 */       int y = this.row;
/* 667 */       VPXMacroblock mb2 = mbs[this.self.Rrow][this.self.column - 1];
/*     */       
/* 669 */       if (p == VP8Util.PLANE.Y2)
/* 670 */         while (mb2.lumaMode == 4) {
/* 671 */           mb2 = mbs[mb2.Rrow][mb2.column - 1];
/*     */         } 
/* 673 */       return mb2.getRightSubBlock(y, p);
/*     */     }
/*     */ 
/*     */     
/*     */     private int[] getAboveRightLowestRow(VPXMacroblock[][] mbs) {
/*     */       int[] aboveRightDistValues;
/* 679 */       if (!VP8Util.PLANE.Y1.equals(this.plane)) {
/* 680 */         throw new NotImplementedException("Decoder.getAboveRight: not implemented for Y2 and chroma planes");
/*     */       }
/*     */ 
/*     */       
/* 684 */       if (this.row == 0 && this.col < 3) {
/*     */         
/* 686 */         VPXMacroblock mb2 = mbs[this.self.Rrow - 1][this.self.column];
/* 687 */         Subblock aboveRight = mb2.ySubblocks[3][this.col + 1];
/* 688 */         aboveRightDistValues = aboveRight.val;
/*     */       }
/* 690 */       else if (this.row > 0 && this.col < 3) {
/*     */         
/* 692 */         Subblock aboveRight = this.self.ySubblocks[this.row - 1][this.col + 1];
/* 693 */         aboveRightDistValues = aboveRight.val;
/*     */       }
/* 695 */       else if (this.row == 0 && this.col == 3) {
/*     */         
/* 697 */         VPXMacroblock aboveRightMb = mbs[this.self.Rrow - 1][this.self.column + 1];
/* 698 */         if (aboveRightMb.column < (mbs[0]).length - 1) {
/* 699 */           Subblock aboveRightSb = aboveRightMb.ySubblocks[3][0];
/* 700 */           aboveRightDistValues = aboveRightSb.val;
/*     */         } else {
/* 702 */           aboveRightDistValues = new int[16];
/* 703 */           int fillVal = (aboveRightMb.Rrow == 0) ? 127 : ((mbs[this.self.Rrow - 1][this.self.column]).ySubblocks[3][3]).val[15];
/*     */           
/* 705 */           Arrays.fill(aboveRightDistValues, fillVal);
/*     */         }
/*     */       
/*     */       } else {
/*     */         
/* 710 */         Subblock sb2 = this.self.ySubblocks[0][3];
/* 711 */         return sb2.getAboveRightLowestRow(mbs);
/*     */       } 
/*     */       
/* 714 */       if (aboveRightDistValues == null) {
/* 715 */         aboveRightDistValues = VP8Util.PRED_BLOCK_127;
/*     */       }
/* 717 */       int[] ar = new int[4];
/* 718 */       ar[0] = aboveRightDistValues[12];
/* 719 */       ar[1] = aboveRightDistValues[13];
/* 720 */       ar[2] = aboveRightDistValues[14];
/* 721 */       ar[3] = aboveRightDistValues[15];
/* 722 */       return ar;
/*     */     }
/*     */ 
/*     */     
/*     */     public void decodeSubBlock(VPXBooleanDecoder decoder, int[][][][] allProbs, int ilc, int type, boolean withY2) {
/* 727 */       int startAt = 0;
/* 728 */       if (withY2)
/* 729 */         startAt = 1; 
/* 730 */       int lc = ilc;
/* 731 */       int count = 0;
/* 732 */       int v = 1;
/*     */       
/* 734 */       boolean skip = false;
/*     */       
/* 736 */       this.someValuePresent = false;
/* 737 */       while (v != 11 && count + startAt < 16) {
/*     */         
/* 739 */         int[] probs = allProbs[type][VP8Util.SubblockConstants.vp8CoefBands[count + startAt]][lc];
/* 740 */         if (!skip) {
/* 741 */           v = decoder.readTree(VP8Util.SubblockConstants.vp8CoefTree, probs);
/*     */         } else {
/* 743 */           v = decoder.readTreeSkip(VP8Util.SubblockConstants.vp8CoefTree, probs, 1);
/*     */         } 
/*     */         
/* 746 */         int dv = decodeToken(decoder, v);
/* 747 */         lc = 0;
/* 748 */         skip = false;
/* 749 */         if (dv == 1 || dv == -1) {
/* 750 */           lc = 1;
/* 751 */         } else if (dv > 1 || dv < -1) {
/* 752 */           lc = 2;
/* 753 */         } else if (dv == 0) {
/* 754 */           skip = true;
/*     */         } 
/* 756 */         if (v != 11) {
/* 757 */           this.tokens[VP8Util.SubblockConstants.vp8defaultZigZag1d[count + startAt]] = dv;
/*     */         }
/* 759 */         count++;
/*     */       } 
/*     */       
/* 762 */       for (int x = 0; x < 16; x++) {
/* 763 */         if (this.tokens[x] != 0)
/* 764 */           this.someValuePresent = true; 
/*     */       } 
/*     */     }
/*     */     private int decodeToken(VPXBooleanDecoder decoder, int initialValue) {
/* 768 */       int token = initialValue;
/*     */       
/* 770 */       if (initialValue == 5) {
/* 771 */         token = 5 + DCTextra(decoder, VP8Util.SubblockConstants.Pcat1);
/*     */       }
/* 773 */       if (initialValue == 6) {
/* 774 */         token = 7 + DCTextra(decoder, VP8Util.SubblockConstants.Pcat2);
/*     */       }
/* 776 */       if (initialValue == 7) {
/* 777 */         token = 11 + DCTextra(decoder, VP8Util.SubblockConstants.Pcat3);
/*     */       }
/* 779 */       if (initialValue == 8) {
/* 780 */         token = 19 + DCTextra(decoder, VP8Util.SubblockConstants.Pcat4);
/*     */       }
/* 782 */       if (initialValue == 9) {
/* 783 */         token = 35 + DCTextra(decoder, VP8Util.SubblockConstants.Pcat5);
/*     */       }
/* 785 */       if (initialValue == 10) {
/* 786 */         token = 67 + DCTextra(decoder, VP8Util.SubblockConstants.Pcat6);
/*     */       }
/* 788 */       if (initialValue != 0 && initialValue != 11 && 
/* 789 */         decoder.readBitEq() > 0) {
/* 790 */         token = -token;
/*     */       }
/*     */       
/* 793 */       return token;
/*     */     }
/*     */     
/*     */     private int DCTextra(VPXBooleanDecoder decoder, int[] p) {
/* 797 */       int v = 0;
/* 798 */       int offset = 0;
/*     */       while (true) {
/* 800 */         v += v + decoder.readBit(p[offset]);
/* 801 */         offset++;
/* 802 */         if (p[offset] <= 0)
/* 803 */           return v; 
/*     */       } 
/*     */     }
/*     */     public void dequantSubblock(int dc, int ac, Integer Dc) {
/* 807 */       int[] adjustedValues = new int[16];
/*     */       
/* 809 */       adjustedValues[0] = this.tokens[0] * dc;
/* 810 */       for (int i = 1; i < 16; i++) {
/* 811 */         adjustedValues[i] = this.tokens[i] * ac;
/*     */       }
/* 813 */       if (Dc != null) {
/* 814 */         adjustedValues[0] = Dc.intValue();
/*     */       }
/* 816 */       this.residue = VP8DCT.decodeDCT(adjustedValues);
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   public void put(int mbRow, int mbCol, Picture p) {
/* 822 */     byte[] luma = p.getPlaneData(0);
/* 823 */     byte[] cb = p.getPlaneData(1);
/* 824 */     byte[] cr = p.getPlaneData(2);
/* 825 */     int strideLuma = p.getPlaneWidth(0);
/* 826 */     int strideChroma = p.getPlaneWidth(1);
/* 827 */     for (int lumaRow = 0; lumaRow < 4; lumaRow++) {
/* 828 */       for (int lumaCol = 0; lumaCol < 4; lumaCol++) {
/* 829 */         for (int lumaPRow = 0; lumaPRow < 4; lumaPRow++) {
/* 830 */           for (int lumaPCol = 0; lumaPCol < 4; lumaPCol++)
/* 831 */           { int y = (mbRow << 4) + (lumaRow << 2) + lumaPRow;
/* 832 */             int x = (mbCol << 4) + (lumaCol << 2) + lumaPCol;
/* 833 */             if (x < strideLuma && y < luma.length / strideLuma)
/*     */             
/*     */             { 
/* 836 */               int yy = (this.ySubblocks[lumaRow][lumaCol]).val[lumaPRow * 4 + lumaPCol];
/* 837 */               luma[strideLuma * y + x] = (byte)(yy - 128); }  } 
/*     */         } 
/*     */       } 
/* 840 */     }  for (int chromaRow = 0; chromaRow < 2; chromaRow++) {
/* 841 */       for (int chromaCol = 0; chromaCol < 2; chromaCol++) {
/* 842 */         for (int chromaPRow = 0; chromaPRow < 4; chromaPRow++) {
/* 843 */           for (int chromaPCol = 0; chromaPCol < 4; chromaPCol++) {
/* 844 */             int y = (mbRow << 3) + (chromaRow << 2) + chromaPRow;
/* 845 */             int x = (mbCol << 3) + (chromaCol << 2) + chromaPCol;
/* 846 */             if (x < strideChroma && y < cb.length / strideChroma) {
/*     */ 
/*     */               
/* 849 */               int u = (this.uSubblocks[chromaRow][chromaCol]).val[chromaPRow * 4 + chromaPCol];
/* 850 */               int v = (this.vSubblocks[chromaRow][chromaCol]).val[chromaPRow * 4 + chromaPCol];
/* 851 */               cb[strideChroma * y + x] = (byte)(u - 128);
/* 852 */               cr[strideChroma * y + x] = (byte)(v - 128);
/*     */             } 
/*     */           } 
/*     */         } 
/*     */       } 
/*     */     } 
/*     */   }
/*     */ }


/* Location:              C:\Users\rapha\Downloads\aurora.jar!\META-INF\jars\jcodec-0.2.5.jar!\org\jcodec\codecs\vpx\VPXMacroblock.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */