/*    */ package org.jcodec.codecs.vpx;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class VP8FixedRateControl
/*    */   implements RateControl
/*    */ {
/*    */   private int rate;
/*    */   
/*    */   public VP8FixedRateControl(int rate) {
/* 17 */     this.rate = rate;
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public int[] getSegmentQps() {
/* 23 */     return null;
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public int getSegment() {
/* 29 */     return 0;
/*    */   }
/*    */   
/*    */   public void report(int bits) {}
/*    */   
/*    */   public void reset() {}
/*    */ }


/* Location:              C:\Users\rapha\Downloads\aurora.jar!\META-INF\jars\jcodec-0.2.5.jar!\org\jcodec\codecs\vpx\VP8FixedRateControl.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */