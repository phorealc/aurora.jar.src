/*     */ package org.jcodec.codecs.vpx;
/*     */ 
/*     */ import java.nio.ByteBuffer;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class VPXBooleanDecoder
/*     */ {
/*     */   int bit_count;
/*     */   ByteBuffer input;
/*     */   int offset;
/*     */   int range;
/*     */   int value;
/*  17 */   long callCounter = 0L;
/*     */   private String debugName;
/*     */   
/*     */   public VPXBooleanDecoder(ByteBuffer input, int offset) {
/*  21 */     this.input = input;
/*  22 */     this.offset = offset;
/*  23 */     initBoolDecoder();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected VPXBooleanDecoder() {}
/*     */ 
/*     */ 
/*     */   
/*     */   void initBoolDecoder() {
/*  34 */     this.value = 0;
/*     */ 
/*     */     
/*  37 */     this.value = (this.input.get() & 0xFF) << 8;
/*     */     
/*  39 */     this.offset++;
/*     */     
/*  41 */     this.range = 255;
/*  42 */     this.bit_count = 0;
/*     */   }
/*     */   
/*     */   public int readBitEq() {
/*  46 */     return readBit(128);
/*     */   }
/*     */   
/*     */   public int readBit(int probability) {
/*  50 */     int bit = 0;
/*  51 */     int range = this.range;
/*  52 */     int value = this.value;
/*  53 */     int split = 1 + ((range - 1) * probability >> 8);
/*  54 */     int bigsplit = split << 8;
/*     */     
/*  56 */     this.callCounter++;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*  62 */     range = split;
/*     */     
/*  64 */     if (value >= bigsplit) {
/*  65 */       range = this.range - range;
/*  66 */       value -= bigsplit;
/*  67 */       bit = 1;
/*     */     } 
/*     */     
/*  70 */     int count = this.bit_count;
/*  71 */     int shift = leadingZeroCountInByte((byte)range);
/*  72 */     range <<= shift;
/*  73 */     value <<= shift;
/*  74 */     count -= shift;
/*     */     
/*  76 */     if (count <= 0) {
/*  77 */       value |= (this.input.get() & 0xFF) << -count;
/*     */       
/*  79 */       this.offset++;
/*  80 */       count += 8;
/*     */     } 
/*     */     
/*  83 */     this.bit_count = count;
/*  84 */     this.value = value;
/*  85 */     this.range = range;
/*  86 */     return bit;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int decodeInt(int sizeInBits) {
/*  93 */     int v = 0;
/*  94 */     while (sizeInBits-- > 0)
/*  95 */       v = v << 1 | readBit(128); 
/*  96 */     return v;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int readTree(int[] tree, int[] probability) {
/* 148 */     int i = 0;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 156 */     while ((i = tree[i + readBit(probability[i >> 1])]) > 0);
/*     */     
/* 158 */     return -i;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public int readTree3(int[] tree, int prob0, int prob1) {
/* 164 */     int i = 0;
/* 165 */     if ((i = tree[i + readBit(prob0)]) > 0) {
/* 166 */       while ((i = tree[i + readBit(prob1)]) > 0);
/*     */     }
/* 168 */     return -i;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public int readTreeSkip(int[] t, int[] p, int skip_branches) {
/* 174 */     int i = skip_branches * 2;
/*     */ 
/*     */     
/* 177 */     while ((i = t[i + readBit(p[i >> 1])]) > 0);
/*     */     
/* 179 */     return -i;
/*     */   }
/*     */ 
/*     */   
/*     */   public void seek() {
/* 184 */     this.input.position(this.offset);
/*     */   }
/*     */   
/*     */   public String toString() {
/* 188 */     return "bc: " + this.value;
/*     */   }
/*     */   
/*     */   public static int getBitInBytes(byte[] bs, int i) {
/* 192 */     int byteIndex = i >> 3;
/* 193 */     int bitIndex = i & 0x7;
/* 194 */     return bs[byteIndex] >> 7 - bitIndex & 0x1;
/*     */   }
/*     */   
/*     */   public static int getBitsInBytes(byte[] bytes, int idx, int len) {
/* 198 */     int val = 0;
/* 199 */     for (int i = 0; i < len; i++) {
/* 200 */       val = val << 1 | getBitInBytes(bytes, idx + i);
/*     */     }
/* 202 */     return val;
/*     */   }
/*     */   
/*     */   public static int leadingZeroCountInByte(byte b) {
/* 206 */     int i = b & 0xFF;
/* 207 */     if (i >= 128 || i == 0) {
/* 208 */       return 0;
/*     */     }
/* 210 */     return Integer.numberOfLeadingZeros(b) - 24;
/*     */   }
/*     */ }


/* Location:              C:\Users\rapha\Downloads\aurora.jar!\META-INF\jars\jcodec-0.2.5.jar!\org\jcodec\codecs\vpx\VPXBooleanDecoder.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */