/*    */ package org.jcodec.codecs.vpx.vp9;
/*    */ 
/*    */ import org.jcodec.codecs.vpx.VPXBooleanDecoder;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class CodedBlock
/*    */ {
/* 13 */   public static final CodedBlock[] EMPTY_ARR = new CodedBlock[0];
/*    */   
/*    */   private ModeInfo mode;
/*    */   private Residual residual;
/*    */   
/*    */   public CodedBlock(ModeInfo mode, Residual r) {
/* 19 */     this.mode = mode;
/* 20 */     this.residual = r;
/*    */   }
/*    */   
/*    */   public ModeInfo getMode() {
/* 24 */     return this.mode;
/*    */   }
/*    */   
/*    */   public Residual getResidual() {
/* 28 */     return this.residual;
/*    */   }
/*    */ 
/*    */   
/*    */   public static CodedBlock read(int miCol, int miRow, int blSz, VPXBooleanDecoder decoder, DecodingContext c) {
/*    */     ModeInfo mode;
/* 34 */     if (c.isKeyIntraFrame()) {
/* 35 */       mode = (new ModeInfo()).read(miCol, miRow, blSz, decoder, c);
/*    */     } else {
/* 37 */       mode = (new InterModeInfo()).read(miCol, miRow, blSz, decoder, c);
/* 38 */     }  Residual r = Residual.readResidual(miCol, miRow, blSz, decoder, c, mode);
/* 39 */     return new CodedBlock(mode, r);
/*    */   }
/*    */ }


/* Location:              C:\Users\rapha\Downloads\aurora.jar!\META-INF\jars\jcodec-0.2.5.jar!\org\jcodec\codecs\vpx\vp9\CodedBlock.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */