/*     */ package org.jcodec.codecs.vpx.vp9;
/*     */ 
/*     */ import org.jcodec.codecs.vpx.VPXBooleanDecoder;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ModeInfo
/*     */ {
/*     */   private int segmentId;
/*     */   private boolean skip;
/*     */   private int txSize;
/*     */   private int yMode;
/*     */   private int subModes;
/*     */   private int uvMode;
/*     */   
/*     */   ModeInfo() {}
/*     */   
/*     */   public ModeInfo(int segmentId, boolean skip, int txSize, int yMode, int subModes, int uvMode) {
/*  41 */     this.segmentId = segmentId;
/*  42 */     this.skip = skip;
/*  43 */     this.txSize = txSize;
/*  44 */     this.yMode = yMode;
/*  45 */     this.subModes = subModes;
/*  46 */     this.uvMode = uvMode;
/*     */   }
/*     */   
/*     */   public int getSegmentId() {
/*  50 */     return this.segmentId;
/*     */   }
/*     */   
/*     */   public boolean isSkip() {
/*  54 */     return this.skip;
/*     */   }
/*     */   
/*     */   public int getTxSize() {
/*  58 */     return this.txSize;
/*     */   }
/*     */   
/*     */   public int getYMode() {
/*  62 */     return this.yMode;
/*     */   }
/*     */   
/*     */   public int getSubModes() {
/*  66 */     return this.subModes;
/*     */   }
/*     */   
/*     */   public int getUvMode() {
/*  70 */     return this.uvMode;
/*     */   }
/*     */   
/*     */   public ModeInfo read(int miCol, int miRow, int blSz, VPXBooleanDecoder decoder, DecodingContext c) {
/*  74 */     int yMode, segmentId = 0;
/*  75 */     if (c.isSegmentationEnabled() && c.isUpdateSegmentMap()) {
/*  76 */       segmentId = readSegmentId(decoder, c);
/*     */     }
/*  78 */     boolean skip = true;
/*  79 */     if (!c.isSegmentFeatureActive(segmentId, 3)) {
/*  80 */       skip = readSkipFlag(miCol, miRow, blSz, decoder, c);
/*     */     }
/*  82 */     int txSize = readTxSize(miCol, miRow, blSz, true, decoder, c);
/*     */ 
/*     */     
/*  85 */     int subModes = 0;
/*  86 */     if (blSz >= 3) {
/*  87 */       yMode = readKfIntraMode(miCol, miRow, blSz, decoder, c);
/*     */     } else {
/*  89 */       subModes = readKfIntraModeSub(miCol, miRow, blSz, decoder, c);
/*     */       
/*  91 */       yMode = subModes & 0xFF;
/*     */     } 
/*  93 */     int uvMode = readInterIntraUvMode(yMode, decoder, c);
/*     */     
/*  95 */     return new ModeInfo(segmentId, skip, txSize, yMode, subModes, uvMode);
/*     */   }
/*     */   
/*     */   public int readKfIntraMode(int miCol, int miRow, int blSz, VPXBooleanDecoder decoder, DecodingContext c) {
/*  99 */     boolean availAbove = (miRow > 0);
/* 100 */     boolean availLeft = (miCol > c.getMiTileStartCol());
/* 101 */     int[] aboveIntraModes = c.getAboveModes();
/* 102 */     int[] leftIntraModes = c.getLeftModes();
/*     */ 
/*     */     
/* 105 */     int aboveMode = availAbove ? aboveIntraModes[miCol] : 0;
/* 106 */     int leftMode = availLeft ? leftIntraModes[miRow % 8] : 0;
/*     */     
/* 108 */     int[][][] probs = c.getKfYModeProbs();
/*     */     
/* 110 */     int intraMode = decoder.readTree(Consts.TREE_INTRA_MODE, probs[aboveMode][leftMode]);
/*     */     
/* 112 */     aboveIntraModes[miCol] = intraMode;
/* 113 */     leftIntraModes[miRow % 8] = intraMode;
/* 114 */     return intraMode;
/*     */   }
/*     */   
/*     */   public int readKfIntraModeSub(int miCol, int miRow, int blSz, VPXBooleanDecoder decoder, DecodingContext c) {
/* 118 */     boolean availAbove = (miRow > 0);
/* 119 */     boolean availLeft = (miCol > c.getMiTileStartCol());
/* 120 */     int[] aboveIntraModes = c.getAboveModes();
/* 121 */     int[] leftIntraModes = c.getLeftModes();
/*     */ 
/*     */     
/* 124 */     int[][][] probs = c.getKfYModeProbs();
/* 125 */     int aboveMode = availAbove ? aboveIntraModes[miCol] : 0;
/* 126 */     int leftMode = availLeft ? leftIntraModes[miRow & 0x7] : 0;
/* 127 */     int mode0 = decoder.readTree(Consts.TREE_INTRA_MODE, probs[aboveMode][leftMode]);
/* 128 */     int mode1 = 0, mode2 = 0, mode3 = 0;
/*     */     
/* 130 */     if (blSz == 0) {
/* 131 */       mode1 = decoder.readTree(Consts.TREE_INTRA_MODE, probs[aboveMode][mode0]);
/* 132 */       mode2 = decoder.readTree(Consts.TREE_INTRA_MODE, probs[mode0][leftMode]);
/* 133 */       mode3 = decoder.readTree(Consts.TREE_INTRA_MODE, probs[mode1][mode2]);
/* 134 */       aboveIntraModes[miCol] = mode2;
/* 135 */       leftIntraModes[miRow & 0x7] = mode1;
/* 136 */       return vect4(mode0, mode1, mode2, mode3);
/* 137 */     }  if (blSz == 1) {
/* 138 */       mode1 = decoder.readTree(Consts.TREE_INTRA_MODE, probs[aboveMode][mode0]);
/* 139 */       aboveIntraModes[miCol] = mode0;
/* 140 */       leftIntraModes[miRow & 0x7] = mode1;
/* 141 */       return vect4(mode0, mode1, mode0, mode1);
/* 142 */     }  if (blSz == 2) {
/* 143 */       mode1 = decoder.readTree(Consts.TREE_INTRA_MODE, probs[mode0][leftMode]);
/* 144 */       aboveIntraModes[miCol] = mode1;
/* 145 */       leftIntraModes[miRow & 0x7] = mode0;
/* 146 */       return vect4(mode0, mode0, mode1, mode1);
/*     */     } 
/*     */     
/* 149 */     return 0;
/*     */   }
/*     */   
/*     */   public static int vect4(int val0, int val1, int val2, int val3) {
/* 153 */     return val0 | val1 << 8 | val2 << 16 | val3 << 24;
/*     */   }
/*     */   
/*     */   public static int vect4get(int vect, int ind) {
/* 157 */     return vect >> ind << 3 & 0xFF;
/*     */   }
/*     */ 
/*     */   
/*     */   public int readTxSize(int miCol, int miRow, int blSz, boolean allowSelect, VPXBooleanDecoder decoder, DecodingContext c) {
/* 162 */     if (blSz < 3) {
/* 163 */       return 0;
/*     */     }
/* 165 */     int maxTxSize = Consts.maxTxLookup[blSz];
/* 166 */     int txSize = Math.min(maxTxSize, c.getTxMode());
/* 167 */     if (allowSelect && c.getTxMode() == 4) {
/* 168 */       boolean availAbove = (miRow > 0);
/* 169 */       boolean availLeft = (miCol > c.getMiTileStartCol());
/* 170 */       int above = maxTxSize;
/* 171 */       int left = maxTxSize;
/* 172 */       if (availAbove && !c.getAboveSkipped()[miCol])
/* 173 */         above = c.getAboveTxSizes()[miCol]; 
/* 174 */       if (availLeft && !c.getLeftSkipped()[miRow & 0x7])
/* 175 */         left = c.getLeftTxSizes()[miRow & 0x7]; 
/* 176 */       if (!availLeft)
/* 177 */         left = above; 
/* 178 */       if (!availAbove)
/* 179 */         above = left; 
/* 180 */       int ctx = (above + left > maxTxSize) ? 1 : 0;
/*     */       
/* 182 */       int[][] probs = (int[][])null;
/* 183 */       switch (maxTxSize) {
/*     */         case 3:
/* 185 */           probs = c.getTx32x32Probs();
/*     */           break;
/*     */         case 2:
/* 188 */           probs = c.getTx16x16Probs();
/*     */           break;
/*     */         case 1:
/* 191 */           probs = c.getTx8x8Probs();
/*     */           break;
/*     */         default:
/* 194 */           throw new RuntimeException("Shouldn't happen");
/*     */       } 
/* 196 */       txSize = decoder.readTree(Consts.TREE_TX_SIZE[maxTxSize], probs[ctx]);
/*     */     } else {
/* 198 */       txSize = Math.min(maxTxSize, c.getTxMode());
/*     */     } 
/*     */     
/* 201 */     for (int i = 0; i < Consts.blH[blSz]; i++) {
/* 202 */       c.getLeftTxSizes()[miRow + i & 0x7] = txSize;
/*     */     }
/* 204 */     for (int j = 0; j < Consts.blW[blSz]; j++) {
/* 205 */       c.getAboveTxSizes()[miCol + j & 0x7] = txSize;
/*     */     }
/*     */     
/* 208 */     return txSize;
/*     */   }
/*     */   
/*     */   public static int readSegmentId(VPXBooleanDecoder decoder, DecodingContext c) {
/* 212 */     int[] probs = c.getSegmentationTreeProbs();
/* 213 */     return decoder.readTree(Consts.TREE_SEGMENT_ID, probs);
/*     */   }
/*     */   
/*     */   public boolean readSkipFlag(int miCol, int miRow, int blSz, VPXBooleanDecoder decoder, DecodingContext c) {
/* 217 */     int ctx = 0;
/* 218 */     boolean availAbove = (miRow > 0);
/* 219 */     boolean availLeft = (miCol > c.getMiTileStartCol());
/*     */     
/* 221 */     boolean[] aboveSkipped = c.getAboveSkipped();
/* 222 */     boolean[] leftSkipped = c.getLeftSkipped();
/*     */     
/* 224 */     if (availAbove)
/* 225 */       ctx += aboveSkipped[miCol] ? 1 : 0; 
/* 226 */     if (availLeft) {
/* 227 */       ctx += leftSkipped[miRow & 0x7] ? 1 : 0;
/*     */     }
/* 229 */     System.out.println("SKIP CTX: " + ctx);
/*     */     
/* 231 */     int[] probs = c.getSkipProbs();
/*     */     
/* 233 */     boolean ret = (decoder.readBit(probs[ctx]) == 1);
/*     */     
/* 235 */     for (int i = 0; i < Consts.blH[blSz]; i++) {
/* 236 */       leftSkipped[i + miRow & 0x7] = ret;
/*     */     }
/*     */     
/* 239 */     for (int j = 0; j < Consts.blW[blSz]; j++) {
/* 240 */       aboveSkipped[j + miCol] = ret;
/*     */     }
/*     */     
/* 243 */     return ret;
/*     */   }
/*     */   
/*     */   public boolean isInter() {
/* 247 */     return false;
/*     */   }
/*     */   
/*     */   public int readInterIntraUvMode(int yMode, VPXBooleanDecoder decoder, DecodingContext c) {
/* 251 */     int[][] probs = c.getKfUVModeProbs();
/* 252 */     return decoder.readTree(Consts.TREE_INTRA_MODE, probs[yMode]);
/*     */   }
/*     */ }


/* Location:              C:\Users\rapha\Downloads\aurora.jar!\META-INF\jars\jcodec-0.2.5.jar!\org\jcodec\codecs\vpx\vp9\ModeInfo.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */