/*      */ package org.jcodec.codecs.vpx.vp9;
/*      */ 
/*      */ import org.jcodec.codecs.common.biari.Packed4BitList;
/*      */ import org.jcodec.codecs.vpx.VPXBooleanDecoder;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ public class InterModeInfo
/*      */   extends ModeInfo
/*      */ {
/*      */   private long mvl0;
/*      */   private long mvl1;
/*      */   private long mvl2;
/*      */   private long mvl3;
/*      */   
/*      */   InterModeInfo() {}
/*      */   
/*      */   public InterModeInfo(int segmentId, boolean skip, int txSize, int yMode, int subModes, int uvMode) {
/*   64 */     super(segmentId, skip, txSize, yMode, subModes, uvMode);
/*      */   }
/*      */ 
/*      */   
/*      */   public InterModeInfo(int segmentId, boolean skip, int txSize, int yMode, int subModes, int uvMode, long mvl0, long mvl1, long mvl2, long mvl3) {
/*   69 */     super(segmentId, skip, txSize, yMode, subModes, uvMode);
/*   70 */     this.mvl0 = mvl0;
/*   71 */     this.mvl1 = mvl1;
/*   72 */     this.mvl2 = mvl2;
/*   73 */     this.mvl3 = mvl3;
/*      */   }
/*      */ 
/*      */   
/*      */   public boolean isInter() {
/*   78 */     return true;
/*      */   }
/*      */   
/*      */   public long getMvl0() {
/*   82 */     return this.mvl0;
/*      */   }
/*      */   
/*      */   public long getMvl1() {
/*   86 */     return this.mvl1;
/*      */   }
/*      */   
/*      */   public long getMvl2() {
/*   90 */     return this.mvl2;
/*      */   }
/*      */   
/*      */   public long getMvl3() {
/*   94 */     return this.mvl3;
/*      */   }
/*      */   
/*      */   public InterModeInfo read(int miCol, int miRow, int blSz, VPXBooleanDecoder decoder, DecodingContext c) {
/*   98 */     int segmentId = 0;
/*   99 */     if (c.isSegmentationEnabled()) {
/*  100 */       segmentId = predicSegmentId(miCol, miRow, blSz, c);
/*  101 */       if (c.isUpdateSegmentMap() && (
/*  102 */         !c.isSegmentMapConditionalUpdate() || !readSegIdPredicted(miCol, miRow, blSz, decoder, c))) {
/*  103 */         segmentId = readSegmentId(decoder, c);
/*      */       }
/*      */     } 
/*      */     
/*  107 */     boolean skip = true;
/*  108 */     if (!c.isSegmentFeatureActive(segmentId, 3)) {
/*  109 */       skip = readSkipFlag(miCol, miRow, blSz, decoder, c);
/*      */     }
/*  111 */     boolean isInter = (c.getSegmentFeature(segmentId, 2) != 0);
/*  112 */     if (!c.isSegmentFeatureActive(segmentId, 2)) {
/*  113 */       isInter = readIsInter(miCol, miRow, blSz, decoder, c);
/*      */     }
/*  115 */     int txSize = readTxSize(miCol, miRow, blSz, (!skip || !isInter), decoder, c);
/*      */     
/*  117 */     if (!isInter) {
/*  118 */       return readInterIntraMode(miCol, miRow, blSz, decoder, c, segmentId, skip, txSize);
/*      */     }
/*  120 */     return readInterInterMode(miCol, miRow, blSz, decoder, c, segmentId, skip, txSize);
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   private InterModeInfo readInterInterMode(int miCol, int miRow, int blSz, VPXBooleanDecoder decoder, DecodingContext c, int segmentId, boolean skip, int txSize) {
/*  126 */     int packedRefFrames = readRefFrames(miCol, miRow, blSz, segmentId, decoder, c);
/*      */     
/*  128 */     int lumaMode = 12;
/*  129 */     if (!c.isSegmentFeatureActive(segmentId, 3) && 
/*  130 */       blSz >= 3) {
/*  131 */       lumaMode = readInterMode(miCol, miRow, blSz, decoder, c);
/*      */     }
/*      */     
/*  134 */     int interpFilter = c.getInterpFilter();
/*  135 */     if (interpFilter == 3) {
/*  136 */       interpFilter = readInterpFilter(miCol, miRow, blSz, decoder, c);
/*      */     }
/*      */     
/*  139 */     if (blSz < 3) {
/*  140 */       if (blSz == 0) {
/*  141 */         long[] mv4x4 = readMV4x4(miCol, miRow, blSz, decoder, c, packedRefFrames);
/*  142 */         return new InterModeInfo(segmentId, skip, txSize, -1, 0, -1, mv4x4[0], mv4x4[1], mv4x4[2], mv4x4[3]);
/*      */       } 
/*      */       
/*  145 */       long[] mv12 = readMvSub8x8(miCol, miRow, blSz, decoder, c, packedRefFrames);
/*  146 */       return new InterModeInfo(segmentId, skip, txSize, 0, 0, 0, mv12[0], mv12[1], 0L, 0L);
/*      */     } 
/*      */     
/*  149 */     long mvl = readMV8x8AndAbove(miCol, miRow, blSz, decoder, c, packedRefFrames, lumaMode);
/*  150 */     return new InterModeInfo(segmentId, skip, txSize, lumaMode, 0, lumaMode, mvl, 0L, 0L, 0L);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected long readMV8x8AndAbove(int miCol, int miRow, int blSz, VPXBooleanDecoder decoder, DecodingContext c, int packedRefFrames, int lumaMode) {
/*  157 */     long mvl = readSub0(miCol, miRow, blSz, decoder, c, lumaMode, packedRefFrames);
/*      */     
/*  159 */     updateMVLineBuffers(miCol, miRow, blSz, c, mvl);
/*  160 */     updateMVLineBuffers4x4(miCol, miRow, blSz, c, mvl, mvl);
/*  161 */     return mvl;
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   protected long[] readMvSub8x8(int miCol, int miRow, int blSz, VPXBooleanDecoder decoder, DecodingContext c, int packedRefFrames) {
/*  167 */     int subMode0 = readInterMode(miCol, miRow, blSz, decoder, c);
/*  168 */     long mvl0 = readSub0(miCol, miRow, blSz, decoder, c, subMode0, packedRefFrames);
/*      */     
/*  170 */     int subMode1 = readInterMode(miCol, miRow, blSz, decoder, c);
/*  171 */     int blk = (blSz == 1) ? 1 : 2;
/*  172 */     long mvl1 = readSub12(miCol, miRow, blSz, decoder, c, mvl0, subMode1, blk, packedRefFrames);
/*      */     
/*  174 */     if (blSz == 1) {
/*  175 */       updateMVLineBuffers4x4(miCol, miRow, blSz, c, mvl1, mvl0);
/*      */     } else {
/*  177 */       updateMVLineBuffers4x4(miCol, miRow, blSz, c, mvl0, mvl1);
/*      */     } 
/*  179 */     updateMVLineBuffers(miCol, miRow, blSz, c, mvl1);
/*      */     
/*  181 */     return new long[] { mvl0, mvl1 };
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   protected long[] readMV4x4(int miCol, int miRow, int blSz, VPXBooleanDecoder decoder, DecodingContext c, int packedRefFrames) {
/*  187 */     int subMode0 = readInterMode(miCol, miRow, blSz, decoder, c);
/*  188 */     long mvl0 = readSub0(miCol, miRow, blSz, decoder, c, subMode0, packedRefFrames);
/*      */     
/*  190 */     int subMode1 = readInterMode(miCol, miRow, blSz, decoder, c);
/*  191 */     long mvl1 = readSub12(miCol, miRow, blSz, decoder, c, mvl0, subMode1, 1, packedRefFrames);
/*      */     
/*  193 */     int subMode2 = readInterMode(miCol, miRow, blSz, decoder, c);
/*  194 */     long mvl2 = readSub12(miCol, miRow, blSz, decoder, c, mvl0, subMode2, 2, packedRefFrames);
/*      */     
/*  196 */     int subMode3 = readInterMode(miCol, miRow, blSz, decoder, c);
/*  197 */     long mvl3 = readMvSub3(miCol, miRow, blSz, decoder, c, mvl0, mvl1, mvl2, subMode3, packedRefFrames);
/*      */     
/*  199 */     updateMVLineBuffers(miCol, miRow, blSz, c, mvl3);
/*  200 */     updateMVLineBuffers4x4(miCol, miRow, blSz, c, mvl1, mvl2);
/*      */ 
/*      */     
/*  203 */     return new long[] { mvl0, mvl1, mvl2, mvl3 };
/*      */   }
/*      */ 
/*      */   
/*      */   private static long readSub0(int miCol, int miRow, int blSz, VPXBooleanDecoder decoder, DecodingContext c, int lumaMode, int packedRefFrames) {
/*  208 */     int ref0 = Packed4BitList.get(packedRefFrames, 0);
/*  209 */     int ref1 = Packed4BitList.get(packedRefFrames, 1);
/*  210 */     boolean compoundPred = (Packed4BitList.get(packedRefFrames, 2) == 1);
/*      */     
/*  212 */     long nearestNearMv00 = findBestMv(miCol, miRow, blSz, ref0, 0, c, true);
/*  213 */     long nearestNearMv01 = 0L;
/*  214 */     if (compoundPred)
/*  215 */       nearestNearMv01 = findBestMv(miCol, miRow, blSz, ref1, 0, c, true); 
/*  216 */     int mv0 = 0, mv1 = 0;
/*  217 */     if (lumaMode == 13) {
/*  218 */       mv0 = readDiffMv(decoder, c, nearestNearMv00);
/*  219 */       if (compoundPred)
/*  220 */         mv1 = readDiffMv(decoder, c, nearestNearMv01); 
/*  221 */     } else if (lumaMode != 12) {
/*  222 */       mv0 = MVList.get(nearestNearMv00, lumaMode - 10);
/*  223 */       mv1 = MVList.get(nearestNearMv01, lumaMode - 10);
/*      */     } 
/*      */     
/*  226 */     return MVList.create(mv0, mv1);
/*      */   }
/*      */ 
/*      */   
/*      */   private static long readSub12(int miCol, int miRow, int blSz, VPXBooleanDecoder decoder, DecodingContext c, long mvl0, int subMode1, int blk, int packedRefFrames) {
/*  231 */     int ref0 = Packed4BitList.get(packedRefFrames, 0);
/*  232 */     int ref1 = Packed4BitList.get(packedRefFrames, 1);
/*  233 */     boolean compoundPred = (Packed4BitList.get(packedRefFrames, 2) == 1);
/*  234 */     int mv10 = 0, mv11 = 0;
/*  235 */     long nearestNearMv00 = findBestMv(miCol, miRow, blSz, ref0, 0, c, true);
/*  236 */     long nearestNearMv01 = 0L;
/*  237 */     if (compoundPred)
/*  238 */       nearestNearMv01 = findBestMv(miCol, miRow, blSz, ref1, 0, c, true); 
/*  239 */     if (subMode1 == 13) {
/*  240 */       mv10 = readDiffMv(decoder, c, nearestNearMv00);
/*  241 */       if (compoundPred)
/*  242 */         mv11 = readDiffMv(decoder, c, nearestNearMv01); 
/*  243 */     } else if (subMode1 != 12) {
/*  244 */       long nearestNearMv10 = prepandSubMvBlk12(findBestMv(miCol, miRow, blSz, ref0, blk, c, false), 
/*  245 */           MVList.get(mvl0, 0));
/*  246 */       long nearestNearMv11 = 0L;
/*  247 */       if (compoundPred)
/*  248 */         nearestNearMv11 = prepandSubMvBlk12(findBestMv(miCol, miRow, blSz, ref1, blk, c, false), 
/*  249 */             MVList.get(mvl0, 1)); 
/*  250 */       mv10 = MVList.get(nearestNearMv10, subMode1 - 10);
/*  251 */       mv11 = MVList.get(nearestNearMv11, subMode1 - 10);
/*      */     } 
/*      */     
/*  254 */     return MVList.create(mv10, mv11);
/*      */   }
/*      */ 
/*      */   
/*      */   private static long readMvSub3(int miCol, int miRow, int blSz, VPXBooleanDecoder decoder, DecodingContext c, long mvl0, long mvl1, long mvl2, int subMode3, int packedRefFrames) {
/*  259 */     int ref0 = Packed4BitList.get(packedRefFrames, 0);
/*  260 */     int ref1 = Packed4BitList.get(packedRefFrames, 1);
/*  261 */     boolean compoundPred = (Packed4BitList.get(packedRefFrames, 2) == 1);
/*      */     
/*  263 */     long nearestNearMv00 = findBestMv(miCol, miRow, blSz, ref0, 0, c, true);
/*  264 */     long nearestNearMv01 = 0L;
/*  265 */     if (compoundPred)
/*  266 */       nearestNearMv01 = findBestMv(miCol, miRow, blSz, ref1, 0, c, true); 
/*  267 */     int mv30 = 0, mv31 = 0;
/*  268 */     if (subMode3 == 13) {
/*  269 */       mv30 = readDiffMv(decoder, c, nearestNearMv00);
/*  270 */       if (compoundPred)
/*  271 */         mv31 = readDiffMv(decoder, c, nearestNearMv01); 
/*  272 */     } else if (subMode3 != 12) {
/*  273 */       long nearestNearMv30 = prepandSubMvBlk3(findBestMv(miCol, miRow, blSz, ref0, 3, c, false), 
/*  274 */           MVList.get(mvl0, 0), MVList.get(mvl1, 0), MVList.get(mvl2, 0));
/*  275 */       long nearestNearMv31 = 0L;
/*  276 */       if (compoundPred)
/*  277 */         nearestNearMv31 = prepandSubMvBlk3(findBestMv(miCol, miRow, blSz, ref1, 3, c, false), 
/*  278 */             MVList.get(mvl0, 1), MVList.get(mvl1, 1), MVList.get(mvl2, 1)); 
/*  279 */       mv30 = MVList.get(nearestNearMv30, subMode3 - 10);
/*  280 */       mv31 = MVList.get(nearestNearMv31, subMode3 - 10);
/*      */     } 
/*      */     
/*  283 */     return MVList.create(mv30, mv31);
/*      */   }
/*      */ 
/*      */   
/*      */   private int readRefFrames(int miCol, int miRow, int blSz, int segmentId, VPXBooleanDecoder decoder, DecodingContext c) {
/*  288 */     int ref0 = c.getSegmentFeature(segmentId, 2), ref1 = 0;
/*  289 */     boolean compoundPred = false;
/*  290 */     if (!c.isSegmentFeatureActive(segmentId, 2)) {
/*  291 */       int refMode = c.getRefMode();
/*  292 */       compoundPred = (refMode == 1);
/*  293 */       if (refMode == 2)
/*  294 */         compoundPred = readRefMode(miCol, miRow, decoder, c); 
/*  295 */       if (compoundPred) {
/*  296 */         int compRef = readCompRef(miCol, miRow, blSz, decoder, c);
/*  297 */         int fixedRef = c.getCompFixedRef();
/*  298 */         if (c.refFrameSignBias(fixedRef) == 0) {
/*  299 */           ref0 = fixedRef;
/*  300 */           ref1 = compRef;
/*      */         } else {
/*  302 */           ref0 = compRef;
/*  303 */           ref1 = fixedRef;
/*      */         } 
/*      */       } else {
/*  306 */         ref0 = readSingleRef(miCol, miRow, decoder, c);
/*      */       } 
/*      */     } 
/*  309 */     updateRefFrameLineBuffers(miCol, miRow, blSz, c, ref0, ref1, compoundPred);
/*      */     
/*  311 */     return Packed4BitList._3(ref0, ref1, compoundPred ? 1 : 0);
/*      */   }
/*      */   
/*      */   private static void updateMVLineBuffers(int miCol, int miRow, int blSz, DecodingContext c, long mv) {
/*  315 */     long[][] leftMVs = c.getLeftMVs();
/*  316 */     long[][] aboveMVs = c.getAboveMVs();
/*  317 */     long[][] aboveLeftMVs = c.getAboveLeftMVs();
/*      */     int i;
/*  319 */     for (i = 0; i < Math.max(3, Consts.blW[blSz]); i++) {
/*  320 */       aboveLeftMVs[2][i] = aboveLeftMVs[1][i];
/*  321 */       aboveLeftMVs[1][i] = aboveLeftMVs[0][i];
/*  322 */       aboveLeftMVs[0][i] = aboveMVs[i][miCol + i];
/*      */     } 
/*      */     
/*  325 */     for (i = 0; i < Math.max(3, Consts.blH[blSz]); i++) {
/*  326 */       int offTop = (miRow + i) % 8;
/*  327 */       aboveLeftMVs[i][2] = aboveLeftMVs[i][1];
/*  328 */       aboveLeftMVs[i][1] = aboveLeftMVs[i][0];
/*  329 */       aboveLeftMVs[i][0] = leftMVs[i][offTop];
/*      */     } 
/*      */     int j;
/*  332 */     for (j = 0; j < Math.max(3, Consts.blH[blSz]); j++) {
/*  333 */       for (int k = 0; k < Consts.blW[blSz]; k++) {
/*  334 */         int offLeft = miCol + k;
/*  335 */         aboveMVs[2][offLeft] = aboveMVs[1][offLeft];
/*  336 */         aboveMVs[1][offLeft] = aboveMVs[0][offLeft];
/*  337 */         aboveMVs[0][offLeft] = mv;
/*      */       } 
/*      */     } 
/*      */     
/*  341 */     for (j = 0; j < Math.max(3, Consts.blW[blSz]); j++) {
/*  342 */       for (int k = 0; k < Consts.blH[blSz]; k++) {
/*  343 */         int offTop = (miRow + k) % 8;
/*  344 */         leftMVs[2][offTop] = leftMVs[1][offTop];
/*  345 */         leftMVs[1][offTop] = leftMVs[0][offTop];
/*  346 */         leftMVs[0][offTop] = mv;
/*      */       } 
/*      */     } 
/*      */   }
/*      */ 
/*      */   
/*      */   private static void updateMVLineBuffers4x4(int miCol, int miRow, int blSz, DecodingContext c, long mvLeft, long mvAbove) {
/*  353 */     long[] leftMVs = c.getLeft4x4MVs();
/*  354 */     long[] aboveMVs = c.getAbove4x4MVs();
/*      */     
/*  356 */     aboveMVs[miCol] = mvAbove;
/*  357 */     leftMVs[miRow % 8] = mvLeft;
/*      */   }
/*      */   
/*      */   public static int ref(int ref0, int ref1) {
/*  361 */     return (ref0 & 0x3) << 2 | ref1 & 0x3;
/*      */   }
/*      */   
/*      */   public static int getRef(int packed, int n) {
/*  365 */     if (n == 0) {
/*  366 */       return packed & 0x3;
/*      */     }
/*  368 */     return packed >> 2 & 0x3;
/*      */   }
/*      */ 
/*      */   
/*      */   private static void updateRefFrameLineBuffers(int miCol, int miRow, int blSz, DecodingContext c, int ref0, int ref1, boolean compoundPred) {
/*  373 */     boolean[] aboveCompound = c.getAboveCompound();
/*  374 */     boolean[] leftCompound = c.getLeftCompound(); int k;
/*  375 */     for (k = 0; k < Consts.blW[blSz]; k++)
/*  376 */       aboveCompound[k + miCol] = compoundPred; 
/*  377 */     for (k = 0; k < Consts.blH[blSz]; k++) {
/*  378 */       leftCompound[miRow + k & 0x7] = compoundPred;
/*      */     }
/*  380 */     for (int j = 0; j < Consts.blW[blSz]; j++) {
/*  381 */       c.getAboveRefs()[j] = ref(ref0, ref1);
/*      */     }
/*  383 */     for (int i = 0; i < Consts.blH[blSz]; i++) {
/*  384 */       c.getLeftRefs()[i & 0x7] = ref(ref0, ref1);
/*      */     }
/*      */   }
/*      */   
/*      */   private static int readDiffMv(VPXBooleanDecoder decoder, DecodingContext c, long nearNearest) {
/*  389 */     int bestMv = MVList.get(nearNearest, 0);
/*  390 */     boolean useHp = (c.isAllowHpMv() && !largeMv(bestMv));
/*  391 */     int joint = decoder.readTree(Consts.TREE_MV_JOINT, c.getMvJointProbs());
/*      */     
/*  393 */     int diffMv0 = 0, diffMv1 = 0;
/*  394 */     if (joint == 2 || joint == 3)
/*  395 */       diffMv0 = readMvComponent(decoder, c, 0, useHp); 
/*  396 */     if (joint == 1 || joint == 3) {
/*  397 */       diffMv1 = readMvComponent(decoder, c, 1, useHp);
/*      */     }
/*  399 */     return MV.create(MV.x(bestMv) + diffMv0, MV.y(bestMv) + diffMv1, MV.ref(bestMv));
/*      */   }
/*      */   private static int readMvComponent(VPXBooleanDecoder decoder, DecodingContext c, int comp, boolean useHp) {
/*      */     int mag;
/*  403 */     boolean sign = (decoder.readBitEq() == 1);
/*  404 */     int mvClass = decoder.readTree(Consts.MV_CLASS_TREE, c.getMvClassProbs()[comp]);
/*      */     
/*  406 */     if (mvClass == 0) {
/*  407 */       int mvClass0Bit = decoder.readBit(c.getMvClass0BitProbs()[comp]);
/*  408 */       int mvClass0Fr = decoder.readTree(Consts.MV_FR_TREE, c.getMvClass0FrProbs()[comp][mvClass0Bit]);
/*  409 */       int mvClass0Hp = useHp ? decoder.readBit(c.getMvClass0HpProbs()[comp]) : 1;
/*  410 */       mag = (mvClass0Bit << 3 | mvClass0Fr << 1 | mvClass0Hp) + 1;
/*      */     } else {
/*  412 */       int d = 0;
/*  413 */       for (int i = 0; i < mvClass; i++) {
/*  414 */         int mvBit = decoder.readBit(c.getMvBitsProb()[comp][i]);
/*  415 */         d |= mvBit << i;
/*      */       } 
/*  417 */       mag = 2 << mvClass + 2;
/*  418 */       int mvFr = decoder.readTree(Consts.MV_FR_TREE, c.getMvFrProbs()[comp]);
/*  419 */       int mvHp = useHp ? decoder.readBit(c.getMvHpProbs()[comp]) : 1;
/*  420 */       mag += (d << 3 | mvFr << 1 | mvHp) + 1;
/*      */     } 
/*  422 */     return sign ? -mag : mag;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private static boolean largeMv(int mv) {
/*  429 */     return ((MV.x(mv) >= 64 || MV.x(mv) <= -64) && (MV.y(mv) >= 64 || MV.y(mv) <= -64));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static long findBestMv(int miCol, int miRow, int blSz, int ref, int blk, DecodingContext c, boolean clearHp) {
/*  437 */     long[][] leftMVs = c.getLeftMVs();
/*  438 */     long[][] aboveMVs = c.getAboveMVs();
/*  439 */     long[][] aboveLeftMVs = c.getAboveLeftMVs();
/*  440 */     long[] left4x4MVs = c.getLeft4x4MVs();
/*  441 */     long[] above4x4MVs = c.getAbove4x4MVs();
/*  442 */     long list = 0L;
/*  443 */     boolean checkDifferentRef = false;
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  448 */     int pt0 = Consts.mv_ref_blocks[blSz][0];
/*  449 */     int pt1 = Consts.mv_ref_blocks[blSz][1];
/*  450 */     long mvp0 = getMV(leftMVs, aboveMVs, aboveLeftMVs, pt0, miRow, miCol, c);
/*  451 */     long mvp1 = getMV(leftMVs, aboveMVs, aboveLeftMVs, pt1, miRow, miCol, c);
/*      */ 
/*      */ 
/*      */     
/*  455 */     if (blk == 1) {
/*  456 */       mvp0 = (mvp0 == -1L) ? -1L : left4x4MVs[miRow % 8];
/*  457 */     } else if (blk == 2) {
/*  458 */       mvp1 = (mvp1 == -1L) ? -1L : above4x4MVs[miCol];
/*      */     } 
/*      */     
/*  461 */     int j = ((mvp0 != 0L) ? 1 : 0) | ((mvp1 != 0L) ? 1 : 0);
/*      */     
/*  463 */     list = processCandidate(ref, list, mvp0);
/*  464 */     list = processCandidate(ref, list, mvp1);
/*      */     
/*      */     int i;
/*      */     
/*  468 */     for (i = 2; i < (Consts.mv_ref_blocks[blSz]).length && MVList.size(list) < 2; i++) {
/*  469 */       long mvi = getMV(leftMVs, aboveMVs, aboveLeftMVs, Consts.mv_ref_blocks[blSz][i], miRow, miCol, c);
/*  470 */       j |= (mvi != 0L) ? 1 : 0;
/*  471 */       list = processCandidate(ref, list, mvi);
/*      */     } 
/*      */ 
/*      */ 
/*      */     
/*  476 */     if (MVList.size(list) < 2 && c.isUsePrevFrameMvs()) {
/*  477 */       long[][] prevFrameMv = c.getPrevFrameMv();
/*  478 */       long prevMv = prevFrameMv[miCol][miRow];
/*  479 */       list = processCandidate(ref, list, prevMv);
/*      */     } 
/*      */ 
/*      */ 
/*      */     
/*  484 */     if (MVList.size(list) < 2 && j != 0) {
/*  485 */       for (i = 0; i < (Consts.mv_ref_blocks[blSz]).length && MVList.size(list) < 2; i++) {
/*  486 */         long mvp = getMV(leftMVs, aboveMVs, aboveLeftMVs, Consts.mv_ref_blocks[blSz][i], miRow, miCol, c);
/*  487 */         list = processNECandidate(ref, c, list, mvp);
/*      */       } 
/*      */     }
/*      */ 
/*      */ 
/*      */     
/*  493 */     if (MVList.size(list) < 2 && c.isUsePrevFrameMvs()) {
/*  494 */       long[][] prevFrameMv = c.getPrevFrameMv();
/*  495 */       long prevMv = prevFrameMv[miCol][miRow];
/*  496 */       list = processNECandidate(ref, c, list, prevMv);
/*      */     } 
/*      */ 
/*      */     
/*  500 */     list = clampMvs(miCol, miRow, blSz, c, list);
/*  501 */     if (clearHp) {
/*  502 */       list = clearHp(c, list);
/*      */     }
/*      */     
/*  505 */     return list;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private static long clearHp(DecodingContext c, long list) {
/*  513 */     int mv0 = MVList.get(list, 0);
/*  514 */     if (!c.isAllowHpMv() || largeMv(mv0)) {
/*  515 */       mv0 = MV.create(MV.x(mv0) & 0xFFFFFFFE, MV.y(mv0) & 0xFFFFFFFE, MV.ref(mv0));
/*      */     }
/*  517 */     int mv1 = MVList.get(list, 1);
/*  518 */     if (!c.isAllowHpMv() || largeMv(mv1)) {
/*  519 */       mv1 = MV.create(MV.x(mv1) & 0xFFFFFFFE, MV.y(mv1) & 0xFFFFFFFE, MV.ref(mv1));
/*      */     }
/*      */     
/*  522 */     list = MVList.create(mv0, mv1);
/*  523 */     return list;
/*      */   }
/*      */   
/*      */   private static long clampMvs(int miCol, int miRow, int blSz, DecodingContext c, long list) {
/*  527 */     int mv0 = MVList.get(list, 0);
/*  528 */     int mv1 = MVList.get(list, 1);
/*      */     
/*  530 */     int mv0xCl = clampMvCol(miCol, blSz, c, MV.x(mv0));
/*  531 */     int mv0yCl = clampMvRow(miRow, blSz, c, MV.y(mv0));
/*  532 */     int mv1xCl = clampMvCol(miCol, blSz, c, MV.x(mv1));
/*  533 */     int mv1yCl = clampMvRow(miRow, blSz, c, MV.y(mv1));
/*  534 */     return MVList.create(MV.create(mv0xCl, mv0yCl, MV.ref(mv0)), MV.create(mv1xCl, mv1yCl, MV.ref(mv1)));
/*      */   }
/*      */   
/*      */   private static long processNECandidate(int ref, DecodingContext c, long list, long mvp) {
/*  538 */     int mv0 = MVList.get(mvp, 0);
/*  539 */     int mv1 = MVList.get(mvp, 1);
/*  540 */     boolean matchMv = (MV.x(mv0) == MV.x(mv1) && MV.y(mv0) == MV.y(mv1));
/*  541 */     list = processNEComponent(ref, c, list, mv0);
/*  542 */     if (!matchMv)
/*  543 */       list = processNEComponent(ref, c, list, mv1); 
/*  544 */     return list;
/*      */   }
/*      */   
/*      */   private static long processNEComponent(int ref, DecodingContext c, long list, int mv0) {
/*  548 */     int ref0 = MV.ref(mv0);
/*  549 */     if (ref0 != 0 && ref0 != ref) {
/*      */       
/*  551 */       int q = c.refFrameSignBias(ref0) * c.refFrameSignBias(ref);
/*  552 */       int mv = MV.create(MV.x(mv0) * q, MV.y(mv0), ref);
/*  553 */       list = MVList.addUniq(list, mv);
/*      */     } 
/*  555 */     return list;
/*      */   }
/*      */   
/*      */   private static long processCandidate(int ref, long list, long mvp0) {
/*  559 */     int mv00 = MVList.get(mvp0, 0);
/*  560 */     int mv01 = MVList.get(mvp0, 1);
/*  561 */     if (MV.ref(mv00) == ref) {
/*  562 */       list = MVList.addUniq(list, mv00);
/*  563 */     } else if (MV.ref(mv01) == ref) {
/*  564 */       list = MVList.addUniq(list, mv01);
/*      */     } 
/*  566 */     return list;
/*      */   }
/*      */   
/*      */   private static long prepandSubMvBlk12(long list, int blkMv) {
/*  570 */     long nlist = 0L;
/*      */     
/*  572 */     nlist = MVList.add(nlist, blkMv);
/*  573 */     nlist = MVList.addUniq(nlist, MVList.get(list, 0));
/*  574 */     nlist = MVList.addUniq(nlist, MVList.get(list, 0));
/*  575 */     return nlist;
/*      */   }
/*      */   
/*      */   private static long prepandSubMvBlk3(long list, int blk0Mv, int blk1Mv, int blk2Mv) {
/*  579 */     long nlist = 0L;
/*      */     
/*  581 */     nlist = MVList.add(nlist, blk2Mv);
/*  582 */     nlist = MVList.addUniq(nlist, blk1Mv);
/*  583 */     nlist = MVList.addUniq(nlist, blk0Mv);
/*  584 */     nlist = MVList.addUniq(nlist, MVList.get(list, 0));
/*  585 */     nlist = MVList.addUniq(nlist, MVList.get(list, 0));
/*      */     
/*  587 */     return nlist;
/*      */   }
/*      */   
/*      */   private static int clampMvRow(int miRow, int blSz, DecodingContext c, int mv) {
/*  591 */     int mbToTopEdge = -(miRow << 6);
/*  592 */     int mbToBottomEdge = c.getMiFrameHeight() - Consts.blH[blSz] - miRow << 6;
/*  593 */     return clip3(mbToTopEdge - 128, mbToBottomEdge + 128, mv);
/*      */   }
/*      */   
/*      */   private static int clip3(int from, int to, int v) {
/*  597 */     return (v < from) ? from : ((v > to) ? to : v);
/*      */   }
/*      */   
/*      */   private static int clampMvCol(int miCol, int blSz, DecodingContext c, int mv) {
/*  601 */     int mbToLeftEdge = -(miCol << 6);
/*  602 */     int mbToRightEdge = c.getMiFrameWidth() - Consts.blW[blSz] - miCol << 6;
/*  603 */     return clip3(mbToLeftEdge - 128, mbToRightEdge + 128, mv);
/*      */   }
/*      */   protected int readInterpFilter(int miCol, int miRow, int blSz, VPXBooleanDecoder decoder, DecodingContext c) {
/*      */     int ctx;
/*  607 */     boolean availAbove = (miRow > 0);
/*  608 */     boolean availLeft = (miCol > c.getMiTileStartCol());
/*  609 */     int[] aboveRefs = c.getAboveRefs();
/*  610 */     int[] leftRefs = c.getLeftRefs();
/*  611 */     int aboveRefFrame0 = getRef(aboveRefs[miCol], 0);
/*  612 */     int leftRefFrame0 = getRef(leftRefs[miRow & 0x7], 0);
/*  613 */     int[] leftInterpFilters = c.getLeftInterpFilters();
/*  614 */     int[] aboveInterpFilters = c.getAboveInterpFilters();
/*      */     
/*  616 */     int leftInterp = (availLeft && leftRefFrame0 > 0) ? leftInterpFilters[miRow & 0x7] : 3;
/*  617 */     int aboveInterp = (availAbove && aboveRefFrame0 > 0) ? aboveInterpFilters[miCol] : 3;
/*  618 */     if (leftInterp == aboveInterp) {
/*  619 */       ctx = leftInterp;
/*  620 */     } else if (leftInterp == 3 && aboveInterp != 3) {
/*  621 */       ctx = aboveInterp;
/*  622 */     } else if (leftInterp != 3 && aboveInterp == 3) {
/*  623 */       ctx = leftInterp;
/*      */     } else {
/*  625 */       ctx = 3;
/*      */     } 
/*  627 */     int[][] probs = c.getInterpFilterProbs();
/*      */     
/*  629 */     int ret = decoder.readTree(Consts.TREE_INTERP_FILTER, probs[ctx]);
/*      */     int i;
/*  631 */     for (i = 0; i < Consts.blW[blSz]; i++)
/*  632 */       aboveInterpFilters[miCol + i] = ret; 
/*  633 */     for (i = 0; i < Consts.blH[blSz]; i++) {
/*  634 */       leftInterpFilters[miRow + i & 0x7] = ret;
/*      */     }
/*  636 */     return ret;
/*      */   }
/*      */   
/*      */   public int readInterMode(int miCol, int miRow, int blSz, VPXBooleanDecoder decoder, DecodingContext c) {
/*  640 */     int ctx, ind0 = Consts.mv_ref_blocks_sm[blSz][0];
/*  641 */     int ind1 = Consts.mv_ref_blocks_sm[blSz][1];
/*  642 */     int[] leftModes = c.getLeftModes();
/*  643 */     int[] aboveModes = c.getAboveModes();
/*      */     
/*  645 */     int mode0 = getMode(leftModes, aboveModes, ind0, miRow, miCol, c);
/*  646 */     int mode1 = getMode(leftModes, aboveModes, ind1, miRow, miCol, c);
/*      */     
/*  648 */     if (mode0 == 11 || mode0 == 10) {
/*  649 */       if (mode1 == 11 || mode1 == 10) {
/*  650 */         ctx = 2;
/*  651 */       } else if (mode1 == 13) {
/*  652 */         ctx = 3;
/*  653 */       } else if (mode1 == 12) {
/*  654 */         ctx = 1;
/*      */       } else {
/*  656 */         ctx = 5;
/*      */       } 
/*  658 */     } else if (mode0 == 12) {
/*  659 */       if (mode1 == 11 || mode1 == 10) {
/*  660 */         ctx = 1;
/*  661 */       } else if (mode1 == 13) {
/*  662 */         ctx = 3;
/*  663 */       } else if (mode1 == 12) {
/*  664 */         ctx = 0;
/*      */       } else {
/*  666 */         ctx = 5;
/*      */       } 
/*  668 */     } else if (mode0 == 13) {
/*  669 */       if (mode1 == 11 || mode1 == 10) {
/*  670 */         ctx = 3;
/*  671 */       } else if (mode1 == 13) {
/*  672 */         ctx = 4;
/*  673 */       } else if (mode1 == 12) {
/*  674 */         ctx = 3;
/*      */       } else {
/*  676 */         ctx = 3;
/*      */       } 
/*      */     } else {
/*  679 */       ctx = (mode1 >= 10) ? 5 : 6;
/*      */     } 
/*  681 */     System.out.println(String.format("inter_mode_ctx: %d\n", new Object[] { Integer.valueOf(ctx) }));
/*  682 */     int[][] probs = c.getInterModeProbs();
/*      */     
/*  684 */     int ret = 10 + decoder.readTree(Consts.TREE_INTER_MODE, probs[ctx]);
/*      */     int i;
/*  686 */     for (i = 0; i < Consts.blW[blSz]; i++)
/*  687 */       aboveModes[miCol + i] = ret; 
/*  688 */     for (i = 0; i < Consts.blH[blSz]; i++) {
/*  689 */       leftModes[(miRow + i) % 8] = ret;
/*      */     }
/*  691 */     return ret;
/*      */   }
/*      */   
/*      */   private static int getMode(int[] leftModes, int[] aboveModes, int ind0, int miRow, int miCol, DecodingContext c) {
/*  695 */     switch (ind0) {
/*      */       
/*      */       case 0:
/*  698 */         return (miCol > c.getMiTileStartCol()) ? leftModes[miRow % 8] : 10;
/*      */       
/*      */       case 1:
/*  701 */         return (miRow > 0) ? aboveModes[miCol] : 10;
/*      */       
/*      */       case 2:
/*  704 */         return (miCol > c.getMiTileStartCol() && miRow < c.getMiFrameHeight() - 1) ? leftModes[miRow % 8 + 1] : 10;
/*      */ 
/*      */       
/*      */       case 3:
/*  708 */         return (miCol < c.getMiTileWidth() - 1 && miRow > 0) ? aboveModes[miCol + 1] : 10;
/*      */       
/*      */       case 4:
/*  711 */         return (miCol > c.getMiTileStartCol() && miRow < c.getMiFrameHeight() - 3) ? leftModes[miRow % 8 + 3] : 10;
/*      */ 
/*      */       
/*      */       case 5:
/*  715 */         return (miCol < c.getMiTileWidth() - 3 && miRow > 0) ? aboveModes[miCol + 3] : 10;
/*      */     } 
/*  717 */     return 10;
/*      */   }
/*      */ 
/*      */   
/*      */   private static long getMV(long[][] leftMV, long[][] aboveMV, long[][] aboveLeftMV, int ind0, int miRow, int miCol, DecodingContext c) {
/*  722 */     int th = c.getMiTileHeight();
/*  723 */     int tw = c.getMiTileWidth();
/*  724 */     switch (ind0) {
/*      */       
/*      */       case 0:
/*  727 */         return (miCol >= c.getMiTileStartCol()) ? leftMV[0][miRow % 8] : 0L;
/*      */       
/*      */       case 1:
/*  730 */         return (miRow > 0) ? aboveMV[0][miCol] : 0L;
/*      */       
/*      */       case 2:
/*  733 */         return (miCol >= c.getMiTileStartCol() && miRow < th - 1) ? leftMV[0][miRow % 8 + 1] : 0L;
/*      */       
/*      */       case 3:
/*  736 */         return (miRow > 0 && miCol < tw - 1) ? aboveMV[0][miCol + 1] : 0L;
/*      */       
/*      */       case 4:
/*  739 */         return (miCol >= c.getMiTileStartCol() && miRow < th - 3) ? leftMV[0][miRow % 8 + 3] : 0L;
/*      */       
/*      */       case 5:
/*  742 */         return (miRow > 0 && miCol < tw - 3) ? aboveMV[0][miCol + 3] : 0L;
/*      */       
/*      */       case 6:
/*  745 */         return (miCol >= c.getMiTileStartCol() && miRow < th - 2) ? leftMV[0][miRow % 8 + 2] : 0L;
/*      */       
/*      */       case 7:
/*  748 */         return (miRow > 0 && miCol < tw - 2) ? aboveMV[0][miCol + 2] : 0L;
/*      */       
/*      */       case 8:
/*  751 */         return (miCol >= c.getMiTileStartCol() && miRow < th - 4) ? leftMV[0][miRow % 8 + 4] : 0L;
/*      */       
/*      */       case 9:
/*  754 */         return (miRow > 0 && miCol < tw - 4) ? aboveMV[0][miCol + 4] : 0L;
/*      */       
/*      */       case 10:
/*  757 */         return (miCol >= c.getMiTileStartCol() && miRow < th - 6) ? leftMV[0][miRow % 8 + 6] : 0L;
/*      */       
/*      */       case 11:
/*  760 */         return (miCol >= c.getMiTileStartCol() && miRow > 0) ? aboveLeftMV[0][0] : 0L;
/*      */       
/*      */       case 12:
/*  763 */         return (miCol >= c.getMiTileStartCol() + 1) ? leftMV[1][miRow % 8] : 0L;
/*      */       
/*      */       case 13:
/*  766 */         return (miRow > 1) ? aboveMV[1][miCol] : 0L;
/*      */       
/*      */       case 14:
/*  769 */         return (miCol >= c.getMiTileStartCol() + 2) ? leftMV[2][miRow % 8] : 0L;
/*      */       
/*      */       case 15:
/*  772 */         return (miRow > 2) ? aboveMV[2][miCol] : 0L;
/*      */       
/*      */       case 16:
/*  775 */         return (miCol >= c.getMiTileStartCol() + 1 && miRow > 0) ? aboveLeftMV[0][1] : 0L;
/*      */       
/*      */       case 17:
/*  778 */         return (miCol >= c.getMiTileStartCol() && miRow > 1) ? aboveLeftMV[1][0] : 0L;
/*      */       
/*      */       case 18:
/*  781 */         return (miCol >= c.getMiTileStartCol() + 1 && miRow > 1) ? aboveLeftMV[1][1] : 0L;
/*      */       
/*      */       case 19:
/*  784 */         return (miCol >= c.getMiTileStartCol() + 2 && miRow > 2) ? aboveLeftMV[2][2] : 0L;
/*      */     } 
/*  786 */     return 0L;
/*      */   }
/*      */   
/*      */   protected int readCompRef(int miCol, int miRow, int blSz, VPXBooleanDecoder decoder, DecodingContext c) {
/*  790 */     int aboveVarRefFrame, leftVarRefFrame, ctx, compFixedRef = c.getCompFixedRef();
/*  791 */     int fixRefIdx = c.refFrameSignBias(compFixedRef);
/*  792 */     boolean availAbove = (miRow > 0);
/*  793 */     boolean availLeft = (miCol > c.getMiTileStartCol());
/*  794 */     boolean[] aboveCompound = c.getAboveCompound();
/*  795 */     boolean[] leftCompound = c.getLeftCompound();
/*  796 */     int aboveRefFrame0 = getRef(c.getAboveRefs()[miCol], 0);
/*  797 */     int leftRefFrame0 = getRef(c.getLeftRefs()[miRow & 0x7], 0);
/*  798 */     int aboveRefFrame1 = getRef(c.getAboveRefs()[miCol], 1);
/*  799 */     int leftRefFrame1 = getRef(c.getLeftRefs()[miRow & 0x7], 1);
/*  800 */     boolean aboveIntra = (aboveRefFrame0 <= 0);
/*  801 */     boolean leftIntra = (leftRefFrame0 <= 0);
/*  802 */     boolean aboveSingle = !aboveCompound[miCol];
/*  803 */     boolean leftSingle = !leftCompound[miRow % 8];
/*      */     
/*  805 */     if (fixRefIdx == 0) {
/*  806 */       aboveVarRefFrame = aboveRefFrame1;
/*  807 */       leftVarRefFrame = leftRefFrame1;
/*      */     } else {
/*  809 */       aboveVarRefFrame = aboveRefFrame0;
/*  810 */       leftVarRefFrame = leftRefFrame0;
/*      */     } 
/*      */     
/*  813 */     int compVarRef0 = c.getCompVarRef(0);
/*  814 */     int compVarRef1 = c.getCompVarRef(1);
/*      */ 
/*      */     
/*  817 */     if (availAbove && availLeft) {
/*  818 */       if (aboveIntra && leftIntra)
/*  819 */       { ctx = 2; }
/*  820 */       else if (leftIntra)
/*  821 */       { if (aboveSingle)
/*  822 */         { ctx = 1 + 2 * ((aboveRefFrame0 != compVarRef1) ? 1 : 0); }
/*      */         else
/*  824 */         { ctx = 1 + 2 * ((aboveVarRefFrame != compVarRef1) ? 1 : 0); }  }
/*  825 */       else if (aboveIntra)
/*  826 */       { if (leftSingle) {
/*  827 */           ctx = 1 + 2 * ((leftRefFrame0 != compVarRef1) ? 1 : 0);
/*      */         } else {
/*  829 */           ctx = 1 + 2 * ((leftVarRefFrame != compVarRef1) ? 1 : 0);
/*      */         }  }
/*  831 */       else { int vrfa = aboveSingle ? aboveRefFrame0 : aboveVarRefFrame;
/*  832 */         int vrfl = leftSingle ? leftRefFrame0 : leftVarRefFrame;
/*  833 */         if (vrfa == vrfl && compVarRef1 == vrfa) {
/*  834 */           ctx = 0;
/*  835 */         } else if (leftSingle && aboveSingle) {
/*  836 */           if ((vrfa == compFixedRef && vrfl == compVarRef0) || (vrfl == compFixedRef && vrfa == compVarRef0))
/*  837 */           { ctx = 4; }
/*  838 */           else if (vrfa == vrfl)
/*  839 */           { ctx = 3; }
/*      */           else
/*  841 */           { ctx = 1; } 
/*  842 */         } else if (leftSingle || aboveSingle) {
/*  843 */           int vrfc = leftSingle ? vrfa : vrfl;
/*  844 */           int rfs = aboveSingle ? vrfa : vrfl;
/*  845 */           if (vrfc == compVarRef1 && rfs != compVarRef1)
/*  846 */           { ctx = 1; }
/*  847 */           else if (rfs == compVarRef1 && vrfc != compVarRef1)
/*  848 */           { ctx = 2; }
/*      */           else
/*  850 */           { ctx = 4; } 
/*  851 */         } else if (vrfa == vrfl) {
/*  852 */           ctx = 4;
/*      */         } else {
/*  854 */           ctx = 2;
/*      */         }  }
/*      */     
/*  857 */     } else if (availAbove) {
/*  858 */       if (aboveIntra) {
/*  859 */         ctx = 2;
/*      */       }
/*  861 */       else if (aboveSingle) {
/*  862 */         ctx = 3 * ((aboveRefFrame0 != compVarRef1) ? 1 : 0);
/*      */       } else {
/*  864 */         ctx = 4 * ((aboveVarRefFrame != compVarRef1) ? 1 : 0);
/*      */       } 
/*  866 */     } else if (availLeft) {
/*  867 */       if (leftIntra) {
/*  868 */         ctx = 2;
/*      */       }
/*  870 */       else if (leftSingle) {
/*  871 */         ctx = 3 * ((leftRefFrame0 != compVarRef1) ? 1 : 0);
/*      */       } else {
/*  873 */         ctx = 4 * ((leftVarRefFrame != compVarRef1) ? 1 : 0);
/*      */       } 
/*      */     } else {
/*  876 */       ctx = 2;
/*      */     } 
/*      */     
/*  879 */     int[] probs = c.getCompRefProbs();
/*      */     
/*  881 */     return decoder.readBit(probs[ctx]);
/*      */   }
/*      */   
/*      */   protected int readSingleRef(int miCol, int miRow, VPXBooleanDecoder decoder, DecodingContext c) {
/*  885 */     boolean singleRefP1 = readSingRefBin(0, miCol, miRow, decoder, c);
/*  886 */     if (singleRefP1) {
/*  887 */       boolean singleRefP2 = readSingRefBin(2, miCol, miRow, decoder, c);
/*  888 */       return singleRefP2 ? 2 : 3;
/*      */     } 
/*  890 */     return 1;
/*      */   }
/*      */   
/*      */   private boolean readSingRefBin(int bin, int miCol, int miRow, VPXBooleanDecoder decoder, DecodingContext c) {
/*      */     int ctx;
/*  895 */     boolean availAbove = (miRow > 0);
/*  896 */     boolean availLeft = (miCol > c.getMiTileStartCol());
/*  897 */     boolean[] aboveCompound = c.getAboveCompound();
/*  898 */     boolean[] leftCompound = c.getLeftCompound();
/*  899 */     int aboveRefFrame0 = getRef(c.getAboveRefs()[miCol], 0);
/*  900 */     int leftRefFrame0 = getRef(c.getLeftRefs()[miRow & 0x7], 0);
/*  901 */     int aboveRefFrame1 = getRef(c.getAboveRefs()[miCol], 1);
/*  902 */     int leftRefFrame1 = getRef(c.getLeftRefs()[miRow & 0x7], 1);
/*  903 */     boolean aboveIntra = (aboveRefFrame0 <= 0);
/*  904 */     boolean leftIntra = (leftRefFrame0 <= 0);
/*  905 */     boolean aboveSingle = !aboveCompound[miCol];
/*  906 */     boolean leftSingle = !leftCompound[miRow % 8];
/*      */ 
/*      */     
/*  909 */     if (availAbove && availLeft) {
/*  910 */       if (aboveIntra && leftIntra) {
/*  911 */         ctx = 2;
/*  912 */       } else if (leftIntra) {
/*  913 */         if (aboveSingle) {
/*  914 */           if (bin == 0) {
/*  915 */             ctx = 4 * ((aboveRefFrame0 == 1) ? 1 : 0);
/*      */           }
/*  917 */           else if (aboveRefFrame0 == 1) {
/*  918 */             ctx = 3;
/*      */           } else {
/*  920 */             ctx = 4 * ((aboveRefFrame0 == 3) ? 1 : 0);
/*      */           }
/*      */         
/*  923 */         } else if (bin == 0) {
/*  924 */           ctx = 1 + ((aboveRefFrame0 == 1 || aboveRefFrame1 == 1) ? 1 : 0);
/*      */         } else {
/*  926 */           ctx = 1 + 2 * ((aboveRefFrame0 == 3 || aboveRefFrame1 == 3) ? 1 : 0);
/*      */         } 
/*  928 */       } else if (aboveIntra) {
/*  929 */         if (leftSingle) {
/*  930 */           if (bin == 0) {
/*  931 */             ctx = 4 * ((leftRefFrame0 == 1) ? 1 : 0);
/*      */           }
/*  933 */           else if (leftRefFrame0 == 1) {
/*  934 */             ctx = 3;
/*      */           } else {
/*  936 */             ctx = 4 * ((leftRefFrame0 == 3) ? 1 : 0);
/*      */           }
/*      */         
/*  939 */         } else if (bin == 0) {
/*  940 */           ctx = 1 + ((leftRefFrame0 == 1 || leftRefFrame1 == 1) ? 1 : 0);
/*      */         } else {
/*  942 */           ctx = 1 + 2 * ((leftRefFrame0 == 3 || leftRefFrame1 == 3) ? 1 : 0);
/*      */         }
/*      */       
/*  945 */       } else if (aboveSingle && leftSingle) {
/*  946 */         if (bin == 0) {
/*  947 */           ctx = 2 * ((aboveRefFrame0 == 1) ? 1 : 0) + 2 * ((leftRefFrame0 == 1) ? 1 : 0);
/*      */         }
/*  949 */         else if (aboveRefFrame0 == 1 && leftRefFrame0 == 1) {
/*  950 */           ctx = 3;
/*  951 */         } else if (aboveRefFrame0 == 1) {
/*  952 */           ctx = 4 * ((leftRefFrame0 == 3) ? 1 : 0);
/*  953 */         } else if (leftRefFrame0 == 1) {
/*  954 */           ctx = 4 * ((aboveRefFrame0 == 3) ? 1 : 0);
/*      */         } else {
/*  956 */           ctx = 2 * ((aboveRefFrame0 == 3) ? 1 : 0) + 2 * ((leftRefFrame0 == 3) ? 1 : 0);
/*      */         }
/*      */       
/*      */       }
/*  960 */       else if (!aboveSingle && !leftSingle) {
/*  961 */         if (bin == 0) {
/*  962 */           ctx = 1 + ((aboveRefFrame0 == 1 || aboveRefFrame1 == 1 || leftRefFrame0 == 1 || leftRefFrame1 == 1) ? 1 : 0);
/*      */         
/*      */         }
/*  965 */         else if (aboveRefFrame0 == leftRefFrame0 && aboveRefFrame1 == leftRefFrame1) {
/*  966 */           ctx = 3 * ((aboveRefFrame0 == 3 || aboveRefFrame1 == 3) ? 1 : 0);
/*      */         } else {
/*  968 */           ctx = 2;
/*      */         } 
/*      */       } else {
/*  971 */         int rfs = aboveSingle ? aboveRefFrame0 : leftRefFrame0;
/*  972 */         int crf1 = aboveSingle ? leftRefFrame0 : aboveRefFrame0;
/*  973 */         int crf2 = aboveSingle ? leftRefFrame1 : aboveRefFrame1;
/*  974 */         if (bin == 0) {
/*  975 */           if (rfs == 1) {
/*  976 */             ctx = 3 + ((crf1 == 1 || crf2 == 1) ? 1 : 0);
/*      */           } else {
/*  978 */             ctx = (crf1 == 1 || crf2 == 1) ? 1 : 0;
/*      */           } 
/*  980 */         } else if (rfs == 3) {
/*  981 */           ctx = 3 + ((crf1 == 3 || crf2 == 3) ? 1 : 0);
/*  982 */         } else if (rfs == 2) {
/*  983 */           ctx = (crf1 == 3 || crf2 == 3) ? 1 : 0;
/*      */         } else {
/*  985 */           ctx = 1 + 2 * ((crf1 == 3 || crf2 == 3) ? 1 : 0);
/*      */         }
/*      */       
/*      */       } 
/*  989 */     } else if (availAbove) {
/*  990 */       if (aboveIntra || (bin == 1 && aboveRefFrame0 == 1 && aboveSingle)) {
/*  991 */         ctx = 2;
/*      */       
/*      */       }
/*  994 */       else if (aboveSingle) {
/*  995 */         if (bin == 0) {
/*  996 */           ctx = 4 * ((aboveRefFrame0 == 1) ? 1 : 0);
/*      */         } else {
/*  998 */           ctx = 4 * ((aboveRefFrame0 == 3) ? 1 : 0);
/*      */         } 
/* 1000 */       } else if (bin == 0) {
/* 1001 */         ctx = 1 + ((aboveRefFrame0 == 1 || aboveRefFrame1 == 1) ? 1 : 0);
/*      */       } else {
/* 1003 */         ctx = 3 * ((aboveRefFrame0 == 3 || aboveRefFrame1 == 3) ? 1 : 0);
/*      */       }
/*      */     
/* 1006 */     } else if (availLeft) {
/*      */       
/* 1008 */       if (leftIntra || (bin == 1 && leftRefFrame0 == 1 && leftSingle)) {
/* 1009 */         ctx = 2;
/*      */       }
/* 1011 */       else if (leftSingle) {
/* 1012 */         if (bin == 0) {
/* 1013 */           ctx = 4 * ((leftRefFrame0 == 1) ? 1 : 0);
/*      */         } else {
/* 1015 */           ctx = 4 * ((leftRefFrame0 == 3) ? 1 : 0);
/*      */         } 
/* 1017 */       } else if (bin == 0) {
/* 1018 */         ctx = 1 + ((leftRefFrame0 == 1 || leftRefFrame1 == 1) ? 1 : 0);
/*      */       } else {
/* 1020 */         ctx = 3 * ((leftRefFrame0 == 3 || leftRefFrame1 == 3) ? 1 : 0);
/*      */       } 
/*      */     } else {
/*      */       
/* 1024 */       ctx = 2;
/*      */     } 
/* 1026 */     int[][] probs = c.getSingleRefProbs();
/*      */     
/* 1028 */     return (decoder.readBit(probs[ctx][bin]) == 1);
/*      */   }
/*      */   protected boolean readRefMode(int miCol, int miRow, VPXBooleanDecoder decoder, DecodingContext c) {
/*      */     int ctx;
/* 1032 */     boolean availAbove = (miRow > 0);
/* 1033 */     boolean availLeft = (miCol > c.getMiTileStartCol());
/* 1034 */     boolean[] aboveCompound = c.getAboveCompound();
/* 1035 */     boolean[] leftCompound = c.getLeftCompound();
/* 1036 */     int aboveRefFrame0 = getRef(c.getAboveRefs()[miCol], 0);
/* 1037 */     int leftRefFrame0 = getRef(c.getLeftRefs()[miRow & 0x7], 0);
/* 1038 */     int compFixedRef = c.getCompFixedRef();
/* 1039 */     boolean aboveSingle = !aboveCompound[miCol];
/* 1040 */     boolean leftSingle = !leftCompound[miRow % 8];
/* 1041 */     boolean aboveIntra = (aboveRefFrame0 <= 0);
/* 1042 */     boolean leftIntra = (leftRefFrame0 <= 0);
/*      */ 
/*      */     
/* 1045 */     if (availAbove && availLeft)
/* 1046 */     { if (aboveSingle && leftSingle)
/* 1047 */       { ctx = ((((aboveRefFrame0 == compFixedRef) ? 1 : 0) ^ ((leftRefFrame0 == compFixedRef) ? 1 : 0)) != 0) ? 1 : 0; }
/* 1048 */       else if (aboveSingle)
/* 1049 */       { ctx = 2 + ((aboveRefFrame0 == compFixedRef || aboveIntra) ? 1 : 0); }
/* 1050 */       else if (leftSingle)
/* 1051 */       { ctx = 2 + ((leftRefFrame0 == compFixedRef || leftIntra) ? 1 : 0); }
/*      */       else
/* 1053 */       { ctx = 4; }  }
/* 1054 */     else if (availAbove)
/* 1055 */     { if (aboveSingle)
/* 1056 */       { ctx = (aboveRefFrame0 == compFixedRef) ? 1 : 0; }
/*      */       else
/* 1058 */       { ctx = 3; }  }
/* 1059 */     else if (availLeft)
/* 1060 */     { if (leftSingle) {
/* 1061 */         ctx = (leftRefFrame0 == compFixedRef) ? 1 : 0;
/*      */       } else {
/* 1063 */         ctx = 3;
/*      */       }  }
/* 1065 */     else { ctx = 1; }
/*      */     
/* 1067 */     int[] probs = c.getCompModeProb();
/*      */     
/* 1069 */     return (decoder.readBit(probs[ctx]) == 1);
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   private InterModeInfo readInterIntraMode(int miCol, int miRow, int blSz, VPXBooleanDecoder decoder, DecodingContext c, int segmentId, boolean skip, int txSize) {
/* 1075 */     int yMode, subModes = 0;
/* 1076 */     if (blSz >= 3) {
/* 1077 */       yMode = readInterIntraMode(miCol, miRow, blSz, decoder, c);
/*      */     } else {
/* 1079 */       subModes = readInterIntraModeSub(miCol, miRow, blSz, decoder, c);
/*      */       
/* 1081 */       yMode = subModes & 0xFF;
/*      */     } 
/* 1083 */     int uvMode = readKfUvMode(yMode, decoder, c);
/*      */     
/* 1085 */     return new InterModeInfo(segmentId, skip, txSize, yMode, subModes, uvMode, 0L, 0L, 0L, 0L);
/*      */   }
/*      */   
/*      */   protected int readInterIntraMode(int miCol, int miRow, int blSz, VPXBooleanDecoder decoder, DecodingContext c) {
/* 1089 */     int[][] probs = c.getYModeProbs();
/* 1090 */     return decoder.readTree(Consts.TREE_INTRA_MODE, probs[Consts.size_group_lookup[blSz]]);
/*      */   }
/*      */   
/*      */   protected int readInterIntraModeSub(int miCol, int miRow, int blSz, VPXBooleanDecoder decoder, DecodingContext c) {
/* 1094 */     int[][] probs = c.getYModeProbs();
/* 1095 */     int mode0 = decoder.readTree(Consts.TREE_INTRA_MODE, probs[0]);
/* 1096 */     int mode1 = decoder.readTree(Consts.TREE_INTRA_MODE, probs[0]);
/* 1097 */     int mode2 = decoder.readTree(Consts.TREE_INTRA_MODE, probs[0]);
/* 1098 */     int mode3 = decoder.readTree(Consts.TREE_INTRA_MODE, probs[0]);
/*      */     
/* 1100 */     return ModeInfo.vect4(mode0, mode1, mode2, mode3);
/*      */   }
/*      */   
/*      */   public int readKfUvMode(int yMode, VPXBooleanDecoder decoder, DecodingContext c) {
/* 1104 */     int[][] probs = c.getUvModeProbs();
/* 1105 */     return decoder.readTree(Consts.TREE_INTRA_MODE, probs[yMode]);
/*      */   }
/*      */   
/*      */   protected boolean readIsInter(int miCol, int miRow, int blSz, VPXBooleanDecoder decoder, DecodingContext c) {
/* 1109 */     boolean availAbove = (miRow > 0);
/* 1110 */     boolean availLeft = (miCol > c.getMiTileStartCol());
/* 1111 */     int aboveRefFrame0 = getRef(c.getAboveRefs()[miCol], 0);
/* 1112 */     int leftRefFrame0 = getRef(c.getLeftRefs()[miRow & 0x7], 0);
/*      */     
/* 1114 */     boolean leftIntra = availLeft ? ((leftRefFrame0 <= 0)) : true;
/* 1115 */     boolean aboveIntra = availAbove ? ((aboveRefFrame0 <= 0)) : true;
/*      */     
/* 1117 */     int ctx = 0;
/* 1118 */     if (availAbove && availLeft) {
/* 1119 */       ctx = (leftIntra && aboveIntra) ? 3 : ((leftIntra || aboveIntra) ? 1 : 0);
/* 1120 */     } else if (availAbove || availLeft) {
/* 1121 */       ctx = 2 * (availAbove ? (aboveIntra ? 1 : 0) : (leftIntra ? 1 : 0));
/*      */     } 
/* 1123 */     int[] probs = c.getIsInterProbs();
/* 1124 */     return (decoder.readBit(probs[ctx]) == 1);
/*      */   }
/*      */ 
/*      */   
/*      */   private static boolean readSegIdPredicted(int miCol, int miRow, int blSz, VPXBooleanDecoder decoder, DecodingContext c) {
/* 1129 */     boolean[] aboveSegIdPredicted = c.getAboveSegIdPredicted();
/* 1130 */     boolean[] leftSegIdPredicted = c.getLeftSegIdPredicted();
/*      */     
/* 1132 */     int ctx = (aboveSegIdPredicted[miRow] ? 1 : 0) + (leftSegIdPredicted[miCol] ? 1 : 0);
/* 1133 */     int[] prob = c.getSegmentationPredProbs();
/*      */     
/* 1135 */     boolean ret = (decoder.readBit(prob[ctx]) == 1);
/*      */     int i;
/* 1137 */     for (i = 0; i < Consts.blH[blSz]; i++)
/* 1138 */       aboveSegIdPredicted[miCol + i] = ret; 
/* 1139 */     for (i = 0; i < Consts.blW[blSz]; i++) {
/* 1140 */       leftSegIdPredicted[miRow + i] = ret;
/*      */     }
/* 1142 */     return false;
/*      */   }
/*      */   
/*      */   private static int predicSegmentId(int miCol, int miRow, int blSz, DecodingContext c) {
/* 1146 */     int blWcl = Math.min(c.getMiTileWidth() - miCol, Consts.blW[blSz]);
/* 1147 */     int blHcl = Math.min(c.getMiTileHeight() - miRow, Consts.blH[blSz]);
/* 1148 */     int[][] prevSegmentIds = c.getPrevSegmentIds();
/* 1149 */     int seg = 7;
/* 1150 */     for (int y = 0; y < blHcl; y++) {
/* 1151 */       for (int x = 0; x < blWcl; x++)
/* 1152 */         seg = Math.min(seg, prevSegmentIds[miRow + y][miCol + x]); 
/* 1153 */     }  return seg;
/*      */   }
/*      */ }


/* Location:              C:\Users\rapha\Downloads\aurora.jar!\META-INF\jars\jcodec-0.2.5.jar!\org\jcodec\codecs\vpx\vp9\InterModeInfo.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */