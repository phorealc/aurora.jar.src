/*    */ package org.jcodec.codecs.vpx.vp9;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class MVList
/*    */ {
/* 14 */   private static long LO_MASK = 2147483647L;
/* 15 */   private static long HI_MASK = LO_MASK << 31L;
/* 16 */   private static long HI_MASK_NEG = (HI_MASK | 0xC000000000000000L) ^ 0xFFFFFFFFFFFFFFFFL;
/* 17 */   private static long LO_MASK_NEG = (LO_MASK | 0xC000000000000000L) ^ 0xFFFFFFFFFFFFFFFFL;
/*    */   
/*    */   public static long create(int mv0, int mv1) {
/* 20 */     return Long.MIN_VALUE | mv1 << 31L | mv0 & LO_MASK;
/*    */   }
/*    */   
/*    */   public static long addUniq(long list, int mv) {
/* 24 */     long cnt = list >> 62L & 0x3L;
/* 25 */     if (cnt == 2L)
/* 26 */       return list; 
/* 27 */     if (cnt == 0L) {
/* 28 */       return 0x4000000000000000L | list & LO_MASK_NEG | mv & LO_MASK;
/*    */     }
/* 30 */     int first = (int)(list & LO_MASK);
/* 31 */     if (first != mv) {
/* 32 */       return Long.MIN_VALUE | list & HI_MASK_NEG | mv << 31L & HI_MASK;
/*    */     }
/* 34 */     return list;
/*    */   }
/*    */ 
/*    */   
/*    */   public static long add(long list, int mv) {
/* 39 */     long cnt = list >> 62L & 0x3L;
/* 40 */     if (cnt == 2L)
/* 41 */       return list; 
/* 42 */     if (cnt == 0L) {
/* 43 */       return 0x4000000000000000L | list & LO_MASK_NEG | mv & LO_MASK;
/*    */     }
/* 45 */     return Long.MIN_VALUE | list & HI_MASK_NEG | mv << 31L & HI_MASK;
/*    */   }
/*    */ 
/*    */   
/*    */   public static int get(long list, int n) {
/* 50 */     if (n == 0) {
/* 51 */       return (int)(list & LO_MASK);
/*    */     }
/* 53 */     return (int)(list >> 31L & LO_MASK);
/*    */   }
/*    */   
/*    */   public static long set(long list, int n, int mv) {
/* 57 */     long cnt = list >> 62L & 0x3L;
/* 58 */     long newc = (n + 1);
/* 59 */     cnt = (newc > cnt) ? newc : cnt;
/* 60 */     if (n == 0) {
/* 61 */       return cnt << 62L | list & LO_MASK_NEG | mv & LO_MASK;
/*    */     }
/* 63 */     return cnt << 62L | list & HI_MASK_NEG | mv << 31L & HI_MASK;
/*    */   }
/*    */ 
/*    */   
/*    */   public static int size(long list) {
/* 68 */     return (int)(list >> 62L & 0x3L);
/*    */   }
/*    */ }


/* Location:              C:\Users\rapha\Downloads\aurora.jar!\META-INF\jars\jcodec-0.2.5.jar!\org\jcodec\codecs\vpx\vp9\MVList.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */