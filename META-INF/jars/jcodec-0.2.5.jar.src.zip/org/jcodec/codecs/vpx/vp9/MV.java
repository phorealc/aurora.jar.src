/*    */ package org.jcodec.codecs.vpx.vp9;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class MV
/*    */ {
/*    */   public static int create(int x, int y, int ref) {
/*  9 */     return ref << 28 | (y & 0x3FFF) << 14 | x & 0x3FFF;
/*    */   }
/*    */   
/*    */   public static int x(int mv) {
/* 13 */     return mv << 18 >> 18;
/*    */   }
/*    */   
/*    */   public static int y(int mv) {
/* 17 */     return mv << 4 >> 18;
/*    */   }
/*    */   
/*    */   public static int ref(int mv) {
/* 21 */     return mv >> 28 & 0x3;
/*    */   }
/*    */ }


/* Location:              C:\Users\rapha\Downloads\aurora.jar!\META-INF\jars\jcodec-0.2.5.jar!\org\jcodec\codecs\vpx\vp9\MV.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */