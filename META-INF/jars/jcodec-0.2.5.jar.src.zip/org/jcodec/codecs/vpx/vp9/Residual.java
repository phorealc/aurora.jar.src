/*     */ package org.jcodec.codecs.vpx.vp9;
/*     */ 
/*     */ import org.jcodec.codecs.vpx.VPXBooleanDecoder;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class Residual
/*     */ {
/*     */   private int[][][] coefs;
/*     */   
/*     */   public Residual(int[][][] coefs) {
/*  44 */     this.coefs = coefs;
/*     */   }
/*     */ 
/*     */   
/*     */   protected Residual() {}
/*     */ 
/*     */   
/*     */   public static Residual readResidual(int miCol, int miRow, int blSz, VPXBooleanDecoder decoder, DecodingContext c, ModeInfo mode) {
/*  52 */     Residual ret = new Residual();
/*  53 */     ret.read(miCol, miRow, blSz, decoder, c, mode);
/*  54 */     return ret;
/*     */   }
/*     */ 
/*     */   
/*     */   public void read(int miCol, int miRow, int blType, VPXBooleanDecoder decoder, DecodingContext c, ModeInfo modeInfo) {
/*  59 */     if (modeInfo.isSkip())
/*     */       return; 
/*  61 */     int subXRound = (1 << c.getSubX()) - 1;
/*  62 */     int subYRound = (1 << c.getSubY()) - 1;
/*     */     
/*  64 */     int[][][] coefs = new int[3][][];
/*  65 */     for (int pl = 0; pl < 3; pl++) {
/*     */       
/*  67 */       int txSize = (pl == 0) ? modeInfo.getTxSize() : Consts.uv_txsize_lookup[blType][modeInfo.getTxSize()][c.getSubX()][c.getSubY()];
/*  68 */       int step4x4 = 1 << txSize;
/*     */       
/*  70 */       int n4w = 1 << Consts.blW[blType];
/*  71 */       int n4h = 1 << Consts.blH[blType];
/*  72 */       if (pl != 0) {
/*  73 */         n4w >>= c.getSubX();
/*  74 */         n4h >>= c.getSubY();
/*     */       } 
/*  76 */       int extra4w = (miCol << 1) + n4w - (c.getFrameWidth() + 3 >> 2);
/*  77 */       int extra4h = (miRow << 1) + n4h - (c.getFrameHeight() + 3 >> 2);
/*  78 */       int startBlkX = miCol << 1;
/*  79 */       int startBlkY = miRow << 1;
/*  80 */       if (pl != 0) {
/*  81 */         extra4w = extra4w + subXRound >> c.getSubX();
/*  82 */         extra4h = extra4h + subYRound >> c.getSubY();
/*  83 */         startBlkX >>= c.getSubX();
/*  84 */         startBlkY >>= c.getSubY();
/*     */       } 
/*  86 */       int max4w = n4w - ((extra4w > 0) ? extra4w : 0);
/*  87 */       int max4h = n4h - ((extra4h > 0) ? extra4h : 0);
/*     */       
/*  89 */       coefs[pl] = new int[n4w * n4h][]; int y;
/*  90 */       for (y = 0; y < max4h; y += step4x4) {
/*  91 */         int x; for (x = 0; x < max4w; x += step4x4) {
/*  92 */           int predMode, blkCol = startBlkX + x;
/*  93 */           int blkRow = startBlkY + y;
/*     */           
/*  95 */           if (pl == 0) {
/*  96 */             predMode = modeInfo.getYMode();
/*  97 */             if (blType < 3)
/*  98 */               predMode = ModeInfo.vect4get(modeInfo.getSubModes(), (y << 1) + x); 
/*     */           } else {
/* 100 */             predMode = modeInfo.getUvMode();
/* 101 */           }  coefs[pl][x + n4w * y] = readOneTU((pl == 0) ? 0 : 1, blkCol, blkRow, txSize, modeInfo.isInter(), predMode, decoder, c);
/*     */         } 
/*     */       } 
/*     */     } 
/*     */     
/* 106 */     this.coefs = coefs;
/*     */   }
/*     */   
/* 109 */   public static int[][] blk_size_lookup = new int[][] { { -1, 0, 2 }, { 1, 3, 5 }, { 4, 6, 8 }, { 7, 9, 11 }, { 10, 12, -1 } };
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int[] readOneTU(int plane, int blkCol, int blkRow, int txSz, boolean isInter, int intraMode, VPXBooleanDecoder decoder, DecodingContext c) {
/* 115 */     int[] tokenCache = new int[16 << txSz << 1];
/* 116 */     int maxCoeff = 16 << txSz << 1;
/* 117 */     boolean expectMoreCoefs = false;
/* 118 */     int txType = (plane == 0 && !isInter) ? Consts.intra_mode_to_tx_type_lookup[intraMode] : 0;
/* 119 */     int[] scan = (plane == 0 && !isInter) ? Scan.vp9_scan_orders[txSz][txType][0] : Scan.vp9_default_scan_orders[txSz][0];
/*     */     
/* 121 */     int[] neighbors = (plane == 0 && !isInter) ? Scan.vp9_scan_orders[txSz][txType][2] : Scan.vp9_default_scan_orders[txSz][2];
/*     */     
/* 123 */     int[] coefs = new int[maxCoeff];
/* 124 */     int ctx = calcTokenContextCoef0(plane, txSz, blkCol, blkRow, c);
/* 125 */     for (int cf = 0; cf < maxCoeff; cf++) {
/* 126 */       int band = (txSz == 0) ? Consts.coefband_4x4[cf] : Consts.coefband_8x8plus[cf];
/* 127 */       int pos = scan[cf];
/* 128 */       int[] probs = c.getCoefProbs()[txSz][(plane > 0) ? 1 : 0][isInter ? 1 : 0][band][ctx];
/*     */       
/* 130 */       if (!expectMoreCoefs) {
/* 131 */         boolean moreCoefs = (decoder.readBit(probs[0]) == 1);
/* 132 */         if (!moreCoefs) {
/*     */           break;
/*     */         }
/*     */       } 
/* 136 */       if (decoder.readBit(probs[1]) == 0) {
/* 137 */         tokenCache[pos] = 0;
/* 138 */         expectMoreCoefs = true;
/*     */       } else {
/* 140 */         int coef; expectMoreCoefs = false;
/* 141 */         if (decoder.readBit(probs[2]) == 0) {
/* 142 */           tokenCache[pos] = 1;
/* 143 */           coef = 1;
/*     */         } else {
/* 145 */           int token = decoder.readTree(Consts.TOKEN_TREE, Consts.PARETO_TABLE[probs[2] - 1]);
/* 146 */           if (token < 5)
/* 147 */           { coef = token;
/* 148 */             if (token == 2) {
/* 149 */               tokenCache[pos] = 2;
/*     */             } else {
/* 151 */               tokenCache[pos] = 3;
/*     */             }  }
/* 153 */           else { if (token < 7) {
/* 154 */               tokenCache[pos] = 4;
/*     */             } else {
/* 156 */               tokenCache[pos] = 5;
/* 157 */             }  coef = readCoef(token, decoder, c); }
/*     */         
/*     */         } 
/* 160 */         int sign = decoder.readBitEq();
/* 161 */         coefs[pos] = (sign == 1) ? -coef : coef;
/*     */       } 
/* 163 */       ctx = 1 + tokenCache[neighbors[2 * cf + 2]] + tokenCache[neighbors[2 * cf + 3]] >> 1;
/* 164 */       System.out.println("CTX: " + ctx);
/*     */     } 
/* 166 */     return coefs;
/*     */   }
/*     */   
/*     */   private static int readCoef(int token, VPXBooleanDecoder decoder, DecodingContext c) {
/* 170 */     int cat = Consts.extra_bits[token][0];
/* 171 */     int numExtra = Consts.extra_bits[token][1];
/* 172 */     int coef = Consts.extra_bits[token][2];
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 180 */     for (int bit = 0; bit < numExtra; bit++) {
/* 181 */       int coef_bit = decoder.readBit(Consts.cat_probs[cat][bit]);
/*     */       
/* 183 */       coef += coef_bit << numExtra - 1 - bit;
/*     */     } 
/* 185 */     return coef;
/*     */   }
/*     */   
/*     */   private static int calcTokenContextCoef0(int plane, int txSz, int blkCol, int blkRow, DecodingContext c) {
/* 189 */     int[][] aboveNonzeroContext = c.getAboveNonzeroContext();
/* 190 */     int[][] leftNonzeroContext = c.getLeftNonzeroContext();
/* 191 */     int subX = (plane > 0) ? c.getSubX() : 0;
/* 192 */     int subY = (plane > 0) ? c.getSubY() : 0;
/* 193 */     int max4x = c.getMiFrameWidth() << 1 >> subX;
/* 194 */     int max4y = c.getMiFrameHeight() << 1 >> subY;
/* 195 */     int tx4 = 1 << txSz;
/* 196 */     int aboveNz = 0;
/* 197 */     int leftNz = 0;
/* 198 */     for (int i = 0; i < tx4; i++) {
/* 199 */       if (blkCol + i < max4x)
/* 200 */         aboveNz |= aboveNonzeroContext[plane][blkCol + i]; 
/* 201 */       if (blkRow + i < max4y)
/* 202 */         leftNz |= leftNonzeroContext[plane][blkRow + i & 0xF]; 
/*     */     } 
/* 204 */     return aboveNz + leftNz;
/*     */   }
/*     */   
/*     */   public int[][][] getCoefs() {
/* 208 */     return this.coefs;
/*     */   }
/*     */ }


/* Location:              C:\Users\rapha\Downloads\aurora.jar!\META-INF\jars\jcodec-0.2.5.jar!\org\jcodec\codecs\vpx\vp9\Residual.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */