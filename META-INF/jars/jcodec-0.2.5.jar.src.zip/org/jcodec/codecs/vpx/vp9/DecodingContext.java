/*      */ package org.jcodec.codecs.vpx.vp9;
/*      */ 
/*      */ import java.nio.ByteBuffer;
/*      */ import org.jcodec.codecs.vpx.VPXBooleanDecoder;
/*      */ import org.jcodec.common.ArrayUtil;
/*      */ import org.jcodec.common.io.BitReader;
/*      */ import org.jcodec.common.io.NIOUtils;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ public class DecodingContext
/*      */ {
/*      */   private int profile;
/*      */   private int showExistingFrame;
/*      */   private int frameToShowMapIdx;
/*      */   private int frameType;
/*      */   private int showFrame;
/*      */   private int errorResilientMode;
/*      */   private int refreshFrameFlags;
/*      */   private int frameIsIntra;
/*      */   private int intraOnly;
/*      */   private int resetFrameContext;
/*      */   private int colorSpace;
/*      */   int subsamplingX;
/*      */   int subsamplingY;
/*      */   int bitDepth;
/*      */   int frameWidth;
/*      */   int frameHeight;
/*      */   private int renderWidth;
/*      */   private int renderHeight;
/*   39 */   private int[] refFrameWidth = new int[4];
/*   40 */   private int[] refFrameHeight = new int[4];
/*   41 */   private int[] refFrameIdx = new int[3];
/*   42 */   private int[] refFrameSignBias = new int[3];
/*      */   private int allowHighPrecisionMv;
/*      */   int interpFilter;
/*      */   private int frameParallelDecodingMode;
/*      */   private int refreshFrameContext;
/*      */   private int frameContextIdx;
/*   48 */   private int[] loopFilterRefDeltas = new int[4];
/*   49 */   private int[] loopFilterModeDeltas = new int[2];
/*      */   private int baseQIdx;
/*      */   private int deltaQYDc;
/*      */   private int deltaQUvDc;
/*      */   private int deltaQUvAc;
/*      */   private boolean lossless;
/*      */   private boolean segmentationEnabled;
/*   56 */   private int[] segmentationTreeProbs = new int[7];
/*   57 */   private int[] segmentationPredProbs = new int[3];
/*   58 */   private int[][] featureEnabled = new int[8][4];
/*   59 */   private int[][] featureData = new int[8][4];
/*      */   
/*      */   private int tileRowsLog2;
/*      */   
/*      */   private int tileColsLog2;
/*      */   int txMode;
/*      */   private int compFixedRef;
/*      */   private int compVarRef0;
/*      */   private int compVarRef1;
/*      */   int refMode;
/*   69 */   int[][] tx8x8Probs = new int[2][1];
/*   70 */   int[][] tx16x16Probs = new int[2][2];
/*   71 */   int[][] tx32x32Probs = new int[2][3];
/*      */   int[][][][][][] coefProbs;
/*   73 */   private int[] skipProbs = new int[3];
/*   74 */   int[][] interModeProbs = new int[7][3];
/*   75 */   int[][] interpFilterProbs = new int[4][2];
/*   76 */   private int[] isInterProbs = new int[4];
/*      */   
/*   78 */   private int[] compModeProbs = new int[5];
/*   79 */   private int[][] singleRefProbs = new int[5][2];
/*   80 */   private int[] compRefProbs = new int[5];
/*      */   
/*   82 */   int[][] yModeProbs = new int[4][9];
/*   83 */   int[][] partitionProbs = new int[16][3];
/*      */   
/*   85 */   public int[][] uvModeProbs = new int[10][9];
/*      */   
/*   87 */   private int[] mvJointProbs = new int[3];
/*   88 */   private int[] mvSignProbs = new int[2];
/*   89 */   private int[][] mvClassProbs = new int[2][10];
/*   90 */   private int[] mvClass0BitProbs = new int[2];
/*   91 */   private int[][] mvBitsProbs = new int[2][10];
/*   92 */   private int[][][] mvClass0FrProbs = new int[2][2][3];
/*   93 */   private int[][] mvFrProbs = new int[2][3];
/*   94 */   private int[] mvClass0HpProb = new int[2];
/*   95 */   private int[] mvHpProbs = new int[2];
/*      */   
/*      */   private int filterLevel;
/*      */   private int sharpnessLevel;
/*      */   int[] leftPartitionSizes;
/*      */   int[] abovePartitionSizes;
/*      */   int tileHeight;
/*      */   int tileWidth;
/*      */   boolean[] leftSkipped;
/*      */   boolean[] aboveSkipped;
/*      */   int[][] aboveNonzeroContext;
/*      */   int[][] leftNonzeroContext;
/*      */   int[] aboveModes;
/*      */   int[] leftModes;
/*      */   private int colorRange;
/*      */   int[] aboveRefs;
/*      */   int[] leftRefs;
/*      */   int[] leftInterpFilters;
/*      */   int[] aboveInterpFilters;
/*      */   int miTileStartCol;
/*      */   int[] leftTxSizes;
/*      */   int[] aboveTxSizes;
/*      */   boolean[] leftCompound;
/*      */   boolean[] aboveCompound;
/*  119 */   private static final int[] defaultSkipProb = new int[] { 192, 128, 64 };
/*      */   
/*  121 */   private static final int[][] defaultTxProbs8x8 = new int[][] { { 100 }, { 66 } };
/*  122 */   private static final int[][] defaultTxProbs16x16 = new int[][] { { 20, 152 }, { 15, 101 } };
/*  123 */   private static final int[][] defaultTxProbs32x32 = new int[][] { { 3, 136, 37 }, { 5, 52, 13 } };
/*  124 */   public static final int[][][][][][] defaultCoefProbs = new int[][][][][][] { { { { { { 195, 29, 183 }, { 84, 49, 136 }, { 8, 42, 71 }, { 0, 0, 0 }, { 0, 0, 0 }, { 0, 0, 0 } }, { { 31, 107, 169 }, { 35, 99, 159 }, { 17, 82, 140 }, { 8, 66, 114 }, { 2, 44, 76 }, { 1, 19, 32 } }, { { 40, 132, 201 }, { 29, 114, 187 }, { 13, 91, 157 }, { 7, 75, 127 }, { 3, 58, 95 }, { 1, 28, 47 } }, { { 69, 142, 221 }, { 42, 122, 201 }, { 15, 91, 159 }, { 6, 67, 121 }, { 1, 42, 77 }, { 1, 17, 31 } }, { { 102, 148, 228 }, { 67, 117, 204 }, { 17, 82, 154 }, { 6, 59, 114 }, { 2, 39, 75 }, { 1, 15, 29 } }, { { 156, 57, 233 }, { 119, 57, 212 }, { 58, 48, 163 }, { 29, 40, 124 }, { 12, 30, 81 }, { 3, 12, 31 } } }, { { { 191, 107, 226 }, { 124, 117, 204 }, { 25, 99, 155 }, { 0, 0, 0 }, { 0, 0, 0 }, { 0, 0, 0 } }, { { 29, 148, 210 }, { 37, 126, 194 }, { 8, 93, 157 }, { 2, 68, 118 }, { 1, 39, 69 }, { 1, 17, 33 } }, { { 41, 151, 213 }, { 27, 123, 193 }, { 3, 82, 144 }, { 1, 58, 105 }, { 1, 32, 60 }, { 1, 13, 26 } }, { { 59, 159, 220 }, { 23, 126, 198 }, { 4, 88, 151 }, { 1, 66, 114 }, { 1, 38, 71 }, { 1, 18, 34 } }, { { 114, 136, 232 }, { 51, 114, 207 }, { 11, 83, 155 }, { 3, 56, 105 }, { 1, 33, 65 }, { 1, 17, 34 } }, { { 149, 65, 234 }, { 121, 57, 215 }, { 61, 49, 166 }, { 28, 36, 114 }, { 12, 25, 76 }, { 3, 16, 42 } } } }, { { { { 214, 49, 220 }, { 132, 63, 188 }, { 42, 65, 137 }, { 0, 0, 0 }, { 0, 0, 0 }, { 0, 0, 0 } }, { { 85, 137, 221 }, { 104, 131, 216 }, { 49, 111, 192 }, { 21, 87, 155 }, { 2, 49, 87 }, { 1, 16, 28 } }, { { 89, 163, 230 }, { 90, 137, 220 }, { 29, 100, 183 }, { 10, 70, 135 }, { 2, 42, 81 }, { 1, 17, 33 } }, { { 108, 167, 237 }, { 55, 133, 222 }, { 15, 97, 179 }, { 4, 72, 135 }, { 1, 45, 85 }, { 1, 19, 38 } }, { { 124, 146, 240 }, { 66, 124, 224 }, { 17, 88, 175 }, { 4, 58, 122 }, { 1, 36, 75 }, { 1, 18, 37 } }, { { 141, 79, 241 }, { 126, 70, 227 }, { 66, 58, 182 }, { 30, 44, 136 }, { 12, 34, 96 }, { 2, 20, 47 } } }, { { { 229, 99, 249 }, { 143, 111, 235 }, { 46, 109, 192 }, { 0, 0, 0 }, { 0, 0, 0 }, { 0, 0, 0 } }, { { 82, 158, 236 }, { 94, 146, 224 }, { 25, 117, 191 }, { 9, 87, 149 }, { 3, 56, 99 }, { 1, 33, 57 } }, { { 83, 167, 237 }, { 68, 145, 222 }, { 10, 103, 177 }, { 2, 72, 131 }, { 1, 41, 79 }, { 1, 20, 39 } }, { { 99, 167, 239 }, { 47, 141, 224 }, { 10, 104, 178 }, { 2, 73, 133 }, { 1, 44, 85 }, { 1, 22, 47 } }, { { 127, 145, 243 }, { 71, 129, 228 }, { 17, 93, 177 }, { 3, 61, 124 }, { 1, 41, 84 }, { 1, 21, 52 } }, { { 157, 78, 244 }, { 140, 72, 231 }, { 69, 58, 184 }, { 31, 44, 137 }, { 14, 38, 105 }, { 8, 23, 61 } } } } }, { { { { { 125, 34, 187 }, { 52, 41, 133 }, { 6, 31, 56 }, { 0, 0, 0 }, { 0, 0, 0 }, { 0, 0, 0 } }, { { 37, 109, 153 }, { 51, 102, 147 }, { 23, 87, 128 }, { 8, 67, 101 }, { 1, 41, 63 }, { 1, 19, 29 } }, { { 31, 154, 185 }, { 17, 127, 175 }, { 6, 96, 145 }, { 2, 73, 114 }, { 1, 51, 82 }, { 1, 28, 45 } }, { { 23, 163, 200 }, { 10, 131, 185 }, { 2, 93, 148 }, { 1, 67, 111 }, { 1, 41, 69 }, { 1, 14, 24 } }, { { 29, 176, 217 }, { 12, 145, 201 }, { 3, 101, 156 }, { 1, 69, 111 }, { 1, 39, 63 }, { 1, 14, 23 } }, { { 57, 192, 233 }, { 25, 154, 215 }, { 6, 109, 167 }, { 3, 78, 118 }, { 1, 48, 69 }, { 1, 21, 29 } } }, { { { 202, 105, 245 }, { 108, 106, 216 }, { 18, 90, 144 }, { 0, 0, 0 }, { 0, 0, 0 }, { 0, 0, 0 } }, { { 33, 172, 219 }, { 64, 149, 206 }, { 14, 117, 177 }, { 5, 90, 141 }, { 2, 61, 95 }, { 1, 37, 57 } }, { { 33, 179, 220 }, { 11, 140, 198 }, { 1, 89, 148 }, { 1, 60, 104 }, { 1, 33, 57 }, { 1, 12, 21 } }, { { 30, 181, 221 }, { 8, 141, 198 }, { 1, 87, 145 }, { 1, 58, 100 }, { 1, 31, 55 }, { 1, 12, 20 } }, { { 32, 186, 224 }, { 7, 142, 198 }, { 1, 86, 143 }, { 1, 58, 100 }, { 1, 31, 55 }, { 1, 12, 22 } }, { { 57, 192, 227 }, { 20, 143, 204 }, { 3, 96, 154 }, { 1, 68, 112 }, { 1, 42, 69 }, { 1, 19, 32 } } } }, { { { { 212, 35, 215 }, { 113, 47, 169 }, { 29, 48, 105 }, { 0, 0, 0 }, { 0, 0, 0 }, { 0, 0, 0 } }, { { 74, 129, 203 }, { 106, 120, 203 }, { 49, 107, 178 }, { 19, 84, 144 }, { 4, 50, 84 }, { 1, 15, 25 } }, { { 71, 172, 217 }, { 44, 141, 209 }, { 15, 102, 173 }, { 6, 76, 133 }, { 2, 51, 89 }, { 1, 24, 42 } }, { { 64, 185, 231 }, { 31, 148, 216 }, { 8, 103, 175 }, { 3, 74, 131 }, { 1, 46, 81 }, { 1, 18, 30 } }, { { 65, 196, 235 }, { 25, 157, 221 }, { 5, 105, 174 }, { 1, 67, 120 }, { 1, 38, 69 }, { 1, 15, 30 } }, { { 65, 204, 238 }, { 30, 156, 224 }, { 7, 107, 177 }, { 2, 70, 124 }, { 1, 42, 73 }, { 1, 18, 34 } } }, { { { 225, 86, 251 }, { 144, 104, 235 }, { 42, 99, 181 }, { 0, 0, 0 }, { 0, 0, 0 }, { 0, 0, 0 } }, { { 85, 175, 239 }, { 112, 165, 229 }, { 29, 136, 200 }, { 12, 103, 162 }, { 6, 77, 123 }, { 2, 53, 84 } }, { { 75, 183, 239 }, { 30, 155, 221 }, { 3, 106, 171 }, { 1, 74, 128 }, { 1, 44, 76 }, { 1, 17, 28 } }, { { 73, 185, 240 }, { 27, 159, 222 }, { 2, 107, 172 }, { 1, 75, 127 }, { 1, 42, 73 }, { 1, 17, 29 } }, { { 62, 190, 238 }, { 21, 159, 222 }, { 2, 107, 172 }, { 1, 72, 122 }, { 1, 40, 71 }, { 1, 18, 32 } }, { { 61, 199, 240 }, { 27, 161, 226 }, { 4, 113, 180 }, { 1, 76, 129 }, { 1, 46, 80 }, { 1, 23, 41 } } } } }, { { { { { 7, 27, 153 }, { 5, 30, 95 }, { 1, 16, 30 }, { 0, 0, 0 }, { 0, 0, 0 }, { 0, 0, 0 } }, { { 50, 75, 127 }, { 57, 75, 124 }, { 27, 67, 108 }, { 10, 54, 86 }, { 1, 33, 52 }, { 1, 12, 18 } }, { { 43, 125, 151 }, { 26, 108, 148 }, { 7, 83, 122 }, { 2, 59, 89 }, { 1, 38, 60 }, { 1, 17, 27 } }, { { 23, 144, 163 }, { 13, 112, 154 }, { 2, 75, 117 }, { 1, 50, 81 }, { 1, 31, 51 }, { 1, 14, 23 } }, { { 18, 162, 185 }, { 6, 123, 171 }, { 1, 78, 125 }, { 1, 51, 86 }, { 1, 31, 54 }, { 1, 14, 23 } }, { { 15, 199, 227 }, { 3, 150, 204 }, { 1, 91, 146 }, { 1, 55, 95 }, { 1, 30, 53 }, { 1, 11, 20 } } }, { { { 19, 55, 240 }, { 19, 59, 196 }, { 3, 52, 105 }, { 0, 0, 0 }, { 0, 0, 0 }, { 0, 0, 0 } }, { { 41, 166, 207 }, { 104, 153, 199 }, { 31, 123, 181 }, { 14, 101, 152 }, { 5, 72, 106 }, { 1, 36, 52 } }, { { 35, 176, 211 }, { 12, 131, 190 }, { 2, 88, 144 }, { 1, 60, 101 }, { 1, 36, 60 }, { 1, 16, 28 } }, { { 28, 183, 213 }, { 8, 134, 191 }, { 1, 86, 142 }, { 1, 56, 96 }, { 1, 30, 53 }, { 1, 12, 20 } }, { { 20, 190, 215 }, { 4, 135, 192 }, { 1, 84, 139 }, { 1, 53, 91 }, { 1, 28, 49 }, { 1, 11, 20 } }, { { 13, 196, 216 }, { 2, 137, 192 }, { 1, 86, 143 }, { 1, 57, 99 }, { 1, 32, 56 }, { 1, 13, 24 } } } }, { { { { 211, 29, 217 }, { 96, 47, 156 }, { 22, 43, 87 }, { 0, 0, 0 }, { 0, 0, 0 }, { 0, 0, 0 } }, { { 78, 120, 193 }, { 111, 116, 186 }, { 46, 102, 164 }, { 15, 80, 128 }, { 2, 49, 76 }, { 1, 18, 28 } }, { { 71, 161, 203 }, { 42, 132, 192 }, { 10, 98, 150 }, { 3, 69, 109 }, { 1, 44, 70 }, { 1, 18, 29 } }, { { 57, 186, 211 }, { 30, 140, 196 }, { 4, 93, 146 }, { 1, 62, 102 }, { 1, 38, 65 }, { 1, 16, 27 } }, { { 47, 199, 217 }, { 14, 145, 196 }, { 1, 88, 142 }, { 1, 57, 98 }, { 1, 36, 62 }, { 1, 15, 26 } }, { { 26, 219, 229 }, { 5, 155, 207 }, { 1, 94, 151 }, { 1, 60, 104 }, { 1, 36, 62 }, { 1, 16, 28 } } }, { { { 233, 29, 248 }, { 146, 47, 220 }, { 43, 52, 140 }, { 0, 0, 0 }, { 0, 0, 0 }, { 0, 0, 0 } }, { { 100, 163, 232 }, { 179, 161, 222 }, { 63, 142, 204 }, { 37, 113, 174 }, { 26, 89, 137 }, { 18, 68, 97 } }, { { 85, 181, 230 }, { 32, 146, 209 }, { 7, 100, 164 }, { 3, 71, 121 }, { 1, 45, 77 }, { 1, 18, 30 } }, { { 65, 187, 230 }, { 20, 148, 207 }, { 2, 97, 159 }, { 1, 68, 116 }, { 1, 40, 70 }, { 1, 14, 29 } }, { { 40, 194, 227 }, { 8, 147, 204 }, { 1, 94, 155 }, { 1, 65, 112 }, { 1, 39, 66 }, { 1, 14, 26 } }, { { 16, 208, 228 }, { 3, 151, 207 }, { 1, 98, 160 }, { 1, 67, 117 }, { 1, 41, 74 }, { 1, 17, 31 } } } } }, { { { { { 17, 38, 140 }, { 7, 34, 80 }, { 1, 17, 29 }, { 0, 0, 0 }, { 0, 0, 0 }, { 0, 0, 0 } }, { { 37, 75, 128 }, { 41, 76, 128 }, { 26, 66, 116 }, { 12, 52, 94 }, { 2, 32, 55 }, { 1, 10, 16 } }, { { 50, 127, 154 }, { 37, 109, 152 }, { 16, 82, 121 }, { 5, 59, 85 }, { 1, 35, 54 }, { 1, 13, 20 } }, { { 40, 142, 167 }, { 17, 110, 157 }, { 2, 71, 112 }, { 1, 44, 72 }, { 1, 27, 45 }, { 1, 11, 17 } }, { { 30, 175, 188 }, { 9, 124, 169 }, { 1, 74, 116 }, { 1, 48, 78 }, { 1, 30, 49 }, { 1, 11, 18 } }, { { 10, 222, 223 }, { 2, 150, 194 }, { 1, 83, 128 }, { 1, 48, 79 }, { 1, 27, 45 }, { 1, 11, 17 } } }, { { { 36, 41, 235 }, { 29, 36, 193 }, { 10, 27, 111 }, { 0, 0, 0 }, { 0, 0, 0 }, { 0, 0, 0 } }, { { 85, 165, 222 }, { 177, 162, 215 }, { 110, 135, 195 }, { 57, 113, 168 }, { 23, 83, 120 }, { 10, 49, 61 } }, { { 85, 190, 223 }, { 36, 139, 200 }, { 5, 90, 146 }, { 1, 60, 103 }, { 1, 38, 65 }, { 1, 18, 30 } }, { { 72, 202, 223 }, { 23, 141, 199 }, { 2, 86, 140 }, { 1, 56, 97 }, { 1, 36, 61 }, { 1, 16, 27 } }, { { 55, 218, 225 }, { 13, 145, 200 }, { 1, 86, 141 }, { 1, 57, 99 }, { 1, 35, 61 }, { 1, 13, 22 } }, { { 15, 235, 212 }, { 1, 132, 184 }, { 1, 84, 139 }, { 1, 57, 97 }, { 1, 34, 56 }, { 1, 14, 23 } } } }, { { { { 181, 21, 201 }, { 61, 37, 123 }, { 10, 38, 71 }, { 0, 0, 0 }, { 0, 0, 0 }, { 0, 0, 0 } }, { { 47, 106, 172 }, { 95, 104, 173 }, { 42, 93, 159 }, { 18, 77, 131 }, { 4, 50, 81 }, { 1, 17, 23 } }, { { 62, 147, 199 }, { 44, 130, 189 }, { 28, 102, 154 }, { 18, 75, 115 }, { 2, 44, 65 }, { 1, 12, 19 } }, { { 55, 153, 210 }, { 24, 130, 194 }, { 3, 93, 146 }, { 1, 61, 97 }, { 1, 31, 50 }, { 1, 10, 16 } }, { { 49, 186, 223 }, { 17, 148, 204 }, { 1, 96, 142 }, { 1, 53, 83 }, { 1, 26, 44 }, { 1, 11, 17 } }, { { 13, 217, 212 }, { 2, 136, 180 }, { 1, 78, 124 }, { 1, 50, 83 }, { 1, 29, 49 }, { 1, 14, 23 } } }, { { { 197, 13, 247 }, { 82, 17, 222 }, { 25, 17, 162 }, { 0, 0, 0 }, { 0, 0, 0 }, { 0, 0, 0 } }, { { 126, 186, 247 }, { 234, 191, 243 }, { 176, 177, 234 }, { 104, 158, 220 }, { 66, 128, 186 }, { 55, 90, 137 } }, { { 111, 197, 242 }, { 46, 158, 219 }, { 9, 104, 171 }, { 2, 65, 125 }, { 1, 44, 80 }, { 1, 17, 91 } }, { { 104, 208, 245 }, { 39, 168, 224 }, { 3, 109, 162 }, { 1, 79, 124 }, { 1, 50, 102 }, { 1, 43, 102 } }, { { 84, 220, 246 }, { 31, 177, 231 }, { 2, 115, 180 }, { 1, 79, 134 }, { 1, 55, 77 }, { 1, 60, 79 } }, { { 43, 243, 240 }, { 8, 180, 217 }, { 1, 115, 166 }, { 1, 84, 121 }, { 1, 51, 67 }, { 1, 16, 6 } } } } } };
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  455 */   public static final int[] defaultMvJointProbs = new int[] { 32, 64, 96 };
/*      */   
/*  457 */   public static final int[][] defaultMvBitsProb = new int[][] { { 136, 140, 148, 160, 176, 192, 224, 234, 234, 240 }, { 136, 140, 148, 160, 176, 192, 224, 234, 234, 240 } };
/*      */ 
/*      */   
/*  460 */   public static final int[] defaultMvClass0BitProb = new int[] { 216, 208 };
/*      */   
/*  462 */   public static final int[] defaultMvClass0HpProb = new int[] { 160, 160 };
/*      */   
/*  464 */   public static final int[] defaultMvSignProb = new int[] { 128, 128 };
/*      */   
/*  466 */   public static final int[][] defaultMvClassProbs = new int[][] { { 224, 144, 192, 168, 192, 176, 192, 198, 198, 245 }, { 216, 128, 176, 160, 176, 176, 192, 198, 198, 208 } };
/*      */ 
/*      */   
/*  469 */   public static final int[][][] defaultMvClass0FrProbs = new int[][][] { { { 128, 128, 64 }, { 96, 112, 64 } }, { { 128, 128, 64 }, { 96, 112, 64 } } };
/*      */   
/*  471 */   public static final int[][] defaultMvFrProbs = new int[][] { { 64, 96, 64 }, { 64, 96, 64 } };
/*  472 */   public static final int[] defaultMvHpProb = new int[] { 128, 128 };
/*      */   
/*  474 */   public static final int[][] defaultInterModeProbs = new int[][] { { 2, 173, 34 }, { 7, 145, 85 }, { 7, 166, 63 }, { 7, 94, 66 }, { 8, 64, 46 }, { 17, 81, 31 }, { 25, 29, 30 } };
/*      */ 
/*      */   
/*  477 */   public static final int[][] defaultInterpFilterProbs = new int[][] { { 235, 162 }, { 36, 255 }, { 34, 3 }, { 149, 144 } };
/*      */   
/*  479 */   public static final int[] defaultIsInterProbs = new int[] { 9, 102, 187, 225 };
/*      */   
/*  481 */   private static final int[][] defaultPartitionProbs = new int[][] { { 199, 122, 141 }, { 147, 63, 159 }, { 148, 133, 118 }, { 121, 104, 114 }, { 174, 73, 87 }, { 92, 41, 83 }, { 82, 99, 50 }, { 53, 39, 39 }, { 177, 58, 59 }, { 68, 26, 63 }, { 52, 79, 25 }, { 17, 14, 12 }, { 222, 34, 30 }, { 72, 16, 44 }, { 58, 32, 12 }, { 10, 7, 6 } };
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  504 */   public static final int[][][] kfYmodeProbs = new int[][][] { { { 137, 30, 42, 148, 151, 207, 70, 52, 91 }, { 92, 45, 102, 136, 116, 180, 74, 90, 100 }, { 73, 32, 19, 187, 222, 215, 46, 34, 100 }, { 91, 30, 32, 116, 121, 186, 93, 86, 94 }, { 72, 35, 36, 149, 68, 206, 68, 63, 105 }, { 73, 31, 28, 138, 57, 124, 55, 122, 151 }, { 67, 23, 21, 140, 126, 197, 40, 37, 171 }, { 86, 27, 28, 128, 154, 212, 45, 43, 53 }, { 74, 32, 27, 107, 86, 160, 63, 134, 102 }, { 59, 67, 44, 140, 161, 202, 78, 67, 119 } }, { { 63, 36, 126, 146, 123, 158, 60, 90, 96 }, { 43, 46, 168, 134, 107, 128, 69, 142, 92 }, { 44, 29, 68, 159, 201, 177, 50, 57, 77 }, { 58, 38, 76, 114, 97, 172, 78, 133, 92 }, { 46, 41, 76, 140, 63, 184, 69, 112, 57 }, { 38, 32, 85, 140, 46, 112, 54, 151, 133 }, { 39, 27, 61, 131, 110, 175, 44, 75, 136 }, { 52, 30, 74, 113, 130, 175, 51, 64, 58 }, { 47, 35, 80, 100, 74, 143, 64, 163, 74 }, { 36, 61, 116, 114, 128, 162, 80, 125, 82 } }, { { 82, 26, 26, 171, 208, 204, 44, 32, 105 }, { 55, 44, 68, 166, 179, 192, 57, 57, 108 }, { 42, 26, 11, 199, 241, 228, 23, 15, 85 }, { 68, 42, 19, 131, 160, 199, 55, 52, 83 }, { 58, 50, 25, 139, 115, 232, 39, 52, 118 }, { 50, 35, 33, 153, 104, 162, 64, 59, 131 }, { 44, 24, 16, 150, 177, 202, 33, 19, 156 }, { 55, 27, 12, 153, 203, 218, 26, 27, 49 }, { 53, 49, 21, 110, 116, 168, 59, 80, 76 }, { 38, 72, 19, 168, 203, 212, 50, 50, 107 } }, { { 103, 26, 36, 129, 132, 201, 83, 80, 93 }, { 59, 38, 83, 112, 103, 162, 98, 136, 90 }, { 62, 30, 23, 158, 200, 207, 59, 57, 50 }, { 67, 30, 29, 84, 86, 191, 102, 91, 59 }, { 60, 32, 33, 112, 71, 220, 64, 89, 104 }, { 53, 26, 34, 130, 56, 149, 84, 120, 103 }, { 53, 21, 23, 133, 109, 210, 56, 77, 172 }, { 77, 19, 29, 112, 142, 228, 55, 66, 36 }, { 61, 29, 29, 93, 97, 165, 83, 175, 162 }, { 47, 47, 43, 114, 137, 181, 100, 99, 95 } }, { { 69, 23, 29, 128, 83, 199, 46, 44, 101 }, { 53, 40, 55, 139, 69, 183, 61, 80, 110 }, { 40, 29, 19, 161, 180, 207, 43, 24, 91 }, { 60, 34, 19, 105, 61, 198, 53, 64, 89 }, { 52, 31, 22, 158, 40, 209, 58, 62, 89 }, { 44, 31, 29, 147, 46, 158, 56, 102, 198 }, { 35, 19, 12, 135, 87, 209, 41, 45, 167 }, { 55, 25, 21, 118, 95, 215, 38, 39, 66 }, { 51, 38, 25, 113, 58, 164, 70, 93, 97 }, { 47, 54, 34, 146, 108, 203, 72, 103, 151 } }, { { 64, 19, 37, 156, 66, 138, 49, 95, 133 }, { 46, 27, 80, 150, 55, 124, 55, 121, 135 }, { 36, 23, 27, 165, 149, 166, 54, 64, 118 }, { 53, 21, 36, 131, 63, 163, 60, 109, 81 }, { 40, 26, 35, 154, 40, 185, 51, 97, 123 }, { 35, 19, 34, 179, 19, 97, 48, 129, 124 }, { 36, 20, 26, 136, 62, 164, 33, 77, 154 }, { 45, 18, 32, 130, 90, 157, 40, 79, 91 }, { 45, 26, 28, 129, 45, 129, 49, 147, 123 }, { 38, 44, 51, 136, 74, 162, 57, 97, 121 } }, { { 75, 17, 22, 136, 138, 185, 32, 34, 166 }, { 56, 39, 58, 133, 117, 173, 48, 53, 187 }, { 35, 21, 12, 161, 212, 207, 20, 23, 145 }, { 56, 29, 19, 117, 109, 181, 55, 68, 112 }, { 47, 29, 17, 153, 64, 220, 59, 51, 114 }, { 46, 16, 24, 136, 76, 147, 41, 64, 172 }, { 34, 17, 11, 108, 152, 187, 13, 15, 209 }, { 51, 24, 14, 115, 133, 209, 32, 26, 104 }, { 55, 30, 18, 122, 79, 179, 44, 88, 116 }, { 37, 49, 25, 129, 168, 164, 41, 54, 148 } }, { { 82, 22, 32, 127, 143, 213, 39, 41, 70 }, { 62, 44, 61, 123, 105, 189, 48, 57, 64 }, { 47, 25, 17, 175, 222, 220, 24, 30, 86 }, { 68, 36, 17, 106, 102, 206, 59, 74, 74 }, { 57, 39, 23, 151, 68, 216, 55, 63, 58 }, { 49, 30, 35, 141, 70, 168, 82, 40, 115 }, { 51, 25, 15, 136, 129, 202, 38, 35, 139 }, { 68, 26, 16, 111, 141, 215, 29, 28, 28 }, { 59, 39, 19, 114, 75, 180, 77, 104, 42 }, { 40, 61, 26, 126, 152, 206, 61, 59, 93 } }, { { 78, 23, 39, 111, 117, 170, 74, 124, 94 }, { 48, 34, 86, 101, 92, 146, 78, 179, 134 }, { 47, 22, 24, 138, 187, 178, 68, 69, 59 }, { 56, 25, 33, 105, 112, 187, 95, 177, 129 }, { 48, 31, 27, 114, 63, 183, 82, 116, 56 }, { 43, 28, 37, 121, 63, 123, 61, 192, 169 }, { 42, 17, 24, 109, 97, 177, 56, 76, 122 }, { 58, 18, 28, 105, 139, 182, 70, 92, 63 }, { 46, 23, 32, 74, 86, 150, 67, 183, 88 }, { 36, 38, 48, 92, 122, 165, 88, 137, 91 } }, { { 65, 70, 60, 155, 159, 199, 61, 60, 81 }, { 44, 78, 115, 132, 119, 173, 71, 112, 93 }, { 39, 38, 21, 184, 227, 206, 42, 32, 64 }, { 58, 47, 36, 124, 137, 193, 80, 82, 78 }, { 49, 50, 35, 144, 95, 205, 63, 78, 59 }, { 41, 53, 52, 148, 71, 142, 65, 128, 51 }, { 40, 36, 28, 143, 143, 202, 40, 55, 137 }, { 52, 34, 29, 129, 183, 227, 42, 35, 43 }, { 42, 44, 44, 104, 105, 164, 64, 130, 80 }, { 43, 81, 53, 140, 169, 204, 68, 84, 72 } } };
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  616 */   public static final int[][] kfUvModeProbs = new int[][] { { 144, 11, 54, 157, 195, 130, 46, 58, 108 }, { 118, 15, 123, 148, 131, 101, 44, 93, 131 }, { 113, 12, 23, 188, 226, 142, 26, 32, 125 }, { 120, 11, 50, 123, 163, 135, 64, 77, 103 }, { 113, 9, 36, 155, 111, 157, 32, 44, 161 }, { 116, 9, 55, 176, 76, 96, 37, 61, 149 }, { 115, 9, 28, 141, 161, 167, 21, 25, 193 }, { 120, 12, 32, 145, 195, 142, 32, 38, 86 }, { 116, 12, 64, 120, 140, 125, 49, 115, 121 }, { 102, 19, 66, 162, 182, 122, 35, 59, 128 } };
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  627 */   public static final int[][] defaultYModeProbs = new int[][] { { 65, 32, 18, 144, 162, 194, 41, 51, 98 }, { 132, 68, 18, 165, 217, 196, 45, 40, 78 }, { 173, 80, 19, 176, 240, 193, 64, 35, 46 }, { 221, 135, 38, 194, 248, 121, 96, 85, 29 } };
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  633 */   public static final int[][] defaultUvModeProbs = new int[][] { { 120, 7, 76, 176, 208, 126, 28, 54, 103 }, { 48, 12, 154, 155, 139, 90, 34, 117, 119 }, { 67, 6, 25, 204, 243, 158, 13, 21, 96 }, { 97, 5, 44, 131, 176, 139, 48, 68, 97 }, { 83, 5, 42, 156, 111, 152, 26, 49, 152 }, { 80, 5, 58, 178, 74, 83, 33, 62, 145 }, { 86, 5, 32, 154, 192, 168, 14, 22, 163 }, { 85, 5, 32, 156, 216, 148, 19, 29, 73 }, { 77, 7, 64, 116, 132, 122, 37, 126, 120 }, { 101, 21, 107, 181, 192, 103, 19, 67, 125 } };
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  645 */   public static final int[][] defaultSingleRefProb = new int[][] { { 33, 16 }, { 77, 74 }, { 142, 142 }, { 172, 170 }, { 238, 247 } };
/*      */ 
/*      */   
/*  648 */   public static final int[] defaultCompRefProb = new int[] { 50, 126, 123, 221, 226 };
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static DecodingContext createFromHeaders(ByteBuffer bb) {
/*  661 */     DecodingContext dc = new DecodingContext();
/*  662 */     int compressedHeaderSize = dc.readUncompressedHeader(bb);
/*  663 */     dc.readCompressedHeader(NIOUtils.read(bb, compressedHeaderSize));
/*  664 */     return dc;
/*      */   }
/*      */   
/*      */   protected DecodingContext() {
/*  668 */     ArrayUtil.copy1D(this.skipProbs, defaultSkipProb);
/*  669 */     ArrayUtil.copy2D(this.tx8x8Probs, defaultTxProbs8x8);
/*  670 */     ArrayUtil.copy2D(this.tx16x16Probs, defaultTxProbs16x16);
/*  671 */     ArrayUtil.copy2D(this.tx32x32Probs, defaultTxProbs32x32);
/*      */     
/*  673 */     this.coefProbs = new int[4][2][2][6][][];
/*  674 */     for (int i = 0; i < 4; i++) {
/*  675 */       for (int j = 0; j < 2; j++) {
/*  676 */         for (int k = 0; k < 2; k++) {
/*  677 */           this.coefProbs[i][j][k][0] = new int[3][3];
/*  678 */           for (int l = 1; l < 6; l++) {
/*  679 */             this.coefProbs[i][j][k][l] = new int[6][3];
/*      */           }
/*      */         } 
/*      */       } 
/*      */     } 
/*      */     
/*  685 */     ArrayUtil.copy6D(this.coefProbs, defaultCoefProbs);
/*      */     
/*  687 */     ArrayUtil.copy1D(this.mvJointProbs, defaultMvJointProbs);
/*  688 */     ArrayUtil.copy1D(this.mvSignProbs, defaultMvSignProb);
/*  689 */     ArrayUtil.copy2D(this.mvClassProbs, defaultMvClassProbs);
/*  690 */     ArrayUtil.copy1D(this.mvClass0BitProbs, defaultMvClass0BitProb);
/*  691 */     ArrayUtil.copy2D(this.mvBitsProbs, defaultMvBitsProb);
/*  692 */     ArrayUtil.copy3D(this.mvClass0FrProbs, defaultMvClass0FrProbs);
/*  693 */     ArrayUtil.copy2D(this.mvFrProbs, defaultMvFrProbs);
/*  694 */     ArrayUtil.copy1D(this.mvClass0HpProb, defaultMvClass0HpProb);
/*  695 */     ArrayUtil.copy1D(this.mvHpProbs, defaultMvHpProb);
/*      */     
/*  697 */     ArrayUtil.copy2D(this.interModeProbs, defaultInterModeProbs);
/*  698 */     ArrayUtil.copy2D(this.interpFilterProbs, defaultInterpFilterProbs);
/*      */     
/*  700 */     ArrayUtil.copy1D(this.isInterProbs, defaultIsInterProbs);
/*      */     
/*  702 */     ArrayUtil.copy2D(this.singleRefProbs, defaultSingleRefProb);
/*      */     
/*  704 */     ArrayUtil.copy2D(this.yModeProbs, defaultYModeProbs);
/*  705 */     ArrayUtil.copy2D(this.uvModeProbs, defaultUvModeProbs);
/*      */     
/*  707 */     ArrayUtil.copy2D(this.partitionProbs, defaultPartitionProbs);
/*      */     
/*  709 */     ArrayUtil.copy1D(this.compRefProbs, defaultCompRefProb);
/*      */   }
/*      */   
/*      */   public boolean isKeyIntraFrame() {
/*  713 */     return false;
/*      */   }
/*      */   
/*      */   public boolean isSegmentationEnabled() {
/*  717 */     return this.segmentationEnabled;
/*      */   }
/*      */   
/*      */   public boolean isUpdateSegmentMap() {
/*  721 */     return false;
/*      */   }
/*      */   
/*      */   public boolean isSegmentFeatureActive(int segmentId, int segLvlSkip) {
/*  725 */     return false;
/*      */   }
/*      */   
/*      */   public boolean isSegmentMapConditionalUpdate() {
/*  729 */     return false;
/*      */   }
/*      */   
/*      */   public int getSegmentFeature(int segmentId, int segLvlRefFrame) {
/*  733 */     return 0;
/*      */   }
/*      */   
/*      */   public int getCompFixedRef() {
/*  737 */     return 0;
/*      */   }
/*      */   
/*      */   public int refFrameSignBias(int fixedRef) {
/*  741 */     return 0;
/*      */   }
/*      */   
/*      */   public int getInterpFilter() {
/*  745 */     return this.interpFilter;
/*      */   }
/*      */   
/*      */   public int getRefMode() {
/*  749 */     return this.refMode;
/*      */   }
/*      */   
/*      */   public long[][] getLeftMVs() {
/*  753 */     return (long[][])null;
/*      */   }
/*      */   
/*      */   public long[][] getAboveMVs() {
/*  757 */     return (long[][])null;
/*      */   }
/*      */   
/*      */   public long[][] getAboveLeftMVs() {
/*  761 */     return (long[][])null;
/*      */   }
/*      */   
/*      */   public long[] getLeft4x4MVs() {
/*  765 */     return null;
/*      */   }
/*      */   
/*      */   public long[] getAbove4x4MVs() {
/*  769 */     return null;
/*      */   }
/*      */   
/*      */   public boolean[] getAboveCompound() {
/*  773 */     return this.aboveCompound;
/*      */   }
/*      */   
/*      */   public boolean[] getLeftCompound() {
/*  777 */     return this.leftCompound;
/*      */   }
/*      */   
/*      */   public boolean isAllowHpMv() {
/*  781 */     return false;
/*      */   }
/*      */   
/*      */   public boolean isUsePrevFrameMvs() {
/*  785 */     return false;
/*      */   }
/*      */   
/*      */   public long[][] getPrevFrameMv() {
/*  789 */     return (long[][])null;
/*      */   }
/*      */   
/*      */   public int getMiFrameWidth() {
/*  793 */     return this.frameWidth + 7 >> 3;
/*      */   }
/*      */   
/*      */   public int getMiFrameHeight() {
/*  797 */     return this.frameHeight + 7 >> 3;
/*      */   }
/*      */   
/*      */   public int[] getLeftInterpFilters() {
/*  801 */     return this.leftInterpFilters;
/*      */   }
/*      */   
/*      */   public int[] getAboveInterpFilters() {
/*  805 */     return this.aboveInterpFilters;
/*      */   }
/*      */   
/*      */   public int getMiTileHeight() {
/*  809 */     return this.tileHeight;
/*      */   }
/*      */   
/*      */   public int getMiTileWidth() {
/*  813 */     return this.tileWidth;
/*      */   }
/*      */   
/*      */   public int getCompVarRef(int i) {
/*  817 */     return 0;
/*      */   }
/*      */   
/*      */   public int[] getAboveModes() {
/*  821 */     return this.aboveModes;
/*      */   }
/*      */   
/*      */   public int[] getLeftModes() {
/*  825 */     return this.leftModes;
/*      */   }
/*      */   
/*      */   public int getTxMode() {
/*  829 */     return this.txMode;
/*      */   }
/*      */   
/*      */   public boolean[] getAboveSegIdPredicted() {
/*  833 */     return null;
/*      */   }
/*      */   
/*      */   public boolean[] getLeftSegIdPredicted() {
/*  837 */     return null;
/*      */   }
/*      */   
/*      */   public int[][] getPrevSegmentIds() {
/*  841 */     return (int[][])null;
/*      */   }
/*      */   
/*      */   public int getSubX() {
/*  845 */     return this.subsamplingX;
/*      */   }
/*      */   
/*      */   public int getSubY() {
/*  849 */     return this.subsamplingY;
/*      */   }
/*      */   
/*      */   public int getBitDepth() {
/*  853 */     return this.bitDepth;
/*      */   }
/*      */   
/*      */   public int[][] getAboveNonzeroContext() {
/*  857 */     return this.aboveNonzeroContext;
/*      */   }
/*      */   
/*      */   public int[][] getLeftNonzeroContext() {
/*  861 */     return this.leftNonzeroContext;
/*      */   }
/*      */   
/*      */   public int[] getLeftPartitionSizes() {
/*  865 */     return this.leftPartitionSizes;
/*      */   }
/*      */   
/*      */   public int[] getAbovePartitionSizes() {
/*  869 */     return this.abovePartitionSizes;
/*      */   }
/*      */   
/*      */   public boolean[] getLeftSkipped() {
/*  873 */     return this.leftSkipped;
/*      */   }
/*      */   
/*      */   public boolean[] getAboveSkipped() {
/*  877 */     return this.aboveSkipped;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected int readUncompressedHeader(ByteBuffer bb) {
/*  891 */     BitReader br = BitReader.createBitReader(bb);
/*      */     
/*  893 */     int frame_marker = br.readNBit(2);
/*  894 */     this.profile = br.read1Bit() | br.read1Bit() << 1;
/*  895 */     if (this.profile == 3)
/*  896 */       br.read1Bit(); 
/*  897 */     this.showExistingFrame = br.read1Bit();
/*  898 */     if (this.showExistingFrame == 1) {
/*  899 */       this.frameToShowMapIdx = br.readNBit(3);
/*      */     }
/*  901 */     this.frameType = br.read1Bit();
/*  902 */     this.showFrame = br.read1Bit();
/*  903 */     this.errorResilientMode = br.read1Bit();
/*  904 */     if (this.frameType == 0) {
/*  905 */       frame_sync_code(br);
/*  906 */       readColorConfig(br);
/*  907 */       readFrameSize(br);
/*  908 */       readRenderSize(br);
/*  909 */       this.refreshFrameFlags = 255;
/*  910 */       this.frameIsIntra = 1;
/*      */     } else {
/*  912 */       this.intraOnly = 0;
/*  913 */       if (this.showFrame == 0) {
/*  914 */         this.intraOnly = br.read1Bit();
/*      */       }
/*  916 */       this.resetFrameContext = 0;
/*  917 */       if (this.errorResilientMode == 0) {
/*  918 */         this.resetFrameContext = br.readNBit(2);
/*      */       }
/*  920 */       if (this.intraOnly == 1) {
/*  921 */         frame_sync_code(br);
/*  922 */         if (this.profile > 0) {
/*  923 */           readColorConfig(br);
/*      */         } else {
/*  925 */           this.colorSpace = 1;
/*  926 */           this.subsamplingX = 1;
/*  927 */           this.subsamplingY = 1;
/*  928 */           this.bitDepth = 8;
/*      */         } 
/*  930 */         this.refreshFrameFlags = br.readNBit(8);
/*  931 */         readFrameSize(br);
/*  932 */         readRenderSize(br);
/*      */       } else {
/*  934 */         int refreshFrameFlags = br.readNBit(8);
/*      */         
/*  936 */         for (int i = 0; i < 3; i++) {
/*  937 */           this.refFrameIdx[i] = br.readNBit(3);
/*  938 */           this.refFrameSignBias[1 + i] = br.read1Bit();
/*      */         } 
/*  940 */         readFrameSizeWithRefs(br);
/*  941 */         this.allowHighPrecisionMv = br.read1Bit();
/*  942 */         readInterpolationFilter(br);
/*      */       } 
/*      */     } 
/*  945 */     this.refreshFrameContext = 0;
/*  946 */     if (this.errorResilientMode == 0) {
/*  947 */       this.refreshFrameContext = br.read1Bit();
/*  948 */       this.frameParallelDecodingMode = br.read1Bit();
/*      */     } 
/*  950 */     this.frameContextIdx = br.readNBit(2);
/*  951 */     readLoopFilterParams(br);
/*  952 */     readQuantizationParams(br);
/*  953 */     readSegmentationParams(br);
/*  954 */     readTileInfo(br);
/*  955 */     int headerSizeInBytes = br.readNBit(16);
/*  956 */     br.terminate();
/*      */     
/*  958 */     return headerSizeInBytes;
/*      */   }
/*      */   
/*      */   int calc_min_log2_tile_cols() {
/*  962 */     int sb64Cols = this.frameWidth + 63 >> 6;
/*  963 */     int minLog2 = 0;
/*  964 */     while (64 << minLog2 < sb64Cols)
/*  965 */       minLog2++; 
/*  966 */     return minLog2;
/*      */   }
/*      */   
/*      */   int calc_max_log2_tile_cols() {
/*  970 */     int sb64Cols = this.frameWidth + 63 >> 6;
/*  971 */     int maxLog2 = 1;
/*  972 */     while (sb64Cols >> maxLog2 >= 4)
/*  973 */       maxLog2++; 
/*  974 */     return maxLog2 - 1;
/*      */   }
/*      */   
/*      */   private void readTileInfo(BitReader br) {
/*  978 */     int minLog2TileCols = calc_min_log2_tile_cols();
/*  979 */     int maxLog2TileCols = calc_max_log2_tile_cols();
/*  980 */     this.tileColsLog2 = minLog2TileCols;
/*  981 */     while (this.tileColsLog2 < maxLog2TileCols) {
/*  982 */       int increment_tile_cols_log2 = br.read1Bit();
/*  983 */       if (increment_tile_cols_log2 == 1) {
/*  984 */         this.tileColsLog2++;
/*      */       }
/*      */     } 
/*      */     
/*  988 */     this.tileRowsLog2 = br.read1Bit();
/*  989 */     if (this.tileRowsLog2 == 1) {
/*  990 */       int increment_tile_rows_log2 = br.read1Bit();
/*  991 */       this.tileRowsLog2 += increment_tile_rows_log2;
/*      */     } 
/*      */   }
/*      */   
/*      */   private static int readProb(BitReader br) {
/*  996 */     if (br.read1Bit() == 1) {
/*  997 */       return br.readNBit(8);
/*      */     }
/*  999 */     return 255;
/*      */   }
/*      */ 
/*      */   
/*      */   private void readSegmentationParams(BitReader br) {
/* 1004 */     this.segmentationEnabled = (br.read1Bit() == 1);
/* 1005 */     if (this.segmentationEnabled) {
/* 1006 */       if (br.read1Bit() == 1) {
/* 1007 */         for (int i = 0; i < 7; i++)
/* 1008 */           this.segmentationTreeProbs[i] = readProb(br); 
/* 1009 */         int segmentationTemporalUpdate = br.read1Bit();
/* 1010 */         for (int j = 0; j < 3; j++)
/* 1011 */           this.segmentationPredProbs[j] = (segmentationTemporalUpdate == 1) ? readProb(br) : 255; 
/*      */       } 
/* 1013 */       if (br.read1Bit() == 1) {
/* 1014 */         int segmentationAbsOrDeltaUpdate = br.read1Bit();
/* 1015 */         for (int i = 0; i < 8; i++) {
/* 1016 */           for (int j = 0; j < 4; j++) {
/* 1017 */             if (br.read1Bit() == 1) {
/* 1018 */               this.featureEnabled[i][j] = 1;
/* 1019 */               int bits_to_read = Consts.SEGMENTATION_FEATURE_BITS[j];
/* 1020 */               int value = br.readNBit(bits_to_read);
/* 1021 */               if (Consts.SEGMENTATION_FEATURE_SIGNED[j] == 1 && 
/* 1022 */                 br.read1Bit() == 1) {
/* 1023 */                 value *= -1;
/*      */               }
/* 1025 */               this.featureData[i][j] = value;
/*      */             } 
/*      */           } 
/*      */         } 
/*      */       } 
/*      */     } 
/*      */   }
/*      */   
/*      */   private static int readDeltaQ(BitReader br) {
/* 1034 */     int delta_coded = br.read1Bit();
/* 1035 */     if (delta_coded == 1) {
/* 1036 */       return br.readNBitSigned(4);
/*      */     }
/* 1038 */     return 0;
/*      */   }
/*      */ 
/*      */   
/*      */   private void readQuantizationParams(BitReader br) {
/* 1043 */     this.baseQIdx = br.readNBit(8);
/* 1044 */     this.deltaQYDc = readDeltaQ(br);
/* 1045 */     this.deltaQUvDc = readDeltaQ(br);
/* 1046 */     this.deltaQUvAc = readDeltaQ(br);
/* 1047 */     this.lossless = (this.baseQIdx == 0 && this.deltaQYDc == 0 && this.deltaQUvDc == 0 && this.deltaQUvAc == 0);
/*      */   }
/*      */   
/*      */   private void readLoopFilterParams(BitReader br) {
/* 1051 */     this.filterLevel = br.readNBit(6);
/* 1052 */     this.sharpnessLevel = br.readNBit(3);
/* 1053 */     int modeRefDeltaEnabled = br.read1Bit();
/* 1054 */     if (modeRefDeltaEnabled == 1) {
/* 1055 */       int modeRefDeltaUpdate = br.read1Bit();
/* 1056 */       if (modeRefDeltaUpdate == 1) {
/* 1057 */         int i; for (i = 0; i < 4; i++) {
/* 1058 */           if (br.read1Bit() == 1)
/* 1059 */             this.loopFilterRefDeltas[i] = br.readNBitSigned(6); 
/*      */         } 
/* 1061 */         for (i = 0; i < 2; i++) {
/* 1062 */           if (br.read1Bit() == 1)
/* 1063 */             this.loopFilterModeDeltas[i] = br.readNBitSigned(6); 
/*      */         } 
/*      */       } 
/*      */     } 
/*      */   }
/*      */   
/*      */   private void readInterpolationFilter(BitReader br) {
/* 1070 */     this.interpFilter = 3;
/* 1071 */     if (br.read1Bit() == 0) {
/* 1072 */       this.interpFilter = Consts.LITERAL_TO_FILTER_TYPE[br.readNBit(2)];
/*      */     }
/*      */   }
/*      */   
/*      */   private void readFrameSizeWithRefs(BitReader br) {
/*      */     int i;
/* 1078 */     for (i = 0; i < 3; i++) {
/* 1079 */       if (br.read1Bit() == 1) {
/* 1080 */         this.frameWidth = this.refFrameWidth[this.refFrameIdx[i]];
/* 1081 */         this.frameHeight = this.refFrameHeight[this.refFrameIdx[i]];
/*      */         break;
/*      */       } 
/*      */     } 
/* 1085 */     if (i == 3) {
/* 1086 */       readFrameSize(br);
/*      */     }
/* 1088 */     readRenderSize(br);
/*      */   }
/*      */   
/*      */   private void readRenderSize(BitReader br) {
/* 1092 */     if (br.read1Bit() == 1) {
/* 1093 */       this.renderWidth = br.readNBit(16) + 1;
/* 1094 */       this.renderHeight = br.readNBit(16) + 1;
/*      */     } else {
/* 1096 */       this.renderWidth = this.frameWidth;
/* 1097 */       this.renderHeight = this.frameHeight;
/*      */     } 
/*      */   }
/*      */   
/*      */   private void readFrameSize(BitReader br) {
/* 1102 */     this.frameWidth = br.readNBit(16) + 1;
/* 1103 */     this.frameHeight = br.readNBit(16) + 1;
/*      */   }
/*      */   
/*      */   private void readColorConfig(BitReader br) {
/* 1107 */     if (this.profile >= 2) {
/* 1108 */       int ten_or_twelve_bit = br.read1Bit();
/* 1109 */       this.bitDepth = (ten_or_twelve_bit == 1) ? 12 : 10;
/*      */     } else {
/* 1111 */       this.bitDepth = 8;
/*      */     } 
/* 1113 */     int colorSpace = br.readNBit(3);
/* 1114 */     if (colorSpace != 7) {
/* 1115 */       this.colorRange = br.read1Bit();
/* 1116 */       if (this.profile == 1 || this.profile == 3) {
/* 1117 */         this.subsamplingX = br.read1Bit();
/* 1118 */         this.subsamplingY = br.read1Bit();
/* 1119 */         int i = br.read1Bit();
/*      */       } else {
/* 1121 */         this.subsamplingX = 1;
/* 1122 */         this.subsamplingY = 1;
/*      */       } 
/*      */     } else {
/* 1125 */       this.colorRange = 1;
/* 1126 */       if (this.profile == 1 || this.profile == 3) {
/* 1127 */         this.subsamplingX = 0;
/* 1128 */         this.subsamplingY = 0;
/* 1129 */         int i = br.read1Bit();
/*      */       } 
/*      */     } 
/*      */   }
/*      */   
/*      */   private static void frame_sync_code(BitReader br) {
/* 1135 */     int code = br.readNBit(24);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected void readCompressedHeader(ByteBuffer compressedHeader) {
/* 1145 */     VPXBooleanDecoder boolDec = new VPXBooleanDecoder(compressedHeader, 0);
/*      */     
/* 1147 */     if (boolDec.readBitEq() != 0) {
/* 1148 */       throw new RuntimeException("Invalid marker bit");
/*      */     }
/* 1150 */     readTxMode(boolDec);
/*      */ 
/*      */     
/* 1153 */     if (this.txMode == 4) {
/* 1154 */       readTxModeProbs(boolDec);
/*      */     }
/* 1156 */     readCoefProbs(boolDec);
/* 1157 */     readSkipProb(boolDec);
/* 1158 */     if (this.frameIsIntra == 0) {
/* 1159 */       readInterModeProbs(boolDec);
/* 1160 */       if (this.interpFilter == 3)
/* 1161 */         readInterpFilterProbs(boolDec); 
/* 1162 */       readIsInterProbs(boolDec);
/* 1163 */       frameReferenceMode(boolDec);
/* 1164 */       frameReferenceModeProbs(boolDec);
/* 1165 */       readYModeProbs(boolDec);
/* 1166 */       readPartitionProbs(boolDec);
/* 1167 */       mvProbs(boolDec);
/*      */     } 
/*      */   }
/*      */   
/*      */   private void readTxMode(VPXBooleanDecoder boolDec) {
/* 1172 */     if (this.lossless) {
/* 1173 */       this.txMode = 0;
/*      */     } else {
/* 1175 */       this.txMode = boolDec.decodeInt(2);
/* 1176 */       if (this.txMode == 3)
/* 1177 */         this.txMode += boolDec.decodeInt(1); 
/*      */     } 
/*      */   }
/*      */   
/*      */   private void readTxModeProbs(VPXBooleanDecoder boolDec) {
/*      */     int i;
/* 1183 */     for (i = 0; i < 2; i++) {
/* 1184 */       for (int j = 0; j < 1; j++)
/* 1185 */         this.tx8x8Probs[i][j] = diffUpdateProb(boolDec, this.tx8x8Probs[i][j]); 
/*      */     } 
/* 1187 */     for (i = 0; i < 2; i++) {
/* 1188 */       for (int j = 0; j < 2; j++)
/* 1189 */         this.tx16x16Probs[i][j] = diffUpdateProb(boolDec, this.tx16x16Probs[i][j]); 
/*      */     } 
/* 1191 */     for (i = 0; i < 2; i++) {
/* 1192 */       for (int j = 0; j < 3; j++)
/* 1193 */         this.tx32x32Probs[i][j] = diffUpdateProb(boolDec, this.tx32x32Probs[i][j]); 
/*      */     } 
/*      */   }
/*      */   
/*      */   private int diffUpdateProb(VPXBooleanDecoder boolDec, int prob) {
/* 1198 */     int update_prob = boolDec.readBit(252);
/* 1199 */     if (update_prob == 1) {
/* 1200 */       int deltaProb = decodeTermSubexp(boolDec);
/* 1201 */       prob = invRemapProb(deltaProb, prob);
/*      */     } 
/* 1203 */     return prob;
/*      */   }
/*      */   
/*      */   private int decodeTermSubexp(VPXBooleanDecoder boolDec) {
/* 1207 */     int bit = boolDec.readBitEq();
/* 1208 */     if (bit == 0) {
/* 1209 */       return boolDec.decodeInt(4);
/*      */     }
/* 1211 */     bit = boolDec.readBitEq();
/* 1212 */     if (bit == 0) {
/* 1213 */       return boolDec.decodeInt(4) + 16;
/*      */     }
/* 1215 */     bit = boolDec.readBitEq();
/* 1216 */     if (bit == 0) {
/* 1217 */       return boolDec.decodeInt(5) + 32;
/*      */     }
/* 1219 */     int v = boolDec.decodeInt(7);
/* 1220 */     if (v < 65)
/* 1221 */       return v + 64; 
/* 1222 */     bit = boolDec.readBitEq();
/* 1223 */     return (v << 1) - 1 + bit;
/*      */   }
/*      */   
/*      */   private int invRemapProb(int deltaProb, int prob) {
/* 1227 */     int m = prob;
/* 1228 */     int v = deltaProb;
/* 1229 */     v = Consts.INV_REMAP_TABLE[v];
/* 1230 */     m--;
/* 1231 */     if (m << 1 <= 255) {
/* 1232 */       m = 1 + invRecenterNonneg(v, m);
/*      */     } else {
/* 1234 */       m = 255 - invRecenterNonneg(v, 254 - m);
/* 1235 */     }  return m;
/*      */   }
/*      */   
/*      */   private int invRecenterNonneg(int v, int m) {
/* 1239 */     if (v > 2 * m)
/* 1240 */       return v; 
/* 1241 */     if ((v & 0x1) != 0)
/* 1242 */       return m - (v + 1 >> 1); 
/* 1243 */     return m + (v >> 1);
/*      */   }
/*      */   
/*      */   private void readCoefProbs(VPXBooleanDecoder boolDec) {
/* 1247 */     int maxTxSize = Consts.tx_mode_to_biggest_tx_size[this.txMode];
/* 1248 */     for (int txSz = 0; txSz <= maxTxSize; txSz++) {
/* 1249 */       int update_probs = boolDec.readBitEq();
/* 1250 */       if (update_probs == 1) {
/* 1251 */         for (int i = 0; i < 2; i++) {
/* 1252 */           for (int j = 0; j < 2; j++) {
/* 1253 */             for (int k = 0; k < 6; k++) {
/* 1254 */               int maxL = (k == 0) ? 3 : 6;
/* 1255 */               for (int l = 0; l < maxL; l++) {
/* 1256 */                 for (int m = 0; m < 3; m++) {
/* 1257 */                   this.coefProbs[txSz][i][j][k][l][m] = diffUpdateProb(boolDec, this.coefProbs[txSz][i][j][k][l][m]);
/*      */                 }
/*      */               } 
/*      */             } 
/*      */           } 
/*      */         } 
/*      */       }
/*      */     } 
/*      */   }
/*      */ 
/*      */   
/*      */   private void readSkipProb(VPXBooleanDecoder boolDec) {
/* 1269 */     for (int i = 0; i < 3; i++) {
/* 1270 */       this.skipProbs[i] = diffUpdateProb(boolDec, this.skipProbs[i]);
/*      */     }
/*      */   }
/*      */   
/*      */   private void readInterModeProbs(VPXBooleanDecoder boolDec) {
/* 1275 */     for (int i = 0; i < 7; i++) {
/* 1276 */       for (int j = 0; j < 3; j++)
/* 1277 */         this.interModeProbs[i][j] = diffUpdateProb(boolDec, this.interModeProbs[i][j]); 
/*      */     } 
/*      */   }
/*      */   private void readInterpFilterProbs(VPXBooleanDecoder boolDec) {
/* 1281 */     for (int j = 0; j < 4; j++) {
/* 1282 */       for (int i = 0; i < 2; i++)
/* 1283 */         this.interpFilterProbs[j][i] = diffUpdateProb(boolDec, this.interpFilterProbs[j][i]); 
/*      */     } 
/*      */   }
/*      */   private void readIsInterProbs(VPXBooleanDecoder boolDec) {
/* 1287 */     for (int i = 0; i < 4; i++)
/* 1288 */       this.isInterProbs[i] = diffUpdateProb(boolDec, this.isInterProbs[i]); 
/*      */   }
/*      */   
/*      */   private void frameReferenceMode(VPXBooleanDecoder boolDec) {
/* 1292 */     int compoundReferenceAllowed = 0;
/* 1293 */     for (int i = 1; i < 3; i++) {
/* 1294 */       if (this.refFrameSignBias[i] != this.refFrameSignBias[0])
/* 1295 */         compoundReferenceAllowed = 1; 
/* 1296 */     }  if (compoundReferenceAllowed == 1) {
/* 1297 */       int non_single_reference = boolDec.readBitEq();
/* 1298 */       if (non_single_reference == 0) {
/* 1299 */         this.refMode = 0;
/*      */       } else {
/* 1301 */         int reference_select = boolDec.readBitEq();
/* 1302 */         if (reference_select == 0) {
/* 1303 */           this.refMode = 1;
/*      */         } else {
/* 1305 */           this.refMode = 2;
/* 1306 */         }  setupCompoundReferenceMode();
/*      */       } 
/*      */     } else {
/* 1309 */       this.refMode = 0;
/*      */     } 
/*      */   }
/*      */   
/*      */   private void frameReferenceModeProbs(VPXBooleanDecoder boolDec) {
/* 1314 */     if (this.refMode == 2)
/* 1315 */       for (int i = 0; i < 5; i++) {
/* 1316 */         this.compModeProbs[i] = diffUpdateProb(boolDec, this.compModeProbs[i]);
/*      */       } 
/* 1318 */     if (this.refMode != 1) {
/* 1319 */       for (int i = 0; i < 5; i++) {
/* 1320 */         this.singleRefProbs[i][0] = diffUpdateProb(boolDec, this.singleRefProbs[i][0]);
/* 1321 */         this.singleRefProbs[i][1] = diffUpdateProb(boolDec, this.singleRefProbs[i][1]);
/*      */       } 
/*      */     }
/* 1324 */     if (this.refMode != 0)
/* 1325 */       for (int i = 0; i < 5; i++) {
/* 1326 */         this.compRefProbs[i] = diffUpdateProb(boolDec, this.compRefProbs[i]);
/*      */       } 
/*      */   }
/*      */   
/*      */   private void readYModeProbs(VPXBooleanDecoder boolDec) {
/* 1331 */     for (int i = 0; i < 4; i++) {
/* 1332 */       for (int j = 0; j < 9; j++)
/* 1333 */         this.yModeProbs[i][j] = diffUpdateProb(boolDec, this.yModeProbs[i][j]); 
/*      */     } 
/*      */   }
/*      */   private void readPartitionProbs(VPXBooleanDecoder boolDec) {
/* 1337 */     for (int i = 0; i < 16; i++) {
/* 1338 */       for (int j = 0; j < 3; j++)
/* 1339 */         this.partitionProbs[i][j] = diffUpdateProb(boolDec, this.partitionProbs[i][j]); 
/*      */     } 
/*      */   }
/*      */   private void mvProbs(VPXBooleanDecoder boolDec) {
/* 1343 */     for (int j = 0; j < 3; j++)
/* 1344 */       this.mvJointProbs[j] = updateMvProb(boolDec, this.mvJointProbs[j]);  int i;
/* 1345 */     for (i = 0; i < 2; i++) {
/* 1346 */       this.mvSignProbs[i] = updateMvProb(boolDec, this.mvSignProbs[i]); int k;
/* 1347 */       for (k = 0; k < 10; k++)
/* 1348 */         this.mvClassProbs[i][k] = updateMvProb(boolDec, this.mvClassProbs[i][k]); 
/* 1349 */       this.mvClass0BitProbs[i] = updateMvProb(boolDec, this.mvClass0BitProbs[i]);
/* 1350 */       for (k = 0; k < 10; k++)
/* 1351 */         this.mvBitsProbs[i][k] = updateMvProb(boolDec, this.mvBitsProbs[i][k]); 
/*      */     } 
/* 1353 */     for (i = 0; i < 2; i++) {
/* 1354 */       for (int m = 0; m < 2; m++) {
/* 1355 */         for (int n = 0; n < 3; n++)
/* 1356 */           this.mvClass0FrProbs[i][m][n] = updateMvProb(boolDec, this.mvClass0FrProbs[i][m][n]); 
/* 1357 */       }  for (int k = 0; k < 3; k++)
/* 1358 */         this.mvFrProbs[i][k] = updateMvProb(boolDec, this.mvFrProbs[i][k]); 
/*      */     } 
/* 1360 */     if (this.allowHighPrecisionMv == 1) {
/* 1361 */       for (i = 0; i < 2; i++) {
/* 1362 */         this.mvClass0HpProb[i] = updateMvProb(boolDec, this.mvClass0HpProb[i]);
/* 1363 */         this.mvHpProbs[i] = updateMvProb(boolDec, this.mvHpProbs[i]);
/*      */       } 
/*      */     }
/*      */   }
/*      */   
/*      */   private int updateMvProb(VPXBooleanDecoder boolDec, int prob) {
/* 1369 */     int update_mv_prob = boolDec.readBit(252);
/* 1370 */     if (update_mv_prob == 1) {
/* 1371 */       int mv_prob = boolDec.decodeInt(7);
/* 1372 */       prob = mv_prob << 1 | 0x1;
/*      */     } 
/* 1374 */     return prob;
/*      */   }
/*      */   
/*      */   private void setupCompoundReferenceMode() {
/* 1378 */     if (this.refFrameSignBias[1] == this.refFrameSignBias[3]) {
/* 1379 */       this.compFixedRef = 2;
/* 1380 */       this.compVarRef0 = 1;
/* 1381 */       this.compVarRef1 = 3;
/* 1382 */     } else if (this.refFrameSignBias[1] == this.refFrameSignBias[2]) {
/* 1383 */       this.compFixedRef = 3;
/* 1384 */       this.compVarRef0 = 1;
/* 1385 */       this.compVarRef1 = 2;
/*      */     } else {
/* 1387 */       this.compFixedRef = 1;
/* 1388 */       this.compVarRef0 = 3;
/* 1389 */       this.compVarRef1 = 2;
/*      */     } 
/*      */   }
/*      */   
/*      */   public int getFrameContextIdx() {
/* 1394 */     return this.frameContextIdx;
/*      */   }
/*      */   
/*      */   public int getTileColsLog2() {
/* 1398 */     return this.tileColsLog2;
/*      */   }
/*      */   
/*      */   public int getTileRowsLog2() {
/* 1402 */     return this.tileRowsLog2;
/*      */   }
/*      */   
/*      */   public int getFrameWidth() {
/* 1406 */     return this.frameWidth;
/*      */   }
/*      */   
/*      */   public int getFrameHeight() {
/* 1410 */     return this.frameHeight;
/*      */   }
/*      */   
/*      */   public int getBaseQIdx() {
/* 1414 */     return this.baseQIdx;
/*      */   }
/*      */   
/*      */   public int getDeltaQYDc() {
/* 1418 */     return this.deltaQYDc;
/*      */   }
/*      */   
/*      */   public int getDeltaQUvDc() {
/* 1422 */     return this.deltaQUvDc;
/*      */   }
/*      */   
/*      */   public int getDeltaQUvAc() {
/* 1426 */     return this.deltaQUvAc;
/*      */   }
/*      */   
/*      */   public int getFilterLevel() {
/* 1430 */     return this.filterLevel;
/*      */   }
/*      */   
/*      */   public int getSharpnessLevel() {
/* 1434 */     return this.sharpnessLevel;
/*      */   }
/*      */   
/*      */   public int[] getSkipProbs() {
/* 1438 */     return this.skipProbs;
/*      */   }
/*      */   
/*      */   public int[][] getTx8x8Probs() {
/* 1442 */     return this.tx8x8Probs;
/*      */   }
/*      */   
/*      */   public int[][] getTx16x16Probs() {
/* 1446 */     return this.tx16x16Probs;
/*      */   }
/*      */   
/*      */   public int[][] getTx32x32Probs() {
/* 1450 */     return this.tx32x32Probs;
/*      */   }
/*      */   
/*      */   public int[][][][][][] getCoefProbs() {
/* 1454 */     return this.coefProbs;
/*      */   }
/*      */   
/*      */   public int[] getMvJointProbs() {
/* 1458 */     return this.mvJointProbs;
/*      */   }
/*      */   
/*      */   public int[] getMvSignProb() {
/* 1462 */     return this.mvSignProbs;
/*      */   }
/*      */   
/*      */   public int[][] getMvClassProbs() {
/* 1466 */     return this.mvClassProbs;
/*      */   }
/*      */   
/*      */   public int[] getMvClass0BitProbs() {
/* 1470 */     return this.mvClass0BitProbs;
/*      */   }
/*      */   
/*      */   public int[][] getMvBitsProb() {
/* 1474 */     return this.mvBitsProbs;
/*      */   }
/*      */   
/*      */   public int[][][] getMvClass0FrProbs() {
/* 1478 */     return this.mvClass0FrProbs;
/*      */   }
/*      */   
/*      */   public int[][] getMvFrProbs() {
/* 1482 */     return this.mvFrProbs;
/*      */   }
/*      */   
/*      */   public int[] getMvClass0HpProbs() {
/* 1486 */     return this.mvClass0HpProb;
/*      */   }
/*      */   
/*      */   public int[] getMvHpProbs() {
/* 1490 */     return this.mvHpProbs;
/*      */   }
/*      */   
/*      */   public int[][] getInterModeProbs() {
/* 1494 */     return this.interModeProbs;
/*      */   }
/*      */   
/*      */   public int[][] getInterpFilterProbs() {
/* 1498 */     return this.interpFilterProbs;
/*      */   }
/*      */   
/*      */   public int[] getIsInterProbs() {
/* 1502 */     return this.isInterProbs;
/*      */   }
/*      */   
/*      */   public int[][] getSingleRefProbs() {
/* 1506 */     return this.singleRefProbs;
/*      */   }
/*      */   
/*      */   public int[][] getYModeProbs() {
/* 1510 */     return this.yModeProbs;
/*      */   }
/*      */   
/*      */   public int[][] getPartitionProbs() {
/* 1514 */     return this.partitionProbs;
/*      */   }
/*      */   
/*      */   public int[][] getUvModeProbs() {
/* 1518 */     return this.uvModeProbs;
/*      */   }
/*      */   
/*      */   public int[] getCompRefProbs() {
/* 1522 */     return this.compRefProbs;
/*      */   }
/*      */   
/*      */   public int[][][] getKfYModeProbs() {
/* 1526 */     return kfYmodeProbs;
/*      */   }
/*      */   
/*      */   public int[][] getKfUVModeProbs() {
/* 1530 */     return kfUvModeProbs;
/*      */   }
/*      */   
/*      */   public int[] getSegmentationTreeProbs() {
/* 1534 */     return this.segmentationTreeProbs;
/*      */   }
/*      */   
/*      */   public int[] getSegmentationPredProbs() {
/* 1538 */     return this.segmentationPredProbs;
/*      */   }
/*      */   
/*      */   public int[] getCompModeProb() {
/* 1542 */     return this.compModeProbs;
/*      */   }
/*      */   
/*      */   public int[] getAboveRefs() {
/* 1546 */     return this.aboveRefs;
/*      */   }
/*      */   
/*      */   public int[] getLeftRefs() {
/* 1550 */     return this.leftRefs;
/*      */   }
/*      */   
/*      */   public int getMiTileStartCol() {
/* 1554 */     return this.miTileStartCol;
/*      */   }
/*      */   
/*      */   public int[] getAboveTxSizes() {
/* 1558 */     return this.aboveTxSizes;
/*      */   }
/*      */   
/*      */   public int[] getLeftTxSizes() {
/* 1562 */     return this.leftTxSizes;
/*      */   }
/*      */ }


/* Location:              C:\Users\rapha\Downloads\aurora.jar!\META-INF\jars\jcodec-0.2.5.jar!\org\jcodec\codecs\vpx\vp9\DecodingContext.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */