/*     */ package org.jcodec.codecs.vpx.vp9;
/*     */ 
/*     */ import java.util.ArrayList;
/*     */ import java.util.List;
/*     */ import org.jcodec.codecs.vpx.VPXBooleanDecoder;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class CodedSuperBlock
/*     */ {
/*     */   private CodedBlock[] codedBlocks;
/*     */   
/*     */   public CodedSuperBlock(CodedBlock[] codedBlocks) {
/*  31 */     this.codedBlocks = codedBlocks;
/*     */   }
/*     */ 
/*     */   
/*     */   protected CodedSuperBlock() {}
/*     */   
/*     */   public CodedBlock[] getCodedBlocks() {
/*  38 */     return this.codedBlocks;
/*     */   }
/*     */ 
/*     */   
/*     */   public static CodedSuperBlock read(int miCol, int miRow, VPXBooleanDecoder decoder, DecodingContext c) {
/*  43 */     List<CodedBlock> blocks = new ArrayList<CodedBlock>();
/*     */     
/*  45 */     CodedSuperBlock result = new CodedSuperBlock();
/*  46 */     result.readSubPartition(miCol, miRow, 3, decoder, c, blocks);
/*     */     
/*  48 */     result.codedBlocks = blocks.<CodedBlock>toArray(CodedBlock.EMPTY_ARR);
/*     */     
/*  50 */     return result;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected CodedBlock readBlock(int miCol, int miRow, int blSz, VPXBooleanDecoder decoder, DecodingContext c) {
/*  57 */     return CodedBlock.read(miCol, miRow, blSz, decoder, c);
/*     */   }
/*     */ 
/*     */   
/*     */   protected void readSubPartition(int miCol, int miRow, int logBlkSize, VPXBooleanDecoder decoder, DecodingContext c, List<CodedBlock> blocks) {
/*  62 */     int part = readPartition(miCol, miRow, logBlkSize, decoder, c);
/*  63 */     int nextBlkSize = 1 << logBlkSize >> 1;
/*     */     
/*  65 */     if (logBlkSize > 0) {
/*  66 */       if (part == 0) {
/*  67 */         CodedBlock blk = readBlock(miCol, miRow, Consts.blSizeLookup[1 + logBlkSize][1 + logBlkSize], decoder, c);
/*  68 */         blocks.add(blk);
/*  69 */         saveAboveSizes(miCol, 1 + logBlkSize, c);
/*  70 */         saveLeftSizes(miRow, 1 + logBlkSize, c);
/*  71 */       } else if (part == 1) {
/*  72 */         CodedBlock blk = readBlock(miCol, miRow, Consts.blSizeLookup[1 + logBlkSize][logBlkSize], decoder, c);
/*  73 */         blocks.add(blk);
/*  74 */         saveAboveSizes(miCol, 1 + logBlkSize, c);
/*  75 */         saveLeftSizes(miRow, logBlkSize, c);
/*  76 */         if (miRow + nextBlkSize < c.getMiTileHeight()) {
/*  77 */           blk = readBlock(miCol, miRow + nextBlkSize, Consts.blSizeLookup[1 + logBlkSize][logBlkSize], decoder, c);
/*  78 */           blocks.add(blk);
/*  79 */           saveLeftSizes(miRow + nextBlkSize, logBlkSize, c);
/*     */         } 
/*  81 */       } else if (part == 2) {
/*  82 */         CodedBlock blk = readBlock(miCol, miRow, Consts.blSizeLookup[logBlkSize][1 + logBlkSize], decoder, c);
/*  83 */         blocks.add(blk);
/*  84 */         saveLeftSizes(miRow, 1 + logBlkSize, c);
/*  85 */         saveAboveSizes(miCol, logBlkSize, c);
/*  86 */         if (miCol + nextBlkSize < c.getMiTileWidth()) {
/*  87 */           blk = readBlock(miCol + nextBlkSize, miRow, Consts.blSizeLookup[logBlkSize][1 + logBlkSize], decoder, c);
/*  88 */           blocks.add(blk);
/*  89 */           saveAboveSizes(miCol + nextBlkSize, logBlkSize, c);
/*     */         } 
/*     */       } else {
/*  92 */         readSubPartition(miCol, miRow, logBlkSize - 1, decoder, c, blocks);
/*  93 */         if (miCol + nextBlkSize < c.getMiTileWidth())
/*  94 */           readSubPartition(miCol + nextBlkSize, miRow, logBlkSize - 1, decoder, c, blocks); 
/*  95 */         if (miRow + nextBlkSize < c.getMiTileHeight())
/*  96 */           readSubPartition(miCol, miRow + nextBlkSize, logBlkSize - 1, decoder, c, blocks); 
/*  97 */         if (miCol + nextBlkSize < c.getMiTileWidth() && miRow + nextBlkSize < c.getMiTileHeight())
/*  98 */           readSubPartition(miCol + nextBlkSize, miRow + nextBlkSize, logBlkSize - 1, decoder, c, blocks); 
/*     */       } 
/*     */     } else {
/* 101 */       int subBlSz = Consts.sub8x8PartitiontoBlockType[part];
/* 102 */       CodedBlock blk = readBlock(miCol, miRow, subBlSz, decoder, c);
/* 103 */       blocks.add(blk);
/* 104 */       saveAboveSizes(miCol, 1 + logBlkSize - ((subBlSz == 0 || subBlSz == 1) ? 1 : 0), c);
/* 105 */       saveLeftSizes(miRow, 1 + logBlkSize - ((subBlSz == 0 || subBlSz == 2) ? 1 : 0), c);
/*     */     } 
/*     */   }
/*     */   
/*     */   private static void saveLeftSizes(int miRow, int blkSize4x4, DecodingContext c) {
/* 110 */     int blkSize8x8 = (blkSize4x4 == 0) ? 0 : (blkSize4x4 - 1);
/* 111 */     int miBlkSize = 1 << blkSize8x8;
/*     */     
/* 113 */     int[] leftSizes = c.getLeftPartitionSizes();
/* 114 */     for (int i = 0; i < miBlkSize; i++)
/* 115 */       leftSizes[miRow % 8 + i] = blkSize4x4; 
/*     */   }
/*     */   
/*     */   private static void saveAboveSizes(int miCol, int blkSize4x4, DecodingContext c) {
/* 119 */     int blkSize8x8 = (blkSize4x4 == 0) ? 0 : (blkSize4x4 - 1);
/* 120 */     int miBlkSize = 1 << blkSize8x8;
/*     */     
/* 122 */     int[] aboveSizes = c.getAbovePartitionSizes();
/* 123 */     for (int i = 0; i < miBlkSize; i++) {
/* 124 */       aboveSizes[miCol + i] = blkSize4x4;
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   protected static int readPartition(int miCol, int miRow, int blkSize, VPXBooleanDecoder decoder, DecodingContext c) {
/* 130 */     int ctx = calcPartitionContext(miCol, miRow, blkSize, c);
/*     */     
/* 132 */     int[] probs = c.getPartitionProbs()[ctx];
/* 133 */     int halfBlk = 1 << blkSize >> 1;
/* 134 */     boolean rightEdge = (miCol + halfBlk >= c.getMiTileWidth());
/* 135 */     boolean bottomEdge = (miRow + halfBlk >= c.getMiTileHeight());
/*     */     
/* 137 */     if (rightEdge && bottomEdge)
/* 138 */       return 3; 
/* 139 */     if (rightEdge)
/* 140 */       return (decoder.readBit(probs[2]) == 1) ? 3 : 2; 
/* 141 */     if (bottomEdge) {
/* 142 */       return (decoder.readBit(probs[1]) == 1) ? 3 : 1;
/*     */     }
/* 144 */     return decoder.readTree(Consts.TREE_PARTITION, probs);
/*     */   }
/*     */ 
/*     */   
/*     */   private static int calcPartitionContext(int miCol, int miRow, int blkSize, DecodingContext c) {
/* 149 */     boolean left = false, above = false;
/*     */     
/* 151 */     int[] aboveSizes = c.getAbovePartitionSizes();
/* 152 */     above = (aboveSizes[miCol] <= blkSize);
/*     */     
/* 154 */     int[] leftSizes = c.getLeftPartitionSizes();
/* 155 */     int i = left | ((leftSizes[miRow % 8] <= blkSize) ? 1 : 0);
/*     */ 
/*     */ 
/*     */     
/* 159 */     return blkSize * 4 + ((i != 0) ? 2 : 0) + (above ? 1 : 0);
/*     */   }
/*     */ }


/* Location:              C:\Users\rapha\Downloads\aurora.jar!\META-INF\jars\jcodec-0.2.5.jar!\org\jcodec\codecs\vpx\vp9\CodedSuperBlock.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */