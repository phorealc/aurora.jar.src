/*     */ package org.jcodec.codecs.vpx;
/*     */ 
/*     */ import org.jcodec.common.tools.MathUtil;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class VPXBitstream
/*     */ {
/*  13 */   public static final int[] coeffBandMapping = new int[] { 0, 1, 2, 3, 6, 4, 5, 6, 6, 6, 6, 6, 6, 6, 6, 7 };
/*     */   
/*     */   private int[][][][] tokenBinProbs;
/*  16 */   private int whtNzLeft = 0;
/*     */   private int[] whtNzTop;
/*     */   private int[][] dctNzLeft;
/*     */   private int[][] dctNzTop;
/*     */   
/*     */   public VPXBitstream(int[][][][] tokenBinProbs, int mbWidth) {
/*  22 */     this.dctNzLeft = new int[][] { new int[4], new int[2], new int[2] };
/*  23 */     this.tokenBinProbs = tokenBinProbs;
/*     */     
/*  25 */     this.whtNzTop = new int[mbWidth];
/*  26 */     this.dctNzTop = new int[][] { new int[mbWidth << 2], new int[mbWidth << 1], new int[mbWidth << 1] };
/*     */   }
/*     */   
/*     */   public void encodeCoeffsWHT(VPXBooleanEncoder bc, int[] coeffs, int mbX) {
/*  30 */     int nCoeff = fastCountCoeffWHT(coeffs);
/*  31 */     encodeCoeffs(bc, coeffs, 0, nCoeff, 1, ((mbX == 0 || this.whtNzLeft <= 0) ? 0 : 1) + ((this.whtNzTop[mbX] > 0) ? 1 : 0));
/*  32 */     this.whtNzLeft = nCoeff;
/*  33 */     this.whtNzTop[mbX] = nCoeff;
/*     */   }
/*     */   
/*     */   public void encodeCoeffsDCT15(VPXBooleanEncoder bc, int[] coeffs, int mbX, int blkX, int blkY) {
/*  37 */     int nCoeff = countCoeff(coeffs, 16);
/*  38 */     int blkAbsX = (mbX << 2) + blkX;
/*  39 */     encodeCoeffs(bc, coeffs, 1, nCoeff, 0, ((blkAbsX == 0 || this.dctNzLeft[0][blkY] <= 0) ? 0 : 1) + ((this.dctNzTop[0][blkAbsX] > 0) ? 1 : 0));
/*  40 */     this.dctNzLeft[0][blkY] = Math.max(nCoeff - 1, 0);
/*  41 */     this.dctNzTop[0][blkAbsX] = Math.max(nCoeff - 1, 0);
/*     */   }
/*     */   
/*     */   public void encodeCoeffsDCT16(VPXBooleanEncoder bc, int[] coeffs, int mbX, int blkX, int blkY) {
/*  45 */     int nCoeff = countCoeff(coeffs, 16);
/*  46 */     int blkAbsX = (mbX << 2) + blkX;
/*  47 */     encodeCoeffs(bc, coeffs, 0, nCoeff, 3, ((blkAbsX == 0 || this.dctNzLeft[0][blkY] <= 0) ? 0 : 1) + ((this.dctNzTop[0][blkAbsX] > 0) ? 1 : 0));
/*  48 */     this.dctNzLeft[0][blkY] = nCoeff;
/*  49 */     this.dctNzTop[0][blkAbsX] = nCoeff;
/*     */   }
/*     */   
/*     */   public void encodeCoeffsDCTUV(VPXBooleanEncoder bc, int[] coeffs, int comp, int mbX, int blkX, int blkY) {
/*  53 */     int nCoeff = countCoeff(coeffs, 16);
/*  54 */     int blkAbsX = (mbX << 1) + blkX;
/*  55 */     encodeCoeffs(bc, coeffs, 0, nCoeff, 2, ((blkAbsX == 0 || this.dctNzLeft[comp][blkY] <= 0) ? 0 : 1) + ((this.dctNzTop[comp][blkAbsX] > 0) ? 1 : 0));
/*     */     
/*  57 */     this.dctNzLeft[comp][blkY] = nCoeff;
/*  58 */     this.dctNzTop[comp][blkAbsX] = nCoeff;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void encodeCoeffs(VPXBooleanEncoder bc, int[] coeffs, int firstCoeff, int nCoeff, int blkType, int ctx) {
/*  69 */     boolean prevZero = false;
/*     */     
/*     */     int i;
/*  72 */     for (i = firstCoeff; i < nCoeff; i++) {
/*  73 */       int[] probs = this.tokenBinProbs[blkType][coeffBandMapping[i]][ctx];
/*     */       
/*  75 */       int coeffAbs = MathUtil.abs(coeffs[i]);
/*  76 */       if (!prevZero)
/*  77 */         bc.writeBit(probs[0], 1); 
/*  78 */       if (coeffAbs == 0) {
/*  79 */         bc.writeBit(probs[1], 0);
/*  80 */         ctx = 0;
/*     */       } else {
/*  82 */         bc.writeBit(probs[1], 1);
/*  83 */         if (coeffAbs == 1) {
/*  84 */           bc.writeBit(probs[2], 0);
/*  85 */           ctx = 1;
/*     */         } else {
/*  87 */           ctx = 2;
/*  88 */           bc.writeBit(probs[2], 1);
/*  89 */           if (coeffAbs <= 4) {
/*  90 */             bc.writeBit(probs[3], 0);
/*  91 */             if (coeffAbs == 2) {
/*  92 */               bc.writeBit(probs[4], 0);
/*     */             } else {
/*  94 */               bc.writeBit(probs[4], 1);
/*  95 */               bc.writeBit(probs[5], coeffAbs - 3);
/*     */             } 
/*     */           } else {
/*  98 */             bc.writeBit(probs[3], 1);
/*  99 */             if (coeffAbs <= 10) {
/* 100 */               bc.writeBit(probs[6], 0);
/* 101 */               if (coeffAbs <= 6) {
/* 102 */                 bc.writeBit(probs[7], 0);
/* 103 */                 bc.writeBit(159, coeffAbs - 5);
/*     */               } else {
/* 105 */                 bc.writeBit(probs[7], 1);
/* 106 */                 int d = coeffAbs - 7;
/* 107 */                 bc.writeBit(165, d >> 1);
/* 108 */                 bc.writeBit(145, d & 0x1);
/*     */               } 
/*     */             } else {
/* 111 */               bc.writeBit(probs[6], 1);
/* 112 */               if (coeffAbs <= 34) {
/* 113 */                 bc.writeBit(probs[8], 0);
/* 114 */                 if (coeffAbs <= 18) {
/* 115 */                   bc.writeBit(probs[9], 0);
/* 116 */                   writeCat3Ext(bc, coeffAbs);
/*     */                 } else {
/* 118 */                   bc.writeBit(probs[9], 1);
/* 119 */                   writeCat4Ext(bc, coeffAbs);
/*     */                 } 
/*     */               } else {
/* 122 */                 bc.writeBit(probs[8], 1);
/* 123 */                 if (coeffAbs <= 66) {
/* 124 */                   bc.writeBit(probs[10], 0);
/* 125 */                   writeCatExt(bc, coeffAbs, 35, VPXConst.probCoeffExtCat5);
/*     */                 } else {
/* 127 */                   bc.writeBit(probs[10], 1);
/* 128 */                   writeCatExt(bc, coeffAbs, 67, VPXConst.probCoeffExtCat6);
/*     */                 } 
/*     */               } 
/*     */             } 
/*     */           } 
/*     */         } 
/* 134 */         bc.writeBit(128, MathUtil.sign(coeffs[i]));
/*     */       } 
/*     */       
/* 137 */       prevZero = (coeffAbs == 0);
/*     */     } 
/* 139 */     if (nCoeff < 16) {
/* 140 */       int[] probs = this.tokenBinProbs[blkType][coeffBandMapping[i]][ctx];
/* 141 */       bc.writeBit(probs[0], 0);
/*     */     } 
/*     */   }
/*     */   
/*     */   private static void writeCat3Ext(VPXBooleanEncoder bc, int coeff) {
/* 146 */     int d = coeff - 11;
/* 147 */     bc.writeBit(173, d >> 2);
/* 148 */     bc.writeBit(148, d >> 1 & 0x1);
/* 149 */     bc.writeBit(140, d & 0x1);
/*     */   }
/*     */   
/*     */   private static void writeCat4Ext(VPXBooleanEncoder bc, int coeff) {
/* 153 */     int d = coeff - 19;
/* 154 */     bc.writeBit(176, d >> 3);
/* 155 */     bc.writeBit(155, d >> 2 & 0x1);
/* 156 */     bc.writeBit(140, d >> 1 & 0x1);
/* 157 */     bc.writeBit(135, d & 0x1);
/*     */   }
/*     */   
/*     */   private static final void writeCatExt(VPXBooleanEncoder bc, int coeff, int catOff, int[] cat) {
/* 161 */     int d = coeff - catOff;
/* 162 */     for (int b = cat.length - 1, i = 0; b >= 0; b--) {
/* 163 */       bc.writeBit(cat[i++], d >> b & 0x1);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private int fastCountCoeffWHT(int[] coeffs) {
/* 175 */     if (coeffs[15] != 0) {
/* 176 */       return 16;
/*     */     }
/* 178 */     return countCoeff(coeffs, 15);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private int countCoeff(int[] coeffs, int nCoeff) {
/* 189 */     while (nCoeff > 0) {
/* 190 */       nCoeff--;
/* 191 */       if (coeffs[nCoeff] != 0)
/* 192 */         return nCoeff + 1; 
/*     */     } 
/* 194 */     return nCoeff;
/*     */   }
/*     */ }


/* Location:              C:\Users\rapha\Downloads\aurora.jar!\META-INF\jars\jcodec-0.2.5.jar!\org\jcodec\codecs\vpx\VPXBitstream.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */