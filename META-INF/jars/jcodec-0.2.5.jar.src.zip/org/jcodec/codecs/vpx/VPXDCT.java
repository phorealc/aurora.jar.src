/*     */ package org.jcodec.codecs.vpx;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class VPXDCT
/*     */ {
/*     */   public static void fdct4x4(int[] coef) {
/*     */     int i;
/*  13 */     for (i = 0; i < 16; i += 4) {
/*  14 */       int a1 = coef[i] + coef[i + 3] << 3;
/*  15 */       int b1 = coef[i + 1] + coef[i + 2] << 3;
/*  16 */       int c1 = coef[i + 1] - coef[i + 2] << 3;
/*  17 */       int d1 = coef[i] - coef[i + 3] << 3;
/*     */       
/*  19 */       coef[i] = a1 + b1;
/*  20 */       coef[i + 2] = a1 - b1;
/*     */       
/*  22 */       coef[i + 1] = c1 * 2217 + d1 * 5352 + 14500 >> 12;
/*  23 */       coef[i + 3] = d1 * 2217 - c1 * 5352 + 7500 >> 12;
/*     */     } 
/*     */     
/*  26 */     for (i = 0; i < 4; i++) {
/*  27 */       int a1 = coef[i] + coef[i + 12];
/*  28 */       int b1 = coef[i + 4] + coef[i + 8];
/*  29 */       int c1 = coef[i + 4] - coef[i + 8];
/*  30 */       int d1 = coef[i] - coef[i + 12];
/*     */       
/*  32 */       coef[i] = a1 + b1 + 7 >> 4;
/*  33 */       coef[i + 8] = a1 - b1 + 7 >> 4;
/*     */       
/*  35 */       coef[i + 4] = (c1 * 2217 + d1 * 5352 + 12000 >> 16) + ((d1 != 0) ? 1 : 0);
/*  36 */       coef[i + 12] = d1 * 2217 - c1 * 5352 + 51000 >> 16;
/*     */     } 
/*     */   }
/*     */   public static void walsh4x4(int[] coef) {
/*     */     int i;
/*  41 */     for (i = 0; i < 16; i += 4) {
/*  42 */       int a1 = coef[i] + coef[i + 2] << 2;
/*  43 */       int d1 = coef[i + 1] + coef[i + 3] << 2;
/*  44 */       int c1 = coef[i + 1] - coef[i + 3] << 2;
/*  45 */       int b1 = coef[i] - coef[i + 2] << 2;
/*     */       
/*  47 */       coef[i] = a1 + d1 + ((a1 != 0) ? 1 : 0);
/*  48 */       coef[i + 1] = b1 + c1;
/*  49 */       coef[i + 2] = b1 - c1;
/*  50 */       coef[i + 3] = a1 - d1;
/*     */     } 
/*     */     
/*  53 */     for (i = 0; i < 4; i++) {
/*  54 */       int a1 = coef[i] + coef[i + 8];
/*  55 */       int d1 = coef[i + 4] + coef[i + 12];
/*  56 */       int c1 = coef[i + 4] - coef[i + 12];
/*  57 */       int b1 = coef[i] - coef[i + 8];
/*     */       
/*  59 */       int a2 = a1 + d1;
/*  60 */       int b2 = b1 + c1;
/*  61 */       int c2 = b1 - c1;
/*  62 */       int d2 = a1 - d1;
/*     */       
/*  64 */       a2 += (a2 < 0) ? 1 : 0;
/*  65 */       b2 += (b2 < 0) ? 1 : 0;
/*  66 */       c2 += (c2 < 0) ? 1 : 0;
/*  67 */       d2 += (d2 < 0) ? 1 : 0;
/*     */       
/*  69 */       coef[i] = a2 + 3 >> 3;
/*  70 */       coef[i + 4] = b2 + 3 >> 3;
/*  71 */       coef[i + 8] = c2 + 3 >> 3;
/*  72 */       coef[i + 12] = d2 + 3 >> 3;
/*     */     } 
/*     */   }
/*     */   
/*  76 */   public static int cospi8sqrt2minus1 = 20091;
/*  77 */   public static int sinpi8sqrt2 = 35468;
/*     */   
/*     */   public static void idct4x4(int[] coef) {
/*     */     int i;
/*  81 */     for (i = 0; i < 4; i++) {
/*  82 */       int a1 = coef[i] + coef[i + 8];
/*  83 */       int b1 = coef[i] - coef[i + 8];
/*     */       
/*  85 */       int temp1 = coef[i + 4] * sinpi8sqrt2 >> 16;
/*  86 */       int temp2 = coef[i + 12] + (coef[i + 12] * cospi8sqrt2minus1 >> 16);
/*  87 */       int c1 = temp1 - temp2;
/*     */       
/*  89 */       temp1 = coef[i + 4] + (coef[i + 4] * cospi8sqrt2minus1 >> 16);
/*  90 */       temp2 = coef[i + 12] * sinpi8sqrt2 >> 16;
/*  91 */       int d1 = temp1 + temp2;
/*     */       
/*  93 */       coef[i] = a1 + d1;
/*  94 */       coef[i + 12] = a1 - d1;
/*     */       
/*  96 */       coef[i + 4] = b1 + c1;
/*  97 */       coef[i + 8] = b1 - c1;
/*     */     } 
/*     */     
/* 100 */     for (i = 0; i < 16; i += 4) {
/* 101 */       int a1 = coef[i] + coef[i + 2];
/* 102 */       int b1 = coef[i] - coef[i + 2];
/*     */       
/* 104 */       int temp1 = coef[i + 1] * sinpi8sqrt2 >> 16;
/* 105 */       int temp2 = coef[i + 3] + (coef[i + 3] * cospi8sqrt2minus1 >> 16);
/* 106 */       int c1 = temp1 - temp2;
/*     */       
/* 108 */       temp1 = coef[i + 1] + (coef[i + 1] * cospi8sqrt2minus1 >> 16);
/* 109 */       temp2 = coef[i + 3] * sinpi8sqrt2 >> 16;
/* 110 */       int d1 = temp1 + temp2;
/*     */       
/* 112 */       coef[i] = a1 + d1 + 4 >> 3;
/* 113 */       coef[i + 3] = a1 - d1 + 4 >> 3;
/*     */       
/* 115 */       coef[i + 1] = b1 + c1 + 4 >> 3;
/* 116 */       coef[i + 2] = b1 - c1 + 4 >> 3;
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public static void iwalsh4x4(int[] coef) {
/*     */     int i;
/* 123 */     for (i = 0; i < 4; i++) {
/* 124 */       int a1 = coef[i] + coef[i + 12];
/* 125 */       int b1 = coef[i + 4] + coef[i + 8];
/* 126 */       int c1 = coef[i + 4] - coef[i + 8];
/* 127 */       int d1 = coef[i] - coef[i + 12];
/*     */       
/* 129 */       coef[i] = a1 + b1;
/* 130 */       coef[i + 4] = c1 + d1;
/* 131 */       coef[i + 8] = a1 - b1;
/* 132 */       coef[i + 12] = d1 - c1;
/*     */     } 
/*     */     
/* 135 */     for (i = 0; i < 16; i += 4) {
/* 136 */       int a1 = coef[i] + coef[i + 3];
/* 137 */       int b1 = coef[i + 1] + coef[i + 2];
/* 138 */       int c1 = coef[i + 1] - coef[i + 2];
/* 139 */       int d1 = coef[i] - coef[i + 3];
/*     */       
/* 141 */       int a2 = a1 + b1;
/* 142 */       int b2 = c1 + d1;
/* 143 */       int c2 = a1 - b1;
/* 144 */       int d2 = d1 - c1;
/*     */       
/* 146 */       coef[i] = a2 + 3 >> 3;
/* 147 */       coef[i + 1] = b2 + 3 >> 3;
/* 148 */       coef[i + 2] = c2 + 3 >> 3;
/* 149 */       coef[i + 3] = d2 + 3 >> 3;
/*     */     } 
/*     */   }
/*     */ }


/* Location:              C:\Users\rapha\Downloads\aurora.jar!\META-INF\jars\jcodec-0.2.5.jar!\org\jcodec\codecs\vpx\VPXDCT.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */