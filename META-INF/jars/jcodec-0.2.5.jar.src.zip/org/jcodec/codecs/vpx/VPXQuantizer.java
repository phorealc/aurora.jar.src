/*    */ package org.jcodec.codecs.vpx;
/*    */ 
/*    */ import org.jcodec.common.tools.MathUtil;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class VPXQuantizer
/*    */ {
/*    */   private int y1_dc_delta_q;
/*    */   private int uv_dc_delta_q;
/*    */   private int uv_ac_delta_q;
/*    */   private int y2_dc_delta_q;
/*    */   private int y2_ac_delta_q;
/*    */   
/*    */   public final void quantizeY(int[] coeffs, int qp) {
/* 20 */     int factDC = MathUtil.clip(VPXConst.dc_qlookup[qp + this.y1_dc_delta_q], 8, 132);
/* 21 */     int invFactAC = MathUtil.clip(VPXConst.ac_qlookup[qp], 8, 132);
/* 22 */     quantize(coeffs, factDC, invFactAC);
/*    */   }
/*    */   
/*    */   public final void quantizeUV(int[] coeffs, int qp) {
/* 26 */     int factDC = MathUtil.clip(VPXConst.dc_qlookup[qp + this.uv_dc_delta_q], 8, 132);
/* 27 */     int invFactAC = MathUtil.clip(VPXConst.ac_qlookup[qp + this.uv_ac_delta_q], 8, 132);
/* 28 */     quantize(coeffs, factDC, invFactAC);
/*    */   }
/*    */   
/*    */   public final void quantizeY2(int[] coeffs, int qp) {
/* 32 */     int factDC = MathUtil.clip(VPXConst.dc_qlookup[qp + this.y2_dc_delta_q] * 2, 8, 132);
/* 33 */     int invFactAC = MathUtil.clip(VPXConst.ac_qlookup[qp + this.y2_ac_delta_q] * 155 / 100, 8, 132);
/* 34 */     quantize(coeffs, factDC, invFactAC);
/*    */   }
/*    */   
/*    */   private final void quantize(int[] coeffs, int factDC, int factAC) {
/* 38 */     coeffs[0] = coeffs[0] / factDC;
/* 39 */     for (int i = 1; i < 16; i++)
/* 40 */       coeffs[i] = coeffs[i] / factAC; 
/*    */   }
/*    */   
/*    */   public final void dequantizeY(int[] coeffs, int qp) {
/* 44 */     int factDC = MathUtil.clip(VPXConst.dc_qlookup[qp + this.y1_dc_delta_q], 8, 132);
/* 45 */     int factAC = MathUtil.clip(VPXConst.ac_qlookup[qp], 8, 132);
/* 46 */     dequantize(coeffs, factDC, factAC);
/*    */   }
/*    */   
/*    */   public final void dequantizeUV(int[] coeffs, int qp) {
/* 50 */     int factDC = MathUtil.clip(VPXConst.dc_qlookup[qp + this.uv_dc_delta_q], 8, 132);
/* 51 */     int factAC = MathUtil.clip(VPXConst.ac_qlookup[qp + this.uv_ac_delta_q], 8, 132);
/* 52 */     dequantize(coeffs, factDC, factAC);
/*    */   }
/*    */   
/*    */   public final void dequantizeY2(int[] coeffs, int qp) {
/* 56 */     int factDC = MathUtil.clip(VPXConst.dc_qlookup[qp + this.y2_dc_delta_q] * 2, 8, 132);
/* 57 */     int factAC = MathUtil.clip(VPXConst.ac_qlookup[qp + this.y2_ac_delta_q] * 155 / 100, 8, 132);
/* 58 */     dequantize(coeffs, factDC, factAC);
/*    */   }
/*    */   
/*    */   private final void dequantize(int[] coeffs, int factDC, int factAC) {
/* 62 */     coeffs[0] = coeffs[0] * factDC;
/* 63 */     for (int i = 1; i < 16; i++)
/* 64 */       coeffs[i] = coeffs[i] * factAC; 
/*    */   }
/*    */ }


/* Location:              C:\Users\rapha\Downloads\aurora.jar!\META-INF\jars\jcodec-0.2.5.jar!\org\jcodec\codecs\vpx\VPXQuantizer.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */