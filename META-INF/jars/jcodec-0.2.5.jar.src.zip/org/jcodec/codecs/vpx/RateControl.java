package org.jcodec.codecs.vpx;

public interface RateControl {
  int[] getSegmentQps();
  
  int getSegment();
  
  void report(int paramInt);
  
  void reset();
}


/* Location:              C:\Users\rapha\Downloads\aurora.jar!\META-INF\jars\jcodec-0.2.5.jar!\org\jcodec\codecs\vpx\RateControl.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */