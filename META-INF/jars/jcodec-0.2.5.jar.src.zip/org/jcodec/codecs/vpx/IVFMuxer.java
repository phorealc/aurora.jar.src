/*    */ package org.jcodec.codecs.vpx;
/*    */ 
/*    */ import java.io.IOException;
/*    */ import java.nio.ByteBuffer;
/*    */ import java.nio.ByteOrder;
/*    */ import java.nio.channels.WritableByteChannel;
/*    */ import org.jcodec.common.AudioCodecMeta;
/*    */ import org.jcodec.common.Codec;
/*    */ import org.jcodec.common.Muxer;
/*    */ import org.jcodec.common.MuxerTrack;
/*    */ import org.jcodec.common.VideoCodecMeta;
/*    */ import org.jcodec.common.io.NIOUtils;
/*    */ import org.jcodec.common.io.SeekableByteChannel;
/*    */ import org.jcodec.common.model.Packet;
/*    */ import org.jcodec.common.model.Size;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class IVFMuxer
/*    */   implements Muxer, MuxerTrack
/*    */ {
/*    */   private SeekableByteChannel ch;
/*    */   private int nFrames;
/*    */   private Size dim;
/*    */   private int frameRate;
/*    */   private boolean headerWritten;
/*    */   
/*    */   public IVFMuxer(SeekableByteChannel ch) throws IOException {
/* 32 */     this.ch = ch;
/*    */   }
/*    */ 
/*    */   
/*    */   public void addFrame(Packet pkt) throws IOException {
/* 37 */     if (!this.headerWritten) {
/* 38 */       this.frameRate = pkt.getTimescale();
/* 39 */       writeHeader();
/* 40 */       this.headerWritten = true;
/*    */     } 
/*    */     
/* 43 */     ByteBuffer fh = ByteBuffer.allocate(12);
/* 44 */     fh.order(ByteOrder.LITTLE_ENDIAN);
/* 45 */     ByteBuffer frame = pkt.getData();
/* 46 */     fh.putInt(frame.remaining());
/* 47 */     fh.putLong(this.nFrames);
/* 48 */     fh.clear();
/*    */     
/* 50 */     this.ch.write(fh);
/* 51 */     this.ch.write(frame);
/*    */     
/* 53 */     this.nFrames++;
/*    */   }
/*    */   
/*    */   public void close() throws IOException {
/* 57 */     this.ch.setPosition(24L);
/* 58 */     NIOUtils.writeIntLE((WritableByteChannel)this.ch, this.nFrames);
/*    */   }
/*    */ 
/*    */   
/*    */   public MuxerTrack addVideoTrack(Codec codec, VideoCodecMeta meta) {
/* 63 */     if (this.dim != null)
/* 64 */       throw new RuntimeException("IVF can not have multiple video tracks."); 
/* 65 */     this.dim = meta.getSize();
/* 66 */     return this;
/*    */   }
/*    */   
/*    */   private void writeHeader() throws IOException {
/* 70 */     ByteBuffer ivf = ByteBuffer.allocate(32);
/* 71 */     ivf.order(ByteOrder.LITTLE_ENDIAN);
/*    */     
/* 73 */     ivf.put((byte)68);
/* 74 */     ivf.put((byte)75);
/* 75 */     ivf.put((byte)73);
/* 76 */     ivf.put((byte)70);
/* 77 */     ivf.putShort((short)0);
/* 78 */     ivf.putShort((short)32);
/* 79 */     ivf.putInt(808996950);
/* 80 */     ivf.putShort((short)this.dim.getWidth());
/* 81 */     ivf.putShort((short)this.dim.getHeight());
/* 82 */     ivf.putInt(this.frameRate);
/* 83 */     ivf.putInt(1);
/* 84 */     ivf.putInt(1);
/* 85 */     ivf.clear();
/*    */     
/* 87 */     this.ch.write(ivf);
/*    */   }
/*    */ 
/*    */   
/*    */   public MuxerTrack addAudioTrack(Codec codec, AudioCodecMeta meta) {
/* 92 */     throw new RuntimeException("Video-only container");
/*    */   }
/*    */   
/*    */   public void finish() throws IOException {}
/*    */ }


/* Location:              C:\Users\rapha\Downloads\aurora.jar!\META-INF\jars\jcodec-0.2.5.jar!\org\jcodec\codecs\vpx\IVFMuxer.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */