/*     */ package org.jcodec.codecs.mjpeg;
/*     */ 
/*     */ import java.nio.ByteBuffer;
/*     */ import java.util.Arrays;
/*     */ import org.jcodec.api.UnhandledStateException;
/*     */ import org.jcodec.common.VideoCodecMeta;
/*     */ import org.jcodec.common.VideoDecoder;
/*     */ import org.jcodec.common.dct.SimpleIDCT10Bit;
/*     */ import org.jcodec.common.io.BitReader;
/*     */ import org.jcodec.common.io.NIOUtils;
/*     */ import org.jcodec.common.io.VLC;
/*     */ import org.jcodec.common.io.VLCBuilder;
/*     */ import org.jcodec.common.logging.Logger;
/*     */ import org.jcodec.common.model.ColorSpace;
/*     */ import org.jcodec.common.model.Picture;
/*     */ import org.jcodec.common.model.Rect;
/*     */ import org.jcodec.common.model.Size;
/*     */ import org.jcodec.common.tools.MathUtil;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class JpegDecoder
/*     */   extends VideoDecoder
/*     */ {
/*     */   private boolean interlace;
/*     */   private boolean topFieldFirst;
/*  35 */   int[] buf = new int[64];
/*     */ 
/*     */   
/*     */   public void setInterlace(boolean interlace, boolean topFieldFirst) {
/*  39 */     this.interlace = interlace;
/*  40 */     this.topFieldFirst = topFieldFirst;
/*     */   }
/*     */ 
/*     */   
/*     */   private Picture decodeScan(ByteBuffer data, FrameHeader header, ScanHeader scan, VLC[] huffTables, int[][] quant, byte[][] data2, int field, int step) {
/*  45 */     int blockW = header.getHmax();
/*  46 */     int blockH = header.getVmax();
/*  47 */     int mcuW = blockW << 3;
/*  48 */     int mcuH = blockH << 3;
/*     */     
/*  50 */     int width = header.width;
/*  51 */     int height = header.height;
/*     */     
/*  53 */     int xBlocks = width + mcuW - 1 >> blockW + 2;
/*  54 */     int yBlocks = height + mcuH - 1 >> blockH + 2;
/*     */     
/*  56 */     int nn = blockW + blockH;
/*  57 */     Picture result = new Picture(xBlocks << blockW + 2, yBlocks << blockH + 2, data2, (byte[][])null, (nn == 4) ? ColorSpace.YUV420J : ((nn == 3) ? ColorSpace.YUV422J : ColorSpace.YUV444J), 0, new Rect(0, 0, width, height));
/*     */ 
/*     */ 
/*     */     
/*  61 */     BitReader bits = BitReader.createBitReader(data);
/*  62 */     int[] dcPredictor = { 1024, 1024, 1024 };
/*  63 */     for (int by = 0; by < yBlocks; by++) {
/*  64 */       for (int bx = 0; bx < xBlocks && bits.moreData(); bx++)
/*  65 */         decodeMCU(bits, dcPredictor, quant, huffTables, result, bx, by, blockW, blockH, field, step); 
/*     */     } 
/*  67 */     return result;
/*     */   }
/*     */   
/*     */   private static void putBlock(byte[] plane, int stride, int[] patch, int x, int y, int field, int step) {
/*  71 */     int dstride = step * stride;
/*  72 */     for (int i = 0, off = field * stride + y * dstride + x, poff = 0; i < 8; i++) {
/*  73 */       for (int j = 0; j < 8; j++)
/*  74 */         plane[j + off] = (byte)(MathUtil.clip(patch[j + poff], 0, 255) - 128); 
/*  75 */       off += dstride;
/*  76 */       poff += 8;
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   private void decodeMCU(BitReader bits, int[] dcPredictor, int[][] quant, VLC[] huff, Picture result, int bx, int by, int blockH, int blockV, int field, int step) {
/*  82 */     int sx = bx << blockH - 1;
/*  83 */     int sy = by << blockV - 1;
/*     */     
/*  85 */     for (int i = 0; i < blockV; i++) {
/*  86 */       for (int j = 0; j < blockH; j++) {
/*  87 */         decodeBlock(bits, dcPredictor, quant, huff, result, this.buf, sx + j << 3, sy + i << 3, 0, 0, field, step);
/*     */       }
/*     */     } 
/*     */     
/*  91 */     decodeBlock(bits, dcPredictor, quant, huff, result, this.buf, bx << 3, by << 3, 1, 1, field, step);
/*  92 */     decodeBlock(bits, dcPredictor, quant, huff, result, this.buf, bx << 3, by << 3, 2, 1, field, step);
/*     */   }
/*     */ 
/*     */   
/*     */   void decodeBlock(BitReader bits, int[] dcPredictor, int[][] quant, VLC[] huff, Picture result, int[] buf, int blkX, int blkY, int plane, int chroma, int field, int step) {
/*  97 */     Arrays.fill(buf, 0);
/*  98 */     buf[0] = readDCValue(bits, huff[chroma]) * quant[chroma][0] + dcPredictor[plane]; dcPredictor[plane] = readDCValue(bits, huff[chroma]) * quant[chroma][0] + dcPredictor[plane];
/*  99 */     readACValues(bits, buf, huff[chroma + 2], quant[chroma]);
/* 100 */     SimpleIDCT10Bit.idct10(buf, 0);
/*     */     
/* 102 */     putBlock(result.getPlaneData(plane), result.getPlaneWidth(plane), buf, blkX, blkY, field, step);
/*     */   }
/*     */   
/*     */   static int readDCValue(BitReader _in, VLC table) {
/* 106 */     int code = table.readVLC16(_in);
/* 107 */     return (code != 0) ? toValue(_in.readNBit(code), code) : 0;
/*     */   }
/*     */ 
/*     */   
/*     */   void readACValues(BitReader _in, int[] target, VLC table, int[] quantTable) {
/* 112 */     int code, curOff = 1;
/*     */     do {
/* 114 */       code = table.readVLC16(_in);
/* 115 */       if (code == 240) {
/* 116 */         curOff += 16;
/* 117 */       } else if (code > 0) {
/* 118 */         int rle = code >> 4;
/* 119 */         curOff += rle;
/* 120 */         int len = code & 0xF;
/* 121 */         target[JpegConst.naturalOrder[curOff]] = toValue(_in.readNBit(len), len) * quantTable[curOff];
/* 122 */         curOff++;
/*     */       } 
/* 124 */     } while (code != 0 && curOff < 64);
/*     */   }
/*     */   
/*     */   static int toValue(int raw, int length) {
/* 128 */     return (length >= 1 && raw < 1 << length - 1) ? (-(1 << length) + 1 + raw) : raw;
/*     */   }
/*     */ 
/*     */   
/*     */   public Picture decodeFrame(ByteBuffer data, byte[][] data2) {
/* 133 */     if (this.interlace) {
/* 134 */       Picture r1 = decodeField(data, data2, this.topFieldFirst ? 0 : 1, 2);
/* 135 */       Picture r2 = decodeField(data, data2, this.topFieldFirst ? 1 : 0, 2);
/* 136 */       return Picture.createPicture(r1.getWidth(), r1.getHeight() << 1, data2, r1.getColor());
/*     */     } 
/* 138 */     return decodeField(data, data2, 0, 1);
/*     */   }
/*     */ 
/*     */   
/*     */   public Picture decodeField(ByteBuffer data, byte[][] data2, int field, int step) {
/* 143 */     Picture result = null;
/*     */     
/* 145 */     FrameHeader header = null;
/* 146 */     VLC[] huffTables = { JpegConst.YDC_DEFAULT, JpegConst.CDC_DEFAULT, JpegConst.YAC_DEFAULT, JpegConst.CAC_DEFAULT };
/*     */     
/* 148 */     int[][] quant = { JpegConst.DEFAULT_QUANT_LUMA, JpegConst.DEFAULT_QUANT_CHROMA };
/* 149 */     ScanHeader scan = null;
/* 150 */     boolean skipToNext = false;
/* 151 */     while (data.hasRemaining()) {
/*     */       int marker;
/* 153 */       if (!skipToNext) {
/* 154 */         marker = data.get() & 0xFF;
/*     */       } else {
/* 156 */         while ((marker = data.get() & 0xFF) != 255);
/*     */       } 
/*     */       
/* 159 */       skipToNext = false;
/* 160 */       if (marker == 0)
/*     */         continue; 
/* 162 */       if (marker != 255) {
/* 163 */         throw new RuntimeException("@" + 
/* 164 */             Long.toHexString(data.position()) + " Marker expected: 0x" + Integer.toHexString(marker));
/*     */       }
/*     */       int b;
/* 167 */       while ((b = data.get() & 0xFF) == 255);
/*     */ 
/*     */       
/* 170 */       if (b == 192) {
/* 171 */         header = FrameHeader.read(data); continue;
/*     */       } 
/* 173 */       if (b == 196) {
/* 174 */         int len1 = data.getShort() & 0xFFFF;
/* 175 */         ByteBuffer buf = NIOUtils.read(data, len1 - 2);
/* 176 */         while (buf.hasRemaining()) {
/* 177 */           int tableNo = buf.get() & 0xFF;
/* 178 */           huffTables[tableNo & 0x1 | tableNo >> 3 & 0x2] = readHuffmanTable(buf);
/*     */         }  continue;
/* 180 */       }  if (b == 219) {
/* 181 */         int len4 = data.getShort() & 0xFFFF;
/* 182 */         ByteBuffer buf = NIOUtils.read(data, len4 - 2);
/* 183 */         while (buf.hasRemaining()) {
/* 184 */           int ind = buf.get() & 0xFF;
/* 185 */           quant[ind] = readQuantTable(buf);
/*     */         }  continue;
/* 187 */       }  if (b == 218) {
/*     */         
/* 189 */         if (scan != null) {
/* 190 */           throw new UnhandledStateException("unhandled - more than one scan header");
/*     */         }
/* 192 */         scan = ScanHeader.read(data);
/*     */         
/* 194 */         result = decodeScan(readToMarker(data), header, scan, huffTables, quant, data2, field, step); continue;
/* 195 */       }  if (b == 216 || (b >= 208 && b <= 215)) {
/* 196 */         Logger.warn("SOI not supported.");
/* 197 */         skipToNext = true; continue;
/* 198 */       }  if (b == 217)
/*     */         break; 
/* 200 */       if (b >= 224 && b <= 254) {
/* 201 */         int len3 = data.getShort() & 0xFFFF;
/* 202 */         NIOUtils.read(data, len3 - 2); continue;
/* 203 */       }  if (b == 221) {
/* 204 */         Logger.warn("DRI not supported.");
/* 205 */         skipToNext = true; continue;
/*     */       } 
/* 207 */       if (b != 0)
/* 208 */         Logger.warn("unhandled marker " + JpegConst.markerToString(b)); 
/* 209 */       skipToNext = true;
/*     */     } 
/*     */ 
/*     */     
/* 213 */     return result;
/*     */   }
/*     */   
/*     */   private static ByteBuffer readToMarker(ByteBuffer data) {
/* 217 */     ByteBuffer out = ByteBuffer.allocate(data.remaining());
/* 218 */     while (data.hasRemaining()) {
/* 219 */       byte b0 = data.get();
/* 220 */       if (b0 == -1) {
/* 221 */         byte b1 = data.get();
/* 222 */         if (b1 == 0) {
/* 223 */           out.put((byte)-1); continue;
/*     */         } 
/* 225 */         data.position(data.position() - 2);
/*     */         
/*     */         break;
/*     */       } 
/* 229 */       out.put(b0);
/*     */     } 
/* 231 */     out.flip();
/* 232 */     return out;
/*     */   }
/*     */   
/*     */   private static VLC readHuffmanTable(ByteBuffer data) {
/* 236 */     VLCBuilder builder = new VLCBuilder();
/*     */     
/* 238 */     byte[] levelSizes = NIOUtils.toArray(NIOUtils.read(data, 16));
/*     */     
/* 240 */     int levelStart = 0;
/* 241 */     for (int i = 0; i < 16; i++) {
/* 242 */       int length = levelSizes[i] & 0xFF;
/* 243 */       for (int c = 0; c < length; c++) {
/* 244 */         int val = data.get() & 0xFF;
/* 245 */         int code = levelStart++;
/* 246 */         builder.setInt(code, i + 1, val);
/*     */       } 
/* 248 */       levelStart <<= 1;
/*     */     } 
/*     */     
/* 251 */     return builder.getVLC();
/*     */   }
/*     */   
/*     */   private static int[] readQuantTable(ByteBuffer data) {
/* 255 */     int[] result = new int[64];
/* 256 */     for (int i = 0; i < 64; i++) {
/* 257 */       result[i] = data.get() & 0xFF;
/*     */     }
/* 259 */     return result;
/*     */   }
/*     */ 
/*     */   
/*     */   public VideoCodecMeta getCodecMeta(ByteBuffer data) {
/* 264 */     FrameHeader header = null;
/* 265 */     while (data.hasRemaining()) {
/* 266 */       while (data.hasRemaining() && (data.get() & 0xFF) != 255);
/*     */       
/*     */       int type;
/*     */       
/* 270 */       while ((type = data.get() & 0xFF) == 255);
/*     */       
/* 272 */       if (type == 192) {
/* 273 */         header = FrameHeader.read(data);
/*     */         break;
/*     */       } 
/*     */     } 
/* 277 */     if (header != null) {
/* 278 */       int blockW = header.getHmax();
/* 279 */       int blockH = header.getVmax();
/* 280 */       int nn = blockW + blockH;
/* 281 */       ColorSpace color = (nn == 4) ? ColorSpace.YUV420J : ((nn == 3) ? ColorSpace.YUV422J : ColorSpace.YUV444J);
/* 282 */       return VideoCodecMeta.createSimpleVideoCodecMeta(new Size(header.width, header.height), color);
/*     */     } 
/* 284 */     return null;
/*     */   }
/*     */ }


/* Location:              C:\Users\rapha\Downloads\aurora.jar!\META-INF\jars\jcodec-0.2.5.jar!\org\jcodec\codecs\mjpeg\JpegDecoder.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */