/*     */ package org.jcodec.codecs.mjpeg;
/*     */ 
/*     */ import java.nio.ByteBuffer;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ScanHeader
/*     */ {
/*     */   int ls;
/*     */   int ns;
/*     */   Component[] components;
/*     */   int ss;
/*     */   int se;
/*     */   int ah;
/*     */   int al;
/*     */   
/*     */   public boolean isInterleaved() {
/*  32 */     return (this.ns > 1);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static class Component
/*     */   {
/*     */     int cs;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     int td;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     int ta;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static ScanHeader read(ByteBuffer bb) {
/* 126 */     ScanHeader scan = new ScanHeader();
/* 127 */     scan.ls = bb.getShort() & 0xFFFF;
/* 128 */     scan.ns = bb.get() & 0xFF;
/* 129 */     scan.components = new Component[scan.ns];
/* 130 */     for (int i = 0; i < scan.components.length; i++) {
/* 131 */       Component c = scan.components[i] = new Component();
/* 132 */       c.cs = bb.get() & 0xFF;
/* 133 */       int tdta = bb.get() & 0xFF;
/* 134 */       c.td = (tdta & 0xF0) >>> 4;
/* 135 */       c.ta = tdta & 0xF;
/*     */     } 
/* 137 */     scan.ss = bb.get() & 0xFF;
/* 138 */     scan.se = bb.get() & 0xFF;
/* 139 */     int ahal = bb.get() & 0xFF;
/* 140 */     scan.ah = (ahal & 0xF0) >>> 4;
/* 141 */     scan.al = ahal & 0xF;
/* 142 */     return scan;
/*     */   }
/*     */ }


/* Location:              C:\Users\rapha\Downloads\aurora.jar!\META-INF\jars\jcodec-0.2.5.jar!\org\jcodec\codecs\mjpeg\ScanHeader.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */