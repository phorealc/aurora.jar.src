/*     */ package org.jcodec.codecs.mjpeg;
/*     */ 
/*     */ import java.nio.ByteBuffer;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class FrameHeader
/*     */ {
/*     */   int headerLength;
/*     */   int bitsPerSample;
/*     */   int height;
/*     */   int width;
/*     */   int nComp;
/*     */   Component[] components;
/*     */   
/*     */   public static class Component
/*     */   {
/*     */     int index;
/*     */     int subH;
/*     */     int subV;
/*     */     int quantTable;
/*     */   }
/*     */   
/*     */   public int getHmax() {
/*  92 */     int max = 0;
/*  93 */     for (int i = 0; i < this.components.length; i++) {
/*  94 */       Component c = this.components[i];
/*  95 */       max = Math.max(max, c.subH);
/*     */     } 
/*  97 */     return max;
/*     */   }
/*     */   
/*     */   public int getVmax() {
/* 101 */     int max = 0;
/* 102 */     for (int i = 0; i < this.components.length; i++) {
/* 103 */       Component c = this.components[i];
/* 104 */       max = Math.max(max, c.subV);
/*     */     } 
/* 106 */     return max;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public static FrameHeader read(ByteBuffer is) {
/* 112 */     FrameHeader frame = new FrameHeader();
/* 113 */     frame.headerLength = is.getShort() & 0xFFFF;
/* 114 */     frame.bitsPerSample = is.get() & 0xFF;
/* 115 */     frame.height = is.getShort() & 0xFFFF;
/* 116 */     frame.width = is.getShort() & 0xFFFF;
/* 117 */     frame.nComp = is.get() & 0xFF;
/* 118 */     frame.components = new Component[frame.nComp];
/* 119 */     for (int i = 0; i < frame.components.length; i++) {
/* 120 */       Component c = frame.components[i] = new Component();
/* 121 */       c.index = is.get() & 0xFF;
/* 122 */       int hv = is.get() & 0xFF;
/* 123 */       c.subH = (hv & 0xF0) >>> 4;
/* 124 */       c.subV = hv & 0xF;
/* 125 */       c.quantTable = is.get() & 0xFF;
/*     */     } 
/* 127 */     return frame;
/*     */   }
/*     */ }


/* Location:              C:\Users\rapha\Downloads\aurora.jar!\META-INF\jars\jcodec-0.2.5.jar!\org\jcodec\codecs\mjpeg\FrameHeader.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */