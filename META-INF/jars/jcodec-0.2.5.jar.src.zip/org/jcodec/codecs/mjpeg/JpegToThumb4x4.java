/*    */ package org.jcodec.codecs.mjpeg;
/*    */ 
/*    */ import java.nio.ByteBuffer;
/*    */ import org.jcodec.common.dct.IDCT4x4;
/*    */ import org.jcodec.common.io.BitReader;
/*    */ import org.jcodec.common.io.VLC;
/*    */ import org.jcodec.common.model.Picture;
/*    */ import org.jcodec.common.model.Rect;
/*    */ import org.jcodec.common.tools.MathUtil;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class JpegToThumb4x4
/*    */   extends JpegDecoder
/*    */ {
/* 23 */   private static final int[] mapping4x4 = new int[] { 0, 1, 4, 8, 5, 2, 3, 6, 9, 12, 16, 13, 10, 7, 16, 16, 16, 11, 14, 16, 16, 16, 16, 16, 15, 16, 16, 16, 16, 16, 16, 16, 16, 16, 16, 16, 16, 16, 16, 16, 16, 16, 16, 16, 16, 16, 16, 16, 16, 16, 16, 16, 16, 16, 16, 16, 16, 16, 16, 16, 16, 16, 16, 16 };
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   void decodeBlock(BitReader bits, int[] dcPredictor, int[][] quant, VLC[] huff, Picture result, int[] buf, int blkX, int blkY, int plane, int chroma, int field, int step) {
/* 30 */     buf[15] = 0; buf[14] = 0; buf[13] = 0; buf[12] = 0; buf[11] = 0; buf[10] = 0; buf[9] = 0; buf[8] = 0; buf[7] = 0; buf[6] = 0; buf[5] = 0; buf[4] = 0; buf[3] = 0; buf[2] = 0; buf[1] = 0;
/*    */     
/* 32 */     buf[0] = readDCValue(bits, huff[chroma]) * quant[chroma][0] + dcPredictor[plane]; dcPredictor[plane] = readDCValue(bits, huff[chroma]) * quant[chroma][0] + dcPredictor[plane];
/* 33 */     readACValues(bits, buf, huff[chroma + 2], quant[chroma]);
/* 34 */     IDCT4x4.idct(buf, 0);
/*    */     
/* 36 */     putBlock4x4(result.getPlaneData(plane), result.getPlaneWidth(plane), buf, blkX, blkY, field, step);
/*    */   }
/*    */   
/*    */   private static void putBlock4x4(byte[] plane, int stride, int[] patch, int x, int y, int field, int step) {
/* 40 */     stride >>= 1;
/* 41 */     int dstride = step * stride;
/* 42 */     int off = field * stride + (y >> 1) * dstride + (x >> 1);
/* 43 */     for (int i = 0; i < 16; i += 4) {
/* 44 */       plane[off] = (byte)(MathUtil.clip(patch[i], 0, 255) - 128);
/* 45 */       plane[off + 1] = (byte)(MathUtil.clip(patch[i + 1], 0, 255) - 128);
/* 46 */       plane[off + 2] = (byte)(MathUtil.clip(patch[i + 2], 0, 255) - 128);
/* 47 */       plane[off + 3] = (byte)(MathUtil.clip(patch[i + 3], 0, 255) - 128);
/* 48 */       off += dstride;
/*    */     } 
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   void readACValues(BitReader _in, int[] target, VLC table, int[] quantTable) {
/* 55 */     int code, curOff = 1;
/*    */     do {
/* 57 */       code = table.readVLC16(_in);
/* 58 */       if (code == 240) {
/* 59 */         curOff += 16;
/* 60 */       } else if (code > 0) {
/* 61 */         int rle = code >> 4;
/* 62 */         curOff += rle;
/* 63 */         int len = code & 0xF;
/* 64 */         target[mapping4x4[curOff]] = toValue(_in.readNBit(len), len) * quantTable[curOff];
/* 65 */         curOff++;
/*    */       } 
/* 67 */     } while (code != 0 && curOff < 19);
/*    */     
/* 69 */     if (code != 0) {
/*    */       do {
/* 71 */         code = table.readVLC16(_in);
/* 72 */         if (code == 240) {
/* 73 */           curOff += 16;
/* 74 */         } else if (code > 0) {
/* 75 */           int rle = code >> 4;
/* 76 */           curOff += rle;
/* 77 */           int len = code & 0xF;
/* 78 */           _in.skip(len);
/* 79 */           curOff++;
/*    */         } 
/* 81 */       } while (code != 0 && curOff < 64);
/*    */     }
/*    */   }
/*    */ 
/*    */   
/*    */   public Picture decodeField(ByteBuffer data, byte[][] data2, int field, int step) {
/* 87 */     Picture res = super.decodeField(data, data2, field, step);
/*    */     
/* 89 */     return new Picture(res.getWidth() >> 1, res.getHeight() >> 1, res.getData(), (byte[][])null, res.getColor(), 0, new Rect(0, 0, res
/* 90 */           .getCroppedWidth() >> 1, res.getCroppedHeight() >> 1));
/*    */   }
/*    */ }


/* Location:              C:\Users\rapha\Downloads\aurora.jar!\META-INF\jars\jcodec-0.2.5.jar!\org\jcodec\codecs\mjpeg\JpegToThumb4x4.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */