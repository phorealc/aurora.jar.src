/*    */ package org.jcodec.codecs.mjpeg;
/*    */ 
/*    */ import java.nio.ByteBuffer;
/*    */ import org.jcodec.common.dct.IDCT2x2;
/*    */ import org.jcodec.common.io.BitReader;
/*    */ import org.jcodec.common.io.VLC;
/*    */ import org.jcodec.common.model.Picture;
/*    */ import org.jcodec.common.model.Rect;
/*    */ import org.jcodec.common.tools.MathUtil;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class JpegToThumb2x2
/*    */   extends JpegDecoder
/*    */ {
/* 23 */   private static final int[] mapping2x2 = new int[] { 0, 1, 2, 4, 3, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4 };
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   void decodeBlock(BitReader bits, int[] dcPredictor, int[][] quant, VLC[] huff, Picture result, int[] buf, int blkX, int blkY, int plane, int chroma, int field, int step) {
/* 29 */     buf[3] = 0; buf[2] = 0; buf[1] = 0;
/* 30 */     buf[0] = readDCValue(bits, huff[chroma]) * quant[chroma][0] + dcPredictor[plane]; dcPredictor[plane] = readDCValue(bits, huff[chroma]) * quant[chroma][0] + dcPredictor[plane];
/* 31 */     readACValues(bits, buf, huff[chroma + 2], quant[chroma]);
/* 32 */     IDCT2x2.idct(buf, 0);
/*    */     
/* 34 */     putBlock2x2(result.getPlaneData(plane), result.getPlaneWidth(plane), buf, blkX, blkY, field, step);
/*    */   }
/*    */   
/*    */   private static void putBlock2x2(byte[] plane, int stride, int[] patch, int x, int y, int field, int step) {
/* 38 */     stride >>= 2;
/* 39 */     int dstride = stride * step;
/* 40 */     int off = field * stride + (y >> 2) * dstride + (x >> 2);
/* 41 */     plane[off] = (byte)(MathUtil.clip(patch[0], 0, 255) - 128);
/* 42 */     plane[off + 1] = (byte)(MathUtil.clip(patch[1], 0, 255) - 128);
/* 43 */     plane[off + dstride] = (byte)(MathUtil.clip(patch[2], 0, 255) - 128);
/* 44 */     plane[off + dstride + 1] = (byte)(MathUtil.clip(patch[3], 0, 255) - 128);
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   void readACValues(BitReader _in, int[] target, VLC table, int[] quantTable) {
/* 50 */     int code, curOff = 1;
/*    */     do {
/* 52 */       code = table.readVLC16(_in);
/* 53 */       if (code == 240) {
/* 54 */         curOff += 16;
/* 55 */       } else if (code > 0) {
/* 56 */         int rle = code >> 4;
/* 57 */         curOff += rle;
/* 58 */         int len = code & 0xF;
/* 59 */         target[mapping2x2[curOff]] = toValue(_in.readNBit(len), len) * quantTable[curOff];
/* 60 */         curOff++;
/*    */       } 
/* 62 */     } while (code != 0 && curOff < 5);
/*    */     
/* 64 */     if (code != 0) {
/*    */       do {
/* 66 */         code = table.readVLC16(_in);
/* 67 */         if (code == 240) {
/* 68 */           curOff += 16;
/* 69 */         } else if (code > 0) {
/* 70 */           int rle = code >> 4;
/* 71 */           curOff += rle;
/* 72 */           int len = code & 0xF;
/* 73 */           _in.skip(len);
/* 74 */           curOff++;
/*    */         } 
/* 76 */       } while (code != 0 && curOff < 64);
/*    */     }
/*    */   }
/*    */ 
/*    */   
/*    */   public Picture decodeField(ByteBuffer data, byte[][] data2, int field, int step) {
/* 82 */     Picture res = super.decodeField(data, data2, field, step);
/*    */     
/* 84 */     return new Picture(res.getWidth() >> 2, res.getHeight() >> 2, res.getData(), (byte[][])null, res.getColor(), 0, new Rect(0, 0, res
/* 85 */           .getCroppedWidth() >> 2, res.getCroppedHeight() >> 2));
/*    */   }
/*    */ }


/* Location:              C:\Users\rapha\Downloads\aurora.jar!\META-INF\jars\jcodec-0.2.5.jar!\org\jcodec\codecs\mjpeg\JpegToThumb2x2.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */