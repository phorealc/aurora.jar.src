/*    */ package org.jcodec.codecs.mjpeg;
/*    */ 
/*    */ import java.nio.ByteBuffer;
/*    */ import org.jcodec.common.io.BitReader;
/*    */ import org.jcodec.common.io.VLC;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class JPEGBitStream
/*    */ {
/*    */   private VLC[] huff;
/*    */   private BitReader _in;
/*    */   private int[] dcPredictor;
/*    */   private int lumaLen;
/*    */   
/*    */   public JPEGBitStream(ByteBuffer b, VLC[] huff, int lumaLen) {
/* 25 */     this.dcPredictor = new int[3];
/* 26 */     this._in = BitReader.createBitReader(b);
/* 27 */     this.huff = huff;
/* 28 */     this.lumaLen = lumaLen;
/*    */   }
/*    */   
/*    */   public void readMCU(int[][] buf) {
/* 32 */     int blk = 0;
/* 33 */     for (int i = 0; i < this.lumaLen; i++, blk++) {
/* 34 */       buf[blk][0] = readDCValue(this.dcPredictor[0], this.huff[0]); this.dcPredictor[0] = readDCValue(this.dcPredictor[0], this.huff[0]);
/* 35 */       readACValues(buf[blk], this.huff[2]);
/*    */     } 
/*    */     
/* 38 */     buf[blk][0] = readDCValue(this.dcPredictor[1], this.huff[1]); this.dcPredictor[1] = readDCValue(this.dcPredictor[1], this.huff[1]);
/* 39 */     readACValues(buf[blk], this.huff[3]);
/* 40 */     blk++;
/*    */     
/* 42 */     buf[blk][0] = readDCValue(this.dcPredictor[2], this.huff[1]); this.dcPredictor[2] = readDCValue(this.dcPredictor[2], this.huff[1]);
/* 43 */     readACValues(buf[blk], this.huff[3]);
/* 44 */     blk++;
/*    */   }
/*    */   
/*    */   public int readDCValue(int prevDC, VLC table) {
/* 48 */     int code = table.readVLC(this._in);
/* 49 */     return (code != 0) ? (toValue(this._in.readNBit(code), code) + prevDC) : prevDC;
/*    */   }
/*    */ 
/*    */   
/*    */   public void readACValues(int[] target, VLC table) {
/* 54 */     int code, curOff = 1;
/*    */     do {
/* 56 */       code = table.readVLC(this._in);
/* 57 */       if (code == 240) {
/* 58 */         curOff += 16;
/* 59 */       } else if (code > 0) {
/* 60 */         int rle = code >> 4;
/* 61 */         curOff += rle;
/* 62 */         int len = code & 0xF;
/* 63 */         target[curOff] = toValue(this._in.readNBit(len), len);
/* 64 */         curOff++;
/*    */       } 
/* 66 */     } while (code != 0 && curOff < 64);
/*    */   }
/*    */   
/*    */   public final int toValue(int raw, int length) {
/* 70 */     return (length >= 1 && raw < 1 << length - 1) ? (-(1 << length) + 1 + raw) : raw;
/*    */   }
/*    */ }


/* Location:              C:\Users\rapha\Downloads\aurora.jar!\META-INF\jars\jcodec-0.2.5.jar!\org\jcodec\codecs\mjpeg\JPEGBitStream.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */