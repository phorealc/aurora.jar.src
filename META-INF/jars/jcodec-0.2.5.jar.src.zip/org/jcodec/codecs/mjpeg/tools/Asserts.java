/*    */ package org.jcodec.codecs.mjpeg.tools;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class Asserts
/*    */ {
/*    */   public static void assertEquals(int expected, int actual) {
/* 12 */     if (expected != actual) {
/* 13 */       throw new AssertionException("assert failed: " + expected + " != " + actual);
/*    */     }
/*    */   }
/*    */ 
/*    */   
/*    */   public static void assertInRange(String message, int low, int up, int val) {
/* 19 */     if (val < low || val > up) {
/* 20 */       throw new AssertionException(message);
/*    */     }
/*    */   }
/*    */   
/*    */   public static void assertEpsilonEqualsInt(int[] expected, int[] actual, int eps) {
/* 25 */     if (expected.length != actual.length)
/* 26 */       throw new AssertionException("arrays of different size"); 
/* 27 */     for (int i = 0; i < expected.length; i++) {
/* 28 */       int e = expected[i];
/* 29 */       int a = actual[i];
/* 30 */       if (Math.abs(e - a) > eps) {
/* 31 */         throw new AssertionException("array element " + i + " " + e + " != " + a + " out of expected diff range " + eps);
/*    */       }
/*    */     } 
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public static void assertEpsilonEquals(byte[] expected, byte[] actual, int eps) {
/* 39 */     if (expected.length != actual.length)
/* 40 */       throw new AssertionException("arrays of different size"); 
/* 41 */     for (int i = 0; i < expected.length; i++) {
/* 42 */       int e = expected[i] & 0xFF;
/* 43 */       int a = actual[i] & 0xFF;
/* 44 */       if (Math.abs(e - a) > eps)
/* 45 */         throw new AssertionException("array element out of expected diff range: " + 
/*    */             
/* 47 */             Math.abs(e - a)); 
/*    */     } 
/*    */   }
/*    */ }


/* Location:              C:\Users\rapha\Downloads\aurora.jar!\META-INF\jars\jcodec-0.2.5.jar!\org\jcodec\codecs\mjpeg\tools\Asserts.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */