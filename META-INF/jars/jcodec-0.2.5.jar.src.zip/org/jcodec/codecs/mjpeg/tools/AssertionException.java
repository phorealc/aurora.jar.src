/*   */ package org.jcodec.codecs.mjpeg.tools;
/*   */ 
/*   */ public class AssertionException
/*   */   extends RuntimeException {
/*   */   public AssertionException(String string) {
/* 6 */     super(string);
/*   */   }
/*   */ }


/* Location:              C:\Users\rapha\Downloads\aurora.jar!\META-INF\jars\jcodec-0.2.5.jar!\org\jcodec\codecs\mjpeg\tools\AssertionException.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */