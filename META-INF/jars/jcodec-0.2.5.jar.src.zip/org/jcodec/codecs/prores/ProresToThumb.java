/*     */ package org.jcodec.codecs.prores;
/*     */ 
/*     */ import java.nio.ByteBuffer;
/*     */ import org.jcodec.common.io.BitReader;
/*     */ import org.jcodec.common.model.ColorSpace;
/*     */ import org.jcodec.common.model.Picture;
/*     */ import org.jcodec.common.model.Rect;
/*     */ import org.jcodec.common.tools.MathUtil;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ProresToThumb
/*     */   extends ProresDecoder
/*     */ {
/*     */   protected void decodeOnePlane(BitReader bits, int blocksPerSlice, int[] out, int[] qMat, int[] scan, int mbX, int mbY, int plane) {
/*     */     try {
/*  31 */       readDCCoeffs(bits, qMat, out, blocksPerSlice, 1);
/*  32 */     } catch (RuntimeException e) {
/*  33 */       System.err.println("Suppressing slice error at [" + mbX + ", " + mbY + "].");
/*     */     } 
/*     */     
/*  36 */     for (int i = 0; i < blocksPerSlice; i++) {
/*  37 */       out[i] = out[i] >> 3;
/*     */     }
/*     */   }
/*     */   
/*     */   public Picture decodeFrameHiBD(ByteBuffer data, byte[][] target, byte[][] lowBits) {
/*  42 */     ProresConsts.FrameHeader fh = readFrameHeader(data);
/*     */     
/*  44 */     int codedWidth = (fh.width + 15 & 0xFFFFFFF0) >> 3;
/*  45 */     int codedHeight = (fh.height + 15 & 0xFFFFFFF0) >> 3;
/*     */     
/*  47 */     int lumaSize = codedWidth * codedHeight;
/*  48 */     int chromaSize = lumaSize >> 1;
/*     */     
/*  50 */     if (target == null || (target[0]).length < lumaSize || (target[1]).length < chromaSize || (target[2]).length < chromaSize)
/*     */     {
/*  52 */       throw new RuntimeException("Provided output picture won't fit into provided buffer");
/*     */     }
/*     */     
/*  55 */     if (fh.frameType == 0) {
/*  56 */       decodePicture(data, target, lowBits, codedWidth, codedHeight, codedWidth >> 1, fh.qMatLuma, fh.qMatChroma, new int[] { 0 }, 0, fh.chromaType);
/*     */     } else {
/*     */       
/*  59 */       decodePicture(data, target, lowBits, codedWidth, codedHeight >> 1, codedWidth >> 1, fh.qMatLuma, fh.qMatChroma, new int[] { 0 }, fh.topFieldFirst ? 1 : 2, fh.chromaType);
/*     */ 
/*     */       
/*  62 */       decodePicture(data, target, lowBits, codedWidth, codedHeight >> 1, codedWidth >> 1, fh.qMatLuma, fh.qMatChroma, new int[] { 0 }, fh.topFieldFirst ? 2 : 1, fh.chromaType);
/*     */     } 
/*     */ 
/*     */     
/*  66 */     ColorSpace color = (fh.chromaType == 2) ? ColorSpace.YUV422 : ColorSpace.YUV444;
/*  67 */     return new Picture(codedWidth, codedHeight, target, lowBits, color, (lowBits == null) ? 0 : 2, new Rect(0, 0, fh.width >> 3 & color
/*  68 */           .getWidthMask(), fh.height >> 3 & color.getHeightMask()));
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   protected void putSlice(byte[][] result, byte[][] lowBits, int lumaStride, int mbX, int mbY, int[] y, int[] u, int[] v, int dist, int shift, int chromaType, int sliceMbCount) {
/*  74 */     int chromaStride = lumaStride >> 1;
/*     */     
/*  76 */     _putLuma(result[0], (lowBits != null) ? lowBits[0] : null, shift * lumaStride, lumaStride << dist, mbX, mbY, y, sliceMbCount, dist, shift);
/*     */     
/*  78 */     if (chromaType == 2) {
/*  79 */       _putChroma(result[1], (lowBits != null) ? lowBits[1] : null, shift * chromaStride, chromaStride << dist, mbX, mbY, u, sliceMbCount, dist, shift);
/*     */       
/*  81 */       _putChroma(result[2], (lowBits != null) ? lowBits[2] : null, shift * chromaStride, chromaStride << dist, mbX, mbY, v, sliceMbCount, dist, shift);
/*     */     } else {
/*     */       
/*  84 */       _putLuma(result[1], (lowBits != null) ? lowBits[1] : null, shift * lumaStride, lumaStride << dist, mbX, mbY, u, sliceMbCount, dist, shift);
/*     */       
/*  86 */       _putLuma(result[2], (lowBits != null) ? lowBits[2] : null, shift * lumaStride, lumaStride << dist, mbX, mbY, v, sliceMbCount, dist, shift);
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   private void _putLuma(byte[] y, byte[] lowBits, int _off, int stride, int mbX, int mbY, int[] luma, int mbPerSlice, int dist, int shift) {
/*  92 */     int off = _off + (mbX << 1) + (mbY << 1) * stride; int k, sOff;
/*  93 */     for (k = 0, sOff = 0; k < mbPerSlice; k++) {
/*  94 */       int round0 = MathUtil.clip(luma[sOff] + 2 >> 2, 1, 255);
/*  95 */       y[off] = (byte)(round0 - 128);
/*     */       
/*  97 */       int round1 = MathUtil.clip(luma[sOff + 1] + 2 >> 2, 1, 255);
/*  98 */       y[off + 1] = (byte)(round1 - 128);
/*     */       
/* 100 */       off += stride;
/*     */       
/* 102 */       int round2 = MathUtil.clip(luma[sOff + 2] + 2 >> 2, 1, 255);
/* 103 */       y[off] = (byte)(round2 - 128);
/*     */       
/* 105 */       int round3 = MathUtil.clip(luma[sOff + 3] + 2 >> 2, 1, 255);
/* 106 */       y[off + 1] = (byte)(round3 - 128);
/*     */       
/* 108 */       off += 2 - stride;
/* 109 */       sOff += 4;
/*     */     } 
/*     */     
/* 112 */     if (lowBits != null) {
/* 113 */       off = _off + (mbX << 1) + (mbY << 1) * stride;
/* 114 */       for (k = 0, sOff = 0; k < mbPerSlice; k++) {
/* 115 */         int val0 = MathUtil.clip(luma[sOff], 4, 1019);
/* 116 */         int round0 = MathUtil.clip(luma[sOff] + 2 >> 2, 1, 255);
/* 117 */         lowBits[off] = (byte)(val0 - (round0 << 2));
/*     */         
/* 119 */         int val1 = MathUtil.clip(luma[sOff + 1], 4, 1019);
/* 120 */         int round1 = MathUtil.clip(luma[sOff + 1] + 2 >> 2, 1, 255);
/* 121 */         lowBits[off + 1] = (byte)(val1 - (round1 << 2));
/*     */         
/* 123 */         off += stride;
/*     */         
/* 125 */         int val2 = MathUtil.clip(luma[sOff + 2], 4, 1019);
/* 126 */         int round2 = MathUtil.clip(luma[sOff + 2] + 2 >> 2, 1, 255);
/* 127 */         lowBits[off] = (byte)(val2 - (round2 << 2));
/*     */         
/* 129 */         int val3 = MathUtil.clip(luma[sOff + 3], 4, 1019);
/* 130 */         int round3 = MathUtil.clip(luma[sOff + 3] + 2 >> 2, 1, 255);
/* 131 */         lowBits[off + 1] = (byte)(val3 - (round3 << 2));
/*     */         
/* 133 */         off += 2 - stride;
/* 134 */         sOff += 4;
/*     */       } 
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   private void _putChroma(byte[] y, byte[] lowBits, int _off, int stride, int mbX, int mbY, int[] chroma, int mbPerSlice, int dist, int shift) {
/* 141 */     int off = _off + mbX + (mbY << 1) * stride; int k, sOff;
/* 142 */     for (k = 0, sOff = 0; k < mbPerSlice; k++) {
/* 143 */       int round0 = MathUtil.clip(chroma[sOff] + 2 >> 2, 1, 255);
/* 144 */       y[off] = (byte)(round0 - 128);
/*     */       
/* 146 */       off += stride;
/*     */       
/* 148 */       int round1 = MathUtil.clip(chroma[sOff + 1] + 2 >> 2, 1, 255);
/* 149 */       y[off] = (byte)(round1 - 128);
/*     */       
/* 151 */       off += 1 - stride;
/* 152 */       sOff += 2;
/*     */     } 
/*     */     
/* 155 */     if (lowBits != null) {
/* 156 */       off = _off + mbX + (mbY << 1) * stride;
/* 157 */       for (k = 0, sOff = 0; k < mbPerSlice; k++) {
/*     */         
/* 159 */         int val0 = MathUtil.clip(chroma[sOff], 4, 1019);
/* 160 */         int round0 = MathUtil.clip(chroma[sOff] + 2 >> 2, 1, 255);
/* 161 */         lowBits[off] = (byte)(val0 - (round0 << 2));
/*     */         
/* 163 */         off += stride;
/*     */         
/* 165 */         int val1 = MathUtil.clip(chroma[sOff + 1], 4, 1019);
/* 166 */         int round1 = MathUtil.clip(chroma[sOff + 1] + 2 >> 2, 1, 255);
/* 167 */         lowBits[off] = (byte)(val1 - (round1 << 2));
/*     */         
/* 169 */         off += 1 - stride;
/* 170 */         sOff += 2;
/*     */       } 
/*     */     } 
/*     */   }
/*     */ }


/* Location:              C:\Users\rapha\Downloads\aurora.jar!\META-INF\jars\jcodec-0.2.5.jar!\org\jcodec\codecs\prores\ProresToThumb.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */