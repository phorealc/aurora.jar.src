/*     */ package org.jcodec.codecs.prores;
/*     */ 
/*     */ import java.nio.ByteBuffer;
/*     */ import java.util.Arrays;
/*     */ import org.jcodec.common.UsedViaReflection;
/*     */ import org.jcodec.common.VideoCodecMeta;
/*     */ import org.jcodec.common.VideoDecoder;
/*     */ import org.jcodec.common.dct.SimpleIDCT10Bit;
/*     */ import org.jcodec.common.io.BitReader;
/*     */ import org.jcodec.common.io.NIOUtils;
/*     */ import org.jcodec.common.logging.Logger;
/*     */ import org.jcodec.common.model.ColorSpace;
/*     */ import org.jcodec.common.model.Picture;
/*     */ import org.jcodec.common.model.Rect;
/*     */ import org.jcodec.common.model.Size;
/*     */ import org.jcodec.common.tools.MathUtil;
/*     */ import org.jcodec.platform.Platform;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ProresDecoder
/*     */   extends VideoDecoder
/*     */ {
/*  49 */   static final int[] table = new int[] { 8, 7, 6, 6, 5, 5, 5, 5, 4, 4, 4, 4, 4, 4, 4, 4, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0 };
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  58 */   static final int[] mask = new int[] { 0, 0, 0, 0, 0, 0, 0, 0, -1 };
/*     */   
/*     */   public static final int nZeros(int check16Bit) {
/*  61 */     int low = table[check16Bit & 0xFF];
/*  62 */     check16Bit >>= 8;
/*  63 */     int high = table[check16Bit];
/*     */     
/*  65 */     return high + (mask[high] & low);
/*     */   }
/*     */   
/*     */   public static final int readCodeword(BitReader reader, Codebook codebook) {
/*  69 */     int q = nZeros(reader.check16Bits());
/*  70 */     reader.skipFast(q + 1);
/*     */     
/*  72 */     if (q > codebook.switchBits) {
/*  73 */       int bits = codebook.golombBits + q;
/*  74 */       if (bits > 16)
/*  75 */         Logger.error("Broken prores slice"); 
/*  76 */       return (1 << bits | reader.readFast16(bits)) - codebook.golombOffset;
/*  77 */     }  if (codebook.riceOrder > 0) {
/*  78 */       return q << codebook.riceOrder | reader.readFast16(codebook.riceOrder);
/*     */     }
/*  80 */     return q;
/*     */   }
/*     */   
/*     */   public static final int golumbToSigned(int val) {
/*  84 */     return val >> 1 ^ golumbSign(val);
/*     */   }
/*     */   
/*     */   public static final int golumbSign(int val) {
/*  88 */     return -(val & 0x1);
/*     */   }
/*     */   
/*     */   public static final void readDCCoeffs(BitReader bits, int[] qMat, int[] out, int blocksPerSlice, int blkSize) {
/*  92 */     int c = readCodeword(bits, ProresConsts.firstDCCodebook);
/*  93 */     if (c < 0) {
/*     */       return;
/*     */     }
/*     */     
/*  97 */     int prevDc = golumbToSigned(c);
/*  98 */     out[0] = 4096 + qScale(qMat, 0, prevDc);
/*     */     
/* 100 */     int code = 5, sign = 0, idx = blkSize;
/* 101 */     for (int i = 1; i < blocksPerSlice; i++, idx += blkSize) {
/* 102 */       code = readCodeword(bits, ProresConsts.dcCodebooks[Math.min(code, 6)]);
/* 103 */       if (code < 0) {
/*     */         return;
/*     */       }
/*     */ 
/*     */       
/* 108 */       if (code != 0) {
/* 109 */         sign ^= golumbSign(code);
/*     */       } else {
/* 111 */         sign = 0;
/*     */       } 
/* 113 */       prevDc += MathUtil.toSigned(code + 1 >> 1, sign);
/* 114 */       out[idx] = 4096 + qScale(qMat, 0, prevDc);
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   protected static final void readACCoeffs(BitReader bits, int[] qMat, int[] out, int blocksPerSlice, int[] scan, int max, int log2blkSize) {
/* 120 */     int run = 4;
/* 121 */     int level = 2;
/*     */     
/* 123 */     int blockMask = blocksPerSlice - 1;
/* 124 */     int log2BlocksPerSlice = MathUtil.log2(blocksPerSlice);
/* 125 */     int maxCoeffs = 64 << log2BlocksPerSlice;
/*     */     
/* 127 */     int pos = blockMask;
/* 128 */     while (bits.remaining() > 32 || bits.checkAllBits() != 0) {
/* 129 */       run = readCodeword(bits, ProresConsts.runCodebooks[Math.min(run, 15)]);
/* 130 */       if (run < 0 || run >= maxCoeffs - pos - 1) {
/*     */         return;
/*     */       }
/*     */       
/* 134 */       pos += run + 1;
/*     */       
/* 136 */       level = readCodeword(bits, ProresConsts.levCodebooks[Math.min(level, 9)]) + 1;
/* 137 */       if (level < 0 || level > 65535) {
/*     */         return;
/*     */       }
/*     */       
/* 141 */       int sign = -bits.read1Bit();
/* 142 */       int ind = pos >> log2BlocksPerSlice;
/* 143 */       if (ind >= max)
/*     */         break; 
/* 145 */       out[((pos & blockMask) << log2blkSize) + scan[ind]] = qScale(qMat, ind, MathUtil.toSigned(level, sign));
/*     */     } 
/*     */   }
/*     */   
/*     */   private static final int qScale(int[] qMat, int ind, int val) {
/* 150 */     return val * qMat[ind] >> 2;
/*     */   }
/*     */ 
/*     */   
/*     */   protected void decodeOnePlane(BitReader bits, int blocksPerSlice, int[] out, int[] qMat, int[] scan, int mbX, int mbY, int plane) {
/*     */     try {
/* 156 */       readDCCoeffs(bits, qMat, out, blocksPerSlice, 64);
/* 157 */       readACCoeffs(bits, qMat, out, blocksPerSlice, scan, 64, 6);
/* 158 */     } catch (RuntimeException e) {
/* 159 */       System.err.println("Suppressing slice error at [" + mbX + ", " + mbY + "].");
/*     */     } 
/*     */     
/* 162 */     for (int i = 0; i < blocksPerSlice; i++) {
/* 163 */       SimpleIDCT10Bit.idct10(out, i << 6);
/*     */     }
/*     */   }
/*     */   
/*     */   public Picture decodeFrame(ByteBuffer data, byte[][] target) {
/* 168 */     return decodeFrameHiBD(data, target, (byte[][])null);
/*     */   }
/*     */   
/*     */   public Picture decodeFrameHiBD(ByteBuffer data, byte[][] target, byte[][] lowBits) {
/* 172 */     ProresConsts.FrameHeader fh = readFrameHeader(data);
/*     */     
/* 174 */     int codedWidth = fh.width + 15 & 0xFFFFFFF0;
/* 175 */     int codedHeight = fh.height + 15 & 0xFFFFFFF0;
/*     */     
/* 177 */     int lumaSize = codedWidth * codedHeight;
/* 178 */     int chromaSize = lumaSize >> 3 - fh.chromaType;
/*     */     
/* 180 */     if (target == null || (target[0]).length < lumaSize || (target[1]).length < chromaSize || (target[2]).length < chromaSize)
/*     */     {
/* 182 */       throw new RuntimeException("Provided output picture won't fit into provided buffer");
/*     */     }
/*     */     
/* 185 */     if (fh.frameType == 0) {
/* 186 */       decodePicture(data, target, lowBits, codedWidth, codedHeight, codedWidth >> 4, fh.qMatLuma, fh.qMatChroma, fh.scan, 0, fh.chromaType);
/*     */     } else {
/*     */       
/* 189 */       decodePicture(data, target, lowBits, codedWidth, codedHeight >> 1, codedWidth >> 4, fh.qMatLuma, fh.qMatChroma, fh.scan, fh.topFieldFirst ? 1 : 2, fh.chromaType);
/*     */ 
/*     */       
/* 192 */       decodePicture(data, target, lowBits, codedWidth, codedHeight >> 1, codedWidth >> 4, fh.qMatLuma, fh.qMatChroma, fh.scan, fh.topFieldFirst ? 2 : 1, fh.chromaType);
/*     */     } 
/*     */ 
/*     */     
/* 196 */     ColorSpace color = (fh.chromaType == 2) ? ColorSpace.YUV422 : ColorSpace.YUV444;
/*     */     
/* 198 */     return new Picture(codedWidth, codedHeight, target, lowBits, color, (lowBits == null) ? 0 : 2, new Rect(0, 0, fh.width & color
/* 199 */           .getWidthMask(), fh.height & color.getHeightMask()));
/*     */   }
/*     */   
/*     */   public Picture[] decodeFields(ByteBuffer data, byte[][][] target) {
/* 203 */     return decodeFieldsHiBD(data, target, (byte[][][])null);
/*     */   }
/*     */   
/*     */   public Picture[] decodeFieldsHiBD(ByteBuffer data, byte[][][] target, byte[][][] lowBits) {
/* 207 */     ProresConsts.FrameHeader fh = readFrameHeader(data);
/*     */     
/* 209 */     int codedWidth = fh.width + 15 & 0xFFFFFFF0;
/* 210 */     int codedHeight = fh.height + 15 & 0xFFFFFFF0;
/*     */     
/* 212 */     int lumaSize = codedWidth * codedHeight;
/* 213 */     int chromaSize = lumaSize >> 1;
/*     */     
/* 215 */     if (fh.frameType == 0) {
/* 216 */       if (target == null || (target[0][0]).length < lumaSize || (target[0][1]).length < chromaSize || (target[0][2]).length < chromaSize)
/*     */       {
/* 218 */         throw new RuntimeException("Provided output picture won't fit into provided buffer");
/*     */       }
/*     */       
/* 221 */       decodePicture(data, target[0], lowBits[0], fh.width, fh.height, codedWidth >> 4, fh.qMatLuma, fh.qMatChroma, fh.scan, 0, fh.chromaType);
/*     */       
/* 223 */       return new Picture[] {
/* 224 */           Picture.createPicture(codedWidth, codedHeight, target[0], ColorSpace.YUV422) };
/*     */     } 
/* 226 */     lumaSize >>= 1;
/* 227 */     chromaSize >>= 1;
/* 228 */     if (target == null || (target[0][0]).length < lumaSize || (target[0][1]).length < chromaSize || (target[0][2]).length < chromaSize || (target[1][0]).length < lumaSize || (target[1][1]).length < chromaSize || (target[1][2]).length < chromaSize)
/*     */     {
/*     */       
/* 231 */       throw new RuntimeException("Provided output picture won't fit into provided buffer");
/*     */     }
/*     */     
/* 234 */     decodePicture(data, target[fh.topFieldFirst ? 0 : 1], lowBits[fh.topFieldFirst ? 0 : 1], fh.width, fh.height >> 1, codedWidth >> 4, fh.qMatLuma, fh.qMatChroma, fh.scan, 0, fh.chromaType);
/*     */ 
/*     */     
/* 237 */     decodePicture(data, target[fh.topFieldFirst ? 1 : 0], lowBits[fh.topFieldFirst ? 0 : 1], fh.width, fh.height >> 1, codedWidth >> 4, fh.qMatLuma, fh.qMatChroma, fh.scan, 0, fh.chromaType);
/*     */ 
/*     */     
/* 240 */     return new Picture[] {
/* 241 */         Picture.createPicture(codedWidth, codedHeight >> 1, target[0], ColorSpace.YUV422), 
/* 242 */         Picture.createPicture(codedWidth, codedHeight >> 1, target[1], ColorSpace.YUV422)
/*     */       };
/*     */   }
/*     */   
/*     */   public static ProresConsts.FrameHeader readFrameHeader(ByteBuffer inp) {
/* 247 */     int scan[], frameSize = inp.getInt();
/* 248 */     String sig = readSig(inp);
/* 249 */     if (!"icpf".equals(sig)) {
/* 250 */       throw new RuntimeException("Not a prores frame");
/*     */     }
/* 252 */     short hdrSize = inp.getShort();
/* 253 */     short version = inp.getShort();
/*     */     
/* 255 */     int res1 = inp.getInt();
/*     */     
/* 257 */     short width = inp.getShort();
/* 258 */     short height = inp.getShort();
/*     */     
/* 260 */     int flags1 = inp.get();
/*     */     
/* 262 */     int frameType = flags1 >> 2 & 0x3;
/* 263 */     int chromaType = flags1 >> 6 & 0x3;
/*     */ 
/*     */     
/* 266 */     boolean topFieldFirst = false;
/*     */     
/* 268 */     if (frameType == 0) {
/* 269 */       scan = ProresConsts.progressive_scan;
/*     */     } else {
/* 271 */       scan = ProresConsts.interlaced_scan;
/* 272 */       if (frameType == 1) {
/* 273 */         topFieldFirst = true;
/*     */       }
/*     */     } 
/* 276 */     byte res2 = inp.get();
/* 277 */     byte prim = inp.get();
/* 278 */     byte transFunc = inp.get();
/* 279 */     byte matrix = inp.get();
/* 280 */     byte pixFmt = inp.get();
/* 281 */     byte res3 = inp.get();
/*     */     
/* 283 */     int flags2 = inp.get() & 0xFF;
/*     */     
/* 285 */     int[] qMatLuma = new int[64];
/* 286 */     int[] qMatChroma = new int[64];
/*     */     
/* 288 */     if (hasQMatLuma(flags2)) {
/* 289 */       readQMat(inp, qMatLuma, scan);
/*     */     } else {
/* 291 */       Arrays.fill(qMatLuma, 4);
/*     */     } 
/*     */     
/* 294 */     if (hasQMatChroma(flags2)) {
/* 295 */       readQMat(inp, qMatChroma, scan);
/*     */     } else {
/* 297 */       Arrays.fill(qMatChroma, 4);
/*     */     } 
/*     */     
/* 300 */     inp.position(inp
/* 301 */         .position() + hdrSize - 20 + (hasQMatLuma(flags2) ? 64 : 0) + (hasQMatChroma(flags2) ? 64 : 0));
/*     */     
/* 303 */     return new ProresConsts.FrameHeader(frameSize - hdrSize - 8, width, height, frameType, topFieldFirst, scan, qMatLuma, qMatChroma, chromaType);
/*     */   }
/*     */ 
/*     */   
/*     */   static final String readSig(ByteBuffer inp) {
/* 308 */     byte[] sig = new byte[4];
/* 309 */     inp.get(sig);
/* 310 */     return Platform.stringFromBytes(sig);
/*     */   }
/*     */ 
/*     */   
/*     */   protected void decodePicture(ByteBuffer data, byte[][] result, byte[][] lowBits, int width, int height, int mbWidth, int[] qMatLuma, int[] qMatChroma, int[] scan, int pictureType, int chromaType) {
/* 315 */     ProresConsts.PictureHeader ph = readPictureHeader(data);
/*     */     
/* 317 */     int mbX = 0, mbY = 0;
/* 318 */     int sliceMbCount = 1 << ph.log2SliceMbWidth;
/* 319 */     for (int i = 0; i < ph.sliceSizes.length; i++) {
/*     */       
/* 321 */       while (mbWidth - mbX < sliceMbCount) {
/* 322 */         sliceMbCount >>= 1;
/*     */       }
/* 324 */       decodeSlice(NIOUtils.read(data, ph.sliceSizes[i]), qMatLuma, qMatChroma, scan, sliceMbCount, mbX, mbY, ph.sliceSizes[i], result, lowBits, width, pictureType, chromaType);
/*     */ 
/*     */       
/* 327 */       mbX += sliceMbCount;
/* 328 */       if (mbX == mbWidth) {
/* 329 */         sliceMbCount = 1 << ph.log2SliceMbWidth;
/* 330 */         mbX = 0;
/* 331 */         mbY++;
/*     */       } 
/*     */     } 
/*     */   }
/*     */   
/*     */   public static ProresConsts.PictureHeader readPictureHeader(ByteBuffer inp) {
/* 337 */     int hdrSize = (inp.get() & 0xFF) >> 3;
/* 338 */     inp.getInt();
/* 339 */     int sliceCount = inp.getShort();
/*     */     
/* 341 */     int a = inp.get() & 0xFF;
/* 342 */     int log2SliceMbWidth = a >> 4;
/*     */     
/* 344 */     short[] sliceSizes = new short[sliceCount];
/* 345 */     for (int i = 0; i < sliceCount; i++) {
/* 346 */       sliceSizes[i] = inp.getShort();
/*     */     }
/* 348 */     return new ProresConsts.PictureHeader(log2SliceMbWidth, sliceSizes);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private void decodeSlice(ByteBuffer data, int[] qMatLuma, int[] qMatChroma, int[] scan, int sliceMbCount, int mbX, int mbY, short sliceSize, byte[][] result, byte[][] lowBits, int lumaStride, int pictureType, int chromaType) {
/* 354 */     int hdrSize = (data.get() & 0xFF) >> 3;
/* 355 */     int qScale = clip(data.get() & 0xFF, 1, 224);
/* 356 */     qScale = (qScale > 128) ? (qScale - 96 << 2) : qScale;
/* 357 */     int yDataSize = data.getShort();
/* 358 */     int uDataSize = data.getShort();
/* 359 */     int vDataSize = (hdrSize > 7) ? data.getShort() : (sliceSize - uDataSize - yDataSize - hdrSize);
/*     */     
/* 361 */     int[] y = new int[sliceMbCount << 8];
/* 362 */     decodeOnePlane(bitstream(data, yDataSize), sliceMbCount << 2, y, scaleMat(qMatLuma, qScale), scan, mbX, mbY, 0);
/* 363 */     int chromaBlkCount = sliceMbCount << chromaType >> 1;
/* 364 */     int[] u = new int[chromaBlkCount << 6];
/* 365 */     decodeOnePlane(bitstream(data, uDataSize), chromaBlkCount, u, scaleMat(qMatChroma, qScale), scan, mbX, mbY, 1);
/* 366 */     int[] v = new int[chromaBlkCount << 6];
/* 367 */     decodeOnePlane(bitstream(data, vDataSize), chromaBlkCount, v, scaleMat(qMatChroma, qScale), scan, mbX, mbY, 2);
/*     */     
/* 369 */     putSlice(result, lowBits, lumaStride, mbX, mbY, y, u, v, (pictureType == 0) ? 0 : 1, (pictureType == 2) ? 1 : 0, chromaType, sliceMbCount);
/*     */   }
/*     */ 
/*     */   
/*     */   public static final int[] scaleMat(int[] qMatLuma, int qScale) {
/* 374 */     int[] res = new int[qMatLuma.length];
/* 375 */     for (int i = 0; i < qMatLuma.length; i++) {
/* 376 */       res[i] = qMatLuma[i] * qScale;
/*     */     }
/* 378 */     return res;
/*     */   }
/*     */   
/*     */   static final BitReader bitstream(ByteBuffer data, int dataSize) {
/* 382 */     return BitReader.createBitReader(NIOUtils.read(data, dataSize));
/*     */   }
/*     */   
/*     */   static final int clip(int val, int min, int max) {
/* 386 */     return (val < min) ? min : ((val > max) ? max : val);
/*     */   }
/*     */ 
/*     */   
/*     */   protected void putSlice(byte[][] result, byte[][] lowBits, int lumaStride, int mbX, int mbY, int[] y, int[] u, int[] v, int dist, int shift, int chromaType, int sliceMbCount) {
/* 391 */     int chromaStride = lumaStride >> 1;
/*     */     
/* 393 */     putLuma(result[0], (lowBits != null) ? lowBits[0] : null, shift * lumaStride, lumaStride << dist, mbX, mbY, y, sliceMbCount, dist, shift);
/*     */     
/* 395 */     if (chromaType == 2) {
/* 396 */       putChroma(result[1], (lowBits != null) ? lowBits[1] : null, shift * chromaStride, chromaStride << dist, mbX, mbY, u, sliceMbCount, dist, shift);
/*     */       
/* 398 */       putChroma(result[2], (lowBits != null) ? lowBits[2] : null, shift * chromaStride, chromaStride << dist, mbX, mbY, v, sliceMbCount, dist, shift);
/*     */     } else {
/*     */       
/* 401 */       putLuma(result[1], (lowBits != null) ? lowBits[1] : null, shift * lumaStride, lumaStride << dist, mbX, mbY, u, sliceMbCount, dist, shift);
/*     */       
/* 403 */       putLuma(result[2], (lowBits != null) ? lowBits[2] : null, shift * lumaStride, lumaStride << dist, mbX, mbY, v, sliceMbCount, dist, shift);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private void putLuma(byte[] y, byte[] lowBits, int off, int stride, int mbX, int mbY, int[] luma, int mbPerSlice, int dist, int shift) {
/* 410 */     off += (mbX << 4) + (mbY << 4) * stride;
/* 411 */     for (int k = 0; k < mbPerSlice; k++) {
/* 412 */       putBlock(y, lowBits, off, stride, luma, k << 8, dist, shift);
/* 413 */       putBlock(y, lowBits, off + 8, stride, luma, (k << 8) + 64, dist, shift);
/* 414 */       putBlock(y, lowBits, off + 8 * stride, stride, luma, (k << 8) + 128, dist, shift);
/* 415 */       putBlock(y, lowBits, off + 8 * stride + 8, stride, luma, (k << 8) + 192, dist, shift);
/* 416 */       off += 16;
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   private void putChroma(byte[] y, byte[] lowBits, int off, int stride, int mbX, int mbY, int[] chroma, int mbPerSlice, int dist, int shift) {
/* 422 */     off += (mbX << 3) + (mbY << 4) * stride;
/* 423 */     for (int k = 0; k < mbPerSlice; k++) {
/* 424 */       putBlock(y, lowBits, off, stride, chroma, k << 7, dist, shift);
/* 425 */       putBlock(y, lowBits, off + 8 * stride, stride, chroma, (k << 7) + 64, dist, shift);
/* 426 */       off += 8;
/*     */     } 
/*     */   } private void putBlock(byte[] square, byte[] lowBits, int sqOff, int sqStride, int[] flat, int flOff, int dist, int shift) {
/*     */     int i;
/*     */     int dstOff;
/*     */     int srcOff;
/* 432 */     for (i = 0, dstOff = sqOff, srcOff = flOff; i < 8; i++, dstOff += sqStride, srcOff += 8) {
/* 433 */       for (int j = 0; j < 8; j++) {
/* 434 */         int round = MathUtil.clip(flat[j + srcOff] + 2 >> 2, 1, 255);
/* 435 */         square[j + dstOff] = (byte)(round - 128);
/*     */       } 
/*     */     } 
/*     */     
/* 439 */     if (lowBits != null) {
/* 440 */       for (i = 0, dstOff = sqOff, srcOff = flOff; i < 8; i++, dstOff += sqStride, srcOff += 8) {
/* 441 */         for (int j = 0; j < 8; j++) {
/* 442 */           int val = MathUtil.clip(flat[j + srcOff], 4, 1019);
/* 443 */           int round = MathUtil.clip(flat[j + srcOff] + 2 >> 2, 1, 255);
/* 444 */           lowBits[j + dstOff] = (byte)(val - (round << 2));
/*     */         } 
/*     */       } 
/*     */     }
/*     */   }
/*     */   
/*     */   static final boolean hasQMatChroma(int flags2) {
/* 451 */     return ((flags2 & 0x1) != 0);
/*     */   }
/*     */   
/*     */   static final void readQMat(ByteBuffer inp, int[] qMatLuma, int[] scan) {
/* 455 */     byte[] b = new byte[64];
/* 456 */     inp.get(b);
/* 457 */     for (int i = 0; i < 64; i++) {
/* 458 */       qMatLuma[i] = b[scan[i]] & 0xFF;
/*     */     }
/*     */   }
/*     */   
/*     */   static final boolean hasQMatLuma(int flags2) {
/* 463 */     return ((flags2 & 0x2) != 0);
/*     */   }
/*     */   
/*     */   public boolean isProgressive(ByteBuffer data) {
/* 467 */     return (((data.get(20) & 0xFF) >> 2 & 0x3) == 0);
/*     */   }
/*     */   
/*     */   @UsedViaReflection
/*     */   public static int probe(ByteBuffer data) {
/* 472 */     if (data.get(4) == 105 && data.get(5) == 99 && data.get(6) == 112 && data.get(7) == 102)
/* 473 */       return 100; 
/* 474 */     return 0;
/*     */   }
/*     */ 
/*     */   
/*     */   public VideoCodecMeta getCodecMeta(ByteBuffer data) {
/* 479 */     ProresConsts.FrameHeader fh = readFrameHeader(data);
/* 480 */     return VideoCodecMeta.createSimpleVideoCodecMeta(new Size(fh.width, fh.height), (fh.chromaType == 2) ? ColorSpace.YUV422 : ColorSpace.YUV444);
/*     */   }
/*     */ }


/* Location:              C:\Users\rapha\Downloads\aurora.jar!\META-INF\jars\jcodec-0.2.5.jar!\org\jcodec\codecs\prores\ProresDecoder.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */