/*     */ package org.jcodec.codecs.prores;
/*     */ 
/*     */ import java.nio.ByteBuffer;
/*     */ import org.jcodec.common.io.BitReader;
/*     */ import org.jcodec.common.io.BitWriter;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ProresToProxy
/*     */ {
/*     */   private int[] qMatLumaTo;
/*     */   private int[] qMatChromaTo;
/*     */   private int frameSize;
/*     */   private static final int START_QP = 6;
/*     */   private int bitsPer1024;
/*     */   private int bitsPer1024High;
/*     */   private int bitsPer1024Low;
/*     */   private int nCoeffs;
/*     */   
/*     */   public ProresToProxy(int width, int height, int frameSize) {
/*  41 */     this.qMatLumaTo = ProresConsts.QMAT_LUMA_APCO;
/*  42 */     this.qMatChromaTo = ProresConsts.QMAT_CHROMA_APCO;
/*  43 */     this.frameSize = frameSize;
/*     */     
/*  45 */     int headerBytes = (height >> 4) * ((width >> 4) + 7 >> 3) * 8 + 148;
/*  46 */     int dataBits = frameSize - headerBytes << 3;
/*  47 */     this.bitsPer1024 = (dataBits << 10) / width * height;
/*     */     
/*  49 */     this.bitsPer1024High = this.bitsPer1024 - this.bitsPer1024 / 10;
/*  50 */     this.bitsPer1024Low = this.bitsPer1024 - this.bitsPer1024 / 20;
/*     */     
/*  52 */     this.nCoeffs = Math.max(Math.min(33000 / (width * height >> 8), 64), 4);
/*     */   }
/*     */   
/*     */   public int getFrameSize() {
/*  56 */     return this.frameSize;
/*     */   }
/*     */ 
/*     */   
/*     */   void requant(BitReader ib, BitWriter ob, int blocksPerSlice, int[] qMatFrom, int[] qMatTo, int[] scan, int mbX, int mbY, int plane) {
/*  61 */     int[] out = new int[blocksPerSlice << 6];
/*     */     try {
/*  63 */       ProresDecoder.readDCCoeffs(ib, qMatFrom, out, blocksPerSlice, 64);
/*  64 */       ProresDecoder.readACCoeffs(ib, qMatFrom, out, blocksPerSlice, scan, this.nCoeffs, 6);
/*  65 */     } catch (RuntimeException runtimeException) {}
/*     */     
/*  67 */     for (int i = 0; i < out.length; i++)
/*  68 */       out[i] = out[i] << 2; 
/*  69 */     ProresEncoder.writeDCCoeffs(ob, qMatTo, out, blocksPerSlice);
/*  70 */     ProresEncoder.writeACCoeffs(ob, qMatTo, out, blocksPerSlice, scan, this.nCoeffs);
/*  71 */     ob.flush();
/*     */   }
/*     */   
/*     */   public void transcode(ByteBuffer inBuf, ByteBuffer outBuf) {
/*  75 */     ByteBuffer fork = outBuf.duplicate();
/*     */     
/*  77 */     ProresConsts.FrameHeader fh = ProresDecoder.readFrameHeader(inBuf);
/*  78 */     ProresEncoder.writeFrameHeader(outBuf, fh);
/*     */     
/*  80 */     int beforePicture = outBuf.position();
/*  81 */     if (fh.frameType == 0) {
/*  82 */       transcodePicture(inBuf, outBuf, fh);
/*     */     } else {
/*  84 */       transcodePicture(inBuf, outBuf, fh);
/*  85 */       transcodePicture(inBuf, outBuf, fh);
/*     */     } 
/*  87 */     fh.qMatLuma = this.qMatLumaTo;
/*  88 */     fh.qMatChroma = this.qMatChromaTo;
/*  89 */     fh.payloadSize = outBuf.position() - beforePicture;
/*  90 */     ProresEncoder.writeFrameHeader(fork, fh);
/*     */   }
/*     */ 
/*     */   
/*     */   private void transcodePicture(ByteBuffer inBuf, ByteBuffer outBuf, ProresConsts.FrameHeader fh) {
/*  95 */     ProresConsts.PictureHeader ph = ProresDecoder.readPictureHeader(inBuf);
/*  96 */     ProresEncoder.writePictureHeader(ph.log2SliceMbWidth, ph.sliceSizes.length, outBuf);
/*  97 */     ByteBuffer sliceSizes = outBuf.duplicate();
/*  98 */     outBuf.position(outBuf.position() + (ph.sliceSizes.length << 1));
/*     */     
/* 100 */     int mbX = 0, mbY = 0;
/* 101 */     int mbWidth = fh.width + 15 >> 4;
/* 102 */     int sliceMbCount = 1 << ph.log2SliceMbWidth;
/* 103 */     int balance = 0, qp = 6;
/* 104 */     for (int i = 0; i < ph.sliceSizes.length; i++) {
/*     */       
/* 106 */       while (mbWidth - mbX < sliceMbCount) {
/* 107 */         sliceMbCount >>= 1;
/*     */       }
/* 109 */       int savedPoint = outBuf.position();
/*     */       
/* 111 */       transcodeSlice(inBuf, outBuf, fh.qMatLuma, fh.qMatChroma, fh.scan, sliceMbCount, mbX, mbY, ph.sliceSizes[i], qp);
/*     */       
/* 113 */       short encodedSize = (short)(outBuf.position() - savedPoint);
/* 114 */       sliceSizes.putShort(encodedSize);
/*     */       
/* 116 */       int max = (sliceMbCount * this.bitsPer1024High >> 5) + 6;
/* 117 */       int low = (sliceMbCount * this.bitsPer1024Low >> 5) + 6;
/*     */       
/* 119 */       if (encodedSize > max && qp < 128) {
/* 120 */         qp++;
/* 121 */         if (encodedSize > max + balance && qp < 128) {
/* 122 */           qp++;
/*     */         }
/* 124 */       } else if (encodedSize < low && qp > 2 && balance > 0) {
/* 125 */         qp--;
/*     */       } 
/* 127 */       balance += max - encodedSize;
/*     */       
/* 129 */       mbX += sliceMbCount;
/* 130 */       if (mbX == mbWidth) {
/* 131 */         sliceMbCount = 1 << ph.log2SliceMbWidth;
/* 132 */         mbX = 0;
/* 133 */         mbY++;
/*     */       } 
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private void transcodeSlice(ByteBuffer inBuf, ByteBuffer outBuf, int[] qMatLuma, int[] qMatChroma, int[] scan, int sliceMbCount, int mbX, int mbY, short sliceSize, int qp) {
/* 141 */     int hdrSize = (inBuf.get() & 0xFF) >> 3;
/* 142 */     int qScaleOrig = ProresDecoder.clip(inBuf.get() & 0xFF, 1, 224);
/* 143 */     int qScale = (qScaleOrig > 128) ? (qScaleOrig - 96 << 2) : qScaleOrig;
/* 144 */     int yDataSize = inBuf.getShort();
/* 145 */     int uDataSize = inBuf.getShort();
/* 146 */     int vDataSize = sliceSize - uDataSize - yDataSize - hdrSize;
/*     */     
/* 148 */     outBuf.put((byte)48);
/* 149 */     outBuf.put((byte)qp);
/* 150 */     ByteBuffer beforeSizes = outBuf.duplicate();
/* 151 */     outBuf.putInt(0);
/*     */     
/* 153 */     int beforeY = outBuf.position();
/*     */     
/* 155 */     requant(ProresDecoder.bitstream(inBuf, yDataSize), new BitWriter(outBuf), sliceMbCount << 2, ProresDecoder.scaleMat(qMatLuma, qScale), 
/* 156 */         ProresDecoder.scaleMat(this.qMatLumaTo, qp), scan, mbX, mbY, 0);
/* 157 */     int beforeCb = outBuf.position();
/* 158 */     requant(ProresDecoder.bitstream(inBuf, uDataSize), new BitWriter(outBuf), sliceMbCount << 1, ProresDecoder.scaleMat(qMatChroma, qScale), 
/* 159 */         ProresDecoder.scaleMat(this.qMatChromaTo, qp), scan, mbX, mbY, 1);
/* 160 */     int beforeCr = outBuf.position();
/* 161 */     requant(ProresDecoder.bitstream(inBuf, vDataSize), new BitWriter(outBuf), sliceMbCount << 1, ProresDecoder.scaleMat(qMatChroma, qScale), 
/* 162 */         ProresDecoder.scaleMat(this.qMatChromaTo, qp), scan, mbX, mbY, 2);
/*     */     
/* 164 */     beforeSizes.putShort((short)(beforeCb - beforeY));
/* 165 */     beforeSizes.putShort((short)(beforeCr - beforeCb));
/*     */   }
/*     */ }


/* Location:              C:\Users\rapha\Downloads\aurora.jar!\META-INF\jars\jcodec-0.2.5.jar!\org\jcodec\codecs\prores\ProresToProxy.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */