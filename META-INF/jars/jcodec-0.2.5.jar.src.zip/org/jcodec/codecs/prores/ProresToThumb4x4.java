/*     */ package org.jcodec.codecs.prores;
/*     */ 
/*     */ import java.nio.ByteBuffer;
/*     */ import org.jcodec.common.dct.IDCT4x4;
/*     */ import org.jcodec.common.io.BitReader;
/*     */ import org.jcodec.common.model.ColorSpace;
/*     */ import org.jcodec.common.model.Picture;
/*     */ import org.jcodec.common.model.Rect;
/*     */ import org.jcodec.common.tools.MathUtil;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ProresToThumb4x4
/*     */   extends ProresDecoder
/*     */ {
/*     */   protected void decodeOnePlane(BitReader bits, int blocksPerSlice, int[] out, int[] qMat, int[] scan, int mbX, int mbY, int plane) {
/*  31 */     readDCCoeffs(bits, qMat, out, blocksPerSlice, 16);
/*  32 */     readACCoeffs(bits, qMat, out, blocksPerSlice, scan, 16, 4);
/*     */     
/*  34 */     for (int i = 0; i < blocksPerSlice; i++) {
/*  35 */       IDCT4x4.idct(out, i << 4);
/*     */     }
/*     */   }
/*     */   
/*  39 */   public static int[] progressive_scan_4x4 = new int[] { 0, 1, 4, 5, 2, 3, 6, 7, 8, 9, 12, 13, 11, 12, 14, 15 };
/*     */   
/*  41 */   public static int[] interlaced_scan_4x4 = new int[] { 0, 4, 1, 5, 8, 12, 9, 13, 2, 6, 3, 7, 10, 14, 11, 15 };
/*     */ 
/*     */   
/*     */   public Picture decodeFrameHiBD(ByteBuffer data, byte[][] target, byte[][] lowBits) {
/*  45 */     ProresConsts.FrameHeader fh = readFrameHeader(data);
/*     */     
/*  47 */     int codedWidth = (fh.width + 15 & 0xFFFFFFF0) >> 1;
/*  48 */     int codedHeight = (fh.height + 15 & 0xFFFFFFF0) >> 1;
/*     */     
/*  50 */     int lumaSize = codedWidth * codedHeight;
/*  51 */     int chromaSize = lumaSize >> 1;
/*     */     
/*  53 */     if (target == null || (target[0]).length < lumaSize || (target[1]).length < chromaSize || (target[2]).length < chromaSize)
/*     */     {
/*  55 */       throw new RuntimeException("Provided output picture won't fit into provided buffer");
/*     */     }
/*     */     
/*  58 */     if (fh.frameType == 0) {
/*  59 */       decodePicture(data, target, lowBits, codedWidth, codedHeight, codedWidth >> 3, fh.qMatLuma, fh.qMatChroma, progressive_scan_4x4, 0, fh.chromaType);
/*     */     } else {
/*     */       
/*  62 */       decodePicture(data, target, lowBits, codedWidth, codedHeight >> 1, codedWidth >> 3, fh.qMatLuma, fh.qMatChroma, interlaced_scan_4x4, fh.topFieldFirst ? 1 : 2, fh.chromaType);
/*     */ 
/*     */       
/*  65 */       decodePicture(data, target, lowBits, codedWidth, codedHeight >> 1, codedWidth >> 3, fh.qMatLuma, fh.qMatChroma, interlaced_scan_4x4, fh.topFieldFirst ? 2 : 1, fh.chromaType);
/*     */     } 
/*     */ 
/*     */     
/*  69 */     ColorSpace color = (fh.chromaType == 2) ? ColorSpace.YUV422 : ColorSpace.YUV444;
/*  70 */     return new Picture(codedWidth, codedHeight, target, lowBits, color, (lowBits == null) ? 0 : 2, new Rect(0, 0, fh.width >> 1 & color
/*  71 */           .getWidthMask(), fh.height >> 1 & color.getHeightMask()));
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   protected void putSlice(byte[][] result, byte[][] lowBits, int lumaStride, int mbX, int mbY, int[] y, int[] u, int[] v, int dist, int shift, int chromaType, int sliceMbCount) {
/*  77 */     int chromaStride = lumaStride >> 1;
/*     */     
/*  79 */     _putLuma(result[0], (lowBits == null) ? null : lowBits[0], shift * lumaStride, lumaStride << dist, mbX, mbY, y, sliceMbCount, dist, shift);
/*     */     
/*  81 */     if (chromaType == 2) {
/*  82 */       _putChroma(result[1], (lowBits == null) ? null : lowBits[1], shift * chromaStride, chromaStride << dist, mbX, mbY, u, sliceMbCount, dist, shift);
/*     */       
/*  84 */       _putChroma(result[2], (lowBits == null) ? null : lowBits[2], shift * chromaStride, chromaStride << dist, mbX, mbY, v, sliceMbCount, dist, shift);
/*     */     } else {
/*     */       
/*  87 */       _putLuma(result[1], (lowBits == null) ? null : lowBits[1], shift * lumaStride, lumaStride << dist, mbX, mbY, u, sliceMbCount, dist, shift);
/*     */       
/*  89 */       _putLuma(result[2], (lowBits == null) ? null : lowBits[2], shift * lumaStride, lumaStride << dist, mbX, mbY, v, sliceMbCount, dist, shift);
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*  94 */   private static final int[] srcIncLuma = new int[] { 4, 4, 4, 20, 4, 4, 4, 20 };
/*     */ 
/*     */   
/*     */   private void _putLuma(byte[] y, byte[] lowBits, int fieldOffset, int stride, int mbX, int mbY, int[] luma, int mbPerSlice, int dist, int shift) {
/*  98 */     int mbTopLeftOff = fieldOffset + (mbX << 3) + (mbY << 3) * stride; int mb, sOff;
/*  99 */     for (mb = 0, sOff = 0; mb < mbPerSlice; mb++, mbTopLeftOff += 8) {
/* 100 */       int lineOff = mbTopLeftOff;
/* 101 */       for (int line = 0; line < 8; line++) {
/* 102 */         int col; for (col = 0; col < 4; col++) {
/* 103 */           int round = MathUtil.clip(luma[sOff + col] + 2 >> 2, 1, 255);
/* 104 */           y[lineOff + col] = (byte)(round - 128);
/*     */         } 
/* 106 */         for (col = 4; col < 8; col++) {
/* 107 */           int round = MathUtil.clip(luma[sOff + col + 12] + 2 >> 2, 1, 255);
/* 108 */           y[lineOff + col] = (byte)(round - 128);
/*     */         } 
/*     */         
/* 111 */         sOff += srcIncLuma[line];
/* 112 */         lineOff += stride;
/*     */       } 
/*     */     } 
/*     */     
/* 116 */     if (lowBits != null) {
/* 117 */       mbTopLeftOff = fieldOffset + (mbX << 3) + (mbY << 3) * stride;
/* 118 */       for (mb = 0, sOff = 0; mb < mbPerSlice; mb++, mbTopLeftOff += 8) {
/* 119 */         int lineOff = mbTopLeftOff;
/* 120 */         for (int line = 0; line < 4; line++) {
/* 121 */           int col; for (col = 0; col < 4; col++) {
/* 122 */             int val = MathUtil.clip(luma[sOff + col], 4, 1019);
/* 123 */             int round = MathUtil.clip(luma[sOff + col] + 2 >> 2, 1, 255);
/* 124 */             lowBits[lineOff + col] = (byte)(val - (round << 2));
/*     */           } 
/* 126 */           for (col = 4; col < 8; col++) {
/* 127 */             int val = MathUtil.clip(luma[sOff + col + 12], 4, 1019);
/* 128 */             int round = MathUtil.clip(luma[sOff + col] + 2 >> 2, 1, 255);
/* 129 */             lowBits[lineOff + col] = (byte)(val - (round << 2));
/*     */           } 
/*     */           
/* 132 */           sOff += srcIncLuma[line];
/* 133 */           lineOff += stride;
/*     */         } 
/*     */       } 
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   private void _putChroma(byte[] y, byte[] lowBits, int fieldOff, int stride, int mbX, int mbY, int[] chroma, int mbPerSlice, int dist, int shift) {
/* 141 */     int mbTopLeftOff = fieldOff + (mbX << 2) + (mbY << 3) * stride; int k, sOff;
/* 142 */     for (k = 0, sOff = 0; k < mbPerSlice; k++, mbTopLeftOff += 4) {
/* 143 */       int lineOff = mbTopLeftOff;
/* 144 */       for (int line = 0; line < 8; line++) {
/* 145 */         for (int col = 0; col < 4; col++) {
/* 146 */           int round = MathUtil.clip(chroma[sOff + col] + 2 >> 2, 1, 255);
/* 147 */           y[lineOff + col] = (byte)(round - 128);
/*     */         } 
/*     */         
/* 150 */         sOff += 4;
/* 151 */         lineOff += stride;
/*     */       } 
/*     */     } 
/*     */     
/* 155 */     if (lowBits != null) {
/* 156 */       mbTopLeftOff = fieldOff + (mbX << 2) + (mbY << 3) * stride;
/* 157 */       for (k = 0, sOff = 0; k < mbPerSlice; k++, mbTopLeftOff += 4) {
/* 158 */         int lineOff = mbTopLeftOff;
/* 159 */         for (int line = 0; line < 8; line++) {
/* 160 */           for (int col = 0; col < 4; col++) {
/* 161 */             int val = MathUtil.clip(chroma[sOff + col], 4, 1019);
/* 162 */             int round = MathUtil.clip(chroma[sOff + col] + 2 >> 2, 1, 255);
/* 163 */             lowBits[lineOff + col] = (byte)(val - (round << 2));
/*     */           } 
/*     */           
/* 166 */           sOff += 4;
/* 167 */           lineOff += stride;
/*     */         } 
/*     */       } 
/*     */     } 
/*     */   }
/*     */ }


/* Location:              C:\Users\rapha\Downloads\aurora.jar!\META-INF\jars\jcodec-0.2.5.jar!\org\jcodec\codecs\prores\ProresToThumb4x4.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */