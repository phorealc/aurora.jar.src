/*    */ package org.jcodec.codecs.prores;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class Codebook
/*    */ {
/*    */   int riceOrder;
/*    */   int expOrder;
/*    */   int switchBits;
/*    */   int golombOffset;
/*    */   int golombBits;
/*    */   int riceMask;
/*    */   
/*    */   public Codebook(int riceOrder, int expOrder, int switchBits) {
/* 21 */     this.riceOrder = riceOrder;
/* 22 */     this.expOrder = expOrder;
/* 23 */     this.switchBits = switchBits;
/*    */     
/* 25 */     this.golombOffset = (1 << expOrder) - (switchBits + 1 << riceOrder);
/* 26 */     this.golombBits = expOrder - switchBits - 1;
/* 27 */     this.riceMask = (1 << riceOrder) - 1;
/*    */   }
/*    */ }


/* Location:              C:\Users\rapha\Downloads\aurora.jar!\META-INF\jars\jcodec-0.2.5.jar!\org\jcodec\codecs\prores\Codebook.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */