/*     */ package org.jcodec.codecs.prores;
/*     */ 
/*     */ import java.nio.ByteBuffer;
/*     */ import org.jcodec.common.dct.IDCT2x2;
/*     */ import org.jcodec.common.io.BitReader;
/*     */ import org.jcodec.common.model.ColorSpace;
/*     */ import org.jcodec.common.model.Picture;
/*     */ import org.jcodec.common.model.Rect;
/*     */ import org.jcodec.common.tools.MathUtil;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ProresToThumb2x2
/*     */   extends ProresDecoder
/*     */ {
/*     */   protected void decodeOnePlane(BitReader bits, int blocksPerSlice, int[] out, int[] qMat, int[] scan, int mbX, int mbY, int plane) {
/*  32 */     readDCCoeffs(bits, qMat, out, blocksPerSlice, 4);
/*  33 */     readACCoeffs(bits, qMat, out, blocksPerSlice, scan, 4, 2);
/*     */     
/*  35 */     for (int i = 0; i < blocksPerSlice; i++) {
/*  36 */       IDCT2x2.idct(out, i << 2);
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   public Picture decodeFrameHiBD(ByteBuffer data, byte[][] target, byte[][] lowBits) {
/*  42 */     ProresConsts.FrameHeader fh = readFrameHeader(data);
/*     */     
/*  44 */     int codedWidth = (fh.width + 15 & 0xFFFFFFF0) >> 2;
/*  45 */     int codedHeight = (fh.height + 15 & 0xFFFFFFF0) >> 2;
/*     */     
/*  47 */     int lumaSize = codedWidth * codedHeight;
/*  48 */     int chromaSize = lumaSize >> 1;
/*     */     
/*  50 */     if (target == null || (target[0]).length < lumaSize || (target[1]).length < chromaSize || (target[2]).length < chromaSize)
/*     */     {
/*  52 */       throw new RuntimeException("Provided output picture won't fit into provided buffer");
/*     */     }
/*     */     
/*  55 */     if (fh.frameType == 0) {
/*  56 */       decodePicture(data, target, lowBits, codedWidth, codedHeight, codedWidth >> 2, fh.qMatLuma, fh.qMatChroma, new int[] { 0, 1, 2, 3 }, 0, fh.chromaType);
/*     */     } else {
/*     */       
/*  59 */       decodePicture(data, target, lowBits, codedWidth, codedHeight >> 1, codedWidth >> 2, fh.qMatLuma, fh.qMatChroma, new int[] { 0, 2, 1, 3 }, fh.topFieldFirst ? 1 : 2, fh.chromaType);
/*     */ 
/*     */       
/*  62 */       decodePicture(data, target, lowBits, codedWidth, codedHeight >> 1, codedWidth >> 2, fh.qMatLuma, fh.qMatChroma, new int[] { 0, 2, 1, 3 }, fh.topFieldFirst ? 2 : 1, fh.chromaType);
/*     */     } 
/*     */ 
/*     */     
/*  66 */     ColorSpace color = (fh.chromaType == 2) ? ColorSpace.YUV422 : ColorSpace.YUV444;
/*  67 */     return new Picture(codedWidth, codedHeight, target, lowBits, color, (lowBits == null) ? 0 : 2, new Rect(0, 0, fh.width >> 2 & color
/*  68 */           .getWidthMask(), fh.height >> 2 & color.getHeightMask()));
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   protected void putSlice(byte[][] result, byte[][] lowBits, int lumaStride, int mbX, int mbY, int[] y, int[] u, int[] v, int dist, int shift, int chromaType, int sliceMbCount) {
/*  74 */     int chromaStride = lumaStride >> 1;
/*     */     
/*  76 */     _putLuma(result[0], (lowBits == null) ? null : lowBits[0], shift * lumaStride, lumaStride << dist, mbX, mbY, y, sliceMbCount, dist, shift);
/*     */     
/*  78 */     if (chromaType == 2) {
/*  79 */       _putChroma(result[1], (lowBits == null) ? null : lowBits[1], shift * chromaStride, chromaStride << dist, mbX, mbY, u, sliceMbCount, dist, shift);
/*     */       
/*  81 */       _putChroma(result[2], (lowBits == null) ? null : lowBits[2], shift * chromaStride, chromaStride << dist, mbX, mbY, v, sliceMbCount, dist, shift);
/*     */     } else {
/*     */       
/*  84 */       _putLuma(result[1], (lowBits == null) ? null : lowBits[1], shift * lumaStride, lumaStride << dist, mbX, mbY, u, sliceMbCount, dist, shift);
/*     */       
/*  86 */       _putLuma(result[2], (lowBits == null) ? null : lowBits[2], shift * lumaStride, lumaStride << dist, mbX, mbY, v, sliceMbCount, dist, shift);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private void _putLuma(byte[] y, byte[] lowBits, int off, int stride, int mbX, int mbY, int[] luma, int mbPerSlice, int dist, int shift) {
/*  93 */     off += (mbX << 2) + (mbY << 2) * stride;
/*  94 */     int tstride = stride * 3;
/*  95 */     for (int k = 0, sOff = 0; k < mbPerSlice; k++) {
/*  96 */       putGroup(y, lowBits, off, luma, sOff);
/*  97 */       off += stride;
/*  98 */       putGroup(y, lowBits, off, luma, sOff + 2);
/*  99 */       off += stride;
/* 100 */       putGroup(y, lowBits, off, luma, sOff + 8);
/* 101 */       off += stride;
/* 102 */       putGroup(y, lowBits, off, luma, sOff + 10);
/*     */       
/* 104 */       off += 4 - tstride;
/* 105 */       sOff += 16;
/*     */     } 
/*     */   }
/*     */   
/*     */   private void putGroup(byte[] y, byte[] lowBits, int off, int[] luma, int sOff) {
/* 110 */     int round0 = MathUtil.clip(luma[sOff] + 2 >> 2, 1, 255);
/* 111 */     int round1 = MathUtil.clip(luma[sOff + 1] + 2 >> 2, 1, 255);
/* 112 */     int round2 = MathUtil.clip(luma[sOff + 4] + 2 >> 2, 1, 255);
/* 113 */     int round3 = MathUtil.clip(luma[sOff + 5] + 2 >> 2, 1, 255);
/*     */     
/* 115 */     y[off] = (byte)(round0 - 128);
/* 116 */     y[off + 1] = (byte)(round1 - 128);
/* 117 */     y[off + 2] = (byte)(round2 - 128);
/* 118 */     y[off + 3] = (byte)(round3 - 128);
/*     */     
/* 120 */     if (lowBits != null) {
/* 121 */       int val0 = MathUtil.clip(luma[sOff], 4, 1019);
/* 122 */       int val1 = MathUtil.clip(luma[sOff + 1], 4, 1019);
/* 123 */       int val2 = MathUtil.clip(luma[sOff + 4], 4, 1019);
/* 124 */       int val3 = MathUtil.clip(luma[sOff + 5], 4, 1019);
/*     */       
/* 126 */       lowBits[off] = (byte)(val0 - (round0 << 2));
/* 127 */       lowBits[off + 1] = (byte)(val1 - (round1 << 2));
/* 128 */       lowBits[off + 2] = (byte)(val2 - (round2 << 2));
/* 129 */       lowBits[off + 3] = (byte)(val3 - (round3 << 2));
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   private void _putChroma(byte[] y, byte[] lowBits, int off_, int stride, int mbX, int mbY, int[] chroma, int mbPerSlice, int dist, int shift) {
/* 135 */     int off = off_ + (mbX << 1) + (mbY << 2) * stride; int k, sOff;
/* 136 */     for (k = 0, sOff = 0; k < mbPerSlice; k++) {
/*     */       
/* 138 */       for (int row = 0, rowOff = off; row < 4; row++, rowOff += stride, sOff += 2) {
/* 139 */         int round0 = MathUtil.clip(chroma[sOff] + 2 >> 2, 1, 255);
/* 140 */         int round1 = MathUtil.clip(chroma[sOff + 1] + 2 >> 2, 1, 255);
/*     */         
/* 142 */         y[rowOff] = (byte)(round0 - 128);
/* 143 */         y[rowOff + 1] = (byte)(round1 - 128);
/*     */       } 
/*     */       
/* 146 */       off += 2;
/*     */     } 
/*     */     
/* 149 */     if (lowBits != null) {
/* 150 */       off = off_ + (mbX << 1) + (mbY << 2) * stride;
/* 151 */       for (k = 0, sOff = 0; k < mbPerSlice; k++) {
/*     */         
/* 153 */         for (int row = 0, rowOff = off; row < 4; row++, rowOff += stride, sOff += 2) {
/* 154 */           int val0 = MathUtil.clip(chroma[sOff], 4, 1019);
/* 155 */           int val1 = MathUtil.clip(chroma[sOff + 1], 4, 1019);
/* 156 */           int round0 = MathUtil.clip(chroma[sOff] + 2 >> 2, 1, 255);
/* 157 */           int round1 = MathUtil.clip(chroma[sOff + 1] + 2 >> 2, 1, 255);
/*     */           
/* 159 */           lowBits[rowOff] = (byte)(val0 - (round0 << 2));
/* 160 */           lowBits[rowOff + 1] = (byte)(val1 - (round1 << 2));
/*     */         } 
/*     */         
/* 163 */         off += 2;
/*     */       } 
/*     */     } 
/*     */   }
/*     */ }


/* Location:              C:\Users\rapha\Downloads\aurora.jar!\META-INF\jars\jcodec-0.2.5.jar!\org\jcodec\codecs\prores\ProresToThumb2x2.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */