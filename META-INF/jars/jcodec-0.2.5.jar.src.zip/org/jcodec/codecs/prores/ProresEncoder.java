/*     */ package org.jcodec.codecs.prores;
/*     */ 
/*     */ import java.nio.ByteBuffer;
/*     */ import org.jcodec.common.VideoEncoder;
/*     */ import org.jcodec.common.dct.SimpleIDCT10Bit;
/*     */ import org.jcodec.common.io.BitWriter;
/*     */ import org.jcodec.common.io.NIOUtils;
/*     */ import org.jcodec.common.model.ColorSpace;
/*     */ import org.jcodec.common.model.Picture;
/*     */ import org.jcodec.common.model.Rect;
/*     */ import org.jcodec.common.tools.ImageOP;
/*     */ import org.jcodec.common.tools.MathUtil;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ProresEncoder
/*     */   extends VideoEncoder
/*     */ {
/*     */   private static final int LOG_DEFAULT_SLICE_MB_WIDTH = 3;
/*     */   private static final int DEFAULT_SLICE_MB_WIDTH = 8;
/*     */   protected Profile profile;
/*     */   private int[][] scaledLuma;
/*     */   private int[][] scaledChroma;
/*     */   private boolean interlaced;
/*     */   
/*     */   public static final class Profile
/*     */   {
/*  48 */     public static final Profile PROXY = new Profile("PROXY", ProresConsts.QMAT_LUMA_APCO, ProresConsts.QMAT_CHROMA_APCO, "apco", 1000, 4, 8);
/*  49 */     public static final Profile LT = new Profile("LT", ProresConsts.QMAT_LUMA_APCS, ProresConsts.QMAT_CHROMA_APCS, "apcs", 2100, 1, 9);
/*  50 */     public static final Profile STANDARD = new Profile("STANDARD", ProresConsts.QMAT_LUMA_APCN, ProresConsts.QMAT_CHROMA_APCN, "apcn", 3500, 1, 6);
/*     */     
/*  52 */     public static final Profile HQ = new Profile("HQ", ProresConsts.QMAT_LUMA_APCH, ProresConsts.QMAT_CHROMA_APCH, "apch", 5400, 1, 6);
/*     */     
/*  54 */     private static final Profile[] _values = new Profile[] { PROXY, LT, STANDARD, HQ }; final String name; final int[] qmatLuma; final int[] qmatChroma;
/*     */     
/*     */     public static Profile[] values() {
/*  57 */       return _values;
/*     */     }
/*     */     public final String fourcc; final int bitrate; final int firstQp; final int lastQp;
/*     */     public static Profile valueOf(String name) {
/*  61 */       String nameU = name.toUpperCase();
/*  62 */       for (Profile profile2 : _values) {
/*  63 */         if (name.equals(nameU))
/*  64 */           return profile2; 
/*     */       } 
/*  66 */       return null;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     private Profile(String name, int[] qmatLuma, int[] qmatChroma, String fourcc, int bitrate, int firstQp, int lastQp) {
/*  80 */       this.name = name;
/*  81 */       this.qmatLuma = qmatLuma;
/*  82 */       this.qmatChroma = qmatChroma;
/*  83 */       this.fourcc = fourcc;
/*  84 */       this.bitrate = bitrate;
/*  85 */       this.firstQp = firstQp;
/*  86 */       this.lastQp = lastQp;
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static ProresEncoder createProresEncoder(String profile, boolean interlaced) {
/*  97 */     return new ProresEncoder((profile == null) ? Profile.HQ : Profile.valueOf(profile), interlaced);
/*     */   }
/*     */   
/*     */   public ProresEncoder(Profile profile, boolean interlaced) {
/* 101 */     this.profile = profile;
/* 102 */     this.scaledLuma = scaleQMat(profile.qmatLuma, 1, 16);
/* 103 */     this.scaledChroma = scaleQMat(profile.qmatChroma, 1, 16);
/* 104 */     this.interlaced = interlaced;
/*     */   }
/*     */   
/*     */   private int[][] scaleQMat(int[] qmatLuma, int start, int count) {
/* 108 */     int[][] result = new int[count][];
/* 109 */     for (int i = 0; i < count; i++) {
/* 110 */       result[i] = new int[qmatLuma.length];
/* 111 */       for (int j = 0; j < qmatLuma.length; j++)
/* 112 */         result[i][j] = qmatLuma[j] * (i + start); 
/*     */     } 
/* 114 */     return result;
/*     */   }
/*     */   
/*     */   public static final void writeCodeword(BitWriter writer, Codebook codebook, int val) {
/* 118 */     int firstExp = codebook.switchBits + 1 << codebook.riceOrder;
/* 119 */     if (val >= firstExp) {
/* 120 */       val -= firstExp;
/* 121 */       val += 1 << codebook.expOrder;
/*     */       
/* 123 */       int exp = MathUtil.log2(val);
/* 124 */       int zeros = exp - codebook.expOrder + codebook.switchBits + 1;
/* 125 */       for (int i = 0; i < zeros; i++)
/* 126 */         writer.write1Bit(0); 
/* 127 */       writer.write1Bit(1);
/* 128 */       writer.writeNBit(val, exp);
/*     */     }
/* 130 */     else if (codebook.riceOrder > 0) {
/* 131 */       for (int i = 0; i < val >> codebook.riceOrder; i++)
/* 132 */         writer.write1Bit(0); 
/* 133 */       writer.write1Bit(1);
/* 134 */       writer.writeNBit(val & (1 << codebook.riceOrder) - 1, codebook.riceOrder);
/*     */     } else {
/* 136 */       for (int i = 0; i < val; i++)
/* 137 */         writer.write1Bit(0); 
/* 138 */       writer.write1Bit(1);
/*     */     } 
/*     */   }
/*     */   
/*     */   private static final int qScale(int[] qMat, int ind, int val) {
/* 143 */     return val / qMat[ind];
/*     */   }
/*     */   
/*     */   private static final int toGolumb(int val) {
/* 147 */     return val << 1 ^ val >> 31;
/*     */   }
/*     */   
/*     */   private static final int toGolumbSign(int val, int sign) {
/* 151 */     if (val == 0)
/* 152 */       return 0; 
/* 153 */     return (val << 1) + sign;
/*     */   }
/*     */   
/*     */   private static final int diffSign(int val, int sign) {
/* 157 */     return val >> 31 ^ sign;
/*     */   }
/*     */   
/*     */   public static final int getLevel(int val) {
/* 161 */     int sign = val >> 31;
/* 162 */     return (val ^ sign) - sign;
/*     */   }
/*     */   
/*     */   static final void writeDCCoeffs(BitWriter bits, int[] qMat, int[] _in, int blocksPerSlice) {
/* 166 */     int prevDc = qScale(qMat, 0, _in[0] - 16384);
/* 167 */     writeCodeword(bits, ProresConsts.firstDCCodebook, toGolumb(prevDc));
/*     */     
/* 169 */     int code = 5, sign = 0, idx = 64;
/* 170 */     for (int i = 1; i < blocksPerSlice; i++, idx += 64) {
/* 171 */       int newDc = qScale(qMat, 0, _in[idx] - 16384);
/* 172 */       int delta = newDc - prevDc;
/* 173 */       int newCode = toGolumbSign(getLevel(delta), diffSign(delta, sign));
/* 174 */       writeCodeword(bits, ProresConsts.dcCodebooks[Math.min(code, 6)], newCode);
/* 175 */       code = newCode;
/* 176 */       sign = delta >> 31;
/* 177 */       prevDc = newDc;
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   static final void writeACCoeffs(BitWriter bits, int[] qMat, int[] _in, int blocksPerSlice, int[] scan, int maxCoeff) {
/* 183 */     int prevRun = 4;
/* 184 */     int prevLevel = 2;
/*     */     
/* 186 */     int run = 0;
/* 187 */     for (int i = 1; i < maxCoeff; i++) {
/* 188 */       int indp = scan[i];
/* 189 */       for (int j = 0; j < blocksPerSlice; j++) {
/* 190 */         int val = qScale(qMat, indp, _in[(j << 6) + indp]);
/* 191 */         if (val == 0) {
/* 192 */           run++;
/*     */         } else {
/* 194 */           writeCodeword(bits, ProresConsts.runCodebooks[Math.min(prevRun, 15)], run);
/* 195 */           prevRun = run;
/* 196 */           run = 0;
/* 197 */           int level = getLevel(val);
/* 198 */           writeCodeword(bits, ProresConsts.levCodebooks[Math.min(prevLevel, 9)], level - 1);
/* 199 */           prevLevel = level;
/* 200 */           bits.write1Bit(MathUtil.sign(val));
/*     */         } 
/*     */       } 
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   static final void encodeOnePlane(BitWriter bits, int blocksPerSlice, int[] qMat, int[] scan, int[] _in) {
/* 208 */     writeDCCoeffs(bits, qMat, _in, blocksPerSlice);
/* 209 */     writeACCoeffs(bits, qMat, _in, blocksPerSlice, scan, 64);
/*     */   }
/*     */   
/*     */   private void dctOnePlane(int blocksPerSlice, byte[] src, byte[] hibd, int[] dst) {
/*     */     int i;
/* 214 */     for (i = 0; i < src.length; i++) {
/* 215 */       dst[i] = src[i] + 128 << 2;
/*     */     }
/* 217 */     if (hibd != null) {
/* 218 */       for (i = 0; i < src.length; i++) {
/* 219 */         dst[i] = dst[i] + hibd[i];
/*     */       }
/*     */     }
/*     */     
/* 223 */     for (i = 0; i < blocksPerSlice; i++) {
/* 224 */       SimpleIDCT10Bit.fdctProres10(dst, i << 6);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected int encodeSlice(ByteBuffer out, int[][] scaledLuma, int[][] scaledChroma, int[] scan, int sliceMbCount, int mbX, int mbY, Picture result, int prevQp, int mbWidth, int mbHeight, boolean unsafe, int vStep, int vOffset) {
/* 232 */     Picture striped = splitSlice(result, mbX, mbY, sliceMbCount, unsafe, vStep, vOffset);
/* 233 */     int[][] ac = { new int[sliceMbCount << 8], new int[sliceMbCount << 7], new int[sliceMbCount << 7] };
/* 234 */     byte[][] data = striped.getData();
/* 235 */     byte[][] lowBits = striped.getLowBits();
/* 236 */     dctOnePlane(sliceMbCount << 2, data[0], (lowBits == null) ? null : lowBits[0], ac[0]);
/* 237 */     dctOnePlane(sliceMbCount << 1, data[1], (lowBits == null) ? null : lowBits[1], ac[1]);
/* 238 */     dctOnePlane(sliceMbCount << 1, data[2], (lowBits == null) ? null : lowBits[2], ac[2]);
/*     */     
/* 240 */     int est = (sliceMbCount >> 2) * this.profile.bitrate;
/* 241 */     int low = est - (est >> 3);
/* 242 */     int high = est + (est >> 3);
/*     */     
/* 244 */     int qp = prevQp;
/*     */     
/* 246 */     out.put((byte)48);
/* 247 */     ByteBuffer fork = out.duplicate();
/* 248 */     NIOUtils.skip(out, 5);
/* 249 */     int rem = out.position();
/* 250 */     int[] sizes = new int[3];
/* 251 */     encodeSliceData(out, scaledLuma[qp - 1], scaledChroma[qp - 1], scan, sliceMbCount, ac, qp, sizes);
/* 252 */     if (bits(sizes) > high && qp < this.profile.lastQp) {
/*     */       do {
/* 254 */         qp++;
/* 255 */         out.position(rem);
/* 256 */         encodeSliceData(out, scaledLuma[qp - 1], scaledChroma[qp - 1], scan, sliceMbCount, ac, qp, sizes);
/* 257 */       } while (bits(sizes) > high && qp < this.profile.lastQp);
/* 258 */     } else if (bits(sizes) < low && qp > this.profile.firstQp) {
/*     */       do {
/* 260 */         qp--;
/* 261 */         out.position(rem);
/* 262 */         encodeSliceData(out, scaledLuma[qp - 1], scaledChroma[qp - 1], scan, sliceMbCount, ac, qp, sizes);
/* 263 */       } while (bits(sizes) < low && qp > this.profile.firstQp);
/*     */     } 
/*     */     
/* 266 */     fork.put((byte)qp);
/* 267 */     fork.putShort((short)sizes[0]);
/* 268 */     fork.putShort((short)sizes[1]);
/*     */     
/* 270 */     return qp;
/*     */   }
/*     */   
/*     */   static final int bits(int[] sizes) {
/* 274 */     return sizes[0] + sizes[1] + sizes[2] << 3;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   protected static final void encodeSliceData(ByteBuffer out, int[] qmatLuma, int[] qmatChroma, int[] scan, int sliceMbCount, int[][] ac, int qp, int[] sizes) {
/* 280 */     sizes[0] = onePlane(out, sliceMbCount << 2, qmatLuma, scan, ac[0]);
/* 281 */     sizes[1] = onePlane(out, sliceMbCount << 1, qmatChroma, scan, ac[1]);
/* 282 */     sizes[2] = onePlane(out, sliceMbCount << 1, qmatChroma, scan, ac[2]);
/*     */   }
/*     */   
/*     */   static final int onePlane(ByteBuffer out, int blocksPerSlice, int[] qmatLuma, int[] scan, int[] data) {
/* 286 */     int rem = out.position();
/* 287 */     BitWriter bits = new BitWriter(out);
/* 288 */     encodeOnePlane(bits, blocksPerSlice, qmatLuma, scan, data);
/* 289 */     bits.flush();
/* 290 */     return out.position() - rem;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   protected void encodePicture(ByteBuffer out, int[][] scaledLuma, int[][] scaledChroma, int[] scan, Picture picture, int vStep, int vOffset) {
/* 296 */     int mbWidth = picture.getWidth() + 15 >> 4;
/* 297 */     int shift = 4 + vStep;
/* 298 */     int round = (1 << shift) - 1;
/* 299 */     int mbHeight = picture.getHeight() + round >> shift;
/* 300 */     int qp = this.profile.firstQp;
/*     */     
/* 302 */     int nSlices = calcNSlices(mbWidth, mbHeight);
/* 303 */     writePictureHeader(3, nSlices, out);
/* 304 */     ByteBuffer fork = out.duplicate();
/* 305 */     NIOUtils.skip(out, nSlices << 1);
/*     */     
/* 307 */     int i = 0;
/* 308 */     int[] total = new int[nSlices];
/* 309 */     for (int mbY = 0; mbY < mbHeight; mbY++) {
/* 310 */       int mbX = 0;
/* 311 */       int sliceMbCount = 8;
/* 312 */       while (mbX < mbWidth) {
/* 313 */         while (mbWidth - mbX < sliceMbCount) {
/* 314 */           sliceMbCount >>= 1;
/*     */         }
/* 316 */         int sliceStart = out.position();
/* 317 */         boolean unsafeBottom = (picture.getHeight() % 16 != 0 && mbY == mbHeight - 1);
/* 318 */         boolean unsafeRight = (picture.getWidth() % 16 != 0 && mbX + sliceMbCount == mbWidth);
/* 319 */         qp = encodeSlice(out, scaledLuma, scaledChroma, scan, sliceMbCount, mbX, mbY, picture, qp, mbWidth, mbHeight, (unsafeBottom || unsafeRight), vStep, vOffset);
/*     */         
/* 321 */         fork.putShort((short)(out.position() - sliceStart));
/* 322 */         total[i++] = (short)(out.position() - sliceStart);
/*     */         
/* 324 */         mbX += sliceMbCount;
/*     */       } 
/*     */     } 
/*     */   }
/*     */   
/*     */   public static void writePictureHeader(int logDefaultSliceMbWidth, int nSlices, ByteBuffer out) {
/* 330 */     int headerLen = 8;
/* 331 */     out.put((byte)(headerLen << 3));
/* 332 */     out.putInt(0);
/* 333 */     out.putShort((short)nSlices);
/* 334 */     out.put((byte)(logDefaultSliceMbWidth << 4));
/*     */   }
/*     */   
/*     */   private int calcNSlices(int mbWidth, int mbHeight) {
/* 338 */     int nSlices = mbWidth >> 3;
/* 339 */     for (int i = 0; i < 3; i++) {
/* 340 */       nSlices += mbWidth >> i & 0x1;
/*     */     }
/* 342 */     return nSlices * mbHeight;
/*     */   }
/*     */ 
/*     */   
/*     */   private Picture splitSlice(Picture result, int mbX, int mbY, int sliceMbCount, boolean unsafe, int vStep, int vOffset) {
/* 347 */     Picture out = Picture.createCroppedHiBD(sliceMbCount << 4, 16, result.getLowBitsNum(), ColorSpace.YUV422, null);
/* 348 */     if (unsafe) {
/* 349 */       int mbHeightPix = 16 << vStep;
/* 350 */       Picture filled = Picture.create(sliceMbCount << 4, mbHeightPix, ColorSpace.YUV422);
/* 351 */       ImageOP.subImageWithFillPic8(result, filled, new Rect(mbX << 4, mbY << 4 + vStep, sliceMbCount << 4, mbHeightPix));
/*     */ 
/*     */       
/* 354 */       split(filled, out, 0, 0, sliceMbCount, vStep, vOffset);
/*     */     } else {
/* 356 */       split(result, out, mbX, mbY, sliceMbCount, vStep, vOffset);
/*     */     } 
/*     */     
/* 359 */     return out;
/*     */   }
/*     */ 
/*     */   
/*     */   private void split(Picture src, Picture dst, int mbX, int mbY, int sliceMbCount, int vStep, int vOffset) {
/* 364 */     byte[][] inData = src.getData();
/* 365 */     byte[][] inhbdData = src.getLowBits();
/*     */     
/* 367 */     byte[][] outData = dst.getData();
/* 368 */     byte[][] outhbdData = dst.getLowBits();
/*     */     
/* 370 */     doSplit(inData[0], outData[0], src.getPlaneWidth(0), mbX, mbY, sliceMbCount, 0, vStep, vOffset);
/* 371 */     doSplit(inData[1], outData[1], src.getPlaneWidth(1), mbX, mbY, sliceMbCount, 1, vStep, vOffset);
/* 372 */     doSplit(inData[2], outData[2], src.getPlaneWidth(2), mbX, mbY, sliceMbCount, 1, vStep, vOffset);
/*     */     
/* 374 */     if (src.getLowBits() != null) {
/* 375 */       doSplit(inhbdData[0], outhbdData[0], src.getPlaneWidth(0), mbX, mbY, sliceMbCount, 0, vStep, vOffset);
/* 376 */       doSplit(inhbdData[1], outhbdData[1], src.getPlaneWidth(1), mbX, mbY, sliceMbCount, 1, vStep, vOffset);
/* 377 */       doSplit(inhbdData[2], outhbdData[2], src.getPlaneWidth(2), mbX, mbY, sliceMbCount, 1, vStep, vOffset);
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   private void doSplit(byte[] _in, byte[] out, int stride, int mbX, int mbY, int sliceMbCount, int chroma, int vStep, int vOffset) {
/* 383 */     int outOff = 0;
/* 384 */     int off = (mbY << 4) * (stride << vStep) + (mbX << 4 - chroma) + stride * vOffset;
/* 385 */     stride <<= vStep;
/*     */     
/* 387 */     for (int i = 0; i < sliceMbCount; i++) {
/* 388 */       splitBlock(_in, stride, off, out, outOff);
/* 389 */       splitBlock(_in, stride, off + (stride << 3), out, outOff + (128 >> chroma));
/*     */       
/* 391 */       if (chroma == 0) {
/* 392 */         splitBlock(_in, stride, off + 8, out, outOff + 64);
/* 393 */         splitBlock(_in, stride, off + (stride << 3) + 8, out, outOff + 192);
/*     */       } 
/*     */       
/* 396 */       outOff += 256 >> chroma;
/* 397 */       off += 16 >> chroma;
/*     */     } 
/*     */   }
/*     */   
/*     */   private void splitBlock(byte[] y, int stride, int off, byte[] out, int outOff) {
/* 402 */     for (int i = 0; i < 8; i++) {
/* 403 */       for (int j = 0; j < 8; j++)
/* 404 */         out[outOff++] = y[off++]; 
/* 405 */       off += stride - 8;
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public VideoEncoder.EncodedFrame encodeFrame(Picture pic, ByteBuffer buffer) {
/* 411 */     ByteBuffer out = buffer.duplicate();
/* 412 */     ByteBuffer fork = out.duplicate();
/*     */     
/* 414 */     int[] scan = this.interlaced ? ProresConsts.interlaced_scan : ProresConsts.progressive_scan;
/* 415 */     writeFrameHeader(out, new ProresConsts.FrameHeader(0, pic.getCroppedWidth(), pic.getCroppedHeight(), this.interlaced ? 1 : 0, true, scan, this.profile.qmatLuma, this.profile.qmatChroma, 2));
/*     */ 
/*     */     
/* 418 */     encodePicture(out, this.scaledLuma, this.scaledChroma, scan, pic, this.interlaced ? 1 : 0, 0);
/* 419 */     if (this.interlaced)
/* 420 */       encodePicture(out, this.scaledLuma, this.scaledChroma, scan, pic, this.interlaced ? 1 : 0, 1); 
/* 421 */     out.flip();
/* 422 */     fork.putInt(out.remaining());
/*     */     
/* 424 */     return new VideoEncoder.EncodedFrame(out, true);
/*     */   }
/*     */ 
/*     */   
/*     */   public static void writeFrameHeader(ByteBuffer outp, ProresConsts.FrameHeader header) {
/* 429 */     short headerSize = 148;
/* 430 */     outp.putInt(headerSize + 8 + header.payloadSize);
/* 431 */     outp.put(new byte[] { 105, 99, 112, 102 });
/*     */     
/* 433 */     outp.putShort(headerSize);
/* 434 */     outp.putShort((short)0);
/*     */     
/* 436 */     outp.put(new byte[] { 97, 112, 108, 48 });
/*     */     
/* 438 */     outp.putShort((short)header.width);
/* 439 */     outp.putShort((short)header.height);
/*     */     
/* 441 */     outp.put((byte)((header.frameType == 0) ? 131 : 135));
/*     */     
/* 443 */     outp.put(new byte[] { 0, 2, 2, 6, 32, 0 });
/*     */     
/* 445 */     outp.put((byte)3);
/* 446 */     writeQMat(outp, header.qMatLuma);
/* 447 */     writeQMat(outp, header.qMatChroma);
/*     */   }
/*     */   
/*     */   static final void writeQMat(ByteBuffer out, int[] qmat) {
/* 451 */     for (int i = 0; i < 64; i++) {
/* 452 */       out.put((byte)qmat[i]);
/*     */     }
/*     */   }
/*     */   
/*     */   public ColorSpace[] getSupportedColorSpaces() {
/* 457 */     return new ColorSpace[] { ColorSpace.YUV422 };
/*     */   }
/*     */ 
/*     */   
/*     */   public int estimateBufferSize(Picture frame) {
/* 462 */     return 3 * frame.getWidth() * frame.getHeight() / 2;
/*     */   }
/*     */ }


/* Location:              C:\Users\rapha\Downloads\aurora.jar!\META-INF\jars\jcodec-0.2.5.jar!\org\jcodec\codecs\prores\ProresEncoder.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */