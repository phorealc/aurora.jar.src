/*     */ package org.jcodec.codecs.prores;
/*     */ 
/*     */ import java.nio.ByteBuffer;
/*     */ import java.util.ArrayList;
/*     */ import java.util.List;
/*     */ import org.jcodec.common.io.BitReader;
/*     */ import org.jcodec.common.io.BitWriter;
/*     */ import org.jcodec.common.io.NIOUtils;
/*     */ import org.jcodec.common.tools.MathUtil;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ProresFix
/*     */ {
/*     */   static final void readDCCoeffs(BitReader bits, int[] out, int blocksPerSlice) {
/*  37 */     out[0] = ProresDecoder.readCodeword(bits, ProresConsts.firstDCCodebook);
/*  38 */     if (out[0] < 0) {
/*  39 */       throw new RuntimeException("First DC coeff damaged");
/*     */     }
/*     */     
/*  42 */     int code = 5, idx = 64;
/*  43 */     for (int i = 1; i < blocksPerSlice; i++, idx += 64) {
/*  44 */       code = ProresDecoder.readCodeword(bits, ProresConsts.dcCodebooks[Math.min(code, 6)]);
/*  45 */       if (code < 0) {
/*  46 */         throw new RuntimeException("DC coeff damaged");
/*     */       }
/*     */       
/*  49 */       out[idx] = code;
/*     */     } 
/*     */   }
/*     */   
/*     */   static final void readACCoeffs(BitReader bits, int[] out, int blocksPerSlice, int[] scan) {
/*  54 */     int run = 4;
/*  55 */     int level = 2;
/*     */     
/*  57 */     int blockMask = blocksPerSlice - 1;
/*  58 */     int log2BlocksPerSlice = MathUtil.log2(blocksPerSlice);
/*  59 */     int maxCoeffs = 64 << log2BlocksPerSlice;
/*     */     
/*  61 */     int pos = blockMask;
/*  62 */     while (bits.remaining() > 32 || bits.checkNBit(24) != 0) {
/*  63 */       run = ProresDecoder.readCodeword(bits, ProresConsts.runCodebooks[Math.min(run, 15)]);
/*  64 */       if (run < 0 || run >= maxCoeffs - pos - 1) {
/*  65 */         throw new RuntimeException("Run codeword damaged");
/*     */       }
/*  67 */       pos += run + 1;
/*     */       
/*  69 */       level = ProresDecoder.readCodeword(bits, ProresConsts.levCodebooks[Math.min(level, 9)]) + 1;
/*  70 */       if (level < 0 || level > 65535) {
/*  71 */         throw new RuntimeException("Level codeword damaged");
/*     */       }
/*  73 */       int sign = -bits.read1Bit();
/*  74 */       int ind = pos >> log2BlocksPerSlice;
/*  75 */       out[((pos & blockMask) << 6) + scan[ind]] = MathUtil.toSigned(level, sign);
/*     */     } 
/*     */   }
/*     */   
/*     */   static final void writeDCCoeffs(BitWriter bits, int[] _in, int blocksPerSlice) {
/*  80 */     ProresEncoder.writeCodeword(bits, ProresConsts.firstDCCodebook, _in[0]);
/*     */     
/*  82 */     int code = 5, idx = 64;
/*  83 */     for (int i = 1; i < blocksPerSlice; i++, idx += 64) {
/*  84 */       ProresEncoder.writeCodeword(bits, ProresConsts.dcCodebooks[Math.min(code, 6)], _in[idx]);
/*  85 */       code = _in[idx];
/*     */     } 
/*     */   }
/*     */   
/*     */   static final void writeACCoeffs(BitWriter bits, int[] _in, int blocksPerSlice, int[] scan) {
/*  90 */     int prevRun = 4;
/*  91 */     int prevLevel = 2;
/*     */     
/*  93 */     int run = 0;
/*  94 */     for (int i = 1; i < 64; i++) {
/*  95 */       int indp = scan[i];
/*  96 */       for (int j = 0; j < blocksPerSlice; j++) {
/*  97 */         int val = _in[(j << 6) + indp];
/*  98 */         if (val == 0) {
/*  99 */           run++;
/*     */         } else {
/* 101 */           ProresEncoder.writeCodeword(bits, ProresConsts.runCodebooks[Math.min(prevRun, 15)], run);
/* 102 */           prevRun = run;
/* 103 */           run = 0;
/* 104 */           int level = ProresEncoder.getLevel(val);
/* 105 */           ProresEncoder.writeCodeword(bits, ProresConsts.levCodebooks[Math.min(prevLevel, 9)], level - 1);
/* 106 */           prevLevel = level;
/* 107 */           bits.write1Bit(MathUtil.sign(val));
/*     */         } 
/*     */       } 
/*     */     } 
/*     */   }
/*     */   
/*     */   static void copyCoeff(BitReader ib, BitWriter ob, int blocksPerSlice, int[] scan) {
/* 114 */     int[] out = new int[blocksPerSlice << 6];
/*     */     try {
/* 116 */       readDCCoeffs(ib, out, blocksPerSlice);
/* 117 */       readACCoeffs(ib, out, blocksPerSlice, scan);
/* 118 */     } catch (RuntimeException runtimeException) {}
/*     */     
/* 120 */     writeDCCoeffs(ob, out, blocksPerSlice);
/* 121 */     writeACCoeffs(ob, out, blocksPerSlice, scan);
/* 122 */     ob.flush();
/*     */   }
/*     */   
/*     */   public static ByteBuffer transcode(ByteBuffer inBuf, ByteBuffer _outBuf) {
/* 126 */     ByteBuffer outBuf = _outBuf.slice();
/* 127 */     ByteBuffer fork = outBuf.duplicate();
/*     */     
/* 129 */     ProresConsts.FrameHeader fh = ProresDecoder.readFrameHeader(inBuf);
/* 130 */     ProresEncoder.writeFrameHeader(outBuf, fh);
/*     */     
/* 132 */     if (fh.frameType == 0) {
/* 133 */       transcodePicture(inBuf, outBuf, fh);
/*     */     } else {
/* 135 */       transcodePicture(inBuf, outBuf, fh);
/*     */       
/* 137 */       transcodePicture(inBuf, outBuf, fh);
/*     */     } 
/*     */     
/* 140 */     ProresEncoder.writeFrameHeader(fork, fh);
/*     */     
/* 142 */     outBuf.flip();
/*     */     
/* 144 */     return outBuf;
/*     */   }
/*     */ 
/*     */   
/*     */   private static void transcodePicture(ByteBuffer inBuf, ByteBuffer outBuf, ProresConsts.FrameHeader fh) {
/* 149 */     ProresConsts.PictureHeader ph = ProresDecoder.readPictureHeader(inBuf);
/* 150 */     ProresEncoder.writePictureHeader(ph.log2SliceMbWidth, ph.sliceSizes.length, outBuf);
/* 151 */     ByteBuffer fork = outBuf.duplicate();
/* 152 */     outBuf.position(outBuf.position() + (ph.sliceSizes.length << 1));
/*     */     
/* 154 */     int mbWidth = fh.width + 15 >> 4;
/*     */     
/* 156 */     int sliceMbCount = 1 << ph.log2SliceMbWidth;
/* 157 */     int mbX = 0;
/* 158 */     for (int i = 0; i < ph.sliceSizes.length; i++) {
/*     */       
/* 160 */       while (mbWidth - mbX < sliceMbCount) {
/* 161 */         sliceMbCount >>= 1;
/*     */       }
/* 163 */       int savedPoint = outBuf.position();
/*     */       
/* 165 */       transcodeSlice(inBuf, outBuf, sliceMbCount, ph.sliceSizes[i], fh);
/* 166 */       fork.putShort((short)(outBuf.position() - savedPoint));
/*     */       
/* 168 */       mbX += sliceMbCount;
/* 169 */       if (mbX == mbWidth) {
/* 170 */         sliceMbCount = 1 << ph.log2SliceMbWidth;
/* 171 */         mbX = 0;
/*     */       } 
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private static void transcodeSlice(ByteBuffer inBuf, ByteBuffer outBuf, int sliceMbCount, short sliceSize, ProresConsts.FrameHeader fh) {
/* 179 */     int hdrSize = (inBuf.get() & 0xFF) >> 3;
/* 180 */     int qScaleOrig = inBuf.get() & 0xFF;
/* 181 */     int yDataSize = inBuf.getShort();
/* 182 */     int uDataSize = inBuf.getShort();
/* 183 */     int vDataSize = sliceSize - uDataSize - yDataSize - hdrSize;
/*     */     
/* 185 */     outBuf.put((byte)48);
/* 186 */     outBuf.put((byte)qScaleOrig);
/* 187 */     ByteBuffer beforeSizes = outBuf.duplicate();
/* 188 */     outBuf.putInt(0);
/*     */     
/* 190 */     int beforeY = outBuf.position();
/* 191 */     copyCoeff(ProresDecoder.bitstream(inBuf, yDataSize), new BitWriter(outBuf), sliceMbCount << 2, fh.scan);
/* 192 */     int beforeCb = outBuf.position();
/* 193 */     copyCoeff(ProresDecoder.bitstream(inBuf, uDataSize), new BitWriter(outBuf), sliceMbCount << 1, fh.scan);
/* 194 */     int beforeCr = outBuf.position();
/* 195 */     copyCoeff(ProresDecoder.bitstream(inBuf, vDataSize), new BitWriter(outBuf), sliceMbCount << 1, fh.scan);
/*     */     
/* 197 */     beforeSizes.putShort((short)(beforeCb - beforeY));
/* 198 */     beforeSizes.putShort((short)(beforeCr - beforeCb));
/*     */   }
/*     */   
/*     */   public static List<String> check(ByteBuffer data) {
/* 202 */     List<String> messages = new ArrayList<String>();
/* 203 */     int frameSize = data.getInt();
/*     */     
/* 205 */     if (!"icpf".equals(ProresDecoder.readSig(data))) {
/* 206 */       messages.add("[ERROR] Missing ProRes signature (icpf).");
/* 207 */       return messages;
/*     */     } 
/*     */     
/* 210 */     short headerSize = data.getShort();
/* 211 */     if (headerSize > 148) {
/* 212 */       messages.add("[ERROR] Wrong ProRes frame header.");
/* 213 */       return messages;
/*     */     } 
/* 215 */     short version = data.getShort();
/*     */     
/* 217 */     int res1 = data.getInt();
/*     */     
/* 219 */     short width = data.getShort();
/* 220 */     short height = data.getShort();
/* 221 */     if (width < 0 || width > 10000 || height < 0 || height > 10000) {
/* 222 */       messages.add("[ERROR] Wrong ProRes frame header, invalid image size [" + width + "x" + height + "].");
/* 223 */       return messages;
/*     */     } 
/*     */     
/* 226 */     int flags1 = data.get();
/*     */     
/* 228 */     data.position(data.position() + headerSize - 13);
/*     */     
/* 230 */     if ((flags1 >> 2 & 0x3) == 0) {
/* 231 */       checkPicture(data, width, height, messages);
/*     */     } else {
/* 233 */       checkPicture(data, width, height / 2, messages);
/* 234 */       checkPicture(data, width, height / 2, messages);
/*     */     } 
/*     */     
/* 237 */     return messages;
/*     */   }
/*     */ 
/*     */   
/*     */   private static void checkPicture(ByteBuffer data, int width, int height, List<String> messages) {
/* 242 */     ProresConsts.PictureHeader ph = ProresDecoder.readPictureHeader(data);
/*     */     
/* 244 */     int mbWidth = width + 15 >> 4;
/* 245 */     int mbHeight = height + 15 >> 4;
/*     */     
/* 247 */     int sliceMbCount = 1 << ph.log2SliceMbWidth;
/* 248 */     int mbX = 0, mbY = 0;
/* 249 */     for (int i = 0; i < ph.sliceSizes.length; i++) {
/*     */       
/* 251 */       while (mbWidth - mbX < sliceMbCount) {
/* 252 */         sliceMbCount >>= 1;
/*     */       }
/*     */       try {
/* 255 */         checkSlice(NIOUtils.read(data, ph.sliceSizes[i]), sliceMbCount);
/* 256 */       } catch (Exception e) {
/* 257 */         messages.add("[ERROR] Slice data corrupt: mbX = " + mbX + ", mbY = " + mbY + ". " + e.getMessage());
/*     */       } 
/*     */       
/* 260 */       mbX += sliceMbCount;
/* 261 */       if (mbX == mbWidth) {
/* 262 */         sliceMbCount = 1 << ph.log2SliceMbWidth;
/* 263 */         mbX = 0;
/* 264 */         mbY++;
/*     */       } 
/*     */     } 
/*     */   }
/*     */   
/*     */   private static void checkSlice(ByteBuffer sliceData, int sliceMbCount) {
/* 270 */     int sliceSize = sliceData.remaining();
/*     */     
/* 272 */     int hdrSize = (sliceData.get() & 0xFF) >> 3;
/* 273 */     int qScaleOrig = sliceData.get() & 0xFF;
/* 274 */     int yDataSize = sliceData.getShort();
/* 275 */     int uDataSize = sliceData.getShort();
/* 276 */     int vDataSize = sliceSize - uDataSize - yDataSize - hdrSize;
/*     */     
/* 278 */     checkCoeff(ProresDecoder.bitstream(sliceData, yDataSize), sliceMbCount << 2);
/* 279 */     checkCoeff(ProresDecoder.bitstream(sliceData, uDataSize), sliceMbCount << 1);
/* 280 */     checkCoeff(ProresDecoder.bitstream(sliceData, vDataSize), sliceMbCount << 1);
/*     */   }
/*     */   
/*     */   private static void checkCoeff(BitReader ib, int blocksPerSlice) {
/* 284 */     int[] scan = new int[64];
/* 285 */     int[] out = new int[blocksPerSlice << 6];
/* 286 */     readDCCoeffs(ib, out, blocksPerSlice);
/* 287 */     readACCoeffs(ib, out, blocksPerSlice, scan);
/*     */   }
/*     */ }


/* Location:              C:\Users\rapha\Downloads\aurora.jar!\META-INF\jars\jcodec-0.2.5.jar!\org\jcodec\codecs\prores\ProresFix.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */