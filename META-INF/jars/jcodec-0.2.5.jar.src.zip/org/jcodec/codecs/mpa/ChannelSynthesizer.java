/*    */ package org.jcodec.codecs.mpa;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ class ChannelSynthesizer
/*    */ {
/*    */   private float[][] v;
/*    */   private int pos;
/*    */   private float scalefactor;
/*    */   private int current;
/*    */   
/*    */   public ChannelSynthesizer(int channelnumber, float factor) {
/* 19 */     this.v = new float[2][512];
/* 20 */     this.scalefactor = factor;
/* 21 */     this.pos = 15;
/*    */   }
/*    */   private static void distributeSamples(int pos, float[] dest, float[] next, float[] s) {
/*    */     int i;
/* 25 */     for (i = 0; i < 16; i++) {
/* 26 */       dest[(i << 4) + pos] = s[i];
/*    */     }
/* 28 */     for (i = 1; i < 17; i++) {
/* 29 */       next[(i << 4) + pos] = s[15 + i];
/*    */     }
/* 31 */     dest[256 + pos] = 0.0F;
/* 32 */     next[0 + pos] = -s[0];
/*    */     
/* 34 */     for (i = 0; i < 15; i++) {
/* 35 */       dest[272 + (i << 4) + pos] = -s[15 - i];
/*    */     }
/* 37 */     for (i = 0; i < 15; i++) {
/* 38 */       next[272 + (i << 4) + pos] = s[30 - i];
/*    */     }
/*    */   }
/*    */   
/*    */   public void synthesize(float[] coeffs, short[] out, int off) {
/* 43 */     MpaPqmf.computeButterfly(this.pos, coeffs);
/* 44 */     int next = (this.current ^ 0xFFFFFFFF) & 0x1;
/* 45 */     distributeSamples(this.pos, this.v[this.current], this.v[next], coeffs);
/* 46 */     MpaPqmf.computeFilter(this.pos, this.v[this.current], out, off, this.scalefactor);
/*    */     
/* 48 */     this.pos = this.pos + 1 & 0xF;
/* 49 */     this.current = next;
/*    */   }
/*    */ }


/* Location:              C:\Users\rapha\Downloads\aurora.jar!\META-INF\jars\jcodec-0.2.5.jar!\org\jcodec\codecs\mpa\ChannelSynthesizer.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */