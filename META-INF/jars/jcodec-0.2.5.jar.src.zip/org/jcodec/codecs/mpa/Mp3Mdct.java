/*     */ package org.jcodec.codecs.mpa;
/*     */ 
/*     */ import java.util.Arrays;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class Mp3Mdct
/*     */ {
/*     */   private static final float factor36pt0 = 0.34729636F;
/*     */   private static final float factor36pt1 = 1.5320889F;
/*     */   private static final float factor36pt2 = 1.8793852F;
/*     */   private static final float factor36pt3 = 1.7320508F;
/*     */   private static final float factor36pt4 = 1.9696155F;
/*     */   private static final float factor36pt5 = 1.2855753F;
/*     */   private static final float factor36pt6 = 0.6840403F;
/*  21 */   private static final float[] factor36 = new float[] { 0.5019099F, 0.5176381F, 0.55168897F, 0.61038727F, 0.8717234F, 1.1831008F, 1.9318516F, 5.7368565F };
/*     */   
/*     */   private static final float cos075 = 0.9914449F;
/*     */   
/*     */   private static final float cos225 = 0.9238795F;
/*     */   
/*     */   private static final float cos300 = 0.8660254F;
/*     */   private static final float cos375 = 0.7933533F;
/*     */   private static final float cos450 = 0.70710677F;
/*     */   private static final float cos525 = 0.6087614F;
/*     */   private static final float cos600 = 0.5F;
/*     */   private static final float cos675 = 0.38268343F;
/*     */   private static final float cos825 = 0.13052619F;
/*     */   private static final float factor12pt0 = 1.9318516F;
/*     */   private static final float factor12pt1 = 0.5176381F;
/*  36 */   private static final float[] factor12 = new float[] { 0.5043145F, 0.5411961F, 0.6302362F, 0.8213398F, 1.306563F, 3.830649F };
/*     */ 
/*     */   
/*  39 */   private static float[] tmp = new float[16];
/*     */   
/*     */   static void oneLong(float[] src, float[] dst) {
/*     */     int i;
/*  43 */     for (i = 17; i > 0; i--) {
/*  44 */       src[i] = src[i] + src[i - 1];
/*     */     }
/*  46 */     for (i = 17; i > 2; i -= 2)
/*  47 */       src[i] = src[i] + src[i - 2]; 
/*     */     int k;
/*  49 */     for (i = 0, k = 0; i < 2; i++, k += 8) {
/*  50 */       float f1 = src[i] + src[i];
/*  51 */       float f2 = f1 + src[12 + i];
/*  52 */       float tmp2 = src[6 + i] * 1.7320508F;
/*     */       
/*  54 */       tmp[k + 0] = f2 + src[4 + i] * 1.8793852F + src[8 + i] * 1.5320889F + src[16 + i] * 0.34729636F;
/*  55 */       tmp[k + 1] = f1 + src[4 + i] - src[8 + i] - src[12 + i] - src[12 + i] - src[16 + i];
/*  56 */       tmp[k + 2] = f2 - src[4 + i] * 0.34729636F - src[8 + i] * 1.8793852F + src[16 + i] * 1.5320889F;
/*  57 */       tmp[k + 3] = f2 - src[4 + i] * 1.5320889F + src[8 + i] * 0.34729636F - src[16 + i] * 1.8793852F;
/*     */       
/*  59 */       tmp[k + 4] = src[2 + i] * 1.9696155F + tmp2 + src[10 + i] * 1.2855753F + src[14 + i] * 0.6840403F;
/*  60 */       tmp[k + 5] = (src[2 + i] - src[10 + i] - src[14 + i]) * 1.7320508F;
/*  61 */       tmp[k + 6] = src[2 + i] * 1.2855753F - tmp2 - src[10 + i] * 0.6840403F + src[14 + i] * 1.9696155F;
/*  62 */       tmp[k + 7] = src[2 + i] * 0.6840403F - tmp2 + src[10 + i] * 1.9696155F - src[14 + i] * 1.2855753F;
/*     */     } 
/*     */     int j, m, l;
/*  65 */     for (i = 0, j = 4, m = 8, l = 12; i < 4; i++, j++, m++, l++) {
/*  66 */       float q1 = tmp[i];
/*  67 */       float q2 = tmp[m];
/*  68 */       tmp[i] = tmp[i] + tmp[j];
/*  69 */       tmp[j] = q1 - tmp[j];
/*  70 */       tmp[m] = (tmp[m] + tmp[l]) * factor36[i];
/*  71 */       tmp[l] = (q2 - tmp[l]) * factor36[7 - i];
/*     */     } 
/*     */     
/*  74 */     for (i = 0; i < 4; i++) {
/*  75 */       dst[26 - i] = tmp[i] + tmp[8 + i];
/*  76 */       dst[8 - i] = tmp[8 + i] - tmp[i];
/*  77 */       dst[27 + i] = dst[26 - i];
/*  78 */       dst[9 + i] = -dst[8 - i];
/*     */     } 
/*     */     
/*  81 */     for (i = 0; i < 4; i++) {
/*  82 */       dst[21 - i] = tmp[7 - i] + tmp[15 - i];
/*  83 */       dst[3 - i] = tmp[15 - i] - tmp[7 - i];
/*  84 */       dst[32 + i] = dst[21 - i];
/*  85 */       dst[14 + i] = -dst[3 - i];
/*     */     } 
/*     */     
/*  88 */     float tmp0 = src[0] - src[4] + src[8] - src[12] + src[16];
/*  89 */     float tmp1 = (src[1] - src[5] + src[9] - src[13] + src[17]) * 0.70710677F;
/*  90 */     dst[4] = tmp1 - tmp0;
/*  91 */     dst[13] = -dst[4];
/*  92 */     dst[22] = tmp0 + tmp1; dst[31] = tmp0 + tmp1;
/*     */   }
/*     */ 
/*     */   
/*     */   static void threeShort(float[] src, float[] dst) {
/*  97 */     Arrays.fill(dst, 0.0F);
/*     */     
/*  99 */     for (int i = 0, outOff = 0; i < 3; i++, outOff += 6) {
/* 100 */       imdct12(src, dst, outOff, i);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private static void imdct12(float[] src, float[] dst, int outOff, int wndIdx) {
/* 107 */     for (int j = 15 + wndIdx, k = 12 + wndIdx; j >= 3 + wndIdx; j -= 3, k -= 3) {
/* 108 */       src[j] = src[j] + src[k];
/*     */     }
/* 110 */     src[15 + wndIdx] = src[15 + wndIdx] + src[9 + wndIdx];
/* 111 */     src[9 + wndIdx] = src[9 + wndIdx] + src[3 + wndIdx];
/*     */     
/* 113 */     float pp2 = src[12 + wndIdx] * 0.5F;
/* 114 */     float pp1 = src[6 + wndIdx] * 0.8660254F;
/* 115 */     float sum = src[0 + wndIdx] + pp2;
/* 116 */     tmp[1] = src[wndIdx] - src[12 + wndIdx];
/* 117 */     tmp[0] = sum + pp1;
/* 118 */     tmp[2] = sum - pp1;
/*     */     
/* 120 */     pp2 = src[15 + wndIdx] * 0.5F;
/* 121 */     pp1 = src[9 + wndIdx] * 0.8660254F;
/* 122 */     sum = src[3 + wndIdx] + pp2;
/* 123 */     tmp[4] = src[3 + wndIdx] - src[15 + wndIdx];
/* 124 */     tmp[5] = sum + pp1;
/* 125 */     tmp[3] = sum - pp1;
/*     */     
/* 127 */     tmp[3] = tmp[3] * 1.9318516F;
/* 128 */     tmp[4] = tmp[4] * 0.70710677F;
/* 129 */     tmp[5] = tmp[5] * 0.5176381F;
/*     */     
/* 131 */     float t = tmp[0];
/* 132 */     tmp[0] = tmp[0] + tmp[5];
/* 133 */     tmp[5] = t - tmp[5];
/*     */     
/* 135 */     t = tmp[1];
/* 136 */     tmp[1] = tmp[1] + tmp[4];
/* 137 */     tmp[4] = t - tmp[4];
/*     */     
/* 139 */     t = tmp[2];
/* 140 */     tmp[2] = tmp[2] + tmp[3];
/* 141 */     tmp[3] = t - tmp[3];
/*     */     
/* 143 */     for (int m = 0; m < 6; m++) {
/* 144 */       tmp[m] = tmp[m] * factor12[m];
/*     */     }
/* 146 */     tmp[8] = -tmp[0] * 0.7933533F;
/* 147 */     tmp[9] = -tmp[0] * 0.6087614F;
/* 148 */     tmp[7] = -tmp[1] * 0.9238795F;
/* 149 */     tmp[10] = -tmp[1] * 0.38268343F;
/* 150 */     tmp[6] = -tmp[2] * 0.9914449F;
/* 151 */     tmp[11] = -tmp[2] * 0.13052619F;
/*     */     
/* 153 */     tmp[0] = tmp[3];
/* 154 */     tmp[1] = tmp[4] * 0.38268343F;
/* 155 */     tmp[2] = tmp[5] * 0.6087614F;
/*     */     
/* 157 */     tmp[3] = -tmp[5] * 0.7933533F;
/* 158 */     tmp[4] = -tmp[4] * 0.9238795F;
/* 159 */     tmp[5] = -tmp[0] * 0.9914449F;
/*     */     
/* 161 */     tmp[0] = tmp[0] * 0.13052619F;
/*     */     
/* 163 */     for (int i = 0, n = outOff + 6; i < 12; i++, n++)
/* 164 */       dst[n] = dst[n] + tmp[i]; 
/*     */   }
/*     */ }


/* Location:              C:\Users\rapha\Downloads\aurora.jar!\META-INF\jars\jcodec-0.2.5.jar!\org\jcodec\codecs\mpa\Mp3Mdct.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */