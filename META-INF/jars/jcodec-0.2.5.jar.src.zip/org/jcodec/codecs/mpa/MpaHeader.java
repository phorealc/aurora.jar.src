/*     */ package org.jcodec.codecs.mpa;
/*     */ 
/*     */ import java.nio.ByteBuffer;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ class MpaHeader
/*     */ {
/*     */   int layer;
/*     */   int protectionBit;
/*     */   int bitrateIndex;
/*     */   int paddingBit;
/*     */   int modeExtension;
/*     */   int version;
/*     */   int mode;
/*     */   int sampleFreq;
/*     */   int numSubbands;
/*     */   int intensityStereoBound;
/*     */   boolean copyright;
/*     */   boolean original;
/*     */   int framesize;
/*     */   int frameBytes;
/*     */   
/*     */   static MpaHeader read_header(ByteBuffer bb) {
/*  43 */     MpaHeader ret = new MpaHeader();
/*     */ 
/*     */     
/*  46 */     int headerstring = bb.getInt();
/*  47 */     ret.version = headerstring >>> 19 & 0x1;
/*  48 */     if ((headerstring >>> 20 & 0x1) == 0)
/*  49 */       if (ret.version == 0) {
/*  50 */         ret.version = 2;
/*     */       } else {
/*  52 */         throw new RuntimeException("UNKNOWN_ERROR");
/*  53 */       }   if ((ret.sampleFreq = headerstring >>> 10 & 0x3) == 3) {
/*  54 */       throw new RuntimeException("UNKNOWN_ERROR");
/*     */     }
/*  56 */     ret.layer = 4 - (headerstring >>> 17) & 0x3;
/*  57 */     ret.protectionBit = headerstring >>> 16 & 0x1;
/*  58 */     ret.bitrateIndex = headerstring >>> 12 & 0xF;
/*  59 */     ret.paddingBit = headerstring >>> 9 & 0x1;
/*  60 */     ret.mode = headerstring >>> 6 & 0x3;
/*  61 */     ret.modeExtension = headerstring >>> 4 & 0x3;
/*  62 */     if (ret.mode == 1) {
/*  63 */       ret.intensityStereoBound = (ret.modeExtension << 2) + 4;
/*     */     } else {
/*  65 */       ret.intensityStereoBound = 0;
/*  66 */     }  if ((headerstring >>> 3 & 0x1) == 1)
/*  67 */       ret.copyright = true; 
/*  68 */     if ((headerstring >>> 2 & 0x1) == 1)
/*  69 */       ret.original = true; 
/*  70 */     if (ret.layer == 1) {
/*  71 */       ret.numSubbands = 32;
/*     */     } else {
/*  73 */       int channel_bitrate = ret.bitrateIndex;
/*  74 */       if (ret.mode != 3)
/*  75 */         if (channel_bitrate == 4) {
/*  76 */           channel_bitrate = 1;
/*     */         } else {
/*  78 */           channel_bitrate -= 4;
/*  79 */         }   if (channel_bitrate == 1 || channel_bitrate == 2) {
/*  80 */         if (ret.sampleFreq == 2)
/*  81 */         { ret.numSubbands = 12; }
/*     */         else
/*  83 */         { ret.numSubbands = 8; } 
/*  84 */       } else if (ret.sampleFreq == 1 || (channel_bitrate >= 3 && channel_bitrate <= 5)) {
/*  85 */         ret.numSubbands = 27;
/*     */       } else {
/*  87 */         ret.numSubbands = 30;
/*     */       } 
/*  89 */     }  if (ret.intensityStereoBound > ret.numSubbands)
/*  90 */       ret.intensityStereoBound = ret.numSubbands; 
/*  91 */     calculateFramesize(ret);
/*     */     
/*  93 */     return ret;
/*     */   }
/*     */   
/*     */   public static void calculateFramesize(MpaHeader ret) {
/*  97 */     if (ret.layer == 1) {
/*  98 */       ret.framesize = 12 * MpaConst.bitrates[ret.version][0][ret.bitrateIndex] / MpaConst.frequencies[ret.version][ret.sampleFreq];
/*     */       
/* 100 */       if (ret.paddingBit != 0)
/* 101 */         ret.framesize++; 
/* 102 */       ret.framesize <<= 2;
/* 103 */       ret.frameBytes = 0;
/*     */     } else {
/* 105 */       ret.framesize = 144 * MpaConst.bitrates[ret.version][ret.layer - 1][ret.bitrateIndex] / MpaConst.frequencies[ret.version][ret.sampleFreq];
/*     */       
/* 107 */       if (ret.version == 0 || ret.version == 2)
/* 108 */         ret.framesize >>= 1; 
/* 109 */       if (ret.paddingBit != 0)
/* 110 */         ret.framesize++; 
/* 111 */       if (ret.layer == 3) {
/* 112 */         if (ret.version == 1) {
/* 113 */           ret.frameBytes = ret.framesize - ((ret.mode == 3) ? 17 : 32) - ((ret.protectionBit != 0) ? 0 : 2) - 4;
/*     */         } else {
/*     */           
/* 116 */           ret.frameBytes = ret.framesize - ((ret.mode == 3) ? 9 : 17) - ((ret.protectionBit != 0) ? 0 : 2) - 4;
/*     */         } 
/*     */       } else {
/*     */         
/* 120 */         ret.frameBytes = 0;
/*     */       } 
/*     */     } 
/* 123 */     ret.framesize -= 4;
/*     */   }
/*     */ }


/* Location:              C:\Users\rapha\Downloads\aurora.jar!\META-INF\jars\jcodec-0.2.5.jar!\org\jcodec\codecs\mpa\MpaHeader.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */