/*     */ package org.jcodec.codecs.mpa;
/*     */ 
/*     */ import org.jcodec.common.tools.MathUtil;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class MpaPqmf
/*     */ {
/*     */   private static final double MY_PI = 3.141592653589793D;
/*  16 */   private static final float cos1_64 = (float)(1.0D / 2.0D * Math.cos(0.04908738521234052D));
/*  17 */   private static final float cos3_64 = (float)(1.0D / 2.0D * Math.cos(0.14726215563702155D));
/*  18 */   private static final float cos5_64 = (float)(1.0D / 2.0D * Math.cos(0.2454369260617026D));
/*  19 */   private static final float cos7_64 = (float)(1.0D / 2.0D * Math.cos(0.3436116964863836D));
/*  20 */   private static final float cos9_64 = (float)(1.0D / 2.0D * Math.cos(0.44178646691106466D));
/*  21 */   private static final float cos11_64 = (float)(1.0D / 2.0D * Math.cos(0.5399612373357456D));
/*  22 */   private static final float cos13_64 = (float)(1.0D / 2.0D * Math.cos(0.6381360077604268D));
/*  23 */   private static final float cos15_64 = (float)(1.0D / 2.0D * Math.cos(0.7363107781851077D));
/*  24 */   private static final float cos17_64 = (float)(1.0D / 2.0D * Math.cos(0.8344855486097889D));
/*  25 */   private static final float cos19_64 = (float)(1.0D / 2.0D * Math.cos(0.9326603190344698D));
/*  26 */   private static final float cos21_64 = (float)(1.0D / 2.0D * Math.cos(1.030835089459151D));
/*  27 */   private static final float cos23_64 = (float)(1.0D / 2.0D * Math.cos(1.1290098598838318D));
/*  28 */   private static final float cos25_64 = (float)(1.0D / 2.0D * Math.cos(1.227184630308513D));
/*  29 */   private static final float cos27_64 = (float)(1.0D / 2.0D * Math.cos(1.325359400733194D));
/*  30 */   private static final float cos29_64 = (float)(1.0D / 2.0D * Math.cos(1.423534171157875D));
/*  31 */   private static final float cos31_64 = (float)(1.0D / 2.0D * Math.cos(1.521708941582556D));
/*  32 */   private static final float cos1_32 = (float)(1.0D / 2.0D * Math.cos(0.09817477042468103D));
/*  33 */   private static final float cos3_32 = (float)(1.0D / 2.0D * Math.cos(0.2945243112740431D));
/*  34 */   private static final float cos5_32 = (float)(1.0D / 2.0D * Math.cos(0.4908738521234052D));
/*  35 */   private static final float cos7_32 = (float)(1.0D / 2.0D * Math.cos(0.6872233929727672D));
/*  36 */   private static final float cos9_32 = (float)(1.0D / 2.0D * Math.cos(0.8835729338221293D));
/*  37 */   private static final float cos11_32 = (float)(1.0D / 2.0D * Math.cos(1.0799224746714913D));
/*  38 */   private static final float cos13_32 = (float)(1.0D / 2.0D * Math.cos(1.2762720155208536D));
/*  39 */   private static final float cos15_32 = (float)(1.0D / 2.0D * Math.cos(1.4726215563702154D));
/*  40 */   private static final float cos1_16 = (float)(1.0D / 2.0D * Math.cos(0.19634954084936207D));
/*  41 */   private static final float cos3_16 = (float)(1.0D / 2.0D * Math.cos(0.5890486225480862D));
/*  42 */   private static final float cos5_16 = (float)(1.0D / 2.0D * Math.cos(0.9817477042468103D));
/*  43 */   private static final float cos7_16 = (float)(1.0D / 2.0D * Math.cos(1.3744467859455345D));
/*  44 */   private static final float cos1_8 = (float)(1.0D / 2.0D * Math.cos(0.39269908169872414D));
/*  45 */   private static final float cos3_8 = (float)(1.0D / 2.0D * Math.cos(1.1780972450961724D));
/*  46 */   private static final float cos1_4 = (float)(1.0D / 2.0D * Math.cos(0.7853981633974483D));
/*     */   
/*  48 */   private static final float[] bf32 = new float[] { cos1_64, cos3_64, cos5_64, cos7_64, cos9_64, cos11_64, cos13_64, cos15_64, cos17_64, cos19_64, cos21_64, cos23_64, cos25_64, cos27_64, cos29_64, cos31_64 };
/*     */ 
/*     */   
/*  51 */   private static final float[] bf16 = new float[] { cos1_32, cos3_32, cos5_32, cos7_32, cos9_32, cos11_32, cos13_32, cos15_32 };
/*     */   
/*  53 */   private static final float[] bf8 = new float[] { cos1_16, cos3_16, cos5_16, cos7_16 };
/*     */   
/*     */   static void computeFilter(int sampleOff, float[] samples, short[] out, int outOff, float scalefactor) {
/*  56 */     int dvp = 0;
/*  57 */     for (int i = 0; i < 32; i++) {
/*     */       
/*  59 */       int b = i << 4;
/*  60 */       float pcm_sample = (samples[(16 + sampleOff & 0xF) + dvp] * MpaConst.dp[b + 0] + samples[(15 + sampleOff & 0xF) + dvp] * MpaConst.dp[b + 1] + samples[(14 + sampleOff & 0xF) + dvp] * MpaConst.dp[b + 2] + samples[(13 + sampleOff & 0xF) + dvp] * MpaConst.dp[b + 3] + samples[(12 + sampleOff & 0xF) + dvp] * MpaConst.dp[b + 4] + samples[(11 + sampleOff & 0xF) + dvp] * MpaConst.dp[b + 5] + samples[(10 + sampleOff & 0xF) + dvp] * MpaConst.dp[b + 6] + samples[(9 + sampleOff & 0xF) + dvp] * MpaConst.dp[b + 7] + samples[(8 + sampleOff & 0xF) + dvp] * MpaConst.dp[b + 8] + samples[(7 + sampleOff & 0xF) + dvp] * MpaConst.dp[b + 9] + samples[(6 + sampleOff & 0xF) + dvp] * MpaConst.dp[b + 10] + samples[(5 + sampleOff & 0xF) + dvp] * MpaConst.dp[b + 11] + samples[(4 + sampleOff & 0xF) + dvp] * MpaConst.dp[b + 12] + samples[(3 + sampleOff & 0xF) + dvp] * MpaConst.dp[b + 13] + samples[(2 + sampleOff & 0xF) + dvp] * MpaConst.dp[b + 14] + samples[(1 + sampleOff & 0xF) + dvp] * MpaConst.dp[b + 15]) * scalefactor;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/*  79 */       out[outOff + i] = (short)MathUtil.clip((int)pcm_sample, -32768, 32767);
/*  80 */       dvp += 16;
/*     */     } 
/*     */   }
/*     */   
/*     */   static void computeButterfly(int pos, float[] s) {
/*  85 */     butterfly32(s);
/*     */     
/*  87 */     butterfly16L(s);
/*  88 */     butterfly16H(s);
/*     */     
/*  90 */     butterfly8L(s, 0);
/*  91 */     butterfly8H(s, 0);
/*  92 */     butterfly8L(s, 16);
/*  93 */     butterfly8H(s, 16);
/*     */     int i;
/*  95 */     for (i = 0; i < 32; i += 8) {
/*  96 */       butterfly4L(s, i);
/*  97 */       butterfly4H(s, i);
/*     */     } 
/*     */     
/* 100 */     for (i = 0; i < 32; i += 4) {
/* 101 */       butterfly2L(s, i);
/* 102 */       butterfly2H(s, i);
/*     */     } 
/*     */     
/* 105 */     float k0 = -s[14] - s[15] - s[10] - s[11];
/* 106 */     float k1 = s[29] + s[31] + s[25];
/* 107 */     float k2 = k1 + s[17];
/* 108 */     float k3 = k1 + s[21] + s[23];
/* 109 */     float k4 = s[15] + s[11];
/* 110 */     float k5 = s[15] + s[13] + s[9];
/* 111 */     float k6 = s[7] + s[5];
/* 112 */     float k7 = s[31] + s[23];
/* 113 */     float k8 = k7 + s[27];
/* 114 */     float k9 = s[31] + s[27] + s[19];
/* 115 */     float k10 = -s[26] - s[27] - s[30] - s[31];
/* 116 */     float k11 = -s[24] - s[28] - s[30] - s[31];
/* 117 */     float k12 = s[20] + s[22] + s[23];
/* 118 */     float k13 = s[21] + s[29];
/*     */     
/* 120 */     float s0 = s[0];
/* 121 */     float s1 = s[1];
/* 122 */     float s2 = s[2];
/* 123 */     float s3 = s[3];
/* 124 */     float s4 = s[4];
/* 125 */     float s6 = s[6];
/* 126 */     float s7 = s[7];
/* 127 */     float s8 = s[8];
/* 128 */     float s12 = s[12];
/* 129 */     float s13 = s[13];
/* 130 */     float s14 = s[14];
/* 131 */     float s15 = s[15];
/* 132 */     float s16 = s[16];
/* 133 */     float s18 = s[18];
/* 134 */     float s19 = s[19];
/* 135 */     float s21 = s[21];
/* 136 */     float s22 = s[22];
/* 137 */     float s23 = s[23];
/* 138 */     float s28 = s[28];
/* 139 */     float s29 = s[29];
/* 140 */     float s30 = s[30];
/* 141 */     float s31 = s[31];
/*     */     
/* 143 */     s[0] = s1;
/* 144 */     s[1] = k2;
/* 145 */     s[2] = k5;
/* 146 */     s[3] = k3;
/* 147 */     s[4] = k6;
/* 148 */     s[5] = k8 + k13;
/* 149 */     s[6] = k4 + s13;
/* 150 */     s[7] = k9 + s29;
/* 151 */     s[8] = s3;
/* 152 */     s[9] = k9;
/* 153 */     s[10] = k4;
/* 154 */     s[11] = k8;
/* 155 */     s[12] = s7;
/* 156 */     s[13] = k7;
/* 157 */     s[14] = s15;
/* 158 */     s[15] = s31;
/* 159 */     s[16] = -k2 - s30;
/* 160 */     s[17] = -k5 - s14;
/* 161 */     s[18] = -k3 - s22 - s30;
/* 162 */     s[19] = -k6 - s6;
/* 163 */     s[20] = k10 - s29 - s21 - s22 - s23;
/* 164 */     s[21] = k0 - s13;
/* 165 */     s[22] = k10 - s29 - s18 - s19;
/* 166 */     s[23] = -s3 - s2;
/* 167 */     s[24] = k10 - s28 - s18 - s19;
/* 168 */     s[25] = k0 - s12;
/* 169 */     s[26] = k10 - s28 - k12;
/* 170 */     s[27] = -s6 - s7 - s4;
/* 171 */     s[28] = k11 - k12;
/* 172 */     s[29] = -s14 - s15 - s12 - s8;
/* 173 */     s[30] = k11 - s16;
/* 174 */     s[31] = -s0;
/*     */   }
/*     */   
/*     */   private static void butterfly16H(float[] s) {
/* 178 */     for (int i = 0; i < 8; i++) {
/* 179 */       float tmp0 = s[16 + i];
/* 180 */       float tmp1 = s[31 - i];
/* 181 */       s[16 + i] = tmp0 + tmp1;
/* 182 */       s[31 - i] = -(tmp0 - tmp1) * bf16[i];
/*     */     } 
/*     */   }
/*     */   
/*     */   private static void butterfly16L(float[] s) {
/* 187 */     for (int i = 0; i < 8; i++) {
/* 188 */       float tmp0 = s[i];
/* 189 */       float tmp1 = s[15 - i];
/* 190 */       s[i] = tmp0 + tmp1;
/* 191 */       s[15 - i] = (tmp0 - tmp1) * bf16[i];
/*     */     } 
/*     */   }
/*     */   
/*     */   private static void butterfly8H(float[] s, int o) {
/* 196 */     for (int i = 0; i < 4; i++) {
/* 197 */       float tmp0 = s[o + 8 + i];
/* 198 */       float tmp1 = s[o + 15 - i];
/* 199 */       s[o + 8 + i] = tmp0 + tmp1;
/* 200 */       s[o + 15 - i] = -(tmp0 - tmp1) * bf8[i];
/*     */     } 
/*     */   }
/*     */   
/*     */   private static void butterfly8L(float[] s, int o) {
/* 205 */     for (int i = 0; i < 4; i++) {
/* 206 */       float tmp0 = s[o + i];
/* 207 */       float tmp1 = s[o + 7 - i];
/* 208 */       s[o + i] = tmp0 + tmp1;
/* 209 */       s[o + 7 - i] = (tmp0 - tmp1) * bf8[i];
/*     */     } 
/*     */   }
/*     */   
/*     */   private static void butterfly4H(float[] s, int o) {
/* 214 */     float tmp0 = s[o + 4];
/* 215 */     float tmp1 = s[o + 7];
/* 216 */     s[o + 4] = tmp0 + tmp1;
/* 217 */     s[o + 7] = -(tmp0 - tmp1) * cos1_8;
/*     */     
/* 219 */     float tmp2 = s[o + 5];
/* 220 */     float tmp3 = s[o + 6];
/* 221 */     s[o + 5] = tmp2 + tmp3;
/* 222 */     s[o + 6] = -(tmp2 - tmp3) * cos3_8;
/*     */   }
/*     */   
/*     */   private static void butterfly4L(float[] s, int o) {
/* 226 */     float tmp0 = s[o];
/* 227 */     float tmp1 = s[o + 3];
/* 228 */     s[o + 0] = tmp0 + tmp1;
/* 229 */     s[o + 3] = (tmp0 - tmp1) * cos1_8;
/*     */     
/* 231 */     float tmp2 = s[o + 1];
/* 232 */     float tmp3 = s[o + 2];
/* 233 */     s[o + 1] = tmp2 + tmp3;
/* 234 */     s[o + 2] = (tmp2 - tmp3) * cos3_8;
/*     */   }
/*     */   
/*     */   private static void butterfly2H(float[] s, int o) {
/* 238 */     float tmp0 = s[o + 2];
/* 239 */     float tmp1 = s[o + 3];
/* 240 */     s[o + 2] = tmp0 + tmp1;
/* 241 */     s[o + 3] = -(tmp0 - tmp1) * cos1_4;
/*     */   }
/*     */   
/*     */   private static void butterfly2L(float[] s, int o) {
/* 245 */     float tmp0 = s[o];
/* 246 */     float tmp1 = s[o + 1];
/* 247 */     s[o + 0] = tmp0 + tmp1;
/* 248 */     s[o + 1] = (tmp0 - tmp1) * cos1_4;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private static void butterfly32(float[] s) {
/* 254 */     for (int i = 0; i < 16; i++) {
/* 255 */       float tmp0 = s[i];
/* 256 */       float tmp1 = s[31 - i];
/* 257 */       s[i] = tmp0 + tmp1;
/* 258 */       s[31 - i] = (tmp0 - tmp1) * bf32[i];
/*     */     } 
/*     */   }
/*     */ }


/* Location:              C:\Users\rapha\Downloads\aurora.jar!\META-INF\jars\jcodec-0.2.5.jar!\org\jcodec\codecs\mpa\MpaPqmf.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */