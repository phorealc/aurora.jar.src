/*     */ package org.jcodec.codecs.mpa;
/*     */ 
/*     */ import java.nio.ByteBuffer;
/*     */ import org.jcodec.common.Vector2Int;
/*     */ import org.jcodec.common.Vector4Int;
/*     */ import org.jcodec.common.io.BitReader;
/*     */ import org.jcodec.common.tools.MathUtil;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class Mp3Bitstream
/*     */ {
/*     */   static class MP3SideInfo
/*     */   {
/*     */     int mainDataBegin;
/*     */     int privateBits;
/*  37 */     boolean[][] scfsi = new boolean[2][4];
/*  38 */     Mp3Bitstream.Granule[][] granule = new Mp3Bitstream.Granule[][] { { new Mp3Bitstream.Granule(), new Mp3Bitstream.Granule() }, { new Mp3Bitstream.Granule(), new Mp3Bitstream.Granule() } };
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   static class Granule
/*     */   {
/*     */     int part23Length;
/*     */     
/*     */     int bigValues;
/*     */     
/*     */     int globalGain;
/*     */     
/*     */     int scalefacCompress;
/*     */     
/*     */     boolean windowSwitchingFlag;
/*     */     
/*     */     int blockType;
/*     */     
/*     */     boolean mixedBlockFlag;
/*     */     
/*  59 */     int[] tableSelect = new int[3];
/*  60 */     int[] subblockGain = new int[3];
/*     */     int region0Count;
/*     */     int region1Count;
/*     */     boolean preflag;
/*     */     int scalefacScale;
/*     */     int count1tableSelect;
/*     */   }
/*     */   
/*     */   static class ScaleFactors {
/*  69 */     int[] large = new int[23];
/*  70 */     int[][] small = new int[3][13];
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   static MP3SideInfo readSideInfo(MpaHeader header, ByteBuffer src, int channels) {
/*  76 */     MP3SideInfo si = new MP3SideInfo();
/*  77 */     BitReader stream = BitReader.createBitReader(src);
/*  78 */     if (header.version == 1) {
/*     */       
/*  80 */       si.mainDataBegin = stream.readNBit(9);
/*  81 */       if (channels == 1) {
/*  82 */         si.privateBits = stream.readNBit(5);
/*     */       } else {
/*  84 */         si.privateBits = stream.readNBit(3);
/*     */       } 
/*  86 */       for (int ch = 0; ch < channels; ch++) {
/*  87 */         si.scfsi[ch][0] = (stream.read1Bit() == 0);
/*  88 */         si.scfsi[ch][1] = (stream.read1Bit() == 0);
/*  89 */         si.scfsi[ch][2] = (stream.read1Bit() == 0);
/*  90 */         si.scfsi[ch][3] = (stream.read1Bit() == 0);
/*     */       } 
/*     */       
/*  93 */       for (int gr = 0; gr < 2; gr++) {
/*  94 */         for (int i = 0; i < channels; i++) {
/*  95 */           Granule granule = si.granule[i][gr];
/*  96 */           granule.part23Length = stream.readNBit(12);
/*  97 */           granule.bigValues = stream.readNBit(9);
/*  98 */           granule.globalGain = stream.readNBit(8);
/*  99 */           granule.scalefacCompress = stream.readNBit(4);
/* 100 */           granule.windowSwitchingFlag = (stream.readNBit(1) != 0);
/* 101 */           if (granule.windowSwitchingFlag) {
/* 102 */             granule.blockType = stream.readNBit(2);
/* 103 */             granule.mixedBlockFlag = (stream.readNBit(1) != 0);
/*     */             
/* 105 */             granule.tableSelect[0] = stream.readNBit(5);
/* 106 */             granule.tableSelect[1] = stream.readNBit(5);
/*     */             
/* 108 */             granule.subblockGain[0] = stream.readNBit(3);
/* 109 */             granule.subblockGain[1] = stream.readNBit(3);
/* 110 */             granule.subblockGain[2] = stream.readNBit(3);
/*     */             
/* 112 */             if (granule.blockType == 0)
/* 113 */               return null; 
/* 114 */             if (granule.blockType == 2 && !granule.mixedBlockFlag) {
/* 115 */               granule.region0Count = 8;
/*     */             } else {
/* 117 */               granule.region0Count = 7;
/*     */             } 
/* 119 */             granule.region1Count = 20 - granule.region0Count;
/*     */           } else {
/* 121 */             granule.tableSelect[0] = stream.readNBit(5);
/* 122 */             granule.tableSelect[1] = stream.readNBit(5);
/* 123 */             granule.tableSelect[2] = stream.readNBit(5);
/* 124 */             granule.region0Count = stream.readNBit(4);
/* 125 */             granule.region1Count = stream.readNBit(3);
/* 126 */             granule.blockType = 0;
/*     */           } 
/* 128 */           granule.preflag = (stream.readNBit(1) != 0);
/* 129 */           granule.scalefacScale = stream.readNBit(1);
/* 130 */           granule.count1tableSelect = stream.readNBit(1);
/*     */         } 
/*     */       } 
/*     */     } else {
/*     */       
/* 135 */       si.mainDataBegin = stream.readNBit(8);
/* 136 */       if (channels == 1) {
/* 137 */         si.privateBits = stream.readNBit(1);
/*     */       } else {
/* 139 */         si.privateBits = stream.readNBit(2);
/*     */       } 
/* 141 */       for (int ch = 0; ch < channels; ch++) {
/* 142 */         Granule granule = si.granule[ch][0];
/* 143 */         granule.part23Length = stream.readNBit(12);
/* 144 */         granule.bigValues = stream.readNBit(9);
/* 145 */         granule.globalGain = stream.readNBit(8);
/* 146 */         granule.scalefacCompress = stream.readNBit(9);
/* 147 */         granule.windowSwitchingFlag = (stream.readNBit(1) != 0);
/*     */         
/* 149 */         if (granule.windowSwitchingFlag) {
/*     */           
/* 151 */           granule.blockType = stream.readNBit(2);
/* 152 */           granule.mixedBlockFlag = (stream.readNBit(1) != 0);
/* 153 */           granule.tableSelect[0] = stream.readNBit(5);
/* 154 */           granule.tableSelect[1] = stream.readNBit(5);
/*     */           
/* 156 */           granule.subblockGain[0] = stream.readNBit(3);
/* 157 */           granule.subblockGain[1] = stream.readNBit(3);
/* 158 */           granule.subblockGain[2] = stream.readNBit(3);
/*     */           
/* 160 */           if (granule.blockType == 0)
/* 161 */             return null; 
/* 162 */           if (granule.blockType == 2 && !granule.mixedBlockFlag) {
/* 163 */             granule.region0Count = 8;
/*     */           } else {
/* 165 */             granule.region0Count = 7;
/* 166 */             granule.region1Count = 20 - granule.region0Count;
/*     */           } 
/*     */         } else {
/*     */           
/* 170 */           granule.tableSelect[0] = stream.readNBit(5);
/* 171 */           granule.tableSelect[1] = stream.readNBit(5);
/* 172 */           granule.tableSelect[2] = stream.readNBit(5);
/* 173 */           granule.region0Count = stream.readNBit(4);
/* 174 */           granule.region1Count = stream.readNBit(3);
/* 175 */           granule.blockType = 0;
/*     */         } 
/*     */         
/* 178 */         granule.scalefacScale = stream.readNBit(1);
/* 179 */         granule.count1tableSelect = stream.readNBit(1);
/*     */       } 
/*     */     } 
/* 182 */     stream.terminate();
/* 183 */     return si;
/*     */   }
/*     */   
/*     */   static ScaleFactors readScaleFactors(BitReader br, Granule granule, boolean[] b) {
/* 187 */     if (granule.windowSwitchingFlag && granule.blockType == 2) {
/* 188 */       if (granule.mixedBlockFlag) {
/* 189 */         return readScaleFacMixed(br, granule);
/*     */       }
/* 191 */       return readScaleFacShort(br, granule);
/*     */     } 
/*     */     
/* 194 */     return readScaleFacNonSwitch(br, granule, b);
/*     */   }
/*     */ 
/*     */   
/*     */   private static ScaleFactors readScaleFacMixed(BitReader br, Granule granule) {
/* 199 */     ScaleFactors sf = new ScaleFactors(); int sfb;
/* 200 */     for (sfb = 0; sfb < 8; sfb++)
/* 201 */       sf.large[sfb] = br.readNBit(MpaConst.scaleFactorLen[0][granule.scalefacCompress]); 
/* 202 */     for (sfb = 3; sfb < 6; sfb++) {
/* 203 */       for (int i = 0; i < 3; i++)
/* 204 */         sf.small[i][sfb] = br.readNBit(MpaConst.scaleFactorLen[0][granule.scalefacCompress]); 
/* 205 */     }  for (sfb = 6; sfb < 12; sfb++) {
/* 206 */       for (int i = 0; i < 3; i++)
/* 207 */         sf.small[i][sfb] = br.readNBit(MpaConst.scaleFactorLen[1][granule.scalefacCompress]); 
/* 208 */     }  int window; for (sfb = 12, window = 0; window < 3; window++)
/* 209 */       sf.small[window][sfb] = 0; 
/* 210 */     return sf;
/*     */   }
/*     */   
/*     */   private static ScaleFactors readScaleFacNonSwitch(BitReader br, Granule granule, boolean[] b) {
/* 214 */     ScaleFactors sf = new ScaleFactors();
/* 215 */     int length0 = MpaConst.scaleFactorLen[0][granule.scalefacCompress];
/* 216 */     int length1 = MpaConst.scaleFactorLen[1][granule.scalefacCompress];
/* 217 */     if (b[0])
/* 218 */       for (int i = 0; i < 6; i++) {
/* 219 */         sf.large[i] = br.readNBit(length0);
/*     */       } 
/* 221 */     if (b[1])
/* 222 */       for (int i = 6; i < 11; i++) {
/* 223 */         sf.large[i] = br.readNBit(length0);
/*     */       } 
/* 225 */     if (b[2])
/* 226 */       for (int i = 11; i < 16; i++) {
/* 227 */         sf.large[i] = br.readNBit(length1);
/*     */       } 
/* 229 */     if (b[3])
/* 230 */       for (int i = 16; i < 21; i++) {
/* 231 */         sf.large[i] = br.readNBit(length1);
/*     */       } 
/* 233 */     sf.large[21] = 0;
/* 234 */     sf.large[22] = 0;
/* 235 */     return sf;
/*     */   }
/*     */   
/*     */   private static ScaleFactors readScaleFacShort(BitReader br, Granule granule) {
/* 239 */     ScaleFactors sf = new ScaleFactors();
/* 240 */     int length0 = MpaConst.scaleFactorLen[0][granule.scalefacCompress];
/* 241 */     int length1 = MpaConst.scaleFactorLen[1][granule.scalefacCompress]; int i;
/* 242 */     for (i = 0; i < 6; i++) {
/* 243 */       for (int j = 0; j < 3; j++)
/* 244 */         sf.small[j][i] = br.readNBit(length0); 
/*     */     } 
/* 246 */     for (i = 6; i < 12; i++) {
/* 247 */       for (int j = 0; j < 3; j++)
/* 248 */         sf.small[j][i] = br.readNBit(length1); 
/*     */     } 
/* 250 */     sf.small[0][12] = 0;
/* 251 */     sf.small[1][12] = 0;
/* 252 */     sf.small[2][12] = 0;
/* 253 */     return sf;
/*     */   }
/*     */   
/*     */   static ScaleFactors readLSFScaleFactors(BitReader br, MpaHeader header, Granule granule, int ch) {
/* 257 */     ScaleFactors scalefac = new ScaleFactors();
/* 258 */     int[] scalefacBuffer = readLSFScaleData(br, header, granule, ch);
/*     */     
/* 260 */     int m = 0;
/* 261 */     if (granule.windowSwitchingFlag && granule.blockType == 2) {
/* 262 */       if (granule.mixedBlockFlag) {
/* 263 */         int sfb; for (sfb = 0; sfb < 8; sfb++) {
/* 264 */           scalefac.large[sfb] = scalefacBuffer[m];
/* 265 */           m++;
/*     */         } 
/* 267 */         for (sfb = 3; sfb < 12; sfb++) {
/* 268 */           for (int i = 0; i < 3; i++) {
/* 269 */             scalefac.small[i][sfb] = scalefacBuffer[m];
/* 270 */             m++;
/*     */           } 
/*     */         } 
/* 273 */         for (int window = 0; window < 3; window++) {
/* 274 */           scalefac.small[window][12] = 0;
/*     */         }
/*     */       } else {
/* 277 */         for (int sfb = 0; sfb < 12; sfb++) {
/* 278 */           for (int i = 0; i < 3; i++) {
/* 279 */             scalefac.small[i][sfb] = scalefacBuffer[m];
/* 280 */             m++;
/*     */           } 
/*     */         } 
/*     */         
/* 284 */         for (int window = 0; window < 3; window++) {
/* 285 */           scalefac.small[window][12] = 0;
/*     */         }
/*     */       } 
/*     */     } else {
/* 289 */       for (int sfb = 0; sfb < 21; sfb++) {
/* 290 */         scalefac.large[sfb] = scalefacBuffer[m];
/* 291 */         m++;
/*     */       } 
/* 293 */       scalefac.large[21] = 0;
/* 294 */       scalefac.large[22] = 0;
/*     */     } 
/* 296 */     return scalefac;
/*     */   }
/*     */   
/*     */   private static int[] readLSFScaleData(BitReader br, MpaHeader header, Granule granule, int ch) {
/* 300 */     int[] result = new int[54];
/* 301 */     int[] scaleFacLen = new int[4];
/*     */     
/* 303 */     int comp = granule.scalefacCompress;
/*     */     
/* 305 */     int blockType = (granule.blockType == 2) ? (granule.mixedBlockFlag ? 2 : 1) : 0;
/*     */     
/* 307 */     boolean ch1 = ((header.modeExtension == 1 || header.modeExtension == 3) && ch == 1);
/* 308 */     int lenType = 0;
/* 309 */     if (!ch1) {
/* 310 */       if (comp < 400) {
/* 311 */         scaleFacLen[0] = (comp >>> 4) / 5;
/* 312 */         scaleFacLen[1] = (comp >>> 4) % 5;
/* 313 */         scaleFacLen[2] = (comp & 0xF) >>> 2;
/* 314 */         scaleFacLen[3] = comp & 0x3;
/* 315 */         granule.preflag = false;
/* 316 */         lenType = 0;
/* 317 */       } else if (comp < 500) {
/* 318 */         scaleFacLen[0] = (comp - 400 >>> 2) / 5;
/* 319 */         scaleFacLen[1] = (comp - 400 >>> 2) % 5;
/* 320 */         scaleFacLen[2] = comp - 400 & 0x3;
/* 321 */         scaleFacLen[3] = 0;
/* 322 */         granule.preflag = false;
/* 323 */         lenType = 1;
/*     */       }
/* 325 */       else if (comp < 512) {
/* 326 */         scaleFacLen[0] = (comp - 500) / 3;
/* 327 */         scaleFacLen[1] = (comp - 500) % 3;
/* 328 */         scaleFacLen[2] = 0;
/* 329 */         scaleFacLen[3] = 0;
/* 330 */         granule.preflag = true;
/* 331 */         lenType = 2;
/*     */       } 
/*     */     } else {
/* 334 */       int halfComp = comp >>> 1;
/*     */       
/* 336 */       if (halfComp < 180) {
/* 337 */         scaleFacLen[0] = halfComp / 36;
/* 338 */         scaleFacLen[1] = halfComp % 36 / 6;
/* 339 */         scaleFacLen[2] = halfComp % 36 % 6;
/* 340 */         scaleFacLen[3] = 0;
/* 341 */         granule.preflag = false;
/* 342 */         lenType = 3;
/* 343 */       } else if (halfComp < 244) {
/* 344 */         scaleFacLen[0] = (halfComp - 180 & 0x3F) >>> 4;
/* 345 */         scaleFacLen[1] = (halfComp - 180 & 0xF) >>> 2;
/* 346 */         scaleFacLen[2] = halfComp - 180 & 0x3;
/* 347 */         scaleFacLen[3] = 0;
/* 348 */         granule.preflag = false;
/* 349 */         lenType = 4;
/* 350 */       } else if (halfComp < 255) {
/* 351 */         scaleFacLen[0] = (halfComp - 244) / 3;
/* 352 */         scaleFacLen[1] = (halfComp - 244) % 3;
/* 353 */         scaleFacLen[2] = 0;
/* 354 */         scaleFacLen[3] = 0;
/* 355 */         granule.preflag = false;
/* 356 */         lenType = 5;
/*     */       } 
/*     */     } 
/*     */     
/* 360 */     for (int i = 0, m = 0; i < 4; i++) {
/* 361 */       for (int j = 0; j < MpaConst.numberOfScaleFactors[lenType][blockType][i]; j++, m++) {
/* 362 */         result[m] = (scaleFacLen[i] == 0) ? 0 : br.readNBit(scaleFacLen[i]);
/*     */       }
/*     */     } 
/*     */     
/* 366 */     return result;
/*     */   }
/*     */   
/*     */   static int readCoeffs(BitReader br, Granule granule, int ch, int part2_start, int sfreq, int[] out) {
/* 370 */     int part23End = part2_start + granule.part23Length;
/* 371 */     int region1Start = (sfreq == 8) ? 72 : 36;
/* 372 */     int region2Start = 576;
/*     */     
/* 374 */     if (!granule.windowSwitchingFlag || granule.blockType != 2) {
/* 375 */       int region1StartIdx = MathUtil.clip(granule.region0Count + granule.region1Count + 2, 0, (MpaConst.sfbLong[sfreq]).length - 1);
/*     */ 
/*     */       
/* 378 */       region1Start = MpaConst.sfbLong[sfreq][granule.region0Count + 1];
/* 379 */       region2Start = MpaConst.sfbLong[sfreq][region1StartIdx];
/*     */     } 
/*     */     
/* 382 */     int index = 0;
/* 383 */     for (int i = 0; i < granule.bigValues << 1; i += 2) {
/* 384 */       int tab = 0;
/* 385 */       if (i < region1Start) {
/* 386 */         tab = granule.tableSelect[0];
/* 387 */       } else if (i < region2Start) {
/* 388 */         tab = granule.tableSelect[1];
/*     */       } else {
/* 390 */         tab = granule.tableSelect[2];
/* 391 */       }  if (tab == 0 || tab == 4 || tab == 14) {
/* 392 */         out[index++] = 0;
/* 393 */         out[index++] = 0;
/*     */       } else {
/* 395 */         int packed = readBigVal(tab, br);
/* 396 */         out[index++] = Vector2Int.el16_0(packed);
/* 397 */         out[index++] = Vector2Int.el16_1(packed);
/*     */       } 
/*     */     } 
/*     */     
/* 401 */     while (br.position() < part23End && index < 576) {
/*     */       
/* 403 */       int packed = readCount1(granule.count1tableSelect, br);
/*     */       
/* 405 */       out[index++] = Vector4Int.el8_0(packed);
/* 406 */       out[index++] = Vector4Int.el8_1(packed);
/* 407 */       out[index++] = Vector4Int.el8_2(packed);
/* 408 */       out[index++] = Vector4Int.el8_3(packed);
/*     */     } 
/*     */     
/* 411 */     if (br.position() < part23End) {
/* 412 */       br.readNBit(part23End - br.position());
/*     */     }
/* 414 */     return MathUtil.clip(index, 0, 576);
/*     */   }
/*     */   
/*     */   static int readBigVal(int tab, BitReader br) {
/* 418 */     int res = MpaConst.bigValVlc[tab].readVLC(br);
/* 419 */     int x = res >>> 4;
/* 420 */     int y = res & 0xF;
/*     */     
/* 422 */     if (MpaConst.bigValEscBits[tab] != 0 && 
/* 423 */       MpaConst.bigValMaxval[tab] - 1 == x)
/* 424 */       x += br.readNBit(MpaConst.bigValEscBits[tab]); 
/* 425 */     if (x != 0 && 
/* 426 */       br.read1Bit() != 0)
/* 427 */       x = -x; 
/* 428 */     if (MpaConst.bigValEscBits[tab] != 0 && 
/* 429 */       MpaConst.bigValMaxval[tab] - 1 == y)
/* 430 */       y += br.readNBit(MpaConst.bigValEscBits[tab]); 
/* 431 */     if (y != 0 && 
/* 432 */       br.read1Bit() != 0)
/* 433 */       y = -y; 
/* 434 */     return Vector2Int.pack16(x, y);
/*     */   }
/*     */   
/*     */   static int readCount1(int tab, BitReader br) {
/* 438 */     int res = ((tab == 0) ? MpaConst.cnt1A : MpaConst.cnt1B).readVLC(br);
/*     */     
/* 440 */     int v = res >> 3 & 0x1;
/* 441 */     int w = res >> 2 & 0x1;
/* 442 */     int x = res >> 1 & 0x1;
/* 443 */     int y = res & 0x1;
/*     */     
/* 445 */     if (v != 0 && 
/* 446 */       br.read1Bit() != 0)
/* 447 */       v = -v; 
/* 448 */     if (w != 0 && 
/* 449 */       br.read1Bit() != 0)
/* 450 */       w = -w; 
/* 451 */     if (x != 0 && 
/* 452 */       br.read1Bit() != 0)
/* 453 */       x = -x; 
/* 454 */     if (y != 0 && 
/* 455 */       br.read1Bit() != 0)
/* 456 */       y = -y; 
/* 457 */     return Vector4Int.pack8(v, w, x, y);
/*     */   }
/*     */ }


/* Location:              C:\Users\rapha\Downloads\aurora.jar!\META-INF\jars\jcodec-0.2.5.jar!\org\jcodec\codecs\mpa\Mp3Bitstream.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */