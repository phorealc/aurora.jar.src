/*     */ package org.jcodec.codecs.mpa;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.nio.ByteBuffer;
/*     */ import java.nio.ByteOrder;
/*     */ import java.util.Arrays;
/*     */ import org.jcodec.common.AudioCodecMeta;
/*     */ import org.jcodec.common.AudioDecoder;
/*     */ import org.jcodec.common.AudioFormat;
/*     */ import org.jcodec.common.io.BitReader;
/*     */ import org.jcodec.common.io.NIOUtils;
/*     */ import org.jcodec.common.model.AudioBuffer;
/*     */ import org.jcodec.common.tools.MathUtil;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class Mp3Decoder
/*     */   implements AudioDecoder
/*     */ {
/*  45 */   private static final boolean[] ALL_TRUE = new boolean[] { true, true, true, true };
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static final int SAMPLES_PER_BAND = 18;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static final int NUM_BANDS = 32;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private boolean initialized;
/*     */ 
/*     */ 
/*     */   
/*     */   private static final double fourByThree = 1.3333333333333333D;
/*     */ 
/*     */ 
/*     */   
/*  68 */   private ChannelSynthesizer[] filter = new ChannelSynthesizer[] { null, null }; private float[][] prevBlk;
/*  69 */   private ByteBuffer frameData = ByteBuffer.allocate(4096); private int channels;
/*  70 */   private float[] samples = new float[32]; private int sfreq;
/*  71 */   private float[] mdctIn = new float[18];
/*  72 */   private float[] mdctOut = new float[36];
/*  73 */   private float[][] dequant = new float[2][576];
/*  74 */   private short[][] tmpOut = new short[2][576];
/*     */ 
/*     */   
/*     */   private void init(MpaHeader header) {
/*  78 */     float scalefactor = 32700.0F;
/*     */     
/*  80 */     this.channels = (header.mode == 3) ? 1 : 2;
/*     */     
/*  82 */     this.filter[0] = new ChannelSynthesizer(0, scalefactor);
/*  83 */     if (this.channels == 2) {
/*  84 */       this.filter[1] = new ChannelSynthesizer(1, scalefactor);
/*     */     }
/*  86 */     this.prevBlk = new float[2][576];
/*     */     
/*  88 */     this.sfreq = header.sampleFreq + ((header.version == 1) ? 3 : ((header.version == 2) ? 6 : 0));
/*     */     
/*  90 */     for (int ch = 0; ch < 2; ch++) {
/*  91 */       Arrays.fill(this.prevBlk[ch], 0.0F);
/*     */     }
/*  93 */     this.initialized = true;
/*     */   }
/*     */ 
/*     */   
/*     */   private void decodeGranule(MpaHeader header, ByteBuffer output, Mp3Bitstream.MP3SideInfo si, BitReader br, Mp3Bitstream.ScaleFactors[] scalefac, int grInd) {
/*  98 */     Arrays.fill(this.dequant[0], 0.0F);
/*  99 */     Arrays.fill(this.dequant[1], 0.0F);
/*     */     
/* 101 */     for (int ch = 0; ch < this.channels; ch++) {
/* 102 */       int part2Start = br.position();
/*     */       
/* 104 */       Mp3Bitstream.Granule granule = si.granule[ch][grInd];
/* 105 */       if (header.version == 1) {
/* 106 */         Mp3Bitstream.ScaleFactors old = scalefac[ch];
/* 107 */         boolean[] scfi = (grInd == 0) ? ALL_TRUE : si.scfsi[ch];
/* 108 */         scalefac[ch] = Mp3Bitstream.readScaleFactors(br, si.granule[ch][grInd], scfi);
/* 109 */         mergeScaleFac(scalefac[ch], old, scfi);
/*     */       } else {
/* 111 */         scalefac[ch] = Mp3Bitstream.readLSFScaleFactors(br, header, granule, ch);
/*     */       } 
/*     */       
/* 114 */       int[] coeffs = new int[580];
/* 115 */       int nonzero = Mp3Bitstream.readCoeffs(br, granule, ch, part2Start, this.sfreq, coeffs);
/* 116 */       dequantizeCoeffs(coeffs, nonzero, granule, scalefac[ch], this.dequant[ch]);
/*     */     } 
/*     */     
/* 119 */     boolean msStereo = (header.mode == 1 && (header.modeExtension & 0x2) != 0);
/* 120 */     if (msStereo && this.channels == 2) {
/* 121 */       decodeMsStereo(header, si.granule[0][grInd], scalefac, this.dequant);
/*     */     }
/* 123 */     for (int i = 0; i < this.channels; i++) {
/* 124 */       float[] out = this.dequant[i];
/* 125 */       Mp3Bitstream.Granule granule = si.granule[i][grInd];
/*     */       
/* 127 */       antialias(granule, out);
/*     */       
/* 129 */       mdctDecode(i, granule, out);
/*     */       
/* 131 */       for (int sb18 = 18; sb18 < 576; sb18 += 36) {
/* 132 */         for (int j = 1; j < 18; j += 2) {
/* 133 */           out[sb18 + j] = -out[sb18 + j];
/*     */         }
/*     */       } 
/* 136 */       for (int ss = 0, off = 0; ss < 18; ss++, off += 32) {
/* 137 */         for (int j = 0, sb = 0; j < 576; j += 18, sb++) {
/* 138 */           this.samples[sb] = out[j + ss];
/*     */         }
/* 140 */         this.filter[i].synthesize(this.samples, this.tmpOut[i], off);
/*     */       } 
/*     */     } 
/*     */     
/* 144 */     if (this.channels == 2) {
/* 145 */       appendSamplesInterleave(output, this.tmpOut[0], this.tmpOut[1], 576);
/*     */     } else {
/* 147 */       appendSamples(output, this.tmpOut[0], 576);
/*     */     } 
/*     */   }
/*     */   
/*     */   public static void appendSamples(ByteBuffer buf, short[] f, int n) {
/* 152 */     for (int i = 0; i < n; i++) {
/* 153 */       buf.putShort(f[i]);
/*     */     }
/*     */   }
/*     */   
/*     */   public static void appendSamplesInterleave(ByteBuffer buf, short[] f0, short[] f1, int n) {
/* 158 */     for (int i = 0; i < n; i++) {
/* 159 */       buf.putShort(f0[i]);
/* 160 */       buf.putShort(f1[i]);
/*     */     } 
/*     */   }
/*     */   
/*     */   private void mergeScaleFac(Mp3Bitstream.ScaleFactors sf, Mp3Bitstream.ScaleFactors old, boolean[] scfsi) {
/* 165 */     if (!scfsi[0])
/* 166 */       for (int i = 0; i < 6; i++) {
/* 167 */         sf.large[i] = old.large[i];
/*     */       } 
/* 169 */     if (!scfsi[1])
/* 170 */       for (int i = 6; i < 11; i++) {
/* 171 */         sf.large[i] = old.large[i];
/*     */       } 
/* 173 */     if (!scfsi[2])
/* 174 */       for (int i = 11; i < 16; i++) {
/* 175 */         sf.large[i] = old.large[i];
/*     */       } 
/* 177 */     if (!scfsi[3])
/* 178 */       for (int i = 16; i < 21; i++) {
/* 179 */         sf.large[i] = old.large[i];
/*     */       } 
/*     */   }
/*     */   
/*     */   private void dequantizeCoeffs(int[] input, int nonzero, Mp3Bitstream.Granule granule, Mp3Bitstream.ScaleFactors scalefac, float[] out) {
/* 184 */     float globalGain = (float)Math.pow(2.0D, 0.25D * (granule.globalGain - 210.0D));
/*     */     
/* 186 */     if (granule.windowSwitchingFlag && granule.blockType == 2) {
/* 187 */       if (granule.mixedBlockFlag) {
/* 188 */         dequantMixed(input, nonzero, granule, scalefac, globalGain, out);
/*     */       } else {
/* 190 */         dequantShort(input, nonzero, granule, scalefac, globalGain, out);
/*     */       } 
/*     */     } else {
/* 193 */       dequantLong(input, nonzero, granule, scalefac, globalGain, out);
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   private void dequantMixed(int[] input, int nonzero, Mp3Bitstream.Granule granule, Mp3Bitstream.ScaleFactors scalefac, float globalGain, float[] out) {
/* 199 */     int i = 0; int sfb;
/* 200 */     for (sfb = 0; sfb < 8 && i < nonzero; sfb++) {
/* 201 */       for (; i < MpaConst.sfbLong[this.sfreq][sfb + 1] && i < nonzero; i++) {
/* 202 */         int idx = scalefac.large[sfb] + (granule.preflag ? MpaConst.pretab[sfb] : 0) << granule.scalefacScale;
/* 203 */         out[i] = globalGain * pow43(input[i]) * MpaConst.quantizerTab[idx];
/*     */       } 
/*     */     } 
/* 206 */     for (sfb = 3; sfb < 12 && i < nonzero; sfb++) {
/* 207 */       int sfbSz = MpaConst.sfbShort[this.sfreq][sfb + 1] - MpaConst.sfbShort[this.sfreq][sfb];
/* 208 */       int sfbStart = i;
/* 209 */       for (int wnd = 0; wnd < 3; wnd++) {
/* 210 */         for (int j = 0; j < sfbSz && i < nonzero; j++, i++) {
/* 211 */           int idx = (scalefac.small[wnd][sfb] << granule.scalefacScale) + (granule.subblockGain[wnd] << 2);
/*     */           
/* 213 */           out[sfbStart + j * 3 + wnd] = globalGain * pow43(input[i]) * MpaConst.quantizerTab[idx];
/*     */         } 
/*     */       } 
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   private void dequantShort(int[] input, int nonzero, Mp3Bitstream.Granule granule, Mp3Bitstream.ScaleFactors scalefac, float globalGain, float[] out) {
/* 221 */     for (int sfb = 0, i = 0; i < nonzero; sfb++) {
/* 222 */       int sfbSz = MpaConst.sfbShort[this.sfreq][sfb + 1] - MpaConst.sfbShort[this.sfreq][sfb];
/* 223 */       int sfbStart = i;
/* 224 */       for (int wnd = 0; wnd < 3; wnd++) {
/* 225 */         for (int j = 0; j < sfbSz && i < nonzero; j++, i++) {
/* 226 */           int idx = (scalefac.small[wnd][sfb] << granule.scalefacScale) + (granule.subblockGain[wnd] << 2);
/*     */           
/* 228 */           out[sfbStart + j * 3 + wnd] = globalGain * pow43(input[i]) * MpaConst.quantizerTab[idx];
/*     */         } 
/*     */       } 
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   private void dequantLong(int[] input, int nonzero, Mp3Bitstream.Granule granule, Mp3Bitstream.ScaleFactors scalefac, float globalGain, float[] out) {
/* 236 */     for (int i = 0, sfb = 0; i < nonzero; i++) {
/* 237 */       if (i == MpaConst.sfbLong[this.sfreq][sfb + 1]) {
/* 238 */         sfb++;
/*     */       }
/* 240 */       int idx = scalefac.large[sfb] + (granule.preflag ? MpaConst.pretab[sfb] : 0) << granule.scalefacScale;
/* 241 */       out[i] = globalGain * pow43(input[i]) * MpaConst.quantizerTab[idx];
/*     */     } 
/*     */   }
/*     */   
/*     */   private float pow43(int val) {
/* 246 */     if (val == 0) {
/* 247 */       return 0.0F;
/*     */     }
/* 249 */     int sign = 1 - (val >>> 31 << 1);
/* 250 */     int abs = MathUtil.abs(val);
/*     */     
/* 252 */     if (abs < MpaConst.power43Tab.length) {
/* 253 */       return sign * MpaConst.power43Tab[abs];
/*     */     }
/* 255 */     return sign * (float)Math.pow(abs, 1.3333333333333333D);
/*     */   }
/*     */ 
/*     */   
/*     */   private void decodeMsStereo(MpaHeader header, Mp3Bitstream.Granule granule, Mp3Bitstream.ScaleFactors[] scalefac, float[][] ro) {
/* 260 */     for (int i = 0; i < 576; i++) {
/* 261 */       float a = ro[0][i];
/* 262 */       float b = ro[1][i];
/* 263 */       ro[0][i] = (a + b) * 0.70710677F;
/* 264 */       ro[1][i] = (a - b) * 0.70710677F;
/*     */     } 
/*     */   }
/*     */   
/*     */   private void antialias(Mp3Bitstream.Granule granule, float[] out) {
/* 269 */     if (granule.windowSwitchingFlag && granule.blockType == 2 && !granule.mixedBlockFlag) {
/*     */       return;
/*     */     }
/* 272 */     int bands = (granule.windowSwitchingFlag && granule.mixedBlockFlag && granule.blockType == 2) ? 1 : 31;
/*     */     
/* 274 */     for (int band = 0, bandStart = 0; band < bands; band++, bandStart += 18) {
/* 275 */       for (int sample = 0; sample < 8; sample++) {
/* 276 */         int src_idx1 = bandStart + 17 - sample;
/* 277 */         int src_idx2 = bandStart + 18 + sample;
/* 278 */         float bu = out[src_idx1];
/* 279 */         float bd = out[src_idx2];
/* 280 */         out[src_idx1] = bu * MpaConst.cs[sample] - bd * MpaConst.ca[sample];
/* 281 */         out[src_idx2] = bd * MpaConst.cs[sample] + bu * MpaConst.ca[sample];
/*     */       } 
/*     */     } 
/*     */   }
/*     */   
/*     */   private void mdctDecode(int ch, Mp3Bitstream.Granule granule, float[] out) {
/* 287 */     for (int sb18 = 0; sb18 < 576; sb18 += 18) {
/* 288 */       int blockType = (granule.windowSwitchingFlag && granule.mixedBlockFlag && sb18 < 36) ? 0 : granule.blockType;
/*     */ 
/*     */       
/* 291 */       for (int cc = 0; cc < 18; cc++) {
/* 292 */         this.mdctIn[cc] = out[cc + sb18];
/*     */       }
/* 294 */       if (blockType == 2) {
/* 295 */         Mp3Mdct.threeShort(this.mdctIn, this.mdctOut);
/*     */       } else {
/* 297 */         Mp3Mdct.oneLong(this.mdctIn, this.mdctOut);
/* 298 */         for (int j = 0; j < 36; j++) {
/* 299 */           this.mdctOut[j] = this.mdctOut[j] * MpaConst.win[blockType][j];
/*     */         }
/*     */       } 
/* 302 */       for (int i = 0; i < 18; i++) {
/* 303 */         out[i + sb18] = this.mdctOut[i] + this.prevBlk[ch][sb18 + i];
/* 304 */         this.prevBlk[ch][sb18 + i] = this.mdctOut[18 + i];
/*     */       } 
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public AudioBuffer decodeFrame(ByteBuffer frame, ByteBuffer dst) throws IOException {
/* 311 */     MpaHeader header = MpaHeader.read_header(frame);
/* 312 */     if (!this.initialized) {
/* 313 */       init(header);
/*     */     }
/* 315 */     boolean intensityStereo = (header.mode == 1 && (header.modeExtension & 0x1) != 0);
/* 316 */     if (intensityStereo) {
/* 317 */       throw new RuntimeException("Intensity stereo is not supported.");
/*     */     }
/* 319 */     dst.order(ByteOrder.LITTLE_ENDIAN);
/* 320 */     Mp3Bitstream.MP3SideInfo si = Mp3Bitstream.readSideInfo(header, frame, this.channels);
/* 321 */     int reserve = this.frameData.position();
/* 322 */     this.frameData.put(NIOUtils.read(frame, header.frameBytes));
/* 323 */     this.frameData.flip();
/* 324 */     if (header.protectionBit == 0) {
/* 325 */       frame.getShort();
/*     */     }
/* 327 */     NIOUtils.skip(this.frameData, reserve - si.mainDataBegin);
/* 328 */     BitReader br = BitReader.createBitReader(this.frameData);
/*     */     
/* 330 */     Mp3Bitstream.ScaleFactors[] scalefac = new Mp3Bitstream.ScaleFactors[2];
/* 331 */     decodeGranule(header, dst, si, br, scalefac, 0);
/* 332 */     if (header.version == 1) {
/* 333 */       decodeGranule(header, dst, si, br, scalefac, 1);
/*     */     }
/* 335 */     br.terminate();
/*     */     
/* 337 */     NIOUtils.relocateLeftover(this.frameData);
/* 338 */     dst.flip();
/*     */     
/* 340 */     return new AudioBuffer(dst, null, 1);
/*     */   }
/*     */ 
/*     */   
/*     */   public AudioCodecMeta getCodecMeta(ByteBuffer data) throws IOException {
/* 345 */     MpaHeader header = MpaHeader.read_header(data.duplicate());
/* 346 */     AudioFormat format = new AudioFormat(MpaConst.frequencies[header.version][header.sampleFreq], 16, (header.mode == 3) ? 1 : 2, true, false);
/*     */     
/* 348 */     return AudioCodecMeta.fromAudioFormat(format);
/*     */   }
/*     */ }


/* Location:              C:\Users\rapha\Downloads\aurora.jar!\META-INF\jars\jcodec-0.2.5.jar!\org\jcodec\codecs\mpa\Mp3Decoder.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */