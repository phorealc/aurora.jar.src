/*     */ package org.jcodec.codecs.h264.mp4;
/*     */ 
/*     */ import java.nio.ByteBuffer;
/*     */ import java.util.ArrayList;
/*     */ import java.util.List;
/*     */ import org.jcodec.common.Preconditions;
/*     */ import org.jcodec.common.io.NIOUtils;
/*     */ import org.jcodec.containers.mp4.boxes.Box;
/*     */ import org.jcodec.containers.mp4.boxes.Header;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class AvcCBox
/*     */   extends Box
/*     */ {
/*     */   private int profile;
/*     */   private int profileCompat;
/*     */   private int level;
/*     */   private int nalLengthSize;
/*     */   private List<ByteBuffer> spsList;
/*     */   private List<ByteBuffer> ppsList;
/*     */   
/*     */   public AvcCBox(Header header) {
/*  33 */     super(header);
/*  34 */     this.spsList = new ArrayList<ByteBuffer>();
/*  35 */     this.ppsList = new ArrayList<ByteBuffer>();
/*     */   }
/*     */   
/*     */   public static String fourcc() {
/*  39 */     return "avcC";
/*     */   }
/*     */   
/*     */   public static AvcCBox parseAvcCBox(ByteBuffer buf) {
/*  43 */     AvcCBox avcCBox = new AvcCBox(new Header(fourcc()));
/*  44 */     avcCBox.parse(buf);
/*  45 */     return avcCBox;
/*     */   }
/*     */   
/*     */   public static AvcCBox createEmpty() {
/*  49 */     return new AvcCBox(new Header(fourcc()));
/*     */   }
/*     */ 
/*     */   
/*     */   public static AvcCBox createAvcCBox(int profile, int profileCompat, int level, int nalLengthSize, List<ByteBuffer> spsList, List<ByteBuffer> ppsList) {
/*  54 */     AvcCBox avcc = new AvcCBox(new Header(fourcc()));
/*  55 */     avcc.profile = profile;
/*  56 */     avcc.profileCompat = profileCompat;
/*  57 */     avcc.level = level;
/*  58 */     avcc.nalLengthSize = nalLengthSize;
/*  59 */     avcc.spsList = spsList;
/*  60 */     avcc.ppsList = ppsList;
/*  61 */     return avcc;
/*     */   }
/*     */ 
/*     */   
/*     */   public void parse(ByteBuffer input) {
/*  66 */     NIOUtils.skip(input, 1);
/*  67 */     this.profile = input.get() & 0xFF;
/*  68 */     this.profileCompat = input.get() & 0xFF;
/*  69 */     this.level = input.get() & 0xFF;
/*  70 */     int flags = input.get() & 0xFF;
/*  71 */     this.nalLengthSize = (flags & 0x3) + 1;
/*     */     
/*  73 */     int nSPS = input.get() & 0x1F;
/*     */     
/*  75 */     for (int i = 0; i < nSPS; i++) {
/*  76 */       int spsSize = input.getShort();
/*  77 */       Preconditions.checkState((39 == (input.get() & 0x3F)));
/*  78 */       this.spsList.add(NIOUtils.read(input, spsSize - 1));
/*     */     } 
/*     */     
/*  81 */     int nPPS = input.get() & 0xFF;
/*  82 */     for (int j = 0; j < nPPS; j++) {
/*  83 */       int ppsSize = input.getShort();
/*  84 */       Preconditions.checkState((40 == (input.get() & 0x3F)));
/*  85 */       this.ppsList.add(NIOUtils.read(input, ppsSize - 1));
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public void doWrite(ByteBuffer out) {
/*  91 */     out.put((byte)1);
/*  92 */     out.put((byte)this.profile);
/*  93 */     out.put((byte)this.profileCompat);
/*  94 */     out.put((byte)this.level);
/*  95 */     out.put((byte)-1);
/*     */     
/*  97 */     out.put((byte)(this.spsList.size() | 0xE0));
/*  98 */     for (ByteBuffer sps : this.spsList) {
/*  99 */       out.putShort((short)(sps.remaining() + 1));
/* 100 */       out.put((byte)103);
/* 101 */       NIOUtils.write(out, sps);
/*     */     } 
/*     */     
/* 104 */     out.put((byte)this.ppsList.size());
/* 105 */     for (ByteBuffer pps : this.ppsList) {
/* 106 */       out.putShort((short)(byte)(pps.remaining() + 1));
/* 107 */       out.put((byte)104);
/* 108 */       NIOUtils.write(out, pps);
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public int estimateSize() {
/* 114 */     int sz = 17;
/* 115 */     for (ByteBuffer sps : this.spsList) {
/* 116 */       sz += 3 + sps.remaining();
/*     */     }
/*     */     
/* 119 */     for (ByteBuffer pps : this.ppsList) {
/* 120 */       sz += 3 + pps.remaining();
/*     */     }
/* 122 */     return sz;
/*     */   }
/*     */   
/*     */   public int getProfile() {
/* 126 */     return this.profile;
/*     */   }
/*     */   
/*     */   public int getProfileCompat() {
/* 130 */     return this.profileCompat;
/*     */   }
/*     */   
/*     */   public int getLevel() {
/* 134 */     return this.level;
/*     */   }
/*     */   
/*     */   public List<ByteBuffer> getSpsList() {
/* 138 */     return this.spsList;
/*     */   }
/*     */   
/*     */   public List<ByteBuffer> getPpsList() {
/* 142 */     return this.ppsList;
/*     */   }
/*     */   
/*     */   public int getNalLengthSize() {
/* 146 */     return this.nalLengthSize;
/*     */   }
/*     */ }


/* Location:              C:\Users\rapha\Downloads\aurora.jar!\META-INF\jars\jcodec-0.2.5.jar!\org\jcodec\codecs\h264\mp4\AvcCBox.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */