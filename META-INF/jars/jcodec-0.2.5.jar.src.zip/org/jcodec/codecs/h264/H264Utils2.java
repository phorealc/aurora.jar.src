/*   */ package org.jcodec.codecs.h264;
/*   */ 
/*   */ public class H264Utils2
/*   */ {
/*   */   public static int golomb2Signed(int val) {
/* 6 */     int sign = ((val & 0x1) << 1) - 1;
/* 7 */     val = ((val >> 1) + (val & 0x1)) * sign;
/* 8 */     return val;
/*   */   }
/*   */ }


/* Location:              C:\Users\rapha\Downloads\aurora.jar!\META-INF\jars\jcodec-0.2.5.jar!\org\jcodec\codecs\h264\H264Utils2.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */