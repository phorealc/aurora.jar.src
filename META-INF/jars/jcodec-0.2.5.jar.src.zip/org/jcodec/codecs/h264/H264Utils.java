/*      */ package org.jcodec.codecs.h264;
/*      */ 
/*      */ import java.io.File;
/*      */ import java.io.IOException;
/*      */ import java.nio.ByteBuffer;
/*      */ import java.nio.ByteOrder;
/*      */ import java.nio.channels.WritableByteChannel;
/*      */ import java.util.ArrayList;
/*      */ import java.util.Arrays;
/*      */ import java.util.Collection;
/*      */ import java.util.List;
/*      */ import org.jcodec.codecs.h264.decode.SliceHeaderReader;
/*      */ import org.jcodec.codecs.h264.io.model.NALUnit;
/*      */ import org.jcodec.codecs.h264.io.model.NALUnitType;
/*      */ import org.jcodec.codecs.h264.io.model.PictureParameterSet;
/*      */ import org.jcodec.codecs.h264.io.model.SeqParameterSet;
/*      */ import org.jcodec.codecs.h264.io.model.SliceHeader;
/*      */ import org.jcodec.codecs.h264.io.model.SliceType;
/*      */ import org.jcodec.codecs.h264.io.write.SliceHeaderWriter;
/*      */ import org.jcodec.codecs.h264.mp4.AvcCBox;
/*      */ import org.jcodec.common.IntArrayList;
/*      */ import org.jcodec.common.io.BitReader;
/*      */ import org.jcodec.common.io.BitWriter;
/*      */ import org.jcodec.common.io.FileChannelWrapper;
/*      */ import org.jcodec.common.io.NIOUtils;
/*      */ import org.jcodec.common.io.SeekableByteChannel;
/*      */ import org.jcodec.common.model.Size;
/*      */ import org.jcodec.containers.mp4.boxes.Box;
/*      */ import org.jcodec.containers.mp4.boxes.NodeBox;
/*      */ import org.jcodec.containers.mp4.boxes.SampleEntry;
/*      */ import org.jcodec.containers.mp4.boxes.VideoSampleEntry;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ public class H264Utils
/*      */ {
/*      */   public static ByteBuffer nextNALUnit(ByteBuffer buf) {
/*   45 */     skipToNALUnit(buf);
/*      */     
/*   47 */     if (buf.hasArray()) {
/*   48 */       return gotoNALUnitWithArray(buf);
/*      */     }
/*   50 */     return gotoNALUnit(buf);
/*      */   }
/*      */   
/*      */   public static final void skipToNALUnit(ByteBuffer buf) {
/*   54 */     if (!buf.hasRemaining()) {
/*      */       return;
/*      */     }
/*   57 */     int val = -1;
/*   58 */     while (buf.hasRemaining()) {
/*   59 */       val <<= 8;
/*   60 */       val |= buf.get() & 0xFF;
/*   61 */       if ((val & 0xFFFFFF) == 1) {
/*   62 */         buf.position(buf.position());
/*      */         break;
/*      */       } 
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static final ByteBuffer gotoNALUnit(ByteBuffer buf) {
/*   81 */     if (!buf.hasRemaining()) {
/*   82 */       return null;
/*      */     }
/*   84 */     int from = buf.position();
/*   85 */     ByteBuffer result = buf.slice();
/*   86 */     result.order(ByteOrder.BIG_ENDIAN);
/*      */     
/*   88 */     int val = -1;
/*   89 */     while (buf.hasRemaining()) {
/*   90 */       val <<= 8;
/*   91 */       val |= buf.get() & 0xFF;
/*   92 */       if ((val & 0xFFFFFF) == 1) {
/*   93 */         buf.position(buf.position() - ((val == 1) ? 4 : 3));
/*   94 */         result.limit(buf.position() - from);
/*      */         break;
/*      */       } 
/*      */     } 
/*   98 */     return result;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static final ByteBuffer gotoNALUnitWithArray(ByteBuffer buf) {
/*  112 */     if (!buf.hasRemaining()) {
/*  113 */       return null;
/*      */     }
/*  115 */     int from = buf.position();
/*  116 */     ByteBuffer result = buf.slice();
/*  117 */     result.order(ByteOrder.BIG_ENDIAN);
/*      */     
/*  119 */     byte[] arr = buf.array();
/*  120 */     int pos = from + buf.arrayOffset();
/*  121 */     int posFrom = pos;
/*  122 */     int lim = buf.limit() + buf.arrayOffset();
/*      */     
/*  124 */     while (pos < lim) {
/*  125 */       byte b = arr[pos];
/*      */       
/*  127 */       if ((b & 0xFE) == 0) {
/*  128 */         while (b == 0 && ++pos < lim) {
/*  129 */           b = arr[pos];
/*      */         }
/*  131 */         if (b == 1 && 
/*  132 */           pos - posFrom >= 2 && arr[pos - 1] == 0 && arr[pos - 2] == 0) {
/*  133 */           int lenSize = (pos - posFrom >= 3 && arr[pos - 3] == 0) ? 4 : 3;
/*      */           
/*  135 */           buf.position(pos + 1 - buf.arrayOffset() - lenSize);
/*  136 */           result.limit(buf.position() - from);
/*      */           
/*  138 */           return result;
/*      */         } 
/*      */       } 
/*      */ 
/*      */       
/*  143 */       pos += 3;
/*      */     } 
/*      */     
/*  146 */     buf.position(buf.limit());
/*      */     
/*  148 */     return result;
/*      */   }
/*      */   
/*      */   public static final void unescapeNAL(ByteBuffer _buf) {
/*  152 */     if (_buf.remaining() < 2)
/*      */       return; 
/*  154 */     ByteBuffer _in = _buf.duplicate();
/*  155 */     ByteBuffer out = _buf.duplicate();
/*  156 */     byte p1 = _in.get();
/*  157 */     out.put(p1);
/*  158 */     byte p2 = _in.get();
/*  159 */     out.put(p2);
/*  160 */     while (_in.hasRemaining()) {
/*  161 */       byte b = _in.get();
/*  162 */       if (p1 != 0 || p2 != 0 || b != 3)
/*  163 */         out.put(b); 
/*  164 */       p1 = p2;
/*  165 */       p2 = b;
/*      */     } 
/*  167 */     _buf.limit(out.position());
/*      */   }
/*      */   
/*      */   public static final void escapeNALinplace(ByteBuffer src) {
/*  171 */     int[] loc = searchEscapeLocations(src);
/*      */     
/*  173 */     int old = src.limit();
/*  174 */     src.limit(src.limit() + loc.length);
/*      */     
/*  176 */     int newPos = src.limit() - 1, oldPos = old - 1, locIdx = loc.length - 1; for (; newPos >= src
/*  177 */       .position(); newPos--, oldPos--) {
/*  178 */       src.put(newPos, src.get(oldPos));
/*  179 */       if (locIdx >= 0 && loc[locIdx] == oldPos) {
/*  180 */         newPos--;
/*  181 */         src.put(newPos, (byte)3);
/*  182 */         locIdx--;
/*      */       } 
/*      */     } 
/*      */   }
/*      */   
/*      */   private static int[] searchEscapeLocations(ByteBuffer src) {
/*  188 */     IntArrayList points = IntArrayList.createIntArrayList();
/*  189 */     ByteBuffer search = src.duplicate();
/*  190 */     int p = search.getShort();
/*  191 */     while (search.hasRemaining()) {
/*  192 */       byte b = search.get();
/*  193 */       if (p == 0 && (b & 0xFFFFFFFC) == 0) {
/*  194 */         points.add(search.position() - 1);
/*  195 */         p = 3;
/*      */       } 
/*  197 */       p = p << 8 & 0xFFFF;
/*  198 */       p |= b & 0xFF;
/*      */     } 
/*  200 */     int[] array = points.toArray();
/*  201 */     return array;
/*      */   }
/*      */   
/*      */   public static final void escapeNAL(ByteBuffer src, ByteBuffer dst) {
/*  205 */     byte p1 = src.get(), p2 = src.get();
/*  206 */     dst.put(p1);
/*  207 */     dst.put(p2);
/*  208 */     while (src.hasRemaining()) {
/*  209 */       byte b = src.get();
/*  210 */       if (p1 == 0 && p2 == 0 && (b & 0xFF) <= 3) {
/*  211 */         dst.put((byte)3);
/*  212 */         p1 = p2;
/*  213 */         p2 = 3;
/*      */       } 
/*  215 */       dst.put(b);
/*  216 */       p1 = p2;
/*  217 */       p2 = b;
/*      */     } 
/*      */   }
/*      */   
/*      */   public static List<ByteBuffer> splitMOVPacket(ByteBuffer buf, AvcCBox avcC) {
/*  222 */     List<ByteBuffer> result = new ArrayList<ByteBuffer>();
/*  223 */     int nls = avcC.getNalLengthSize();
/*  224 */     ByteBuffer dup = buf.duplicate();
/*  225 */     while (dup.remaining() >= nls) {
/*  226 */       int len = readLen(dup, nls);
/*  227 */       if (len == 0)
/*      */         break; 
/*  229 */       result.add(NIOUtils.read(dup, len));
/*      */     } 
/*  231 */     return result;
/*      */   }
/*      */   
/*      */   private static int readLen(ByteBuffer dup, int nls) {
/*  235 */     switch (nls) {
/*      */       case 1:
/*  237 */         return dup.get() & 0xFF;
/*      */       case 2:
/*  239 */         return dup.getShort() & 0xFFFF;
/*      */       case 3:
/*  241 */         return (dup.getShort() & 0xFFFF) << 8 | dup.get() & 0xFF;
/*      */       case 4:
/*  243 */         return dup.getInt();
/*      */     } 
/*  245 */     throw new IllegalArgumentException("NAL Unit length size can not be " + nls);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static void encodeMOVPacketInplace(ByteBuffer avcFrame) {
/*  261 */     ByteBuffer dup = avcFrame.duplicate();
/*  262 */     ByteBuffer d1 = avcFrame.duplicate();
/*      */     
/*  264 */     int tot = d1.position(); while (true) {
/*  265 */       ByteBuffer buf = nextNALUnit(dup);
/*  266 */       if (buf == null)
/*      */         break; 
/*  268 */       d1.position(tot);
/*  269 */       d1.putInt(buf.remaining());
/*  270 */       tot += buf.remaining() + 4;
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static ByteBuffer encodeMOVPacket(ByteBuffer avcFrame) {
/*  286 */     ByteBuffer dup = avcFrame.duplicate();
/*      */     
/*  288 */     List<ByteBuffer> list = new ArrayList<ByteBuffer>();
/*      */     
/*  290 */     int totalLen = 0; ByteBuffer buf;
/*  291 */     while ((buf = nextNALUnit(dup)) != null) {
/*  292 */       list.add(buf);
/*  293 */       totalLen += buf.remaining();
/*      */     } 
/*  295 */     ByteBuffer result = ByteBuffer.allocate(list.size() * 4 + totalLen);
/*  296 */     for (ByteBuffer byteBuffer : list) {
/*  297 */       result.putInt(byteBuffer.remaining());
/*  298 */       result.put(byteBuffer);
/*      */     } 
/*  300 */     result.flip();
/*  301 */     return result;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static ByteBuffer decodeMOVPacket(ByteBuffer result, AvcCBox avcC) {
/*  313 */     if (avcC.getNalLengthSize() == 4) {
/*  314 */       decodeMOVPacketInplace(result, avcC);
/*  315 */       return result;
/*      */     } 
/*  317 */     return joinNALUnits(splitMOVPacket(result, avcC));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static void decodeMOVPacketInplace(ByteBuffer result, AvcCBox avcC) {
/*  328 */     if (avcC.getNalLengthSize() != 4)
/*  329 */       throw new IllegalArgumentException("Can only inplace decode AVC MOV packet with nal_length_size = 4."); 
/*  330 */     ByteBuffer dup = result.duplicate();
/*  331 */     while (dup.remaining() >= 4) {
/*  332 */       int size = dup.getInt();
/*  333 */       dup.position(dup.position() - 4);
/*  334 */       dup.putInt(1);
/*  335 */       dup.position(dup.position() + size);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static void wipePS(ByteBuffer _in, ByteBuffer out, List<ByteBuffer> spsList, List<ByteBuffer> ppsList) {
/*  355 */     ByteBuffer dup = _in.duplicate();
/*  356 */     while (dup.hasRemaining()) {
/*  357 */       ByteBuffer buf = nextNALUnit(dup);
/*  358 */       if (buf == null) {
/*      */         break;
/*      */       }
/*  361 */       NALUnit nu = NALUnit.read(buf.duplicate());
/*  362 */       if (nu.type == NALUnitType.PPS) {
/*  363 */         if (ppsList != null)
/*  364 */           ppsList.add(NIOUtils.duplicate(buf));  continue;
/*  365 */       }  if (nu.type == NALUnitType.SPS) {
/*  366 */         if (spsList != null)
/*  367 */           spsList.add(NIOUtils.duplicate(buf));  continue;
/*  368 */       }  if (out != null) {
/*  369 */         out.putInt(1);
/*  370 */         out.put(buf);
/*      */       } 
/*      */     } 
/*  373 */     if (out != null) {
/*  374 */       out.flip();
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static void wipePSinplace(ByteBuffer _in, Collection<ByteBuffer> spsList, Collection<ByteBuffer> ppsList) {
/*  391 */     ByteBuffer dup = _in.duplicate();
/*  392 */     while (dup.hasRemaining()) {
/*  393 */       ByteBuffer buf = nextNALUnit(dup);
/*  394 */       if (buf == null) {
/*      */         break;
/*      */       }
/*  397 */       NALUnit nu = NALUnit.read(buf);
/*  398 */       if (nu.type == NALUnitType.PPS) {
/*  399 */         if (ppsList != null)
/*  400 */           ppsList.add(NIOUtils.duplicate(buf)); 
/*  401 */         _in.position(dup.position()); continue;
/*  402 */       }  if (nu.type == NALUnitType.SPS) {
/*  403 */         if (spsList != null)
/*  404 */           spsList.add(NIOUtils.duplicate(buf)); 
/*  405 */         _in.position(dup.position()); continue;
/*  406 */       }  if (nu.type == NALUnitType.IDR_SLICE || nu.type == NALUnitType.NON_IDR_SLICE)
/*      */         break; 
/*      */     } 
/*      */   }
/*      */   
/*      */   public static AvcCBox createAvcC(SeqParameterSet sps, PictureParameterSet pps, int nalLengthSize) {
/*  412 */     ByteBuffer serialSps = ByteBuffer.allocate(512);
/*  413 */     sps.write(serialSps);
/*  414 */     serialSps.flip();
/*  415 */     escapeNALinplace(serialSps);
/*      */     
/*  417 */     ByteBuffer serialPps = ByteBuffer.allocate(512);
/*  418 */     pps.write(serialPps);
/*  419 */     serialPps.flip();
/*  420 */     escapeNALinplace(serialPps);
/*      */     
/*  422 */     AvcCBox avcC = AvcCBox.createAvcCBox(sps.profileIdc, 0, sps.levelIdc, nalLengthSize, Arrays.asList(new ByteBuffer[] { serialSps
/*  423 */           }, ), Arrays.asList(new ByteBuffer[] { serialPps }));
/*      */     
/*  425 */     return avcC;
/*      */   }
/*      */ 
/*      */   
/*      */   public static AvcCBox createAvcCFromList(List<SeqParameterSet> initSPS, List<PictureParameterSet> initPPS, int nalLengthSize) {
/*  430 */     List<ByteBuffer> serialSps = saveSPS(initSPS);
/*  431 */     List<ByteBuffer> serialPps = savePPS(initPPS);
/*      */     
/*  433 */     SeqParameterSet sps = initSPS.get(0);
/*  434 */     return AvcCBox.createAvcCBox(sps.profileIdc, 0, sps.levelIdc, nalLengthSize, serialSps, serialPps);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static List<ByteBuffer> savePPS(List<PictureParameterSet> initPPS) {
/*  442 */     List<ByteBuffer> serialPps = new ArrayList<ByteBuffer>();
/*  443 */     for (PictureParameterSet pps : initPPS) {
/*  444 */       ByteBuffer bb1 = ByteBuffer.allocate(512);
/*  445 */       pps.write(bb1);
/*  446 */       bb1.flip();
/*  447 */       escapeNALinplace(bb1);
/*  448 */       serialPps.add(bb1);
/*      */     } 
/*  450 */     return serialPps;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static List<ByteBuffer> saveSPS(List<SeqParameterSet> initSPS) {
/*  458 */     List<ByteBuffer> serialSps = new ArrayList<ByteBuffer>();
/*  459 */     for (SeqParameterSet sps : initSPS) {
/*  460 */       ByteBuffer bb1 = ByteBuffer.allocate(512);
/*  461 */       sps.write(bb1);
/*  462 */       bb1.flip();
/*  463 */       escapeNALinplace(bb1);
/*  464 */       serialSps.add(bb1);
/*      */     } 
/*  466 */     return serialSps;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static SampleEntry createMOVSampleEntryFromBytes(ByteBuffer codecPrivate) {
/*  478 */     List<ByteBuffer> rawSPS = getRawSPS(codecPrivate.duplicate());
/*  479 */     List<ByteBuffer> rawPPS = getRawPPS(codecPrivate.duplicate());
/*  480 */     return createMOVSampleEntryFromSpsPpsList(rawSPS, rawPPS, 4);
/*      */   }
/*      */ 
/*      */   
/*      */   public static SampleEntry createMOVSampleEntryFromSpsPpsList(List<ByteBuffer> spsList, List<ByteBuffer> ppsList, int nalLengthSize) {
/*  485 */     AvcCBox avcC = createAvcCFromPS(spsList, ppsList, nalLengthSize);
/*      */     
/*  487 */     return createMOVSampleEntryFromAvcC(avcC);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static AvcCBox createAvcCFromBytes(ByteBuffer codecPrivate) {
/*  499 */     List<ByteBuffer> rawSPS = getRawSPS(codecPrivate.duplicate());
/*  500 */     List<ByteBuffer> rawPPS = getRawPPS(codecPrivate.duplicate());
/*  501 */     return createAvcCFromPS(rawSPS, rawPPS, 4);
/*      */   }
/*      */   
/*      */   public static AvcCBox createAvcCFromPS(List<ByteBuffer> spsList, List<ByteBuffer> ppsList, int nalLengthSize) {
/*  505 */     SeqParameterSet sps = readSPS(NIOUtils.duplicate(spsList.get(0)));
/*  506 */     return AvcCBox.createAvcCBox(sps.profileIdc, 0, sps.levelIdc, nalLengthSize, spsList, ppsList);
/*      */   }
/*      */   
/*      */   public static SampleEntry createMOVSampleEntryFromAvcC(AvcCBox avcC) {
/*  510 */     SeqParameterSet sps = SeqParameterSet.read(((ByteBuffer)avcC.getSpsList().get(0)).duplicate());
/*  511 */     int codedWidth = sps.picWidthInMbsMinus1 + 1 << 4;
/*  512 */     int codedHeight = SeqParameterSet.getPicHeightInMbs(sps) << 4;
/*      */     
/*  514 */     VideoSampleEntry videoSampleEntry = VideoSampleEntry.videoSampleEntry("avc1", getPicSize(sps), "JCodec");
/*  515 */     videoSampleEntry.add((Box)avcC);
/*  516 */     return (SampleEntry)videoSampleEntry;
/*      */   }
/*      */ 
/*      */   
/*      */   public static SampleEntry createMOVSampleEntryFromSpsPps(SeqParameterSet initSPS, PictureParameterSet initPPS, int nalLengthSize) {
/*  521 */     ByteBuffer bb1 = ByteBuffer.allocate(512), bb2 = ByteBuffer.allocate(512);
/*  522 */     initSPS.write(bb1);
/*  523 */     initPPS.write(bb2);
/*  524 */     bb1.flip();
/*  525 */     bb2.flip();
/*  526 */     return createMOVSampleEntryFromBuffer(bb1, bb2, nalLengthSize);
/*      */   }
/*      */   
/*      */   public static SampleEntry createMOVSampleEntryFromBuffer(ByteBuffer sps, ByteBuffer pps, int nalLengthSize) {
/*  530 */     return createMOVSampleEntryFromSpsPpsList(Arrays.asList(new ByteBuffer[] { sps
/*  531 */           }, ), Arrays.asList(new ByteBuffer[] { pps }, ), nalLengthSize);
/*      */   }
/*      */   
/*      */   public static boolean iFrame(ByteBuffer _data) {
/*  535 */     ByteBuffer data = _data.duplicate();
/*      */     ByteBuffer segment;
/*  537 */     while ((segment = nextNALUnit(data)) != null) {
/*  538 */       NALUnitType type = (NALUnit.read(segment)).type;
/*  539 */       if (type == NALUnitType.IDR_SLICE || type == NALUnitType.NON_IDR_SLICE) {
/*  540 */         unescapeNAL(segment);
/*  541 */         BitReader reader = BitReader.createBitReader(segment);
/*  542 */         SliceHeader part1 = SliceHeaderReader.readPart1(reader);
/*  543 */         return (part1.sliceType == SliceType.I);
/*      */       } 
/*      */     } 
/*  546 */     return false;
/*      */   }
/*      */   
/*      */   public static boolean isByteBufferIDRSlice(ByteBuffer _data) {
/*  550 */     ByteBuffer data = _data.duplicate();
/*      */     ByteBuffer segment;
/*  552 */     while ((segment = nextNALUnit(data)) != null) {
/*  553 */       if ((NALUnit.read(segment)).type == NALUnitType.IDR_SLICE)
/*  554 */         return true; 
/*      */     } 
/*  556 */     return false;
/*      */   }
/*      */   
/*      */   public static boolean idrSlice(List<ByteBuffer> _data) {
/*  560 */     for (ByteBuffer segment : _data) {
/*  561 */       if ((NALUnit.read(segment.duplicate())).type == NALUnitType.IDR_SLICE)
/*  562 */         return true; 
/*      */     } 
/*  564 */     return false;
/*      */   }
/*      */   
/*      */   public static void saveRawFrame(ByteBuffer data, AvcCBox avcC, File f) throws IOException {
/*  568 */     FileChannelWrapper fileChannelWrapper = NIOUtils.writableChannel(f);
/*  569 */     saveStreamParams(avcC, (SeekableByteChannel)fileChannelWrapper);
/*  570 */     fileChannelWrapper.write(data.duplicate());
/*  571 */     fileChannelWrapper.close();
/*      */   }
/*      */   
/*      */   public static void saveStreamParams(AvcCBox avcC, SeekableByteChannel raw) throws IOException {
/*  575 */     ByteBuffer bb = ByteBuffer.allocate(1024);
/*  576 */     for (ByteBuffer byteBuffer : avcC.getSpsList()) {
/*  577 */       raw.write(ByteBuffer.wrap(new byte[] { 0, 0, 0, 1, 103 }));
/*      */       
/*  579 */       escapeNAL(byteBuffer.duplicate(), bb);
/*  580 */       bb.flip();
/*  581 */       raw.write(bb);
/*  582 */       bb.clear();
/*      */     } 
/*  584 */     for (ByteBuffer byteBuffer : avcC.getPpsList()) {
/*  585 */       raw.write(ByteBuffer.wrap(new byte[] { 0, 0, 0, 1, 104 }));
/*  586 */       escapeNAL(byteBuffer.duplicate(), bb);
/*  587 */       bb.flip();
/*  588 */       raw.write(bb);
/*  589 */       bb.clear();
/*      */     } 
/*      */   }
/*      */   
/*      */   public static List<ByteBuffer> splitFrame(ByteBuffer frame) {
/*  594 */     ArrayList<ByteBuffer> result = new ArrayList<ByteBuffer>();
/*      */     
/*      */     ByteBuffer segment;
/*  597 */     while ((segment = nextNALUnit(frame)) != null) {
/*  598 */       result.add(segment);
/*      */     }
/*      */     
/*  601 */     return result;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static ByteBuffer joinNALUnits(List<ByteBuffer> nalUnits) {
/*  613 */     int size = 0;
/*  614 */     for (ByteBuffer nal : nalUnits) {
/*  615 */       size += 4 + nal.remaining();
/*      */     }
/*  617 */     ByteBuffer allocate = ByteBuffer.allocate(size);
/*  618 */     joinNALUnitsToBuffer(nalUnits, allocate);
/*  619 */     return allocate;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static void joinNALUnitsToBuffer(List<ByteBuffer> nalUnits, ByteBuffer out) {
/*  631 */     for (ByteBuffer nal : nalUnits) {
/*  632 */       out.putInt(1);
/*  633 */       out.put(nal.duplicate());
/*      */     } 
/*      */   }
/*      */   
/*      */   public static ByteBuffer getAvcCData(AvcCBox avcC) {
/*  638 */     ByteBuffer bb = ByteBuffer.allocate(2048);
/*  639 */     avcC.doWrite(bb);
/*  640 */     bb.flip();
/*  641 */     return bb;
/*      */   }
/*      */   
/*      */   public static AvcCBox parseAVCC(VideoSampleEntry vse) {
/*  645 */     Box lb = NodeBox.findFirst((NodeBox)vse, Box.class, "avcC");
/*  646 */     if (lb instanceof AvcCBox) {
/*  647 */       return (AvcCBox)lb;
/*      */     }
/*  649 */     return parseAVCCFromBuffer(((Box.LeafBox)lb).getData().duplicate());
/*      */   }
/*      */ 
/*      */   
/*      */   public static ByteBuffer saveCodecPrivate(List<ByteBuffer> spsList, List<ByteBuffer> ppsList) {
/*  654 */     int totalCodecPrivateSize = 0;
/*  655 */     for (ByteBuffer byteBuffer : spsList) {
/*  656 */       totalCodecPrivateSize += byteBuffer.remaining() + 5;
/*      */     }
/*  658 */     for (ByteBuffer byteBuffer : ppsList) {
/*  659 */       totalCodecPrivateSize += byteBuffer.remaining() + 5;
/*      */     }
/*      */     
/*  662 */     ByteBuffer bb = ByteBuffer.allocate(totalCodecPrivateSize);
/*  663 */     for (ByteBuffer byteBuffer : spsList) {
/*  664 */       bb.putInt(1);
/*  665 */       bb.put((byte)103);
/*  666 */       bb.put(byteBuffer.duplicate());
/*      */     } 
/*  668 */     for (ByteBuffer byteBuffer : ppsList) {
/*  669 */       bb.putInt(1);
/*  670 */       bb.put((byte)104);
/*  671 */       bb.put(byteBuffer.duplicate());
/*      */     } 
/*  673 */     bb.flip();
/*  674 */     return bb;
/*      */   }
/*      */   
/*      */   public static ByteBuffer avcCToAnnexB(AvcCBox avcC) {
/*  678 */     return saveCodecPrivate(avcC.getSpsList(), avcC.getPpsList());
/*      */   }
/*      */   
/*      */   public static AvcCBox parseAVCCFromBuffer(ByteBuffer bb) {
/*  682 */     return AvcCBox.parseAvcCBox(bb);
/*      */   }
/*      */   
/*      */   public static ByteBuffer writeSPS(SeqParameterSet sps, int approxSize) {
/*  686 */     ByteBuffer output = ByteBuffer.allocate(approxSize + 8);
/*  687 */     sps.write(output);
/*  688 */     output.flip();
/*  689 */     escapeNALinplace(output);
/*  690 */     return output;
/*      */   }
/*      */   
/*      */   public static SeqParameterSet readSPS(ByteBuffer data) {
/*  694 */     ByteBuffer input = NIOUtils.duplicate(data);
/*  695 */     unescapeNAL(input);
/*  696 */     SeqParameterSet sps = SeqParameterSet.read(input);
/*  697 */     return sps;
/*      */   }
/*      */   
/*      */   public static ByteBuffer writePPS(PictureParameterSet pps, int approxSize) {
/*  701 */     ByteBuffer output = ByteBuffer.allocate(approxSize + 8);
/*  702 */     pps.write(output);
/*  703 */     output.flip();
/*  704 */     escapeNALinplace(output);
/*  705 */     return output;
/*      */   }
/*      */   
/*      */   public static PictureParameterSet readPPS(ByteBuffer data) {
/*  709 */     ByteBuffer input = NIOUtils.duplicate(data);
/*  710 */     unescapeNAL(input);
/*  711 */     PictureParameterSet pps = PictureParameterSet.read(input);
/*  712 */     return pps;
/*      */   }
/*      */   
/*      */   public static PictureParameterSet findPPS(List<PictureParameterSet> ppss, int id) {
/*  716 */     for (PictureParameterSet pps : ppss) {
/*  717 */       if (pps.picParameterSetId == id)
/*  718 */         return pps; 
/*      */     } 
/*  720 */     return null;
/*      */   }
/*      */   
/*      */   public static SeqParameterSet findSPS(List<SeqParameterSet> spss, int id) {
/*  724 */     for (SeqParameterSet sps : spss) {
/*  725 */       if (sps.seqParameterSetId == id)
/*  726 */         return sps; 
/*      */     } 
/*  728 */     return null;
/*      */   }
/*      */   
/*      */   public static abstract class SliceHeaderTweaker
/*      */   {
/*      */     protected List<SeqParameterSet> sps;
/*      */     protected List<PictureParameterSet> pps;
/*      */     
/*      */     protected abstract void tweak(SliceHeader param1SliceHeader);
/*      */     
/*      */     public SliceHeader run(ByteBuffer is, ByteBuffer os, NALUnit nu) {
/*  739 */       ByteBuffer nal = os.duplicate();
/*      */       
/*  741 */       H264Utils.unescapeNAL(is);
/*      */       
/*  743 */       BitReader reader = BitReader.createBitReader(is);
/*  744 */       SliceHeader sh = SliceHeaderReader.readPart1(reader);
/*      */       
/*  746 */       PictureParameterSet pp = H264Utils.findPPS(this.pps, sh.picParameterSetId);
/*      */       
/*  748 */       return part2(is, os, nu, H264Utils.findSPS(this.sps, pp.picParameterSetId), pp, nal, reader, sh);
/*      */     }
/*      */ 
/*      */     
/*      */     public SliceHeader runSpsPps(ByteBuffer is, ByteBuffer os, NALUnit nu, SeqParameterSet sps, PictureParameterSet pps) {
/*  753 */       ByteBuffer nal = os.duplicate();
/*      */       
/*  755 */       H264Utils.unescapeNAL(is);
/*      */       
/*  757 */       BitReader reader = BitReader.createBitReader(is);
/*  758 */       SliceHeader sh = SliceHeaderReader.readPart1(reader);
/*      */       
/*  760 */       return part2(is, os, nu, sps, pps, nal, reader, sh);
/*      */     }
/*      */ 
/*      */     
/*      */     private SliceHeader part2(ByteBuffer is, ByteBuffer os, NALUnit nu, SeqParameterSet sps, PictureParameterSet pps, ByteBuffer nal, BitReader reader, SliceHeader sh) {
/*  765 */       BitWriter writer = new BitWriter(os);
/*  766 */       SliceHeaderReader.readPart2(sh, nu, sps, pps, reader);
/*      */       
/*  768 */       tweak(sh);
/*      */       
/*  770 */       SliceHeaderWriter.write(sh, (nu.type == NALUnitType.IDR_SLICE), nu.nal_ref_idc, writer);
/*      */       
/*  772 */       if (pps.entropyCodingModeFlag) {
/*  773 */         copyDataCABAC(is, os, reader, writer);
/*      */       } else {
/*  775 */         copyDataCAVLC(is, os, reader, writer);
/*      */       } 
/*  777 */       nal.limit(os.position());
/*      */       
/*  779 */       H264Utils.escapeNALinplace(nal);
/*      */       
/*  781 */       os.position(nal.limit());
/*      */       
/*  783 */       return sh;
/*      */     }
/*      */     
/*      */     private void copyDataCAVLC(ByteBuffer is, ByteBuffer os, BitReader reader, BitWriter writer) {
/*  787 */       int wLeft = 8 - writer.curBit();
/*  788 */       if (wLeft != 0)
/*  789 */         writer.writeNBit(reader.readNBit(wLeft), wLeft); 
/*  790 */       writer.flush();
/*      */ 
/*      */       
/*  793 */       int shift = reader.curBit();
/*  794 */       if (shift != 0) {
/*  795 */         int mShift = 8 - shift;
/*  796 */         int inp = reader.readNBit(mShift);
/*  797 */         reader.stop();
/*      */         
/*  799 */         while (is.hasRemaining()) {
/*  800 */           int out = inp << shift;
/*  801 */           inp = is.get() & 0xFF;
/*  802 */           out |= inp >> mShift;
/*      */           
/*  804 */           os.put((byte)out);
/*      */         } 
/*  806 */         os.put((byte)(inp << shift));
/*      */       } else {
/*  808 */         reader.stop();
/*  809 */         os.put(is);
/*      */       } 
/*      */     }
/*      */     
/*      */     private void copyDataCABAC(ByteBuffer is, ByteBuffer os, BitReader reader, BitWriter writer) {
/*  814 */       long bp = reader.curBit();
/*  815 */       if (bp != 0L) {
/*  816 */         long rem = reader.readNBit(8 - (int)bp);
/*  817 */         if (((1 << (int)(8L - bp)) - 1) != rem) {
/*  818 */           throw new RuntimeException("Invalid CABAC padding");
/*      */         }
/*      */       } 
/*  821 */       if (writer.curBit() != 0)
/*  822 */         writer.writeNBit(255, 8 - writer.curBit()); 
/*  823 */       writer.flush();
/*  824 */       reader.stop();
/*      */       
/*  826 */       os.put(is);
/*      */     }
/*      */   }
/*      */   
/*      */   public static Size getPicSize(SeqParameterSet sps) {
/*  831 */     int w = sps.picWidthInMbsMinus1 + 1 << 4;
/*  832 */     int h = SeqParameterSet.getPicHeightInMbs(sps) << 4;
/*  833 */     if (sps.frameCroppingFlag) {
/*  834 */       w -= sps.frameCropLeftOffset + sps.frameCropRightOffset << sps.chromaFormatIdc.compWidth[1];
/*  835 */       h -= sps.frameCropTopOffset + sps.frameCropBottomOffset << sps.chromaFormatIdc.compHeight[1];
/*      */     } 
/*  837 */     return new Size(w, h);
/*      */   }
/*      */   
/*      */   public static List<SeqParameterSet> readSPSFromBufferList(List<ByteBuffer> spsList) {
/*  841 */     List<SeqParameterSet> result = new ArrayList<SeqParameterSet>();
/*  842 */     for (ByteBuffer byteBuffer : spsList) {
/*  843 */       result.add(readSPS(NIOUtils.duplicate(byteBuffer)));
/*      */     }
/*  845 */     return result;
/*      */   }
/*      */   
/*      */   public static List<PictureParameterSet> readPPSFromBufferList(List<ByteBuffer> ppsList) {
/*  849 */     List<PictureParameterSet> result = new ArrayList<PictureParameterSet>();
/*  850 */     for (ByteBuffer byteBuffer : ppsList) {
/*  851 */       result.add(readPPS(NIOUtils.duplicate(byteBuffer)));
/*      */     }
/*  853 */     return result;
/*      */   }
/*      */   
/*      */   public static List<ByteBuffer> writePPSList(List<PictureParameterSet> allPps) {
/*  857 */     List<ByteBuffer> result = new ArrayList<ByteBuffer>();
/*  858 */     for (PictureParameterSet pps : allPps) {
/*  859 */       result.add(writePPS(pps, 64));
/*      */     }
/*  861 */     return result;
/*      */   }
/*      */   
/*      */   public static List<ByteBuffer> writeSPSList(List<SeqParameterSet> allSps) {
/*  865 */     List<ByteBuffer> result = new ArrayList<ByteBuffer>();
/*  866 */     for (SeqParameterSet sps : allSps) {
/*  867 */       result.add(writeSPS(sps, 256));
/*      */     }
/*  869 */     return result;
/*      */   }
/*      */   
/*      */   public static void dumpFrame(FileChannelWrapper ch, SeqParameterSet[] values, PictureParameterSet[] values2, List<ByteBuffer> nalUnits) throws IOException {
/*      */     int i;
/*  874 */     for (i = 0; i < values.length; i++) {
/*  875 */       SeqParameterSet sps = values[i];
/*  876 */       NIOUtils.writeInt((WritableByteChannel)ch, 1);
/*  877 */       NIOUtils.writeByte((WritableByteChannel)ch, (byte)103);
/*  878 */       ch.write(writeSPS(sps, 128));
/*      */     } 
/*      */     
/*  881 */     for (i = 0; i < values2.length; i++) {
/*  882 */       PictureParameterSet pps = values2[i];
/*  883 */       NIOUtils.writeInt((WritableByteChannel)ch, 1);
/*  884 */       NIOUtils.writeByte((WritableByteChannel)ch, (byte)104);
/*  885 */       ch.write(writePPS(pps, 256));
/*      */     } 
/*      */     
/*  888 */     for (ByteBuffer byteBuffer : nalUnits) {
/*  889 */       NIOUtils.writeInt((WritableByteChannel)ch, 1);
/*  890 */       ch.write(byteBuffer.duplicate());
/*      */     } 
/*      */   }
/*      */   
/*      */   public static void toNAL(ByteBuffer codecPrivate, SeqParameterSet sps, PictureParameterSet pps) {
/*  895 */     ByteBuffer bb1 = ByteBuffer.allocate(512), bb2 = ByteBuffer.allocate(512);
/*  896 */     sps.write(bb1);
/*  897 */     pps.write(bb2);
/*  898 */     bb1.flip();
/*  899 */     bb2.flip();
/*      */     
/*  901 */     putNAL(codecPrivate, bb1, 103);
/*  902 */     putNAL(codecPrivate, bb2, 104);
/*      */   }
/*      */   
/*      */   public static void toNALList(ByteBuffer codecPrivate, List<ByteBuffer> spsList2, List<ByteBuffer> ppsList2) {
/*  906 */     for (ByteBuffer byteBuffer : spsList2)
/*  907 */       putNAL(codecPrivate, byteBuffer, 103); 
/*  908 */     for (ByteBuffer byteBuffer : ppsList2)
/*  909 */       putNAL(codecPrivate, byteBuffer, 104); 
/*      */   }
/*      */   
/*      */   private static void putNAL(ByteBuffer codecPrivate, ByteBuffer byteBuffer, int nalType) {
/*  913 */     ByteBuffer dst = ByteBuffer.allocate(byteBuffer.remaining() * 2);
/*  914 */     escapeNAL(byteBuffer, dst);
/*  915 */     dst.flip();
/*  916 */     codecPrivate.putInt(1);
/*  917 */     codecPrivate.put((byte)nalType);
/*  918 */     codecPrivate.put(dst);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static List<ByteBuffer> getRawPPS(ByteBuffer codecPrivate) {
/*  929 */     return getRawNALUnitsOfType(codecPrivate, NALUnitType.PPS);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static List<ByteBuffer> getRawSPS(ByteBuffer codecPrivate) {
/*  940 */     return getRawNALUnitsOfType(codecPrivate, NALUnitType.SPS);
/*      */   }
/*      */   
/*      */   public static List<ByteBuffer> getRawNALUnitsOfType(ByteBuffer codecPrivate, NALUnitType type) {
/*  944 */     List<ByteBuffer> result = new ArrayList<ByteBuffer>();
/*  945 */     for (ByteBuffer bb : splitFrame(codecPrivate.duplicate())) {
/*  946 */       NALUnit nu = NALUnit.read(bb);
/*  947 */       if (nu.type == type) {
/*  948 */         result.add(bb);
/*      */       }
/*      */     } 
/*  951 */     return result;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static class Mv
/*      */   {
/*      */     public static int mvX(int mv) {
/*  964 */       return mv << 18 >> 18;
/*      */     }
/*      */     
/*      */     public static int mvY(int mv) {
/*  968 */       return mv << 6 >> 20;
/*      */     }
/*      */     
/*      */     public static int mvRef(int mv) {
/*  972 */       return mv >> 26;
/*      */     }
/*      */     
/*      */     public static int packMv(int mvx, int mvy, int r) {
/*  976 */       return (r & 0x3F) << 26 | (mvy & 0xFFF) << 14 | mvx & 0x3FFF;
/*      */     }
/*      */     
/*      */     public static int mvC(int mv, int comp) {
/*  980 */       return (comp == 0) ? mvX(mv) : mvY(mv);
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static class MvList
/*      */   {
/*      */     private int[] list;
/*      */ 
/*      */ 
/*      */     
/*  994 */     private static final int NA = H264Utils.Mv.packMv(0, 0, -1);
/*      */     
/*      */     public MvList(int size) {
/*  997 */       this.list = new int[size << 1];
/*  998 */       clear();
/*      */     }
/*      */     
/*      */     public void clear() {
/* 1002 */       for (int i = 0; i < this.list.length; i += 2) {
/* 1003 */         this.list[i + 1] = NA; this.list[i] = NA;
/*      */       } 
/*      */     }
/*      */     
/*      */     public int mv0X(int off) {
/* 1008 */       return H264Utils.Mv.mvX(this.list[off << 1]);
/*      */     }
/*      */     
/*      */     public int mv0Y(int off) {
/* 1012 */       return H264Utils.Mv.mvY(this.list[off << 1]);
/*      */     }
/*      */     
/*      */     public int mv0R(int off) {
/* 1016 */       return H264Utils.Mv.mvRef(this.list[off << 1]);
/*      */     }
/*      */     
/*      */     public int mv1X(int off) {
/* 1020 */       return H264Utils.Mv.mvX(this.list[(off << 1) + 1]);
/*      */     }
/*      */     
/*      */     public int mv1Y(int off) {
/* 1024 */       return H264Utils.Mv.mvY(this.list[(off << 1) + 1]);
/*      */     }
/*      */     
/*      */     public int mv1R(int off) {
/* 1028 */       return H264Utils.Mv.mvRef(this.list[(off << 1) + 1]);
/*      */     }
/*      */     
/*      */     public int getMv(int off, int forward) {
/* 1032 */       return this.list[(off << 1) + forward];
/*      */     }
/*      */     
/*      */     public void setMv(int off, int forward, int mv) {
/* 1036 */       this.list[(off << 1) + forward] = mv;
/*      */     }
/*      */     
/*      */     public void setPair(int off, int mv0, int mv1) {
/* 1040 */       this.list[off << 1] = mv0;
/* 1041 */       this.list[(off << 1) + 1] = mv1;
/*      */     }
/*      */     
/*      */     public void copyPair(int off, MvList other, int otherOff) {
/* 1045 */       this.list[off << 1] = other.list[otherOff << 1];
/* 1046 */       this.list[(off << 1) + 1] = other.list[(otherOff << 1) + 1];
/*      */     }
/*      */   }
/*      */   
/*      */   public static class MvList2D {
/*      */     private int[] list;
/*      */     private int stride;
/*      */     private int width;
/*      */     private int height;
/* 1055 */     private static final int NA = H264Utils.Mv.packMv(0, 0, -1);
/*      */     
/*      */     public MvList2D(int width, int height) {
/* 1058 */       this.list = new int[(width << 1) * height];
/* 1059 */       this.stride = width << 1;
/* 1060 */       this.width = width;
/* 1061 */       this.height = height;
/* 1062 */       clear();
/*      */     }
/*      */     
/*      */     public void clear() {
/* 1066 */       for (int i = 0; i < this.list.length; i += 2) {
/* 1067 */         this.list[i + 1] = NA; this.list[i] = NA;
/*      */       } 
/*      */     }
/*      */     
/*      */     public int mv0X(int offX, int offY) {
/* 1072 */       return H264Utils.Mv.mvX(this.list[(offX << 1) + this.stride * offY]);
/*      */     }
/*      */     
/*      */     public int mv0Y(int offX, int offY) {
/* 1076 */       return H264Utils.Mv.mvY(this.list[(offX << 1) + this.stride * offY]);
/*      */     }
/*      */     
/*      */     public int mv0R(int offX, int offY) {
/* 1080 */       return H264Utils.Mv.mvRef(this.list[(offX << 1) + this.stride * offY]);
/*      */     }
/*      */     
/*      */     public int mv1X(int offX, int offY) {
/* 1084 */       return H264Utils.Mv.mvX(this.list[(offX << 1) + this.stride * offY + 1]);
/*      */     }
/*      */     
/*      */     public int mv1Y(int offX, int offY) {
/* 1088 */       return H264Utils.Mv.mvY(this.list[(offX << 1) + this.stride * offY + 1]);
/*      */     }
/*      */     
/*      */     public int mv1R(int offX, int offY) {
/* 1092 */       return H264Utils.Mv.mvRef(this.list[(offX << 1) + this.stride * offY + 1]);
/*      */     }
/*      */     
/*      */     public int getMv(int offX, int offY, int forward) {
/* 1096 */       return this.list[(offX << 1) + this.stride * offY + forward];
/*      */     }
/*      */     
/*      */     public void setMv(int offX, int offY, int forward, int mv) {
/* 1100 */       this.list[(offX << 1) + this.stride * offY + forward] = mv;
/*      */     }
/*      */     
/*      */     public int getHeight() {
/* 1104 */       return this.height;
/*      */     }
/*      */     
/*      */     public int getWidth() {
/* 1108 */       return this.width;
/*      */     }
/*      */   }
/*      */ }


/* Location:              C:\Users\rapha\Downloads\aurora.jar!\META-INF\jars\jcodec-0.2.5.jar!\org\jcodec\codecs\h264\H264Utils.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */