/*      */ package org.jcodec.codecs.h264.decode;
/*      */ 
/*      */ import org.jcodec.codecs.common.biari.MDecoder;
/*      */ import org.jcodec.codecs.h264.H264Const;
/*      */ import org.jcodec.codecs.h264.decode.aso.Mapper;
/*      */ import org.jcodec.codecs.h264.io.CABAC;
/*      */ import org.jcodec.codecs.h264.io.CAVLC;
/*      */ import org.jcodec.codecs.h264.io.model.MBType;
/*      */ import org.jcodec.codecs.h264.io.model.NALUnit;
/*      */ import org.jcodec.codecs.h264.io.model.PictureParameterSet;
/*      */ import org.jcodec.codecs.h264.io.model.SliceHeader;
/*      */ import org.jcodec.codecs.h264.io.model.SliceType;
/*      */ import org.jcodec.common.io.BitReader;
/*      */ import org.jcodec.common.logging.Logger;
/*      */ import org.jcodec.common.model.ColorSpace;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ public class SliceReader
/*      */ {
/*      */   private PictureParameterSet activePps;
/*      */   private CABAC cabac;
/*      */   private MDecoder mDecoder;
/*      */   private CAVLC[] cavlc;
/*      */   private BitReader reader;
/*      */   private Mapper mapper;
/*      */   private SliceHeader sh;
/*      */   private NALUnit nalUnit;
/*      */   private boolean prevMbSkipped = false;
/*      */   private int mbIdx;
/*   56 */   private MBType prevMBType = null;
/*      */   
/*      */   private int mbSkipRun;
/*      */   
/*      */   private boolean endOfData;
/*      */   
/*      */   MBType[] topMBType;
/*      */   MBType leftMBType;
/*      */   int leftCBPLuma;
/*      */   int[] topCBPLuma;
/*      */   int leftCBPChroma;
/*      */   int[] topCBPChroma;
/*      */   ColorSpace chromaFormat;
/*      */   boolean transform8x8;
/*      */   int[] numRef;
/*      */   boolean tf8x8Left;
/*      */   boolean[] tf8x8Top;
/*      */   int[] i4x4PredTop;
/*      */   int[] i4x4PredLeft;
/*      */   H264Const.PartPred[] predModeLeft;
/*      */   H264Const.PartPred[] predModeTop;
/*      */   
/*      */   public SliceReader(PictureParameterSet activePps, CABAC cabac, CAVLC[] cavlc, MDecoder mDecoder, BitReader reader, Mapper mapper, SliceHeader sh, NALUnit nalUnit) {
/*   79 */     this.activePps = activePps;
/*   80 */     this.cabac = cabac;
/*   81 */     this.mDecoder = mDecoder;
/*   82 */     this.cavlc = cavlc;
/*   83 */     this.reader = reader;
/*   84 */     this.mapper = mapper;
/*   85 */     this.sh = sh;
/*   86 */     this.nalUnit = nalUnit;
/*      */     
/*   88 */     int mbWidth = sh.sps.picWidthInMbsMinus1 + 1;
/*   89 */     this.topMBType = new MBType[mbWidth];
/*   90 */     this.topCBPLuma = new int[mbWidth];
/*   91 */     this.topCBPChroma = new int[mbWidth];
/*   92 */     this.chromaFormat = sh.sps.chromaFormatIdc;
/*   93 */     this.transform8x8 = (sh.pps.extended == null) ? false : sh.pps.extended.transform8x8ModeFlag;
/*   94 */     if (sh.numRefIdxActiveOverrideFlag) {
/*   95 */       this.numRef = new int[] { sh.numRefIdxActiveMinus1[0] + 1, sh.numRefIdxActiveMinus1[1] + 1 };
/*      */     } else {
/*   97 */       this.numRef = new int[] { sh.pps.numRefIdxActiveMinus1[0] + 1, sh.pps.numRefIdxActiveMinus1[1] + 1 };
/*      */     } 
/*   99 */     this.tf8x8Top = new boolean[mbWidth];
/*  100 */     this.predModeLeft = new H264Const.PartPred[2];
/*  101 */     this.predModeTop = new H264Const.PartPred[mbWidth << 1];
/*      */     
/*  103 */     this.i4x4PredLeft = new int[4];
/*  104 */     this.i4x4PredTop = new int[mbWidth << 2];
/*      */   }
/*      */   
/*      */   public boolean readMacroblock(MBlock mBlock) {
/*  108 */     int mbWidth = this.sh.sps.picWidthInMbsMinus1 + 1;
/*  109 */     int mbHeight = this.sh.sps.picHeightInMapUnitsMinus1 + 1;
/*  110 */     if ((this.endOfData && this.mbSkipRun == 0) || this.mbIdx >= mbWidth * mbHeight) {
/*  111 */       return false;
/*      */     }
/*  113 */     mBlock.mbIdx = this.mbIdx;
/*  114 */     mBlock.prevMbType = this.prevMBType;
/*      */     
/*  116 */     boolean mbaffFrameFlag = (this.sh.sps.mbAdaptiveFrameFieldFlag && !this.sh.fieldPicFlag);
/*      */     
/*  118 */     if (this.sh.sliceType.isInter() && !this.activePps.entropyCodingModeFlag) {
/*  119 */       if (!this.prevMbSkipped && this.mbSkipRun == 0) {
/*  120 */         this.mbSkipRun = CAVLCReader.readUEtrace(this.reader, "mb_skip_run");
/*  121 */         if (!CAVLCReader.moreRBSPData(this.reader)) {
/*  122 */           this.endOfData = true;
/*      */         }
/*      */       } 
/*      */       
/*  126 */       if (this.mbSkipRun > 0) {
/*  127 */         this.mbSkipRun--;
/*  128 */         int i = this.mapper.getAddress(this.mbIdx);
/*  129 */         this.prevMbSkipped = true;
/*  130 */         this.prevMBType = null;
/*  131 */         MBlockDecoderUtils.debugPrint(new Object[] { "---------------------- MB (%d,%d) ---------------------", Integer.valueOf(i % mbWidth), 
/*  132 */               Integer.valueOf(i / mbWidth) });
/*  133 */         mBlock.skipped = true;
/*  134 */         int j = this.mapper.getMbX(mBlock.mbIdx);
/*  135 */         this.topMBType[j] = this.leftMBType = null;
/*  136 */         int blk8x8X = j << 1;
/*  137 */         this.predModeTop[blk8x8X + 1] = H264Const.PartPred.L0; this.predModeTop[blk8x8X] = H264Const.PartPred.L0; this.predModeLeft[1] = H264Const.PartPred.L0; this.predModeLeft[0] = H264Const.PartPred.L0;
/*  138 */         this.mbIdx++;
/*  139 */         return true;
/*      */       } 
/*  141 */       this.prevMbSkipped = false;
/*      */     } 
/*      */ 
/*      */     
/*  145 */     int mbAddr = this.mapper.getAddress(this.mbIdx);
/*  146 */     int mbX = mbAddr % mbWidth;
/*  147 */     int mbY = mbAddr / mbWidth;
/*  148 */     MBlockDecoderUtils.debugPrint(new Object[] { "---------------------- MB (%d,%d) ---------------------", Integer.valueOf(mbX), Integer.valueOf(mbY) });
/*      */     
/*  150 */     if (this.sh.sliceType.isIntra() || !this.activePps.entropyCodingModeFlag || 
/*  151 */       !readMBSkipFlag(this.sh.sliceType, this.mapper.leftAvailable(this.mbIdx), this.mapper
/*  152 */         .topAvailable(this.mbIdx), mbX)) {
/*      */       
/*  154 */       boolean mb_field_decoding_flag = false;
/*  155 */       if (mbaffFrameFlag && (this.mbIdx % 2 == 0 || (this.mbIdx % 2 == 1 && this.prevMbSkipped))) {
/*  156 */         mb_field_decoding_flag = CAVLCReader.readBool(this.reader, "mb_field_decoding_flag");
/*      */       }
/*      */       
/*  159 */       mBlock.fieldDecoding = mb_field_decoding_flag;
/*  160 */       readMBlock(mBlock, this.sh.sliceType);
/*      */       
/*  162 */       this.prevMBType = mBlock.curMbType;
/*      */     } else {
/*      */       
/*  165 */       this.prevMBType = null;
/*  166 */       this.prevMbSkipped = true;
/*  167 */       mBlock.skipped = true;
/*  168 */       int blk8x8X = mbX << 1;
/*  169 */       this.predModeTop[blk8x8X + 1] = H264Const.PartPred.L0; this.predModeTop[blk8x8X] = H264Const.PartPred.L0; this.predModeLeft[1] = H264Const.PartPred.L0; this.predModeLeft[0] = H264Const.PartPred.L0;
/*      */     } 
/*      */     
/*  172 */     this
/*  173 */       .endOfData = ((this.activePps.entropyCodingModeFlag && this.mDecoder.decodeFinalBin() == 1) || (!this.activePps.entropyCodingModeFlag && !CAVLCReader.moreRBSPData(this.reader)));
/*      */     
/*  175 */     this.mbIdx++;
/*      */     
/*  177 */     this.topMBType[this.mapper.getMbX(mBlock.mbIdx)] = this.leftMBType = mBlock.curMbType;
/*      */     
/*  179 */     return true;
/*      */   }
/*      */   
/*      */   int readMBQpDelta(MBType prevMbType) {
/*      */     int mbQPDelta;
/*  184 */     if (!this.activePps.entropyCodingModeFlag) {
/*  185 */       mbQPDelta = CAVLCReader.readSE(this.reader, "mb_qp_delta");
/*      */     } else {
/*  187 */       mbQPDelta = this.cabac.readMBQpDelta(this.mDecoder, prevMbType);
/*      */     } 
/*  189 */     return mbQPDelta;
/*      */   }
/*      */   
/*      */   int readChromaPredMode(int mbX, boolean leftAvailable, boolean topAvailable) {
/*      */     int chromaPredictionMode;
/*  194 */     if (!this.activePps.entropyCodingModeFlag) {
/*  195 */       chromaPredictionMode = CAVLCReader.readUEtrace(this.reader, "MBP: intra_chroma_pred_mode");
/*      */     } else {
/*  197 */       chromaPredictionMode = this.cabac.readIntraChromaPredMode(this.mDecoder, mbX, this.leftMBType, this.topMBType[mbX], leftAvailable, topAvailable);
/*      */     } 
/*      */     
/*  200 */     return chromaPredictionMode;
/*      */   }
/*      */ 
/*      */   
/*      */   boolean readTransform8x8Flag(boolean leftAvailable, boolean topAvailable, MBType leftType, MBType topType, boolean is8x8Left, boolean is8x8Top) {
/*  205 */     if (!this.activePps.entropyCodingModeFlag) {
/*  206 */       return CAVLCReader.readBool(this.reader, "transform_size_8x8_flag");
/*      */     }
/*  208 */     return this.cabac.readTransform8x8Flag(this.mDecoder, leftAvailable, topAvailable, leftType, topType, is8x8Left, is8x8Top);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected int readCodedBlockPatternIntra(boolean leftAvailable, boolean topAvailable, int leftCBP, int topCBP, MBType leftMB, MBType topMB) {
/*  215 */     if (!this.activePps.entropyCodingModeFlag) {
/*  216 */       return H264Const.CODED_BLOCK_PATTERN_INTRA_COLOR[CAVLCReader.readUEtrace(this.reader, "coded_block_pattern")];
/*      */     }
/*  218 */     return this.cabac.codedBlockPatternIntra(this.mDecoder, leftAvailable, topAvailable, leftCBP, topCBP, leftMB, topMB);
/*      */   }
/*      */ 
/*      */   
/*      */   protected int readCodedBlockPatternInter(boolean leftAvailable, boolean topAvailable, int leftCBP, int topCBP, MBType leftMB, MBType topMB) {
/*  223 */     if (!this.activePps.entropyCodingModeFlag) {
/*  224 */       int code = CAVLCReader.readUEtrace(this.reader, "coded_block_pattern");
/*  225 */       return H264Const.CODED_BLOCK_PATTERN_INTER_COLOR[code];
/*      */     } 
/*  227 */     return this.cabac.codedBlockPatternIntra(this.mDecoder, leftAvailable, topAvailable, leftCBP, topCBP, leftMB, topMB);
/*      */   }
/*      */ 
/*      */   
/*      */   int readRefIdx(boolean leftAvailable, boolean topAvailable, MBType leftType, MBType topType, H264Const.PartPred leftPred, H264Const.PartPred topPred, H264Const.PartPred curPred, int mbX, int partX, int partY, int partW, int partH, int list) {
/*  232 */     if (!this.activePps.entropyCodingModeFlag) {
/*  233 */       return CAVLCReader.readTE(this.reader, this.numRef[list] - 1);
/*      */     }
/*  235 */     return this.cabac.readRefIdx(this.mDecoder, leftAvailable, topAvailable, leftType, topType, leftPred, topPred, curPred, mbX, partX, partY, partW, partH, list);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   int readMVD(int comp, boolean leftAvailable, boolean topAvailable, MBType leftType, MBType topType, H264Const.PartPred leftPred, H264Const.PartPred topPred, H264Const.PartPred curPred, int mbX, int partX, int partY, int partW, int partH, int list) {
/*  242 */     if (!this.activePps.entropyCodingModeFlag) {
/*  243 */       return CAVLCReader.readSE(this.reader, "mvd_l0_x");
/*      */     }
/*  245 */     return this.cabac.readMVD(this.mDecoder, comp, leftAvailable, topAvailable, leftType, topType, leftPred, topPred, curPred, mbX, partX, partY, partW, partH, list);
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   int readPredictionI4x4Block(boolean leftAvailable, boolean topAvailable, MBType leftMBType, MBType topMBType, int blkX, int blkY, int mbX) {
/*  251 */     int mode = 2;
/*  252 */     if ((leftAvailable || blkX > 0) && (topAvailable || blkY > 0)) {
/*  253 */       int predModeB = (topMBType == MBType.I_NxN || blkY > 0) ? this.i4x4PredTop[(mbX << 2) + blkX] : 2;
/*  254 */       int predModeA = (leftMBType == MBType.I_NxN || blkX > 0) ? this.i4x4PredLeft[blkY] : 2;
/*  255 */       mode = Math.min(predModeB, predModeA);
/*      */     } 
/*  257 */     if (!prev4x4PredMode()) {
/*  258 */       int rem_intra4x4_pred_mode = rem4x4PredMode();
/*  259 */       mode = rem_intra4x4_pred_mode + ((rem_intra4x4_pred_mode < mode) ? 0 : 1);
/*      */     } 
/*  261 */     this.i4x4PredLeft[blkY] = mode; this.i4x4PredTop[(mbX << 2) + blkX] = mode;
/*  262 */     return mode;
/*      */   }
/*      */   
/*      */   int rem4x4PredMode() {
/*  266 */     if (!this.activePps.entropyCodingModeFlag) {
/*  267 */       return CAVLCReader.readNBit(this.reader, 3, "MB: rem_intra4x4_pred_mode");
/*      */     }
/*  269 */     return this.cabac.rem4x4PredMode(this.mDecoder);
/*      */   }
/*      */   
/*      */   boolean prev4x4PredMode() {
/*  273 */     if (!this.activePps.entropyCodingModeFlag) {
/*  274 */       return CAVLCReader.readBool(this.reader, "MBP: prev_intra4x4_pred_mode_flag");
/*      */     }
/*  276 */     return this.cabac.prev4x4PredModeFlag(this.mDecoder);
/*      */   }
/*      */   
/*      */   void read16x16DC(boolean leftAvailable, boolean topAvailable, int mbX, int[] dc) {
/*  280 */     if (!this.activePps.entropyCodingModeFlag) {
/*  281 */       this.cavlc[0].readLumaDCBlock(this.reader, dc, mbX, leftAvailable, this.leftMBType, topAvailable, this.topMBType[mbX], CoeffTransformer.zigzag4x4);
/*      */     
/*      */     }
/*  284 */     else if (this.cabac.readCodedBlockFlagLumaDC(this.mDecoder, mbX, this.leftMBType, this.topMBType[mbX], leftAvailable, topAvailable, MBType.I_16x16) == 1) {
/*      */       
/*  286 */       this.cabac.readCoeffs(this.mDecoder, CABAC.BlockType.LUMA_16_DC, dc, 0, 16, CoeffTransformer.zigzag4x4, H264Const.identityMapping16, H264Const.identityMapping16);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   int read16x16AC(boolean leftAvailable, boolean topAvailable, int mbX, int cbpLuma, int[] ac, int blkOffLeft, int blkOffTop, int blkX, int blkY) {
/*  299 */     if (!this.activePps.entropyCodingModeFlag) {
/*  300 */       return this.cavlc[0].readACBlock(this.reader, ac, blkX, blkOffTop, (blkOffLeft != 0 || leftAvailable), (blkOffLeft == 0) ? this.leftMBType : MBType.I_16x16, (blkOffTop != 0 || topAvailable), (blkOffTop == 0) ? this.topMBType[mbX] : MBType.I_16x16, 1, 15, CoeffTransformer.zigzag4x4);
/*      */     }
/*      */ 
/*      */     
/*  304 */     if (this.cabac.readCodedBlockFlagLumaAC(this.mDecoder, CABAC.BlockType.LUMA_15_AC, blkX, blkOffTop, 0, this.leftMBType, this.topMBType[mbX], leftAvailable, topAvailable, this.leftCBPLuma, this.topCBPLuma[mbX], cbpLuma, MBType.I_16x16) == 1)
/*      */     {
/*  306 */       return this.cabac.readCoeffs(this.mDecoder, CABAC.BlockType.LUMA_15_AC, ac, 1, 15, CoeffTransformer.zigzag4x4, H264Const.identityMapping16, H264Const.identityMapping16);
/*      */     }
/*      */     
/*  309 */     return 0;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   int readResidualAC(boolean leftAvailable, boolean topAvailable, int mbX, MBType curMbType, int cbpLuma, int blkOffLeft, int blkOffTop, int blkX, int blkY, int[] ac) {
/*  319 */     if (!this.activePps.entropyCodingModeFlag) {
/*  320 */       if (this.reader.remaining() <= 0)
/*  321 */         return 0; 
/*  322 */       return this.cavlc[0].readACBlock(this.reader, ac, blkX, blkOffTop, (blkOffLeft != 0 || leftAvailable), (blkOffLeft == 0) ? this.leftMBType : curMbType, (blkOffTop != 0 || topAvailable), (blkOffTop == 0) ? this.topMBType[mbX] : curMbType, 0, 16, CoeffTransformer.zigzag4x4);
/*      */     } 
/*      */ 
/*      */     
/*  326 */     if (this.cabac.readCodedBlockFlagLumaAC(this.mDecoder, CABAC.BlockType.LUMA_16, blkX, blkOffTop, 0, this.leftMBType, this.topMBType[mbX], leftAvailable, topAvailable, this.leftCBPLuma, this.topCBPLuma[mbX], cbpLuma, curMbType) == 1)
/*      */     {
/*  328 */       return this.cabac.readCoeffs(this.mDecoder, CABAC.BlockType.LUMA_16, ac, 0, 16, CoeffTransformer.zigzag4x4, H264Const.identityMapping16, H264Const.identityMapping16);
/*      */     }
/*      */     
/*  331 */     return 0;
/*      */   }
/*      */   
/*      */   public void setZeroCoeff(int comp, int blkX, int blkOffTop) {
/*  335 */     this.cavlc[comp].setZeroCoeff(blkX, blkOffTop);
/*      */   }
/*      */   
/*      */   public void savePrevCBP(int codedBlockPattern) {
/*  339 */     if (this.activePps.entropyCodingModeFlag) {
/*  340 */       this.cabac.setPrevCBP(codedBlockPattern);
/*      */     }
/*      */   }
/*      */   
/*      */   public int readLumaAC(boolean leftAvailable, boolean topAvailable, int mbX, MBType curMbType, int blkX, int j, int[] ac16, int blkOffLeft, int blkOffTop) {
/*  345 */     return this.cavlc[0].readACBlock(this.reader, ac16, blkX + (j & 0x1), blkOffTop, (blkOffLeft != 0 || leftAvailable), (blkOffLeft == 0) ? this.leftMBType : curMbType, (blkOffTop != 0 || topAvailable), (blkOffTop == 0) ? this.topMBType[mbX] : curMbType, 0, 16, H264Const.identityMapping16);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public int readLumaAC8x8(int blkX, int blkY, int[] ac) {
/*  357 */     int readCoeffs = this.cabac.readCoeffs(this.mDecoder, CABAC.BlockType.LUMA_64, ac, 0, 64, CoeffTransformer.zigzag8x8, H264Const.sig_coeff_map_8x8, H264Const.last_sig_coeff_map_8x8);
/*      */     
/*  359 */     this.cabac.setCodedBlock(blkX, blkY);
/*  360 */     this.cabac.setCodedBlock(blkX + 1, blkY);
/*  361 */     this.cabac.setCodedBlock(blkX, blkY + 1);
/*  362 */     this.cabac.setCodedBlock(blkX + 1, blkY + 1);
/*      */     
/*  364 */     return readCoeffs;
/*      */   }
/*      */   
/*      */   public int readSubMBTypeP() {
/*  368 */     if (!this.activePps.entropyCodingModeFlag) {
/*  369 */       return CAVLCReader.readUEtrace(this.reader, "SUB: sub_mb_type");
/*      */     }
/*  371 */     return this.cabac.readSubMbTypeP(this.mDecoder);
/*      */   }
/*      */   
/*      */   public int readSubMBTypeB() {
/*  375 */     if (!this.activePps.entropyCodingModeFlag) {
/*  376 */       return CAVLCReader.readUEtrace(this.reader, "SUB: sub_mb_type");
/*      */     }
/*  378 */     return this.cabac.readSubMbTypeB(this.mDecoder);
/*      */   }
/*      */   
/*      */   public void readChromaDC(int mbX, boolean leftAvailable, boolean topAvailable, int[] dc, int comp, MBType curMbType) {
/*  382 */     if (!this.activePps.entropyCodingModeFlag) {
/*  383 */       this.cavlc[comp].readChromaDCBlock(this.reader, dc, leftAvailable, topAvailable);
/*      */     }
/*  385 */     else if (this.cabac.readCodedBlockFlagChromaDC(this.mDecoder, mbX, comp, this.leftMBType, this.topMBType[mbX], leftAvailable, topAvailable, this.leftCBPChroma, this.topCBPChroma[mbX], curMbType) == 1) {
/*      */       
/*  387 */       this.cabac.readCoeffs(this.mDecoder, CABAC.BlockType.CHROMA_DC, dc, 0, 4, H264Const.identityMapping16, H264Const.identityMapping16, H264Const.identityMapping16);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public void readChromaAC(boolean leftAvailable, boolean topAvailable, int mbX, int comp, MBType curMbType, int[] ac, int blkOffLeft, int blkOffTop, int blkX) {
/*  394 */     if (!this.activePps.entropyCodingModeFlag) {
/*  395 */       if (this.reader.remaining() <= 0)
/*      */         return; 
/*  397 */       this.cavlc[comp].readACBlock(this.reader, ac, blkX, blkOffTop, (blkOffLeft != 0 || leftAvailable), (blkOffLeft == 0) ? this.leftMBType : curMbType, (blkOffTop != 0 || topAvailable), (blkOffTop == 0) ? this.topMBType[mbX] : curMbType, 1, 15, CoeffTransformer.zigzag4x4);
/*      */ 
/*      */     
/*      */     }
/*  401 */     else if (this.cabac.readCodedBlockFlagChromaAC(this.mDecoder, blkX, blkOffTop, comp, this.leftMBType, this.topMBType[mbX], leftAvailable, topAvailable, this.leftCBPChroma, this.topCBPChroma[mbX], curMbType) == 1) {
/*      */       
/*  403 */       this.cabac.readCoeffs(this.mDecoder, CABAC.BlockType.CHROMA_AC, ac, 1, 15, CoeffTransformer.zigzag4x4, H264Const.identityMapping16, H264Const.identityMapping16);
/*      */     } 
/*      */   }
/*      */ 
/*      */   
/*      */   public int decodeMBTypeI(int mbIdx, boolean leftAvailable, boolean topAvailable, MBType leftMBType, MBType topMBType) {
/*      */     int mbType;
/*  410 */     if (!this.activePps.entropyCodingModeFlag) {
/*  411 */       mbType = CAVLCReader.readUEtrace(this.reader, "MB: mb_type");
/*      */     } else {
/*  413 */       mbType = this.cabac.readMBTypeI(this.mDecoder, leftMBType, topMBType, leftAvailable, topAvailable);
/*  414 */     }  return mbType;
/*      */   }
/*      */   
/*      */   public int readMBTypeP() {
/*      */     int mbType;
/*  419 */     if (!this.activePps.entropyCodingModeFlag) {
/*  420 */       mbType = CAVLCReader.readUEtrace(this.reader, "MB: mb_type");
/*      */     } else {
/*  422 */       mbType = this.cabac.readMBTypeP(this.mDecoder);
/*  423 */     }  return mbType;
/*      */   }
/*      */   
/*      */   public int readMBTypeB(int mbIdx, boolean leftAvailable, boolean topAvailable, MBType leftMBType, MBType topMBType) {
/*      */     int mbType;
/*  428 */     if (!this.activePps.entropyCodingModeFlag) {
/*  429 */       mbType = CAVLCReader.readUEtrace(this.reader, "MB: mb_type");
/*      */     } else {
/*  431 */       mbType = this.cabac.readMBTypeB(this.mDecoder, leftMBType, topMBType, leftAvailable, topAvailable);
/*  432 */     }  return mbType;
/*      */   }
/*      */   
/*      */   public boolean readMBSkipFlag(SliceType slType, boolean leftAvailable, boolean topAvailable, int mbX) {
/*  436 */     return this.cabac.readMBSkipFlag(this.mDecoder, slType, leftAvailable, topAvailable, mbX);
/*      */   }
/*      */   
/*      */   public void readIntra16x16(int mbType, MBlock mBlock) {
/*  440 */     int mbX = this.mapper.getMbX(mBlock.mbIdx);
/*  441 */     int mbY = this.mapper.getMbY(mBlock.mbIdx);
/*  442 */     boolean leftAvailable = this.mapper.leftAvailable(mBlock.mbIdx);
/*  443 */     boolean topAvailable = this.mapper.topAvailable(mBlock.mbIdx);
/*  444 */     mBlock.cbp(mbType / 12 * 15, mbType / 4 % 3);
/*  445 */     mBlock.luma16x16Mode = mbType % 4;
/*  446 */     mBlock.chromaPredictionMode = readChromaPredMode(mbX, leftAvailable, topAvailable);
/*  447 */     mBlock.mbQPDelta = readMBQpDelta(mBlock.prevMbType);
/*  448 */     read16x16DC(leftAvailable, topAvailable, mbX, mBlock.dc);
/*  449 */     for (int i = 0; i < 16; i++) {
/*  450 */       int blkOffLeft = H264Const.MB_BLK_OFF_LEFT[i];
/*  451 */       int blkOffTop = H264Const.MB_BLK_OFF_TOP[i];
/*  452 */       int blkX = (mbX << 2) + blkOffLeft;
/*  453 */       int blkY = (mbY << 2) + blkOffTop;
/*      */       
/*  455 */       if ((mBlock.cbpLuma() & 1 << i >> 2) != 0) {
/*  456 */         mBlock.nCoeff[i] = read16x16AC(leftAvailable, topAvailable, mbX, mBlock.cbpLuma(), mBlock.ac[0][i], blkOffLeft, blkOffTop, blkX, blkY);
/*      */       
/*      */       }
/*  459 */       else if (!this.sh.pps.entropyCodingModeFlag) {
/*  460 */         setZeroCoeff(0, blkX, blkOffTop);
/*      */       } 
/*      */     } 
/*      */     
/*  464 */     if (this.chromaFormat != ColorSpace.MONO) {
/*  465 */       readChromaResidual(mBlock, leftAvailable, topAvailable, mbX);
/*      */     }
/*      */   }
/*      */   
/*      */   public void readMBlockBDirect(MBlock mBlock) {
/*  470 */     int mbX = this.mapper.getMbX(mBlock.mbIdx);
/*  471 */     int mbY = this.mapper.getMbY(mBlock.mbIdx);
/*  472 */     boolean lAvb = this.mapper.leftAvailable(mBlock.mbIdx);
/*  473 */     boolean tAvb = this.mapper.topAvailable(mBlock.mbIdx);
/*  474 */     mBlock._cbp = readCodedBlockPatternInter(lAvb, tAvb, this.leftCBPLuma | this.leftCBPChroma << 4, this.topCBPLuma[mbX] | this.topCBPChroma[mbX] << 4, this.leftMBType, this.topMBType[mbX]);
/*      */ 
/*      */     
/*  477 */     mBlock.transform8x8Used = false;
/*  478 */     if (this.transform8x8 && mBlock.cbpLuma() != 0 && this.sh.sps.direct8x8InferenceFlag) {
/*  479 */       mBlock.transform8x8Used = readTransform8x8Flag(lAvb, tAvb, this.leftMBType, this.topMBType[mbX], this.tf8x8Left, this.tf8x8Top[mbX]);
/*      */     }
/*      */ 
/*      */     
/*  483 */     if (mBlock.cbpLuma() > 0 || mBlock.cbpChroma() > 0) {
/*  484 */       mBlock.mbQPDelta = readMBQpDelta(mBlock.prevMbType);
/*      */     }
/*  486 */     readResidualLuma(mBlock, lAvb, tAvb, mbX, mbY);
/*  487 */     readChromaResidual(mBlock, lAvb, tAvb, mbX);
/*      */     
/*  489 */     this.predModeLeft[1] = H264Const.PartPred.Direct; this.predModeLeft[0] = H264Const.PartPred.Direct; this.predModeTop[(mbX << 1) + 1] = H264Const.PartPred.Direct; this.predModeTop[mbX << 1] = H264Const.PartPred.Direct;
/*      */   }
/*      */   
/*      */   public void readInter16x16(H264Const.PartPred p0, MBlock mBlock) {
/*  493 */     int mbX = this.mapper.getMbX(mBlock.mbIdx);
/*  494 */     int mbY = this.mapper.getMbY(mBlock.mbIdx);
/*  495 */     boolean leftAvailable = this.mapper.leftAvailable(mBlock.mbIdx);
/*  496 */     boolean topAvailable = this.mapper.topAvailable(mBlock.mbIdx);
/*      */     int list;
/*  498 */     for (list = 0; list < 2; list++) {
/*  499 */       if (H264Const.usesList(p0, list) && this.numRef[list] > 1) {
/*  500 */         mBlock.pb16x16.refIdx[list] = readRefIdx(leftAvailable, topAvailable, this.leftMBType, this.topMBType[mbX], this.predModeLeft[0], this.predModeTop[mbX << 1], p0, mbX, 0, 0, 4, 4, list);
/*      */       }
/*      */     } 
/*  503 */     for (list = 0; list < 2; list++) {
/*  504 */       readPredictionInter16x16(mBlock, mbX, leftAvailable, topAvailable, list, p0);
/*      */     }
/*  506 */     readResidualInter(mBlock, leftAvailable, topAvailable, mbX, mbY);
/*      */     
/*  508 */     this.predModeTop[(mbX << 1) + 1] = p0; this.predModeTop[mbX << 1] = p0; this.predModeLeft[1] = p0; this.predModeLeft[0] = p0;
/*      */   }
/*      */ 
/*      */   
/*      */   private void readPredInter8x16(MBlock mBlock, int mbX, boolean leftAvailable, boolean topAvailable, int list, H264Const.PartPred p0, H264Const.PartPred p1) {
/*  513 */     int blk8x8X = mbX << 1;
/*      */     
/*  515 */     if (H264Const.usesList(p0, list)) {
/*  516 */       mBlock.pb168x168.mvdX1[list] = readMVD(0, leftAvailable, topAvailable, this.leftMBType, this.topMBType[mbX], this.predModeLeft[0], this.predModeTop[blk8x8X], p0, mbX, 0, 0, 2, 4, list);
/*      */       
/*  518 */       mBlock.pb168x168.mvdY1[list] = readMVD(1, leftAvailable, topAvailable, this.leftMBType, this.topMBType[mbX], this.predModeLeft[0], this.predModeTop[blk8x8X], p0, mbX, 0, 0, 2, 4, list);
/*      */     } 
/*      */ 
/*      */ 
/*      */     
/*  523 */     if (H264Const.usesList(p1, list)) {
/*  524 */       mBlock.pb168x168.mvdX2[list] = readMVD(0, true, topAvailable, MBType.P_8x16, this.topMBType[mbX], p0, this.predModeTop[blk8x8X + 1], p1, mbX, 2, 0, 2, 4, list);
/*      */       
/*  526 */       mBlock.pb168x168.mvdY2[list] = readMVD(1, true, topAvailable, MBType.P_8x16, this.topMBType[mbX], p0, this.predModeTop[blk8x8X + 1], p1, mbX, 2, 0, 2, 4, list);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private void readPredictionInter16x8(MBlock mBlock, int mbX, boolean leftAvailable, boolean topAvailable, H264Const.PartPred p0, H264Const.PartPred p1, int list) {
/*  534 */     int blk8x8X = mbX << 1;
/*  535 */     if (H264Const.usesList(p0, list)) {
/*      */       
/*  537 */       mBlock.pb168x168.mvdX1[list] = readMVD(0, leftAvailable, topAvailable, this.leftMBType, this.topMBType[mbX], this.predModeLeft[0], this.predModeTop[blk8x8X], p0, mbX, 0, 0, 4, 2, list);
/*      */       
/*  539 */       mBlock.pb168x168.mvdY1[list] = readMVD(1, leftAvailable, topAvailable, this.leftMBType, this.topMBType[mbX], this.predModeLeft[0], this.predModeTop[blk8x8X], p0, mbX, 0, 0, 4, 2, list);
/*      */     } 
/*      */ 
/*      */     
/*  543 */     if (H264Const.usesList(p1, list)) {
/*  544 */       mBlock.pb168x168.mvdX2[list] = readMVD(0, leftAvailable, true, this.leftMBType, MBType.P_16x8, this.predModeLeft[1], p0, p1, mbX, 0, 2, 4, 2, list);
/*      */       
/*  546 */       mBlock.pb168x168.mvdY2[list] = readMVD(1, leftAvailable, true, this.leftMBType, MBType.P_16x8, this.predModeLeft[1], p0, p1, mbX, 0, 2, 4, 2, list);
/*      */     } 
/*      */   }
/*      */ 
/*      */   
/*      */   public void readInter16x8(H264Const.PartPred p0, H264Const.PartPred p1, MBlock mBlock) {
/*  552 */     int mbX = this.mapper.getMbX(mBlock.mbIdx);
/*  553 */     int mbY = this.mapper.getMbY(mBlock.mbIdx);
/*  554 */     boolean leftAvailable = this.mapper.leftAvailable(mBlock.mbIdx);
/*  555 */     boolean topAvailable = this.mapper.topAvailable(mBlock.mbIdx);
/*      */     int list;
/*  557 */     for (list = 0; list < 2; list++) {
/*  558 */       if (H264Const.usesList(p0, list) && this.numRef[list] > 1) {
/*  559 */         mBlock.pb168x168.refIdx1[list] = readRefIdx(leftAvailable, topAvailable, this.leftMBType, this.topMBType[mbX], this.predModeLeft[0], this.predModeTop[mbX << 1], p0, mbX, 0, 0, 4, 2, list);
/*      */       }
/*  561 */       if (H264Const.usesList(p1, list) && this.numRef[list] > 1) {
/*  562 */         mBlock.pb168x168.refIdx2[list] = readRefIdx(leftAvailable, true, this.leftMBType, mBlock.curMbType, this.predModeLeft[1], p0, p1, mbX, 0, 2, 4, 2, list);
/*      */       }
/*      */     } 
/*      */     
/*  566 */     for (list = 0; list < 2; list++) {
/*  567 */       readPredictionInter16x8(mBlock, mbX, leftAvailable, topAvailable, p0, p1, list);
/*      */     }
/*  569 */     readResidualInter(mBlock, leftAvailable, topAvailable, mbX, mbY);
/*      */     
/*  571 */     this.predModeLeft[0] = p0;
/*  572 */     this.predModeTop[(mbX << 1) + 1] = p1; this.predModeTop[mbX << 1] = p1; this.predModeLeft[1] = p1;
/*      */   }
/*      */   
/*      */   public void readIntra8x16(H264Const.PartPred p0, H264Const.PartPred p1, MBlock mBlock) {
/*  576 */     int mbX = this.mapper.getMbX(mBlock.mbIdx);
/*  577 */     int mbY = this.mapper.getMbY(mBlock.mbIdx);
/*  578 */     boolean leftAvailable = this.mapper.leftAvailable(mBlock.mbIdx);
/*  579 */     boolean topAvailable = this.mapper.topAvailable(mBlock.mbIdx); int list;
/*  580 */     for (list = 0; list < 2; list++) {
/*  581 */       if (H264Const.usesList(p0, list) && this.numRef[list] > 1) {
/*  582 */         mBlock.pb168x168.refIdx1[list] = readRefIdx(leftAvailable, topAvailable, this.leftMBType, this.topMBType[mbX], this.predModeLeft[0], this.predModeTop[mbX << 1], p0, mbX, 0, 0, 2, 4, list);
/*      */       }
/*  584 */       if (H264Const.usesList(p1, list) && this.numRef[list] > 1) {
/*  585 */         mBlock.pb168x168.refIdx2[list] = readRefIdx(true, topAvailable, mBlock.curMbType, this.topMBType[mbX], p0, this.predModeTop[(mbX << 1) + 1], p1, mbX, 2, 0, 2, 4, list);
/*      */       }
/*      */     } 
/*      */     
/*  589 */     for (list = 0; list < 2; list++) {
/*  590 */       readPredInter8x16(mBlock, mbX, leftAvailable, topAvailable, list, p0, p1);
/*      */     }
/*  592 */     readResidualInter(mBlock, leftAvailable, topAvailable, mbX, mbY);
/*  593 */     this.predModeTop[mbX << 1] = p0;
/*  594 */     this.predModeLeft[1] = p1; this.predModeLeft[0] = p1; this.predModeTop[(mbX << 1) + 1] = p1;
/*      */   }
/*      */ 
/*      */   
/*      */   private void readPredictionInter16x16(MBlock mBlock, int mbX, boolean leftAvailable, boolean topAvailable, int list, H264Const.PartPred curPred) {
/*  599 */     int blk8x8X = mbX << 1;
/*      */     
/*  601 */     if (H264Const.usesList(curPred, list)) {
/*  602 */       mBlock.pb16x16.mvdX[list] = readMVD(0, leftAvailable, topAvailable, this.leftMBType, this.topMBType[mbX], this.predModeLeft[0], this.predModeTop[blk8x8X], curPred, mbX, 0, 0, 4, 4, list);
/*      */       
/*  604 */       mBlock.pb16x16.mvdY[list] = readMVD(1, leftAvailable, topAvailable, this.leftMBType, this.topMBType[mbX], this.predModeLeft[0], this.predModeTop[blk8x8X], curPred, mbX, 0, 0, 4, 4, list);
/*      */     } 
/*      */   }
/*      */ 
/*      */   
/*      */   private void readResidualInter(MBlock mBlock, boolean leftAvailable, boolean topAvailable, int mbX, int mbY) {
/*  610 */     mBlock._cbp = readCodedBlockPatternInter(leftAvailable, topAvailable, this.leftCBPLuma | this.leftCBPChroma << 4, this.topCBPLuma[mbX] | this.topCBPChroma[mbX] << 4, this.leftMBType, this.topMBType[mbX]);
/*      */ 
/*      */     
/*  613 */     mBlock.transform8x8Used = false;
/*  614 */     if (mBlock.cbpLuma() != 0 && this.transform8x8) {
/*  615 */       mBlock.transform8x8Used = readTransform8x8Flag(leftAvailable, topAvailable, this.leftMBType, this.topMBType[mbX], this.tf8x8Left, this.tf8x8Top[mbX]);
/*      */     }
/*      */ 
/*      */     
/*  619 */     if (mBlock.cbpLuma() > 0 || mBlock.cbpChroma() > 0) {
/*  620 */       mBlock.mbQPDelta = readMBQpDelta(mBlock.prevMbType);
/*      */     }
/*      */     
/*  623 */     readResidualLuma(mBlock, leftAvailable, topAvailable, mbX, mbY);
/*      */     
/*  625 */     if (this.chromaFormat != ColorSpace.MONO)
/*  626 */       readChromaResidual(mBlock, leftAvailable, topAvailable, mbX); 
/*      */   }
/*      */   
/*      */   public void readMBlock8x8(MBlock mBlock) {
/*      */     boolean noSubMBLessThen8x8;
/*  631 */     int mbX = this.mapper.getMbX(mBlock.mbIdx);
/*  632 */     int mbY = this.mapper.getMbY(mBlock.mbIdx);
/*  633 */     boolean leftAvailable = this.mapper.leftAvailable(mBlock.mbIdx);
/*  634 */     boolean topAvailable = this.mapper.topAvailable(mBlock.mbIdx);
/*      */ 
/*      */     
/*  637 */     if (mBlock.curMbType == MBType.P_8x8 || mBlock.curMbType == MBType.P_8x8ref0) {
/*  638 */       readPrediction8x8P(mBlock, mbX, leftAvailable, topAvailable);
/*      */       
/*  640 */       noSubMBLessThen8x8 = (mBlock.pb8x8.subMbTypes[0] == 0 && mBlock.pb8x8.subMbTypes[1] == 0 && mBlock.pb8x8.subMbTypes[2] == 0 && mBlock.pb8x8.subMbTypes[3] == 0);
/*      */     } else {
/*      */       
/*  643 */       readPrediction8x8B(mBlock, mbX, leftAvailable, topAvailable);
/*  644 */       noSubMBLessThen8x8 = (H264Const.bSubMbTypes[mBlock.pb8x8.subMbTypes[0]] == 0 && H264Const.bSubMbTypes[mBlock.pb8x8.subMbTypes[1]] == 0 && H264Const.bSubMbTypes[mBlock.pb8x8.subMbTypes[2]] == 0 && H264Const.bSubMbTypes[mBlock.pb8x8.subMbTypes[3]] == 0);
/*      */     } 
/*      */ 
/*      */ 
/*      */     
/*  649 */     mBlock._cbp = readCodedBlockPatternInter(leftAvailable, topAvailable, this.leftCBPLuma | this.leftCBPChroma << 4, this.topCBPLuma[mbX] | this.topCBPChroma[mbX] << 4, this.leftMBType, this.topMBType[mbX]);
/*      */ 
/*      */     
/*  652 */     mBlock.transform8x8Used = false;
/*  653 */     if (this.transform8x8 && mBlock.cbpLuma() != 0 && noSubMBLessThen8x8) {
/*  654 */       mBlock.transform8x8Used = readTransform8x8Flag(leftAvailable, topAvailable, this.leftMBType, this.topMBType[mbX], this.tf8x8Left, this.tf8x8Top[mbX]);
/*      */     }
/*      */ 
/*      */     
/*  658 */     if (mBlock.cbpLuma() > 0 || mBlock.cbpChroma() > 0) {
/*  659 */       mBlock.mbQPDelta = readMBQpDelta(mBlock.prevMbType);
/*      */     }
/*  661 */     readResidualLuma(mBlock, leftAvailable, topAvailable, mbX, mbY);
/*  662 */     readChromaResidual(mBlock, leftAvailable, topAvailable, mbX);
/*      */   }
/*      */   
/*      */   private void readPrediction8x8P(MBlock mBlock, int mbX, boolean leftAvailable, boolean topAvailable) {
/*  666 */     for (int i = 0; i < 4; i++) {
/*  667 */       mBlock.pb8x8.subMbTypes[i] = readSubMBTypeP();
/*      */     }
/*      */     
/*  670 */     if (this.numRef[0] > 1 && mBlock.curMbType != MBType.P_8x8ref0) {
/*  671 */       mBlock.pb8x8.refIdx[0][0] = readRefIdx(leftAvailable, topAvailable, this.leftMBType, this.topMBType[mbX], H264Const.PartPred.L0, H264Const.PartPred.L0, H264Const.PartPred.L0, mbX, 0, 0, 2, 2, 0);
/*      */       
/*  673 */       mBlock.pb8x8.refIdx[0][1] = readRefIdx(true, topAvailable, MBType.P_8x8, this.topMBType[mbX], H264Const.PartPred.L0, H264Const.PartPred.L0, H264Const.PartPred.L0, mbX, 2, 0, 2, 2, 0);
/*      */       
/*  675 */       mBlock.pb8x8.refIdx[0][2] = readRefIdx(leftAvailable, true, this.leftMBType, MBType.P_8x8, H264Const.PartPred.L0, H264Const.PartPred.L0, H264Const.PartPred.L0, mbX, 0, 2, 2, 2, 0);
/*      */       
/*  677 */       mBlock.pb8x8.refIdx[0][3] = readRefIdx(true, true, MBType.P_8x8, MBType.P_8x8, H264Const.PartPred.L0, H264Const.PartPred.L0, H264Const.PartPred.L0, mbX, 2, 2, 2, 2, 0);
/*      */     } 
/*      */     
/*  680 */     readSubMb8x8(mBlock, 0, mBlock.pb8x8.subMbTypes[0], topAvailable, leftAvailable, 0, 0, mbX, this.leftMBType, this.topMBType[mbX], MBType.P_8x8, H264Const.PartPred.L0, H264Const.PartPred.L0, H264Const.PartPred.L0, 0);
/*      */     
/*  682 */     readSubMb8x8(mBlock, 1, mBlock.pb8x8.subMbTypes[1], topAvailable, true, 2, 0, mbX, MBType.P_8x8, this.topMBType[mbX], MBType.P_8x8, H264Const.PartPred.L0, H264Const.PartPred.L0, H264Const.PartPred.L0, 0);
/*      */     
/*  684 */     readSubMb8x8(mBlock, 2, mBlock.pb8x8.subMbTypes[2], true, leftAvailable, 0, 2, mbX, this.leftMBType, MBType.P_8x8, MBType.P_8x8, H264Const.PartPred.L0, H264Const.PartPred.L0, H264Const.PartPred.L0, 0);
/*      */     
/*  686 */     readSubMb8x8(mBlock, 3, mBlock.pb8x8.subMbTypes[3], true, true, 2, 2, mbX, MBType.P_8x8, MBType.P_8x8, MBType.P_8x8, H264Const.PartPred.L0, H264Const.PartPred.L0, H264Const.PartPred.L0, 0);
/*      */     
/*  688 */     int blk8x8X = mbX << 1;
/*      */     
/*  690 */     this.predModeTop[blk8x8X + 1] = H264Const.PartPred.L0; this.predModeTop[blk8x8X] = H264Const.PartPred.L0; this.predModeLeft[1] = H264Const.PartPred.L0; this.predModeLeft[0] = H264Const.PartPred.L0;
/*      */   }
/*      */   
/*      */   private void readPrediction8x8B(MBlock mBlock, int mbX, boolean leftAvailable, boolean topAvailable) {
/*  694 */     H264Const.PartPred[] p = new H264Const.PartPred[4];
/*  695 */     for (int i = 0; i < 4; i++) {
/*  696 */       mBlock.pb8x8.subMbTypes[i] = readSubMBTypeB();
/*  697 */       p[i] = H264Const.bPartPredModes[mBlock.pb8x8.subMbTypes[i]];
/*      */     } 
/*      */     
/*  700 */     for (int list = 0; list < 2; list++) {
/*  701 */       if (this.numRef[list] > 1) {
/*      */         
/*  703 */         if (H264Const.usesList(p[0], list)) {
/*  704 */           mBlock.pb8x8.refIdx[list][0] = readRefIdx(leftAvailable, topAvailable, this.leftMBType, this.topMBType[mbX], this.predModeLeft[0], this.predModeTop[mbX << 1], p[0], mbX, 0, 0, 2, 2, list);
/*      */         }
/*  706 */         if (H264Const.usesList(p[1], list)) {
/*  707 */           mBlock.pb8x8.refIdx[list][1] = readRefIdx(true, topAvailable, MBType.B_8x8, this.topMBType[mbX], p[0], this.predModeTop[(mbX << 1) + 1], p[1], mbX, 2, 0, 2, 2, list);
/*      */         }
/*  709 */         if (H264Const.usesList(p[2], list)) {
/*  710 */           mBlock.pb8x8.refIdx[list][2] = readRefIdx(leftAvailable, true, this.leftMBType, MBType.B_8x8, this.predModeLeft[1], p[0], p[2], mbX, 0, 2, 2, 2, list);
/*      */         }
/*  712 */         if (H264Const.usesList(p[3], list)) {
/*  713 */           mBlock.pb8x8.refIdx[list][3] = readRefIdx(true, true, MBType.B_8x8, MBType.B_8x8, p[2], p[1], p[3], mbX, 2, 2, 2, 2, list);
/*      */         }
/*      */       } 
/*      */     } 
/*  717 */     MBlockDecoderUtils.debugPrint(new Object[] { "Pred: " + p[0] + ", " + p[1] + ", " + p[2] + ", " + p[3] });
/*      */     
/*  719 */     int blk8x8X = mbX << 1;
/*  720 */     for (int j = 0; j < 2; j++) {
/*  721 */       if (H264Const.usesList(p[0], j)) {
/*  722 */         readSubMb8x8(mBlock, 0, H264Const.bSubMbTypes[mBlock.pb8x8.subMbTypes[0]], topAvailable, leftAvailable, 0, 0, mbX, this.leftMBType, this.topMBType[mbX], MBType.B_8x8, this.predModeLeft[0], this.predModeTop[blk8x8X], p[0], j);
/*      */       }
/*      */       
/*  725 */       if (H264Const.usesList(p[1], j)) {
/*  726 */         readSubMb8x8(mBlock, 1, H264Const.bSubMbTypes[mBlock.pb8x8.subMbTypes[1]], topAvailable, true, 2, 0, mbX, MBType.B_8x8, this.topMBType[mbX], MBType.B_8x8, p[0], this.predModeTop[blk8x8X + 1], p[1], j);
/*      */       }
/*      */ 
/*      */       
/*  730 */       if (H264Const.usesList(p[2], j)) {
/*  731 */         readSubMb8x8(mBlock, 2, H264Const.bSubMbTypes[mBlock.pb8x8.subMbTypes[2]], true, leftAvailable, 0, 2, mbX, this.leftMBType, MBType.B_8x8, MBType.B_8x8, this.predModeLeft[1], p[0], p[2], j);
/*      */       }
/*      */ 
/*      */       
/*  735 */       if (H264Const.usesList(p[3], j)) {
/*  736 */         readSubMb8x8(mBlock, 3, H264Const.bSubMbTypes[mBlock.pb8x8.subMbTypes[3]], true, true, 2, 2, mbX, MBType.B_8x8, MBType.B_8x8, MBType.B_8x8, p[2], p[1], p[3], j);
/*      */       }
/*      */     } 
/*      */ 
/*      */     
/*  741 */     this.predModeLeft[0] = p[1];
/*  742 */     this.predModeTop[blk8x8X] = p[2];
/*  743 */     this.predModeTop[blk8x8X + 1] = p[3]; this.predModeLeft[1] = p[3];
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   private void readSubMb8x8(MBlock mBlock, int partNo, int subMbType, boolean tAvb, boolean lAvb, int blk8x8X, int blk8x8Y, int mbX, MBType leftMBType, MBType topMBType, MBType curMBType, H264Const.PartPred leftPred, H264Const.PartPred topPred, H264Const.PartPred partPred, int list) {
/*  749 */     switch (subMbType) {
/*      */       case 3:
/*  751 */         readSub4x4(mBlock, partNo, tAvb, lAvb, blk8x8X, blk8x8Y, mbX, leftMBType, topMBType, curMBType, leftPred, topPred, partPred, list);
/*      */         break;
/*      */       
/*      */       case 2:
/*  755 */         readSub4x8(mBlock, partNo, tAvb, lAvb, blk8x8X, blk8x8Y, mbX, leftMBType, topMBType, curMBType, leftPred, topPred, partPred, list);
/*      */         break;
/*      */       
/*      */       case 1:
/*  759 */         readSub8x4(mBlock, partNo, tAvb, lAvb, blk8x8X, blk8x8Y, mbX, leftMBType, topMBType, curMBType, leftPred, topPred, partPred, list);
/*      */         break;
/*      */       
/*      */       case 0:
/*  763 */         readSub8x8(mBlock, partNo, tAvb, lAvb, blk8x8X, blk8x8Y, mbX, leftMBType, topMBType, leftPred, topPred, partPred, list);
/*      */         break;
/*      */     } 
/*      */   }
/*      */ 
/*      */   
/*      */   private void readSub8x8(MBlock mBlock, int partNo, boolean tAvb, boolean lAvb, int blk8x8X, int blk8x8Y, int mbX, MBType leftMBType, MBType topMBType, H264Const.PartPred leftPred, H264Const.PartPred topPred, H264Const.PartPred partPred, int list) {
/*  770 */     mBlock.pb8x8.mvdX1[list][partNo] = readMVD(0, lAvb, tAvb, leftMBType, topMBType, leftPred, topPred, partPred, mbX, blk8x8X, blk8x8Y, 2, 2, list);
/*      */     
/*  772 */     mBlock.pb8x8.mvdY1[list][partNo] = readMVD(1, lAvb, tAvb, leftMBType, topMBType, leftPred, topPred, partPred, mbX, blk8x8X, blk8x8Y, 2, 2, list);
/*      */     
/*  774 */     MBlockDecoderUtils.debugPrint(new Object[] { "mvd: (%d, %d)", Integer.valueOf(mBlock.pb8x8.mvdX1[list][partNo]), Integer.valueOf(mBlock.pb8x8.mvdY1[list][partNo]) });
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   private void readSub8x4(MBlock mBlock, int partNo, boolean tAvb, boolean lAvb, int blk8x8X, int blk8x8Y, int mbX, MBType leftMBType, MBType topMBType, MBType curMBType, H264Const.PartPred leftPred, H264Const.PartPred topPred, H264Const.PartPred partPred, int list) {
/*  780 */     mBlock.pb8x8.mvdX1[list][partNo] = readMVD(0, lAvb, tAvb, leftMBType, topMBType, leftPred, topPred, partPred, mbX, blk8x8X, blk8x8Y, 2, 1, list);
/*      */     
/*  782 */     mBlock.pb8x8.mvdY1[list][partNo] = readMVD(1, lAvb, tAvb, leftMBType, topMBType, leftPred, topPred, partPred, mbX, blk8x8X, blk8x8Y, 2, 1, list);
/*      */ 
/*      */     
/*  785 */     mBlock.pb8x8.mvdX2[list][partNo] = readMVD(0, lAvb, true, leftMBType, curMBType, leftPred, partPred, partPred, mbX, blk8x8X, blk8x8Y + 1, 2, 1, list);
/*      */     
/*  787 */     mBlock.pb8x8.mvdY2[list][partNo] = readMVD(1, lAvb, true, leftMBType, curMBType, leftPred, partPred, partPred, mbX, blk8x8X, blk8x8Y + 1, 2, 1, list);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private void readSub4x8(MBlock mBlock, int partNo, boolean tAvb, boolean lAvb, int blk8x8X, int blk8x8Y, int mbX, MBType leftMBType, MBType topMBType, MBType curMBType, H264Const.PartPred leftPred, H264Const.PartPred topPred, H264Const.PartPred partPred, int list) {
/*  794 */     mBlock.pb8x8.mvdX1[list][partNo] = readMVD(0, lAvb, tAvb, leftMBType, topMBType, leftPred, topPred, partPred, mbX, blk8x8X, blk8x8Y, 1, 2, list);
/*      */     
/*  796 */     mBlock.pb8x8.mvdY1[list][partNo] = readMVD(1, lAvb, tAvb, leftMBType, topMBType, leftPred, topPred, partPred, mbX, blk8x8X, blk8x8Y, 1, 2, list);
/*      */     
/*  798 */     mBlock.pb8x8.mvdX2[list][partNo] = readMVD(0, true, tAvb, curMBType, topMBType, partPred, topPred, partPred, mbX, blk8x8X + 1, blk8x8Y, 1, 2, list);
/*      */     
/*  800 */     mBlock.pb8x8.mvdY2[list][partNo] = readMVD(1, true, tAvb, curMBType, topMBType, partPred, topPred, partPred, mbX, blk8x8X + 1, blk8x8Y, 1, 2, list);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private void readSub4x4(MBlock mBlock, int partNo, boolean tAvb, boolean lAvb, int blk8x8X, int blk8x8Y, int mbX, MBType leftMBType, MBType topMBType, MBType curMBType, H264Const.PartPred leftPred, H264Const.PartPred topPred, H264Const.PartPred partPred, int list) {
/*  807 */     mBlock.pb8x8.mvdX1[list][partNo] = readMVD(0, lAvb, tAvb, leftMBType, topMBType, leftPred, topPred, partPred, mbX, blk8x8X, blk8x8Y, 1, 1, list);
/*      */     
/*  809 */     mBlock.pb8x8.mvdY1[list][partNo] = readMVD(1, lAvb, tAvb, leftMBType, topMBType, leftPred, topPred, partPred, mbX, blk8x8X, blk8x8Y, 1, 1, list);
/*      */     
/*  811 */     mBlock.pb8x8.mvdX2[list][partNo] = readMVD(0, true, tAvb, curMBType, topMBType, partPred, topPred, partPred, mbX, blk8x8X + 1, blk8x8Y, 1, 1, list);
/*      */     
/*  813 */     mBlock.pb8x8.mvdY2[list][partNo] = readMVD(1, true, tAvb, curMBType, topMBType, partPred, topPred, partPred, mbX, blk8x8X + 1, blk8x8Y, 1, 1, list);
/*      */     
/*  815 */     mBlock.pb8x8.mvdX3[list][partNo] = readMVD(0, lAvb, true, leftMBType, curMBType, leftPred, partPred, partPred, mbX, blk8x8X, blk8x8Y + 1, 1, 1, list);
/*      */     
/*  817 */     mBlock.pb8x8.mvdY3[list][partNo] = readMVD(1, lAvb, true, leftMBType, curMBType, leftPred, partPred, partPred, mbX, blk8x8X, blk8x8Y + 1, 1, 1, list);
/*      */     
/*  819 */     mBlock.pb8x8.mvdX4[list][partNo] = readMVD(0, true, true, curMBType, curMBType, partPred, partPred, partPred, mbX, blk8x8X + 1, blk8x8Y + 1, 1, 1, list);
/*      */     
/*  821 */     mBlock.pb8x8.mvdY4[list][partNo] = readMVD(1, true, true, curMBType, curMBType, partPred, partPred, partPred, mbX, blk8x8X + 1, blk8x8Y + 1, 1, 1, list);
/*      */   }
/*      */ 
/*      */   
/*      */   public void readIntraNxN(MBlock mBlock) {
/*  826 */     int mbX = this.mapper.getMbX(mBlock.mbIdx);
/*  827 */     int mbY = this.mapper.getMbY(mBlock.mbIdx);
/*  828 */     boolean leftAvailable = this.mapper.leftAvailable(mBlock.mbIdx);
/*  829 */     boolean topAvailable = this.mapper.topAvailable(mBlock.mbIdx);
/*      */     
/*  831 */     mBlock.transform8x8Used = false;
/*  832 */     if (this.transform8x8) {
/*  833 */       mBlock.transform8x8Used = readTransform8x8Flag(leftAvailable, topAvailable, this.leftMBType, this.topMBType[mbX], this.tf8x8Left, this.tf8x8Top[mbX]);
/*      */     }
/*      */ 
/*      */     
/*  837 */     if (!mBlock.transform8x8Used) {
/*  838 */       for (int i = 0; i < 16; i++) {
/*  839 */         int blkX = H264Const.MB_BLK_OFF_LEFT[i];
/*  840 */         int blkY = H264Const.MB_BLK_OFF_TOP[i];
/*  841 */         mBlock.lumaModes[i] = readPredictionI4x4Block(leftAvailable, topAvailable, this.leftMBType, this.topMBType[mbX], blkX, blkY, mbX);
/*      */       } 
/*      */     } else {
/*      */       
/*  845 */       for (int i = 0; i < 4; i++) {
/*  846 */         int blkX = (i & 0x1) << 1;
/*  847 */         int blkY = i & 0x2;
/*  848 */         mBlock.lumaModes[i] = readPredictionI4x4Block(leftAvailable, topAvailable, this.leftMBType, this.topMBType[mbX], blkX, blkY, mbX);
/*      */         
/*  850 */         this.i4x4PredLeft[blkY + 1] = this.i4x4PredLeft[blkY];
/*  851 */         this.i4x4PredTop[(mbX << 2) + blkX + 1] = this.i4x4PredTop[(mbX << 2) + blkX];
/*      */       } 
/*      */     } 
/*  854 */     mBlock.chromaPredictionMode = readChromaPredMode(mbX, leftAvailable, topAvailable);
/*      */     
/*  856 */     mBlock._cbp = readCodedBlockPatternIntra(leftAvailable, topAvailable, this.leftCBPLuma | this.leftCBPChroma << 4, this.topCBPLuma[mbX] | this.topCBPChroma[mbX] << 4, this.leftMBType, this.topMBType[mbX]);
/*      */ 
/*      */     
/*  859 */     if (mBlock.cbpLuma() > 0 || mBlock.cbpChroma() > 0) {
/*  860 */       mBlock.mbQPDelta = readMBQpDelta(mBlock.prevMbType);
/*      */     }
/*  862 */     readResidualLuma(mBlock, leftAvailable, topAvailable, mbX, mbY);
/*  863 */     if (this.chromaFormat != ColorSpace.MONO) {
/*  864 */       readChromaResidual(mBlock, leftAvailable, topAvailable, mbX);
/*      */     }
/*      */   }
/*      */   
/*      */   public void readResidualLuma(MBlock mBlock, boolean leftAvailable, boolean topAvailable, int mbX, int mbY) {
/*  869 */     if (!mBlock.transform8x8Used) {
/*  870 */       readLuma(mBlock, leftAvailable, topAvailable, mbX, mbY);
/*  871 */     } else if (this.sh.pps.entropyCodingModeFlag) {
/*  872 */       readLuma8x8CABAC(mBlock, mbX, mbY);
/*      */     } else {
/*  874 */       readLuma8x8CAVLC(mBlock, leftAvailable, topAvailable, mbX, mbY);
/*      */     } 
/*      */   }
/*      */   
/*      */   private void readLuma(MBlock mBlock, boolean leftAvailable, boolean topAvailable, int mbX, int mbY) {
/*  879 */     for (int i = 0; i < 16; i++) {
/*  880 */       int blkOffLeft = H264Const.MB_BLK_OFF_LEFT[i];
/*  881 */       int blkOffTop = H264Const.MB_BLK_OFF_TOP[i];
/*  882 */       int blkX = (mbX << 2) + blkOffLeft;
/*  883 */       int blkY = (mbY << 2) + blkOffTop;
/*      */       
/*  885 */       if ((mBlock.cbpLuma() & 1 << i >> 2) == 0) {
/*  886 */         if (!this.sh.pps.entropyCodingModeFlag) {
/*  887 */           setZeroCoeff(0, blkX, blkOffTop);
/*      */         }
/*      */       } else {
/*      */         
/*  891 */         mBlock.nCoeff[i] = readResidualAC(leftAvailable, topAvailable, mbX, mBlock.curMbType, mBlock.cbpLuma(), blkOffLeft, blkOffTop, blkX, blkY, mBlock.ac[0][i]);
/*      */       } 
/*      */     } 
/*      */     
/*  895 */     savePrevCBP(mBlock._cbp);
/*      */   }
/*      */   
/*      */   private void readLuma8x8CABAC(MBlock mBlock, int mbX, int mbY) {
/*  899 */     for (int i = 0; i < 4; i++) {
/*  900 */       int blkOffLeft = (i & 0x1) << 1;
/*  901 */       int blkOffTop = i & 0x2;
/*  902 */       int blkX = (mbX << 2) + blkOffLeft;
/*  903 */       int blkY = (mbY << 2) + blkOffTop;
/*      */       
/*  905 */       if ((mBlock.cbpLuma() & 1 << i) != 0) {
/*      */ 
/*      */ 
/*      */         
/*  909 */         int nCoeff = readLumaAC8x8(blkX, blkY, mBlock.ac[0][i]);
/*      */         
/*  911 */         int blk4x4Offset = i << 2;
/*  912 */         mBlock.nCoeff[blk4x4Offset + 3] = nCoeff; mBlock.nCoeff[blk4x4Offset + 2] = nCoeff; mBlock.nCoeff[blk4x4Offset + 1] = nCoeff; mBlock.nCoeff[blk4x4Offset] = nCoeff;
/*      */       } 
/*  914 */     }  savePrevCBP(mBlock._cbp);
/*      */   }
/*      */   
/*      */   private void readLuma8x8CAVLC(MBlock mBlock, boolean leftAvailable, boolean topAvailable, int mbX, int mbY) {
/*  918 */     for (int i = 0; i < 4; i++) {
/*  919 */       int blk8x8OffLeft = (i & 0x1) << 1;
/*  920 */       int blk8x8OffTop = i & 0x2;
/*  921 */       int blkX = (mbX << 2) + blk8x8OffLeft;
/*  922 */       int blkY = (mbY << 2) + blk8x8OffTop;
/*      */       
/*  924 */       if ((mBlock.cbpLuma() & 1 << i) == 0) {
/*  925 */         setZeroCoeff(0, blkX, blk8x8OffTop);
/*  926 */         setZeroCoeff(0, blkX + 1, blk8x8OffTop);
/*  927 */         setZeroCoeff(0, blkX, blk8x8OffTop + 1);
/*  928 */         setZeroCoeff(0, blkX + 1, blk8x8OffTop + 1);
/*      */       } else {
/*      */         
/*  931 */         int coeffs = 0;
/*  932 */         for (int j = 0; j < 4; j++) {
/*  933 */           int[] ac16 = new int[16];
/*  934 */           int blkOffLeft = blk8x8OffLeft + (j & 0x1);
/*  935 */           int blkOffTop = blk8x8OffTop + (j >> 1);
/*  936 */           coeffs += readLumaAC(leftAvailable, topAvailable, mbX, mBlock.curMbType, blkX, j, ac16, blkOffLeft, blkOffTop);
/*      */           
/*  938 */           for (int k = 0; k < 16; k++)
/*  939 */             mBlock.ac[0][i][CoeffTransformer.zigzag8x8[(k << 2) + j]] = ac16[k]; 
/*      */         } 
/*  941 */         int blk4x4Offset = i << 2;
/*  942 */         mBlock.nCoeff[blk4x4Offset + 3] = coeffs; mBlock.nCoeff[blk4x4Offset + 2] = coeffs; mBlock.nCoeff[blk4x4Offset + 1] = coeffs; mBlock.nCoeff[blk4x4Offset] = coeffs;
/*      */       } 
/*      */     } 
/*      */   }
/*      */   public void readChromaResidual(MBlock mBlock, boolean leftAvailable, boolean topAvailable, int mbX) {
/*  947 */     if (mBlock.cbpChroma() != 0) {
/*  948 */       if ((mBlock.cbpChroma() & 0x3) > 0) {
/*  949 */         readChromaDC(mbX, leftAvailable, topAvailable, mBlock.dc1, 1, mBlock.curMbType);
/*  950 */         readChromaDC(mbX, leftAvailable, topAvailable, mBlock.dc2, 2, mBlock.curMbType);
/*      */       } 
/*  952 */       _readChromaAC(leftAvailable, topAvailable, mbX, mBlock.dc1, 1, mBlock.curMbType, 
/*  953 */           ((mBlock.cbpChroma() & 0x2) > 0), mBlock.ac[1]);
/*  954 */       _readChromaAC(leftAvailable, topAvailable, mbX, mBlock.dc2, 2, mBlock.curMbType, 
/*  955 */           ((mBlock.cbpChroma() & 0x2) > 0), mBlock.ac[2]);
/*  956 */     } else if (!this.sh.pps.entropyCodingModeFlag) {
/*  957 */       setZeroCoeff(1, mbX << 1, 0);
/*  958 */       setZeroCoeff(1, (mbX << 1) + 1, 1);
/*  959 */       setZeroCoeff(2, mbX << 1, 0);
/*  960 */       setZeroCoeff(2, (mbX << 1) + 1, 1);
/*      */     } 
/*      */   }
/*      */ 
/*      */   
/*      */   private void _readChromaAC(boolean leftAvailable, boolean topAvailable, int mbX, int[] dc, int comp, MBType curMbType, boolean codedAC, int[][] residualOut) {
/*  966 */     for (int i = 0; i < dc.length; i++) {
/*  967 */       int[] ac = residualOut[i];
/*  968 */       int blkOffLeft = H264Const.MB_BLK_OFF_LEFT[i];
/*  969 */       int blkOffTop = H264Const.MB_BLK_OFF_TOP[i];
/*      */       
/*  971 */       int blkX = (mbX << 1) + blkOffLeft;
/*      */       
/*  973 */       if (codedAC) {
/*  974 */         readChromaAC(leftAvailable, topAvailable, mbX, comp, curMbType, ac, blkOffLeft, blkOffTop, blkX);
/*      */       }
/*  976 */       else if (!this.sh.pps.entropyCodingModeFlag) {
/*  977 */         setZeroCoeff(comp, blkX, blkOffTop);
/*      */       } 
/*      */     } 
/*      */   }
/*      */   
/*      */   private void readIPCM(MBlock mBlock) {
/*  983 */     this.reader.align();
/*      */     
/*  985 */     for (int i = 0; i < 256; i++) {
/*  986 */       mBlock.ipcm.samplesLuma[i] = this.reader.readNBit(8);
/*      */     }
/*  988 */     int MbWidthC = 16 >> this.chromaFormat.compWidth[1];
/*  989 */     int MbHeightC = 16 >> this.chromaFormat.compHeight[1];
/*      */     
/*  991 */     for (int j = 0; j < 2 * MbWidthC * MbHeightC; j++) {
/*  992 */       mBlock.ipcm.samplesChroma[j] = this.reader.readNBit(8);
/*      */     }
/*      */   }
/*      */ 
/*      */   
/*      */   public void readMBlock(MBlock mBlock, SliceType sliceType) {
/*  998 */     if (sliceType == SliceType.I) {
/*  999 */       readMBlockI(mBlock);
/* 1000 */     } else if (sliceType == SliceType.P) {
/* 1001 */       readMBlockP(mBlock);
/*      */     } else {
/* 1003 */       readMBlockB(mBlock);
/*      */     } 
/* 1005 */     int mbX = this.mapper.getMbX(mBlock.mbIdx);
/* 1006 */     this.topCBPLuma[mbX] = this.leftCBPLuma = mBlock.cbpLuma();
/* 1007 */     this.topCBPChroma[mbX] = this.leftCBPChroma = mBlock.cbpChroma();
/* 1008 */     this.tf8x8Left = this.tf8x8Top[mbX] = mBlock.transform8x8Used;
/*      */   }
/*      */ 
/*      */   
/*      */   private void readMBlockI(MBlock mBlock) {
/* 1013 */     mBlock.mbType = decodeMBTypeI(mBlock.mbIdx, this.mapper.leftAvailable(mBlock.mbIdx), this.mapper
/* 1014 */         .topAvailable(mBlock.mbIdx), this.leftMBType, this.topMBType[this.mapper.getMbX(mBlock.mbIdx)]);
/*      */     
/* 1016 */     readMBlockIInt(mBlock, mBlock.mbType);
/*      */   }
/*      */   
/*      */   private void readMBlockIInt(MBlock mBlock, int mbType) {
/* 1020 */     if (mbType == 0) {
/* 1021 */       mBlock.curMbType = MBType.I_NxN;
/* 1022 */       readIntraNxN(mBlock);
/* 1023 */     } else if (mbType >= 1 && mbType <= 24) {
/* 1024 */       mBlock.curMbType = MBType.I_16x16;
/* 1025 */       readIntra16x16(mbType - 1, mBlock);
/*      */     } else {
/* 1027 */       Logger.warn("IPCM macroblock found. Not tested, may cause unpredictable behavior.");
/* 1028 */       mBlock.curMbType = MBType.I_PCM;
/* 1029 */       readIPCM(mBlock);
/*      */     } 
/*      */   }
/*      */   
/*      */   private void readMBlockP(MBlock mBlock) {
/* 1034 */     mBlock.mbType = readMBTypeP();
/*      */     
/* 1036 */     switch (mBlock.mbType) {
/*      */       case 0:
/* 1038 */         mBlock.curMbType = MBType.P_16x16;
/* 1039 */         readInter16x16(H264Const.PartPred.L0, mBlock);
/*      */         return;
/*      */       case 1:
/* 1042 */         mBlock.curMbType = MBType.P_16x8;
/* 1043 */         readInter16x8(H264Const.PartPred.L0, H264Const.PartPred.L0, mBlock);
/*      */         return;
/*      */       case 2:
/* 1046 */         mBlock.curMbType = MBType.P_8x16;
/* 1047 */         readIntra8x16(H264Const.PartPred.L0, H264Const.PartPred.L0, mBlock);
/*      */         return;
/*      */       case 3:
/* 1050 */         mBlock.curMbType = MBType.P_8x8;
/* 1051 */         readMBlock8x8(mBlock);
/*      */         return;
/*      */       case 4:
/* 1054 */         mBlock.curMbType = MBType.P_8x8ref0;
/* 1055 */         readMBlock8x8(mBlock);
/*      */         return;
/*      */     } 
/* 1058 */     readMBlockIInt(mBlock, mBlock.mbType - 5);
/*      */   }
/*      */ 
/*      */   
/*      */   private void readMBlockB(MBlock mBlock) {
/* 1063 */     mBlock.mbType = readMBTypeB(mBlock.mbIdx, this.mapper.leftAvailable(mBlock.mbIdx), this.mapper
/* 1064 */         .topAvailable(mBlock.mbIdx), this.leftMBType, this.topMBType[this.mapper.getMbX(mBlock.mbIdx)]);
/* 1065 */     if (mBlock.mbType >= 23) {
/* 1066 */       readMBlockIInt(mBlock, mBlock.mbType - 23);
/*      */     } else {
/* 1068 */       mBlock.curMbType = H264Const.bMbTypes[mBlock.mbType];
/*      */       
/* 1070 */       if (mBlock.mbType == 0) {
/* 1071 */         readMBlockBDirect(mBlock);
/* 1072 */       } else if (mBlock.mbType <= 3) {
/* 1073 */         readInter16x16(H264Const.bPredModes[mBlock.mbType][0], mBlock);
/* 1074 */       } else if (mBlock.mbType == 22) {
/* 1075 */         readMBlock8x8(mBlock);
/* 1076 */       } else if ((mBlock.mbType & 0x1) == 0) {
/* 1077 */         readInter16x8(H264Const.bPredModes[mBlock.mbType][0], H264Const.bPredModes[mBlock.mbType][1], mBlock);
/*      */       } else {
/* 1079 */         readIntra8x16(H264Const.bPredModes[mBlock.mbType][0], H264Const.bPredModes[mBlock.mbType][1], mBlock);
/*      */       } 
/*      */     } 
/*      */   }
/*      */   
/*      */   public SliceHeader getSliceHeader() {
/* 1085 */     return this.sh;
/*      */   }
/*      */   
/*      */   public NALUnit getNALUnit() {
/* 1089 */     return this.nalUnit;
/*      */   }
/*      */ }


/* Location:              C:\Users\rapha\Downloads\aurora.jar!\META-INF\jars\jcodec-0.2.5.jar!\org\jcodec\codecs\h264\decode\SliceReader.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */