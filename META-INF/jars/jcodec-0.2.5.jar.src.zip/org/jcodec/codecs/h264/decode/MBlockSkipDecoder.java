/*    */ package org.jcodec.codecs.h264.decode;
/*    */ 
/*    */ import java.util.Arrays;
/*    */ import org.jcodec.codecs.h264.H264Const;
/*    */ import org.jcodec.codecs.h264.H264Utils;
/*    */ import org.jcodec.codecs.h264.decode.aso.Mapper;
/*    */ import org.jcodec.codecs.h264.io.model.Frame;
/*    */ import org.jcodec.codecs.h264.io.model.SliceHeader;
/*    */ import org.jcodec.codecs.h264.io.model.SliceType;
/*    */ import org.jcodec.common.model.Picture;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class MBlockSkipDecoder
/*    */   extends MBlockDecoderBase
/*    */ {
/*    */   private Mapper mapper;
/*    */   private MBlockDecoderBDirect bDirectDecoder;
/*    */   
/*    */   public MBlockSkipDecoder(Mapper mapper, MBlockDecoderBDirect bDirectDecoder, SliceHeader sh, DeblockerInput di, int poc, DecoderState sharedState) {
/* 34 */     super(sh, di, poc, sharedState);
/* 35 */     this.mapper = mapper;
/* 36 */     this.bDirectDecoder = bDirectDecoder;
/*    */   }
/*    */   
/*    */   public void decodeSkip(MBlock mBlock, Frame[][] refs, Picture mb, SliceType sliceType) {
/* 40 */     int mbX = this.mapper.getMbX(mBlock.mbIdx);
/* 41 */     int mbY = this.mapper.getMbY(mBlock.mbIdx);
/* 42 */     int mbAddr = this.mapper.getAddress(mBlock.mbIdx);
/*    */     
/* 44 */     if (sliceType == SliceType.P) {
/* 45 */       predictPSkip(refs, mbX, mbY, this.mapper.leftAvailable(mBlock.mbIdx), this.mapper.topAvailable(mBlock.mbIdx), this.mapper
/* 46 */           .topLeftAvailable(mBlock.mbIdx), this.mapper.topRightAvailable(mBlock.mbIdx), mBlock.x, mb);
/* 47 */       Arrays.fill((Object[])mBlock.partPreds, H264Const.PartPred.L0);
/*    */     } else {
/* 49 */       this.bDirectDecoder.predictBDirect(refs, mbX, mbY, this.mapper.leftAvailable(mBlock.mbIdx), this.mapper
/* 50 */           .topAvailable(mBlock.mbIdx), this.mapper.topLeftAvailable(mBlock.mbIdx), this.mapper
/* 51 */           .topRightAvailable(mBlock.mbIdx), mBlock.x, mBlock.partPreds, mb, H264Const.identityMapping4);
/* 52 */       MBlockDecoderUtils.savePrediction8x8(this.s, mbX, mBlock.x);
/*    */     } 
/*    */     
/* 55 */     decodeChromaSkip(refs, mBlock.x, mBlock.partPreds, mbX, mbY, mb);
/*    */     
/* 57 */     MBlockDecoderUtils.collectPredictors(this.s, mb, mbX);
/*    */     
/* 59 */     MBlockDecoderUtils.saveMvs(this.di, mBlock.x, mbX, mbY);
/* 60 */     this.di.mbTypes[mbAddr] = mBlock.curMbType;
/* 61 */     this.di.mbQps[0][mbAddr] = this.s.qp;
/* 62 */     this.di.mbQps[1][mbAddr] = calcQpChroma(this.s.qp, this.s.chromaQpOffset[0]);
/* 63 */     this.di.mbQps[2][mbAddr] = calcQpChroma(this.s.qp, this.s.chromaQpOffset[1]);
/*    */   }
/*    */ 
/*    */   
/*    */   public void predictPSkip(Frame[][] refs, int mbX, int mbY, boolean lAvb, boolean tAvb, boolean tlAvb, boolean trAvb, H264Utils.MvList x, Picture mb) {
/* 68 */     int mvX = 0, mvY = 0;
/* 69 */     if (lAvb && tAvb) {
/* 70 */       int b = this.s.mvTop.getMv(mbX << 2, 0);
/* 71 */       int a = this.s.mvLeft.getMv(0, 0);
/*    */       
/* 73 */       if (a != 0 && b != 0) {
/* 74 */         mvX = MBlockDecoderUtils.calcMVPredictionMedian(a, b, this.s.mvTop.getMv((mbX << 2) + 4, 0), this.s.mvTopLeft.getMv(0, 0), lAvb, tAvb, trAvb, tlAvb, 0, 0);
/*    */         
/* 76 */         mvY = MBlockDecoderUtils.calcMVPredictionMedian(a, b, this.s.mvTop.getMv((mbX << 2) + 4, 0), this.s.mvTopLeft.getMv(0, 0), lAvb, tAvb, trAvb, tlAvb, 0, 1);
/*    */       } 
/*    */     } 
/*    */ 
/*    */     
/* 81 */     int xx = mbX << 2;
/* 82 */     this.s.mvTopLeft.copyPair(0, this.s.mvTop, xx + 3);
/* 83 */     MBlockDecoderUtils.saveVect(this.s.mvTop, 0, xx, xx + 4, H264Utils.Mv.packMv(mvX, mvY, 0));
/* 84 */     MBlockDecoderUtils.saveVect(this.s.mvLeft, 0, 0, 4, H264Utils.Mv.packMv(mvX, mvY, 0));
/* 85 */     MBlockDecoderUtils.saveVect(this.s.mvTop, 1, xx, xx + 4, MBlockDecoderUtils.NULL_VECTOR);
/* 86 */     MBlockDecoderUtils.saveVect(this.s.mvLeft, 1, 0, 4, MBlockDecoderUtils.NULL_VECTOR);
/*    */     
/* 88 */     for (int i = 0; i < 16; i++) {
/* 89 */       x.setMv(i, 0, H264Utils.Mv.packMv(mvX, mvY, 0));
/*    */     }
/* 91 */     this.interpolator.getBlockLuma((Picture)refs[0][0], mb, 0, (mbX << 6) + mvX, (mbY << 6) + mvY, 16, 16);
/*    */     
/* 93 */     PredictionMerger.mergePrediction(this.sh, 0, 0, H264Const.PartPred.L0, 0, mb.getPlaneData(0), null, 0, 16, 16, 16, mb.getPlaneData(0), refs, this.poc);
/*    */   }
/*    */ 
/*    */   
/*    */   public void decodeChromaSkip(Frame[][] reference, H264Utils.MvList vectors, H264Const.PartPred[] pp, int mbX, int mbY, Picture mb) {
/* 98 */     predictChromaInter(reference, vectors, mbX << 3, mbY << 3, 1, mb, pp);
/* 99 */     predictChromaInter(reference, vectors, mbX << 3, mbY << 3, 2, mb, pp);
/*    */   }
/*    */ }


/* Location:              C:\Users\rapha\Downloads\aurora.jar!\META-INF\jars\jcodec-0.2.5.jar!\org\jcodec\codecs\h264\decode\MBlockSkipDecoder.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */