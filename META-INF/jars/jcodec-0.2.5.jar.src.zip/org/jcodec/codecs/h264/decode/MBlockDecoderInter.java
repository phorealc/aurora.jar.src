/*     */ package org.jcodec.codecs.h264.decode;
/*     */ 
/*     */ import org.jcodec.codecs.h264.H264Const;
/*     */ import org.jcodec.codecs.h264.H264Utils;
/*     */ import org.jcodec.codecs.h264.decode.aso.Mapper;
/*     */ import org.jcodec.codecs.h264.io.model.Frame;
/*     */ import org.jcodec.codecs.h264.io.model.SliceHeader;
/*     */ import org.jcodec.common.model.ColorSpace;
/*     */ import org.jcodec.common.model.Picture;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class MBlockDecoderInter
/*     */   extends MBlockDecoderBase
/*     */ {
/*     */   private Mapper mapper;
/*     */   
/*     */   public MBlockDecoderInter(Mapper mapper, SliceHeader sh, DeblockerInput di, int poc, DecoderState decoderState) {
/*  37 */     super(sh, di, poc, decoderState);
/*  38 */     this.mapper = mapper;
/*     */   }
/*     */ 
/*     */   
/*     */   public void decode16x16(MBlock mBlock, Picture mb, Frame[][] refs, H264Const.PartPred p0) {
/*  43 */     int mbX = this.mapper.getMbX(mBlock.mbIdx);
/*  44 */     int mbY = this.mapper.getMbY(mBlock.mbIdx);
/*  45 */     boolean leftAvailable = this.mapper.leftAvailable(mBlock.mbIdx);
/*  46 */     boolean topAvailable = this.mapper.topAvailable(mBlock.mbIdx);
/*     */     
/*  48 */     boolean topLeftAvailable = this.mapper.topLeftAvailable(mBlock.mbIdx);
/*  49 */     boolean topRightAvailable = this.mapper.topRightAvailable(mBlock.mbIdx);
/*  50 */     int address = this.mapper.getAddress(mBlock.mbIdx);
/*  51 */     int xx = mbX << 2;
/*     */     
/*  53 */     for (int list = 0; list < 2; list++) {
/*  54 */       predictInter16x16(mBlock, this.mbb[list], (Picture[][])refs, mbX, mbY, leftAvailable, topAvailable, topLeftAvailable, topRightAvailable, mBlock.x, xx, list, p0);
/*     */     }
/*     */ 
/*     */     
/*  58 */     PredictionMerger.mergePrediction(this.sh, mBlock.x.mv0R(0), mBlock.x.mv1R(0), p0, 0, this.mbb[0].getPlaneData(0), this.mbb[1]
/*  59 */         .getPlaneData(0), 0, 16, 16, 16, mb.getPlaneData(0), refs, this.poc);
/*     */     
/*  61 */     mBlock.partPreds[3] = p0; mBlock.partPreds[2] = p0; mBlock.partPreds[1] = p0; mBlock.partPreds[0] = p0;
/*  62 */     predictChromaInter(refs, mBlock.x, mbX << 3, mbY << 3, 1, mb, mBlock.partPreds);
/*  63 */     predictChromaInter(refs, mBlock.x, mbX << 3, mbY << 3, 2, mb, mBlock.partPreds);
/*     */     
/*  65 */     residualInter(mBlock, refs, leftAvailable, topAvailable, mbX, mbY, this.mapper.getAddress(mBlock.mbIdx));
/*     */     
/*  67 */     MBlockDecoderUtils.saveMvs(this.di, mBlock.x, mbX, mbY);
/*     */     
/*  69 */     MBlockDecoderUtils.mergeResidual(mb, mBlock.ac, mBlock.transform8x8Used ? H264Const.COMP_BLOCK_8x8_LUT : H264Const.COMP_BLOCK_4x4_LUT, mBlock.transform8x8Used ? H264Const.COMP_POS_8x8_LUT : H264Const.COMP_POS_4x4_LUT);
/*     */ 
/*     */     
/*  72 */     MBlockDecoderUtils.collectPredictors(this.s, mb, mbX);
/*     */     
/*  74 */     this.di.mbTypes[address] = mBlock.curMbType;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private void predictInter8x16(MBlock mBlock, Picture mb, Picture[][] references, int mbX, int mbY, boolean leftAvailable, boolean topAvailable, boolean tlAvailable, boolean trAvailable, H264Utils.MvList x, int list, H264Const.PartPred p0, H264Const.PartPred p1) {
/*  80 */     int xx = mbX << 2;
/*     */     
/*  82 */     int mvX1 = 0, mvY1 = 0, r1 = -1, mvX2 = 0, mvY2 = 0, r2 = -1;
/*  83 */     if (H264Const.usesList(p0, list)) {
/*  84 */       int mvpX1 = calcMVPrediction8x16Left(this.s.mvLeft.getMv(0, list), this.s.mvTop.getMv(mbX << 2, list), this.s.mvTop
/*  85 */           .getMv((mbX << 2) + 2, list), this.s.mvTopLeft.getMv(0, list), leftAvailable, topAvailable, topAvailable, tlAvailable, mBlock.pb168x168.refIdx1[list], 0);
/*     */       
/*  87 */       int mvpY1 = calcMVPrediction8x16Left(this.s.mvLeft.getMv(0, list), this.s.mvTop.getMv(mbX << 2, list), this.s.mvTop
/*  88 */           .getMv((mbX << 2) + 2, list), this.s.mvTopLeft.getMv(0, list), leftAvailable, topAvailable, topAvailable, tlAvailable, mBlock.pb168x168.refIdx1[list], 1);
/*     */ 
/*     */       
/*  91 */       mvX1 = mBlock.pb168x168.mvdX1[list] + mvpX1;
/*  92 */       mvY1 = mBlock.pb168x168.mvdY1[list] + mvpY1;
/*     */       
/*  94 */       MBlockDecoderUtils.debugPrint(new Object[] { "MVP: (%d, %d), MVD: (%d, %d), MV: (%d,%d,%d)", Integer.valueOf(mvpX1), Integer.valueOf(mvpY1), Integer.valueOf(mBlock.pb168x168.mvdX1[list]), 
/*  95 */             Integer.valueOf(mBlock.pb168x168.mvdY1[list]), Integer.valueOf(mvX1), Integer.valueOf(mvY1), Integer.valueOf(mBlock.pb168x168.refIdx1[list]) });
/*     */       
/*  97 */       this.interpolator.getBlockLuma(references[list][mBlock.pb168x168.refIdx1[list]], mb, 0, (mbX << 6) + mvX1, (mbY << 6) + mvY1, 8, 16);
/*     */       
/*  99 */       r1 = mBlock.pb168x168.refIdx1[list];
/*     */     } 
/*     */ 
/*     */ 
/*     */     
/* 104 */     int v1 = H264Utils.Mv.packMv(mvX1, mvY1, r1);
/* 105 */     if (H264Const.usesList(p1, list)) {
/* 106 */       int mvpX2 = calcMVPrediction8x16Right(v1, this.s.mvTop.getMv((mbX << 2) + 2, list), this.s.mvTop
/* 107 */           .getMv((mbX << 2) + 4, list), this.s.mvTop.getMv((mbX << 2) + 1, list), true, topAvailable, trAvailable, topAvailable, mBlock.pb168x168.refIdx2[list], 0);
/*     */       
/* 109 */       int mvpY2 = calcMVPrediction8x16Right(v1, this.s.mvTop.getMv((mbX << 2) + 2, list), this.s.mvTop
/* 110 */           .getMv((mbX << 2) + 4, list), this.s.mvTop.getMv((mbX << 2) + 1, list), true, topAvailable, trAvailable, topAvailable, mBlock.pb168x168.refIdx2[list], 1);
/*     */ 
/*     */       
/* 113 */       mvX2 = mBlock.pb168x168.mvdX2[list] + mvpX2;
/* 114 */       mvY2 = mBlock.pb168x168.mvdY2[list] + mvpY2;
/*     */       
/* 116 */       MBlockDecoderUtils.debugPrint(new Object[] { "MVP: (" + mvpX2 + ", " + mvpY2 + "), MVD: (" + mBlock.pb168x168.mvdX2[list] + ", " + mBlock.pb168x168.mvdY2[list] + "), MV: (" + mvX2 + "," + mvY2 + "," + mBlock.pb168x168.refIdx2[list] + ")" });
/*     */ 
/*     */ 
/*     */       
/* 120 */       this.interpolator.getBlockLuma(references[list][mBlock.pb168x168.refIdx2[list]], mb, 8, (mbX << 6) + 32 + mvX2, (mbY << 6) + mvY2, 8, 16);
/*     */       
/* 122 */       r2 = mBlock.pb168x168.refIdx2[list];
/*     */     } 
/* 124 */     int v2 = H264Utils.Mv.packMv(mvX2, mvY2, r2);
/*     */     
/* 126 */     this.s.mvTopLeft.setMv(0, list, this.s.mvTop.getMv(xx + 3, list));
/* 127 */     MBlockDecoderUtils.saveVect(this.s.mvTop, list, xx, xx + 2, v1);
/* 128 */     MBlockDecoderUtils.saveVect(this.s.mvTop, list, xx + 2, xx + 4, v2);
/* 129 */     MBlockDecoderUtils.saveVect(this.s.mvLeft, list, 0, 4, v2);
/*     */     
/* 131 */     for (int i = 0; i < 16; i += 4) {
/* 132 */       x.setMv(i, list, v1);
/* 133 */       x.setMv(i + 1, list, v1);
/* 134 */       x.setMv(i + 2, list, v2);
/* 135 */       x.setMv(i + 3, list, v2);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void predictInter16x8(MBlock mBlock, Picture mb, Picture[][] references, int mbX, int mbY, boolean leftAvailable, boolean topAvailable, boolean tlAvailable, boolean trAvailable, int xx, H264Utils.MvList x, H264Const.PartPred p0, H264Const.PartPred p1, int list) {
/* 143 */     int mvX1 = 0, mvY1 = 0, mvX2 = 0, mvY2 = 0, r1 = -1, r2 = -1;
/* 144 */     if (H264Const.usesList(p0, list)) {
/*     */       
/* 146 */       int mvpX1 = calcMVPrediction16x8Top(this.s.mvLeft.getMv(0, list), this.s.mvTop.getMv(mbX << 2, list), this.s.mvTop
/* 147 */           .getMv((mbX << 2) + 4, list), this.s.mvTopLeft.getMv(0, list), leftAvailable, topAvailable, trAvailable, tlAvailable, mBlock.pb168x168.refIdx1[list], 0);
/*     */       
/* 149 */       int mvpY1 = calcMVPrediction16x8Top(this.s.mvLeft.getMv(0, list), this.s.mvTop.getMv(mbX << 2, list), this.s.mvTop
/* 150 */           .getMv((mbX << 2) + 4, list), this.s.mvTopLeft.getMv(0, list), leftAvailable, topAvailable, trAvailable, tlAvailable, mBlock.pb168x168.refIdx1[list], 1);
/*     */ 
/*     */       
/* 153 */       mvX1 = mBlock.pb168x168.mvdX1[list] + mvpX1;
/* 154 */       mvY1 = mBlock.pb168x168.mvdY1[list] + mvpY1;
/*     */       
/* 156 */       MBlockDecoderUtils.debugPrint(new Object[] { "MVP: (%d, %d), MVD: (%d, %d), MV: (%d,%d,%d)", Integer.valueOf(mvpX1), Integer.valueOf(mvpY1), Integer.valueOf(mBlock.pb168x168.mvdX1[list]), 
/* 157 */             Integer.valueOf(mBlock.pb168x168.mvdY1[list]), Integer.valueOf(mvX1), Integer.valueOf(mvY1), Integer.valueOf(mBlock.pb168x168.refIdx1[list]) });
/*     */       
/* 159 */       this.interpolator.getBlockLuma(references[list][mBlock.pb168x168.refIdx1[list]], mb, 0, (mbX << 6) + mvX1, (mbY << 6) + mvY1, 16, 8);
/*     */       
/* 161 */       r1 = mBlock.pb168x168.refIdx1[list];
/*     */     } 
/* 163 */     int v1 = H264Utils.Mv.packMv(mvX1, mvY1, r1);
/*     */     
/* 165 */     if (H264Const.usesList(p1, list)) {
/* 166 */       int mvpX2 = calcMVPrediction16x8Bottom(this.s.mvLeft.getMv(2, list), v1, MBlockDecoderUtils.NULL_VECTOR, this.s.mvLeft.getMv(1, list), leftAvailable, true, false, leftAvailable, mBlock.pb168x168.refIdx2[list], 0);
/*     */       
/* 168 */       int mvpY2 = calcMVPrediction16x8Bottom(this.s.mvLeft.getMv(2, list), v1, MBlockDecoderUtils.NULL_VECTOR, this.s.mvLeft.getMv(1, list), leftAvailable, true, false, leftAvailable, mBlock.pb168x168.refIdx2[list], 1);
/*     */ 
/*     */       
/* 171 */       mvX2 = mBlock.pb168x168.mvdX2[list] + mvpX2;
/* 172 */       mvY2 = mBlock.pb168x168.mvdY2[list] + mvpY2;
/*     */       
/* 174 */       MBlockDecoderUtils.debugPrint(new Object[] { "MVP: (%d, %d), MVD: (%d, %d), MV: (%d,%d,%d)", Integer.valueOf(mvpX2), Integer.valueOf(mvpY2), Integer.valueOf(mBlock.pb168x168.mvdX2[list]), 
/* 175 */             Integer.valueOf(mBlock.pb168x168.mvdY2[list]), Integer.valueOf(mvX2), Integer.valueOf(mvY2), Integer.valueOf(mBlock.pb168x168.refIdx2[list]) });
/*     */       
/* 177 */       this.interpolator.getBlockLuma(references[list][mBlock.pb168x168.refIdx2[list]], mb, 128, (mbX << 6) + mvX2, (mbY << 6) + 32 + mvY2, 16, 8);
/*     */       
/* 179 */       r2 = mBlock.pb168x168.refIdx2[list];
/*     */     } 
/* 181 */     int v2 = H264Utils.Mv.packMv(mvX2, mvY2, r2);
/*     */     
/* 183 */     this.s.mvTopLeft.setMv(0, list, this.s.mvTop.getMv(xx + 3, list));
/* 184 */     MBlockDecoderUtils.saveVect(this.s.mvLeft, list, 0, 2, v1);
/* 185 */     MBlockDecoderUtils.saveVect(this.s.mvLeft, list, 2, 4, v2);
/* 186 */     MBlockDecoderUtils.saveVect(this.s.mvTop, list, xx, xx + 4, v2);
/*     */     int i;
/* 188 */     for (i = 0; i < 8; i++) {
/* 189 */       x.setMv(i, list, v1);
/*     */     }
/* 191 */     for (i = 8; i < 16; i++) {
/* 192 */       x.setMv(i, list, v2);
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   public void decode16x8(MBlock mBlock, Picture mb, Frame[][] refs, H264Const.PartPred p0, H264Const.PartPred p1) {
/* 198 */     int mbX = this.mapper.getMbX(mBlock.mbIdx);
/* 199 */     int mbY = this.mapper.getMbY(mBlock.mbIdx);
/* 200 */     boolean leftAvailable = this.mapper.leftAvailable(mBlock.mbIdx);
/* 201 */     boolean topAvailable = this.mapper.topAvailable(mBlock.mbIdx);
/* 202 */     boolean topLeftAvailable = this.mapper.topLeftAvailable(mBlock.mbIdx);
/* 203 */     boolean topRightAvailable = this.mapper.topRightAvailable(mBlock.mbIdx);
/* 204 */     int address = this.mapper.getAddress(mBlock.mbIdx);
/* 205 */     int xx = mbX << 2;
/*     */     
/* 207 */     for (int list = 0; list < 2; list++) {
/* 208 */       predictInter16x8(mBlock, this.mbb[list], (Picture[][])refs, mbX, mbY, leftAvailable, topAvailable, topLeftAvailable, topRightAvailable, xx, mBlock.x, p0, p1, list);
/*     */     }
/*     */ 
/*     */     
/* 212 */     PredictionMerger.mergePrediction(this.sh, mBlock.x.mv0R(0), mBlock.x.mv1R(0), p0, 0, this.mbb[0].getPlaneData(0), this.mbb[1].getPlaneData(0), 0, 16, 16, 8, mb
/* 213 */         .getPlaneData(0), refs, this.poc);
/* 214 */     PredictionMerger.mergePrediction(this.sh, mBlock.x.mv0R(8), mBlock.x.mv1R(8), p1, 0, this.mbb[0].getPlaneData(0), this.mbb[1].getPlaneData(0), 128, 16, 16, 8, mb
/* 215 */         .getPlaneData(0), refs, this.poc);
/*     */     
/* 217 */     mBlock.partPreds[1] = p0; mBlock.partPreds[0] = p0;
/* 218 */     mBlock.partPreds[3] = p1; mBlock.partPreds[2] = p1;
/* 219 */     predictChromaInter(refs, mBlock.x, mbX << 3, mbY << 3, 1, mb, mBlock.partPreds);
/* 220 */     predictChromaInter(refs, mBlock.x, mbX << 3, mbY << 3, 2, mb, mBlock.partPreds);
/*     */     
/* 222 */     residualInter(mBlock, refs, leftAvailable, topAvailable, mbX, mbY, this.mapper.getAddress(mBlock.mbIdx));
/*     */     
/* 224 */     MBlockDecoderUtils.saveMvs(this.di, mBlock.x, mbX, mbY);
/*     */     
/* 226 */     MBlockDecoderUtils.mergeResidual(mb, mBlock.ac, mBlock.transform8x8Used ? H264Const.COMP_BLOCK_8x8_LUT : H264Const.COMP_BLOCK_4x4_LUT, mBlock.transform8x8Used ? H264Const.COMP_POS_8x8_LUT : H264Const.COMP_POS_4x4_LUT);
/*     */ 
/*     */     
/* 229 */     MBlockDecoderUtils.collectPredictors(this.s, mb, mbX);
/*     */     
/* 231 */     this.di.mbTypes[address] = mBlock.curMbType;
/*     */   }
/*     */   
/*     */   public void decode8x16(MBlock mBlock, Picture mb, Frame[][] refs, H264Const.PartPred p0, H264Const.PartPred p1) {
/* 235 */     int mbX = this.mapper.getMbX(mBlock.mbIdx);
/* 236 */     int mbY = this.mapper.getMbY(mBlock.mbIdx);
/* 237 */     boolean leftAvailable = this.mapper.leftAvailable(mBlock.mbIdx);
/* 238 */     boolean topAvailable = this.mapper.topAvailable(mBlock.mbIdx);
/* 239 */     boolean topLeftAvailable = this.mapper.topLeftAvailable(mBlock.mbIdx);
/* 240 */     boolean topRightAvailable = this.mapper.topRightAvailable(mBlock.mbIdx);
/* 241 */     int address = this.mapper.getAddress(mBlock.mbIdx);
/*     */     
/* 243 */     for (int list = 0; list < 2; list++) {
/* 244 */       predictInter8x16(mBlock, this.mbb[list], (Picture[][])refs, mbX, mbY, leftAvailable, topAvailable, topLeftAvailable, topRightAvailable, mBlock.x, list, p0, p1);
/*     */     }
/*     */ 
/*     */     
/* 248 */     PredictionMerger.mergePrediction(this.sh, mBlock.x.mv0R(0), mBlock.x.mv1R(0), p0, 0, this.mbb[0].getPlaneData(0), this.mbb[1].getPlaneData(0), 0, 16, 8, 16, mb
/* 249 */         .getPlaneData(0), refs, this.poc);
/* 250 */     PredictionMerger.mergePrediction(this.sh, mBlock.x.mv0R(2), mBlock.x.mv1R(2), p1, 0, this.mbb[0].getPlaneData(0), this.mbb[1].getPlaneData(0), 8, 16, 8, 16, mb
/* 251 */         .getPlaneData(0), refs, this.poc);
/*     */     
/* 253 */     mBlock.partPreds[2] = p0; mBlock.partPreds[0] = p0;
/* 254 */     mBlock.partPreds[3] = p1; mBlock.partPreds[1] = p1;
/*     */     
/* 256 */     predictChromaInter(refs, mBlock.x, mbX << 3, mbY << 3, 1, mb, mBlock.partPreds);
/* 257 */     predictChromaInter(refs, mBlock.x, mbX << 3, mbY << 3, 2, mb, mBlock.partPreds);
/*     */     
/* 259 */     residualInter(mBlock, refs, leftAvailable, topAvailable, mbX, mbY, this.mapper.getAddress(mBlock.mbIdx));
/*     */     
/* 261 */     MBlockDecoderUtils.saveMvs(this.di, mBlock.x, mbX, mbY);
/*     */     
/* 263 */     MBlockDecoderUtils.mergeResidual(mb, mBlock.ac, mBlock.transform8x8Used ? H264Const.COMP_BLOCK_8x8_LUT : H264Const.COMP_BLOCK_4x4_LUT, mBlock.transform8x8Used ? H264Const.COMP_POS_8x8_LUT : H264Const.COMP_POS_4x4_LUT);
/*     */ 
/*     */     
/* 266 */     MBlockDecoderUtils.collectPredictors(this.s, mb, mbX);
/*     */     
/* 268 */     this.di.mbTypes[address] = mBlock.curMbType;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   void predictInter16x16(MBlock mBlock, Picture mb, Picture[][] references, int mbX, int mbY, boolean leftAvailable, boolean topAvailable, boolean tlAvailable, boolean trAvailable, H264Utils.MvList x, int xx, int list, H264Const.PartPred curPred) {
/* 275 */     int mvX = 0, mvY = 0, r = -1;
/* 276 */     if (H264Const.usesList(curPred, list)) {
/* 277 */       int mvpX = MBlockDecoderUtils.calcMVPredictionMedian(this.s.mvLeft.getMv(0, list), this.s.mvTop.getMv(mbX << 2, list), this.s.mvTop
/* 278 */           .getMv((mbX << 2) + 4, list), this.s.mvTopLeft.getMv(0, list), leftAvailable, topAvailable, trAvailable, tlAvailable, mBlock.pb16x16.refIdx[list], 0);
/*     */       
/* 280 */       int mvpY = MBlockDecoderUtils.calcMVPredictionMedian(this.s.mvLeft.getMv(0, list), this.s.mvTop.getMv(mbX << 2, list), this.s.mvTop
/* 281 */           .getMv((mbX << 2) + 4, list), this.s.mvTopLeft.getMv(0, list), leftAvailable, topAvailable, trAvailable, tlAvailable, mBlock.pb16x16.refIdx[list], 1);
/*     */ 
/*     */       
/* 284 */       mvX = mBlock.pb16x16.mvdX[list] + mvpX;
/* 285 */       mvY = mBlock.pb16x16.mvdY[list] + mvpY;
/*     */       
/* 287 */       MBlockDecoderUtils.debugPrint(new Object[] { "MVP: (%d, %d), MVD: (%d, %d), MV: (%d,%d,%d)", Integer.valueOf(mvpX), Integer.valueOf(mvpY), Integer.valueOf(mBlock.pb16x16.mvdX[list]), 
/* 288 */             Integer.valueOf(mBlock.pb16x16.mvdY[list]), Integer.valueOf(mvX), Integer.valueOf(mvY), Integer.valueOf(mBlock.pb16x16.refIdx[list]) });
/* 289 */       r = mBlock.pb16x16.refIdx[list];
/*     */       
/* 291 */       this.interpolator.getBlockLuma(references[list][r], mb, 0, (mbX << 6) + mvX, (mbY << 6) + mvY, 16, 16);
/*     */     } 
/*     */     
/* 294 */     int v = H264Utils.Mv.packMv(mvX, mvY, r);
/* 295 */     this.s.mvTopLeft.setMv(0, list, this.s.mvTop.getMv(xx + 3, list));
/* 296 */     MBlockDecoderUtils.saveVect(this.s.mvTop, list, xx, xx + 4, v);
/* 297 */     MBlockDecoderUtils.saveVect(this.s.mvLeft, list, 0, 4, v);
/*     */     
/* 299 */     for (int i = 0; i < 16; i++) {
/* 300 */       x.setMv(i, list, v);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private void residualInter(MBlock mBlock, Frame[][] refs, boolean leftAvailable, boolean topAvailable, int mbX, int mbY, int mbAddr) {
/* 307 */     if (mBlock.cbpLuma() > 0 || mBlock.cbpChroma() > 0) {
/* 308 */       this.s.qp = (this.s.qp + mBlock.mbQPDelta + 52) % 52;
/*     */     }
/* 310 */     this.di.mbQps[0][mbAddr] = this.s.qp;
/*     */     
/* 312 */     residualLuma(mBlock, leftAvailable, topAvailable, mbX, mbY);
/*     */     
/* 314 */     if (this.s.chromaFormat != ColorSpace.MONO) {
/* 315 */       int qp1 = calcQpChroma(this.s.qp, this.s.chromaQpOffset[0]);
/* 316 */       int qp2 = calcQpChroma(this.s.qp, this.s.chromaQpOffset[1]);
/*     */       
/* 318 */       decodeChromaResidual(mBlock, leftAvailable, topAvailable, mbX, mbY, qp1, qp2);
/*     */       
/* 320 */       this.di.mbQps[1][mbAddr] = qp1;
/* 321 */       this.di.mbQps[2][mbAddr] = qp2;
/*     */     } 
/*     */     
/* 324 */     this.di.tr8x8Used[mbAddr] = mBlock.transform8x8Used;
/*     */   }
/*     */ 
/*     */   
/*     */   public int calcMVPrediction16x8Top(int a, int b, int c, int d, boolean aAvb, boolean bAvb, boolean cAvb, boolean dAvb, int refIdx, int comp) {
/* 329 */     if (bAvb && H264Utils.Mv.mvRef(b) == refIdx) {
/* 330 */       return H264Utils.Mv.mvC(b, comp);
/*     */     }
/* 332 */     return MBlockDecoderUtils.calcMVPredictionMedian(a, b, c, d, aAvb, bAvb, cAvb, dAvb, refIdx, comp);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public int calcMVPrediction16x8Bottom(int a, int b, int c, int d, boolean aAvb, boolean bAvb, boolean cAvb, boolean dAvb, int refIdx, int comp) {
/* 338 */     if (aAvb && H264Utils.Mv.mvRef(a) == refIdx) {
/* 339 */       return H264Utils.Mv.mvC(a, comp);
/*     */     }
/* 341 */     return MBlockDecoderUtils.calcMVPredictionMedian(a, b, c, d, aAvb, bAvb, cAvb, dAvb, refIdx, comp);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public int calcMVPrediction8x16Left(int a, int b, int c, int d, boolean aAvb, boolean bAvb, boolean cAvb, boolean dAvb, int refIdx, int comp) {
/* 347 */     if (aAvb && H264Utils.Mv.mvRef(a) == refIdx) {
/* 348 */       return H264Utils.Mv.mvC(a, comp);
/*     */     }
/* 350 */     return MBlockDecoderUtils.calcMVPredictionMedian(a, b, c, d, aAvb, bAvb, cAvb, dAvb, refIdx, comp);
/*     */   }
/*     */ 
/*     */   
/*     */   public int calcMVPrediction8x16Right(int a, int b, int c, int d, boolean aAvb, boolean bAvb, boolean cAvb, boolean dAvb, int refIdx, int comp) {
/* 355 */     int lc = cAvb ? c : (dAvb ? d : MBlockDecoderUtils.NULL_VECTOR);
/*     */     
/* 357 */     if (H264Utils.Mv.mvRef(lc) == refIdx) {
/* 358 */       return H264Utils.Mv.mvC(lc, comp);
/*     */     }
/* 360 */     return MBlockDecoderUtils.calcMVPredictionMedian(a, b, c, d, aAvb, bAvb, cAvb, dAvb, refIdx, comp);
/*     */   }
/*     */ }


/* Location:              C:\Users\rapha\Downloads\aurora.jar!\META-INF\jars\jcodec-0.2.5.jar!\org\jcodec\codecs\h264\decode\MBlockDecoderInter.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */