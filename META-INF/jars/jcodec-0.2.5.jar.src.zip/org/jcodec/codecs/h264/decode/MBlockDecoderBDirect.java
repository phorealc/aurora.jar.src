/*     */ package org.jcodec.codecs.h264.decode;
/*     */ 
/*     */ import org.jcodec.codecs.h264.H264Const;
/*     */ import org.jcodec.codecs.h264.H264Utils;
/*     */ import org.jcodec.codecs.h264.decode.aso.Mapper;
/*     */ import org.jcodec.codecs.h264.io.model.Frame;
/*     */ import org.jcodec.codecs.h264.io.model.SliceHeader;
/*     */ import org.jcodec.common.logging.Logger;
/*     */ import org.jcodec.common.model.Picture;
/*     */ import org.jcodec.common.tools.MathUtil;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class MBlockDecoderBDirect
/*     */   extends MBlockDecoderBase
/*     */ {
/*     */   private Mapper mapper;
/*     */   
/*     */   public MBlockDecoderBDirect(Mapper mapper, SliceHeader sh, DeblockerInput di, int poc, DecoderState decoderState) {
/*  49 */     super(sh, di, poc, decoderState);
/*  50 */     this.mapper = mapper;
/*     */   }
/*     */   
/*     */   public void decode(MBlock mBlock, Picture mb, Frame[][] references) {
/*  54 */     int mbX = this.mapper.getMbX(mBlock.mbIdx);
/*  55 */     int mbY = this.mapper.getMbY(mBlock.mbIdx);
/*  56 */     boolean lAvb = this.mapper.leftAvailable(mBlock.mbIdx);
/*  57 */     boolean tAvb = this.mapper.topAvailable(mBlock.mbIdx);
/*  58 */     int mbAddr = this.mapper.getAddress(mBlock.mbIdx);
/*  59 */     boolean tlAvb = this.mapper.topLeftAvailable(mBlock.mbIdx);
/*  60 */     boolean trAvb = this.mapper.topRightAvailable(mBlock.mbIdx);
/*     */     
/*  62 */     predictBDirect(references, mbX, mbY, lAvb, tAvb, tlAvb, trAvb, mBlock.x, mBlock.partPreds, mb, H264Const.identityMapping4);
/*     */     
/*  64 */     predictChromaInter(references, mBlock.x, mbX << 3, mbY << 3, 1, mb, mBlock.partPreds);
/*  65 */     predictChromaInter(references, mBlock.x, mbX << 3, mbY << 3, 2, mb, mBlock.partPreds);
/*     */     
/*  67 */     if (mBlock.cbpLuma() > 0 || mBlock.cbpChroma() > 0) {
/*  68 */       this.s.qp = (this.s.qp + mBlock.mbQPDelta + 52) % 52;
/*     */     }
/*  70 */     this.di.mbQps[0][mbAddr] = this.s.qp;
/*     */     
/*  72 */     residualLuma(mBlock, lAvb, tAvb, mbX, mbY);
/*     */     
/*  74 */     MBlockDecoderUtils.savePrediction8x8(this.s, mbX, mBlock.x);
/*  75 */     MBlockDecoderUtils.saveMvs(this.di, mBlock.x, mbX, mbY);
/*     */     
/*  77 */     int qp1 = calcQpChroma(this.s.qp, this.s.chromaQpOffset[0]);
/*  78 */     int qp2 = calcQpChroma(this.s.qp, this.s.chromaQpOffset[1]);
/*     */     
/*  80 */     decodeChromaResidual(mBlock, lAvb, tAvb, mbX, mbY, qp1, qp2);
/*     */     
/*  82 */     this.di.mbQps[1][mbAddr] = qp1;
/*  83 */     this.di.mbQps[2][mbAddr] = qp2;
/*     */     
/*  85 */     MBlockDecoderUtils.mergeResidual(mb, mBlock.ac, mBlock.transform8x8Used ? H264Const.COMP_BLOCK_8x8_LUT : H264Const.COMP_BLOCK_4x4_LUT, mBlock.transform8x8Used ? H264Const.COMP_POS_8x8_LUT : H264Const.COMP_POS_4x4_LUT);
/*     */ 
/*     */     
/*  88 */     MBlockDecoderUtils.collectPredictors(this.s, mb, mbX);
/*     */     
/*  90 */     this.di.mbTypes[mbAddr] = mBlock.curMbType;
/*  91 */     this.di.tr8x8Used[mbAddr] = mBlock.transform8x8Used;
/*     */   }
/*     */ 
/*     */   
/*     */   public void predictBDirect(Frame[][] refs, int mbX, int mbY, boolean lAvb, boolean tAvb, boolean tlAvb, boolean trAvb, H264Utils.MvList x, H264Const.PartPred[] pp, Picture mb, int[] blocks) {
/*  96 */     if (this.sh.directSpatialMvPredFlag) {
/*  97 */       predictBSpatialDirect(refs, mbX, mbY, lAvb, tAvb, tlAvb, trAvb, x, pp, mb, blocks);
/*     */     } else {
/*  99 */       predictBTemporalDirect(refs, mbX, mbY, lAvb, tAvb, tlAvb, trAvb, x, pp, mb, blocks);
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   private void predictBTemporalDirect(Frame[][] refs, int mbX, int mbY, boolean lAvb, boolean tAvb, boolean tlAvb, boolean trAvb, H264Utils.MvList x, H264Const.PartPred[] pp, Picture mb, int[] blocks8x8) {
/* 105 */     for (int i = 0; i < blocks8x8.length; i++) {
/* 106 */       int blk8x8 = blocks8x8[i];
/* 107 */       int blk4x4_0 = H264Const.BLK8x8_BLOCKS[blk8x8][0];
/* 108 */       pp[blk8x8] = H264Const.PartPred.Bi;
/*     */       
/* 110 */       if (!this.sh.sps.direct8x8InferenceFlag) {
/* 111 */         int[] js = H264Const.BLK8x8_BLOCKS[blk8x8];
/* 112 */         for (int j = 0; j < js.length; j++) {
/* 113 */           int blk4x4 = js[j];
/* 114 */           predTemp4x4(refs, mbX, mbY, x, blk4x4);
/*     */           
/* 116 */           int blkIndX = blk4x4 & 0x3;
/* 117 */           int blkIndY = blk4x4 >> 2;
/*     */           
/* 119 */           MBlockDecoderUtils.debugPrint(new Object[] { "DIRECT_4x4 [%d, %d]: (%d,%d,%d), (%d,%d,%d)", Integer.valueOf(blkIndY), Integer.valueOf(blkIndX), Integer.valueOf(x.mv0X(blk4x4)), 
/* 120 */                 Integer.valueOf(x.mv0Y(blk4x4)), Integer.valueOf(x.mv0R(blk4x4)), Integer.valueOf(x.mv1X(blk4x4)), Integer.valueOf(x.mv1Y(blk4x4)), Integer.valueOf(x.mv1R(blk4x4)) });
/*     */           
/* 122 */           int blkPredX = (mbX << 6) + (blkIndX << 4);
/* 123 */           int blkPredY = (mbY << 6) + (blkIndY << 4);
/*     */           
/* 125 */           this.interpolator.getBlockLuma((Picture)refs[0][x.mv0R(blk4x4)], this.mbb[0], H264Const.BLK_4x4_MB_OFF_LUMA[blk4x4], blkPredX + x
/* 126 */               .mv0X(blk4x4), blkPredY + x.mv0Y(blk4x4), 4, 4);
/* 127 */           this.interpolator.getBlockLuma((Picture)refs[1][0], this.mbb[1], H264Const.BLK_4x4_MB_OFF_LUMA[blk4x4], blkPredX + x
/* 128 */               .mv1X(blk4x4), blkPredY + x.mv1Y(blk4x4), 4, 4);
/*     */         } 
/*     */       } else {
/* 131 */         int blk4x4Pred = H264Const.BLK_INV_MAP[blk8x8 * 5];
/* 132 */         predTemp4x4(refs, mbX, mbY, x, blk4x4Pred);
/* 133 */         propagatePred(x, blk8x8, blk4x4Pred);
/*     */         
/* 135 */         int blkIndX = blk4x4_0 & 0x3;
/* 136 */         int blkIndY = blk4x4_0 >> 2;
/*     */         
/* 138 */         MBlockDecoderUtils.debugPrint(new Object[] { "DIRECT_8x8 [%d, %d]: (%d,%d,%d), (%d,%d)", Integer.valueOf(blkIndY), Integer.valueOf(blkIndX), Integer.valueOf(x.mv0X(blk4x4_0)), 
/* 139 */               Integer.valueOf(x.mv0Y(blk4x4_0)), Integer.valueOf(x.mv0R(blk4x4_0)), Integer.valueOf(x.mv1X(blk4x4_0)), Integer.valueOf(x.mv1Y(blk4x4_0)), Integer.valueOf(x.mv1R(blk4x4_0)) });
/*     */         
/* 141 */         int blkPredX = (mbX << 6) + (blkIndX << 4);
/* 142 */         int blkPredY = (mbY << 6) + (blkIndY << 4);
/*     */         
/* 144 */         this.interpolator.getBlockLuma((Picture)refs[0][x.mv0R(blk4x4_0)], this.mbb[0], H264Const.BLK_4x4_MB_OFF_LUMA[blk4x4_0], blkPredX + x
/* 145 */             .mv0X(blk4x4_0), blkPredY + x.mv0Y(blk4x4_0), 8, 8);
/* 146 */         this.interpolator.getBlockLuma((Picture)refs[1][0], this.mbb[1], H264Const.BLK_4x4_MB_OFF_LUMA[blk4x4_0], blkPredX + x
/* 147 */             .mv1X(blk4x4_0), blkPredY + x.mv1Y(blk4x4_0), 8, 8);
/*     */       } 
/* 149 */       PredictionMerger.mergePrediction(this.sh, x.mv0R(blk4x4_0), x.mv1R(blk4x4_0), H264Const.PartPred.Bi, 0, this.mbb[0].getPlaneData(0), this.mbb[1].getPlaneData(0), H264Const.BLK_4x4_MB_OFF_LUMA[blk4x4_0], 16, 8, 8, mb
/* 150 */           .getPlaneData(0), refs, this.poc);
/*     */     } 
/*     */   }
/*     */   private void predTemp4x4(Frame[][] refs, int mbX, int mbY, H264Utils.MvList x, int blk4x4) {
/*     */     Frame refL0;
/* 155 */     int refIdxL0, mbWidth = this.sh.sps.picWidthInMbsMinus1 + 1;
/*     */     
/* 157 */     Frame picCol = refs[1][0];
/* 158 */     int blkIndX = blk4x4 & 0x3;
/* 159 */     int blkIndY = blk4x4 >> 2;
/*     */     
/* 161 */     int blkPosX = (mbX << 2) + blkIndX;
/* 162 */     int blkPosY = (mbY << 2) + blkIndY;
/*     */     
/* 164 */     int mvCol = picCol.getMvs().getMv(blkPosX, blkPosY, 0);
/*     */ 
/*     */     
/* 167 */     if (H264Utils.Mv.mvRef(mvCol) == -1) {
/* 168 */       mvCol = picCol.getMvs().getMv(blkPosX, blkPosY, 1);
/* 169 */       if (H264Utils.Mv.mvRef(mvCol) == -1) {
/* 170 */         refIdxL0 = 0;
/* 171 */         refL0 = refs[0][0];
/*     */       } else {
/* 173 */         refL0 = picCol.getRefsUsed()[mbY * mbWidth + mbX][1][H264Utils.Mv.mvRef(mvCol)];
/* 174 */         refIdxL0 = findPic(refs[0], refL0);
/*     */       } 
/*     */     } else {
/* 177 */       refL0 = picCol.getRefsUsed()[mbY * mbWidth + mbX][0][H264Utils.Mv.mvRef(mvCol)];
/* 178 */       refIdxL0 = findPic(refs[0], refL0);
/*     */     } 
/*     */     
/* 181 */     int td = MathUtil.clip(picCol.getPOC() - refL0.getPOC(), -128, 127);
/* 182 */     if (!refL0.isShortTerm() || td == 0) {
/* 183 */       x.setPair(blk4x4, H264Utils.Mv.packMv(H264Utils.Mv.mvX(mvCol), H264Utils.Mv.mvY(mvCol), refIdxL0), 0);
/*     */     } else {
/* 185 */       int tb = MathUtil.clip(this.poc - refL0.getPOC(), -128, 127);
/* 186 */       int tx = (16384 + Math.abs(td / 2)) / td;
/* 187 */       int dsf = MathUtil.clip(tb * tx + 32 >> 6, -1024, 1023);
/*     */       
/* 189 */       x.setPair(blk4x4, H264Utils.Mv.packMv(dsf * H264Utils.Mv.mvX(mvCol) + 128 >> 8, dsf * H264Utils.Mv.mvY(mvCol) + 128 >> 8, refIdxL0), 
/* 190 */           H264Utils.Mv.packMv(x.mv0X(blk4x4) - H264Utils.Mv.mvX(mvCol), x.mv0Y(blk4x4) - H264Utils.Mv.mvY(mvCol), 0));
/*     */     } 
/*     */   }
/*     */   
/*     */   private int findPic(Frame[] frames, Frame refL0) {
/* 195 */     for (int i = 0; i < frames.length; i++) {
/* 196 */       if (frames[i] == refL0)
/* 197 */         return i; 
/* 198 */     }  Logger.error("RefPicList0 shall contain refPicCol");
/* 199 */     return 0;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private void predictBSpatialDirect(Frame[][] refs, int mbX, int mbY, boolean lAvb, boolean tAvb, boolean tlAvb, boolean trAvb, H264Utils.MvList x, H264Const.PartPred[] pp, Picture mb, int[] blocks8x8) {
/* 205 */     int a0 = this.s.mvLeft.getMv(0, 0), a1 = this.s.mvLeft.getMv(0, 1);
/* 206 */     int b0 = this.s.mvTop.getMv(mbX << 2, 0), b1 = this.s.mvTop.getMv(mbX << 2, 1);
/* 207 */     int c0 = this.s.mvTop.getMv((mbX << 2) + 4, 0), c1 = this.s.mvTop.getMv((mbX << 2) + 4, 1);
/* 208 */     int d0 = this.s.mvTopLeft.getMv(0, 0);
/* 209 */     int d1 = this.s.mvTopLeft.getMv(0, 1);
/*     */     
/* 211 */     int refIdxL0 = calcRef(a0, b0, c0, d0, lAvb, tAvb, tlAvb, trAvb, mbX);
/* 212 */     int refIdxL1 = calcRef(a1, b1, c1, d1, lAvb, tAvb, tlAvb, trAvb, mbX);
/*     */     
/* 214 */     if (refIdxL0 < 0 && refIdxL1 < 0) {
/* 215 */       for (int j = 0; j < blocks8x8.length; j++) {
/* 216 */         int blk8x8 = blocks8x8[j];
/* 217 */         int[] js = H264Const.BLK8x8_BLOCKS[blk8x8];
/* 218 */         for (int k = 0; k < js.length; k++) {
/* 219 */           int blk4x4 = js[k];
/* 220 */           x.setPair(blk4x4, 0, 0);
/*     */         } 
/* 222 */         pp[blk8x8] = H264Const.PartPred.Bi;
/*     */         
/* 224 */         int blkOffX = (blk8x8 & 0x1) << 5;
/* 225 */         int blkOffY = blk8x8 >> 1 << 5;
/* 226 */         this.interpolator.getBlockLuma((Picture)refs[0][0], this.mbb[0], H264Const.BLK_8x8_MB_OFF_LUMA[blk8x8], (mbX << 6) + blkOffX, (mbY << 6) + blkOffY, 8, 8);
/*     */         
/* 228 */         this.interpolator.getBlockLuma((Picture)refs[1][0], this.mbb[1], H264Const.BLK_8x8_MB_OFF_LUMA[blk8x8], (mbX << 6) + blkOffX, (mbY << 6) + blkOffY, 8, 8);
/*     */         
/* 230 */         PredictionMerger.mergePrediction(this.sh, 0, 0, H264Const.PartPred.Bi, 0, this.mbb[0].getPlaneData(0), this.mbb[1].getPlaneData(0), H264Const.BLK_8x8_MB_OFF_LUMA[blk8x8], 16, 8, 8, mb
/* 231 */             .getPlaneData(0), refs, this.poc);
/* 232 */         MBlockDecoderUtils.debugPrint(new Object[] { "DIRECT_8x8 [%d, %d]: (0,0,0), (0,0,0)", Integer.valueOf(blk8x8 & 0x2), Integer.valueOf(blk8x8 << 1 & 0x2) });
/*     */       } 
/*     */       return;
/*     */     } 
/* 236 */     int mvX0 = MBlockDecoderUtils.calcMVPredictionMedian(a0, b0, c0, d0, lAvb, tAvb, trAvb, tlAvb, refIdxL0, 0);
/* 237 */     int mvY0 = MBlockDecoderUtils.calcMVPredictionMedian(a0, b0, c0, d0, lAvb, tAvb, trAvb, tlAvb, refIdxL0, 1);
/* 238 */     int mvX1 = MBlockDecoderUtils.calcMVPredictionMedian(a1, b1, c1, d1, lAvb, tAvb, trAvb, tlAvb, refIdxL1, 0);
/* 239 */     int mvY1 = MBlockDecoderUtils.calcMVPredictionMedian(a1, b1, c1, d1, lAvb, tAvb, trAvb, tlAvb, refIdxL1, 1);
/*     */     
/* 241 */     Frame col = refs[1][0];
/* 242 */     H264Const.PartPred partPred = (refIdxL0 >= 0 && refIdxL1 >= 0) ? H264Const.PartPred.Bi : ((refIdxL0 >= 0) ? H264Const.PartPred.L0 : H264Const.PartPred.L1);
/* 243 */     for (int i = 0; i < blocks8x8.length; i++) {
/* 244 */       int blk8x8 = blocks8x8[i];
/* 245 */       int blk4x4_0 = H264Const.BLK8x8_BLOCKS[blk8x8][0];
/*     */       
/* 247 */       if (!this.sh.sps.direct8x8InferenceFlag) {
/* 248 */         int[] js = H264Const.BLK8x8_BLOCKS[blk8x8];
/* 249 */         for (int j = 0; j < js.length; j++) {
/* 250 */           int blk4x4 = js[j];
/* 251 */           pred4x4(mbX, mbY, x, pp, refIdxL0, refIdxL1, mvX0, mvY0, mvX1, mvY1, col, partPred, blk4x4);
/*     */           
/* 253 */           int blkIndX = blk4x4 & 0x3;
/* 254 */           int blkIndY = blk4x4 >> 2;
/*     */           
/* 256 */           MBlockDecoderUtils.debugPrint(new Object[] { "DIRECT_4x4 [%d, %d]: (%d,%d,%d), (%d,%d," + refIdxL1 + ")", Integer.valueOf(blkIndY), Integer.valueOf(blkIndX), 
/* 257 */                 Integer.valueOf(x.mv0X(blk4x4)), Integer.valueOf(x.mv0Y(blk4x4)), Integer.valueOf(refIdxL0), Integer.valueOf(x.mv1X(blk4x4)), Integer.valueOf(x.mv1Y(blk4x4)) });
/*     */           
/* 259 */           int blkPredX = (mbX << 6) + (blkIndX << 4);
/* 260 */           int blkPredY = (mbY << 6) + (blkIndY << 4);
/*     */           
/* 262 */           if (refIdxL0 >= 0)
/* 263 */             this.interpolator.getBlockLuma((Picture)refs[0][refIdxL0], this.mbb[0], H264Const.BLK_4x4_MB_OFF_LUMA[blk4x4], blkPredX + x
/* 264 */                 .mv0X(blk4x4), blkPredY + x.mv0Y(blk4x4), 4, 4); 
/* 265 */           if (refIdxL1 >= 0)
/* 266 */             this.interpolator.getBlockLuma((Picture)refs[1][refIdxL1], this.mbb[1], H264Const.BLK_4x4_MB_OFF_LUMA[blk4x4], blkPredX + x
/* 267 */                 .mv1X(blk4x4), blkPredY + x.mv1Y(blk4x4), 4, 4); 
/*     */         } 
/*     */       } else {
/* 270 */         int blk4x4Pred = H264Const.BLK_INV_MAP[blk8x8 * 5];
/* 271 */         pred4x4(mbX, mbY, x, pp, refIdxL0, refIdxL1, mvX0, mvY0, mvX1, mvY1, col, partPred, blk4x4Pred);
/* 272 */         propagatePred(x, blk8x8, blk4x4Pred);
/*     */         
/* 274 */         int blkIndX = blk4x4_0 & 0x3;
/* 275 */         int blkIndY = blk4x4_0 >> 2;
/*     */         
/* 277 */         MBlockDecoderUtils.debugPrint(new Object[] { "DIRECT_8x8 [%d, %d]: (%d,%d,%d), (%d,%d,%d)", Integer.valueOf(blkIndY), Integer.valueOf(blkIndX), Integer.valueOf(x.mv0X(blk4x4_0)), 
/* 278 */               Integer.valueOf(x.mv0Y(blk4x4_0)), Integer.valueOf(refIdxL0), Integer.valueOf(x.mv1X(blk4x4_0)), Integer.valueOf(x.mv1Y(blk4x4_0)), Integer.valueOf(refIdxL1) });
/*     */         
/* 280 */         int blkPredX = (mbX << 6) + (blkIndX << 4);
/* 281 */         int blkPredY = (mbY << 6) + (blkIndY << 4);
/*     */         
/* 283 */         if (refIdxL0 >= 0)
/* 284 */           this.interpolator.getBlockLuma((Picture)refs[0][refIdxL0], this.mbb[0], H264Const.BLK_4x4_MB_OFF_LUMA[blk4x4_0], blkPredX + x
/* 285 */               .mv0X(blk4x4_0), blkPredY + x.mv0Y(blk4x4_0), 8, 8); 
/* 286 */         if (refIdxL1 >= 0)
/* 287 */           this.interpolator.getBlockLuma((Picture)refs[1][refIdxL1], this.mbb[1], H264Const.BLK_4x4_MB_OFF_LUMA[blk4x4_0], blkPredX + x
/* 288 */               .mv1X(blk4x4_0), blkPredY + x.mv1Y(blk4x4_0), 8, 8); 
/*     */       } 
/* 290 */       PredictionMerger.mergePrediction(this.sh, x.mv0R(blk4x4_0), x.mv1R(blk4x4_0), (refIdxL0 >= 0) ? ((refIdxL1 >= 0) ? H264Const.PartPred.Bi : H264Const.PartPred.L0) : H264Const.PartPred.L1, 0, this.mbb[0]
/* 291 */           .getPlaneData(0), this.mbb[1].getPlaneData(0), H264Const.BLK_4x4_MB_OFF_LUMA[blk4x4_0], 16, 8, 8, mb
/* 292 */           .getPlaneData(0), refs, this.poc);
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   private int calcRef(int a0, int b0, int c0, int d0, boolean lAvb, boolean tAvb, boolean tlAvb, boolean trAvb, int mbX) {
/* 298 */     return minPos(minPos(lAvb ? H264Utils.Mv.mvRef(a0) : -1, tAvb ? H264Utils.Mv.mvRef(b0) : -1), trAvb ? H264Utils.Mv.mvRef(c0) : (tlAvb ? H264Utils.Mv.mvRef(d0) : -1));
/*     */   }
/*     */   
/*     */   private void propagatePred(H264Utils.MvList x, int blk8x8, int blk4x4Pred) {
/* 302 */     int b0 = H264Const.BLK8x8_BLOCKS[blk8x8][0];
/* 303 */     int b1 = H264Const.BLK8x8_BLOCKS[blk8x8][1];
/* 304 */     int b2 = H264Const.BLK8x8_BLOCKS[blk8x8][2];
/* 305 */     int b3 = H264Const.BLK8x8_BLOCKS[blk8x8][3];
/* 306 */     x.copyPair(b0, x, blk4x4Pred);
/* 307 */     x.copyPair(b1, x, blk4x4Pred);
/* 308 */     x.copyPair(b2, x, blk4x4Pred);
/* 309 */     x.copyPair(b3, x, blk4x4Pred);
/*     */   }
/*     */ 
/*     */   
/*     */   private void pred4x4(int mbX, int mbY, H264Utils.MvList x, H264Const.PartPred[] pp, int refL0, int refL1, int mvX0, int mvY0, int mvX1, int mvY1, Frame col, H264Const.PartPred partPred, int blk4x4) {
/* 314 */     int blkIndX = blk4x4 & 0x3;
/* 315 */     int blkIndY = blk4x4 >> 2;
/*     */     
/* 317 */     int blkPosX = (mbX << 2) + blkIndX;
/* 318 */     int blkPosY = (mbY << 2) + blkIndY;
/*     */     
/* 320 */     int mvCol = col.getMvs().getMv(blkPosX, blkPosY, 0);
/* 321 */     if (H264Utils.Mv.mvRef(mvCol) == -1) {
/* 322 */       mvCol = col.getMvs().getMv(blkPosX, blkPosY, 1);
/*     */     }
/*     */     
/* 325 */     boolean colZero = (col.isShortTerm() && H264Utils.Mv.mvRef(mvCol) == 0 && MathUtil.abs(H264Utils.Mv.mvX(mvCol)) >> 1 == 0 && MathUtil.abs(H264Utils.Mv.mvY(mvCol)) >> 1 == 0);
/*     */     
/* 327 */     int x0 = H264Utils.Mv.packMv(0, 0, refL0), x1 = H264Utils.Mv.packMv(0, 0, refL1);
/* 328 */     if (refL0 > 0 || !colZero) {
/* 329 */       x0 = H264Utils.Mv.packMv(mvX0, mvY0, refL0);
/*     */     }
/* 331 */     if (refL1 > 0 || !colZero) {
/* 332 */       x1 = H264Utils.Mv.packMv(mvX1, mvY1, refL1);
/*     */     }
/* 334 */     x.setPair(blk4x4, x0, x1);
/*     */     
/* 336 */     pp[H264Const.BLK_8x8_IND[blk4x4]] = partPred;
/*     */   }
/*     */   
/*     */   private int minPos(int a, int b) {
/* 340 */     return (a >= 0 && b >= 0) ? Math.min(a, b) : Math.max(a, b);
/*     */   }
/*     */ }


/* Location:              C:\Users\rapha\Downloads\aurora.jar!\META-INF\jars\jcodec-0.2.5.jar!\org\jcodec\codecs\h264\decode\MBlockDecoderBDirect.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */