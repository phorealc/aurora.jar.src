/*     */ package org.jcodec.codecs.h264.decode;
/*     */ 
/*     */ import org.jcodec.codecs.h264.H264Const;
/*     */ import org.jcodec.common.tools.MathUtil;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ChromaPredictionBuilder
/*     */ {
/*     */   public static void predictWithMode(int[][] residual, int chromaMode, int mbX, boolean leftAvailable, boolean topAvailable, byte[] leftRow, byte[] topLine, byte[] topLeft, byte[] pixOut) {
/*  21 */     switch (chromaMode) {
/*     */       case 0:
/*  23 */         predictDC(residual, mbX, leftAvailable, topAvailable, leftRow, topLine, pixOut);
/*     */         break;
/*     */       case 1:
/*  26 */         predictHorizontal(residual, mbX, leftAvailable, leftRow, pixOut);
/*     */         break;
/*     */       case 2:
/*  29 */         predictVertical(residual, mbX, topAvailable, topLine, pixOut);
/*     */         break;
/*     */       case 3:
/*  32 */         predictPlane(residual, mbX, leftAvailable, topAvailable, leftRow, topLine, topLeft, pixOut);
/*     */         break;
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public static void predictDC(int[][] planeData, int mbX, boolean leftAvailable, boolean topAvailable, byte[] leftRow, byte[] topLine, byte[] pixOut) {
/*  40 */     predictDCInside(planeData, 0, 0, mbX, leftAvailable, topAvailable, leftRow, topLine, pixOut);
/*  41 */     predictDCTopBorder(planeData, 1, 0, mbX, leftAvailable, topAvailable, leftRow, topLine, pixOut);
/*  42 */     predictDCLeftBorder(planeData, 0, 1, mbX, leftAvailable, topAvailable, leftRow, topLine, pixOut);
/*  43 */     predictDCInside(planeData, 1, 1, mbX, leftAvailable, topAvailable, leftRow, topLine, pixOut);
/*     */   }
/*     */   
/*     */   public static void predictVertical(int[][] residual, int mbX, boolean topAvailable, byte[] topLine, byte[] pixOut) {
/*  47 */     for (int off = 0, j = 0; j < 8; j++) {
/*  48 */       for (int i = 0; i < 8; i++, off++) {
/*  49 */         pixOut[off] = (byte)MathUtil.clip(residual[H264Const.CHROMA_BLOCK_LUT[off]][H264Const.CHROMA_POS_LUT[off]] + topLine[(mbX << 3) + i], -128, 127);
/*     */       }
/*     */     } 
/*     */   }
/*     */   
/*     */   public static void predictHorizontal(int[][] residual, int mbX, boolean leftAvailable, byte[] leftRow, byte[] pixOut) {
/*  55 */     for (int off = 0, j = 0; j < 8; j++) {
/*  56 */       for (int i = 0; i < 8; i++, off++) {
/*  57 */         pixOut[off] = (byte)MathUtil.clip(residual[H264Const.CHROMA_BLOCK_LUT[off]][H264Const.CHROMA_POS_LUT[off]] + leftRow[j], -128, 127);
/*     */       }
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public static void predictDCInside(int[][] residual, int blkX, int blkY, int mbX, boolean leftAvailable, boolean topAvailable, byte[] leftRow, byte[] topLine, byte[] pixOut) {
/*  64 */     int s0, blkOffX = (blkX << 2) + (mbX << 3), blkOffY = blkY << 2;
/*     */     
/*  66 */     if (leftAvailable && topAvailable) {
/*  67 */       s0 = 0; int i;
/*  68 */       for (i = 0; i < 4; i++)
/*  69 */         s0 += leftRow[i + blkOffY]; 
/*  70 */       for (i = 0; i < 4; i++) {
/*  71 */         s0 += topLine[blkOffX + i];
/*     */       }
/*  73 */       s0 = s0 + 4 >> 3;
/*  74 */     } else if (leftAvailable) {
/*  75 */       s0 = 0;
/*  76 */       for (int i = 0; i < 4; i++)
/*  77 */         s0 += leftRow[blkOffY + i]; 
/*  78 */       s0 = s0 + 2 >> 2;
/*  79 */     } else if (topAvailable) {
/*  80 */       s0 = 0;
/*  81 */       for (int i = 0; i < 4; i++)
/*  82 */         s0 += topLine[blkOffX + i]; 
/*  83 */       s0 = s0 + 2 >> 2;
/*     */     } else {
/*  85 */       s0 = 0;
/*     */     } 
/*     */     
/*  88 */     for (int off = (blkY << 5) + (blkX << 2), j = 0; j < 4; j++, off += 8) {
/*  89 */       pixOut[off] = (byte)MathUtil.clip(residual[H264Const.CHROMA_BLOCK_LUT[off]][H264Const.CHROMA_POS_LUT[off]] + s0, -128, 127);
/*  90 */       pixOut[off + 1] = (byte)MathUtil.clip(residual[H264Const.CHROMA_BLOCK_LUT[off + 1]][H264Const.CHROMA_POS_LUT[off + 1]] + s0, -128, 127);
/*  91 */       pixOut[off + 2] = (byte)MathUtil.clip(residual[H264Const.CHROMA_BLOCK_LUT[off + 2]][H264Const.CHROMA_POS_LUT[off + 2]] + s0, -128, 127);
/*  92 */       pixOut[off + 3] = (byte)MathUtil.clip(residual[H264Const.CHROMA_BLOCK_LUT[off + 3]][H264Const.CHROMA_POS_LUT[off + 3]] + s0, -128, 127);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public static void predictDCTopBorder(int[][] residual, int blkX, int blkY, int mbX, boolean leftAvailable, boolean topAvailable, byte[] leftRow, byte[] topLine, byte[] pixOut) {
/*  99 */     int s1, blkOffX = (blkX << 2) + (mbX << 3), blkOffY = blkY << 2;
/* 100 */     if (topAvailable) {
/* 101 */       s1 = 0;
/* 102 */       for (int i = 0; i < 4; i++) {
/* 103 */         s1 += topLine[blkOffX + i];
/*     */       }
/* 105 */       s1 = s1 + 2 >> 2;
/* 106 */     } else if (leftAvailable) {
/* 107 */       s1 = 0;
/* 108 */       for (int i = 0; i < 4; i++)
/* 109 */         s1 += leftRow[blkOffY + i]; 
/* 110 */       s1 = s1 + 2 >> 2;
/*     */     } else {
/* 112 */       s1 = 0;
/*     */     } 
/*     */     
/* 115 */     for (int off = (blkY << 5) + (blkX << 2), j = 0; j < 4; j++, off += 8) {
/* 116 */       pixOut[off] = (byte)MathUtil.clip(residual[H264Const.CHROMA_BLOCK_LUT[off]][H264Const.CHROMA_POS_LUT[off]] + s1, -128, 127);
/* 117 */       pixOut[off + 1] = (byte)MathUtil.clip(residual[H264Const.CHROMA_BLOCK_LUT[off + 1]][H264Const.CHROMA_POS_LUT[off + 1]] + s1, -128, 127);
/* 118 */       pixOut[off + 2] = (byte)MathUtil.clip(residual[H264Const.CHROMA_BLOCK_LUT[off + 2]][H264Const.CHROMA_POS_LUT[off + 2]] + s1, -128, 127);
/* 119 */       pixOut[off + 3] = (byte)MathUtil.clip(residual[H264Const.CHROMA_BLOCK_LUT[off + 3]][H264Const.CHROMA_POS_LUT[off + 3]] + s1, -128, 127);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public static void predictDCLeftBorder(int[][] residual, int blkX, int blkY, int mbX, boolean leftAvailable, boolean topAvailable, byte[] leftRow, byte[] topLine, byte[] pixOut) {
/* 126 */     int s2, blkOffX = (blkX << 2) + (mbX << 3), blkOffY = blkY << 2;
/* 127 */     if (leftAvailable) {
/* 128 */       s2 = 0;
/* 129 */       for (int i = 0; i < 4; i++)
/* 130 */         s2 += leftRow[blkOffY + i]; 
/* 131 */       s2 = s2 + 2 >> 2;
/* 132 */     } else if (topAvailable) {
/* 133 */       s2 = 0;
/* 134 */       for (int i = 0; i < 4; i++)
/* 135 */         s2 += topLine[blkOffX + i]; 
/* 136 */       s2 = s2 + 2 >> 2;
/*     */     } else {
/* 138 */       s2 = 0;
/*     */     } 
/*     */     
/* 141 */     for (int off = (blkY << 5) + (blkX << 2), j = 0; j < 4; j++, off += 8) {
/* 142 */       pixOut[off] = (byte)MathUtil.clip(residual[H264Const.CHROMA_BLOCK_LUT[off]][H264Const.CHROMA_POS_LUT[off]] + s2, -128, 127);
/* 143 */       pixOut[off + 1] = (byte)MathUtil.clip(residual[H264Const.CHROMA_BLOCK_LUT[off + 1]][H264Const.CHROMA_POS_LUT[off + 1]] + s2, -128, 127);
/* 144 */       pixOut[off + 2] = (byte)MathUtil.clip(residual[H264Const.CHROMA_BLOCK_LUT[off + 2]][H264Const.CHROMA_POS_LUT[off + 2]] + s2, -128, 127);
/* 145 */       pixOut[off + 3] = (byte)MathUtil.clip(residual[H264Const.CHROMA_BLOCK_LUT[off + 3]][H264Const.CHROMA_POS_LUT[off + 3]] + s2, -128, 127);
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public static void predictPlane(int[][] residual, int mbX, boolean leftAvailable, boolean topAvailable, byte[] leftRow, byte[] topLine, byte[] topLeft, byte[] pixOut) {
/* 151 */     int H = 0, blkOffX = mbX << 3;
/*     */     
/* 153 */     for (int i = 0; i < 3; i++) {
/* 154 */       H += (i + 1) * (topLine[blkOffX + 4 + i] - topLine[blkOffX + 2 - i]);
/*     */     }
/* 156 */     H += 4 * (topLine[blkOffX + 7] - topLeft[0]);
/*     */     
/* 158 */     int V = 0;
/* 159 */     for (int j = 0; j < 3; j++) {
/* 160 */       V += (j + 1) * (leftRow[4 + j] - leftRow[2 - j]);
/*     */     }
/* 162 */     V += 4 * (leftRow[7] - topLeft[0]);
/*     */     
/* 164 */     int c = 34 * V + 32 >> 6;
/* 165 */     int b = 34 * H + 32 >> 6;
/* 166 */     int a = 16 * (leftRow[7] + topLine[blkOffX + 7]);
/*     */     
/* 168 */     for (int off = 0, k = 0; k < 8; k++) {
/* 169 */       for (int m = 0; m < 8; m++, off++) {
/* 170 */         int val = a + b * (m - 3) + c * (k - 3) + 16 >> 5;
/* 171 */         pixOut[off] = (byte)MathUtil.clip(residual[H264Const.CHROMA_BLOCK_LUT[off]][H264Const.CHROMA_POS_LUT[off]] + MathUtil.clip(val, -128, 127), -128, 127);
/*     */       } 
/*     */     } 
/*     */   }
/*     */ }


/* Location:              C:\Users\rapha\Downloads\aurora.jar!\META-INF\jars\jcodec-0.2.5.jar!\org\jcodec\codecs\h264\decode\ChromaPredictionBuilder.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */