/*    */ package org.jcodec.codecs.h264.decode;
/*    */ 
/*    */ import org.jcodec.codecs.h264.H264Utils;
/*    */ import org.jcodec.codecs.h264.io.model.SliceHeader;
/*    */ import org.jcodec.common.model.ColorSpace;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class DecoderState
/*    */ {
/*    */   int[] chromaQpOffset;
/*    */   int qp;
/*    */   byte[][] leftRow;
/*    */   byte[][] topLine;
/*    */   byte[][] topLeft;
/*    */   ColorSpace chromaFormat;
/*    */   H264Utils.MvList mvTop;
/*    */   H264Utils.MvList mvLeft;
/*    */   H264Utils.MvList mvTopLeft;
/*    */   
/*    */   public DecoderState(SliceHeader sh) {
/* 30 */     int mbWidth = sh.sps.picWidthInMbsMinus1 + 1;
/* 31 */     this.chromaQpOffset = new int[] { sh.pps.chromaQpIndexOffset, (sh.pps.extended != null) ? sh.pps.extended.secondChromaQpIndexOffset : sh.pps.chromaQpIndexOffset };
/*    */ 
/*    */     
/* 34 */     this.chromaFormat = sh.sps.chromaFormatIdc;
/*    */     
/* 36 */     this.mvTop = new H264Utils.MvList((mbWidth << 2) + 1);
/* 37 */     this.mvLeft = new H264Utils.MvList(4);
/* 38 */     this.mvTopLeft = new H264Utils.MvList(1);
/*    */     
/* 40 */     this.leftRow = new byte[3][16];
/* 41 */     this.topLeft = new byte[3][4];
/* 42 */     this.topLine = new byte[3][mbWidth << 4];
/*    */     
/* 44 */     this.qp = sh.pps.picInitQpMinus26 + 26 + sh.sliceQpDelta;
/*    */   }
/*    */ }


/* Location:              C:\Users\rapha\Downloads\aurora.jar!\META-INF\jars\jcodec-0.2.5.jar!\org\jcodec\codecs\h264\decode\DecoderState.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */