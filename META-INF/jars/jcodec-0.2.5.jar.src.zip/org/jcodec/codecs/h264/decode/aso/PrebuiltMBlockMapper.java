/*    */ package org.jcodec.codecs.h264.decode.aso;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class PrebuiltMBlockMapper
/*    */   implements Mapper
/*    */ {
/*    */   private MBToSliceGroupMap map;
/*    */   private int firstMBInSlice;
/*    */   private int groupId;
/*    */   private int picWidthInMbs;
/*    */   private int indexOfFirstMb;
/*    */   
/*    */   public PrebuiltMBlockMapper(MBToSliceGroupMap map, int firstMBInSlice, int picWidthInMbs) {
/* 22 */     this.map = map;
/* 23 */     this.firstMBInSlice = firstMBInSlice;
/* 24 */     this.groupId = map.getGroups()[firstMBInSlice];
/* 25 */     this.picWidthInMbs = picWidthInMbs;
/* 26 */     this.indexOfFirstMb = map.getIndices()[firstMBInSlice];
/*    */   }
/*    */   
/*    */   public int getAddress(int mbIndex) {
/* 30 */     return this.map.getInverse()[this.groupId][mbIndex + this.indexOfFirstMb];
/*    */   }
/*    */   
/*    */   public boolean leftAvailable(int mbIndex) {
/* 34 */     int mbAddr = this.map.getInverse()[this.groupId][mbIndex + this.indexOfFirstMb];
/* 35 */     int leftMBAddr = mbAddr - 1;
/*    */     
/* 37 */     return (leftMBAddr >= this.firstMBInSlice && mbAddr % this.picWidthInMbs != 0 && this.map.getGroups()[leftMBAddr] == this.groupId);
/*    */   }
/*    */   
/*    */   public boolean topAvailable(int mbIndex) {
/* 41 */     int mbAddr = this.map.getInverse()[this.groupId][mbIndex + this.indexOfFirstMb];
/* 42 */     int topMBAddr = mbAddr - this.picWidthInMbs;
/*    */     
/* 44 */     return (topMBAddr >= this.firstMBInSlice && this.map.getGroups()[topMBAddr] == this.groupId);
/*    */   }
/*    */   
/*    */   public int getMbX(int index) {
/* 48 */     return getAddress(index) % this.picWidthInMbs;
/*    */   }
/*    */   
/*    */   public int getMbY(int index) {
/* 52 */     return getAddress(index) / this.picWidthInMbs;
/*    */   }
/*    */   
/*    */   public boolean topRightAvailable(int mbIndex) {
/* 56 */     int mbAddr = this.map.getInverse()[this.groupId][mbIndex + this.indexOfFirstMb];
/* 57 */     int topRMBAddr = mbAddr - this.picWidthInMbs + 1;
/*    */     
/* 59 */     return (topRMBAddr >= this.firstMBInSlice && (mbAddr + 1) % this.picWidthInMbs != 0 && this.map.getGroups()[topRMBAddr] == this.groupId);
/*    */   }
/*    */   
/*    */   public boolean topLeftAvailable(int mbIndex) {
/* 63 */     int mbAddr = this.map.getInverse()[this.groupId][mbIndex + this.indexOfFirstMb];
/* 64 */     int topLMBAddr = mbAddr - this.picWidthInMbs - 1;
/*    */     
/* 66 */     return (topLMBAddr >= this.firstMBInSlice && mbAddr % this.picWidthInMbs != 0 && this.map.getGroups()[topLMBAddr] == this.groupId);
/*    */   }
/*    */ }


/* Location:              C:\Users\rapha\Downloads\aurora.jar!\META-INF\jars\jcodec-0.2.5.jar!\org\jcodec\codecs\h264\decode\aso\PrebuiltMBlockMapper.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */