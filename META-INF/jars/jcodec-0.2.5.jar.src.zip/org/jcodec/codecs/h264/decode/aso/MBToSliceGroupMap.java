/*    */ package org.jcodec.codecs.h264.decode.aso;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class MBToSliceGroupMap
/*    */ {
/*    */   private int[] groups;
/*    */   private int[] indices;
/*    */   private int[][] inverse;
/*    */   
/*    */   public MBToSliceGroupMap(int[] groups, int[] indices, int[][] inverse) {
/* 19 */     this.groups = groups;
/* 20 */     this.indices = indices;
/* 21 */     this.inverse = inverse;
/*    */   }
/*    */   
/*    */   public int[] getGroups() {
/* 25 */     return this.groups;
/*    */   }
/*    */   
/*    */   public int[] getIndices() {
/* 29 */     return this.indices;
/*    */   }
/*    */   
/*    */   public int[][] getInverse() {
/* 33 */     return this.inverse;
/*    */   }
/*    */ }


/* Location:              C:\Users\rapha\Downloads\aurora.jar!\META-INF\jars\jcodec-0.2.5.jar!\org\jcodec\codecs\h264\decode\aso\MBToSliceGroupMap.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */