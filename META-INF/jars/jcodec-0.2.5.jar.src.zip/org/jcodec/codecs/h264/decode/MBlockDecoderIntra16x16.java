/*    */ package org.jcodec.codecs.h264.decode;
/*    */ 
/*    */ import org.jcodec.codecs.h264.decode.aso.Mapper;
/*    */ import org.jcodec.codecs.h264.io.model.SliceHeader;
/*    */ import org.jcodec.common.model.Picture;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class MBlockDecoderIntra16x16
/*    */   extends MBlockDecoderBase
/*    */ {
/*    */   private Mapper mapper;
/*    */   
/*    */   public MBlockDecoderIntra16x16(Mapper mapper, SliceHeader sh, DeblockerInput di, int poc, DecoderState decoderState) {
/* 23 */     super(sh, di, poc, decoderState);
/* 24 */     this.mapper = mapper;
/*    */   }
/*    */   
/*    */   public void decode(MBlock mBlock, Picture mb) {
/* 28 */     int mbX = this.mapper.getMbX(mBlock.mbIdx);
/* 29 */     int mbY = this.mapper.getMbY(mBlock.mbIdx);
/* 30 */     int address = this.mapper.getAddress(mBlock.mbIdx);
/* 31 */     boolean leftAvailable = this.mapper.leftAvailable(mBlock.mbIdx);
/* 32 */     boolean topAvailable = this.mapper.topAvailable(mBlock.mbIdx);
/* 33 */     this.s.qp = (this.s.qp + mBlock.mbQPDelta + 52) % 52;
/* 34 */     this.di.mbQps[0][address] = this.s.qp;
/*    */     
/* 36 */     residualLumaI16x16(mBlock, leftAvailable, topAvailable, mbX, mbY);
/*    */     
/* 38 */     Intra16x16PredictionBuilder.predictWithMode(mBlock.luma16x16Mode, mBlock.ac[0], leftAvailable, topAvailable, this.s.leftRow[0], this.s.topLine[0], this.s.topLeft[0], mbX << 4, mb
/* 39 */         .getPlaneData(0));
/*    */     
/* 41 */     decodeChroma(mBlock, mbX, mbY, leftAvailable, topAvailable, mb, this.s.qp);
/* 42 */     this.di.mbTypes[address] = mBlock.curMbType;
/*    */     
/* 44 */     MBlockDecoderUtils.collectPredictors(this.s, mb, mbX);
/* 45 */     MBlockDecoderUtils.saveMvsIntra(this.di, mbX, mbY);
/* 46 */     MBlockDecoderUtils.saveVectIntra(this.s, this.mapper.getMbX(mBlock.mbIdx));
/*    */   }
/*    */   
/*    */   private void residualLumaI16x16(MBlock mBlock, boolean leftAvailable, boolean topAvailable, int mbX, int mbY) {
/* 50 */     CoeffTransformer.invDC4x4(mBlock.dc);
/* 51 */     int[] scalingList = getScalingList(0);
/* 52 */     CoeffTransformer.dequantizeDC4x4(mBlock.dc, this.s.qp, scalingList);
/* 53 */     CoeffTransformer.reorderDC4x4(mBlock.dc);
/*    */     
/* 55 */     for (int i = 0; i < 16; i++) {
/* 56 */       if ((mBlock.cbpLuma() & 1 << i >> 2) != 0) {
/* 57 */         CoeffTransformer.dequantizeAC(mBlock.ac[0][i], this.s.qp, scalingList);
/*    */       }
/* 59 */       mBlock.ac[0][i][0] = mBlock.dc[i];
/* 60 */       CoeffTransformer.idct4x4(mBlock.ac[0][i]);
/*    */     } 
/*    */   }
/*    */ }


/* Location:              C:\Users\rapha\Downloads\aurora.jar!\META-INF\jars\jcodec-0.2.5.jar!\org\jcodec\codecs\h264\decode\MBlockDecoderIntra16x16.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */