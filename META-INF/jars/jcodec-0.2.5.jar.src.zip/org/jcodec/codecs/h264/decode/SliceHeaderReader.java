/*     */ package org.jcodec.codecs.h264.decode;
/*     */ 
/*     */ import java.util.ArrayList;
/*     */ import org.jcodec.codecs.h264.io.model.NALUnit;
/*     */ import org.jcodec.codecs.h264.io.model.NALUnitType;
/*     */ import org.jcodec.codecs.h264.io.model.PictureParameterSet;
/*     */ import org.jcodec.codecs.h264.io.model.PredictionWeightTable;
/*     */ import org.jcodec.codecs.h264.io.model.RefPicMarking;
/*     */ import org.jcodec.codecs.h264.io.model.RefPicMarkingIDR;
/*     */ import org.jcodec.codecs.h264.io.model.SeqParameterSet;
/*     */ import org.jcodec.codecs.h264.io.model.SliceHeader;
/*     */ import org.jcodec.codecs.h264.io.model.SliceType;
/*     */ import org.jcodec.common.IntArrayList;
/*     */ import org.jcodec.common.io.BitReader;
/*     */ import org.jcodec.common.model.ColorSpace;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class SliceHeaderReader
/*     */ {
/*     */   public static SliceHeader readPart1(BitReader _in) {
/*  40 */     SliceHeader sh = new SliceHeader();
/*  41 */     sh.firstMbInSlice = CAVLCReader.readUEtrace(_in, "SH: first_mb_in_slice");
/*  42 */     int shType = CAVLCReader.readUEtrace(_in, "SH: slice_type");
/*  43 */     sh.sliceType = SliceType.fromValue(shType % 5);
/*  44 */     sh.sliceTypeRestr = (shType / 5 > 0);
/*     */     
/*  46 */     sh.picParameterSetId = CAVLCReader.readUEtrace(_in, "SH: pic_parameter_set_id");
/*     */     
/*  48 */     return sh;
/*     */   }
/*     */ 
/*     */   
/*     */   public static SliceHeader readPart2(SliceHeader sh, NALUnit nalUnit, SeqParameterSet sps, PictureParameterSet pps, BitReader _in) {
/*  53 */     sh.pps = pps;
/*  54 */     sh.sps = sps;
/*     */     
/*  56 */     sh.frameNum = CAVLCReader.readU(_in, sps.log2MaxFrameNumMinus4 + 4, "SH: frame_num");
/*  57 */     if (!sps.frameMbsOnlyFlag) {
/*  58 */       sh.fieldPicFlag = CAVLCReader.readBool(_in, "SH: field_pic_flag");
/*  59 */       if (sh.fieldPicFlag) {
/*  60 */         sh.bottomFieldFlag = CAVLCReader.readBool(_in, "SH: bottom_field_flag");
/*     */       }
/*     */     } 
/*  63 */     if (nalUnit.type == NALUnitType.IDR_SLICE) {
/*  64 */       sh.idrPicId = CAVLCReader.readUEtrace(_in, "SH: idr_pic_id");
/*     */     }
/*  66 */     if (sps.picOrderCntType == 0) {
/*  67 */       sh.picOrderCntLsb = CAVLCReader.readU(_in, sps.log2MaxPicOrderCntLsbMinus4 + 4, "SH: pic_order_cnt_lsb");
/*  68 */       if (pps.picOrderPresentFlag && !sps.fieldPicFlag) {
/*  69 */         sh.deltaPicOrderCntBottom = CAVLCReader.readSE(_in, "SH: delta_pic_order_cnt_bottom");
/*     */       }
/*     */     } 
/*  72 */     sh.deltaPicOrderCnt = new int[2];
/*  73 */     if (sps.picOrderCntType == 1 && !sps.deltaPicOrderAlwaysZeroFlag) {
/*  74 */       sh.deltaPicOrderCnt[0] = CAVLCReader.readSE(_in, "SH: delta_pic_order_cnt[0]");
/*  75 */       if (pps.picOrderPresentFlag && !sps.fieldPicFlag)
/*  76 */         sh.deltaPicOrderCnt[1] = CAVLCReader.readSE(_in, "SH: delta_pic_order_cnt[1]"); 
/*     */     } 
/*  78 */     if (pps.redundantPicCntPresentFlag) {
/*  79 */       sh.redundantPicCnt = CAVLCReader.readUEtrace(_in, "SH: redundant_pic_cnt");
/*     */     }
/*  81 */     if (sh.sliceType == SliceType.B) {
/*  82 */       sh.directSpatialMvPredFlag = CAVLCReader.readBool(_in, "SH: direct_spatial_mv_pred_flag");
/*     */     }
/*  84 */     if (sh.sliceType == SliceType.P || sh.sliceType == SliceType.SP || sh.sliceType == SliceType.B) {
/*  85 */       sh.numRefIdxActiveOverrideFlag = CAVLCReader.readBool(_in, "SH: num_ref_idx_active_override_flag");
/*  86 */       if (sh.numRefIdxActiveOverrideFlag) {
/*  87 */         sh.numRefIdxActiveMinus1[0] = CAVLCReader.readUEtrace(_in, "SH: num_ref_idx_l0_active_minus1");
/*  88 */         if (sh.sliceType == SliceType.B) {
/*  89 */           sh.numRefIdxActiveMinus1[1] = CAVLCReader.readUEtrace(_in, "SH: num_ref_idx_l1_active_minus1");
/*     */         }
/*     */       } 
/*     */     } 
/*  93 */     readRefPicListReordering(sh, _in);
/*  94 */     if ((pps.weightedPredFlag && (sh.sliceType == SliceType.P || sh.sliceType == SliceType.SP)) || (pps.weightedBipredIdc == 1 && sh.sliceType == SliceType.B))
/*     */     {
/*  96 */       readPredWeightTable(sps, pps, sh, _in); } 
/*  97 */     if (nalUnit.nal_ref_idc != 0)
/*  98 */       readDecoderPicMarking(nalUnit, sh, _in); 
/*  99 */     if (pps.entropyCodingModeFlag && sh.sliceType.isInter()) {
/* 100 */       sh.cabacInitIdc = CAVLCReader.readUEtrace(_in, "SH: cabac_init_idc");
/*     */     }
/* 102 */     sh.sliceQpDelta = CAVLCReader.readSE(_in, "SH: slice_qp_delta");
/* 103 */     if (sh.sliceType == SliceType.SP || sh.sliceType == SliceType.SI) {
/* 104 */       if (sh.sliceType == SliceType.SP) {
/* 105 */         sh.spForSwitchFlag = CAVLCReader.readBool(_in, "SH: sp_for_switch_flag");
/*     */       }
/* 107 */       sh.sliceQsDelta = CAVLCReader.readSE(_in, "SH: slice_qs_delta");
/*     */     } 
/* 109 */     if (pps.deblockingFilterControlPresentFlag) {
/* 110 */       sh.disableDeblockingFilterIdc = CAVLCReader.readUEtrace(_in, "SH: disable_deblocking_filter_idc");
/* 111 */       if (sh.disableDeblockingFilterIdc != 1) {
/* 112 */         sh.sliceAlphaC0OffsetDiv2 = CAVLCReader.readSE(_in, "SH: slice_alpha_c0_offset_div2");
/* 113 */         sh.sliceBetaOffsetDiv2 = CAVLCReader.readSE(_in, "SH: slice_beta_offset_div2");
/*     */       } 
/*     */     } 
/* 116 */     if (pps.numSliceGroupsMinus1 > 0 && pps.sliceGroupMapType >= 3 && pps.sliceGroupMapType <= 5) {
/* 117 */       int len = SeqParameterSet.getPicHeightInMbs(sps) * (sps.picWidthInMbsMinus1 + 1) / (pps.sliceGroupChangeRateMinus1 + 1);
/*     */       
/* 119 */       if (SeqParameterSet.getPicHeightInMbs(sps) * (sps.picWidthInMbsMinus1 + 1) % (pps.sliceGroupChangeRateMinus1 + 1) > 0)
/*     */       {
/* 121 */         len++;
/*     */       }
/* 123 */       len = CeilLog2(len + 1);
/* 124 */       sh.sliceGroupChangeCycle = CAVLCReader.readU(_in, len, "SH: slice_group_change_cycle");
/*     */     } 
/*     */     
/* 127 */     return sh;
/*     */   }
/*     */   
/*     */   private static int CeilLog2(int uiVal) {
/* 131 */     int uiTmp = uiVal - 1;
/* 132 */     int uiRet = 0;
/*     */     
/* 134 */     while (uiTmp != 0) {
/* 135 */       uiTmp >>= 1;
/* 136 */       uiRet++;
/*     */     } 
/* 138 */     return uiRet;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private static void readDecoderPicMarking(NALUnit nalUnit, SliceHeader sh, BitReader _in) {
/* 144 */     if (nalUnit.type == NALUnitType.IDR_SLICE) {
/* 145 */       boolean noOutputOfPriorPicsFlag = CAVLCReader.readBool(_in, "SH: no_output_of_prior_pics_flag");
/* 146 */       boolean longTermReferenceFlag = CAVLCReader.readBool(_in, "SH: long_term_reference_flag");
/* 147 */       sh.refPicMarkingIDR = new RefPicMarkingIDR(noOutputOfPriorPicsFlag, longTermReferenceFlag);
/*     */     } else {
/* 149 */       boolean adaptiveRefPicMarkingModeFlag = CAVLCReader.readBool(_in, "SH: adaptive_ref_pic_marking_mode_flag");
/* 150 */       if (adaptiveRefPicMarkingModeFlag) {
/* 151 */         ArrayList<RefPicMarking.Instruction> mmops = new ArrayList<RefPicMarking.Instruction>();
/*     */         
/*     */         while (true) {
/* 154 */           int memoryManagementControlOperation = CAVLCReader.readUEtrace(_in, "SH: memory_management_control_operation");
/*     */           
/* 156 */           RefPicMarking.Instruction instr = null;
/*     */           
/* 158 */           switch (memoryManagementControlOperation) {
/*     */             case 1:
/* 160 */               instr = new RefPicMarking.Instruction(RefPicMarking.InstrType.REMOVE_SHORT, CAVLCReader.readUEtrace(_in, "SH: difference_of_pic_nums_minus1") + 1, 0);
/*     */               break;
/*     */ 
/*     */             
/*     */             case 2:
/* 165 */               instr = new RefPicMarking.Instruction(RefPicMarking.InstrType.REMOVE_LONG, CAVLCReader.readUEtrace(_in, "SH: long_term_pic_num"), 0);
/*     */               break;
/*     */             
/*     */             case 3:
/* 169 */               instr = new RefPicMarking.Instruction(RefPicMarking.InstrType.CONVERT_INTO_LONG, CAVLCReader.readUEtrace(_in, "SH: difference_of_pic_nums_minus1") + 1, CAVLCReader.readUEtrace(_in, "SH: long_term_frame_idx"));
/*     */               break;
/*     */             case 4:
/* 172 */               instr = new RefPicMarking.Instruction(RefPicMarking.InstrType.TRUNK_LONG, CAVLCReader.readUEtrace(_in, "SH: max_long_term_frame_idx_plus1") - 1, 0);
/*     */               break;
/*     */             
/*     */             case 5:
/* 176 */               instr = new RefPicMarking.Instruction(RefPicMarking.InstrType.CLEAR, 0, 0);
/*     */               break;
/*     */             
/*     */             case 6:
/* 180 */               instr = new RefPicMarking.Instruction(RefPicMarking.InstrType.MARK_LONG, CAVLCReader.readUEtrace(_in, "SH: long_term_frame_idx"), 0);
/*     */               break;
/*     */           } 
/* 183 */           if (instr != null)
/* 184 */             mmops.add(instr); 
/* 185 */           if (memoryManagementControlOperation == 0) {
/* 186 */             sh.refPicMarkingNonIDR = new RefPicMarking(mmops.<RefPicMarking.Instruction>toArray(new RefPicMarking.Instruction[0]));
/*     */             break;
/*     */           } 
/*     */         } 
/*     */       } 
/*     */     }  } private static void readPredWeightTable(SeqParameterSet sps, PictureParameterSet pps, SliceHeader sh, BitReader _in) {
/* 192 */     sh.predWeightTable = new PredictionWeightTable();
/* 193 */     int[] numRefsMinus1 = sh.numRefIdxActiveOverrideFlag ? sh.numRefIdxActiveMinus1 : pps.numRefIdxActiveMinus1;
/*     */     
/* 195 */     int[] nr = { numRefsMinus1[0] + 1, numRefsMinus1[1] + 1 };
/*     */     
/* 197 */     sh.predWeightTable.lumaLog2WeightDenom = CAVLCReader.readUEtrace(_in, "SH: luma_log2_weight_denom");
/* 198 */     if (sps.chromaFormatIdc != ColorSpace.MONO) {
/* 199 */       sh.predWeightTable.chromaLog2WeightDenom = CAVLCReader.readUEtrace(_in, "SH: chroma_log2_weight_denom");
/*     */     }
/* 201 */     int defaultLW = 1 << sh.predWeightTable.lumaLog2WeightDenom;
/* 202 */     int defaultCW = 1 << sh.predWeightTable.chromaLog2WeightDenom;
/*     */     
/* 204 */     for (int list = 0; list < 2; list++) {
/* 205 */       sh.predWeightTable.lumaWeight[list] = new int[nr[list]];
/* 206 */       sh.predWeightTable.lumaOffset[list] = new int[nr[list]];
/* 207 */       sh.predWeightTable.chromaWeight[list] = new int[2][nr[list]];
/* 208 */       sh.predWeightTable.chromaOffset[list] = new int[2][nr[list]];
/* 209 */       for (int i = 0; i < nr[list]; i++) {
/* 210 */         sh.predWeightTable.lumaWeight[list][i] = defaultLW;
/* 211 */         sh.predWeightTable.lumaOffset[list][i] = 0;
/* 212 */         sh.predWeightTable.chromaWeight[list][0][i] = defaultCW;
/* 213 */         sh.predWeightTable.chromaOffset[list][0][i] = 0;
/* 214 */         sh.predWeightTable.chromaWeight[list][1][i] = defaultCW;
/* 215 */         sh.predWeightTable.chromaOffset[list][1][i] = 0;
/*     */       } 
/*     */     } 
/*     */     
/* 219 */     readWeightOffset(sps, pps, sh, _in, nr, 0);
/* 220 */     if (sh.sliceType == SliceType.B) {
/* 221 */       readWeightOffset(sps, pps, sh, _in, nr, 1);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private static void readWeightOffset(SeqParameterSet sps, PictureParameterSet pps, SliceHeader sh, BitReader _in, int[] numRefs, int list) {
/* 228 */     for (int i = 0; i < numRefs[list]; i++) {
/* 229 */       boolean lumaWeightL0Flag = CAVLCReader.readBool(_in, "SH: luma_weight_l0_flag");
/* 230 */       if (lumaWeightL0Flag) {
/* 231 */         sh.predWeightTable.lumaWeight[list][i] = CAVLCReader.readSE(_in, "SH: weight");
/* 232 */         sh.predWeightTable.lumaOffset[list][i] = CAVLCReader.readSE(_in, "SH: offset");
/*     */       } 
/* 234 */       if (sps.chromaFormatIdc != ColorSpace.MONO) {
/* 235 */         boolean chromaWeightL0Flag = CAVLCReader.readBool(_in, "SH: chroma_weight_l0_flag");
/* 236 */         if (chromaWeightL0Flag) {
/* 237 */           sh.predWeightTable.chromaWeight[list][0][i] = CAVLCReader.readSE(_in, "SH: weight");
/* 238 */           sh.predWeightTable.chromaOffset[list][0][i] = CAVLCReader.readSE(_in, "SH: offset");
/* 239 */           sh.predWeightTable.chromaWeight[list][1][i] = CAVLCReader.readSE(_in, "SH: weight");
/* 240 */           sh.predWeightTable.chromaOffset[list][1][i] = CAVLCReader.readSE(_in, "SH: offset");
/*     */         } 
/*     */       } 
/*     */     } 
/*     */   }
/*     */   
/*     */   private static void readRefPicListReordering(SliceHeader sh, BitReader _in) {
/* 247 */     sh.refPicReordering = new int[2][][];
/*     */     
/* 249 */     if (sh.sliceType.isInter()) {
/* 250 */       boolean refPicListReorderingFlagL0 = CAVLCReader.readBool(_in, "SH: ref_pic_list_reordering_flag_l0");
/* 251 */       if (refPicListReorderingFlagL0) {
/* 252 */         sh.refPicReordering[0] = readReorderingEntries(_in);
/*     */       }
/*     */     } 
/* 255 */     if (sh.sliceType == SliceType.B) {
/* 256 */       boolean refPicListReorderingFlagL1 = CAVLCReader.readBool(_in, "SH: ref_pic_list_reordering_flag_l1");
/* 257 */       if (refPicListReorderingFlagL1) {
/* 258 */         sh.refPicReordering[1] = readReorderingEntries(_in);
/*     */       }
/*     */     } 
/*     */   }
/*     */   
/*     */   private static int[][] readReorderingEntries(BitReader _in) {
/* 264 */     IntArrayList ops = IntArrayList.createIntArrayList();
/* 265 */     IntArrayList args = IntArrayList.createIntArrayList();
/*     */     while (true) {
/* 267 */       int idc = CAVLCReader.readUEtrace(_in, "SH: reordering_of_pic_nums_idc");
/* 268 */       if (idc == 3)
/*     */         break; 
/* 270 */       ops.add(idc);
/* 271 */       args.add(CAVLCReader.readUEtrace(_in, "SH: abs_diff_pic_num_minus1"));
/*     */     } 
/* 273 */     return new int[][] { ops.toArray(), args.toArray() };
/*     */   }
/*     */ }


/* Location:              C:\Users\rapha\Downloads\aurora.jar!\META-INF\jars\jcodec-0.2.5.jar!\org\jcodec\codecs\h264\decode\SliceHeaderReader.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */