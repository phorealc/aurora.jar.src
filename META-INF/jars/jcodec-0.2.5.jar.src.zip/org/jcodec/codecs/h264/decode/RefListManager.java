/*     */ package org.jcodec.codecs.h264.decode;
/*     */ 
/*     */ import java.util.Arrays;
/*     */ import java.util.Comparator;
/*     */ import org.jcodec.codecs.h264.H264Const;
/*     */ import org.jcodec.codecs.h264.io.model.Frame;
/*     */ import org.jcodec.codecs.h264.io.model.SliceHeader;
/*     */ import org.jcodec.codecs.h264.io.model.SliceType;
/*     */ import org.jcodec.common.IntObjectMap;
/*     */ import org.jcodec.common.model.Picture;
/*     */ import org.jcodec.common.tools.MathUtil;
/*     */ import org.jcodec.platform.Platform;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class RefListManager
/*     */ {
/*     */   private SliceHeader sh;
/*     */   private int[] numRef;
/*     */   private Frame[] sRefs;
/*     */   private IntObjectMap<Frame> lRefs;
/*     */   private Frame frameOut;
/*     */   
/*     */   public RefListManager(SliceHeader sh, Frame[] sRefs, IntObjectMap<Frame> lRefs, Frame frameOut) {
/*  29 */     this.sh = sh;
/*  30 */     this.sRefs = sRefs;
/*  31 */     this.lRefs = lRefs;
/*  32 */     if (sh.numRefIdxActiveOverrideFlag) {
/*  33 */       this.numRef = new int[] { sh.numRefIdxActiveMinus1[0] + 1, sh.numRefIdxActiveMinus1[1] + 1 };
/*     */     } else {
/*  35 */       this.numRef = new int[] { sh.pps.numRefIdxActiveMinus1[0] + 1, sh.pps.numRefIdxActiveMinus1[1] + 1 };
/*  36 */     }  this.frameOut = frameOut;
/*     */   }
/*     */   
/*     */   public Frame[][] getRefList() {
/*  40 */     Frame[][] refList = (Frame[][])null;
/*  41 */     if (this.sh.sliceType == SliceType.P) {
/*  42 */       refList = new Frame[][] { buildRefListP(), null };
/*  43 */     } else if (this.sh.sliceType == SliceType.B) {
/*  44 */       refList = buildRefListB();
/*     */     } 
/*     */     
/*  47 */     MBlockDecoderUtils.debugPrint(new Object[] { "------" });
/*  48 */     if (refList != null)
/*  49 */       for (int l = 0; l < 2; l++) {
/*  50 */         if (refList[l] != null)
/*  51 */           for (int i = 0; i < (refList[l]).length; i++) {
/*  52 */             if (refList[l][i] != null)
/*  53 */               MBlockDecoderUtils.debugPrint(new Object[] { "REF[%d][%d]: ", Integer.valueOf(l), Integer.valueOf(i), Integer.valueOf(refList[l][i].getPOC()) }); 
/*     */           }  
/*     */       }  
/*  56 */     return refList;
/*     */   }
/*     */   
/*     */   private Frame[] buildRefListP() {
/*  60 */     int frame_num = this.sh.frameNum;
/*  61 */     int maxFrames = 1 << this.sh.sps.log2MaxFrameNumMinus4 + 4;
/*     */     
/*  63 */     Frame[] result = new Frame[this.numRef[0]];
/*     */     
/*  65 */     int refs = 0;
/*  66 */     for (int i = frame_num - 1; i >= frame_num - maxFrames && refs < this.numRef[0]; i--) {
/*  67 */       int fn = (i < 0) ? (i + maxFrames) : i;
/*  68 */       if (this.sRefs[fn] != null) {
/*  69 */         result[refs] = (this.sRefs[fn] == H264Const.NO_PIC) ? null : this.sRefs[fn];
/*  70 */         refs++;
/*     */       } 
/*     */     } 
/*  73 */     int[] keys = this.lRefs.keys();
/*  74 */     Arrays.sort(keys);
/*  75 */     for (int j = 0; j < keys.length && refs < this.numRef[0]; j++) {
/*  76 */       result[refs++] = (Frame)this.lRefs.get(keys[j]);
/*     */     }
/*     */     
/*  79 */     reorder((Picture[])result, 0);
/*     */     
/*  81 */     return result;
/*     */   }
/*     */ 
/*     */   
/*     */   private Frame[][] buildRefListB() {
/*  86 */     Frame[] l0 = buildList(Frame.POCDesc, Frame.POCAsc);
/*  87 */     Frame[] l1 = buildList(Frame.POCAsc, Frame.POCDesc);
/*     */     
/*  89 */     if (Platform.arrayEqualsObj((Object[])l0, (Object[])l1) && count(l1) > 1) {
/*  90 */       Frame frame = l1[1];
/*  91 */       l1[1] = l1[0];
/*  92 */       l1[0] = frame;
/*     */     } 
/*     */     
/*  95 */     Frame[][] result = { (Frame[])Platform.copyOfObj((Object[])l0, this.numRef[0]), (Frame[])Platform.copyOfObj((Object[])l1, this.numRef[1]) };
/*     */     
/*  97 */     reorder((Picture[])result[0], 0);
/*  98 */     reorder((Picture[])result[1], 1);
/*     */     
/* 100 */     return result;
/*     */   }
/*     */   
/*     */   private Frame[] buildList(Comparator<Frame> cmpFwd, Comparator<Frame> cmpInv) {
/* 104 */     Frame[] refs = new Frame[this.sRefs.length + this.lRefs.size()];
/* 105 */     Frame[] fwd = copySort(cmpFwd, this.frameOut);
/* 106 */     Frame[] inv = copySort(cmpInv, this.frameOut);
/* 107 */     int nFwd = count(fwd);
/* 108 */     int nInv = count(inv);
/*     */     
/* 110 */     int ref = 0; int i;
/* 111 */     for (i = 0; i < nFwd; i++, ref++)
/* 112 */       refs[ref] = fwd[i]; 
/* 113 */     for (i = 0; i < nInv; i++, ref++) {
/* 114 */       refs[ref] = inv[i];
/*     */     }
/* 116 */     int[] keys = this.lRefs.keys();
/* 117 */     Arrays.sort(keys);
/* 118 */     for (int j = 0; j < keys.length; j++, ref++) {
/* 119 */       refs[ref] = (Frame)this.lRefs.get(keys[j]);
/*     */     }
/* 121 */     return refs;
/*     */   }
/*     */   
/*     */   private int count(Frame[] arr) {
/* 125 */     for (int nn = 0; nn < arr.length; nn++) {
/* 126 */       if (arr[nn] == null)
/* 127 */         return nn; 
/* 128 */     }  return arr.length;
/*     */   }
/*     */   
/*     */   private Frame[] copySort(Comparator<Frame> fwd, Frame dummy) {
/* 132 */     Frame[] copyOf = (Frame[])Platform.copyOfObj((Object[])this.sRefs, this.sRefs.length);
/* 133 */     for (int i = 0; i < copyOf.length; i++) {
/* 134 */       if (fwd.compare(dummy, copyOf[i]) > 0)
/* 135 */         copyOf[i] = null; 
/* 136 */     }  Arrays.sort(copyOf, fwd);
/* 137 */     return copyOf;
/*     */   }
/*     */   
/*     */   private void reorder(Picture[] result, int list) {
/* 141 */     if (this.sh.refPicReordering[list] == null) {
/*     */       return;
/*     */     }
/* 144 */     int predict = this.sh.frameNum;
/* 145 */     int maxFrames = 1 << this.sh.sps.log2MaxFrameNumMinus4 + 4;
/*     */     
/* 147 */     for (int ind = 0; ind < (this.sh.refPicReordering[list][0]).length; ind++) {
/* 148 */       switch (this.sh.refPicReordering[list][0][ind]) {
/*     */         case 0:
/* 150 */           predict = MathUtil.wrap(predict - this.sh.refPicReordering[list][1][ind] - 1, maxFrames);
/*     */           break;
/*     */         case 1:
/* 153 */           predict = MathUtil.wrap(predict + this.sh.refPicReordering[list][1][ind] + 1, maxFrames);
/*     */           break;
/*     */         case 2:
/* 156 */           throw new RuntimeException("long term");
/*     */       }  int i;
/* 158 */       for (i = this.numRef[list] - 1; i > ind; i--)
/* 159 */         result[i] = result[i - 1]; 
/* 160 */       result[ind] = (Picture)this.sRefs[predict];
/* 161 */       for (int j = i = ind + 1; i < this.numRef[list] && result[i] != null; i++) {
/* 162 */         if (result[i] != this.sRefs[predict])
/* 163 */           result[j++] = result[i]; 
/*     */       } 
/*     */     } 
/*     */   }
/*     */ }


/* Location:              C:\Users\rapha\Downloads\aurora.jar!\META-INF\jars\jcodec-0.2.5.jar!\org\jcodec\codecs\h264\decode\RefListManager.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */