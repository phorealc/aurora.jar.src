/*     */ package org.jcodec.codecs.h264.decode;
/*     */ 
/*     */ import org.jcodec.codecs.h264.H264Utils;
/*     */ import org.jcodec.common.ArrayUtil;
/*     */ import org.jcodec.common.logging.Logger;
/*     */ import org.jcodec.common.model.Picture;
/*     */ import org.jcodec.common.tools.MathUtil;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class MBlockDecoderUtils
/*     */ {
/*     */   private static boolean debug;
/*  15 */   public static final int NULL_VECTOR = H264Utils.Mv.packMv(0, 0, -1);
/*     */   
/*     */   public static void debugPrint(Object... arguments) {
/*  18 */     if (debug && arguments.length > 0) {
/*  19 */       if (arguments.length == 1) {
/*  20 */         Logger.debug("" + arguments[0]);
/*     */       } else {
/*  22 */         String fmt = (String)arguments[0];
/*  23 */         ArrayUtil.shiftLeft1(arguments);
/*  24 */         Logger.debug(String.format(fmt, arguments));
/*     */       } 
/*     */     }
/*     */   }
/*     */   
/*     */   static void collectPredictors(DecoderState sharedState, Picture outMB, int mbX) {
/*  30 */     sharedState.topLeft[0][0] = sharedState.topLine[0][(mbX << 4) + 15];
/*  31 */     sharedState.topLeft[0][1] = outMB.getPlaneData(0)[63];
/*  32 */     sharedState.topLeft[0][2] = outMB.getPlaneData(0)[127];
/*  33 */     sharedState.topLeft[0][3] = outMB.getPlaneData(0)[191];
/*  34 */     System.arraycopy(outMB.getPlaneData(0), 240, sharedState.topLine[0], mbX << 4, 16);
/*  35 */     copyCol(outMB.getPlaneData(0), 16, 15, 16, sharedState.leftRow[0]);
/*     */     
/*  37 */     collectChromaPredictors(sharedState, outMB, mbX);
/*     */   }
/*     */   
/*     */   static void collectChromaPredictors(DecoderState sharedState, Picture outMB, int mbX) {
/*  41 */     sharedState.topLeft[1][0] = sharedState.topLine[1][(mbX << 3) + 7];
/*  42 */     sharedState.topLeft[2][0] = sharedState.topLine[2][(mbX << 3) + 7];
/*     */     
/*  44 */     System.arraycopy(outMB.getPlaneData(1), 56, sharedState.topLine[1], mbX << 3, 8);
/*  45 */     System.arraycopy(outMB.getPlaneData(2), 56, sharedState.topLine[2], mbX << 3, 8);
/*     */     
/*  47 */     copyCol(outMB.getPlaneData(1), 8, 7, 8, sharedState.leftRow[1]);
/*  48 */     copyCol(outMB.getPlaneData(2), 8, 7, 8, sharedState.leftRow[2]);
/*     */   }
/*     */   
/*     */   private static void copyCol(byte[] planeData, int n, int off, int stride, byte[] out) {
/*  52 */     for (int i = 0; i < n; i++, off += stride) {
/*  53 */       out[i] = planeData[off];
/*     */     }
/*     */   }
/*     */   
/*     */   static void saveMvsIntra(DeblockerInput di, int mbX, int mbY) {
/*  58 */     for (int j = 0, blkOffY = mbY << 2, blkInd = 0; j < 4; j++, blkOffY++) {
/*  59 */       for (int i = 0, blkOffX = mbX << 2; i < 4; i++, blkOffX++, blkInd++) {
/*  60 */         di.mvs.setMv(blkOffX, blkOffY, 0, NULL_VECTOR);
/*  61 */         di.mvs.setMv(blkOffX, blkOffY, 1, NULL_VECTOR);
/*     */       } 
/*     */     } 
/*     */   }
/*     */   
/*     */   static void mergeResidual(Picture mb, int[][][] residual, int[][] blockLUT, int[][] posLUT) {
/*  67 */     for (int comp = 0; comp < 3; comp++) {
/*  68 */       byte[] to = mb.getPlaneData(comp);
/*  69 */       for (int i = 0; i < to.length; i++) {
/*  70 */         to[i] = (byte)MathUtil.clip(to[i] + residual[comp][blockLUT[comp][i]][posLUT[comp][i]], -128, 127);
/*     */       }
/*     */     } 
/*     */   }
/*     */   
/*     */   static void saveVect(H264Utils.MvList mv, int list, int from, int to, int vect) {
/*  76 */     for (int i = from; i < to; i++) {
/*  77 */       mv.setMv(i, list, vect);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static int calcMVPredictionMedian(int a, int b, int c, int d, boolean aAvb, boolean bAvb, boolean cAvb, boolean dAvb, int ref, int comp) {
/*  88 */     if (!cAvb) {
/*  89 */       c = d;
/*  90 */       cAvb = dAvb;
/*     */     } 
/*     */     
/*  93 */     if (aAvb && !bAvb && !cAvb) {
/*  94 */       b = c = a;
/*  95 */       bAvb = cAvb = aAvb;
/*     */     } 
/*     */     
/*  98 */     a = aAvb ? a : NULL_VECTOR;
/*  99 */     b = bAvb ? b : NULL_VECTOR;
/* 100 */     c = cAvb ? c : NULL_VECTOR;
/*     */     
/* 102 */     if (H264Utils.Mv.mvRef(a) == ref && H264Utils.Mv.mvRef(b) != ref && H264Utils.Mv.mvRef(c) != ref)
/* 103 */       return H264Utils.Mv.mvC(a, comp); 
/* 104 */     if (H264Utils.Mv.mvRef(b) == ref && H264Utils.Mv.mvRef(a) != ref && H264Utils.Mv.mvRef(c) != ref)
/* 105 */       return H264Utils.Mv.mvC(b, comp); 
/* 106 */     if (H264Utils.Mv.mvRef(c) == ref && H264Utils.Mv.mvRef(a) != ref && H264Utils.Mv.mvRef(b) != ref) {
/* 107 */       return H264Utils.Mv.mvC(c, comp);
/*     */     }
/* 109 */     return H264Utils.Mv.mvC(a, comp) + H264Utils.Mv.mvC(b, comp) + H264Utils.Mv.mvC(c, comp) - min(H264Utils.Mv.mvC(a, comp), H264Utils.Mv.mvC(b, comp), H264Utils.Mv.mvC(c, comp)) - 
/* 110 */       max(H264Utils.Mv.mvC(a, comp), H264Utils.Mv.mvC(b, comp), H264Utils.Mv.mvC(c, comp));
/*     */   }
/*     */   
/*     */   public static int max(int x, int x2, int x3) {
/* 114 */     return (x > x2) ? ((x > x3) ? x : x3) : ((x2 > x3) ? x2 : x3);
/*     */   }
/*     */   
/*     */   public static int min(int x, int x2, int x3) {
/* 118 */     return (x < x2) ? ((x < x3) ? x : x3) : ((x2 < x3) ? x2 : x3);
/*     */   }
/*     */   
/*     */   static void saveMvs(DeblockerInput di, H264Utils.MvList x, int mbX, int mbY) {
/* 122 */     for (int j = 0, blkOffY = mbY << 2, blkInd = 0; j < 4; j++, blkOffY++) {
/* 123 */       for (int i = 0, blkOffX = mbX << 2; i < 4; i++, blkOffX++, blkInd++) {
/* 124 */         di.mvs.setMv(blkOffX, blkOffY, 0, x.getMv(blkInd, 0));
/* 125 */         di.mvs.setMv(blkOffX, blkOffY, 1, x.getMv(blkInd, 1));
/*     */       } 
/*     */     } 
/*     */   }
/*     */   
/*     */   static void savePrediction8x8(DecoderState sharedState, int mbX, H264Utils.MvList x) {
/* 131 */     sharedState.mvTopLeft.copyPair(0, sharedState.mvTop, (mbX << 2) + 3);
/* 132 */     sharedState.mvLeft.copyPair(0, x, 3);
/* 133 */     sharedState.mvLeft.copyPair(1, x, 7);
/* 134 */     sharedState.mvLeft.copyPair(2, x, 11);
/* 135 */     sharedState.mvLeft.copyPair(3, x, 15);
/* 136 */     sharedState.mvTop.copyPair(mbX << 2, x, 12);
/* 137 */     sharedState.mvTop.copyPair((mbX << 2) + 1, x, 13);
/* 138 */     sharedState.mvTop.copyPair((mbX << 2) + 2, x, 14);
/* 139 */     sharedState.mvTop.copyPair((mbX << 2) + 3, x, 15);
/*     */   }
/*     */   
/*     */   public static void saveVectIntra(DecoderState sharedState, int mbX) {
/* 143 */     int xx = mbX << 2;
/*     */     
/* 145 */     sharedState.mvTopLeft.copyPair(0, sharedState.mvTop, xx + 3);
/*     */     
/* 147 */     saveVect(sharedState.mvTop, 0, xx, xx + 4, NULL_VECTOR);
/* 148 */     saveVect(sharedState.mvLeft, 0, 0, 4, NULL_VECTOR);
/* 149 */     saveVect(sharedState.mvTop, 1, xx, xx + 4, NULL_VECTOR);
/* 150 */     saveVect(sharedState.mvLeft, 1, 0, 4, NULL_VECTOR);
/*     */   }
/*     */ }


/* Location:              C:\Users\rapha\Downloads\aurora.jar!\META-INF\jars\jcodec-0.2.5.jar!\org\jcodec\codecs\h264\decode\MBlockDecoderUtils.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */