/*     */ package org.jcodec.codecs.h264.decode;
/*     */ 
/*     */ import java.util.Arrays;
/*     */ import org.jcodec.common.ArrayUtil;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class CoeffTransformer
/*     */ {
/*  17 */   public static int[] zigzag4x4 = new int[] { 0, 1, 4, 8, 5, 2, 3, 6, 9, 12, 13, 10, 7, 11, 14, 15 };
/*  18 */   public static int[] invZigzag4x4 = new int[16];
/*     */   
/*  20 */   static int[][] dequantCoef = new int[][] { { 10, 13, 10, 13, 13, 16, 13, 16, 10, 13, 10, 13, 13, 16, 13, 16 }, { 11, 14, 11, 14, 14, 18, 14, 18, 11, 14, 11, 14, 14, 18, 14, 18 }, { 13, 16, 13, 16, 16, 20, 16, 20, 13, 16, 13, 16, 16, 20, 16, 20 }, { 14, 18, 14, 18, 18, 23, 18, 23, 14, 18, 14, 18, 18, 23, 18, 23 }, { 16, 20, 16, 20, 20, 25, 20, 25, 16, 20, 16, 20, 20, 25, 20, 25 }, { 18, 23, 18, 23, 23, 29, 23, 29, 18, 23, 18, 23, 23, 29, 23, 29 } };
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  29 */   static int[][] dequantCoef8x8 = new int[6][64];
/*     */   
/*  31 */   static int[][] initDequantCoeff8x8 = new int[][] { { 20, 18, 32, 19, 25, 24 }, { 22, 19, 35, 21, 28, 26 }, { 26, 23, 42, 24, 33, 31 }, { 28, 25, 45, 26, 35, 33 }, { 32, 28, 51, 30, 40, 38 }, { 36, 32, 58, 34, 46, 43 } };
/*     */ 
/*     */ 
/*     */   
/*  35 */   public static int[] zigzag8x8 = new int[] { 0, 1, 8, 16, 9, 2, 3, 10, 17, 24, 32, 25, 18, 11, 4, 5, 12, 19, 26, 33, 40, 48, 41, 34, 27, 20, 13, 6, 7, 14, 21, 28, 35, 42, 49, 56, 57, 50, 43, 36, 29, 22, 15, 23, 30, 37, 44, 51, 58, 59, 52, 45, 38, 31, 39, 46, 53, 60, 61, 54, 47, 55, 62, 63 };
/*     */ 
/*     */   
/*  38 */   public static int[] invZigzag8x8 = new int[64];
/*     */   static {
/*     */     int i;
/*  41 */     for (i = 0; i < 16; i++)
/*  42 */       invZigzag4x4[zigzag4x4[i]] = i; 
/*  43 */     for (i = 0; i < 64; i++)
/*  44 */       invZigzag8x8[zigzag8x8[i]] = i; 
/*     */   }
/*     */   
/*  47 */   private static final int[][] quantCoeff = new int[][] { { 13107, 8066, 13107, 8066, 8066, 5243, 8066, 5243, 13107, 8066, 13107, 8066, 8066, 5243, 8066, 5243 }, { 11916, 7490, 11916, 7490, 7490, 4660, 7490, 4660, 11916, 7490, 11916, 7490, 7490, 4660, 7490, 4660 }, { 10082, 6554, 10082, 6554, 6554, 4194, 6554, 4194, 10082, 6554, 10082, 6554, 6554, 4194, 6554, 4194 }, { 9362, 5825, 9362, 5825, 5825, 3647, 5825, 3647, 9362, 5825, 9362, 5825, 5825, 3647, 5825, 3647 }, { 8192, 5243, 8192, 5243, 5243, 3355, 5243, 3355, 8192, 5243, 8192, 5243, 5243, 3355, 5243, 3355 }, { 7282, 4559, 7282, 4559, 4559, 2893, 4559, 2893, 7282, 4559, 7282, 4559, 4559, 2893, 4559, 2893 } };
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static {
/*  56 */     for (int g = 0; g < 6; g++) {
/*  57 */       Arrays.fill(dequantCoef8x8[g], initDequantCoeff8x8[g][5]); int j;
/*  58 */       for (j = 0; j < 8; j += 4) {
/*  59 */         for (int k = 0; k < 8; k += 4)
/*  60 */           dequantCoef8x8[g][(j << 3) + k] = initDequantCoeff8x8[g][0]; 
/*  61 */       }  for (j = 1; j < 8; j += 2) {
/*  62 */         for (int k = 1; k < 8; k += 2)
/*  63 */           dequantCoef8x8[g][(j << 3) + k] = initDequantCoeff8x8[g][1]; 
/*  64 */       }  for (j = 2; j < 8; j += 4) {
/*  65 */         for (int k = 2; k < 8; k += 4)
/*  66 */           dequantCoef8x8[g][(j << 3) + k] = initDequantCoeff8x8[g][2]; 
/*  67 */       }  for (j = 0; j < 8; j += 4) {
/*  68 */         for (int k = 1; k < 8; k += 2)
/*  69 */           dequantCoef8x8[g][(j << 3) + k] = initDequantCoeff8x8[g][3]; 
/*  70 */       }  for (j = 1; j < 8; j += 2) {
/*  71 */         for (int k = 0; k < 8; k += 4)
/*  72 */           dequantCoef8x8[g][(j << 3) + k] = initDequantCoeff8x8[g][3]; 
/*  73 */       }  for (j = 0; j < 8; j += 4) {
/*  74 */         for (int k = 2; k < 8; k += 4)
/*  75 */           dequantCoef8x8[g][(j << 3) + k] = initDequantCoeff8x8[g][4]; 
/*  76 */       }  for (j = 2; j < 8; j += 4) {
/*  77 */         for (int k = 0; k < 8; k += 4) {
/*  78 */           dequantCoef8x8[g][(j << 3) + k] = initDequantCoeff8x8[g][4];
/*     */         }
/*     */       } 
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static final void idct4x4(int[] block) {
/*  89 */     _idct4x4(block, block);
/*     */   }
/*     */   
/*     */   public static final void _idct4x4(int[] block, int[] out) {
/*     */     int i;
/*  94 */     for (i = 0; i < 16; i += 4) {
/*  95 */       int e0 = block[i] + block[i + 2];
/*  96 */       int e1 = block[i] - block[i + 2];
/*  97 */       int e2 = (block[i + 1] >> 1) - block[i + 3];
/*  98 */       int e3 = block[i + 1] + (block[i + 3] >> 1);
/*     */       
/* 100 */       out[i] = e0 + e3;
/* 101 */       out[i + 1] = e1 + e2;
/* 102 */       out[i + 2] = e1 - e2;
/* 103 */       out[i + 3] = e0 - e3;
/*     */     } 
/*     */ 
/*     */     
/* 107 */     for (i = 0; i < 4; i++) {
/* 108 */       int g0 = out[i] + out[i + 8];
/* 109 */       int g1 = out[i] - out[i + 8];
/* 110 */       int g2 = (out[i + 4] >> 1) - out[i + 12];
/* 111 */       int g3 = out[i + 4] + (out[i + 12] >> 1);
/* 112 */       out[i] = g0 + g3;
/* 113 */       out[i + 4] = g1 + g2;
/* 114 */       out[i + 8] = g1 - g2;
/* 115 */       out[i + 12] = g0 - g3;
/*     */     } 
/*     */ 
/*     */     
/* 119 */     for (i = 0; i < 16; i++) {
/* 120 */       out[i] = out[i] + 32 >> 6;
/*     */     }
/*     */   }
/*     */   
/*     */   public static void fdct4x4(int[] block) {
/*     */     int i;
/* 126 */     for (i = 0; i < 16; i += 4) {
/* 127 */       int t0 = block[i] + block[i + 3];
/* 128 */       int t1 = block[i + 1] + block[i + 2];
/* 129 */       int t2 = block[i + 1] - block[i + 2];
/* 130 */       int t3 = block[i] - block[i + 3];
/*     */       
/* 132 */       block[i] = t0 + t1;
/* 133 */       block[i + 1] = (t3 << 1) + t2;
/* 134 */       block[i + 2] = t0 - t1;
/* 135 */       block[i + 3] = t3 - (t2 << 1);
/*     */     } 
/*     */ 
/*     */     
/* 139 */     for (i = 0; i < 4; i++) {
/* 140 */       int t0 = block[i] + block[i + 12];
/* 141 */       int t1 = block[i + 4] + block[i + 8];
/* 142 */       int t2 = block[i + 4] - block[i + 8];
/* 143 */       int t3 = block[i] - block[i + 12];
/*     */       
/* 145 */       block[i] = t0 + t1;
/* 146 */       block[i + 4] = t2 + (t3 << 1);
/* 147 */       block[i + 8] = t0 - t1;
/* 148 */       block[i + 12] = t3 - (t2 << 1);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static void invDC4x4(int[] scaled) {
/*     */     int i;
/* 159 */     for (i = 0; i < 16; i += 4) {
/* 160 */       int e0 = scaled[i] + scaled[i + 2];
/* 161 */       int e1 = scaled[i] - scaled[i + 2];
/* 162 */       int e2 = scaled[i + 1] - scaled[i + 3];
/* 163 */       int e3 = scaled[i + 1] + scaled[i + 3];
/*     */       
/* 165 */       scaled[i] = e0 + e3;
/* 166 */       scaled[i + 1] = e1 + e2;
/* 167 */       scaled[i + 2] = e1 - e2;
/* 168 */       scaled[i + 3] = e0 - e3;
/*     */     } 
/*     */ 
/*     */     
/* 172 */     for (i = 0; i < 4; i++) {
/* 173 */       int g0 = scaled[i] + scaled[i + 8];
/* 174 */       int g1 = scaled[i] - scaled[i + 8];
/* 175 */       int g2 = scaled[i + 4] - scaled[i + 12];
/* 176 */       int g3 = scaled[i + 4] + scaled[i + 12];
/* 177 */       scaled[i] = g0 + g3;
/* 178 */       scaled[i + 4] = g1 + g2;
/* 179 */       scaled[i + 8] = g1 - g2;
/* 180 */       scaled[i + 12] = g0 - g3;
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static void fvdDC4x4(int[] scaled) {
/*     */     int i;
/* 191 */     for (i = 0; i < 16; i += 4) {
/* 192 */       int t0 = scaled[i] + scaled[i + 3];
/* 193 */       int t1 = scaled[i + 1] + scaled[i + 2];
/* 194 */       int t2 = scaled[i + 1] - scaled[i + 2];
/* 195 */       int t3 = scaled[i] - scaled[i + 3];
/*     */       
/* 197 */       scaled[i] = t0 + t1;
/* 198 */       scaled[i + 1] = t3 + t2;
/* 199 */       scaled[i + 2] = t0 - t1;
/* 200 */       scaled[i + 3] = t3 - t2;
/*     */     } 
/*     */ 
/*     */     
/* 204 */     for (i = 0; i < 4; i++) {
/* 205 */       int t0 = scaled[i] + scaled[i + 12];
/* 206 */       int t1 = scaled[i + 4] + scaled[i + 8];
/* 207 */       int t2 = scaled[i + 4] - scaled[i + 8];
/* 208 */       int t3 = scaled[i] - scaled[i + 12];
/*     */       
/* 210 */       scaled[i] = t0 + t1 >> 1;
/* 211 */       scaled[i + 4] = t2 + t3 >> 1;
/* 212 */       scaled[i + 8] = t0 - t1 >> 1;
/* 213 */       scaled[i + 12] = t3 - t2 >> 1;
/*     */     } 
/*     */   }
/*     */   
/*     */   public static void dequantizeAC(int[] coeffs, int qp, int[] scalingList) {
/* 218 */     int group = qp % 6;
/*     */     
/* 220 */     if (scalingList == null) {
/* 221 */       int qbits = qp / 6;
/* 222 */       for (int i = 0; i < 16; i++) {
/* 223 */         coeffs[i] = coeffs[i] * dequantCoef[group][i] << qbits;
/*     */       }
/* 225 */     } else if (qp >= 24) {
/* 226 */       int qbits = qp / 6 - 4;
/* 227 */       for (int i = 0; i < 16; i++)
/* 228 */         coeffs[i] = coeffs[i] * dequantCoef[group][i] * scalingList[invZigzag4x4[i]] << qbits; 
/*     */     } else {
/* 230 */       int qbits = 4 - qp / 6;
/* 231 */       int addition = 1 << 3 - qp / 6;
/* 232 */       for (int i = 0; i < 16; i++) {
/* 233 */         coeffs[i] = coeffs[i] * scalingList[invZigzag4x4[i]] * dequantCoef[group][i] + addition >> qbits;
/*     */       }
/*     */     } 
/*     */   }
/*     */   
/*     */   public static void quantizeAC(int[] coeffs, int qp) {
/* 239 */     int level = qp / 6;
/* 240 */     int offset = qp % 6;
/*     */     
/* 242 */     int addition = 682 << qp / 6 + 4;
/* 243 */     int qbits = 15 + level;
/*     */     
/* 245 */     if (qp < 10) {
/* 246 */       for (int i = 0; i < 16; i++) {
/* 247 */         int sign = coeffs[i] >> 31;
/* 248 */         coeffs[i] = (Math.min(((coeffs[i] ^ sign) - sign) * quantCoeff[offset][i] + addition >> qbits, 2063) ^ sign) - sign;
/*     */       } 
/*     */     } else {
/*     */       
/* 252 */       for (int i = 0; i < 16; i++) {
/* 253 */         int sign = coeffs[i] >> 31;
/* 254 */         coeffs[i] = (((coeffs[i] ^ sign) - sign) * quantCoeff[offset][i] + addition >> qbits ^ sign) - sign;
/*     */       } 
/*     */     } 
/*     */   }
/*     */   
/*     */   public static void dequantizeDC4x4(int[] coeffs, int qp, int[] scalingList) {
/* 260 */     int group = qp % 6;
/*     */     
/* 262 */     if (qp >= 36) {
/* 263 */       int qbits = qp / 6 - 6;
/* 264 */       if (scalingList == null) {
/* 265 */         for (int i = 0; i < 16; i++)
/* 266 */           coeffs[i] = coeffs[i] * (dequantCoef[group][0] << 4) << qbits; 
/*     */       } else {
/* 268 */         for (int i = 0; i < 16; i++)
/* 269 */           coeffs[i] = coeffs[i] * dequantCoef[group][0] * scalingList[0] << qbits; 
/*     */       } 
/*     */     } else {
/* 272 */       int qbits = 6 - qp / 6;
/* 273 */       int addition = 1 << 5 - qp / 6;
/* 274 */       if (scalingList == null) {
/* 275 */         for (int i = 0; i < 16; i++)
/* 276 */           coeffs[i] = coeffs[i] * (dequantCoef[group][0] << 4) + addition >> qbits; 
/*     */       } else {
/* 278 */         for (int i = 0; i < 16; i++) {
/* 279 */           coeffs[i] = coeffs[i] * dequantCoef[group][0] * scalingList[0] + addition >> qbits;
/*     */         }
/*     */       } 
/*     */     } 
/*     */   }
/*     */   
/*     */   public static void quantizeDC4x4(int[] coeffs, int qp) {
/* 286 */     int level = qp / 6;
/* 287 */     int offset = qp % 6;
/*     */     
/* 289 */     int addition = 682 << qp / 6 + 5;
/* 290 */     int qbits = 16 + level;
/*     */     
/* 292 */     if (qp < 10) {
/* 293 */       for (int i = 0; i < 16; i++) {
/* 294 */         int sign = coeffs[i] >> 31;
/* 295 */         coeffs[i] = (Math.min(((coeffs[i] ^ sign) - sign) * quantCoeff[offset][0] + addition >> qbits, 2063) ^ sign) - sign;
/*     */       } 
/*     */     } else {
/*     */       
/* 299 */       for (int i = 0; i < 16; i++) {
/* 300 */         int sign = coeffs[i] >> 31;
/* 301 */         coeffs[i] = (((coeffs[i] ^ sign) - sign) * quantCoeff[offset][0] + addition >> qbits ^ sign) - sign;
/*     */       } 
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static void invDC2x2(int[] block) {
/* 314 */     int t0 = block[0] + block[1];
/* 315 */     int t1 = block[0] - block[1];
/* 316 */     int t2 = block[2] + block[3];
/* 317 */     int t3 = block[2] - block[3];
/*     */     
/* 319 */     block[0] = t0 + t2;
/* 320 */     block[1] = t1 + t3;
/* 321 */     block[2] = t0 - t2;
/* 322 */     block[3] = t1 - t3;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static void fvdDC2x2(int[] block) {
/* 331 */     invDC2x2(block);
/*     */   }
/*     */ 
/*     */   
/*     */   public static void dequantizeDC2x2(int[] transformed, int qp, int[] scalingList) {
/* 336 */     int group = qp % 6;
/*     */     
/* 338 */     if (scalingList == null) {
/* 339 */       int shift = qp / 6;
/*     */       
/* 341 */       for (int i = 0; i < 4; i++) {
/* 342 */         transformed[i] = transformed[i] * dequantCoef[group][0] << shift >> 1;
/*     */       }
/*     */     }
/* 345 */     else if (qp >= 24) {
/* 346 */       int qbits = qp / 6 - 4;
/* 347 */       for (int i = 0; i < 4; i++) {
/* 348 */         transformed[i] = transformed[i] * dequantCoef[group][0] * scalingList[0] << qbits >> 1;
/*     */       }
/*     */     } else {
/* 351 */       int qbits = 4 - qp / 6;
/* 352 */       int addition = 1 << 3 - qp / 6;
/* 353 */       for (int i = 0; i < 4; i++) {
/* 354 */         transformed[i] = transformed[i] * dequantCoef[group][0] * scalingList[0] + addition >> qbits >> 1;
/*     */       }
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public static void quantizeDC2x2(int[] coeffs, int qp) {
/* 362 */     int level = qp / 6;
/* 363 */     int offset = qp % 6;
/*     */     
/* 365 */     int addition = 682 << qp / 6 + 5;
/* 366 */     int qbits = 16 + level;
/*     */     
/* 368 */     if (qp < 4) {
/* 369 */       for (int i = 0; i < 4; i++) {
/* 370 */         int sign = coeffs[i] >> 31;
/* 371 */         coeffs[i] = (Math.min(((coeffs[i] ^ sign) - sign) * quantCoeff[offset][0] + addition >> qbits, 2063) ^ sign) - sign;
/*     */       } 
/*     */     } else {
/*     */       
/* 375 */       for (int i = 0; i < 4; i++) {
/* 376 */         int sign = coeffs[i] >> 31;
/* 377 */         coeffs[i] = (((coeffs[i] ^ sign) - sign) * quantCoeff[offset][0] + addition >> qbits ^ sign) - sign;
/*     */       } 
/*     */     } 
/*     */   }
/*     */   
/*     */   public static void reorderDC4x4(int[] dc) {
/* 383 */     ArrayUtil.swap(dc, 2, 4);
/* 384 */     ArrayUtil.swap(dc, 3, 5);
/* 385 */     ArrayUtil.swap(dc, 10, 12);
/* 386 */     ArrayUtil.swap(dc, 11, 13);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static void fvdDC4x2(int[] dc) {}
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static void quantizeDC4x2(int[] dc, int qp) {}
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static void invDC4x2(int[] dc) {}
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static void dequantizeDC4x2(int[] dc, int qp) {}
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static void dequantizeAC8x8(int[] coeffs, int qp, int[] scalingList) {
/* 414 */     int group = qp % 6;
/*     */     
/* 416 */     if (qp >= 36) {
/* 417 */       int qbits = qp / 6 - 6;
/* 418 */       if (scalingList == null) {
/* 419 */         for (int i = 0; i < 64; i++)
/* 420 */           coeffs[i] = coeffs[i] * dequantCoef8x8[group][i] << 4 << qbits; 
/*     */       } else {
/* 422 */         for (int i = 0; i < 64; i++)
/* 423 */           coeffs[i] = coeffs[i] * dequantCoef8x8[group][i] * scalingList[invZigzag8x8[i]] << qbits; 
/*     */       } 
/*     */     } else {
/* 426 */       int qbits = 6 - qp / 6;
/* 427 */       int addition = 1 << 5 - qp / 6;
/* 428 */       if (scalingList == null) {
/* 429 */         for (int i = 0; i < 64; i++)
/* 430 */           coeffs[i] = coeffs[i] * (dequantCoef8x8[group][i] << 4) + addition >> qbits; 
/*     */       } else {
/* 432 */         for (int i = 0; i < 64; i++)
/* 433 */           coeffs[i] = coeffs[i] * dequantCoef8x8[group][i] * scalingList[invZigzag8x8[i]] + addition >> qbits; 
/*     */       } 
/*     */     } 
/*     */   }
/*     */   
/*     */   public static void idct8x8(int[] ac) {
/* 439 */     int off = 0;
/*     */ 
/*     */     
/* 442 */     for (int row = 0; row < 8; row++) {
/* 443 */       int e0 = ac[off] + ac[off + 4];
/* 444 */       int e1 = -ac[off + 3] + ac[off + 5] - ac[off + 7] - (ac[off + 7] >> 1);
/* 445 */       int e2 = ac[off] - ac[off + 4];
/* 446 */       int e3 = ac[off + 1] + ac[off + 7] - ac[off + 3] - (ac[off + 3] >> 1);
/* 447 */       int e4 = (ac[off + 2] >> 1) - ac[off + 6];
/* 448 */       int e5 = -ac[off + 1] + ac[off + 7] + ac[off + 5] + (ac[off + 5] >> 1);
/* 449 */       int e6 = ac[off + 2] + (ac[off + 6] >> 1);
/* 450 */       int e7 = ac[off + 3] + ac[off + 5] + ac[off + 1] + (ac[off + 1] >> 1);
/*     */       
/* 452 */       int f0 = e0 + e6;
/* 453 */       int f1 = e1 + (e7 >> 2);
/* 454 */       int f2 = e2 + e4;
/* 455 */       int f3 = e3 + (e5 >> 2);
/* 456 */       int f4 = e2 - e4;
/* 457 */       int f5 = (e3 >> 2) - e5;
/* 458 */       int f6 = e0 - e6;
/* 459 */       int f7 = e7 - (e1 >> 2);
/*     */       
/* 461 */       ac[off] = f0 + f7;
/* 462 */       ac[off + 1] = f2 + f5;
/* 463 */       ac[off + 2] = f4 + f3;
/* 464 */       ac[off + 3] = f6 + f1;
/* 465 */       ac[off + 4] = f6 - f1;
/* 466 */       ac[off + 5] = f4 - f3;
/* 467 */       ac[off + 6] = f2 - f5;
/* 468 */       ac[off + 7] = f0 - f7;
/*     */       
/* 470 */       off += 8;
/*     */     } 
/*     */ 
/*     */     
/* 474 */     for (int col = 0; col < 8; col++) {
/* 475 */       int e0 = ac[col] + ac[col + 32];
/* 476 */       int e1 = -ac[col + 24] + ac[col + 40] - ac[col + 56] - (ac[col + 56] >> 1);
/* 477 */       int e2 = ac[col] - ac[col + 32];
/* 478 */       int e3 = ac[col + 8] + ac[col + 56] - ac[col + 24] - (ac[col + 24] >> 1);
/* 479 */       int e4 = (ac[col + 16] >> 1) - ac[col + 48];
/* 480 */       int e5 = -ac[col + 8] + ac[col + 56] + ac[col + 40] + (ac[col + 40] >> 1);
/* 481 */       int e6 = ac[col + 16] + (ac[col + 48] >> 1);
/* 482 */       int e7 = ac[col + 24] + ac[col + 40] + ac[col + 8] + (ac[col + 8] >> 1);
/*     */       
/* 484 */       int f0 = e0 + e6;
/* 485 */       int f1 = e1 + (e7 >> 2);
/* 486 */       int f2 = e2 + e4;
/* 487 */       int f3 = e3 + (e5 >> 2);
/* 488 */       int f4 = e2 - e4;
/* 489 */       int f5 = (e3 >> 2) - e5;
/* 490 */       int f6 = e0 - e6;
/* 491 */       int f7 = e7 - (e1 >> 2);
/*     */       
/* 493 */       ac[col] = f0 + f7;
/* 494 */       ac[col + 8] = f2 + f5;
/* 495 */       ac[col + 16] = f4 + f3;
/* 496 */       ac[col + 24] = f6 + f1;
/* 497 */       ac[col + 32] = f6 - f1;
/* 498 */       ac[col + 40] = f4 - f3;
/* 499 */       ac[col + 48] = f2 - f5;
/* 500 */       ac[col + 56] = f0 - f7;
/*     */     } 
/*     */ 
/*     */     
/* 504 */     for (int i = 0; i < 64; i++)
/* 505 */       ac[i] = ac[i] + 32 >> 6; 
/*     */   }
/*     */ }


/* Location:              C:\Users\rapha\Downloads\aurora.jar!\META-INF\jars\jcodec-0.2.5.jar!\org\jcodec\codecs\h264\decode\CoeffTransformer.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */