/*     */ package org.jcodec.codecs.h264.decode;
/*     */ 
/*     */ import org.jcodec.codecs.h264.H264Const;
/*     */ import org.jcodec.codecs.h264.io.model.Frame;
/*     */ import org.jcodec.codecs.h264.io.model.PictureParameterSet;
/*     */ import org.jcodec.codecs.h264.io.model.PredictionWeightTable;
/*     */ import org.jcodec.codecs.h264.io.model.SliceHeader;
/*     */ import org.jcodec.codecs.h264.io.model.SliceType;
/*     */ import org.jcodec.common.tools.MathUtil;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class PredictionMerger
/*     */ {
/*     */   public static void mergePrediction(SliceHeader sh, int refIdxL0, int refIdxL1, H264Const.PartPred predType, int comp, byte[] pred0, byte[] pred1, int off, int stride, int blkW, int blkH, byte[] out, Frame[][] refs, int thisPoc) {
/*  30 */     PictureParameterSet pps = sh.pps;
/*  31 */     if (sh.sliceType == SliceType.P) {
/*  32 */       weightPrediction(sh, refIdxL0, comp, pred0, off, stride, blkW, blkH, out);
/*     */     }
/*  34 */     else if (!pps.weightedPredFlag || sh.pps.weightedBipredIdc == 0 || (sh.pps.weightedBipredIdc == 2 && predType != H264Const.PartPred.Bi)) {
/*     */       
/*  36 */       mergeAvg(pred0, pred1, stride, predType, off, blkW, blkH, out);
/*  37 */     } else if (sh.pps.weightedBipredIdc == 1) {
/*  38 */       PredictionWeightTable w = sh.predWeightTable;
/*  39 */       int w0 = (refIdxL0 == -1) ? 0 : ((comp == 0) ? w.lumaWeight[0][refIdxL0] : w.chromaWeight[0][comp - 1][refIdxL0]);
/*     */       
/*  41 */       int w1 = (refIdxL1 == -1) ? 0 : ((comp == 0) ? w.lumaWeight[1][refIdxL1] : w.chromaWeight[1][comp - 1][refIdxL1]);
/*     */       
/*  43 */       int o0 = (refIdxL0 == -1) ? 0 : ((comp == 0) ? w.lumaOffset[0][refIdxL0] : w.chromaOffset[0][comp - 1][refIdxL0]);
/*     */       
/*  45 */       int o1 = (refIdxL1 == -1) ? 0 : ((comp == 0) ? w.lumaOffset[1][refIdxL1] : w.chromaOffset[1][comp - 1][refIdxL1]);
/*     */       
/*  47 */       mergeWeight(pred0, pred1, stride, predType, off, blkW, blkH, (comp == 0) ? w.lumaLog2WeightDenom : w.chromaLog2WeightDenom, w0, w1, o0, o1, out);
/*     */     } else {
/*     */       
/*  50 */       int tb = MathUtil.clip(thisPoc - refs[0][refIdxL0].getPOC(), -128, 127);
/*  51 */       int td = MathUtil.clip(refs[1][refIdxL1].getPOC() - refs[0][refIdxL0].getPOC(), -128, 127);
/*  52 */       int w0 = 32, w1 = 32;
/*  53 */       if (td != 0 && refs[0][refIdxL0].isShortTerm() && refs[1][refIdxL1].isShortTerm()) {
/*  54 */         int tx = (16384 + Math.abs(td / 2)) / td;
/*  55 */         int dsf = MathUtil.clip(tb * tx + 32 >> 6, -1024, 1023) >> 2;
/*     */         
/*  57 */         if (dsf >= -64 && dsf <= 128) {
/*  58 */           w1 = dsf;
/*  59 */           w0 = 64 - dsf;
/*     */         } 
/*     */       } 
/*     */       
/*  63 */       mergeWeight(pred0, pred1, stride, predType, off, blkW, blkH, 5, w0, w1, 0, 0, out);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public static void weightPrediction(SliceHeader sh, int refIdxL0, int comp, byte[] pred0, int off, int stride, int blkW, int blkH, byte[] out) {
/*  70 */     PictureParameterSet pps = sh.pps;
/*  71 */     if (pps.weightedPredFlag && sh.predWeightTable != null) {
/*  72 */       PredictionWeightTable w = sh.predWeightTable;
/*  73 */       weight(pred0, stride, off, blkW, blkH, (comp == 0) ? w.lumaLog2WeightDenom : w.chromaLog2WeightDenom, (comp == 0) ? w.lumaWeight[0][refIdxL0] : w.chromaWeight[0][comp - 1][refIdxL0], (comp == 0) ? w.lumaOffset[0][refIdxL0] : w.chromaOffset[0][comp - 1][refIdxL0], out);
/*     */     
/*     */     }
/*     */     else {
/*     */       
/*  78 */       copyPrediction(pred0, stride, off, blkW, blkH, out);
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   private static void mergeAvg(byte[] blk0, byte[] blk1, int stride, H264Const.PartPred p0, int off, int blkW, int blkH, byte[] out) {
/*  84 */     if (p0 == H264Const.PartPred.Bi) {
/*  85 */       _mergePrediction(blk0, blk1, stride, p0, off, blkW, blkH, out);
/*  86 */     } else if (p0 == H264Const.PartPred.L0) {
/*  87 */       copyPrediction(blk0, stride, off, blkW, blkH, out);
/*  88 */     } else if (p0 == H264Const.PartPred.L1) {
/*  89 */       copyPrediction(blk1, stride, off, blkW, blkH, out);
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   private static void mergeWeight(byte[] blk0, byte[] blk1, int stride, H264Const.PartPred partPred, int off, int blkW, int blkH, int logWD, int w0, int w1, int o0, int o1, byte[] out) {
/*  95 */     if (partPred == H264Const.PartPred.L0) {
/*  96 */       weight(blk0, stride, off, blkW, blkH, logWD, w0, o0, out);
/*  97 */     } else if (partPred == H264Const.PartPred.L1) {
/*  98 */       weight(blk1, stride, off, blkW, blkH, logWD, w1, o1, out);
/*  99 */     } else if (partPred == H264Const.PartPred.Bi) {
/* 100 */       _weightPrediction(blk0, blk1, stride, off, blkW, blkH, logWD, w0, w1, o0, o1, out);
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   private static void copyPrediction(byte[] _in, int stride, int off, int blkW, int blkH, byte[] out) {
/* 106 */     for (int i = 0; i < blkH; i++, off += stride - blkW) {
/* 107 */       for (int j = 0; j < blkW; j++, off++) {
/* 108 */         out[off] = _in[off];
/*     */       }
/*     */     } 
/*     */   }
/*     */   
/*     */   private static void _mergePrediction(byte[] blk0, byte[] blk1, int stride, H264Const.PartPred p0, int off, int blkW, int blkH, byte[] out) {
/* 114 */     for (int i = 0; i < blkH; i++, off += stride - blkW) {
/* 115 */       for (int j = 0; j < blkW; j++, off++) {
/* 116 */         out[off] = (byte)(blk0[off] + blk1[off] + 1 >> 1);
/*     */       }
/*     */     } 
/*     */   }
/*     */   
/*     */   private static void _weightPrediction(byte[] blk0, byte[] blk1, int stride, int off, int blkW, int blkH, int logWD, int w0, int w1, int o0, int o1, byte[] out) {
/* 122 */     int round = (1 << logWD) + (w0 + w1 << 7);
/* 123 */     int sum = (o0 + o1 + 1 >> 1) - 128;
/* 124 */     int logWDCP1 = logWD + 1;
/* 125 */     for (int i = 0; i < blkH; i++, off += stride - blkW) {
/* 126 */       for (int j = 0; j < blkW; j++, off++)
/* 127 */         out[off] = (byte)MathUtil.clip((blk0[off] * w0 + blk1[off] * w1 + round >> logWDCP1) + sum, -128, 127); 
/*     */     } 
/*     */   }
/*     */   
/*     */   private static void weight(byte[] blk0, int stride, int off, int blkW, int blkH, int logWD, int w, int o, byte[] out) {
/* 132 */     int round = 1 << logWD - 1;
/*     */     
/* 134 */     if (logWD >= 1) {
/*     */ 
/*     */ 
/*     */       
/* 138 */       o -= 128;
/* 139 */       round += w << 7;
/* 140 */       for (int i = 0; i < blkH; i++, off += stride - blkW) {
/* 141 */         for (int j = 0; j < blkW; j++, off++)
/* 142 */           out[off] = (byte)MathUtil.clip((blk0[off] * w + round >> logWD) + o, -128, 127); 
/*     */       } 
/*     */     } else {
/* 145 */       o += (w << 7) - 128;
/* 146 */       for (int i = 0; i < blkH; i++, off += stride - blkW) {
/* 147 */         for (int j = 0; j < blkW; j++, off++)
/* 148 */           out[off] = (byte)MathUtil.clip(blk0[off] * w + o, -128, 127); 
/*     */       } 
/*     */     } 
/*     */   }
/*     */ }


/* Location:              C:\Users\rapha\Downloads\aurora.jar!\META-INF\jars\jcodec-0.2.5.jar!\org\jcodec\codecs\h264\decode\PredictionMerger.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */