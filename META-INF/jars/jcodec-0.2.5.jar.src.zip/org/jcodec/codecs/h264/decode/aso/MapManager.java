/*     */ package org.jcodec.codecs.h264.decode.aso;
/*     */ 
/*     */ import org.jcodec.codecs.h264.io.model.PictureParameterSet;
/*     */ import org.jcodec.codecs.h264.io.model.SeqParameterSet;
/*     */ import org.jcodec.codecs.h264.io.model.SliceHeader;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class MapManager
/*     */ {
/*     */   private SeqParameterSet sps;
/*     */   private PictureParameterSet pps;
/*     */   private MBToSliceGroupMap mbToSliceGroupMap;
/*     */   private int prevSliceGroupChangeCycle;
/*     */   
/*     */   public MapManager(SeqParameterSet sps, PictureParameterSet pps) {
/*  22 */     this.sps = sps;
/*  23 */     this.pps = pps;
/*  24 */     this.mbToSliceGroupMap = buildMap(sps, pps);
/*     */   }
/*     */   
/*     */   private MBToSliceGroupMap buildMap(SeqParameterSet sps, PictureParameterSet pps) {
/*  28 */     int numGroups = pps.numSliceGroupsMinus1 + 1;
/*     */     
/*  30 */     if (numGroups > 1) {
/*     */       
/*  32 */       int map[], picWidthInMbs = sps.picWidthInMbsMinus1 + 1;
/*  33 */       int picHeightInMbs = SeqParameterSet.getPicHeightInMbs(sps);
/*     */       
/*  35 */       if (pps.sliceGroupMapType == 0) {
/*  36 */         int[] runLength = new int[numGroups];
/*  37 */         for (int i = 0; i < numGroups; i++) {
/*  38 */           runLength[i] = pps.runLengthMinus1[i] + 1;
/*     */         }
/*  40 */         map = SliceGroupMapBuilder.buildInterleavedMap(picWidthInMbs, picHeightInMbs, runLength);
/*  41 */       } else if (pps.sliceGroupMapType == 1) {
/*  42 */         map = SliceGroupMapBuilder.buildDispersedMap(picWidthInMbs, picHeightInMbs, numGroups);
/*  43 */       } else if (pps.sliceGroupMapType == 2) {
/*  44 */         map = SliceGroupMapBuilder.buildForegroundMap(picWidthInMbs, picHeightInMbs, numGroups, pps.topLeft, pps.bottomRight);
/*     */       } else {
/*  46 */         if (pps.sliceGroupMapType >= 3 && pps.sliceGroupMapType <= 5)
/*  47 */           return null; 
/*  48 */         if (pps.sliceGroupMapType == 6) {
/*  49 */           map = pps.sliceGroupId;
/*     */         } else {
/*  51 */           throw new RuntimeException("Unsupported slice group map type");
/*     */         } 
/*     */       } 
/*  54 */       return buildMapIndices(map, numGroups);
/*     */     } 
/*     */     
/*  57 */     return null;
/*     */   }
/*     */   
/*     */   private MBToSliceGroupMap buildMapIndices(int[] map, int numGroups) {
/*  61 */     int[] ind = new int[numGroups];
/*  62 */     int[] indices = new int[map.length];
/*     */     
/*  64 */     for (int i = 0; i < map.length; i++) {
/*  65 */       ind[map[i]] = ind[map[i]] + 1; indices[i] = ind[map[i]];
/*     */     } 
/*     */     
/*  68 */     int[][] inverse = new int[numGroups][]; int j;
/*  69 */     for (j = 0; j < numGroups; j++) {
/*  70 */       inverse[j] = new int[ind[j]];
/*     */     }
/*  72 */     ind = new int[numGroups];
/*  73 */     for (j = 0; j < map.length; j++) {
/*  74 */       int sliceGroup = map[j];
/*  75 */       ind[sliceGroup] = ind[sliceGroup] + 1; inverse[sliceGroup][ind[sliceGroup]] = j;
/*     */     } 
/*     */     
/*  78 */     return new MBToSliceGroupMap(map, indices, inverse);
/*     */   }
/*     */   
/*     */   private void updateMap(SliceHeader sh) {
/*  82 */     int mapType = this.pps.sliceGroupMapType;
/*  83 */     int numGroups = this.pps.numSliceGroupsMinus1 + 1;
/*     */     
/*  85 */     if (numGroups > 1 && mapType >= 3 && mapType <= 5 && (sh.sliceGroupChangeCycle != this.prevSliceGroupChangeCycle || this.mbToSliceGroupMap == null)) {
/*     */       int[] map;
/*     */       
/*  88 */       this.prevSliceGroupChangeCycle = sh.sliceGroupChangeCycle;
/*     */       
/*  90 */       int picWidthInMbs = this.sps.picWidthInMbsMinus1 + 1;
/*  91 */       int picHeightInMbs = SeqParameterSet.getPicHeightInMbs(this.sps);
/*  92 */       int picSizeInMapUnits = picWidthInMbs * picHeightInMbs;
/*  93 */       int mapUnitsInSliceGroup0 = sh.sliceGroupChangeCycle * (this.pps.sliceGroupChangeRateMinus1 + 1);
/*  94 */       mapUnitsInSliceGroup0 = (mapUnitsInSliceGroup0 > picSizeInMapUnits) ? picSizeInMapUnits : mapUnitsInSliceGroup0;
/*     */ 
/*     */       
/*  97 */       int sizeOfUpperLeftGroup = this.pps.sliceGroupChangeDirectionFlag ? (picSizeInMapUnits - mapUnitsInSliceGroup0) : mapUnitsInSliceGroup0;
/*     */ 
/*     */ 
/*     */       
/* 101 */       if (mapType == 3) {
/* 102 */         map = SliceGroupMapBuilder.buildBoxOutMap(picWidthInMbs, picHeightInMbs, this.pps.sliceGroupChangeDirectionFlag, mapUnitsInSliceGroup0);
/*     */       }
/* 104 */       else if (mapType == 4) {
/* 105 */         map = SliceGroupMapBuilder.buildRasterScanMap(picWidthInMbs, picHeightInMbs, sizeOfUpperLeftGroup, this.pps.sliceGroupChangeDirectionFlag);
/*     */       } else {
/*     */         
/* 108 */         map = SliceGroupMapBuilder.buildWipeMap(picWidthInMbs, picHeightInMbs, sizeOfUpperLeftGroup, this.pps.sliceGroupChangeDirectionFlag);
/*     */       } 
/*     */ 
/*     */       
/* 112 */       this.mbToSliceGroupMap = buildMapIndices(map, numGroups);
/*     */     } 
/*     */   }
/*     */   
/*     */   public Mapper getMapper(SliceHeader sh) {
/* 117 */     updateMap(sh);
/* 118 */     int firstMBInSlice = sh.firstMbInSlice;
/* 119 */     if (this.pps.numSliceGroupsMinus1 > 0)
/*     */     {
/* 121 */       return new PrebuiltMBlockMapper(this.mbToSliceGroupMap, firstMBInSlice, this.sps.picWidthInMbsMinus1 + 1);
/*     */     }
/* 123 */     return new FlatMBlockMapper(this.sps.picWidthInMbsMinus1 + 1, firstMBInSlice);
/*     */   }
/*     */ }


/* Location:              C:\Users\rapha\Downloads\aurora.jar!\META-INF\jars\jcodec-0.2.5.jar!\org\jcodec\codecs\h264\decode\aso\MapManager.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */