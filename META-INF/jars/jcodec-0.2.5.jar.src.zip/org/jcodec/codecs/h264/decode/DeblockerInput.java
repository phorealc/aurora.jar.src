/*    */ package org.jcodec.codecs.h264.decode;
/*    */ 
/*    */ import org.jcodec.codecs.h264.H264Utils;
/*    */ import org.jcodec.codecs.h264.io.model.Frame;
/*    */ import org.jcodec.codecs.h264.io.model.MBType;
/*    */ import org.jcodec.codecs.h264.io.model.SeqParameterSet;
/*    */ import org.jcodec.codecs.h264.io.model.SliceHeader;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class DeblockerInput
/*    */ {
/*    */   public int[][] nCoeff;
/*    */   public H264Utils.MvList2D mvs;
/*    */   public MBType[] mbTypes;
/*    */   public int[][] mbQps;
/*    */   public boolean[] tr8x8Used;
/*    */   public Frame[][][] refsUsed;
/*    */   public SliceHeader[] shs;
/*    */   
/*    */   public DeblockerInput(SeqParameterSet activeSps) {
/* 30 */     int picWidthInMbs = activeSps.picWidthInMbsMinus1 + 1;
/* 31 */     int picHeightInMbs = SeqParameterSet.getPicHeightInMbs(activeSps);
/*    */     
/* 33 */     this.nCoeff = new int[picHeightInMbs << 2][picWidthInMbs << 2];
/* 34 */     this.mvs = new H264Utils.MvList2D(picWidthInMbs << 2, picHeightInMbs << 2);
/* 35 */     this.mbTypes = new MBType[picHeightInMbs * picWidthInMbs];
/* 36 */     this.tr8x8Used = new boolean[picHeightInMbs * picWidthInMbs];
/* 37 */     this.mbQps = new int[3][picHeightInMbs * picWidthInMbs];
/* 38 */     this.shs = new SliceHeader[picHeightInMbs * picWidthInMbs];
/* 39 */     this.refsUsed = new Frame[picHeightInMbs * picWidthInMbs][][];
/*    */   }
/*    */ }


/* Location:              C:\Users\rapha\Downloads\aurora.jar!\META-INF\jars\jcodec-0.2.5.jar!\org\jcodec\codecs\h264\decode\DeblockerInput.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */