/*     */ package org.jcodec.codecs.h264.decode;
/*     */ 
/*     */ import org.jcodec.codecs.h264.H264Const;
/*     */ import org.jcodec.codecs.h264.decode.aso.MapManager;
/*     */ import org.jcodec.codecs.h264.decode.aso.Mapper;
/*     */ import org.jcodec.codecs.h264.io.model.Frame;
/*     */ import org.jcodec.codecs.h264.io.model.MBType;
/*     */ import org.jcodec.codecs.h264.io.model.SeqParameterSet;
/*     */ import org.jcodec.codecs.h264.io.model.SliceHeader;
/*     */ import org.jcodec.codecs.h264.io.model.SliceType;
/*     */ import org.jcodec.common.IntObjectMap;
/*     */ import org.jcodec.common.logging.Logger;
/*     */ import org.jcodec.common.model.Picture;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class SliceDecoder
/*     */ {
/*     */   private Mapper mapper;
/*     */   private MBlockDecoderIntra16x16 decoderIntra16x16;
/*     */   private MBlockDecoderIntraNxN decoderIntraNxN;
/*     */   private MBlockDecoderInter decoderInter;
/*     */   private MBlockDecoderInter8x8 decoderInter8x8;
/*     */   private MBlockSkipDecoder skipDecoder;
/*     */   private MBlockDecoderBDirect decoderBDirect;
/*     */   private RefListManager refListManager;
/*     */   private MBlockDecoderIPCM decoderIPCM;
/*     */   private SliceReader parser;
/*     */   private SeqParameterSet activeSps;
/*     */   private Frame frameOut;
/*     */   private DecoderState decoderState;
/*     */   private DeblockerInput di;
/*     */   private IntObjectMap<Frame> lRefs;
/*     */   private Frame[] sRefs;
/*     */   
/*     */   public SliceDecoder(SeqParameterSet activeSps, Frame[] sRefs, IntObjectMap<Frame> lRefs, DeblockerInput di, Frame result) {
/*  56 */     this.di = di;
/*  57 */     this.activeSps = activeSps;
/*  58 */     this.frameOut = result;
/*  59 */     this.sRefs = sRefs;
/*  60 */     this.lRefs = lRefs;
/*     */   }
/*     */ 
/*     */   
/*     */   public void decodeFromReader(SliceReader sliceReader) {
/*  65 */     this.parser = sliceReader;
/*     */     
/*  67 */     initContext();
/*     */     
/*  69 */     MBlockDecoderUtils.debugPrint(new Object[] { "============%d============= ", Integer.valueOf(this.frameOut.getPOC()) });
/*     */     
/*  71 */     Frame[][] refList = this.refListManager.getRefList();
/*     */     
/*  73 */     decodeMacroblocks(refList);
/*     */   }
/*     */ 
/*     */   
/*     */   private void initContext() {
/*  78 */     SliceHeader sh = this.parser.getSliceHeader();
/*     */     
/*  80 */     this.decoderState = new DecoderState(sh);
/*  81 */     this.mapper = (new MapManager(sh.sps, sh.pps)).getMapper(sh);
/*     */     
/*  83 */     this.decoderIntra16x16 = new MBlockDecoderIntra16x16(this.mapper, sh, this.di, this.frameOut.getPOC(), this.decoderState);
/*  84 */     this.decoderIntraNxN = new MBlockDecoderIntraNxN(this.mapper, sh, this.di, this.frameOut.getPOC(), this.decoderState);
/*  85 */     this.decoderInter = new MBlockDecoderInter(this.mapper, sh, this.di, this.frameOut.getPOC(), this.decoderState);
/*  86 */     this.decoderBDirect = new MBlockDecoderBDirect(this.mapper, sh, this.di, this.frameOut.getPOC(), this.decoderState);
/*  87 */     this.decoderInter8x8 = new MBlockDecoderInter8x8(this.mapper, this.decoderBDirect, sh, this.di, this.frameOut.getPOC(), this.decoderState);
/*  88 */     this.skipDecoder = new MBlockSkipDecoder(this.mapper, this.decoderBDirect, sh, this.di, this.frameOut.getPOC(), this.decoderState);
/*  89 */     this.decoderIPCM = new MBlockDecoderIPCM(this.mapper, this.decoderState);
/*     */     
/*  91 */     this.refListManager = new RefListManager(sh, this.sRefs, this.lRefs, this.frameOut);
/*     */   }
/*     */   
/*     */   private void decodeMacroblocks(Frame[][] refList) {
/*  95 */     Picture mb = Picture.create(16, 16, this.activeSps.chromaFormatIdc);
/*  96 */     int mbWidth = this.activeSps.picWidthInMbsMinus1 + 1;
/*     */     
/*  98 */     MBlock mBlock = new MBlock(this.activeSps.chromaFormatIdc);
/*  99 */     while (this.parser.readMacroblock(mBlock)) {
/* 100 */       decode(mBlock, (this.parser.getSliceHeader()).sliceType, mb, refList);
/* 101 */       int mbAddr = this.mapper.getAddress(mBlock.mbIdx);
/* 102 */       int mbX = mbAddr % mbWidth;
/* 103 */       int mbY = mbAddr / mbWidth;
/* 104 */       putMacroblock((Picture)this.frameOut, mb, mbX, mbY);
/* 105 */       this.di.shs[mbAddr] = this.parser.getSliceHeader();
/* 106 */       this.di.refsUsed[mbAddr] = refList;
/* 107 */       fillCoeff(mBlock, mbX, mbY);
/* 108 */       mb.fill(0);
/* 109 */       mBlock.clear();
/*     */     } 
/*     */   }
/*     */   
/*     */   private void fillCoeff(MBlock mBlock, int mbX, int mbY) {
/* 114 */     for (int i = 0; i < 16; i++) {
/* 115 */       int blkOffLeft = H264Const.MB_BLK_OFF_LEFT[i];
/* 116 */       int blkOffTop = H264Const.MB_BLK_OFF_TOP[i];
/* 117 */       int blkX = (mbX << 2) + blkOffLeft;
/* 118 */       int blkY = (mbY << 2) + blkOffTop;
/*     */       
/* 120 */       this.di.nCoeff[blkY][blkX] = mBlock.nCoeff[i];
/*     */     } 
/*     */   }
/*     */   
/*     */   public void decode(MBlock mBlock, SliceType sliceType, Picture mb, Frame[][] references) {
/* 125 */     if (mBlock.skipped) {
/* 126 */       this.skipDecoder.decodeSkip(mBlock, references, mb, sliceType);
/* 127 */     } else if (sliceType == SliceType.I) {
/* 128 */       decodeMBlockI(mBlock, mb);
/* 129 */     } else if (sliceType == SliceType.P) {
/* 130 */       decodeMBlockP(mBlock, mb, references);
/*     */     } else {
/* 132 */       decodeMBlockB(mBlock, mb, references);
/*     */     } 
/*     */   }
/*     */   
/*     */   private void decodeMBlockI(MBlock mBlock, Picture mb) {
/* 137 */     decodeMBlockIInt(mBlock, mb);
/*     */   }
/*     */   
/*     */   private void decodeMBlockIInt(MBlock mBlock, Picture mb) {
/* 141 */     if (mBlock.curMbType == MBType.I_NxN) {
/* 142 */       this.decoderIntraNxN.decode(mBlock, mb);
/* 143 */     } else if (mBlock.curMbType == MBType.I_16x16) {
/* 144 */       this.decoderIntra16x16.decode(mBlock, mb);
/*     */     } else {
/* 146 */       Logger.warn("IPCM macroblock found. Not tested, may cause unpredictable behavior.");
/* 147 */       this.decoderIPCM.decode(mBlock, mb);
/*     */     } 
/*     */   }
/*     */   
/*     */   private void decodeMBlockP(MBlock mBlock, Picture mb, Frame[][] references) {
/* 152 */     if (MBType.P_16x16 == mBlock.curMbType) {
/* 153 */       this.decoderInter.decode16x16(mBlock, mb, references, H264Const.PartPred.L0);
/* 154 */     } else if (MBType.P_16x8 == mBlock.curMbType) {
/* 155 */       this.decoderInter.decode16x8(mBlock, mb, references, H264Const.PartPred.L0, H264Const.PartPred.L0);
/* 156 */     } else if (MBType.P_8x16 == mBlock.curMbType) {
/* 157 */       this.decoderInter.decode8x16(mBlock, mb, references, H264Const.PartPred.L0, H264Const.PartPred.L0);
/* 158 */     } else if (MBType.P_8x8 == mBlock.curMbType) {
/* 159 */       this.decoderInter8x8.decode(mBlock, references, mb, SliceType.P, false);
/* 160 */     } else if (MBType.P_8x8ref0 == mBlock.curMbType) {
/* 161 */       this.decoderInter8x8.decode(mBlock, references, mb, SliceType.P, true);
/*     */     } else {
/* 163 */       decodeMBlockIInt(mBlock, mb);
/*     */     } 
/*     */   }
/*     */   
/*     */   private void decodeMBlockB(MBlock mBlock, Picture mb, Frame[][] references) {
/* 168 */     if (mBlock.curMbType.isIntra()) {
/* 169 */       decodeMBlockIInt(mBlock, mb);
/*     */     }
/* 171 */     else if (mBlock.curMbType == MBType.B_Direct_16x16) {
/* 172 */       this.decoderBDirect.decode(mBlock, mb, references);
/* 173 */     } else if (mBlock.mbType <= 3) {
/* 174 */       this.decoderInter.decode16x16(mBlock, mb, references, H264Const.bPredModes[mBlock.mbType][0]);
/* 175 */     } else if (mBlock.mbType == 22) {
/* 176 */       this.decoderInter8x8.decode(mBlock, references, mb, SliceType.B, false);
/* 177 */     } else if ((mBlock.mbType & 0x1) == 0) {
/* 178 */       this.decoderInter.decode16x8(mBlock, mb, references, H264Const.bPredModes[mBlock.mbType][0], H264Const.bPredModes[mBlock.mbType][1]);
/*     */     } else {
/*     */       
/* 181 */       this.decoderInter.decode8x16(mBlock, mb, references, H264Const.bPredModes[mBlock.mbType][0], H264Const.bPredModes[mBlock.mbType][1]);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private static void putMacroblock(Picture tgt, Picture decoded, int mbX, int mbY) {
/* 188 */     byte[] luma = tgt.getPlaneData(0);
/* 189 */     int stride = tgt.getPlaneWidth(0);
/*     */     
/* 191 */     byte[] cb = tgt.getPlaneData(1);
/* 192 */     byte[] cr = tgt.getPlaneData(2);
/* 193 */     int strideChroma = tgt.getPlaneWidth(1);
/*     */     
/* 195 */     int dOff = 0;
/* 196 */     int mbx16 = mbX * 16;
/* 197 */     int mby16 = mbY * 16;
/* 198 */     byte[] decodedY = decoded.getPlaneData(0);
/* 199 */     for (int i = 0; i < 16; i++) {
/* 200 */       System.arraycopy(decodedY, dOff, luma, (mby16 + i) * stride + mbx16, 16);
/* 201 */       dOff += 16;
/*     */     } 
/*     */     
/* 204 */     int mbx8 = mbX * 8;
/* 205 */     int mby8 = mbY * 8;
/* 206 */     byte[] decodedCb = decoded.getPlaneData(1);
/* 207 */     byte[] decodedCr = decoded.getPlaneData(2);
/* 208 */     for (int j = 0; j < 8; j++) {
/* 209 */       int decodePos = j << 3;
/* 210 */       int chromaPos = (mby8 + j) * strideChroma + mbx8;
/* 211 */       System.arraycopy(decodedCb, decodePos, cb, chromaPos, 8);
/* 212 */       System.arraycopy(decodedCr, decodePos, cr, chromaPos, 8);
/*     */     } 
/*     */   }
/*     */ }


/* Location:              C:\Users\rapha\Downloads\aurora.jar!\META-INF\jars\jcodec-0.2.5.jar!\org\jcodec\codecs\h264\decode\SliceDecoder.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */