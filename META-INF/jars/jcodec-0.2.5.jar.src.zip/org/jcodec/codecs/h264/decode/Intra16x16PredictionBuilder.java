/*     */ package org.jcodec.codecs.h264.decode;
/*     */ 
/*     */ import org.jcodec.codecs.h264.H264Const;
/*     */ import org.jcodec.common.tools.MathUtil;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class Intra16x16PredictionBuilder
/*     */ {
/*     */   public static void predictWithMode(int predMode, int[][] residual, boolean leftAvailable, boolean topAvailable, byte[] leftRow, byte[] topLine, byte[] topLeft, int x, byte[] pixOut) {
/*  20 */     switch (predMode) {
/*     */       case 0:
/*  22 */         predictVertical(residual, topAvailable, topLine, x, pixOut);
/*     */         break;
/*     */       case 1:
/*  25 */         predictHorizontal(residual, leftAvailable, leftRow, x, pixOut);
/*     */         break;
/*     */       case 2:
/*  28 */         predictDC(residual, leftAvailable, topAvailable, leftRow, topLine, x, pixOut);
/*     */         break;
/*     */       case 3:
/*  31 */         predictPlane(residual, leftAvailable, topAvailable, leftRow, topLine, topLeft, x, pixOut);
/*     */         break;
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public static void predictVertical(int[][] residual, boolean topAvailable, byte[] topLine, int x, byte[] pixOut) {
/*  38 */     int off = 0;
/*  39 */     for (int j = 0; j < 16; j++) {
/*  40 */       for (int i = 0; i < 16; i++, off++)
/*  41 */         pixOut[off] = (byte)MathUtil.clip(residual[H264Const.LUMA_4x4_BLOCK_LUT[off]][H264Const.LUMA_4x4_POS_LUT[off]] + topLine[x + i], -128, 127); 
/*     */     } 
/*     */   }
/*     */   
/*     */   public static void predictHorizontal(int[][] residual, boolean leftAvailable, byte[] leftRow, int x, byte[] pixOut) {
/*  46 */     int off = 0;
/*  47 */     for (int j = 0; j < 16; j++) {
/*  48 */       for (int i = 0; i < 16; i++, off++) {
/*  49 */         pixOut[off] = (byte)MathUtil.clip(residual[H264Const.LUMA_4x4_BLOCK_LUT[off]][H264Const.LUMA_4x4_POS_LUT[off]] + leftRow[j], -128, 127);
/*     */       }
/*     */     } 
/*     */   }
/*     */   
/*     */   public static void predictDC(int[][] residual, boolean leftAvailable, boolean topAvailable, byte[] leftRow, byte[] topLine, int x, byte[] pixOut) {
/*     */     int s0;
/*  56 */     if (leftAvailable && topAvailable) {
/*  57 */       s0 = 0; int j;
/*  58 */       for (j = 0; j < 16; j++)
/*  59 */         s0 += leftRow[j]; 
/*  60 */       for (j = 0; j < 16; j++) {
/*  61 */         s0 += topLine[x + j];
/*     */       }
/*  63 */       s0 = s0 + 16 >> 5;
/*  64 */     } else if (leftAvailable) {
/*  65 */       s0 = 0;
/*  66 */       for (int j = 0; j < 16; j++)
/*  67 */         s0 += leftRow[j]; 
/*  68 */       s0 = s0 + 8 >> 4;
/*  69 */     } else if (topAvailable) {
/*  70 */       s0 = 0;
/*  71 */       for (int j = 0; j < 16; j++)
/*  72 */         s0 += topLine[x + j]; 
/*  73 */       s0 = s0 + 8 >> 4;
/*     */     } else {
/*  75 */       s0 = 0;
/*     */     } 
/*     */     
/*  78 */     for (int i = 0; i < 256; i++) {
/*  79 */       pixOut[i] = (byte)MathUtil.clip(residual[H264Const.LUMA_4x4_BLOCK_LUT[i]][H264Const.LUMA_4x4_POS_LUT[i]] + s0, -128, 127);
/*     */     }
/*     */   }
/*     */   
/*     */   public static void predictPlane(int[][] residual, boolean leftAvailable, boolean topAvailable, byte[] leftRow, byte[] topLine, byte[] topLeft, int x, byte[] pixOut) {
/*  84 */     int H = 0;
/*     */     
/*  86 */     for (int i = 0; i < 7; i++) {
/*  87 */       H += (i + 1) * (topLine[x + 8 + i] - topLine[x + 6 - i]);
/*     */     }
/*  89 */     H += 8 * (topLine[x + 15] - topLeft[0]);
/*     */     
/*  91 */     int V = 0;
/*  92 */     for (int j = 0; j < 7; j++) {
/*  93 */       V += (j + 1) * (leftRow[8 + j] - leftRow[6 - j]);
/*     */     }
/*  95 */     V += 8 * (leftRow[15] - topLeft[0]);
/*     */     
/*  97 */     int c = 5 * V + 32 >> 6;
/*  98 */     int b = 5 * H + 32 >> 6;
/*  99 */     int a = 16 * (leftRow[15] + topLine[x + 15]);
/*     */     
/* 101 */     int off = 0;
/* 102 */     for (int k = 0; k < 16; k++) {
/* 103 */       for (int m = 0; m < 16; m++, off++) {
/* 104 */         int val = MathUtil.clip(a + b * (m - 7) + c * (k - 7) + 16 >> 5, -128, 127);
/* 105 */         pixOut[off] = (byte)MathUtil.clip(residual[H264Const.LUMA_4x4_BLOCK_LUT[off]][H264Const.LUMA_4x4_POS_LUT[off]] + val, -128, 127);
/*     */       } 
/*     */     } 
/*     */   }
/*     */ }


/* Location:              C:\Users\rapha\Downloads\aurora.jar!\META-INF\jars\jcodec-0.2.5.jar!\org\jcodec\codecs\h264\decode\Intra16x16PredictionBuilder.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */