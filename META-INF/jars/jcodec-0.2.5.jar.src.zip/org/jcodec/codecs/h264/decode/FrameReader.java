/*     */ package org.jcodec.codecs.h264.decode;
/*     */ 
/*     */ import java.nio.ByteBuffer;
/*     */ import java.util.ArrayList;
/*     */ import java.util.List;
/*     */ import org.jcodec.codecs.common.biari.MDecoder;
/*     */ import org.jcodec.codecs.h264.H264Utils;
/*     */ import org.jcodec.codecs.h264.decode.aso.MapManager;
/*     */ import org.jcodec.codecs.h264.decode.aso.Mapper;
/*     */ import org.jcodec.codecs.h264.io.CABAC;
/*     */ import org.jcodec.codecs.h264.io.CAVLC;
/*     */ import org.jcodec.codecs.h264.io.model.NALUnit;
/*     */ import org.jcodec.codecs.h264.io.model.NALUnitType;
/*     */ import org.jcodec.codecs.h264.io.model.PictureParameterSet;
/*     */ import org.jcodec.codecs.h264.io.model.SeqParameterSet;
/*     */ import org.jcodec.codecs.h264.io.model.SliceHeader;
/*     */ import org.jcodec.common.IntObjectMap;
/*     */ import org.jcodec.common.io.BitReader;
/*     */ import org.jcodec.common.io.NIOUtils;
/*     */ import org.jcodec.common.logging.Logger;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class FrameReader
/*     */ {
/*  42 */   private IntObjectMap<SeqParameterSet> sps = new IntObjectMap();
/*  43 */   private IntObjectMap<PictureParameterSet> pps = new IntObjectMap();
/*     */ 
/*     */   
/*     */   public List<SliceReader> readFrame(List<ByteBuffer> nalUnits) {
/*  47 */     List<SliceReader> result = new ArrayList<SliceReader>();
/*     */     
/*  49 */     for (ByteBuffer nalData : nalUnits) {
/*  50 */       NALUnit nalUnit = NALUnit.read(nalData);
/*     */       
/*  52 */       H264Utils.unescapeNAL(nalData);
/*  53 */       if (NALUnitType.SPS == nalUnit.type) {
/*  54 */         SeqParameterSet _sps = SeqParameterSet.read(nalData);
/*  55 */         this.sps.put(_sps.seqParameterSetId, _sps); continue;
/*  56 */       }  if (NALUnitType.PPS == nalUnit.type) {
/*  57 */         PictureParameterSet _pps = PictureParameterSet.read(nalData);
/*  58 */         this.pps.put(_pps.picParameterSetId, _pps); continue;
/*  59 */       }  if (NALUnitType.IDR_SLICE == nalUnit.type || NALUnitType.NON_IDR_SLICE == nalUnit.type) {
/*  60 */         if (this.sps.size() == 0 || this.pps.size() == 0) {
/*  61 */           Logger.warn("Skipping frame as no SPS/PPS have been seen so far...");
/*  62 */           return null;
/*     */         } 
/*  64 */         result.add(createSliceReader(nalData, nalUnit));
/*     */       } 
/*     */     } 
/*     */     
/*  68 */     return result;
/*     */   }
/*     */   
/*     */   private SliceReader createSliceReader(ByteBuffer segment, NALUnit nalUnit) {
/*  72 */     BitReader _in = BitReader.createBitReader(segment);
/*  73 */     SliceHeader sh = SliceHeaderReader.readPart1(_in);
/*  74 */     sh.pps = (PictureParameterSet)this.pps.get(sh.picParameterSetId);
/*  75 */     sh.sps = (SeqParameterSet)this.sps.get(sh.pps.seqParameterSetId);
/*  76 */     SliceHeaderReader.readPart2(sh, nalUnit, sh.sps, sh.pps, _in);
/*     */     
/*  78 */     Mapper mapper = (new MapManager(sh.sps, sh.pps)).getMapper(sh);
/*     */     
/*  80 */     CAVLC[] cavlc = { new CAVLC(sh.sps, sh.pps, 2, 2), new CAVLC(sh.sps, sh.pps, 1, 1), new CAVLC(sh.sps, sh.pps, 1, 1) };
/*     */ 
/*     */     
/*  83 */     int mbWidth = sh.sps.picWidthInMbsMinus1 + 1;
/*  84 */     CABAC cabac = new CABAC(mbWidth);
/*     */     
/*  86 */     MDecoder mDecoder = null;
/*  87 */     if (sh.pps.entropyCodingModeFlag) {
/*  88 */       _in.terminate();
/*  89 */       int[][] cm = new int[2][1024];
/*  90 */       int qp = sh.pps.picInitQpMinus26 + 26 + sh.sliceQpDelta;
/*  91 */       cabac.initModels(cm, sh.sliceType, sh.cabacInitIdc, qp);
/*  92 */       mDecoder = new MDecoder(segment, cm);
/*     */     } 
/*     */     
/*  95 */     return new SliceReader(sh.pps, cabac, cavlc, mDecoder, _in, mapper, sh, nalUnit);
/*     */   }
/*     */   
/*     */   public void addSpsList(List<ByteBuffer> spsList) {
/*  99 */     for (ByteBuffer byteBuffer : spsList) {
/* 100 */       addSps(byteBuffer);
/*     */     }
/*     */   }
/*     */   
/*     */   public void addSps(ByteBuffer byteBuffer) {
/* 105 */     ByteBuffer clone = NIOUtils.clone(byteBuffer);
/* 106 */     H264Utils.unescapeNAL(clone);
/* 107 */     SeqParameterSet s = SeqParameterSet.read(clone);
/* 108 */     this.sps.put(s.seqParameterSetId, s);
/*     */   }
/*     */   
/*     */   public void addPpsList(List<ByteBuffer> ppsList) {
/* 112 */     for (ByteBuffer byteBuffer : ppsList) {
/* 113 */       addPps(byteBuffer);
/*     */     }
/*     */   }
/*     */   
/*     */   public void addPps(ByteBuffer byteBuffer) {
/* 118 */     ByteBuffer clone = NIOUtils.clone(byteBuffer);
/* 119 */     H264Utils.unescapeNAL(clone);
/* 120 */     PictureParameterSet p = PictureParameterSet.read(clone);
/* 121 */     this.pps.put(p.picParameterSetId, p);
/*     */   }
/*     */ }


/* Location:              C:\Users\rapha\Downloads\aurora.jar!\META-INF\jars\jcodec-0.2.5.jar!\org\jcodec\codecs\h264\decode\FrameReader.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */