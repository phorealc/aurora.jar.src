/*    */ package org.jcodec.codecs.h264.decode.aso;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class FlatMBlockMapper
/*    */   implements Mapper
/*    */ {
/*    */   private int frameWidthInMbs;
/*    */   private int firstMBAddr;
/*    */   
/*    */   public FlatMBlockMapper(int frameWidthInMbs, int firstMBAddr) {
/* 17 */     this.frameWidthInMbs = frameWidthInMbs;
/* 18 */     this.firstMBAddr = firstMBAddr;
/*    */   }
/*    */   
/*    */   public boolean leftAvailable(int index) {
/* 22 */     int mbAddr = index + this.firstMBAddr;
/* 23 */     boolean atTheBorder = (mbAddr % this.frameWidthInMbs == 0);
/* 24 */     return (!atTheBorder && mbAddr > this.firstMBAddr);
/*    */   }
/*    */   
/*    */   public boolean topAvailable(int index) {
/* 28 */     int mbAddr = index + this.firstMBAddr;
/* 29 */     return (mbAddr - this.frameWidthInMbs >= this.firstMBAddr);
/*    */   }
/*    */   
/*    */   public int getAddress(int index) {
/* 33 */     return this.firstMBAddr + index;
/*    */   }
/*    */   
/*    */   public int getMbX(int index) {
/* 37 */     return getAddress(index) % this.frameWidthInMbs;
/*    */   }
/*    */   
/*    */   public int getMbY(int index) {
/* 41 */     return getAddress(index) / this.frameWidthInMbs;
/*    */   }
/*    */   
/*    */   public boolean topRightAvailable(int index) {
/* 45 */     int mbAddr = index + this.firstMBAddr;
/* 46 */     boolean atTheBorder = ((mbAddr + 1) % this.frameWidthInMbs == 0);
/* 47 */     return (!atTheBorder && mbAddr - this.frameWidthInMbs + 1 >= this.firstMBAddr);
/*    */   }
/*    */   
/*    */   public boolean topLeftAvailable(int index) {
/* 51 */     int mbAddr = index + this.firstMBAddr;
/* 52 */     boolean atTheBorder = (mbAddr % this.frameWidthInMbs == 0);
/* 53 */     return (!atTheBorder && mbAddr - this.frameWidthInMbs - 1 >= this.firstMBAddr);
/*    */   }
/*    */ }


/* Location:              C:\Users\rapha\Downloads\aurora.jar!\META-INF\jars\jcodec-0.2.5.jar!\org\jcodec\codecs\h264\decode\aso\FlatMBlockMapper.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */