/*    */ package org.jcodec.codecs.h264.decode;
/*    */ 
/*    */ import org.jcodec.codecs.h264.H264Utils2;
/*    */ import org.jcodec.common.io.BitReader;
/*    */ import org.jcodec.common.tools.Debug;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class CAVLCReader
/*    */ {
/*    */   public static int readNBit(BitReader bits, int n, String message) {
/* 23 */     int val = bits.readNBit(n);
/*    */     
/* 25 */     Debug.trace(new Object[] { message, Integer.valueOf(val) });
/*    */     
/* 27 */     return val;
/*    */   }
/*    */   
/*    */   public static int readUE(BitReader bits) {
/* 31 */     int cnt = 0;
/* 32 */     while (bits.read1Bit() == 0 && cnt < 32) {
/* 33 */       cnt++;
/*    */     }
/* 35 */     int res = 0;
/* 36 */     if (cnt > 0) {
/* 37 */       long val = bits.readNBit(cnt);
/*    */       
/* 39 */       res = (int)(((1 << cnt) - 1) + val);
/*    */     } 
/*    */     
/* 42 */     return res;
/*    */   }
/*    */   
/*    */   public static int readUEtrace(BitReader bits, String message) {
/* 46 */     int res = readUE(bits);
/*    */     
/* 48 */     Debug.trace(new Object[] { message, Integer.valueOf(res) });
/*    */     
/* 50 */     return res;
/*    */   }
/*    */   
/*    */   public static int readSE(BitReader bits, String message) {
/* 54 */     int val = readUE(bits);
/*    */     
/* 56 */     val = H264Utils2.golomb2Signed(val);
/*    */     
/* 58 */     Debug.trace(new Object[] { message, Integer.valueOf(val) });
/*    */     
/* 60 */     return val;
/*    */   }
/*    */ 
/*    */   
/*    */   public static boolean readBool(BitReader bits, String message) {
/* 65 */     boolean res = !(bits.read1Bit() == 0);
/*    */     
/* 67 */     Debug.trace(new Object[] { message, Integer.valueOf(res ? 1 : 0) });
/*    */     
/* 69 */     return res;
/*    */   }
/*    */   
/*    */   public static int readU(BitReader bits, int i, String string) {
/* 73 */     return readNBit(bits, i, string);
/*    */   }
/*    */   
/*    */   public static int readTE(BitReader bits, int max) {
/* 77 */     if (max > 1)
/* 78 */       return readUE(bits); 
/* 79 */     return (bits.read1Bit() ^ 0xFFFFFFFF) & 0x1;
/*    */   }
/*    */   
/*    */   public static int readME(BitReader bits, String string) {
/* 83 */     return readUEtrace(bits, string);
/*    */   }
/*    */   
/*    */   public static int readZeroBitCount(BitReader bits, String message) {
/* 87 */     int count = 0;
/* 88 */     while (bits.read1Bit() == 0 && count < 32) {
/* 89 */       count++;
/*    */     }
/* 91 */     if (Debug.debug) {
/* 92 */       Debug.trace(new Object[] { message, String.valueOf(count) });
/*    */     }
/* 94 */     return count;
/*    */   }
/*    */   
/*    */   public static boolean moreRBSPData(BitReader bits) {
/* 98 */     return (bits.remaining() >= 32 || bits.checkNBit(1) != 1 || bits.checkNBit(24) << 9 != 0);
/*    */   }
/*    */ }


/* Location:              C:\Users\rapha\Downloads\aurora.jar!\META-INF\jars\jcodec-0.2.5.jar!\org\jcodec\codecs\h264\decode\CAVLCReader.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */