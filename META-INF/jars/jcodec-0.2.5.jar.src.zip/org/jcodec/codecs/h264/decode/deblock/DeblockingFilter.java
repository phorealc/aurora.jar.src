/*     */ package org.jcodec.codecs.h264.decode.deblock;
/*     */ 
/*     */ import org.jcodec.codecs.h264.H264Utils;
/*     */ import org.jcodec.codecs.h264.decode.DeblockerInput;
/*     */ import org.jcodec.codecs.h264.io.model.Frame;
/*     */ import org.jcodec.codecs.h264.io.model.SliceHeader;
/*     */ import org.jcodec.common.model.ColorSpace;
/*     */ import org.jcodec.common.model.Picture;
/*     */ import org.jcodec.common.tools.MathUtil;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class DeblockingFilter
/*     */ {
/*  40 */   public static int[] alphaTab = new int[] { 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 4, 4, 5, 6, 7, 8, 9, 10, 12, 13, 15, 17, 20, 22, 25, 28, 32, 36, 40, 45, 50, 56, 63, 71, 80, 90, 101, 113, 127, 144, 162, 182, 203, 226, 255, 255 };
/*     */ 
/*     */   
/*  43 */   public static int[] betaTab = new int[] { 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 2, 2, 2, 3, 3, 3, 3, 4, 4, 4, 6, 6, 7, 7, 8, 8, 9, 9, 10, 10, 11, 11, 12, 12, 13, 13, 14, 14, 15, 15, 16, 16, 17, 17, 18, 18 };
/*     */ 
/*     */   
/*  46 */   public static int[][] tcs = new int[][] { { 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 2, 2, 2, 2, 3, 3, 3, 4, 4, 4, 5, 6, 6, 7, 8, 9, 10, 11, 13 }, { 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 2, 2, 2, 2, 3, 3, 3, 4, 4, 5, 5, 6, 7, 8, 8, 10, 11, 12, 13, 15, 17 }, { 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 2, 2, 2, 2, 3, 3, 3, 4, 4, 4, 5, 6, 6, 7, 8, 9, 10, 11, 13, 14, 16, 18, 20, 23, 25 } };
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private DeblockerInput di;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public DeblockingFilter(int bitDepthLuma, int bitDepthChroma, DeblockerInput di) {
/*  59 */     this.di = di;
/*     */   }
/*     */   
/*     */   public void deblockFrame(Picture result) {
/*  63 */     ColorSpace color = result.getColor();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*  69 */     int[][] bsV = new int[4][4], bsH = new int[4][4];
/*  70 */     for (int i = 0; i < this.di.shs.length; i++) {
/*  71 */       calcBsH(result, i, bsH);
/*  72 */       calcBsV(result, i, bsV);
/*  73 */       for (int c = 0; c < color.nComp; c++) {
/*  74 */         fillVerticalEdge(result, c, i, bsV);
/*  75 */         fillHorizontalEdge(result, c, i, bsH);
/*     */       } 
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 102 */   static int[] inverse = new int[] { 0, 1, 4, 5, 2, 3, 6, 7, 8, 9, 12, 13, 10, 11, 14, 15 };
/*     */ 
/*     */ 
/*     */   
/*     */   private int calcBoundaryStrenth(boolean atMbBoundary, boolean leftIntra, boolean rightIntra, int leftCoeff, int rightCoeff, int mvA0, int mvB0, int mvA1, int mvB1, int mbAddrA, int mbAddrB) {
/* 107 */     if (atMbBoundary && (leftIntra || rightIntra))
/* 108 */       return 4; 
/* 109 */     if (leftIntra || rightIntra) {
/* 110 */       return 3;
/*     */     }
/*     */     
/* 113 */     if (leftCoeff > 0 || rightCoeff > 0) {
/* 114 */       return 2;
/*     */     }
/* 116 */     int nA = ((H264Utils.Mv.mvRef(mvA0) == -1) ? 0 : 1) + ((H264Utils.Mv.mvRef(mvA1) == -1) ? 0 : 1);
/* 117 */     int nB = ((H264Utils.Mv.mvRef(mvB0) == -1) ? 0 : 1) + ((H264Utils.Mv.mvRef(mvB1) == -1) ? 0 : 1);
/*     */     
/* 119 */     if (nA != nB) {
/* 120 */       return 1;
/*     */     }
/* 122 */     Frame frame1 = (H264Utils.Mv.mvRef(mvA0) < 0) ? null : this.di.refsUsed[mbAddrA][0][H264Utils.Mv.mvRef(mvA0)];
/* 123 */     Frame frame2 = (H264Utils.Mv.mvRef(mvA1) < 0) ? null : this.di.refsUsed[mbAddrA][1][H264Utils.Mv.mvRef(mvA1)];
/*     */     
/* 125 */     Frame frame3 = (H264Utils.Mv.mvRef(mvB0) < 0) ? null : this.di.refsUsed[mbAddrB][0][H264Utils.Mv.mvRef(mvB0)];
/* 126 */     Frame frame4 = (H264Utils.Mv.mvRef(mvB1) < 0) ? null : this.di.refsUsed[mbAddrB][1][H264Utils.Mv.mvRef(mvB1)];
/*     */     
/* 128 */     if ((frame1 != frame3 && frame1 != frame4) || (frame2 != frame3 && frame2 != frame4) || (frame3 != frame1 && frame3 != frame2) || (frame4 != frame1 && frame4 != frame2))
/*     */     {
/* 130 */       return 1;
/*     */     }
/* 132 */     if (frame1 == frame2 && frame2 == frame3 && frame3 == frame4) {
/* 133 */       return (frame1 != null && (
/* 134 */         mvThresh(mvA0, mvB0) || mvThresh(mvA1, mvB0) || mvThresh(mvA0, mvB1) || mvThresh(mvA1, mvB1))) ? 1 : 0;
/*     */     }
/* 136 */     if (frame1 == frame3 && frame2 == frame4)
/* 137 */       return ((frame1 != null && mvThresh(mvA0, mvB0)) || (frame2 != null && mvThresh(mvA1, mvB1))) ? 1 : 0; 
/* 138 */     if (frame1 == frame4 && frame2 == frame3) {
/* 139 */       return ((frame1 != null && mvThresh(mvA0, mvB1)) || (frame2 != null && mvThresh(mvA1, mvB0))) ? 1 : 0;
/*     */     }
/*     */ 
/*     */     
/* 143 */     return 0;
/*     */   }
/*     */   
/*     */   private boolean mvThresh(int v0, int v1) {
/* 147 */     return (Math.abs(H264Utils.Mv.mvX(v0) - H264Utils.Mv.mvX(v1)) >= 4 || Math.abs(H264Utils.Mv.mvY(v0) - H264Utils.Mv.mvY(v1)) >= 4);
/*     */   }
/*     */   
/*     */   private static int getIdxBeta(int sliceBetaOffset, int avgQp) {
/* 151 */     return MathUtil.clip(avgQp + sliceBetaOffset, 0, 51);
/*     */   }
/*     */   
/*     */   private static int getIdxAlpha(int sliceAlphaC0Offset, int avgQp) {
/* 155 */     return MathUtil.clip(avgQp + sliceAlphaC0Offset, 0, 51);
/*     */   }
/*     */   
/*     */   private void calcBsH(Picture pic, int mbAddr, int[][] bs) {
/* 159 */     SliceHeader sh = this.di.shs[mbAddr];
/* 160 */     int mbWidth = sh.sps.picWidthInMbsMinus1 + 1;
/*     */     
/* 162 */     int mbX = mbAddr % mbWidth;
/* 163 */     int mbY = mbAddr / mbWidth;
/*     */     
/* 165 */     boolean topAvailable = (mbY > 0 && (sh.disableDeblockingFilterIdc != 2 || this.di.shs[mbAddr - mbWidth] == sh));
/* 166 */     boolean thisIntra = (this.di.mbTypes[mbAddr] != null && this.di.mbTypes[mbAddr].isIntra());
/*     */     
/* 168 */     if (topAvailable) {
/* 169 */       boolean topIntra = (this.di.mbTypes[mbAddr - mbWidth] != null && this.di.mbTypes[mbAddr - mbWidth].isIntra());
/* 170 */       for (int blkX = 0; blkX < 4; blkX++) {
/* 171 */         int thisBlkX = (mbX << 2) + blkX;
/* 172 */         int thisBlkY = mbY << 2;
/*     */         
/* 174 */         bs[0][blkX] = calcBoundaryStrenth(true, topIntra, thisIntra, this.di.nCoeff[thisBlkY][thisBlkX], this.di.nCoeff[thisBlkY - 1][thisBlkX], this.di.mvs
/* 175 */             .getMv(thisBlkX, thisBlkY, 0), this.di.mvs
/* 176 */             .getMv(thisBlkX, thisBlkY - 1, 0), this.di.mvs.getMv(thisBlkX, thisBlkY, 1), this.di.mvs
/* 177 */             .getMv(thisBlkX, thisBlkY - 1, 1), mbAddr, mbAddr - mbWidth);
/*     */       } 
/*     */     } 
/*     */ 
/*     */     
/* 182 */     for (int blkY = 1; blkY < 4; blkY++) {
/* 183 */       for (int blkX = 0; blkX < 4; blkX++) {
/* 184 */         int thisBlkX = (mbX << 2) + blkX;
/* 185 */         int thisBlkY = (mbY << 2) + blkY;
/*     */         
/* 187 */         bs[blkY][blkX] = calcBoundaryStrenth(false, thisIntra, thisIntra, this.di.nCoeff[thisBlkY][thisBlkX], this.di.nCoeff[thisBlkY - 1][thisBlkX], this.di.mvs
/* 188 */             .getMv(thisBlkX, thisBlkY, 0), this.di.mvs
/* 189 */             .getMv(thisBlkX, thisBlkY - 1, 0), this.di.mvs.getMv(thisBlkX, thisBlkY, 1), this.di.mvs
/* 190 */             .getMv(thisBlkX, thisBlkY - 1, 1), mbAddr, mbAddr);
/*     */       } 
/*     */     } 
/*     */   }
/*     */   
/*     */   private void fillHorizontalEdge(Picture pic, int comp, int mbAddr, int[][] bs) {
/* 196 */     SliceHeader sh = this.di.shs[mbAddr];
/* 197 */     int mbWidth = sh.sps.picWidthInMbsMinus1 + 1;
/*     */     
/* 199 */     int alpha = sh.sliceAlphaC0OffsetDiv2 << 1;
/* 200 */     int beta = sh.sliceBetaOffsetDiv2 << 1;
/*     */     
/* 202 */     int mbX = mbAddr % mbWidth;
/* 203 */     int mbY = mbAddr / mbWidth;
/*     */     
/* 205 */     boolean topAvailable = (mbY > 0 && (sh.disableDeblockingFilterIdc != 2 || this.di.shs[mbAddr - mbWidth] == sh));
/* 206 */     int curQp = this.di.mbQps[comp][mbAddr];
/*     */     
/* 208 */     int cW = 2 - (pic.getColor()).compWidth[comp];
/* 209 */     int cH = 2 - (pic.getColor()).compHeight[comp];
/* 210 */     if (topAvailable) {
/* 211 */       int topQp = this.di.mbQps[comp][mbAddr - mbWidth];
/* 212 */       int avgQp = topQp + curQp + 1 >> 1;
/* 213 */       for (int blkX = 0; blkX < 4; blkX++) {
/* 214 */         int thisBlkX = (mbX << 2) + blkX;
/* 215 */         int thisBlkY = mbY << 2;
/*     */         
/* 217 */         filterBlockEdgeHoris(pic, comp, thisBlkX << cW, thisBlkY << cH, getIdxAlpha(alpha, avgQp), 
/* 218 */             getIdxBeta(beta, avgQp), bs[0][blkX], 1 << cW);
/*     */       } 
/*     */     } 
/*     */     
/* 222 */     boolean skip4x4 = ((comp == 0 && this.di.tr8x8Used[mbAddr]) || cH == 1);
/*     */     
/* 224 */     for (int blkY = 1; blkY < 4; blkY++) {
/* 225 */       if (!skip4x4 || (blkY & 0x1) != 1)
/*     */       {
/*     */         
/* 228 */         for (int blkX = 0; blkX < 4; blkX++) {
/* 229 */           int thisBlkX = (mbX << 2) + blkX;
/* 230 */           int thisBlkY = (mbY << 2) + blkY;
/*     */           
/* 232 */           filterBlockEdgeHoris(pic, comp, thisBlkX << cW, thisBlkY << cH, getIdxAlpha(alpha, curQp), 
/* 233 */               getIdxBeta(beta, curQp), bs[blkY][blkX], 1 << cW);
/*     */         } 
/*     */       }
/*     */     } 
/*     */   }
/*     */   
/*     */   private void calcBsV(Picture pic, int mbAddr, int[][] bs) {
/* 240 */     SliceHeader sh = this.di.shs[mbAddr];
/* 241 */     int mbWidth = sh.sps.picWidthInMbsMinus1 + 1;
/*     */     
/* 243 */     int mbX = mbAddr % mbWidth;
/* 244 */     int mbY = mbAddr / mbWidth;
/*     */     
/* 246 */     boolean leftAvailable = (mbX > 0 && (sh.disableDeblockingFilterIdc != 2 || this.di.shs[mbAddr - 1] == sh));
/* 247 */     boolean thisIntra = (this.di.mbTypes[mbAddr] != null && this.di.mbTypes[mbAddr].isIntra());
/*     */     
/* 249 */     if (leftAvailable) {
/* 250 */       boolean leftIntra = (this.di.mbTypes[mbAddr - 1] != null && this.di.mbTypes[mbAddr - 1].isIntra());
/* 251 */       for (int blkY = 0; blkY < 4; blkY++) {
/* 252 */         int thisBlkX = mbX << 2;
/* 253 */         int thisBlkY = (mbY << 2) + blkY;
/* 254 */         bs[blkY][0] = calcBoundaryStrenth(true, leftIntra, thisIntra, this.di.nCoeff[thisBlkY][thisBlkX], this.di.nCoeff[thisBlkY][thisBlkX - 1], this.di.mvs
/* 255 */             .getMv(thisBlkX, thisBlkY, 0), this.di.mvs
/* 256 */             .getMv(thisBlkX - 1, thisBlkY, 0), this.di.mvs.getMv(thisBlkX, thisBlkY, 1), this.di.mvs
/* 257 */             .getMv(thisBlkX - 1, thisBlkY, 1), mbAddr, mbAddr - 1);
/*     */       } 
/*     */     } 
/*     */     
/* 261 */     for (int blkX = 1; blkX < 4; blkX++) {
/* 262 */       for (int blkY = 0; blkY < 4; blkY++) {
/* 263 */         int thisBlkX = (mbX << 2) + blkX;
/* 264 */         int thisBlkY = (mbY << 2) + blkY;
/* 265 */         bs[blkY][blkX] = calcBoundaryStrenth(false, thisIntra, thisIntra, this.di.nCoeff[thisBlkY][thisBlkX], this.di.nCoeff[thisBlkY][thisBlkX - 1], this.di.mvs
/* 266 */             .getMv(thisBlkX, thisBlkY, 0), this.di.mvs
/* 267 */             .getMv(thisBlkX - 1, thisBlkY, 0), this.di.mvs.getMv(thisBlkX, thisBlkY, 1), this.di.mvs
/* 268 */             .getMv(thisBlkX - 1, thisBlkY, 1), mbAddr, mbAddr);
/*     */       } 
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   private void fillVerticalEdge(Picture pic, int comp, int mbAddr, int[][] bs) {
/* 275 */     SliceHeader sh = this.di.shs[mbAddr];
/* 276 */     int mbWidth = sh.sps.picWidthInMbsMinus1 + 1;
/*     */     
/* 278 */     int alpha = sh.sliceAlphaC0OffsetDiv2 << 1;
/* 279 */     int beta = sh.sliceBetaOffsetDiv2 << 1;
/*     */     
/* 281 */     int mbX = mbAddr % mbWidth;
/* 282 */     int mbY = mbAddr / mbWidth;
/*     */     
/* 284 */     boolean leftAvailable = (mbX > 0 && (sh.disableDeblockingFilterIdc != 2 || this.di.shs[mbAddr - 1] == sh));
/* 285 */     int curQp = this.di.mbQps[comp][mbAddr];
/*     */     
/* 287 */     int cW = 2 - (pic.getColor()).compWidth[comp];
/* 288 */     int cH = 2 - (pic.getColor()).compHeight[comp];
/* 289 */     if (leftAvailable) {
/* 290 */       int leftQp = this.di.mbQps[comp][mbAddr - 1];
/* 291 */       int avgQpV = leftQp + curQp + 1 >> 1;
/* 292 */       for (int blkY = 0; blkY < 4; blkY++) {
/* 293 */         int thisBlkX = mbX << 2;
/* 294 */         int thisBlkY = (mbY << 2) + blkY;
/* 295 */         filterBlockEdgeVert(pic, comp, thisBlkX << cW, thisBlkY << cH, getIdxAlpha(alpha, avgQpV), 
/* 296 */             getIdxBeta(beta, avgQpV), bs[blkY][0], 1 << cH);
/*     */       } 
/*     */     } 
/* 299 */     boolean skip4x4 = ((comp == 0 && this.di.tr8x8Used[mbAddr]) || cW == 1);
/*     */     
/* 301 */     for (int blkX = 1; blkX < 4; blkX++) {
/* 302 */       if (!skip4x4 || (blkX & 0x1) != 1)
/*     */       {
/* 304 */         for (int blkY = 0; blkY < 4; blkY++) {
/* 305 */           int thisBlkX = (mbX << 2) + blkX;
/* 306 */           int thisBlkY = (mbY << 2) + blkY;
/* 307 */           filterBlockEdgeVert(pic, comp, thisBlkX << cW, thisBlkY << cH, getIdxAlpha(alpha, curQp), 
/* 308 */               getIdxBeta(beta, curQp), bs[blkY][blkX], 1 << cH);
/*     */         } 
/*     */       }
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   private void filterBlockEdgeHoris(Picture pic, int comp, int x, int y, int indexAlpha, int indexBeta, int bs, int blkW) {
/* 316 */     int stride = pic.getPlaneWidth(comp);
/* 317 */     int offset = y * stride + x;
/*     */     
/* 319 */     for (int pixOff = 0; pixOff < blkW; pixOff++) {
/* 320 */       int p2Idx = offset - 3 * stride + pixOff;
/* 321 */       int p1Idx = offset - 2 * stride + pixOff;
/* 322 */       int p0Idx = offset - stride + pixOff;
/* 323 */       int q0Idx = offset + pixOff;
/* 324 */       int q1Idx = offset + stride + pixOff;
/* 325 */       int q2Idx = offset + 2 * stride + pixOff;
/*     */       
/* 327 */       if (bs == 4) {
/* 328 */         int p3Idx = offset - 4 * stride + pixOff;
/* 329 */         int q3Idx = offset + 3 * stride + pixOff;
/*     */         
/* 331 */         filterBs4(indexAlpha, indexBeta, pic.getPlaneData(comp), pic.getPlaneData(comp), p3Idx, p2Idx, p1Idx, p0Idx, q0Idx, q1Idx, q2Idx, q3Idx, (comp != 0));
/*     */       }
/* 333 */       else if (bs > 0) {
/*     */         
/* 335 */         filterBs(bs, indexAlpha, indexBeta, pic.getPlaneData(comp), pic.getPlaneData(comp), p2Idx, p1Idx, p0Idx, q0Idx, q1Idx, q2Idx, (comp != 0));
/*     */       } 
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void filterBlockEdgeVert(Picture pic, int comp, int x, int y, int indexAlpha, int indexBeta, int bs, int blkH) {
/* 344 */     int stride = pic.getPlaneWidth(comp);
/* 345 */     for (int i = 0; i < blkH; i++) {
/* 346 */       int offsetQ = (y + i) * stride + x;
/* 347 */       int p2Idx = offsetQ - 3;
/* 348 */       int p1Idx = offsetQ - 2;
/* 349 */       int p0Idx = offsetQ - 1;
/* 350 */       int q0Idx = offsetQ;
/* 351 */       int q1Idx = offsetQ + 1;
/* 352 */       int q2Idx = offsetQ + 2;
/*     */       
/* 354 */       if (bs == 4) {
/* 355 */         int p3Idx = offsetQ - 4;
/* 356 */         int q3Idx = offsetQ + 3;
/* 357 */         filterBs4(indexAlpha, indexBeta, pic.getPlaneData(comp), pic.getPlaneData(comp), p3Idx, p2Idx, p1Idx, p0Idx, q0Idx, q1Idx, q2Idx, q3Idx, (comp != 0));
/*     */       }
/* 359 */       else if (bs > 0) {
/* 360 */         filterBs(bs, indexAlpha, indexBeta, pic.getPlaneData(comp), pic.getPlaneData(comp), p2Idx, p1Idx, p0Idx, q0Idx, q1Idx, q2Idx, (comp != 0));
/*     */       } 
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public static void filterBs(int bs, int indexAlpha, int indexBeta, byte[] pelsP, byte[] pelsQ, int p2Idx, int p1Idx, int p0Idx, int q0Idx, int q1Idx, int q2Idx, boolean isChroma) {
/*     */     boolean conditionP, conditionQ;
/* 369 */     int tC, p1 = pelsP[p1Idx];
/* 370 */     int p0 = pelsP[p0Idx];
/* 371 */     int q0 = pelsQ[q0Idx];
/* 372 */     int q1 = pelsQ[q1Idx];
/*     */     
/* 374 */     int alphaThresh = alphaTab[indexAlpha];
/* 375 */     int betaThresh = betaTab[indexBeta];
/*     */     
/* 377 */     boolean filterEnabled = (Math.abs(p0 - q0) < alphaThresh && Math.abs(p1 - p0) < betaThresh && Math.abs(q1 - q0) < betaThresh);
/*     */     
/* 379 */     if (!filterEnabled) {
/*     */       return;
/*     */     }
/*     */ 
/*     */ 
/*     */     
/* 385 */     int tC0 = tcs[bs - 1][indexAlpha];
/*     */ 
/*     */ 
/*     */     
/* 389 */     if (!isChroma) {
/* 390 */       int ap = Math.abs(pelsP[p2Idx] - p0);
/* 391 */       int aq = Math.abs(pelsQ[q2Idx] - q0);
/* 392 */       tC = tC0 + ((ap < betaThresh) ? 1 : 0) + ((aq < betaThresh) ? 1 : 0);
/* 393 */       conditionP = (ap < betaThresh);
/* 394 */       conditionQ = (aq < betaThresh);
/*     */     } else {
/* 396 */       tC = tC0 + 1;
/* 397 */       conditionP = false;
/* 398 */       conditionQ = false;
/*     */     } 
/*     */     
/* 401 */     int sigma = (q0 - p0 << 2) + p1 - q1 + 4 >> 3;
/* 402 */     sigma = (sigma < -tC) ? -tC : ((sigma > tC) ? tC : sigma);
/*     */     
/* 404 */     int p0n = p0 + sigma;
/* 405 */     p0n = (p0n < -128) ? -128 : p0n;
/* 406 */     int q0n = q0 - sigma;
/* 407 */     q0n = (q0n < -128) ? -128 : q0n;
/*     */     
/* 409 */     if (conditionP) {
/* 410 */       int p2 = pelsP[p2Idx];
/*     */       
/* 412 */       int diff = p2 + (p0 + q0 + 1 >> 1) - (p1 << 1) >> 1;
/* 413 */       diff = (diff < -tC0) ? -tC0 : ((diff > tC0) ? tC0 : diff);
/* 414 */       int p1n = p1 + diff;
/* 415 */       pelsP[p1Idx] = (byte)MathUtil.clip(p1n, -128, 127);
/*     */     } 
/*     */     
/* 418 */     if (conditionQ) {
/* 419 */       int q2 = pelsQ[q2Idx];
/* 420 */       int diff = q2 + (p0 + q0 + 1 >> 1) - (q1 << 1) >> 1;
/* 421 */       diff = (diff < -tC0) ? -tC0 : ((diff > tC0) ? tC0 : diff);
/* 422 */       int q1n = q1 + diff;
/* 423 */       pelsQ[q1Idx] = (byte)MathUtil.clip(q1n, -128, 127);
/*     */     } 
/*     */     
/* 426 */     pelsQ[q0Idx] = (byte)MathUtil.clip(q0n, -128, 127);
/* 427 */     pelsP[p0Idx] = (byte)MathUtil.clip(p0n, -128, 127);
/*     */   }
/*     */ 
/*     */   
/*     */   public static void filterBs4(int indexAlpha, int indexBeta, byte[] pelsP, byte[] pelsQ, int p3Idx, int p2Idx, int p1Idx, int p0Idx, int q0Idx, int q1Idx, int q2Idx, int q3Idx, boolean isChroma) {
/*     */     boolean conditionP, conditionQ;
/* 433 */     int p0 = pelsP[p0Idx];
/* 434 */     int q0 = pelsQ[q0Idx];
/* 435 */     int p1 = pelsP[p1Idx];
/* 436 */     int q1 = pelsQ[q1Idx];
/*     */     
/* 438 */     int alphaThresh = alphaTab[indexAlpha];
/* 439 */     int betaThresh = betaTab[indexBeta];
/*     */     
/* 441 */     boolean filterEnabled = (Math.abs(p0 - q0) < alphaThresh && Math.abs(p1 - p0) < betaThresh && Math.abs(q1 - q0) < betaThresh);
/*     */     
/* 443 */     if (!filterEnabled) {
/*     */       return;
/*     */     }
/*     */ 
/*     */     
/* 448 */     if (isChroma) {
/* 449 */       conditionP = false;
/* 450 */       conditionQ = false;
/*     */     } else {
/* 452 */       int ap = Math.abs(pelsP[p2Idx] - p0);
/* 453 */       int aq = Math.abs(pelsQ[q2Idx] - q0);
/*     */       
/* 455 */       conditionP = (ap < betaThresh && Math.abs(p0 - q0) < (alphaThresh >> 2) + 2);
/* 456 */       conditionQ = (aq < betaThresh && Math.abs(p0 - q0) < (alphaThresh >> 2) + 2);
/*     */     } 
/*     */ 
/*     */     
/* 460 */     if (conditionP) {
/* 461 */       int p3 = pelsP[p3Idx];
/* 462 */       int p2 = pelsP[p2Idx];
/*     */       
/* 464 */       int p0n = p2 + 2 * p1 + 2 * p0 + 2 * q0 + q1 + 4 >> 3;
/* 465 */       int p1n = p2 + p1 + p0 + q0 + 2 >> 2;
/* 466 */       int p2n = 2 * p3 + 3 * p2 + p1 + p0 + q0 + 4 >> 3;
/* 467 */       pelsP[p0Idx] = (byte)MathUtil.clip(p0n, -128, 127);
/* 468 */       pelsP[p1Idx] = (byte)MathUtil.clip(p1n, -128, 127);
/* 469 */       pelsP[p2Idx] = (byte)MathUtil.clip(p2n, -128, 127);
/*     */     } else {
/* 471 */       int p0n = 2 * p1 + p0 + q1 + 2 >> 2;
/* 472 */       pelsP[p0Idx] = (byte)MathUtil.clip(p0n, -128, 127);
/*     */     } 
/*     */     
/* 475 */     if (conditionQ && !isChroma) {
/* 476 */       int q2 = pelsQ[q2Idx];
/* 477 */       int q3 = pelsQ[q3Idx];
/* 478 */       int q0n = p1 + 2 * p0 + 2 * q0 + 2 * q1 + q2 + 4 >> 3;
/* 479 */       int q1n = p0 + q0 + q1 + q2 + 2 >> 2;
/* 480 */       int q2n = 2 * q3 + 3 * q2 + q1 + q0 + p0 + 4 >> 3;
/* 481 */       pelsQ[q0Idx] = (byte)MathUtil.clip(q0n, -128, 127);
/* 482 */       pelsQ[q1Idx] = (byte)MathUtil.clip(q1n, -128, 127);
/* 483 */       pelsQ[q2Idx] = (byte)MathUtil.clip(q2n, -128, 127);
/*     */     } else {
/* 485 */       int q0n = 2 * q1 + q0 + p1 + 2 >> 2;
/* 486 */       pelsQ[q0Idx] = (byte)MathUtil.clip(q0n, -128, 127);
/*     */     } 
/*     */   }
/*     */ }


/* Location:              C:\Users\rapha\Downloads\aurora.jar!\META-INF\jars\jcodec-0.2.5.jar!\org\jcodec\codecs\h264\decode\deblock\DeblockingFilter.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */