/*      */ package org.jcodec.codecs.h264.decode;
/*      */ 
/*      */ import org.jcodec.common.model.Picture;
/*      */ import org.jcodec.common.tools.MathUtil;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ public class BlockInterpolator
/*      */ {
/*   25 */   private int[] tmp1 = new int[1024];
/*   26 */   private int[] tmp2 = new int[1024];
/*   27 */   private byte[] tmp3 = new byte[1024];
/*   28 */   private LumaInterpolator[] safe = initSafe();
/*   29 */   private LumaInterpolator[] unsafe = initUnsafe();
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void getBlockLuma(Picture pic, Picture out, int off, int x, int y, int w, int h) {
/*   35 */     int xInd = x & 0x3;
/*   36 */     int yInd = y & 0x3;
/*      */     
/*   38 */     int xFp = x >> 2;
/*   39 */     int yFp = y >> 2;
/*   40 */     if (xFp < 2 || yFp < 2 || xFp > pic.getWidth() - w - 5 || yFp > pic.getHeight() - h - 5) {
/*   41 */       this.unsafe[(yInd << 2) + xInd].getLuma(pic.getData()[0], pic.getWidth(), pic.getHeight(), out.getPlaneData(0), off, out
/*   42 */           .getPlaneWidth(0), xFp, yFp, w, h);
/*      */     } else {
/*   44 */       this.safe[(yInd << 2) + xInd].getLuma(pic.getData()[0], pic.getWidth(), pic.getHeight(), out.getPlaneData(0), off, out
/*   45 */           .getPlaneWidth(0), xFp, yFp, w, h);
/*      */     } 
/*      */   }
/*      */ 
/*      */   
/*      */   public static void getBlockChroma(byte[] pels, int picW, int picH, byte[] blk, int blkOff, int blkStride, int x, int y, int blkW, int blkH) {
/*   51 */     int xInd = x & 0x7;
/*   52 */     int yInd = y & 0x7;
/*      */     
/*   54 */     int xFull = x >> 3;
/*   55 */     int yFull = y >> 3;
/*      */     
/*   57 */     if (xFull < 0 || xFull > picW - blkW - 1 || yFull < 0 || yFull > picH - blkH - 1) {
/*   58 */       if (xInd == 0 && yInd == 0) {
/*   59 */         getChroma00Unsafe(pels, picW, picH, blk, blkOff, blkStride, xFull, yFull, blkW, blkH);
/*   60 */       } else if (yInd == 0) {
/*      */         
/*   62 */         getChromaX0Unsafe(pels, picW, picH, blk, blkOff, blkStride, xFull, yFull, xInd, blkW, blkH);
/*      */       }
/*   64 */       else if (xInd == 0) {
/*   65 */         getChroma0XUnsafe(pels, picW, picH, blk, blkOff, blkStride, xFull, yFull, yInd, blkW, blkH);
/*      */       } else {
/*   67 */         getChromaXXUnsafe(pels, picW, picH, blk, blkOff, blkStride, xFull, yFull, xInd, yInd, blkW, blkH);
/*      */       }
/*      */     
/*   70 */     } else if (xInd == 0 && yInd == 0) {
/*   71 */       getChroma00(pels, picW, picH, blk, blkOff, blkStride, xFull, yFull, blkW, blkH);
/*   72 */     } else if (yInd == 0) {
/*      */       
/*   74 */       getChromaX0(pels, picW, picH, blk, blkOff, blkStride, xFull, yFull, xInd, blkW, blkH);
/*      */     }
/*   76 */     else if (xInd == 0) {
/*   77 */       getChroma0X(pels, picW, picH, blk, blkOff, blkStride, xFull, yFull, yInd, blkW, blkH);
/*      */     } else {
/*   79 */       getChromaXX(pels, picW, picH, blk, blkOff, blkStride, xFull, yFull, xInd, yInd, blkW, blkH);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   static void getLuma00(byte[] pic, int picW, byte[] blk, int blkOff, int blkStride, int x, int y, int blkW, int blkH) {
/*   89 */     int off = y * picW + x;
/*   90 */     for (int j = 0; j < blkH; j++) {
/*   91 */       System.arraycopy(pic, off, blk, blkOff, blkW);
/*   92 */       off += picW;
/*   93 */       blkOff += blkStride;
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   static void getLuma00Unsafe(byte[] pic, int picW, int picH, byte[] blk, int blkOff, int blkStride, int x, int y, int blkW, int blkH) {
/*  102 */     int maxH = picH - 1;
/*  103 */     int maxW = picW - 1;
/*      */     
/*  105 */     for (int j = 0; j < blkH; j++) {
/*  106 */       int lineStart = MathUtil.clip(j + y, 0, maxH) * picW;
/*      */       
/*  108 */       for (int i = 0; i < blkW; i++) {
/*  109 */         blk[blkOff + i] = pic[lineStart + MathUtil.clip(x + i, 0, maxW)];
/*      */       }
/*  111 */       blkOff += blkStride;
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   static void getLuma20NoRoundInt(int[] pic, int picW, int[] blk, int blkOff, int blkStride, int x, int y, int blkW, int blkH) {
/*  121 */     int off = y * picW + x;
/*  122 */     for (int j = 0; j < blkH; j++) {
/*  123 */       int off1 = -2;
/*  124 */       for (int i = 0; i < blkW; i++) {
/*  125 */         int a = pic[off + off1] + pic[off + off1 + 5];
/*  126 */         int b = pic[off + off1 + 1] + pic[off + off1 + 4];
/*  127 */         int c = pic[off + off1 + 2] + pic[off + off1 + 3];
/*  128 */         blk[blkOff + i] = a + 5 * ((c << 2) - b);
/*  129 */         off1++;
/*      */       } 
/*  131 */       off += picW;
/*  132 */       blkOff += blkStride;
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   static void getLuma20NoRound(byte[] pic, int picW, int[] blk, int blkOff, int blkStride, int x, int y, int blkW, int blkH) {
/*  142 */     int off = y * picW + x;
/*  143 */     for (int j = 0; j < blkH; j++) {
/*  144 */       int off1 = -2;
/*  145 */       for (int i = 0; i < blkW; i++) {
/*  146 */         int a = pic[off + off1] + pic[off + off1 + 5];
/*  147 */         int b = pic[off + off1 + 1] + pic[off + off1 + 4];
/*  148 */         int c = pic[off + off1 + 2] + pic[off + off1 + 3];
/*  149 */         blk[blkOff + i] = a + 5 * ((c << 2) - b);
/*  150 */         off1++;
/*      */       } 
/*  152 */       off += picW;
/*  153 */       blkOff += blkStride;
/*      */     } 
/*      */   }
/*      */   
/*      */   static void getLuma20(byte[] pic, int picW, byte[] blk, int blkOff, int blkStride, int x, int y, int blkW, int blkH) {
/*  158 */     int off = y * picW + x;
/*  159 */     for (int j = 0; j < blkH; j++) {
/*  160 */       int off1 = -2;
/*  161 */       for (int i = 0; i < blkW; i++) {
/*  162 */         int a = pic[off + off1] + pic[off + off1 + 5];
/*  163 */         int b = pic[off + off1 + 1] + pic[off + off1 + 4];
/*  164 */         int c = pic[off + off1 + 2] + pic[off + off1 + 3];
/*  165 */         blk[blkOff + i] = (byte)MathUtil.clip(a + 5 * ((c << 2) - b) + 16 >> 5, -128, 127);
/*  166 */         off1++;
/*      */       } 
/*  168 */       off += picW;
/*  169 */       blkOff += blkStride;
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   static void getLuma20UnsafeNoRound(byte[] pic, int picW, int picH, int[] blk, int blkOff, int blkStride, int x, int y, int blkW, int blkH) {
/*  178 */     int maxW = picW - 1;
/*  179 */     int maxH = picH - 1;
/*      */     
/*  181 */     for (int i = 0; i < blkW; i++) {
/*  182 */       int ipos_m2 = MathUtil.clip(x + i - 2, 0, maxW);
/*  183 */       int ipos_m1 = MathUtil.clip(x + i - 1, 0, maxW);
/*  184 */       int ipos = MathUtil.clip(x + i, 0, maxW);
/*  185 */       int ipos_p1 = MathUtil.clip(x + i + 1, 0, maxW);
/*  186 */       int ipos_p2 = MathUtil.clip(x + i + 2, 0, maxW);
/*  187 */       int ipos_p3 = MathUtil.clip(x + i + 3, 0, maxW);
/*      */       
/*  189 */       int boff = blkOff;
/*  190 */       for (int j = 0; j < blkH; j++) {
/*  191 */         int lineStart = MathUtil.clip(j + y, 0, maxH) * picW;
/*      */         
/*  193 */         int a = pic[lineStart + ipos_m2] + pic[lineStart + ipos_p3];
/*  194 */         int b = pic[lineStart + ipos_m1] + pic[lineStart + ipos_p2];
/*  195 */         int c = pic[lineStart + ipos] + pic[lineStart + ipos_p1];
/*      */         
/*  197 */         blk[boff + i] = a + 5 * ((c << 2) - b);
/*      */         
/*  199 */         boff += blkStride;
/*      */       } 
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   void getLuma20Unsafe(byte[] pic, int picW, int picH, byte[] blk, int blkOff, int blkStride, int x, int y, int blkW, int blkH) {
/*  207 */     getLuma20UnsafeNoRound(pic, picW, picH, this.tmp1, blkOff, blkStride, x, y, blkW, blkH);
/*      */     
/*  209 */     for (int i = 0; i < blkW; i++) {
/*  210 */       int boff = blkOff;
/*  211 */       for (int j = 0; j < blkH; j++) {
/*  212 */         blk[boff + i] = (byte)MathUtil.clip(this.tmp1[boff + i] + 16 >> 5, -128, 127);
/*  213 */         boff += blkStride;
/*      */       } 
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   static void getLuma02NoRoundInt(int[] pic, int picW, int[] blk, int blkOff, int blkStride, int x, int y, int blkW, int blkH) {
/*  223 */     int off = (y - 2) * picW + x, picWx2 = picW + picW, picWx3 = picWx2 + picW, picWx4 = picWx3 + picW, picWx5 = picWx4 + picW;
/*      */     
/*  225 */     for (int j = 0; j < blkH; j++) {
/*  226 */       for (int i = 0; i < blkW; i++) {
/*  227 */         int a = pic[off + i] + pic[off + i + picWx5];
/*  228 */         int b = pic[off + i + picW] + pic[off + i + picWx4];
/*  229 */         int c = pic[off + i + picWx2] + pic[off + i + picWx3];
/*      */         
/*  231 */         blk[blkOff + i] = a + 5 * ((c << 2) - b);
/*      */       } 
/*  233 */       off += picW;
/*  234 */       blkOff += blkStride;
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   static void getLuma02NoRound(byte[] pic, int picW, int[] blk, int blkOff, int blkStride, int x, int y, int blkW, int blkH) {
/*  243 */     int off = (y - 2) * picW + x, picWx2 = picW + picW, picWx3 = picWx2 + picW, picWx4 = picWx3 + picW, picWx5 = picWx4 + picW;
/*      */     
/*  245 */     for (int j = 0; j < blkH; j++) {
/*  246 */       for (int i = 0; i < blkW; i++) {
/*  247 */         int a = pic[off + i] + pic[off + i + picWx5];
/*  248 */         int b = pic[off + i + picW] + pic[off + i + picWx4];
/*  249 */         int c = pic[off + i + picWx2] + pic[off + i + picWx3];
/*      */         
/*  251 */         blk[blkOff + i] = a + 5 * ((c << 2) - b);
/*      */       } 
/*  253 */       off += picW;
/*  254 */       blkOff += blkStride;
/*      */     } 
/*      */   }
/*      */ 
/*      */   
/*      */   static void getLuma02(byte[] pic, int picW, byte[] blk, int blkOff, int blkStride, int x, int y, int blkW, int blkH) {
/*  260 */     int off = (y - 2) * picW + x, picWx2 = picW + picW, picWx3 = picWx2 + picW, picWx4 = picWx3 + picW, picWx5 = picWx4 + picW;
/*      */     
/*  262 */     for (int j = 0; j < blkH; j++) {
/*  263 */       for (int i = 0; i < blkW; i++) {
/*  264 */         int a = pic[off + i] + pic[off + i + picWx5];
/*  265 */         int b = pic[off + i + picW] + pic[off + i + picWx4];
/*  266 */         int c = pic[off + i + picWx2] + pic[off + i + picWx3];
/*  267 */         blk[blkOff + i] = (byte)MathUtil.clip(a + 5 * ((c << 2) - b) + 16 >> 5, -128, 127);
/*      */       } 
/*  269 */       off += picW;
/*  270 */       blkOff += blkStride;
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   static void getLuma02UnsafeNoRound(byte[] pic, int picW, int picH, int[] blk, int blkOff, int blkStride, int x, int y, int blkW, int blkH) {
/*  279 */     int maxH = picH - 1;
/*  280 */     int maxW = picW - 1;
/*      */     
/*  282 */     for (int j = 0; j < blkH; j++) {
/*  283 */       int offP0 = MathUtil.clip(y + j - 2, 0, maxH) * picW;
/*  284 */       int offP1 = MathUtil.clip(y + j - 1, 0, maxH) * picW;
/*  285 */       int offP2 = MathUtil.clip(y + j, 0, maxH) * picW;
/*  286 */       int offP3 = MathUtil.clip(y + j + 1, 0, maxH) * picW;
/*  287 */       int offP4 = MathUtil.clip(y + j + 2, 0, maxH) * picW;
/*  288 */       int offP5 = MathUtil.clip(y + j + 3, 0, maxH) * picW;
/*      */       
/*  290 */       for (int i = 0; i < blkW; i++) {
/*  291 */         int pres_x = MathUtil.clip(x + i, 0, maxW);
/*      */         
/*  293 */         int a = pic[pres_x + offP0] + pic[pres_x + offP5];
/*  294 */         int b = pic[pres_x + offP1] + pic[pres_x + offP4];
/*  295 */         int c = pic[pres_x + offP2] + pic[pres_x + offP3];
/*      */         
/*  297 */         blk[blkOff + i] = a + 5 * ((c << 2) - b);
/*      */       } 
/*  299 */       blkOff += blkStride;
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   void getLuma02Unsafe(byte[] pic, int picW, int picH, byte[] blk, int blkOff, int blkStride, int x, int y, int blkW, int blkH) {
/*  306 */     getLuma02UnsafeNoRound(pic, picW, picH, this.tmp1, blkOff, blkStride, x, y, blkW, blkH);
/*      */     
/*  308 */     for (int j = 0; j < blkH; j++) {
/*  309 */       for (int i = 0; i < blkW; i++) {
/*  310 */         blk[blkOff + i] = (byte)MathUtil.clip(this.tmp1[blkOff + i] + 16 >> 5, -128, 127);
/*      */       }
/*  312 */       blkOff += blkStride;
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   static void getLuma10(byte[] pic, int picW, byte[] blk, int blkOff, int blkStride, int x, int y, int blkW, int blkH) {
/*  321 */     getLuma20(pic, picW, blk, blkOff, blkStride, x, y, blkW, blkH);
/*      */     
/*  323 */     int off = y * picW + x;
/*  324 */     for (int j = 0; j < blkH; j++) {
/*      */       
/*  326 */       for (int i = 0; i < blkW; i++)
/*      */       {
/*  328 */         blk[blkOff + i] = (byte)(blk[blkOff + i] + pic[off + i] + 1 >> 1);
/*      */       }
/*  330 */       off += picW;
/*  331 */       blkOff += blkStride;
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   void getLuma10Unsafe(byte[] pic, int picW, int picH, byte[] blk, int blkOff, int blkStride, int x, int y, int blkW, int blkH) {
/*  340 */     int maxH = picH - 1;
/*  341 */     int maxW = picW - 1;
/*      */     
/*  343 */     getLuma20Unsafe(pic, picW, picH, blk, blkOff, blkStride, x, y, blkW, blkH);
/*      */     
/*  345 */     for (int j = 0; j < blkH; j++) {
/*  346 */       int lineStart = MathUtil.clip(j + y, 0, maxH) * picW;
/*      */       
/*  348 */       for (int i = 0; i < blkW; i++) {
/*  349 */         blk[blkOff + i] = (byte)(blk[blkOff + i] + pic[lineStart + MathUtil.clip(x + i, 0, maxW)] + 1 >> 1);
/*      */       }
/*  351 */       blkOff += blkStride;
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   static void getLuma30(byte[] pic, int picW, byte[] blk, int blkOff, int blkStride, int x, int y, int blkW, int blkH) {
/*  360 */     getLuma20(pic, picW, blk, blkOff, blkStride, x, y, blkW, blkH);
/*      */     
/*  362 */     int off = y * picW + x;
/*  363 */     for (int j = 0; j < blkH; j++) {
/*  364 */       for (int i = 0; i < blkW; i++) {
/*  365 */         blk[blkOff + i] = (byte)(pic[off + i + 1] + blk[blkOff + i] + 1 >> 1);
/*      */       }
/*  367 */       off += picW;
/*  368 */       blkOff += blkStride;
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   void getLuma30Unsafe(byte[] pic, int picW, int picH, byte[] blk, int blkOff, int blkStride, int x, int y, int blkW, int blkH) {
/*  377 */     int maxH = picH - 1;
/*  378 */     int maxW = picW - 1;
/*      */     
/*  380 */     getLuma20Unsafe(pic, picW, picH, blk, blkOff, blkStride, x, y, blkW, blkH);
/*      */     
/*  382 */     for (int j = 0; j < blkH; j++) {
/*  383 */       int lineStart = MathUtil.clip(j + y, 0, maxH) * picW;
/*      */       
/*  385 */       for (int i = 0; i < blkW; i++) {
/*  386 */         blk[blkOff + i] = (byte)(blk[blkOff + i] + pic[lineStart + MathUtil.clip(x + i + 1, 0, maxW)] + 1 >> 1);
/*      */       }
/*  388 */       blkOff += blkStride;
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   static void getLuma01(byte[] pic, int picW, byte[] blk, int blkOff, int blkStride, int x, int y, int blkW, int blkH) {
/*  397 */     getLuma02(pic, picW, blk, blkOff, blkStride, x, y, blkW, blkH);
/*      */     
/*  399 */     int off = y * picW + x;
/*  400 */     for (int j = 0; j < blkH; j++) {
/*  401 */       for (int i = 0; i < blkW; i++) {
/*  402 */         blk[blkOff + i] = (byte)(blk[blkOff + i] + pic[off + i] + 1 >> 1);
/*      */       }
/*  404 */       off += picW;
/*  405 */       blkOff += blkStride;
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   void getLuma01Unsafe(byte[] pic, int picW, int picH, byte[] blk, int blkOff, int blkStride, int x, int y, int blkW, int blkH) {
/*  414 */     int maxH = picH - 1;
/*  415 */     int maxW = picW - 1;
/*      */     
/*  417 */     getLuma02Unsafe(pic, picW, picH, blk, blkOff, blkStride, x, y, blkW, blkH);
/*      */     
/*  419 */     for (int j = 0; j < blkH; j++) {
/*  420 */       int lineStart = MathUtil.clip(y + j, 0, maxH) * picW;
/*  421 */       for (int i = 0; i < blkW; i++) {
/*  422 */         blk[blkOff + i] = (byte)(blk[blkOff + i] + pic[lineStart + MathUtil.clip(x + i, 0, maxW)] + 1 >> 1);
/*      */       }
/*  424 */       blkOff += blkStride;
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   static void getLuma03(byte[] pic, int picW, byte[] blk, int blkOff, int blkStride, int x, int y, int blkW, int blkH) {
/*  433 */     getLuma02(pic, picW, blk, blkOff, blkStride, x, y, blkW, blkH);
/*      */     
/*  435 */     int off = y * picW + x;
/*  436 */     for (int j = 0; j < blkH; j++) {
/*  437 */       for (int i = 0; i < blkW; i++) {
/*  438 */         blk[blkOff + i] = (byte)(blk[blkOff + i] + pic[off + i + picW] + 1 >> 1);
/*      */       }
/*  440 */       off += picW;
/*  441 */       blkOff += blkStride;
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   void getLuma03Unsafe(byte[] pic, int picW, int picH, byte[] blk, int blkOff, int blkStride, int x, int y, int blkW, int blkH) {
/*  451 */     int maxH = picH - 1;
/*  452 */     int maxW = picW - 1;
/*      */     
/*  454 */     getLuma02Unsafe(pic, picW, picH, blk, blkOff, blkStride, x, y, blkW, blkH);
/*      */     
/*  456 */     for (int j = 0; j < blkH; j++) {
/*  457 */       int lineStart = MathUtil.clip(y + j + 1, 0, maxH) * picW;
/*  458 */       for (int i = 0; i < blkW; i++) {
/*  459 */         blk[blkOff + i] = (byte)(blk[blkOff + i] + pic[lineStart + MathUtil.clip(x + i, 0, maxW)] + 1 >> 1);
/*      */       }
/*  461 */       blkOff += blkStride;
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   void getLuma21(byte[] pic, int picW, byte[] blk, int blkOff, int blkStride, int x, int y, int blkW, int blkH) {
/*  470 */     getLuma20NoRound(pic, picW, this.tmp1, 0, blkW, x, y - 2, blkW, blkH + 7);
/*  471 */     getLuma02NoRoundInt(this.tmp1, blkW, this.tmp2, blkOff, blkStride, 0, 2, blkW, blkH);
/*      */     
/*  473 */     int off = blkW << 1;
/*  474 */     for (int j = 0; j < blkH; j++) {
/*  475 */       for (int i = 0; i < blkW; i++) {
/*  476 */         int rounded = MathUtil.clip(this.tmp2[blkOff + i] + 512 >> 10, -128, 127);
/*  477 */         int rounded2 = MathUtil.clip(this.tmp1[off + i] + 16 >> 5, -128, 127);
/*  478 */         blk[blkOff + i] = (byte)(rounded + rounded2 + 1 >> 1);
/*      */       } 
/*  480 */       blkOff += blkStride;
/*  481 */       off += blkW;
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   void getLuma21Unsafe(byte[] pic, int picW, int imgH, byte[] blk, int blkOff, int blkStride, int x, int y, int blkW, int blkH) {
/*  490 */     getLuma20UnsafeNoRound(pic, picW, imgH, this.tmp1, 0, blkW, x, y - 2, blkW, blkH + 7);
/*  491 */     getLuma02NoRoundInt(this.tmp1, blkW, this.tmp2, blkOff, blkStride, 0, 2, blkW, blkH);
/*      */     
/*  493 */     int off = blkW << 1;
/*  494 */     for (int j = 0; j < blkH; j++) {
/*  495 */       for (int i = 0; i < blkW; i++) {
/*  496 */         int rounded = MathUtil.clip(this.tmp2[blkOff + i] + 512 >> 10, -128, 127);
/*  497 */         int rounded2 = MathUtil.clip(this.tmp1[off + i] + 16 >> 5, -128, 127);
/*  498 */         blk[blkOff + i] = (byte)(rounded + rounded2 + 1 >> 1);
/*      */       } 
/*  500 */       blkOff += blkStride;
/*  501 */       off += blkW;
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   void getLuma22(byte[] pic, int picW, byte[] blk, int blkOff, int blkStride, int x, int y, int blkW, int blkH) {
/*  509 */     getLuma20NoRound(pic, picW, this.tmp1, 0, blkW, x, y - 2, blkW, blkH + 7);
/*  510 */     getLuma02NoRoundInt(this.tmp1, blkW, this.tmp2, blkOff, blkStride, 0, 2, blkW, blkH);
/*      */     
/*  512 */     for (int j = 0; j < blkH; j++) {
/*  513 */       for (int i = 0; i < blkW; i++) {
/*  514 */         blk[blkOff + i] = (byte)MathUtil.clip(this.tmp2[blkOff + i] + 512 >> 10, -128, 127);
/*      */       }
/*  516 */       blkOff += blkStride;
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   void getLuma22Unsafe(byte[] pic, int picW, int imgH, byte[] blk, int blkOff, int blkStride, int x, int y, int blkW, int blkH) {
/*  525 */     getLuma20UnsafeNoRound(pic, picW, imgH, this.tmp1, 0, blkW, x, y - 2, blkW, blkH + 7);
/*  526 */     getLuma02NoRoundInt(this.tmp1, blkW, this.tmp2, blkOff, blkStride, 0, 2, blkW, blkH);
/*      */     
/*  528 */     for (int j = 0; j < blkH; j++) {
/*  529 */       for (int i = 0; i < blkW; i++) {
/*  530 */         blk[blkOff + i] = (byte)MathUtil.clip(this.tmp2[blkOff + i] + 512 >> 10, -128, 127);
/*      */       }
/*  532 */       blkOff += blkStride;
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   void getLuma23(byte[] pic, int picW, byte[] blk, int blkOff, int blkStride, int x, int y, int blkW, int blkH) {
/*  541 */     getLuma20NoRound(pic, picW, this.tmp1, 0, blkW, x, y - 2, blkW, blkH + 7);
/*  542 */     getLuma02NoRoundInt(this.tmp1, blkW, this.tmp2, blkOff, blkStride, 0, 2, blkW, blkH);
/*      */     
/*  544 */     int off = blkW << 1;
/*  545 */     for (int j = 0; j < blkH; j++) {
/*  546 */       for (int i = 0; i < blkW; i++) {
/*  547 */         int rounded = MathUtil.clip(this.tmp2[blkOff + i] + 512 >> 10, -128, 127);
/*  548 */         int rounded2 = MathUtil.clip(this.tmp1[off + i + blkW] + 16 >> 5, -128, 127);
/*  549 */         blk[blkOff + i] = (byte)(rounded + rounded2 + 1 >> 1);
/*      */       } 
/*  551 */       blkOff += blkStride;
/*  552 */       off += blkW;
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   void getLuma23Unsafe(byte[] pic, int picW, int imgH, byte[] blk, int blkOff, int blkStride, int x, int y, int blkW, int blkH) {
/*  561 */     getLuma20UnsafeNoRound(pic, picW, imgH, this.tmp1, 0, blkW, x, y - 2, blkW, blkH + 7);
/*  562 */     getLuma02NoRoundInt(this.tmp1, blkW, this.tmp2, blkOff, blkStride, 0, 2, blkW, blkH);
/*      */     
/*  564 */     int off = blkW << 1;
/*  565 */     for (int j = 0; j < blkH; j++) {
/*  566 */       for (int i = 0; i < blkW; i++) {
/*  567 */         int rounded = MathUtil.clip(this.tmp2[blkOff + i] + 512 >> 10, -128, 127);
/*  568 */         int rounded2 = MathUtil.clip(this.tmp1[off + i + blkW] + 16 >> 5, -128, 127);
/*  569 */         blk[blkOff + i] = (byte)(rounded + rounded2 + 1 >> 1);
/*      */       } 
/*  571 */       blkOff += blkStride;
/*  572 */       off += blkW;
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   void getLuma12(byte[] pic, int picW, byte[] blk, int blkOff, int blkStride, int x, int y, int blkW, int blkH) {
/*  581 */     int tmpW = blkW + 7;
/*      */     
/*  583 */     getLuma02NoRound(pic, picW, this.tmp1, 0, tmpW, x - 2, y, tmpW, blkH);
/*  584 */     getLuma20NoRoundInt(this.tmp1, tmpW, this.tmp2, blkOff, blkStride, 2, 0, blkW, blkH);
/*      */     
/*  586 */     int off = 2;
/*  587 */     for (int j = 0; j < blkH; j++) {
/*  588 */       for (int i = 0; i < blkW; i++) {
/*  589 */         int rounded = MathUtil.clip(this.tmp2[blkOff + i] + 512 >> 10, -128, 127);
/*  590 */         int rounded2 = MathUtil.clip(this.tmp1[off + i] + 16 >> 5, -128, 127);
/*  591 */         blk[blkOff + i] = (byte)(rounded + rounded2 + 1 >> 1);
/*      */       } 
/*  593 */       blkOff += blkStride;
/*  594 */       off += tmpW;
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   void getLuma12Unsafe(byte[] pic, int picW, int imgH, byte[] blk, int blkOff, int blkStride, int x, int y, int blkW, int blkH) {
/*  603 */     int tmpW = blkW + 7;
/*      */     
/*  605 */     getLuma02UnsafeNoRound(pic, picW, imgH, this.tmp1, 0, tmpW, x - 2, y, tmpW, blkH);
/*  606 */     getLuma20NoRoundInt(this.tmp1, tmpW, this.tmp2, blkOff, blkStride, 2, 0, blkW, blkH);
/*      */     
/*  608 */     int off = 2;
/*  609 */     for (int j = 0; j < blkH; j++) {
/*  610 */       for (int i = 0; i < blkW; i++) {
/*  611 */         int rounded = MathUtil.clip(this.tmp2[blkOff + i] + 512 >> 10, -128, 127);
/*  612 */         int rounded2 = MathUtil.clip(this.tmp1[off + i] + 16 >> 5, -128, 127);
/*  613 */         blk[blkOff + i] = (byte)(rounded + rounded2 + 1 >> 1);
/*      */       } 
/*  615 */       blkOff += blkStride;
/*  616 */       off += tmpW;
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   void getLuma32(byte[] pic, int picW, byte[] blk, int blkOff, int blkStride, int x, int y, int blkW, int blkH) {
/*  624 */     int tmpW = blkW + 7;
/*      */     
/*  626 */     getLuma02NoRound(pic, picW, this.tmp1, 0, tmpW, x - 2, y, tmpW, blkH);
/*  627 */     getLuma20NoRoundInt(this.tmp1, tmpW, this.tmp2, blkOff, blkStride, 2, 0, blkW, blkH);
/*      */     
/*  629 */     int off = 2;
/*  630 */     for (int j = 0; j < blkH; j++) {
/*  631 */       for (int i = 0; i < blkW; i++) {
/*  632 */         int rounded = MathUtil.clip(this.tmp2[blkOff + i] + 512 >> 10, -128, 127);
/*  633 */         int rounded2 = MathUtil.clip(this.tmp1[off + i + 1] + 16 >> 5, -128, 127);
/*  634 */         blk[blkOff + i] = (byte)(rounded + rounded2 + 1 >> 1);
/*      */       } 
/*  636 */       blkOff += blkStride;
/*  637 */       off += tmpW;
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   void getLuma32Unsafe(byte[] pic, int picW, int imgH, byte[] blk, int blkOff, int blkStride, int x, int y, int blkW, int blkH) {
/*  646 */     int tmpW = blkW + 7;
/*      */     
/*  648 */     getLuma02UnsafeNoRound(pic, picW, imgH, this.tmp1, 0, tmpW, x - 2, y, tmpW, blkH);
/*  649 */     getLuma20NoRoundInt(this.tmp1, tmpW, this.tmp2, blkOff, blkStride, 2, 0, blkW, blkH);
/*      */     
/*  651 */     int off = 2;
/*  652 */     for (int j = 0; j < blkH; j++) {
/*  653 */       for (int i = 0; i < blkW; i++) {
/*  654 */         int rounded = MathUtil.clip(this.tmp2[blkOff + i] + 512 >> 10, -128, 127);
/*  655 */         int rounded2 = MathUtil.clip(this.tmp1[off + i + 1] + 16 >> 5, -128, 127);
/*  656 */         blk[blkOff + i] = (byte)(rounded + rounded2 + 1 >> 1);
/*      */       } 
/*  658 */       blkOff += blkStride;
/*  659 */       off += tmpW;
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   void getLuma33(byte[] pic, int picW, byte[] blk, int blkOff, int blkStride, int x, int y, int blkW, int blkH) {
/*  667 */     getLuma20(pic, picW, blk, blkOff, blkStride, x, y + 1, blkW, blkH);
/*  668 */     getLuma02(pic, picW, this.tmp3, 0, blkW, x + 1, y, blkW, blkH);
/*      */     
/*  670 */     merge(blk, this.tmp3, blkOff, blkStride, blkW, blkH);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   void getLuma33Unsafe(byte[] pic, int picW, int imgH, byte[] blk, int blkOff, int blkStride, int x, int y, int blkW, int blkH) {
/*  678 */     getLuma20Unsafe(pic, picW, imgH, blk, blkOff, blkStride, x, y + 1, blkW, blkH);
/*  679 */     getLuma02Unsafe(pic, picW, imgH, this.tmp3, 0, blkW, x + 1, y, blkW, blkH);
/*      */     
/*  681 */     merge(blk, this.tmp3, blkOff, blkStride, blkW, blkH);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   void getLuma11(byte[] pic, int picW, byte[] blk, int blkOff, int blkStride, int x, int y, int blkW, int blkH) {
/*  688 */     getLuma20(pic, picW, blk, blkOff, blkStride, x, y, blkW, blkH);
/*  689 */     getLuma02(pic, picW, this.tmp3, 0, blkW, x, y, blkW, blkH);
/*      */     
/*  691 */     merge(blk, this.tmp3, blkOff, blkStride, blkW, blkH);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   void getLuma11Unsafe(byte[] pic, int picW, int imgH, byte[] blk, int blkOff, int blkStride, int x, int y, int blkW, int blkH) {
/*  699 */     getLuma20Unsafe(pic, picW, imgH, blk, blkOff, blkStride, x, y, blkW, blkH);
/*  700 */     getLuma02Unsafe(pic, picW, imgH, this.tmp3, 0, blkW, x, y, blkW, blkH);
/*      */     
/*  702 */     merge(blk, this.tmp3, blkOff, blkStride, blkW, blkH);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   void getLuma13(byte[] pic, int picW, byte[] blk, int blkOff, int blkStride, int x, int y, int blkW, int blkH) {
/*  709 */     getLuma20(pic, picW, blk, blkOff, blkStride, x, y + 1, blkW, blkH);
/*  710 */     getLuma02(pic, picW, this.tmp3, 0, blkW, x, y, blkW, blkH);
/*      */     
/*  712 */     merge(blk, this.tmp3, blkOff, blkStride, blkW, blkH);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   void getLuma13Unsafe(byte[] pic, int picW, int imgH, byte[] blk, int blkOff, int blkStride, int x, int y, int blkW, int blkH) {
/*  720 */     getLuma20Unsafe(pic, picW, imgH, blk, blkOff, blkStride, x, y + 1, blkW, blkH);
/*  721 */     getLuma02Unsafe(pic, picW, imgH, this.tmp3, 0, blkW, x, y, blkW, blkH);
/*      */     
/*  723 */     merge(blk, this.tmp3, blkOff, blkStride, blkW, blkH);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   void getLuma31(byte[] pels, int picW, byte[] blk, int blkOff, int blkStride, int x, int y, int blkW, int blkH) {
/*  731 */     getLuma20(pels, picW, blk, blkOff, blkStride, x, y, blkW, blkH);
/*  732 */     getLuma02(pels, picW, this.tmp3, 0, blkW, x + 1, y, blkW, blkH);
/*      */     
/*  734 */     merge(blk, this.tmp3, blkOff, blkStride, blkW, blkH);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   void getLuma31Unsafe(byte[] pels, int picW, int imgH, byte[] blk, int blkOff, int blkStride, int x, int y, int blkW, int blkH) {
/*  742 */     getLuma20Unsafe(pels, picW, imgH, blk, blkOff, blkStride, x, y, blkW, blkH);
/*  743 */     getLuma02Unsafe(pels, picW, imgH, this.tmp3, 0, blkW, x + 1, y, blkW, blkH);
/*      */     
/*  745 */     merge(blk, this.tmp3, blkOff, blkStride, blkW, blkH);
/*      */   }
/*      */   
/*      */   private static void merge(byte[] first, byte[] second, int blkOff, int blkStride, int blkW, int blkH) {
/*  749 */     int tOff = 0;
/*  750 */     for (int j = 0; j < blkH; j++) {
/*  751 */       for (int i = 0; i < blkW; i++) {
/*  752 */         first[blkOff + i] = (byte)(first[blkOff + i] + second[tOff + i] + 1 >> 1);
/*      */       }
/*  754 */       blkOff += blkStride;
/*  755 */       tOff += blkW;
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private static void getChroma00(byte[] pic, int picW, int picH, byte[] blk, int blkOff, int blkStride, int x, int y, int blkW, int blkH) {
/*  764 */     int off = y * picW + x;
/*  765 */     for (int j = 0; j < blkH; j++) {
/*  766 */       System.arraycopy(pic, off, blk, blkOff, blkW);
/*  767 */       off += picW;
/*  768 */       blkOff += blkStride;
/*      */     } 
/*      */   }
/*      */ 
/*      */   
/*      */   private static void getChroma00Unsafe(byte[] pic, int picW, int picH, byte[] blk, int blkOff, int blkStride, int x, int y, int blkW, int blkH) {
/*  774 */     int maxH = picH - 1;
/*  775 */     int maxW = picW - 1;
/*      */     
/*  777 */     for (int j = 0; j < blkH; j++) {
/*  778 */       int lineStart = MathUtil.clip(j + y, 0, maxH) * picW;
/*      */       
/*  780 */       for (int i = 0; i < blkW; i++) {
/*  781 */         blk[blkOff + i] = pic[lineStart + MathUtil.clip(x + i, 0, maxW)];
/*      */       }
/*  783 */       blkOff += blkStride;
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private static void getChroma0X(byte[] pels, int picW, int picH, byte[] blk, int blkOff, int blkStride, int fullX, int fullY, int fracY, int blkW, int blkH) {
/*  792 */     int w00 = fullY * picW + fullX;
/*  793 */     int w01 = w00 + ((fullY < picH - 1) ? picW : 0);
/*  794 */     int eMy = 8 - fracY;
/*      */     
/*  796 */     for (int j = 0; j < blkH; j++) {
/*  797 */       for (int i = 0; i < blkW; i++)
/*      */       {
/*  799 */         blk[blkOff + i] = (byte)(eMy * pels[w00 + i] + fracY * pels[w01 + i] + 4 >> 3);
/*      */       }
/*  801 */       w00 += picW;
/*  802 */       w01 += picW;
/*  803 */       blkOff += blkStride;
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   private static void getChroma0XUnsafe(byte[] pels, int picW, int picH, byte[] blk, int blkOff, int blkStride, int fullX, int fullY, int fracY, int blkW, int blkH) {
/*  810 */     int maxW = picW - 1;
/*  811 */     int maxH = picH - 1;
/*  812 */     int eMy = 8 - fracY;
/*      */     
/*  814 */     for (int j = 0; j < blkH; j++) {
/*  815 */       int off00 = MathUtil.clip(fullY + j, 0, maxH) * picW;
/*  816 */       int off01 = MathUtil.clip(fullY + j + 1, 0, maxH) * picW;
/*      */       
/*  818 */       for (int i = 0; i < blkW; i++) {
/*  819 */         int w00 = MathUtil.clip(fullX + i, 0, maxW) + off00;
/*  820 */         int w01 = MathUtil.clip(fullX + i, 0, maxW) + off01;
/*      */         
/*  822 */         blk[blkOff + i] = (byte)(eMy * pels[w00] + fracY * pels[w01] + 4 >> 3);
/*      */       } 
/*  824 */       blkOff += blkStride;
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private static void getChromaX0(byte[] pels, int picW, int imgH, byte[] blk, int blkOff, int blkStride, int fullX, int fullY, int fracX, int blkW, int blkH) {
/*  833 */     int w00 = fullY * picW + fullX;
/*  834 */     int w10 = w00 + ((fullX < picW - 1) ? 1 : 0);
/*  835 */     int eMx = 8 - fracX;
/*      */     
/*  837 */     for (int j = 0; j < blkH; j++) {
/*  838 */       for (int i = 0; i < blkW; i++) {
/*  839 */         blk[blkOff + i] = (byte)(eMx * pels[w00 + i] + fracX * pels[w10 + i] + 4 >> 3);
/*      */       }
/*  841 */       w00 += picW;
/*  842 */       w10 += picW;
/*  843 */       blkOff += blkStride;
/*      */     } 
/*      */   }
/*      */ 
/*      */   
/*      */   private static void getChromaX0Unsafe(byte[] pels, int picW, int picH, byte[] blk, int blkOff, int blkStride, int fullX, int fullY, int fracX, int blkW, int blkH) {
/*  849 */     int eMx = 8 - fracX;
/*  850 */     int maxW = picW - 1;
/*  851 */     int maxH = picH - 1;
/*      */     
/*  853 */     for (int j = 0; j < blkH; j++) {
/*  854 */       for (int i = 0; i < blkW; i++) {
/*  855 */         int w00 = MathUtil.clip(fullY + j, 0, maxH) * picW + MathUtil.clip(fullX + i, 0, maxW);
/*  856 */         int w10 = MathUtil.clip(fullY + j, 0, maxH) * picW + MathUtil.clip(fullX + i + 1, 0, maxW);
/*      */         
/*  858 */         blk[blkOff + i] = (byte)(eMx * pels[w00] + fracX * pels[w10] + 4 >> 3);
/*      */       } 
/*  860 */       blkOff += blkStride;
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private static void getChromaXX(byte[] pels, int picW, int picH, byte[] blk, int blkOff, int blkStride, int fullX, int fullY, int fracX, int fracY, int blkW, int blkH) {
/*  869 */     int w00 = fullY * picW + fullX;
/*  870 */     int w01 = w00 + ((fullY < picH - 1) ? picW : 0);
/*  871 */     int w10 = w00 + ((fullX < picW - 1) ? 1 : 0);
/*  872 */     int w11 = w10 + w01 - w00;
/*  873 */     int eMx = 8 - fracX;
/*  874 */     int eMy = 8 - fracY;
/*      */     
/*  876 */     for (int j = 0; j < blkH; j++) {
/*  877 */       for (int i = 0; i < blkW; i++)
/*      */       {
/*  879 */         blk[blkOff + i] = (byte)(eMx * eMy * pels[w00 + i] + fracX * eMy * pels[w10 + i] + eMx * fracY * pels[w01 + i] + fracX * fracY * pels[w11 + i] + 32 >> 6);
/*      */       }
/*      */       
/*  882 */       blkOff += blkStride;
/*  883 */       w00 += picW;
/*  884 */       w01 += picW;
/*  885 */       w10 += picW;
/*  886 */       w11 += picW;
/*      */     } 
/*      */   }
/*      */ 
/*      */   
/*      */   private static void getChromaXXUnsafe(byte[] pels, int picW, int picH, byte[] blk, int blkOff, int blkStride, int fullX, int fullY, int fracX, int fracY, int blkW, int blkH) {
/*  892 */     int maxH = picH - 1;
/*  893 */     int maxW = picW - 1;
/*      */     
/*  895 */     int eMx = 8 - fracX;
/*  896 */     int eMy = 8 - fracY;
/*      */     
/*  898 */     for (int j = 0; j < blkH; j++) {
/*  899 */       for (int i = 0; i < blkW; i++) {
/*  900 */         int w00 = MathUtil.clip(fullY + j, 0, maxH) * picW + MathUtil.clip(fullX + i, 0, maxW);
/*  901 */         int w01 = MathUtil.clip(fullY + j + 1, 0, maxH) * picW + MathUtil.clip(fullX + i, 0, maxW);
/*  902 */         int w10 = MathUtil.clip(fullY + j, 0, maxH) * picW + MathUtil.clip(fullX + i + 1, 0, maxW);
/*  903 */         int w11 = MathUtil.clip(fullY + j + 1, 0, maxH) * picW + MathUtil.clip(fullX + i + 1, 0, maxW);
/*      */         
/*  905 */         blk[blkOff + i] = (byte)(eMx * eMy * pels[w00] + fracX * eMy * pels[w10] + eMx * fracY * pels[w01] + fracX * fracY * pels[w11] + 32 >> 6);
/*      */       } 
/*      */       
/*  908 */       blkOff += blkStride;
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private LumaInterpolator[] initSafe() {
/*  918 */     final BlockInterpolator self = this;
/*  919 */     return new LumaInterpolator[] { new LumaInterpolator()
/*      */         {
/*      */ 
/*      */           
/*      */           public void getLuma(byte[] pels, int picW, int imgH, byte[] blk, int blkOff, int blkStride, int x, int y, int blkW, int blkH)
/*      */           {
/*  925 */             BlockInterpolator.getLuma00(pels, picW, blk, blkOff, blkStride, x, y, blkW, blkH);
/*      */           }
/*      */         }, new LumaInterpolator()
/*      */         {
/*      */ 
/*      */           
/*      */           public void getLuma(byte[] pels, int picW, int imgH, byte[] blk, int blkOff, int blkStride, int x, int y, int blkW, int blkH)
/*      */           {
/*  933 */             BlockInterpolator.getLuma10(pels, picW, blk, blkOff, blkStride, x, y, blkW, blkH);
/*      */           }
/*      */         }, new LumaInterpolator()
/*      */         {
/*      */ 
/*      */           
/*      */           public void getLuma(byte[] pels, int picW, int imgH, byte[] blk, int blkOff, int blkStride, int x, int y, int blkW, int blkH)
/*      */           {
/*  941 */             BlockInterpolator.getLuma20(pels, picW, blk, blkOff, blkStride, x, y, blkW, blkH);
/*      */           }
/*      */         }, new LumaInterpolator()
/*      */         {
/*      */           public void getLuma(byte[] pels, int picW, int imgH, byte[] blk, int blkOff, int blkStride, int x, int y, int blkW, int blkH)
/*      */           {
/*  947 */             BlockInterpolator.getLuma30(pels, picW, blk, blkOff, blkStride, x, y, blkW, blkH);
/*      */           }
/*      */         }, new LumaInterpolator()
/*      */         {
/*      */           public void getLuma(byte[] pels, int picW, int imgH, byte[] blk, int blkOff, int blkStride, int x, int y, int blkW, int blkH)
/*      */           {
/*  953 */             BlockInterpolator.getLuma01(pels, picW, blk, blkOff, blkStride, x, y, blkW, blkH);
/*      */           }
/*      */         }, new LumaInterpolator()
/*      */         {
/*      */ 
/*      */           
/*      */           public void getLuma(byte[] pels, int picW, int imgH, byte[] blk, int blkOff, int blkStride, int x, int y, int blkW, int blkH)
/*      */           {
/*  961 */             self.getLuma11(pels, picW, blk, blkOff, blkStride, x, y, blkW, blkH);
/*      */           }
/*      */         }, new LumaInterpolator()
/*      */         {
/*      */ 
/*      */           
/*      */           public void getLuma(byte[] pels, int picW, int imgH, byte[] blk, int blkOff, int blkStride, int x, int y, int blkW, int blkH)
/*      */           {
/*  969 */             self.getLuma21(pels, picW, blk, blkOff, blkStride, x, y, blkW, blkH);
/*      */           }
/*      */         }, new LumaInterpolator()
/*      */         {
/*      */           public void getLuma(byte[] pels, int picW, int imgH, byte[] blk, int blkOff, int blkStride, int x, int y, int blkW, int blkH)
/*      */           {
/*  975 */             self.getLuma31(pels, picW, blk, blkOff, blkStride, x, y, blkW, blkH);
/*      */           }
/*      */         }, new LumaInterpolator()
/*      */         {
/*      */           public void getLuma(byte[] pels, int picW, int imgH, byte[] blk, int blkOff, int blkStride, int x, int y, int blkW, int blkH)
/*      */           {
/*  981 */             BlockInterpolator.getLuma02(pels, picW, blk, blkOff, blkStride, x, y, blkW, blkH);
/*      */           }
/*      */         }, new LumaInterpolator()
/*      */         {
/*      */ 
/*      */           
/*      */           public void getLuma(byte[] pels, int picW, int imgH, byte[] blk, int blkOff, int blkStride, int x, int y, int blkW, int blkH)
/*      */           {
/*  989 */             self.getLuma12(pels, picW, blk, blkOff, blkStride, x, y, blkW, blkH);
/*      */           }
/*      */         }, 
/*      */         new LumaInterpolator()
/*      */         {
/*      */           
/*      */           public void getLuma(byte[] pels, int picW, int imgH, byte[] blk, int blkOff, int blkStride, int x, int y, int blkW, int blkH)
/*      */           {
/*  997 */             self.getLuma22(pels, picW, blk, blkOff, blkStride, x, y, blkW, blkH);
/*      */           }
/*      */         }, new LumaInterpolator()
/*      */         {
/*      */           public void getLuma(byte[] pels, int picW, int imgH, byte[] blk, int blkOff, int blkStride, int x, int y, int blkW, int blkH)
/*      */           {
/* 1003 */             self.getLuma32(pels, picW, blk, blkOff, blkStride, x, y, blkW, blkH);
/*      */           }
/*      */         }, new LumaInterpolator()
/*      */         {
/*      */           public void getLuma(byte[] pels, int picW, int imgH, byte[] blk, int blkOff, int blkStride, int x, int y, int blkW, int blkH)
/*      */           {
/* 1009 */             BlockInterpolator.getLuma03(pels, picW, blk, blkOff, blkStride, x, y, blkW, blkH);
/*      */           }
/*      */         }, new LumaInterpolator()
/*      */         {
/*      */ 
/*      */           
/*      */           public void getLuma(byte[] pels, int picW, int imgH, byte[] blk, int blkOff, int blkStride, int x, int y, int blkW, int blkH)
/*      */           {
/* 1017 */             self.getLuma13(pels, picW, blk, blkOff, blkStride, x, y, blkW, blkH);
/*      */           }
/*      */         }, new LumaInterpolator()
/*      */         {
/*      */ 
/*      */           
/*      */           public void getLuma(byte[] pels, int picW, int imgH, byte[] blk, int blkOff, int blkStride, int x, int y, int blkW, int blkH)
/*      */           {
/* 1025 */             self.getLuma23(pels, picW, blk, blkOff, blkStride, x, y, blkW, blkH);
/*      */           }
/*      */         }, new LumaInterpolator()
/*      */         {
/*      */           public void getLuma(byte[] pels, int picW, int imgH, byte[] blk, int blkOff, int blkStride, int x, int y, int blkW, int blkH)
/*      */           {
/* 1031 */             self.getLuma33(pels, picW, blk, blkOff, blkStride, x, y, blkW, blkH);
/*      */           }
/*      */         } };
/*      */   }
/*      */   
/*      */   private LumaInterpolator[] initUnsafe() {
/* 1037 */     final BlockInterpolator self = this;
/* 1038 */     return new LumaInterpolator[] { new LumaInterpolator()
/*      */         {
/*      */ 
/*      */           
/*      */           public void getLuma(byte[] pels, int picW, int imgH, byte[] blk, int blkOff, int blkStride, int x, int y, int blkW, int blkH)
/*      */           {
/* 1044 */             BlockInterpolator.getLuma00Unsafe(pels, picW, imgH, blk, blkOff, blkStride, x, y, blkW, blkH);
/*      */           }
/*      */         }, new LumaInterpolator()
/*      */         {
/*      */ 
/*      */           
/*      */           public void getLuma(byte[] pels, int picW, int imgH, byte[] blk, int blkOff, int blkStride, int x, int y, int blkW, int blkH)
/*      */           {
/* 1052 */             self.getLuma10Unsafe(pels, picW, imgH, blk, blkOff, blkStride, x, y, blkW, blkH);
/*      */           }
/*      */         }, new LumaInterpolator()
/*      */         {
/*      */ 
/*      */           
/*      */           public void getLuma(byte[] pels, int picW, int imgH, byte[] blk, int blkOff, int blkStride, int x, int y, int blkW, int blkH)
/*      */           {
/* 1060 */             self.getLuma20Unsafe(pels, picW, imgH, blk, blkOff, blkStride, x, y, blkW, blkH);
/*      */           }
/*      */         }, new LumaInterpolator()
/*      */         {
/*      */           public void getLuma(byte[] pels, int picW, int imgH, byte[] blk, int blkOff, int blkStride, int x, int y, int blkW, int blkH)
/*      */           {
/* 1066 */             self.getLuma30Unsafe(pels, picW, imgH, blk, blkOff, blkStride, x, y, blkW, blkH);
/*      */           }
/*      */         }, new LumaInterpolator()
/*      */         {
/*      */           public void getLuma(byte[] pels, int picW, int imgH, byte[] blk, int blkOff, int blkStride, int x, int y, int blkW, int blkH)
/*      */           {
/* 1072 */             self.getLuma01Unsafe(pels, picW, imgH, blk, blkOff, blkStride, x, y, blkW, blkH);
/*      */           }
/*      */         }, new LumaInterpolator()
/*      */         {
/*      */ 
/*      */           
/*      */           public void getLuma(byte[] pels, int picW, int imgH, byte[] blk, int blkOff, int blkStride, int x, int y, int blkW, int blkH)
/*      */           {
/* 1080 */             self.getLuma11Unsafe(pels, picW, imgH, blk, blkOff, blkStride, x, y, blkW, blkH);
/*      */           }
/*      */         }, new LumaInterpolator()
/*      */         {
/*      */ 
/*      */           
/*      */           public void getLuma(byte[] pels, int picW, int imgH, byte[] blk, int blkOff, int blkStride, int x, int y, int blkW, int blkH)
/*      */           {
/* 1088 */             self.getLuma21Unsafe(pels, picW, imgH, blk, blkOff, blkStride, x, y, blkW, blkH);
/*      */           }
/*      */         }, new LumaInterpolator()
/*      */         {
/*      */           public void getLuma(byte[] pels, int picW, int imgH, byte[] blk, int blkOff, int blkStride, int x, int y, int blkW, int blkH)
/*      */           {
/* 1094 */             self.getLuma31Unsafe(pels, picW, imgH, blk, blkOff, blkStride, x, y, blkW, blkH);
/*      */           }
/*      */         }, new LumaInterpolator()
/*      */         {
/*      */           public void getLuma(byte[] pels, int picW, int imgH, byte[] blk, int blkOff, int blkStride, int x, int y, int blkW, int blkH)
/*      */           {
/* 1100 */             self.getLuma02Unsafe(pels, picW, imgH, blk, blkOff, blkStride, x, y, blkW, blkH);
/*      */           }
/*      */         }, new LumaInterpolator()
/*      */         {
/*      */ 
/*      */           
/*      */           public void getLuma(byte[] pels, int picW, int imgH, byte[] blk, int blkOff, int blkStride, int x, int y, int blkW, int blkH)
/*      */           {
/* 1108 */             self.getLuma12Unsafe(pels, picW, imgH, blk, blkOff, blkStride, x, y, blkW, blkH);
/*      */           }
/*      */         }, 
/*      */         new LumaInterpolator()
/*      */         {
/*      */           
/*      */           public void getLuma(byte[] pels, int picW, int imgH, byte[] blk, int blkOff, int blkStride, int x, int y, int blkW, int blkH)
/*      */           {
/* 1116 */             self.getLuma22Unsafe(pels, picW, imgH, blk, blkOff, blkStride, x, y, blkW, blkH);
/*      */           }
/*      */         }, new LumaInterpolator()
/*      */         {
/*      */           public void getLuma(byte[] pels, int picW, int imgH, byte[] blk, int blkOff, int blkStride, int x, int y, int blkW, int blkH)
/*      */           {
/* 1122 */             self.getLuma32Unsafe(pels, picW, imgH, blk, blkOff, blkStride, x, y, blkW, blkH);
/*      */           }
/*      */         }, new LumaInterpolator()
/*      */         {
/*      */           public void getLuma(byte[] pels, int picW, int imgH, byte[] blk, int blkOff, int blkStride, int x, int y, int blkW, int blkH)
/*      */           {
/* 1128 */             self.getLuma03Unsafe(pels, picW, imgH, blk, blkOff, blkStride, x, y, blkW, blkH);
/*      */           }
/*      */         }, new LumaInterpolator()
/*      */         {
/*      */ 
/*      */           
/*      */           public void getLuma(byte[] pels, int picW, int imgH, byte[] blk, int blkOff, int blkStride, int x, int y, int blkW, int blkH)
/*      */           {
/* 1136 */             self.getLuma13Unsafe(pels, picW, imgH, blk, blkOff, blkStride, x, y, blkW, blkH);
/*      */           }
/*      */         }, new LumaInterpolator()
/*      */         {
/*      */ 
/*      */           
/*      */           public void getLuma(byte[] pels, int picW, int imgH, byte[] blk, int blkOff, int blkStride, int x, int y, int blkW, int blkH)
/*      */           {
/* 1144 */             self.getLuma23Unsafe(pels, picW, imgH, blk, blkOff, blkStride, x, y, blkW, blkH);
/*      */           }
/*      */         }, new LumaInterpolator()
/*      */         {
/*      */           public void getLuma(byte[] pels, int picW, int imgH, byte[] blk, int blkOff, int blkStride, int x, int y, int blkW, int blkH)
/*      */           {
/* 1150 */             self.getLuma33Unsafe(pels, picW, imgH, blk, blkOff, blkStride, x, y, blkW, blkH);
/*      */           }
/*      */         } };
/*      */   }
/*      */   
/*      */   private static interface LumaInterpolator {
/*      */     void getLuma(byte[] param1ArrayOfbyte1, int param1Int1, int param1Int2, byte[] param1ArrayOfbyte2, int param1Int3, int param1Int4, int param1Int5, int param1Int6, int param1Int7, int param1Int8);
/*      */   }
/*      */ }


/* Location:              C:\Users\rapha\Downloads\aurora.jar!\META-INF\jars\jcodec-0.2.5.jar!\org\jcodec\codecs\h264\decode\BlockInterpolator.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */