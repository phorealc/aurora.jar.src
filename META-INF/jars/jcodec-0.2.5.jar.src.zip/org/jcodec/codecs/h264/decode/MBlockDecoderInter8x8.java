/*     */ package org.jcodec.codecs.h264.decode;
/*     */ 
/*     */ import java.util.Arrays;
/*     */ import org.jcodec.codecs.h264.H264Const;
/*     */ import org.jcodec.codecs.h264.H264Utils;
/*     */ import org.jcodec.codecs.h264.decode.aso.Mapper;
/*     */ import org.jcodec.codecs.h264.io.model.Frame;
/*     */ import org.jcodec.codecs.h264.io.model.SliceHeader;
/*     */ import org.jcodec.codecs.h264.io.model.SliceType;
/*     */ import org.jcodec.common.model.Picture;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class MBlockDecoderInter8x8
/*     */   extends MBlockDecoderBase
/*     */ {
/*     */   private Mapper mapper;
/*     */   private MBlockDecoderBDirect bDirectDecoder;
/*     */   
/*     */   public MBlockDecoderInter8x8(Mapper mapper, MBlockDecoderBDirect bDirectDecoder, SliceHeader sh, DeblockerInput di, int poc, DecoderState decoderState) {
/*  48 */     super(sh, di, poc, decoderState);
/*  49 */     this.mapper = mapper;
/*  50 */     this.bDirectDecoder = bDirectDecoder;
/*     */   }
/*     */ 
/*     */   
/*     */   public void decode(MBlock mBlock, Frame[][] references, Picture mb, SliceType sliceType, boolean ref0) {
/*  55 */     int mbX = this.mapper.getMbX(mBlock.mbIdx);
/*  56 */     int mbY = this.mapper.getMbY(mBlock.mbIdx);
/*  57 */     boolean leftAvailable = this.mapper.leftAvailable(mBlock.mbIdx);
/*  58 */     boolean topAvailable = this.mapper.topAvailable(mBlock.mbIdx);
/*  59 */     int mbAddr = this.mapper.getAddress(mBlock.mbIdx);
/*  60 */     boolean topLeftAvailable = this.mapper.topLeftAvailable(mBlock.mbIdx);
/*  61 */     boolean topRightAvailable = this.mapper.topRightAvailable(mBlock.mbIdx);
/*     */     
/*  63 */     if (sliceType == SliceType.P) {
/*  64 */       predict8x8P(mBlock, (Picture[])references[0], mb, ref0, mbX, mbY, leftAvailable, topAvailable, topLeftAvailable, topRightAvailable, mBlock.x, mBlock.partPreds);
/*     */     } else {
/*     */       
/*  67 */       predict8x8B(mBlock, references, mb, ref0, mbX, mbY, leftAvailable, topAvailable, topLeftAvailable, topRightAvailable, mBlock.x, mBlock.partPreds);
/*     */     } 
/*     */ 
/*     */     
/*  71 */     predictChromaInter(references, mBlock.x, mbX << 3, mbY << 3, 1, mb, mBlock.partPreds);
/*  72 */     predictChromaInter(references, mBlock.x, mbX << 3, mbY << 3, 2, mb, mBlock.partPreds);
/*     */     
/*  74 */     if (mBlock.cbpLuma() > 0 || mBlock.cbpChroma() > 0) {
/*  75 */       this.s.qp = (this.s.qp + mBlock.mbQPDelta + 52) % 52;
/*     */     }
/*  77 */     this.di.mbQps[0][mbAddr] = this.s.qp;
/*     */     
/*  79 */     residualLuma(mBlock, leftAvailable, topAvailable, mbX, mbY);
/*     */     
/*  81 */     MBlockDecoderUtils.saveMvs(this.di, mBlock.x, mbX, mbY);
/*     */     
/*  83 */     int qp1 = calcQpChroma(this.s.qp, this.s.chromaQpOffset[0]);
/*  84 */     int qp2 = calcQpChroma(this.s.qp, this.s.chromaQpOffset[1]);
/*     */     
/*  86 */     decodeChromaResidual(mBlock, leftAvailable, topAvailable, mbX, mbY, qp1, qp2);
/*     */     
/*  88 */     this.di.mbQps[1][mbAddr] = qp1;
/*  89 */     this.di.mbQps[2][mbAddr] = qp2;
/*     */     
/*  91 */     MBlockDecoderUtils.mergeResidual(mb, mBlock.ac, mBlock.transform8x8Used ? H264Const.COMP_BLOCK_8x8_LUT : H264Const.COMP_BLOCK_4x4_LUT, mBlock.transform8x8Used ? H264Const.COMP_POS_8x8_LUT : H264Const.COMP_POS_4x4_LUT);
/*     */ 
/*     */     
/*  94 */     MBlockDecoderUtils.collectPredictors(this.s, mb, mbX);
/*     */     
/*  96 */     this.di.mbTypes[mbAddr] = mBlock.curMbType;
/*  97 */     this.di.tr8x8Used[mbAddr] = mBlock.transform8x8Used;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void predict8x8P(MBlock mBlock, Picture[] references, Picture mb, boolean ref0, int mbX, int mbY, boolean leftAvailable, boolean topAvailable, boolean tlAvailable, boolean topRightAvailable, H264Utils.MvList x, H264Const.PartPred[] pp) {
/* 104 */     decodeSubMb8x8(mBlock, 0, mBlock.pb8x8.subMbTypes[0], references, mbX << 6, mbY << 6, this.s.mvTopLeft.getMv(0, 0), this.s.mvTop
/* 105 */         .getMv(mbX << 2, 0), this.s.mvTop.getMv((mbX << 2) + 1, 0), this.s.mvTop.getMv((mbX << 2) + 2, 0), this.s.mvLeft
/* 106 */         .getMv(0, 0), this.s.mvLeft.getMv(1, 0), tlAvailable, topAvailable, topAvailable, leftAvailable, mBlock.x, 0, 1, 4, 5, mBlock.pb8x8.refIdx[0][0], mb, 0, 0);
/*     */ 
/*     */     
/* 109 */     decodeSubMb8x8(mBlock, 1, mBlock.pb8x8.subMbTypes[1], references, (mbX << 6) + 32, mbY << 6, this.s.mvTop
/* 110 */         .getMv((mbX << 2) + 1, 0), this.s.mvTop.getMv((mbX << 2) + 2, 0), this.s.mvTop.getMv((mbX << 2) + 3, 0), this.s.mvTop
/* 111 */         .getMv((mbX << 2) + 4, 0), x.getMv(1, 0), x.getMv(5, 0), topAvailable, topAvailable, topRightAvailable, true, x, 2, 3, 6, 7, mBlock.pb8x8.refIdx[0][1], mb, 8, 0);
/*     */ 
/*     */     
/* 114 */     decodeSubMb8x8(mBlock, 2, mBlock.pb8x8.subMbTypes[2], references, mbX << 6, (mbY << 6) + 32, this.s.mvLeft
/* 115 */         .getMv(1, 0), x.getMv(4, 0), x.getMv(5, 0), x.getMv(6, 0), this.s.mvLeft.getMv(2, 0), this.s.mvLeft
/* 116 */         .getMv(3, 0), leftAvailable, true, true, leftAvailable, x, 8, 9, 12, 13, mBlock.pb8x8.refIdx[0][2], mb, 128, 0);
/*     */ 
/*     */     
/* 119 */     decodeSubMb8x8(mBlock, 3, mBlock.pb8x8.subMbTypes[3], references, (mbX << 6) + 32, (mbY << 6) + 32, x
/* 120 */         .getMv(5, 0), x.getMv(6, 0), x.getMv(7, 0), MBlockDecoderUtils.NULL_VECTOR, x.getMv(9, 0), x.getMv(13, 0), true, true, false, true, x, 10, 11, 14, 15, mBlock.pb8x8.refIdx[0][3], mb, 136, 0);
/*     */ 
/*     */     
/* 123 */     for (int i = 0; i < 4; i++) {
/*     */       
/* 125 */       int blk4x4 = H264Const.BLK8x8_BLOCKS[i][0];
/* 126 */       PredictionMerger.weightPrediction(this.sh, x.mv0R(blk4x4), 0, mb.getPlaneData(0), H264Const.BLK_8x8_MB_OFF_LUMA[i], 16, 8, 8, mb
/* 127 */           .getPlaneData(0));
/*     */     } 
/*     */     
/* 130 */     MBlockDecoderUtils.savePrediction8x8(this.s, mbX, x);
/* 131 */     Arrays.fill((Object[])pp, H264Const.PartPred.L0);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private void predict8x8B(MBlock mBlock, Frame[][] refs, Picture mb, boolean ref0, int mbX, int mbY, boolean leftAvailable, boolean topAvailable, boolean tlAvailable, boolean topRightAvailable, H264Utils.MvList x, H264Const.PartPred[] p) {
/*     */     int j;
/* 138 */     for (j = 0; j < 4; j++) {
/* 139 */       p[j] = H264Const.bPartPredModes[mBlock.pb8x8.subMbTypes[j]];
/*     */     }
/*     */     
/* 142 */     for (j = 0; j < 4; j++) {
/* 143 */       if (p[j] == H264Const.PartPred.Direct) {
/* 144 */         this.bDirectDecoder.predictBDirect(refs, mbX, mbY, leftAvailable, topAvailable, tlAvailable, topRightAvailable, x, p, mb, H264Const.ARRAY[j]);
/*     */       }
/*     */     } 
/*     */     
/* 148 */     for (int list = 0; list < 2; list++) {
/* 149 */       if (H264Const.usesList(H264Const.bPartPredModes[mBlock.pb8x8.subMbTypes[0]], list)) {
/* 150 */         decodeSubMb8x8(mBlock, 0, H264Const.bSubMbTypes[mBlock.pb8x8.subMbTypes[0]], (Picture[])refs[list], mbX << 6, mbY << 6, this.s.mvTopLeft
/* 151 */             .getMv(0, list), this.s.mvTop.getMv(mbX << 2, list), this.s.mvTop.getMv((mbX << 2) + 1, list), this.s.mvTop
/* 152 */             .getMv((mbX << 2) + 2, list), this.s.mvLeft.getMv(0, list), this.s.mvLeft.getMv(1, list), tlAvailable, topAvailable, topAvailable, leftAvailable, x, 0, 1, 4, 5, mBlock.pb8x8.refIdx[list][0], this.mbb[list], 0, list);
/*     */       }
/*     */ 
/*     */       
/* 156 */       if (H264Const.usesList(H264Const.bPartPredModes[mBlock.pb8x8.subMbTypes[1]], list)) {
/* 157 */         decodeSubMb8x8(mBlock, 1, H264Const.bSubMbTypes[mBlock.pb8x8.subMbTypes[1]], (Picture[])refs[list], (mbX << 6) + 32, mbY << 6, this.s.mvTop
/* 158 */             .getMv((mbX << 2) + 1, list), this.s.mvTop.getMv((mbX << 2) + 2, list), this.s.mvTop
/* 159 */             .getMv((mbX << 2) + 3, list), this.s.mvTop.getMv((mbX << 2) + 4, list), x.getMv(1, list), x
/* 160 */             .getMv(5, list), topAvailable, topAvailable, topRightAvailable, true, x, 2, 3, 6, 7, mBlock.pb8x8.refIdx[list][1], this.mbb[list], 8, list);
/*     */       }
/*     */ 
/*     */       
/* 164 */       if (H264Const.usesList(H264Const.bPartPredModes[mBlock.pb8x8.subMbTypes[2]], list)) {
/* 165 */         decodeSubMb8x8(mBlock, 2, H264Const.bSubMbTypes[mBlock.pb8x8.subMbTypes[2]], (Picture[])refs[list], mbX << 6, (mbY << 6) + 32, this.s.mvLeft
/* 166 */             .getMv(1, list), x.getMv(4, list), x.getMv(5, list), x.getMv(6, list), this.s.mvLeft
/* 167 */             .getMv(2, list), this.s.mvLeft.getMv(3, list), leftAvailable, true, true, leftAvailable, x, 8, 9, 12, 13, mBlock.pb8x8.refIdx[list][2], this.mbb[list], 128, list);
/*     */       }
/*     */ 
/*     */       
/* 171 */       if (H264Const.usesList(H264Const.bPartPredModes[mBlock.pb8x8.subMbTypes[3]], list)) {
/* 172 */         decodeSubMb8x8(mBlock, 3, H264Const.bSubMbTypes[mBlock.pb8x8.subMbTypes[3]], (Picture[])refs[list], (mbX << 6) + 32, (mbY << 6) + 32, x
/* 173 */             .getMv(5, list), x.getMv(6, list), x.getMv(7, list), MBlockDecoderUtils.NULL_VECTOR, x
/* 174 */             .getMv(9, list), x.getMv(13, list), true, true, false, true, x, 10, 11, 14, 15, mBlock.pb8x8.refIdx[list][3], this.mbb[list], 136, list);
/*     */       }
/*     */     } 
/*     */ 
/*     */     
/* 179 */     for (int i = 0; i < 4; i++) {
/* 180 */       int blk4x4 = H264Const.BLK8x8_BLOCKS[i][0];
/* 181 */       PredictionMerger.mergePrediction(this.sh, x.mv0R(blk4x4), x.mv1R(blk4x4), H264Const.bPartPredModes[mBlock.pb8x8.subMbTypes[i]], 0, this.mbb[0]
/* 182 */           .getPlaneData(0), this.mbb[1].getPlaneData(0), H264Const.BLK_8x8_MB_OFF_LUMA[i], 16, 8, 8, mb
/* 183 */           .getPlaneData(0), refs, this.poc);
/*     */     } 
/*     */     
/* 186 */     MBlockDecoderUtils.savePrediction8x8(this.s, mbX, x);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void decodeSubMb8x8(MBlock mBlock, int partNo, int subMbType, Picture[] references, int offX, int offY, int tl, int t0, int t1, int tr, int l0, int l1, boolean tlAvb, boolean tAvb, boolean trAvb, boolean lAvb, H264Utils.MvList x, int i00, int i01, int i10, int i11, int refIdx, Picture mb, int off, int list) {
/* 193 */     switch (subMbType) {
/*     */       case 3:
/* 195 */         decodeSub4x4(mBlock, partNo, references, offX, offY, tl, t0, t1, tr, l0, l1, tlAvb, tAvb, trAvb, lAvb, x, i00, i01, i10, i11, refIdx, mb, off, list);
/*     */         break;
/*     */       
/*     */       case 2:
/* 199 */         decodeSub4x8(mBlock, partNo, references, offX, offY, tl, t0, t1, tr, l0, tlAvb, tAvb, trAvb, lAvb, x, i00, i01, i10, i11, refIdx, mb, off, list);
/*     */         break;
/*     */       
/*     */       case 1:
/* 203 */         decodeSub8x4(mBlock, partNo, references, offX, offY, tl, t0, tr, l0, l1, tlAvb, tAvb, trAvb, lAvb, x, i00, i01, i10, i11, refIdx, mb, off, list);
/*     */         break;
/*     */       
/*     */       case 0:
/* 207 */         decodeSub8x8(mBlock, partNo, references, offX, offY, tl, t0, tr, l0, tlAvb, tAvb, trAvb, lAvb, x, i00, i01, i10, i11, refIdx, mb, off, list);
/*     */         break;
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void decodeSub8x8(MBlock mBlock, int partNo, Picture[] references, int offX, int offY, int tl, int t0, int tr, int l0, boolean tlAvb, boolean tAvb, boolean trAvb, boolean lAvb, H264Utils.MvList x, int i00, int i01, int i10, int i11, int refIdx, Picture mb, int off, int list) {
/* 216 */     int mvpX = MBlockDecoderUtils.calcMVPredictionMedian(l0, t0, tr, tl, lAvb, tAvb, trAvb, tlAvb, refIdx, 0);
/* 217 */     int mvpY = MBlockDecoderUtils.calcMVPredictionMedian(l0, t0, tr, tl, lAvb, tAvb, trAvb, tlAvb, refIdx, 1);
/*     */     
/* 219 */     int mv = H264Utils.Mv.packMv(mBlock.pb8x8.mvdX1[list][partNo] + mvpX, mBlock.pb8x8.mvdY1[list][partNo] + mvpY, refIdx);
/*     */     
/* 221 */     x.setMv(i00, list, mv);
/* 222 */     x.setMv(i01, list, mv);
/* 223 */     x.setMv(i10, list, mv);
/* 224 */     x.setMv(i11, list, mv);
/*     */     
/* 226 */     MBlockDecoderUtils.debugPrint(new Object[] { "MVP: (%d, %d), MVD: (%d, %d), MV: (%d,%d,%d)", Integer.valueOf(mvpX), Integer.valueOf(mvpY), Integer.valueOf(mBlock.pb8x8.mvdX1[list][partNo]), 
/* 227 */           Integer.valueOf(mBlock.pb8x8.mvdY1[list][partNo]), Integer.valueOf(H264Utils.Mv.mvX(mv)), Integer.valueOf(H264Utils.Mv.mvY(mv)), Integer.valueOf(refIdx) });
/*     */     
/* 229 */     this.interpolator.getBlockLuma(references[refIdx], mb, off, offX + H264Utils.Mv.mvX(mv), offY + H264Utils.Mv.mvY(mv), 8, 8);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void decodeSub8x4(MBlock mBlock, int partNo, Picture[] references, int offX, int offY, int tl, int t0, int tr, int l0, int l1, boolean tlAvb, boolean tAvb, boolean trAvb, boolean lAvb, H264Utils.MvList x, int i00, int i01, int i10, int i11, int refIdx, Picture mb, int off, int list) {
/* 236 */     int mvpX1 = MBlockDecoderUtils.calcMVPredictionMedian(l0, t0, tr, tl, lAvb, tAvb, trAvb, tlAvb, refIdx, 0);
/* 237 */     int mvpY1 = MBlockDecoderUtils.calcMVPredictionMedian(l0, t0, tr, tl, lAvb, tAvb, trAvb, tlAvb, refIdx, 1);
/*     */ 
/*     */     
/* 240 */     int mv1 = H264Utils.Mv.packMv(mBlock.pb8x8.mvdX1[list][partNo] + mvpX1, mBlock.pb8x8.mvdY1[list][partNo] + mvpY1, refIdx);
/* 241 */     x.setMv(i00, list, mv1);
/* 242 */     x.setMv(i01, list, mv1);
/*     */     
/* 244 */     MBlockDecoderUtils.debugPrint(new Object[] { "MVP: (%d, %d), MVD: (%d, %d), MV: (%d,%d,%d)", Integer.valueOf(mvpX1), Integer.valueOf(mvpY1), Integer.valueOf(mBlock.pb8x8.mvdX1[list][partNo]), 
/* 245 */           Integer.valueOf(mBlock.pb8x8.mvdY1[list][partNo]), Integer.valueOf(H264Utils.Mv.mvX(mv1)), Integer.valueOf(H264Utils.Mv.mvY(mv1)), Integer.valueOf(refIdx) });
/*     */     
/* 247 */     int mvpX2 = MBlockDecoderUtils.calcMVPredictionMedian(l1, mv1, MBlockDecoderUtils.NULL_VECTOR, l0, lAvb, true, false, lAvb, refIdx, 0);
/* 248 */     int mvpY2 = MBlockDecoderUtils.calcMVPredictionMedian(l1, mv1, MBlockDecoderUtils.NULL_VECTOR, l0, lAvb, true, false, lAvb, refIdx, 1);
/*     */     
/* 250 */     int mv2 = H264Utils.Mv.packMv(mBlock.pb8x8.mvdX2[list][partNo] + mvpX2, mBlock.pb8x8.mvdY2[list][partNo] + mvpY2, refIdx);
/* 251 */     x.setMv(i10, list, mv2);
/* 252 */     x.setMv(i11, list, mv2);
/*     */     
/* 254 */     MBlockDecoderUtils.debugPrint(new Object[] { "MVP: (%d, %d), MVD: (%d, %d), MV: (%d,%d,%d)", Integer.valueOf(mvpX2), Integer.valueOf(mvpY2), Integer.valueOf(mBlock.pb8x8.mvdX2[list][partNo]), 
/* 255 */           Integer.valueOf(mBlock.pb8x8.mvdY2[list][partNo]), Integer.valueOf(H264Utils.Mv.mvX(mv2)), Integer.valueOf(H264Utils.Mv.mvY(mv2)), Integer.valueOf(refIdx) });
/*     */     
/* 257 */     this.interpolator.getBlockLuma(references[refIdx], mb, off, offX + H264Utils.Mv.mvX(mv1), offY + H264Utils.Mv.mvY(mv1), 8, 4);
/* 258 */     this.interpolator.getBlockLuma(references[refIdx], mb, off + mb.getWidth() * 4, offX + H264Utils.Mv.mvX(mv2), offY + 
/* 259 */         H264Utils.Mv.mvY(mv2) + 16, 8, 4);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void decodeSub4x8(MBlock mBlock, int partNo, Picture[] references, int offX, int offY, int tl, int t0, int t1, int tr, int l0, boolean tlAvb, boolean tAvb, boolean trAvb, boolean lAvb, H264Utils.MvList x, int i00, int i01, int i10, int i11, int refIdx, Picture mb, int off, int list) {
/* 266 */     int mvpX1 = MBlockDecoderUtils.calcMVPredictionMedian(l0, t0, t1, tl, lAvb, tAvb, tAvb, tlAvb, refIdx, 0);
/* 267 */     int mvpY1 = MBlockDecoderUtils.calcMVPredictionMedian(l0, t0, t1, tl, lAvb, tAvb, tAvb, tlAvb, refIdx, 1);
/*     */     
/* 269 */     int mv1 = H264Utils.Mv.packMv(mBlock.pb8x8.mvdX1[list][partNo] + mvpX1, mBlock.pb8x8.mvdY1[list][partNo] + mvpY1, refIdx);
/* 270 */     x.setMv(i00, list, mv1);
/* 271 */     x.setMv(i10, list, mv1);
/*     */     
/* 273 */     MBlockDecoderUtils.debugPrint(new Object[] { "MVP: (%d, %d), MVD: (%d, %d), MV: (%d,%d,%d)", Integer.valueOf(mvpX1), Integer.valueOf(mvpY1), Integer.valueOf(mBlock.pb8x8.mvdX1[list][partNo]), 
/* 274 */           Integer.valueOf(mBlock.pb8x8.mvdY1[list][partNo]), Integer.valueOf(H264Utils.Mv.mvX(mv1)), Integer.valueOf(H264Utils.Mv.mvY(mv1)), Integer.valueOf(refIdx) });
/*     */     
/* 276 */     int mvpX2 = MBlockDecoderUtils.calcMVPredictionMedian(mv1, t1, tr, t0, true, tAvb, trAvb, tAvb, refIdx, 0);
/* 277 */     int mvpY2 = MBlockDecoderUtils.calcMVPredictionMedian(mv1, t1, tr, t0, true, tAvb, trAvb, tAvb, refIdx, 1);
/*     */     
/* 279 */     int mv2 = H264Utils.Mv.packMv(mBlock.pb8x8.mvdX2[list][partNo] + mvpX2, mBlock.pb8x8.mvdY2[list][partNo] + mvpY2, refIdx);
/*     */     
/* 281 */     x.setMv(i01, list, mv2);
/* 282 */     x.setMv(i11, list, mv2);
/*     */     
/* 284 */     MBlockDecoderUtils.debugPrint(new Object[] { "MVP: (%d, %d), MVD: (%d, %d), MV: (%d,%d,%d)", Integer.valueOf(mvpX2), Integer.valueOf(mvpY2), Integer.valueOf(mBlock.pb8x8.mvdX2[list][partNo]), 
/* 285 */           Integer.valueOf(mBlock.pb8x8.mvdY2[list][partNo]), Integer.valueOf(H264Utils.Mv.mvX(mv2)), Integer.valueOf(H264Utils.Mv.mvY(mv2)), Integer.valueOf(refIdx) });
/*     */     
/* 287 */     this.interpolator.getBlockLuma(references[refIdx], mb, off, offX + H264Utils.Mv.mvX(mv1), offY + H264Utils.Mv.mvY(mv1), 4, 8);
/* 288 */     this.interpolator.getBlockLuma(references[refIdx], mb, off + 4, offX + H264Utils.Mv.mvX(mv2) + 16, offY + H264Utils.Mv.mvY(mv2), 4, 8);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void decodeSub4x4(MBlock mBlock, int partNo, Picture[] references, int offX, int offY, int tl, int t0, int t1, int tr, int l0, int l1, boolean tlAvb, boolean tAvb, boolean trAvb, boolean lAvb, H264Utils.MvList x, int i00, int i01, int i10, int i11, int refIdx, Picture mb, int off, int list) {
/* 295 */     int mvpX1 = MBlockDecoderUtils.calcMVPredictionMedian(l0, t0, t1, tl, lAvb, tAvb, tAvb, tlAvb, refIdx, 0);
/* 296 */     int mvpY1 = MBlockDecoderUtils.calcMVPredictionMedian(l0, t0, t1, tl, lAvb, tAvb, tAvb, tlAvb, refIdx, 1);
/*     */     
/* 298 */     int mv1 = H264Utils.Mv.packMv(mBlock.pb8x8.mvdX1[list][partNo] + mvpX1, mBlock.pb8x8.mvdY1[list][partNo] + mvpY1, refIdx);
/* 299 */     x.setMv(i00, list, mv1);
/* 300 */     MBlockDecoderUtils.debugPrint(new Object[] { "MVP: (%d, %d), MVD: (%d, %d), MV: (%d,%d,%d)", Integer.valueOf(mvpX1), Integer.valueOf(mvpY1), Integer.valueOf(mBlock.pb8x8.mvdX1[list][partNo]), 
/* 301 */           Integer.valueOf(mBlock.pb8x8.mvdY1[list][partNo]), Integer.valueOf(H264Utils.Mv.mvX(mv1)), Integer.valueOf(H264Utils.Mv.mvY(mv1)), Integer.valueOf(refIdx) });
/*     */     
/* 303 */     int mvpX2 = MBlockDecoderUtils.calcMVPredictionMedian(mv1, t1, tr, t0, true, tAvb, trAvb, tAvb, refIdx, 0);
/* 304 */     int mvpY2 = MBlockDecoderUtils.calcMVPredictionMedian(mv1, t1, tr, t0, true, tAvb, trAvb, tAvb, refIdx, 1);
/*     */     
/* 306 */     int mv2 = H264Utils.Mv.packMv(mBlock.pb8x8.mvdX2[list][partNo] + mvpX2, mBlock.pb8x8.mvdY2[list][partNo] + mvpY2, refIdx);
/* 307 */     x.setMv(i01, list, mv2);
/*     */     
/* 309 */     MBlockDecoderUtils.debugPrint(new Object[] { "MVP: (%d, %d), MVD: (%d, %d), MV: (%d,%d,%d)", Integer.valueOf(mvpX2), Integer.valueOf(mvpY2), Integer.valueOf(mBlock.pb8x8.mvdX2[list][partNo]), 
/* 310 */           Integer.valueOf(mBlock.pb8x8.mvdY2[list][partNo]), Integer.valueOf(H264Utils.Mv.mvX(mv2)), Integer.valueOf(H264Utils.Mv.mvY(mv2)), Integer.valueOf(refIdx) });
/*     */     
/* 312 */     int mvpX3 = MBlockDecoderUtils.calcMVPredictionMedian(l1, mv1, mv2, l0, lAvb, true, true, lAvb, refIdx, 0);
/* 313 */     int mvpY3 = MBlockDecoderUtils.calcMVPredictionMedian(l1, mv1, mv2, l0, lAvb, true, true, lAvb, refIdx, 1);
/*     */     
/* 315 */     int mv3 = H264Utils.Mv.packMv(mBlock.pb8x8.mvdX3[list][partNo] + mvpX3, mBlock.pb8x8.mvdY3[list][partNo] + mvpY3, refIdx);
/* 316 */     x.setMv(i10, list, mv3);
/*     */     
/* 318 */     MBlockDecoderUtils.debugPrint(new Object[] { "MVP: (%d, %d), MVD: (%d, %d), MV: (%d,%d,%d)", Integer.valueOf(mvpX3), Integer.valueOf(mvpY3), Integer.valueOf(mBlock.pb8x8.mvdX3[list][partNo]), 
/* 319 */           Integer.valueOf(mBlock.pb8x8.mvdY3[list][partNo]), Integer.valueOf(H264Utils.Mv.mvX(mv3)), Integer.valueOf(H264Utils.Mv.mvY(mv3)), Integer.valueOf(refIdx) });
/*     */     
/* 321 */     int mvpX4 = MBlockDecoderUtils.calcMVPredictionMedian(mv3, mv2, MBlockDecoderUtils.NULL_VECTOR, mv1, true, true, false, true, refIdx, 0);
/* 322 */     int mvpY4 = MBlockDecoderUtils.calcMVPredictionMedian(mv3, mv2, MBlockDecoderUtils.NULL_VECTOR, mv1, true, true, false, true, refIdx, 1);
/*     */     
/* 324 */     int mv4 = H264Utils.Mv.packMv(mBlock.pb8x8.mvdX4[list][partNo] + mvpX4, mBlock.pb8x8.mvdY4[list][partNo] + mvpY4, refIdx);
/* 325 */     x.setMv(i11, list, mv4);
/*     */     
/* 327 */     MBlockDecoderUtils.debugPrint(new Object[] { "MVP: (%d, %d), MVD: (%d, %d), MV: (%d,%d,%d)", Integer.valueOf(mvpX4), Integer.valueOf(mvpY4), Integer.valueOf(mBlock.pb8x8.mvdX4[list][partNo]), 
/* 328 */           Integer.valueOf(mBlock.pb8x8.mvdY4[list][partNo]), Integer.valueOf(H264Utils.Mv.mvX(mv4)), Integer.valueOf(H264Utils.Mv.mvY(mv4)), Integer.valueOf(refIdx) });
/*     */     
/* 330 */     this.interpolator.getBlockLuma(references[refIdx], mb, off, offX + H264Utils.Mv.mvX(mv1), offY + H264Utils.Mv.mvY(mv1), 4, 4);
/* 331 */     this.interpolator.getBlockLuma(references[refIdx], mb, off + 4, offX + H264Utils.Mv.mvX(mv2) + 16, offY + H264Utils.Mv.mvY(mv2), 4, 4);
/* 332 */     this.interpolator.getBlockLuma(references[refIdx], mb, off + mb.getWidth() * 4, offX + H264Utils.Mv.mvX(mv3), offY + H264Utils.Mv.mvY(mv3) + 16, 4, 4);
/*     */     
/* 334 */     this.interpolator.getBlockLuma(references[refIdx], mb, off + mb.getWidth() * 4 + 4, offX + H264Utils.Mv.mvX(mv4) + 16, offY + 
/* 335 */         H264Utils.Mv.mvY(mv4) + 16, 4, 4);
/*     */   }
/*     */ }


/* Location:              C:\Users\rapha\Downloads\aurora.jar!\META-INF\jars\jcodec-0.2.5.jar!\org\jcodec\codecs\h264\decode\MBlockDecoderInter8x8.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */