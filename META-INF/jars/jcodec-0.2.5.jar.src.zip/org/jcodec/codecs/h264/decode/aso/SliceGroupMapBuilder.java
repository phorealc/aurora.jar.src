/*     */ package org.jcodec.codecs.h264.decode.aso;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class SliceGroupMapBuilder
/*     */ {
/*     */   public static int[] buildInterleavedMap(int picWidthInMbs, int picHeightInMbs, int[] runLength) {
/*  28 */     int numSliceGroups = runLength.length;
/*  29 */     int picSizeInMbs = picWidthInMbs * picHeightInMbs;
/*  30 */     int[] groups = new int[picSizeInMbs];
/*     */     
/*  32 */     int i = 0;
/*     */     do {
/*  34 */       for (int iGroup = 0; iGroup < numSliceGroups && i < picSizeInMbs; i += runLength[iGroup++]) {
/*  35 */         for (int j = 0; j < runLength[iGroup] && i + j < picSizeInMbs; j++) {
/*  36 */           groups[i + j] = iGroup;
/*     */         }
/*     */       } 
/*  39 */     } while (i < picSizeInMbs);
/*     */     
/*  41 */     return groups;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static int[] buildDispersedMap(int picWidthInMbs, int picHeightInMbs, int numSliceGroups) {
/*  57 */     int picSizeInMbs = picWidthInMbs * picHeightInMbs;
/*  58 */     int[] groups = new int[picSizeInMbs];
/*     */     
/*  60 */     for (int i = 0; i < picSizeInMbs; i++) {
/*  61 */       int group = (i % picWidthInMbs + i / picWidthInMbs * numSliceGroups / 2) % numSliceGroups;
/*  62 */       groups[i] = group;
/*     */     } 
/*     */     
/*  65 */     return groups;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static int[] buildForegroundMap(int picWidthInMbs, int picHeightInMbs, int numSliceGroups, int[] topLeftAddr, int[] bottomRightAddr) {
/*  90 */     int picSizeInMbs = picWidthInMbs * picHeightInMbs;
/*  91 */     int[] groups = new int[picSizeInMbs];
/*     */     
/*  93 */     for (int i = 0; i < picSizeInMbs; i++) {
/*  94 */       groups[i] = numSliceGroups - 1;
/*     */     }
/*  96 */     int tot = 0;
/*  97 */     for (int iGroup = numSliceGroups - 2; iGroup >= 0; iGroup--) {
/*     */       
/*  99 */       int yTopLeft = topLeftAddr[iGroup] / picWidthInMbs;
/* 100 */       int xTopLeft = topLeftAddr[iGroup] % picWidthInMbs;
/* 101 */       int yBottomRight = bottomRightAddr[iGroup] / picWidthInMbs;
/* 102 */       int xBottomRight = bottomRightAddr[iGroup] % picWidthInMbs;
/*     */       
/* 104 */       int sz = (yBottomRight - yTopLeft + 1) * (xBottomRight - xTopLeft + 1);
/* 105 */       tot += sz;
/*     */       
/* 107 */       int ind = 0;
/* 108 */       for (int y = yTopLeft; y <= yBottomRight; y++) {
/* 109 */         for (int x = xTopLeft; x <= xBottomRight; x++) {
/* 110 */           int mbAddr = y * picWidthInMbs + x;
/* 111 */           groups[mbAddr] = iGroup;
/*     */         } 
/*     */       } 
/*     */     } 
/* 115 */     return groups;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static int[] buildBoxOutMap(int picWidthInMbs, int picHeightInMbs, boolean changeDirection, int numberOfMbsInBox) {
/* 133 */     int picSizeInMbs = picWidthInMbs * picHeightInMbs;
/* 134 */     int[] groups = new int[picSizeInMbs];
/* 135 */     int changeDirectionInt = changeDirection ? 1 : 0;
/*     */     
/* 137 */     for (int i = 0; i < picSizeInMbs; i++) {
/* 138 */       groups[i] = 1;
/*     */     }
/* 140 */     int x = (picWidthInMbs - changeDirectionInt) / 2;
/* 141 */     int y = (picHeightInMbs - changeDirectionInt) / 2;
/* 142 */     int leftBound = x;
/* 143 */     int topBound = y;
/* 144 */     int rightBound = x;
/* 145 */     int bottomBound = y;
/* 146 */     int xDir = changeDirectionInt - 1;
/* 147 */     int yDir = changeDirectionInt;
/*     */     
/* 149 */     boolean mapUnitVacant = false; int k;
/* 150 */     for (k = 0; k < numberOfMbsInBox; k += mapUnitVacant ? 1 : 0) {
/* 151 */       int mbAddr = y * picWidthInMbs + x;
/* 152 */       mapUnitVacant = (groups[mbAddr] == 1);
/* 153 */       if (mapUnitVacant) {
/* 154 */         groups[mbAddr] = 0;
/*     */       }
/* 156 */       if (xDir == -1 && x == leftBound) {
/* 157 */         leftBound = Max(leftBound - 1, 0);
/* 158 */         x = leftBound;
/* 159 */         xDir = 0;
/* 160 */         yDir = 2 * changeDirectionInt - 1;
/* 161 */       } else if (xDir == 1 && x == rightBound) {
/* 162 */         rightBound = Min(rightBound + 1, picWidthInMbs - 1);
/* 163 */         x = rightBound;
/* 164 */         xDir = 0;
/* 165 */         yDir = 1 - 2 * changeDirectionInt;
/* 166 */       } else if (yDir == -1 && y == topBound) {
/* 167 */         topBound = Max(topBound - 1, 0);
/* 168 */         y = topBound;
/* 169 */         xDir = 1 - 2 * changeDirectionInt;
/* 170 */         yDir = 0;
/* 171 */       } else if (yDir == 1 && y == bottomBound) {
/* 172 */         bottomBound = Min(bottomBound + 1, picHeightInMbs - 1);
/* 173 */         y = bottomBound;
/* 174 */         xDir = 2 * changeDirectionInt - 1;
/* 175 */         yDir = 0;
/*     */       } else {
/* 177 */         x += xDir;
/* 178 */         y += yDir;
/*     */       } 
/*     */     } 
/*     */     
/* 182 */     return groups;
/*     */   }
/*     */   
/*     */   private static int Min(int i, int j) {
/* 186 */     return (i < j) ? i : j;
/*     */   }
/*     */   
/*     */   private static int Max(int i, int j) {
/* 190 */     return (i > j) ? i : j;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static int[] buildRasterScanMap(int picWidthInMbs, int picHeightInMbs, int sizeOfUpperLeftGroup, boolean changeDirection) {
/* 206 */     int picSizeInMbs = picWidthInMbs * picHeightInMbs;
/* 207 */     int[] groups = new int[picSizeInMbs];
/* 208 */     int changeDirectionInt = changeDirection ? 1 : 0;
/*     */     
/*     */     int i;
/* 211 */     for (i = 0; i < sizeOfUpperLeftGroup; i++) {
/* 212 */       groups[i] = changeDirectionInt;
/*     */     }
/*     */     
/* 215 */     for (; i < picSizeInMbs; i++) {
/* 216 */       groups[i] = 1 - changeDirectionInt;
/*     */     }
/*     */     
/* 219 */     return groups;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static int[] buildWipeMap(int picWidthInMbs, int picHeightInMbs, int sizeOfUpperLeftGroup, boolean changeDirection) {
/* 234 */     int picSizeInMbs = picWidthInMbs * picHeightInMbs;
/* 235 */     int[] groups = new int[picSizeInMbs];
/* 236 */     int changeDirectionInt = changeDirection ? 1 : 0;
/*     */     
/* 238 */     int k = 0;
/* 239 */     for (int j = 0; j < picWidthInMbs; j++) {
/* 240 */       for (int i = 0; i < picHeightInMbs; i++) {
/* 241 */         int mbAddr = i * picWidthInMbs + j;
/* 242 */         if (k++ < sizeOfUpperLeftGroup) {
/* 243 */           groups[mbAddr] = changeDirectionInt;
/*     */         } else {
/* 245 */           groups[mbAddr] = 1 - changeDirectionInt;
/*     */         } 
/*     */       } 
/*     */     } 
/*     */     
/* 250 */     return groups;
/*     */   }
/*     */ }


/* Location:              C:\Users\rapha\Downloads\aurora.jar!\META-INF\jars\jcodec-0.2.5.jar!\org\jcodec\codecs\h264\decode\aso\SliceGroupMapBuilder.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */