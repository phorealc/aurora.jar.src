/*     */ package org.jcodec.codecs.h264.decode;
/*     */ 
/*     */ import org.jcodec.common.Preconditions;
/*     */ import org.jcodec.common.tools.MathUtil;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class Intra8x8PredictionBuilder
/*     */ {
/*  22 */   byte[] topBuf = new byte[16];
/*  23 */   byte[] leftBuf = new byte[8];
/*  24 */   byte[] genBuf = new byte[24];
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void predictWithMode(int mode, int[] residual, boolean leftAvailable, boolean topAvailable, boolean topLeftAvailable, boolean topRightAvailable, byte[] leftRow, byte[] topLine, byte[] topLeft, int mbOffX, int blkX, int blkY, byte[] pixOut) {
/*  30 */     switch (mode) {
/*     */       case 0:
/*  32 */         Preconditions.checkState(topAvailable, "");
/*  33 */         predictVertical(residual, topLeftAvailable, topRightAvailable, topLeft, topLine, mbOffX, blkX, blkY, pixOut);
/*     */         break;
/*     */       case 1:
/*  36 */         Preconditions.checkState(leftAvailable, "");
/*  37 */         predictHorizontal(residual, topLeftAvailable, topLeft, leftRow, mbOffX, blkX, blkY, pixOut);
/*     */         break;
/*     */       case 2:
/*  40 */         predictDC(residual, topLeftAvailable, topRightAvailable, leftAvailable, topAvailable, topLeft, leftRow, topLine, mbOffX, blkX, blkY, pixOut);
/*     */         break;
/*     */       
/*     */       case 3:
/*  44 */         Preconditions.checkState(topAvailable, "");
/*  45 */         predictDiagonalDownLeft(residual, topLeftAvailable, topAvailable, topRightAvailable, topLeft, topLine, mbOffX, blkX, blkY, pixOut);
/*     */         break;
/*     */       
/*     */       case 4:
/*  49 */         Preconditions.checkState((topAvailable && leftAvailable && topLeftAvailable), "");
/*  50 */         predictDiagonalDownRight(residual, topRightAvailable, topLeft, leftRow, topLine, mbOffX, blkX, blkY, pixOut);
/*     */         break;
/*     */       case 5:
/*  53 */         Preconditions.checkState((topAvailable && leftAvailable && topLeftAvailable), "");
/*  54 */         predictVerticalRight(residual, topRightAvailable, topLeft, leftRow, topLine, mbOffX, blkX, blkY, pixOut);
/*     */         break;
/*     */       case 6:
/*  57 */         Preconditions.checkState((topAvailable && leftAvailable && topLeftAvailable), "");
/*  58 */         predictHorizontalDown(residual, topRightAvailable, topLeft, leftRow, topLine, mbOffX, blkX, blkY, pixOut);
/*     */         break;
/*     */       case 7:
/*  61 */         Preconditions.checkState(topAvailable, "");
/*  62 */         predictVerticalLeft(residual, topLeftAvailable, topRightAvailable, topLeft, topLine, mbOffX, blkX, blkY, pixOut);
/*     */         break;
/*     */       
/*     */       case 8:
/*  66 */         Preconditions.checkState(leftAvailable, "");
/*  67 */         predictHorizontalUp(residual, topLeftAvailable, topLeft, leftRow, mbOffX, blkX, blkY, pixOut);
/*     */         break;
/*     */     } 
/*     */     
/*  71 */     int oo1 = mbOffX + blkX;
/*  72 */     int off1 = (blkY << 4) + blkX + 7;
/*     */     
/*  74 */     topLeft[blkY >> 2] = topLine[oo1 + 7];
/*     */     
/*  76 */     for (int i = 0; i < 8; i++) {
/*  77 */       leftRow[blkY + i] = pixOut[off1 + (i << 4)];
/*     */     }
/*  79 */     int off2 = (blkY << 4) + blkX + 112;
/*  80 */     for (int j = 0; j < 8; j++) {
/*  81 */       topLine[oo1 + j] = pixOut[off2 + j];
/*     */     }
/*  83 */     topLeft[(blkY >> 2) + 1] = leftRow[blkY + 3];
/*     */   }
/*     */ 
/*     */   
/*     */   private void interpolateTop(boolean topLeftAvailable, boolean topRightAvailable, byte[] topLeft, byte[] topLine, int blkX, int blkY, byte[] out) {
/*  88 */     int a = topLeftAvailable ? topLeft[blkY >> 2] : topLine[blkX];
/*     */     
/*  90 */     out[0] = (byte)(a + (topLine[blkX] << 1) + topLine[blkX + 1] + 2 >> 2);
/*     */     int i;
/*  92 */     for (i = 1; i < 7; i++) {
/*  93 */       out[i] = (byte)(topLine[blkX + i - 1] + (topLine[blkX + i] << 1) + topLine[blkX + i + 1] + 2 >> 2);
/*     */     }
/*  95 */     if (topRightAvailable) {
/*  96 */       for (; i < 15; i++)
/*  97 */         out[i] = (byte)(topLine[blkX + i - 1] + (topLine[blkX + i] << 1) + topLine[blkX + i + 1] + 2 >> 2); 
/*  98 */       out[15] = (byte)(topLine[blkX + 14] + (topLine[blkX + 15] << 1) + topLine[blkX + 15] + 2 >> 2);
/*     */     } else {
/* 100 */       out[7] = (byte)(topLine[blkX + 6] + (topLine[blkX + 7] << 1) + topLine[blkX + 7] + 2 >> 2);
/* 101 */       for (i = 8; i < 16; i++)
/* 102 */         out[i] = topLine[blkX + 7]; 
/*     */     } 
/*     */   }
/*     */   
/*     */   private void interpolateLeft(boolean topLeftAvailable, byte[] topLeft, byte[] leftRow, int blkY, byte[] out) {
/* 107 */     int a = topLeftAvailable ? topLeft[blkY >> 2] : leftRow[0];
/*     */     
/* 109 */     out[0] = (byte)(a + (leftRow[blkY] << 1) + leftRow[blkY + 1] + 2 >> 2);
/* 110 */     for (int i = 1; i < 7; i++) {
/* 111 */       out[i] = (byte)(leftRow[blkY + i - 1] + (leftRow[blkY + i] << 1) + leftRow[blkY + i + 1] + 2 >> 2);
/*     */     }
/* 113 */     out[7] = (byte)(leftRow[blkY + 6] + (leftRow[blkY + 7] << 1) + leftRow[blkY + 7] + 2 >> 2);
/*     */   }
/*     */ 
/*     */   
/*     */   private int interpolateTopLeft(boolean topAvailable, boolean leftAvailable, byte[] topLeft, byte[] topLine, byte[] leftRow, int mbOffX, int blkX, int blkY) {
/* 118 */     int a = topLeft[blkY >> 2];
/* 119 */     int b = topAvailable ? topLine[mbOffX + blkX] : a;
/* 120 */     int c = leftAvailable ? leftRow[blkY] : a;
/* 121 */     int aa = a << 1;
/*     */     
/* 123 */     return aa + b + c + 2 >> 2;
/*     */   }
/*     */   
/*     */   public void copyAdd(byte[] pred, int srcOff, int[] residual, int pixOff, int rOff, byte[] out) {
/* 127 */     out[pixOff] = (byte)MathUtil.clip(residual[rOff] + pred[srcOff], -128, 127);
/* 128 */     out[pixOff + 1] = (byte)MathUtil.clip(residual[rOff + 1] + pred[srcOff + 1], -128, 127);
/* 129 */     out[pixOff + 2] = (byte)MathUtil.clip(residual[rOff + 2] + pred[srcOff + 2], -128, 127);
/* 130 */     out[pixOff + 3] = (byte)MathUtil.clip(residual[rOff + 3] + pred[srcOff + 3], -128, 127);
/* 131 */     out[pixOff + 4] = (byte)MathUtil.clip(residual[rOff + 4] + pred[srcOff + 4], -128, 127);
/* 132 */     out[pixOff + 5] = (byte)MathUtil.clip(residual[rOff + 5] + pred[srcOff + 5], -128, 127);
/* 133 */     out[pixOff + 6] = (byte)MathUtil.clip(residual[rOff + 6] + pred[srcOff + 6], -128, 127);
/* 134 */     out[pixOff + 7] = (byte)MathUtil.clip(residual[rOff + 7] + pred[srcOff + 7], -128, 127);
/*     */   }
/*     */   
/*     */   public void fillAdd(int[] residual, int pixOff, int val, byte[] pixOut) {
/* 138 */     int rOff = 0;
/* 139 */     for (int i = 0; i < 8; i++) {
/* 140 */       pixOut[pixOff] = (byte)MathUtil.clip(residual[rOff] + val, -128, 127);
/* 141 */       pixOut[pixOff + 1] = (byte)MathUtil.clip(residual[rOff + 1] + val, -128, 127);
/* 142 */       pixOut[pixOff + 2] = (byte)MathUtil.clip(residual[rOff + 2] + val, -128, 127);
/* 143 */       pixOut[pixOff + 3] = (byte)MathUtil.clip(residual[rOff + 3] + val, -128, 127);
/* 144 */       pixOut[pixOff + 4] = (byte)MathUtil.clip(residual[rOff + 4] + val, -128, 127);
/* 145 */       pixOut[pixOff + 5] = (byte)MathUtil.clip(residual[rOff + 5] + val, -128, 127);
/* 146 */       pixOut[pixOff + 6] = (byte)MathUtil.clip(residual[rOff + 6] + val, -128, 127);
/* 147 */       pixOut[pixOff + 7] = (byte)MathUtil.clip(residual[rOff + 7] + val, -128, 127);
/* 148 */       pixOff += 16;
/* 149 */       rOff += 8;
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public void predictVertical(int[] residual, boolean topLeftAvailable, boolean topRightAvailable, byte[] topLeft, byte[] topLine, int mbOffX, int blkX, int blkY, byte[] pixOut) {
/* 155 */     interpolateTop(topLeftAvailable, topRightAvailable, topLeft, topLine, mbOffX + blkX, blkY, this.topBuf);
/* 156 */     int pixOff = (blkY << 4) + blkX;
/* 157 */     int rOff = 0;
/* 158 */     for (int i = 0; i < 8; i++) {
/* 159 */       pixOut[pixOff] = (byte)MathUtil.clip(residual[rOff] + this.topBuf[0], -128, 127);
/* 160 */       pixOut[pixOff + 1] = (byte)MathUtil.clip(residual[rOff + 1] + this.topBuf[1], -128, 127);
/* 161 */       pixOut[pixOff + 2] = (byte)MathUtil.clip(residual[rOff + 2] + this.topBuf[2], -128, 127);
/* 162 */       pixOut[pixOff + 3] = (byte)MathUtil.clip(residual[rOff + 3] + this.topBuf[3], -128, 127);
/* 163 */       pixOut[pixOff + 4] = (byte)MathUtil.clip(residual[rOff + 4] + this.topBuf[4], -128, 127);
/* 164 */       pixOut[pixOff + 5] = (byte)MathUtil.clip(residual[rOff + 5] + this.topBuf[5], -128, 127);
/* 165 */       pixOut[pixOff + 6] = (byte)MathUtil.clip(residual[rOff + 6] + this.topBuf[6], -128, 127);
/* 166 */       pixOut[pixOff + 7] = (byte)MathUtil.clip(residual[rOff + 7] + this.topBuf[7], -128, 127);
/* 167 */       pixOff += 16;
/* 168 */       rOff += 8;
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public void predictHorizontal(int[] residual, boolean topLeftAvailable, byte[] topLeft, byte[] leftRow, int mbOffX, int blkX, int blkY, byte[] pixOut) {
/* 174 */     interpolateLeft(topLeftAvailable, topLeft, leftRow, blkY, this.leftBuf);
/* 175 */     int pixOff = (blkY << 4) + blkX;
/* 176 */     int rOff = 0;
/* 177 */     for (int i = 0; i < 8; i++) {
/* 178 */       pixOut[pixOff] = (byte)MathUtil.clip(residual[rOff] + this.leftBuf[i], -128, 127);
/* 179 */       pixOut[pixOff + 1] = (byte)MathUtil.clip(residual[rOff + 1] + this.leftBuf[i], -128, 127);
/* 180 */       pixOut[pixOff + 2] = (byte)MathUtil.clip(residual[rOff + 2] + this.leftBuf[i], -128, 127);
/* 181 */       pixOut[pixOff + 3] = (byte)MathUtil.clip(residual[rOff + 3] + this.leftBuf[i], -128, 127);
/* 182 */       pixOut[pixOff + 4] = (byte)MathUtil.clip(residual[rOff + 4] + this.leftBuf[i], -128, 127);
/* 183 */       pixOut[pixOff + 5] = (byte)MathUtil.clip(residual[rOff + 5] + this.leftBuf[i], -128, 127);
/* 184 */       pixOut[pixOff + 6] = (byte)MathUtil.clip(residual[rOff + 6] + this.leftBuf[i], -128, 127);
/* 185 */       pixOut[pixOff + 7] = (byte)MathUtil.clip(residual[rOff + 7] + this.leftBuf[i], -128, 127);
/* 186 */       pixOff += 16;
/* 187 */       rOff += 8;
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void predictDC(int[] residual, boolean topLeftAvailable, boolean topRightAvailable, boolean leftAvailable, boolean topAvailable, byte[] topLeft, byte[] leftRow, byte[] topLine, int mbOffX, int blkX, int blkY, byte[] pixOut) {
/* 194 */     if (topAvailable && leftAvailable) {
/* 195 */       interpolateTop(topLeftAvailable, topRightAvailable, topLeft, topLine, mbOffX + blkX, blkY, this.topBuf);
/* 196 */       interpolateLeft(topLeftAvailable, topLeft, leftRow, blkY, this.leftBuf);
/* 197 */       int sum1 = this.topBuf[0] + this.topBuf[1] + this.topBuf[2] + this.topBuf[3];
/* 198 */       int sum2 = this.topBuf[4] + this.topBuf[5] + this.topBuf[6] + this.topBuf[7];
/* 199 */       int sum3 = this.leftBuf[0] + this.leftBuf[1] + this.leftBuf[2] + this.leftBuf[3];
/* 200 */       int sum4 = this.leftBuf[4] + this.leftBuf[5] + this.leftBuf[6] + this.leftBuf[7];
/* 201 */       fillAdd(residual, (blkY << 4) + blkX, sum1 + sum2 + sum3 + sum4 + 8 >> 4, pixOut);
/* 202 */     } else if (leftAvailable) {
/* 203 */       interpolateLeft(topLeftAvailable, topLeft, leftRow, blkY, this.leftBuf);
/* 204 */       int sum3 = this.leftBuf[0] + this.leftBuf[1] + this.leftBuf[2] + this.leftBuf[3];
/* 205 */       int sum4 = this.leftBuf[4] + this.leftBuf[5] + this.leftBuf[6] + this.leftBuf[7];
/* 206 */       fillAdd(residual, (blkY << 4) + blkX, sum3 + sum4 + 4 >> 3, pixOut);
/* 207 */     } else if (topAvailable) {
/* 208 */       interpolateTop(topLeftAvailable, topRightAvailable, topLeft, topLine, mbOffX + blkX, blkY, this.topBuf);
/* 209 */       int sum1 = this.topBuf[0] + this.topBuf[1] + this.topBuf[2] + this.topBuf[3];
/* 210 */       int sum2 = this.topBuf[4] + this.topBuf[5] + this.topBuf[6] + this.topBuf[7];
/* 211 */       fillAdd(residual, (blkY << 4) + blkX, sum1 + sum2 + 4 >> 3, pixOut);
/*     */     } else {
/* 213 */       fillAdd(residual, (blkY << 4) + blkX, 0, pixOut);
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public void predictDiagonalDownLeft(int[] residual, boolean topLeftAvailable, boolean topAvailable, boolean topRightAvailable, byte[] topLeft, byte[] topLine, int mbOffX, int blkX, int blkY, byte[] pixOut) {
/* 219 */     interpolateTop(topLeftAvailable, topRightAvailable, topLeft, topLine, mbOffX + blkX, blkY, this.topBuf);
/*     */     
/* 221 */     this.genBuf[0] = (byte)(this.topBuf[0] + this.topBuf[2] + (this.topBuf[1] << 1) + 2 >> 2);
/* 222 */     this.genBuf[1] = (byte)(this.topBuf[1] + this.topBuf[3] + (this.topBuf[2] << 1) + 2 >> 2);
/* 223 */     this.genBuf[2] = (byte)(this.topBuf[2] + this.topBuf[4] + (this.topBuf[3] << 1) + 2 >> 2);
/* 224 */     this.genBuf[3] = (byte)(this.topBuf[3] + this.topBuf[5] + (this.topBuf[4] << 1) + 2 >> 2);
/* 225 */     this.genBuf[4] = (byte)(this.topBuf[4] + this.topBuf[6] + (this.topBuf[5] << 1) + 2 >> 2);
/* 226 */     this.genBuf[5] = (byte)(this.topBuf[5] + this.topBuf[7] + (this.topBuf[6] << 1) + 2 >> 2);
/* 227 */     this.genBuf[6] = (byte)(this.topBuf[6] + this.topBuf[8] + (this.topBuf[7] << 1) + 2 >> 2);
/* 228 */     this.genBuf[7] = (byte)(this.topBuf[7] + this.topBuf[9] + (this.topBuf[8] << 1) + 2 >> 2);
/* 229 */     this.genBuf[8] = (byte)(this.topBuf[8] + this.topBuf[10] + (this.topBuf[9] << 1) + 2 >> 2);
/* 230 */     this.genBuf[9] = (byte)(this.topBuf[9] + this.topBuf[11] + (this.topBuf[10] << 1) + 2 >> 2);
/* 231 */     this.genBuf[10] = (byte)(this.topBuf[10] + this.topBuf[12] + (this.topBuf[11] << 1) + 2 >> 2);
/* 232 */     this.genBuf[11] = (byte)(this.topBuf[11] + this.topBuf[13] + (this.topBuf[12] << 1) + 2 >> 2);
/* 233 */     this.genBuf[12] = (byte)(this.topBuf[12] + this.topBuf[14] + (this.topBuf[13] << 1) + 2 >> 2);
/* 234 */     this.genBuf[13] = (byte)(this.topBuf[13] + this.topBuf[15] + (this.topBuf[14] << 1) + 2 >> 2);
/* 235 */     this.genBuf[14] = (byte)(this.topBuf[14] + this.topBuf[15] + (this.topBuf[15] << 1) + 2 >> 2);
/*     */     
/* 237 */     int off = (blkY << 4) + blkX;
/* 238 */     copyAdd(this.genBuf, 0, residual, off, 0, pixOut);
/* 239 */     copyAdd(this.genBuf, 1, residual, off + 16, 8, pixOut);
/* 240 */     copyAdd(this.genBuf, 2, residual, off + 32, 16, pixOut);
/* 241 */     copyAdd(this.genBuf, 3, residual, off + 48, 24, pixOut);
/* 242 */     copyAdd(this.genBuf, 4, residual, off + 64, 32, pixOut);
/* 243 */     copyAdd(this.genBuf, 5, residual, off + 80, 40, pixOut);
/* 244 */     copyAdd(this.genBuf, 6, residual, off + 96, 48, pixOut);
/* 245 */     copyAdd(this.genBuf, 7, residual, off + 112, 56, pixOut);
/*     */   }
/*     */ 
/*     */   
/*     */   public void predictDiagonalDownRight(int[] residual, boolean topRightAvailable, byte[] topLeft, byte[] leftRow, byte[] topLine, int mbOffX, int blkX, int blkY, byte[] pixOut) {
/* 250 */     interpolateTop(true, topRightAvailable, topLeft, topLine, mbOffX + blkX, blkY, this.topBuf);
/* 251 */     interpolateLeft(true, topLeft, leftRow, blkY, this.leftBuf);
/* 252 */     int tl = interpolateTopLeft(true, true, topLeft, topLine, leftRow, mbOffX, blkX, blkY);
/*     */     
/* 254 */     this.genBuf[0] = (byte)(this.leftBuf[7] + this.leftBuf[5] + (this.leftBuf[6] << 1) + 2 >> 2);
/* 255 */     this.genBuf[1] = (byte)(this.leftBuf[6] + this.leftBuf[4] + (this.leftBuf[5] << 1) + 2 >> 2);
/* 256 */     this.genBuf[2] = (byte)(this.leftBuf[5] + this.leftBuf[3] + (this.leftBuf[4] << 1) + 2 >> 2);
/* 257 */     this.genBuf[3] = (byte)(this.leftBuf[4] + this.leftBuf[2] + (this.leftBuf[3] << 1) + 2 >> 2);
/* 258 */     this.genBuf[4] = (byte)(this.leftBuf[3] + this.leftBuf[1] + (this.leftBuf[2] << 1) + 2 >> 2);
/* 259 */     this.genBuf[5] = (byte)(this.leftBuf[2] + this.leftBuf[0] + (this.leftBuf[1] << 1) + 2 >> 2);
/* 260 */     this.genBuf[6] = (byte)(this.leftBuf[1] + tl + (this.leftBuf[0] << 1) + 2 >> 2);
/* 261 */     this.genBuf[7] = (byte)(this.leftBuf[0] + this.topBuf[0] + (tl << 1) + 2 >> 2);
/* 262 */     this.genBuf[8] = (byte)(tl + this.topBuf[1] + (this.topBuf[0] << 1) + 2 >> 2);
/* 263 */     this.genBuf[9] = (byte)(this.topBuf[0] + this.topBuf[2] + (this.topBuf[1] << 1) + 2 >> 2);
/* 264 */     this.genBuf[10] = (byte)(this.topBuf[1] + this.topBuf[3] + (this.topBuf[2] << 1) + 2 >> 2);
/* 265 */     this.genBuf[11] = (byte)(this.topBuf[2] + this.topBuf[4] + (this.topBuf[3] << 1) + 2 >> 2);
/* 266 */     this.genBuf[12] = (byte)(this.topBuf[3] + this.topBuf[5] + (this.topBuf[4] << 1) + 2 >> 2);
/* 267 */     this.genBuf[13] = (byte)(this.topBuf[4] + this.topBuf[6] + (this.topBuf[5] << 1) + 2 >> 2);
/* 268 */     this.genBuf[14] = (byte)(this.topBuf[5] + this.topBuf[7] + (this.topBuf[6] << 1) + 2 >> 2);
/*     */     
/* 270 */     int off = (blkY << 4) + blkX;
/* 271 */     copyAdd(this.genBuf, 7, residual, off, 0, pixOut);
/* 272 */     copyAdd(this.genBuf, 6, residual, off + 16, 8, pixOut);
/* 273 */     copyAdd(this.genBuf, 5, residual, off + 32, 16, pixOut);
/* 274 */     copyAdd(this.genBuf, 4, residual, off + 48, 24, pixOut);
/* 275 */     copyAdd(this.genBuf, 3, residual, off + 64, 32, pixOut);
/* 276 */     copyAdd(this.genBuf, 2, residual, off + 80, 40, pixOut);
/* 277 */     copyAdd(this.genBuf, 1, residual, off + 96, 48, pixOut);
/* 278 */     copyAdd(this.genBuf, 0, residual, off + 112, 56, pixOut);
/*     */   }
/*     */ 
/*     */   
/*     */   public void predictVerticalRight(int[] residual, boolean topRightAvailable, byte[] topLeft, byte[] leftRow, byte[] topLine, int mbOffX, int blkX, int blkY, byte[] pixOut) {
/* 283 */     interpolateTop(true, topRightAvailable, topLeft, topLine, mbOffX + blkX, blkY, this.topBuf);
/* 284 */     interpolateLeft(true, topLeft, leftRow, blkY, this.leftBuf);
/* 285 */     int tl = interpolateTopLeft(true, true, topLeft, topLine, leftRow, mbOffX, blkX, blkY);
/*     */     
/* 287 */     this.genBuf[0] = (byte)(this.leftBuf[5] + this.leftBuf[3] + (this.leftBuf[4] << 1) + 2 >> 2);
/* 288 */     this.genBuf[1] = (byte)(this.leftBuf[3] + this.leftBuf[1] + (this.leftBuf[2] << 1) + 2 >> 2);
/* 289 */     this.genBuf[2] = (byte)(this.leftBuf[1] + tl + (this.leftBuf[0] << 1) + 2 >> 2);
/* 290 */     this.genBuf[3] = (byte)(tl + this.topBuf[0] + 1 >> 1);
/* 291 */     this.genBuf[4] = (byte)(this.topBuf[0] + this.topBuf[1] + 1 >> 1);
/* 292 */     this.genBuf[5] = (byte)(this.topBuf[1] + this.topBuf[2] + 1 >> 1);
/* 293 */     this.genBuf[6] = (byte)(this.topBuf[2] + this.topBuf[3] + 1 >> 1);
/* 294 */     this.genBuf[7] = (byte)(this.topBuf[3] + this.topBuf[4] + 1 >> 1);
/* 295 */     this.genBuf[8] = (byte)(this.topBuf[4] + this.topBuf[5] + 1 >> 1);
/* 296 */     this.genBuf[9] = (byte)(this.topBuf[5] + this.topBuf[6] + 1 >> 1);
/* 297 */     this.genBuf[10] = (byte)(this.topBuf[6] + this.topBuf[7] + 1 >> 1);
/* 298 */     this.genBuf[11] = (byte)(this.leftBuf[6] + this.leftBuf[4] + (this.leftBuf[5] << 1) + 2 >> 2);
/* 299 */     this.genBuf[12] = (byte)(this.leftBuf[4] + this.leftBuf[2] + (this.leftBuf[3] << 1) + 2 >> 2);
/* 300 */     this.genBuf[13] = (byte)(this.leftBuf[2] + this.leftBuf[0] + (this.leftBuf[1] << 1) + 2 >> 2);
/* 301 */     this.genBuf[14] = (byte)(this.leftBuf[0] + this.topBuf[0] + (tl << 1) + 2 >> 2);
/* 302 */     this.genBuf[15] = (byte)(tl + this.topBuf[1] + (this.topBuf[0] << 1) + 2 >> 2);
/* 303 */     this.genBuf[16] = (byte)(this.topBuf[0] + this.topBuf[2] + (this.topBuf[1] << 1) + 2 >> 2);
/* 304 */     this.genBuf[17] = (byte)(this.topBuf[1] + this.topBuf[3] + (this.topBuf[2] << 1) + 2 >> 2);
/* 305 */     this.genBuf[18] = (byte)(this.topBuf[2] + this.topBuf[4] + (this.topBuf[3] << 1) + 2 >> 2);
/* 306 */     this.genBuf[19] = (byte)(this.topBuf[3] + this.topBuf[5] + (this.topBuf[4] << 1) + 2 >> 2);
/* 307 */     this.genBuf[20] = (byte)(this.topBuf[4] + this.topBuf[6] + (this.topBuf[5] << 1) + 2 >> 2);
/* 308 */     this.genBuf[21] = (byte)(this.topBuf[5] + this.topBuf[7] + (this.topBuf[6] << 1) + 2 >> 2);
/*     */     
/* 310 */     int off = (blkY << 4) + blkX;
/* 311 */     copyAdd(this.genBuf, 3, residual, off, 0, pixOut);
/* 312 */     copyAdd(this.genBuf, 14, residual, off + 16, 8, pixOut);
/* 313 */     copyAdd(this.genBuf, 2, residual, off + 32, 16, pixOut);
/* 314 */     copyAdd(this.genBuf, 13, residual, off + 48, 24, pixOut);
/* 315 */     copyAdd(this.genBuf, 1, residual, off + 64, 32, pixOut);
/* 316 */     copyAdd(this.genBuf, 12, residual, off + 80, 40, pixOut);
/* 317 */     copyAdd(this.genBuf, 0, residual, off + 96, 48, pixOut);
/* 318 */     copyAdd(this.genBuf, 11, residual, off + 112, 56, pixOut);
/*     */   }
/*     */ 
/*     */   
/*     */   public void predictHorizontalDown(int[] residual, boolean topRightAvailable, byte[] topLeft, byte[] leftRow, byte[] topLine, int mbOffX, int blkX, int blkY, byte[] pixOut) {
/* 323 */     interpolateTop(true, topRightAvailable, topLeft, topLine, mbOffX + blkX, blkY, this.topBuf);
/* 324 */     interpolateLeft(true, topLeft, leftRow, blkY, this.leftBuf);
/* 325 */     int tl = interpolateTopLeft(true, true, topLeft, topLine, leftRow, mbOffX, blkX, blkY);
/*     */     
/* 327 */     this.genBuf[0] = (byte)(this.leftBuf[7] + this.leftBuf[6] + 1 >> 1);
/* 328 */     this.genBuf[1] = (byte)(this.leftBuf[5] + this.leftBuf[7] + (this.leftBuf[6] << 1) + 2 >> 2);
/* 329 */     this.genBuf[2] = (byte)(this.leftBuf[6] + this.leftBuf[5] + 1 >> 1);
/* 330 */     this.genBuf[3] = (byte)(this.leftBuf[4] + this.leftBuf[6] + (this.leftBuf[5] << 1) + 2 >> 2);
/* 331 */     this.genBuf[4] = (byte)(this.leftBuf[5] + this.leftBuf[4] + 1 >> 1);
/* 332 */     this.genBuf[5] = (byte)(this.leftBuf[3] + this.leftBuf[5] + (this.leftBuf[4] << 1) + 2 >> 2);
/* 333 */     this.genBuf[6] = (byte)(this.leftBuf[4] + this.leftBuf[3] + 1 >> 1);
/* 334 */     this.genBuf[7] = (byte)(this.leftBuf[2] + this.leftBuf[4] + (this.leftBuf[3] << 1) + 2 >> 2);
/* 335 */     this.genBuf[8] = (byte)(this.leftBuf[3] + this.leftBuf[2] + 1 >> 1);
/* 336 */     this.genBuf[9] = (byte)(this.leftBuf[1] + this.leftBuf[3] + (this.leftBuf[2] << 1) + 2 >> 2);
/* 337 */     this.genBuf[10] = (byte)(this.leftBuf[2] + this.leftBuf[1] + 1 >> 1);
/* 338 */     this.genBuf[11] = (byte)(this.leftBuf[0] + this.leftBuf[2] + (this.leftBuf[1] << 1) + 2 >> 2);
/* 339 */     this.genBuf[12] = (byte)(this.leftBuf[1] + this.leftBuf[0] + 1 >> 1);
/* 340 */     this.genBuf[13] = (byte)(tl + this.leftBuf[1] + (this.leftBuf[0] << 1) + 2 >> 2);
/* 341 */     this.genBuf[14] = (byte)(this.leftBuf[0] + tl + 1 >> 1);
/* 342 */     this.genBuf[15] = (byte)(this.leftBuf[0] + this.topBuf[0] + (tl << 1) + 2 >> 2);
/* 343 */     this.genBuf[16] = (byte)(tl + this.topBuf[1] + (this.topBuf[0] << 1) + 2 >> 2);
/* 344 */     this.genBuf[17] = (byte)(this.topBuf[0] + this.topBuf[2] + (this.topBuf[1] << 1) + 2 >> 2);
/* 345 */     this.genBuf[18] = (byte)(this.topBuf[1] + this.topBuf[3] + (this.topBuf[2] << 1) + 2 >> 2);
/* 346 */     this.genBuf[19] = (byte)(this.topBuf[2] + this.topBuf[4] + (this.topBuf[3] << 1) + 2 >> 2);
/* 347 */     this.genBuf[20] = (byte)(this.topBuf[3] + this.topBuf[5] + (this.topBuf[4] << 1) + 2 >> 2);
/* 348 */     this.genBuf[21] = (byte)(this.topBuf[4] + this.topBuf[6] + (this.topBuf[5] << 1) + 2 >> 2);
/*     */     
/* 350 */     int off = (blkY << 4) + blkX;
/* 351 */     copyAdd(this.genBuf, 14, residual, off, 0, pixOut);
/* 352 */     copyAdd(this.genBuf, 12, residual, off + 16, 8, pixOut);
/* 353 */     copyAdd(this.genBuf, 10, residual, off + 32, 16, pixOut);
/* 354 */     copyAdd(this.genBuf, 8, residual, off + 48, 24, pixOut);
/* 355 */     copyAdd(this.genBuf, 6, residual, off + 64, 32, pixOut);
/* 356 */     copyAdd(this.genBuf, 4, residual, off + 80, 40, pixOut);
/* 357 */     copyAdd(this.genBuf, 2, residual, off + 96, 48, pixOut);
/* 358 */     copyAdd(this.genBuf, 0, residual, off + 112, 56, pixOut);
/*     */   }
/*     */ 
/*     */   
/*     */   public void predictVerticalLeft(int[] residual, boolean topLeftAvailable, boolean topRightAvailable, byte[] topLeft, byte[] topLine, int mbOffX, int blkX, int blkY, byte[] pixOut) {
/* 363 */     interpolateTop(topLeftAvailable, topRightAvailable, topLeft, topLine, mbOffX + blkX, blkY, this.topBuf);
/*     */     
/* 365 */     this.genBuf[0] = (byte)(this.topBuf[0] + this.topBuf[1] + 1 >> 1);
/* 366 */     this.genBuf[1] = (byte)(this.topBuf[1] + this.topBuf[2] + 1 >> 1);
/* 367 */     this.genBuf[2] = (byte)(this.topBuf[2] + this.topBuf[3] + 1 >> 1);
/* 368 */     this.genBuf[3] = (byte)(this.topBuf[3] + this.topBuf[4] + 1 >> 1);
/* 369 */     this.genBuf[4] = (byte)(this.topBuf[4] + this.topBuf[5] + 1 >> 1);
/* 370 */     this.genBuf[5] = (byte)(this.topBuf[5] + this.topBuf[6] + 1 >> 1);
/* 371 */     this.genBuf[6] = (byte)(this.topBuf[6] + this.topBuf[7] + 1 >> 1);
/* 372 */     this.genBuf[7] = (byte)(this.topBuf[7] + this.topBuf[8] + 1 >> 1);
/* 373 */     this.genBuf[8] = (byte)(this.topBuf[8] + this.topBuf[9] + 1 >> 1);
/* 374 */     this.genBuf[9] = (byte)(this.topBuf[9] + this.topBuf[10] + 1 >> 1);
/* 375 */     this.genBuf[10] = (byte)(this.topBuf[10] + this.topBuf[11] + 1 >> 1);
/* 376 */     this.genBuf[11] = (byte)(this.topBuf[0] + this.topBuf[2] + (this.topBuf[1] << 1) + 2 >> 2);
/* 377 */     this.genBuf[12] = (byte)(this.topBuf[1] + this.topBuf[3] + (this.topBuf[2] << 1) + 2 >> 2);
/* 378 */     this.genBuf[13] = (byte)(this.topBuf[2] + this.topBuf[4] + (this.topBuf[3] << 1) + 2 >> 2);
/* 379 */     this.genBuf[14] = (byte)(this.topBuf[3] + this.topBuf[5] + (this.topBuf[4] << 1) + 2 >> 2);
/* 380 */     this.genBuf[15] = (byte)(this.topBuf[4] + this.topBuf[6] + (this.topBuf[5] << 1) + 2 >> 2);
/* 381 */     this.genBuf[16] = (byte)(this.topBuf[5] + this.topBuf[7] + (this.topBuf[6] << 1) + 2 >> 2);
/* 382 */     this.genBuf[17] = (byte)(this.topBuf[6] + this.topBuf[8] + (this.topBuf[7] << 1) + 2 >> 2);
/* 383 */     this.genBuf[18] = (byte)(this.topBuf[7] + this.topBuf[9] + (this.topBuf[8] << 1) + 2 >> 2);
/* 384 */     this.genBuf[19] = (byte)(this.topBuf[8] + this.topBuf[10] + (this.topBuf[9] << 1) + 2 >> 2);
/* 385 */     this.genBuf[20] = (byte)(this.topBuf[9] + this.topBuf[11] + (this.topBuf[10] << 1) + 2 >> 2);
/* 386 */     this.genBuf[21] = (byte)(this.topBuf[10] + this.topBuf[12] + (this.topBuf[11] << 1) + 2 >> 2);
/*     */     
/* 388 */     int off = (blkY << 4) + blkX;
/* 389 */     copyAdd(this.genBuf, 0, residual, off, 0, pixOut);
/* 390 */     copyAdd(this.genBuf, 11, residual, off + 16, 8, pixOut);
/* 391 */     copyAdd(this.genBuf, 1, residual, off + 32, 16, pixOut);
/* 392 */     copyAdd(this.genBuf, 12, residual, off + 48, 24, pixOut);
/* 393 */     copyAdd(this.genBuf, 2, residual, off + 64, 32, pixOut);
/* 394 */     copyAdd(this.genBuf, 13, residual, off + 80, 40, pixOut);
/* 395 */     copyAdd(this.genBuf, 3, residual, off + 96, 48, pixOut);
/* 396 */     copyAdd(this.genBuf, 14, residual, off + 112, 56, pixOut);
/*     */   }
/*     */ 
/*     */   
/*     */   public void predictHorizontalUp(int[] residual, boolean topLeftAvailable, byte[] topLeft, byte[] leftRow, int mbOffX, int blkX, int blkY, byte[] pixOut) {
/* 401 */     interpolateLeft(topLeftAvailable, topLeft, leftRow, blkY, this.leftBuf);
/*     */     
/* 403 */     this.genBuf[0] = (byte)(this.leftBuf[0] + this.leftBuf[1] + 1 >> 1);
/* 404 */     this.genBuf[1] = (byte)(this.leftBuf[2] + this.leftBuf[0] + (this.leftBuf[1] << 1) + 2 >> 2);
/* 405 */     this.genBuf[2] = (byte)(this.leftBuf[1] + this.leftBuf[2] + 1 >> 1);
/* 406 */     this.genBuf[3] = (byte)(this.leftBuf[3] + this.leftBuf[1] + (this.leftBuf[2] << 1) + 2 >> 2);
/* 407 */     this.genBuf[4] = (byte)(this.leftBuf[2] + this.leftBuf[3] + 1 >> 1);
/* 408 */     this.genBuf[5] = (byte)(this.leftBuf[4] + this.leftBuf[2] + (this.leftBuf[3] << 1) + 2 >> 2);
/* 409 */     this.genBuf[6] = (byte)(this.leftBuf[3] + this.leftBuf[4] + 1 >> 1);
/* 410 */     this.genBuf[7] = (byte)(this.leftBuf[5] + this.leftBuf[3] + (this.leftBuf[4] << 1) + 2 >> 2);
/* 411 */     this.genBuf[8] = (byte)(this.leftBuf[4] + this.leftBuf[5] + 1 >> 1);
/* 412 */     this.genBuf[9] = (byte)(this.leftBuf[6] + this.leftBuf[4] + (this.leftBuf[5] << 1) + 2 >> 2);
/* 413 */     this.genBuf[10] = (byte)(this.leftBuf[5] + this.leftBuf[6] + 1 >> 1);
/* 414 */     this.genBuf[11] = (byte)(this.leftBuf[7] + this.leftBuf[5] + (this.leftBuf[6] << 1) + 2 >> 2);
/* 415 */     this.genBuf[12] = (byte)(this.leftBuf[6] + this.leftBuf[7] + 1 >> 1);
/* 416 */     this.genBuf[13] = (byte)(this.leftBuf[6] + this.leftBuf[7] + (this.leftBuf[7] << 1) + 2 >> 2);
/* 417 */     this.genBuf[21] = this.leftBuf[7]; this.genBuf[20] = this.leftBuf[7]; this.genBuf[19] = this.leftBuf[7]; this.genBuf[18] = this.leftBuf[7]; this.genBuf[17] = this.leftBuf[7]; this.genBuf[16] = this.leftBuf[7]; this.genBuf[15] = this.leftBuf[7]; this.genBuf[14] = this.leftBuf[7];
/*     */     
/* 419 */     int off = (blkY << 4) + blkX;
/* 420 */     copyAdd(this.genBuf, 0, residual, off, 0, pixOut);
/* 421 */     copyAdd(this.genBuf, 2, residual, off + 16, 8, pixOut);
/* 422 */     copyAdd(this.genBuf, 4, residual, off + 32, 16, pixOut);
/* 423 */     copyAdd(this.genBuf, 6, residual, off + 48, 24, pixOut);
/* 424 */     copyAdd(this.genBuf, 8, residual, off + 64, 32, pixOut);
/* 425 */     copyAdd(this.genBuf, 10, residual, off + 80, 40, pixOut);
/* 426 */     copyAdd(this.genBuf, 12, residual, off + 96, 48, pixOut);
/* 427 */     copyAdd(this.genBuf, 14, residual, off + 112, 56, pixOut);
/*     */   }
/*     */ }


/* Location:              C:\Users\rapha\Downloads\aurora.jar!\META-INF\jars\jcodec-0.2.5.jar!\org\jcodec\codecs\h264\decode\Intra8x8PredictionBuilder.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */