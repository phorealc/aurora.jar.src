package org.jcodec.codecs.h264.decode.aso;

public interface Mapper {
  boolean leftAvailable(int paramInt);
  
  boolean topAvailable(int paramInt);
  
  int getAddress(int paramInt);
  
  int getMbX(int paramInt);
  
  int getMbY(int paramInt);
  
  boolean topRightAvailable(int paramInt);
  
  boolean topLeftAvailable(int paramInt);
}


/* Location:              C:\Users\rapha\Downloads\aurora.jar!\META-INF\jars\jcodec-0.2.5.jar!\org\jcodec\codecs\h264\decode\aso\Mapper.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */