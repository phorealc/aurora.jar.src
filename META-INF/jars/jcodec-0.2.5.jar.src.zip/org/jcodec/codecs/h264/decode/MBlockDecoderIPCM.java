/*    */ package org.jcodec.codecs.h264.decode;
/*    */ 
/*    */ import org.jcodec.codecs.h264.decode.aso.Mapper;
/*    */ import org.jcodec.common.model.Picture;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class MBlockDecoderIPCM
/*    */ {
/*    */   private Mapper mapper;
/*    */   private DecoderState s;
/*    */   
/*    */   public MBlockDecoderIPCM(Mapper mapper, DecoderState decoderState) {
/* 19 */     this.mapper = mapper;
/* 20 */     this.s = decoderState;
/*    */   }
/*    */   
/*    */   public void decode(MBlock mBlock, Picture mb) {
/* 24 */     int mbX = this.mapper.getMbX(mBlock.mbIdx);
/* 25 */     MBlockDecoderUtils.collectPredictors(this.s, mb, mbX);
/* 26 */     MBlockDecoderUtils.saveVectIntra(this.s, this.mapper.getMbX(mBlock.mbIdx));
/*    */   }
/*    */ }


/* Location:              C:\Users\rapha\Downloads\aurora.jar!\META-INF\jars\jcodec-0.2.5.jar!\org\jcodec\codecs\h264\decode\MBlockDecoderIPCM.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */