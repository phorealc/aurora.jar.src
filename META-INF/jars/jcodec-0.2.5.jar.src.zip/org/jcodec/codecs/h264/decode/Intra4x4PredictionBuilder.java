/*     */ package org.jcodec.codecs.h264.decode;
/*     */ 
/*     */ import org.jcodec.common.tools.MathUtil;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class Intra4x4PredictionBuilder
/*     */ {
/*     */   public static void predictWithMode(int mode, int[] residual, boolean leftAvailable, boolean topAvailable, boolean topRightAvailable, byte[] leftRow, byte[] topLine, byte[] topLeft, int mbOffX, int blkX, int blkY, byte[] pixOut) {
/*  19 */     switch (mode) {
/*     */       case 0:
/*  21 */         predictVertical(residual, topAvailable, topLine, mbOffX, blkX, blkY, pixOut);
/*     */         break;
/*     */       case 1:
/*  24 */         predictHorizontal(residual, leftAvailable, leftRow, mbOffX, blkX, blkY, pixOut);
/*     */         break;
/*     */       case 2:
/*  27 */         predictDC(residual, leftAvailable, topAvailable, leftRow, topLine, mbOffX, blkX, blkY, pixOut);
/*     */         break;
/*     */       case 3:
/*  30 */         predictDiagonalDownLeft(residual, topAvailable, topRightAvailable, topLine, mbOffX, blkX, blkY, pixOut);
/*     */         break;
/*     */       case 4:
/*  33 */         predictDiagonalDownRight(residual, leftAvailable, topAvailable, leftRow, topLine, topLeft, mbOffX, blkX, blkY, pixOut);
/*     */         break;
/*     */       
/*     */       case 5:
/*  37 */         predictVerticalRight(residual, leftAvailable, topAvailable, leftRow, topLine, topLeft, mbOffX, blkX, blkY, pixOut);
/*     */         break;
/*     */       
/*     */       case 6:
/*  41 */         predictHorizontalDown(residual, leftAvailable, topAvailable, leftRow, topLine, topLeft, mbOffX, blkX, blkY, pixOut);
/*     */         break;
/*     */       
/*     */       case 7:
/*  45 */         predictVerticalLeft(residual, topAvailable, topRightAvailable, topLine, mbOffX, blkX, blkY, pixOut);
/*     */         break;
/*     */       case 8:
/*  48 */         predictHorizontalUp(residual, leftAvailable, leftRow, mbOffX, blkX, blkY, pixOut);
/*     */         break;
/*     */     } 
/*     */     
/*  52 */     int oo1 = mbOffX + blkX;
/*  53 */     int off1 = (blkY << 4) + blkX + 3;
/*     */     
/*  55 */     topLeft[blkY >> 2] = topLine[oo1 + 3];
/*     */     
/*  57 */     leftRow[blkY] = pixOut[off1];
/*  58 */     leftRow[blkY + 1] = pixOut[off1 + 16];
/*  59 */     leftRow[blkY + 2] = pixOut[off1 + 32];
/*  60 */     leftRow[blkY + 3] = pixOut[off1 + 48];
/*     */     
/*  62 */     int off2 = (blkY << 4) + blkX + 48;
/*  63 */     topLine[oo1] = pixOut[off2];
/*  64 */     topLine[oo1 + 1] = pixOut[off2 + 1];
/*  65 */     topLine[oo1 + 2] = pixOut[off2 + 2];
/*  66 */     topLine[oo1 + 3] = pixOut[off2 + 3];
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public static void predictVertical(int[] residual, boolean topAvailable, byte[] topLine, int mbOffX, int blkX, int blkY, byte[] pixOut) {
/*  72 */     int pixOff = (blkY << 4) + blkX;
/*  73 */     int toff = mbOffX + blkX;
/*  74 */     int rOff = 0;
/*  75 */     for (int j = 0; j < 4; j++) {
/*  76 */       pixOut[pixOff] = (byte)MathUtil.clip(residual[rOff] + topLine[toff], -128, 127);
/*  77 */       pixOut[pixOff + 1] = (byte)MathUtil.clip(residual[rOff + 1] + topLine[toff + 1], -128, 127);
/*  78 */       pixOut[pixOff + 2] = (byte)MathUtil.clip(residual[rOff + 2] + topLine[toff + 2], -128, 127);
/*  79 */       pixOut[pixOff + 3] = (byte)MathUtil.clip(residual[rOff + 3] + topLine[toff + 3], -128, 127);
/*  80 */       rOff += 4;
/*  81 */       pixOff += 16;
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public static void predictHorizontal(int[] residual, boolean leftAvailable, byte[] leftRow, int mbOffX, int blkX, int blkY, byte[] pixOut) {
/*  88 */     int pixOff = (blkY << 4) + blkX;
/*  89 */     int rOff = 0;
/*  90 */     for (int j = 0; j < 4; j++) {
/*  91 */       int l = leftRow[blkY + j];
/*  92 */       pixOut[pixOff] = (byte)MathUtil.clip(residual[rOff] + l, -128, 127);
/*  93 */       pixOut[pixOff + 1] = (byte)MathUtil.clip(residual[rOff + 1] + l, -128, 127);
/*  94 */       pixOut[pixOff + 2] = (byte)MathUtil.clip(residual[rOff + 2] + l, -128, 127);
/*  95 */       pixOut[pixOff + 3] = (byte)MathUtil.clip(residual[rOff + 3] + l, -128, 127);
/*  96 */       rOff += 4;
/*  97 */       pixOff += 16;
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public static void predictDC(int[] residual, boolean leftAvailable, boolean topAvailable, byte[] leftRow, byte[] topLine, int mbOffX, int blkX, int blkY, byte[] pixOut) {
/*     */     int val;
/* 105 */     if (leftAvailable && topAvailable) {
/* 106 */       val = leftRow[blkY] + leftRow[blkY + 1] + leftRow[blkY + 2] + leftRow[blkY + 3] + topLine[mbOffX + blkX] + topLine[mbOffX + blkX + 1] + topLine[mbOffX + blkX + 2] + topLine[mbOffX + blkX + 3] + 4 >> 3;
/*     */     }
/* 108 */     else if (leftAvailable) {
/* 109 */       val = leftRow[blkY] + leftRow[blkY + 1] + leftRow[blkY + 2] + leftRow[blkY + 3] + 2 >> 2;
/* 110 */     } else if (topAvailable) {
/* 111 */       val = topLine[mbOffX + blkX] + topLine[mbOffX + blkX + 1] + topLine[mbOffX + blkX + 2] + topLine[mbOffX + blkX + 3] + 2 >> 2;
/*     */     } else {
/*     */       
/* 114 */       val = 0;
/*     */     } 
/*     */     
/* 117 */     int pixOff = (blkY << 4) + blkX;
/* 118 */     int rOff = 0;
/* 119 */     for (int j = 0; j < 4; j++) {
/* 120 */       pixOut[pixOff] = (byte)MathUtil.clip(residual[rOff] + val, -128, 127);
/* 121 */       pixOut[pixOff + 1] = (byte)MathUtil.clip(residual[rOff + 1] + val, -128, 127);
/* 122 */       pixOut[pixOff + 2] = (byte)MathUtil.clip(residual[rOff + 2] + val, -128, 127);
/* 123 */       pixOut[pixOff + 3] = (byte)MathUtil.clip(residual[rOff + 3] + val, -128, 127);
/* 124 */       pixOff += 16;
/* 125 */       rOff += 4;
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public static void predictDiagonalDownLeft(int[] residual, boolean topAvailable, boolean topRightAvailable, byte[] topLine, int mbOffX, int blkX, int blkY, byte[] pixOut) {
/* 132 */     int to = mbOffX + blkX;
/* 133 */     int tr0 = topLine[to + 3], tr1 = topLine[to + 3], tr2 = topLine[to + 3], tr3 = topLine[to + 3];
/* 134 */     if (topRightAvailable) {
/* 135 */       tr0 = topLine[to + 4];
/* 136 */       tr1 = topLine[to + 5];
/* 137 */       tr2 = topLine[to + 6];
/* 138 */       tr3 = topLine[to + 7];
/*     */     } 
/*     */     
/* 141 */     int c0 = topLine[to] + topLine[to + 2] + (topLine[to + 1] << 1) + 2 >> 2;
/* 142 */     int c1 = topLine[to + 1] + topLine[to + 3] + (topLine[to + 2] << 1) + 2 >> 2;
/* 143 */     int c2 = topLine[to + 2] + tr0 + (topLine[to + 3] << 1) + 2 >> 2;
/* 144 */     int c3 = topLine[to + 3] + tr1 + (tr0 << 1) + 2 >> 2;
/* 145 */     int c4 = tr0 + tr2 + (tr1 << 1) + 2 >> 2;
/* 146 */     int c5 = tr1 + tr3 + (tr2 << 1) + 2 >> 2;
/* 147 */     int c6 = tr2 + 3 * tr3 + 2 >> 2;
/*     */     
/* 149 */     int off = (blkY << 4) + blkX;
/* 150 */     pixOut[off] = (byte)MathUtil.clip(residual[0] + c0, -128, 127);
/* 151 */     pixOut[off + 1] = (byte)MathUtil.clip(residual[1] + c1, -128, 127);
/* 152 */     pixOut[off + 2] = (byte)MathUtil.clip(residual[2] + c2, -128, 127);
/* 153 */     pixOut[off + 3] = (byte)MathUtil.clip(residual[3] + c3, -128, 127);
/*     */     
/* 155 */     pixOut[off + 16] = (byte)MathUtil.clip(residual[4] + c1, -128, 127);
/* 156 */     pixOut[off + 17] = (byte)MathUtil.clip(residual[5] + c2, -128, 127);
/* 157 */     pixOut[off + 18] = (byte)MathUtil.clip(residual[6] + c3, -128, 127);
/* 158 */     pixOut[off + 19] = (byte)MathUtil.clip(residual[7] + c4, -128, 127);
/*     */     
/* 160 */     pixOut[off + 32] = (byte)MathUtil.clip(residual[8] + c2, -128, 127);
/* 161 */     pixOut[off + 33] = (byte)MathUtil.clip(residual[9] + c3, -128, 127);
/* 162 */     pixOut[off + 34] = (byte)MathUtil.clip(residual[10] + c4, -128, 127);
/* 163 */     pixOut[off + 35] = (byte)MathUtil.clip(residual[11] + c5, -128, 127);
/*     */     
/* 165 */     pixOut[off + 48] = (byte)MathUtil.clip(residual[12] + c3, -128, 127);
/* 166 */     pixOut[off + 49] = (byte)MathUtil.clip(residual[13] + c4, -128, 127);
/* 167 */     pixOut[off + 50] = (byte)MathUtil.clip(residual[14] + c5, -128, 127);
/* 168 */     pixOut[off + 51] = (byte)MathUtil.clip(residual[15] + c6, -128, 127);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public static void predictDiagonalDownRight(int[] residual, boolean leftAvailable, boolean topAvailable, byte[] leftRow, byte[] topLine, byte[] topLeft, int mbOffX, int blkX, int blkY, byte[] pixOut) {
/* 174 */     int off = (blkY << 4) + blkX;
/* 175 */     int c0 = topLine[mbOffX + blkX] + 2 * topLeft[blkY >> 2] + leftRow[blkY] + 2 >> 2;
/*     */     
/* 177 */     int c1 = topLeft[blkY >> 2] + (topLine[mbOffX + blkX + 0] << 1) + topLine[mbOffX + blkX + 1] + 2 >> 2;
/* 178 */     int c2 = topLine[mbOffX + blkX] + (topLine[mbOffX + blkX + 1] << 1) + topLine[mbOffX + blkX + 2] + 2 >> 2;
/* 179 */     int c3 = topLine[mbOffX + blkX + 1] + (topLine[mbOffX + blkX + 2] << 1) + topLine[mbOffX + blkX + 3] + 2 >> 2;
/*     */     
/* 181 */     pixOut[off] = (byte)MathUtil.clip(residual[0] + c0, -128, 127);
/* 182 */     pixOut[off + 1] = (byte)MathUtil.clip(residual[1] + c1, -128, 127);
/* 183 */     pixOut[off + 2] = (byte)MathUtil.clip(residual[2] + c2, -128, 127);
/* 184 */     pixOut[off + 3] = (byte)MathUtil.clip(residual[3] + c3, -128, 127);
/*     */     
/* 186 */     int c4 = topLeft[blkY >> 2] + (leftRow[blkY] << 1) + leftRow[blkY + 1] + 2 >> 2;
/* 187 */     int c6 = topLeft[blkY >> 2] + (topLine[mbOffX + blkX] << 1) + topLine[mbOffX + blkX + 1] + 2 >> 2;
/* 188 */     int c7 = topLine[mbOffX + blkX] + (topLine[mbOffX + blkX + 1] << 1) + topLine[mbOffX + blkX + 2] + 2 >> 2;
/*     */     
/* 190 */     pixOut[off + 16] = (byte)MathUtil.clip(residual[4] + c4, -128, 127);
/* 191 */     pixOut[off + 17] = (byte)MathUtil.clip(residual[5] + c0, -128, 127);
/* 192 */     pixOut[off + 18] = (byte)MathUtil.clip(residual[6] + c6, -128, 127);
/* 193 */     pixOut[off + 19] = (byte)MathUtil.clip(residual[7] + c7, -128, 127);
/*     */     
/* 195 */     int c8 = leftRow[blkY + 0] + (leftRow[blkY + 1] << 1) + leftRow[blkY + 2] + 2 >> 2;
/* 196 */     int c9 = topLeft[blkY >> 2] + (leftRow[blkY] << 1) + leftRow[blkY + 1] + 2 >> 2;
/* 197 */     int c11 = topLeft[blkY >> 2] + (topLine[mbOffX + blkX] << 1) + topLine[mbOffX + blkX + 1] + 2 >> 2;
/*     */     
/* 199 */     pixOut[off + 32] = (byte)MathUtil.clip(residual[8] + c8, -128, 127);
/* 200 */     pixOut[off + 33] = (byte)MathUtil.clip(residual[9] + c9, -128, 127);
/* 201 */     pixOut[off + 34] = (byte)MathUtil.clip(residual[10] + c0, -128, 127);
/* 202 */     pixOut[off + 35] = (byte)MathUtil.clip(residual[11] + c11, -128, 127);
/*     */     
/* 204 */     int c12 = leftRow[blkY + 1] + (leftRow[blkY + 2] << 1) + leftRow[blkY + 3] + 2 >> 2;
/* 205 */     int c13 = leftRow[blkY] + (leftRow[blkY + 1] << 1) + leftRow[blkY + 2] + 2 >> 2;
/* 206 */     int c14 = topLeft[blkY >> 2] + (leftRow[blkY] << 1) + leftRow[blkY + 1] + 2 >> 2;
/*     */     
/* 208 */     pixOut[off + 48] = (byte)MathUtil.clip(residual[12] + c12, -128, 127);
/* 209 */     pixOut[off + 49] = (byte)MathUtil.clip(residual[13] + c13, -128, 127);
/* 210 */     pixOut[off + 50] = (byte)MathUtil.clip(residual[14] + c14, -128, 127);
/* 211 */     pixOut[off + 51] = (byte)MathUtil.clip(residual[15] + c0, -128, 127);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public static void predictVerticalRight(int[] residual, boolean leftAvailable, boolean topAvailable, byte[] leftRow, byte[] topLine, byte[] topLeft, int mbOffX, int blkX, int blkY, byte[] pixOut) {
/* 217 */     int v1 = topLeft[blkY >> 2] + topLine[mbOffX + blkX + 0] + 1 >> 1;
/* 218 */     int v2 = topLine[mbOffX + blkX + 0] + topLine[mbOffX + blkX + 1] + 1 >> 1;
/* 219 */     int v3 = topLine[mbOffX + blkX + 1] + topLine[mbOffX + blkX + 2] + 1 >> 1;
/* 220 */     int v4 = topLine[mbOffX + blkX + 2] + topLine[mbOffX + blkX + 3] + 1 >> 1;
/* 221 */     int v5 = leftRow[blkY] + 2 * topLeft[blkY >> 2] + topLine[mbOffX + blkX + 0] + 2 >> 2;
/* 222 */     int v6 = topLeft[blkY >> 2] + 2 * topLine[mbOffX + blkX + 0] + topLine[mbOffX + blkX + 1] + 2 >> 2;
/* 223 */     int v7 = topLine[mbOffX + blkX + 0] + 2 * topLine[mbOffX + blkX + 1] + topLine[mbOffX + blkX + 2] + 2 >> 2;
/* 224 */     int v8 = topLine[mbOffX + blkX + 1] + 2 * topLine[mbOffX + blkX + 2] + topLine[mbOffX + blkX + 3] + 2 >> 2;
/* 225 */     int v9 = topLeft[blkY >> 2] + 2 * leftRow[blkY] + leftRow[blkY + 1] + 2 >> 2;
/* 226 */     int v10 = leftRow[blkY] + 2 * leftRow[blkY + 1] + leftRow[blkY + 2] + 2 >> 2;
/*     */     
/* 228 */     int off = (blkY << 4) + blkX;
/* 229 */     pixOut[off] = (byte)MathUtil.clip(residual[0] + v1, -128, 127);
/* 230 */     pixOut[off + 1] = (byte)MathUtil.clip(residual[1] + v2, -128, 127);
/* 231 */     pixOut[off + 2] = (byte)MathUtil.clip(residual[2] + v3, -128, 127);
/* 232 */     pixOut[off + 3] = (byte)MathUtil.clip(residual[3] + v4, -128, 127);
/* 233 */     pixOut[off + 16] = (byte)MathUtil.clip(residual[4] + v5, -128, 127);
/* 234 */     pixOut[off + 17] = (byte)MathUtil.clip(residual[5] + v6, -128, 127);
/* 235 */     pixOut[off + 18] = (byte)MathUtil.clip(residual[6] + v7, -128, 127);
/* 236 */     pixOut[off + 19] = (byte)MathUtil.clip(residual[7] + v8, -128, 127);
/* 237 */     pixOut[off + 32] = (byte)MathUtil.clip(residual[8] + v9, -128, 127);
/* 238 */     pixOut[off + 33] = (byte)MathUtil.clip(residual[9] + v1, -128, 127);
/* 239 */     pixOut[off + 34] = (byte)MathUtil.clip(residual[10] + v2, -128, 127);
/* 240 */     pixOut[off + 35] = (byte)MathUtil.clip(residual[11] + v3, -128, 127);
/* 241 */     pixOut[off + 48] = (byte)MathUtil.clip(residual[12] + v10, -128, 127);
/* 242 */     pixOut[off + 49] = (byte)MathUtil.clip(residual[13] + v5, -128, 127);
/* 243 */     pixOut[off + 50] = (byte)MathUtil.clip(residual[14] + v6, -128, 127);
/* 244 */     pixOut[off + 51] = (byte)MathUtil.clip(residual[15] + v7, -128, 127);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public static void predictHorizontalDown(int[] residual, boolean leftAvailable, boolean topAvailable, byte[] leftRow, byte[] topLine, byte[] topLeft, int mbOffX, int blkX, int blkY, byte[] pixOut) {
/* 250 */     int c0 = topLeft[blkY >> 2] + leftRow[blkY] + 1 >> 1;
/* 251 */     int c1 = leftRow[blkY] + 2 * topLeft[blkY >> 2] + topLine[mbOffX + blkX + 0] + 2 >> 2;
/* 252 */     int c2 = topLeft[blkY >> 2] + 2 * topLine[mbOffX + blkX + 0] + topLine[mbOffX + blkX + 1] + 2 >> 2;
/* 253 */     int c3 = topLine[mbOffX + blkX + 0] + 2 * topLine[mbOffX + blkX + 1] + topLine[mbOffX + blkX + 2] + 2 >> 2;
/* 254 */     int c4 = leftRow[blkY] + leftRow[blkY + 1] + 1 >> 1;
/* 255 */     int c5 = topLeft[blkY >> 2] + 2 * leftRow[blkY] + leftRow[blkY + 1] + 2 >> 2;
/* 256 */     int c6 = leftRow[blkY + 1] + leftRow[blkY + 2] + 1 >> 1;
/* 257 */     int c7 = leftRow[blkY] + 2 * leftRow[blkY + 1] + leftRow[blkY + 2] + 2 >> 2;
/* 258 */     int c8 = leftRow[blkY + 2] + leftRow[blkY + 3] + 1 >> 1;
/* 259 */     int c9 = leftRow[blkY + 1] + 2 * leftRow[blkY + 2] + leftRow[blkY + 3] + 2 >> 2;
/*     */     
/* 261 */     int off = (blkY << 4) + blkX;
/* 262 */     pixOut[off] = (byte)MathUtil.clip(residual[0] + c0, -128, 127);
/* 263 */     pixOut[off + 1] = (byte)MathUtil.clip(residual[1] + c1, -128, 127);
/* 264 */     pixOut[off + 2] = (byte)MathUtil.clip(residual[2] + c2, -128, 127);
/* 265 */     pixOut[off + 3] = (byte)MathUtil.clip(residual[3] + c3, -128, 127);
/* 266 */     pixOut[off + 16] = (byte)MathUtil.clip(residual[4] + c4, -128, 127);
/* 267 */     pixOut[off + 17] = (byte)MathUtil.clip(residual[5] + c5, -128, 127);
/* 268 */     pixOut[off + 18] = (byte)MathUtil.clip(residual[6] + c0, -128, 127);
/* 269 */     pixOut[off + 19] = (byte)MathUtil.clip(residual[7] + c1, -128, 127);
/* 270 */     pixOut[off + 32] = (byte)MathUtil.clip(residual[8] + c6, -128, 127);
/* 271 */     pixOut[off + 33] = (byte)MathUtil.clip(residual[9] + c7, -128, 127);
/* 272 */     pixOut[off + 34] = (byte)MathUtil.clip(residual[10] + c4, -128, 127);
/* 273 */     pixOut[off + 35] = (byte)MathUtil.clip(residual[11] + c5, -128, 127);
/* 274 */     pixOut[off + 48] = (byte)MathUtil.clip(residual[12] + c8, -128, 127);
/* 275 */     pixOut[off + 49] = (byte)MathUtil.clip(residual[13] + c9, -128, 127);
/* 276 */     pixOut[off + 50] = (byte)MathUtil.clip(residual[14] + c6, -128, 127);
/* 277 */     pixOut[off + 51] = (byte)MathUtil.clip(residual[15] + c7, -128, 127);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public static void predictVerticalLeft(int[] residual, boolean topAvailable, boolean topRightAvailable, byte[] topLine, int mbOffX, int blkX, int blkY, byte[] pixOut) {
/* 283 */     int to = mbOffX + blkX;
/* 284 */     int tr0 = topLine[to + 3], tr1 = topLine[to + 3], tr2 = topLine[to + 3];
/* 285 */     if (topRightAvailable) {
/* 286 */       tr0 = topLine[to + 4];
/* 287 */       tr1 = topLine[to + 5];
/* 288 */       tr2 = topLine[to + 6];
/*     */     } 
/*     */     
/* 291 */     int c0 = topLine[to] + topLine[to + 1] + 1 >> 1;
/* 292 */     int c1 = topLine[to + 1] + topLine[to + 2] + 1 >> 1;
/* 293 */     int c2 = topLine[to + 2] + topLine[to + 3] + 1 >> 1;
/* 294 */     int c3 = topLine[to + 3] + tr0 + 1 >> 1;
/* 295 */     int c4 = tr0 + tr1 + 1 >> 1;
/* 296 */     int c5 = topLine[to] + 2 * topLine[to + 1] + topLine[to + 2] + 2 >> 2;
/* 297 */     int c6 = topLine[to + 1] + 2 * topLine[to + 2] + topLine[to + 3] + 2 >> 2;
/* 298 */     int c7 = topLine[to + 2] + 2 * topLine[to + 3] + tr0 + 2 >> 2;
/* 299 */     int c8 = topLine[to + 3] + 2 * tr0 + tr1 + 2 >> 2;
/* 300 */     int c9 = tr0 + 2 * tr1 + tr2 + 2 >> 2;
/*     */     
/* 302 */     int off = (blkY << 4) + blkX;
/* 303 */     pixOut[off] = (byte)MathUtil.clip(residual[0] + c0, -128, 127);
/* 304 */     pixOut[off + 1] = (byte)MathUtil.clip(residual[1] + c1, -128, 127);
/* 305 */     pixOut[off + 2] = (byte)MathUtil.clip(residual[2] + c2, -128, 127);
/* 306 */     pixOut[off + 3] = (byte)MathUtil.clip(residual[3] + c3, -128, 127);
/*     */     
/* 308 */     pixOut[off + 16] = (byte)MathUtil.clip(residual[4] + c5, -128, 127);
/* 309 */     pixOut[off + 17] = (byte)MathUtil.clip(residual[5] + c6, -128, 127);
/* 310 */     pixOut[off + 18] = (byte)MathUtil.clip(residual[6] + c7, -128, 127);
/* 311 */     pixOut[off + 19] = (byte)MathUtil.clip(residual[7] + c8, -128, 127);
/*     */     
/* 313 */     pixOut[off + 32] = (byte)MathUtil.clip(residual[8] + c1, -128, 127);
/* 314 */     pixOut[off + 33] = (byte)MathUtil.clip(residual[9] + c2, -128, 127);
/* 315 */     pixOut[off + 34] = (byte)MathUtil.clip(residual[10] + c3, -128, 127);
/* 316 */     pixOut[off + 35] = (byte)MathUtil.clip(residual[11] + c4, -128, 127);
/*     */     
/* 318 */     pixOut[off + 48] = (byte)MathUtil.clip(residual[12] + c6, -128, 127);
/* 319 */     pixOut[off + 49] = (byte)MathUtil.clip(residual[13] + c7, -128, 127);
/* 320 */     pixOut[off + 50] = (byte)MathUtil.clip(residual[14] + c8, -128, 127);
/* 321 */     pixOut[off + 51] = (byte)MathUtil.clip(residual[15] + c9, -128, 127);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public static void predictHorizontalUp(int[] residual, boolean leftAvailable, byte[] leftRow, int mbOffX, int blkX, int blkY, byte[] pixOut) {
/* 327 */     int c0 = leftRow[blkY] + leftRow[blkY + 1] + 1 >> 1;
/* 328 */     int c1 = leftRow[blkY] + (leftRow[blkY + 1] << 1) + leftRow[blkY + 2] + 2 >> 2;
/* 329 */     int c2 = leftRow[blkY + 1] + leftRow[blkY + 2] + 1 >> 1;
/* 330 */     int c3 = leftRow[blkY + 1] + (leftRow[blkY + 2] << 1) + leftRow[blkY + 3] + 2 >> 2;
/* 331 */     int c4 = leftRow[blkY + 2] + leftRow[blkY + 3] + 1 >> 1;
/* 332 */     int c5 = leftRow[blkY + 2] + (leftRow[blkY + 3] << 1) + leftRow[blkY + 3] + 2 >> 2;
/* 333 */     int c6 = leftRow[blkY + 3];
/*     */     
/* 335 */     int off = (blkY << 4) + blkX;
/* 336 */     pixOut[off] = (byte)MathUtil.clip(residual[0] + c0, -128, 127);
/* 337 */     pixOut[off + 1] = (byte)MathUtil.clip(residual[1] + c1, -128, 127);
/* 338 */     pixOut[off + 2] = (byte)MathUtil.clip(residual[2] + c2, -128, 127);
/* 339 */     pixOut[off + 3] = (byte)MathUtil.clip(residual[3] + c3, -128, 127);
/*     */     
/* 341 */     pixOut[off + 16] = (byte)MathUtil.clip(residual[4] + c2, -128, 127);
/* 342 */     pixOut[off + 17] = (byte)MathUtil.clip(residual[5] + c3, -128, 127);
/* 343 */     pixOut[off + 18] = (byte)MathUtil.clip(residual[6] + c4, -128, 127);
/* 344 */     pixOut[off + 19] = (byte)MathUtil.clip(residual[7] + c5, -128, 127);
/*     */     
/* 346 */     pixOut[off + 32] = (byte)MathUtil.clip(residual[8] + c4, -128, 127);
/* 347 */     pixOut[off + 33] = (byte)MathUtil.clip(residual[9] + c5, -128, 127);
/* 348 */     pixOut[off + 34] = (byte)MathUtil.clip(residual[10] + c6, -128, 127);
/* 349 */     pixOut[off + 35] = (byte)MathUtil.clip(residual[11] + c6, -128, 127);
/*     */     
/* 351 */     pixOut[off + 48] = (byte)MathUtil.clip(residual[12] + c6, -128, 127);
/* 352 */     pixOut[off + 49] = (byte)MathUtil.clip(residual[13] + c6, -128, 127);
/* 353 */     pixOut[off + 50] = (byte)MathUtil.clip(residual[14] + c6, -128, 127);
/* 354 */     pixOut[off + 51] = (byte)MathUtil.clip(residual[15] + c6, -128, 127);
/*     */   }
/*     */ }


/* Location:              C:\Users\rapha\Downloads\aurora.jar!\META-INF\jars\jcodec-0.2.5.jar!\org\jcodec\codecs\h264\decode\Intra4x4PredictionBuilder.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */