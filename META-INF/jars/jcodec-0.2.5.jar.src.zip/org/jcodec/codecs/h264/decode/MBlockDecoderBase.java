/*     */ package org.jcodec.codecs.h264.decode;
/*     */ 
/*     */ import java.util.Arrays;
/*     */ import org.jcodec.codecs.h264.H264Const;
/*     */ import org.jcodec.codecs.h264.H264Utils;
/*     */ import org.jcodec.codecs.h264.io.model.Frame;
/*     */ import org.jcodec.codecs.h264.io.model.MBType;
/*     */ import org.jcodec.codecs.h264.io.model.SliceHeader;
/*     */ import org.jcodec.common.model.ColorSpace;
/*     */ import org.jcodec.common.model.Picture;
/*     */ import org.jcodec.common.tools.MathUtil;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class MBlockDecoderBase
/*     */ {
/*     */   protected DecoderState s;
/*     */   protected SliceHeader sh;
/*     */   protected DeblockerInput di;
/*     */   protected int poc;
/*     */   protected BlockInterpolator interpolator;
/*     */   protected Picture[] mbb;
/*     */   protected int[][] scalingMatrix;
/*     */   
/*     */   public MBlockDecoderBase(SliceHeader sh, DeblockerInput di, int poc, DecoderState decoderState) {
/*  42 */     this.interpolator = new BlockInterpolator();
/*  43 */     this.s = decoderState;
/*  44 */     this.sh = sh;
/*  45 */     this.di = di;
/*  46 */     this.poc = poc;
/*  47 */     this.mbb = new Picture[] { Picture.create(16, 16, this.s.chromaFormat), Picture.create(16, 16, this.s.chromaFormat) };
/*  48 */     this.scalingMatrix = initScalingMatrix(sh);
/*     */   }
/*     */   
/*     */   void residualLuma(MBlock mBlock, boolean leftAvailable, boolean topAvailable, int mbX, int mbY) {
/*  52 */     if (!mBlock.transform8x8Used) {
/*  53 */       residualLuma4x4(mBlock);
/*  54 */     } else if (this.sh.pps.entropyCodingModeFlag) {
/*  55 */       residualLuma8x8CABAC(mBlock);
/*     */     } else {
/*  57 */       residualLuma8x8CAVLC(mBlock);
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   private void residualLuma4x4(MBlock mBlock) {
/*  63 */     for (int i = 0; i < 16; i++) {
/*  64 */       if ((mBlock.cbpLuma() & 1 << i >> 2) != 0) {
/*     */ 
/*     */ 
/*     */         
/*  68 */         CoeffTransformer.dequantizeAC(mBlock.ac[0][i], this.s.qp, getScalingList(mBlock.curMbType.intra ? 0 : 3));
/*  69 */         CoeffTransformer.idct4x4(mBlock.ac[0][i]);
/*     */       } 
/*     */     } 
/*     */   }
/*     */   protected int[] getScalingList(int which) {
/*  74 */     if (this.scalingMatrix == null)
/*  75 */       return null; 
/*  76 */     return this.scalingMatrix[which];
/*     */   }
/*     */   
/*     */   protected static int[][] initScalingMatrix(SliceHeader sh2) {
/*  80 */     if (sh2.sps.scalingMatrix == null && (sh2.pps.extended == null || sh2.pps.extended.scalingMatrix == null))
/*  81 */       return (int[][])null; 
/*  82 */     int[][] merged = { H264Const.defaultScalingList4x4Intra, null, null, H264Const.defaultScalingList4x4Inter, null, null, H264Const.defaultScalingList8x8Intra, H264Const.defaultScalingList8x8Inter, null, null, null, null };
/*     */ 
/*     */     
/*  85 */     for (int i = 0; i < 8; i++) {
/*  86 */       if (sh2.sps.scalingMatrix != null && sh2.sps.scalingMatrix[i] != null)
/*  87 */         merged[i] = sh2.sps.scalingMatrix[i]; 
/*  88 */       if (sh2.pps.extended != null && sh2.pps.extended.scalingMatrix != null && sh2.pps.extended.scalingMatrix[i] != null)
/*     */       {
/*  90 */         merged[i] = sh2.pps.extended.scalingMatrix[i]; } 
/*     */     } 
/*  92 */     if (merged[1] == null)
/*  93 */       merged[1] = merged[0]; 
/*  94 */     if (merged[2] == null)
/*  95 */       merged[2] = merged[0]; 
/*  96 */     if (merged[4] == null)
/*  97 */       merged[4] = merged[3]; 
/*  98 */     if (merged[5] == null)
/*  99 */       merged[5] = merged[3]; 
/* 100 */     if (merged[8] == null)
/* 101 */       merged[8] = merged[6]; 
/* 102 */     if (merged[10] == null)
/* 103 */       merged[10] = merged[6]; 
/* 104 */     if (merged[9] == null)
/* 105 */       merged[9] = merged[7]; 
/* 106 */     if (merged[11] == null)
/* 107 */       merged[11] = merged[7]; 
/* 108 */     return merged;
/*     */   }
/*     */ 
/*     */   
/*     */   private void residualLuma8x8CABAC(MBlock mBlock) {
/* 113 */     for (int i = 0; i < 4; i++) {
/* 114 */       if ((mBlock.cbpLuma() & 1 << i) != 0) {
/*     */ 
/*     */ 
/*     */         
/* 118 */         CoeffTransformer.dequantizeAC8x8(mBlock.ac[0][i], this.s.qp, getScalingList(mBlock.curMbType.intra ? 6 : 7));
/* 119 */         CoeffTransformer.idct8x8(mBlock.ac[0][i]);
/*     */       } 
/*     */     } 
/*     */   }
/*     */   
/*     */   private void residualLuma8x8CAVLC(MBlock mBlock) {
/* 125 */     for (int i = 0; i < 4; i++) {
/* 126 */       if ((mBlock.cbpLuma() & 1 << i) != 0) {
/*     */ 
/*     */ 
/*     */         
/* 130 */         CoeffTransformer.dequantizeAC8x8(mBlock.ac[0][i], this.s.qp, getScalingList(mBlock.curMbType.intra ? 6 : 7));
/* 131 */         CoeffTransformer.idct8x8(mBlock.ac[0][i]);
/*     */       } 
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public void decodeChroma(MBlock mBlock, int mbX, int mbY, boolean leftAvailable, boolean topAvailable, Picture mb, int qp) {
/* 138 */     if (this.s.chromaFormat == ColorSpace.MONO) {
/* 139 */       Arrays.fill(mb.getPlaneData(1), (byte)0);
/* 140 */       Arrays.fill(mb.getPlaneData(2), (byte)0);
/*     */       
/*     */       return;
/*     */     } 
/* 144 */     int qp1 = calcQpChroma(qp, this.s.chromaQpOffset[0]);
/* 145 */     int qp2 = calcQpChroma(qp, this.s.chromaQpOffset[1]);
/*     */     
/* 147 */     if (mBlock.cbpChroma() != 0) {
/* 148 */       decodeChromaResidual(mBlock, leftAvailable, topAvailable, mbX, mbY, qp1, qp2);
/*     */     }
/* 150 */     int addr = mbY * (this.sh.sps.picWidthInMbsMinus1 + 1) + mbX;
/* 151 */     this.di.mbQps[1][addr] = qp1;
/* 152 */     this.di.mbQps[2][addr] = qp2;
/* 153 */     ChromaPredictionBuilder.predictWithMode(mBlock.ac[1], mBlock.chromaPredictionMode, mbX, leftAvailable, topAvailable, this.s.leftRow[1], this.s.topLine[1], this.s.topLeft[1], mb
/* 154 */         .getPlaneData(1));
/* 155 */     ChromaPredictionBuilder.predictWithMode(mBlock.ac[2], mBlock.chromaPredictionMode, mbX, leftAvailable, topAvailable, this.s.leftRow[2], this.s.topLine[2], this.s.topLeft[2], mb
/* 156 */         .getPlaneData(2));
/*     */   }
/*     */ 
/*     */   
/*     */   void decodeChromaResidual(MBlock mBlock, boolean leftAvailable, boolean topAvailable, int mbX, int mbY, int crQp1, int crQp2) {
/* 161 */     if (mBlock.cbpChroma() != 0) {
/* 162 */       if ((mBlock.cbpChroma() & 0x3) > 0) {
/* 163 */         chromaDC(mbX, leftAvailable, topAvailable, mBlock.dc1, 1, crQp1, mBlock.curMbType);
/* 164 */         chromaDC(mbX, leftAvailable, topAvailable, mBlock.dc2, 2, crQp2, mBlock.curMbType);
/*     */       } 
/*     */       
/* 167 */       chromaAC(leftAvailable, topAvailable, mbX, mbY, mBlock.dc1, 1, crQp1, mBlock.curMbType, 
/* 168 */           ((mBlock.cbpChroma() & 0x2) > 0), mBlock.ac[1]);
/* 169 */       chromaAC(leftAvailable, topAvailable, mbX, mbY, mBlock.dc2, 2, crQp2, mBlock.curMbType, 
/* 170 */           ((mBlock.cbpChroma() & 0x2) > 0), mBlock.ac[2]);
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   private void chromaDC(int mbX, boolean leftAvailable, boolean topAvailable, int[] dc, int comp, int crQp, MBType curMbType) {
/* 176 */     CoeffTransformer.invDC2x2(dc);
/* 177 */     CoeffTransformer.dequantizeDC2x2(dc, crQp, getScalingList((curMbType.intra ? 6 : 7) + comp * 2));
/*     */   }
/*     */ 
/*     */   
/*     */   private void chromaAC(boolean leftAvailable, boolean topAvailable, int mbX, int mbY, int[] dc, int comp, int crQp, MBType curMbType, boolean codedAC, int[][] residualOut) {
/* 182 */     for (int i = 0; i < dc.length; i++) {
/* 183 */       int[] ac = residualOut[i];
/*     */       
/* 185 */       if (codedAC) {
/* 186 */         CoeffTransformer.dequantizeAC(ac, crQp, getScalingList((curMbType.intra ? 0 : 3) + comp));
/*     */       }
/* 188 */       ac[0] = dc[i];
/* 189 */       CoeffTransformer.idct4x4(ac);
/*     */     } 
/*     */   }
/*     */   
/*     */   static int calcQpChroma(int qp, int crQpOffset) {
/* 194 */     return H264Const.QP_SCALE_CR[MathUtil.clip(qp + crQpOffset, 0, 51)];
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void predictChromaInter(Frame[][] refs, H264Utils.MvList vectors, int x, int y, int comp, Picture mb, H264Const.PartPred[] predType) {
/* 200 */     for (int blk8x8 = 0; blk8x8 < 4; blk8x8++) {
/* 201 */       for (int list = 0; list < 2; list++) {
/* 202 */         if (H264Const.usesList(predType[blk8x8], list))
/*     */         {
/* 204 */           for (int i = 0; i < 4; i++) {
/* 205 */             int j = H264Const.BLK_INV_MAP[(blk8x8 << 2) + i];
/* 206 */             int mv = vectors.getMv(j, list);
/* 207 */             Frame frame = refs[list][H264Utils.Mv.mvRef(mv)];
/*     */             
/* 209 */             int blkPox = (j & 0x3) << 1;
/* 210 */             int blkPoy = j >> 2 << 1;
/*     */             
/* 212 */             int xx = (x + blkPox << 3) + H264Utils.Mv.mvX(mv);
/* 213 */             int yy = (y + blkPoy << 3) + H264Utils.Mv.mvY(mv);
/*     */             
/* 215 */             BlockInterpolator.getBlockChroma(frame.getPlaneData(comp), frame.getPlaneWidth(comp), frame
/* 216 */                 .getPlaneHeight(comp), this.mbb[list].getPlaneData(comp), blkPoy * mb.getPlaneWidth(comp) + blkPox, mb
/* 217 */                 .getPlaneWidth(comp), xx, yy, 2, 2);
/*     */           } 
/*     */         }
/*     */       } 
/* 221 */       int blk4x4 = H264Const.BLK8x8_BLOCKS[blk8x8][0];
/* 222 */       PredictionMerger.mergePrediction(this.sh, vectors.mv0R(blk4x4), vectors.mv1R(blk4x4), predType[blk8x8], comp, this.mbb[0]
/* 223 */           .getPlaneData(comp), this.mbb[1].getPlaneData(comp), H264Const.BLK_8x8_MB_OFF_CHROMA[blk8x8], mb
/* 224 */           .getPlaneWidth(comp), 4, 4, mb.getPlaneData(comp), refs, this.poc);
/*     */     } 
/*     */   }
/*     */ }


/* Location:              C:\Users\rapha\Downloads\aurora.jar!\META-INF\jars\jcodec-0.2.5.jar!\org\jcodec\codecs\h264\decode\MBlockDecoderBase.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */