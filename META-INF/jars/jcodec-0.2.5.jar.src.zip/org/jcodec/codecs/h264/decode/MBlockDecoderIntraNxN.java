/*    */ package org.jcodec.codecs.h264.decode;
/*    */ 
/*    */ import org.jcodec.codecs.h264.H264Const;
/*    */ import org.jcodec.codecs.h264.decode.aso.Mapper;
/*    */ import org.jcodec.codecs.h264.io.model.SliceHeader;
/*    */ import org.jcodec.common.model.Picture;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class MBlockDecoderIntraNxN
/*    */   extends MBlockDecoderBase
/*    */ {
/*    */   private Mapper mapper;
/*    */   private Intra8x8PredictionBuilder prediction8x8Builder;
/*    */   
/*    */   public MBlockDecoderIntraNxN(Mapper mapper, SliceHeader sh, DeblockerInput di, int poc, DecoderState decoderState) {
/* 19 */     super(sh, di, poc, decoderState);
/* 20 */     this.mapper = mapper;
/* 21 */     this.prediction8x8Builder = new Intra8x8PredictionBuilder();
/*    */   }
/*    */ 
/*    */   
/*    */   public void decode(MBlock mBlock, Picture mb) {
/* 26 */     int mbX = this.mapper.getMbX(mBlock.mbIdx);
/* 27 */     int mbY = this.mapper.getMbY(mBlock.mbIdx);
/* 28 */     int mbAddr = this.mapper.getAddress(mBlock.mbIdx);
/* 29 */     boolean leftAvailable = this.mapper.leftAvailable(mBlock.mbIdx);
/* 30 */     boolean topAvailable = this.mapper.topAvailable(mBlock.mbIdx);
/* 31 */     boolean topLeftAvailable = this.mapper.topLeftAvailable(mBlock.mbIdx);
/* 32 */     boolean topRightAvailable = this.mapper.topRightAvailable(mBlock.mbIdx);
/*    */     
/* 34 */     if (mBlock.cbpLuma() > 0 || mBlock.cbpChroma() > 0) {
/* 35 */       this.s.qp = (this.s.qp + mBlock.mbQPDelta + 52) % 52;
/*    */     }
/* 37 */     this.di.mbQps[0][mbAddr] = this.s.qp;
/*    */     
/* 39 */     residualLuma(mBlock, leftAvailable, topAvailable, mbX, mbY);
/*    */     
/* 41 */     if (!mBlock.transform8x8Used) {
/* 42 */       for (int i = 0; i < 16; i++) {
/* 43 */         int blkX = (i & 0x3) << 2;
/* 44 */         int blkY = i & 0xFFFFFFFC;
/*    */         
/* 46 */         int bi = H264Const.BLK_INV_MAP[i];
/* 47 */         boolean trAvailable = (((bi == 0 || bi == 1 || bi == 4) && topAvailable) || (bi == 5 && topRightAvailable) || bi == 2 || bi == 6 || bi == 8 || bi == 9 || bi == 10 || bi == 12 || bi == 14);
/*    */ 
/*    */ 
/*    */         
/* 51 */         Intra4x4PredictionBuilder.predictWithMode(mBlock.lumaModes[bi], mBlock.ac[0][bi], (blkX == 0) ? leftAvailable : true, (blkY == 0) ? topAvailable : true, trAvailable, this.s.leftRow[0], this.s.topLine[0], this.s.topLeft[0], mbX << 4, blkX, blkY, mb
/*    */             
/* 53 */             .getPlaneData(0));
/*    */       } 
/*    */     } else {
/* 56 */       for (int i = 0; i < 4; i++) {
/* 57 */         int blkX = (i & 0x1) << 1;
/* 58 */         int blkY = i & 0x2;
/*    */         
/* 60 */         boolean trAvailable = ((i == 0 && topAvailable) || (i == 1 && topRightAvailable) || i == 2);
/* 61 */         boolean tlAvailable = (i == 0) ? topLeftAvailable : ((i == 1) ? topAvailable : ((i == 2) ? leftAvailable : true));
/*    */ 
/*    */         
/* 64 */         this.prediction8x8Builder.predictWithMode(mBlock.lumaModes[i], mBlock.ac[0][i], (blkX == 0) ? leftAvailable : true, (blkY == 0) ? topAvailable : true, tlAvailable, trAvailable, this.s.leftRow[0], this.s.topLine[0], this.s.topLeft[0], mbX << 4, blkX << 2, blkY << 2, mb
/*    */             
/* 66 */             .getPlaneData(0));
/*    */       } 
/*    */     } 
/*    */     
/* 70 */     decodeChroma(mBlock, mbX, mbY, leftAvailable, topAvailable, mb, this.s.qp);
/*    */     
/* 72 */     this.di.mbTypes[mbAddr] = mBlock.curMbType;
/* 73 */     this.di.tr8x8Used[mbAddr] = mBlock.transform8x8Used;
/*    */     
/* 75 */     MBlockDecoderUtils.collectChromaPredictors(this.s, mb, mbX);
/*    */     
/* 77 */     MBlockDecoderUtils.saveMvsIntra(this.di, mbX, mbY);
/* 78 */     MBlockDecoderUtils.saveVectIntra(this.s, this.mapper.getMbX(mBlock.mbIdx));
/*    */   }
/*    */ }


/* Location:              C:\Users\rapha\Downloads\aurora.jar!\META-INF\jars\jcodec-0.2.5.jar!\org\jcodec\codecs\h264\decode\MBlockDecoderIntraNxN.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */