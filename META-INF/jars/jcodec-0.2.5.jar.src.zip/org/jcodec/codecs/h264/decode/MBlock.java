/*     */ package org.jcodec.codecs.h264.decode;
/*     */ 
/*     */ import java.util.Arrays;
/*     */ import org.jcodec.codecs.h264.H264Const;
/*     */ import org.jcodec.codecs.h264.H264Utils;
/*     */ import org.jcodec.codecs.h264.io.model.MBType;
/*     */ import org.jcodec.common.model.ColorSpace;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class MBlock
/*     */ {
/*     */   public int chromaPredictionMode;
/*     */   public int mbQPDelta;
/*     */   public int[] dc;
/*     */   public int[][][] ac;
/*     */   public boolean transform8x8Used;
/*     */   public int[] lumaModes;
/*     */   public int[] dc1;
/*     */   public int[] dc2;
/*     */   public int _cbp;
/*     */   public int mbType;
/*     */   public MBType curMbType;
/*     */   public PB16x16 pb16x16;
/*     */   public PB168x168 pb168x168;
/*     */   public PB8x8 pb8x8;
/*     */   public IPCM ipcm;
/*     */   public int mbIdx;
/*     */   public boolean fieldDecoding;
/*     */   public MBType prevMbType;
/*     */   public int luma16x16Mode;
/*     */   public H264Utils.MvList x;
/*     */   public H264Const.PartPred[] partPreds;
/*     */   public boolean skipped;
/*     */   public int[] nCoeff;
/*     */   
/*     */   public MBlock(ColorSpace chromaFormat) {
/*  47 */     this.pb8x8 = new PB8x8();
/*  48 */     this.pb16x16 = new PB16x16();
/*  49 */     this.pb168x168 = new PB168x168();
/*     */     
/*  51 */     this.dc = new int[16];
/*  52 */     this.ac = new int[][][] { new int[16][64], new int[4][16], new int[4][16] };
/*  53 */     this.lumaModes = new int[16];
/*  54 */     this.nCoeff = new int[16];
/*  55 */     this.dc1 = new int[16 >> chromaFormat.compWidth[1] >> chromaFormat.compHeight[1]];
/*  56 */     this.dc2 = new int[16 >> chromaFormat.compWidth[2] >> chromaFormat.compHeight[2]];
/*  57 */     this.ipcm = new IPCM(chromaFormat);
/*  58 */     this.x = new H264Utils.MvList(16);
/*  59 */     this.partPreds = new H264Const.PartPred[4];
/*     */   }
/*     */   
/*     */   public int cbpLuma() {
/*  63 */     return this._cbp & 0xF;
/*     */   }
/*     */   
/*     */   public int cbpChroma() {
/*  67 */     return this._cbp >> 4;
/*     */   }
/*     */   
/*     */   public void cbp(int cbpLuma, int cbpChroma) {
/*  71 */     this._cbp = cbpLuma & 0xF | cbpChroma << 4;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static class PB16x16
/*     */   {
/*  80 */     public int[] refIdx = new int[2];
/*  81 */     public int[] mvdX = new int[2];
/*  82 */     public int[] mvdY = new int[2];
/*     */ 
/*     */     
/*     */     public void clean() {
/*  86 */       this.refIdx[1] = 0; this.refIdx[0] = 0;
/*  87 */       this.mvdX[1] = 0; this.mvdX[0] = 0;
/*  88 */       this.mvdY[1] = 0; this.mvdY[0] = 0;
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static class PB168x168
/*     */   {
/* 101 */     public int[] refIdx1 = new int[2];
/* 102 */     public int[] refIdx2 = new int[2];
/* 103 */     public int[] mvdX1 = new int[2];
/* 104 */     public int[] mvdY1 = new int[2];
/* 105 */     public int[] mvdX2 = new int[2];
/* 106 */     public int[] mvdY2 = new int[2];
/*     */ 
/*     */     
/*     */     public void clean() {
/* 110 */       this.refIdx1[1] = 0; this.refIdx1[0] = 0;
/* 111 */       this.refIdx2[1] = 0; this.refIdx2[0] = 0;
/*     */       
/* 113 */       this.mvdX1[1] = 0; this.mvdX1[0] = 0;
/* 114 */       this.mvdY1[1] = 0; this.mvdY1[0] = 0;
/* 115 */       this.mvdX2[1] = 0; this.mvdX2[0] = 0;
/* 116 */       this.mvdY2[1] = 0; this.mvdY2[0] = 0;
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static class PB8x8
/*     */   {
/* 133 */     public int[][] refIdx = new int[2][4];
/* 134 */     public int[] subMbTypes = new int[4];
/* 135 */     public int[][] mvdX1 = new int[2][4];
/* 136 */     public int[][] mvdY1 = new int[2][4];
/* 137 */     public int[][] mvdX2 = new int[2][4];
/* 138 */     public int[][] mvdY2 = new int[2][4];
/* 139 */     public int[][] mvdX3 = new int[2][4];
/* 140 */     public int[][] mvdY3 = new int[2][4];
/* 141 */     public int[][] mvdX4 = new int[2][4];
/* 142 */     public int[][] mvdY4 = new int[2][4];
/*     */ 
/*     */     
/*     */     public void clean() {
/* 146 */       this.mvdX1[0][3] = 0; this.mvdX1[0][2] = 0; this.mvdX1[0][1] = 0; this.mvdX1[0][0] = 0;
/* 147 */       this.mvdX2[0][3] = 0; this.mvdX2[0][2] = 0; this.mvdX2[0][1] = 0; this.mvdX2[0][0] = 0;
/* 148 */       this.mvdX3[0][3] = 0; this.mvdX3[0][2] = 0; this.mvdX3[0][1] = 0; this.mvdX3[0][0] = 0;
/* 149 */       this.mvdX4[0][3] = 0; this.mvdX4[0][2] = 0; this.mvdX4[0][1] = 0; this.mvdX4[0][0] = 0;
/*     */       
/* 151 */       this.mvdY1[0][3] = 0; this.mvdY1[0][2] = 0; this.mvdY1[0][1] = 0; this.mvdY1[0][0] = 0;
/* 152 */       this.mvdY2[0][3] = 0; this.mvdY2[0][2] = 0; this.mvdY2[0][1] = 0; this.mvdY2[0][0] = 0;
/* 153 */       this.mvdY3[0][3] = 0; this.mvdY3[0][2] = 0; this.mvdY3[0][1] = 0; this.mvdY3[0][0] = 0;
/* 154 */       this.mvdY4[0][3] = 0; this.mvdY4[0][2] = 0; this.mvdY4[0][1] = 0; this.mvdY4[0][0] = 0;
/*     */       
/* 156 */       this.mvdX1[1][3] = 0; this.mvdX1[1][2] = 0; this.mvdX1[1][1] = 0; this.mvdX1[1][0] = 0;
/* 157 */       this.mvdX2[1][3] = 0; this.mvdX2[1][2] = 0; this.mvdX2[1][1] = 0; this.mvdX2[1][0] = 0;
/* 158 */       this.mvdX3[1][3] = 0; this.mvdX3[1][2] = 0; this.mvdX3[1][1] = 0; this.mvdX3[1][0] = 0;
/* 159 */       this.mvdX4[1][3] = 0; this.mvdX4[1][2] = 0; this.mvdX4[1][1] = 0; this.mvdX4[1][0] = 0;
/*     */       
/* 161 */       this.mvdY1[1][3] = 0; this.mvdY1[1][2] = 0; this.mvdY1[1][1] = 0; this.mvdY1[1][0] = 0;
/* 162 */       this.mvdY2[1][3] = 0; this.mvdY2[1][2] = 0; this.mvdY2[1][1] = 0; this.mvdY2[1][0] = 0;
/* 163 */       this.mvdY3[1][3] = 0; this.mvdY3[1][2] = 0; this.mvdY3[1][1] = 0; this.mvdY3[1][0] = 0;
/* 164 */       this.mvdY4[1][3] = 0; this.mvdY4[1][2] = 0; this.mvdY4[1][1] = 0; this.mvdY4[1][0] = 0;
/*     */       
/* 166 */       this.subMbTypes[3] = 0; this.subMbTypes[2] = 0; this.subMbTypes[1] = 0; this.subMbTypes[0] = 0;
/* 167 */       this.refIdx[0][3] = 0; this.refIdx[0][2] = 0; this.refIdx[0][1] = 0; this.refIdx[0][0] = 0;
/* 168 */       this.refIdx[1][3] = 0; this.refIdx[1][2] = 0; this.refIdx[1][1] = 0; this.refIdx[1][0] = 0;
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static class IPCM
/*     */   {
/* 178 */     public int[] samplesLuma = new int[256]; public IPCM(ColorSpace chromaFormat) {
/* 179 */       int MbWidthC = 16 >> chromaFormat.compWidth[1];
/* 180 */       int MbHeightC = 16 >> chromaFormat.compHeight[1];
/*     */       
/* 182 */       this.samplesChroma = new int[2 * MbWidthC * MbHeightC];
/*     */     }
/*     */     public int[] samplesChroma;
/*     */     public void clean() {
/* 186 */       Arrays.fill(this.samplesLuma, 0);
/* 187 */       Arrays.fill(this.samplesChroma, 0);
/*     */     }
/*     */   }
/*     */   
/*     */   public void clear() {
/* 192 */     this.chromaPredictionMode = 0;
/* 193 */     this.mbQPDelta = 0;
/* 194 */     Arrays.fill(this.dc, 0);
/* 195 */     for (int i = 0; i < this.ac.length; i++) {
/* 196 */       int[][] aci = this.ac[i];
/* 197 */       for (int j = 0; j < aci.length; j++) {
/* 198 */         Arrays.fill(aci[j], 0);
/*     */       }
/*     */     } 
/* 201 */     this.transform8x8Used = false;
/* 202 */     Arrays.fill(this.lumaModes, 0);
/* 203 */     Arrays.fill(this.dc1, 0);
/* 204 */     Arrays.fill(this.dc2, 0);
/* 205 */     Arrays.fill(this.nCoeff, 0);
/* 206 */     this._cbp = 0;
/* 207 */     this.mbType = 0;
/* 208 */     this.pb16x16.clean();
/* 209 */     this.pb168x168.clean();
/* 210 */     this.pb8x8.clean();
/* 211 */     if (this.curMbType == MBType.I_PCM)
/* 212 */       this.ipcm.clean(); 
/* 213 */     this.mbIdx = 0;
/* 214 */     this.fieldDecoding = false;
/* 215 */     this.prevMbType = null;
/* 216 */     this.luma16x16Mode = 0;
/* 217 */     this.skipped = false;
/* 218 */     this.curMbType = null;
/* 219 */     this.x.clear();
/* 220 */     this.partPreds[3] = null; this.partPreds[2] = null; this.partPreds[1] = null; this.partPreds[0] = null;
/*     */   }
/*     */ }


/* Location:              C:\Users\rapha\Downloads\aurora.jar!\META-INF\jars\jcodec-0.2.5.jar!\org\jcodec\codecs\h264\decode\MBlock.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */