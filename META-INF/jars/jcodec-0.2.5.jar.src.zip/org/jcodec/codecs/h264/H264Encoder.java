/*     */ package org.jcodec.codecs.h264;
/*     */ import java.nio.ByteBuffer;
/*     */ import org.jcodec.codecs.h264.encode.DumbRateControl;
/*     */ import org.jcodec.codecs.h264.encode.EncodedMB;
/*     */ import org.jcodec.codecs.h264.encode.MBEncoderHelper;
/*     */ import org.jcodec.codecs.h264.encode.MBEncoderI16x16;
/*     */ import org.jcodec.codecs.h264.encode.MBEncoderP16x16;
/*     */ import org.jcodec.codecs.h264.encode.MotionEstimator;
/*     */ import org.jcodec.codecs.h264.encode.RateControl;
/*     */ import org.jcodec.codecs.h264.io.CAVLC;
/*     */ import org.jcodec.codecs.h264.io.model.MBType;
/*     */ import org.jcodec.codecs.h264.io.model.NALUnit;
/*     */ import org.jcodec.codecs.h264.io.model.NALUnitType;
/*     */ import org.jcodec.codecs.h264.io.model.PictureParameterSet;
/*     */ import org.jcodec.codecs.h264.io.model.RefPicMarkingIDR;
/*     */ import org.jcodec.codecs.h264.io.model.SeqParameterSet;
/*     */ import org.jcodec.codecs.h264.io.model.SliceHeader;
/*     */ import org.jcodec.codecs.h264.io.model.SliceType;
/*     */ import org.jcodec.codecs.h264.io.write.CAVLCWriter;
/*     */ import org.jcodec.codecs.h264.io.write.SliceHeaderWriter;
/*     */ import org.jcodec.common.VideoEncoder;
/*     */ import org.jcodec.common.io.BitWriter;
/*     */ import org.jcodec.common.logging.Logger;
/*     */ import org.jcodec.common.model.ColorSpace;
/*     */ import org.jcodec.common.model.Picture;
/*     */ import org.jcodec.common.model.Size;
/*     */ import org.jcodec.common.tools.MathUtil;
/*     */ 
/*     */ public class H264Encoder extends VideoEncoder {
/*     */   private static final int KEY_INTERVAL_DEFAULT = 25;
/*     */   private static final int MOTION_SEARCH_RANGE_DEFAULT = 16;
/*     */   private CAVLC[] cavlc;
/*     */   private byte[][] leftRow;
/*     */   private byte[][] topLine;
/*     */   private RateControl rc;
/*     */   private int frameNumber;
/*     */   private int keyInterval;
/*     */   private int motionSearchRange;
/*     */   private int maxPOC;
/*     */   private int maxFrameNumber;
/*     */   private SeqParameterSet sps;
/*     */   private PictureParameterSet pps;
/*     */   private MBEncoderI16x16 mbEncoderI16x16;
/*     */   private MBEncoderP16x16 mbEncoderP16x16;
/*     */   private Picture ref;
/*     */   private Picture picOut;
/*     */   private EncodedMB[] topEncoded;
/*     */   private EncodedMB outMB;
/*     */   
/*     */   public static H264Encoder createH264Encoder() {
/*  51 */     return new H264Encoder((RateControl)new DumbRateControl());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public H264Encoder(RateControl rc) {
/*  81 */     this.rc = rc;
/*  82 */     this.keyInterval = 25;
/*  83 */     this.motionSearchRange = 16;
/*     */   }
/*     */   
/*     */   public int getKeyInterval() {
/*  87 */     return this.keyInterval;
/*     */   }
/*     */   
/*     */   public void setKeyInterval(int keyInterval) {
/*  91 */     this.keyInterval = keyInterval;
/*     */   }
/*     */   
/*     */   public int getMotionSearchRange() {
/*  95 */     return this.motionSearchRange;
/*     */   }
/*     */   
/*     */   public void setMotionSearchRange(int motionSearchRange) {
/*  99 */     this.motionSearchRange = motionSearchRange;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public VideoEncoder.EncodedFrame encodeFrame(Picture pic, ByteBuffer _out) {
/* 107 */     if (pic.getColor() != ColorSpace.YUV420J) {
/* 108 */       throw new IllegalArgumentException("Input picture color is not supported: " + pic.getColor());
/*     */     }
/* 110 */     if (this.frameNumber >= this.keyInterval) {
/* 111 */       this.frameNumber = 0;
/*     */     }
/*     */     
/* 114 */     SliceType sliceType = (this.frameNumber == 0) ? SliceType.I : SliceType.P;
/* 115 */     boolean idr = (this.frameNumber == 0);
/*     */     
/* 117 */     ByteBuffer data = doEncodeFrame(pic, _out, idr, this.frameNumber++, sliceType);
/* 118 */     return new VideoEncoder.EncodedFrame(data, idr);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ByteBuffer encodeIDRFrame(Picture pic, ByteBuffer _out) {
/* 130 */     this.frameNumber = 0;
/* 131 */     return doEncodeFrame(pic, _out, true, this.frameNumber, SliceType.I);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ByteBuffer encodePFrame(Picture pic, ByteBuffer _out) {
/* 144 */     this.frameNumber++;
/* 145 */     return doEncodeFrame(pic, _out, true, this.frameNumber, SliceType.P);
/*     */   }
/*     */   
/*     */   public ByteBuffer doEncodeFrame(Picture pic, ByteBuffer _out, boolean idr, int frameNumber, SliceType frameType) {
/* 149 */     ByteBuffer dup = _out.duplicate();
/* 150 */     int maxSize = Math.min(dup.remaining(), pic.getWidth() * pic.getHeight());
/* 151 */     maxSize -= maxSize >>> 6;
/* 152 */     int qp = this.rc.startPicture(pic.getSize(), maxSize, frameType);
/*     */     
/* 154 */     if (idr) {
/* 155 */       this.sps = initSPS(new Size(pic.getCroppedWidth(), pic.getCroppedHeight()));
/* 156 */       this.pps = initPPS();
/*     */       
/* 158 */       this.maxPOC = 1 << this.sps.log2MaxPicOrderCntLsbMinus4 + 4;
/* 159 */       this.maxFrameNumber = 1 << this.sps.log2MaxFrameNumMinus4 + 4;
/*     */     } 
/*     */     
/* 162 */     if (idr) {
/* 163 */       dup.putInt(1);
/* 164 */       (new NALUnit(NALUnitType.SPS, 3)).write(dup);
/* 165 */       writeSPS(dup, this.sps);
/*     */       
/* 167 */       dup.putInt(1);
/* 168 */       (new NALUnit(NALUnitType.PPS, 3)).write(dup);
/* 169 */       writePPS(dup, this.pps);
/*     */     } 
/*     */     
/* 172 */     int mbWidth = this.sps.picWidthInMbsMinus1 + 1;
/* 173 */     int mbHeight = this.sps.picHeightInMapUnitsMinus1 + 1;
/*     */     
/* 175 */     this.leftRow = new byte[][] { new byte[16], new byte[8], new byte[8] };
/* 176 */     this.topLine = new byte[][] { new byte[mbWidth << 4], new byte[mbWidth << 3], new byte[mbWidth << 3] };
/* 177 */     this.picOut = Picture.create(mbWidth << 4, mbHeight << 4, ColorSpace.YUV420J);
/*     */     
/* 179 */     this.outMB = new EncodedMB();
/* 180 */     this.topEncoded = new EncodedMB[mbWidth];
/* 181 */     for (int i = 0; i < mbWidth; i++) {
/* 182 */       this.topEncoded[i] = new EncodedMB();
/*     */     }
/* 184 */     encodeSlice(this.sps, this.pps, pic, dup, idr, frameNumber, frameType, qp);
/*     */     
/* 186 */     putLastMBLine();
/*     */     
/* 188 */     this.ref = this.picOut;
/*     */     
/* 190 */     dup.flip();
/* 191 */     return dup;
/*     */   }
/*     */   
/*     */   private void writePPS(ByteBuffer dup, PictureParameterSet pps) {
/* 195 */     ByteBuffer tmp = ByteBuffer.allocate(1024);
/* 196 */     pps.write(tmp);
/* 197 */     tmp.flip();
/* 198 */     H264Utils.escapeNAL(tmp, dup);
/*     */   }
/*     */   
/*     */   private void writeSPS(ByteBuffer dup, SeqParameterSet sps) {
/* 202 */     ByteBuffer tmp = ByteBuffer.allocate(1024);
/* 203 */     sps.write(tmp);
/* 204 */     tmp.flip();
/* 205 */     H264Utils.escapeNAL(tmp, dup);
/*     */   }
/*     */   
/*     */   public PictureParameterSet initPPS() {
/* 209 */     PictureParameterSet pps = new PictureParameterSet();
/* 210 */     pps.picInitQpMinus26 = 0;
/* 211 */     return pps;
/*     */   }
/*     */   
/*     */   public SeqParameterSet initSPS(Size sz) {
/* 215 */     SeqParameterSet sps = new SeqParameterSet();
/* 216 */     sps.picWidthInMbsMinus1 = (sz.getWidth() + 15 >> 4) - 1;
/* 217 */     sps.picHeightInMapUnitsMinus1 = (sz.getHeight() + 15 >> 4) - 1;
/* 218 */     sps.chromaFormatIdc = ColorSpace.YUV420J;
/* 219 */     sps.profileIdc = 66;
/* 220 */     sps.levelIdc = 40;
/* 221 */     sps.numRefFrames = 1;
/* 222 */     sps.frameMbsOnlyFlag = true;
/* 223 */     sps.log2MaxFrameNumMinus4 = Math.max(0, MathUtil.log2(this.keyInterval) - 3);
/*     */     
/* 225 */     int codedWidth = sps.picWidthInMbsMinus1 + 1 << 4;
/* 226 */     int codedHeight = sps.picHeightInMapUnitsMinus1 + 1 << 4;
/* 227 */     sps.frameCroppingFlag = (codedWidth != sz.getWidth() || codedHeight != sz.getHeight());
/* 228 */     sps.frameCropRightOffset = codedWidth - sz.getWidth() + 1 >> 1;
/* 229 */     sps.frameCropBottomOffset = codedHeight - sz.getHeight() + 1 >> 1;
/*     */     
/* 231 */     return sps;
/*     */   }
/*     */ 
/*     */   
/*     */   private void encodeSlice(SeqParameterSet sps, PictureParameterSet pps, Picture pic, ByteBuffer dup, boolean idr, int frameNum, SliceType sliceType, int qp) {
/* 236 */     if (idr && sliceType != SliceType.I) {
/* 237 */       idr = false;
/* 238 */       Logger.warn("Illegal value of idr = true when sliceType != I");
/*     */     } 
/* 240 */     this.cavlc = new CAVLC[] { new CAVLC(sps, pps, 2, 2), new CAVLC(sps, pps, 1, 1), new CAVLC(sps, pps, 1, 1) };
/* 241 */     this.mbEncoderI16x16 = new MBEncoderI16x16(this.cavlc, this.leftRow, this.topLine);
/* 242 */     this.mbEncoderP16x16 = new MBEncoderP16x16(sps, this.ref, this.cavlc, new MotionEstimator(this.motionSearchRange));
/*     */     
/* 244 */     dup.putInt(1);
/* 245 */     (new NALUnit(idr ? NALUnitType.IDR_SLICE : NALUnitType.NON_IDR_SLICE, 3)).write(dup);
/* 246 */     SliceHeader sh = new SliceHeader();
/* 247 */     sh.sliceType = sliceType;
/* 248 */     if (idr)
/* 249 */       sh.refPicMarkingIDR = new RefPicMarkingIDR(false, false); 
/* 250 */     sh.pps = pps;
/* 251 */     sh.sps = sps;
/* 252 */     sh.picOrderCntLsb = (frameNum << 1) % this.maxPOC;
/* 253 */     sh.frameNum = frameNum % this.maxFrameNumber;
/* 254 */     sh.sliceQpDelta = qp - pps.picInitQpMinus26 + 26;
/*     */     
/* 256 */     ByteBuffer buf = ByteBuffer.allocate(pic.getWidth() * pic.getHeight());
/* 257 */     BitWriter sliceData = new BitWriter(buf);
/* 258 */     SliceHeaderWriter.write(sh, idr, 2, sliceData);
/*     */     
/* 260 */     for (int mbY = 0, mbAddr = 0; mbY < sps.picHeightInMapUnitsMinus1 + 1; mbY++) {
/* 261 */       for (int mbX = 0; mbX < sps.picWidthInMbsMinus1 + 1; mbX++, mbAddr++) {
/* 262 */         if (sliceType == SliceType.P) {
/* 263 */           CAVLCWriter.writeUE(sliceData, 0);
/*     */         }
/*     */         
/* 266 */         MBType mbType = selectMBType(sliceType);
/*     */         
/* 268 */         if (mbType == MBType.I_16x16) {
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */           
/* 274 */           int predMode = this.mbEncoderI16x16.getPredMode(pic, mbX, mbY);
/* 275 */           int cbpChroma = this.mbEncoderI16x16.getCbpChroma(pic, mbX, mbY);
/* 276 */           int cbpLuma = this.mbEncoderI16x16.getCbpLuma(pic, mbX, mbY);
/*     */           
/* 278 */           int i16x16TypeOffset = cbpLuma / 15 * 12 + cbpChroma * 4 + predMode;
/* 279 */           int mbTypeOffset = (sliceType == SliceType.P) ? 5 : 0;
/*     */           
/* 281 */           CAVLCWriter.writeUE(sliceData, mbTypeOffset + mbType.code() + i16x16TypeOffset);
/*     */         } else {
/* 283 */           CAVLCWriter.writeUE(sliceData, mbType.code());
/*     */         } 
/*     */ 
/*     */         
/* 287 */         int totalQpDelta = 0;
/* 288 */         int qpDelta = this.rc.initialQpDelta();
/*     */         while (true) {
/* 290 */           BitWriter candidate = sliceData.fork();
/* 291 */           totalQpDelta += qpDelta;
/* 292 */           encodeMacroblock(mbType, pic, mbX, mbY, candidate, qp, totalQpDelta);
/* 293 */           qpDelta = this.rc.accept(candidate.position() - sliceData.position());
/* 294 */           if (qpDelta != 0)
/* 295 */             restoreMacroblock(mbType); 
/* 296 */           if (qpDelta == 0)
/* 297 */           { sliceData = candidate;
/* 298 */             qp += totalQpDelta;
/*     */             
/* 300 */             collectPredictors(this.outMB.getPixels(), mbX);
/* 301 */             addToReference(mbX, mbY); break; } 
/*     */         } 
/*     */       } 
/* 304 */     }  sliceData.write1Bit(1);
/* 305 */     sliceData.flush();
/* 306 */     buf = sliceData.getBuffer();
/* 307 */     buf.flip();
/*     */     
/* 309 */     H264Utils.escapeNAL(buf, dup);
/*     */   }
/*     */   
/*     */   private void encodeMacroblock(MBType mbType, Picture pic, int mbX, int mbY, BitWriter candidate, int qp, int qpDelta) {
/* 313 */     if (mbType == MBType.I_16x16) {
/* 314 */       this.mbEncoderI16x16.save();
/* 315 */       this.mbEncoderI16x16.encodeMacroblock(pic, mbX, mbY, candidate, this.outMB, (mbX > 0) ? this.topEncoded[mbX - 1] : null, (mbY > 0) ? this.topEncoded[mbX] : null, qp + qpDelta, qpDelta);
/*     */     }
/* 317 */     else if (mbType == MBType.P_16x16) {
/* 318 */       this.mbEncoderP16x16.save();
/* 319 */       this.mbEncoderP16x16.encodeMacroblock(pic, mbX, mbY, candidate, this.outMB, (mbX > 0) ? this.topEncoded[mbX - 1] : null, (mbY > 0) ? this.topEncoded[mbX] : null, qp + qpDelta, qpDelta);
/*     */     } else {
/*     */       
/* 322 */       throw new RuntimeException("Macroblock of type " + mbType + " is not supported.");
/*     */     } 
/*     */   }
/*     */   private void restoreMacroblock(MBType mbType) {
/* 326 */     if (mbType == MBType.I_16x16) {
/* 327 */       this.mbEncoderI16x16.restore();
/* 328 */     } else if (mbType == MBType.P_16x16) {
/* 329 */       this.mbEncoderP16x16.restore();
/*     */     } else {
/* 331 */       throw new RuntimeException("Macroblock of type " + mbType + " is not supported.");
/*     */     } 
/*     */   }
/*     */   private MBType selectMBType(SliceType sliceType) {
/* 335 */     if (sliceType == SliceType.I)
/* 336 */       return MBType.I_16x16; 
/* 337 */     if (sliceType == SliceType.P) {
/* 338 */       return MBType.P_16x16;
/*     */     }
/* 340 */     throw new RuntimeException("Unsupported slice type");
/*     */   }
/*     */   
/*     */   private void addToReference(int mbX, int mbY) {
/* 344 */     if (mbY > 0)
/* 345 */       MBEncoderHelper.putBlkPic(this.picOut, this.topEncoded[mbX].getPixels(), mbX << 4, mbY - 1 << 4); 
/* 346 */     EncodedMB tmp = this.topEncoded[mbX];
/* 347 */     this.topEncoded[mbX] = this.outMB;
/* 348 */     this.outMB = tmp;
/*     */   }
/*     */   
/*     */   private void putLastMBLine() {
/* 352 */     int mbWidth = this.sps.picWidthInMbsMinus1 + 1;
/* 353 */     int mbHeight = this.sps.picHeightInMapUnitsMinus1 + 1;
/* 354 */     for (int mbX = 0; mbX < mbWidth; mbX++)
/* 355 */       MBEncoderHelper.putBlkPic(this.picOut, this.topEncoded[mbX].getPixels(), mbX << 4, mbHeight - 1 << 4); 
/*     */   }
/*     */   
/*     */   private void collectPredictors(Picture outMB, int mbX) {
/* 359 */     System.arraycopy(outMB.getPlaneData(0), 240, this.topLine[0], mbX << 4, 16);
/* 360 */     System.arraycopy(outMB.getPlaneData(1), 56, this.topLine[1], mbX << 3, 8);
/* 361 */     System.arraycopy(outMB.getPlaneData(2), 56, this.topLine[2], mbX << 3, 8);
/*     */     
/* 363 */     copyCol(outMB.getPlaneData(0), 15, 16, this.leftRow[0]);
/* 364 */     copyCol(outMB.getPlaneData(1), 7, 8, this.leftRow[1]);
/* 365 */     copyCol(outMB.getPlaneData(2), 7, 8, this.leftRow[2]);
/*     */   }
/*     */   
/*     */   private void copyCol(byte[] planeData, int off, int stride, byte[] out) {
/* 369 */     for (int i = 0; i < out.length; i++) {
/* 370 */       out[i] = planeData[off];
/* 371 */       off += stride;
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public ColorSpace[] getSupportedColorSpaces() {
/* 377 */     return new ColorSpace[] { ColorSpace.YUV420J };
/*     */   }
/*     */ 
/*     */   
/*     */   public int estimateBufferSize(Picture frame) {
/* 382 */     return Math.max(65536, frame.getWidth() * frame.getHeight() / 2);
/*     */   }
/*     */ }


/* Location:              C:\Users\rapha\Downloads\aurora.jar!\META-INF\jars\jcodec-0.2.5.jar!\org\jcodec\codecs\h264\H264Encoder.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */