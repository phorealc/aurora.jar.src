/*     */ package org.jcodec.codecs.h264.io.model;
/*     */ 
/*     */ import java.nio.ByteBuffer;
/*     */ import java.util.Arrays;
/*     */ import org.jcodec.codecs.h264.decode.CAVLCReader;
/*     */ import org.jcodec.codecs.h264.io.write.CAVLCWriter;
/*     */ import org.jcodec.common.io.BitReader;
/*     */ import org.jcodec.common.io.BitWriter;
/*     */ import org.jcodec.platform.Platform;
/*     */ 
/*     */ public class PictureParameterSet
/*     */ {
/*     */   public boolean entropyCodingModeFlag;
/*     */   public int[] numRefIdxActiveMinus1;
/*     */   public int sliceGroupChangeRateMinus1;
/*     */   public int picParameterSetId;
/*     */   public int seqParameterSetId;
/*     */   public boolean picOrderPresentFlag;
/*     */   public int numSliceGroupsMinus1;
/*     */   public int sliceGroupMapType;
/*     */   public boolean weightedPredFlag;
/*     */   public int weightedBipredIdc;
/*     */   public int picInitQpMinus26;
/*     */   public int picInitQsMinus26;
/*     */   public int chromaQpIndexOffset;
/*     */   public boolean deblockingFilterControlPresentFlag;
/*     */   public boolean constrainedIntraPredFlag;
/*     */   public boolean redundantPicCntPresentFlag;
/*     */   public int[] topLeft;
/*     */   public int[] bottomRight;
/*     */   public int[] runLengthMinus1;
/*     */   public boolean sliceGroupChangeDirectionFlag;
/*     */   public int[] sliceGroupId;
/*     */   public PPSExt extended;
/*     */   
/*     */   public static class PPSExt {
/*     */     public boolean transform8x8ModeFlag;
/*     */     public int[][] scalingMatrix;
/*     */     public int secondChromaQpIndexOffset;
/*     */     
/*     */     public boolean isTransform8x8ModeFlag() {
/*  42 */       return this.transform8x8ModeFlag;
/*     */     }
/*     */     
/*     */     public int[][] getScalingMatrix() {
/*  46 */       return this.scalingMatrix;
/*     */     }
/*     */ 
/*     */     
/*     */     public int getSecondChromaQpIndexOffset() {
/*  51 */       return this.secondChromaQpIndexOffset;
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public PictureParameterSet() {
/* 100 */     this.numRefIdxActiveMinus1 = new int[2];
/*     */   }
/*     */   
/*     */   public static PictureParameterSet read(ByteBuffer is) {
/* 104 */     BitReader _in = BitReader.createBitReader(is);
/* 105 */     PictureParameterSet pps = new PictureParameterSet();
/*     */     
/* 107 */     pps.picParameterSetId = CAVLCReader.readUEtrace(_in, "PPS: pic_parameter_set_id");
/* 108 */     pps.seqParameterSetId = CAVLCReader.readUEtrace(_in, "PPS: seq_parameter_set_id");
/* 109 */     pps.entropyCodingModeFlag = CAVLCReader.readBool(_in, "PPS: entropy_coding_mode_flag");
/* 110 */     pps.picOrderPresentFlag = CAVLCReader.readBool(_in, "PPS: pic_order_present_flag");
/* 111 */     pps.numSliceGroupsMinus1 = CAVLCReader.readUEtrace(_in, "PPS: num_slice_groups_minus1");
/* 112 */     if (pps.numSliceGroupsMinus1 > 0) {
/* 113 */       pps.sliceGroupMapType = CAVLCReader.readUEtrace(_in, "PPS: slice_group_map_type");
/* 114 */       pps.topLeft = new int[pps.numSliceGroupsMinus1 + 1];
/* 115 */       pps.bottomRight = new int[pps.numSliceGroupsMinus1 + 1];
/* 116 */       pps.runLengthMinus1 = new int[pps.numSliceGroupsMinus1 + 1];
/* 117 */       if (pps.sliceGroupMapType == 0) {
/* 118 */         for (int iGroup = 0; iGroup <= pps.numSliceGroupsMinus1; iGroup++)
/* 119 */           pps.runLengthMinus1[iGroup] = CAVLCReader.readUEtrace(_in, "PPS: run_length_minus1"); 
/* 120 */       } else if (pps.sliceGroupMapType == 2) {
/* 121 */         for (int iGroup = 0; iGroup < pps.numSliceGroupsMinus1; iGroup++) {
/* 122 */           pps.topLeft[iGroup] = CAVLCReader.readUEtrace(_in, "PPS: top_left");
/* 123 */           pps.bottomRight[iGroup] = CAVLCReader.readUEtrace(_in, "PPS: bottom_right");
/*     */         } 
/* 125 */       } else if (pps.sliceGroupMapType == 3 || pps.sliceGroupMapType == 4 || pps.sliceGroupMapType == 5) {
/* 126 */         pps.sliceGroupChangeDirectionFlag = CAVLCReader.readBool(_in, "PPS: slice_group_change_direction_flag");
/* 127 */         pps.sliceGroupChangeRateMinus1 = CAVLCReader.readUEtrace(_in, "PPS: slice_group_change_rate_minus1");
/* 128 */       } else if (pps.sliceGroupMapType == 6) {
/*     */         int NumberBitsPerSliceGroupId;
/* 130 */         if (pps.numSliceGroupsMinus1 + 1 > 4) {
/* 131 */           NumberBitsPerSliceGroupId = 3;
/* 132 */         } else if (pps.numSliceGroupsMinus1 + 1 > 2) {
/* 133 */           NumberBitsPerSliceGroupId = 2;
/*     */         } else {
/* 135 */           NumberBitsPerSliceGroupId = 1;
/* 136 */         }  int pic_size_in_map_units_minus1 = CAVLCReader.readUEtrace(_in, "PPS: pic_size_in_map_units_minus1");
/* 137 */         pps.sliceGroupId = new int[pic_size_in_map_units_minus1 + 1];
/* 138 */         for (int i = 0; i <= pic_size_in_map_units_minus1; i++) {
/* 139 */           pps.sliceGroupId[i] = CAVLCReader.readU(_in, NumberBitsPerSliceGroupId, "PPS: slice_group_id [" + i + "]f");
/*     */         }
/*     */       } 
/*     */     } 
/* 143 */     pps.numRefIdxActiveMinus1 = new int[] { CAVLCReader.readUEtrace(_in, "PPS: num_ref_idx_l0_active_minus1"), CAVLCReader.readUEtrace(_in, "PPS: num_ref_idx_l1_active_minus1") };
/* 144 */     pps.weightedPredFlag = CAVLCReader.readBool(_in, "PPS: weighted_pred_flag");
/* 145 */     pps.weightedBipredIdc = CAVLCReader.readNBit(_in, 2, "PPS: weighted_bipred_idc");
/* 146 */     pps.picInitQpMinus26 = CAVLCReader.readSE(_in, "PPS: pic_init_qp_minus26");
/* 147 */     pps.picInitQsMinus26 = CAVLCReader.readSE(_in, "PPS: pic_init_qs_minus26");
/* 148 */     pps.chromaQpIndexOffset = CAVLCReader.readSE(_in, "PPS: chroma_qp_index_offset");
/* 149 */     pps.deblockingFilterControlPresentFlag = CAVLCReader.readBool(_in, "PPS: deblocking_filter_control_present_flag");
/* 150 */     pps.constrainedIntraPredFlag = CAVLCReader.readBool(_in, "PPS: constrained_intra_pred_flag");
/* 151 */     pps.redundantPicCntPresentFlag = CAVLCReader.readBool(_in, "PPS: redundant_pic_cnt_present_flag");
/* 152 */     if (CAVLCReader.moreRBSPData(_in)) {
/* 153 */       pps.extended = new PPSExt();
/* 154 */       pps.extended.transform8x8ModeFlag = CAVLCReader.readBool(_in, "PPS: transform_8x8_mode_flag");
/* 155 */       boolean pic_scaling_matrix_present_flag = CAVLCReader.readBool(_in, "PPS: pic_scaling_matrix_present_flag");
/* 156 */       if (pic_scaling_matrix_present_flag) {
/* 157 */         pps.extended.scalingMatrix = new int[8][];
/* 158 */         for (int i = 0; i < 6 + 2 * (pps.extended.transform8x8ModeFlag ? 1 : 0); i++) {
/* 159 */           int scalingListSize = (i < 6) ? 16 : 64;
/* 160 */           if (CAVLCReader.readBool(_in, "PPS: pic_scaling_list_present_flag")) {
/* 161 */             pps.extended.scalingMatrix[i] = SeqParameterSet.readScalingList(_in, scalingListSize);
/*     */           }
/*     */         } 
/*     */       } 
/* 165 */       pps.extended.secondChromaQpIndexOffset = CAVLCReader.readSE(_in, "PPS: second_chroma_qp_index_offset");
/*     */     } 
/*     */     
/* 168 */     return pps;
/*     */   }
/*     */   
/*     */   public void write(ByteBuffer out) {
/* 172 */     BitWriter writer = new BitWriter(out);
/*     */     
/* 174 */     CAVLCWriter.writeUEtrace(writer, this.picParameterSetId, "PPS: pic_parameter_set_id");
/* 175 */     CAVLCWriter.writeUEtrace(writer, this.seqParameterSetId, "PPS: seq_parameter_set_id");
/* 176 */     CAVLCWriter.writeBool(writer, this.entropyCodingModeFlag, "PPS: entropy_coding_mode_flag");
/* 177 */     CAVLCWriter.writeBool(writer, this.picOrderPresentFlag, "PPS: pic_order_present_flag");
/* 178 */     CAVLCWriter.writeUEtrace(writer, this.numSliceGroupsMinus1, "PPS: num_slice_groups_minus1");
/* 179 */     if (this.numSliceGroupsMinus1 > 0) {
/* 180 */       CAVLCWriter.writeUEtrace(writer, this.sliceGroupMapType, "PPS: slice_group_map_type");
/* 181 */       if (this.sliceGroupMapType == 0) {
/* 182 */         for (int iGroup = 0; iGroup <= this.numSliceGroupsMinus1; iGroup++) {
/* 183 */           CAVLCWriter.writeUEtrace(writer, this.runLengthMinus1[iGroup], "PPS: ");
/*     */         }
/* 185 */       } else if (this.sliceGroupMapType == 2) {
/* 186 */         for (int iGroup = 0; iGroup < this.numSliceGroupsMinus1; iGroup++) {
/* 187 */           CAVLCWriter.writeUEtrace(writer, this.topLeft[iGroup], "PPS: ");
/* 188 */           CAVLCWriter.writeUEtrace(writer, this.bottomRight[iGroup], "PPS: ");
/*     */         } 
/* 190 */       } else if (this.sliceGroupMapType == 3 || this.sliceGroupMapType == 4 || this.sliceGroupMapType == 5) {
/* 191 */         CAVLCWriter.writeBool(writer, this.sliceGroupChangeDirectionFlag, "PPS: slice_group_change_direction_flag");
/* 192 */         CAVLCWriter.writeUEtrace(writer, this.sliceGroupChangeRateMinus1, "PPS: slice_group_change_rate_minus1");
/* 193 */       } else if (this.sliceGroupMapType == 6) {
/*     */         int NumberBitsPerSliceGroupId;
/* 195 */         if (this.numSliceGroupsMinus1 + 1 > 4) {
/* 196 */           NumberBitsPerSliceGroupId = 3;
/* 197 */         } else if (this.numSliceGroupsMinus1 + 1 > 2) {
/* 198 */           NumberBitsPerSliceGroupId = 2;
/*     */         } else {
/* 200 */           NumberBitsPerSliceGroupId = 1;
/* 201 */         }  CAVLCWriter.writeUEtrace(writer, this.sliceGroupId.length, "PPS: ");
/* 202 */         for (int i = 0; i <= this.sliceGroupId.length; i++) {
/* 203 */           CAVLCWriter.writeU(writer, this.sliceGroupId[i], NumberBitsPerSliceGroupId);
/*     */         }
/*     */       } 
/*     */     } 
/* 207 */     CAVLCWriter.writeUEtrace(writer, this.numRefIdxActiveMinus1[0], "PPS: num_ref_idx_l0_active_minus1");
/* 208 */     CAVLCWriter.writeUEtrace(writer, this.numRefIdxActiveMinus1[1], "PPS: num_ref_idx_l1_active_minus1");
/* 209 */     CAVLCWriter.writeBool(writer, this.weightedPredFlag, "PPS: weighted_pred_flag");
/* 210 */     CAVLCWriter.writeNBit(writer, this.weightedBipredIdc, 2, "PPS: weighted_bipred_idc");
/* 211 */     CAVLCWriter.writeSEtrace(writer, this.picInitQpMinus26, "PPS: pic_init_qp_minus26");
/* 212 */     CAVLCWriter.writeSEtrace(writer, this.picInitQsMinus26, "PPS: pic_init_qs_minus26");
/* 213 */     CAVLCWriter.writeSEtrace(writer, this.chromaQpIndexOffset, "PPS: chroma_qp_index_offset");
/* 214 */     CAVLCWriter.writeBool(writer, this.deblockingFilterControlPresentFlag, "PPS: deblocking_filter_control_present_flag");
/* 215 */     CAVLCWriter.writeBool(writer, this.constrainedIntraPredFlag, "PPS: constrained_intra_pred_flag");
/* 216 */     CAVLCWriter.writeBool(writer, this.redundantPicCntPresentFlag, "PPS: redundant_pic_cnt_present_flag");
/* 217 */     if (this.extended != null) {
/* 218 */       CAVLCWriter.writeBool(writer, this.extended.transform8x8ModeFlag, "PPS: transform_8x8_mode_flag");
/* 219 */       CAVLCWriter.writeBool(writer, (this.extended.scalingMatrix != null), "PPS: scalindMatrix");
/* 220 */       if (this.extended.scalingMatrix != null) {
/* 221 */         for (int i = 0; i < 6 + 2 * (this.extended.transform8x8ModeFlag ? 1 : 0); i++) {
/* 222 */           CAVLCWriter.writeBool(writer, (this.extended.scalingMatrix[i] != null), "PPS: ");
/* 223 */           if (this.extended.scalingMatrix[i] != null) {
/* 224 */             SeqParameterSet.writeScalingList(writer, this.extended.scalingMatrix, i);
/*     */           }
/*     */         } 
/*     */       }
/* 228 */       CAVLCWriter.writeSEtrace(writer, this.extended.secondChromaQpIndexOffset, "PPS: ");
/*     */     } 
/*     */     
/* 231 */     CAVLCWriter.writeTrailingBits(writer);
/*     */   }
/*     */ 
/*     */   
/*     */   public int hashCode() {
/* 236 */     int prime = 31;
/* 237 */     int result = 1;
/* 238 */     result = 31 * result + Arrays.hashCode(this.bottomRight);
/* 239 */     result = 31 * result + this.chromaQpIndexOffset;
/* 240 */     result = 31 * result + (this.constrainedIntraPredFlag ? 1231 : 1237);
/* 241 */     result = 31 * result + (this.deblockingFilterControlPresentFlag ? 1231 : 1237);
/* 242 */     result = 31 * result + (this.entropyCodingModeFlag ? 1231 : 1237);
/* 243 */     result = 31 * result + ((this.extended == null) ? 0 : this.extended.hashCode());
/* 244 */     result = 31 * result + this.numRefIdxActiveMinus1[0];
/* 245 */     result = 31 * result + this.numRefIdxActiveMinus1[1];
/* 246 */     result = 31 * result + this.numSliceGroupsMinus1;
/* 247 */     result = 31 * result + this.picInitQpMinus26;
/* 248 */     result = 31 * result + this.picInitQsMinus26;
/* 249 */     result = 31 * result + (this.picOrderPresentFlag ? 1231 : 1237);
/* 250 */     result = 31 * result + this.picParameterSetId;
/* 251 */     result = 31 * result + (this.redundantPicCntPresentFlag ? 1231 : 1237);
/* 252 */     result = 31 * result + Arrays.hashCode(this.runLengthMinus1);
/* 253 */     result = 31 * result + this.seqParameterSetId;
/* 254 */     result = 31 * result + (this.sliceGroupChangeDirectionFlag ? 1231 : 1237);
/* 255 */     result = 31 * result + this.sliceGroupChangeRateMinus1;
/* 256 */     result = 31 * result + Arrays.hashCode(this.sliceGroupId);
/* 257 */     result = 31 * result + this.sliceGroupMapType;
/* 258 */     result = 31 * result + Arrays.hashCode(this.topLeft);
/* 259 */     result = 31 * result + this.weightedBipredIdc;
/* 260 */     result = 31 * result + (this.weightedPredFlag ? 1231 : 1237);
/* 261 */     return result;
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean equals(Object obj) {
/* 266 */     if (this == obj)
/* 267 */       return true; 
/* 268 */     if (obj == null)
/* 269 */       return false; 
/* 270 */     if (getClass() != obj.getClass())
/* 271 */       return false; 
/* 272 */     PictureParameterSet other = (PictureParameterSet)obj;
/* 273 */     if (!Platform.arrayEqualsInt(this.bottomRight, other.bottomRight))
/* 274 */       return false; 
/* 275 */     if (this.chromaQpIndexOffset != other.chromaQpIndexOffset)
/* 276 */       return false; 
/* 277 */     if (this.constrainedIntraPredFlag != other.constrainedIntraPredFlag)
/* 278 */       return false; 
/* 279 */     if (this.deblockingFilterControlPresentFlag != other.deblockingFilterControlPresentFlag)
/* 280 */       return false; 
/* 281 */     if (this.entropyCodingModeFlag != other.entropyCodingModeFlag)
/* 282 */       return false; 
/* 283 */     if (this.extended == null) {
/* 284 */       if (other.extended != null)
/* 285 */         return false; 
/* 286 */     } else if (!this.extended.equals(other.extended)) {
/* 287 */       return false;
/* 288 */     }  if (this.numRefIdxActiveMinus1[0] != other.numRefIdxActiveMinus1[0])
/* 289 */       return false; 
/* 290 */     if (this.numRefIdxActiveMinus1[1] != other.numRefIdxActiveMinus1[1])
/* 291 */       return false; 
/* 292 */     if (this.numSliceGroupsMinus1 != other.numSliceGroupsMinus1)
/* 293 */       return false; 
/* 294 */     if (this.picInitQpMinus26 != other.picInitQpMinus26)
/* 295 */       return false; 
/* 296 */     if (this.picInitQsMinus26 != other.picInitQsMinus26)
/* 297 */       return false; 
/* 298 */     if (this.picOrderPresentFlag != other.picOrderPresentFlag)
/* 299 */       return false; 
/* 300 */     if (this.picParameterSetId != other.picParameterSetId)
/* 301 */       return false; 
/* 302 */     if (this.redundantPicCntPresentFlag != other.redundantPicCntPresentFlag)
/* 303 */       return false; 
/* 304 */     if (!Platform.arrayEqualsInt(this.runLengthMinus1, other.runLengthMinus1))
/* 305 */       return false; 
/* 306 */     if (this.seqParameterSetId != other.seqParameterSetId)
/* 307 */       return false; 
/* 308 */     if (this.sliceGroupChangeDirectionFlag != other.sliceGroupChangeDirectionFlag)
/* 309 */       return false; 
/* 310 */     if (this.sliceGroupChangeRateMinus1 != other.sliceGroupChangeRateMinus1)
/* 311 */       return false; 
/* 312 */     if (!Platform.arrayEqualsInt(this.sliceGroupId, other.sliceGroupId))
/* 313 */       return false; 
/* 314 */     if (this.sliceGroupMapType != other.sliceGroupMapType)
/* 315 */       return false; 
/* 316 */     if (!Platform.arrayEqualsInt(this.topLeft, other.topLeft))
/* 317 */       return false; 
/* 318 */     if (this.weightedBipredIdc != other.weightedBipredIdc)
/* 319 */       return false; 
/* 320 */     if (this.weightedPredFlag != other.weightedPredFlag)
/* 321 */       return false; 
/* 322 */     return true;
/*     */   }
/*     */   
/*     */   public PictureParameterSet copy() {
/* 326 */     ByteBuffer buf = ByteBuffer.allocate(2048);
/* 327 */     write(buf);
/* 328 */     buf.flip();
/* 329 */     return read(buf);
/*     */   }
/*     */   
/*     */   public boolean isEntropyCodingModeFlag() {
/* 333 */     return this.entropyCodingModeFlag;
/*     */   }
/*     */   
/*     */   public int[] getNumRefIdxActiveMinus1() {
/* 337 */     return this.numRefIdxActiveMinus1;
/*     */   }
/*     */   
/*     */   public int getSliceGroupChangeRateMinus1() {
/* 341 */     return this.sliceGroupChangeRateMinus1;
/*     */   }
/*     */   
/*     */   public int getPicParameterSetId() {
/* 345 */     return this.picParameterSetId;
/*     */   }
/*     */   
/*     */   public int getSeqParameterSetId() {
/* 349 */     return this.seqParameterSetId;
/*     */   }
/*     */   
/*     */   public boolean isPicOrderPresentFlag() {
/* 353 */     return this.picOrderPresentFlag;
/*     */   }
/*     */   
/*     */   public int getNumSliceGroupsMinus1() {
/* 357 */     return this.numSliceGroupsMinus1;
/*     */   }
/*     */   
/*     */   public int getSliceGroupMapType() {
/* 361 */     return this.sliceGroupMapType;
/*     */   }
/*     */   
/*     */   public boolean isWeightedPredFlag() {
/* 365 */     return this.weightedPredFlag;
/*     */   }
/*     */   
/*     */   public int getWeightedBipredIdc() {
/* 369 */     return this.weightedBipredIdc;
/*     */   }
/*     */   
/*     */   public int getPicInitQpMinus26() {
/* 373 */     return this.picInitQpMinus26;
/*     */   }
/*     */   
/*     */   public int getPicInitQsMinus26() {
/* 377 */     return this.picInitQsMinus26;
/*     */   }
/*     */   
/*     */   public int getChromaQpIndexOffset() {
/* 381 */     return this.chromaQpIndexOffset;
/*     */   }
/*     */   
/*     */   public boolean isDeblockingFilterControlPresentFlag() {
/* 385 */     return this.deblockingFilterControlPresentFlag;
/*     */   }
/*     */   
/*     */   public boolean isConstrainedIntraPredFlag() {
/* 389 */     return this.constrainedIntraPredFlag;
/*     */   }
/*     */   
/*     */   public boolean isRedundantPicCntPresentFlag() {
/* 393 */     return this.redundantPicCntPresentFlag;
/*     */   }
/*     */   
/*     */   public int[] getTopLeft() {
/* 397 */     return this.topLeft;
/*     */   }
/*     */   
/*     */   public int[] getBottomRight() {
/* 401 */     return this.bottomRight;
/*     */   }
/*     */   
/*     */   public int[] getRunLengthMinus1() {
/* 405 */     return this.runLengthMinus1;
/*     */   }
/*     */   
/*     */   public boolean isSliceGroupChangeDirectionFlag() {
/* 409 */     return this.sliceGroupChangeDirectionFlag;
/*     */   }
/*     */   
/*     */   public int[] getSliceGroupId() {
/* 413 */     return this.sliceGroupId;
/*     */   }
/*     */   
/*     */   public PPSExt getExtended() {
/* 417 */     return this.extended;
/*     */   }
/*     */ }


/* Location:              C:\Users\rapha\Downloads\aurora.jar!\META-INF\jars\jcodec-0.2.5.jar!\org\jcodec\codecs\h264\io\model\PictureParameterSet.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */