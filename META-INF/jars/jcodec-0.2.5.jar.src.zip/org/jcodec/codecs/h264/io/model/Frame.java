/*     */ package org.jcodec.codecs.h264.io.model;
/*     */ 
/*     */ import java.util.Comparator;
/*     */ import org.jcodec.codecs.h264.H264Utils;
/*     */ import org.jcodec.common.model.ColorSpace;
/*     */ import org.jcodec.common.model.Picture;
/*     */ import org.jcodec.common.model.Rect;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class Frame
/*     */   extends Picture
/*     */ {
/*     */   private int frameNo;
/*     */   private SliceType frameType;
/*     */   private H264Utils.MvList2D mvs;
/*     */   private Frame[][][] refsUsed;
/*     */   private boolean shortTerm;
/*     */   private int poc;
/*     */   
/*     */   public Frame(int width, int height, byte[][] data, ColorSpace color, Rect crop, int frameNo, SliceType frameType, H264Utils.MvList2D mvs, Frame[][][] refsUsed, int poc) {
/*  29 */     super(width, height, data, (byte[][])null, color, 0, crop);
/*  30 */     this.frameNo = frameNo;
/*  31 */     this.mvs = mvs;
/*  32 */     this.refsUsed = refsUsed;
/*  33 */     this.poc = poc;
/*  34 */     this.shortTerm = true;
/*     */   }
/*     */   
/*     */   public static Frame createFrame(Frame pic) {
/*  38 */     Picture comp = pic.createCompatible();
/*  39 */     return new Frame(comp.getWidth(), comp.getHeight(), comp.getData(), comp.getColor(), pic.getCrop(), pic.frameNo, pic.frameType, pic.mvs, pic.refsUsed, pic.poc);
/*     */   }
/*     */ 
/*     */   
/*     */   public Frame cropped() {
/*  44 */     Picture cropped = super.cropped();
/*  45 */     return new Frame(cropped.getWidth(), cropped.getHeight(), cropped.getData(), cropped.getColor(), null, this.frameNo, this.frameType, this.mvs, this.refsUsed, this.poc);
/*     */   }
/*     */ 
/*     */   
/*     */   public void copyFromFrame(Frame src) {
/*  50 */     copyFrom(src);
/*  51 */     this.frameNo = src.frameNo;
/*  52 */     this.mvs = src.mvs;
/*  53 */     this.shortTerm = src.shortTerm;
/*  54 */     this.refsUsed = src.refsUsed;
/*  55 */     this.poc = src.poc;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Frame cloneCropped() {
/*  64 */     if (cropNeeded()) {
/*  65 */       return cropped();
/*     */     }
/*  67 */     Frame clone = createFrame(this);
/*  68 */     clone.copyFrom(this);
/*  69 */     return clone;
/*     */   }
/*     */ 
/*     */   
/*     */   public int getFrameNo() {
/*  74 */     return this.frameNo;
/*     */   }
/*     */   
/*     */   public H264Utils.MvList2D getMvs() {
/*  78 */     return this.mvs;
/*     */   }
/*     */   
/*     */   public boolean isShortTerm() {
/*  82 */     return this.shortTerm;
/*     */   }
/*     */   
/*     */   public void setShortTerm(boolean shortTerm) {
/*  86 */     this.shortTerm = shortTerm;
/*     */   }
/*     */   
/*     */   public int getPOC() {
/*  90 */     return this.poc;
/*     */   }
/*     */   
/*  93 */   public static Comparator<Frame> POCAsc = new Comparator<Frame>() {
/*     */       public int compare(Frame o1, Frame o2) {
/*  95 */         if (o1 == null && o2 == null)
/*  96 */           return 0; 
/*  97 */         if (o1 == null)
/*  98 */           return 1; 
/*  99 */         if (o2 == null) {
/* 100 */           return -1;
/*     */         }
/* 102 */         return (o1.poc > o2.poc) ? 1 : ((o1.poc == o2.poc) ? 0 : -1);
/*     */       }
/*     */     };
/*     */   
/* 106 */   public static Comparator<Frame> POCDesc = new Comparator<Frame>() {
/*     */       public int compare(Frame o1, Frame o2) {
/* 108 */         if (o1 == null && o2 == null)
/* 109 */           return 0; 
/* 110 */         if (o1 == null)
/* 111 */           return 1; 
/* 112 */         if (o2 == null) {
/* 113 */           return -1;
/*     */         }
/* 115 */         return (o1.poc < o2.poc) ? 1 : ((o1.poc == o2.poc) ? 0 : -1);
/*     */       }
/*     */     };
/*     */   
/*     */   public Frame[][][] getRefsUsed() {
/* 120 */     return this.refsUsed;
/*     */   }
/*     */   
/*     */   public SliceType getFrameType() {
/* 124 */     return this.frameType;
/*     */   }
/*     */ }


/* Location:              C:\Users\rapha\Downloads\aurora.jar!\META-INF\jars\jcodec-0.2.5.jar!\org\jcodec\codecs\h264\io\model\Frame.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */