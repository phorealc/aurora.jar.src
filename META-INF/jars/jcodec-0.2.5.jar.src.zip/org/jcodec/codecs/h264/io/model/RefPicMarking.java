/*    */ package org.jcodec.codecs.h264.io.model;
/*    */ 
/*    */ import org.jcodec.platform.Platform;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class RefPicMarking
/*    */ {
/*    */   private Instruction[] instructions;
/*    */   
/*    */   public enum InstrType
/*    */   {
/* 18 */     REMOVE_SHORT, REMOVE_LONG, CONVERT_INTO_LONG, TRUNK_LONG, CLEAR, MARK_LONG;
/*    */   }
/*    */   
/*    */   public static class Instruction {
/*    */     private RefPicMarking.InstrType type;
/*    */     private int arg1;
/*    */     private int arg2;
/*    */     
/*    */     public Instruction(RefPicMarking.InstrType type, int arg1, int arg2) {
/* 27 */       this.type = type;
/* 28 */       this.arg1 = arg1;
/* 29 */       this.arg2 = arg2;
/*    */     }
/*    */     
/*    */     public RefPicMarking.InstrType getType() {
/* 33 */       return this.type;
/*    */     }
/*    */     
/*    */     public int getArg1() {
/* 37 */       return this.arg1;
/*    */     }
/*    */     
/*    */     public int getArg2() {
/* 41 */       return this.arg2;
/*    */     }
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public RefPicMarking(Instruction[] instructions) {
/* 48 */     this.instructions = instructions;
/*    */   }
/*    */   
/*    */   public Instruction[] getInstructions() {
/* 52 */     return this.instructions;
/*    */   }
/*    */ 
/*    */   
/*    */   public String toString() {
/* 57 */     return Platform.toJSON(this);
/*    */   }
/*    */ }


/* Location:              C:\Users\rapha\Downloads\aurora.jar!\META-INF\jars\jcodec-0.2.5.jar!\org\jcodec\codecs\h264\io\model\RefPicMarking.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */