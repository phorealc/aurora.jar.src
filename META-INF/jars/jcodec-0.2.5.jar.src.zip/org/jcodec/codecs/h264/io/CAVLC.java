/*     */ package org.jcodec.codecs.h264.io;
/*     */ 
/*     */ import org.jcodec.codecs.h264.H264Const;
/*     */ import org.jcodec.codecs.h264.decode.CAVLCReader;
/*     */ import org.jcodec.codecs.h264.io.model.MBType;
/*     */ import org.jcodec.codecs.h264.io.model.PictureParameterSet;
/*     */ import org.jcodec.codecs.h264.io.model.SeqParameterSet;
/*     */ import org.jcodec.common.SaveRestore;
/*     */ import org.jcodec.common.io.BitReader;
/*     */ import org.jcodec.common.io.BitWriter;
/*     */ import org.jcodec.common.io.VLC;
/*     */ import org.jcodec.common.model.ColorSpace;
/*     */ import org.jcodec.common.tools.MathUtil;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class CAVLC
/*     */   implements SaveRestore
/*     */ {
/*     */   private ColorSpace color;
/*     */   private VLC chromaDCVLC;
/*     */   private int[] tokensLeft;
/*     */   private int[] tokensTop;
/*     */   private int[] tokensLeftSaved;
/*     */   private int[] tokensTopSaved;
/*     */   private int mbWidth;
/*     */   private int mbMask;
/*     */   
/*     */   public CAVLC(SeqParameterSet sps, PictureParameterSet pps, int mbW, int mbH) {
/*  42 */     this.color = sps.chromaFormatIdc;
/*  43 */     this.chromaDCVLC = codeTableChromaDC();
/*  44 */     this.mbWidth = sps.picWidthInMbsMinus1 + 1;
/*     */     
/*  46 */     this.mbMask = (1 << mbH) - 1;
/*     */     
/*  48 */     this.tokensLeft = new int[4];
/*  49 */     this.tokensTop = new int[this.mbWidth << mbW];
/*  50 */     this.tokensLeftSaved = new int[4];
/*  51 */     this.tokensTopSaved = new int[this.mbWidth << mbW];
/*     */   }
/*     */ 
/*     */   
/*     */   public void save() {
/*  56 */     System.arraycopy(this.tokensLeft, 0, this.tokensLeftSaved, 0, this.tokensLeft.length);
/*  57 */     System.arraycopy(this.tokensTop, 0, this.tokensTopSaved, 0, this.tokensTop.length);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void restore() {
/*  63 */     int[] tmp = this.tokensLeft;
/*  64 */     this.tokensLeft = this.tokensLeftSaved;
/*  65 */     this.tokensLeftSaved = tmp;
/*     */ 
/*     */     
/*  68 */     tmp = this.tokensTop;
/*  69 */     this.tokensTop = this.tokensTopSaved;
/*  70 */     this.tokensTopSaved = tmp;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public int writeACBlock(BitWriter out, int blkIndX, int blkIndY, MBType leftMBType, MBType topMBType, int[] coeff, VLC[] totalZerosTab, int firstCoeff, int maxCoeff, int[] scan) {
/*  76 */     VLC coeffTokenTab = getCoeffTokenVLCForLuma((blkIndX != 0), leftMBType, this.tokensLeft[blkIndY & this.mbMask], (blkIndY != 0), topMBType, this.tokensTop[blkIndX]);
/*     */ 
/*     */     
/*  79 */     int coeffToken = writeBlockGen(out, coeff, totalZerosTab, firstCoeff, maxCoeff, scan, coeffTokenTab);
/*     */     
/*  81 */     this.tokensLeft[blkIndY & this.mbMask] = coeffToken;
/*  82 */     this.tokensTop[blkIndX] = coeffToken;
/*     */     
/*  84 */     return coeffToken;
/*     */   }
/*     */ 
/*     */   
/*     */   public void writeChrDCBlock(BitWriter out, int[] coeff, VLC[] totalZerosTab, int firstCoeff, int maxCoeff, int[] scan) {
/*  89 */     writeBlockGen(out, coeff, totalZerosTab, firstCoeff, maxCoeff, scan, getCoeffTokenVLCForChromaDC());
/*     */   }
/*     */ 
/*     */   
/*     */   public void writeLumaDCBlock(BitWriter out, int blkIndX, int blkIndY, MBType leftMBType, MBType topMBType, int[] coeff, VLC[] totalZerosTab, int firstCoeff, int maxCoeff, int[] scan) {
/*  94 */     VLC coeffTokenTab = getCoeffTokenVLCForLuma((blkIndX != 0), leftMBType, this.tokensLeft[blkIndY & this.mbMask], (blkIndY != 0), topMBType, this.tokensTop[blkIndX]);
/*     */ 
/*     */     
/*  97 */     writeBlockGen(out, coeff, totalZerosTab, firstCoeff, maxCoeff, scan, coeffTokenTab);
/*     */   }
/*     */ 
/*     */   
/*     */   private int writeBlockGen(BitWriter out, int[] coeff, VLC[] totalZerosTab, int firstCoeff, int maxCoeff, int[] scan, VLC coeffTokenTab) {
/* 102 */     int trailingOnes = 0, totalCoeff = 0, totalZeros = 0;
/* 103 */     int[] runBefore = new int[maxCoeff];
/* 104 */     int[] levels = new int[maxCoeff];
/* 105 */     for (int i = 0; i < maxCoeff; i++) {
/* 106 */       int c = coeff[scan[i + firstCoeff]];
/* 107 */       if (c == 0) {
/* 108 */         runBefore[totalCoeff] = runBefore[totalCoeff] + 1;
/* 109 */         totalZeros++;
/*     */       } else {
/* 111 */         levels[totalCoeff++] = c;
/*     */       } 
/*     */     } 
/* 114 */     if (totalCoeff < maxCoeff) {
/* 115 */       totalZeros -= runBefore[totalCoeff];
/*     */     }
/* 117 */     trailingOnes = 0;
/* 118 */     for (; trailingOnes < totalCoeff && trailingOnes < 3 && Math.abs(levels[totalCoeff - trailingOnes - 1]) == 1; trailingOnes++);
/*     */ 
/*     */     
/* 121 */     int coeffToken = H264Const.coeffToken(totalCoeff, trailingOnes);
/*     */     
/* 123 */     coeffTokenTab.writeVLC(out, coeffToken);
/*     */     
/* 125 */     if (totalCoeff > 0) {
/* 126 */       writeTrailingOnes(out, levels, totalCoeff, trailingOnes);
/* 127 */       writeLevels(out, levels, totalCoeff, trailingOnes);
/*     */       
/* 129 */       if (totalCoeff < maxCoeff) {
/* 130 */         totalZerosTab[totalCoeff - 1].writeVLC(out, totalZeros);
/* 131 */         writeRuns(out, runBefore, totalCoeff, totalZeros);
/*     */       } 
/*     */     } 
/* 134 */     return coeffToken;
/*     */   }
/*     */   
/*     */   private void writeTrailingOnes(BitWriter out, int[] levels, int totalCoeff, int trailingOne) {
/* 138 */     for (int i = totalCoeff - 1; i >= totalCoeff - trailingOne; i--) {
/* 139 */       out.write1Bit(levels[i] >>> 31);
/*     */     }
/*     */   }
/*     */   
/*     */   private void writeLevels(BitWriter out, int[] levels, int totalCoeff, int trailingOnes) {
/* 144 */     int suffixLen = (totalCoeff > 10 && trailingOnes < 3) ? 1 : 0;
/* 145 */     for (int i = totalCoeff - trailingOnes - 1; i >= 0; i--) {
/* 146 */       int absLev = unsigned(levels[i]);
/* 147 */       if (i == totalCoeff - trailingOnes - 1 && trailingOnes < 3) {
/* 148 */         absLev -= 2;
/*     */       }
/* 150 */       int prefix = absLev >> suffixLen;
/* 151 */       if ((suffixLen == 0 && prefix < 14) || (suffixLen > 0 && prefix < 15)) {
/* 152 */         out.writeNBit(1, prefix + 1);
/* 153 */         out.writeNBit(absLev, suffixLen);
/* 154 */       } else if (suffixLen == 0 && absLev < 30) {
/* 155 */         out.writeNBit(1, 15);
/* 156 */         out.writeNBit(absLev - 14, 4);
/*     */       } else {
/* 158 */         if (suffixLen == 0)
/* 159 */           absLev -= 15;  int len;
/*     */         int code;
/* 161 */         for (len = 12; (code = absLev - (len + 3 << suffixLen) - (1 << len) + 4096) >= 1 << len; len++);
/*     */         
/* 163 */         out.writeNBit(1, len + 4);
/* 164 */         out.writeNBit(code, len);
/*     */       } 
/* 166 */       if (suffixLen == 0)
/* 167 */         suffixLen = 1; 
/* 168 */       if (MathUtil.abs(levels[i]) > 3 << suffixLen - 1 && suffixLen < 6)
/* 169 */         suffixLen++; 
/*     */     } 
/*     */   }
/*     */   
/*     */   private final int unsigned(int signed) {
/* 174 */     int sign = signed >>> 31;
/* 175 */     int s = signed >> 31;
/*     */     
/* 177 */     return ((signed ^ s) - s << 1) + sign - 2;
/*     */   }
/*     */   
/*     */   private void writeRuns(BitWriter out, int[] run, int totalCoeff, int totalZeros) {
/* 181 */     for (int i = totalCoeff - 1; i > 0 && totalZeros > 0; i--) {
/* 182 */       H264Const.run[Math.min(6, totalZeros - 1)].writeVLC(out, run[i]);
/* 183 */       totalZeros -= run[i];
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public VLC getCoeffTokenVLCForLuma(boolean leftAvailable, MBType leftMBType, int leftToken, boolean topAvailable, MBType topMBType, int topToken) {
/* 190 */     int nc = codeTableLuma(leftAvailable, leftMBType, leftToken, topAvailable, topMBType, topToken);
/*     */     
/* 192 */     return H264Const.CoeffToken[Math.min(nc, 8)];
/*     */   }
/*     */   
/*     */   public VLC getCoeffTokenVLCForChromaDC() {
/* 196 */     return this.chromaDCVLC;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   protected int codeTableLuma(boolean leftAvailable, MBType leftMBType, int leftToken, boolean topAvailable, MBType topMBType, int topToken) {
/* 202 */     int nA = (leftMBType == null) ? 0 : totalCoeff(leftToken);
/* 203 */     int nB = (topMBType == null) ? 0 : totalCoeff(topToken);
/*     */     
/* 205 */     if (leftAvailable && topAvailable)
/* 206 */       return nA + nB + 1 >> 1; 
/* 207 */     if (leftAvailable)
/* 208 */       return nA; 
/* 209 */     if (topAvailable) {
/* 210 */       return nB;
/*     */     }
/* 212 */     return 0;
/*     */   }
/*     */   
/*     */   protected VLC codeTableChromaDC() {
/* 216 */     if (this.color == ColorSpace.YUV420J)
/* 217 */       return H264Const.coeffTokenChromaDCY420; 
/* 218 */     if (this.color == ColorSpace.YUV422)
/* 219 */       return H264Const.coeffTokenChromaDCY422; 
/* 220 */     if (this.color == ColorSpace.YUV444) {
/* 221 */       return H264Const.CoeffToken[0];
/*     */     }
/* 223 */     return null;
/*     */   }
/*     */ 
/*     */   
/*     */   public int readCoeffs(BitReader _in, VLC coeffTokenTab, VLC[] totalZerosTab, int[] coeffLevel, int firstCoeff, int nCoeff, int[] zigzag) {
/* 228 */     int coeffToken = coeffTokenTab.readVLC(_in);
/* 229 */     int totalCoeff = totalCoeff(coeffToken);
/* 230 */     int trailingOnes = trailingOnes(coeffToken);
/*     */     
/* 232 */     if (totalCoeff > 0) {
/* 233 */       int zerosLeft, suffixLength = (totalCoeff > 10 && trailingOnes < 3) ? 1 : 0;
/*     */       
/* 235 */       int[] level = new int[totalCoeff];
/*     */       int i;
/* 237 */       for (i = 0; i < trailingOnes; i++) {
/* 238 */         level[i] = 1 - 2 * _in.read1Bit();
/*     */       }
/* 240 */       for (; i < totalCoeff; i++) {
/* 241 */         int level_prefix = CAVLCReader.readZeroBitCount(_in, "");
/* 242 */         int levelSuffixSize = suffixLength;
/* 243 */         if (level_prefix == 14 && suffixLength == 0)
/* 244 */           levelSuffixSize = 4; 
/* 245 */         if (level_prefix >= 15) {
/* 246 */           levelSuffixSize = level_prefix - 3;
/*     */         }
/* 248 */         int levelCode = Min(15, level_prefix) << suffixLength;
/* 249 */         if (levelSuffixSize > 0) {
/* 250 */           int level_suffix = CAVLCReader.readU(_in, levelSuffixSize, "RB: level_suffix");
/* 251 */           levelCode += level_suffix;
/*     */         } 
/* 253 */         if (level_prefix >= 15 && suffixLength == 0)
/* 254 */           levelCode += 15; 
/* 255 */         if (level_prefix >= 16)
/* 256 */           levelCode += (1 << level_prefix - 3) - 4096; 
/* 257 */         if (i == trailingOnes && trailingOnes < 3) {
/* 258 */           levelCode += 2;
/*     */         }
/* 260 */         if (levelCode % 2 == 0) {
/* 261 */           level[i] = levelCode + 2 >> 1;
/*     */         } else {
/* 263 */           level[i] = -levelCode - 1 >> 1;
/*     */         } 
/* 265 */         if (suffixLength == 0)
/* 266 */           suffixLength = 1; 
/* 267 */         if (Abs(level[i]) > 3 << suffixLength - 1 && suffixLength < 6) {
/* 268 */           suffixLength++;
/*     */         }
/*     */       } 
/*     */       
/* 272 */       if (totalCoeff < nCoeff) {
/* 273 */         if (coeffLevel.length == 4) {
/* 274 */           zerosLeft = H264Const.totalZeros4[totalCoeff - 1].readVLC(_in);
/* 275 */         } else if (coeffLevel.length == 8) {
/* 276 */           zerosLeft = H264Const.totalZeros8[totalCoeff - 1].readVLC(_in);
/*     */         } else {
/* 278 */           zerosLeft = H264Const.totalZeros16[totalCoeff - 1].readVLC(_in);
/*     */         } 
/*     */       } else {
/* 281 */         zerosLeft = 0;
/*     */       } 
/* 283 */       int[] runs = new int[totalCoeff];
/*     */       int r;
/* 285 */       for (r = 0; r < totalCoeff - 1 && zerosLeft > 0; r++) {
/* 286 */         int run = H264Const.run[Math.min(6, zerosLeft - 1)].readVLC(_in);
/* 287 */         zerosLeft -= run;
/* 288 */         runs[r] = run;
/*     */       } 
/* 290 */       runs[r] = zerosLeft;
/*     */       
/* 292 */       for (int j = totalCoeff - 1, cn = 0; j >= 0 && cn < nCoeff; j--, cn++) {
/* 293 */         cn += runs[j];
/* 294 */         coeffLevel[zigzag[cn + firstCoeff]] = level[j];
/*     */       } 
/*     */     } 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 303 */     return coeffToken;
/*     */   }
/*     */   
/*     */   private static int Min(int i, int level_prefix) {
/* 307 */     return (i < level_prefix) ? i : level_prefix;
/*     */   }
/*     */   
/*     */   private static int Abs(int i) {
/* 311 */     return (i < 0) ? -i : i;
/*     */   }
/*     */   
/*     */   public static final int totalCoeff(int coeffToken) {
/* 315 */     return coeffToken >> 4;
/*     */   }
/*     */   
/*     */   public static final int trailingOnes(int coeffToken) {
/* 319 */     return coeffToken & 0xF;
/*     */   }
/*     */   
/* 322 */   public static int[] NO_ZIGZAG = new int[] { 0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15 };
/*     */   
/*     */   public void readChromaDCBlock(BitReader reader, int[] coeff, boolean leftAvailable, boolean topAvailable) {
/* 325 */     VLC coeffTokenTab = getCoeffTokenVLCForChromaDC();
/*     */     
/* 327 */     readCoeffs(reader, coeffTokenTab, (coeff.length == 16) ? H264Const.totalZeros16 : ((coeff.length == 8) ? H264Const.totalZeros8 : H264Const.totalZeros4), coeff, 0, coeff.length, NO_ZIGZAG);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void readLumaDCBlock(BitReader reader, int[] coeff, int mbX, boolean leftAvailable, MBType leftMbType, boolean topAvailable, MBType topMbType, int[] zigzag4x4) {
/* 334 */     VLC coeffTokenTab = getCoeffTokenVLCForLuma(leftAvailable, leftMbType, this.tokensLeft[0], topAvailable, topMbType, this.tokensTop[mbX << 2]);
/*     */ 
/*     */     
/* 337 */     readCoeffs(reader, coeffTokenTab, H264Const.totalZeros16, coeff, 0, 16, zigzag4x4);
/*     */   }
/*     */ 
/*     */   
/*     */   public int readACBlock(BitReader reader, int[] coeff, int blkIndX, int blkIndY, boolean leftAvailable, MBType leftMbType, boolean topAvailable, MBType topMbType, int firstCoeff, int nCoeff, int[] zigzag4x4) {
/* 342 */     VLC coeffTokenTab = getCoeffTokenVLCForLuma(leftAvailable, leftMbType, this.tokensLeft[blkIndY & this.mbMask], topAvailable, topMbType, this.tokensTop[blkIndX]);
/*     */ 
/*     */     
/* 345 */     int readCoeffs = readCoeffs(reader, coeffTokenTab, H264Const.totalZeros16, coeff, firstCoeff, nCoeff, zigzag4x4);
/* 346 */     this.tokensTop[blkIndX] = readCoeffs; this.tokensLeft[blkIndY & this.mbMask] = readCoeffs;
/*     */     
/* 348 */     return totalCoeff(readCoeffs);
/*     */   }
/*     */   
/*     */   public void setZeroCoeff(int blkIndX, int blkIndY) {
/* 352 */     this.tokensTop[blkIndX] = 0; this.tokensLeft[blkIndY & this.mbMask] = 0;
/*     */   }
/*     */ }


/* Location:              C:\Users\rapha\Downloads\aurora.jar!\META-INF\jars\jcodec-0.2.5.jar!\org\jcodec\codecs\h264\io\CAVLC.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */