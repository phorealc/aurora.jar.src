/*    */ package org.jcodec.codecs.h264.io.model;
/*    */ 
/*    */ import java.nio.ByteBuffer;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class NALUnit
/*    */ {
/*    */   public NALUnitType type;
/*    */   public int nal_ref_idc;
/*    */   
/*    */   public NALUnit(NALUnitType type, int nal_ref_idc) {
/* 19 */     this.type = type;
/* 20 */     this.nal_ref_idc = nal_ref_idc;
/*    */   }
/*    */   
/*    */   public static NALUnit read(ByteBuffer _in) {
/* 24 */     int nalu = _in.get() & 0xFF;
/* 25 */     int nal_ref_idc = nalu >> 5 & 0x3;
/* 26 */     int nb = nalu & 0x1F;
/*    */     
/* 28 */     NALUnitType type = NALUnitType.fromValue(nb);
/* 29 */     return new NALUnit(type, nal_ref_idc);
/*    */   }
/*    */   
/*    */   public void write(ByteBuffer out) {
/* 33 */     int nalu = this.type.getValue() | this.nal_ref_idc << 5;
/* 34 */     out.put((byte)nalu);
/*    */   }
/*    */ }


/* Location:              C:\Users\rapha\Downloads\aurora.jar!\META-INF\jars\jcodec-0.2.5.jar!\org\jcodec\codecs\h264\io\model\NALUnit.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */