/*    */ package org.jcodec.codecs.h264.io.model;
/*    */ 
/*    */ import java.nio.ByteBuffer;
/*    */ import org.jcodec.codecs.h264.decode.CAVLCReader;
/*    */ import org.jcodec.codecs.h264.io.write.CAVLCWriter;
/*    */ import org.jcodec.common.io.BitReader;
/*    */ import org.jcodec.common.io.BitWriter;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class SeqParameterSetExt
/*    */ {
/*    */   public int seq_parameter_set_id;
/*    */   public int aux_format_idc;
/*    */   public int bit_depth_aux_minus8;
/*    */   public boolean alpha_incr_flag;
/*    */   public boolean additional_extension_flag;
/*    */   public int alpha_opaque_value;
/*    */   public int alpha_transparent_value;
/*    */   
/*    */   public static SeqParameterSetExt read(ByteBuffer is) {
/* 34 */     BitReader _in = BitReader.createBitReader(is);
/*    */     
/* 36 */     SeqParameterSetExt spse = new SeqParameterSetExt();
/* 37 */     spse.seq_parameter_set_id = CAVLCReader.readUEtrace(_in, "SPSE: seq_parameter_set_id");
/* 38 */     spse.aux_format_idc = CAVLCReader.readUEtrace(_in, "SPSE: aux_format_idc");
/* 39 */     if (spse.aux_format_idc != 0) {
/* 40 */       spse.bit_depth_aux_minus8 = CAVLCReader.readUEtrace(_in, "SPSE: bit_depth_aux_minus8");
/* 41 */       spse.alpha_incr_flag = CAVLCReader.readBool(_in, "SPSE: alpha_incr_flag");
/* 42 */       spse.alpha_opaque_value = CAVLCReader.readU(_in, spse.bit_depth_aux_minus8 + 9, "SPSE: alpha_opaque_value");
/* 43 */       spse.alpha_transparent_value = CAVLCReader.readU(_in, spse.bit_depth_aux_minus8 + 9, "SPSE: alpha_transparent_value");
/*    */     } 
/* 45 */     spse.additional_extension_flag = CAVLCReader.readBool(_in, "SPSE: additional_extension_flag");
/*    */     
/* 47 */     return spse;
/*    */   }
/*    */   
/*    */   public void write(ByteBuffer out) {
/* 51 */     BitWriter writer = new BitWriter(out);
/* 52 */     CAVLCWriter.writeTrailingBits(writer);
/*    */   }
/*    */ }


/* Location:              C:\Users\rapha\Downloads\aurora.jar!\META-INF\jars\jcodec-0.2.5.jar!\org\jcodec\codecs\h264\io\model\SeqParameterSetExt.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */