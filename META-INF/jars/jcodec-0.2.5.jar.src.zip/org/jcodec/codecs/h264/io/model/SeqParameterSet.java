/*     */ package org.jcodec.codecs.h264.io.model;
/*     */ 
/*     */ import java.nio.ByteBuffer;
/*     */ import org.jcodec.codecs.h264.H264Const;
/*     */ import org.jcodec.codecs.h264.decode.CAVLCReader;
/*     */ import org.jcodec.codecs.h264.io.write.CAVLCWriter;
/*     */ import org.jcodec.common.io.BitReader;
/*     */ import org.jcodec.common.io.BitWriter;
/*     */ import org.jcodec.common.model.ColorSpace;
/*     */ import org.jcodec.platform.Platform;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class SeqParameterSet
/*     */ {
/*     */   public int picOrderCntType;
/*     */   public boolean fieldPicFlag;
/*     */   public boolean deltaPicOrderAlwaysZeroFlag;
/*     */   public boolean mbAdaptiveFrameFieldFlag;
/*     */   public boolean direct8x8InferenceFlag;
/*     */   public ColorSpace chromaFormatIdc;
/*     */   public int log2MaxFrameNumMinus4;
/*     */   public int log2MaxPicOrderCntLsbMinus4;
/*     */   public int picHeightInMapUnitsMinus1;
/*     */   public int picWidthInMbsMinus1;
/*     */   public int bitDepthLumaMinus8;
/*     */   public int bitDepthChromaMinus8;
/*     */   public boolean qpprimeYZeroTransformBypassFlag;
/*     */   public int profileIdc;
/*     */   public boolean constraintSet0Flag;
/*     */   public boolean constraintSet1Flag;
/*     */   public boolean constraintSet2Flag;
/*     */   public boolean constraintSet3Flag;
/*     */   public boolean constraintSet4Flag;
/*     */   public boolean constraintSet5Flag;
/*     */   public int levelIdc;
/*     */   public int seqParameterSetId;
/*     */   public boolean separateColourPlaneFlag;
/*     */   public int offsetForNonRefPic;
/*     */   public int offsetForTopToBottomField;
/*     */   public int numRefFrames;
/*     */   public boolean gapsInFrameNumValueAllowedFlag;
/*     */   public boolean frameMbsOnlyFlag;
/*     */   public boolean frameCroppingFlag;
/*     */   public int frameCropLeftOffset;
/*     */   public int frameCropRightOffset;
/*     */   public int frameCropTopOffset;
/*     */   public int frameCropBottomOffset;
/*     */   public int[] offsetForRefFrame;
/*     */   public VUIParameters vuiParams;
/*     */   public int[][] scalingMatrix;
/*     */   public int numRefFramesInPicOrderCntCycle;
/*     */   
/*     */   public static ColorSpace getColor(int id) {
/* 152 */     switch (id) {
/*     */       case 0:
/* 154 */         return ColorSpace.MONO;
/*     */       case 1:
/* 156 */         return ColorSpace.YUV420J;
/*     */       case 2:
/* 158 */         return ColorSpace.YUV422;
/*     */       case 3:
/* 160 */         return ColorSpace.YUV444;
/*     */     } 
/* 162 */     throw new RuntimeException("Colorspace not supported");
/*     */   }
/*     */   
/*     */   public static int fromColor(ColorSpace color) {
/* 166 */     if (color == ColorSpace.MONO)
/* 167 */       return 0; 
/* 168 */     if (color == ColorSpace.YUV420J)
/* 169 */       return 1; 
/* 170 */     if (color == ColorSpace.YUV422)
/* 171 */       return 2; 
/* 172 */     if (color == ColorSpace.YUV444) {
/* 173 */       return 3;
/*     */     }
/* 175 */     throw new RuntimeException("Colorspace not supported");
/*     */   }
/*     */   
/*     */   public static SeqParameterSet read(ByteBuffer is) {
/* 179 */     BitReader _in = BitReader.createBitReader(is);
/* 180 */     SeqParameterSet sps = new SeqParameterSet();
/*     */     
/* 182 */     sps.profileIdc = CAVLCReader.readNBit(_in, 8, "SPS: profile_idc");
/* 183 */     sps.constraintSet0Flag = CAVLCReader.readBool(_in, "SPS: constraint_set_0_flag");
/* 184 */     sps.constraintSet1Flag = CAVLCReader.readBool(_in, "SPS: constraint_set_1_flag");
/* 185 */     sps.constraintSet2Flag = CAVLCReader.readBool(_in, "SPS: constraint_set_2_flag");
/* 186 */     sps.constraintSet3Flag = CAVLCReader.readBool(_in, "SPS: constraint_set_3_flag");
/* 187 */     sps.constraintSet4Flag = CAVLCReader.readBool(_in, "SPS: constraint_set_4_flag");
/* 188 */     sps.constraintSet5Flag = CAVLCReader.readBool(_in, "SPS: constraint_set_5_flag");
/* 189 */     CAVLCReader.readNBit(_in, 2, "SPS: reserved_zero_2bits");
/* 190 */     sps.levelIdc = CAVLCReader.readNBit(_in, 8, "SPS: level_idc");
/* 191 */     sps.seqParameterSetId = CAVLCReader.readUEtrace(_in, "SPS: seq_parameter_set_id");
/*     */     
/* 193 */     if (sps.profileIdc == 100 || sps.profileIdc == 110 || sps.profileIdc == 122 || sps.profileIdc == 144) {
/* 194 */       sps.chromaFormatIdc = getColor(CAVLCReader.readUEtrace(_in, "SPS: chroma_format_idc"));
/* 195 */       if (sps.chromaFormatIdc == ColorSpace.YUV444) {
/* 196 */         sps.separateColourPlaneFlag = CAVLCReader.readBool(_in, "SPS: separate_colour_plane_flag");
/*     */       }
/* 198 */       sps.bitDepthLumaMinus8 = CAVLCReader.readUEtrace(_in, "SPS: bit_depth_luma_minus8");
/* 199 */       sps.bitDepthChromaMinus8 = CAVLCReader.readUEtrace(_in, "SPS: bit_depth_chroma_minus8");
/* 200 */       sps.qpprimeYZeroTransformBypassFlag = CAVLCReader.readBool(_in, "SPS: qpprime_y_zero_transform_bypass_flag");
/* 201 */       boolean seqScalingMatrixPresent = CAVLCReader.readBool(_in, "SPS: seq_scaling_matrix_present_lag");
/* 202 */       if (seqScalingMatrixPresent) {
/* 203 */         readScalingListMatrix(_in, sps);
/*     */       }
/*     */     } else {
/* 206 */       sps.chromaFormatIdc = ColorSpace.YUV420J;
/*     */     } 
/* 208 */     sps.log2MaxFrameNumMinus4 = CAVLCReader.readUEtrace(_in, "SPS: log2_max_frame_num_minus4");
/* 209 */     sps.picOrderCntType = CAVLCReader.readUEtrace(_in, "SPS: pic_order_cnt_type");
/* 210 */     if (sps.picOrderCntType == 0) {
/* 211 */       sps.log2MaxPicOrderCntLsbMinus4 = CAVLCReader.readUEtrace(_in, "SPS: log2_max_pic_order_cnt_lsb_minus4");
/* 212 */     } else if (sps.picOrderCntType == 1) {
/* 213 */       sps.deltaPicOrderAlwaysZeroFlag = CAVLCReader.readBool(_in, "SPS: delta_pic_order_always_zero_flag");
/* 214 */       sps.offsetForNonRefPic = CAVLCReader.readSE(_in, "SPS: offset_for_non_ref_pic");
/* 215 */       sps.offsetForTopToBottomField = CAVLCReader.readSE(_in, "SPS: offset_for_top_to_bottom_field");
/* 216 */       sps.numRefFramesInPicOrderCntCycle = CAVLCReader.readUEtrace(_in, "SPS: num_ref_frames_in_pic_order_cnt_cycle");
/* 217 */       sps.offsetForRefFrame = new int[sps.numRefFramesInPicOrderCntCycle];
/* 218 */       for (int i = 0; i < sps.numRefFramesInPicOrderCntCycle; i++) {
/* 219 */         sps.offsetForRefFrame[i] = CAVLCReader.readSE(_in, "SPS: offsetForRefFrame [" + i + "]");
/*     */       }
/*     */     } 
/* 222 */     sps.numRefFrames = CAVLCReader.readUEtrace(_in, "SPS: num_ref_frames");
/* 223 */     sps.gapsInFrameNumValueAllowedFlag = CAVLCReader.readBool(_in, "SPS: gaps_in_frame_num_value_allowed_flag");
/* 224 */     sps.picWidthInMbsMinus1 = CAVLCReader.readUEtrace(_in, "SPS: pic_width_in_mbs_minus1");
/* 225 */     sps.picHeightInMapUnitsMinus1 = CAVLCReader.readUEtrace(_in, "SPS: pic_height_in_map_units_minus1");
/* 226 */     sps.frameMbsOnlyFlag = CAVLCReader.readBool(_in, "SPS: frame_mbs_only_flag");
/* 227 */     if (!sps.frameMbsOnlyFlag) {
/* 228 */       sps.mbAdaptiveFrameFieldFlag = CAVLCReader.readBool(_in, "SPS: mb_adaptive_frame_field_flag");
/*     */     }
/* 230 */     sps.direct8x8InferenceFlag = CAVLCReader.readBool(_in, "SPS: direct_8x8_inference_flag");
/* 231 */     sps.frameCroppingFlag = CAVLCReader.readBool(_in, "SPS: frame_cropping_flag");
/* 232 */     if (sps.frameCroppingFlag) {
/* 233 */       sps.frameCropLeftOffset = CAVLCReader.readUEtrace(_in, "SPS: frame_crop_left_offset");
/* 234 */       sps.frameCropRightOffset = CAVLCReader.readUEtrace(_in, "SPS: frame_crop_right_offset");
/* 235 */       sps.frameCropTopOffset = CAVLCReader.readUEtrace(_in, "SPS: frame_crop_top_offset");
/* 236 */       sps.frameCropBottomOffset = CAVLCReader.readUEtrace(_in, "SPS: frame_crop_bottom_offset");
/*     */     } 
/* 238 */     boolean vuiParametersPresentFlag = CAVLCReader.readBool(_in, "SPS: vui_parameters_present_flag");
/* 239 */     if (vuiParametersPresentFlag) {
/* 240 */       sps.vuiParams = readVUIParameters(_in);
/*     */     }
/* 242 */     return sps;
/*     */   }
/*     */ 
/*     */   
/*     */   public static void writeScalingList(BitWriter out, int[][] scalingMatrix, int which) {
/* 247 */     boolean useDefaultScalingMatrixFlag = false;
/* 248 */     switch (which) {
/*     */       case 0:
/* 250 */         useDefaultScalingMatrixFlag = Platform.arrayEqualsInt(scalingMatrix[which], H264Const.defaultScalingList4x4Intra);
/*     */         break;
/*     */       case 1:
/*     */       case 2:
/* 254 */         useDefaultScalingMatrixFlag = Platform.arrayEqualsInt(scalingMatrix[which], scalingMatrix[0]);
/*     */         break;
/*     */       case 3:
/* 257 */         useDefaultScalingMatrixFlag = Platform.arrayEqualsInt(scalingMatrix[which], H264Const.defaultScalingList4x4Inter);
/*     */         break;
/*     */       case 4:
/*     */       case 5:
/* 261 */         useDefaultScalingMatrixFlag = Platform.arrayEqualsInt(scalingMatrix[which], scalingMatrix[3]);
/*     */         break;
/*     */       case 6:
/* 264 */         useDefaultScalingMatrixFlag = Platform.arrayEqualsInt(scalingMatrix[which], H264Const.defaultScalingList8x8Intra);
/*     */         break;
/*     */       case 7:
/* 267 */         useDefaultScalingMatrixFlag = Platform.arrayEqualsInt(scalingMatrix[which], H264Const.defaultScalingList8x8Inter);
/*     */         break;
/*     */     } 
/* 270 */     int[] scalingList = scalingMatrix[which];
/*     */     
/* 272 */     if (useDefaultScalingMatrixFlag) {
/* 273 */       CAVLCWriter.writeSEtrace(out, -8, "SPS: ");
/*     */       
/*     */       return;
/*     */     } 
/* 277 */     int lastScale = 8;
/* 278 */     int nextScale = 8;
/* 279 */     for (int j = 0; j < scalingList.length; j++) {
/* 280 */       if (nextScale != 0) {
/* 281 */         int deltaScale = scalingList[j] - lastScale - 256;
/* 282 */         CAVLCWriter.writeSEtrace(out, deltaScale, "SPS: ");
/*     */       } 
/* 284 */       lastScale = scalingList[j];
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public static int[] readScalingList(BitReader src, int sizeOfScalingList) {
/* 291 */     int[] scalingList = new int[sizeOfScalingList];
/* 292 */     int lastScale = 8;
/* 293 */     int nextScale = 8;
/* 294 */     for (int j = 0; j < sizeOfScalingList; j++) {
/* 295 */       if (nextScale != 0) {
/* 296 */         int deltaScale = CAVLCReader.readSE(src, "deltaScale");
/* 297 */         nextScale = (lastScale + deltaScale + 256) % 256;
/* 298 */         if (j == 0 && nextScale == 0)
/* 299 */           return null; 
/*     */       } 
/* 301 */       scalingList[j] = (nextScale == 0) ? lastScale : nextScale;
/* 302 */       lastScale = scalingList[j];
/*     */     } 
/* 304 */     return scalingList;
/*     */   }
/*     */ 
/*     */   
/*     */   private static void readScalingListMatrix(BitReader src, SeqParameterSet sps) {
/* 309 */     sps.scalingMatrix = new int[8][];
/* 310 */     for (int i = 0; i < 8; i++) {
/* 311 */       boolean seqScalingListPresentFlag = CAVLCReader.readBool(src, "SPS: seqScalingListPresentFlag");
/* 312 */       if (seqScalingListPresentFlag) {
/* 313 */         int scalingListSize = (i < 6) ? 16 : 64;
/* 314 */         sps.scalingMatrix[i] = readScalingList(src, scalingListSize);
/*     */       } 
/*     */     } 
/*     */   }
/*     */   
/*     */   private static VUIParameters readVUIParameters(BitReader _in) {
/* 320 */     VUIParameters vuip = new VUIParameters();
/* 321 */     vuip.aspectRatioInfoPresentFlag = CAVLCReader.readBool(_in, "VUI: aspect_ratio_info_present_flag");
/* 322 */     if (vuip.aspectRatioInfoPresentFlag) {
/* 323 */       vuip.aspectRatio = AspectRatio.fromValue(CAVLCReader.readNBit(_in, 8, "VUI: aspect_ratio"));
/* 324 */       if (vuip.aspectRatio == AspectRatio.Extended_SAR) {
/* 325 */         vuip.sarWidth = CAVLCReader.readNBit(_in, 16, "VUI: sar_width");
/* 326 */         vuip.sarHeight = CAVLCReader.readNBit(_in, 16, "VUI: sar_height");
/*     */       } 
/*     */     } 
/* 329 */     vuip.overscanInfoPresentFlag = CAVLCReader.readBool(_in, "VUI: overscan_info_present_flag");
/* 330 */     if (vuip.overscanInfoPresentFlag) {
/* 331 */       vuip.overscanAppropriateFlag = CAVLCReader.readBool(_in, "VUI: overscan_appropriate_flag");
/*     */     }
/* 333 */     vuip.videoSignalTypePresentFlag = CAVLCReader.readBool(_in, "VUI: video_signal_type_present_flag");
/* 334 */     if (vuip.videoSignalTypePresentFlag) {
/* 335 */       vuip.videoFormat = CAVLCReader.readNBit(_in, 3, "VUI: video_format");
/* 336 */       vuip.videoFullRangeFlag = CAVLCReader.readBool(_in, "VUI: video_full_range_flag");
/* 337 */       vuip.colourDescriptionPresentFlag = CAVLCReader.readBool(_in, "VUI: colour_description_present_flag");
/* 338 */       if (vuip.colourDescriptionPresentFlag) {
/* 339 */         vuip.colourPrimaries = CAVLCReader.readNBit(_in, 8, "VUI: colour_primaries");
/* 340 */         vuip.transferCharacteristics = CAVLCReader.readNBit(_in, 8, "VUI: transfer_characteristics");
/* 341 */         vuip.matrixCoefficients = CAVLCReader.readNBit(_in, 8, "VUI: matrix_coefficients");
/*     */       } 
/*     */     } 
/* 344 */     vuip.chromaLocInfoPresentFlag = CAVLCReader.readBool(_in, "VUI: chroma_loc_info_present_flag");
/* 345 */     if (vuip.chromaLocInfoPresentFlag) {
/* 346 */       vuip.chromaSampleLocTypeTopField = CAVLCReader.readUEtrace(_in, "VUI chroma_sample_loc_type_top_field");
/* 347 */       vuip.chromaSampleLocTypeBottomField = CAVLCReader.readUEtrace(_in, "VUI chroma_sample_loc_type_bottom_field");
/*     */     } 
/* 349 */     vuip.timingInfoPresentFlag = CAVLCReader.readBool(_in, "VUI: timing_info_present_flag");
/* 350 */     if (vuip.timingInfoPresentFlag) {
/* 351 */       vuip.numUnitsInTick = CAVLCReader.readNBit(_in, 32, "VUI: num_units_in_tick");
/* 352 */       vuip.timeScale = CAVLCReader.readNBit(_in, 32, "VUI: time_scale");
/* 353 */       vuip.fixedFrameRateFlag = CAVLCReader.readBool(_in, "VUI: fixed_frame_rate_flag");
/*     */     } 
/* 355 */     boolean nalHRDParametersPresentFlag = CAVLCReader.readBool(_in, "VUI: nal_hrd_parameters_present_flag");
/* 356 */     if (nalHRDParametersPresentFlag)
/* 357 */       vuip.nalHRDParams = readHRDParameters(_in); 
/* 358 */     boolean vclHRDParametersPresentFlag = CAVLCReader.readBool(_in, "VUI: vcl_hrd_parameters_present_flag");
/* 359 */     if (vclHRDParametersPresentFlag)
/* 360 */       vuip.vclHRDParams = readHRDParameters(_in); 
/* 361 */     if (nalHRDParametersPresentFlag || vclHRDParametersPresentFlag) {
/* 362 */       vuip.lowDelayHrdFlag = CAVLCReader.readBool(_in, "VUI: low_delay_hrd_flag");
/*     */     }
/* 364 */     vuip.picStructPresentFlag = CAVLCReader.readBool(_in, "VUI: pic_struct_present_flag");
/* 365 */     boolean bitstreamRestrictionFlag = CAVLCReader.readBool(_in, "VUI: bitstream_restriction_flag");
/* 366 */     if (bitstreamRestrictionFlag) {
/* 367 */       vuip.bitstreamRestriction = new VUIParameters.BitstreamRestriction();
/* 368 */       vuip.bitstreamRestriction.motionVectorsOverPicBoundariesFlag = CAVLCReader.readBool(_in, "VUI: motion_vectors_over_pic_boundaries_flag");
/*     */       
/* 370 */       vuip.bitstreamRestriction.maxBytesPerPicDenom = CAVLCReader.readUEtrace(_in, "VUI max_bytes_per_pic_denom");
/* 371 */       vuip.bitstreamRestriction.maxBitsPerMbDenom = CAVLCReader.readUEtrace(_in, "VUI max_bits_per_mb_denom");
/* 372 */       vuip.bitstreamRestriction.log2MaxMvLengthHorizontal = CAVLCReader.readUEtrace(_in, "VUI log2_max_mv_length_horizontal");
/* 373 */       vuip.bitstreamRestriction.log2MaxMvLengthVertical = CAVLCReader.readUEtrace(_in, "VUI log2_max_mv_length_vertical");
/* 374 */       vuip.bitstreamRestriction.numReorderFrames = CAVLCReader.readUEtrace(_in, "VUI num_reorder_frames");
/* 375 */       vuip.bitstreamRestriction.maxDecFrameBuffering = CAVLCReader.readUEtrace(_in, "VUI max_dec_frame_buffering");
/*     */     } 
/*     */     
/* 378 */     return vuip;
/*     */   }
/*     */   
/*     */   private static HRDParameters readHRDParameters(BitReader _in) {
/* 382 */     HRDParameters hrd = new HRDParameters();
/* 383 */     hrd.cpbCntMinus1 = CAVLCReader.readUEtrace(_in, "SPS: cpb_cnt_minus1");
/* 384 */     hrd.bitRateScale = CAVLCReader.readNBit(_in, 4, "HRD: bit_rate_scale");
/* 385 */     hrd.cpbSizeScale = CAVLCReader.readNBit(_in, 4, "HRD: cpb_size_scale");
/* 386 */     hrd.bitRateValueMinus1 = new int[hrd.cpbCntMinus1 + 1];
/* 387 */     hrd.cpbSizeValueMinus1 = new int[hrd.cpbCntMinus1 + 1];
/* 388 */     hrd.cbrFlag = new boolean[hrd.cpbCntMinus1 + 1];
/*     */     
/* 390 */     for (int SchedSelIdx = 0; SchedSelIdx <= hrd.cpbCntMinus1; SchedSelIdx++) {
/* 391 */       hrd.bitRateValueMinus1[SchedSelIdx] = CAVLCReader.readUEtrace(_in, "HRD: bit_rate_value_minus1");
/* 392 */       hrd.cpbSizeValueMinus1[SchedSelIdx] = CAVLCReader.readUEtrace(_in, "HRD: cpb_size_value_minus1");
/* 393 */       hrd.cbrFlag[SchedSelIdx] = CAVLCReader.readBool(_in, "HRD: cbr_flag");
/*     */     } 
/* 395 */     hrd.initialCpbRemovalDelayLengthMinus1 = CAVLCReader.readNBit(_in, 5, "HRD: initial_cpb_removal_delay_length_minus1");
/*     */     
/* 397 */     hrd.cpbRemovalDelayLengthMinus1 = CAVLCReader.readNBit(_in, 5, "HRD: cpb_removal_delay_length_minus1");
/* 398 */     hrd.dpbOutputDelayLengthMinus1 = CAVLCReader.readNBit(_in, 5, "HRD: dpb_output_delay_length_minus1");
/* 399 */     hrd.timeOffsetLength = CAVLCReader.readNBit(_in, 5, "HRD: time_offset_length");
/* 400 */     return hrd;
/*     */   }
/*     */   
/*     */   public void write(ByteBuffer out) {
/* 404 */     BitWriter writer = new BitWriter(out);
/*     */     
/* 406 */     CAVLCWriter.writeNBit(writer, this.profileIdc, 8, "SPS: profile_idc");
/* 407 */     CAVLCWriter.writeBool(writer, this.constraintSet0Flag, "SPS: constraint_set_0_flag");
/* 408 */     CAVLCWriter.writeBool(writer, this.constraintSet1Flag, "SPS: constraint_set_1_flag");
/* 409 */     CAVLCWriter.writeBool(writer, this.constraintSet2Flag, "SPS: constraint_set_2_flag");
/* 410 */     CAVLCWriter.writeBool(writer, this.constraintSet3Flag, "SPS: constraint_set_3_flag");
/* 411 */     CAVLCWriter.writeBool(writer, this.constraintSet4Flag, "SPS: constraint_set_4_flag");
/* 412 */     CAVLCWriter.writeBool(writer, this.constraintSet5Flag, "SPS: constraint_set_5_flag");
/* 413 */     CAVLCWriter.writeNBit(writer, 0L, 2, "SPS: reserved");
/* 414 */     CAVLCWriter.writeNBit(writer, this.levelIdc, 8, "SPS: level_idc");
/* 415 */     CAVLCWriter.writeUEtrace(writer, this.seqParameterSetId, "SPS: seq_parameter_set_id");
/*     */     
/* 417 */     if (this.profileIdc == 100 || this.profileIdc == 110 || this.profileIdc == 122 || this.profileIdc == 144) {
/* 418 */       CAVLCWriter.writeUEtrace(writer, fromColor(this.chromaFormatIdc), "SPS: chroma_format_idc");
/* 419 */       if (this.chromaFormatIdc == ColorSpace.YUV444) {
/* 420 */         CAVLCWriter.writeBool(writer, this.separateColourPlaneFlag, "SPS: residual_color_transform_flag");
/*     */       }
/* 422 */       CAVLCWriter.writeUEtrace(writer, this.bitDepthLumaMinus8, "SPS: ");
/* 423 */       CAVLCWriter.writeUEtrace(writer, this.bitDepthChromaMinus8, "SPS: ");
/* 424 */       CAVLCWriter.writeBool(writer, this.qpprimeYZeroTransformBypassFlag, "SPS: qpprime_y_zero_transform_bypass_flag");
/* 425 */       CAVLCWriter.writeBool(writer, (this.scalingMatrix != null), "SPS: ");
/* 426 */       if (this.scalingMatrix != null)
/* 427 */         for (int i = 0; i < 8; i++) {
/* 428 */           CAVLCWriter.writeBool(writer, (this.scalingMatrix[i] != null), "SPS: ");
/* 429 */           if (this.scalingMatrix[i] != null) {
/* 430 */             writeScalingList(writer, this.scalingMatrix, i);
/*     */           }
/*     */         }  
/*     */     } 
/* 434 */     CAVLCWriter.writeUEtrace(writer, this.log2MaxFrameNumMinus4, "SPS: log2_max_frame_num_minus4");
/* 435 */     CAVLCWriter.writeUEtrace(writer, this.picOrderCntType, "SPS: pic_order_cnt_type");
/* 436 */     if (this.picOrderCntType == 0) {
/* 437 */       CAVLCWriter.writeUEtrace(writer, this.log2MaxPicOrderCntLsbMinus4, "SPS: log2_max_pic_order_cnt_lsb_minus4");
/* 438 */     } else if (this.picOrderCntType == 1) {
/* 439 */       CAVLCWriter.writeBool(writer, this.deltaPicOrderAlwaysZeroFlag, "SPS: delta_pic_order_always_zero_flag");
/* 440 */       CAVLCWriter.writeSEtrace(writer, this.offsetForNonRefPic, "SPS: offset_for_non_ref_pic");
/* 441 */       CAVLCWriter.writeSEtrace(writer, this.offsetForTopToBottomField, "SPS: offset_for_top_to_bottom_field");
/* 442 */       CAVLCWriter.writeUEtrace(writer, this.offsetForRefFrame.length, "SPS: ");
/* 443 */       for (int i = 0; i < this.offsetForRefFrame.length; i++)
/* 444 */         CAVLCWriter.writeSEtrace(writer, this.offsetForRefFrame[i], "SPS: "); 
/*     */     } 
/* 446 */     CAVLCWriter.writeUEtrace(writer, this.numRefFrames, "SPS: num_ref_frames");
/* 447 */     CAVLCWriter.writeBool(writer, this.gapsInFrameNumValueAllowedFlag, "SPS: gaps_in_frame_num_value_allowed_flag");
/* 448 */     CAVLCWriter.writeUEtrace(writer, this.picWidthInMbsMinus1, "SPS: pic_width_in_mbs_minus1");
/* 449 */     CAVLCWriter.writeUEtrace(writer, this.picHeightInMapUnitsMinus1, "SPS: pic_height_in_map_units_minus1");
/* 450 */     CAVLCWriter.writeBool(writer, this.frameMbsOnlyFlag, "SPS: frame_mbs_only_flag");
/* 451 */     if (!this.frameMbsOnlyFlag) {
/* 452 */       CAVLCWriter.writeBool(writer, this.mbAdaptiveFrameFieldFlag, "SPS: mb_adaptive_frame_field_flag");
/*     */     }
/* 454 */     CAVLCWriter.writeBool(writer, this.direct8x8InferenceFlag, "SPS: direct_8x8_inference_flag");
/* 455 */     CAVLCWriter.writeBool(writer, this.frameCroppingFlag, "SPS: frame_cropping_flag");
/* 456 */     if (this.frameCroppingFlag) {
/* 457 */       CAVLCWriter.writeUEtrace(writer, this.frameCropLeftOffset, "SPS: frame_crop_left_offset");
/* 458 */       CAVLCWriter.writeUEtrace(writer, this.frameCropRightOffset, "SPS: frame_crop_right_offset");
/* 459 */       CAVLCWriter.writeUEtrace(writer, this.frameCropTopOffset, "SPS: frame_crop_top_offset");
/* 460 */       CAVLCWriter.writeUEtrace(writer, this.frameCropBottomOffset, "SPS: frame_crop_bottom_offset");
/*     */     } 
/* 462 */     CAVLCWriter.writeBool(writer, (this.vuiParams != null), "SPS: ");
/* 463 */     if (this.vuiParams != null) {
/* 464 */       writeVUIParameters(this.vuiParams, writer);
/*     */     }
/* 466 */     CAVLCWriter.writeTrailingBits(writer);
/*     */   }
/*     */   
/*     */   private void writeVUIParameters(VUIParameters vuip, BitWriter writer) {
/* 470 */     CAVLCWriter.writeBool(writer, vuip.aspectRatioInfoPresentFlag, "VUI: aspect_ratio_info_present_flag");
/* 471 */     if (vuip.aspectRatioInfoPresentFlag) {
/* 472 */       CAVLCWriter.writeNBit(writer, vuip.aspectRatio.getValue(), 8, "VUI: aspect_ratio");
/* 473 */       if (vuip.aspectRatio == AspectRatio.Extended_SAR) {
/* 474 */         CAVLCWriter.writeNBit(writer, vuip.sarWidth, 16, "VUI: sar_width");
/* 475 */         CAVLCWriter.writeNBit(writer, vuip.sarHeight, 16, "VUI: sar_height");
/*     */       } 
/*     */     } 
/* 478 */     CAVLCWriter.writeBool(writer, vuip.overscanInfoPresentFlag, "VUI: overscan_info_present_flag");
/* 479 */     if (vuip.overscanInfoPresentFlag) {
/* 480 */       CAVLCWriter.writeBool(writer, vuip.overscanAppropriateFlag, "VUI: overscan_appropriate_flag");
/*     */     }
/* 482 */     CAVLCWriter.writeBool(writer, vuip.videoSignalTypePresentFlag, "VUI: video_signal_type_present_flag");
/* 483 */     if (vuip.videoSignalTypePresentFlag) {
/* 484 */       CAVLCWriter.writeNBit(writer, vuip.videoFormat, 3, "VUI: video_format");
/* 485 */       CAVLCWriter.writeBool(writer, vuip.videoFullRangeFlag, "VUI: video_full_range_flag");
/* 486 */       CAVLCWriter.writeBool(writer, vuip.colourDescriptionPresentFlag, "VUI: colour_description_present_flag");
/* 487 */       if (vuip.colourDescriptionPresentFlag) {
/* 488 */         CAVLCWriter.writeNBit(writer, vuip.colourPrimaries, 8, "VUI: colour_primaries");
/* 489 */         CAVLCWriter.writeNBit(writer, vuip.transferCharacteristics, 8, "VUI: transfer_characteristics");
/* 490 */         CAVLCWriter.writeNBit(writer, vuip.matrixCoefficients, 8, "VUI: matrix_coefficients");
/*     */       } 
/*     */     } 
/* 493 */     CAVLCWriter.writeBool(writer, vuip.chromaLocInfoPresentFlag, "VUI: chroma_loc_info_present_flag");
/* 494 */     if (vuip.chromaLocInfoPresentFlag) {
/* 495 */       CAVLCWriter.writeUEtrace(writer, vuip.chromaSampleLocTypeTopField, "VUI: chroma_sample_loc_type_top_field");
/* 496 */       CAVLCWriter.writeUEtrace(writer, vuip.chromaSampleLocTypeBottomField, "VUI: chroma_sample_loc_type_bottom_field");
/*     */     } 
/* 498 */     CAVLCWriter.writeBool(writer, vuip.timingInfoPresentFlag, "VUI: timing_info_present_flag");
/* 499 */     if (vuip.timingInfoPresentFlag) {
/* 500 */       CAVLCWriter.writeNBit(writer, vuip.numUnitsInTick, 32, "VUI: num_units_in_tick");
/* 501 */       CAVLCWriter.writeNBit(writer, vuip.timeScale, 32, "VUI: time_scale");
/* 502 */       CAVLCWriter.writeBool(writer, vuip.fixedFrameRateFlag, "VUI: fixed_frame_rate_flag");
/*     */     } 
/* 504 */     CAVLCWriter.writeBool(writer, (vuip.nalHRDParams != null), "VUI: ");
/* 505 */     if (vuip.nalHRDParams != null) {
/* 506 */       writeHRDParameters(vuip.nalHRDParams, writer);
/*     */     }
/* 508 */     CAVLCWriter.writeBool(writer, (vuip.vclHRDParams != null), "VUI: ");
/* 509 */     if (vuip.vclHRDParams != null) {
/* 510 */       writeHRDParameters(vuip.vclHRDParams, writer);
/*     */     }
/*     */     
/* 513 */     if (vuip.nalHRDParams != null || vuip.vclHRDParams != null) {
/* 514 */       CAVLCWriter.writeBool(writer, vuip.lowDelayHrdFlag, "VUI: low_delay_hrd_flag");
/*     */     }
/* 516 */     CAVLCWriter.writeBool(writer, vuip.picStructPresentFlag, "VUI: pic_struct_present_flag");
/* 517 */     CAVLCWriter.writeBool(writer, (vuip.bitstreamRestriction != null), "VUI: ");
/* 518 */     if (vuip.bitstreamRestriction != null) {
/* 519 */       CAVLCWriter.writeBool(writer, vuip.bitstreamRestriction.motionVectorsOverPicBoundariesFlag, "VUI: motion_vectors_over_pic_boundaries_flag");
/*     */       
/* 521 */       CAVLCWriter.writeUEtrace(writer, vuip.bitstreamRestriction.maxBytesPerPicDenom, "VUI: max_bytes_per_pic_denom");
/* 522 */       CAVLCWriter.writeUEtrace(writer, vuip.bitstreamRestriction.maxBitsPerMbDenom, "VUI: max_bits_per_mb_denom");
/* 523 */       CAVLCWriter.writeUEtrace(writer, vuip.bitstreamRestriction.log2MaxMvLengthHorizontal, "VUI: log2_max_mv_length_horizontal");
/*     */       
/* 525 */       CAVLCWriter.writeUEtrace(writer, vuip.bitstreamRestriction.log2MaxMvLengthVertical, "VUI: log2_max_mv_length_vertical");
/* 526 */       CAVLCWriter.writeUEtrace(writer, vuip.bitstreamRestriction.numReorderFrames, "VUI: num_reorder_frames");
/* 527 */       CAVLCWriter.writeUEtrace(writer, vuip.bitstreamRestriction.maxDecFrameBuffering, "VUI: max_dec_frame_buffering");
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   private void writeHRDParameters(HRDParameters hrd, BitWriter writer) {
/* 533 */     CAVLCWriter.writeUEtrace(writer, hrd.cpbCntMinus1, "HRD: cpb_cnt_minus1");
/* 534 */     CAVLCWriter.writeNBit(writer, hrd.bitRateScale, 4, "HRD: bit_rate_scale");
/* 535 */     CAVLCWriter.writeNBit(writer, hrd.cpbSizeScale, 4, "HRD: cpb_size_scale");
/*     */     
/* 537 */     for (int SchedSelIdx = 0; SchedSelIdx <= hrd.cpbCntMinus1; SchedSelIdx++) {
/* 538 */       CAVLCWriter.writeUEtrace(writer, hrd.bitRateValueMinus1[SchedSelIdx], "HRD: ");
/* 539 */       CAVLCWriter.writeUEtrace(writer, hrd.cpbSizeValueMinus1[SchedSelIdx], "HRD: ");
/* 540 */       CAVLCWriter.writeBool(writer, hrd.cbrFlag[SchedSelIdx], "HRD: ");
/*     */     } 
/* 542 */     CAVLCWriter.writeNBit(writer, hrd.initialCpbRemovalDelayLengthMinus1, 5, "HRD: initial_cpb_removal_delay_length_minus1");
/*     */     
/* 544 */     CAVLCWriter.writeNBit(writer, hrd.cpbRemovalDelayLengthMinus1, 5, "HRD: cpb_removal_delay_length_minus1");
/* 545 */     CAVLCWriter.writeNBit(writer, hrd.dpbOutputDelayLengthMinus1, 5, "HRD: dpb_output_delay_length_minus1");
/* 546 */     CAVLCWriter.writeNBit(writer, hrd.timeOffsetLength, 5, "HRD: time_offset_length");
/*     */   }
/*     */   
/*     */   public SeqParameterSet copy() {
/* 550 */     ByteBuffer buf = ByteBuffer.allocate(2048);
/* 551 */     write(buf);
/* 552 */     buf.flip();
/* 553 */     return read(buf);
/*     */   }
/*     */   
/*     */   public int getPicOrderCntType() {
/* 557 */     return this.picOrderCntType;
/*     */   }
/*     */   
/*     */   public boolean isFieldPicFlag() {
/* 561 */     return this.fieldPicFlag;
/*     */   }
/*     */   
/*     */   public boolean isDeltaPicOrderAlwaysZeroFlag() {
/* 565 */     return this.deltaPicOrderAlwaysZeroFlag;
/*     */   }
/*     */   
/*     */   public boolean isMbAdaptiveFrameFieldFlag() {
/* 569 */     return this.mbAdaptiveFrameFieldFlag;
/*     */   }
/*     */   
/*     */   public boolean isDirect8x8InferenceFlag() {
/* 573 */     return this.direct8x8InferenceFlag;
/*     */   }
/*     */   
/*     */   public ColorSpace getChromaFormatIdc() {
/* 577 */     return this.chromaFormatIdc;
/*     */   }
/*     */   
/*     */   public int getLog2MaxFrameNumMinus4() {
/* 581 */     return this.log2MaxFrameNumMinus4;
/*     */   }
/*     */   
/*     */   public int getLog2MaxPicOrderCntLsbMinus4() {
/* 585 */     return this.log2MaxPicOrderCntLsbMinus4;
/*     */   }
/*     */   
/*     */   public int getPicHeightInMapUnitsMinus1() {
/* 589 */     return this.picHeightInMapUnitsMinus1;
/*     */   }
/*     */   
/*     */   public int getPicWidthInMbsMinus1() {
/* 593 */     return this.picWidthInMbsMinus1;
/*     */   }
/*     */   
/*     */   public int getBitDepthLumaMinus8() {
/* 597 */     return this.bitDepthLumaMinus8;
/*     */   }
/*     */   
/*     */   public int getBitDepthChromaMinus8() {
/* 601 */     return this.bitDepthChromaMinus8;
/*     */   }
/*     */   
/*     */   public boolean isQpprimeYZeroTransformBypassFlag() {
/* 605 */     return this.qpprimeYZeroTransformBypassFlag;
/*     */   }
/*     */   
/*     */   public int getProfileIdc() {
/* 609 */     return this.profileIdc;
/*     */   }
/*     */   
/*     */   public boolean isConstraintSet0Flag() {
/* 613 */     return this.constraintSet0Flag;
/*     */   }
/*     */   
/*     */   public boolean isConstraintSet1Flag() {
/* 617 */     return this.constraintSet1Flag;
/*     */   }
/*     */   
/*     */   public boolean isConstraintSet2Flag() {
/* 621 */     return this.constraintSet2Flag;
/*     */   }
/*     */   
/*     */   public boolean isConstraintSet3Flag() {
/* 625 */     return this.constraintSet3Flag;
/*     */   }
/*     */   
/*     */   public boolean isConstraintSet4Flag() {
/* 629 */     return this.constraintSet4Flag;
/*     */   }
/*     */   
/*     */   public boolean isConstraintSet5Flag() {
/* 633 */     return this.constraintSet5Flag;
/*     */   }
/*     */   
/*     */   public int getLevelIdc() {
/* 637 */     return this.levelIdc;
/*     */   }
/*     */   
/*     */   public int getSeqParameterSetId() {
/* 641 */     return this.seqParameterSetId;
/*     */   }
/*     */   
/*     */   public boolean isResidualColorTransformFlag() {
/* 645 */     return this.separateColourPlaneFlag;
/*     */   }
/*     */   
/*     */   public int getOffsetForNonRefPic() {
/* 649 */     return this.offsetForNonRefPic;
/*     */   }
/*     */   
/*     */   public int getOffsetForTopToBottomField() {
/* 653 */     return this.offsetForTopToBottomField;
/*     */   }
/*     */   
/*     */   public int getNumRefFrames() {
/* 657 */     return this.numRefFrames;
/*     */   }
/*     */   
/*     */   public boolean isGapsInFrameNumValueAllowedFlag() {
/* 661 */     return this.gapsInFrameNumValueAllowedFlag;
/*     */   }
/*     */   
/*     */   public boolean isFrameMbsOnlyFlag() {
/* 665 */     return this.frameMbsOnlyFlag;
/*     */   }
/*     */   
/*     */   public boolean isFrameCroppingFlag() {
/* 669 */     return this.frameCroppingFlag;
/*     */   }
/*     */   
/*     */   public int getFrameCropLeftOffset() {
/* 673 */     return this.frameCropLeftOffset;
/*     */   }
/*     */   
/*     */   public int getFrameCropRightOffset() {
/* 677 */     return this.frameCropRightOffset;
/*     */   }
/*     */   
/*     */   public int getFrameCropTopOffset() {
/* 681 */     return this.frameCropTopOffset;
/*     */   }
/*     */   
/*     */   public int getFrameCropBottomOffset() {
/* 685 */     return this.frameCropBottomOffset;
/*     */   }
/*     */   
/*     */   public int[] getOffsetForRefFrame() {
/* 689 */     return this.offsetForRefFrame;
/*     */   }
/*     */   
/*     */   public VUIParameters getVuiParams() {
/* 693 */     return this.vuiParams;
/*     */   }
/*     */   
/*     */   public int[][] getScalingMatrix() {
/* 697 */     return this.scalingMatrix;
/*     */   }
/*     */   
/*     */   public int getNumRefFramesInPicOrderCntCycle() {
/* 701 */     return this.numRefFramesInPicOrderCntCycle;
/*     */   }
/*     */   
/*     */   public static int getPicHeightInMbs(SeqParameterSet sps) {
/* 705 */     int picHeightInMbs = sps.picHeightInMapUnitsMinus1 + 1 << (sps.frameMbsOnlyFlag ? 0 : 1);
/* 706 */     return picHeightInMbs;
/*     */   }
/*     */ }


/* Location:              C:\Users\rapha\Downloads\aurora.jar!\META-INF\jars\jcodec-0.2.5.jar!\org\jcodec\codecs\h264\io\model\SeqParameterSet.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */