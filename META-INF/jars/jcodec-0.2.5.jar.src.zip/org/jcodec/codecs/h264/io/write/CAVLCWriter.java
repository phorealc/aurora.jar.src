/*    */ package org.jcodec.codecs.h264.io.write;
/*    */ 
/*    */ import org.jcodec.api.NotImplementedException;
/*    */ import org.jcodec.common.io.BitWriter;
/*    */ import org.jcodec.common.tools.Debug;
/*    */ import org.jcodec.common.tools.MathUtil;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class CAVLCWriter
/*    */ {
/*    */   public static void writeUtrace(BitWriter out, int value, int n, String message) {
/* 23 */     out.writeNBit(value, n);
/* 24 */     Debug.trace(new Object[] { message, Integer.valueOf(value) });
/*    */   }
/*    */   
/*    */   public static void writeUE(BitWriter out, int value) {
/* 28 */     int bits = 0;
/* 29 */     int cumul = 0;
/* 30 */     for (int i = 0; i < 15; i++) {
/* 31 */       if (value < cumul + (1 << i)) {
/* 32 */         bits = i;
/*    */         break;
/*    */       } 
/* 35 */       cumul += 1 << i;
/*    */     } 
/* 37 */     out.writeNBit(0, bits);
/* 38 */     out.write1Bit(1);
/* 39 */     out.writeNBit(value - cumul, bits);
/*    */   }
/*    */   
/*    */   public static void writeSE(BitWriter out, int value) {
/* 43 */     writeUE(out, MathUtil.golomb(value));
/*    */   }
/*    */   
/*    */   public static void writeUEtrace(BitWriter out, int value, String message) {
/* 47 */     writeUE(out, value);
/* 48 */     Debug.trace(new Object[] { message, Integer.valueOf(value) });
/*    */   }
/*    */   
/*    */   public static void writeSEtrace(BitWriter out, int value, String message) {
/* 52 */     writeUE(out, MathUtil.golomb(value));
/* 53 */     Debug.trace(new Object[] { message, Integer.valueOf(value) });
/*    */   }
/*    */   
/*    */   public static void writeTE(BitWriter out, int value, int max) {
/* 57 */     if (max > 1) {
/* 58 */       writeUE(out, value);
/*    */     } else {
/* 60 */       out.write1Bit((value ^ 0xFFFFFFFF) & 0x1);
/*    */     } 
/*    */   }
/*    */   public static void writeBool(BitWriter out, boolean value, String message) {
/* 64 */     out.write1Bit(value ? 1 : 0);
/* 65 */     Debug.trace(new Object[] { message, Integer.valueOf(value ? 1 : 0) });
/*    */   }
/*    */   
/*    */   public static void writeU(BitWriter out, int i, int n) {
/* 69 */     out.writeNBit(i, n);
/*    */   }
/*    */   
/*    */   public static void writeNBit(BitWriter out, long value, int n, String message) {
/* 73 */     for (int i = 0; i < n; i++) {
/* 74 */       out.write1Bit((int)(value >> n - i - 1) & 0x1);
/*    */     }
/* 76 */     Debug.trace(new Object[] { message, Long.valueOf(value) });
/*    */   }
/*    */   
/*    */   public static void writeTrailingBits(BitWriter out) {
/* 80 */     out.write1Bit(1);
/* 81 */     out.flush();
/*    */   }
/*    */   
/*    */   public static void writeSliceTrailingBits() {
/* 85 */     throw new NotImplementedException("todo");
/*    */   }
/*    */ }


/* Location:              C:\Users\rapha\Downloads\aurora.jar!\META-INF\jars\jcodec-0.2.5.jar!\org\jcodec\codecs\h264\io\write\CAVLCWriter.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */