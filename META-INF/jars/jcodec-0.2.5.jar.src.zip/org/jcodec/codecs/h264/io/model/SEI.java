/*    */ package org.jcodec.codecs.h264.io.model;
/*    */ 
/*    */ import java.nio.ByteBuffer;
/*    */ import java.util.ArrayList;
/*    */ import java.util.List;
/*    */ import org.jcodec.codecs.h264.io.write.CAVLCWriter;
/*    */ import org.jcodec.common.io.BitWriter;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class SEI
/*    */ {
/*    */   public SEIMessage[] messages;
/*    */   
/*    */   public static class SEIMessage
/*    */   {
/*    */     public int payloadType;
/*    */     public int payloadSize;
/*    */     public byte[] payload;
/*    */     
/*    */     public SEIMessage(int payloadType2, int payloadSize2, byte[] payload2) {
/* 29 */       this.payload = payload2;
/* 30 */       this.payloadType = payloadType2;
/* 31 */       this.payloadSize = payloadSize2;
/*    */     }
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public SEI(SEIMessage[] messages) {
/* 39 */     this.messages = messages;
/*    */   }
/*    */   
/*    */   public static SEI read(ByteBuffer is) {
/*    */     SEIMessage msg;
/* 44 */     List<SEIMessage> messages = new ArrayList<SEIMessage>();
/*    */     
/*    */     do {
/* 47 */       msg = sei_message(is);
/* 48 */       if (msg == null)
/* 49 */         continue;  messages.add(msg);
/* 50 */     } while (msg != null);
/*    */     
/* 52 */     return new SEI(messages.<SEIMessage>toArray(new SEIMessage[0]));
/*    */   }
/*    */   
/*    */   private static SEIMessage sei_message(ByteBuffer is) {
/* 56 */     int payloadType = 0;
/* 57 */     int b = 0;
/* 58 */     while (is.hasRemaining() && (b = is.get() & 0xFF) == 255) {
/* 59 */       payloadType += 255;
/*    */     }
/* 61 */     if (!is.hasRemaining())
/* 62 */       return null; 
/* 63 */     payloadType += b;
/* 64 */     int payloadSize = 0;
/* 65 */     while (is.hasRemaining() && (b = is.get() & 0xFF) == 255) {
/* 66 */       payloadSize += 255;
/*    */     }
/* 68 */     if (!is.hasRemaining())
/* 69 */       return null; 
/* 70 */     payloadSize += b;
/* 71 */     byte[] payload = sei_payload(payloadType, payloadSize, is);
/* 72 */     if (payload.length != payloadSize) {
/* 73 */       return null;
/*    */     }
/* 75 */     return new SEIMessage(payloadType, payloadSize, payload);
/*    */   }
/*    */ 
/*    */   
/*    */   private static byte[] sei_payload(int payloadType, int payloadSize, ByteBuffer is) {
/* 80 */     byte[] res = new byte[payloadSize];
/* 81 */     is.get(res);
/* 82 */     return res;
/*    */   }
/*    */   
/*    */   public void write(ByteBuffer out) {
/* 86 */     BitWriter writer = new BitWriter(out);
/*    */ 
/*    */     
/* 89 */     CAVLCWriter.writeTrailingBits(writer);
/*    */   }
/*    */ }


/* Location:              C:\Users\rapha\Downloads\aurora.jar!\META-INF\jars\jcodec-0.2.5.jar!\org\jcodec\codecs\h264\io\model\SEI.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */