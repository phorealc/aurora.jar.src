/*    */ package org.jcodec.codecs.h264.io.model;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public final class MBType
/*    */ {
/* 12 */   public static final MBType I_NxN = new MBType(true, 0);
/* 13 */   public static final MBType I_16x16 = new MBType(true, 1);
/* 14 */   public static final MBType I_PCM = new MBType(true, 25);
/* 15 */   public static final MBType P_16x16 = new MBType(false, 0);
/* 16 */   public static final MBType P_16x8 = new MBType(false, 1);
/* 17 */   public static final MBType P_8x16 = new MBType(false, 2);
/* 18 */   public static final MBType P_8x8 = new MBType(false, 3);
/* 19 */   public static final MBType P_8x8ref0 = new MBType(false, 4);
/* 20 */   public static final MBType B_Direct_16x16 = new MBType(false, 0);
/* 21 */   public static final MBType B_L0_16x16 = new MBType(false, 1);
/* 22 */   public static final MBType B_L1_16x16 = new MBType(false, 2);
/* 23 */   public static final MBType B_Bi_16x16 = new MBType(false, 3);
/* 24 */   public static final MBType B_L0_L0_16x8 = new MBType(false, 4);
/* 25 */   public static final MBType B_L0_L0_8x16 = new MBType(false, 5);
/* 26 */   public static final MBType B_L1_L1_16x8 = new MBType(false, 6);
/* 27 */   public static final MBType B_L1_L1_8x16 = new MBType(false, 7);
/* 28 */   public static final MBType B_L0_L1_16x8 = new MBType(false, 8);
/* 29 */   public static final MBType B_L0_L1_8x16 = new MBType(false, 9);
/* 30 */   public static final MBType B_L1_L0_16x8 = new MBType(false, 10);
/* 31 */   public static final MBType B_L1_L0_8x16 = new MBType(false, 11);
/* 32 */   public static final MBType B_L0_Bi_16x8 = new MBType(false, 12);
/* 33 */   public static final MBType B_L0_Bi_8x16 = new MBType(false, 13);
/* 34 */   public static final MBType B_L1_Bi_16x8 = new MBType(false, 14);
/* 35 */   public static final MBType B_L1_Bi_8x16 = new MBType(false, 15);
/* 36 */   public static final MBType B_Bi_L0_16x8 = new MBType(false, 16);
/* 37 */   public static final MBType B_Bi_L0_8x16 = new MBType(false, 17);
/* 38 */   public static final MBType B_Bi_L1_16x8 = new MBType(false, 18);
/* 39 */   public static final MBType B_Bi_L1_8x16 = new MBType(false, 19);
/* 40 */   public static final MBType B_Bi_Bi_16x8 = new MBType(false, 20);
/* 41 */   public static final MBType B_Bi_Bi_8x16 = new MBType(false, 21);
/* 42 */   public static final MBType B_8x8 = new MBType(false, 22);
/*    */   
/*    */   public boolean intra;
/*    */   public int _code;
/*    */   
/*    */   private MBType(boolean intra, int code) {
/* 48 */     this.intra = intra;
/* 49 */     this._code = code;
/*    */   }
/*    */   
/*    */   public boolean isIntra() {
/* 53 */     return this.intra;
/*    */   }
/*    */   
/*    */   public int code() {
/* 57 */     return this._code;
/*    */   }
/*    */ }


/* Location:              C:\Users\rapha\Downloads\aurora.jar!\META-INF\jars\jcodec-0.2.5.jar!\org\jcodec\codecs\h264\io\model\MBType.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */