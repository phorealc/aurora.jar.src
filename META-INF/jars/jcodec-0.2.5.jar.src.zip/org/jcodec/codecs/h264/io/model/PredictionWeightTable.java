/*    */ package org.jcodec.codecs.h264.io.model;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class PredictionWeightTable
/*    */ {
/*    */   public int lumaLog2WeightDenom;
/*    */   public int chromaLog2WeightDenom;
/* 27 */   public int[][] lumaWeight = new int[2][];
/* 28 */   public int[][][] chromaWeight = new int[2][][];
/*    */   
/* 30 */   public int[][] lumaOffset = new int[2][];
/* 31 */   public int[][][] chromaOffset = new int[2][][];
/*    */ }


/* Location:              C:\Users\rapha\Downloads\aurora.jar!\META-INF\jars\jcodec-0.2.5.jar!\org\jcodec\codecs\h264\io\model\PredictionWeightTable.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */