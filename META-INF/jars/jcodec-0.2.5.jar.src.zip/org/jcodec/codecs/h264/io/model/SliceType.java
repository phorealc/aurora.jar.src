/*    */ package org.jcodec.codecs.h264.io.model;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public final class SliceType
/*    */ {
/* 11 */   private static final SliceType[] _values = new SliceType[5];
/* 12 */   public static final SliceType P = new SliceType("P", 0);
/* 13 */   public static final SliceType B = new SliceType("B", 1);
/* 14 */   public static final SliceType I = new SliceType("I", 2);
/* 15 */   public static final SliceType SP = new SliceType("SP", 3);
/* 16 */   public static final SliceType SI = new SliceType("SI", 4);
/*    */   private String _name;
/*    */   private int _ordinal;
/*    */   
/*    */   private SliceType(String name, int ordinal) {
/* 21 */     this._name = name;
/* 22 */     this._ordinal = ordinal;
/* 23 */     _values[ordinal] = this;
/*    */   }
/*    */   
/*    */   public boolean isIntra() {
/* 27 */     return (this == I || this == SI);
/*    */   }
/*    */   
/*    */   public boolean isInter() {
/* 31 */     return (this != I && this != SI);
/*    */   }
/*    */   
/*    */   public static SliceType[] values() {
/* 35 */     return _values;
/*    */   }
/*    */   
/*    */   public int ordinal() {
/* 39 */     return this._ordinal;
/*    */   }
/*    */ 
/*    */   
/*    */   public String toString() {
/* 44 */     return this._name;
/*    */   }
/*    */   
/*    */   public String name() {
/* 48 */     return this._name;
/*    */   }
/*    */   
/*    */   public static SliceType fromValue(int j) {
/* 52 */     return values()[j];
/*    */   }
/*    */ }


/* Location:              C:\Users\rapha\Downloads\aurora.jar!\META-INF\jars\jcodec-0.2.5.jar!\org\jcodec\codecs\h264\io\model\SliceType.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */