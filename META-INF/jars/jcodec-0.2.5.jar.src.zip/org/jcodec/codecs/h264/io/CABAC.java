/*     */ package org.jcodec.codecs.h264.io;
/*     */ 
/*     */ import org.jcodec.codecs.common.biari.MDecoder;
/*     */ import org.jcodec.codecs.common.biari.MEncoder;
/*     */ import org.jcodec.codecs.h264.H264Const;
/*     */ import org.jcodec.codecs.h264.H264Utils2;
/*     */ import org.jcodec.codecs.h264.decode.CABACContst;
/*     */ import org.jcodec.codecs.h264.io.model.MBType;
/*     */ import org.jcodec.codecs.h264.io.model.SliceType;
/*     */ import org.jcodec.common.tools.MathUtil;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class CABAC
/*     */ {
/*     */   private int chromaPredModeLeft;
/*     */   private int[] chromaPredModeTop;
/*     */   private int prevMbQpDelta;
/*     */   private int prevCBP;
/*     */   private int[][] codedBlkLeft;
/*     */   private int[][] codedBlkTop;
/*     */   private int[] codedBlkDCLeft;
/*     */   private int[][] codedBlkDCTop;
/*     */   private int[][] refIdxLeft;
/*     */   private int[][] refIdxTop;
/*     */   private boolean skipFlagLeft;
/*     */   private boolean[] skipFlagsTop;
/*     */   private int[][][] mvdTop;
/*     */   private int[][][] mvdLeft;
/*     */   public int[] tmp;
/*     */   
/*     */   public static final class BlockType
/*     */   {
/*  35 */     public static final BlockType LUMA_16_DC = new BlockType(85, 105, 166, 277, 338, 227, 0);
/*  36 */     public static final BlockType LUMA_15_AC = new BlockType(89, 120, 181, 292, 353, 237, 0);
/*  37 */     public static final BlockType LUMA_16 = new BlockType(93, 134, 195, 306, 367, 247, 0);
/*  38 */     public static final BlockType CHROMA_DC = new BlockType(97, 149, 210, 321, 382, 257, 1);
/*  39 */     public static final BlockType CHROMA_AC = new BlockType(101, 152, 213, 324, 385, 266, 0);
/*  40 */     public static final BlockType LUMA_64 = new BlockType(1012, 402, 417, 436, 451, 426, 0);
/*  41 */     public static final BlockType CB_16_DC = new BlockType(460, 484, 572, 776, 864, 952, 0);
/*  42 */     public static final BlockType CB_15x16_AC = new BlockType(464, 499, 587, 791, 879, 962, 0);
/*  43 */     public static final BlockType CB_16 = new BlockType(468, 513, 601, 805, 893, 972, 0);
/*  44 */     public static final BlockType CB_64 = new BlockType(1016, 660, 690, 675, 699, 708, 0);
/*  45 */     public static final BlockType CR_16_DC = new BlockType(472, 528, 616, 820, 908, 982, 0);
/*  46 */     public static final BlockType CR_15x16_AC = new BlockType(476, 543, 631, 835, 923, 992, 0);
/*  47 */     public static final BlockType CR_16 = new BlockType(480, 557, 645, 849, 937, 1002, 0);
/*  48 */     public static final BlockType CR_64 = new BlockType(1020, 718, 748, 733, 757, 766, 0);
/*     */     
/*     */     public int codedBlockCtxOff;
/*     */     
/*     */     public int sigCoeffFlagCtxOff;
/*     */     public int lastSigCoeffCtxOff;
/*     */     public int sigCoeffFlagFldCtxOff;
/*     */     public int lastSigCoeffFldCtxOff;
/*     */     public int coeffAbsLevelCtxOff;
/*     */     public int coeffAbsLevelAdjust;
/*     */     
/*     */     private BlockType(int codecBlockCtxOff, int sigCoeffCtxOff, int lastSigCoeffCtxOff, int sigCoeffFlagFldCtxOff, int lastSigCoeffFldCtxOff, int coeffAbsLevelCtxOff, int coeffAbsLevelAdjust) {
/*  60 */       this.codedBlockCtxOff = codecBlockCtxOff;
/*  61 */       this.sigCoeffFlagCtxOff = sigCoeffCtxOff;
/*  62 */       this.lastSigCoeffCtxOff = lastSigCoeffCtxOff;
/*  63 */       this.sigCoeffFlagFldCtxOff = sigCoeffFlagFldCtxOff;
/*  64 */       this.lastSigCoeffFldCtxOff = sigCoeffFlagFldCtxOff;
/*  65 */       this.coeffAbsLevelCtxOff = coeffAbsLevelCtxOff;
/*  66 */       this.coeffAbsLevelAdjust = coeffAbsLevelAdjust;
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public CABAC(int mbWidth) {
/*  93 */     this.tmp = new int[16];
/*  94 */     this.chromaPredModeLeft = 0;
/*  95 */     this.chromaPredModeTop = new int[mbWidth];
/*  96 */     this.codedBlkLeft = new int[][] { new int[4], new int[2], new int[2] };
/*  97 */     this.codedBlkTop = new int[][] { new int[mbWidth << 2], new int[mbWidth << 1], new int[mbWidth << 1] };
/*     */     
/*  99 */     this.codedBlkDCLeft = new int[3];
/* 100 */     this.codedBlkDCTop = new int[3][mbWidth];
/*     */     
/* 102 */     this.refIdxLeft = new int[2][4];
/* 103 */     this.refIdxTop = new int[2][mbWidth << 2];
/*     */     
/* 105 */     this.skipFlagsTop = new boolean[mbWidth];
/*     */     
/* 107 */     this.mvdTop = new int[2][2][mbWidth << 2];
/* 108 */     this.mvdLeft = new int[2][2][4];
/*     */   }
/*     */ 
/*     */   
/*     */   public int readCoeffs(MDecoder decoder, BlockType blockType, int[] out, int first, int num, int[] reorder, int[] scMapping, int[] lscMapping) {
/* 113 */     boolean[] sigCoeff = new boolean[num];
/*     */     int numCoeff;
/* 115 */     for (numCoeff = 0; numCoeff < num - 1; numCoeff++) {
/* 116 */       sigCoeff[numCoeff] = (decoder.decodeBin(blockType.sigCoeffFlagCtxOff + scMapping[numCoeff]) == 1);
/* 117 */       if (sigCoeff[numCoeff] && decoder.decodeBin(blockType.lastSigCoeffCtxOff + lscMapping[numCoeff]) == 1)
/*     */         break; 
/*     */     } 
/* 120 */     sigCoeff[numCoeff++] = true;
/*     */     
/* 122 */     int numGt1 = 0, numEq1 = 0;
/* 123 */     for (int j = numCoeff - 1; j >= 0; j--) {
/* 124 */       if (sigCoeff[j]) {
/*     */         
/* 126 */         int absLev = readCoeffAbsLevel(decoder, blockType, numGt1, numEq1);
/* 127 */         if (absLev == 0) {
/* 128 */           numEq1++;
/*     */         } else {
/* 130 */           numGt1++;
/* 131 */         }  out[reorder[j + first]] = MathUtil.toSigned(absLev + 1, -decoder.decodeBinBypass());
/*     */       } 
/*     */     } 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 138 */     return numGt1 + numEq1;
/*     */   }
/*     */ 
/*     */   
/*     */   private int readCoeffAbsLevel(MDecoder decoder, BlockType blockType, int numDecodAbsLevelGt1, int numDecodAbsLevelEq1) {
/* 143 */     int incB0 = (numDecodAbsLevelGt1 != 0) ? 0 : Math.min(4, 1 + numDecodAbsLevelEq1);
/* 144 */     int incBN = 5 + Math.min(4 - blockType.coeffAbsLevelAdjust, numDecodAbsLevelGt1);
/*     */     
/* 146 */     int b = decoder.decodeBin(blockType.coeffAbsLevelCtxOff + incB0); int val;
/* 147 */     for (val = 0; b != 0 && val < 13; val++)
/* 148 */       b = decoder.decodeBin(blockType.coeffAbsLevelCtxOff + incBN); 
/* 149 */     val += b;
/*     */     
/* 151 */     if (val == 14) {
/* 152 */       int log = -2, add = 0, sum = 0;
/*     */       do {
/* 154 */         log++;
/* 155 */         b = decoder.decodeBinBypass();
/* 156 */       } while (b != 0);
/*     */       
/* 158 */       for (; log >= 0; log--) {
/* 159 */         add |= decoder.decodeBinBypass() << log;
/* 160 */         sum += 1 << log;
/*     */       } 
/*     */       
/* 163 */       val += add + sum;
/*     */     } 
/*     */     
/* 166 */     return val;
/*     */   }
/*     */ 
/*     */   
/*     */   public void writeCoeffs(MEncoder encoder, BlockType blockType, int[] _out, int first, int num, int[] reorder) {
/* 171 */     for (int i = 0; i < num; i++) {
/* 172 */       this.tmp[i] = _out[reorder[first + i]];
/*     */     }
/* 174 */     int numCoeff = 0; int k;
/* 175 */     for (k = 0; k < num; k++) {
/* 176 */       if (this.tmp[k] != 0)
/* 177 */         numCoeff = k + 1; 
/*     */     } 
/* 179 */     for (k = 0; k < Math.min(numCoeff, num - 1); k++) {
/* 180 */       if (this.tmp[k] != 0) {
/* 181 */         encoder.encodeBin(blockType.sigCoeffFlagCtxOff + k, 1);
/* 182 */         encoder.encodeBin(blockType.lastSigCoeffCtxOff + k, (k == numCoeff - 1) ? 1 : 0);
/*     */       } else {
/* 184 */         encoder.encodeBin(blockType.sigCoeffFlagCtxOff + k, 0);
/*     */       } 
/*     */     } 
/*     */     
/* 188 */     int numGt1 = 0, numEq1 = 0;
/* 189 */     for (int j = numCoeff - 1; j >= 0; j--) {
/* 190 */       if (this.tmp[j] != 0) {
/*     */         
/* 192 */         int absLev = MathUtil.abs(this.tmp[j]) - 1;
/* 193 */         writeCoeffAbsLevel(encoder, blockType, numGt1, numEq1, absLev);
/* 194 */         if (absLev == 0) {
/* 195 */           numEq1++;
/*     */         } else {
/* 197 */           numGt1++;
/* 198 */         }  encoder.encodeBinBypass(MathUtil.sign(this.tmp[j]));
/*     */       } 
/*     */     } 
/*     */   }
/*     */   
/*     */   private void writeCoeffAbsLevel(MEncoder encoder, BlockType blockType, int numDecodAbsLevelGt1, int numDecodAbsLevelEq1, int absLev) {
/* 204 */     int incB0 = (numDecodAbsLevelGt1 != 0) ? 0 : Math.min(4, 1 + numDecodAbsLevelEq1);
/* 205 */     int incBN = 5 + Math.min(4 - blockType.coeffAbsLevelAdjust, numDecodAbsLevelGt1);
/*     */     
/* 207 */     if (absLev == 0) {
/* 208 */       encoder.encodeBin(blockType.coeffAbsLevelCtxOff + incB0, 0);
/*     */     } else {
/* 210 */       encoder.encodeBin(blockType.coeffAbsLevelCtxOff + incB0, 1);
/* 211 */       if (absLev < 14) {
/* 212 */         for (int i = 1; i < absLev; i++)
/* 213 */           encoder.encodeBin(blockType.coeffAbsLevelCtxOff + incBN, 1); 
/* 214 */         encoder.encodeBin(blockType.coeffAbsLevelCtxOff + incBN, 0);
/*     */       } else {
/* 216 */         for (int i = 1; i < 14; i++)
/* 217 */           encoder.encodeBin(blockType.coeffAbsLevelCtxOff + incBN, 1); 
/* 218 */         absLev -= 14;
/*     */         int sufLen, pow;
/* 220 */         for (sufLen = 0, pow = 1; absLev >= pow; pow = 1 << ++sufLen) {
/* 221 */           encoder.encodeBinBypass(1);
/* 222 */           absLev -= pow;
/*     */         } 
/* 224 */         encoder.encodeBinBypass(0);
/* 225 */         for (; --sufLen >= 0; sufLen--) {
/* 226 */           encoder.encodeBinBypass(absLev >> sufLen & 0x1);
/*     */         }
/*     */       } 
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public void initModels(int[][] cm, SliceType sliceType, int cabacIdc, int sliceQp) {
/* 234 */     int[] tabA = sliceType.isIntra() ? CABACContst.cabac_context_init_I_A : CABACContst.cabac_context_init_PB_A[cabacIdc];
/*     */     
/* 236 */     int[] tabB = sliceType.isIntra() ? CABACContst.cabac_context_init_I_B : CABACContst.cabac_context_init_PB_B[cabacIdc];
/*     */ 
/*     */     
/* 239 */     for (int i = 0; i < 1024; i++) {
/* 240 */       int preCtxState = MathUtil.clip((tabA[i] * MathUtil.clip(sliceQp, 0, 51) >> 4) + tabB[i], 1, 126);
/* 241 */       if (preCtxState <= 63) {
/* 242 */         cm[0][i] = 63 - preCtxState;
/* 243 */         cm[1][i] = 0;
/*     */       } else {
/* 245 */         cm[0][i] = preCtxState - 64;
/* 246 */         cm[1][i] = 1;
/*     */       } 
/*     */     } 
/*     */   }
/*     */   
/*     */   public int readMBTypeI(MDecoder decoder, MBType left, MBType top, boolean leftAvailable, boolean topAvailable) {
/* 252 */     int ctx = 3;
/* 253 */     ctx += (!leftAvailable || left == MBType.I_NxN) ? 0 : 1;
/* 254 */     ctx += (!topAvailable || top == MBType.I_NxN) ? 0 : 1;
/*     */     
/* 256 */     if (decoder.decodeBin(ctx) == 0) {
/* 257 */       return 0;
/*     */     }
/* 259 */     return (decoder.decodeFinalBin() == 1) ? 25 : (1 + readMBType16x16(decoder));
/*     */   }
/*     */ 
/*     */   
/*     */   private int readMBType16x16(MDecoder decoder) {
/* 264 */     int type = decoder.decodeBin(6) * 12;
/* 265 */     if (decoder.decodeBin(7) == 0) {
/* 266 */       return type + (decoder.decodeBin(9) << 1) + decoder.decodeBin(10);
/*     */     }
/* 268 */     return type + (decoder.decodeBin(8) << 2) + (decoder.decodeBin(9) << 1) + decoder.decodeBin(10) + 4;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public int readMBTypeP(MDecoder decoder) {
/* 274 */     if (decoder.decodeBin(14) == 1) {
/* 275 */       return 5 + readIntraP(decoder, 17);
/*     */     }
/* 277 */     if (decoder.decodeBin(15) == 0) {
/* 278 */       return (decoder.decodeBin(16) == 0) ? 0 : 3;
/*     */     }
/* 280 */     return (decoder.decodeBin(17) == 0) ? 2 : 1;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private int readIntraP(MDecoder decoder, int ctxOff) {
/* 286 */     if (decoder.decodeBin(ctxOff) == 0) {
/* 287 */       return 0;
/*     */     }
/* 289 */     return (decoder.decodeFinalBin() == 1) ? 25 : (1 + readMBType16x16P(decoder, ctxOff));
/*     */   }
/*     */ 
/*     */   
/*     */   private int readMBType16x16P(MDecoder decoder, int ctxOff) {
/* 294 */     ctxOff++;
/* 295 */     int type = decoder.decodeBin(ctxOff) * 12;
/* 296 */     ctxOff++;
/* 297 */     if (decoder.decodeBin(ctxOff) == 0) {
/* 298 */       ctxOff++;
/* 299 */       return type + (decoder.decodeBin(ctxOff) << 1) + decoder.decodeBin(ctxOff);
/*     */     } 
/* 301 */     return type + (decoder.decodeBin(ctxOff) << 2) + (decoder.decodeBin(ctxOff + 1) << 1) + decoder
/* 302 */       .decodeBin(ctxOff + 1) + 4;
/*     */   }
/*     */ 
/*     */   
/*     */   public int readMBTypeB(MDecoder mDecoder, MBType left, MBType top, boolean leftAvailable, boolean topAvailable) {
/* 307 */     int ctx = 27;
/* 308 */     ctx += (!leftAvailable || left == null || left == MBType.B_Direct_16x16) ? 0 : 1;
/* 309 */     ctx += (!topAvailable || top == null || top == MBType.B_Direct_16x16) ? 0 : 1;
/*     */     
/* 311 */     if (mDecoder.decodeBin(ctx) == 0)
/* 312 */       return 0; 
/* 313 */     if (mDecoder.decodeBin(30) == 0) {
/* 314 */       return 1 + mDecoder.decodeBin(32);
/*     */     }
/* 316 */     int b1 = mDecoder.decodeBin(31);
/* 317 */     if (b1 == 0) {
/* 318 */       return 3 + (mDecoder.decodeBin(32) << 2 | mDecoder.decodeBin(32) << 1 | mDecoder.decodeBin(32));
/*     */     }
/* 320 */     if (mDecoder.decodeBin(32) == 0) {
/* 321 */       return 12 + (mDecoder.decodeBin(32) << 2 | mDecoder.decodeBin(32) << 1 | mDecoder.decodeBin(32));
/*     */     }
/* 323 */     switch ((mDecoder.decodeBin(32) << 1) + mDecoder.decodeBin(32)) {
/*     */       case 0:
/* 325 */         return 20 + mDecoder.decodeBin(32);
/*     */       case 1:
/* 327 */         return 23 + readIntraP(mDecoder, 32);
/*     */       case 2:
/* 329 */         return 11;
/*     */       case 3:
/* 331 */         return 22;
/*     */     } 
/*     */ 
/*     */ 
/*     */     
/* 336 */     return 0;
/*     */   }
/*     */ 
/*     */   
/*     */   public void writeMBTypeI(MEncoder encoder, MBType left, MBType top, boolean leftAvailable, boolean topAvailable, int mbType) {
/* 341 */     int ctx = 3;
/* 342 */     ctx += (!leftAvailable || left == MBType.I_NxN) ? 0 : 1;
/* 343 */     ctx += (!topAvailable || top == MBType.I_NxN) ? 0 : 1;
/*     */     
/* 345 */     if (mbType == 0) {
/* 346 */       encoder.encodeBin(ctx, 0);
/*     */     } else {
/* 348 */       encoder.encodeBin(ctx, 1);
/* 349 */       if (mbType == 25) {
/* 350 */         encoder.encodeBinFinal(1);
/*     */       } else {
/* 352 */         encoder.encodeBinFinal(0);
/* 353 */         writeMBType16x16(encoder, mbType - 1);
/*     */       } 
/*     */     } 
/*     */   }
/*     */   
/*     */   private void writeMBType16x16(MEncoder encoder, int mbType) {
/* 359 */     if (mbType < 12) {
/* 360 */       encoder.encodeBin(6, 0);
/*     */     } else {
/* 362 */       encoder.encodeBin(6, 1);
/* 363 */       mbType -= 12;
/*     */     } 
/* 365 */     if (mbType < 4) {
/* 366 */       encoder.encodeBin(7, 0);
/* 367 */       encoder.encodeBin(9, mbType >> 1);
/* 368 */       encoder.encodeBin(10, mbType & 0x1);
/*     */     } else {
/* 370 */       mbType -= 4;
/* 371 */       encoder.encodeBin(7, 1);
/* 372 */       encoder.encodeBin(8, mbType >> 2);
/* 373 */       encoder.encodeBin(9, mbType >> 1 & 0x1);
/* 374 */       encoder.encodeBin(10, mbType & 0x1);
/*     */     } 
/*     */   }
/*     */   
/*     */   public int readMBQpDelta(MDecoder decoder, MBType prevMbType) {
/* 379 */     int ctx = 60;
/* 380 */     ctx += (prevMbType == null || prevMbType == MBType.I_PCM || (prevMbType != MBType.I_16x16 && this.prevCBP == 0) || this.prevMbQpDelta == 0) ? 0 : 1;
/*     */ 
/*     */     
/* 383 */     int val = 0;
/* 384 */     if (decoder.decodeBin(ctx) == 1) {
/* 385 */       val++;
/* 386 */       if (decoder.decodeBin(62) == 1) {
/* 387 */         val++;
/* 388 */         while (decoder.decodeBin(63) == 1)
/* 389 */           val++; 
/*     */       } 
/*     */     } 
/* 392 */     this.prevMbQpDelta = H264Utils2.golomb2Signed(val);
/*     */     
/* 394 */     return this.prevMbQpDelta;
/*     */   }
/*     */   
/*     */   public void writeMBQpDelta(MEncoder encoder, MBType prevMbType, int mbQpDelta) {
/* 398 */     int ctx = 60;
/* 399 */     ctx += (prevMbType == null || prevMbType == MBType.I_PCM || (prevMbType != MBType.I_16x16 && this.prevCBP == 0) || this.prevMbQpDelta == 0) ? 0 : 1;
/*     */ 
/*     */     
/* 402 */     this.prevMbQpDelta = mbQpDelta;
/* 403 */     if (mbQpDelta-- == 0) {
/* 404 */       encoder.encodeBin(ctx, 0);
/*     */     } else {
/* 406 */       encoder.encodeBin(ctx, 1);
/* 407 */       if (mbQpDelta-- == 0) {
/* 408 */         encoder.encodeBin(62, 0);
/*     */       } else {
/* 410 */         while (mbQpDelta-- > 0)
/* 411 */           encoder.encodeBin(63, 1); 
/* 412 */         encoder.encodeBin(63, 0);
/*     */       } 
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public int readIntraChromaPredMode(MDecoder decoder, int mbX, MBType left, MBType top, boolean leftAvailable, boolean topAvailable) {
/* 419 */     int mode, ctx = 64;
/* 420 */     ctx += (!leftAvailable || left == null || !left.isIntra() || this.chromaPredModeLeft == 0) ? 0 : 1;
/* 421 */     ctx += (!topAvailable || top == null || !top.isIntra() || this.chromaPredModeTop[mbX] == 0) ? 0 : 1;
/*     */     
/* 423 */     if (decoder.decodeBin(ctx) == 0) {
/* 424 */       mode = 0;
/* 425 */     } else if (decoder.decodeBin(67) == 0) {
/* 426 */       mode = 1;
/* 427 */     } else if (decoder.decodeBin(67) == 0) {
/* 428 */       mode = 2;
/*     */     } else {
/* 430 */       mode = 3;
/* 431 */     }  this.chromaPredModeLeft = this.chromaPredModeTop[mbX] = mode;
/*     */     
/* 433 */     return mode;
/*     */   }
/*     */ 
/*     */   
/*     */   public void writeIntraChromaPredMode(MEncoder encoder, int mbX, MBType left, MBType top, boolean leftAvailable, boolean topAvailable, int mode) {
/* 438 */     int ctx = 64;
/* 439 */     ctx += (!leftAvailable || !left.isIntra() || this.chromaPredModeLeft == 0) ? 0 : 1;
/* 440 */     ctx += (!topAvailable || !top.isIntra() || this.chromaPredModeTop[mbX] == 0) ? 0 : 1;
/* 441 */     encoder.encodeBin(ctx, (mode-- == 0) ? 0 : 1);
/* 442 */     for (int i = 0; mode >= 0 && i < 2; i++)
/* 443 */       encoder.encodeBin(67, (mode-- == 0) ? 0 : 1); 
/* 444 */     this.chromaPredModeLeft = this.chromaPredModeTop[mbX] = mode;
/*     */   }
/*     */   
/*     */   public int condTerm(MBType mbCur, boolean nAvb, MBType mbN, boolean nBlkAvb, int cbpN) {
/* 448 */     if (!nAvb)
/* 449 */       return mbCur.isIntra() ? 1 : 0; 
/* 450 */     if (mbN == MBType.I_PCM)
/* 451 */       return 1; 
/* 452 */     if (!nBlkAvb)
/* 453 */       return 0; 
/* 454 */     return cbpN;
/*     */   }
/*     */ 
/*     */   
/*     */   public int readCodedBlockFlagLumaDC(MDecoder decoder, int mbX, MBType left, MBType top, boolean leftAvailable, boolean topAvailable, MBType cur) {
/* 459 */     int tLeft = condTerm(cur, leftAvailable, left, (left == MBType.I_16x16), this.codedBlkDCLeft[0]);
/* 460 */     int tTop = condTerm(cur, topAvailable, top, (top == MBType.I_16x16), this.codedBlkDCTop[0][mbX]);
/*     */     
/* 462 */     int decoded = decoder.decodeBin(BlockType.LUMA_16_DC.codedBlockCtxOff + tLeft + 2 * tTop);
/*     */     
/* 464 */     this.codedBlkDCLeft[0] = decoded;
/* 465 */     this.codedBlkDCTop[0][mbX] = decoded;
/*     */     
/* 467 */     return decoded;
/*     */   }
/*     */ 
/*     */   
/*     */   public int readCodedBlockFlagChromaDC(MDecoder decoder, int mbX, int comp, MBType left, MBType top, boolean leftAvailable, boolean topAvailable, int leftCBPChroma, int topCBPChroma, MBType cur) {
/* 472 */     int tLeft = condTerm(cur, leftAvailable, left, (left != null && leftCBPChroma != 0), this.codedBlkDCLeft[comp]);
/* 473 */     int tTop = condTerm(cur, topAvailable, top, (top != null && topCBPChroma != 0), this.codedBlkDCTop[comp][mbX]);
/*     */     
/* 475 */     int decoded = decoder.decodeBin(BlockType.CHROMA_DC.codedBlockCtxOff + tLeft + 2 * tTop);
/*     */     
/* 477 */     this.codedBlkDCLeft[comp] = decoded;
/* 478 */     this.codedBlkDCTop[comp][mbX] = decoded;
/*     */     
/* 480 */     return decoded;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public int readCodedBlockFlagLumaAC(MDecoder decoder, BlockType blkType, int blkX, int blkY, int comp, MBType left, MBType top, boolean leftAvailable, boolean topAvailable, int leftCBPLuma, int topCBPLuma, int curCBPLuma, MBType cur) {
/* 486 */     int tLeft, tTop, blkOffLeft = blkX & 0x3, blkOffTop = blkY & 0x3;
/*     */ 
/*     */     
/* 489 */     if (blkOffLeft == 0) {
/* 490 */       tLeft = condTerm(cur, leftAvailable, left, (left != null && left != MBType.I_PCM && cbp(leftCBPLuma, 3, blkOffTop)), this.codedBlkLeft[comp][blkOffTop]);
/*     */     } else {
/*     */       
/* 493 */       tLeft = condTerm(cur, true, cur, cbp(curCBPLuma, blkOffLeft - 1, blkOffTop), this.codedBlkLeft[comp][blkOffTop]);
/*     */     } 
/*     */     
/* 496 */     if (blkOffTop == 0) {
/* 497 */       tTop = condTerm(cur, topAvailable, top, (top != null && top != MBType.I_PCM && cbp(topCBPLuma, blkOffLeft, 3)), this.codedBlkTop[comp][blkX]);
/*     */     } else {
/*     */       
/* 500 */       tTop = condTerm(cur, true, cur, cbp(curCBPLuma, blkOffLeft, blkOffTop - 1), this.codedBlkTop[comp][blkX]);
/*     */     } 
/* 502 */     int decoded = decoder.decodeBin(blkType.codedBlockCtxOff + tLeft + 2 * tTop);
/*     */     
/* 504 */     this.codedBlkLeft[comp][blkOffTop] = decoded;
/* 505 */     this.codedBlkTop[comp][blkX] = decoded;
/*     */     
/* 507 */     return decoded;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int readCodedBlockFlagLuma64(MDecoder decoder, int blkX, int blkY, int comp, MBType left, MBType top, boolean leftAvailable, boolean topAvailable, int leftCBPLuma, int topCBPLuma, int curCBPLuma, MBType cur, boolean is8x8Left, boolean is8x8Top) {
/* 514 */     int tLeft, tTop, blkOffLeft = blkX & 0x3, blkOffTop = blkY & 0x3;
/*     */ 
/*     */     
/* 517 */     if (blkOffLeft == 0) {
/* 518 */       tLeft = condTerm(cur, leftAvailable, left, (left != null && left != MBType.I_PCM && is8x8Left && 
/* 519 */           cbp(leftCBPLuma, 3, blkOffTop)), this.codedBlkLeft[comp][blkOffTop]);
/*     */     } else {
/*     */       
/* 522 */       tLeft = condTerm(cur, true, cur, cbp(curCBPLuma, blkOffLeft - 1, blkOffTop), this.codedBlkLeft[comp][blkOffTop]);
/*     */     } 
/*     */     
/* 525 */     if (blkOffTop == 0) {
/* 526 */       tTop = condTerm(cur, topAvailable, top, (top != null && top != MBType.I_PCM && is8x8Top && 
/* 527 */           cbp(topCBPLuma, blkOffLeft, 3)), this.codedBlkTop[comp][blkX]);
/*     */     } else {
/* 529 */       tTop = condTerm(cur, true, cur, cbp(curCBPLuma, blkOffLeft, blkOffTop - 1), this.codedBlkTop[comp][blkX]);
/*     */     } 
/* 531 */     int decoded = decoder.decodeBin(BlockType.LUMA_64.codedBlockCtxOff + tLeft + 2 * tTop);
/*     */     
/* 533 */     this.codedBlkLeft[comp][blkOffTop] = decoded;
/* 534 */     this.codedBlkTop[comp][blkX] = decoded;
/*     */     
/* 536 */     return decoded;
/*     */   }
/*     */   
/*     */   private boolean cbp(int cbpLuma, int blkX, int blkY) {
/* 540 */     int x8x8 = (blkY & 0x2) + (blkX >> 1);
/*     */     
/* 542 */     return ((cbpLuma >> x8x8 & 0x1) == 1);
/*     */   }
/*     */ 
/*     */   
/*     */   public int readCodedBlockFlagChromaAC(MDecoder decoder, int blkX, int blkY, int comp, MBType left, MBType top, boolean leftAvailable, boolean topAvailable, int leftCBPChroma, int topCBPChroma, MBType cur) {
/* 547 */     int tLeft, tTop, blkOffLeft = blkX & 0x1, blkOffTop = blkY & 0x1;
/*     */ 
/*     */     
/* 550 */     if (blkOffLeft == 0) {
/* 551 */       tLeft = condTerm(cur, leftAvailable, left, (left != null && left != MBType.I_PCM && (leftCBPChroma & 0x2) != 0), this.codedBlkLeft[comp][blkOffTop]);
/*     */     } else {
/*     */       
/* 554 */       tLeft = condTerm(cur, true, cur, true, this.codedBlkLeft[comp][blkOffTop]);
/*     */     } 
/* 556 */     if (blkOffTop == 0) {
/* 557 */       tTop = condTerm(cur, topAvailable, top, (top != null && top != MBType.I_PCM && (topCBPChroma & 0x2) != 0), this.codedBlkTop[comp][blkX]);
/*     */     } else {
/*     */       
/* 560 */       tTop = condTerm(cur, true, cur, true, this.codedBlkTop[comp][blkX]);
/*     */     } 
/* 562 */     int decoded = decoder.decodeBin(BlockType.CHROMA_AC.codedBlockCtxOff + tLeft + 2 * tTop);
/*     */     
/* 564 */     this.codedBlkLeft[comp][blkOffTop] = decoded;
/* 565 */     this.codedBlkTop[comp][blkX] = decoded;
/*     */     
/* 567 */     return decoded;
/*     */   }
/*     */   
/*     */   public boolean prev4x4PredModeFlag(MDecoder decoder) {
/* 571 */     return (decoder.decodeBin(68) == 1);
/*     */   }
/*     */   
/*     */   public int rem4x4PredMode(MDecoder decoder) {
/* 575 */     return decoder.decodeBin(69) | decoder.decodeBin(69) << 1 | decoder.decodeBin(69) << 2;
/*     */   }
/*     */ 
/*     */   
/*     */   public int codedBlockPatternIntra(MDecoder mDecoder, boolean leftAvailable, boolean topAvailable, int cbpLeft, int cbpTop, MBType mbLeft, MBType mbTop) {
/* 580 */     int cbp0 = mDecoder.decodeBin(73 + _condTerm(leftAvailable, mbLeft, cbpLeft >> 1 & 0x1) + 2 * 
/* 581 */         _condTerm(topAvailable, mbTop, cbpTop >> 2 & 0x1));
/* 582 */     int cbp1 = mDecoder.decodeBin(73 + 1 - cbp0 + 2 * _condTerm(topAvailable, mbTop, cbpTop >> 3 & 0x1));
/* 583 */     int cbp2 = mDecoder.decodeBin(73 + _condTerm(leftAvailable, mbLeft, cbpLeft >> 3 & 0x1) + 2 * (1 - cbp0));
/* 584 */     int cbp3 = mDecoder.decodeBin(73 + 1 - cbp2 + 2 * (1 - cbp1));
/*     */     
/* 586 */     int cr0 = mDecoder.decodeBin(77 + condTermCr0(leftAvailable, mbLeft, cbpLeft >> 4) + 2 * 
/* 587 */         condTermCr0(topAvailable, mbTop, cbpTop >> 4));
/* 588 */     int cr1 = (cr0 != 0) ? mDecoder.decodeBin(81 + condTermCr1(leftAvailable, mbLeft, cbpLeft >> 4) + 2 * 
/* 589 */         condTermCr1(topAvailable, mbTop, cbpTop >> 4)) : 0;
/*     */     
/* 591 */     return cbp0 | cbp1 << 1 | cbp2 << 2 | cbp3 << 3 | cr0 << 4 | cr1 << 5;
/*     */   }
/*     */   
/*     */   private int condTermCr0(boolean avb, MBType mbt, int cbpChroma) {
/* 595 */     return (avb && (mbt == MBType.I_PCM || (mbt != null && cbpChroma != 0))) ? 1 : 0;
/*     */   }
/*     */   
/*     */   private int condTermCr1(boolean avb, MBType mbt, int cbpChroma) {
/* 599 */     return (avb && (mbt == MBType.I_PCM || (mbt != null && (cbpChroma & 0x2) != 0))) ? 1 : 0;
/*     */   }
/*     */   
/*     */   private int _condTerm(boolean avb, MBType mbt, int cbp) {
/* 603 */     return (!avb || mbt == MBType.I_PCM || (mbt != null && cbp == 1)) ? 0 : 1;
/*     */   }
/*     */   
/*     */   public void setPrevCBP(int prevCBP) {
/* 607 */     this.prevCBP = prevCBP;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public int readMVD(MDecoder decoder, int comp, boolean leftAvailable, boolean topAvailable, MBType leftType, MBType topType, H264Const.PartPred leftPred, H264Const.PartPred topPred, H264Const.PartPred curPred, int mbX, int partX, int partY, int partW, int partH, int list) {
/* 613 */     int ctx = (comp == 0) ? 40 : 47;
/*     */     
/* 615 */     int partAbsX = (mbX << 2) + partX;
/*     */ 
/*     */     
/* 618 */     boolean predEqA = (leftPred != null && leftPred != H264Const.PartPred.Direct && (leftPred == H264Const.PartPred.Bi || leftPred == curPred || (curPred == H264Const.PartPred.Bi && H264Const.usesList(leftPred, list))));
/*     */     
/* 620 */     boolean predEqB = (topPred != null && topPred != H264Const.PartPred.Direct && (topPred == H264Const.PartPred.Bi || topPred == curPred || (curPred == H264Const.PartPred.Bi && H264Const.usesList(topPred, list))));
/*     */ 
/*     */ 
/*     */     
/* 624 */     int absMvdComp = (!leftAvailable || leftType == null || leftType.isIntra() || !predEqA) ? 0 : Math.abs(this.mvdLeft[list][comp][partY]);
/* 625 */     absMvdComp += (!topAvailable || topType == null || topType.isIntra() || !predEqB) ? 0 : 
/* 626 */       Math.abs(this.mvdTop[list][comp][partAbsX]);
/*     */     
/* 628 */     int b = decoder.decodeBin(ctx + ((absMvdComp < 3) ? 0 : ((absMvdComp > 32) ? 2 : 1))); int val;
/* 629 */     for (val = 0; b != 0 && val < 8; val++)
/* 630 */       b = decoder.decodeBin(Math.min(ctx + val + 3, ctx + 6)); 
/* 631 */     val += b;
/*     */     
/* 633 */     if (val != 0) {
/* 634 */       if (val == 9) {
/* 635 */         int log = 2, add = 0, sum = 0, leftover = 0;
/*     */         do {
/* 637 */           sum += leftover;
/* 638 */           log++;
/* 639 */           b = decoder.decodeBinBypass();
/* 640 */           leftover = 1 << log;
/* 641 */         } while (b != 0);
/*     */         
/* 643 */         log--;
/*     */         
/* 645 */         for (; log >= 0; log--) {
/* 646 */           add |= decoder.decodeBinBypass() << log;
/*     */         }
/* 648 */         val += add + sum;
/*     */       } 
/*     */       
/* 651 */       val = MathUtil.toSigned(val, -decoder.decodeBinBypass());
/*     */     } 
/*     */     int i;
/* 654 */     for (i = 0; i < partW; i++) {
/* 655 */       this.mvdTop[list][comp][partAbsX + i] = val;
/*     */     }
/* 657 */     for (i = 0; i < partH; i++) {
/* 658 */       this.mvdLeft[list][comp][partY + i] = val;
/*     */     }
/*     */     
/* 661 */     return val;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public int readRefIdx(MDecoder mDecoder, boolean leftAvailable, boolean topAvailable, MBType leftType, MBType topType, H264Const.PartPred leftPred, H264Const.PartPred topPred, H264Const.PartPred curPred, int mbX, int partX, int partY, int partW, int partH, int list) {
/* 667 */     int val, partAbsX = (mbX << 2) + partX;
/*     */ 
/*     */     
/* 670 */     boolean predEqA = (leftPred != null && leftPred != H264Const.PartPred.Direct && (leftPred == H264Const.PartPred.Bi || leftPred == curPred || (curPred == H264Const.PartPred.Bi && H264Const.usesList(leftPred, list))));
/*     */     
/* 672 */     boolean predEqB = (topPred != null && topPred != H264Const.PartPred.Direct && (topPred == H264Const.PartPred.Bi || topPred == curPred || (curPred == H264Const.PartPred.Bi && H264Const.usesList(topPred, list))));
/*     */     
/* 674 */     int ctA = (!leftAvailable || leftType == null || leftType.isIntra() || !predEqA || this.refIdxLeft[list][partY] == 0) ? 0 : 1;
/*     */     
/* 676 */     int ctB = (!topAvailable || topType == null || topType.isIntra() || !predEqB || this.refIdxTop[list][partAbsX] == 0) ? 0 : 1;
/*     */     
/* 678 */     int b0 = mDecoder.decodeBin(54 + ctA + 2 * ctB);
/*     */     
/* 680 */     if (b0 == 0) {
/* 681 */       val = 0;
/*     */     } else {
/* 683 */       int b1 = mDecoder.decodeBin(58);
/* 684 */       if (b1 == 0) {
/* 685 */         val = 1;
/*     */       } else {
/* 687 */         for (val = 2; mDecoder.decodeBin(59) == 1; val++);
/*     */       } 
/*     */     } 
/*     */     
/*     */     int i;
/* 692 */     for (i = 0; i < partW; i++) {
/* 693 */       this.refIdxTop[list][partAbsX + i] = val;
/*     */     }
/*     */     
/* 696 */     for (i = 0; i < partH; i++) {
/* 697 */       this.refIdxLeft[list][partY + i] = val;
/*     */     }
/*     */     
/* 700 */     return val;
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean readMBSkipFlag(MDecoder mDecoder, SliceType slType, boolean leftAvailable, boolean topAvailable, int mbX) {
/* 705 */     int base = (slType == SliceType.P) ? 11 : 24;
/*     */     
/* 707 */     boolean ret = (mDecoder.decodeBin(base + ((leftAvailable && !this.skipFlagLeft) ? 1 : 0) + ((topAvailable && !this.skipFlagsTop[mbX]) ? 1 : 0)) == 1);
/*     */ 
/*     */     
/* 710 */     this.skipFlagLeft = this.skipFlagsTop[mbX] = ret;
/*     */     
/* 712 */     return ret;
/*     */   }
/*     */   
/*     */   public int readSubMbTypeP(MDecoder mDecoder) {
/* 716 */     if (mDecoder.decodeBin(21) == 1)
/* 717 */       return 0; 
/* 718 */     if (mDecoder.decodeBin(22) == 0)
/* 719 */       return 1; 
/* 720 */     if (mDecoder.decodeBin(23) == 1) {
/* 721 */       return 2;
/*     */     }
/* 723 */     return 3;
/*     */   }
/*     */   
/*     */   public int readSubMbTypeB(MDecoder mDecoder) {
/* 727 */     if (mDecoder.decodeBin(36) == 0)
/* 728 */       return 0; 
/* 729 */     if (mDecoder.decodeBin(37) == 0)
/* 730 */       return 1 + mDecoder.decodeBin(39); 
/* 731 */     if (mDecoder.decodeBin(38) == 0) {
/* 732 */       return 3 + (mDecoder.decodeBin(39) << 1) + mDecoder.decodeBin(39);
/*     */     }
/* 734 */     if (mDecoder.decodeBin(39) == 0) {
/* 735 */       return 7 + (mDecoder.decodeBin(39) << 1) + mDecoder.decodeBin(39);
/*     */     }
/* 737 */     return 11 + mDecoder.decodeBin(39);
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean readTransform8x8Flag(MDecoder mDecoder, boolean leftAvailable, boolean topAvailable, MBType leftType, MBType topType, boolean is8x8Left, boolean is8x8Top) {
/* 742 */     int ctx = 399 + ((leftAvailable && leftType != null && is8x8Left) ? 1 : 0) + ((topAvailable && topType != null && is8x8Top) ? 1 : 0);
/*     */     
/* 744 */     return (mDecoder.decodeBin(ctx) == 1);
/*     */   }
/*     */   
/*     */   public void setCodedBlock(int blkX, int blkY) {
/* 748 */     this.codedBlkTop[0][blkX] = 1; this.codedBlkLeft[0][blkY & 0x3] = 1;
/*     */   }
/*     */ }


/* Location:              C:\Users\rapha\Downloads\aurora.jar!\META-INF\jars\jcodec-0.2.5.jar!\org\jcodec\codecs\h264\io\CABAC.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */