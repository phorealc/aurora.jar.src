/*    */ package org.jcodec.codecs.h264.io.model;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public final class NALUnitType
/*    */ {
/* 13 */   public static final NALUnitType NON_IDR_SLICE = new NALUnitType(1, "NON_IDR_SLICE", "non IDR slice");
/* 14 */   public static final NALUnitType SLICE_PART_A = new NALUnitType(2, "SLICE_PART_A", "slice part a");
/* 15 */   public static final NALUnitType SLICE_PART_B = new NALUnitType(3, "SLICE_PART_B", "slice part b");
/* 16 */   public static final NALUnitType SLICE_PART_C = new NALUnitType(4, "SLICE_PART_C", "slice part c");
/* 17 */   public static final NALUnitType IDR_SLICE = new NALUnitType(5, "IDR_SLICE", "idr slice");
/* 18 */   public static final NALUnitType SEI = new NALUnitType(6, "SEI", "sei");
/* 19 */   public static final NALUnitType SPS = new NALUnitType(7, "SPS", "sequence parameter set");
/* 20 */   public static final NALUnitType PPS = new NALUnitType(8, "PPS", "picture parameter set");
/* 21 */   public static final NALUnitType ACC_UNIT_DELIM = new NALUnitType(9, "ACC_UNIT_DELIM", "access unit delimiter");
/* 22 */   public static final NALUnitType END_OF_SEQ = new NALUnitType(10, "END_OF_SEQ", "end of sequence");
/* 23 */   public static final NALUnitType END_OF_STREAM = new NALUnitType(11, "END_OF_STREAM", "end of stream");
/* 24 */   public static final NALUnitType FILLER_DATA = new NALUnitType(12, "FILLER_DATA", "filler data");
/* 25 */   public static final NALUnitType SEQ_PAR_SET_EXT = new NALUnitType(13, "SEQ_PAR_SET_EXT", "sequence parameter set extension");
/* 26 */   public static final NALUnitType AUX_SLICE = new NALUnitType(19, "AUX_SLICE", "auxilary slice");
/*    */ 
/*    */   
/*    */   private static final NALUnitType[] lut;
/*    */ 
/*    */   
/* 32 */   private static final NALUnitType[] _values = new NALUnitType[] { NON_IDR_SLICE, SLICE_PART_A, SLICE_PART_B, SLICE_PART_C, IDR_SLICE, SEI, SPS, PPS, ACC_UNIT_DELIM, END_OF_SEQ, END_OF_STREAM, FILLER_DATA, SEQ_PAR_SET_EXT, AUX_SLICE };
/*    */   static {
/* 34 */     lut = new NALUnitType[256];
/* 35 */     for (int i = 0; i < _values.length; i++) {
/* 36 */       NALUnitType nalUnitType = _values[i];
/* 37 */       lut[nalUnitType.value] = nalUnitType;
/*    */     } 
/*    */   }
/*    */   
/*    */   private final int value;
/*    */   private final String displayName;
/*    */   private String _name;
/*    */   
/*    */   private NALUnitType(int value, String name, String displayName) {
/* 46 */     this.value = value;
/* 47 */     this._name = name;
/* 48 */     this.displayName = displayName;
/*    */   }
/*    */   
/*    */   public String getName() {
/* 52 */     return this.displayName;
/*    */   }
/*    */   
/*    */   public int getValue() {
/* 56 */     return this.value;
/*    */   }
/*    */   
/*    */   public static NALUnitType fromValue(int value) {
/* 60 */     return (value < lut.length) ? lut[value] : null;
/*    */   }
/*    */ 
/*    */   
/*    */   public String toString() {
/* 65 */     return this._name;
/*    */   }
/*    */ }


/* Location:              C:\Users\rapha\Downloads\aurora.jar!\META-INF\jars\jcodec-0.2.5.jar!\org\jcodec\codecs\h264\io\model\NALUnitType.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */