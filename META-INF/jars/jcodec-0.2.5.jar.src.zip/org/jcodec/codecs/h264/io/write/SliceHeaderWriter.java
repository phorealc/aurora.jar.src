/*     */ package org.jcodec.codecs.h264.io.write;
/*     */ 
/*     */ import org.jcodec.codecs.h264.io.model.PictureParameterSet;
/*     */ import org.jcodec.codecs.h264.io.model.RefPicMarking;
/*     */ import org.jcodec.codecs.h264.io.model.RefPicMarkingIDR;
/*     */ import org.jcodec.codecs.h264.io.model.SeqParameterSet;
/*     */ import org.jcodec.codecs.h264.io.model.SliceHeader;
/*     */ import org.jcodec.codecs.h264.io.model.SliceType;
/*     */ import org.jcodec.common.io.BitWriter;
/*     */ import org.jcodec.common.model.ColorSpace;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class SliceHeaderWriter
/*     */ {
/*     */   public static void write(SliceHeader sliceHeader, boolean idrSlice, int nalRefIdc, BitWriter writer) {
/*  34 */     SeqParameterSet sps = sliceHeader.sps;
/*  35 */     PictureParameterSet pps = sliceHeader.pps;
/*  36 */     CAVLCWriter.writeUEtrace(writer, sliceHeader.firstMbInSlice, "SH: first_mb_in_slice");
/*  37 */     CAVLCWriter.writeUEtrace(writer, sliceHeader.sliceType.ordinal() + (sliceHeader.sliceTypeRestr ? 5 : 0), "SH: slice_type");
/*  38 */     CAVLCWriter.writeUEtrace(writer, sliceHeader.picParameterSetId, "SH: pic_parameter_set_id");
/*  39 */     if (sliceHeader.frameNum > 1 << sps.log2MaxFrameNumMinus4 + 4) {
/*  40 */       throw new IllegalArgumentException("frame_num > " + (1 << sps.log2MaxFrameNumMinus4 + 4));
/*     */     }
/*  42 */     CAVLCWriter.writeUtrace(writer, sliceHeader.frameNum, sps.log2MaxFrameNumMinus4 + 4, "SH: frame_num");
/*  43 */     if (!sps.frameMbsOnlyFlag) {
/*  44 */       CAVLCWriter.writeBool(writer, sliceHeader.fieldPicFlag, "SH: field_pic_flag");
/*  45 */       if (sliceHeader.fieldPicFlag) {
/*  46 */         CAVLCWriter.writeBool(writer, sliceHeader.bottomFieldFlag, "SH: bottom_field_flag");
/*     */       }
/*     */     } 
/*  49 */     if (idrSlice) {
/*  50 */       CAVLCWriter.writeUEtrace(writer, sliceHeader.idrPicId, "SH: idr_pic_id");
/*     */     }
/*  52 */     if (sps.picOrderCntType == 0) {
/*  53 */       if (sliceHeader.picOrderCntLsb > 1 << sps.log2MaxPicOrderCntLsbMinus4 + 4) {
/*  54 */         throw new IllegalArgumentException("pic_order_cnt_lsb > " + (1 << sps.log2MaxPicOrderCntLsbMinus4 + 4));
/*     */       }
/*  56 */       CAVLCWriter.writeU(writer, sliceHeader.picOrderCntLsb, sps.log2MaxPicOrderCntLsbMinus4 + 4);
/*  57 */       if (pps.picOrderPresentFlag && !sps.fieldPicFlag) {
/*  58 */         CAVLCWriter.writeSEtrace(writer, sliceHeader.deltaPicOrderCntBottom, "SH: delta_pic_order_cnt_bottom");
/*     */       }
/*     */     } 
/*  61 */     if (sps.picOrderCntType == 1 && !sps.deltaPicOrderAlwaysZeroFlag) {
/*  62 */       CAVLCWriter.writeSEtrace(writer, sliceHeader.deltaPicOrderCnt[0], "SH: delta_pic_order_cnt");
/*  63 */       if (pps.picOrderPresentFlag && !sps.fieldPicFlag)
/*  64 */         CAVLCWriter.writeSEtrace(writer, sliceHeader.deltaPicOrderCnt[1], "SH: delta_pic_order_cnt"); 
/*     */     } 
/*  66 */     if (pps.redundantPicCntPresentFlag) {
/*  67 */       CAVLCWriter.writeUEtrace(writer, sliceHeader.redundantPicCnt, "SH: redundant_pic_cnt");
/*     */     }
/*  69 */     if (sliceHeader.sliceType == SliceType.B) {
/*  70 */       CAVLCWriter.writeBool(writer, sliceHeader.directSpatialMvPredFlag, "SH: direct_spatial_mv_pred_flag");
/*     */     }
/*  72 */     if (sliceHeader.sliceType == SliceType.P || sliceHeader.sliceType == SliceType.SP || sliceHeader.sliceType == SliceType.B) {
/*     */       
/*  74 */       CAVLCWriter.writeBool(writer, sliceHeader.numRefIdxActiveOverrideFlag, "SH: num_ref_idx_active_override_flag");
/*  75 */       if (sliceHeader.numRefIdxActiveOverrideFlag) {
/*  76 */         CAVLCWriter.writeUEtrace(writer, sliceHeader.numRefIdxActiveMinus1[0], "SH: num_ref_idx_l0_active_minus1");
/*  77 */         if (sliceHeader.sliceType == SliceType.B) {
/*  78 */           CAVLCWriter.writeUEtrace(writer, sliceHeader.numRefIdxActiveMinus1[1], "SH: num_ref_idx_l1_active_minus1");
/*     */         }
/*     */       } 
/*     */     } 
/*  82 */     writeRefPicListReordering(sliceHeader, writer);
/*  83 */     if ((pps.weightedPredFlag && (sliceHeader.sliceType == SliceType.P || sliceHeader.sliceType == SliceType.SP)) || (pps.weightedBipredIdc == 1 && sliceHeader.sliceType == SliceType.B))
/*     */     {
/*  85 */       writePredWeightTable(sliceHeader, writer); } 
/*  86 */     if (nalRefIdc != 0)
/*  87 */       writeDecRefPicMarking(sliceHeader, idrSlice, writer); 
/*  88 */     if (pps.entropyCodingModeFlag && sliceHeader.sliceType.isInter()) {
/*  89 */       CAVLCWriter.writeUEtrace(writer, sliceHeader.cabacInitIdc, "SH: cabac_init_idc");
/*     */     }
/*  91 */     CAVLCWriter.writeSEtrace(writer, sliceHeader.sliceQpDelta, "SH: slice_qp_delta");
/*  92 */     if (sliceHeader.sliceType == SliceType.SP || sliceHeader.sliceType == SliceType.SI) {
/*  93 */       if (sliceHeader.sliceType == SliceType.SP) {
/*  94 */         CAVLCWriter.writeBool(writer, sliceHeader.spForSwitchFlag, "SH: sp_for_switch_flag");
/*     */       }
/*  96 */       CAVLCWriter.writeSEtrace(writer, sliceHeader.sliceQsDelta, "SH: slice_qs_delta");
/*     */     } 
/*  98 */     if (pps.deblockingFilterControlPresentFlag) {
/*  99 */       CAVLCWriter.writeUEtrace(writer, sliceHeader.disableDeblockingFilterIdc, "SH: disable_deblocking_filter_idc");
/* 100 */       if (sliceHeader.disableDeblockingFilterIdc != 1) {
/* 101 */         CAVLCWriter.writeSEtrace(writer, sliceHeader.sliceAlphaC0OffsetDiv2, "SH: slice_alpha_c0_offset_div2");
/* 102 */         CAVLCWriter.writeSEtrace(writer, sliceHeader.sliceBetaOffsetDiv2, "SH: slice_beta_offset_div2");
/*     */       } 
/*     */     } 
/* 105 */     if (pps.numSliceGroupsMinus1 > 0 && pps.sliceGroupMapType >= 3 && pps.sliceGroupMapType <= 5) {
/* 106 */       int len = (sps.picHeightInMapUnitsMinus1 + 1) * (sps.picWidthInMbsMinus1 + 1) / (pps.sliceGroupChangeRateMinus1 + 1);
/*     */       
/* 108 */       if ((sps.picHeightInMapUnitsMinus1 + 1) * (sps.picWidthInMbsMinus1 + 1) % (pps.sliceGroupChangeRateMinus1 + 1) > 0)
/*     */       {
/* 110 */         len++;
/*     */       }
/* 112 */       len = CeilLog2(len + 1);
/* 113 */       CAVLCWriter.writeU(writer, sliceHeader.sliceGroupChangeCycle, len);
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   private static int CeilLog2(int uiVal) {
/* 119 */     int uiTmp = uiVal - 1;
/* 120 */     int uiRet = 0;
/*     */     
/* 122 */     while (uiTmp != 0) {
/* 123 */       uiTmp >>= 1;
/* 124 */       uiRet++;
/*     */     } 
/* 126 */     return uiRet;
/*     */   }
/*     */   
/*     */   private static void writeDecRefPicMarking(SliceHeader sliceHeader, boolean idrSlice, BitWriter writer) {
/* 130 */     if (idrSlice) {
/* 131 */       RefPicMarkingIDR drpmidr = sliceHeader.refPicMarkingIDR;
/* 132 */       CAVLCWriter.writeBool(writer, drpmidr.isDiscardDecodedPics(), "SH: no_output_of_prior_pics_flag");
/* 133 */       CAVLCWriter.writeBool(writer, drpmidr.isUseForlongTerm(), "SH: long_term_reference_flag");
/*     */     } else {
/* 135 */       CAVLCWriter.writeBool(writer, (sliceHeader.refPicMarkingNonIDR != null), "SH: adaptive_ref_pic_marking_mode_flag");
/* 136 */       if (sliceHeader.refPicMarkingNonIDR != null) {
/* 137 */         RefPicMarking drpmidr = sliceHeader.refPicMarkingNonIDR;
/* 138 */         RefPicMarking.Instruction[] instructions = drpmidr.getInstructions();
/* 139 */         for (int i = 0; i < instructions.length; i++) {
/* 140 */           RefPicMarking.Instruction mmop = instructions[i];
/* 141 */           switch (mmop.getType()) {
/*     */             case REMOVE_SHORT:
/* 143 */               CAVLCWriter.writeUEtrace(writer, 1, "SH: memory_management_control_operation");
/* 144 */               CAVLCWriter.writeUEtrace(writer, mmop.getArg1() - 1, "SH: difference_of_pic_nums_minus1");
/*     */               break;
/*     */             case REMOVE_LONG:
/* 147 */               CAVLCWriter.writeUEtrace(writer, 2, "SH: memory_management_control_operation");
/* 148 */               CAVLCWriter.writeUEtrace(writer, mmop.getArg1(), "SH: long_term_pic_num");
/*     */               break;
/*     */             case CONVERT_INTO_LONG:
/* 151 */               CAVLCWriter.writeUEtrace(writer, 3, "SH: memory_management_control_operation");
/* 152 */               CAVLCWriter.writeUEtrace(writer, mmop.getArg1() - 1, "SH: difference_of_pic_nums_minus1");
/* 153 */               CAVLCWriter.writeUEtrace(writer, mmop.getArg2(), "SH: long_term_frame_idx");
/*     */               break;
/*     */             case TRUNK_LONG:
/* 156 */               CAVLCWriter.writeUEtrace(writer, 4, "SH: memory_management_control_operation");
/* 157 */               CAVLCWriter.writeUEtrace(writer, mmop.getArg1() + 1, "SH: max_long_term_frame_idx_plus1");
/*     */               break;
/*     */             case CLEAR:
/* 160 */               CAVLCWriter.writeUEtrace(writer, 5, "SH: memory_management_control_operation");
/*     */               break;
/*     */             case MARK_LONG:
/* 163 */               CAVLCWriter.writeUEtrace(writer, 6, "SH: memory_management_control_operation");
/* 164 */               CAVLCWriter.writeUEtrace(writer, mmop.getArg1(), "SH: long_term_frame_idx");
/*     */               break;
/*     */           } 
/*     */         } 
/* 168 */         CAVLCWriter.writeUEtrace(writer, 0, "SH: memory_management_control_operation");
/*     */       } 
/*     */     } 
/*     */   }
/*     */   
/*     */   private static void writePredWeightTable(SliceHeader sliceHeader, BitWriter writer) {
/* 174 */     SeqParameterSet sps = sliceHeader.sps;
/* 175 */     CAVLCWriter.writeUEtrace(writer, sliceHeader.predWeightTable.lumaLog2WeightDenom, "SH: luma_log2_weight_denom");
/* 176 */     if (sps.chromaFormatIdc != ColorSpace.MONO) {
/* 177 */       CAVLCWriter.writeUEtrace(writer, sliceHeader.predWeightTable.chromaLog2WeightDenom, "SH: chroma_log2_weight_denom");
/*     */     }
/*     */     
/* 180 */     writeOffsetWeight(sliceHeader, writer, 0);
/* 181 */     if (sliceHeader.sliceType == SliceType.B) {
/* 182 */       writeOffsetWeight(sliceHeader, writer, 1);
/*     */     }
/*     */   }
/*     */   
/*     */   private static void writeOffsetWeight(SliceHeader sliceHeader, BitWriter writer, int list) {
/* 187 */     SeqParameterSet sps = sliceHeader.sps;
/* 188 */     int defaultLW = 1 << sliceHeader.predWeightTable.lumaLog2WeightDenom;
/* 189 */     int defaultCW = 1 << sliceHeader.predWeightTable.chromaLog2WeightDenom;
/*     */     
/* 191 */     for (int i = 0; i < (sliceHeader.predWeightTable.lumaWeight[list]).length; i++) {
/* 192 */       boolean flagLuma = (sliceHeader.predWeightTable.lumaWeight[list][i] != defaultLW || sliceHeader.predWeightTable.lumaOffset[list][i] != 0);
/*     */       
/* 194 */       CAVLCWriter.writeBool(writer, flagLuma, "SH: luma_weight_l0_flag");
/* 195 */       if (flagLuma) {
/* 196 */         CAVLCWriter.writeSEtrace(writer, sliceHeader.predWeightTable.lumaWeight[list][i], "SH: luma_weight_l" + list);
/* 197 */         CAVLCWriter.writeSEtrace(writer, sliceHeader.predWeightTable.lumaOffset[list][i], "SH: luma_offset_l" + list);
/*     */       } 
/* 199 */       if (sps.chromaFormatIdc != ColorSpace.MONO) {
/* 200 */         boolean flagChroma = (sliceHeader.predWeightTable.chromaWeight[list][0][i] != defaultCW || sliceHeader.predWeightTable.chromaOffset[list][0][i] != 0 || sliceHeader.predWeightTable.chromaWeight[list][1][i] != defaultCW || sliceHeader.predWeightTable.chromaOffset[list][1][i] != 0);
/*     */ 
/*     */ 
/*     */         
/* 204 */         CAVLCWriter.writeBool(writer, flagChroma, "SH: chroma_weight_l0_flag");
/* 205 */         if (flagChroma)
/* 206 */           for (int j = 0; j < 2; j++) {
/* 207 */             CAVLCWriter.writeSEtrace(writer, sliceHeader.predWeightTable.chromaWeight[list][j][i], "SH: chroma_weight_l" + list);
/* 208 */             CAVLCWriter.writeSEtrace(writer, sliceHeader.predWeightTable.chromaOffset[list][j][i], "SH: chroma_offset_l" + list);
/*     */           }  
/*     */       } 
/*     */     } 
/*     */   }
/*     */   
/*     */   private static void writeRefPicListReordering(SliceHeader sliceHeader, BitWriter writer) {
/* 215 */     if (sliceHeader.sliceType.isInter()) {
/* 216 */       boolean l0ReorderingPresent = (sliceHeader.refPicReordering != null && sliceHeader.refPicReordering[0] != null);
/*     */       
/* 218 */       CAVLCWriter.writeBool(writer, l0ReorderingPresent, "SH: ref_pic_list_reordering_flag_l0");
/* 219 */       if (l0ReorderingPresent)
/* 220 */         writeReorderingList(sliceHeader.refPicReordering[0], writer); 
/*     */     } 
/* 222 */     if (sliceHeader.sliceType == SliceType.B) {
/* 223 */       boolean l1ReorderingPresent = (sliceHeader.refPicReordering != null && sliceHeader.refPicReordering[1] != null);
/*     */       
/* 225 */       CAVLCWriter.writeBool(writer, l1ReorderingPresent, "SH: ref_pic_list_reordering_flag_l1");
/* 226 */       if (l1ReorderingPresent)
/* 227 */         writeReorderingList(sliceHeader.refPicReordering[1], writer); 
/*     */     } 
/*     */   }
/*     */   
/*     */   private static void writeReorderingList(int[][] reordering, BitWriter writer) {
/* 232 */     if (reordering == null) {
/*     */       return;
/*     */     }
/* 235 */     for (int i = 0; i < (reordering[0]).length; i++) {
/* 236 */       CAVLCWriter.writeUEtrace(writer, reordering[0][i], "SH: reordering_of_pic_nums_idc");
/* 237 */       CAVLCWriter.writeUEtrace(writer, reordering[1][i], "SH: abs_diff_pic_num_minus1");
/*     */     } 
/* 239 */     CAVLCWriter.writeUEtrace(writer, 3, "SH: reordering_of_pic_nums_idc");
/*     */   }
/*     */ }


/* Location:              C:\Users\rapha\Downloads\aurora.jar!\META-INF\jars\jcodec-0.2.5.jar!\org\jcodec\codecs\h264\io\write\SliceHeaderWriter.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */