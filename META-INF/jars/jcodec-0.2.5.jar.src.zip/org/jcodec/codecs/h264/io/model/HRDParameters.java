package org.jcodec.codecs.h264.io.model;

public class HRDParameters {
  public int cpbCntMinus1;
  
  public int bitRateScale;
  
  public int cpbSizeScale;
  
  public int[] bitRateValueMinus1;
  
  public int[] cpbSizeValueMinus1;
  
  public boolean[] cbrFlag;
  
  public int initialCpbRemovalDelayLengthMinus1;
  
  public int cpbRemovalDelayLengthMinus1;
  
  public int dpbOutputDelayLengthMinus1;
  
  public int timeOffsetLength;
}


/* Location:              C:\Users\rapha\Downloads\aurora.jar!\META-INF\jars\jcodec-0.2.5.jar!\org\jcodec\codecs\h264\io\model\HRDParameters.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */