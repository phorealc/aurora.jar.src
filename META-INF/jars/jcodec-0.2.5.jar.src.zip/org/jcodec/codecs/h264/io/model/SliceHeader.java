/*     */ package org.jcodec.codecs.h264.io.model;
/*     */ 
/*     */ import org.jcodec.platform.Platform;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class SliceHeader
/*     */ {
/*     */   public SeqParameterSet sps;
/*     */   public PictureParameterSet pps;
/*     */   public RefPicMarking refPicMarkingNonIDR;
/*     */   public RefPicMarkingIDR refPicMarkingIDR;
/*     */   public int[][][] refPicReordering;
/*     */   public PredictionWeightTable predWeightTable;
/*     */   public int firstMbInSlice;
/*     */   public boolean fieldPicFlag;
/*     */   public SliceType sliceType;
/*     */   public boolean sliceTypeRestr;
/*     */   public int picParameterSetId;
/*     */   public int frameNum;
/*     */   public boolean bottomFieldFlag;
/*     */   public int idrPicId;
/*     */   public int picOrderCntLsb;
/*     */   public int deltaPicOrderCntBottom;
/*     */   public int[] deltaPicOrderCnt;
/*     */   public int redundantPicCnt;
/*     */   public boolean directSpatialMvPredFlag;
/*     */   public boolean numRefIdxActiveOverrideFlag;
/*  98 */   public int[] numRefIdxActiveMinus1 = new int[2];
/*     */   public int cabacInitIdc;
/*     */   public int sliceQpDelta;
/*     */   
/*     */   public String toString() {
/* 103 */     return Platform.toJSON(this);
/*     */   }
/*     */   
/*     */   public boolean spForSwitchFlag;
/*     */   public int sliceQsDelta;
/*     */   public int disableDeblockingFilterIdc;
/*     */   public int sliceAlphaC0OffsetDiv2;
/*     */   public int sliceBetaOffsetDiv2;
/*     */   public int sliceGroupChangeCycle;
/*     */ }


/* Location:              C:\Users\rapha\Downloads\aurora.jar!\META-INF\jars\jcodec-0.2.5.jar!\org\jcodec\codecs\h264\io\model\SliceHeader.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */