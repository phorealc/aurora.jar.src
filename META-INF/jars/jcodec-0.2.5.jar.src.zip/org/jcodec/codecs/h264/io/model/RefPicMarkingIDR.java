/*    */ package org.jcodec.codecs.h264.io.model;
/*    */ 
/*    */ import org.jcodec.platform.Platform;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class RefPicMarkingIDR
/*    */ {
/*    */   boolean discardDecodedPics;
/*    */   boolean useForlongTerm;
/*    */   
/*    */   public RefPicMarkingIDR(boolean discardDecodedPics, boolean useForlongTerm) {
/* 20 */     this.discardDecodedPics = discardDecodedPics;
/* 21 */     this.useForlongTerm = useForlongTerm;
/*    */   }
/*    */   
/*    */   public boolean isDiscardDecodedPics() {
/* 25 */     return this.discardDecodedPics;
/*    */   }
/*    */   
/*    */   public boolean isUseForlongTerm() {
/* 29 */     return this.useForlongTerm;
/*    */   }
/*    */ 
/*    */   
/*    */   public String toString() {
/* 34 */     return Platform.toJSON(this);
/*    */   }
/*    */ }


/* Location:              C:\Users\rapha\Downloads\aurora.jar!\META-INF\jars\jcodec-0.2.5.jar!\org\jcodec\codecs\h264\io\model\RefPicMarkingIDR.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */