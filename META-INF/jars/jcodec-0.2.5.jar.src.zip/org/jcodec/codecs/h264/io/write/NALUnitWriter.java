/*    */ package org.jcodec.codecs.h264.io.write;
/*    */ 
/*    */ import java.io.IOException;
/*    */ import java.nio.ByteBuffer;
/*    */ import java.nio.channels.WritableByteChannel;
/*    */ import org.jcodec.codecs.h264.io.model.NALUnit;
/*    */ import org.jcodec.common.io.NIOUtils;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class NALUnitWriter
/*    */ {
/*    */   private final WritableByteChannel to;
/* 18 */   private static ByteBuffer _MARKER = ByteBuffer.allocate(4);
/*    */   
/*    */   static {
/* 21 */     _MARKER.putInt(1);
/* 22 */     _MARKER.flip();
/*    */   }
/*    */   
/*    */   public NALUnitWriter(WritableByteChannel to) {
/* 26 */     this.to = to;
/*    */   }
/*    */   
/*    */   public void writeUnit(NALUnit nal, ByteBuffer data) throws IOException {
/* 30 */     ByteBuffer emprev = ByteBuffer.allocate(data.remaining() + 1024);
/* 31 */     NIOUtils.write(emprev, _MARKER);
/* 32 */     nal.write(emprev);
/* 33 */     emprev(emprev, data);
/* 34 */     emprev.flip();
/* 35 */     this.to.write(emprev);
/*    */   }
/*    */   
/*    */   private void emprev(ByteBuffer emprev, ByteBuffer data) {
/* 39 */     ByteBuffer dd = data.duplicate();
/* 40 */     int prev1 = 1, prev2 = 1;
/* 41 */     while (dd.hasRemaining()) {
/* 42 */       byte b = dd.get();
/* 43 */       if (prev1 == 0 && prev2 == 0 && (b & 0x3) == b) {
/* 44 */         prev2 = prev1;
/* 45 */         prev1 = 3;
/* 46 */         emprev.put((byte)3);
/*    */       } 
/*    */       
/* 49 */       prev2 = prev1;
/* 50 */       prev1 = b;
/* 51 */       emprev.put(b);
/*    */     } 
/*    */   }
/*    */ }


/* Location:              C:\Users\rapha\Downloads\aurora.jar!\META-INF\jars\jcodec-0.2.5.jar!\org\jcodec\codecs\h264\io\write\NALUnitWriter.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */