/*    */ package org.jcodec.codecs.h264.io.model;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class AspectRatio
/*    */ {
/* 16 */   public static final AspectRatio Extended_SAR = new AspectRatio(255);
/*    */   
/*    */   private int value;
/*    */   
/*    */   private AspectRatio(int value) {
/* 21 */     this.value = value;
/*    */   }
/*    */   
/*    */   public static AspectRatio fromValue(int value) {
/* 25 */     if (value == Extended_SAR.value) {
/* 26 */       return Extended_SAR;
/*    */     }
/* 28 */     return new AspectRatio(value);
/*    */   }
/*    */   
/*    */   public int getValue() {
/* 32 */     return this.value;
/*    */   }
/*    */ }


/* Location:              C:\Users\rapha\Downloads\aurora.jar!\META-INF\jars\jcodec-0.2.5.jar!\org\jcodec\codecs\h264\io\model\AspectRatio.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */