package org.jcodec.codecs.h264.encode;

import org.jcodec.codecs.h264.io.model.SliceType;
import org.jcodec.common.model.Size;

public interface RateControl {
  int startPicture(Size paramSize, int paramInt, SliceType paramSliceType);
  
  int initialQpDelta();
  
  int accept(int paramInt);
}


/* Location:              C:\Users\rapha\Downloads\aurora.jar!\META-INF\jars\jcodec-0.2.5.jar!\org\jcodec\codecs\h264\encode\RateControl.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */