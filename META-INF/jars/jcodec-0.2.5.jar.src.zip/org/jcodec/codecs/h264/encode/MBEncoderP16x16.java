/*     */ package org.jcodec.codecs.h264.encode;
/*     */ 
/*     */ import java.util.Arrays;
/*     */ import org.jcodec.codecs.h264.H264Const;
/*     */ import org.jcodec.codecs.h264.decode.BlockInterpolator;
/*     */ import org.jcodec.codecs.h264.decode.CoeffTransformer;
/*     */ import org.jcodec.codecs.h264.io.CAVLC;
/*     */ import org.jcodec.codecs.h264.io.model.MBType;
/*     */ import org.jcodec.codecs.h264.io.model.SeqParameterSet;
/*     */ import org.jcodec.codecs.h264.io.write.CAVLCWriter;
/*     */ import org.jcodec.common.SaveRestore;
/*     */ import org.jcodec.common.io.BitWriter;
/*     */ import org.jcodec.common.model.Picture;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class MBEncoderP16x16
/*     */   implements SaveRestore
/*     */ {
/*     */   private CAVLC[] cavlc;
/*     */   private SeqParameterSet sps;
/*     */   private Picture ref;
/*     */   private MotionEstimator me;
/*     */   private int[] mvTopX;
/*     */   private int[] mvTopY;
/*     */   private int mvLeftX;
/*     */   private int mvLeftY;
/*     */   private int mvTopLeftX;
/*     */   private int mvTopLeftY;
/*     */   private int[] mvTopXSave;
/*     */   private int[] mvTopYSave;
/*     */   private int mvLeftXSave;
/*     */   private int mvLeftYSave;
/*     */   private int mvTopLeftXSave;
/*     */   private int mvTopLeftYSave;
/*     */   private BlockInterpolator interpolator;
/*     */   
/*     */   public MBEncoderP16x16(SeqParameterSet sps, Picture ref, CAVLC[] cavlc, MotionEstimator me) {
/*  53 */     this.sps = sps;
/*  54 */     this.cavlc = cavlc;
/*  55 */     this.ref = ref;
/*  56 */     this.me = me;
/*  57 */     this.mvTopX = new int[sps.picWidthInMbsMinus1 + 1];
/*  58 */     this.mvTopY = new int[sps.picWidthInMbsMinus1 + 1];
/*     */     
/*  60 */     this.mvTopXSave = new int[sps.picWidthInMbsMinus1 + 1];
/*  61 */     this.mvTopYSave = new int[sps.picWidthInMbsMinus1 + 1];
/*  62 */     this.interpolator = new BlockInterpolator();
/*     */   }
/*     */ 
/*     */   
/*     */   public void save() {
/*  67 */     for (int i = 0; i < this.cavlc.length; i++)
/*  68 */       this.cavlc[i].save(); 
/*  69 */     System.arraycopy(this.mvTopX, 0, this.mvTopXSave, 0, this.mvTopX.length);
/*  70 */     System.arraycopy(this.mvTopY, 0, this.mvTopYSave, 0, this.mvTopY.length);
/*     */     
/*  72 */     this.mvLeftXSave = this.mvLeftX;
/*  73 */     this.mvLeftYSave = this.mvLeftY;
/*  74 */     this.mvTopLeftXSave = this.mvTopLeftX;
/*  75 */     this.mvTopLeftYSave = this.mvTopLeftY;
/*     */   }
/*     */ 
/*     */   
/*     */   public void restore() {
/*  80 */     for (int i = 0; i < this.cavlc.length; i++)
/*  81 */       this.cavlc[i].restore(); 
/*  82 */     int[] tmp = this.mvTopX;
/*  83 */     this.mvTopX = this.mvTopXSave;
/*  84 */     this.mvTopXSave = tmp;
/*     */     
/*  86 */     tmp = this.mvTopY;
/*  87 */     this.mvTopY = this.mvTopYSave;
/*  88 */     this.mvTopYSave = tmp;
/*     */     
/*  90 */     this.mvLeftX = this.mvLeftXSave;
/*  91 */     this.mvLeftY = this.mvLeftYSave;
/*  92 */     this.mvTopLeftX = this.mvTopLeftXSave;
/*  93 */     this.mvTopLeftY = this.mvTopLeftYSave;
/*     */   }
/*     */ 
/*     */   
/*     */   public void encodeMacroblock(Picture pic, int mbX, int mbY, BitWriter out, EncodedMB outMB, EncodedMB leftOutMB, EncodedMB topOutMB, int qp, int qpDelta) {
/*  98 */     if (this.sps.numRefFrames > 1) {
/*  99 */       int refIdx = decideRef();
/* 100 */       CAVLCWriter.writeTE(out, refIdx, this.sps.numRefFrames - 1);
/*     */     } 
/*     */     
/* 103 */     boolean trAvb = (mbY > 0 && mbX < this.sps.picWidthInMbsMinus1);
/* 104 */     boolean tlAvb = (mbX > 0 && mbY > 0);
/* 105 */     int mvpx = median(this.mvLeftX, this.mvTopX[mbX], trAvb ? this.mvTopX[mbX + 1] : 0, tlAvb ? this.mvTopLeftX : 0, (mbX > 0), (mbY > 0), trAvb, tlAvb);
/*     */     
/* 107 */     int mvpy = median(this.mvLeftY, this.mvTopY[mbX], trAvb ? this.mvTopY[mbX + 1] : 0, tlAvb ? this.mvTopLeftY : 0, (mbX > 0), (mbY > 0), trAvb, tlAvb);
/*     */ 
/*     */ 
/*     */     
/* 111 */     int[] mv = mvEstimate(pic, mbX, mbY, mvpx, mvpy);
/* 112 */     this.mvTopLeftX = this.mvTopX[mbX];
/* 113 */     this.mvTopLeftY = this.mvTopY[mbX];
/* 114 */     this.mvTopX[mbX] = mv[0];
/* 115 */     this.mvTopY[mbX] = mv[1];
/* 116 */     this.mvLeftX = mv[0];
/* 117 */     this.mvLeftY = mv[1];
/* 118 */     CAVLCWriter.writeSE(out, mv[0] - mvpx);
/* 119 */     CAVLCWriter.writeSE(out, mv[1] - mvpy);
/*     */     
/* 121 */     Picture mbRef = Picture.create(16, 16, this.sps.chromaFormatIdc);
/* 122 */     int[][] mb = { new int[256], new int[64], new int[64] };
/*     */     
/* 124 */     this.interpolator.getBlockLuma(this.ref, mbRef, 0, (mbX << 6) + mv[0], (mbY << 6) + mv[1], 16, 16);
/*     */     
/* 126 */     BlockInterpolator.getBlockChroma(this.ref.getPlaneData(1), this.ref.getPlaneWidth(1), this.ref.getPlaneHeight(1), mbRef
/* 127 */         .getPlaneData(1), 0, mbRef.getPlaneWidth(1), (mbX << 6) + mv[0], (mbY << 6) + mv[1], 8, 8);
/* 128 */     BlockInterpolator.getBlockChroma(this.ref.getPlaneData(2), this.ref.getPlaneWidth(2), this.ref.getPlaneHeight(2), mbRef
/* 129 */         .getPlaneData(2), 0, mbRef.getPlaneWidth(2), (mbX << 6) + mv[0], (mbY << 6) + mv[1], 8, 8);
/*     */     
/* 131 */     MBEncoderHelper.takeSubtract(pic.getPlaneData(0), pic.getPlaneWidth(0), pic.getPlaneHeight(0), mbX << 4, mbY << 4, mb[0], mbRef
/* 132 */         .getPlaneData(0), 16, 16);
/* 133 */     MBEncoderHelper.takeSubtract(pic.getPlaneData(1), pic.getPlaneWidth(1), pic.getPlaneHeight(1), mbX << 3, mbY << 3, mb[1], mbRef
/* 134 */         .getPlaneData(1), 8, 8);
/* 135 */     MBEncoderHelper.takeSubtract(pic.getPlaneData(2), pic.getPlaneWidth(2), pic.getPlaneHeight(2), mbX << 3, mbY << 3, mb[2], mbRef
/* 136 */         .getPlaneData(2), 8, 8);
/*     */     
/* 138 */     int codedBlockPattern = getCodedBlockPattern();
/* 139 */     CAVLCWriter.writeUE(out, H264Const.CODED_BLOCK_PATTERN_INTER_COLOR_INV[codedBlockPattern]);
/*     */     
/* 141 */     CAVLCWriter.writeSE(out, qpDelta);
/*     */     
/* 143 */     luma(pic, mb[0], mbX, mbY, out, qp, outMB.getNc());
/* 144 */     chroma(pic, mb[1], mb[2], mbX, mbY, out, qp);
/*     */     
/* 146 */     MBEncoderHelper.putBlk(outMB.getPixels().getPlaneData(0), mb[0], mbRef.getPlaneData(0), 4, 0, 0, 16, 16);
/* 147 */     MBEncoderHelper.putBlk(outMB.getPixels().getPlaneData(1), mb[1], mbRef.getPlaneData(1), 3, 0, 0, 8, 8);
/* 148 */     MBEncoderHelper.putBlk(outMB.getPixels().getPlaneData(2), mb[2], mbRef.getPlaneData(2), 3, 0, 0, 8, 8);
/*     */     
/* 150 */     Arrays.fill(outMB.getMx(), mv[0]);
/* 151 */     Arrays.fill(outMB.getMy(), mv[1]);
/* 152 */     outMB.setType(MBType.P_16x16);
/* 153 */     outMB.setQp(qp);
/*     */     
/* 155 */     (new MBDeblocker()).deblockMBP(outMB, leftOutMB, topOutMB);
/*     */   }
/*     */ 
/*     */   
/*     */   public int median(int a, int b, int c, int d, boolean aAvb, boolean bAvb, boolean cAvb, boolean dAvb) {
/* 160 */     if (!cAvb) {
/* 161 */       c = d;
/* 162 */       cAvb = dAvb;
/*     */     } 
/*     */     
/* 165 */     if (aAvb && !bAvb && !cAvb) {
/* 166 */       b = c = a;
/* 167 */       bAvb = cAvb = aAvb;
/*     */     } 
/*     */     
/* 170 */     a = aAvb ? a : 0;
/* 171 */     b = bAvb ? b : 0;
/* 172 */     c = cAvb ? c : 0;
/*     */     
/* 174 */     return a + b + c - Math.min(Math.min(a, b), c) - Math.max(Math.max(a, b), c);
/*     */   }
/*     */   
/*     */   private int getCodedBlockPattern() {
/* 178 */     return 47;
/*     */   }
/*     */   
/*     */   private int[] mvEstimate(Picture pic, int mbX, int mbY, int mvpx, int mvpy) {
/* 182 */     byte[] patch = new byte[256];
/* 183 */     MBEncoderHelper.take(pic.getPlaneData(0), pic.getPlaneWidth(0), pic.getPlaneHeight(0), mbX << 4, mbY << 4, patch, 16, 16);
/*     */     
/* 185 */     return this.me.estimate(this.ref, patch, mbX, mbY, mvpx, mvpy);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private int decideRef() {
/* 194 */     return 0;
/*     */   }
/*     */   
/*     */   private void luma(Picture pic, int[] pix, int mbX, int mbY, BitWriter out, int qp, int[] nc) {
/* 198 */     int[][] ac = new int[16][16]; int i;
/* 199 */     for (i = 0; i < ac.length; i++) {
/* 200 */       for (int j = 0; j < (H264Const.PIX_MAP_SPLIT_4x4[i]).length; j++) {
/* 201 */         ac[i][j] = pix[H264Const.PIX_MAP_SPLIT_4x4[i][j]];
/*     */       }
/* 203 */       CoeffTransformer.fdct4x4(ac[i]);
/*     */     } 
/*     */     
/* 206 */     writeAC(0, mbX, mbY, out, mbX << 2, mbY << 2, ac, qp);
/*     */     
/* 208 */     for (i = 0; i < ac.length; i++) {
/* 209 */       CoeffTransformer.dequantizeAC(ac[i], qp, null);
/* 210 */       CoeffTransformer.idct4x4(ac[i]);
/* 211 */       for (int j = 0; j < (H264Const.PIX_MAP_SPLIT_4x4[i]).length; j++)
/* 212 */         pix[H264Const.PIX_MAP_SPLIT_4x4[i][j]] = ac[i][j]; 
/*     */     } 
/*     */   }
/*     */   
/*     */   private void chroma(Picture pic, int[] pix1, int[] pix2, int mbX, int mbY, BitWriter out, int qp) {
/* 217 */     int[][] ac1 = new int[4][16];
/* 218 */     int[][] ac2 = new int[4][16]; int i;
/* 219 */     for (i = 0; i < ac1.length; i++) {
/* 220 */       for (int j = 0; j < (H264Const.PIX_MAP_SPLIT_2x2[i]).length; j++)
/* 221 */         ac1[i][j] = pix1[H264Const.PIX_MAP_SPLIT_2x2[i][j]]; 
/*     */     } 
/* 223 */     for (i = 0; i < ac2.length; i++) {
/* 224 */       for (int j = 0; j < (H264Const.PIX_MAP_SPLIT_2x2[i]).length; j++)
/* 225 */         ac2[i][j] = pix2[H264Const.PIX_MAP_SPLIT_2x2[i][j]]; 
/*     */     } 
/* 227 */     MBEncoderI16x16.chromaResidual(pic, mbX, mbY, out, qp, ac1, ac2, this.cavlc[1], this.cavlc[2], MBType.P_16x16, MBType.P_16x16);
/*     */     
/* 229 */     for (i = 0; i < ac1.length; i++) {
/* 230 */       for (int j = 0; j < (H264Const.PIX_MAP_SPLIT_2x2[i]).length; j++)
/* 231 */         pix1[H264Const.PIX_MAP_SPLIT_2x2[i][j]] = ac1[i][j]; 
/*     */     } 
/* 233 */     for (i = 0; i < ac2.length; i++) {
/* 234 */       for (int j = 0; j < (H264Const.PIX_MAP_SPLIT_2x2[i]).length; j++)
/* 235 */         pix2[H264Const.PIX_MAP_SPLIT_2x2[i][j]] = ac2[i][j]; 
/*     */     } 
/*     */   }
/*     */   
/*     */   private void writeAC(int comp, int mbX, int mbY, BitWriter out, int mbLeftBlk, int mbTopBlk, int[][] ac, int qp) {
/* 240 */     for (int i = 0; i < ac.length; i++) {
/* 241 */       int blkI = H264Const.BLK_INV_MAP[i];
/* 242 */       CoeffTransformer.quantizeAC(ac[blkI], qp);
/* 243 */       this.cavlc[comp].writeACBlock(out, mbLeftBlk + H264Const.MB_BLK_OFF_LEFT[i], mbTopBlk + H264Const.MB_BLK_OFF_TOP[i], MBType.P_16x16, MBType.P_16x16, ac[blkI], H264Const.totalZeros16, 0, 16, CoeffTransformer.zigzag4x4);
/*     */     } 
/*     */   }
/*     */ }


/* Location:              C:\Users\rapha\Downloads\aurora.jar!\META-INF\jars\jcodec-0.2.5.jar!\org\jcodec\codecs\h264\encode\MBEncoderP16x16.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */