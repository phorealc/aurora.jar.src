/*    */ package org.jcodec.codecs.h264.encode;
/*    */ 
/*    */ import org.jcodec.codecs.h264.io.model.MBType;
/*    */ import org.jcodec.common.model.ColorSpace;
/*    */ import org.jcodec.common.model.Picture;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class EncodedMB
/*    */ {
/* 22 */   private Picture pixels = Picture.create(16, 16, ColorSpace.YUV420J); private MBType type;
/* 23 */   private int[] nc = new int[16]; private int qp;
/* 24 */   private int[] mx = new int[16];
/* 25 */   private int[] my = new int[16];
/*    */ 
/*    */   
/*    */   public Picture getPixels() {
/* 29 */     return this.pixels;
/*    */   }
/*    */   
/*    */   public MBType getType() {
/* 33 */     return this.type;
/*    */   }
/*    */   
/*    */   public void setType(MBType type) {
/* 37 */     this.type = type;
/*    */   }
/*    */   
/*    */   public int getQp() {
/* 41 */     return this.qp;
/*    */   }
/*    */   
/*    */   public void setQp(int qp) {
/* 45 */     this.qp = qp;
/*    */   }
/*    */   
/*    */   public int[] getNc() {
/* 49 */     return this.nc;
/*    */   }
/*    */   
/*    */   public int[] getMx() {
/* 53 */     return this.mx;
/*    */   }
/*    */   
/*    */   public int[] getMy() {
/* 57 */     return this.my;
/*    */   }
/*    */ }


/* Location:              C:\Users\rapha\Downloads\aurora.jar!\META-INF\jars\jcodec-0.2.5.jar!\org\jcodec\codecs\h264\encode\EncodedMB.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */