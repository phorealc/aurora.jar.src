/*    */ package org.jcodec.codecs.h264.encode;
/*    */ 
/*    */ import org.jcodec.codecs.h264.io.model.SliceType;
/*    */ import org.jcodec.common.model.Size;
/*    */ import org.jcodec.common.tools.MathUtil;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class H264FixedRateControl
/*    */   implements RateControl
/*    */ {
/*    */   private static final int INIT_QP = 26;
/*    */   private int balance;
/*    */   private int perMb;
/*    */   private int curQp;
/*    */   
/*    */   public H264FixedRateControl(int bitsPer256) {
/* 23 */     this.perMb = bitsPer256;
/* 24 */     this.curQp = 26;
/*    */   }
/*    */ 
/*    */   
/*    */   public int startPicture(Size sz, int maxSize, SliceType sliceType) {
/* 29 */     return 26 + ((sliceType == SliceType.P) ? 4 : 0);
/*    */   }
/*    */ 
/*    */   
/*    */   public int initialQpDelta() {
/* 34 */     int qpDelta = (this.balance < 0) ? ((this.balance < -(this.perMb >> 1)) ? 2 : 1) : ((this.balance > this.perMb) ? ((this.balance > this.perMb << 2) ? -2 : -1) : 0);
/*    */     
/* 36 */     int prevQp = this.curQp;
/* 37 */     this.curQp = MathUtil.clip(this.curQp + qpDelta, 12, 30);
/*    */     
/* 39 */     return this.curQp - prevQp;
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public int accept(int bits) {
/* 45 */     this.balance += this.perMb - bits;
/*    */     
/* 47 */     return 0;
/*    */   }
/*    */   
/*    */   public void reset() {
/* 51 */     this.balance = 0;
/* 52 */     this.curQp = 26;
/*    */   }
/*    */   
/*    */   public int calcFrameSize(int nMB) {
/* 56 */     return (256 + nMB * (this.perMb + 9) >> 3) + (nMB >> 6);
/*    */   }
/*    */   
/*    */   public void setRate(int rate) {
/* 60 */     this.perMb = rate;
/*    */   }
/*    */ }


/* Location:              C:\Users\rapha\Downloads\aurora.jar!\META-INF\jars\jcodec-0.2.5.jar!\org\jcodec\codecs\h264\encode\H264FixedRateControl.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */