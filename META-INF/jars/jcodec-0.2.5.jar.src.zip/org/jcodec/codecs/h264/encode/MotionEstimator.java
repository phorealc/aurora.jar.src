/*    */ package org.jcodec.codecs.h264.encode;
/*    */ 
/*    */ import org.jcodec.common.model.Picture;
/*    */ import org.jcodec.common.tools.MathUtil;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class MotionEstimator
/*    */ {
/*    */   private int maxSearchRange;
/*    */   
/*    */   public MotionEstimator(int maxSearchRange) {
/* 20 */     this.maxSearchRange = maxSearchRange;
/*    */   }
/*    */   
/*    */   public int[] estimate(Picture ref, byte[] patch, int mbX, int mbY, int mvpx, int mvpy) {
/* 24 */     byte[] searchPatch = new byte[(this.maxSearchRange * 2 + 16) * (this.maxSearchRange * 2 + 16)];
/*    */     
/* 26 */     int startX = mbX << 4;
/* 27 */     int startY = mbY << 4;
/*    */     
/* 29 */     int patchTlX = Math.max(startX - this.maxSearchRange, 0);
/* 30 */     int patchTlY = Math.max(startY - this.maxSearchRange, 0);
/* 31 */     int patchBrX = Math.min(startX + this.maxSearchRange + 16, ref.getPlaneWidth(0));
/* 32 */     int patchBrY = Math.min(startY + this.maxSearchRange + 16, ref.getPlaneHeight(0));
/*    */     
/* 34 */     int centerX = startX - patchTlX;
/* 35 */     int centerY = startY - patchTlY;
/*    */     
/* 37 */     int patchW = patchBrX - patchTlX;
/* 38 */     int patchH = patchBrY - patchTlY;
/* 39 */     MBEncoderHelper.takeSafe(ref.getPlaneData(0), ref.getPlaneWidth(0), ref.getPlaneHeight(0), patchTlX, patchTlY, searchPatch, patchW, patchH);
/*    */ 
/*    */     
/* 42 */     int bestMvX = centerX, bestMvY = centerY;
/* 43 */     int bestScore = sad(searchPatch, patchW, patch, bestMvX, bestMvY);
/*    */     
/* 45 */     for (int i = 0; i < this.maxSearchRange; i++) {
/* 46 */       int score1 = (bestMvX > 0) ? sad(searchPatch, patchW, patch, bestMvX - 1, bestMvY) : Integer.MAX_VALUE;
/* 47 */       int score2 = (bestMvX < patchW - 1) ? sad(searchPatch, patchW, patch, bestMvX + 1, bestMvY) : Integer.MAX_VALUE;
/* 48 */       int score3 = (bestMvY > 0) ? sad(searchPatch, patchW, patch, bestMvX, bestMvY - 1) : Integer.MAX_VALUE;
/* 49 */       int score4 = (bestMvY < patchH - 1) ? sad(searchPatch, patchW, patch, bestMvX, bestMvY + 1) : Integer.MAX_VALUE;
/* 50 */       int min = Math.min(Math.min(Math.min(score1, score2), score3), score4);
/* 51 */       if (min > bestScore)
/*    */         break; 
/* 53 */       bestScore = min;
/* 54 */       if (score1 == min) {
/* 55 */         bestMvX--;
/* 56 */       } else if (score2 == min) {
/* 57 */         bestMvX++;
/* 58 */       } else if (score3 == min) {
/* 59 */         bestMvY--;
/*    */       } else {
/* 61 */         bestMvY++;
/*    */       } 
/*    */     } 
/*    */     
/* 65 */     return new int[] { bestMvX - centerX << 2, bestMvY - centerY << 2 };
/*    */   }
/*    */   
/*    */   private int sad(byte[] big, int bigStride, byte[] small, int offX, int offY) {
/* 69 */     int score = 0, bigOff = offY * bigStride + offX, smallOff = 0;
/* 70 */     for (int i = 0; i < 16; i++) {
/* 71 */       for (int j = 0; j < 16; j++, bigOff++, smallOff++) {
/* 72 */         score += MathUtil.abs(big[bigOff] - small[smallOff]);
/*    */       }
/* 74 */       bigOff += bigStride - 16;
/*    */     } 
/* 76 */     return score;
/*    */   }
/*    */ }


/* Location:              C:\Users\rapha\Downloads\aurora.jar!\META-INF\jars\jcodec-0.2.5.jar!\org\jcodec\codecs\h264\encode\MotionEstimator.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */