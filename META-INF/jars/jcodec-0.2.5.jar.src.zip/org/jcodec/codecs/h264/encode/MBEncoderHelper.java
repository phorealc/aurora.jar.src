/*     */ package org.jcodec.codecs.h264.encode;
/*     */ 
/*     */ import org.jcodec.common.model.Picture;
/*     */ import org.jcodec.common.tools.MathUtil;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class MBEncoderHelper
/*     */ {
/*     */   public static final void takeSubtract(byte[] planeData, int planeWidth, int planeHeight, int x, int y, int[] coeff, byte[] pred, int blkW, int blkH) {
/*  17 */     if (x + blkW < planeWidth && y + blkH < planeHeight) {
/*  18 */       takeSubtractSafe(planeData, planeWidth, planeHeight, x, y, coeff, pred, blkW, blkH);
/*     */     } else {
/*  20 */       takeSubtractUnsafe(planeData, planeWidth, planeHeight, x, y, coeff, pred, blkW, blkH);
/*     */     } 
/*     */   }
/*     */   
/*     */   public static final void takeSubtractSafe(byte[] planeData, int planeWidth, int planeHeight, int x, int y, int[] coeff, byte[] pred, int blkW, int blkH) {
/*     */     int srcOff;
/*  26 */     for (int i = 0, dstOff = 0; i < blkH; i++, srcOff += planeWidth) {
/*  27 */       for (int j = 0, srcOff1 = srcOff; j < blkW; j += 4, dstOff += 4, srcOff1 += 4) {
/*  28 */         coeff[dstOff] = planeData[srcOff1] - pred[dstOff];
/*  29 */         coeff[dstOff + 1] = planeData[srcOff1 + 1] - pred[dstOff + 1];
/*  30 */         coeff[dstOff + 2] = planeData[srcOff1 + 2] - pred[dstOff + 2];
/*  31 */         coeff[dstOff + 3] = planeData[srcOff1 + 3] - pred[dstOff + 3];
/*     */       } 
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public static final void take(byte[] planeData, int planeWidth, int planeHeight, int x, int y, byte[] patch, int blkW, int blkH) {
/*  38 */     if (x + blkW < planeWidth && y + blkH < planeHeight) {
/*  39 */       takeSafe(planeData, planeWidth, planeHeight, x, y, patch, blkW, blkH);
/*     */     } else {
/*  41 */       takeExtendBorder(planeData, planeWidth, planeHeight, x, y, patch, blkW, blkH);
/*     */     } 
/*     */   }
/*     */   
/*     */   public static final void takeSafe(byte[] planeData, int planeWidth, int planeHeight, int x, int y, byte[] patch, int blkW, int blkH) {
/*     */     int srcOff;
/*  47 */     for (int i = 0, dstOff = 0; i < blkH; i++, srcOff += planeWidth) {
/*  48 */       for (int j = 0, srcOff1 = srcOff; j < blkW; j++, dstOff++, srcOff1++) {
/*  49 */         patch[dstOff] = planeData[srcOff1];
/*     */       }
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public static final void takeExtendBorder(byte[] planeData, int planeWidth, int planeHeight, int x, int y, byte[] patch, int blkW, int blkH) {
/*  56 */     int outOff = 0;
/*     */     
/*     */     int i;
/*  59 */     for (i = y; i < Math.min(y + blkH, planeHeight); i++) {
/*  60 */       int off = i * planeWidth + Math.min(x, planeWidth);
/*     */       int j;
/*  62 */       for (j = x; j < Math.min(x + blkW, planeWidth); j++, outOff++, off++) {
/*  63 */         patch[outOff] = planeData[off];
/*     */       }
/*  65 */       off--;
/*  66 */       for (; j < x + blkW; j++, outOff++) {
/*  67 */         patch[outOff] = planeData[off];
/*     */       }
/*     */     } 
/*  70 */     for (; i < y + blkH; i++) {
/*  71 */       int off = planeHeight * planeWidth - planeWidth + Math.min(x, planeWidth);
/*     */       int j;
/*  73 */       for (j = x; j < Math.min(x + blkW, planeWidth); j++, outOff++, off++) {
/*  74 */         patch[outOff] = planeData[off];
/*     */       }
/*  76 */       off--;
/*  77 */       for (; j < x + blkW; j++, outOff++) {
/*  78 */         patch[outOff] = planeData[off];
/*     */       }
/*     */     } 
/*     */   }
/*     */   
/*     */   public static final void takeSafe2(byte[] planeData, int planeWidth, int planeHeight, int x, int y, int[] coeff, int blkW, int blkH) {
/*     */     int srcOff;
/*  85 */     for (int i = 0, dstOff = 0; i < blkH; i++, srcOff += planeWidth) {
/*  86 */       for (int j = 0, srcOff1 = srcOff; j < blkW; j++, dstOff++, srcOff1++) {
/*  87 */         coeff[dstOff] = planeData[srcOff1];
/*     */       }
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public static final void takeSubtractUnsafe(byte[] planeData, int planeWidth, int planeHeight, int x, int y, int[] coeff, byte[] pred, int blkW, int blkH) {
/*  94 */     int outOff = 0;
/*     */     
/*     */     int i;
/*  97 */     for (i = y; i < Math.min(y + blkH, planeHeight); i++) {
/*  98 */       int off = i * planeWidth + Math.min(x, planeWidth);
/*     */       int j;
/* 100 */       for (j = x; j < Math.min(x + blkW, planeWidth); j++, outOff++, off++) {
/* 101 */         coeff[outOff] = planeData[off] - pred[outOff];
/*     */       }
/* 103 */       off--;
/* 104 */       for (; j < x + blkW; j++, outOff++) {
/* 105 */         coeff[outOff] = planeData[off] - pred[outOff];
/*     */       }
/*     */     } 
/* 108 */     for (; i < y + blkH; i++) {
/* 109 */       int off = planeHeight * planeWidth - planeWidth + Math.min(x, planeWidth);
/*     */       int j;
/* 111 */       for (j = x; j < Math.min(x + blkW, planeWidth); j++, outOff++, off++) {
/* 112 */         coeff[outOff] = planeData[off] - pred[outOff];
/*     */       }
/* 114 */       off--;
/* 115 */       for (; j < x + blkW; j++, outOff++) {
/* 116 */         coeff[outOff] = planeData[off] - pred[outOff];
/*     */       }
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public static final void putBlk(byte[] planeData, int[] block, byte[] pred, int log2stride, int blkX, int blkY, int blkW, int blkH) {
/* 123 */     int stride = 1 << log2stride;
/* 124 */     for (int line = 0, srcOff = 0, dstOff = (blkY << log2stride) + blkX; line < blkH; line++) {
/* 125 */       int dstOff1 = dstOff;
/* 126 */       for (int row = 0; row < blkW; row += 4) {
/* 127 */         planeData[dstOff1] = (byte)MathUtil.clip(block[srcOff] + pred[srcOff], -128, 127);
/* 128 */         planeData[dstOff1 + 1] = (byte)MathUtil.clip(block[srcOff + 1] + pred[srcOff + 1], -128, 127);
/* 129 */         planeData[dstOff1 + 2] = (byte)MathUtil.clip(block[srcOff + 2] + pred[srcOff + 2], -128, 127);
/* 130 */         planeData[dstOff1 + 3] = (byte)MathUtil.clip(block[srcOff + 3] + pred[srcOff + 3], -128, 127);
/* 131 */         srcOff += 4;
/* 132 */         dstOff1 += 4;
/*     */       } 
/* 134 */       dstOff += stride;
/*     */     } 
/*     */   }
/*     */   
/*     */   public static final void putBlkPic(Picture dest, Picture src, int x, int y) {
/* 139 */     if (dest.getColor() != src.getColor())
/* 140 */       throw new RuntimeException("Incompatible color"); 
/* 141 */     for (int c = 0; c < (dest.getColor()).nComp; c++) {
/* 142 */       pubBlkOnePlane(dest.getPlaneData(c), dest.getPlaneWidth(c), src.getPlaneData(c), src.getPlaneWidth(c), src
/* 143 */           .getPlaneHeight(c), x >> (dest.getColor()).compWidth[c], y >> (dest.getColor()).compHeight[c]);
/*     */     }
/*     */   }
/*     */   
/*     */   private static void pubBlkOnePlane(byte[] dest, int destWidth, byte[] src, int srcWidth, int srcHeight, int x, int y) {
/* 148 */     int destOff = y * destWidth + x;
/* 149 */     int srcOff = 0;
/* 150 */     for (int i = 0; i < srcHeight; i++) {
/* 151 */       for (int j = 0; j < srcWidth; j++, destOff++, srcOff++)
/* 152 */         dest[destOff] = src[srcOff]; 
/* 153 */       destOff += destWidth - srcWidth;
/*     */     } 
/*     */   }
/*     */ }


/* Location:              C:\Users\rapha\Downloads\aurora.jar!\META-INF\jars\jcodec-0.2.5.jar!\org\jcodec\codecs\h264\encode\MBEncoderHelper.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */