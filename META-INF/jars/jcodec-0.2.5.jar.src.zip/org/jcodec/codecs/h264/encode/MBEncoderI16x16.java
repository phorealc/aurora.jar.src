/*     */ package org.jcodec.codecs.h264.encode;
/*     */ 
/*     */ import org.jcodec.codecs.h264.H264Const;
/*     */ import org.jcodec.codecs.h264.decode.CoeffTransformer;
/*     */ import org.jcodec.codecs.h264.io.CAVLC;
/*     */ import org.jcodec.codecs.h264.io.model.MBType;
/*     */ import org.jcodec.codecs.h264.io.write.CAVLCWriter;
/*     */ import org.jcodec.common.ArrayUtil;
/*     */ import org.jcodec.common.SaveRestore;
/*     */ import org.jcodec.common.io.BitWriter;
/*     */ import org.jcodec.common.model.Picture;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class MBEncoderI16x16
/*     */   implements SaveRestore
/*     */ {
/*     */   private CAVLC[] cavlc;
/*     */   private byte[][] leftRow;
/*     */   private byte[][] topLine;
/*     */   
/*     */   public MBEncoderI16x16(CAVLC[] cavlc, byte[][] leftRow, byte[][] topLine) {
/*  36 */     this.cavlc = cavlc;
/*  37 */     this.leftRow = leftRow;
/*  38 */     this.topLine = topLine;
/*     */   }
/*     */ 
/*     */   
/*     */   public void save() {
/*  43 */     for (int i = 0; i < this.cavlc.length; i++) {
/*  44 */       this.cavlc[i].save();
/*     */     }
/*     */   }
/*     */   
/*     */   public void restore() {
/*  49 */     for (int i = 0; i < this.cavlc.length; i++) {
/*  50 */       this.cavlc[i].restore();
/*     */     }
/*     */   }
/*     */   
/*     */   public void encodeMacroblock(Picture pic, int mbX, int mbY, BitWriter out, EncodedMB outMB, EncodedMB leftOutMB, EncodedMB topOutMB, int qp, int qpDelta) {
/*  55 */     CAVLCWriter.writeUE(out, 0);
/*  56 */     CAVLCWriter.writeSE(out, qpDelta);
/*     */     
/*  58 */     outMB.setType(MBType.I_16x16);
/*  59 */     outMB.setQp(qp);
/*     */     
/*  61 */     luma(pic, mbX, mbY, out, qp, outMB.getPixels(), this.cavlc[0]);
/*  62 */     chroma(pic, mbX, mbY, out, qp, outMB.getPixels());
/*     */     
/*  64 */     (new MBDeblocker()).deblockMBI(outMB, leftOutMB, topOutMB);
/*     */   }
/*     */   
/*  67 */   private static int[] DUMMY = new int[16];
/*     */   
/*     */   private void chroma(Picture pic, int mbX, int mbY, BitWriter out, int qp, Picture outMB) {
/*  70 */     int x = mbX << 3;
/*  71 */     int y = mbY << 3;
/*  72 */     int[][] ac1 = new int[4][16];
/*  73 */     int[][] ac2 = new int[4][16];
/*  74 */     byte[][] pred1 = new byte[4][16];
/*  75 */     byte[][] pred2 = new byte[4][16];
/*     */     
/*  77 */     predictChroma(pic, ac1, pred1, 1, x, y);
/*  78 */     predictChroma(pic, ac2, pred2, 2, x, y);
/*     */     
/*  80 */     chromaResidual(pic, mbX, mbY, out, qp, ac1, ac2, this.cavlc[1], this.cavlc[2], MBType.I_16x16, MBType.I_16x16);
/*     */     
/*  82 */     putChroma(outMB.getData()[1], 1, x, y, ac1, pred1);
/*  83 */     putChroma(outMB.getData()[2], 2, x, y, ac2, pred2);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public static void chromaResidual(Picture pic, int mbX, int mbY, BitWriter out, int qp, int[][] ac1, int[][] ac2, CAVLC cavlc1, CAVLC cavlc2, MBType leftMBType, MBType topMBType) {
/*  89 */     transformChroma(ac1);
/*  90 */     transformChroma(ac2);
/*     */     
/*  92 */     int[] dc1 = extractDC(ac1);
/*  93 */     int[] dc2 = extractDC(ac2);
/*     */     
/*  95 */     writeDC(cavlc1, mbX, mbY, out, qp, mbX << 1, mbY << 1, dc1, leftMBType, topMBType);
/*  96 */     writeDC(cavlc2, mbX, mbY, out, qp, mbX << 1, mbY << 1, dc2, leftMBType, topMBType);
/*     */     
/*  98 */     writeAC(cavlc1, mbX, mbY, out, mbX << 1, mbY << 1, ac1, qp, leftMBType, topMBType, DUMMY);
/*  99 */     writeAC(cavlc2, mbX, mbY, out, mbX << 1, mbY << 1, ac2, qp, leftMBType, topMBType, DUMMY);
/*     */     
/* 101 */     restorePlane(dc1, ac1, qp);
/* 102 */     restorePlane(dc2, ac2, qp);
/*     */   }
/*     */   
/*     */   private void luma(Picture pic, int mbX, int mbY, BitWriter out, int qp, Picture outMB, CAVLC cavlc) {
/* 106 */     int x = mbX << 4;
/* 107 */     int y = mbY << 4;
/* 108 */     int[][] ac = new int[16][16];
/* 109 */     byte[][] pred = new byte[16][16];
/*     */     
/* 111 */     lumaDCPred(x, y, pred);
/* 112 */     transform(pic, 0, ac, pred, x, y);
/* 113 */     int[] dc = extractDC(ac);
/* 114 */     writeDC(cavlc, mbX, mbY, out, qp, mbX << 2, mbY << 2, dc, MBType.I_16x16, MBType.I_16x16);
/* 115 */     writeAC(cavlc, mbX, mbY, out, mbX << 2, mbY << 2, ac, qp, MBType.I_16x16, MBType.I_16x16, DUMMY);
/*     */     
/* 117 */     restorePlane(dc, ac, qp);
/*     */     
/* 119 */     for (int blk = 0; blk < ac.length; blk++) {
/* 120 */       MBEncoderHelper.putBlk(outMB.getPlaneData(0), ac[blk], pred[blk], 4, H264Const.BLK_X[blk], H264Const.BLK_Y[blk], 4, 4);
/*     */     }
/*     */   }
/*     */   
/*     */   private void putChroma(byte[] mb, int comp, int x, int y, int[][] ac, byte[][] pred) {
/* 125 */     MBEncoderHelper.putBlk(mb, ac[0], pred[0], 3, 0, 0, 4, 4);
/*     */     
/* 127 */     MBEncoderHelper.putBlk(mb, ac[1], pred[1], 3, 4, 0, 4, 4);
/*     */     
/* 129 */     MBEncoderHelper.putBlk(mb, ac[2], pred[2], 3, 0, 4, 4, 4);
/*     */     
/* 131 */     MBEncoderHelper.putBlk(mb, ac[3], pred[3], 3, 4, 4, 4, 4);
/*     */   }
/*     */   
/*     */   private static void restorePlane(int[] dc, int[][] ac, int qp) {
/* 135 */     if (dc.length == 4) {
/* 136 */       CoeffTransformer.invDC2x2(dc);
/* 137 */       CoeffTransformer.dequantizeDC2x2(dc, qp, null);
/* 138 */     } else if (dc.length == 8) {
/* 139 */       CoeffTransformer.invDC4x2(dc);
/* 140 */       CoeffTransformer.dequantizeDC4x2(dc, qp);
/*     */     } else {
/* 142 */       CoeffTransformer.invDC4x4(dc);
/* 143 */       CoeffTransformer.dequantizeDC4x4(dc, qp, null);
/* 144 */       CoeffTransformer.reorderDC4x4(dc);
/*     */     } 
/* 146 */     for (int i = 0; i < ac.length; i++) {
/* 147 */       CoeffTransformer.dequantizeAC(ac[i], qp, null);
/* 148 */       ac[i][0] = dc[i];
/* 149 */       CoeffTransformer.idct4x4(ac[i]);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private static int[] extractDC(int[][] ac) {
/* 156 */     int[] dc = new int[ac.length];
/* 157 */     for (int i = 0; i < ac.length; i++) {
/* 158 */       dc[i] = ac[i][0];
/* 159 */       ac[i][0] = 0;
/*     */     } 
/* 161 */     return dc;
/*     */   }
/*     */ 
/*     */   
/*     */   private static void writeAC(CAVLC cavlc, int mbX, int mbY, BitWriter out, int mbLeftBlk, int mbTopBlk, int[][] ac, int qp, MBType leftMBType, MBType topMBType, int[] nc) {
/* 166 */     for (int i = 0; i < ac.length; i++) {
/* 167 */       CoeffTransformer.quantizeAC(ac[i], qp);
/* 168 */       nc[H264Const.BLK_INV_MAP[i]] = CAVLC.totalCoeff(cavlc.writeACBlock(out, mbLeftBlk + H264Const.MB_BLK_OFF_LEFT[i], mbTopBlk + H264Const.MB_BLK_OFF_TOP[i], leftMBType, topMBType, ac[i], H264Const.totalZeros16, 1, 15, CoeffTransformer.zigzag4x4));
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static void writeDC(CAVLC cavlc, int mbX, int mbY, BitWriter out, int qp, int mbLeftBlk, int mbTopBlk, int[] dc, MBType leftMBType, MBType topMBType) {
/* 176 */     if (dc.length == 4) {
/* 177 */       CoeffTransformer.quantizeDC2x2(dc, qp);
/* 178 */       CoeffTransformer.fvdDC2x2(dc);
/* 179 */       cavlc.writeChrDCBlock(out, dc, H264Const.totalZeros4, 0, dc.length, new int[] { 0, 1, 2, 3 });
/* 180 */     } else if (dc.length == 8) {
/* 181 */       CoeffTransformer.quantizeDC4x2(dc, qp);
/* 182 */       CoeffTransformer.fvdDC4x2(dc);
/* 183 */       cavlc.writeChrDCBlock(out, dc, H264Const.totalZeros8, 0, dc.length, new int[] { 0, 1, 2, 3, 4, 5, 6, 7 });
/*     */     } else {
/* 185 */       CoeffTransformer.reorderDC4x4(dc);
/* 186 */       CoeffTransformer.quantizeDC4x4(dc, qp);
/* 187 */       CoeffTransformer.fvdDC4x4(dc);
/*     */       
/* 189 */       cavlc.writeLumaDCBlock(out, mbLeftBlk, mbTopBlk, leftMBType, topMBType, dc, H264Const.totalZeros16, 0, 16, CoeffTransformer.zigzag4x4);
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   private static void transformChroma(int[][] ac) {
/* 195 */     for (int i = 0; i < 4; i++)
/*     */     {
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 203 */       CoeffTransformer.fdct4x4(ac[i]);
/*     */     }
/*     */   }
/*     */   
/*     */   private void predictChroma(Picture pic, int[][] ac, byte[][] pred, int comp, int x, int y) {
/* 208 */     chromaPredBlk0(comp, x, y, pred[0]);
/* 209 */     chromaPredBlk1(comp, x, y, pred[1]);
/* 210 */     chromaPredBlk2(comp, x, y, pred[2]);
/* 211 */     chromaPredBlk3(comp, x, y, pred[3]);
/*     */     
/* 213 */     MBEncoderHelper.takeSubtract(pic.getPlaneData(comp), pic.getPlaneWidth(comp), pic.getPlaneHeight(comp), x, y, ac[0], pred[0], 4, 4);
/*     */ 
/*     */     
/* 216 */     MBEncoderHelper.takeSubtract(pic.getPlaneData(comp), pic.getPlaneWidth(comp), pic.getPlaneHeight(comp), x + 4, y, ac[1], pred[1], 4, 4);
/*     */ 
/*     */     
/* 219 */     MBEncoderHelper.takeSubtract(pic.getPlaneData(comp), pic.getPlaneWidth(comp), pic.getPlaneHeight(comp), x, y + 4, ac[2], pred[2], 4, 4);
/*     */ 
/*     */     
/* 222 */     MBEncoderHelper.takeSubtract(pic.getPlaneData(comp), pic.getPlaneWidth(comp), pic.getPlaneHeight(comp), x + 4, y + 4, ac[3], pred[3], 4, 4);
/*     */   }
/*     */ 
/*     */   
/*     */   private final int chromaPredOne(byte[] pix, int x) {
/* 227 */     return pix[x] + pix[x + 1] + pix[x + 2] + pix[x + 3] + 2 >> 2;
/*     */   }
/*     */   
/*     */   private final int chromaPredTwo(byte[] pix1, byte[] pix2, int x, int y) {
/* 231 */     return pix1[x] + pix1[x + 1] + pix1[x + 2] + pix1[x + 3] + pix2[y] + pix2[y + 1] + pix2[y + 2] + pix2[y + 3] + 4 >> 3;
/*     */   }
/*     */   
/*     */   private void chromaPredBlk0(int comp, int x, int y, byte[] pred) {
/* 235 */     int dc, predY = y & 0x7;
/* 236 */     if (x != 0 && y != 0) {
/* 237 */       dc = chromaPredTwo(this.leftRow[comp], this.topLine[comp], predY, x);
/* 238 */     } else if (x != 0) {
/* 239 */       dc = chromaPredOne(this.leftRow[comp], predY);
/* 240 */     } else if (y != 0) {
/* 241 */       dc = chromaPredOne(this.topLine[comp], x);
/*     */     } else {
/* 243 */       dc = 0;
/* 244 */     }  for (int i = 0; i < pred.length; i++)
/* 245 */       pred[i] = (byte)(pred[i] + dc); 
/*     */   }
/*     */   
/*     */   private void chromaPredBlk1(int comp, int x, int y, byte[] pred) {
/* 249 */     int dc, predY = y & 0x7;
/* 250 */     if (y != 0) {
/* 251 */       dc = chromaPredOne(this.topLine[comp], x + 4);
/* 252 */     } else if (x != 0) {
/* 253 */       dc = chromaPredOne(this.leftRow[comp], predY);
/*     */     } else {
/* 255 */       dc = 0;
/* 256 */     }  for (int i = 0; i < pred.length; i++)
/* 257 */       pred[i] = (byte)(pred[i] + dc); 
/*     */   }
/*     */   
/*     */   private void chromaPredBlk2(int comp, int x, int y, byte[] pred) {
/* 261 */     int dc, predY = y & 0x7;
/* 262 */     if (x != 0) {
/* 263 */       dc = chromaPredOne(this.leftRow[comp], predY + 4);
/* 264 */     } else if (y != 0) {
/* 265 */       dc = chromaPredOne(this.topLine[comp], x);
/*     */     } else {
/* 267 */       dc = 0;
/* 268 */     }  for (int i = 0; i < pred.length; i++)
/* 269 */       pred[i] = (byte)(pred[i] + dc); 
/*     */   }
/*     */   
/*     */   private void chromaPredBlk3(int comp, int x, int y, byte[] pred) {
/* 273 */     int dc, predY = y & 0x7;
/* 274 */     if (x != 0 && y != 0) {
/* 275 */       dc = chromaPredTwo(this.leftRow[comp], this.topLine[comp], predY + 4, x + 4);
/* 276 */     } else if (x != 0) {
/* 277 */       dc = chromaPredOne(this.leftRow[comp], predY + 4);
/* 278 */     } else if (y != 0) {
/* 279 */       dc = chromaPredOne(this.topLine[comp], x + 4);
/*     */     } else {
/* 281 */       dc = 0;
/* 282 */     }  for (int i = 0; i < pred.length; i++)
/* 283 */       pred[i] = (byte)(pred[i] + dc); 
/*     */   }
/*     */   
/*     */   private void lumaDCPred(int x, int y, byte[][] pred) {
/*     */     int dc;
/* 288 */     if (x == 0 && y == 0) {
/* 289 */       dc = 0;
/* 290 */     } else if (y == 0) {
/* 291 */       dc = ArrayUtil.sumByte(this.leftRow[0]) + 8 >> 4;
/* 292 */     } else if (x == 0) {
/* 293 */       dc = ArrayUtil.sumByte3(this.topLine[0], x, 16) + 8 >> 4;
/*     */     } else {
/* 295 */       dc = ArrayUtil.sumByte(this.leftRow[0]) + ArrayUtil.sumByte3(this.topLine[0], x, 16) + 16 >> 5;
/*     */     } 
/* 297 */     for (int i = 0; i < pred.length; i++) {
/* 298 */       for (int j = 0; j < (pred[i]).length; j++)
/* 299 */         pred[i][j] = (byte)(pred[i][j] + dc); 
/*     */     } 
/*     */   }
/*     */   private void transform(Picture pic, int comp, int[][] ac, byte[][] pred, int x, int y) {
/* 303 */     for (int i = 0; i < ac.length; i++) {
/* 304 */       int[] coeff = ac[i];
/* 305 */       MBEncoderHelper.takeSubtract(pic.getPlaneData(comp), pic.getPlaneWidth(comp), pic.getPlaneHeight(comp), x + H264Const.BLK_X[i], y + H264Const.BLK_Y[i], coeff, pred[i], 4, 4);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 314 */       CoeffTransformer.fdct4x4(coeff);
/*     */     } 
/*     */   }
/*     */   
/*     */   public int getPredMode(Picture pic, int mbX, int mbY) {
/* 319 */     return 2;
/*     */   }
/*     */   
/*     */   public int getCbpChroma(Picture pic, int mbX, int mbY) {
/* 323 */     return 2;
/*     */   }
/*     */   
/*     */   public int getCbpLuma(Picture pic, int mbX, int mbY) {
/* 327 */     return 15;
/*     */   }
/*     */ }


/* Location:              C:\Users\rapha\Downloads\aurora.jar!\META-INF\jars\jcodec-0.2.5.jar!\org\jcodec\codecs\h264\encode\MBEncoderI16x16.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */