/*     */ package org.jcodec.codecs.h264.encode;
/*     */ 
/*     */ import org.jcodec.codecs.h264.decode.deblock.DeblockingFilter;
/*     */ import org.jcodec.common.model.Picture;
/*     */ import org.jcodec.common.tools.MathUtil;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class MBDeblocker
/*     */ {
/*  21 */   static int[][] LOOKUP_IDX_P_V = new int[][] { { 3, 7, 11, 15 }, { 0, 4, 8, 12 }, { 1, 5, 9, 13 }, { 2, 6, 10, 14 } };
/*  22 */   static int[][] LOOKUP_IDX_Q_V = new int[][] { { 0, 4, 8, 12 }, { 1, 5, 9, 13 }, { 2, 6, 10, 14 }, { 3, 7, 11, 15 } };
/*  23 */   static int[][] LOOKUP_IDX_P_H = new int[][] { { 12, 13, 14, 15 }, { 0, 1, 2, 3 }, { 4, 5, 6, 7 }, { 8, 9, 10, 11 } };
/*  24 */   static int[][] LOOKUP_IDX_Q_H = new int[][] { { 0, 1, 2, 3 }, { 4, 5, 6, 7 }, { 8, 9, 10, 11 }, { 12, 13, 14, 15 } };
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  31 */   private static int[][] BS_I = new int[][] { { 4, 4, 4, 4 }, { 3, 3, 3, 3 }, { 3, 3, 3, 3 }, { 3, 3, 3, 3 } };
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void deblockMBGeneric(EncodedMB curMB, EncodedMB leftMB, EncodedMB topMB, int[][] vertStrength, int[][] horizStrength) {
/*  58 */     Picture curPix = curMB.getPixels();
/*  59 */     if (leftMB != null) {
/*  60 */       Picture leftPix = leftMB.getPixels();
/*  61 */       int avgQp = MathUtil.clip(leftMB.getQp() + curMB.getQp() + 1 >> 1, 0, 51);
/*  62 */       deblockBorder(vertStrength[0], avgQp, leftPix.getPlaneData(0), 3, curPix.getPlaneData(0), 0, P_POS_V, Q_POS_V, false);
/*     */       
/*  64 */       deblockBorderChroma(vertStrength[0], avgQp, leftPix.getPlaneData(1), 3, curPix.getPlaneData(1), 0, P_POS_V_CHR, Q_POS_V_CHR, false);
/*     */       
/*  66 */       deblockBorderChroma(vertStrength[0], avgQp, leftPix.getPlaneData(2), 3, curPix.getPlaneData(2), 0, P_POS_V_CHR, Q_POS_V_CHR, false);
/*     */     } 
/*     */     int i;
/*  69 */     for (i = 0; i < 3; i++) {
/*  70 */       deblockBorder(vertStrength[i + 1], curMB.getQp(), curPix.getPlaneData(0), i, curPix.getPlaneData(0), i + 1, P_POS_V, Q_POS_V, false);
/*     */       
/*  72 */       deblockBorderChroma(vertStrength[i + 1], curMB.getQp(), curPix.getPlaneData(1), i, curPix.getPlaneData(1), i + 1, P_POS_V_CHR, Q_POS_V_CHR, false);
/*     */       
/*  74 */       deblockBorderChroma(vertStrength[i + 1], curMB.getQp(), curPix.getPlaneData(2), i, curPix.getPlaneData(2), i + 1, P_POS_V_CHR, Q_POS_V_CHR, false);
/*     */     } 
/*     */ 
/*     */     
/*  78 */     if (topMB != null) {
/*  79 */       Picture topPix = topMB.getPixels();
/*  80 */       int avgQp = MathUtil.clip(topMB.getQp() + curMB.getQp() + 1 >> 1, 0, 51);
/*  81 */       deblockBorder(horizStrength[0], avgQp, topPix.getPlaneData(0), 3, curPix.getPlaneData(0), 0, P_POS_H, Q_POS_H, true);
/*     */       
/*  83 */       deblockBorderChroma(horizStrength[0], avgQp, topPix.getPlaneData(1), 3, curPix.getPlaneData(1), 0, P_POS_H_CHR, Q_POS_H_CHR, true);
/*     */       
/*  85 */       deblockBorderChroma(horizStrength[0], avgQp, topPix.getPlaneData(2), 3, curPix.getPlaneData(2), 0, P_POS_H_CHR, Q_POS_H_CHR, true);
/*     */     } 
/*     */     
/*  88 */     for (i = 0; i < 3; i++) {
/*  89 */       deblockBorder(horizStrength[i + 1], curMB.getQp(), curPix.getPlaneData(0), i, curPix.getPlaneData(0), i + 1, P_POS_H, Q_POS_H, true);
/*     */       
/*  91 */       deblockBorderChroma(horizStrength[i + 1], curMB.getQp(), curPix.getPlaneData(1), i, curPix.getPlaneData(1), i + 1, P_POS_H_CHR, Q_POS_H_CHR, true);
/*     */       
/*  93 */       deblockBorderChroma(horizStrength[i + 1], curMB.getQp(), curPix.getPlaneData(2), i, curPix.getPlaneData(2), i + 1, P_POS_H_CHR, Q_POS_H_CHR, true);
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public void deblockMBI(EncodedMB outMB, EncodedMB leftOutMB, EncodedMB topOutMB) {
/*  99 */     deblockMBGeneric(outMB, leftOutMB, topOutMB, BS_I, BS_I);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void deblockMBP(EncodedMB cur, EncodedMB left, EncodedMB top) {
/* 116 */     int[][] vertStrength = new int[4][4];
/* 117 */     int[][] horizStrength = new int[4][4];
/*     */     
/* 119 */     calcStrengthForBlocks(cur, left, vertStrength, LOOKUP_IDX_P_V, LOOKUP_IDX_Q_V);
/* 120 */     calcStrengthForBlocks(cur, top, horizStrength, LOOKUP_IDX_P_H, LOOKUP_IDX_Q_H);
/*     */     
/* 122 */     deblockMBGeneric(cur, left, top, vertStrength, horizStrength);
/*     */   }
/*     */ 
/*     */   
/*     */   private void deblockBorder(int[] boundary, int qp, byte[] p, int pi, byte[] q, int qi, int[][] pTab, int[][] qTab, boolean horiz) {
/* 127 */     int inc1 = horiz ? 16 : 1, inc2 = inc1 * 2, inc3 = inc1 * 3;
/* 128 */     for (int b = 0; b < 4; b++) {
/* 129 */       if (boundary[b] == 4) {
/* 130 */         for (int i = 0, ii = b << 2; i < 4; i++, ii++) {
/* 131 */           filterBs4(qp, qp, p, q, pTab[pi][ii] - inc3, pTab[pi][ii] - inc2, pTab[pi][ii] - inc1, pTab[pi][ii], qTab[qi][ii], qTab[qi][ii] + inc1, qTab[qi][ii] + inc2, qTab[qi][ii] + inc3);
/*     */         }
/* 133 */       } else if (boundary[b] > 0) {
/* 134 */         for (int i = 0, ii = b << 2; i < 4; i++, ii++) {
/* 135 */           filterBs(boundary[b], qp, qp, p, q, pTab[pi][ii] - inc2, pTab[pi][ii] - inc1, pTab[pi][ii], qTab[qi][ii], qTab[qi][ii] + inc1, qTab[qi][ii] + inc2);
/*     */         }
/*     */       } 
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   protected void filterBs4Chr(int indexAlpha, int indexBeta, byte[] pelsP, byte[] pelsQ, int p1Idx, int p0Idx, int q0Idx, int q1Idx) {
/* 144 */     _filterBs4(indexAlpha, indexBeta, pelsP, pelsQ, -1, -1, p1Idx, p0Idx, q0Idx, q1Idx, -1, -1, true);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   protected void filterBsChr(int bs, int indexAlpha, int indexBeta, byte[] pelsP, byte[] pelsQ, int p1Idx, int p0Idx, int q0Idx, int q1Idx) {
/* 150 */     _filterBs(bs, indexAlpha, indexBeta, pelsP, pelsQ, -1, p1Idx, p0Idx, q0Idx, q1Idx, -1, true);
/*     */   }
/*     */ 
/*     */   
/*     */   protected void filterBs4(int indexAlpha, int indexBeta, byte[] pelsP, byte[] pelsQ, int p3Idx, int p2Idx, int p1Idx, int p0Idx, int q0Idx, int q1Idx, int q2Idx, int q3Idx) {
/* 155 */     _filterBs4(indexAlpha, indexBeta, pelsP, pelsQ, p3Idx, p2Idx, p1Idx, p0Idx, q0Idx, q1Idx, q2Idx, q3Idx, false);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   protected void filterBs(int bs, int indexAlpha, int indexBeta, byte[] pelsP, byte[] pelsQ, int p2Idx, int p1Idx, int p0Idx, int q0Idx, int q1Idx, int q2Idx) {
/* 161 */     _filterBs(bs, indexAlpha, indexBeta, pelsP, pelsQ, p2Idx, p1Idx, p0Idx, q0Idx, q1Idx, q2Idx, false);
/*     */   }
/*     */ 
/*     */   
/*     */   protected void _filterBs4(int indexAlpha, int indexBeta, byte[] pelsP, byte[] pelsQ, int p3Idx, int p2Idx, int p1Idx, int p0Idx, int q0Idx, int q1Idx, int q2Idx, int q3Idx, boolean isChroma) {
/*     */     boolean conditionP, conditionQ;
/* 167 */     int p0 = pelsP[p0Idx];
/* 168 */     int q0 = pelsQ[q0Idx];
/* 169 */     int p1 = pelsP[p1Idx];
/* 170 */     int q1 = pelsQ[q1Idx];
/*     */     
/* 172 */     int alphaThresh = DeblockingFilter.alphaTab[indexAlpha];
/* 173 */     int betaThresh = DeblockingFilter.betaTab[indexBeta];
/*     */     
/* 175 */     boolean filterEnabled = (Math.abs(p0 - q0) < alphaThresh && Math.abs(p1 - p0) < betaThresh && Math.abs(q1 - q0) < betaThresh);
/*     */     
/* 177 */     if (!filterEnabled) {
/*     */       return;
/*     */     }
/*     */ 
/*     */     
/* 182 */     if (isChroma) {
/* 183 */       conditionP = false;
/* 184 */       conditionQ = false;
/*     */     } else {
/* 186 */       int ap = Math.abs(pelsP[p2Idx] - p0);
/* 187 */       int aq = Math.abs(pelsQ[q2Idx] - q0);
/*     */       
/* 189 */       conditionP = (ap < betaThresh && Math.abs(p0 - q0) < (alphaThresh >> 2) + 2);
/* 190 */       conditionQ = (aq < betaThresh && Math.abs(p0 - q0) < (alphaThresh >> 2) + 2);
/*     */     } 
/*     */ 
/*     */     
/* 194 */     if (conditionP) {
/* 195 */       int p3 = pelsP[p3Idx];
/* 196 */       int p2 = pelsP[p2Idx];
/*     */       
/* 198 */       int p0n = p2 + 2 * p1 + 2 * p0 + 2 * q0 + q1 + 4 >> 3;
/* 199 */       int p1n = p2 + p1 + p0 + q0 + 2 >> 2;
/* 200 */       int p2n = 2 * p3 + 3 * p2 + p1 + p0 + q0 + 4 >> 3;
/* 201 */       pelsP[p0Idx] = (byte)MathUtil.clip(p0n, -128, 127);
/* 202 */       pelsP[p1Idx] = (byte)MathUtil.clip(p1n, -128, 127);
/* 203 */       pelsP[p2Idx] = (byte)MathUtil.clip(p2n, -128, 127);
/*     */     } else {
/* 205 */       int p0n = 2 * p1 + p0 + q1 + 2 >> 2;
/* 206 */       pelsP[p0Idx] = (byte)MathUtil.clip(p0n, -128, 127);
/*     */     } 
/*     */     
/* 209 */     if (conditionQ && !isChroma) {
/* 210 */       int q2 = pelsQ[q2Idx];
/* 211 */       int q3 = pelsQ[q3Idx];
/* 212 */       int q0n = p1 + 2 * p0 + 2 * q0 + 2 * q1 + q2 + 4 >> 3;
/* 213 */       int q1n = p0 + q0 + q1 + q2 + 2 >> 2;
/* 214 */       int q2n = 2 * q3 + 3 * q2 + q1 + q0 + p0 + 4 >> 3;
/* 215 */       pelsQ[q0Idx] = (byte)MathUtil.clip(q0n, -128, 127);
/* 216 */       pelsQ[q1Idx] = (byte)MathUtil.clip(q1n, -128, 127);
/* 217 */       pelsQ[q2Idx] = (byte)MathUtil.clip(q2n, -128, 127);
/*     */     } else {
/* 219 */       int q0n = 2 * q1 + q0 + p1 + 2 >> 2;
/* 220 */       pelsQ[q0Idx] = (byte)MathUtil.clip(q0n, -128, 127);
/*     */     } 
/*     */   }
/*     */   
/*     */   protected void _filterBs(int bs, int indexAlpha, int indexBeta, byte[] pelsP, byte[] pelsQ, int p2Idx, int p1Idx, int p0Idx, int q0Idx, int q1Idx, int q2Idx, boolean isChroma) {
/*     */     boolean conditionP, conditionQ;
/* 226 */     int tC, p1 = pelsP[p1Idx];
/* 227 */     int p0 = pelsP[p0Idx];
/* 228 */     int q0 = pelsQ[q0Idx];
/* 229 */     int q1 = pelsQ[q1Idx];
/*     */     
/* 231 */     int alphaThresh = DeblockingFilter.alphaTab[indexAlpha];
/* 232 */     int betaThresh = DeblockingFilter.betaTab[indexBeta];
/*     */     
/* 234 */     boolean filterEnabled = (Math.abs(p0 - q0) < alphaThresh && Math.abs(p1 - p0) < betaThresh && Math.abs(q1 - q0) < betaThresh);
/*     */     
/* 236 */     if (!filterEnabled) {
/*     */       return;
/*     */     }
/* 239 */     int tC0 = DeblockingFilter.tcs[bs - 1][indexAlpha];
/*     */ 
/*     */ 
/*     */     
/* 243 */     if (!isChroma) {
/* 244 */       int ap = Math.abs(pelsP[p2Idx] - p0);
/* 245 */       int aq = Math.abs(pelsQ[q2Idx] - q0);
/* 246 */       tC = tC0 + ((ap < betaThresh) ? 1 : 0) + ((aq < betaThresh) ? 1 : 0);
/* 247 */       conditionP = (ap < betaThresh);
/* 248 */       conditionQ = (aq < betaThresh);
/*     */     } else {
/* 250 */       tC = tC0 + 1;
/* 251 */       conditionP = false;
/* 252 */       conditionQ = false;
/*     */     } 
/*     */     
/* 255 */     int sigma = (q0 - p0 << 2) + p1 - q1 + 4 >> 3;
/* 256 */     sigma = (sigma < -tC) ? -tC : ((sigma > tC) ? tC : sigma);
/*     */     
/* 258 */     int p0n = p0 + sigma;
/* 259 */     p0n = (p0n < -128) ? -128 : p0n;
/* 260 */     int q0n = q0 - sigma;
/* 261 */     q0n = (q0n < -128) ? -128 : q0n;
/*     */     
/* 263 */     if (conditionP) {
/* 264 */       int p2 = pelsP[p2Idx];
/*     */       
/* 266 */       int diff = p2 + (p0 + q0 + 1 >> 1) - (p1 << 1) >> 1;
/* 267 */       diff = (diff < -tC0) ? -tC0 : ((diff > tC0) ? tC0 : diff);
/* 268 */       int p1n = p1 + diff;
/* 269 */       pelsP[p1Idx] = (byte)MathUtil.clip(p1n, -128, 127);
/*     */     } 
/*     */     
/* 272 */     if (conditionQ) {
/* 273 */       int q2 = pelsQ[q2Idx];
/* 274 */       int diff = q2 + (p0 + q0 + 1 >> 1) - (q1 << 1) >> 1;
/* 275 */       diff = (diff < -tC0) ? -tC0 : ((diff > tC0) ? tC0 : diff);
/* 276 */       int q1n = q1 + diff;
/* 277 */       pelsQ[q1Idx] = (byte)MathUtil.clip(q1n, -128, 127);
/*     */     } 
/*     */     
/* 280 */     pelsQ[q0Idx] = (byte)MathUtil.clip(q0n, -128, 127);
/* 281 */     pelsP[p0Idx] = (byte)MathUtil.clip(p0n, -128, 127);
/*     */   }
/*     */ 
/*     */   
/*     */   private void deblockBorderChroma(int[] boundary, int qp, byte[] p, int pi, byte[] q, int qi, int[][] pTab, int[][] qTab, boolean horiz) {
/* 286 */     int inc1 = horiz ? 8 : 1;
/* 287 */     for (int b = 0; b < 4; b++) {
/* 288 */       if (boundary[b] == 4) {
/* 289 */         for (int i = 0, ii = b << 1; i < 2; i++, ii++)
/* 290 */           filterBs4Chr(qp, qp, p, q, pTab[pi][ii] - inc1, pTab[pi][ii], qTab[qi][ii], qTab[qi][ii] + inc1); 
/* 291 */       } else if (boundary[b] > 0) {
/* 292 */         for (int i = 0, ii = b << 1; i < 2; i++, ii++) {
/* 293 */           filterBsChr(boundary[b], qp, qp, p, q, pTab[pi][ii] - inc1, pTab[pi][ii], qTab[qi][ii], qTab[qi][ii] + inc1);
/*     */         }
/*     */       } 
/*     */     } 
/*     */   }
/*     */   
/*     */   private static int[][] buildPPosH() {
/* 300 */     int[][] qPos = new int[4][16];
/* 301 */     for (int i = 0; i < 4; i++) {
/* 302 */       for (int j = 0; j < 16; j++) {
/* 303 */         qPos[i][j] = j + (i << 6) + 48;
/*     */       }
/*     */     } 
/* 306 */     return qPos;
/*     */   }
/*     */   
/*     */   private static int[][] buildQPosH() {
/* 310 */     int[][] pPos = new int[4][16];
/* 311 */     for (int i = 0; i < 4; i++) {
/* 312 */       for (int j = 0; j < 16; j++) {
/* 313 */         pPos[i][j] = j + (i << 6);
/*     */       }
/*     */     } 
/* 316 */     return pPos;
/*     */   }
/*     */   
/*     */   private static int[][] buildPPosV() {
/* 320 */     int[][] qPos = new int[4][16];
/* 321 */     for (int i = 0; i < 4; i++) {
/* 322 */       for (int j = 0; j < 16; j++) {
/* 323 */         qPos[i][j] = (j << 4) + (i << 2) + 3;
/*     */       }
/*     */     } 
/* 326 */     return qPos;
/*     */   }
/*     */   
/*     */   private static int[][] buildQPosV() {
/* 330 */     int[][] pPos = new int[4][16];
/* 331 */     for (int i = 0; i < 4; i++) {
/* 332 */       for (int j = 0; j < 16; j++) {
/* 333 */         pPos[i][j] = (j << 4) + (i << 2);
/*     */       }
/*     */     } 
/* 336 */     return pPos;
/*     */   }
/*     */   
/*     */   private static int[][] buildPPosHChr() {
/* 340 */     int[][] qPos = new int[4][8];
/* 341 */     for (int i = 0; i < 4; i++) {
/* 342 */       for (int j = 0; j < 8; j++) {
/* 343 */         qPos[i][j] = j + (i << 4) + 8;
/*     */       }
/*     */     } 
/* 346 */     return qPos;
/*     */   }
/*     */   
/*     */   private static int[][] buildQPosHChr() {
/* 350 */     int[][] pPos = new int[4][8];
/* 351 */     for (int i = 0; i < 4; i++) {
/* 352 */       for (int j = 0; j < 8; j++) {
/* 353 */         pPos[i][j] = j + (i << 4);
/*     */       }
/*     */     } 
/* 356 */     return pPos;
/*     */   }
/*     */   
/*     */   private static int[][] buildPPosVChr() {
/* 360 */     int[][] qPos = new int[4][8];
/* 361 */     for (int i = 0; i < 4; i++) {
/* 362 */       for (int j = 0; j < 8; j++) {
/* 363 */         qPos[i][j] = (j << 3) + (i << 1) + 1;
/*     */       }
/*     */     } 
/* 366 */     return qPos;
/*     */   }
/*     */   
/*     */   private static int[][] buildQPosVChr() {
/* 370 */     int[][] pPos = new int[4][8];
/* 371 */     for (int i = 0; i < 4; i++) {
/* 372 */       for (int j = 0; j < 8; j++) {
/* 373 */         pPos[i][j] = (j << 3) + (i << 1);
/*     */       }
/*     */     } 
/* 376 */     return pPos;
/*     */   }
/*     */ 
/*     */   
/*     */   static void calcStrengthForBlocks(EncodedMB cur, EncodedMB other, int[][] outStrength, int[][] LOOKUP_IDX_P, int[][] LOOKUP_IDX_Q) {
/* 381 */     if (other != null) {
/* 382 */       for (int j = 0; j < 4; j++) {
/* 383 */         outStrength[0][j] = other.getType().isIntra() ? 4 : MathUtil.max3(
/* 384 */             strengthMv(other.getMx()[LOOKUP_IDX_P[0][j]], cur.getMx()[LOOKUP_IDX_Q[0][j]]), 
/* 385 */             strengthMv(other.getMy()[LOOKUP_IDX_P[0][j]], cur.getMy()[LOOKUP_IDX_Q[0][j]]), 
/* 386 */             strengthNc(other.getNc()[LOOKUP_IDX_P[0][j]], cur.getNc()[LOOKUP_IDX_Q[0][j]]));
/*     */       }
/*     */     }
/*     */     
/* 390 */     for (int i = 1; i < 4; i++) {
/* 391 */       for (int j = 0; j < 4; j++) {
/* 392 */         outStrength[i][j] = MathUtil.max3(
/* 393 */             strengthMv(cur.getMx()[LOOKUP_IDX_P[i][j]], cur.getMx()[LOOKUP_IDX_Q[i][j]]), 
/* 394 */             strengthMv(cur.getMy()[LOOKUP_IDX_P[i][j]], cur.getMy()[LOOKUP_IDX_Q[i][j]]), 
/* 395 */             strengthNc(cur.getNc()[LOOKUP_IDX_P[i][j]], cur.getNc()[LOOKUP_IDX_Q[i][j]]));
/*     */       }
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   private static int strengthNc(int ncA, int ncB) {
/* 402 */     return (ncA > 0 || ncB > 0) ? 2 : 0;
/*     */   }
/*     */   
/*     */   private static int strengthMv(int v0, int v1) {
/* 406 */     return (Math.abs(v0 - v1) >= 4) ? 1 : 0;
/*     */   }
/*     */   
/* 409 */   private static int[][] P_POS_V = buildPPosV();
/* 410 */   private static int[][] Q_POS_V = buildQPosV();
/* 411 */   private static int[][] P_POS_H = buildPPosH();
/* 412 */   private static int[][] Q_POS_H = buildQPosH();
/*     */   
/* 414 */   private static int[][] P_POS_V_CHR = buildPPosVChr();
/* 415 */   private static int[][] Q_POS_V_CHR = buildQPosVChr();
/*     */   
/* 417 */   private static int[][] P_POS_H_CHR = buildPPosHChr();
/* 418 */   private static int[][] Q_POS_H_CHR = buildQPosHChr();
/*     */ }


/* Location:              C:\Users\rapha\Downloads\aurora.jar!\META-INF\jars\jcodec-0.2.5.jar!\org\jcodec\codecs\h264\encode\MBDeblocker.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */