/*    */ package org.jcodec.codecs.h264.encode;
/*    */ 
/*    */ import org.jcodec.codecs.h264.io.model.SliceType;
/*    */ import org.jcodec.common.model.Size;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class DumbRateControl
/*    */   implements RateControl
/*    */ {
/*    */   private static final int QP = 20;
/*    */   private int bitsPerMb;
/*    */   private int totalQpDelta;
/*    */   private boolean justSwitched;
/*    */   
/*    */   public int accept(int bits) {
/* 23 */     if (bits >= this.bitsPerMb) {
/* 24 */       this.totalQpDelta++;
/* 25 */       this.justSwitched = true;
/* 26 */       return 1;
/*    */     } 
/*    */     
/* 29 */     if (this.totalQpDelta > 0 && !this.justSwitched && this.bitsPerMb - bits > this.bitsPerMb >> 3) {
/* 30 */       this.totalQpDelta--;
/* 31 */       this.justSwitched = true;
/* 32 */       return -1;
/*    */     } 
/* 34 */     this.justSwitched = false;
/*    */     
/* 36 */     return 0;
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public int startPicture(Size sz, int maxSize, SliceType sliceType) {
/* 42 */     int totalMb = (sz.getWidth() + 15 >> 4) * (sz.getHeight() + 15 >> 4);
/* 43 */     this.bitsPerMb = (maxSize << 3) / totalMb;
/* 44 */     this.totalQpDelta = 0;
/* 45 */     this.justSwitched = false;
/* 46 */     return 20 + ((sliceType == SliceType.P) ? 6 : 0);
/*    */   }
/*    */ 
/*    */   
/*    */   public int initialQpDelta() {
/* 51 */     return 0;
/*    */   }
/*    */ }


/* Location:              C:\Users\rapha\Downloads\aurora.jar!\META-INF\jars\jcodec-0.2.5.jar!\org\jcodec\codecs\h264\encode\DumbRateControl.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */