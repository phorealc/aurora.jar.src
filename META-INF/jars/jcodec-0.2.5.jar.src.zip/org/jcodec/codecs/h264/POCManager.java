/*    */ package org.jcodec.codecs.h264;
/*    */ 
/*    */ import org.jcodec.codecs.h264.io.model.NALUnit;
/*    */ import org.jcodec.codecs.h264.io.model.NALUnitType;
/*    */ import org.jcodec.codecs.h264.io.model.RefPicMarking;
/*    */ import org.jcodec.codecs.h264.io.model.SliceHeader;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class POCManager
/*    */ {
/*    */   private int prevPOCMsb;
/*    */   private int prevPOCLsb;
/*    */   
/*    */   public int calcPOC(SliceHeader firstSliceHeader, NALUnit firstNu) {
/* 34 */     switch (firstSliceHeader.sps.picOrderCntType) {
/*    */       case 0:
/* 36 */         return calcPOC0(firstSliceHeader, firstNu);
/*    */       case 1:
/* 38 */         return calcPOC1(firstSliceHeader, firstNu);
/*    */       case 2:
/* 40 */         return calcPOC2(firstSliceHeader, firstNu);
/*    */     } 
/* 42 */     throw new RuntimeException("POC no!!!");
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   private int calcPOC2(SliceHeader firstSliceHeader, NALUnit firstNu) {
/* 48 */     return firstSliceHeader.frameNum << 1;
/*    */   }
/*    */   
/*    */   private int calcPOC1(SliceHeader firstSliceHeader, NALUnit firstNu) {
/* 52 */     return firstSliceHeader.frameNum << 1;
/*    */   }
/*    */   private int calcPOC0(SliceHeader firstSliceHeader, NALUnit firstNu) {
/*    */     int POCMsb;
/* 56 */     if (firstNu.type == NALUnitType.IDR_SLICE) {
/* 57 */       this.prevPOCMsb = this.prevPOCLsb = 0;
/*    */     }
/* 59 */     int maxPOCLsbDiv2 = 1 << firstSliceHeader.sps.log2MaxPicOrderCntLsbMinus4 + 3, maxPOCLsb = maxPOCLsbDiv2 << 1;
/* 60 */     int POCLsb = firstSliceHeader.picOrderCntLsb;
/*    */ 
/*    */     
/* 63 */     if (POCLsb < this.prevPOCLsb && this.prevPOCLsb - POCLsb >= maxPOCLsbDiv2) {
/* 64 */       POCMsb = this.prevPOCMsb + maxPOCLsb;
/* 65 */     } else if (POCLsb > this.prevPOCLsb && POCLsb - this.prevPOCLsb > maxPOCLsbDiv2) {
/* 66 */       POCMsb = this.prevPOCMsb - maxPOCLsb;
/*    */     } else {
/* 68 */       POCMsb = this.prevPOCMsb;
/*    */     } 
/* 70 */     int POC = POCMsb + POCLsb;
/*    */     
/* 72 */     if (firstNu.nal_ref_idc > 0) {
/* 73 */       if (hasMMCO5(firstSliceHeader, firstNu)) {
/* 74 */         this.prevPOCMsb = 0;
/* 75 */         this.prevPOCLsb = POC;
/*    */       } else {
/* 77 */         this.prevPOCMsb = POCMsb;
/* 78 */         this.prevPOCLsb = POCLsb;
/*    */       } 
/*    */     }
/*    */     
/* 82 */     return POC;
/*    */   }
/*    */   
/*    */   private boolean hasMMCO5(SliceHeader firstSliceHeader, NALUnit firstNu) {
/* 86 */     if (firstNu.type != NALUnitType.IDR_SLICE && firstSliceHeader.refPicMarkingNonIDR != null) {
/* 87 */       RefPicMarking.Instruction[] instructions = firstSliceHeader.refPicMarkingNonIDR.getInstructions();
/* 88 */       for (int i = 0; i < instructions.length; i++) {
/* 89 */         RefPicMarking.Instruction instruction = instructions[i];
/* 90 */         if (instruction.getType() == RefPicMarking.InstrType.CLEAR)
/* 91 */           return true; 
/*    */       } 
/*    */     } 
/* 94 */     return false;
/*    */   }
/*    */ }


/* Location:              C:\Users\rapha\Downloads\aurora.jar!\META-INF\jars\jcodec-0.2.5.jar!\org\jcodec\codecs\h264\POCManager.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */