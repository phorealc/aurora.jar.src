/*     */ package org.jcodec.codecs.h264;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.nio.ByteBuffer;
/*     */ import java.util.ArrayList;
/*     */ import java.util.List;
/*     */ import org.jcodec.codecs.h264.decode.SliceHeaderReader;
/*     */ import org.jcodec.codecs.h264.io.model.NALUnit;
/*     */ import org.jcodec.codecs.h264.io.model.NALUnitType;
/*     */ import org.jcodec.codecs.h264.io.model.PictureParameterSet;
/*     */ import org.jcodec.codecs.h264.io.model.RefPicMarking;
/*     */ import org.jcodec.codecs.h264.io.model.SeqParameterSet;
/*     */ import org.jcodec.codecs.h264.io.model.SliceHeader;
/*     */ import org.jcodec.common.Demuxer;
/*     */ import org.jcodec.common.DemuxerTrack;
/*     */ import org.jcodec.common.DemuxerTrackMeta;
/*     */ import org.jcodec.common.IntObjectMap;
/*     */ import org.jcodec.common.io.BitReader;
/*     */ import org.jcodec.common.model.Packet;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class BufferH264ES
/*     */   implements DemuxerTrack, Demuxer
/*     */ {
/*     */   private ByteBuffer bb;
/*     */   private IntObjectMap<PictureParameterSet> pps;
/*     */   private IntObjectMap<SeqParameterSet> sps;
/*     */   private int prevFrameNumOffset;
/*     */   private int prevFrameNum;
/*     */   private int prevPicOrderCntMsb;
/*     */   private int prevPicOrderCntLsb;
/*     */   private int frameNo;
/*     */   
/*     */   public BufferH264ES(ByteBuffer bb) {
/*  46 */     this.pps = new IntObjectMap();
/*  47 */     this.sps = new IntObjectMap();
/*     */     
/*  49 */     this.bb = bb;
/*  50 */     this.frameNo = 0;
/*     */   }
/*     */ 
/*     */   
/*     */   public Packet nextFrame() {
/*  55 */     ByteBuffer result = this.bb.duplicate();
/*     */     
/*  57 */     NALUnit prevNu = null;
/*  58 */     SliceHeader prevSh = null;
/*     */     while (true) {
/*  60 */       this.bb.mark();
/*  61 */       ByteBuffer buf = H264Utils.nextNALUnit(this.bb);
/*  62 */       if (buf == null) {
/*     */         break;
/*     */       }
/*  65 */       NALUnit nu = NALUnit.read(buf);
/*     */       
/*  67 */       if (nu.type == NALUnitType.IDR_SLICE || nu.type == NALUnitType.NON_IDR_SLICE) {
/*  68 */         SliceHeader sh = readSliceHeader(buf, nu);
/*     */         
/*  70 */         if (prevNu != null && prevSh != null && !sameFrame(prevNu, nu, prevSh, sh)) {
/*  71 */           this.bb.reset();
/*     */           break;
/*     */         } 
/*  74 */         prevSh = sh;
/*  75 */         prevNu = nu; continue;
/*  76 */       }  if (nu.type == NALUnitType.PPS) {
/*  77 */         PictureParameterSet read = PictureParameterSet.read(buf);
/*  78 */         this.pps.put(read.picParameterSetId, read); continue;
/*  79 */       }  if (nu.type == NALUnitType.SPS) {
/*  80 */         SeqParameterSet read = SeqParameterSet.read(buf);
/*  81 */         this.sps.put(read.seqParameterSetId, read);
/*     */       } 
/*     */     } 
/*     */     
/*  85 */     result.limit(this.bb.position());
/*     */     
/*  87 */     return (prevSh == null) ? null : detectPoc(result, prevNu, prevSh);
/*     */   }
/*     */   
/*     */   private SliceHeader readSliceHeader(ByteBuffer buf, NALUnit nu) {
/*  91 */     BitReader br = BitReader.createBitReader(buf);
/*  92 */     SliceHeader sh = SliceHeaderReader.readPart1(br);
/*  93 */     PictureParameterSet pp = (PictureParameterSet)this.pps.get(sh.picParameterSetId);
/*  94 */     SliceHeaderReader.readPart2(sh, nu, (SeqParameterSet)this.sps.get(pp.seqParameterSetId), pp, br);
/*  95 */     return sh;
/*     */   }
/*     */   
/*     */   private boolean sameFrame(NALUnit nu1, NALUnit nu2, SliceHeader sh1, SliceHeader sh2) {
/*  99 */     if (sh1.picParameterSetId != sh2.picParameterSetId) {
/* 100 */       return false;
/*     */     }
/* 102 */     if (sh1.frameNum != sh2.frameNum) {
/* 103 */       return false;
/*     */     }
/* 105 */     SeqParameterSet sps = sh1.sps;
/*     */     
/* 107 */     if (sps.picOrderCntType == 0 && sh1.picOrderCntLsb != sh2.picOrderCntLsb) {
/* 108 */       return false;
/*     */     }
/* 110 */     if (sps.picOrderCntType == 1 && (sh1.deltaPicOrderCnt[0] != sh2.deltaPicOrderCnt[0] || sh1.deltaPicOrderCnt[1] != sh2.deltaPicOrderCnt[1])) {
/* 111 */       return false;
/*     */     }
/* 113 */     if ((nu1.nal_ref_idc == 0 || nu2.nal_ref_idc == 0) && nu1.nal_ref_idc != nu2.nal_ref_idc) {
/* 114 */       return false;
/*     */     }
/* 116 */     if (((nu1.type == NALUnitType.IDR_SLICE) ? true : false) != ((nu2.type == NALUnitType.IDR_SLICE) ? true : false)) {
/* 117 */       return false;
/*     */     }
/* 119 */     if (sh1.idrPicId != sh2.idrPicId) {
/* 120 */       return false;
/*     */     }
/* 122 */     return true;
/*     */   }
/*     */   
/*     */   private Packet detectPoc(ByteBuffer result, NALUnit nu, SliceHeader sh) {
/* 126 */     int maxFrameNum = 1 << sh.sps.log2MaxFrameNumMinus4 + 4;
/* 127 */     if (detectGap(sh, maxFrameNum)) {
/* 128 */       issueNonExistingPic(sh, maxFrameNum);
/*     */     }
/* 130 */     int absFrameNum = updateFrameNumber(sh.frameNum, maxFrameNum, detectMMCO5(sh.refPicMarkingNonIDR));
/*     */     
/* 132 */     int poc = 0;
/* 133 */     if (nu.type == NALUnitType.NON_IDR_SLICE) {
/* 134 */       poc = calcPoc(absFrameNum, nu, sh);
/*     */     }
/* 136 */     return new Packet(result, absFrameNum, 1, 1L, this.frameNo++, (nu.type == NALUnitType.IDR_SLICE) ? Packet.FrameType.KEY : Packet.FrameType.INTER, null, poc);
/*     */   }
/*     */   
/*     */   private int updateFrameNumber(int frameNo, int maxFrameNum, boolean mmco5) {
/*     */     int frameNumOffset;
/* 141 */     if (this.prevFrameNum > frameNo) {
/* 142 */       frameNumOffset = this.prevFrameNumOffset + maxFrameNum;
/*     */     } else {
/* 144 */       frameNumOffset = this.prevFrameNumOffset;
/*     */     } 
/* 146 */     int absFrameNum = frameNumOffset + frameNo;
/*     */     
/* 148 */     this.prevFrameNum = mmco5 ? 0 : frameNo;
/* 149 */     this.prevFrameNumOffset = frameNumOffset;
/* 150 */     return absFrameNum;
/*     */   }
/*     */   
/*     */   private void issueNonExistingPic(SliceHeader sh, int maxFrameNum) {
/* 154 */     int nextFrameNum = (this.prevFrameNum + 1) % maxFrameNum;
/*     */     
/* 156 */     this.prevFrameNum = nextFrameNum;
/*     */   }
/*     */   
/*     */   private boolean detectGap(SliceHeader sh, int maxFrameNum) {
/* 160 */     return (sh.frameNum != this.prevFrameNum && sh.frameNum != (this.prevFrameNum + 1) % maxFrameNum);
/*     */   }
/*     */   
/*     */   private int calcPoc(int absFrameNum, NALUnit nu, SliceHeader sh) {
/* 164 */     if (sh.sps.picOrderCntType == 0)
/* 165 */       return calcPOC0(nu, sh); 
/* 166 */     if (sh.sps.picOrderCntType == 1) {
/* 167 */       return calcPOC1(absFrameNum, nu, sh);
/*     */     }
/* 169 */     return calcPOC2(absFrameNum, nu, sh);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private int calcPOC2(int absFrameNum, NALUnit nu, SliceHeader sh) {
/* 175 */     if (nu.nal_ref_idc == 0) {
/* 176 */       return 2 * absFrameNum - 1;
/*     */     }
/* 178 */     return 2 * absFrameNum;
/*     */   }
/*     */   
/*     */   private int calcPOC1(int absFrameNum, NALUnit nu, SliceHeader sh) {
/*     */     int expectedPicOrderCnt;
/* 183 */     if (sh.sps.numRefFramesInPicOrderCntCycle == 0)
/* 184 */       absFrameNum = 0; 
/* 185 */     if (nu.nal_ref_idc == 0 && absFrameNum > 0) {
/* 186 */       absFrameNum--;
/*     */     }
/* 188 */     int expectedDeltaPerPicOrderCntCycle = 0;
/* 189 */     for (int i = 0; i < sh.sps.numRefFramesInPicOrderCntCycle; i++) {
/* 190 */       expectedDeltaPerPicOrderCntCycle += sh.sps.offsetForRefFrame[i];
/*     */     }
/*     */     
/* 193 */     if (absFrameNum > 0) {
/* 194 */       int picOrderCntCycleCnt = (absFrameNum - 1) / sh.sps.numRefFramesInPicOrderCntCycle;
/* 195 */       int frameNumInPicOrderCntCycle = (absFrameNum - 1) % sh.sps.numRefFramesInPicOrderCntCycle;
/*     */       
/* 197 */       expectedPicOrderCnt = picOrderCntCycleCnt * expectedDeltaPerPicOrderCntCycle;
/* 198 */       for (int j = 0; j <= frameNumInPicOrderCntCycle; j++)
/* 199 */         expectedPicOrderCnt += sh.sps.offsetForRefFrame[j]; 
/*     */     } else {
/* 201 */       expectedPicOrderCnt = 0;
/*     */     } 
/* 203 */     if (nu.nal_ref_idc == 0) {
/* 204 */       expectedPicOrderCnt += sh.sps.offsetForNonRefPic;
/*     */     }
/* 206 */     return expectedPicOrderCnt + sh.deltaPicOrderCnt[0];
/*     */   }
/*     */ 
/*     */   
/*     */   private int calcPOC0(NALUnit nu, SliceHeader sh) {
/* 211 */     int picOrderCntMsb, pocCntLsb = sh.picOrderCntLsb;
/* 212 */     int maxPicOrderCntLsb = 1 << sh.sps.log2MaxPicOrderCntLsbMinus4 + 4;
/*     */ 
/*     */ 
/*     */     
/* 216 */     if (pocCntLsb < this.prevPicOrderCntLsb && this.prevPicOrderCntLsb - pocCntLsb >= maxPicOrderCntLsb / 2) {
/* 217 */       picOrderCntMsb = this.prevPicOrderCntMsb + maxPicOrderCntLsb;
/* 218 */     } else if (pocCntLsb > this.prevPicOrderCntLsb && pocCntLsb - this.prevPicOrderCntLsb > maxPicOrderCntLsb / 2) {
/* 219 */       picOrderCntMsb = this.prevPicOrderCntMsb - maxPicOrderCntLsb;
/*     */     } else {
/* 221 */       picOrderCntMsb = this.prevPicOrderCntMsb;
/*     */     } 
/* 223 */     if (nu.nal_ref_idc != 0) {
/* 224 */       this.prevPicOrderCntMsb = picOrderCntMsb;
/* 225 */       this.prevPicOrderCntLsb = pocCntLsb;
/*     */     } 
/*     */     
/* 228 */     return picOrderCntMsb + pocCntLsb;
/*     */   }
/*     */   
/*     */   private boolean detectMMCO5(RefPicMarking refPicMarkingNonIDR) {
/* 232 */     if (refPicMarkingNonIDR == null) {
/* 233 */       return false;
/*     */     }
/* 235 */     RefPicMarking.Instruction[] instructions = refPicMarkingNonIDR.getInstructions();
/* 236 */     for (int i = 0; i < instructions.length; i++) {
/* 237 */       RefPicMarking.Instruction instr = instructions[i];
/* 238 */       if (instr.getType() == RefPicMarking.InstrType.CLEAR) {
/* 239 */         return true;
/*     */       }
/*     */     } 
/* 242 */     return false;
/*     */   }
/*     */   
/*     */   public SeqParameterSet[] getSps() {
/* 246 */     return (SeqParameterSet[])this.sps.values((Object[])new SeqParameterSet[0]);
/*     */   }
/*     */   
/*     */   public PictureParameterSet[] getPps() {
/* 250 */     return (PictureParameterSet[])this.pps.values((Object[])new PictureParameterSet[0]);
/*     */   }
/*     */ 
/*     */   
/*     */   public DemuxerTrackMeta getMeta() {
/* 255 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void close() throws IOException {}
/*     */ 
/*     */ 
/*     */   
/*     */   public List<? extends DemuxerTrack> getTracks() {
/* 266 */     return getVideoTracks();
/*     */   }
/*     */ 
/*     */   
/*     */   public List<? extends DemuxerTrack> getVideoTracks() {
/* 271 */     List<DemuxerTrack> tracks = new ArrayList<DemuxerTrack>();
/* 272 */     tracks.add(this);
/* 273 */     return tracks;
/*     */   }
/*     */ 
/*     */   
/*     */   public List<? extends DemuxerTrack> getAudioTracks() {
/* 278 */     List<DemuxerTrack> tracks = new ArrayList<DemuxerTrack>();
/* 279 */     return tracks;
/*     */   }
/*     */ }


/* Location:              C:\Users\rapha\Downloads\aurora.jar!\META-INF\jars\jcodec-0.2.5.jar!\org\jcodec\codecs\h264\BufferH264ES.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */