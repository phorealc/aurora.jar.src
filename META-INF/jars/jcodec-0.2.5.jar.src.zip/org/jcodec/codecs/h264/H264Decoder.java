/*     */ package org.jcodec.codecs.h264;
/*     */ 
/*     */ import java.nio.ByteBuffer;
/*     */ import java.util.ArrayList;
/*     */ import java.util.List;
/*     */ import java.util.concurrent.ExecutorService;
/*     */ import java.util.concurrent.Executors;
/*     */ import java.util.concurrent.Future;
/*     */ import java.util.concurrent.ThreadFactory;
/*     */ import org.jcodec.codecs.h264.decode.DeblockerInput;
/*     */ import org.jcodec.codecs.h264.decode.FrameReader;
/*     */ import org.jcodec.codecs.h264.decode.SliceDecoder;
/*     */ import org.jcodec.codecs.h264.decode.SliceHeaderReader;
/*     */ import org.jcodec.codecs.h264.decode.SliceReader;
/*     */ import org.jcodec.codecs.h264.decode.deblock.DeblockingFilter;
/*     */ import org.jcodec.codecs.h264.io.model.Frame;
/*     */ import org.jcodec.codecs.h264.io.model.NALUnit;
/*     */ import org.jcodec.codecs.h264.io.model.NALUnitType;
/*     */ import org.jcodec.codecs.h264.io.model.PictureParameterSet;
/*     */ import org.jcodec.codecs.h264.io.model.RefPicMarking;
/*     */ import org.jcodec.codecs.h264.io.model.RefPicMarkingIDR;
/*     */ import org.jcodec.codecs.h264.io.model.SeqParameterSet;
/*     */ import org.jcodec.codecs.h264.io.model.SliceHeader;
/*     */ import org.jcodec.codecs.h264.io.model.SliceType;
/*     */ import org.jcodec.common.IntObjectMap;
/*     */ import org.jcodec.common.UsedViaReflection;
/*     */ import org.jcodec.common.VideoCodecMeta;
/*     */ import org.jcodec.common.VideoDecoder;
/*     */ import org.jcodec.common.io.BitReader;
/*     */ import org.jcodec.common.logging.Logger;
/*     */ import org.jcodec.common.model.ColorSpace;
/*     */ import org.jcodec.common.model.Picture;
/*     */ import org.jcodec.common.model.Rect;
/*     */ import org.jcodec.common.model.Size;
/*     */ import org.jcodec.common.tools.MathUtil;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class H264Decoder
/*     */   extends VideoDecoder
/*     */ {
/*     */   private Frame[] sRefs;
/*     */   private IntObjectMap<Frame> lRefs;
/*  63 */   private List<Frame> pictureBuffer = new ArrayList<Frame>(); private FrameReader reader;
/*  64 */   private POCManager poc = new POCManager(); private ExecutorService tp;
/*  65 */   private boolean threaded = (Runtime.getRuntime().availableProcessors() > 1); public H264Decoder() {
/*  66 */     if (this.threaded) {
/*  67 */       this.tp = Executors.newFixedThreadPool(Runtime.getRuntime().availableProcessors(), new ThreadFactory() {
/*     */             public Thread newThread(Runnable r) {
/*  69 */               Thread t = Executors.defaultThreadFactory().newThread(r);
/*  70 */               t.setDaemon(true);
/*  71 */               return t;
/*     */             }
/*     */           });
/*     */     }
/*  75 */     this.reader = new FrameReader();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static H264Decoder createH264DecoderFromCodecPrivate(ByteBuffer codecPrivate) {
/*  86 */     H264Decoder d = new H264Decoder();
/*  87 */     for (ByteBuffer bb : H264Utils.splitFrame(codecPrivate.duplicate())) {
/*  88 */       NALUnit nu = NALUnit.read(bb);
/*  89 */       if (nu.type == NALUnitType.SPS) {
/*  90 */         d.reader.addSps(bb); continue;
/*  91 */       }  if (nu.type == NALUnitType.PPS) {
/*  92 */         d.reader.addPps(bb);
/*     */       }
/*     */     } 
/*  95 */     return d;
/*     */   }
/*     */ 
/*     */   
/*     */   public Frame decodeFrame(ByteBuffer data, byte[][] buffer) {
/* 100 */     return decodeFrameFromNals(H264Utils.splitFrame(data), buffer);
/*     */   }
/*     */   
/*     */   public Frame decodeFrameFromNals(List<ByteBuffer> nalUnits, byte[][] buffer) {
/* 104 */     return (new FrameDecoder(this)).decodeFrame(nalUnits, buffer);
/*     */   }
/*     */   
/*     */   private static final class SliceDecoderRunnable implements Runnable {
/*     */     private final SliceReader sliceReader;
/*     */     private final Frame result;
/*     */     private H264Decoder.FrameDecoder fdec;
/*     */     
/*     */     private SliceDecoderRunnable(H264Decoder.FrameDecoder fdec, SliceReader sliceReader, Frame result) {
/* 113 */       this.fdec = fdec;
/* 114 */       this.sliceReader = sliceReader;
/* 115 */       this.result = result;
/*     */     }
/*     */     
/*     */     public void run() {
/* 119 */       (new SliceDecoder(this.fdec.activeSps, this.fdec.dec.sRefs, this.fdec.dec.lRefs, this.fdec.di, this.result))
/* 120 */         .decodeFromReader(this.sliceReader);
/*     */     }
/*     */   }
/*     */   
/*     */   static class FrameDecoder {
/*     */     private SeqParameterSet activeSps;
/*     */     private DeblockingFilter filter;
/*     */     private SliceHeader firstSliceHeader;
/*     */     private NALUnit firstNu;
/*     */     private H264Decoder dec;
/*     */     private DeblockerInput di;
/*     */     
/*     */     public FrameDecoder(H264Decoder decoder) {
/* 133 */       this.dec = decoder;
/*     */     }
/*     */     
/*     */     public Frame decodeFrame(List<ByteBuffer> nalUnits, byte[][] buffer) {
/* 137 */       List<SliceReader> sliceReaders = this.dec.reader.readFrame(nalUnits);
/* 138 */       if (sliceReaders == null || sliceReaders.size() == 0)
/* 139 */         return null; 
/* 140 */       Frame result = init(sliceReaders.get(0), buffer);
/* 141 */       if (this.dec.threaded && sliceReaders.size() > 1) {
/* 142 */         List<Future<?>> futures = new ArrayList<Future<?>>();
/* 143 */         for (SliceReader sliceReader : sliceReaders) {
/* 144 */           futures.add(this.dec.tp.submit(new H264Decoder.SliceDecoderRunnable(this, sliceReader, result)));
/*     */         }
/*     */         
/* 147 */         for (Future<?> future : futures) {
/* 148 */           waitForSure(future);
/*     */         }
/*     */       } else {
/*     */         
/* 152 */         for (SliceReader sliceReader : sliceReaders) {
/* 153 */           (new SliceDecoder(this.activeSps, this.dec.sRefs, this.dec.lRefs, this.di, result)).decodeFromReader(sliceReader);
/*     */         }
/*     */       } 
/*     */       
/* 157 */       this.filter.deblockFrame((Picture)result);
/*     */       
/* 159 */       updateReferences(result);
/*     */       
/* 161 */       return result;
/*     */     }
/*     */ 
/*     */     
/*     */     private void waitForSure(Future<?> future) {
/*     */       try {
/* 167 */         future.get();
/*     */       }
/* 169 */       catch (Exception e) {
/* 170 */         throw new RuntimeException(e);
/*     */       } 
/*     */     }
/*     */ 
/*     */     
/*     */     private void updateReferences(Frame picture) {
/* 176 */       if (this.firstNu.nal_ref_idc != 0) {
/* 177 */         if (this.firstNu.type == NALUnitType.IDR_SLICE) {
/* 178 */           performIDRMarking(this.firstSliceHeader.refPicMarkingIDR, picture);
/*     */         } else {
/* 180 */           performMarking(this.firstSliceHeader.refPicMarkingNonIDR, picture);
/*     */         } 
/*     */       }
/*     */     }
/*     */     
/*     */     private Frame init(SliceReader sliceReader, byte[][] buffer) {
/* 186 */       this.firstNu = sliceReader.getNALUnit();
/*     */       
/* 188 */       this.firstSliceHeader = sliceReader.getSliceHeader();
/* 189 */       this.activeSps = this.firstSliceHeader.sps;
/*     */       
/* 191 */       validateSupportedFeatures(this.firstSliceHeader.sps, this.firstSliceHeader.pps);
/*     */       
/* 193 */       int picWidthInMbs = this.activeSps.picWidthInMbsMinus1 + 1;
/*     */       
/* 195 */       if (this.dec.sRefs == null) {
/* 196 */         this.dec.sRefs = new Frame[1 << this.firstSliceHeader.sps.log2MaxFrameNumMinus4 + 4];
/* 197 */         this.dec.lRefs = new IntObjectMap();
/*     */       } 
/*     */       
/* 200 */       this.di = new DeblockerInput(this.activeSps);
/*     */       
/* 202 */       Frame result = H264Decoder.createFrame(this.activeSps, buffer, this.firstSliceHeader.frameNum, this.firstSliceHeader.sliceType, this.di.mvs, this.di.refsUsed, this.dec
/* 203 */           .poc.calcPOC(this.firstSliceHeader, this.firstNu));
/*     */       
/* 205 */       this.filter = new DeblockingFilter(picWidthInMbs, this.activeSps.bitDepthChromaMinus8 + 8, this.di);
/*     */       
/* 207 */       return result;
/*     */     }
/*     */     
/*     */     private void validateSupportedFeatures(SeqParameterSet sps, PictureParameterSet pps) {
/* 211 */       if (sps.mbAdaptiveFrameFieldFlag)
/* 212 */         throw new RuntimeException("Unsupported h264 feature: MBAFF."); 
/* 213 */       if (sps.bitDepthLumaMinus8 != 0 || sps.bitDepthChromaMinus8 != 0)
/* 214 */         throw new RuntimeException("Unsupported h264 feature: High bit depth."); 
/* 215 */       if (sps.chromaFormatIdc != ColorSpace.YUV420J)
/* 216 */         throw new RuntimeException("Unsupported h264 feature: " + sps.chromaFormatIdc + " color."); 
/* 217 */       if (!sps.frameMbsOnlyFlag || sps.fieldPicFlag)
/* 218 */         throw new RuntimeException("Unsupported h264 feature: interlace."); 
/* 219 */       if (pps.constrainedIntraPredFlag) {
/* 220 */         throw new RuntimeException("Unsupported h264 feature: constrained intra prediction.");
/*     */       }
/*     */       
/* 223 */       if (sps.qpprimeYZeroTransformBypassFlag)
/* 224 */         throw new RuntimeException("Unsupported h264 feature: qprime zero transform bypass."); 
/* 225 */       if (sps.profileIdc != 66 && sps.profileIdc != 77 && sps.profileIdc != 100)
/* 226 */         throw new RuntimeException("Unsupported h264 feature: " + sps.profileIdc + " profile."); 
/*     */     }
/*     */     
/*     */     public void performIDRMarking(RefPicMarkingIDR refPicMarkingIDR, Frame picture) {
/* 230 */       clearAll();
/* 231 */       this.dec.pictureBuffer.clear();
/*     */       
/* 233 */       Frame saved = saveRef(picture);
/* 234 */       if (refPicMarkingIDR.isUseForlongTerm()) {
/* 235 */         this.dec.lRefs.put(0, saved);
/* 236 */         saved.setShortTerm(false);
/*     */       } else {
/* 238 */         this.dec.sRefs[this.firstSliceHeader.frameNum] = saved;
/*     */       } 
/*     */     }
/*     */     private Frame saveRef(Frame decoded) {
/* 242 */       Frame frame = (this.dec.pictureBuffer.size() > 0) ? this.dec.pictureBuffer.remove(0) : Frame.createFrame(decoded);
/* 243 */       frame.copyFromFrame(decoded);
/* 244 */       return frame;
/*     */     }
/*     */     
/*     */     private void releaseRef(Frame picture) {
/* 248 */       if (picture != null) {
/* 249 */         this.dec.pictureBuffer.add(picture);
/*     */       }
/*     */     }
/*     */     
/*     */     public void clearAll() {
/* 254 */       for (int i = 0; i < this.dec.sRefs.length; i++) {
/* 255 */         releaseRef(this.dec.sRefs[i]);
/* 256 */         this.dec.sRefs[i] = null;
/*     */       } 
/* 258 */       int[] keys = this.dec.lRefs.keys();
/* 259 */       for (int j = 0; j < keys.length; j++) {
/* 260 */         releaseRef((Frame)this.dec.lRefs.get(keys[j]));
/*     */       }
/* 262 */       this.dec.lRefs.clear();
/*     */     }
/*     */     
/*     */     public void performMarking(RefPicMarking refPicMarking, Frame picture) {
/* 266 */       Frame saved = saveRef(picture);
/*     */       
/* 268 */       if (refPicMarking != null) {
/* 269 */         RefPicMarking.Instruction[] instructions = refPicMarking.getInstructions();
/* 270 */         for (int i = 0; i < instructions.length; i++) {
/* 271 */           RefPicMarking.Instruction instr = instructions[i];
/* 272 */           switch (instr.getType()) {
/*     */             case REMOVE_SHORT:
/* 274 */               unrefShortTerm(instr.getArg1());
/*     */               break;
/*     */             case REMOVE_LONG:
/* 277 */               unrefLongTerm(instr.getArg1());
/*     */               break;
/*     */             case CONVERT_INTO_LONG:
/* 280 */               convert(instr.getArg1(), instr.getArg2());
/*     */               break;
/*     */             case TRUNK_LONG:
/* 283 */               truncateLongTerm(instr.getArg1() - 1);
/*     */               break;
/*     */             case CLEAR:
/* 286 */               clearAll();
/*     */               break;
/*     */             case MARK_LONG:
/* 289 */               saveLong(saved, instr.getArg1());
/* 290 */               saved = null; break;
/*     */           } 
/*     */         } 
/*     */       } 
/* 294 */       if (saved != null) {
/* 295 */         saveShort(saved);
/*     */       }
/* 297 */       int maxFrames = 1 << this.activeSps.log2MaxFrameNumMinus4 + 4;
/* 298 */       if (refPicMarking == null) {
/* 299 */         int maxShort = Math.max(1, this.activeSps.numRefFrames - this.dec.lRefs.size());
/* 300 */         int min = Integer.MAX_VALUE, num = 0, minFn = 0;
/* 301 */         for (int i = 0; i < this.dec.sRefs.length; i++) {
/* 302 */           if (this.dec.sRefs[i] != null) {
/* 303 */             int fnWrap = unwrap(this.firstSliceHeader.frameNum, this.dec.sRefs[i].getFrameNo(), maxFrames);
/* 304 */             if (fnWrap < min) {
/* 305 */               min = fnWrap;
/* 306 */               minFn = this.dec.sRefs[i].getFrameNo();
/*     */             } 
/* 308 */             num++;
/*     */           } 
/*     */         } 
/* 311 */         if (num > maxShort) {
/* 312 */           releaseRef(this.dec.sRefs[minFn]);
/* 313 */           this.dec.sRefs[minFn] = null;
/*     */         } 
/*     */       } 
/*     */     }
/*     */     
/*     */     private int unwrap(int thisFrameNo, int refFrameNo, int maxFrames) {
/* 319 */       return (refFrameNo > thisFrameNo) ? (refFrameNo - maxFrames) : refFrameNo;
/*     */     }
/*     */     
/*     */     private void saveShort(Frame saved) {
/* 323 */       this.dec.sRefs[this.firstSliceHeader.frameNum] = saved;
/*     */     }
/*     */     
/*     */     private void saveLong(Frame saved, int longNo) {
/* 327 */       Frame prev = (Frame)this.dec.lRefs.get(longNo);
/* 328 */       if (prev != null)
/* 329 */         releaseRef(prev); 
/* 330 */       saved.setShortTerm(false);
/*     */       
/* 332 */       this.dec.lRefs.put(longNo, saved);
/*     */     }
/*     */     
/*     */     private void truncateLongTerm(int maxLongNo) {
/* 336 */       int[] keys = this.dec.lRefs.keys();
/* 337 */       for (int i = 0; i < keys.length; i++) {
/* 338 */         if (keys[i] > maxLongNo) {
/* 339 */           releaseRef((Frame)this.dec.lRefs.get(keys[i]));
/* 340 */           this.dec.lRefs.remove(keys[i]);
/*     */         } 
/*     */       } 
/*     */     }
/*     */     
/*     */     private void convert(int shortNo, int longNo) {
/* 346 */       int ind = MathUtil.wrap(this.firstSliceHeader.frameNum - shortNo, 1 << this.firstSliceHeader.sps.log2MaxFrameNumMinus4 + 4);
/*     */       
/* 348 */       releaseRef((Frame)this.dec.lRefs.get(longNo));
/* 349 */       this.dec.lRefs.put(longNo, this.dec.sRefs[ind]);
/* 350 */       this.dec.sRefs[ind] = null;
/* 351 */       ((Frame)this.dec.lRefs.get(longNo)).setShortTerm(false);
/*     */     }
/*     */     
/*     */     private void unrefLongTerm(int longNo) {
/* 355 */       releaseRef((Frame)this.dec.lRefs.get(longNo));
/* 356 */       this.dec.lRefs.remove(longNo);
/*     */     }
/*     */     
/*     */     private void unrefShortTerm(int shortNo) {
/* 360 */       int ind = MathUtil.wrap(this.firstSliceHeader.frameNum - shortNo, 1 << this.firstSliceHeader.sps.log2MaxFrameNumMinus4 + 4);
/*     */       
/* 362 */       releaseRef(this.dec.sRefs[ind]);
/* 363 */       this.dec.sRefs[ind] = null;
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   public static Frame createFrame(SeqParameterSet sps, byte[][] buffer, int frameNum, SliceType frameType, H264Utils.MvList2D mvs, Frame[][][] refsUsed, int POC) {
/* 369 */     int width = sps.picWidthInMbsMinus1 + 1 << 4;
/* 370 */     int height = SeqParameterSet.getPicHeightInMbs(sps) << 4;
/*     */     
/* 372 */     Rect crop = null;
/* 373 */     if (sps.frameCroppingFlag) {
/* 374 */       int sX = sps.frameCropLeftOffset << 1;
/* 375 */       int sY = sps.frameCropTopOffset << 1;
/* 376 */       int w = width - (sps.frameCropRightOffset << 1) - sX;
/* 377 */       int h = height - (sps.frameCropBottomOffset << 1) - sY;
/* 378 */       crop = new Rect(sX, sY, w, h);
/*     */     } 
/* 380 */     return new Frame(width, height, buffer, ColorSpace.YUV420, crop, frameNum, frameType, mvs, refsUsed, POC);
/*     */   }
/*     */   
/*     */   public void addSps(List<ByteBuffer> spsList) {
/* 384 */     this.reader.addSpsList(spsList);
/*     */   }
/*     */   
/*     */   public void addPps(List<ByteBuffer> ppsList) {
/* 388 */     this.reader.addPpsList(ppsList);
/*     */   }
/*     */   
/*     */   @UsedViaReflection
/*     */   public static int probe(ByteBuffer data) {
/* 393 */     boolean validSps = false, validPps = false, validSh = false;
/* 394 */     for (ByteBuffer nalUnit : H264Utils.splitFrame(data.duplicate())) {
/* 395 */       NALUnit marker = NALUnit.read(nalUnit);
/* 396 */       if (marker.type == NALUnitType.IDR_SLICE || marker.type == NALUnitType.NON_IDR_SLICE) {
/* 397 */         BitReader reader = BitReader.createBitReader(nalUnit);
/* 398 */         validSh = validSh(SliceHeaderReader.readPart1(reader)); break;
/*     */       } 
/* 400 */       if (marker.type == NALUnitType.SPS) {
/* 401 */         validSps = validSps(SeqParameterSet.read(nalUnit)); continue;
/* 402 */       }  if (marker.type == NALUnitType.PPS) {
/* 403 */         validPps = validPps(PictureParameterSet.read(nalUnit));
/*     */       }
/*     */     } 
/*     */     
/* 407 */     return (validSh ? 60 : 0) + (validSps ? 20 : 0) + (validPps ? 20 : 0);
/*     */   }
/*     */   
/*     */   private static boolean validSh(SliceHeader sh) {
/* 411 */     return (sh.firstMbInSlice == 0 && sh.sliceType != null && sh.picParameterSetId < 2);
/*     */   }
/*     */   
/*     */   private static boolean validSps(SeqParameterSet sps) {
/* 415 */     return (sps.bitDepthChromaMinus8 < 4 && sps.bitDepthLumaMinus8 < 4 && sps.chromaFormatIdc != null && sps.seqParameterSetId < 2 && sps.picOrderCntType <= 2);
/*     */   }
/*     */ 
/*     */   
/*     */   private static boolean validPps(PictureParameterSet pps) {
/* 420 */     return (pps.picInitQpMinus26 <= 26 && pps.seqParameterSetId <= 2 && pps.picParameterSetId <= 2);
/*     */   }
/*     */ 
/*     */   
/*     */   public VideoCodecMeta getCodecMeta(ByteBuffer data) {
/* 425 */     List<ByteBuffer> rawSPS = H264Utils.getRawSPS(data.duplicate());
/* 426 */     List<ByteBuffer> rawPPS = H264Utils.getRawPPS(data.duplicate());
/* 427 */     if (rawSPS.size() == 0) {
/* 428 */       Logger.warn("Can not extract metadata from the packet not containing an SPS.");
/* 429 */       return null;
/*     */     } 
/* 431 */     SeqParameterSet sps = SeqParameterSet.read(rawSPS.get(0));
/* 432 */     Size size = H264Utils.getPicSize(sps);
/*     */     
/* 434 */     return VideoCodecMeta.createSimpleVideoCodecMeta(size, ColorSpace.YUV420);
/*     */   }
/*     */ }


/* Location:              C:\Users\rapha\Downloads\aurora.jar!\META-INF\jars\jcodec-0.2.5.jar!\org\jcodec\codecs\h264\H264Decoder.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */