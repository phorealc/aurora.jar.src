/*     */ package org.jcodec.codecs.h264;
/*     */ 
/*     */ import java.util.Arrays;
/*     */ import org.jcodec.codecs.h264.io.model.MBType;
/*     */ import org.jcodec.common.io.VLC;
/*     */ import org.jcodec.common.io.VLCBuilder;
/*     */ import org.jcodec.common.model.Picture;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class H264Const
/*     */ {
/*  23 */   public static final VLC[] CoeffToken = new VLC[10];
/*     */   
/*     */   public static final VLC coeffTokenChromaDCY420;
/*     */   public static final VLC coeffTokenChromaDCY422;
/*     */   
/*     */   static {
/*  29 */     VLCBuilder vbl = new VLCBuilder();
/*     */     
/*  31 */     vbl.set(0, "1");
/*     */     
/*  33 */     vbl.set(coeffToken(1, 0), "000101");
/*  34 */     vbl.set(coeffToken(1, 1), "01");
/*  35 */     vbl.set(coeffToken(2, 0), "00000111");
/*  36 */     vbl.set(coeffToken(2, 1), "000100");
/*  37 */     vbl.set(coeffToken(2, 2), "001");
/*  38 */     vbl.set(coeffToken(3, 0), "000000111");
/*  39 */     vbl.set(coeffToken(3, 1), "00000110");
/*  40 */     vbl.set(coeffToken(3, 2), "0000101");
/*  41 */     vbl.set(coeffToken(3, 3), "00011");
/*  42 */     vbl.set(coeffToken(4, 0), "0000000111");
/*  43 */     vbl.set(coeffToken(4, 1), "000000110");
/*  44 */     vbl.set(coeffToken(4, 2), "00000101");
/*  45 */     vbl.set(coeffToken(4, 3), "000011");
/*  46 */     vbl.set(coeffToken(5, 0), "00000000111");
/*  47 */     vbl.set(coeffToken(5, 1), "0000000110");
/*  48 */     vbl.set(coeffToken(5, 2), "000000101");
/*  49 */     vbl.set(coeffToken(5, 3), "0000100");
/*  50 */     vbl.set(coeffToken(6, 0), "0000000001111");
/*  51 */     vbl.set(coeffToken(6, 1), "00000000110");
/*  52 */     vbl.set(coeffToken(6, 2), "0000000101");
/*  53 */     vbl.set(coeffToken(6, 3), "00000100");
/*  54 */     vbl.set(coeffToken(7, 0), "0000000001011");
/*  55 */     vbl.set(coeffToken(7, 1), "0000000001110");
/*  56 */     vbl.set(coeffToken(7, 2), "00000000101");
/*  57 */     vbl.set(coeffToken(7, 3), "000000100");
/*  58 */     vbl.set(coeffToken(8, 0), "0000000001000");
/*  59 */     vbl.set(coeffToken(8, 1), "0000000001010");
/*  60 */     vbl.set(coeffToken(8, 2), "0000000001101");
/*  61 */     vbl.set(coeffToken(8, 3), "0000000100");
/*  62 */     vbl.set(coeffToken(9, 0), "00000000001111");
/*  63 */     vbl.set(coeffToken(9, 1), "00000000001110");
/*  64 */     vbl.set(coeffToken(9, 2), "0000000001001");
/*  65 */     vbl.set(coeffToken(9, 3), "00000000100");
/*  66 */     vbl.set(coeffToken(10, 0), "00000000001011");
/*  67 */     vbl.set(coeffToken(10, 1), "00000000001010");
/*  68 */     vbl.set(coeffToken(10, 2), "00000000001101");
/*  69 */     vbl.set(coeffToken(10, 3), "0000000001100");
/*  70 */     vbl.set(coeffToken(11, 0), "000000000001111");
/*  71 */     vbl.set(coeffToken(11, 1), "000000000001110");
/*  72 */     vbl.set(coeffToken(11, 2), "00000000001001");
/*  73 */     vbl.set(coeffToken(11, 3), "00000000001100");
/*  74 */     vbl.set(coeffToken(12, 0), "000000000001011");
/*  75 */     vbl.set(coeffToken(12, 1), "000000000001010");
/*  76 */     vbl.set(coeffToken(12, 2), "000000000001101");
/*  77 */     vbl.set(coeffToken(12, 3), "00000000001000");
/*  78 */     vbl.set(coeffToken(13, 0), "0000000000001111");
/*  79 */     vbl.set(coeffToken(13, 1), "000000000000001");
/*  80 */     vbl.set(coeffToken(13, 2), "000000000001001");
/*  81 */     vbl.set(coeffToken(13, 3), "000000000001100");
/*  82 */     vbl.set(coeffToken(14, 0), "0000000000001011");
/*  83 */     vbl.set(coeffToken(14, 1), "0000000000001110");
/*  84 */     vbl.set(coeffToken(14, 2), "0000000000001101");
/*  85 */     vbl.set(coeffToken(14, 3), "000000000001000");
/*  86 */     vbl.set(coeffToken(15, 0), "0000000000000111");
/*  87 */     vbl.set(coeffToken(15, 1), "0000000000001010");
/*  88 */     vbl.set(coeffToken(15, 2), "0000000000001001");
/*  89 */     vbl.set(coeffToken(15, 3), "0000000000001100");
/*  90 */     vbl.set(coeffToken(16, 0), "0000000000000100");
/*  91 */     vbl.set(coeffToken(16, 1), "0000000000000110");
/*  92 */     vbl.set(coeffToken(16, 2), "0000000000000101");
/*  93 */     vbl.set(coeffToken(16, 3), "0000000000001000");
/*  94 */     CoeffToken[1] = vbl.getVLC(); CoeffToken[0] = vbl.getVLC();
/*     */ 
/*     */ 
/*     */     
/*  98 */     vbl = new VLCBuilder();
/*  99 */     vbl.set(coeffToken(0, 0), "11");
/* 100 */     vbl.set(coeffToken(1, 0), "001011");
/* 101 */     vbl.set(coeffToken(1, 1), "10");
/* 102 */     vbl.set(coeffToken(2, 0), "000111");
/* 103 */     vbl.set(coeffToken(2, 1), "00111");
/* 104 */     vbl.set(coeffToken(2, 2), "011");
/* 105 */     vbl.set(coeffToken(3, 0), "0000111");
/* 106 */     vbl.set(coeffToken(3, 1), "001010");
/* 107 */     vbl.set(coeffToken(3, 2), "001001");
/* 108 */     vbl.set(coeffToken(3, 3), "0101");
/* 109 */     vbl.set(coeffToken(4, 0), "00000111");
/* 110 */     vbl.set(coeffToken(4, 1), "000110");
/* 111 */     vbl.set(coeffToken(4, 2), "000101");
/* 112 */     vbl.set(coeffToken(4, 3), "0100");
/* 113 */     vbl.set(coeffToken(5, 0), "00000100");
/* 114 */     vbl.set(coeffToken(5, 1), "0000110");
/* 115 */     vbl.set(coeffToken(5, 2), "0000101");
/* 116 */     vbl.set(coeffToken(5, 3), "00110");
/* 117 */     vbl.set(coeffToken(6, 0), "000000111");
/* 118 */     vbl.set(coeffToken(6, 1), "00000110");
/* 119 */     vbl.set(coeffToken(6, 2), "00000101");
/* 120 */     vbl.set(coeffToken(6, 3), "001000");
/* 121 */     vbl.set(coeffToken(7, 0), "00000001111");
/* 122 */     vbl.set(coeffToken(7, 1), "000000110");
/* 123 */     vbl.set(coeffToken(7, 2), "000000101");
/* 124 */     vbl.set(coeffToken(7, 3), "000100");
/* 125 */     vbl.set(coeffToken(8, 0), "00000001011");
/* 126 */     vbl.set(coeffToken(8, 1), "00000001110");
/* 127 */     vbl.set(coeffToken(8, 2), "00000001101");
/* 128 */     vbl.set(coeffToken(8, 3), "0000100");
/* 129 */     vbl.set(coeffToken(9, 0), "000000001111");
/* 130 */     vbl.set(coeffToken(9, 1), "00000001010");
/* 131 */     vbl.set(coeffToken(9, 2), "00000001001");
/* 132 */     vbl.set(coeffToken(9, 3), "000000100");
/* 133 */     vbl.set(coeffToken(10, 0), "000000001011");
/* 134 */     vbl.set(coeffToken(10, 1), "000000001110");
/* 135 */     vbl.set(coeffToken(10, 2), "000000001101");
/* 136 */     vbl.set(coeffToken(10, 3), "00000001100");
/* 137 */     vbl.set(coeffToken(11, 0), "000000001000");
/* 138 */     vbl.set(coeffToken(11, 1), "000000001010");
/* 139 */     vbl.set(coeffToken(11, 2), "000000001001");
/* 140 */     vbl.set(coeffToken(11, 3), "00000001000");
/* 141 */     vbl.set(coeffToken(12, 0), "0000000001111");
/* 142 */     vbl.set(coeffToken(12, 1), "0000000001110");
/* 143 */     vbl.set(coeffToken(12, 2), "0000000001101");
/* 144 */     vbl.set(coeffToken(12, 3), "000000001100");
/* 145 */     vbl.set(coeffToken(13, 0), "0000000001011");
/* 146 */     vbl.set(coeffToken(13, 1), "0000000001010");
/* 147 */     vbl.set(coeffToken(13, 2), "0000000001001");
/* 148 */     vbl.set(coeffToken(13, 3), "0000000001100");
/* 149 */     vbl.set(coeffToken(14, 0), "0000000000111");
/* 150 */     vbl.set(coeffToken(14, 1), "00000000001011");
/* 151 */     vbl.set(coeffToken(14, 2), "0000000000110");
/* 152 */     vbl.set(coeffToken(14, 3), "0000000001000");
/* 153 */     vbl.set(coeffToken(15, 0), "00000000001001");
/* 154 */     vbl.set(coeffToken(15, 1), "00000000001000");
/* 155 */     vbl.set(coeffToken(15, 2), "00000000001010");
/* 156 */     vbl.set(coeffToken(15, 3), "0000000000001");
/* 157 */     vbl.set(coeffToken(16, 0), "00000000000111");
/* 158 */     vbl.set(coeffToken(16, 1), "00000000000110");
/* 159 */     vbl.set(coeffToken(16, 2), "00000000000101");
/* 160 */     vbl.set(coeffToken(16, 3), "00000000000100");
/* 161 */     CoeffToken[3] = vbl.getVLC(); CoeffToken[2] = vbl.getVLC();
/*     */ 
/*     */ 
/*     */     
/* 165 */     vbl = new VLCBuilder();
/*     */     
/* 167 */     vbl.set(coeffToken(0, 0), "1111");
/* 168 */     vbl.set(coeffToken(1, 0), "001111");
/* 169 */     vbl.set(coeffToken(1, 1), "1110");
/* 170 */     vbl.set(coeffToken(2, 0), "001011");
/* 171 */     vbl.set(coeffToken(2, 1), "01111");
/* 172 */     vbl.set(coeffToken(2, 2), "1101");
/* 173 */     vbl.set(coeffToken(3, 0), "001000");
/* 174 */     vbl.set(coeffToken(3, 1), "01100");
/* 175 */     vbl.set(coeffToken(3, 2), "01110");
/* 176 */     vbl.set(coeffToken(3, 3), "1100");
/* 177 */     vbl.set(coeffToken(4, 0), "0001111");
/* 178 */     vbl.set(coeffToken(4, 1), "01010");
/* 179 */     vbl.set(coeffToken(4, 2), "01011");
/* 180 */     vbl.set(coeffToken(4, 3), "1011");
/* 181 */     vbl.set(coeffToken(5, 0), "0001011");
/* 182 */     vbl.set(coeffToken(5, 1), "01000");
/* 183 */     vbl.set(coeffToken(5, 2), "01001");
/* 184 */     vbl.set(coeffToken(5, 3), "1010");
/* 185 */     vbl.set(coeffToken(6, 0), "0001001");
/* 186 */     vbl.set(coeffToken(6, 1), "001110");
/* 187 */     vbl.set(coeffToken(6, 2), "001101");
/* 188 */     vbl.set(coeffToken(6, 3), "1001");
/* 189 */     vbl.set(coeffToken(7, 0), "0001000");
/* 190 */     vbl.set(coeffToken(7, 1), "001010");
/* 191 */     vbl.set(coeffToken(7, 2), "001001");
/* 192 */     vbl.set(coeffToken(7, 3), "1000");
/* 193 */     vbl.set(coeffToken(8, 0), "00001111");
/* 194 */     vbl.set(coeffToken(8, 1), "0001110");
/* 195 */     vbl.set(coeffToken(8, 2), "0001101");
/* 196 */     vbl.set(coeffToken(8, 3), "01101");
/* 197 */     vbl.set(coeffToken(9, 0), "00001011");
/* 198 */     vbl.set(coeffToken(9, 1), "00001110");
/* 199 */     vbl.set(coeffToken(9, 2), "0001010");
/* 200 */     vbl.set(coeffToken(9, 3), "001100");
/* 201 */     vbl.set(coeffToken(10, 0), "000001111");
/* 202 */     vbl.set(coeffToken(10, 1), "00001010");
/* 203 */     vbl.set(coeffToken(10, 2), "00001101");
/* 204 */     vbl.set(coeffToken(10, 3), "0001100");
/* 205 */     vbl.set(coeffToken(11, 0), "000001011");
/* 206 */     vbl.set(coeffToken(11, 1), "000001110");
/* 207 */     vbl.set(coeffToken(11, 2), "00001001");
/* 208 */     vbl.set(coeffToken(11, 3), "00001100");
/* 209 */     vbl.set(coeffToken(12, 0), "000001000");
/* 210 */     vbl.set(coeffToken(12, 1), "000001010");
/* 211 */     vbl.set(coeffToken(12, 2), "000001101");
/* 212 */     vbl.set(coeffToken(12, 3), "00001000");
/* 213 */     vbl.set(coeffToken(13, 0), "0000001101");
/* 214 */     vbl.set(coeffToken(13, 1), "000000111");
/* 215 */     vbl.set(coeffToken(13, 2), "000001001");
/* 216 */     vbl.set(coeffToken(13, 3), "000001100");
/* 217 */     vbl.set(coeffToken(14, 0), "0000001001");
/* 218 */     vbl.set(coeffToken(14, 1), "0000001100");
/* 219 */     vbl.set(coeffToken(14, 2), "0000001011");
/* 220 */     vbl.set(coeffToken(14, 3), "0000001010");
/* 221 */     vbl.set(coeffToken(15, 0), "0000000101");
/* 222 */     vbl.set(coeffToken(15, 1), "0000001000");
/* 223 */     vbl.set(coeffToken(15, 2), "0000000111");
/* 224 */     vbl.set(coeffToken(15, 3), "0000000110");
/* 225 */     vbl.set(coeffToken(16, 0), "0000000001");
/* 226 */     vbl.set(coeffToken(16, 1), "0000000100");
/* 227 */     vbl.set(coeffToken(16, 2), "0000000011");
/* 228 */     vbl.set(coeffToken(16, 3), "0000000010");
/* 229 */     CoeffToken[7] = vbl.getVLC(); CoeffToken[6] = vbl.getVLC(); CoeffToken[5] = vbl.getVLC(); CoeffToken[4] = vbl.getVLC();
/*     */ 
/*     */ 
/*     */     
/* 233 */     vbl = new VLCBuilder();
/* 234 */     vbl.set(coeffToken(0, 0), "000011");
/* 235 */     vbl.set(coeffToken(1, 0), "000000");
/* 236 */     vbl.set(coeffToken(1, 1), "000001");
/* 237 */     vbl.set(coeffToken(2, 0), "000100");
/* 238 */     vbl.set(coeffToken(2, 1), "000101");
/* 239 */     vbl.set(coeffToken(2, 2), "000110");
/* 240 */     vbl.set(coeffToken(3, 0), "001000");
/* 241 */     vbl.set(coeffToken(3, 1), "001001");
/* 242 */     vbl.set(coeffToken(3, 2), "001010");
/* 243 */     vbl.set(coeffToken(3, 3), "001011");
/* 244 */     vbl.set(coeffToken(4, 0), "001100");
/* 245 */     vbl.set(coeffToken(4, 1), "001101");
/* 246 */     vbl.set(coeffToken(4, 2), "001110");
/* 247 */     vbl.set(coeffToken(4, 3), "001111");
/* 248 */     vbl.set(coeffToken(5, 0), "010000");
/* 249 */     vbl.set(coeffToken(5, 1), "010001");
/* 250 */     vbl.set(coeffToken(5, 2), "010010");
/* 251 */     vbl.set(coeffToken(5, 3), "010011");
/* 252 */     vbl.set(coeffToken(6, 0), "010100");
/* 253 */     vbl.set(coeffToken(6, 1), "010101");
/* 254 */     vbl.set(coeffToken(6, 2), "010110");
/* 255 */     vbl.set(coeffToken(6, 3), "010111");
/* 256 */     vbl.set(coeffToken(7, 0), "011000");
/* 257 */     vbl.set(coeffToken(7, 1), "011001");
/* 258 */     vbl.set(coeffToken(7, 2), "011010");
/* 259 */     vbl.set(coeffToken(7, 3), "011011");
/* 260 */     vbl.set(coeffToken(8, 0), "011100");
/* 261 */     vbl.set(coeffToken(8, 1), "011101");
/* 262 */     vbl.set(coeffToken(8, 2), "011110");
/* 263 */     vbl.set(coeffToken(8, 3), "011111");
/* 264 */     vbl.set(coeffToken(9, 0), "100000");
/* 265 */     vbl.set(coeffToken(9, 1), "100001");
/* 266 */     vbl.set(coeffToken(9, 2), "100010");
/* 267 */     vbl.set(coeffToken(9, 3), "100011");
/* 268 */     vbl.set(coeffToken(10, 0), "100100");
/* 269 */     vbl.set(coeffToken(10, 1), "100101");
/* 270 */     vbl.set(coeffToken(10, 2), "100110");
/* 271 */     vbl.set(coeffToken(10, 3), "100111");
/* 272 */     vbl.set(coeffToken(11, 0), "101000");
/* 273 */     vbl.set(coeffToken(11, 1), "101001");
/* 274 */     vbl.set(coeffToken(11, 2), "101010");
/* 275 */     vbl.set(coeffToken(11, 3), "101011");
/* 276 */     vbl.set(coeffToken(12, 0), "101100");
/* 277 */     vbl.set(coeffToken(12, 1), "101101");
/* 278 */     vbl.set(coeffToken(12, 2), "101110");
/* 279 */     vbl.set(coeffToken(12, 3), "101111");
/* 280 */     vbl.set(coeffToken(13, 0), "110000");
/* 281 */     vbl.set(coeffToken(13, 1), "110001");
/* 282 */     vbl.set(coeffToken(13, 2), "110010");
/* 283 */     vbl.set(coeffToken(13, 3), "110011");
/* 284 */     vbl.set(coeffToken(14, 0), "110100");
/* 285 */     vbl.set(coeffToken(14, 1), "110101");
/* 286 */     vbl.set(coeffToken(14, 2), "110110");
/* 287 */     vbl.set(coeffToken(14, 3), "110111");
/* 288 */     vbl.set(coeffToken(15, 0), "111000");
/* 289 */     vbl.set(coeffToken(15, 1), "111001");
/* 290 */     vbl.set(coeffToken(15, 2), "111010");
/* 291 */     vbl.set(coeffToken(15, 3), "111011");
/* 292 */     vbl.set(coeffToken(16, 0), "111100");
/* 293 */     vbl.set(coeffToken(16, 1), "111101");
/* 294 */     vbl.set(coeffToken(16, 2), "111110");
/* 295 */     vbl.set(coeffToken(16, 3), "111111");
/* 296 */     CoeffToken[8] = vbl.getVLC();
/*     */ 
/*     */ 
/*     */     
/* 300 */     vbl = new VLCBuilder();
/* 301 */     vbl.set(coeffToken(0, 0), "01");
/* 302 */     vbl.set(coeffToken(1, 0), "000111");
/* 303 */     vbl.set(coeffToken(1, 1), "1");
/* 304 */     vbl.set(coeffToken(2, 0), "000100");
/* 305 */     vbl.set(coeffToken(2, 1), "000110");
/* 306 */     vbl.set(coeffToken(2, 2), "001");
/* 307 */     vbl.set(coeffToken(3, 0), "000011");
/* 308 */     vbl.set(coeffToken(3, 1), "0000011");
/* 309 */     vbl.set(coeffToken(3, 2), "0000010");
/* 310 */     vbl.set(coeffToken(3, 3), "000101");
/* 311 */     vbl.set(coeffToken(4, 0), "000010");
/* 312 */     vbl.set(coeffToken(4, 1), "00000011");
/* 313 */     vbl.set(coeffToken(4, 2), "00000010");
/* 314 */     vbl.set(coeffToken(4, 3), "0000000");
/* 315 */     coeffTokenChromaDCY420 = vbl.getVLC();
/*     */ 
/*     */ 
/*     */     
/* 319 */     vbl = new VLCBuilder();
/* 320 */     vbl.set(coeffToken(0, 0), "1");
/* 321 */     vbl.set(coeffToken(1, 0), "0001111");
/* 322 */     vbl.set(coeffToken(1, 1), "01");
/* 323 */     vbl.set(coeffToken(2, 0), "0001110");
/* 324 */     vbl.set(coeffToken(2, 1), "0001101");
/* 325 */     vbl.set(coeffToken(2, 2), "001");
/* 326 */     vbl.set(coeffToken(3, 0), "000000111");
/* 327 */     vbl.set(coeffToken(3, 1), "0001100");
/* 328 */     vbl.set(coeffToken(3, 2), "0001011");
/* 329 */     vbl.set(coeffToken(3, 3), "00001");
/* 330 */     vbl.set(coeffToken(4, 0), "000000110");
/* 331 */     vbl.set(coeffToken(4, 1), "000000101");
/* 332 */     vbl.set(coeffToken(4, 2), "0001010");
/* 333 */     vbl.set(coeffToken(4, 3), "000001");
/* 334 */     vbl.set(coeffToken(5, 0), "0000000111");
/* 335 */     vbl.set(coeffToken(5, 1), "0000000110");
/* 336 */     vbl.set(coeffToken(5, 2), "000000100");
/* 337 */     vbl.set(coeffToken(5, 3), "0001001");
/* 338 */     vbl.set(coeffToken(6, 0), "00000000111");
/* 339 */     vbl.set(coeffToken(6, 1), "00000000110");
/* 340 */     vbl.set(coeffToken(6, 2), "0000000101");
/* 341 */     vbl.set(coeffToken(6, 3), "0001000");
/* 342 */     vbl.set(coeffToken(7, 0), "000000000111");
/* 343 */     vbl.set(coeffToken(7, 1), "000000000110");
/* 344 */     vbl.set(coeffToken(7, 2), "00000000101");
/* 345 */     vbl.set(coeffToken(7, 3), "0000000100");
/* 346 */     vbl.set(coeffToken(8, 0), "0000000000111");
/* 347 */     vbl.set(coeffToken(8, 1), "000000000101");
/* 348 */     vbl.set(coeffToken(8, 2), "000000000100");
/* 349 */     vbl.set(coeffToken(8, 3), "00000000100");
/* 350 */     coeffTokenChromaDCY422 = vbl.getVLC();
/*     */   }
/*     */ 
/*     */   
/* 354 */   public static final VLC[] run = new VLC[] { (new VLCBuilder())
/* 355 */       .set(0, "1").set(1, "0").getVLC(), (new VLCBuilder())
/* 356 */       .set(0, "1").set(1, "01").set(2, "00").getVLC(), (new VLCBuilder())
/* 357 */       .set(0, "11").set(1, "10").set(2, "01").set(3, "00").getVLC(), (new VLCBuilder())
/* 358 */       .set(0, "11").set(1, "10").set(2, "01").set(3, "001").set(4, "000").getVLC(), (new VLCBuilder())
/* 359 */       .set(0, "11").set(1, "10").set(2, "011").set(3, "010").set(4, "001").set(5, "000")
/* 360 */       .getVLC(), (new VLCBuilder())
/* 361 */       .set(0, "11").set(1, "000").set(2, "001").set(3, "011").set(4, "010").set(5, "101")
/* 362 */       .set(6, "100").getVLC(), (new VLCBuilder())
/* 363 */       .set(0, "111").set(1, "110").set(2, "101").set(3, "100").set(4, "011").set(5, "010")
/* 364 */       .set(6, "001").set(7, "0001").set(8, "00001").set(9, "000001").set(10, "0000001")
/* 365 */       .set(11, "00000001").set(12, "000000001").set(13, "0000000001").set(14, "00000000001").getVLC() };
/*     */ 
/*     */   
/* 368 */   public static final VLC[] totalZeros16 = new VLC[] { (new VLCBuilder())
/*     */       
/* 370 */       .set(0, "1").set(1, "011").set(2, "010").set(3, "0011").set(4, "0010").set(5, "00011")
/* 371 */       .set(6, "00010").set(7, "000011").set(8, "000010").set(9, "0000011").set(10, "0000010")
/* 372 */       .set(11, "00000011").set(12, "00000010").set(13, "000000011").set(14, "000000010")
/* 373 */       .set(15, "000000001").getVLC(), (new VLCBuilder())
/*     */       
/* 375 */       .set(0, "111").set(1, "110").set(2, "101").set(3, "100").set(4, "011").set(5, "0101")
/* 376 */       .set(6, "0100").set(7, "0011").set(8, "0010").set(9, "00011").set(10, "00010").set(11, "000011")
/* 377 */       .set(12, "000010").set(13, "000001").set(14, "000000").getVLC(), (new VLCBuilder())
/*     */       
/* 379 */       .set(0, "0101").set(1, "111").set(2, "110").set(3, "101").set(4, "0100").set(5, "0011")
/* 380 */       .set(6, "100").set(7, "011").set(8, "0010").set(9, "00011").set(10, "00010").set(11, "000001")
/* 381 */       .set(12, "00001").set(13, "000000").getVLC(), (new VLCBuilder())
/*     */       
/* 383 */       .set(0, "00011").set(1, "111").set(2, "0101").set(3, "0100").set(4, "110").set(5, "101")
/* 384 */       .set(6, "100").set(7, "0011").set(8, "011").set(9, "0010").set(10, "00010").set(11, "00001")
/* 385 */       .set(12, "00000").getVLC(), (new VLCBuilder())
/*     */       
/* 387 */       .set(0, "0101").set(1, "0100").set(2, "0011").set(3, "111").set(4, "110").set(5, "101")
/* 388 */       .set(6, "100").set(7, "011").set(8, "0010").set(9, "00001").set(10, "0001").set(11, "00000")
/* 389 */       .getVLC(), (new VLCBuilder())
/*     */       
/* 391 */       .set(0, "000001").set(1, "00001").set(2, "111").set(3, "110").set(4, "101").set(5, "100")
/* 392 */       .set(6, "011").set(7, "010").set(8, "0001").set(9, "001").set(10, "000000").getVLC(), (new VLCBuilder())
/*     */       
/* 394 */       .set(0, "000001").set(1, "00001").set(2, "101").set(3, "100").set(4, "011").set(5, "11")
/* 395 */       .set(6, "010").set(7, "0001").set(8, "001").set(9, "000000").getVLC(), (new VLCBuilder())
/*     */       
/* 397 */       .set(0, "000001").set(1, "0001").set(2, "00001").set(3, "011").set(4, "11").set(5, "10")
/* 398 */       .set(6, "010").set(7, "001").set(8, "000000").getVLC(), (new VLCBuilder())
/*     */       
/* 400 */       .set(0, "000001").set(1, "000000").set(2, "0001").set(3, "11").set(4, "10").set(5, "001")
/* 401 */       .set(6, "01").set(7, "00001").getVLC(), (new VLCBuilder())
/*     */       
/* 403 */       .set(0, "00001").set(1, "00000").set(2, "001").set(3, "11").set(4, "10").set(5, "01")
/* 404 */       .set(6, "0001").getVLC(), (new VLCBuilder())
/*     */       
/* 406 */       .set(0, "0000").set(1, "0001").set(2, "001").set(3, "010").set(4, "1").set(5, "011")
/* 407 */       .getVLC(), (new VLCBuilder())
/*     */       
/* 409 */       .set(0, "0000").set(1, "0001").set(2, "01").set(3, "1").set(4, "001").getVLC(), (new VLCBuilder())
/*     */       
/* 411 */       .set(0, "000").set(1, "001").set(2, "1").set(3, "01").getVLC(), (new VLCBuilder())
/*     */       
/* 413 */       .set(0, "00").set(1, "01").set(2, "1").getVLC(), (new VLCBuilder())
/*     */       
/* 415 */       .set(0, "0").set(1, "1").getVLC() };
/*     */   
/* 417 */   public static final VLC[] totalZeros4 = new VLC[] { (new VLCBuilder()).set(0, "1").set(1, "01").set(2, "001").set(3, "000").getVLC(), (new VLCBuilder())
/*     */       
/* 419 */       .set(0, "1").set(1, "01").set(2, "00").getVLC(), (new VLCBuilder())
/*     */       
/* 421 */       .set(0, "1").set(1, "0").getVLC() };
/*     */   
/* 423 */   public static final VLC[] totalZeros8 = new VLC[] { (new VLCBuilder())
/* 424 */       .set(0, "1").set(1, "010").set(2, "011").set(3, "0010").set(4, "0011").set(5, "0001")
/* 425 */       .set(6, "00001").set(7, "00000").getVLC(), (new VLCBuilder())
/*     */       
/* 427 */       .set(0, "000").set(1, "01").set(2, "001").set(3, "100").set(4, "101").set(5, "110")
/* 428 */       .set(6, "111").getVLC(), (new VLCBuilder())
/*     */       
/* 430 */       .set(0, "000").set(1, "001").set(2, "01").set(3, "10").set(4, "110").set(5, "111").getVLC(), (new VLCBuilder())
/*     */       
/* 432 */       .set(0, "110").set(1, "00").set(2, "01").set(3, "10").set(4, "111").getVLC(), (new VLCBuilder())
/*     */       
/* 434 */       .set(0, "00").set(1, "01").set(2, "10").set(3, "11").getVLC(), (new VLCBuilder())
/*     */       
/* 436 */       .set(0, "00").set(1, "01").set(2, "1").getVLC(), (new VLCBuilder())
/*     */       
/* 438 */       .set(0, "0").set(1, "1").getVLC() };
/*     */   
/*     */   public enum PartPred {
/* 441 */     L0, L1, Bi, Direct;
/*     */   }
/*     */   
/* 444 */   public static final PartPred[][] bPredModes = new PartPred[][] { null, { PartPred.L0 }, { PartPred.L1 }, { PartPred.Bi }, { PartPred.L0, PartPred.L0 }, { PartPred.L0, PartPred.L0 }, { PartPred.L1, PartPred.L1 }, { PartPred.L1, PartPred.L1 }, { PartPred.L0, PartPred.L1 }, { PartPred.L0, PartPred.L1 }, { PartPred.L1, PartPred.L0 }, { PartPred.L1, PartPred.L0 }, { PartPred.L0, PartPred.Bi }, { PartPred.L0, PartPred.Bi }, { PartPred.L1, PartPred.Bi }, { PartPred.L1, PartPred.Bi }, { PartPred.Bi, PartPred.L0 }, { PartPred.Bi, PartPred.L0 }, { PartPred.Bi, PartPred.L1 }, { PartPred.Bi, PartPred.L1 }, { PartPred.Bi, PartPred.Bi }, { PartPred.Bi, PartPred.Bi } };
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 452 */   public static final MBType[] bMbTypes = new MBType[] { MBType.B_Direct_16x16, MBType.B_L0_16x16, MBType.B_L1_16x16, MBType.B_Bi_16x16, MBType.B_L0_L0_16x8, MBType.B_L0_L0_8x16, MBType.B_L1_L1_16x8, MBType.B_L1_L1_8x16, MBType.B_L0_L1_16x8, MBType.B_L0_L1_8x16, MBType.B_L1_L0_16x8, MBType.B_L1_L0_8x16, MBType.B_L0_Bi_16x8, MBType.B_L0_Bi_8x16, MBType.B_L1_Bi_16x8, MBType.B_L1_Bi_8x16, MBType.B_Bi_L0_16x8, MBType.B_Bi_L0_8x16, MBType.B_Bi_L1_16x8, MBType.B_Bi_L1_8x16, MBType.B_Bi_Bi_16x8, MBType.B_Bi_Bi_8x16, MBType.B_8x8 };
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 458 */   public static final int[] bPartW = new int[] { 0, 16, 16, 16, 16, 8, 16, 8, 16, 8, 16, 8, 16, 8, 16, 8, 16, 8, 16, 8, 16, 8 };
/* 459 */   public static final int[] bPartH = new int[] { 0, 16, 16, 16, 8, 16, 8, 16, 8, 16, 8, 16, 8, 16, 8, 16, 8, 16, 8, 16, 8, 16 };
/*     */   
/* 461 */   public static final int[] BLK_X = new int[] { 0, 4, 0, 4, 8, 12, 8, 12, 0, 4, 0, 4, 8, 12, 8, 12 };
/* 462 */   public static final int[] BLK_Y = new int[] { 0, 0, 4, 4, 0, 0, 4, 4, 8, 8, 12, 12, 8, 8, 12, 12 };
/*     */   
/* 464 */   public static final int[] BLK_8x8_X = new int[] { 0, 8, 0, 8 };
/* 465 */   public static final int[] BLK_8x8_Y = new int[] { 0, 0, 8, 8 };
/*     */   
/* 467 */   public static final int[] BLK_INV_MAP = new int[] { 0, 1, 4, 5, 2, 3, 6, 7, 8, 9, 12, 13, 10, 11, 14, 15 };
/*     */   
/* 469 */   public static final int[] MB_BLK_OFF_LEFT = new int[] { 0, 1, 0, 1, 2, 3, 2, 3, 0, 1, 0, 1, 2, 3, 2, 3 };
/* 470 */   public static final int[] MB_BLK_OFF_TOP = new int[] { 0, 0, 1, 1, 0, 0, 1, 1, 2, 2, 3, 3, 2, 2, 3, 3 };
/*     */   
/* 472 */   public static final int[] QP_SCALE_CR = new int[] { 0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19, 20, 21, 22, 23, 24, 25, 26, 27, 28, 29, 29, 30, 31, 32, 32, 33, 34, 34, 35, 35, 36, 36, 37, 37, 37, 38, 38, 38, 39, 39, 39, 39 };
/*     */ 
/*     */ 
/*     */   
/* 476 */   public static final Picture NO_PIC = Picture.createPicture(0, 0, (byte[][])null, null);
/* 477 */   public static final int[] BLK_8x8_MB_OFF_LUMA = new int[] { 0, 8, 128, 136 };
/* 478 */   public static final int[] BLK_8x8_MB_OFF_CHROMA = new int[] { 0, 4, 32, 36 };
/* 479 */   public static final int[] BLK_4x4_MB_OFF_LUMA = new int[] { 0, 4, 8, 12, 64, 68, 72, 76, 128, 132, 136, 140, 192, 196, 200, 204 };
/* 480 */   public static final int[] BLK_8x8_IND = new int[] { 0, 0, 1, 1, 0, 0, 1, 1, 2, 2, 3, 3, 2, 2, 3, 3 };
/* 481 */   public static final int[][] BLK8x8_BLOCKS = new int[][] { { 0, 1, 4, 5 }, { 2, 3, 6, 7 }, { 8, 9, 12, 13 }, { 10, 11, 14, 15 } };
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 487 */   public static final int[][] ARRAY = new int[][] { { 0 }, { 1 }, { 2 }, { 3 } };
/*     */   
/* 489 */   public static final int[] CODED_BLOCK_PATTERN_INTRA_COLOR = new int[] { 47, 31, 15, 0, 23, 27, 29, 30, 7, 11, 13, 14, 39, 43, 45, 46, 16, 3, 5, 10, 12, 19, 21, 26, 28, 35, 37, 42, 44, 1, 2, 4, 8, 17, 18, 20, 24, 6, 9, 22, 25, 32, 33, 34, 36, 40, 38, 41 };
/*     */ 
/*     */ 
/*     */   
/* 493 */   public static final int[] coded_block_pattern_intra_monochrome = new int[] { 15, 0, 7, 11, 13, 14, 3, 5, 10, 12, 1, 2, 4, 8, 6, 9 };
/*     */ 
/*     */   
/* 496 */   public static final int[] CODED_BLOCK_PATTERN_INTER_COLOR = new int[] { 0, 16, 1, 2, 4, 8, 32, 3, 5, 10, 12, 15, 47, 7, 11, 13, 14, 6, 9, 31, 35, 37, 42, 44, 33, 34, 36, 40, 39, 43, 45, 46, 17, 18, 20, 24, 19, 21, 26, 28, 23, 27, 29, 30, 22, 25, 38, 41 };
/*     */ 
/*     */ 
/*     */   
/*     */   private static int[] inverse(int[] arr) {
/* 501 */     int[] inv = new int[arr.length];
/* 502 */     for (int i = 0; i < inv.length; i++) {
/* 503 */       inv[arr[i]] = i;
/*     */     }
/* 505 */     return inv;
/*     */   }
/*     */   
/* 508 */   public static final int[] CODED_BLOCK_PATTERN_INTER_COLOR_INV = inverse(CODED_BLOCK_PATTERN_INTER_COLOR);
/*     */   
/* 510 */   public static final int[] coded_block_pattern_inter_monochrome = new int[] { 0, 1, 2, 4, 8, 3, 5, 10, 12, 15, 7, 11, 13, 14, 6, 9 };
/*     */ 
/*     */   
/* 513 */   public static final int[] sig_coeff_map_8x8 = new int[] { 0, 1, 2, 3, 4, 5, 5, 4, 4, 3, 3, 4, 4, 4, 5, 5, 4, 4, 4, 4, 3, 3, 6, 7, 7, 7, 8, 9, 10, 9, 8, 7, 7, 6, 11, 12, 13, 11, 6, 7, 8, 9, 14, 10, 9, 8, 6, 11, 12, 13, 11, 6, 9, 14, 10, 9, 11, 12, 13, 11, 14, 10, 12 };
/*     */ 
/*     */ 
/*     */   
/* 517 */   public static final int[] sig_coeff_map_8x8_mbaff = new int[] { 0, 1, 1, 2, 2, 3, 3, 4, 5, 6, 7, 7, 7, 8, 4, 5, 6, 9, 10, 10, 8, 11, 12, 11, 9, 9, 10, 10, 8, 11, 12, 11, 9, 9, 10, 10, 8, 11, 12, 11, 9, 9, 10, 10, 8, 13, 13, 9, 9, 10, 10, 8, 13, 13, 9, 9, 10, 10, 14, 14, 14, 14, 14 };
/*     */ 
/*     */ 
/*     */   
/* 521 */   public static final int[] last_sig_coeff_map_8x8 = new int[] { 0, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 3, 3, 3, 3, 3, 3, 3, 3, 4, 4, 4, 4, 4, 4, 4, 4, 5, 5, 5, 5, 6, 6, 6, 6, 7, 7, 7, 7, 8, 8, 8 };
/*     */ 
/*     */ 
/*     */   
/* 525 */   public static final int[] identityMapping16 = new int[] { 0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15 };
/* 526 */   public static final int[] identityMapping4 = new int[] { 0, 1, 2, 3 };
/* 527 */   public static final PartPred[] bPartPredModes = new PartPred[] { PartPred.Direct, PartPred.L0, PartPred.L1, PartPred.Bi, PartPred.L0, PartPred.L0, PartPred.L1, PartPred.L1, PartPred.Bi, PartPred.Bi, PartPred.L0, PartPred.L1, PartPred.Bi };
/* 528 */   public static final int[] bSubMbTypes = new int[] { 0, 0, 0, 0, 1, 2, 1, 2, 1, 2, 3, 3, 3 };
/*     */   
/* 530 */   public static final int[] LUMA_4x4_BLOCK_LUT = new int[256];
/* 531 */   public static final int[] LUMA_4x4_POS_LUT = new int[256];
/* 532 */   public static final int[] LUMA_8x8_BLOCK_LUT = new int[256];
/* 533 */   public static final int[] LUMA_8x8_POS_LUT = new int[256];
/* 534 */   public static final int[] CHROMA_BLOCK_LUT = new int[64];
/* 535 */   public static final int[] CHROMA_POS_LUT = new int[64];
/*     */   
/* 537 */   public static final int[][] COMP_BLOCK_4x4_LUT = new int[][] { LUMA_4x4_BLOCK_LUT, CHROMA_BLOCK_LUT, CHROMA_BLOCK_LUT };
/* 538 */   public static final int[][] COMP_POS_4x4_LUT = new int[][] { LUMA_4x4_POS_LUT, CHROMA_POS_LUT, CHROMA_POS_LUT };
/*     */   
/* 540 */   public static final int[][] COMP_BLOCK_8x8_LUT = new int[][] { LUMA_8x8_BLOCK_LUT, CHROMA_BLOCK_LUT, CHROMA_BLOCK_LUT };
/* 541 */   public static final int[][] COMP_POS_8x8_LUT = new int[][] { LUMA_8x8_POS_LUT, CHROMA_POS_LUT, CHROMA_POS_LUT };
/*     */   static {
/* 543 */     int[] tmp = new int[16];
/*     */     int blk;
/* 545 */     for (blk = 0; blk < 16; blk++) {
/* 546 */       for (int i = 0; i < 16; i++) {
/* 547 */         tmp[i] = i;
/*     */       }
/* 549 */       putBlk(tmp, BLK_X[blk], BLK_Y[blk], 4, 4, 16, LUMA_4x4_POS_LUT);
/* 550 */       Arrays.fill(tmp, blk);
/* 551 */       putBlk(tmp, BLK_X[blk], BLK_Y[blk], 4, 4, 16, LUMA_4x4_BLOCK_LUT);
/*     */     } 
/* 553 */     for (blk = 0; blk < 4; blk++) {
/* 554 */       for (int i = 0; i < 16; i++) {
/* 555 */         tmp[i] = i;
/*     */       }
/* 557 */       putBlk(tmp, BLK_X[blk], BLK_Y[blk], 4, 4, 8, CHROMA_POS_LUT);
/* 558 */       Arrays.fill(tmp, blk);
/* 559 */       putBlk(tmp, BLK_X[blk], BLK_Y[blk], 4, 4, 8, CHROMA_BLOCK_LUT);
/*     */     } 
/* 561 */     tmp = new int[64];
/* 562 */     for (blk = 0; blk < 4; blk++) {
/* 563 */       for (int i = 0; i < 64; i++) {
/* 564 */         tmp[i] = i;
/*     */       }
/* 566 */       putBlk(tmp, BLK_8x8_X[blk], BLK_8x8_Y[blk], 8, 8, 16, LUMA_8x8_POS_LUT);
/* 567 */       Arrays.fill(tmp, blk);
/* 568 */       putBlk(tmp, BLK_8x8_X[blk], BLK_8x8_Y[blk], 8, 8, 16, LUMA_8x8_BLOCK_LUT);
/*     */     } 
/*     */   }
/*     */   
/*     */   private static void putBlk(int[] _in, int blkX, int blkY, int blkW, int blkH, int stride, int[] out) {
/* 573 */     for (int line = 0, srcOff = 0, dstOff = blkY * stride + blkX; line < blkH; line++) {
/* 574 */       for (int i = 0; i < blkW; i++)
/* 575 */         out[dstOff + i] = _in[srcOff + i]; 
/* 576 */       srcOff += blkW;
/* 577 */       dstOff += stride;
/*     */     } 
/*     */   }
/*     */   
/*     */   private static int[][] buildPixSplitMap4x4() {
/* 582 */     int[][] result = { { 0, 1, 2, 3, 16, 17, 18, 19, 32, 33, 34, 35, 48, 49, 50, 51 }, new int[16], new int[16], new int[16], new int[16], new int[16], new int[16], new int[16], new int[16], new int[16], new int[16], new int[16], new int[16], new int[16], new int[16], new int[16] };
/*     */ 
/*     */     
/* 585 */     for (int blkY = 0, blk = 0, off = 0; blkY < 4; blkY++) {
/* 586 */       for (int blkX = 0; blkX < 4; blkX++, blk++, off += 4) {
/* 587 */         for (int i = 0; i < 16; i++)
/* 588 */           result[blk][i] = result[0][i] + off; 
/*     */       } 
/* 590 */       off += 48;
/*     */     } 
/* 592 */     return result;
/*     */   }
/*     */   
/*     */   private static int[][] buildPixSplitMap2x2() {
/* 596 */     int[][] result = { { 0, 1, 2, 3, 8, 9, 10, 11, 16, 17, 18, 19, 24, 25, 26, 27 }, new int[16], new int[16], new int[16] };
/*     */     
/* 598 */     for (int blkY = 0, blk = 0, off = 0; blkY < 2; blkY++) {
/* 599 */       for (int blkX = 0; blkX < 2; blkX++, blk++, off += 4) {
/* 600 */         for (int i = 0; i < 16; i++)
/* 601 */           result[blk][i] = result[0][i] + off; 
/*     */       } 
/* 603 */       off += 24;
/*     */     } 
/* 605 */     return result;
/*     */   }
/*     */   
/*     */   public static boolean usesList(PartPred pred, int l) {
/* 609 */     return (pred == PartPred.Bi) ? true : (((pred == PartPred.L0 && l == 0) || (pred == PartPred.L1 && l == 1)));
/*     */   }
/*     */   
/*     */   public static final int coeffToken(int totalCoeff, int trailingOnes) {
/* 613 */     return totalCoeff << 4 | trailingOnes;
/*     */   }
/*     */   
/* 616 */   public static final int[][] PIX_MAP_SPLIT_4x4 = buildPixSplitMap4x4();
/* 617 */   public static final int[][] PIX_MAP_SPLIT_2x2 = buildPixSplitMap2x2();
/*     */   
/*     */   public static final int PROFILE_CAVLC_INTRA = 44;
/*     */   
/*     */   public static final int PROFILE_BASELINE = 66;
/*     */   public static final int PROFILE_MAIN = 77;
/*     */   public static final int PROFILE_EXTENDED = 88;
/*     */   public static final int PROFILE_HIGH = 100;
/*     */   public static final int PROFILE_HIGH_10 = 110;
/*     */   public static final int PROFILE_HIGH_422 = 122;
/*     */   public static final int PROFILE_HIGH_444 = 244;
/* 628 */   public static final int[] defaultScalingList4x4Intra = new int[] { 6, 13, 13, 20, 20, 20, 28, 28, 28, 28, 32, 32, 32, 37, 37, 42 };
/*     */   
/* 630 */   public static final int[] defaultScalingList4x4Inter = new int[] { 10, 14, 14, 20, 20, 20, 24, 24, 24, 24, 27, 27, 27, 30, 30, 34 };
/*     */   
/* 632 */   public static final int[] defaultScalingList8x8Intra = new int[] { 6, 10, 10, 13, 11, 13, 16, 16, 16, 16, 18, 18, 18, 18, 18, 23, 23, 23, 23, 23, 23, 25, 25, 25, 25, 25, 25, 25, 27, 27, 27, 27, 27, 27, 27, 27, 29, 29, 29, 29, 29, 29, 29, 31, 31, 31, 31, 31, 31, 33, 33, 33, 33, 33, 36, 36, 36, 36, 38, 38, 38, 40, 40, 42 };
/*     */ 
/*     */   
/* 635 */   public static final int[] defaultScalingList8x8Inter = new int[] { 9, 13, 13, 15, 13, 15, 17, 17, 17, 17, 19, 19, 19, 19, 19, 21, 21, 21, 21, 21, 21, 22, 22, 22, 22, 22, 22, 22, 24, 24, 24, 24, 24, 24, 24, 24, 25, 25, 25, 25, 25, 25, 25, 27, 27, 27, 27, 27, 27, 28, 28, 28, 28, 28, 30, 30, 30, 30, 32, 32, 32, 33, 33, 35 };
/*     */ }


/* Location:              C:\Users\rapha\Downloads\aurora.jar!\META-INF\jars\jcodec-0.2.5.jar!\org\jcodec\codecs\h264\H264Const.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */