/*    */ package org.jcodec.codecs.aac;
/*    */ 
/*    */ import java.io.IOException;
/*    */ import java.nio.ByteBuffer;
/*    */ import net.sourceforge.jaad.aac.AACException;
/*    */ import net.sourceforge.jaad.aac.Decoder;
/*    */ import net.sourceforge.jaad.aac.SampleBuffer;
/*    */ import org.jcodec.common.AudioCodecMeta;
/*    */ import org.jcodec.common.AudioDecoder;
/*    */ import org.jcodec.common.AudioFormat;
/*    */ import org.jcodec.common.UsedViaReflection;
/*    */ import org.jcodec.common.io.NIOUtils;
/*    */ import org.jcodec.common.logging.Logger;
/*    */ import org.jcodec.common.model.AudioBuffer;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class AACDecoder
/*    */   implements AudioDecoder
/*    */ {
/*    */   private Decoder decoder;
/*    */   
/*    */   public AACDecoder(ByteBuffer decoderSpecific) throws AACException {
/* 32 */     if (decoderSpecific.remaining() >= 7) {
/* 33 */       ADTSParser.Header header = ADTSParser.read(decoderSpecific);
/* 34 */       if (header != null) {
/* 35 */         decoderSpecific = ADTSParser.adtsToStreamInfo(header);
/*    */       }
/* 37 */       Logger.info("Creating AAC decoder from ADTS header.");
/*    */     } 
/* 39 */     this.decoder = new Decoder(NIOUtils.toArray(decoderSpecific));
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public AudioBuffer decodeFrame(ByteBuffer frame, ByteBuffer dst) throws IOException {
/* 45 */     ADTSParser.read(frame);
/* 46 */     SampleBuffer sampleBuffer = new SampleBuffer();
/* 47 */     this.decoder.decodeFrame(NIOUtils.toArray(frame), sampleBuffer);
/* 48 */     if (sampleBuffer.isBigEndian())
/*    */     {
/* 50 */       sampleBuffer.setBigEndian(false);
/*    */     }
/*    */     
/* 53 */     return new AudioBuffer(ByteBuffer.wrap(sampleBuffer.getData()), toAudioFormat(sampleBuffer), 0);
/*    */   }
/*    */   
/*    */   private AudioFormat toAudioFormat(SampleBuffer sampleBuffer) {
/* 57 */     return new AudioFormat(sampleBuffer.getSampleRate(), sampleBuffer.getBitsPerSample(), sampleBuffer
/* 58 */         .getChannels(), true, sampleBuffer.isBigEndian());
/*    */   }
/*    */ 
/*    */   
/*    */   public AudioCodecMeta getCodecMeta(ByteBuffer data) throws IOException {
/* 63 */     SampleBuffer sampleBuffer = new SampleBuffer();
/* 64 */     this.decoder.decodeFrame(NIOUtils.toArray(data), sampleBuffer);
/* 65 */     sampleBuffer.setBigEndian(false);
/*    */     
/* 67 */     return AudioCodecMeta.fromAudioFormat(toAudioFormat(sampleBuffer));
/*    */   }
/*    */   
/*    */   @UsedViaReflection
/*    */   public static int probe(ByteBuffer data) {
/* 72 */     if (data.remaining() < 7)
/* 73 */       return 0; 
/* 74 */     ADTSParser.Header header = ADTSParser.read(data);
/* 75 */     if (header != null)
/* 76 */       return 100; 
/* 77 */     return 0;
/*    */   }
/*    */ }


/* Location:              C:\Users\rapha\Downloads\aurora.jar!\META-INF\jars\jcodec-0.2.5.jar!\org\jcodec\codecs\aac\AACDecoder.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */