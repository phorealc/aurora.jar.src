/*     */ package org.jcodec.codecs.aac.blocks;
/*     */ 
/*     */ import org.jcodec.codecs.aac.Profile;
/*     */ import org.jcodec.codecs.prores.ProresDecoder;
/*     */ import org.jcodec.common.io.BitReader;
/*     */ import org.jcodec.common.io.VLC;
/*     */ import org.jcodec.common.io.VLCBuilder;
/*     */ import org.jcodec.common.tools.MathUtil;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class BlockICS
/*     */   extends Block
/*     */ {
/*     */   private boolean commonWindow;
/*     */   private boolean scaleFlag;
/*     */   private Profile profile;
/*     */   private int samplingIndex;
/*     */   private static VLC[] spectral;
/*  42 */   private static VLC vlc = new VLC(AACTab.ff_aac_scalefactor_code, AACTab.ff_aac_scalefactor_bits);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static {
/*  53 */     spectral = new VLC[] { VLCBuilder.createVLCBuilder(AACTab.codes1, AACTab.bits1, AACTab.codebook_vector02_idx).getVLC(), VLCBuilder.createVLCBuilder(AACTab.codes2, AACTab.bits2, AACTab.codebook_vector02_idx).getVLC(), VLCBuilder.createVLCBuilder(AACTab.codes3, AACTab.bits3, AACTab.codebook_vector02_idx).getVLC(), VLCBuilder.createVLCBuilder(AACTab.codes4, AACTab.bits4, AACTab.codebook_vector02_idx).getVLC(), VLCBuilder.createVLCBuilder(AACTab.codes5, AACTab.bits5, AACTab.codebook_vector4_idx).getVLC(), VLCBuilder.createVLCBuilder(AACTab.codes6, AACTab.bits6, AACTab.codebook_vector4_idx).getVLC(), VLCBuilder.createVLCBuilder(AACTab.codes7, AACTab.bits7, AACTab.codebook_vector6_idx).getVLC(), VLCBuilder.createVLCBuilder(AACTab.codes8, AACTab.bits8, AACTab.codebook_vector6_idx).getVLC(), VLCBuilder.createVLCBuilder(AACTab.codes9, AACTab.bits9, AACTab.codebook_vector8_idx).getVLC(), VLCBuilder.createVLCBuilder(AACTab.codes10, AACTab.bits10, AACTab.codebook_vector8_idx).getVLC(), VLCBuilder.createVLCBuilder(AACTab.codes11, AACTab.bits11, AACTab.codebook_vector10_idx).getVLC() };
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 175 */     ff_aac_pow2sf_tab = new float[428];
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 184 */     for (int i = 0; i < 428; i++)
/* 185 */       ff_aac_pow2sf_tab[i] = (float)Math.pow(2.0D, (i - 200) / 4.0D); 
/*     */   }
/*     */   float[][] ff_aac_codebook_vector_vals = new float[][] { 
/*     */       AACTab.codebook_vector0_vals, AACTab.codebook_vector0_vals, AACTab.codebook_vector10_vals, AACTab.codebook_vector10_vals, AACTab.codebook_vector4_vals, AACTab.codebook_vector4_vals, AACTab.codebook_vector10_vals, AACTab.codebook_vector10_vals, AACTab.codebook_vector10_vals, AACTab.codebook_vector10_vals, 
/* 189 */       AACTab.codebook_vector10_vals }; private static final int MAX_LTP_LONG_SFB = 40; private int windowSequence; int num_window_groups; private int[] group_len = new int[8]; int maxSfb; private int[] band_type = new int[120]; private int[] band_type_run_end = new int[120]; private int globalGain; static float[] ff_aac_pow2sf_tab; private void decodeScalefactors(BitReader _in) { int[] offset = { this.globalGain, this.globalGain - 90, 0 };
/*     */     
/* 191 */     int noise_flag = 1;
/* 192 */     String[] sf_str = { "Global gain", "Noise gain", "Intensity stereo position" };
/* 193 */     int idx = 0;
/* 194 */     for (int g = 0; g < this.num_window_groups; g++)
/* 195 */     { for (int i = 0; i < this.maxSfb; )
/* 196 */       { int run_end = this.band_type_run_end[idx];
/* 197 */         if (this.band_type[idx] == BandType.ZERO_BT.ordinal()) {
/* 198 */           for (; i < run_end; i++, idx++)
/* 199 */             this.sfs[idx] = 0.0D;  continue;
/* 200 */         }  if (this.band_type[idx] == BandType.INTENSITY_BT.ordinal() || this.band_type[idx] == BandType.INTENSITY_BT2.ordinal()) {
/* 201 */           for (; i < run_end; i++, idx++) {
/* 202 */             offset[2] = offset[2] + vlc.readVLC(_in) - 60;
/* 203 */             int clipped_offset = MathUtil.clip(offset[2], -155, 100);
/* 204 */             if (offset[2] != clipped_offset)
/* 205 */               System.out.println(String.format("Intensity stereo position clipped (%d -> %d).\nIf you heard an audible artifact, there may be a bug _in the decoder. ", new Object[] {
/*     */                       
/* 207 */                       Integer.valueOf(offset[2]), 
/* 208 */                       Integer.valueOf(clipped_offset)
/*     */                     })); 
/* 210 */             this.sfs[idx] = ff_aac_pow2sf_tab[-clipped_offset + 200];
/*     */           }  continue;
/* 212 */         }  if (this.band_type[idx] == BandType.NOISE_BT.ordinal()) {
/* 213 */           for (; i < run_end; i++, idx++) {
/* 214 */             if (noise_flag-- > 0) {
/* 215 */               offset[1] = offset[1] + _in.readNBit(9) - 256;
/*     */             } else {
/* 217 */               offset[1] = offset[1] + vlc.readVLC(_in) - 60;
/* 218 */             }  int clipped_offset = MathUtil.clip(offset[1], -100, 155);
/* 219 */             if (offset[1] != clipped_offset)
/* 220 */               System.out.println(String.format("Noise gain clipped (%d -> %d).\nIf you heard an audible artifact, there may be a bug _in the decoder. ", new Object[] {
/*     */                       
/* 222 */                       Integer.valueOf(offset[1]), Integer.valueOf(clipped_offset)
/*     */                     })); 
/* 224 */             this.sfs[idx] = -ff_aac_pow2sf_tab[clipped_offset + 200];
/*     */           }  continue;
/*     */         } 
/* 227 */         for (; i < run_end; i++, idx++)
/* 228 */         { offset[0] = offset[0] + vlc.readVLC(_in) - 60;
/* 229 */           if (offset[0] > 255) {
/* 230 */             throw new RuntimeException(String.format("%s (%d) out of range.\n", new Object[] { sf_str[0], Integer.valueOf(offset[0]) }));
/*     */           }
/* 232 */           this.sfs[idx] = -ff_aac_pow2sf_tab[offset[0] - 100 + 200]; }  }  }  }
/*     */   private static final int POW_SF2_ZERO = 200;
/*     */   private double[] sfs; private int numSwb; private int[] swbOffset; private int numWindows; private enum WindowSequence {
/*     */     ONLY_LONG_SEQUENCE, LONG_START_SEQUENCE, EIGHT_SHORT_SEQUENCE, LONG_STOP_SEQUENCE;
/*     */   } protected int parseICSInfo(BitReader _in) { _in.read1Bit(); this.windowSequence = _in.readNBit(2); int useKbWindow = _in.read1Bit(); this.num_window_groups = 1; this.group_len[0] = 1; if (this.windowSequence == WindowSequence.EIGHT_SHORT_SEQUENCE.ordinal()) { int max_sfb = _in.readNBit(4); for (int i = 0; i < 7; i++) { if (_in.read1Bit() != 0) { this.group_len[this.num_window_groups - 1] = this.group_len[this.num_window_groups - 1] + 1; } else { this.num_window_groups++; this.group_len[this.num_window_groups - 1] = 1; }  }  this.numSwb = AACTab.ff_aac_num_swb_128[this.samplingIndex]; this.swbOffset = AACTab.ff_swb_offset_128[this.samplingIndex]; this.numWindows = 8; } else { this.maxSfb = _in.readNBit(6); this.numSwb = AACTab.ff_aac_num_swb_1024[this.samplingIndex]; this.swbOffset = AACTab.ff_swb_offset_1024[this.samplingIndex]; this.numWindows = 1; int predictor_present = _in.read1Bit(); if (predictor_present != 0) if (this.profile == Profile.MAIN) { decodePrediction(_in, this.maxSfb); } else { if (this.profile == Profile.LC) throw new RuntimeException("Prediction is not allowed _in AAC-LC.\n");  int ltpPresent = _in.read1Bit(); if (ltpPresent != 0)
/*     */             decodeLtp(_in, this.maxSfb);  }   }  return 0; } private void decodePrediction(BitReader _in, int maxSfb) { if (_in.read1Bit() != 0)
/*     */       int i = _in.readNBit(5);  for (int sfb = 0; sfb < Math.min(maxSfb, AACTab.maxSfbTab[this.samplingIndex]); sfb++)
/*     */       _in.read1Bit();  } private void decodeLtp(BitReader _in, int maxSfb) { int lag = _in.readNBit(11); float coef = AACTab.ltpCoefTab[_in.readNBit(3)]; for (int sfb = 0; sfb < Math.min(maxSfb, 40); sfb++)
/*     */       _in.read1Bit();  } private void decodeBandTypes(BitReader _in) { int idx = 0; int bits = (this.windowSequence == WindowSequence.EIGHT_SHORT_SEQUENCE.ordinal()) ? 3 : 5; for (int g = 0; g < this.num_window_groups; g++) { int k = 0; while (k < this.maxSfb) { int sect_end = k; int sect_band_type = _in.readNBit(4); if (sect_band_type == 12)
/*     */           throw new RuntimeException("invalid band type");  int sect_len_incr; while ((sect_len_incr = _in.readNBit(bits)) == (1 << bits) - 1)
/*     */           sect_end += sect_len_incr;  sect_end += sect_len_incr; if (!_in.moreData() || sect_len_incr == (1 << bits) - 1)
/*     */           throw new RuntimeException("Overread");  if (sect_end > this.maxSfb)
/*     */           throw new RuntimeException(String.format("Number of bands (%d) exceeds limit (%d).\n", new Object[] { Integer.valueOf(sect_end), Integer.valueOf(this.maxSfb) }));  for (; k < sect_end; k++) { this.band_type[idx] = sect_band_type; this.band_type_run_end[idx++] = sect_end; }  }  }  } enum BandType {
/*     */     ZERO_BT, BT_1, BT_2, BT_3, BT_4, FIRST_PAIR_BT, BT_6, BT_7, BT_8, BT_9, BT_10, ESC_BT, BT_12, NOISE_BT, INTENSITY_BT2, INTENSITY_BT;
/* 246 */   } public static class Pulse { private int numPulse; private int[] pos; private int[] amp; public Pulse(int numPulse, int[] pos, int[] amp) { this.numPulse = numPulse;
/* 247 */       this.pos = pos;
/* 248 */       this.amp = amp; }
/*     */ 
/*     */     
/*     */     public int getNumPulse() {
/* 252 */       return this.numPulse;
/*     */     }
/*     */     
/*     */     public int[] getPos() {
/* 256 */       return this.pos;
/*     */     }
/*     */     
/*     */     public int[] getAmp() {
/* 260 */       return this.amp;
/*     */     } }
/*     */ 
/*     */   
/*     */   private Pulse decodePulses(BitReader _in) {
/* 265 */     int[] pos = new int[4];
/* 266 */     int[] amp = new int[4];
/*     */     
/* 268 */     int numPulse = _in.readNBit(2) + 1;
/* 269 */     int pulseSwb = _in.readNBit(6);
/* 270 */     if (pulseSwb >= this.numSwb)
/* 271 */       throw new RuntimeException("pulseSwb >= numSwb"); 
/* 272 */     pos[0] = this.swbOffset[pulseSwb];
/* 273 */     pos[0] = pos[0] + _in.readNBit(5);
/* 274 */     if (pos[0] > 1023)
/* 275 */       throw new RuntimeException("pos[0] > 1023"); 
/* 276 */     amp[0] = _in.readNBit(4);
/* 277 */     for (int i = 1; i < numPulse; i++) {
/* 278 */       pos[i] = _in.readNBit(5) + pos[i - 1];
/* 279 */       if (pos[i] > 1023)
/* 280 */         throw new RuntimeException("pos[" + i + "] > 1023"); 
/* 281 */       amp[i] = _in.readNBit(5);
/*     */     } 
/* 283 */     return new Pulse(numPulse, pos, amp);
/*     */   }
/*     */   
/*     */   public static class Tns
/*     */   {
/*     */     private int[] nFilt;
/*     */     private int[][] length;
/*     */     private int[][] order;
/*     */     private int[][] direction;
/*     */     private float[][][] coeff;
/*     */     
/*     */     public Tns(int[] nFilt, int[][] length, int[][] order, int[][] direction, float[][][] coeff) {
/* 295 */       this.nFilt = nFilt;
/* 296 */       this.length = length;
/* 297 */       this.order = order;
/* 298 */       this.direction = direction;
/* 299 */       this.coeff = coeff;
/*     */     }
/*     */   }
/*     */   
/*     */   private Tns decodeTns(BitReader _in) {
/* 304 */     int is8 = (this.windowSequence == WindowSequence.EIGHT_SHORT_SEQUENCE.ordinal()) ? 1 : 0;
/* 305 */     int tns_max_order = (is8 != 0) ? 7 : ((this.profile == Profile.MAIN) ? 20 : 12);
/* 306 */     int[] nFilt = new int[this.numWindows];
/* 307 */     int[][] length = new int[this.numWindows][2];
/* 308 */     int[][] order = new int[this.numWindows][2];
/* 309 */     int[][] direction = new int[this.numWindows][2];
/* 310 */     float[][][] coeff = new float[this.numWindows][2][1 << 5 - 2 * is8];
/* 311 */     for (int w = 0; w < this.numWindows; w++) {
/* 312 */       nFilt[w] = _in.readNBit(2 - is8); if (_in.readNBit(2 - is8) != 0) {
/* 313 */         int coefRes = _in.read1Bit();
/*     */         
/* 315 */         for (int filt = 0; filt < nFilt[w]; filt++) {
/*     */           
/* 317 */           length[w][filt] = _in.readNBit(6 - 2 * is8);
/*     */           
/* 319 */           order[w][filt] = _in.readNBit(5 - 2 * is8); if (_in.readNBit(5 - 2 * is8) > tns_max_order)
/* 320 */             throw new RuntimeException(String.format("TNS filter order %d is greater than maximum %d.\n", new Object[] {
/* 321 */                     Integer.valueOf(order[w][filt]), Integer.valueOf(tns_max_order)
/*     */                   })); 
/* 323 */           if (order[w][filt] != 0) {
/* 324 */             direction[w][filt] = _in.read1Bit();
/* 325 */             int coefCompress = _in.read1Bit();
/* 326 */             int coefLen = coefRes + 3 - coefCompress;
/* 327 */             int tmp2_idx = 2 * coefCompress + coefRes;
/*     */             
/* 329 */             for (int i = 0; i < order[w][filt]; i++)
/* 330 */               coeff[w][filt][i] = AACTab.tns_tmp2_map[tmp2_idx][_in.readNBit(coefLen)]; 
/*     */           } 
/*     */         } 
/*     */       } 
/*     */     } 
/* 335 */     return new Tns(nFilt, length, order, direction, coeff);
/*     */   }
/*     */   
/*     */   void VMUL4(float[] result, int idx, float[] v, int code, float scale) {
/* 339 */     result[idx] = v[code & 0x3] * scale;
/* 340 */     result[idx + 1] = v[code >> 2 & 0x3] * scale;
/* 341 */     result[idx + 2] = v[code >> 4 & 0x3] * scale;
/* 342 */     result[idx + 3] = v[code >> 6 & 0x3] * scale;
/*     */   }
/*     */   
/*     */   void VMUL4S(float[] result, int idx, float[] v, int code, int sign, float scale) {
/* 346 */     int nz = code >> 12;
/*     */ 
/*     */     
/* 349 */     result[idx + 0] = v[idx & 0x3] * scale;
/*     */     
/* 351 */     sign <<= nz & 0x1;
/* 352 */     nz >>= 1;
/*     */     
/* 354 */     result[idx + 1] = v[idx >> 2 & 0x3] * scale;
/*     */     
/* 356 */     sign <<= nz & 0x1;
/* 357 */     nz >>= 1;
/*     */     
/* 359 */     result[idx + 2] = v[idx >> 4 & 0x3] * scale;
/*     */     
/* 361 */     sign <<= nz & 0x1;
/* 362 */     nz >>= 1;
/*     */     
/* 364 */     result[idx + 3] = v[idx >> 6 & 0x3] * scale;
/*     */   }
/*     */   
/*     */   void VMUL2(float[] result, int idx, float[] v, int code, float scale) {
/* 368 */     result[idx] = v[code & 0xF] * scale;
/* 369 */     result[idx + 1] = v[code >> 4 & 0xF] * scale;
/*     */   }
/*     */   
/*     */   void VMUL2S(float[] result, int idx, float[] v, int code, int sign, float scale) {
/* 373 */     result[idx] = v[code & 0xF] * scale;
/* 374 */     result[idx + 1] = v[code >> 4 & 0xF] * scale;
/*     */   }
/*     */   
/*     */   private void decodeSpectrum(BitReader _in) {
/* 378 */     float[] coef = new float[1024];
/* 379 */     int idx = 0;
/*     */     
/* 381 */     for (int g = 0; g < this.num_window_groups; g++) {
/* 382 */       for (int i = 0; i < this.maxSfb; i++, idx++) {
/* 383 */         int cbt_m1 = this.band_type[idx] - 1;
/* 384 */         if (cbt_m1 < BandType.INTENSITY_BT2.ordinal() - 1 && cbt_m1 != BandType.NOISE_BT.ordinal() - 1) {
/* 385 */           float[] vq = this.ff_aac_codebook_vector_vals[cbt_m1];
/* 386 */           VLC vlc = spectral[cbt_m1];
/* 387 */           switch (cbt_m1 >> 1) {
/*     */             case 0:
/* 389 */               readBandType1And2(_in, coef, idx, g, i, vq, vlc);
/*     */               break;
/*     */             
/*     */             case 1:
/* 393 */               readBandType3And4(_in, coef, idx, g, i, vq, vlc);
/*     */               break;
/*     */             
/*     */             case 2:
/* 397 */               readBandType5And6(_in, coef, idx, g, i, vq, vlc);
/*     */               break;
/*     */             
/*     */             case 3:
/*     */             case 4:
/* 402 */               readBandType7Through10(_in, coef, idx, g, i, vq, vlc);
/*     */               break;
/*     */             default:
/* 405 */               readOther(_in, coef, idx, g, i, vq, vlc);
/*     */               break;
/*     */           } 
/*     */         } 
/*     */       } 
/*     */     } 
/*     */   }
/*     */   
/* 413 */   private void readBandType3And4(BitReader _in, float[] coef, int idx, int g, int sfb, float[] vq, VLC vlc) { int g_len = this.group_len[g];
/* 414 */     int cfo = this.swbOffset[sfb];
/* 415 */     int off_len = this.swbOffset[sfb + 1] - this.swbOffset[sfb];
/*     */     
/* 417 */     for (int group = 0; group < g_len; ) {
/* 418 */       int cf = cfo;
/* 419 */       int len = off_len;
/*     */       
/*     */       while (true) {
/* 422 */         int cb_idx = vlc.readVLC(_in);
/* 423 */         int nnz = cb_idx >> 8 & 0xF;
/* 424 */         int bits = (nnz == 0) ? 0 : _in.readNBit(nnz);
/* 425 */         VMUL4S(coef, cf, vq, cb_idx, bits, (float)this.sfs[idx]);
/* 426 */         cf += 4;
/* 427 */         len -= 4;
/* 428 */         if (len <= 0) {
/*     */           group++;
/*     */           cfo += 128;
/*     */         } 
/*     */       } 
/* 433 */     }  } private void readBandType7Through10(BitReader _in, float[] coef, int idx, int g, int sfb, float[] vq, VLC vlc) { int g_len = this.group_len[g];
/* 434 */     int cfo = this.swbOffset[sfb];
/* 435 */     int off_len = this.swbOffset[sfb + 1] - this.swbOffset[sfb];
/*     */     
/* 437 */     for (int group = 0; group < g_len; ) {
/* 438 */       int cf = cfo;
/* 439 */       int len = off_len;
/*     */       
/*     */       while (true) {
/* 442 */         int cb_idx = vlc.readVLC(_in);
/* 443 */         int nnz = cb_idx >> 8 & 0xF;
/* 444 */         int bits = (nnz == 0) ? 0 : (_in.readNBit(nnz) << cb_idx >> 12);
/* 445 */         VMUL2S(coef, cf, vq, cb_idx, bits, (float)this.sfs[idx]);
/* 446 */         cf += 2;
/* 447 */         len -= 2;
/* 448 */         if (len <= 0) {
/*     */           group++;
/*     */           cfo += 128;
/*     */         } 
/*     */       } 
/* 453 */     }  } private void readOther(BitReader _in, float[] coef, int idx, int g, int sfb, float[] vq, VLC vlc) { int g_len = this.group_len[g];
/* 454 */     int cfo = this.swbOffset[sfb];
/* 455 */     int off_len = this.swbOffset[sfb + 1] - this.swbOffset[sfb];
/*     */     
/* 457 */     for (int group = 0; group < g_len; ) {
/* 458 */       int cf = cfo;
/* 459 */       int len = off_len;
/*     */       
/*     */       while (true) {
/* 462 */         int cb_idx = vlc.readVLC(_in);
/*     */         
/* 464 */         if (cb_idx != 0) {
/* 465 */           int nnz = cb_idx >> 12;
/* 466 */           int nzt = cb_idx >> 8;
/* 467 */           int bits = _in.readNBit(nnz) << 32 - nnz;
/*     */           
/* 469 */           for (int j = 0; j < 2; j++) {
/* 470 */             if ((nzt & 1 << j) != 0) {
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */               
/* 479 */               int b = ProresDecoder.nZeros(_in.checkNBit(14) ^ 0xFFFFFFFF);
/*     */               
/* 481 */               if (b > 8) {
/* 482 */                 throw new RuntimeException("error _in spectral data, ESC overflow\n");
/*     */               }
/*     */               
/* 485 */               _in.skip(b + 1);
/* 486 */               b += 4;
/* 487 */               int n = (1 << b) + _in.readNBit(b);
/* 488 */               coef[cf++] = (MathUtil.cubeRoot(n) | bits & Integer.MIN_VALUE);
/* 489 */               bits <<= 1;
/*     */             } else {
/* 491 */               int v = (int)vq[cb_idx & 0xF];
/* 492 */               coef[cf++] = (bits & Integer.MIN_VALUE | v);
/*     */             } 
/*     */             
/* 495 */             cb_idx >>= 4;
/*     */           } 
/* 497 */           cf += 2;
/* 498 */           len += 2;
/*     */         } 
/* 500 */         if (len <= 0) {
/*     */           group++;
/*     */           cfo += 128;
/*     */         } 
/*     */       } 
/* 505 */     }  } private void readBandType1And2(BitReader _in, float[] coef, int idx, int g, int sfb, float[] vq, VLC vlc) { int g_len = this.group_len[g];
/* 506 */     int cfo = this.swbOffset[sfb];
/* 507 */     int off_len = this.swbOffset[sfb + 1] - this.swbOffset[sfb];
/*     */     
/* 509 */     for (int group = 0; group < g_len; ) {
/* 510 */       int cf = cfo;
/* 511 */       int len = off_len;
/*     */       
/*     */       while (true) {
/* 514 */         int cb_idx = vlc.readVLC(_in);
/* 515 */         VMUL4(coef, cf, vq, cb_idx, (float)this.sfs[idx]);
/* 516 */         cf += 4;
/* 517 */         len -= 4;
/* 518 */         if (len <= 0) {
/*     */           group++;
/*     */           cfo += 128;
/*     */         } 
/*     */       } 
/* 523 */     }  } private void readBandType5And6(BitReader _in, float[] coef, int idx, int g, int sfb, float[] vq, VLC vlc) { int g_len = this.group_len[g];
/* 524 */     int cfo = this.swbOffset[sfb];
/* 525 */     int off_len = this.swbOffset[sfb + 1] - this.swbOffset[sfb];
/* 526 */     for (int group = 0; group < g_len; ) {
/* 527 */       int cf = cfo;
/* 528 */       int len = off_len;
/*     */       
/*     */       while (true) {
/* 531 */         int cb_idx = vlc.readVLC(_in);
/* 532 */         VMUL2(coef, cf, vq, cb_idx, (float)this.sfs[idx]);
/* 533 */         cf += 2;
/* 534 */         len -= 2;
/* 535 */         if (len <= 0) {
/*     */           group++;
/*     */           cfo += 128;
/*     */         } 
/*     */       } 
/* 540 */     }  } public void parse(BitReader _in) { this.globalGain = _in.readNBit(8);
/*     */     
/* 542 */     if (!this.commonWindow && !this.scaleFlag) {
/* 543 */       parseICSInfo(_in);
/*     */     }
/*     */     
/* 546 */     decodeBandTypes(_in);
/* 547 */     decodeScalefactors(_in);
/*     */     
/* 549 */     int pulse_present = 0;
/*     */     
/* 551 */     if (!this.scaleFlag) {
/* 552 */       if ((pulse_present = _in.read1Bit()) != 0) {
/* 553 */         if (this.windowSequence == WindowSequence.EIGHT_SHORT_SEQUENCE.ordinal()) {
/* 554 */           throw new RuntimeException("Pulse tool not allowed _in eight short sequence.");
/*     */         }
/* 556 */         decodePulses(_in);
/*     */       }  int tns_present;
/* 558 */       if ((tns_present = _in.read1Bit()) != 0) {
/* 559 */         decodeTns(_in);
/*     */       }
/* 561 */       if (_in.read1Bit() != 0) {
/* 562 */         throw new RuntimeException("SSR is not supported");
/*     */       }
/*     */     } 
/*     */     
/* 566 */     decodeSpectrum(_in); }
/*     */ 
/*     */ }


/* Location:              C:\Users\rapha\Downloads\aurora.jar!\META-INF\jars\jcodec-0.2.5.jar!\org\jcodec\codecs\aac\blocks\BlockICS.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */