/*    */ package org.jcodec.codecs.aac.blocks;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public enum RawDataBlockType
/*    */ {
/* 11 */   TYPE_SCE, TYPE_CPE, TYPE_CCE, TYPE_LFE, TYPE_DSE, TYPE_PCE, TYPE_FIL, TYPE_END;
/*    */ }


/* Location:              C:\Users\rapha\Downloads\aurora.jar!\META-INF\jars\jcodec-0.2.5.jar!\org\jcodec\codecs\aac\blocks\RawDataBlockType.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */