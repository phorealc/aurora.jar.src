/*    */ package org.jcodec.codecs.aac.blocks;
/*    */ 
/*    */ import org.jcodec.common.io.BitReader;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class BlockCPE
/*    */   extends BlockICS
/*    */ {
/*    */   private int[] ms_mask;
/*    */   
/*    */   public void parse(BitReader _in) {
/* 22 */     int common_window = _in.read1Bit();
/* 23 */     if (common_window != 0) {
/* 24 */       parseICSInfo(_in);
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */       
/* 32 */       int ms_present = _in.readNBit(2);
/* 33 */       if (ms_present == 3)
/* 34 */         throw new RuntimeException("ms_present = 3 is reserved."); 
/* 35 */       if (ms_present != 0)
/* 36 */         decodeMidSideStereo(_in, ms_present, 0, 0); 
/*    */     } 
/* 38 */     BlockICS ics1 = new BlockICS();
/* 39 */     ics1.parse(_in);
/* 40 */     BlockICS ics2 = new BlockICS();
/* 41 */     ics2.parse(_in);
/*    */   }
/*    */ 
/*    */   
/*    */   private void decodeMidSideStereo(BitReader _in, int ms_present, int numWindowGroups, int maxSfb) {
/* 46 */     if (ms_present == 1)
/* 47 */       for (int idx = 0; idx < numWindowGroups * maxSfb; idx++)
/* 48 */         this.ms_mask[idx] = _in.read1Bit();  
/*    */   }
/*    */ }


/* Location:              C:\Users\rapha\Downloads\aurora.jar!\META-INF\jars\jcodec-0.2.5.jar!\org\jcodec\codecs\aac\blocks\BlockCPE.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */