/*     */ package org.jcodec.codecs.aac.blocks;
/*     */ 
/*     */ import org.jcodec.codecs.aac.ChannelPosition;
/*     */ import org.jcodec.common.io.BitReader;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class BlockPCE
/*     */   extends Block
/*     */ {
/*     */   private static final int MAX_ELEM_ID = 16;
/*     */   
/*     */   public static class ChannelMapping
/*     */   {
/*     */     RawDataBlockType syn_ele;
/*     */     int someInt;
/*     */     ChannelPosition position;
/*     */   }
/*     */   
/*     */   public void parse(BitReader _in) {
/*  28 */     _in.readNBit(2);
/*     */     
/*  30 */     int samplingIndex = _in.readNBit(4);
/*     */     
/*  32 */     int num_front = _in.readNBit(4);
/*  33 */     int num_side = _in.readNBit(4);
/*  34 */     int num_back = _in.readNBit(4);
/*  35 */     int num_lfe = _in.readNBit(2);
/*  36 */     int num_assoc_data = _in.readNBit(3);
/*  37 */     int num_cc = _in.readNBit(4);
/*     */     
/*  39 */     if (_in.read1Bit() != 0)
/*  40 */       _in.readNBit(4); 
/*  41 */     if (_in.read1Bit() != 0) {
/*  42 */       _in.readNBit(4);
/*     */     }
/*  44 */     if (_in.read1Bit() != 0) {
/*  45 */       _in.readNBit(3);
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*  51 */     ChannelMapping[] layout_map = new ChannelMapping[64];
/*     */     
/*  53 */     int tags = 0;
/*  54 */     decodeChannelMap(layout_map, tags, ChannelPosition.AAC_CHANNEL_FRONT, _in, num_front);
/*  55 */     tags = num_front;
/*  56 */     decodeChannelMap(layout_map, tags, ChannelPosition.AAC_CHANNEL_SIDE, _in, num_side);
/*  57 */     tags += num_side;
/*  58 */     decodeChannelMap(layout_map, tags, ChannelPosition.AAC_CHANNEL_BACK, _in, num_back);
/*  59 */     tags += num_back;
/*  60 */     decodeChannelMap(layout_map, tags, ChannelPosition.AAC_CHANNEL_LFE, _in, num_lfe);
/*  61 */     tags += num_lfe;
/*     */     
/*  63 */     _in.skip(4 * num_assoc_data);
/*     */     
/*  65 */     decodeChannelMap(layout_map, tags, ChannelPosition.AAC_CHANNEL_CC, _in, num_cc);
/*  66 */     tags += num_cc;
/*     */     
/*  68 */     _in.align();
/*     */ 
/*     */     
/*  71 */     int comment_len = _in.readNBit(8) * 8;
/*     */ 
/*     */ 
/*     */     
/*  75 */     _in.skip(comment_len);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void decodeChannelMap(ChannelMapping[] layout_map, int offset, ChannelPosition type, BitReader _in, int n) {
/*  85 */     while (n-- > 0) {
/*  86 */       RawDataBlockType syn_ele = null;
/*  87 */       switch (type) {
/*     */         case AAC_CHANNEL_FRONT:
/*     */         case AAC_CHANNEL_BACK:
/*     */         case AAC_CHANNEL_SIDE:
/*  91 */           syn_ele = RawDataBlockType.values()[_in.read1Bit()];
/*     */           break;
/*     */         case AAC_CHANNEL_CC:
/*  94 */           _in.read1Bit();
/*  95 */           syn_ele = RawDataBlockType.TYPE_CCE;
/*     */           break;
/*     */         case AAC_CHANNEL_LFE:
/*  98 */           syn_ele = RawDataBlockType.TYPE_LFE;
/*     */           break;
/*     */       } 
/* 101 */       (layout_map[offset]).syn_ele = syn_ele;
/* 102 */       (layout_map[offset]).someInt = _in.readNBit(4);
/* 103 */       (layout_map[offset]).position = type;
/* 104 */       offset++;
/*     */     } 
/*     */   }
/*     */ }


/* Location:              C:\Users\rapha\Downloads\aurora.jar!\META-INF\jars\jcodec-0.2.5.jar!\org\jcodec\codecs\aac\blocks\BlockPCE.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */