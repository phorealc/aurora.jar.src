/*    */ package org.jcodec.codecs.aac.blocks;
/*    */ 
/*    */ import org.jcodec.common.io.BitReader;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class BlockFil
/*    */   extends Block
/*    */ {
/*    */   public void parse(BitReader _in) {
/* 15 */     int num = _in.readNBit(4);
/* 16 */     if (num == 15)
/* 17 */       num += _in.readNBit(8) - 1; 
/* 18 */     if (num > 0 && 
/* 19 */       _in.skip(8 * num) != 8 * num)
/* 20 */       throw new RuntimeException("Overread"); 
/*    */   }
/*    */ }


/* Location:              C:\Users\rapha\Downloads\aurora.jar!\META-INF\jars\jcodec-0.2.5.jar!\org\jcodec\codecs\aac\blocks\BlockFil.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */