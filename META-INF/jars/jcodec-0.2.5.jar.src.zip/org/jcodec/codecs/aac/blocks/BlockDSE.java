/*    */ package org.jcodec.codecs.aac.blocks;
/*    */ 
/*    */ import org.jcodec.common.io.BitReader;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class BlockDSE
/*    */   extends Block
/*    */ {
/*    */   public void parse(BitReader _in) {
/* 17 */     int elemType = _in.readNBit(4);
/* 18 */     int byte_align = _in.read1Bit();
/* 19 */     int count = _in.readNBit(8);
/* 20 */     if (count == 255)
/* 21 */       count += _in.readNBit(8); 
/* 22 */     if (byte_align != 0) {
/* 23 */       _in.align();
/*    */     }
/* 25 */     if (_in.skip(8 * count) != 8 * count)
/* 26 */       throw new RuntimeException("Overread"); 
/*    */   }
/*    */ }


/* Location:              C:\Users\rapha\Downloads\aurora.jar!\META-INF\jars\jcodec-0.2.5.jar!\org\jcodec\codecs\aac\blocks\BlockDSE.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */