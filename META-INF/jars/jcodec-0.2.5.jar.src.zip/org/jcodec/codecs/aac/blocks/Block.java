/*    */ package org.jcodec.codecs.aac.blocks;
/*    */ 
/*    */ import org.jcodec.codecs.aac.BlockType;
/*    */ import org.jcodec.common.io.BitReader;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public abstract class Block
/*    */ {
/*    */   private BlockType type;
/*    */   
/*    */   public BlockType getType() {
/* 19 */     return this.type;
/*    */   }
/*    */   
/*    */   public abstract void parse(BitReader paramBitReader);
/*    */ }


/* Location:              C:\Users\rapha\Downloads\aurora.jar!\META-INF\jars\jcodec-0.2.5.jar!\org\jcodec\codecs\aac\blocks\Block.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */