/*    */ package org.jcodec.codecs.aac.blocks;
/*    */ 
/*    */ import org.jcodec.codecs.aac.BlockType;
/*    */ import org.jcodec.common.io.BitReader;
/*    */ import org.jcodec.common.io.VLC;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class BlockCCE
/*    */   extends Block
/*    */ {
/*    */   private int coupling_point;
/*    */   private int num_coupled;
/*    */   private BlockType[] type;
/*    */   private int[] id_select;
/*    */   private int[] ch_select;
/*    */   private int sign;
/*    */   private Object scale;
/*    */   private Object[] cce_scale;
/*    */   private BlockICS blockICS;
/*    */   private BlockICS.BandType[] bandType;
/* 37 */   static VLC vlc = new VLC(AACTab.ff_aac_scalefactor_code, AACTab.ff_aac_scalefactor_bits);
/*    */ 
/*    */   
/*    */   public BlockCCE(BlockICS.BandType[] bandType) {
/* 41 */     this.bandType = bandType;
/*    */   }
/*    */   
/*    */   public void parse(BitReader _in) {
/* 45 */     int num_gain = 0;
/* 46 */     this.coupling_point = 2 * _in.read1Bit();
/* 47 */     this.num_coupled = _in.readNBit(3); int c;
/* 48 */     for (c = 0; c <= this.num_coupled; c++) {
/* 49 */       num_gain++;
/* 50 */       this.type[c] = (_in.read1Bit() != 0) ? BlockType.TYPE_CPE : BlockType.TYPE_SCE;
/* 51 */       this.id_select[c] = _in.readNBit(4);
/* 52 */       if (this.type[c] == BlockType.TYPE_CPE) {
/* 53 */         this.ch_select[c] = _in.readNBit(2);
/* 54 */         if (this.ch_select[c] == 3)
/* 55 */           num_gain++; 
/*    */       } else {
/* 57 */         this.ch_select[c] = 2;
/*    */       } 
/* 59 */     }  this.coupling_point += _in.read1Bit() | this.coupling_point >> 1;
/*    */     
/* 61 */     this.sign = _in.read1Bit();
/* 62 */     this.scale = this.cce_scale[_in.readNBit(2)];
/*    */     
/* 64 */     this.blockICS = new BlockICS();
/* 65 */     this.blockICS.parse(_in);
/*    */     
/* 67 */     for (c = 0; c < num_gain; c++) {
/* 68 */       int idx = 0;
/* 69 */       int cge = 1;
/* 70 */       int gain = 0;
/* 71 */       if (c != 0) {
/* 72 */         cge = (this.coupling_point == CouplingPoint.AFTER_IMDCT.ordinal()) ? 1 : _in.read1Bit();
/* 73 */         gain = (cge != 0) ? (vlc.readVLC(_in) - 60) : 0;
/*    */       } 
/*    */       
/* 76 */       if (this.coupling_point != CouplingPoint.AFTER_IMDCT.ordinal()) {
/* 77 */         for (int g = 0; g < this.blockICS.num_window_groups; g++) {
/* 78 */           for (int sfb = 0; sfb < this.blockICS.maxSfb; sfb++, idx++) {
/* 79 */             if (this.bandType[idx] != BlockICS.BandType.ZERO_BT && 
/* 80 */               cge == 0) {
/* 81 */               int i = vlc.readVLC(_in) - 60;
/*    */             }
/*    */           } 
/*    */         } 
/*    */       }
/*    */     } 
/*    */   }
/*    */   
/*    */   enum CouplingPoint
/*    */   {
/* 91 */     BEFORE_TNS, BETWEEN_TNS_AND_IMDCT, UNDEF, AFTER_IMDCT;
/*    */   }
/*    */ }


/* Location:              C:\Users\rapha\Downloads\aurora.jar!\META-INF\jars\jcodec-0.2.5.jar!\org\jcodec\codecs\aac\blocks\BlockCCE.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */