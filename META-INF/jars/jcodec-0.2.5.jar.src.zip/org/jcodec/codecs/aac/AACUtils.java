/*     */ package org.jcodec.codecs.aac;
/*     */ 
/*     */ import java.nio.ByteBuffer;
/*     */ import org.jcodec.codecs.mpeg4.mp4.EsdsBox;
/*     */ import org.jcodec.common.AudioFormat;
/*     */ import org.jcodec.common.io.BitReader;
/*     */ import org.jcodec.common.model.ChannelLabel;
/*     */ import org.jcodec.containers.mp4.BoxUtil;
/*     */ import org.jcodec.containers.mp4.boxes.Box;
/*     */ import org.jcodec.containers.mp4.boxes.NodeBox;
/*     */ import org.jcodec.containers.mp4.boxes.SampleEntry;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class AACUtils
/*     */ {
/*     */   public static class AACMetadata
/*     */   {
/*     */     private AudioFormat format;
/*     */     private ChannelLabel[] labels;
/*     */     
/*     */     public AACMetadata(AudioFormat format, ChannelLabel[] labels) {
/*  31 */       this.format = format;
/*  32 */       this.labels = labels;
/*     */     }
/*     */     
/*     */     public AudioFormat getFormat() {
/*  36 */       return this.format;
/*     */     }
/*     */     
/*     */     public ChannelLabel[] getLabels() {
/*  40 */       return this.labels;
/*     */     }
/*     */   }
/*     */   
/*     */   private static int getObjectType(BitReader reader) {
/*  45 */     int objectType = reader.readNBit(5);
/*  46 */     if (objectType == ObjectType.AOT_ESCAPE.ordinal())
/*  47 */       objectType = 32 + reader.readNBit(6); 
/*  48 */     return objectType;
/*     */   }
/*     */   
/*  51 */   private static ChannelLabel[][] AAC_DEFAULT_CONFIGS = new ChannelLabel[][] { null, { ChannelLabel.MONO }, { ChannelLabel.STEREO_LEFT, ChannelLabel.STEREO_RIGHT }, { ChannelLabel.CENTER, ChannelLabel.FRONT_LEFT, ChannelLabel.FRONT_RIGHT }, { ChannelLabel.CENTER, ChannelLabel.FRONT_LEFT, ChannelLabel.FRONT_RIGHT, ChannelLabel.REAR_CENTER }, { ChannelLabel.CENTER, ChannelLabel.FRONT_LEFT, ChannelLabel.FRONT_RIGHT, ChannelLabel.REAR_LEFT, ChannelLabel.REAR_RIGHT }, { ChannelLabel.CENTER, ChannelLabel.FRONT_LEFT, ChannelLabel.FRONT_RIGHT, ChannelLabel.REAR_LEFT, ChannelLabel.REAR_RIGHT, ChannelLabel.LFE }, { ChannelLabel.CENTER, ChannelLabel.FRONT_LEFT, ChannelLabel.FRONT_RIGHT, ChannelLabel.SIDE_LEFT, ChannelLabel.SIDE_RIGHT, ChannelLabel.REAR_LEFT, ChannelLabel.REAR_RIGHT, ChannelLabel.LFE } };
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static AACMetadata parseAudioInfo(ByteBuffer privData) {
/*  66 */     BitReader reader = BitReader.createBitReader(privData);
/*     */     
/*  68 */     int objectType = getObjectType(reader);
/*  69 */     int index = reader.readNBit(4);
/*  70 */     int sampleRate = (index == 15) ? reader.readNBit(24) : AACConts.AAC_SAMPLE_RATES[index];
/*  71 */     int channelConfig = reader.readNBit(4);
/*     */     
/*  73 */     if (channelConfig == 0 || channelConfig >= AAC_DEFAULT_CONFIGS.length) {
/*  74 */       return null;
/*     */     }
/*  76 */     ChannelLabel[] channels = AAC_DEFAULT_CONFIGS[channelConfig];
/*  77 */     return new AACMetadata(new AudioFormat(sampleRate, 16, channels.length, true, false), channels);
/*     */   }
/*     */   
/*     */   public static AACMetadata getMetadata(SampleEntry mp4a) {
/*  81 */     if (!"mp4a".equals(mp4a.getFourcc()))
/*  82 */       throw new IllegalArgumentException("Not mp4a sample entry"); 
/*  83 */     ByteBuffer b = getCodecPrivate(mp4a);
/*  84 */     if (b == null) {
/*  85 */       return null;
/*     */     }
/*  87 */     return parseAudioInfo(b);
/*     */   }
/*     */   
/*     */   public static ByteBuffer getCodecPrivate(SampleEntry mp4a) {
/*  91 */     Box.LeafBox b = (Box.LeafBox)NodeBox.findFirst((NodeBox)mp4a, Box.LeafBox.class, "esds");
/*  92 */     if (b == null) {
/*  93 */       b = (Box.LeafBox)NodeBox.findFirstPath((NodeBox)mp4a, Box.LeafBox.class, new String[] { null, "esds" });
/*     */     }
/*  95 */     if (b == null)
/*  96 */       return null; 
/*  97 */     EsdsBox esds = (EsdsBox)BoxUtil.as(EsdsBox.class, b);
/*  98 */     return esds.getStreamInfo();
/*     */   }
/*     */ 
/*     */   
/*     */   public static ADTSParser.Header streamInfoToADTS(ByteBuffer si, boolean crcAbsent, int numAACFrames, int frameSize) {
/* 103 */     BitReader rd = BitReader.createBitReader(si.duplicate());
/* 104 */     int objectType = rd.readNBit(5);
/* 105 */     int samplingIndex = rd.readNBit(4);
/* 106 */     int chanConfig = rd.readNBit(4);
/* 107 */     return new ADTSParser.Header(objectType, chanConfig, crcAbsent ? 1 : 0, numAACFrames, samplingIndex, 7 + frameSize);
/*     */   }
/*     */ }


/* Location:              C:\Users\rapha\Downloads\aurora.jar!\META-INF\jars\jcodec-0.2.5.jar!\org\jcodec\codecs\aac\AACUtils.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */