/*    */ package org.jcodec.codecs.aac;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class AACConts
/*    */ {
/* 12 */   public static final short[] AAC_CHANNEL_COUNT = new short[] { 0, 1, 2, 3, 4, 5, 6, 8 };
/* 13 */   public static int[] AAC_SAMPLE_RATES = new int[] { 96000, 88200, 64000, 48000, 44100, 32000, 24000, 22050, 16000, 12000, 11025, 8000, 7350 };
/*    */ }


/* Location:              C:\Users\rapha\Downloads\aurora.jar!\META-INF\jars\jcodec-0.2.5.jar!\org\jcodec\codecs\aac\AACConts.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */