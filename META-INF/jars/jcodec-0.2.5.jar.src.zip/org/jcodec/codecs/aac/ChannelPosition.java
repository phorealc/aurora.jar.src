/*    */ package org.jcodec.codecs.aac;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public enum ChannelPosition
/*    */ {
/* 11 */   AAC_CHANNEL_FRONT, AAC_CHANNEL_SIDE, AAC_CHANNEL_BACK, AAC_CHANNEL_LFE, AAC_CHANNEL_CC;
/*    */ }


/* Location:              C:\Users\rapha\Downloads\aurora.jar!\META-INF\jars\jcodec-0.2.5.jar!\org\jcodec\codecs\aac\ChannelPosition.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */