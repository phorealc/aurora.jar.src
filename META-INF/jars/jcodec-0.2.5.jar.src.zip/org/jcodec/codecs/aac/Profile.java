/*    */ package org.jcodec.codecs.aac;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public enum Profile
/*    */ {
/* 11 */   MAIN, LC, OTHER;
/*    */ }


/* Location:              C:\Users\rapha\Downloads\aurora.jar!\META-INF\jars\jcodec-0.2.5.jar!\org\jcodec\codecs\aac\Profile.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */