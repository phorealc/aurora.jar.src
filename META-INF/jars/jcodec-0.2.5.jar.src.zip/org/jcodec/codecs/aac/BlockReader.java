/*    */ package org.jcodec.codecs.aac;
/*    */ 
/*    */ import org.jcodec.codecs.aac.blocks.Block;
/*    */ import org.jcodec.common.io.BitReader;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class BlockReader
/*    */ {
/*    */   public Block nextBlock(BitReader bits) {
/* 20 */     BlockType type = BlockType.values()[(int)bits.readNBit(3)];
/* 21 */     if (type == BlockType.TYPE_END) {
/* 22 */       return null;
/*    */     }
/* 24 */     int id = bits.readNBit(4);
/*    */     
/* 26 */     return null;
/*    */   }
/*    */ }


/* Location:              C:\Users\rapha\Downloads\aurora.jar!\META-INF\jars\jcodec-0.2.5.jar!\org\jcodec\codecs\aac\BlockReader.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */