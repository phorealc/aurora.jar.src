/*     */ package org.jcodec.codecs.aac;
/*     */ 
/*     */ import java.nio.ByteBuffer;
/*     */ import org.jcodec.common.io.BitReader;
/*     */ import org.jcodec.common.io.BitWriter;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ADTSParser
/*     */ {
/*     */   public static ByteBuffer adtsToStreamInfo(Header hdr) {
/*  17 */     ByteBuffer si = ByteBuffer.allocate(2);
/*  18 */     BitWriter wr = new BitWriter(si);
/*  19 */     wr.writeNBit(hdr.getObjectType(), 5);
/*  20 */     wr.writeNBit(hdr.getSamplingIndex(), 4);
/*  21 */     wr.writeNBit(hdr.getChanConfig(), 4);
/*  22 */     wr.flush();
/*  23 */     si.clear();
/*  24 */     return si;
/*     */   }
/*     */   
/*     */   public static class Header {
/*     */     private int objectType;
/*     */     private int chanConfig;
/*     */     private int crcAbsent;
/*     */     private int numAACFrames;
/*     */     private int samplingIndex;
/*     */     private int samples;
/*     */     private int size;
/*     */     
/*     */     public Header(int object_type, int chanConfig, int crcAbsent, int numAACFrames, int samplingIndex, int size) {
/*  37 */       this.objectType = object_type;
/*  38 */       this.chanConfig = chanConfig;
/*  39 */       this.crcAbsent = crcAbsent;
/*  40 */       this.numAACFrames = numAACFrames;
/*  41 */       this.samplingIndex = samplingIndex;
/*  42 */       this.size = size;
/*     */     }
/*     */     
/*     */     public int getObjectType() {
/*  46 */       return this.objectType;
/*     */     }
/*     */     
/*     */     public int getChanConfig() {
/*  50 */       return this.chanConfig;
/*     */     }
/*     */     
/*     */     public int getCrcAbsent() {
/*  54 */       return this.crcAbsent;
/*     */     }
/*     */     
/*     */     public int getNumAACFrames() {
/*  58 */       return this.numAACFrames;
/*     */     }
/*     */     
/*     */     public int getSamplingIndex() {
/*  62 */       return this.samplingIndex;
/*     */     }
/*     */     
/*     */     public int getSamples() {
/*  66 */       return this.samples;
/*     */     }
/*     */     
/*     */     public int getSize() {
/*  70 */       return this.size;
/*     */     }
/*     */     
/*     */     public int getSampleRate() {
/*  74 */       return AACConts.AAC_SAMPLE_RATES[this.samplingIndex];
/*     */     }
/*     */   }
/*     */   
/*     */   public static Header read(ByteBuffer data) {
/*  79 */     ByteBuffer dup = data.duplicate();
/*  80 */     BitReader br = BitReader.createBitReader(dup);
/*     */ 
/*     */ 
/*     */     
/*  84 */     if (br.readNBit(12) != 4095) {
/*  85 */       return null;
/*     */     }
/*     */     
/*  88 */     int id = br.read1Bit();
/*  89 */     int layer = br.readNBit(2);
/*  90 */     int crc_abs = br.read1Bit();
/*  91 */     int aot = br.readNBit(2);
/*  92 */     int sr = br.readNBit(4);
/*  93 */     int pb = br.read1Bit();
/*  94 */     int ch = br.readNBit(3);
/*     */     
/*  96 */     int origCopy = br.read1Bit();
/*  97 */     int home = br.read1Bit();
/*     */ 
/*     */     
/* 100 */     int copy = br.read1Bit();
/* 101 */     int copyStart = br.read1Bit();
/* 102 */     int size = br.readNBit(13);
/* 103 */     if (size < 7) {
/* 104 */       return null;
/*     */     }
/* 106 */     int buffer = br.readNBit(11);
/* 107 */     int rdb = br.readNBit(2);
/* 108 */     br.stop();
/*     */     
/* 110 */     data.position(dup.position());
/*     */     
/* 112 */     return new Header(aot + 1, ch, crc_abs, rdb + 1, sr, size);
/*     */   }
/*     */   
/*     */   public static ByteBuffer write(Header header, ByteBuffer buf) {
/* 116 */     ByteBuffer data = buf.duplicate();
/* 117 */     BitWriter br = new BitWriter(data);
/*     */ 
/*     */ 
/*     */     
/* 121 */     br.writeNBit(4095, 12);
/*     */     
/* 123 */     br.write1Bit(1);
/* 124 */     br.writeNBit(0, 2);
/* 125 */     br.write1Bit(header.getCrcAbsent());
/* 126 */     br.writeNBit(header.getObjectType() - 1, 2);
/* 127 */     br.writeNBit(header.getSamplingIndex(), 4);
/* 128 */     br.write1Bit(0);
/* 129 */     br.writeNBit(header.getChanConfig(), 3);
/*     */     
/* 131 */     br.write1Bit(0);
/* 132 */     br.write1Bit(0);
/*     */ 
/*     */     
/* 135 */     br.write1Bit(0);
/* 136 */     br.write1Bit(0);
/* 137 */     br.writeNBit(header.getSize(), 13);
/*     */     
/* 139 */     br.writeNBit(0, 11);
/* 140 */     br.writeNBit(header.getNumAACFrames() - 1, 2);
/* 141 */     br.flush();
/*     */     
/* 143 */     data.flip();
/* 144 */     return data;
/*     */   }
/*     */ }


/* Location:              C:\Users\rapha\Downloads\aurora.jar!\META-INF\jars\jcodec-0.2.5.jar!\org\jcodec\codecs\aac\ADTSParser.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */