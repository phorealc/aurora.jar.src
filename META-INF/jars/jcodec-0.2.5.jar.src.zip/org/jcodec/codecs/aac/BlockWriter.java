/*    */ package org.jcodec.codecs.aac;
/*    */ 
/*    */ import org.jcodec.codecs.aac.blocks.Block;
/*    */ import org.jcodec.common.io.BitWriter;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class BlockWriter
/*    */ {
/*    */   public void nextBlock(BitWriter bits, Block block) {
/* 20 */     bits.writeNBit(block.getType().ordinal(), 3);
/*    */     
/* 22 */     if (block.getType() == BlockType.TYPE_END)
/*    */       return; 
/*    */   }
/*    */ }


/* Location:              C:\Users\rapha\Downloads\aurora.jar!\META-INF\jars\jcodec-0.2.5.jar!\org\jcodec\codecs\aac\BlockWriter.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */