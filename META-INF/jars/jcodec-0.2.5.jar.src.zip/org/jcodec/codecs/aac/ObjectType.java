/*    */ package org.jcodec.codecs.aac;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public enum ObjectType
/*    */ {
/* 11 */   AOT_NULL, AOT_AAC_MAIN,
/* 12 */   AOT_AAC_LC,
/* 13 */   AOT_AAC_SSR,
/* 14 */   AOT_AAC_LTP,
/* 15 */   AOT_SBR,
/* 16 */   AOT_AAC_SCALABLE,
/* 17 */   AOT_TWINVQ,
/* 18 */   AOT_CELP,
/* 19 */   AOT_HVXC,
/* 20 */   CRAP1, CRAP2, AOT_TTSI,
/* 21 */   AOT_MAINSYNTH,
/* 22 */   AOT_WAVESYNTH,
/* 23 */   AOT_MIDI,
/* 24 */   AOT_SAFX,
/* 25 */   AOT_ER_AAC_LC,
/* 26 */   CRAP3, AOT_ER_AAC_LTP,
/* 27 */   AOT_ER_AAC_SCALABLE,
/* 28 */   AOT_ER_TWINVQ,
/* 29 */   AOT_ER_BSAC,
/* 30 */   AOT_ER_AAC_LD,
/* 31 */   AOT_ER_CELP,
/* 32 */   AOT_ER_HVXC,
/* 33 */   AOT_ER_HILN,
/*    */   
/* 35 */   AOT_ER_PARAM,
/* 36 */   AOT_SSC,
/* 37 */   AOT_PS,
/* 38 */   AOT_SURROUND,
/* 39 */   AOT_ESCAPE,
/* 40 */   AOT_L1,
/* 41 */   AOT_L2,
/* 42 */   AOT_L3,
/* 43 */   AOT_DST,
/* 44 */   AOT_ALS,
/* 45 */   AOT_SLS,
/* 46 */   AOT_SLS_NON_CORE,
/* 47 */   AOT_ER_AAC_ELD,
/* 48 */   AOT_SMR_SIMPLE,
/* 49 */   AOT_SMR_MAIN,
/* 50 */   AOT_USAC_NOSBR,
/* 51 */   AOT_SAOC,
/* 52 */   AOT_LD_SURROUND,
/* 53 */   AOT_USAC;
/*    */ }


/* Location:              C:\Users\rapha\Downloads\aurora.jar!\META-INF\jars\jcodec-0.2.5.jar!\org\jcodec\codecs\aac\ObjectType.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */