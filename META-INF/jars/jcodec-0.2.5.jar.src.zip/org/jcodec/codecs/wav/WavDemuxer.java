/*    */ package org.jcodec.codecs.wav;
/*    */ 
/*    */ import java.io.IOException;
/*    */ import java.nio.ByteBuffer;
/*    */ import java.nio.channels.ReadableByteChannel;
/*    */ import java.util.ArrayList;
/*    */ import java.util.List;
/*    */ import org.jcodec.common.AudioCodecMeta;
/*    */ import org.jcodec.common.AudioFormat;
/*    */ import org.jcodec.common.Codec;
/*    */ import org.jcodec.common.Demuxer;
/*    */ import org.jcodec.common.DemuxerTrack;
/*    */ import org.jcodec.common.DemuxerTrackMeta;
/*    */ import org.jcodec.common.TrackType;
/*    */ import org.jcodec.common.io.NIOUtils;
/*    */ import org.jcodec.common.io.SeekableByteChannel;
/*    */ import org.jcodec.common.model.Packet;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class WavDemuxer
/*    */   implements Demuxer, DemuxerTrack
/*    */ {
/*    */   private static final int FRAMES_PER_PKT = 1024;
/*    */   private SeekableByteChannel ch;
/*    */   private WavHeader header;
/*    */   private long dataSize;
/*    */   private short frameSize;
/*    */   private int frameNo;
/*    */   private long pts;
/*    */   
/*    */   public WavDemuxer(SeekableByteChannel ch) throws IOException {
/* 42 */     this.ch = ch;
/* 43 */     this.header = WavHeader.readChannel((ReadableByteChannel)ch);
/* 44 */     this.dataSize = ch.size() - ch.position();
/* 45 */     this.frameSize = this.header.getFormat().getFrameSize();
/*    */   }
/*    */ 
/*    */   
/*    */   public void close() throws IOException {
/* 50 */     this.ch.close();
/*    */   }
/*    */ 
/*    */   
/*    */   public Packet nextFrame() throws IOException {
/* 55 */     ByteBuffer data = NIOUtils.fetchFromChannel((ReadableByteChannel)this.ch, this.frameSize * 1024);
/* 56 */     if (!data.hasRemaining())
/* 57 */       return null; 
/* 58 */     long oldPts = this.pts;
/* 59 */     int duration = data.remaining() / this.frameSize;
/* 60 */     this.pts += duration;
/* 61 */     return Packet.createPacket(data, oldPts, this.header.getFormat().getFrameRate(), (data.remaining() / this.frameSize), this.frameNo++, Packet.FrameType.KEY, null);
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public DemuxerTrackMeta getMeta() {
/* 67 */     AudioFormat format = this.header.getFormat();
/* 68 */     AudioCodecMeta audioCodecMeta = AudioCodecMeta.fromAudioFormat(format);
/* 69 */     long totalFrames = this.dataSize / format.getFrameSize();
/* 70 */     return new DemuxerTrackMeta(TrackType.AUDIO, Codec.PCM, totalFrames / format.getFrameRate(), null, (int)totalFrames, null, null, audioCodecMeta);
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public List<? extends DemuxerTrack> getTracks() {
/* 76 */     List<DemuxerTrack> result = new ArrayList<DemuxerTrack>();
/* 77 */     result.add(this);
/* 78 */     return result;
/*    */   }
/*    */ 
/*    */   
/*    */   public List<? extends DemuxerTrack> getVideoTracks() {
/* 83 */     List<DemuxerTrack> result = new ArrayList<DemuxerTrack>();
/* 84 */     return result;
/*    */   }
/*    */ 
/*    */   
/*    */   public List<? extends DemuxerTrack> getAudioTracks() {
/* 89 */     return getTracks();
/*    */   }
/*    */ }


/* Location:              C:\Users\rapha\Downloads\aurora.jar!\META-INF\jars\jcodec-0.2.5.jar!\org\jcodec\codecs\wav\WavDemuxer.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */