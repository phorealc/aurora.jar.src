/*     */ package org.jcodec.codecs.wav;
/*     */ 
/*     */ import java.io.Closeable;
/*     */ import java.io.File;
/*     */ import java.io.IOException;
/*     */ import java.nio.ByteBuffer;
/*     */ import java.nio.FloatBuffer;
/*     */ import java.nio.channels.ReadableByteChannel;
/*     */ import org.jcodec.audio.AudioSource;
/*     */ import org.jcodec.common.AudioFormat;
/*     */ import org.jcodec.common.AudioUtil;
/*     */ import org.jcodec.common.io.NIOUtils;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class WavInput
/*     */   implements Closeable
/*     */ {
/*     */   protected WavHeader header;
/*     */   protected byte[] prevBuf;
/*     */   protected ReadableByteChannel _in;
/*     */   protected AudioFormat format;
/*     */   
/*     */   public WavInput(ReadableByteChannel _in) throws IOException {
/*  30 */     this.header = WavHeader.readChannel(_in);
/*  31 */     this.format = this.header.getFormat();
/*  32 */     this._in = _in;
/*     */   }
/*     */   
/*     */   public int read(ByteBuffer buf) throws IOException {
/*  36 */     int maxRead = this.format.framesToBytes(this.format.bytesToFrames(buf.remaining()));
/*  37 */     return NIOUtils.readL(this._in, buf, maxRead);
/*     */   }
/*     */   
/*     */   public void close() throws IOException {
/*  41 */     this._in.close();
/*     */   }
/*     */   
/*     */   public WavHeader getHeader() {
/*  45 */     return this.header;
/*     */   }
/*     */   
/*     */   public AudioFormat getFormat() {
/*  49 */     return this.format;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public static class WavFile
/*     */     extends WavInput
/*     */   {
/*     */     public WavFile(File f) throws IOException {
/*  58 */       super((ReadableByteChannel)NIOUtils.readableChannel(f));
/*     */     }
/*     */ 
/*     */     
/*     */     public void close() throws IOException {
/*  63 */       super.close();
/*  64 */       this._in.close();
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   public static class Source
/*     */     implements AudioSource, Closeable
/*     */   {
/*     */     private WavInput src;
/*     */     
/*     */     private AudioFormat format;
/*     */     private int pos;
/*     */     
/*     */     public Source(WavInput src) {
/*  78 */       this.src = src;
/*  79 */       this.format = src.getFormat();
/*     */     }
/*     */     
/*     */     public AudioFormat getFormat() {
/*  83 */       return this.src.getFormat();
/*     */     }
/*     */     
/*     */     public void close() throws IOException {
/*  87 */       this.src.close();
/*     */     }
/*     */ 
/*     */     
/*     */     public int read(int[] samples, int max) throws IOException {
/*  92 */       max = Math.min(max, samples.length);
/*     */       
/*  94 */       ByteBuffer bb = ByteBuffer.allocate(this.format.samplesToBytes(max));
/*  95 */       int read = this.src.read(bb);
/*  96 */       bb.flip();
/*  97 */       AudioUtil.toInt(this.format, bb, samples);
/*  98 */       return this.format.bytesToFrames(read);
/*     */     }
/*     */     
/*     */     public int readFloat(FloatBuffer samples) throws IOException {
/* 102 */       ByteBuffer bb = ByteBuffer.allocate(this.format.samplesToBytes(samples.remaining()));
/* 103 */       int i = this.src.read(bb);
/* 104 */       if (i == -1)
/* 105 */         return -1; 
/* 106 */       bb.flip();
/* 107 */       AudioUtil.toFloat(this.format, bb, samples);
/* 108 */       int read = this.format.bytesToFrames(i);
/* 109 */       this.pos += read;
/*     */       
/* 111 */       return read;
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\rapha\Downloads\aurora.jar!\META-INF\jars\jcodec-0.2.5.jar!\org\jcodec\codecs\wav\WavInput.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */