/*    */ package org.jcodec.codecs.wav;
/*    */ 
/*    */ import java.io.IOException;
/*    */ import java.io.InputStream;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public abstract class ReaderLE
/*    */ {
/*    */   public static short readShort(InputStream input) throws IOException {
/* 15 */     int b2 = input.read();
/* 16 */     int b1 = input.read();
/*    */     
/* 18 */     if (b1 == -1 || b2 == -1) {
/* 19 */       return -1;
/*    */     }
/* 21 */     return (short)((b1 << 8) + b2);
/*    */   }
/*    */   
/*    */   public static int readInt(InputStream input) throws IOException {
/* 25 */     long b4 = input.read();
/* 26 */     long b3 = input.read();
/* 27 */     long b2 = input.read();
/* 28 */     long b1 = input.read();
/*    */     
/* 30 */     if (b1 == -1L || b2 == -1L || b3 == -1L || b4 == -1L) {
/* 31 */       return -1;
/*    */     }
/* 33 */     return (int)((b1 << 24L) + (b2 << 16L) + (b3 << 8L) + b4);
/*    */   }
/*    */   
/*    */   public static long readLong(InputStream input) throws IOException {
/* 37 */     long b8 = input.read();
/* 38 */     long b7 = input.read();
/* 39 */     long b6 = input.read();
/* 40 */     long b5 = input.read();
/* 41 */     long b4 = input.read();
/* 42 */     long b3 = input.read();
/* 43 */     long b2 = input.read();
/* 44 */     long b1 = input.read();
/*    */     
/* 46 */     if (b1 == -1L || b2 == -1L || b3 == -1L || b4 == -1L || b5 == -1L || b6 == -1L || b7 == -1L || b8 == -1L) {
/* 47 */       return -1L;
/*    */     }
/* 49 */     return (int)((b1 << 56L) + (b2 << 48L) + (b3 << 40L) + (b4 << 32L) + (b5 << 24L) + (b6 << 16L) + (b7 << 8L) + b8);
/*    */   }
/*    */ }


/* Location:              C:\Users\rapha\Downloads\aurora.jar!\META-INF\jars\jcodec-0.2.5.jar!\org\jcodec\codecs\wav\ReaderLE.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */