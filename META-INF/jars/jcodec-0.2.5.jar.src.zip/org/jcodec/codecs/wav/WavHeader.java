/*     */ package org.jcodec.codecs.wav;
/*     */ 
/*     */ import java.io.Closeable;
/*     */ import java.io.File;
/*     */ import java.io.IOException;
/*     */ import java.nio.ByteBuffer;
/*     */ import java.nio.ByteOrder;
/*     */ import java.nio.channels.ReadableByteChannel;
/*     */ import java.nio.channels.WritableByteChannel;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Arrays;
/*     */ import java.util.List;
/*     */ import org.jcodec.api.UnhandledStateException;
/*     */ import org.jcodec.common.AudioFormat;
/*     */ import org.jcodec.common.JCodecUtil2;
/*     */ import org.jcodec.common.io.FileChannelWrapper;
/*     */ import org.jcodec.common.io.IOUtils;
/*     */ import org.jcodec.common.io.NIOUtils;
/*     */ import org.jcodec.common.model.ChannelLabel;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class WavHeader
/*     */ {
/*     */   public static class FmtChunkExtended
/*     */     extends FmtChunk
/*     */   {
/*     */     short cbSize;
/*     */     short bitsPerCodedSample;
/*     */     int channelLayout;
/*     */     int guid;
/*     */     
/*     */     public FmtChunkExtended(WavHeader.FmtChunk other, short cbSize, short bitsPerCodedSample, int channelLayout, int guid) {
/*  35 */       super(other.audioFormat, other.numChannels, other.sampleRate, other.byteRate, other.blockAlign, other.bitsPerSample);
/*     */       
/*  37 */       this.cbSize = cbSize;
/*  38 */       this.bitsPerCodedSample = bitsPerCodedSample;
/*  39 */       this.channelLayout = channelLayout;
/*  40 */       this.guid = guid;
/*     */     }
/*     */     
/*     */     public static WavHeader.FmtChunk read(ByteBuffer bb) throws IOException {
/*  44 */       WavHeader.FmtChunk fmtChunk = WavHeader.FmtChunk.get(bb);
/*  45 */       ByteOrder old = bb.order();
/*     */       try {
/*  47 */         bb.order(ByteOrder.LITTLE_ENDIAN);
/*  48 */         return new FmtChunkExtended(fmtChunk, bb.getShort(), bb.getShort(), bb.getInt(), bb.getInt());
/*     */       } finally {
/*  50 */         bb.order(old);
/*     */       } 
/*     */     }
/*     */     
/*     */     public void put(ByteBuffer bb) throws IOException {
/*  55 */       super.put(bb);
/*  56 */       ByteOrder old = bb.order();
/*  57 */       bb.order(ByteOrder.LITTLE_ENDIAN);
/*  58 */       bb.putShort(this.cbSize);
/*  59 */       bb.putShort(this.bitsPerCodedSample);
/*  60 */       bb.putInt(this.channelLayout);
/*  61 */       bb.putInt(this.guid);
/*  62 */       bb.order(old);
/*     */     }
/*     */     
/*     */     public int size() {
/*  66 */       return super.size() + 12;
/*     */     }
/*     */     
/*     */     public ChannelLabel[] getLabels() {
/*  70 */       List<ChannelLabel> labels = new ArrayList<ChannelLabel>();
/*  71 */       for (int i = 0; i < WavHeader.mapping.length; i++) {
/*  72 */         if ((this.channelLayout & 1 << i) != 0)
/*  73 */           labels.add(WavHeader.mapping[i]); 
/*     */       } 
/*  75 */       return labels.<ChannelLabel>toArray(new ChannelLabel[0]);
/*     */     }
/*     */   }
/*     */   
/*  79 */   static ChannelLabel[] mapping = new ChannelLabel[] { ChannelLabel.FRONT_LEFT, ChannelLabel.FRONT_RIGHT, ChannelLabel.CENTER, ChannelLabel.LFE, ChannelLabel.REAR_LEFT, ChannelLabel.REAR_RIGHT, ChannelLabel.FRONT_CENTER_LEFT, ChannelLabel.FRONT_CENTER_RIGHT, ChannelLabel.REAR_CENTER, ChannelLabel.SIDE_LEFT, ChannelLabel.SIDE_RIGHT, ChannelLabel.CENTER, ChannelLabel.FRONT_LEFT, ChannelLabel.CENTER, ChannelLabel.FRONT_RIGHT, ChannelLabel.REAR_LEFT, ChannelLabel.REAR_CENTER, ChannelLabel.REAR_RIGHT, ChannelLabel.STEREO_LEFT, ChannelLabel.STEREO_RIGHT };
/*     */   public String chunkId;
/*     */   public int chunkSize;
/*     */   public String format;
/*     */   public FmtChunk fmt;
/*     */   public int dataOffset;
/*     */   public long dataSize;
/*     */   public static final int WAV_HEADER_SIZE = 44;
/*     */   
/*     */   public static class FmtChunk { public short audioFormat;
/*     */     public short numChannels;
/*     */     public int sampleRate;
/*     */     public int byteRate;
/*     */     public short blockAlign;
/*     */     public short bitsPerSample;
/*     */     
/*     */     public FmtChunk(short audioFormat, short numChannels, int sampleRate, int byteRate, short blockAlign, short bitsPerSample) {
/*  96 */       this.audioFormat = audioFormat;
/*  97 */       this.numChannels = numChannels;
/*  98 */       this.sampleRate = sampleRate;
/*  99 */       this.byteRate = byteRate;
/* 100 */       this.blockAlign = blockAlign;
/* 101 */       this.bitsPerSample = bitsPerSample;
/*     */     }
/*     */     
/*     */     public static FmtChunk get(ByteBuffer bb) throws IOException {
/* 105 */       ByteOrder old = bb.order();
/*     */       try {
/* 107 */         bb.order(ByteOrder.LITTLE_ENDIAN);
/* 108 */         return new FmtChunk(bb.getShort(), bb.getShort(), bb.getInt(), bb.getInt(), bb.getShort(), bb
/* 109 */             .getShort());
/*     */       } finally {
/* 111 */         bb.order(old);
/*     */       } 
/*     */     }
/*     */     
/*     */     public void put(ByteBuffer bb) throws IOException {
/* 116 */       ByteOrder old = bb.order();
/* 117 */       bb.order(ByteOrder.LITTLE_ENDIAN);
/* 118 */       bb.putShort(this.audioFormat);
/* 119 */       bb.putShort(this.numChannels);
/* 120 */       bb.putInt(this.sampleRate);
/* 121 */       bb.putInt(this.byteRate);
/* 122 */       bb.putShort(this.blockAlign);
/* 123 */       bb.putShort(this.bitsPerSample);
/* 124 */       bb.order(old);
/*     */     }
/*     */     
/*     */     public int size() {
/* 128 */       return 16;
/*     */     } }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public WavHeader(String chunkId, int chunkSize, String format, FmtChunk fmt, int dataOffset, long dataSize) {
/* 141 */     this.chunkId = chunkId;
/* 142 */     this.chunkSize = chunkSize;
/* 143 */     this.format = format;
/* 144 */     this.fmt = fmt;
/* 145 */     this.dataOffset = dataOffset;
/* 146 */     this.dataSize = dataSize;
/*     */   }
/*     */ 
/*     */   
/*     */   public static WavHeader copyWithRate(WavHeader header, int rate) {
/* 151 */     WavHeader result = new WavHeader(header.chunkId, header.chunkSize, header.format, copyFmt(header.fmt), header.dataOffset, header.dataSize);
/* 152 */     result.fmt.sampleRate = rate;
/* 153 */     return result;
/*     */   }
/*     */ 
/*     */   
/*     */   public static WavHeader copyWithChannels(WavHeader header, int channels) {
/* 158 */     WavHeader result = new WavHeader(header.chunkId, header.chunkSize, header.format, copyFmt(header.fmt), header.dataOffset, header.dataSize);
/* 159 */     result.fmt.numChannels = (short)channels;
/* 160 */     return result;
/*     */   }
/*     */   
/*     */   private static FmtChunk copyFmt(FmtChunk fmt) {
/* 164 */     if (fmt instanceof FmtChunkExtended) {
/* 165 */       FmtChunkExtended fmtext = (FmtChunkExtended)fmt;
/* 166 */       fmt = new FmtChunkExtended(fmtext, fmtext.cbSize, fmtext.bitsPerCodedSample, fmtext.channelLayout, fmtext.guid);
/*     */     } else {
/* 168 */       fmt = new FmtChunk(fmt.audioFormat, fmt.numChannels, fmt.sampleRate, fmt.byteRate, fmt.blockAlign, fmt.bitsPerSample);
/*     */     } 
/*     */     
/* 171 */     return fmt;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static WavHeader createWavHeader(AudioFormat format, int samples) {
/* 184 */     WavHeader w = new WavHeader("RIFF", 40, "WAVE", new FmtChunk((short)1, (short)format.getChannels(), format.getSampleRate(), format.getSampleRate() * format.getChannels() * (format.getSampleSizeInBits() >> 3), (short)(format.getChannels() * (format.getSampleSizeInBits() >> 3)), (short)format.getSampleSizeInBits()), 44, calcDataSize(format.getChannels(), format
/* 185 */           .getSampleSizeInBits() >> 3, samples));
/* 186 */     return w;
/*     */   }
/*     */   
/*     */   public static WavHeader stereo48k() {
/* 190 */     return stereo48kWithSamples(0L);
/*     */   }
/*     */   
/*     */   public static WavHeader stereo48kWithSamples(long samples) {
/* 194 */     return new WavHeader("RIFF", 40, "WAVE", new FmtChunk((short)1, (short)2, 48000, 192000, (short)4, (short)16), 44, 
/* 195 */         calcDataSize(2, 2, samples));
/*     */   }
/*     */   
/*     */   public static WavHeader mono48k(long samples) {
/* 199 */     return new WavHeader("RIFF", 40, "WAVE", new FmtChunk((short)1, (short)1, 48000, 96000, (short)2, (short)16), 44, 
/* 200 */         calcDataSize(1, 2, samples));
/*     */   }
/*     */   
/*     */   public static WavHeader emptyWavHeader() {
/* 204 */     return new WavHeader("RIFF", 40, "WAVE", newFmtChunk(), 44, 0L);
/*     */   }
/*     */   
/*     */   private static FmtChunk newFmtChunk() {
/* 208 */     return new FmtChunk((short)1, (short)0, 0, 0, (short)0, (short)0);
/*     */   }
/*     */   public static WavHeader read(File file) throws IOException {
/*     */     FileChannelWrapper fileChannelWrapper;
/* 212 */     ReadableByteChannel is = null;
/*     */     try {
/* 214 */       fileChannelWrapper = NIOUtils.readableChannel(file);
/* 215 */       return readChannel((ReadableByteChannel)fileChannelWrapper);
/*     */     } finally {
/* 217 */       IOUtils.closeQuietly((Closeable)fileChannelWrapper);
/*     */     } 
/*     */   }
/*     */   public static WavHeader readChannel(ReadableByteChannel _in) throws IOException {
/*     */     String fourcc;
/* 222 */     ByteBuffer buf = ByteBuffer.allocate(128);
/* 223 */     buf.order(ByteOrder.LITTLE_ENDIAN);
/* 224 */     _in.read(buf);
/* 225 */     if (buf.remaining() > 0)
/* 226 */       throw new IOException("Incomplete wav header found"); 
/* 227 */     buf.flip();
/*     */     
/* 229 */     String chunkId = NIOUtils.readString(buf, 4);
/* 230 */     int chunkSize = buf.getInt();
/* 231 */     String format = NIOUtils.readString(buf, 4);
/* 232 */     FmtChunk fmt = null;
/*     */     
/* 234 */     if (!"RIFF".equals(chunkId) || !"WAVE".equals(format)) {
/* 235 */       return null;
/*     */     }
/*     */     
/* 238 */     int size = 0;
/*     */     do {
/* 240 */       fourcc = NIOUtils.readString(buf, 4);
/* 241 */       size = buf.getInt();
/* 242 */       if ("fmt ".equals(fourcc) && size >= 14 && size <= 1048576) {
/* 243 */         switch (size) {
/*     */           case 16:
/* 245 */             fmt = FmtChunk.get(buf);
/*     */             break;
/*     */           case 18:
/* 248 */             fmt = FmtChunk.get(buf);
/* 249 */             NIOUtils.skip(buf, 2);
/*     */             break;
/*     */           case 40:
/* 252 */             fmt = FmtChunkExtended.get(buf);
/* 253 */             NIOUtils.skip(buf, 12);
/*     */             break;
/*     */           case 28:
/* 256 */             fmt = FmtChunkExtended.get(buf);
/*     */             break;
/*     */           default:
/* 259 */             throw new UnhandledStateException("Don't know how to handle fmt size: " + size);
/*     */         } 
/* 261 */       } else if (!"data".equals(fourcc)) {
/* 262 */         NIOUtils.skip(buf, size);
/*     */       } 
/* 264 */     } while (!"data".equals(fourcc));
/*     */     
/* 266 */     return new WavHeader(chunkId, chunkSize, format, fmt, buf.position(), size);
/*     */   }
/*     */   
/*     */   public static WavHeader multiChannelWavFromFiles(File[] files) throws IOException {
/* 270 */     WavHeader[] headers = new WavHeader[files.length];
/* 271 */     for (int i = 0; i < files.length; i++) {
/* 272 */       headers[i] = read(files[i]);
/*     */     }
/* 274 */     return multiChannelWav(headers);
/*     */   }
/*     */ 
/*     */   
/*     */   public static WavHeader multiChannelWav(WavHeader[] headers) {
/* 279 */     WavHeader w = emptyWavHeader();
/* 280 */     int totalSize = 0;
/* 281 */     for (int i = 0; i < headers.length; i++) {
/* 282 */       WavHeader wavHeader = headers[i];
/* 283 */       totalSize = (int)(totalSize + wavHeader.dataSize);
/*     */     } 
/* 285 */     w.dataSize = totalSize;
/* 286 */     FmtChunk fmt = (headers[0]).fmt;
/* 287 */     int bitsPerSample = fmt.bitsPerSample;
/* 288 */     int bytesPerSample = bitsPerSample / 8;
/* 289 */     int sampleRate = fmt.sampleRate;
/* 290 */     w.fmt.bitsPerSample = (short)bitsPerSample;
/* 291 */     w.fmt.blockAlign = (short)(headers.length * bytesPerSample);
/* 292 */     w.fmt.byteRate = headers.length * bytesPerSample * sampleRate;
/* 293 */     w.fmt.numChannels = (short)headers.length;
/* 294 */     w.fmt.sampleRate = sampleRate;
/* 295 */     return w;
/*     */   }
/*     */   public void write(WritableByteChannel out) throws IOException {
/*     */     long chunkSize;
/* 299 */     ByteBuffer bb = ByteBuffer.allocate(44);
/* 300 */     bb.order(ByteOrder.LITTLE_ENDIAN);
/*     */ 
/*     */     
/* 303 */     if (this.dataSize <= 4294967295L) {
/* 304 */       chunkSize = this.dataSize + 36L;
/*     */     } else {
/* 306 */       chunkSize = 40L;
/*     */     } 
/*     */     
/* 309 */     bb.put(JCodecUtil2.asciiString("RIFF"));
/* 310 */     bb.putInt((int)chunkSize);
/* 311 */     bb.put(JCodecUtil2.asciiString("WAVE"));
/*     */     
/* 313 */     bb.put(JCodecUtil2.asciiString("fmt "));
/* 314 */     bb.putInt(this.fmt.size());
/* 315 */     this.fmt.put(bb);
/* 316 */     bb.put(JCodecUtil2.asciiString("data"));
/* 317 */     if (this.dataSize <= 4294967295L) {
/* 318 */       bb.putInt((int)this.dataSize);
/*     */     } else {
/* 320 */       bb.putInt(0);
/*     */     } 
/* 322 */     bb.flip();
/* 323 */     out.write(bb);
/*     */   }
/*     */   
/*     */   public static long calcDataSize(int numChannels, int bytesPerSample, long samples) {
/* 327 */     return samples * numChannels * bytesPerSample;
/*     */   }
/*     */   
/*     */   public static WavHeader create(AudioFormat af, int size) {
/* 331 */     WavHeader w = emptyWavHeader();
/* 332 */     w.dataSize = size;
/* 333 */     FmtChunk fmt = newFmtChunk();
/* 334 */     int bitsPerSample = af.getSampleSizeInBits();
/* 335 */     int bytesPerSample = bitsPerSample / 8;
/* 336 */     int sampleRate = af.getSampleRate();
/* 337 */     w.fmt.bitsPerSample = (short)bitsPerSample;
/* 338 */     w.fmt.blockAlign = af.getFrameSize();
/* 339 */     w.fmt.byteRate = af.getFrameRate() * af.getFrameSize();
/* 340 */     w.fmt.numChannels = (short)af.getChannels();
/* 341 */     w.fmt.sampleRate = af.getSampleRate();
/* 342 */     return w;
/*     */   }
/*     */   
/*     */   public ChannelLabel[] getChannelLabels() {
/* 346 */     if (this.fmt instanceof FmtChunkExtended) {
/* 347 */       return ((FmtChunkExtended)this.fmt).getLabels();
/*     */     }
/* 349 */     switch (this.fmt.numChannels) {
/*     */       case 1:
/* 351 */         return new ChannelLabel[] { ChannelLabel.MONO };
/*     */       case 2:
/* 353 */         return new ChannelLabel[] { ChannelLabel.STEREO_LEFT, ChannelLabel.STEREO_RIGHT };
/*     */       case 3:
/* 355 */         return new ChannelLabel[] { ChannelLabel.FRONT_LEFT, ChannelLabel.FRONT_RIGHT, ChannelLabel.REAR_CENTER };
/*     */       case 4:
/* 357 */         return new ChannelLabel[] { ChannelLabel.FRONT_LEFT, ChannelLabel.FRONT_RIGHT, ChannelLabel.REAR_LEFT, ChannelLabel.REAR_RIGHT };
/*     */       
/*     */       case 5:
/* 360 */         return new ChannelLabel[] { ChannelLabel.FRONT_LEFT, ChannelLabel.FRONT_RIGHT, ChannelLabel.CENTER, ChannelLabel.REAR_LEFT, ChannelLabel.REAR_RIGHT };
/*     */       
/*     */       case 6:
/* 363 */         return new ChannelLabel[] { ChannelLabel.FRONT_LEFT, ChannelLabel.FRONT_RIGHT, ChannelLabel.CENTER, ChannelLabel.LFE, ChannelLabel.REAR_LEFT, ChannelLabel.REAR_RIGHT };
/*     */       
/*     */       case 7:
/* 366 */         return new ChannelLabel[] { ChannelLabel.FRONT_LEFT, ChannelLabel.FRONT_RIGHT, ChannelLabel.CENTER, ChannelLabel.LFE, ChannelLabel.REAR_LEFT, ChannelLabel.REAR_RIGHT, ChannelLabel.REAR_CENTER };
/*     */       
/*     */       case 8:
/* 369 */         return new ChannelLabel[] { ChannelLabel.FRONT_LEFT, ChannelLabel.FRONT_RIGHT, ChannelLabel.CENTER, ChannelLabel.LFE, ChannelLabel.REAR_LEFT, ChannelLabel.REAR_RIGHT, ChannelLabel.REAR_LEFT, ChannelLabel.REAR_RIGHT };
/*     */     } 
/*     */ 
/*     */     
/* 373 */     ChannelLabel[] labels = new ChannelLabel[this.fmt.numChannels];
/* 374 */     Arrays.fill((Object[])labels, ChannelLabel.MONO);
/* 375 */     return labels;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public AudioFormat getFormat() {
/* 381 */     return new AudioFormat(this.fmt.sampleRate, this.fmt.bitsPerSample, this.fmt.numChannels, true, false);
/*     */   }
/*     */ }


/* Location:              C:\Users\rapha\Downloads\aurora.jar!\META-INF\jars\jcodec-0.2.5.jar!\org\jcodec\codecs\wav\WavHeader.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */