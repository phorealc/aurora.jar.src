/*    */ package org.jcodec.codecs.wav;
/*    */ 
/*    */ import java.io.Closeable;
/*    */ import java.io.IOException;
/*    */ import java.nio.channels.WritableByteChannel;
/*    */ import org.jcodec.common.AudioCodecMeta;
/*    */ import org.jcodec.common.AudioFormat;
/*    */ import org.jcodec.common.Codec;
/*    */ import org.jcodec.common.Muxer;
/*    */ import org.jcodec.common.MuxerTrack;
/*    */ import org.jcodec.common.VideoCodecMeta;
/*    */ import org.jcodec.common.io.NIOUtils;
/*    */ import org.jcodec.common.io.SeekableByteChannel;
/*    */ import org.jcodec.common.model.Packet;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class WavMuxer
/*    */   implements Muxer, MuxerTrack
/*    */ {
/*    */   protected SeekableByteChannel out;
/*    */   protected WavHeader header;
/*    */   protected int written;
/*    */   private AudioFormat format;
/*    */   
/*    */   public WavMuxer(SeekableByteChannel out) throws IOException {
/* 31 */     this.out = out;
/*    */   }
/*    */ 
/*    */   
/*    */   public void addFrame(Packet outPacket) throws IOException {
/* 36 */     this.written += this.out.write(outPacket.getData());
/*    */   }
/*    */   
/*    */   public void close() throws IOException {
/* 40 */     this.out.setPosition(0L);
/* 41 */     WavHeader.createWavHeader(this.format, this.format.bytesToFrames(this.written)).write((WritableByteChannel)this.out);
/* 42 */     NIOUtils.closeQuietly((Closeable)this.out);
/*    */   }
/*    */ 
/*    */   
/*    */   public MuxerTrack addVideoTrack(Codec codec, VideoCodecMeta meta) {
/* 47 */     return null;
/*    */   }
/*    */ 
/*    */   
/*    */   public MuxerTrack addAudioTrack(Codec codec, AudioCodecMeta meta) {
/* 52 */     this.header = WavHeader.createWavHeader(meta.getFormat(), 0);
/* 53 */     this.format = meta.getFormat();
/*    */     try {
/* 55 */       this.header.write((WritableByteChannel)this.out);
/* 56 */     } catch (IOException e) {
/* 57 */       throw new RuntimeException(e);
/*    */     } 
/* 59 */     return this;
/*    */   }
/*    */   
/*    */   public void finish() throws IOException {}
/*    */ }


/* Location:              C:\Users\rapha\Downloads\aurora.jar!\META-INF\jars\jcodec-0.2.5.jar!\org\jcodec\codecs\wav\WavMuxer.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */