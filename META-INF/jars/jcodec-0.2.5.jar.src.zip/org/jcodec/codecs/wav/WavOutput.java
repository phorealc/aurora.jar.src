/*    */ package org.jcodec.codecs.wav;
/*    */ 
/*    */ import java.io.Closeable;
/*    */ import java.io.File;
/*    */ import java.io.IOException;
/*    */ import java.nio.ByteBuffer;
/*    */ import java.nio.FloatBuffer;
/*    */ import java.nio.channels.WritableByteChannel;
/*    */ import org.jcodec.audio.AudioSink;
/*    */ import org.jcodec.common.AudioFormat;
/*    */ import org.jcodec.common.AudioUtil;
/*    */ import org.jcodec.common.io.NIOUtils;
/*    */ import org.jcodec.common.io.SeekableByteChannel;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class WavOutput
/*    */   implements Closeable
/*    */ {
/*    */   protected SeekableByteChannel out;
/*    */   protected WavHeader header;
/*    */   protected int written;
/*    */   protected AudioFormat format;
/*    */   
/*    */   public WavOutput(SeekableByteChannel out, AudioFormat format) throws IOException {
/* 30 */     this.out = out;
/* 31 */     this.format = format;
/* 32 */     this.header = WavHeader.createWavHeader(format, 0);
/* 33 */     this.header.write((WritableByteChannel)out);
/*    */   }
/*    */   
/*    */   public void write(ByteBuffer samples) throws IOException {
/* 37 */     this.written += this.out.write(samples);
/*    */   }
/*    */   
/*    */   public void close() throws IOException {
/* 41 */     this.out.setPosition(0L);
/* 42 */     WavHeader.createWavHeader(this.format, this.format.bytesToFrames(this.written)).write((WritableByteChannel)this.out);
/* 43 */     NIOUtils.closeQuietly((Closeable)this.out);
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public static class WavOutFile
/*    */     extends WavOutput
/*    */   {
/*    */     public WavOutFile(File f, AudioFormat format) throws IOException {
/* 52 */       super((SeekableByteChannel)NIOUtils.writableChannel(f), format);
/*    */     }
/*    */ 
/*    */     
/*    */     public void close() throws IOException {
/* 57 */       super.close();
/* 58 */       NIOUtils.closeQuietly((Closeable)this.out);
/*    */     }
/*    */   }
/*    */ 
/*    */   
/*    */   public static class Sink
/*    */     implements AudioSink, Closeable
/*    */   {
/*    */     private WavOutput out;
/*    */     
/*    */     public Sink(WavOutput out) {
/* 69 */       this.out = out;
/*    */     }
/*    */     
/*    */     public void writeFloat(FloatBuffer data) throws IOException {
/* 73 */       ByteBuffer buf = ByteBuffer.allocate(this.out.format.samplesToBytes(data.remaining()));
/* 74 */       AudioUtil.fromFloat(data, this.out.format, buf);
/* 75 */       buf.flip();
/* 76 */       this.out.write(buf);
/*    */     }
/*    */ 
/*    */     
/*    */     public void write(int[] data, int len) throws IOException {
/* 81 */       len = Math.min(data.length, len);
/*    */       
/* 83 */       ByteBuffer buf = ByteBuffer.allocate(this.out.format.samplesToBytes(len));
/* 84 */       AudioUtil.fromInt(data, len, this.out.format, buf);
/* 85 */       buf.flip();
/* 86 */       this.out.write(buf);
/*    */     }
/*    */     
/*    */     public void close() throws IOException {
/* 90 */       this.out.close();
/*    */     }
/*    */   }
/*    */ }


/* Location:              C:\Users\rapha\Downloads\aurora.jar!\META-INF\jars\jcodec-0.2.5.jar!\org\jcodec\codecs\wav\WavOutput.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */