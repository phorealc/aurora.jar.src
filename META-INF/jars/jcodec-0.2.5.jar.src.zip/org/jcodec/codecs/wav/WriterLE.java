/*    */ package org.jcodec.codecs.wav;
/*    */ 
/*    */ import java.io.IOException;
/*    */ import java.io.OutputStream;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public abstract class WriterLE
/*    */ {
/*    */   public static void writeShort(OutputStream out, short s) throws IOException {
/* 14 */     out.write(s & 0xFF);
/* 15 */     out.write(s >> 8 & 0xFF);
/*    */   }
/*    */   
/*    */   public static void writeInt(OutputStream out, int i) throws IOException {
/* 19 */     out.write(i & 0xFF);
/* 20 */     out.write(i >> 8 & 0xFF);
/* 21 */     out.write(i >> 16 & 0xFF);
/* 22 */     out.write(i >> 24 & 0xFF);
/*    */   }
/*    */   
/*    */   public static void writeLong(OutputStream out, long l) throws IOException {
/* 26 */     out.write((int)(l & 0xFFL));
/* 27 */     out.write((int)(l >> 8L & 0xFFL));
/* 28 */     out.write((int)(l >> 16L & 0xFFL));
/* 29 */     out.write((int)(l >> 24L & 0xFFL));
/* 30 */     out.write((int)(l >> 32L & 0xFFL));
/* 31 */     out.write((int)(l >> 40L & 0xFFL));
/* 32 */     out.write((int)(l >> 48L & 0xFFL));
/* 33 */     out.write((int)(l >> 56L & 0xFFL));
/*    */   }
/*    */ }


/* Location:              C:\Users\rapha\Downloads\aurora.jar!\META-INF\jars\jcodec-0.2.5.jar!\org\jcodec\codecs\wav\WriterLE.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */