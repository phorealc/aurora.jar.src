/*    */ package org.jcodec.codecs.ppm;
/*    */ 
/*    */ import java.nio.ByteBuffer;
/*    */ import org.jcodec.common.JCodecUtil2;
/*    */ import org.jcodec.common.model.ColorSpace;
/*    */ import org.jcodec.common.model.Picture;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class PPMEncoder
/*    */ {
/*    */   public ByteBuffer encodeFrame(Picture picture) {
/* 20 */     if (picture.getColor() != ColorSpace.RGB)
/* 21 */       throw new IllegalArgumentException("Only RGB image can be stored in PPM"); 
/* 22 */     ByteBuffer buffer = ByteBuffer.allocate(picture.getWidth() * picture.getHeight() * 3 + 200);
/* 23 */     buffer.put(JCodecUtil2.asciiString("P6 " + picture.getWidth() + " " + picture.getHeight() + " 255\n"));
/*    */     
/* 25 */     byte[][] data = picture.getData();
/* 26 */     for (int i = 0; i < picture.getWidth() * picture.getHeight() * 3; i += 3) {
/* 27 */       buffer.put((byte)(data[0][i + 2] + 128));
/* 28 */       buffer.put((byte)(data[0][i + 1] + 128));
/* 29 */       buffer.put((byte)(data[0][i] + 128));
/*    */     } 
/*    */     
/* 32 */     buffer.flip();
/*    */     
/* 34 */     return buffer;
/*    */   }
/*    */ }


/* Location:              C:\Users\rapha\Downloads\aurora.jar!\META-INF\jars\jcodec-0.2.5.jar!\org\jcodec\codecs\ppm\PPMEncoder.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */