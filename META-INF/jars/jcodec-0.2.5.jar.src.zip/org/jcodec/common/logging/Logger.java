/*    */ package org.jcodec.common.logging;
/*    */ 
/*    */ import java.util.LinkedList;
/*    */ import java.util.List;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class Logger
/*    */ {
/* 23 */   private static List<LogSink> stageSinks = new LinkedList<LogSink>();
/*    */   private static List<LogSink> sinks;
/*    */   
/*    */   public static void debug(String message) {
/* 27 */     message(LogLevel.DEBUG, message, null);
/*    */   }
/*    */   
/*    */   public static void debug(String message, Object... args) {
/* 31 */     message(LogLevel.DEBUG, message, args);
/*    */   }
/*    */   
/*    */   public static void info(String message) {
/* 35 */     message(LogLevel.INFO, message, null);
/*    */   }
/*    */   
/*    */   public static void info(String message, Object... args) {
/* 39 */     message(LogLevel.INFO, message, args);
/*    */   }
/*    */   
/*    */   public static void warn(String message) {
/* 43 */     message(LogLevel.WARN, message, null);
/*    */   }
/*    */   
/*    */   public static void warn(String message, Object... args) {
/* 47 */     message(LogLevel.WARN, message, args);
/*    */   }
/*    */   
/*    */   public static void error(String message) {
/* 51 */     message(LogLevel.ERROR, message, null);
/*    */   }
/*    */   
/*    */   public static void error(String message, Object... args) {
/* 55 */     message(LogLevel.ERROR, message, args);
/*    */   }
/*    */   private static void message(LogLevel level, String message, Object[] args) {
/*    */     Message msg;
/* 59 */     if (globalLogLevel.ordinal() >= level.ordinal()) {
/*    */       return;
/*    */     }
/* 62 */     if (sinks == null) {
/* 63 */       synchronized (Logger.class) {
/* 64 */         if (sinks == null) {
/* 65 */           sinks = stageSinks;
/* 66 */           stageSinks = null;
/* 67 */           if (sinks.isEmpty()) {
/* 68 */             sinks.add(OutLogSink.createOutLogSink());
/*    */           }
/*    */         } 
/*    */       } 
/*    */     }
/* 73 */     if (LogLevel.DEBUG.equals(globalLogLevel)) {
/* 74 */       StackTraceElement tr = Thread.currentThread().getStackTrace()[3];
/* 75 */       msg = new Message(level, tr.getFileName(), tr.getClassName(), tr.getMethodName(), tr.getLineNumber(), message, args);
/*    */     } else {
/*    */       
/* 78 */       msg = new Message(level, "", "", "", 0, message, args);
/*    */     } 
/* 80 */     for (LogSink logSink : sinks) {
/* 81 */       logSink.postMessage(msg);
/*    */     }
/*    */   }
/*    */   
/* 85 */   private static LogLevel globalLogLevel = LogLevel.INFO;
/*    */   
/*    */   public static synchronized void setLevel(LogLevel level) {
/* 88 */     globalLogLevel = level;
/*    */   }
/*    */   
/*    */   public static synchronized LogLevel getLevel() {
/* 92 */     return globalLogLevel;
/*    */   }
/*    */ 
/*    */   
/*    */   public static void addSink(LogSink sink) {
/* 97 */     if (stageSinks == null)
/* 98 */       throw new IllegalStateException("Logger already started"); 
/* 99 */     stageSinks.add(sink);
/*    */   }
/*    */ }


/* Location:              C:\Users\rapha\Downloads\aurora.jar!\META-INF\jars\jcodec-0.2.5.jar!\org\jcodec\common\logging\Logger.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */