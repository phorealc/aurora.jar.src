/*   */ package org.jcodec.common.logging;
/*   */ 
/*   */ public enum LogLevel {
/* 4 */   DEBUG, INFO, WARN, ERROR;
/*   */ }


/* Location:              C:\Users\rapha\Downloads\aurora.jar!\META-INF\jars\jcodec-0.2.5.jar!\org\jcodec\common\logging\LogLevel.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */