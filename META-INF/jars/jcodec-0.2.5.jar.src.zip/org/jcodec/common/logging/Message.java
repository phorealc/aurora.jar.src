/*    */ package org.jcodec.common.logging;
/*    */ 
/*    */ public class Message {
/*    */   private LogLevel level;
/*    */   private String fileName;
/*    */   private String className;
/*    */   private int lineNumber;
/*    */   private String message;
/*    */   private String methodName;
/*    */   private Object[] args;
/*    */   
/*    */   public Message(LogLevel level, String fileName, String className, String methodName, int lineNumber, String message, Object[] args) {
/* 13 */     this.level = level;
/* 14 */     this.fileName = fileName;
/* 15 */     this.className = className;
/* 16 */     this.methodName = methodName;
/* 17 */     this.message = methodName;
/* 18 */     this.lineNumber = lineNumber;
/* 19 */     this.message = message;
/* 20 */     this.args = args;
/*    */   }
/*    */   
/*    */   public LogLevel getLevel() {
/* 24 */     return this.level;
/*    */   }
/*    */   
/*    */   public String getFileName() {
/* 28 */     return this.fileName;
/*    */   }
/*    */   
/*    */   public String getClassName() {
/* 32 */     return this.className;
/*    */   }
/*    */   
/*    */   public String getMethodName() {
/* 36 */     return this.methodName;
/*    */   }
/*    */   
/*    */   public int getLineNumber() {
/* 40 */     return this.lineNumber;
/*    */   }
/*    */   
/*    */   public String getMessage() {
/* 44 */     return this.message;
/*    */   }
/*    */   
/*    */   public Object[] getArgs() {
/* 48 */     return this.args;
/*    */   }
/*    */ }


/* Location:              C:\Users\rapha\Downloads\aurora.jar!\META-INF\jars\jcodec-0.2.5.jar!\org\jcodec\common\logging\Message.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */