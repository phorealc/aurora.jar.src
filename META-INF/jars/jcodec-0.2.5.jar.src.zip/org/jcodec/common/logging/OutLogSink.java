/*    */ package org.jcodec.common.logging;
/*    */ 
/*    */ import java.io.PrintStream;
/*    */ import java.util.HashMap;
/*    */ import java.util.Map;
/*    */ import org.jcodec.common.tools.MainUtils;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class OutLogSink
/*    */   implements LogSink
/*    */ {
/*    */   public static interface MessageFormat
/*    */   {
/*    */     String formatMessage(Message param1Message);
/*    */   }
/*    */   
/* 23 */   private static String empty = "                                                                                                                                                                                                                                                ";
/*    */   
/*    */   public static class SimpleFormat implements MessageFormat {
/*    */     private String fmt;
/* 27 */     private static Map<LogLevel, MainUtils.ANSIColor> colorMap = new HashMap<LogLevel, MainUtils.ANSIColor>();
/*    */     static {
/* 29 */       colorMap.put(LogLevel.DEBUG, MainUtils.ANSIColor.BROWN);
/* 30 */       colorMap.put(LogLevel.INFO, MainUtils.ANSIColor.GREEN);
/* 31 */       colorMap.put(LogLevel.WARN, MainUtils.ANSIColor.MAGENTA);
/* 32 */       colorMap.put(LogLevel.ERROR, MainUtils.ANSIColor.RED);
/*    */     }
/*    */     
/*    */     public SimpleFormat(String fmt) {
/* 36 */       this.fmt = fmt;
/*    */     }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */     
/*    */     public String formatMessage(Message msg) {
/* 45 */       String str = this.fmt.replace("#level", String.valueOf(msg.getLevel())).replace("#color_code", String.valueOf(30 + ((MainUtils.ANSIColor)colorMap.get(msg.getLevel())).ordinal())).replace("#class", msg.getClassName()).replace("#method", msg.getMethodName()).replace("#file", msg.getFileName()).replace("#line", String.valueOf(msg.getLineNumber())).replace("#message", msg.getMessage());
/* 46 */       return str;
/*    */     }
/*    */   }
/*    */   
/* 50 */   public static SimpleFormat DEFAULT_FORMAT = new SimpleFormat(
/* 51 */       MainUtils.colorString("[#level]", "#color_code") + MainUtils.bold("\t#class.#method (#file:#line):") + "\t#message"); private PrintStream out;
/*    */   
/*    */   public static OutLogSink createOutLogSink() {
/* 54 */     return new OutLogSink(System.out, DEFAULT_FORMAT, LogLevel.INFO);
/*    */   }
/*    */ 
/*    */   
/*    */   private MessageFormat fmt;
/*    */   private LogLevel minLevel;
/*    */   
/*    */   public OutLogSink(PrintStream out, MessageFormat fmt, LogLevel minLevel) {
/* 62 */     this.out = out;
/* 63 */     this.fmt = fmt;
/* 64 */     this.minLevel = minLevel;
/*    */   }
/*    */ 
/*    */   
/*    */   public void postMessage(Message msg) {
/* 69 */     if (msg.getLevel().ordinal() < this.minLevel.ordinal())
/*    */       return; 
/* 71 */     String str = this.fmt.formatMessage(msg);
/* 72 */     this.out.println(str);
/*    */   }
/*    */ }


/* Location:              C:\Users\rapha\Downloads\aurora.jar!\META-INF\jars\jcodec-0.2.5.jar!\org\jcodec\common\logging\OutLogSink.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */