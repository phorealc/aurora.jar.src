/*    */ package org.jcodec.common.logging;
/*    */ 
/*    */ import java.util.LinkedList;
/*    */ import java.util.List;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class BufferLogSink
/*    */   implements LogSink
/*    */ {
/* 19 */   private List<Message> messages = new LinkedList<Message>();
/*    */ 
/*    */ 
/*    */   
/*    */   public void postMessage(Message msg) {
/* 24 */     this.messages.add(msg);
/*    */   }
/*    */   
/*    */   public List<Message> getMessages() {
/* 28 */     return this.messages;
/*    */   }
/*    */ }


/* Location:              C:\Users\rapha\Downloads\aurora.jar!\META-INF\jars\jcodec-0.2.5.jar!\org\jcodec\common\logging\BufferLogSink.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */