/*     */ package org.jcodec.common;
/*     */ 
/*     */ import java.lang.reflect.Array;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ArrayUtil
/*     */ {
/*     */   public static <T> void shiftRight1(T[] array) {
/*  19 */     for (int i = 1; i < array.length; i++) {
/*  20 */       array[i] = array[i - 1];
/*     */     }
/*  22 */     array[0] = null;
/*     */   }
/*     */   
/*     */   public static <T> void shiftLeft1(T[] array) {
/*  26 */     for (int i = 0; i < array.length - 1; i++) {
/*  27 */       array[i] = array[i + 1];
/*     */     }
/*  29 */     array[array.length - 1] = null;
/*     */   }
/*     */   
/*     */   public static <T> void shiftRight3(T[] array, int from, int to) {
/*  33 */     for (int i = to - 1; i > from; i--) {
/*  34 */       array[i] = array[i - 1];
/*     */     }
/*  36 */     array[from] = null;
/*     */   }
/*     */   
/*     */   public static <T> void shiftLeft3(T[] array, int from, int to) {
/*  40 */     for (int i = from; i < to - 1; i++) {
/*  41 */       array[i] = array[i + 1];
/*     */     }
/*  43 */     array[to - 1] = null;
/*     */   }
/*     */   
/*     */   public static <T> void shiftLeft2(T[] array, int from) {
/*  47 */     shiftLeft3(array, from, array.length);
/*     */   }
/*     */   
/*     */   public static <T> void shiftRight2(T[] array, int to) {
/*  51 */     shiftRight3(array, 0, to);
/*     */   }
/*     */   
/*     */   public static final void swap(int[] arr, int ind1, int ind2) {
/*  55 */     if (ind1 == ind2)
/*     */       return; 
/*  57 */     int tmp = arr[ind1];
/*  58 */     arr[ind1] = arr[ind2];
/*  59 */     arr[ind2] = tmp;
/*     */   }
/*     */   
/*     */   public static final int sumInt(int[] array) {
/*  63 */     int result = 0;
/*  64 */     for (int i = 0; i < array.length; i++) {
/*  65 */       result += array[i];
/*     */     }
/*  67 */     return result;
/*     */   }
/*     */   
/*     */   public static final int sumByte(byte[] array) {
/*  71 */     int result = 0;
/*  72 */     for (int i = 0; i < array.length; i++) {
/*  73 */       result += array[i];
/*     */     }
/*  75 */     return result;
/*     */   }
/*     */   
/*     */   public static int sumInt3(int[] array, int from, int count) {
/*  79 */     int result = 0;
/*  80 */     for (int i = from; i < from + count; i++) {
/*  81 */       result += array[i];
/*     */     }
/*  83 */     return result;
/*     */   }
/*     */   
/*     */   public static int sumByte3(byte[] array, int from, int count) {
/*  87 */     int result = 0;
/*  88 */     for (int i = from; i < from + count; i++) {
/*  89 */       result += array[i];
/*     */     }
/*  91 */     return result;
/*     */   }
/*     */   
/*     */   public static void addInt(int[] array, int val) {
/*  95 */     for (int i = 0; i < array.length; i++)
/*  96 */       array[i] = array[i] + val; 
/*     */   }
/*     */   
/*     */   public static int[] addAllInt(int[] array1, int[] array2) {
/* 100 */     if (array1 == null)
/* 101 */       return cloneInt(array2); 
/* 102 */     if (array2 == null) {
/* 103 */       return cloneInt(array1);
/*     */     }
/* 105 */     int[] joinedArray = new int[array1.length + array2.length];
/* 106 */     System.arraycopy(array1, 0, joinedArray, 0, array1.length);
/* 107 */     System.arraycopy(array2, 0, joinedArray, array1.length, array2.length);
/* 108 */     return joinedArray;
/*     */   }
/*     */   
/*     */   public static long[] addAllLong(long[] array1, long[] array2) {
/* 112 */     if (array1 == null)
/* 113 */       return cloneLong(array2); 
/* 114 */     if (array2 == null) {
/* 115 */       return cloneLong(array1);
/*     */     }
/* 117 */     long[] joinedArray = new long[array1.length + array2.length];
/* 118 */     System.arraycopy(array1, 0, joinedArray, 0, array1.length);
/* 119 */     System.arraycopy(array2, 0, joinedArray, array1.length, array2.length);
/* 120 */     return joinedArray;
/*     */   }
/*     */   
/*     */   public static Object[] addAllObj(Object[] array1, Object[] array2) {
/* 124 */     if (array1 == null)
/* 125 */       return cloneObj(array2); 
/* 126 */     if (array2 == null) {
/* 127 */       return cloneObj(array1);
/*     */     }
/* 129 */     Object[] joinedArray = (Object[])Array.newInstance(array1.getClass().getComponentType(), array1.length + array2.length);
/*     */     
/* 131 */     System.arraycopy(array1, 0, joinedArray, 0, array1.length);
/* 132 */     System.arraycopy(array2, 0, joinedArray, array1.length, array2.length);
/* 133 */     return joinedArray;
/*     */   }
/*     */   
/*     */   public static int[] cloneInt(int[] array) {
/* 137 */     if (array == null) {
/* 138 */       return null;
/*     */     }
/* 140 */     return (int[])array.clone();
/*     */   }
/*     */   
/*     */   public static long[] cloneLong(long[] array) {
/* 144 */     if (array == null) {
/* 145 */       return null;
/*     */     }
/* 147 */     return (long[])array.clone();
/*     */   }
/*     */   
/*     */   public static Object[] cloneObj(Object[] array) {
/* 151 */     if (array == null) {
/* 152 */       return null;
/*     */     }
/* 154 */     return (Object[])array.clone();
/*     */   }
/*     */   
/*     */   public static byte[] toByteArrayShifted(int[] array) {
/* 158 */     byte[] result = new byte[array.length];
/* 159 */     for (int i = 0; i < array.length; i++)
/* 160 */       result[i] = (byte)(array[i] - 128); 
/* 161 */     return result;
/*     */   }
/*     */   
/*     */   public static byte[][] toByteArrayShifted2(int[][] intArray) {
/* 165 */     byte[][] result = new byte[intArray.length][];
/* 166 */     for (int i = 0; i < intArray.length; i++) {
/* 167 */       result[i] = toByteArrayShifted(intArray[i]);
/*     */     }
/* 169 */     return result;
/*     */   }
/*     */   
/*     */   public static int[] toIntArrayUnshifted(byte[] bytes) {
/* 173 */     int[] result = new int[bytes.length];
/* 174 */     for (int i = 0; i < result.length; i++) {
/* 175 */       result[i] = (byte)(bytes[i] + 128);
/*     */     }
/* 177 */     return result;
/*     */   }
/*     */   
/*     */   public static byte[] toByteArray(int[] ints) {
/* 181 */     byte[] result = new byte[ints.length];
/* 182 */     for (int i = 0; i < ints.length; i++)
/* 183 */       result[i] = (byte)ints[i]; 
/* 184 */     return result;
/*     */   }
/*     */   
/*     */   public static int[] toIntArray(byte[] bytes) {
/* 188 */     int[] result = new int[bytes.length];
/* 189 */     for (int i = 0; i < result.length; i++) {
/* 190 */       result[i] = bytes[i];
/*     */     }
/* 192 */     return result;
/*     */   }
/*     */   
/*     */   public static int[] toUnsignedIntArray(byte[] bytes) {
/* 196 */     int[] result = new int[bytes.length];
/* 197 */     for (int i = 0; i < bytes.length; i++)
/* 198 */       result[i] = bytes[i] & 0xFF; 
/* 199 */     return result;
/*     */   }
/*     */   
/*     */   public static <T> void reverse(T[] frames) {
/* 203 */     for (int i = 0, j = frames.length - 1; i < frames.length >> 1; i++, j--) {
/* 204 */       T tmp = frames[i];
/* 205 */       frames[i] = frames[j];
/* 206 */       frames[j] = tmp;
/*     */     } 
/*     */   }
/*     */   
/*     */   public static int max(int[] array) {
/* 211 */     int max = Integer.MIN_VALUE;
/* 212 */     for (int i = 0; i < array.length; i++) {
/* 213 */       if (array[i] > max) {
/* 214 */         max = array[i];
/*     */       }
/*     */     } 
/*     */     
/* 218 */     return max;
/*     */   }
/*     */   
/*     */   public static int[][] rotate(int[][] src) {
/* 222 */     int[][] dst = new int[(src[0]).length][src.length];
/* 223 */     for (int i = 0; i < src.length; i++) {
/* 224 */       for (int j = 0; j < (src[0]).length; j++) {
/* 225 */         dst[j][i] = src[i][j];
/*     */       }
/*     */     } 
/* 228 */     return dst;
/*     */   }
/*     */   
/*     */   public static byte[][] create2D(int width, int height) {
/* 232 */     byte[][] result = new byte[height][];
/* 233 */     for (int i = 0; i < height; i++)
/* 234 */       result[i] = new byte[width]; 
/* 235 */     return result;
/*     */   }
/*     */   
/*     */   public static void printMatrixBytes(byte[] array, String format, int width) {
/* 239 */     String[] strings = new String[array.length];
/* 240 */     int maxLen = 0;
/* 241 */     for (int i = 0; i < array.length; i++) {
/* 242 */       strings[i] = String.format(format, new Object[] { Byte.valueOf(array[i]) });
/* 243 */       maxLen = Math.max(maxLen, strings[i].length());
/*     */     } 
/* 245 */     for (int ind = 0; ind < strings.length; ) {
/* 246 */       StringBuilder builder = new StringBuilder();
/* 247 */       for (int j = 0; j < width && ind < strings.length; j++, ind++) {
/* 248 */         for (int k = 0; k < maxLen - strings[ind].length() + 1; k++)
/* 249 */           builder.append(" "); 
/* 250 */         builder.append(strings[ind]);
/*     */       } 
/* 252 */       System.out.println(builder);
/*     */     } 
/*     */   }
/*     */   
/*     */   public static void printMatrix(int[] array, String format, int width) {
/* 257 */     String[] strings = new String[array.length];
/* 258 */     int maxLen = 0;
/* 259 */     for (int i = 0; i < array.length; i++) {
/* 260 */       strings[i] = String.format(format, new Object[] { Integer.valueOf(array[i]) });
/* 261 */       maxLen = Math.max(maxLen, strings[i].length());
/*     */     } 
/* 263 */     for (int ind = 0; ind < strings.length; ) {
/* 264 */       StringBuilder builder = new StringBuilder();
/* 265 */       for (int j = 0; j < width && ind < strings.length; j++, ind++) {
/* 266 */         for (int k = 0; k < maxLen - strings[ind].length() + 1; k++)
/* 267 */           builder.append(" "); 
/* 268 */         builder.append(strings[ind]);
/*     */       } 
/* 270 */       System.out.println(builder);
/*     */     } 
/*     */   }
/*     */   
/*     */   public static byte[] padLeft(byte[] array, int padLength) {
/* 275 */     byte[] result = new byte[array.length + padLength];
/* 276 */     for (int i = padLength; i < result.length; i++)
/* 277 */       result[i] = array[i - padLength]; 
/* 278 */     return result;
/*     */   }
/*     */   
/*     */   public static int[] randomIntArray(int size, int from, int to) {
/* 282 */     int width = to - from;
/* 283 */     int[] result = new int[size];
/* 284 */     for (int i = 0; i < size; i++)
/* 285 */       result[i] = (int)(Math.random() * width % width) + from; 
/* 286 */     return result;
/*     */   }
/*     */   
/*     */   public static byte[] randomByteArray(int size, byte from, byte to) {
/* 290 */     byte width = (byte)(to - from);
/* 291 */     byte[] result = new byte[size];
/* 292 */     for (int i = 0; i < size; i++)
/* 293 */       result[i] = (byte)(int)(Math.random() * width % width + from); 
/* 294 */     return result;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static void quickSort(int[] a, int start, int end, int[] p) {
/* 301 */     int len = end - start;
/* 302 */     if (len < 2) {
/*     */       return;
/*     */     }
/* 305 */     int startPlus1 = start + 1;
/* 306 */     if (len == 2) {
/* 307 */       if (a[start] > a[startPlus1]) {
/* 308 */         swap(a, start, startPlus1);
/* 309 */         if (p != null)
/* 310 */           swap(p, start, startPlus1); 
/*     */       }  return;
/*     */     } 
/* 313 */     if (len == 3) {
/* 314 */       if (a[start] > a[startPlus1]) {
/* 315 */         swap(a, start, startPlus1);
/* 316 */         if (p != null)
/* 317 */           swap(p, start, startPlus1); 
/*     */       } 
/* 319 */       int startPlus2 = start + 2;
/* 320 */       if (a[startPlus1] > a[startPlus2]) {
/* 321 */         swap(a, startPlus1, startPlus2);
/* 322 */         if (p != null)
/* 323 */           swap(p, startPlus1, startPlus2); 
/*     */       } 
/* 325 */       if (a[start] > a[startPlus1]) {
/* 326 */         swap(a, start, startPlus1);
/* 327 */         if (p != null) {
/* 328 */           swap(p, start, startPlus1);
/*     */         }
/*     */       } 
/*     */     } 
/* 332 */     int pivot = a[0];
/*     */ 
/*     */     
/* 335 */     int p_large = end - 1;
/* 336 */     for (int i = end - 1; i >= start; i--) {
/* 337 */       if (a[i] > pivot) {
/* 338 */         swap(a, i, p_large);
/* 339 */         if (p != null)
/* 340 */           swap(p, i, p_large); 
/* 341 */         p_large--;
/*     */       } 
/*     */     } 
/* 344 */     swap(a, start, p_large);
/* 345 */     if (p != null) {
/* 346 */       swap(p, start, p_large);
/*     */     }
/* 348 */     quickSort(a, start, p_large, p);
/* 349 */     quickSort(a, p_large + 1, end, p);
/*     */   }
/*     */   
/*     */   public static int[] flatten5D(int[][][][][] is) {
/* 353 */     IntArrayList list = new IntArrayList(128);
/* 354 */     flatten5DL(is, list);
/* 355 */     return list.toArray();
/*     */   }
/*     */   
/*     */   public static int[] flatten4D(int[][][][] is) {
/* 359 */     IntArrayList list = new IntArrayList(128);
/* 360 */     flatten4DL(is, list);
/* 361 */     return list.toArray();
/*     */   }
/*     */   
/*     */   public static int[] flatten3D(int[][][] is) {
/* 365 */     IntArrayList list = new IntArrayList(128);
/* 366 */     flatten3DL(is, list);
/* 367 */     return list.toArray();
/*     */   }
/*     */   
/*     */   public static int[] flatten2D(int[][] is) {
/* 371 */     IntArrayList list = new IntArrayList(128);
/* 372 */     flatten2DL(is, list);
/* 373 */     return list.toArray();
/*     */   }
/*     */   
/*     */   private static void flatten5DL(int[][][][][] is, IntArrayList list) {
/* 377 */     for (int i = 0; i < is.length; i++) {
/* 378 */       flatten4DL(is[i], list);
/*     */     }
/*     */   }
/*     */   
/*     */   private static void flatten4DL(int[][][][] is, IntArrayList list) {
/* 383 */     for (int i = 0; i < is.length; i++) {
/* 384 */       flatten3DL(is[i], list);
/*     */     }
/*     */   }
/*     */   
/*     */   private static void flatten3DL(int[][][] is, IntArrayList list) {
/* 389 */     for (int i = 0; i < is.length; i++) {
/* 390 */       flatten2DL(is[i], list);
/*     */     }
/*     */   }
/*     */   
/*     */   private static void flatten2DL(int[][] is, IntArrayList list) {
/* 395 */     for (int i = 0; i < is.length; i++) {
/* 396 */       flatten1DL(is[i], list);
/*     */     }
/*     */   }
/*     */   
/*     */   private static void flatten1DL(int[] is, IntArrayList list) {
/* 401 */     for (int i = 0; i < is.length; i++) {
/* 402 */       list.add(is[i]);
/*     */     }
/*     */   }
/*     */   
/*     */   public static void copy6D(int[][][][][][] to, int[][][][][][] from) {
/* 407 */     for (int i = 0; i < Math.min(to.length, from.length); i++) {
/* 408 */       copy5D(to[i], from[i]);
/*     */     }
/*     */   }
/*     */   
/*     */   public static void copy5D(int[][][][][] to, int[][][][][] from) {
/* 413 */     for (int i = 0; i < Math.min(to.length, from.length); i++) {
/* 414 */       copy4D(to[i], from[i]);
/*     */     }
/*     */   }
/*     */   
/*     */   public static void copy4D(int[][][][] to, int[][][][] from) {
/* 419 */     for (int i = 0; i < Math.min(to.length, from.length); i++) {
/* 420 */       copy3D(to[i], from[i]);
/*     */     }
/*     */   }
/*     */   
/*     */   public static void copy3D(int[][][] to, int[][][] from) {
/* 425 */     for (int i = 0; i < Math.min(to.length, from.length); i++) {
/* 426 */       copy2D(to[i], from[i]);
/*     */     }
/*     */   }
/*     */   
/*     */   public static void copy2D(int[][] to, int[][] from) {
/* 431 */     for (int i = 0; i < Math.min(to.length, from.length); i++) {
/* 432 */       copy1D(to[i], from[i]);
/*     */     }
/*     */   }
/*     */   
/*     */   public static void copy1D(int[] to, int[] from) {
/* 437 */     for (int i = 0; i < Math.min(to.length, from.length); i++) {
/* 438 */       to[i] = from[i];
/*     */     }
/*     */   }
/*     */   
/*     */   public static int fill6D(int[][][][][][] to, int[] from, int index) {
/* 443 */     for (int i = 0; i < to.length; i++) {
/* 444 */       index = fill5D(to[i], from, index);
/*     */     }
/* 446 */     return index;
/*     */   }
/*     */   
/*     */   public static int fill5D(int[][][][][] to, int[] from, int index) {
/* 450 */     for (int i = 0; i < to.length; i++) {
/* 451 */       index = fill4D(to[i], from, index);
/*     */     }
/* 453 */     return index;
/*     */   }
/*     */   
/*     */   public static int fill4D(int[][][][] to, int[] from, int index) {
/* 457 */     for (int i = 0; i < to.length; i++) {
/* 458 */       index = fill3D(to[i], from, index);
/*     */     }
/* 460 */     return index;
/*     */   }
/*     */   
/*     */   public static int fill3D(int[][][] to, int[] from, int index) {
/* 464 */     for (int i = 0; i < to.length; i++) {
/* 465 */       index = fill2D(to[i], from, index);
/*     */     }
/* 467 */     return index;
/*     */   }
/*     */   
/*     */   public static int fill2D(int[][] to, int[] from, int index) {
/* 471 */     for (int i = 0; i < to.length; i++) {
/* 472 */       index = fill1D(to[i], from, index);
/*     */     }
/* 474 */     return index;
/*     */   }
/*     */   
/*     */   public static int fill1D(int[] to, int[] from, int index) {
/* 478 */     for (int i = 0; i < to.length; i++) {
/* 479 */       to[i] = from[index++];
/*     */     }
/* 481 */     return index;
/*     */   }
/*     */ }


/* Location:              C:\Users\rapha\Downloads\aurora.jar!\META-INF\jars\jcodec-0.2.5.jar!\org\jcodec\common\ArrayUtil.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */