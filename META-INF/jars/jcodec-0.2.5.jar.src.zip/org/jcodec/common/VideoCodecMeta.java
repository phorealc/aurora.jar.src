/*    */ package org.jcodec.common;
/*    */ 
/*    */ import java.nio.ByteBuffer;
/*    */ import org.jcodec.common.model.ColorSpace;
/*    */ import org.jcodec.common.model.Rational;
/*    */ import org.jcodec.common.model.Size;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class VideoCodecMeta
/*    */   extends CodecMeta
/*    */ {
/*    */   private Size size;
/*    */   private Rational pasp;
/*    */   private boolean interlaced;
/*    */   private boolean topFieldFirst;
/*    */   private ColorSpace color;
/*    */   
/*    */   public static VideoCodecMeta createVideoCodecMeta(String fourcc, ByteBuffer codecPrivate, Size size, Rational pasp) {
/* 22 */     VideoCodecMeta self = new VideoCodecMeta(fourcc, codecPrivate);
/* 23 */     self.size = size;
/* 24 */     self.pasp = pasp;
/* 25 */     return self;
/*    */   }
/*    */ 
/*    */   
/*    */   public static VideoCodecMeta createVideoCodecMeta2(String fourcc, ByteBuffer codecPrivate, Size size, Rational pasp, boolean interlaced, boolean topFieldFirst) {
/* 30 */     VideoCodecMeta self = new VideoCodecMeta(fourcc, codecPrivate);
/* 31 */     self.size = size;
/* 32 */     self.pasp = pasp;
/* 33 */     self.interlaced = interlaced;
/* 34 */     self.topFieldFirst = topFieldFirst;
/* 35 */     return self;
/*    */   }
/*    */   
/*    */   public VideoCodecMeta(String fourcc, ByteBuffer codecPrivate) {
/* 39 */     super(fourcc, codecPrivate);
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public Size getSize() {
/* 49 */     return this.size;
/*    */   }
/*    */   
/*    */   public Rational getPasp() {
/* 53 */     return this.pasp;
/*    */   }
/*    */   
/*    */   public Rational getPixelAspectRatio() {
/* 57 */     return this.pasp;
/*    */   }
/*    */   
/*    */   public boolean isInterlaced() {
/* 61 */     return this.interlaced;
/*    */   }
/*    */   
/*    */   public boolean isTopFieldFirst() {
/* 65 */     return this.topFieldFirst;
/*    */   }
/*    */   
/*    */   public ColorSpace getColor() {
/* 69 */     return this.color;
/*    */   }
/*    */   
/*    */   public static VideoCodecMeta createSimpleVideoCodecMeta(Size size, ColorSpace color) {
/* 73 */     VideoCodecMeta self = new VideoCodecMeta(null, null);
/* 74 */     self.size = size;
/* 75 */     self.color = color;
/* 76 */     return self;
/*    */   }
/*    */   
/*    */   public void setPixelAspectRatio(Rational pasp) {
/* 80 */     this.pasp = pasp;
/*    */   }
/*    */ }


/* Location:              C:\Users\rapha\Downloads\aurora.jar!\META-INF\jars\jcodec-0.2.5.jar!\org\jcodec\common\VideoCodecMeta.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */