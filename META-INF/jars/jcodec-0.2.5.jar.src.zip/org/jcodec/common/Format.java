/*    */ package org.jcodec.common;
/*    */ 
/*    */ import java.util.LinkedHashMap;
/*    */ import java.util.Map;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public final class Format
/*    */ {
/* 16 */   public static final Format MOV = new Format("MOV", true, true);
/* 17 */   public static final Format MPEG_PS = new Format("MPEG_PS", true, true);
/* 18 */   public static final Format MPEG_TS = new Format("MPEG_TS", true, true);
/* 19 */   public static final Format MKV = new Format("MKV", true, true);
/* 20 */   public static final Format H264 = new Format("H264", true, false);
/* 21 */   public static final Format RAW = new Format("RAW", true, true);
/* 22 */   public static final Format FLV = new Format("FLV", true, true);
/* 23 */   public static final Format AVI = new Format("AVI", true, true);
/* 24 */   public static final Format IMG = new Format("IMG", true, false);
/* 25 */   public static final Format IVF = new Format("IVF", true, false);
/* 26 */   public static final Format MJPEG = new Format("MJPEG", true, false);
/* 27 */   public static final Format Y4M = new Format("Y4M", true, false);
/* 28 */   public static final Format WAV = new Format("WAV", false, true);
/* 29 */   public static final Format WEBP = new Format("WEBP", true, false);
/* 30 */   public static final Format MPEG_AUDIO = new Format("MPEG_AUDIO", false, true);
/*    */   
/* 32 */   private static final Map<String, Format> _values = new LinkedHashMap<String, Format>();
/*    */   static {
/* 34 */     _values.put("MOV", MOV);
/* 35 */     _values.put("MPEG_PS", MPEG_PS);
/* 36 */     _values.put("MPEG_TS", MPEG_TS);
/* 37 */     _values.put("MKV", MKV);
/* 38 */     _values.put("H264", H264);
/* 39 */     _values.put("RAW", RAW);
/* 40 */     _values.put("FLV", FLV);
/* 41 */     _values.put("AVI", AVI);
/* 42 */     _values.put("IMG", IMG);
/* 43 */     _values.put("IVF", IVF);
/* 44 */     _values.put("MJPEG", MJPEG);
/* 45 */     _values.put("Y4M", Y4M);
/* 46 */     _values.put("WAV", WAV);
/* 47 */     _values.put("WEBP", WEBP);
/* 48 */     _values.put("MPEG_AUDIO", MPEG_AUDIO);
/*    */   }
/*    */   
/*    */   private final boolean video;
/*    */   private final boolean audio;
/*    */   private final String name;
/*    */   
/*    */   private Format(String name, boolean video, boolean audio) {
/* 56 */     this.name = name;
/* 57 */     this.video = video;
/* 58 */     this.audio = audio;
/*    */   }
/*    */   
/*    */   public boolean isAudio() {
/* 62 */     return this.audio;
/*    */   }
/*    */   
/*    */   public boolean isVideo() {
/* 66 */     return this.video;
/*    */   }
/*    */   
/*    */   public static Format valueOf(String s) {
/* 70 */     return _values.get(s);
/*    */   }
/*    */ }


/* Location:              C:\Users\rapha\Downloads\aurora.jar!\META-INF\jars\jcodec-0.2.5.jar!\org\jcodec\common\Format.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */