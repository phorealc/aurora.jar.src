/*    */ package org.jcodec.common;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class Vector2Int
/*    */ {
/*    */   public static int el16_0(int packed) {
/* 14 */     return packed << 16 >> 16;
/*    */   }
/*    */   
/*    */   public static int el16_1(int packed) {
/* 18 */     return packed >> 16;
/*    */   }
/*    */   
/*    */   public static int el16(int packed, int n) {
/* 22 */     switch (n) {
/*    */       case 0:
/* 24 */         return el16_0(packed);
/*    */     } 
/* 26 */     return el16_1(packed);
/*    */   }
/*    */ 
/*    */   
/*    */   public static int set16_0(int packed, int el) {
/* 31 */     return packed & 0xFFFF0000 | el & 0xFFFF;
/*    */   }
/*    */   
/*    */   public static int set16_1(int packed, int el) {
/* 35 */     return packed & 0xFFFF | (el & 0xFFFF) << 16;
/*    */   }
/*    */   
/*    */   public static int set16(int packed, int el, int n) {
/* 39 */     switch (n) {
/*    */       case 0:
/* 41 */         return set16_0(packed, el);
/*    */     } 
/* 43 */     return set16_1(packed, el);
/*    */   }
/*    */ 
/*    */   
/*    */   public static int pack16(int el0, int el1) {
/* 48 */     return (el1 & 0xFFFF) << 16 | el0 & 0xFFFF;
/*    */   }
/*    */ }


/* Location:              C:\Users\rapha\Downloads\aurora.jar!\META-INF\jars\jcodec-0.2.5.jar!\org\jcodec\common\Vector2Int.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */