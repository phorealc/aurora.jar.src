/*    */ package org.jcodec.common;
/*    */ 
/*    */ import java.util.Arrays;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class ByteArrayList
/*    */ {
/*    */   private static final int DEFAULT_GROW_AMOUNT = 2048;
/*    */   private byte[] storage;
/*    */   private int _size;
/*    */   private int growAmount;
/*    */   
/*    */   public static ByteArrayList createByteArrayList() {
/* 17 */     return new ByteArrayList(2048);
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public ByteArrayList(int growAmount) {
/* 26 */     this.growAmount = growAmount;
/* 27 */     this.storage = new byte[growAmount];
/*    */   }
/*    */   
/*    */   public byte[] toArray() {
/* 31 */     byte[] result = new byte[this._size];
/* 32 */     System.arraycopy(this.storage, 0, result, 0, this._size);
/* 33 */     return result;
/*    */   }
/*    */   
/*    */   public void add(byte val) {
/* 37 */     if (this._size >= this.storage.length) {
/* 38 */       byte[] ns = new byte[this.storage.length + this.growAmount];
/* 39 */       System.arraycopy(this.storage, 0, ns, 0, this.storage.length);
/* 40 */       this.storage = ns;
/*    */     } 
/* 42 */     this.storage[this._size++] = val;
/*    */   }
/*    */   
/*    */   public void push(byte id) {
/* 46 */     add(id);
/*    */   }
/*    */   
/*    */   public void pop() {
/* 50 */     if (this._size == 0)
/*    */       return; 
/* 52 */     this._size--;
/*    */   }
/*    */   
/*    */   public void set(int index, byte value) {
/* 56 */     this.storage[index] = value;
/*    */   }
/*    */   
/*    */   public byte get(int index) {
/* 60 */     return this.storage[index];
/*    */   }
/*    */   
/*    */   public void fill(int start, int end, byte val) {
/* 64 */     if (end > this.storage.length) {
/* 65 */       byte[] ns = new byte[end + this.growAmount];
/* 66 */       System.arraycopy(this.storage, 0, ns, 0, this.storage.length);
/* 67 */       this.storage = ns;
/*    */     } 
/* 69 */     Arrays.fill(this.storage, start, end, val);
/* 70 */     this._size = Math.max(this._size, end);
/*    */   }
/*    */   
/*    */   public int size() {
/* 74 */     return this._size;
/*    */   }
/*    */   
/*    */   public void addAll(byte[] other) {
/* 78 */     if (this._size + other.length >= this.storage.length) {
/* 79 */       byte[] ns = new byte[this._size + this.growAmount + other.length];
/* 80 */       System.arraycopy(this.storage, 0, ns, 0, this._size);
/* 81 */       this.storage = ns;
/*    */     } 
/* 83 */     System.arraycopy(other, 0, this.storage, this._size, other.length);
/* 84 */     this._size += other.length;
/*    */   }
/*    */   
/*    */   public boolean contains(byte needle) {
/* 88 */     for (int i = 0; i < this._size; i++) {
/* 89 */       if (this.storage[i] == needle)
/* 90 */         return true; 
/* 91 */     }  return false;
/*    */   }
/*    */ }


/* Location:              C:\Users\rapha\Downloads\aurora.jar!\META-INF\jars\jcodec-0.2.5.jar!\org\jcodec\common\ByteArrayList.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */