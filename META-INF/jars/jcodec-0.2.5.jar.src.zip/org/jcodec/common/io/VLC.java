/*     */ package org.jcodec.common.io;
/*     */ 
/*     */ import java.io.PrintStream;
/*     */ import org.jcodec.common.IntArrayList;
/*     */ import org.jcodec.platform.Platform;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class VLC
/*     */ {
/*     */   private int[] codes;
/*     */   private int[] codeSizes;
/*     */   private int[] values;
/*     */   private int[] valueSizes;
/*     */   
/*     */   public static VLC createVLC(String[] codes) {
/*  25 */     IntArrayList _codes = IntArrayList.createIntArrayList();
/*  26 */     IntArrayList _codeSizes = IntArrayList.createIntArrayList();
/*  27 */     for (int i = 0; i < codes.length; i++) {
/*  28 */       String string = codes[i];
/*  29 */       _codes.add(Integer.parseInt(string, 2) << 32 - string.length());
/*  30 */       _codeSizes.add(string.length());
/*     */     } 
/*  32 */     VLC vlc = new VLC(_codes.toArray(), _codeSizes.toArray());
/*  33 */     return vlc;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public VLC(int[] codes, int[] codeSizes) {
/*  43 */     this.codes = codes;
/*  44 */     this.codeSizes = codeSizes;
/*     */     
/*  46 */     _invert();
/*     */   }
/*     */   
/*     */   private void _invert() {
/*  50 */     IntArrayList values = IntArrayList.createIntArrayList();
/*  51 */     IntArrayList valueSizes = IntArrayList.createIntArrayList();
/*  52 */     invert(0, 0, 0, values, valueSizes);
/*  53 */     this.values = values.toArray();
/*  54 */     this.valueSizes = valueSizes.toArray();
/*     */   }
/*     */ 
/*     */   
/*     */   private int invert(int startOff, int level, int prefix, IntArrayList values, IntArrayList valueSizes) {
/*  59 */     int tableEnd = startOff + 256;
/*  60 */     values.fill(startOff, tableEnd, -1);
/*  61 */     valueSizes.fill(startOff, tableEnd, 0);
/*     */     
/*  63 */     int prefLen = level << 3;
/*  64 */     for (int i = 0; i < this.codeSizes.length; i++) {
/*  65 */       if (this.codeSizes[i] > prefLen && (level <= 0 || this.codes[i] >>> 32 - prefLen == prefix)) {
/*     */ 
/*     */         
/*  68 */         int pref = this.codes[i] >>> 32 - prefLen - 8;
/*  69 */         int code = pref & 0xFF;
/*  70 */         int len = this.codeSizes[i] - prefLen;
/*  71 */         if (len <= 8) {
/*  72 */           for (int k = 0; k < 1 << 8 - len; k++) {
/*  73 */             values.set(startOff + code + k, i);
/*  74 */             valueSizes.set(startOff + code + k, len);
/*     */           }
/*     */         
/*  77 */         } else if (values.get(startOff + code) == -1) {
/*  78 */           values.set(startOff + code, tableEnd);
/*  79 */           tableEnd = invert(tableEnd, level + 1, pref, values, valueSizes);
/*     */         } 
/*     */       } 
/*     */     } 
/*     */     
/*  84 */     return tableEnd;
/*     */   }
/*     */ 
/*     */   
/*     */   public int readVLC16(BitReader _in) {
/*  89 */     int string = _in.check16Bits();
/*  90 */     int b = string >>> 8;
/*  91 */     int code = this.values[b];
/*  92 */     int len = this.valueSizes[b];
/*     */     
/*  94 */     if (len == 0) {
/*  95 */       b = (string & 0xFF) + code;
/*  96 */       code = this.values[b];
/*  97 */       _in.skipFast(8 + this.valueSizes[b]);
/*     */     } else {
/*  99 */       _in.skipFast(len);
/*     */     } 
/* 101 */     return code;
/*     */   }
/*     */ 
/*     */   
/*     */   public int readVLC(BitReader _in) {
/* 106 */     int code = 0, len = 0, overall = 0, total = 0;
/* 107 */     for (int i = 0; len == 0; i++) {
/* 108 */       int string = _in.checkNBit(8);
/* 109 */       int ind = string + code;
/* 110 */       code = this.values[ind];
/* 111 */       len = this.valueSizes[ind];
/*     */       
/* 113 */       int bits = (len != 0) ? len : 8;
/* 114 */       total += bits;
/* 115 */       overall = overall << bits | string >> 8 - bits;
/* 116 */       _in.skip(bits);
/*     */       
/* 118 */       if (code == -1) {
/* 119 */         throw new RuntimeException("Invalid code prefix " + binary(overall, (i << 3) + bits));
/*     */       }
/*     */     } 
/*     */ 
/*     */     
/* 124 */     return code;
/*     */   }
/*     */   
/*     */   private static String binary(int string, int len) {
/* 128 */     char[] symb = new char[len];
/* 129 */     for (int i = 0; i < len; i++) {
/* 130 */       symb[i] = ((string & 1 << len - i - 1) != 0) ? '1' : '0';
/*     */     }
/* 132 */     return Platform.stringFromChars(symb);
/*     */   }
/*     */   
/*     */   public void writeVLC(BitWriter out, int code) {
/* 136 */     out.writeNBit(this.codes[code] >>> 32 - this.codeSizes[code], this.codeSizes[code]);
/*     */   }
/*     */   
/*     */   public void printTable(PrintStream ps) {
/* 140 */     for (int i = 0; i < this.values.length; i++) {
/* 141 */       ps.println(i + ": " + extracted(i) + " (" + this.valueSizes[i] + ") -> " + this.values[i]);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private static String extracted(int num) {
/* 148 */     String str = Integer.toString(num & 0xFF, 2);
/* 149 */     StringBuilder builder = new StringBuilder();
/* 150 */     for (int i = 0; i < 8 - str.length(); i++)
/* 151 */       builder.append("0"); 
/* 152 */     builder.append(str);
/* 153 */     return builder.toString();
/*     */   }
/*     */   
/*     */   public int[] getCodes() {
/* 157 */     return this.codes;
/*     */   }
/*     */   
/*     */   public int[] getCodeSizes() {
/* 161 */     return this.codeSizes;
/*     */   }
/*     */ }


/* Location:              C:\Users\rapha\Downloads\aurora.jar!\META-INF\jars\jcodec-0.2.5.jar!\org\jcodec\common\io\VLC.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */