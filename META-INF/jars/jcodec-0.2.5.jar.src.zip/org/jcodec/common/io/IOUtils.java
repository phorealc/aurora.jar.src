/*    */ package org.jcodec.common.io;
/*    */ 
/*    */ import java.io.ByteArrayOutputStream;
/*    */ import java.io.Closeable;
/*    */ import java.io.File;
/*    */ import java.io.IOException;
/*    */ import java.io.InputStream;
/*    */ import java.io.OutputStream;
/*    */ import java.nio.ByteBuffer;
/*    */ import org.jcodec.platform.Platform;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class IOUtils
/*    */ {
/*    */   public static final int DEFAULT_BUFFER_SIZE = 4096;
/*    */   
/*    */   public static void closeQuietly(Closeable c) {
/* 24 */     if (c == null)
/*    */       return; 
/*    */     try {
/* 27 */       c.close();
/* 28 */     } catch (IOException iOException) {}
/*    */   }
/*    */ 
/*    */   
/*    */   public static byte[] toByteArray(InputStream input) throws IOException {
/* 33 */     ByteArrayOutputStream output = new ByteArrayOutputStream();
/* 34 */     copy(input, output);
/* 35 */     return output.toByteArray();
/*    */   }
/*    */   
/*    */   public static int copy(InputStream input, OutputStream output) throws IOException {
/* 39 */     byte[] buffer = new byte[4096];
/* 40 */     int count = 0;
/* 41 */     int n = 0;
/* 42 */     while (-1 != (n = input.read(buffer))) {
/* 43 */       output.write(buffer, 0, n);
/* 44 */       count += n;
/*    */     } 
/* 46 */     return count;
/*    */   }
/*    */   
/*    */   public static int copyDumb(InputStream input, OutputStream output) throws IOException {
/* 50 */     int count = 0;
/* 51 */     int n = 0;
/* 52 */     while (-1 != (n = input.read())) {
/* 53 */       output.write(n);
/* 54 */       count++;
/*    */     } 
/* 56 */     return count;
/*    */   }
/*    */   
/*    */   public static byte[] readFileToByteArray(File file) throws IOException {
/* 60 */     return NIOUtils.toArray(NIOUtils.fetchFromFile(file));
/*    */   }
/*    */   
/*    */   public static String readToString(InputStream is) throws IOException {
/* 64 */     return Platform.stringFromBytes(toByteArray(is));
/*    */   }
/*    */   
/*    */   public static void writeStringToFile(File file, String str) throws IOException {
/* 68 */     NIOUtils.writeTo(ByteBuffer.wrap(str.getBytes()), file);
/*    */   }
/*    */   
/*    */   public static void forceMkdir(File directory) throws IOException {
/* 72 */     if (directory.exists()) {
/* 73 */       if (!directory.isDirectory()) {
/* 74 */         String message = "File " + directory + " exists and is not a directory. Unable to create directory.";
/*    */         
/* 76 */         throw new IOException(message);
/*    */       }
/*    */     
/* 79 */     } else if (!directory.mkdirs()) {
/*    */ 
/*    */       
/* 82 */       if (!directory.isDirectory()) {
/* 83 */         String message = "Unable to create directory " + directory;
/* 84 */         throw new IOException(message);
/*    */       } 
/*    */     } 
/*    */   }
/*    */ 
/*    */   
/*    */   public static void copyFile(File src, File dst) throws IOException {
/* 91 */     FileChannelWrapper _in = null;
/* 92 */     FileChannelWrapper out = null;
/*    */     try {
/* 94 */       _in = NIOUtils.readableChannel(src);
/* 95 */       out = NIOUtils.writableChannel(dst);
/* 96 */       NIOUtils.copy(_in, out, Long.MAX_VALUE);
/*    */     } finally {
/* 98 */       NIOUtils.closeQuietly(_in);
/* 99 */       NIOUtils.closeQuietly(out);
/*    */     } 
/*    */   }
/*    */ }


/* Location:              C:\Users\rapha\Downloads\aurora.jar!\META-INF\jars\jcodec-0.2.5.jar!\org\jcodec\common\io\IOUtils.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */