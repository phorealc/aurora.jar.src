/*    */ package org.jcodec.common.io;
/*    */ 
/*    */ import org.jcodec.common.IntArrayList;
/*    */ import org.jcodec.common.IntIntMap;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class VLCBuilder
/*    */ {
/*    */   private IntIntMap forward;
/*    */   private IntIntMap inverse;
/*    */   private IntArrayList codes;
/*    */   private IntArrayList codesSizes;
/*    */   
/*    */   public static VLCBuilder createVLCBuilder(int[] codes, int[] lens, int[] vals) {
/* 19 */     VLCBuilder b = new VLCBuilder();
/* 20 */     for (int i = 0; i < codes.length; i++) {
/* 21 */       b.setInt(codes[i], lens[i], vals[i]);
/*    */     }
/* 23 */     return b;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public VLCBuilder() {
/* 32 */     this.forward = new IntIntMap();
/* 33 */     this.inverse = new IntIntMap();
/* 34 */     this.codes = IntArrayList.createIntArrayList();
/* 35 */     this.codesSizes = IntArrayList.createIntArrayList();
/*    */   }
/*    */   
/*    */   public VLCBuilder set(int val, String code) {
/* 39 */     setInt(Integer.parseInt(code, 2), code.length(), val);
/*    */     
/* 41 */     return this;
/*    */   }
/*    */   
/*    */   public VLCBuilder setInt(int code, int len, int val) {
/* 45 */     this.codes.add(code << 32 - len);
/* 46 */     this.codesSizes.add(len);
/* 47 */     this.forward.put(val, this.codes.size() - 1);
/* 48 */     this.inverse.put(this.codes.size() - 1, val);
/*    */     
/* 50 */     return this;
/*    */   }
/*    */   
/*    */   public VLC getVLC() {
/* 54 */     final VLCBuilder self = this;
/* 55 */     return new VLC(this.codes.toArray(), this.codesSizes.toArray()) {
/*    */         public int readVLC(BitReader _in) {
/* 57 */           return self.inverse.get(super.readVLC(_in));
/*    */         }
/*    */         
/*    */         public int readVLC16(BitReader _in) {
/* 61 */           return self.inverse.get(super.readVLC16(_in));
/*    */         }
/*    */         
/*    */         public void writeVLC(BitWriter out, int code) {
/* 65 */           super.writeVLC(out, self.forward.get(code));
/*    */         }
/*    */       };
/*    */   }
/*    */ }


/* Location:              C:\Users\rapha\Downloads\aurora.jar!\META-INF\jars\jcodec-0.2.5.jar!\org\jcodec\common\io\VLCBuilder.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */