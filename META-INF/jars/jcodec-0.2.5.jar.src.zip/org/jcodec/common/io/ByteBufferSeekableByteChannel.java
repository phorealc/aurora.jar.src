/*    */ package org.jcodec.common.io;
/*    */ 
/*    */ import java.io.IOException;
/*    */ import java.nio.ByteBuffer;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class ByteBufferSeekableByteChannel
/*    */   implements SeekableByteChannel
/*    */ {
/*    */   private ByteBuffer backing;
/*    */   private boolean open;
/*    */   private int contentLength;
/*    */   
/*    */   public ByteBufferSeekableByteChannel(ByteBuffer backing, int contentLength) {
/* 21 */     this.backing = backing;
/* 22 */     this.contentLength = contentLength;
/* 23 */     this.open = true;
/*    */   }
/*    */   
/*    */   public static ByteBufferSeekableByteChannel writeToByteBuffer(ByteBuffer buf) {
/* 27 */     return new ByteBufferSeekableByteChannel(buf, 0);
/*    */   }
/*    */   
/*    */   public static ByteBufferSeekableByteChannel readFromByteBuffer(ByteBuffer buf) {
/* 31 */     return new ByteBufferSeekableByteChannel(buf, buf.remaining());
/*    */   }
/*    */ 
/*    */   
/*    */   public boolean isOpen() {
/* 36 */     return this.open;
/*    */   }
/*    */ 
/*    */   
/*    */   public void close() throws IOException {
/* 41 */     this.open = false;
/*    */   }
/*    */ 
/*    */   
/*    */   public int read(ByteBuffer dst) throws IOException {
/* 46 */     if (!this.backing.hasRemaining() || this.contentLength <= 0) {
/* 47 */       return -1;
/*    */     }
/* 49 */     int toRead = Math.min(this.backing.remaining(), dst.remaining());
/* 50 */     toRead = Math.min(toRead, this.contentLength);
/* 51 */     dst.put(NIOUtils.read(this.backing, toRead));
/* 52 */     this.contentLength = Math.max(this.contentLength, this.backing.position());
/* 53 */     return toRead;
/*    */   }
/*    */ 
/*    */   
/*    */   public int write(ByteBuffer src) throws IOException {
/* 58 */     int toWrite = Math.min(this.backing.remaining(), src.remaining());
/* 59 */     this.backing.put(NIOUtils.read(src, toWrite));
/* 60 */     this.contentLength = Math.max(this.contentLength, this.backing.position());
/* 61 */     return toWrite;
/*    */   }
/*    */ 
/*    */   
/*    */   public long position() throws IOException {
/* 66 */     return this.backing.position();
/*    */   }
/*    */ 
/*    */   
/*    */   public SeekableByteChannel setPosition(long newPosition) throws IOException {
/* 71 */     this.backing.position((int)newPosition);
/* 72 */     this.contentLength = Math.max(this.contentLength, this.backing.position());
/* 73 */     return this;
/*    */   }
/*    */ 
/*    */   
/*    */   public long size() throws IOException {
/* 78 */     return this.contentLength;
/*    */   }
/*    */ 
/*    */   
/*    */   public SeekableByteChannel truncate(long size) throws IOException {
/* 83 */     this.contentLength = (int)size;
/* 84 */     return this;
/*    */   }
/*    */   
/*    */   public ByteBuffer getContents() {
/* 88 */     ByteBuffer contents = this.backing.duplicate();
/* 89 */     contents.position(0);
/* 90 */     contents.limit(this.contentLength);
/* 91 */     return contents;
/*    */   }
/*    */ }


/* Location:              C:\Users\rapha\Downloads\aurora.jar!\META-INF\jars\jcodec-0.2.5.jar!\org\jcodec\common\io\ByteBufferSeekableByteChannel.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */