/*    */ package org.jcodec.common.io;
/*    */ 
/*    */ import java.io.FileNotFoundException;
/*    */ import java.io.IOException;
/*    */ import java.nio.ByteBuffer;
/*    */ import java.nio.channels.FileChannel;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class FileChannelWrapper
/*    */   implements SeekableByteChannel
/*    */ {
/*    */   private FileChannel ch;
/*    */   
/*    */   public FileChannelWrapper(FileChannel ch) throws FileNotFoundException {
/* 20 */     this.ch = ch;
/*    */   }
/*    */ 
/*    */   
/*    */   public int read(ByteBuffer arg0) throws IOException {
/* 25 */     return this.ch.read(arg0);
/*    */   }
/*    */ 
/*    */   
/*    */   public void close() throws IOException {
/* 30 */     this.ch.close();
/*    */   }
/*    */ 
/*    */   
/*    */   public boolean isOpen() {
/* 35 */     return this.ch.isOpen();
/*    */   }
/*    */ 
/*    */   
/*    */   public int write(ByteBuffer arg0) throws IOException {
/* 40 */     return this.ch.write(arg0);
/*    */   }
/*    */ 
/*    */   
/*    */   public long position() throws IOException {
/* 45 */     return this.ch.position();
/*    */   }
/*    */ 
/*    */   
/*    */   public SeekableByteChannel setPosition(long newPosition) throws IOException {
/* 50 */     this.ch.position(newPosition);
/* 51 */     return this;
/*    */   }
/*    */ 
/*    */   
/*    */   public long size() throws IOException {
/* 56 */     return this.ch.size();
/*    */   }
/*    */ 
/*    */   
/*    */   public SeekableByteChannel truncate(long size) throws IOException {
/* 61 */     this.ch.truncate(size);
/* 62 */     return this;
/*    */   }
/*    */ }


/* Location:              C:\Users\rapha\Downloads\aurora.jar!\META-INF\jars\jcodec-0.2.5.jar!\org\jcodec\common\io\FileChannelWrapper.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */