/*     */ package org.jcodec.common.io;
/*     */ 
/*     */ import java.io.Closeable;
/*     */ import java.io.File;
/*     */ import java.io.FileInputStream;
/*     */ import java.io.FileNotFoundException;
/*     */ import java.io.FileOutputStream;
/*     */ import java.io.IOException;
/*     */ import java.io.RandomAccessFile;
/*     */ import java.nio.ByteBuffer;
/*     */ import java.nio.ByteOrder;
/*     */ import java.nio.MappedByteBuffer;
/*     */ import java.nio.channels.FileChannel;
/*     */ import java.nio.channels.ReadableByteChannel;
/*     */ import java.nio.channels.WritableByteChannel;
/*     */ import java.util.ArrayList;
/*     */ import java.util.List;
/*     */ import org.jcodec.common.ArrayUtil;
/*     */ import org.jcodec.common.AutoFileChannelWrapper;
/*     */ import org.jcodec.platform.Platform;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class NIOUtils
/*     */ {
/*     */   public static ByteBuffer search(ByteBuffer buffer, int n, byte[] param) {
/*  38 */     ByteBuffer result = buffer.duplicate();
/*  39 */     int step = 0, rem = buffer.position();
/*  40 */     while (buffer.hasRemaining()) {
/*  41 */       int b = buffer.get();
/*  42 */       if (b == param[step]) {
/*  43 */         step++;
/*  44 */         if (step == param.length) {
/*  45 */           if (n == 0) {
/*  46 */             buffer.position(rem);
/*  47 */             result.limit(buffer.position());
/*     */             break;
/*     */           } 
/*  50 */           n--;
/*  51 */           step = 0;
/*     */         }  continue;
/*     */       } 
/*  54 */       if (step != 0) {
/*  55 */         step = 0;
/*  56 */         rem++;
/*  57 */         buffer.position(rem); continue;
/*     */       } 
/*  59 */       rem = buffer.position();
/*     */     } 
/*     */     
/*  62 */     return result;
/*     */   }
/*     */   
/*     */   public static final ByteBuffer read(ByteBuffer buffer, int count) {
/*  66 */     ByteBuffer slice = buffer.duplicate();
/*  67 */     int limit = buffer.position() + count;
/*  68 */     slice.limit(limit);
/*  69 */     buffer.position(limit);
/*  70 */     return slice;
/*     */   }
/*     */   
/*     */   public static ByteBuffer fetchFromFile(File file) throws IOException {
/*  74 */     return fetchFromFileL(file, (int)file.length());
/*     */   }
/*     */   
/*     */   public static ByteBuffer fetchFromChannel(ReadableByteChannel ch, int size) throws IOException {
/*  78 */     ByteBuffer buf = ByteBuffer.allocate(size);
/*  79 */     readFromChannel(ch, buf);
/*  80 */     buf.flip();
/*  81 */     return buf;
/*     */   }
/*     */   public static ByteBuffer fetchAllFromChannel(SeekableByteChannel ch) throws IOException {
/*     */     ByteBuffer buf;
/*  85 */     List<ByteBuffer> buffers = new ArrayList<ByteBuffer>();
/*     */     
/*     */     do {
/*  88 */       buf = fetchFromChannel(ch, 1048576);
/*  89 */       buffers.add(buf);
/*  90 */     } while (buf.hasRemaining());
/*     */     
/*  92 */     return combineBuffers(buffers);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static ByteBuffer fetchFrom(ByteBuffer buf, ReadableByteChannel ch, int size) throws IOException {
/* 106 */     ByteBuffer result = buf.duplicate();
/* 107 */     result.limit(size);
/* 108 */     readFromChannel(ch, result);
/* 109 */     result.flip();
/* 110 */     return result;
/*     */   }
/*     */   
/*     */   public static ByteBuffer fetchFromFileL(File file, int length) throws IOException {
/* 114 */     FileChannel is = null;
/*     */     try {
/* 116 */       is = (new FileInputStream(file)).getChannel();
/* 117 */       return fetchFromChannel(is, length);
/*     */     } finally {
/* 119 */       closeQuietly(is);
/*     */     } 
/*     */   }
/*     */   
/*     */   public static void writeTo(ByteBuffer buffer, File file) throws IOException {
/* 124 */     FileChannel out = null;
/*     */     try {
/* 126 */       out = (new FileOutputStream(file)).getChannel();
/* 127 */       out.write(buffer);
/*     */     } finally {
/* 129 */       closeQuietly(out);
/*     */     } 
/*     */   }
/*     */   
/*     */   public static byte[] toArray(ByteBuffer buffer) {
/* 134 */     byte[] result = new byte[buffer.remaining()];
/* 135 */     buffer.duplicate().get(result);
/* 136 */     return result;
/*     */   }
/*     */   
/*     */   public static byte[] toArrayL(ByteBuffer buffer, int count) {
/* 140 */     byte[] result = new byte[Math.min(buffer.remaining(), count)];
/* 141 */     buffer.duplicate().get(result);
/* 142 */     return result;
/*     */   }
/*     */   
/*     */   public static int readL(ReadableByteChannel channel, ByteBuffer buffer, int length) throws IOException {
/* 146 */     ByteBuffer fork = buffer.duplicate();
/* 147 */     fork.limit(Math.min(fork.position() + length, fork.limit()));
/* 148 */     while (channel.read(fork) != -1 && fork.hasRemaining());
/*     */     
/* 150 */     buffer.position(fork.position());
/* 151 */     return (buffer.position() == 0) ? -1 : buffer.position();
/*     */   }
/*     */   
/*     */   public static int readFromChannel(ReadableByteChannel channel, ByteBuffer buffer) throws IOException {
/* 155 */     int rem = buffer.position();
/* 156 */     while (channel.read(buffer) != -1 && buffer.hasRemaining());
/*     */     
/* 158 */     return buffer.position() - rem;
/*     */   }
/*     */   
/*     */   public static void write(ByteBuffer to, ByteBuffer from) {
/* 162 */     if (from.hasArray()) {
/* 163 */       to.put(from.array(), from.arrayOffset() + from.position(), Math.min(to.remaining(), from.remaining()));
/*     */     } else {
/* 165 */       to.put(toArrayL(from, to.remaining()));
/*     */     } 
/*     */   }
/*     */   
/*     */   public static void writeL(ByteBuffer to, ByteBuffer from, int count) {
/* 170 */     if (from.hasArray()) {
/* 171 */       to.put(from.array(), from.arrayOffset() + from.position(), Math.min(from.remaining(), count));
/*     */     } else {
/* 173 */       to.put(toArrayL(from, count));
/*     */     } 
/*     */   }
/*     */   
/*     */   public static void fill(ByteBuffer buffer, byte val) {
/* 178 */     while (buffer.hasRemaining())
/* 179 */       buffer.put(val); 
/*     */   }
/*     */   
/*     */   public static final MappedByteBuffer map(String fileName) throws IOException {
/* 183 */     return mapFile(new File(fileName));
/*     */   }
/*     */   
/*     */   public static final MappedByteBuffer mapFile(File file) throws IOException {
/* 187 */     FileInputStream is = new FileInputStream(file);
/* 188 */     MappedByteBuffer map = is.getChannel().map(FileChannel.MapMode.READ_ONLY, 0L, file.length());
/* 189 */     is.close();
/* 190 */     return map;
/*     */   }
/*     */   
/*     */   public static int skip(ByteBuffer buffer, int count) {
/* 194 */     int toSkip = Math.min(buffer.remaining(), count);
/* 195 */     buffer.position(buffer.position() + toSkip);
/* 196 */     return toSkip;
/*     */   }
/*     */   
/*     */   public static ByteBuffer from(ByteBuffer buffer, int offset) {
/* 200 */     ByteBuffer dup = buffer.duplicate();
/* 201 */     dup.position(dup.position() + offset);
/* 202 */     return dup;
/*     */   }
/*     */   
/*     */   public static ByteBuffer combineBuffers(Iterable<ByteBuffer> picture) {
/* 206 */     int size = 0;
/* 207 */     for (ByteBuffer byteBuffer : picture) {
/* 208 */       size += byteBuffer.remaining();
/*     */     }
/* 210 */     ByteBuffer result = ByteBuffer.allocate(size);
/* 211 */     for (ByteBuffer byteBuffer : picture) {
/* 212 */       write(result, byteBuffer);
/*     */     }
/* 214 */     result.flip();
/* 215 */     return result;
/*     */   }
/*     */   
/*     */   public static boolean combineBuffersInto(ByteBuffer dup, List<ByteBuffer> buffers) {
/* 219 */     throw new RuntimeException("Stan");
/*     */   }
/*     */   
/*     */   public static String readString(ByteBuffer buffer, int len) {
/* 223 */     return Platform.stringFromBytes(toArray(read(buffer, len)));
/*     */   }
/*     */   
/*     */   public static String readPascalStringL(ByteBuffer buffer, int maxLen) {
/* 227 */     ByteBuffer sub = read(buffer, maxLen + 1);
/* 228 */     return Platform.stringFromBytes(toArray(read(sub, Math.min(sub.get() & 0xFF, maxLen))));
/*     */   }
/*     */   
/*     */   public static void writePascalStringL(ByteBuffer buffer, String string, int maxLen) {
/* 232 */     buffer.put((byte)string.length());
/* 233 */     buffer.put(asciiString(string));
/* 234 */     skip(buffer, maxLen - string.length());
/*     */   }
/*     */   
/*     */   public static byte[] asciiString(String fourcc) {
/* 238 */     return Platform.getBytes(fourcc);
/*     */   }
/*     */   
/*     */   public static void writePascalString(ByteBuffer buffer, String name) {
/* 242 */     buffer.put((byte)name.length());
/* 243 */     buffer.put(asciiString(name));
/*     */   }
/*     */   
/*     */   public static String readPascalString(ByteBuffer buffer) {
/* 247 */     return readString(buffer, buffer.get() & 0xFF);
/*     */   }
/*     */   
/*     */   public static String readNullTermString(ByteBuffer buffer) {
/* 251 */     return readNullTermStringCharset(buffer, "UTF-8");
/*     */   }
/*     */   
/*     */   public static String readNullTermStringCharset(ByteBuffer buffer, String charset) {
/* 255 */     ByteBuffer fork = buffer.duplicate();
/* 256 */     while (buffer.hasRemaining() && buffer.get() != 0);
/*     */     
/* 258 */     if (buffer.hasRemaining())
/* 259 */       fork.limit(buffer.position() - 1); 
/* 260 */     return Platform.stringFromCharset(toArray(fork), charset);
/*     */   }
/*     */   
/*     */   public static ByteBuffer readBuf(ByteBuffer buffer) {
/* 264 */     ByteBuffer result = buffer.duplicate();
/* 265 */     buffer.position(buffer.limit());
/* 266 */     return result;
/*     */   }
/*     */   public static void copy(ReadableByteChannel _in, WritableByteChannel out, long amount) throws IOException {
/*     */     int read;
/* 270 */     ByteBuffer buf = ByteBuffer.allocate(65536);
/*     */     
/*     */     do {
/* 273 */       buf.position(0);
/* 274 */       buf.limit((int)Math.min(amount, buf.capacity()));
/* 275 */       read = _in.read(buf);
/* 276 */       if (read == -1)
/* 277 */         continue;  buf.flip();
/* 278 */       out.write(buf);
/* 279 */       amount -= read;
/*     */     }
/* 281 */     while (read != -1 && amount > 0L);
/*     */   }
/*     */   
/*     */   public static void closeQuietly(Closeable channel) {
/* 285 */     if (channel == null)
/*     */       return; 
/*     */     try {
/* 288 */       channel.close();
/* 289 */     } catch (IOException iOException) {}
/*     */   }
/*     */ 
/*     */   
/*     */   public static byte readByte(ReadableByteChannel channel) throws IOException {
/* 294 */     ByteBuffer buf = ByteBuffer.allocate(1);
/* 295 */     channel.read(buf);
/* 296 */     buf.flip();
/* 297 */     return buf.get();
/*     */   }
/*     */   
/*     */   public static byte[] readNByte(ReadableByteChannel channel, int n) throws IOException {
/* 301 */     byte[] result = new byte[n];
/* 302 */     channel.read(ByteBuffer.wrap(result));
/* 303 */     return result;
/*     */   }
/*     */   
/*     */   public static int readInt(ReadableByteChannel channel) throws IOException {
/* 307 */     ByteBuffer buf = ByteBuffer.allocate(4);
/* 308 */     channel.read(buf);
/* 309 */     buf.flip();
/* 310 */     return buf.getInt();
/*     */   }
/*     */   
/*     */   public static int readIntOrder(ReadableByteChannel channel, ByteOrder order) throws IOException {
/* 314 */     ByteBuffer buf = ByteBuffer.allocate(4).order(order);
/* 315 */     channel.read(buf);
/* 316 */     buf.flip();
/* 317 */     return buf.getInt();
/*     */   }
/*     */   
/*     */   public static void writeByte(WritableByteChannel channel, byte value) throws IOException {
/* 321 */     channel.write((ByteBuffer)ByteBuffer.allocate(1).put(value).flip());
/*     */   }
/*     */   
/*     */   public static void writeIntOrder(WritableByteChannel channel, int value, ByteOrder order) throws IOException {
/* 325 */     ByteBuffer order2 = ByteBuffer.allocate(4).order(order);
/* 326 */     channel.write((ByteBuffer)order2.putInt(value).flip());
/*     */   }
/*     */   
/*     */   public static void writeIntLE(WritableByteChannel channel, int value) throws IOException {
/* 330 */     ByteBuffer allocate = ByteBuffer.allocate(4);
/* 331 */     allocate.order(ByteOrder.LITTLE_ENDIAN);
/* 332 */     channel.write((ByteBuffer)allocate.putInt(value).flip());
/*     */   }
/*     */   
/*     */   public static void writeInt(WritableByteChannel channel, int value) throws IOException {
/* 336 */     channel.write((ByteBuffer)ByteBuffer.allocate(4).putInt(value).flip());
/*     */   }
/*     */   
/*     */   public static void writeLong(WritableByteChannel channel, long value) throws IOException {
/* 340 */     channel.write((ByteBuffer)ByteBuffer.allocate(8).putLong(value).flip());
/*     */   }
/*     */   
/*     */   public static FileChannelWrapper readableChannel(File file) throws FileNotFoundException {
/* 344 */     return new FileChannelWrapper((new FileInputStream(file)).getChannel());
/*     */   }
/*     */   
/*     */   public static FileChannelWrapper writableChannel(File file) throws FileNotFoundException {
/* 348 */     return new FileChannelWrapper((new FileOutputStream(file)).getChannel());
/*     */   }
/*     */   
/*     */   public static FileChannelWrapper rwChannel(File file) throws FileNotFoundException {
/* 352 */     return new FileChannelWrapper((new RandomAccessFile(file, "rw")).getChannel());
/*     */   }
/*     */   
/*     */   public static FileChannelWrapper readableFileChannel(String file) throws FileNotFoundException {
/* 356 */     return new FileChannelWrapper((new FileInputStream(file)).getChannel());
/*     */   }
/*     */   
/*     */   public static FileChannelWrapper writableFileChannel(String file) throws FileNotFoundException {
/* 360 */     return new FileChannelWrapper((new FileOutputStream(file)).getChannel());
/*     */   }
/*     */   
/*     */   public static FileChannelWrapper rwFileChannel(String file) throws FileNotFoundException {
/* 364 */     return new FileChannelWrapper((new RandomAccessFile(file, "rw")).getChannel());
/*     */   }
/*     */   
/*     */   public static AutoFileChannelWrapper autoChannel(File file) throws IOException {
/* 368 */     return new AutoFileChannelWrapper(file);
/*     */   }
/*     */   
/*     */   public static ByteBuffer duplicate(ByteBuffer bb) {
/* 372 */     ByteBuffer out = ByteBuffer.allocate(bb.remaining());
/* 373 */     out.put(bb.duplicate());
/* 374 */     out.flip();
/* 375 */     return out;
/*     */   }
/*     */   
/*     */   public static int find(List<ByteBuffer> catalog, ByteBuffer key) {
/* 379 */     byte[] keyA = toArray(key);
/* 380 */     for (int i = 0; i < catalog.size(); i++) {
/* 381 */       if (Platform.arrayEqualsByte(toArray(catalog.get(i)), keyA))
/* 382 */         return i; 
/*     */     } 
/* 384 */     return -1;
/*     */   }
/*     */ 
/*     */   
/*     */   public static abstract class FileReader
/*     */   {
/*     */     private int oldPd;
/*     */ 
/*     */     
/*     */     protected abstract void data(ByteBuffer param1ByteBuffer, long param1Long);
/*     */ 
/*     */     
/*     */     protected abstract void done();
/*     */     
/*     */     public void readChannel(SeekableByteChannel ch, int bufferSize, NIOUtils.FileReaderListener listener) throws IOException {
/* 399 */       ByteBuffer buf = ByteBuffer.allocate(bufferSize);
/* 400 */       long size = ch.size(); long pos;
/* 401 */       for (pos = ch.position(); ch.read(buf) != -1; pos = ch.position()) {
/* 402 */         buf.flip();
/* 403 */         data(buf, pos);
/* 404 */         buf.flip();
/* 405 */         if (listener != null) {
/* 406 */           int newPd = (int)(100L * pos / size);
/* 407 */           if (newPd != this.oldPd)
/* 408 */             listener.progress(newPd); 
/* 409 */           this.oldPd = newPd;
/*     */         } 
/*     */       } 
/* 412 */       done();
/*     */     }
/*     */     
/*     */     public void readFile(File source, int bufferSize, NIOUtils.FileReaderListener listener) throws IOException {
/* 416 */       SeekableByteChannel ch = null;
/*     */       try {
/* 418 */         ch = NIOUtils.readableChannel(source);
/* 419 */         readChannel(ch, bufferSize, listener);
/*     */       } finally {
/* 421 */         NIOUtils.closeQuietly(ch);
/*     */       } 
/*     */     }
/*     */   }
/*     */   
/*     */   public static byte getRel(ByteBuffer bb, int rel) {
/* 427 */     return bb.get(bb.position() + rel);
/*     */   }
/*     */   
/*     */   public static ByteBuffer cloneBuffer(ByteBuffer pesBuffer) {
/* 431 */     ByteBuffer res = ByteBuffer.allocate(pesBuffer.remaining());
/* 432 */     res.put(pesBuffer.duplicate());
/* 433 */     res.clear();
/* 434 */     return res;
/*     */   }
/*     */   
/*     */   public static ByteBuffer clone(ByteBuffer byteBuffer) {
/* 438 */     ByteBuffer result = ByteBuffer.allocate(byteBuffer.remaining());
/* 439 */     result.put(byteBuffer.duplicate());
/* 440 */     result.flip();
/* 441 */     return result;
/*     */   }
/*     */   
/*     */   public static ByteBuffer asByteBuffer(byte[] bytes) {
/* 445 */     return ByteBuffer.wrap(bytes);
/*     */   }
/*     */   
/*     */   public static ByteBuffer asByteBufferInt(int[] ints) {
/* 449 */     return asByteBuffer(ArrayUtil.toByteArray(ints));
/*     */   }
/*     */   
/*     */   public static void relocateLeftover(ByteBuffer bb) {
/*     */     int pos;
/* 454 */     for (pos = 0; bb.hasRemaining(); pos++) {
/* 455 */       bb.put(pos, bb.get());
/*     */     }
/* 457 */     bb.position(pos);
/* 458 */     bb.limit(bb.capacity());
/*     */   }
/*     */   
/*     */   public static interface FileReaderListener {
/*     */     void progress(int param1Int);
/*     */   }
/*     */ }


/* Location:              C:\Users\rapha\Downloads\aurora.jar!\META-INF\jars\jcodec-0.2.5.jar!\org\jcodec\common\io\NIOUtils.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */