/*     */ package org.jcodec.common.io;
/*     */ 
/*     */ import java.nio.ByteBuffer;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class BitReader
/*     */ {
/*     */   public static BitReader createBitReader(ByteBuffer bb) {
/*  14 */     BitReader r = new BitReader(bb);
/*  15 */     r.curInt = r.readInt();
/*  16 */     r.deficit = 0;
/*  17 */     return r;
/*     */   }
/*     */   
/*  20 */   private int deficit = -1;
/*  21 */   private int curInt = -1;
/*     */   private ByteBuffer bb;
/*     */   private int initPos;
/*     */   
/*     */   private BitReader(ByteBuffer bb) {
/*  26 */     this.bb = bb;
/*  27 */     this.initPos = bb.position();
/*     */   }
/*     */   
/*     */   public BitReader fork() {
/*  31 */     BitReader fork = new BitReader(this.bb.duplicate());
/*  32 */     fork.initPos = 0;
/*  33 */     fork.curInt = this.curInt;
/*  34 */     fork.deficit = this.deficit;
/*  35 */     return fork;
/*     */   }
/*     */   
/*     */   public final int readInt() {
/*  39 */     if (this.bb.remaining() >= 4) {
/*  40 */       this.deficit -= 32;
/*  41 */       return (this.bb.get() & 0xFF) << 24 | (this.bb.get() & 0xFF) << 16 | (this.bb.get() & 0xFF) << 8 | this.bb.get() & 0xFF;
/*     */     } 
/*  43 */     return readIntSafe();
/*     */   }
/*     */   
/*     */   private int readIntSafe() {
/*  47 */     this.deficit -= this.bb.remaining() << 3;
/*  48 */     int res = 0;
/*  49 */     if (this.bb.hasRemaining())
/*  50 */       res |= this.bb.get() & 0xFF; 
/*  51 */     res <<= 8;
/*  52 */     if (this.bb.hasRemaining())
/*  53 */       res |= this.bb.get() & 0xFF; 
/*  54 */     res <<= 8;
/*  55 */     if (this.bb.hasRemaining())
/*  56 */       res |= this.bb.get() & 0xFF; 
/*  57 */     res <<= 8;
/*  58 */     if (this.bb.hasRemaining())
/*  59 */       res |= this.bb.get() & 0xFF; 
/*  60 */     return res;
/*     */   }
/*     */ 
/*     */   
/*     */   public int read1Bit() {
/*  65 */     int ret = this.curInt >>> 31;
/*  66 */     this.curInt <<= 1;
/*  67 */     this.deficit++;
/*  68 */     if (this.deficit == 32) {
/*  69 */       this.curInt = readInt();
/*     */     }
/*     */ 
/*     */     
/*  73 */     return ret;
/*     */   }
/*     */   
/*     */   public int readNBitSigned(int n) {
/*  77 */     int v = readNBit(n);
/*  78 */     return (read1Bit() == 0) ? v : -v;
/*     */   }
/*     */   
/*     */   public int readNBit(int n) {
/*  82 */     if (n > 32) {
/*  83 */       throw new IllegalArgumentException("Can not read more then 32 bit");
/*     */     }
/*  85 */     int nn = n;
/*     */     
/*  87 */     int ret = 0;
/*  88 */     if (n + this.deficit > 31) {
/*  89 */       ret |= this.curInt >>> this.deficit;
/*  90 */       n -= 32 - this.deficit;
/*  91 */       ret <<= n;
/*  92 */       this.deficit = 32;
/*  93 */       this.curInt = readInt();
/*     */     } 
/*     */     
/*  96 */     if (n != 0) {
/*  97 */       ret |= this.curInt >>> 32 - n;
/*  98 */       this.curInt <<= n;
/*  99 */       this.deficit += n;
/*     */     } 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 106 */     return ret;
/*     */   }
/*     */   
/*     */   public boolean moreData() {
/* 110 */     int remaining = this.bb.remaining() + 4 - (this.deficit + 7 >> 3);
/* 111 */     return (remaining > 1 || (remaining == 1 && this.curInt != 0));
/*     */   }
/*     */   
/*     */   public int remaining() {
/* 115 */     return (this.bb.remaining() << 3) + 32 - this.deficit;
/*     */   }
/*     */   
/*     */   public final boolean isByteAligned() {
/* 119 */     return ((this.deficit & 0x7) == 0);
/*     */   }
/*     */   
/*     */   public int skip(int bits) {
/* 123 */     int left = bits;
/*     */     
/* 125 */     if (left + this.deficit > 31) {
/* 126 */       left -= 32 - this.deficit;
/* 127 */       this.deficit = 32;
/* 128 */       if (left > 31) {
/* 129 */         int skip = Math.min(left >> 3, this.bb.remaining());
/* 130 */         this.bb.position(this.bb.position() + skip);
/* 131 */         left -= skip << 3;
/*     */       } 
/* 133 */       this.curInt = readInt();
/*     */     } 
/*     */     
/* 136 */     this.deficit += left;
/* 137 */     this.curInt <<= left;
/*     */     
/* 139 */     return bits;
/*     */   }
/*     */   
/*     */   public int skipFast(int bits) {
/* 143 */     this.deficit += bits;
/* 144 */     this.curInt <<= bits;
/*     */     
/* 146 */     return bits;
/*     */   }
/*     */   
/*     */   public int bitsToAlign() {
/* 150 */     return ((this.deficit & 0x7) > 0) ? (8 - (this.deficit & 0x7)) : 0;
/*     */   }
/*     */   
/*     */   public int align() {
/* 154 */     return ((this.deficit & 0x7) > 0) ? skip(8 - (this.deficit & 0x7)) : 0;
/*     */   }
/*     */   
/*     */   public int check24Bits() {
/* 158 */     if (this.deficit > 16) {
/* 159 */       this.deficit -= 16;
/* 160 */       this.curInt |= nextIgnore16() << this.deficit;
/*     */     } 
/*     */     
/* 163 */     if (this.deficit > 8) {
/* 164 */       this.deficit -= 8;
/* 165 */       this.curInt |= nextIgnore() << this.deficit;
/*     */     } 
/*     */     
/* 168 */     return this.curInt >>> 8;
/*     */   }
/*     */   
/*     */   public int check16Bits() {
/* 172 */     if (this.deficit > 16) {
/* 173 */       this.deficit -= 16;
/* 174 */       this.curInt |= nextIgnore16() << this.deficit;
/*     */     } 
/* 176 */     return this.curInt >>> 16;
/*     */   }
/*     */   
/*     */   public int readFast16(int n) {
/* 180 */     if (n == 0)
/* 181 */       return 0; 
/* 182 */     if (this.deficit > 16) {
/* 183 */       this.deficit -= 16;
/* 184 */       this.curInt |= nextIgnore16() << this.deficit;
/*     */     } 
/*     */     
/* 187 */     int ret = this.curInt >>> 32 - n;
/* 188 */     this.deficit += n;
/* 189 */     this.curInt <<= n;
/*     */     
/* 191 */     return ret;
/*     */   }
/*     */   
/*     */   public int checkNBit(int n) {
/* 195 */     if (n > 24) {
/* 196 */       throw new IllegalArgumentException("Can not check more then 24 bit");
/*     */     }
/*     */     
/* 199 */     return checkNBitDontCare(n);
/*     */   }
/*     */   
/*     */   public int checkNBitDontCare(int n) {
/* 203 */     while (this.deficit + n > 32) {
/* 204 */       this.deficit -= 8;
/* 205 */       this.curInt |= nextIgnore() << this.deficit;
/*     */     } 
/* 207 */     int res = this.curInt >>> 32 - n;
/* 208 */     return res;
/*     */   }
/*     */   
/*     */   private int nextIgnore16() {
/* 212 */     return (this.bb.remaining() > 1) ? (this.bb.getShort() & 0xFFFF) : (this.bb.hasRemaining() ? ((this.bb.get() & 0xFF) << 8) : 0);
/*     */   }
/*     */   
/*     */   private int nextIgnore() {
/* 216 */     return this.bb.hasRemaining() ? (this.bb.get() & 0xFF) : 0;
/*     */   }
/*     */   
/*     */   public int curBit() {
/* 220 */     return this.deficit & 0x7;
/*     */   }
/*     */   
/*     */   public boolean lastByte() {
/* 224 */     return (this.bb.remaining() + 4 - (this.deficit >> 3) <= 1);
/*     */   }
/*     */   
/*     */   public void terminate() {
/* 228 */     int putBack = 32 - this.deficit >> 3;
/* 229 */     this.bb.position(this.bb.position() - putBack);
/*     */   }
/*     */   
/*     */   public int position() {
/* 233 */     return (this.bb.position() - this.initPos - 4 << 3) + this.deficit;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void stop() {
/* 241 */     this.bb.position(this.bb.position() - (32 - this.deficit >> 3));
/*     */   }
/*     */   
/*     */   public int checkAllBits() {
/* 245 */     return this.curInt;
/*     */   }
/*     */   
/*     */   public boolean readBool() {
/* 249 */     return (read1Bit() == 1);
/*     */   }
/*     */ }


/* Location:              C:\Users\rapha\Downloads\aurora.jar!\META-INF\jars\jcodec-0.2.5.jar!\org\jcodec\common\io\BitReader.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */