/*     */ package org.jcodec.common.io;
/*     */ 
/*     */ import java.io.Closeable;
/*     */ import java.io.IOException;
/*     */ import java.nio.ByteBuffer;
/*     */ import java.nio.ByteOrder;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class DataReader
/*     */   implements Closeable
/*     */ {
/*     */   private static final int DEFAULT_BUFFER_SIZE = 1048576;
/*     */   private SeekableByteChannel channel;
/*     */   private ByteBuffer buffer;
/*     */   
/*     */   public static DataReader createDataReader(SeekableByteChannel channel, ByteOrder order) {
/*  24 */     return new DataReader(channel, order, 1048576);
/*     */   }
/*     */   
/*     */   public DataReader(SeekableByteChannel channel, ByteOrder order, int bufferSize) {
/*  28 */     this.channel = channel;
/*  29 */     this.buffer = ByteBuffer.allocate(bufferSize);
/*  30 */     this.buffer.limit(0);
/*  31 */     this.buffer.order(order);
/*     */   }
/*     */   
/*     */   public int readFully3(byte[] b, int off, int len) throws IOException {
/*  35 */     int initOff = off;
/*  36 */     while (len > 0) {
/*  37 */       fetchIfNeeded(len);
/*     */       
/*  39 */       if (this.buffer.remaining() == 0) {
/*     */         break;
/*     */       }
/*  42 */       int toRead = Math.min(this.buffer.remaining(), len);
/*  43 */       this.buffer.get(b, off, toRead);
/*  44 */       off += toRead;
/*  45 */       len -= toRead;
/*     */     } 
/*  47 */     return off - initOff;
/*     */   }
/*     */   
/*     */   public int skipBytes(int n) throws IOException {
/*  51 */     long oldPosition = position();
/*  52 */     if (n < this.buffer.remaining()) {
/*  53 */       this.buffer.position(this.buffer.position() + n);
/*     */     } else {
/*  55 */       setPosition(oldPosition + n);
/*     */     } 
/*  57 */     return (int)(position() - oldPosition);
/*     */   }
/*     */   
/*     */   public byte readByte() throws IOException {
/*  61 */     fetchIfNeeded(1);
/*  62 */     return this.buffer.get();
/*     */   }
/*     */   
/*     */   public short readShort() throws IOException {
/*  66 */     fetchIfNeeded(2);
/*  67 */     return this.buffer.getShort();
/*     */   }
/*     */   
/*     */   public char readChar() throws IOException {
/*  71 */     fetchIfNeeded(2);
/*  72 */     return this.buffer.getChar();
/*     */   }
/*     */   
/*     */   public int readInt() throws IOException {
/*  76 */     fetchIfNeeded(4);
/*  77 */     return this.buffer.getInt();
/*     */   }
/*     */   
/*     */   public long readLong() throws IOException {
/*  81 */     fetchIfNeeded(8);
/*  82 */     return this.buffer.getLong();
/*     */   }
/*     */   
/*     */   public float readFloat() throws IOException {
/*  86 */     fetchIfNeeded(4);
/*  87 */     return this.buffer.getFloat();
/*     */   }
/*     */   
/*     */   public double readDouble() throws IOException {
/*  91 */     fetchIfNeeded(8);
/*  92 */     return this.buffer.getDouble();
/*     */   }
/*     */   
/*     */   public long position() throws IOException {
/*  96 */     return this.channel.position() - this.buffer.limit() + this.buffer.position();
/*     */   }
/*     */   
/*     */   public long setPosition(long newPos) throws IOException {
/* 100 */     int relative = (int)(newPos - this.channel.position() - this.buffer.limit());
/* 101 */     if (relative >= 0 && relative < this.buffer.limit()) {
/* 102 */       this.buffer.position(relative);
/*     */     } else {
/* 104 */       this.buffer.limit(0);
/* 105 */       this.channel.setPosition(newPos);
/*     */     } 
/* 107 */     return position();
/*     */   }
/*     */ 
/*     */   
/*     */   public void close() throws IOException {
/* 112 */     this.channel.close();
/*     */   }
/*     */   
/*     */   private void fetchIfNeeded(int length) throws IOException {
/* 116 */     if (this.buffer.remaining() < length) {
/* 117 */       moveRemainderToTheStart(this.buffer);
/* 118 */       this.channel.read(this.buffer);
/* 119 */       this.buffer.flip();
/*     */     } 
/*     */   }
/*     */   
/*     */   private static void moveRemainderToTheStart(ByteBuffer readBuf) {
/* 124 */     int rem = readBuf.remaining();
/* 125 */     for (int i = 0; i < rem; i++) {
/* 126 */       readBuf.put(i, readBuf.get());
/*     */     }
/* 128 */     readBuf.clear();
/* 129 */     readBuf.position(rem);
/*     */   }
/*     */   
/*     */   public long size() throws IOException {
/* 133 */     return this.channel.size();
/*     */   }
/*     */   
/*     */   public int readFully(byte[] b) throws IOException {
/* 137 */     return readFully3(b, 0, b.length);
/*     */   }
/*     */ }


/* Location:              C:\Users\rapha\Downloads\aurora.jar!\META-INF\jars\jcodec-0.2.5.jar!\org\jcodec\common\io\DataReader.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */