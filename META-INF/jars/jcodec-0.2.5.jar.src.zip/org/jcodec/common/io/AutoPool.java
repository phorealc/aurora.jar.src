/*    */ package org.jcodec.common.io;
/*    */ 
/*    */ import java.util.ArrayList;
/*    */ import java.util.Collections;
/*    */ import java.util.List;
/*    */ import java.util.concurrent.Executors;
/*    */ import java.util.concurrent.ScheduledExecutorService;
/*    */ import java.util.concurrent.ThreadFactory;
/*    */ import java.util.concurrent.TimeUnit;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class AutoPool
/*    */ {
/* 27 */   private final List<AutoResource> resources = Collections.synchronizedList(new ArrayList<AutoResource>());
/* 28 */   private ScheduledExecutorService scheduler = Executors.newScheduledThreadPool(1, daemonThreadFactory()); private AutoPool() {
/* 29 */     final List<AutoResource> res = this.resources;
/* 30 */     this.scheduler.scheduleAtFixedRate(new Runnable() {
/*    */           public void run() {
/* 32 */             long curTime = System.currentTimeMillis();
/* 33 */             for (AutoResource autoResource : res) {
/* 34 */               autoResource.setCurTime(curTime);
/*    */             }
/*    */           }
/*    */         },  0L, 100L, TimeUnit.MILLISECONDS);
/*    */   }
/*    */   
/*    */   private ThreadFactory daemonThreadFactory() {
/* 41 */     return new ThreadFactory()
/*    */       {
/*    */         public Thread newThread(Runnable r) {
/* 44 */           Thread t = new Thread(r);
/* 45 */           t.setDaemon(true);
/* 46 */           t.setName(AutoPool.class.getName());
/* 47 */           return t;
/*    */         }
/*    */       };
/*    */   }
/*    */   
/*    */   public static AutoPool getInstance() {
/* 53 */     return instance;
/*    */   }
/*    */   
/*    */   public void add(AutoResource res) {
/* 57 */     this.resources.add(res);
/*    */   }
/*    */   
/* 60 */   private static AutoPool instance = new AutoPool();
/*    */ }


/* Location:              C:\Users\rapha\Downloads\aurora.jar!\META-INF\jars\jcodec-0.2.5.jar!\org\jcodec\common\io\AutoPool.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */