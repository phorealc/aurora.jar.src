/*    */ package org.jcodec.common.io;
/*    */ 
/*    */ import java.nio.ByteBuffer;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class BitWriter
/*    */ {
/*    */   private final ByteBuffer buf;
/*    */   private int curInt;
/*    */   private int _curBit;
/*    */   private int initPos;
/*    */   
/*    */   public BitWriter(ByteBuffer buf) {
/* 22 */     this.buf = buf;
/* 23 */     this.initPos = buf.position();
/*    */   }
/*    */   
/*    */   public BitWriter fork() {
/* 27 */     BitWriter fork = new BitWriter(this.buf.duplicate());
/* 28 */     fork._curBit = this._curBit;
/* 29 */     fork.curInt = this.curInt;
/* 30 */     fork.initPos = this.initPos;
/* 31 */     return fork;
/*    */   }
/*    */   
/*    */   public void flush() {
/* 35 */     int toWrite = this._curBit + 7 >> 3;
/* 36 */     for (int i = 0; i < toWrite; i++) {
/* 37 */       this.buf.put((byte)(this.curInt >>> 24));
/* 38 */       this.curInt <<= 8;
/*    */     } 
/*    */   }
/*    */   
/*    */   private final void putInt(int i) {
/* 43 */     this.buf.put((byte)(i >>> 24));
/* 44 */     this.buf.put((byte)(i >> 16));
/* 45 */     this.buf.put((byte)(i >> 8));
/* 46 */     this.buf.put((byte)i);
/*    */   }
/*    */   
/*    */   public final void writeNBit(int value, int n) {
/* 50 */     if (n > 32)
/* 51 */       throw new IllegalArgumentException("Max 32 bit to write"); 
/* 52 */     if (n == 0)
/*    */       return; 
/* 54 */     value &= -1 >>> 32 - n;
/* 55 */     if (32 - this._curBit >= n) {
/* 56 */       this.curInt |= value << 32 - this._curBit - n;
/* 57 */       this._curBit += n;
/* 58 */       if (this._curBit == 32) {
/* 59 */         putInt(this.curInt);
/* 60 */         this._curBit = 0;
/* 61 */         this.curInt = 0;
/*    */       } 
/*    */     } else {
/* 64 */       int secPart = n - 32 - this._curBit;
/* 65 */       this.curInt |= value >>> secPart;
/* 66 */       putInt(this.curInt);
/* 67 */       this.curInt = value << 32 - secPart;
/* 68 */       this._curBit = secPart;
/*    */     } 
/*    */   }
/*    */   
/*    */   public void write1Bit(int bit) {
/* 73 */     this.curInt |= bit << 32 - this._curBit - 1;
/* 74 */     this._curBit++;
/* 75 */     if (this._curBit == 32) {
/* 76 */       putInt(this.curInt);
/* 77 */       this._curBit = 0;
/* 78 */       this.curInt = 0;
/*    */     } 
/*    */   }
/*    */   
/*    */   public int curBit() {
/* 83 */     return this._curBit & 0x7;
/*    */   }
/*    */   
/*    */   public int position() {
/* 87 */     return (this.buf.position() - this.initPos << 3) + this._curBit;
/*    */   }
/*    */   
/*    */   public ByteBuffer getBuffer() {
/* 91 */     return this.buf;
/*    */   }
/*    */ }


/* Location:              C:\Users\rapha\Downloads\aurora.jar!\META-INF\jars\jcodec-0.2.5.jar!\org\jcodec\common\io\BitWriter.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */