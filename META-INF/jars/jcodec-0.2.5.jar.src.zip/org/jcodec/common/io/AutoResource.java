package org.jcodec.common.io;

public interface AutoResource {
  void setCurTime(long paramLong);
}


/* Location:              C:\Users\rapha\Downloads\aurora.jar!\META-INF\jars\jcodec-0.2.5.jar!\org\jcodec\common\io\AutoResource.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */