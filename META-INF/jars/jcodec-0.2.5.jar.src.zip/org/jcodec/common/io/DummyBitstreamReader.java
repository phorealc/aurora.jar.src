/*     */ package org.jcodec.common.io;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.io.InputStream;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class DummyBitstreamReader
/*     */ {
/*     */   private InputStream is;
/*     */   private int curByte;
/*     */   private int nextByte;
/*     */   private int secondByte;
/*     */   int nBit;
/*     */   protected static int bitsRead;
/*     */   int cnt;
/*     */   
/*     */   public DummyBitstreamReader(InputStream is) throws IOException {
/*  31 */     this.cnt = 0;
/*     */     this.is = is;
/*     */     this.curByte = is.read();
/*     */     this.nextByte = is.read();
/*     */     this.secondByte = is.read();
/*     */   }
/*     */   
/*     */   public int read1Bit() throws IOException {
/*  39 */     return read1BitInt();
/*     */   }
/*     */ 
/*     */   
/*     */   public int read1BitInt() throws IOException {
/*  44 */     if (this.nBit == 8) {
/*  45 */       advance();
/*  46 */       if (this.curByte == -1) {
/*  47 */         return -1;
/*     */       }
/*     */     } 
/*  50 */     int res = this.curByte >> 7 - this.nBit & 0x1;
/*  51 */     this.nBit++;
/*     */ 
/*     */     
/*  54 */     bitsRead++;
/*     */     
/*  56 */     return res;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int readNBit(int n) throws IOException {
/*  65 */     if (n > 32) {
/*  66 */       throw new IllegalArgumentException("Can not read more then 32 bit");
/*     */     }
/*  68 */     int val = 0;
/*     */     
/*  70 */     for (int i = 0; i < n; i++) {
/*  71 */       val <<= 1;
/*  72 */       val |= read1BitInt();
/*     */     } 
/*     */     
/*  75 */     return val;
/*     */   }
/*     */   
/*     */   private final void advance1() throws IOException {
/*  79 */     this.curByte = this.nextByte;
/*  80 */     this.nextByte = this.secondByte;
/*  81 */     this.secondByte = this.is.read();
/*     */   }
/*     */   
/*     */   private final void advance() throws IOException {
/*  85 */     advance1();
/*  86 */     this.nBit = 0;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int readByte() throws IOException {
/*  96 */     if (this.nBit > 0) {
/*  97 */       advance();
/*     */     }
/*     */     
/* 100 */     int res = this.curByte;
/*     */     
/* 102 */     advance();
/*     */     
/* 104 */     return res;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean moreRBSPData() throws IOException {
/* 113 */     if (this.nBit == 8) {
/* 114 */       advance();
/*     */     }
/* 116 */     int tail = 1 << 8 - this.nBit - 1;
/* 117 */     int mask = (tail << 1) - 1;
/* 118 */     boolean hasTail = ((this.curByte & mask) == tail);
/*     */     
/* 120 */     return (this.curByte != -1 && (this.nextByte != -1 || !hasTail));
/*     */   }
/*     */   
/*     */   public long getBitPosition() {
/* 124 */     return (bitsRead * 8 + this.nBit % 8);
/*     */   }
/*     */   
/*     */   public boolean moreData() throws IOException {
/* 128 */     if (this.nBit == 8)
/* 129 */       advance(); 
/* 130 */     if (this.curByte == -1)
/* 131 */       return false; 
/* 132 */     if (this.nextByte == -1 || (this.nextByte == 0 && this.secondByte == -1)) {
/* 133 */       int mask = (1 << 8 - this.nBit) - 1;
/* 134 */       return ((this.curByte & mask) != 0);
/*     */     } 
/* 136 */     return true;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public long readRemainingByte() throws IOException {
/* 145 */     return readNBit(8 - this.nBit);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int peakNextBits(int n) throws IOException {
/* 154 */     if (n > 8)
/* 155 */       throw new IllegalArgumentException("N should be less then 8"); 
/* 156 */     if (this.nBit == 8) {
/* 157 */       advance();
/* 158 */       if (this.curByte == -1) {
/* 159 */         return -1;
/*     */       }
/*     */     } 
/* 162 */     int[] bits = new int[16 - this.nBit];
/*     */     
/* 164 */     int cnt = 0; int i;
/* 165 */     for (i = this.nBit; i < 8; i++) {
/* 166 */       bits[cnt++] = this.curByte >> 7 - i & 0x1;
/*     */     }
/*     */     
/* 169 */     for (i = 0; i < 8; i++) {
/* 170 */       bits[cnt++] = this.nextByte >> 7 - i & 0x1;
/*     */     }
/*     */     
/* 173 */     int result = 0;
/* 174 */     for (int j = 0; j < n; j++) {
/* 175 */       result <<= 1;
/* 176 */       result |= bits[j];
/*     */     } 
/*     */     
/* 179 */     return result;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isByteAligned() {
/* 188 */     return (this.nBit % 8 == 0);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void close() throws IOException {
/* 197 */     this.is.close();
/*     */   }
/*     */   
/*     */   public int getCurBit() {
/* 201 */     return this.nBit;
/*     */   }
/*     */   
/*     */   public final int skip(int bits) throws IOException {
/* 205 */     this.nBit += bits;
/* 206 */     int was = this.nBit;
/* 207 */     while (this.nBit >= 8 && this.curByte != -1) {
/* 208 */       advance1();
/* 209 */       this.nBit -= 8;
/*     */     } 
/* 211 */     return was - this.nBit;
/*     */   }
/*     */   
/*     */   public int align() throws IOException {
/* 215 */     int n = 8 - this.nBit & 0x7;
/* 216 */     skip(8 - this.nBit & 0x7);
/* 217 */     return n;
/*     */   }
/*     */   
/*     */   public int checkNBit(int n) throws IOException {
/* 221 */     return peakNextBits(n);
/*     */   }
/*     */   
/*     */   public int curBit() {
/* 225 */     return this.nBit;
/*     */   }
/*     */   
/*     */   public boolean lastByte() throws IOException {
/* 229 */     return (this.nextByte == -1 && this.secondByte == -1);
/*     */   }
/*     */ }


/* Location:              C:\Users\rapha\Downloads\aurora.jar!\META-INF\jars\jcodec-0.2.5.jar!\org\jcodec\common\io\DummyBitstreamReader.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */