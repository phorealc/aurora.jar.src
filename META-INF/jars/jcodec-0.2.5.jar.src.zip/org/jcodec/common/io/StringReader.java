/*    */ package org.jcodec.common.io;
/*    */ 
/*    */ import java.io.IOException;
/*    */ import java.io.InputStream;
/*    */ import org.jcodec.platform.Platform;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public abstract class StringReader
/*    */ {
/*    */   public static String readString(InputStream input, int len) throws IOException {
/* 16 */     byte[] bs = _sureRead(input, len);
/* 17 */     return (bs == null) ? null : Platform.stringFromBytes(bs);
/*    */   }
/*    */   
/*    */   public static byte[] _sureRead(InputStream input, int len) throws IOException {
/* 21 */     byte[] res = new byte[len];
/* 22 */     if (sureRead(input, res, res.length) == len)
/* 23 */       return res; 
/* 24 */     return null;
/*    */   }
/*    */   
/*    */   public static int sureRead(InputStream input, byte[] buf, int len) throws IOException {
/* 28 */     int read = 0;
/* 29 */     while (read < len) {
/* 30 */       int tmp = input.read(buf, read, len - read);
/* 31 */       if (tmp == -1)
/*    */         break; 
/* 33 */       read += tmp;
/*    */     } 
/* 35 */     return read;
/*    */   }
/*    */   
/*    */   public static void sureSkip(InputStream is, long l) throws IOException {
/* 39 */     while (l > 0L)
/* 40 */       l -= is.skip(l); 
/*    */   }
/*    */ }


/* Location:              C:\Users\rapha\Downloads\aurora.jar!\META-INF\jars\jcodec-0.2.5.jar!\org\jcodec\common\io\StringReader.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */