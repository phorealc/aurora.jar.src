/*     */ package org.jcodec.common;
/*     */ 
/*     */ import java.io.File;
/*     */ import java.io.IOException;
/*     */ import java.nio.ByteBuffer;
/*     */ import java.nio.channels.ReadableByteChannel;
/*     */ import java.util.HashMap;
/*     */ import java.util.Map;
/*     */ import java.util.Set;
/*     */ import org.jcodec.codecs.aac.AACDecoder;
/*     */ import org.jcodec.codecs.h264.BufferH264ES;
/*     */ import org.jcodec.codecs.h264.H264Decoder;
/*     */ import org.jcodec.codecs.mjpeg.JpegDecoder;
/*     */ import org.jcodec.codecs.mpeg12.MPEGDecoder;
/*     */ import org.jcodec.codecs.mpeg4.MPEG4Decoder;
/*     */ import org.jcodec.codecs.ppm.PPMEncoder;
/*     */ import org.jcodec.codecs.prores.ProresDecoder;
/*     */ import org.jcodec.codecs.vpx.VP8Decoder;
/*     */ import org.jcodec.codecs.wav.WavDemuxer;
/*     */ import org.jcodec.common.io.FileChannelWrapper;
/*     */ import org.jcodec.common.io.NIOUtils;
/*     */ import org.jcodec.common.io.SeekableByteChannel;
/*     */ import org.jcodec.common.logging.Logger;
/*     */ import org.jcodec.common.model.ColorSpace;
/*     */ import org.jcodec.common.model.Picture;
/*     */ import org.jcodec.common.tools.MathUtil;
/*     */ import org.jcodec.containers.imgseq.ImageSequenceDemuxer;
/*     */ import org.jcodec.containers.mkv.demuxer.MKVDemuxer;
/*     */ import org.jcodec.containers.mp3.MPEGAudioDemuxer;
/*     */ import org.jcodec.containers.mp4.demuxer.MP4Demuxer;
/*     */ import org.jcodec.containers.mps.MPSDemuxer;
/*     */ import org.jcodec.containers.mps.MTSDemuxer;
/*     */ import org.jcodec.containers.webp.WebpDemuxer;
/*     */ import org.jcodec.containers.y4m.Y4MDemuxer;
/*     */ import org.jcodec.platform.Platform;
/*     */ import org.jcodec.scale.ColorUtil;
/*     */ import org.jcodec.scale.Transform;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class JCodecUtil
/*     */ {
/*  52 */   private static final Map<Codec, Class<?>> decoders = new HashMap<Codec, Class<?>>();
/*  53 */   private static final Map<Format, Class<?>> demuxers = new HashMap<Format, Class<?>>();
/*     */   
/*     */   static {
/*  56 */     decoders.put(Codec.VP8, VP8Decoder.class);
/*  57 */     decoders.put(Codec.PRORES, ProresDecoder.class);
/*  58 */     decoders.put(Codec.MPEG2, MPEGDecoder.class);
/*  59 */     decoders.put(Codec.H264, H264Decoder.class);
/*  60 */     decoders.put(Codec.AAC, AACDecoder.class);
/*  61 */     decoders.put(Codec.MPEG4, MPEG4Decoder.class);
/*     */     
/*  63 */     demuxers.put(Format.MPEG_TS, MTSDemuxer.class);
/*  64 */     demuxers.put(Format.MPEG_PS, MPSDemuxer.class);
/*  65 */     demuxers.put(Format.MOV, MP4Demuxer.class);
/*  66 */     demuxers.put(Format.WEBP, WebpDemuxer.class);
/*  67 */     demuxers.put(Format.MPEG_AUDIO, MPEGAudioDemuxer.class);
/*     */   }
/*     */   
/*     */   public static Format detectFormat(File f) throws IOException {
/*  71 */     return detectFormatBuffer(NIOUtils.fetchFromFileL(f, 204800));
/*     */   }
/*     */   
/*     */   public static Format detectFormatChannel(ReadableByteChannel f) throws IOException {
/*  75 */     return detectFormatBuffer(NIOUtils.fetchFromChannel(f, 204800));
/*     */   }
/*     */   
/*     */   public static Format detectFormatBuffer(ByteBuffer b) {
/*  79 */     int maxScore = 0;
/*  80 */     Format selected = null;
/*  81 */     for (Map.Entry<Format, Class<?>> vd : demuxers.entrySet()) {
/*  82 */       int score = probe(b.duplicate(), vd.getValue());
/*  83 */       if (score > maxScore) {
/*  84 */         selected = vd.getKey();
/*  85 */         maxScore = score;
/*     */       } 
/*     */     } 
/*  88 */     return selected;
/*     */   }
/*     */   
/*     */   public static Codec detectDecoder(ByteBuffer b) {
/*  92 */     int maxScore = 0;
/*  93 */     Codec selected = null;
/*  94 */     for (Map.Entry<Codec, Class<?>> vd : decoders.entrySet()) {
/*  95 */       int score = probe(b.duplicate(), vd.getValue());
/*  96 */       if (score > maxScore) {
/*  97 */         selected = vd.getKey();
/*  98 */         maxScore = score;
/*     */       } 
/*     */     } 
/* 101 */     return selected;
/*     */   }
/*     */   
/*     */   private static int probe(ByteBuffer b, Class<?> vd) {
/*     */     try {
/* 106 */       return ((Integer)Platform.invokeStaticMethod(vd, "probe", new Object[] { b })).intValue();
/* 107 */     } catch (Exception exception) {
/*     */       
/* 109 */       return 0;
/*     */     } 
/*     */   }
/*     */   public static VideoDecoder getVideoDecoder(String fourcc) {
/* 113 */     if ("apch".equals(fourcc) || "apcs".equals(fourcc) || "apco".equals(fourcc) || "apcn".equals(fourcc) || "ap4h"
/* 114 */       .equals(fourcc))
/* 115 */       return (VideoDecoder)new ProresDecoder(); 
/* 116 */     if ("m2v1".equals(fourcc)) {
/* 117 */       return (VideoDecoder)new MPEGDecoder();
/*     */     }
/* 119 */     return null;
/*     */   }
/*     */   
/*     */   public static void savePictureAsPPM(Picture pic, File file) throws IOException {
/* 123 */     Transform transform = ColorUtil.getTransform(pic.getColor(), ColorSpace.RGB);
/* 124 */     Picture rgb = Picture.create(pic.getWidth(), pic.getHeight(), ColorSpace.RGB);
/* 125 */     transform.transform(pic, rgb);
/* 126 */     NIOUtils.writeTo((new PPMEncoder()).encodeFrame(rgb), file);
/*     */   }
/*     */   
/*     */   public static byte[] asciiString(String fourcc) {
/* 130 */     char[] ch = fourcc.toCharArray();
/* 131 */     byte[] result = new byte[ch.length];
/* 132 */     for (int i = 0; i < ch.length; i++) {
/* 133 */       result[i] = (byte)ch[i];
/*     */     }
/* 135 */     return result;
/*     */   }
/*     */   
/*     */   public static void writeBER32(ByteBuffer buffer, int value) {
/* 139 */     buffer.put((byte)(value >> 21 | 0x80));
/* 140 */     buffer.put((byte)(value >> 14 | 0x80));
/* 141 */     buffer.put((byte)(value >> 7 | 0x80));
/* 142 */     buffer.put((byte)(value & 0x7F));
/*     */   }
/*     */   
/*     */   public static void writeBER32Var(ByteBuffer bb, int value) {
/* 146 */     for (int i = 0, bits = MathUtil.log2(value); i < 4 && bits > 0; i++) {
/* 147 */       bits -= 7;
/* 148 */       int out = value >> bits;
/* 149 */       if (bits > 0)
/* 150 */         out |= 0x80; 
/* 151 */       bb.put((byte)out);
/*     */     } 
/*     */   }
/*     */   
/*     */   public static int readBER32(ByteBuffer input) {
/* 156 */     int size = 0;
/* 157 */     for (int i = 0; i < 4; i++) {
/* 158 */       byte b = input.get();
/* 159 */       size = size << 7 | b & Byte.MAX_VALUE;
/* 160 */       if ((b & 0xFF) >> 7 == 0)
/*     */         break; 
/*     */     } 
/* 163 */     return size;
/*     */   }
/*     */   
/*     */   public static int[] getAsIntArray(ByteBuffer yuv, int size) {
/* 167 */     byte[] b = new byte[size];
/* 168 */     int[] result = new int[size];
/* 169 */     yuv.get(b);
/* 170 */     for (int i = 0; i < b.length; i++) {
/* 171 */       result[i] = b[i] & 0xFF;
/*     */     }
/* 173 */     return result;
/*     */   }
/*     */   
/*     */   public static String removeExtension(String name) {
/* 177 */     if (name == null)
/* 178 */       return null; 
/* 179 */     return name.replaceAll("\\.[^\\.]+$", "");
/*     */   }
/*     */   
/*     */   public static Demuxer createDemuxer(Format format, File input) throws IOException {
/* 183 */     FileChannelWrapper ch = null;
/* 184 */     if (format != Format.IMG) {
/* 185 */       ch = NIOUtils.readableChannel(input);
/*     */     }
/* 187 */     if (Format.MOV == format)
/* 188 */       return (Demuxer)MP4Demuxer.createMP4Demuxer((SeekableByteChannel)ch); 
/* 189 */     if (Format.MPEG_PS == format)
/* 190 */       return (Demuxer)new MPSDemuxer((ReadableByteChannel)ch); 
/* 191 */     if (Format.MKV == format)
/* 192 */       return (Demuxer)new MKVDemuxer((SeekableByteChannel)ch); 
/* 193 */     if (Format.IMG == format)
/* 194 */       return (Demuxer)new ImageSequenceDemuxer(input.getAbsolutePath(), 2147483647); 
/* 195 */     if (Format.Y4M == format)
/* 196 */       return (Demuxer)new Y4MDemuxer((SeekableByteChannel)ch); 
/* 197 */     if (Format.WEBP == format)
/* 198 */       return (Demuxer)new WebpDemuxer((SeekableByteChannel)ch); 
/* 199 */     if (Format.H264 == format)
/* 200 */       return (Demuxer)new BufferH264ES(NIOUtils.fetchAllFromChannel((SeekableByteChannel)ch)); 
/* 201 */     if (Format.WAV == format)
/* 202 */       return (Demuxer)new WavDemuxer((SeekableByteChannel)ch); 
/* 203 */     if (Format.MPEG_AUDIO == format) {
/* 204 */       return (Demuxer)new MPEGAudioDemuxer((SeekableByteChannel)ch);
/*     */     }
/* 206 */     Logger.error("Format " + format + " is not supported");
/*     */     
/* 208 */     return null;
/*     */   }
/*     */   
/*     */   public static Tuple._2<Integer, Demuxer> createM2TSDemuxer(File input, TrackType targetTrack) throws IOException {
/* 212 */     FileChannelWrapper ch = NIOUtils.readableChannel(input);
/* 213 */     MTSDemuxer mts = new MTSDemuxer((SeekableByteChannel)ch);
/* 214 */     Set<Integer> programs = mts.getPrograms();
/* 215 */     if (programs.size() == 0) {
/* 216 */       Logger.error("The MPEG TS stream contains no programs");
/* 217 */       return null;
/*     */     } 
/* 219 */     Tuple._2<Integer, Demuxer> found = null;
/* 220 */     for (Integer pid : programs) {
/* 221 */       ReadableByteChannel program = mts.getProgram(pid.intValue());
/* 222 */       if (found != null) {
/* 223 */         program.close();
/*     */         continue;
/*     */       } 
/* 226 */       MPSDemuxer demuxer = new MPSDemuxer(program);
/* 227 */       if ((targetTrack == TrackType.AUDIO && demuxer.getAudioTracks().size() > 0) || (targetTrack == TrackType.VIDEO && demuxer
/* 228 */         .getVideoTracks().size() > 0)) {
/* 229 */         found = Tuple.pair(pid, demuxer);
/* 230 */         Logger.info("Using M2TS program: " + pid + " for " + targetTrack + " track."); continue;
/*     */       } 
/* 232 */       program.close();
/*     */     } 
/*     */     
/* 235 */     return found;
/*     */   }
/*     */   
/*     */   public static AudioDecoder createAudioDecoder(Codec codec, ByteBuffer decoderSpecific) throws IOException {
/* 239 */     if (Codec.AAC == codec) {
/* 240 */       return (AudioDecoder)new AACDecoder(decoderSpecific);
/*     */     }
/* 242 */     Logger.error("Codec " + codec + " is not supported");
/*     */     
/* 244 */     return null;
/*     */   }
/*     */   
/*     */   public static VideoDecoder createVideoDecoder(Codec codec, ByteBuffer decoderSpecific) {
/* 248 */     if (Codec.H264 == codec) {
/* 249 */       return (decoderSpecific != null) ? (VideoDecoder)H264Decoder.createH264DecoderFromCodecPrivate(decoderSpecific) : (VideoDecoder)new H264Decoder();
/*     */     }
/* 251 */     if (Codec.MPEG2 == codec)
/* 252 */       return (VideoDecoder)new MPEGDecoder(); 
/* 253 */     if (Codec.VP8 == codec)
/* 254 */       return (VideoDecoder)new VP8Decoder(); 
/* 255 */     if (Codec.JPEG == codec) {
/* 256 */       return (VideoDecoder)new JpegDecoder();
/*     */     }
/* 258 */     Logger.error("Codec " + codec + " is not supported");
/*     */     
/* 260 */     return null;
/*     */   }
/*     */ }


/* Location:              C:\Users\rapha\Downloads\aurora.jar!\META-INF\jars\jcodec-0.2.5.jar!\org\jcodec\common\JCodecUtil.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */