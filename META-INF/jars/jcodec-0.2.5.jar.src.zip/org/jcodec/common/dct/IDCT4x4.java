/*    */ package org.jcodec.common.dct;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class IDCT4x4
/*    */ {
/*    */   public static final int CN_SHIFT = 12;
/*    */   
/*    */   public static void idct(int[] blk, int off) {
/*    */     int i;
/* 15 */     for (i = 0; i < 4; i++) {
/* 16 */       idct4row(blk, off + (i << 2));
/*    */     }
/*    */     
/* 19 */     for (i = 0; i < 4; i++) {
/* 20 */       idct4col_add(blk, off + i);
/*    */     }
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public static final int C_FIX(double x) {
/* 27 */     return (int)(x * 1.414213562D * 4096.0D + 0.5D);
/*    */   }
/*    */   
/* 30 */   public static final int C1 = C_FIX(0.6532814824D);
/* 31 */   public static final int C2 = C_FIX(0.2705980501D);
/* 32 */   public static final int C3 = C_FIX(0.5D);
/*    */   
/*    */   public static final int C_SHIFT = 18;
/*    */   public static final int RN_SHIFT = 15;
/*    */   
/*    */   private static void idct4col_add(int[] blk, int off) {
/* 38 */     int a0 = blk[off];
/* 39 */     int a1 = blk[off + 4];
/* 40 */     int a2 = blk[off + 8];
/* 41 */     int a3 = blk[off + 12];
/* 42 */     int c0 = (a0 + a2) * C3 + 131072;
/* 43 */     int c2 = (a0 - a2) * C3 + 131072;
/* 44 */     int c1 = a1 * C1 + a3 * C2;
/* 45 */     int c3 = a1 * C2 - a3 * C1;
/*    */     
/* 47 */     blk[off] = c0 + c1 >> 18;
/* 48 */     blk[off + 4] = c2 + c3 >> 18;
/* 49 */     blk[off + 8] = c2 - c3 >> 18;
/* 50 */     blk[off + 12] = c0 - c1 >> 18;
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public static final int R_FIX(double x) {
/* 56 */     return (int)(x * 1.414213562D * 32768.0D + 0.5D);
/*    */   }
/*    */   
/* 59 */   public static final int R1 = R_FIX(0.6532814824D);
/* 60 */   public static final int R2 = R_FIX(0.2705980501D);
/* 61 */   public static final int R3 = R_FIX(0.5D);
/*    */   
/*    */   public static final int R_SHIFT = 11;
/*    */ 
/*    */   
/*    */   private static void idct4row(int[] blk, int off) {
/* 67 */     int a0 = blk[off];
/* 68 */     int a1 = blk[off + 1];
/* 69 */     int a2 = blk[off + 2];
/* 70 */     int a3 = blk[off + 3];
/* 71 */     int c0 = (a0 + a2) * R3 + 1024;
/* 72 */     int c2 = (a0 - a2) * R3 + 1024;
/* 73 */     int c1 = a1 * R1 + a3 * R2;
/* 74 */     int c3 = a1 * R2 - a3 * R1;
/* 75 */     blk[off] = c0 + c1 >> 11;
/* 76 */     blk[off + 1] = c2 + c3 >> 11;
/* 77 */     blk[off + 2] = c2 - c3 >> 11;
/* 78 */     blk[off + 3] = c0 - c1 >> 11;
/*    */   }
/*    */ }


/* Location:              C:\Users\rapha\Downloads\aurora.jar!\META-INF\jars\jcodec-0.2.5.jar!\org\jcodec\common\dct\IDCT4x4.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */