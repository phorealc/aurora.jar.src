/*     */ package org.jcodec.common.dct;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class SimpleIDCT10Bit
/*     */ {
/*     */   private static final int ROUND_COL = 8192;
/*     */   private static final int ROUND_ROW = 32768;
/*     */   private static final int SHIFT_COL = 14;
/*     */   private static final int SHIFT_ROW = 16;
/*     */   public static final int C0 = 23170;
/*     */   public static final int C1 = 32138;
/*     */   public static final int C2 = 27246;
/*     */   public static final int C3 = 18205;
/*     */   public static final int C4 = 6393;
/*     */   public static final int C5 = 30274;
/*     */   public static final int C6 = 12540;
/*  24 */   public static int W1 = 90901;
/*  25 */   public static int W2 = 85627;
/*  26 */   public static int W3 = 77062;
/*  27 */   public static int W4 = 65535;
/*  28 */   public static int W5 = 51491;
/*  29 */   public static int W6 = 35468;
/*  30 */   public static int W7 = 18081;
/*  31 */   public static int ROW_SHIFT = 15;
/*  32 */   public static int COL_SHIFT = 20;
/*     */   public static final void idct10(int[] buf, int off) {
/*     */     int i;
/*  35 */     for (i = 0; i < 8; i++)
/*  36 */       idctRow(buf, off + (i << 3)); 
/*  37 */     for (i = 0; i < 8; i++) {
/*  38 */       idctCol(buf, off + i);
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   private static final void idctCol(int[] buf, int off) {
/*  44 */     int a0 = W4 * (buf[off + 0] + (1 << COL_SHIFT - 1) / W4);
/*  45 */     int a1 = a0;
/*  46 */     int a2 = a0;
/*  47 */     int a3 = a0;
/*     */     
/*  49 */     a0 += W2 * buf[off + 16];
/*  50 */     a1 += W6 * buf[off + 16];
/*  51 */     a2 += -W6 * buf[off + 16];
/*  52 */     a3 += -W2 * buf[off + 16];
/*     */     
/*  54 */     int b0 = W1 * buf[off + 8];
/*  55 */     int b1 = W3 * buf[off + 8];
/*  56 */     int b2 = W5 * buf[off + 8];
/*  57 */     int b3 = W7 * buf[off + 8];
/*     */     
/*  59 */     b0 += W3 * buf[off + 24];
/*  60 */     b1 += -W7 * buf[off + 24];
/*  61 */     b2 += -W1 * buf[off + 24];
/*  62 */     b3 += -W5 * buf[off + 24];
/*     */     
/*  64 */     if (buf[off + 32] != 0) {
/*  65 */       a0 += W4 * buf[off + 32];
/*  66 */       a1 += -W4 * buf[off + 32];
/*  67 */       a2 += -W4 * buf[off + 32];
/*  68 */       a3 += W4 * buf[off + 32];
/*     */     } 
/*     */     
/*  71 */     if (buf[off + 40] != 0) {
/*  72 */       b0 += W5 * buf[off + 40];
/*  73 */       b1 += -W1 * buf[off + 40];
/*  74 */       b2 += W7 * buf[off + 40];
/*  75 */       b3 += W3 * buf[off + 40];
/*     */     } 
/*     */     
/*  78 */     if (buf[off + 48] != 0) {
/*  79 */       a0 += W6 * buf[off + 48];
/*  80 */       a1 += -W2 * buf[off + 48];
/*  81 */       a2 += W2 * buf[off + 48];
/*  82 */       a3 += -W6 * buf[off + 48];
/*     */     } 
/*     */     
/*  85 */     if (buf[off + 56] != 0) {
/*  86 */       b0 += W7 * buf[off + 56];
/*  87 */       b1 += -W5 * buf[off + 56];
/*  88 */       b2 += W3 * buf[off + 56];
/*  89 */       b3 += -W1 * buf[off + 56];
/*     */     } 
/*     */     
/*  92 */     buf[off] = a0 + b0 >> COL_SHIFT;
/*  93 */     buf[off + 8] = a1 + b1 >> COL_SHIFT;
/*  94 */     buf[off + 16] = a2 + b2 >> COL_SHIFT;
/*  95 */     buf[off + 24] = a3 + b3 >> COL_SHIFT;
/*  96 */     buf[off + 32] = a3 - b3 >> COL_SHIFT;
/*  97 */     buf[off + 40] = a2 - b2 >> COL_SHIFT;
/*  98 */     buf[off + 48] = a1 - b1 >> COL_SHIFT;
/*  99 */     buf[off + 56] = a0 - b0 >> COL_SHIFT;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private static final void idctRow(int[] buf, int off) {
/* 105 */     int a0 = W4 * buf[off] + (1 << ROW_SHIFT - 1);
/* 106 */     int a1 = a0;
/* 107 */     int a2 = a0;
/* 108 */     int a3 = a0;
/*     */     
/* 110 */     a0 += W2 * buf[off + 2];
/* 111 */     a1 += W6 * buf[off + 2];
/* 112 */     a2 -= W6 * buf[off + 2];
/* 113 */     a3 -= W2 * buf[off + 2];
/*     */     
/* 115 */     int b0 = W1 * buf[off + 1];
/* 116 */     b0 += W3 * buf[off + 3];
/* 117 */     int b1 = W3 * buf[off + 1];
/* 118 */     b1 += -W7 * buf[off + 3];
/* 119 */     int b2 = W5 * buf[off + 1];
/* 120 */     b2 += -W1 * buf[off + 3];
/* 121 */     int b3 = W7 * buf[off + 1];
/* 122 */     b3 += -W5 * buf[off + 3];
/*     */     
/* 124 */     if (buf[off + 4] != 0 || buf[off + 5] != 0 || buf[off + 6] != 0 || buf[off + 7] != 0) {
/* 125 */       a0 += W4 * buf[off + 4] + W6 * buf[off + 6];
/* 126 */       a1 += -W4 * buf[off + 4] - W2 * buf[off + 6];
/* 127 */       a2 += -W4 * buf[off + 4] + W2 * buf[off + 6];
/* 128 */       a3 += W4 * buf[off + 4] - W6 * buf[off + 6];
/*     */       
/* 130 */       b0 += W5 * buf[off + 5];
/* 131 */       b0 += W7 * buf[off + 7];
/*     */       
/* 133 */       b1 += -W1 * buf[off + 5];
/* 134 */       b1 += -W5 * buf[off + 7];
/*     */       
/* 136 */       b2 += W7 * buf[off + 5];
/* 137 */       b2 += W3 * buf[off + 7];
/*     */       
/* 139 */       b3 += W3 * buf[off + 5];
/* 140 */       b3 += -W1 * buf[off + 7];
/*     */     } 
/*     */     
/* 143 */     buf[off + 0] = a0 + b0 >> ROW_SHIFT;
/* 144 */     buf[off + 7] = a0 - b0 >> ROW_SHIFT;
/* 145 */     buf[off + 1] = a1 + b1 >> ROW_SHIFT;
/* 146 */     buf[off + 6] = a1 - b1 >> ROW_SHIFT;
/* 147 */     buf[off + 2] = a2 + b2 >> ROW_SHIFT;
/* 148 */     buf[off + 5] = a2 - b2 >> ROW_SHIFT;
/* 149 */     buf[off + 3] = a3 + b3 >> ROW_SHIFT;
/* 150 */     buf[off + 4] = a3 - b3 >> ROW_SHIFT;
/*     */   }
/*     */ 
/*     */   
/*     */   public static void fdctProres10(int[] block, int off) {
/* 155 */     for (int j = 0; j < 8; j++) {
/* 156 */       fdctCol(block, off + j);
/*     */     }
/*     */     
/* 159 */     for (int i = 0; i < 64; i += 8) {
/* 160 */       fdctRow(block, off + i);
/*     */     }
/*     */   }
/*     */   
/*     */   private static void fdctRow(int[] block, int off) {
/* 165 */     int z0 = block[off + 0] - block[off + 7];
/* 166 */     int z1 = block[off + 1] - block[off + 6];
/* 167 */     int z2 = block[off + 2] - block[off + 5];
/* 168 */     int z3 = block[off + 3] - block[off + 4];
/* 169 */     int z4 = block[off + 0] + block[off + 7];
/* 170 */     int z5 = block[off + 3] + block[off + 4];
/* 171 */     int z6 = block[off + 1] + block[off + 6];
/* 172 */     int z7 = block[off + 2] + block[off + 5];
/*     */     
/* 174 */     int u0 = z4 - z5;
/* 175 */     int u1 = z6 - z7;
/* 176 */     int c0 = (z4 + z5) * 23170;
/* 177 */     int c1 = (z6 + z7) * 23170;
/*     */     
/* 179 */     int c2 = u0 * 30274;
/* 180 */     int c3 = u1 * 12540;
/* 181 */     int c4 = u0 * 12540;
/* 182 */     int c5 = u1 * 30274;
/*     */     
/* 184 */     block[1 + off] = z0 * 32138 + z1 * 27246 + z2 * 18205 + z3 * 6393 + 32768 >> 16;
/* 185 */     block[3 + off] = z0 * 27246 - z1 * 6393 - z2 * 32138 - z3 * 18205 + 32768 >> 16;
/* 186 */     block[5 + off] = z0 * 18205 - z1 * 32138 + z2 * 6393 + z3 * 27246 + 32768 >> 16;
/* 187 */     block[7 + off] = z0 * 6393 - z1 * 18205 + z2 * 27246 - z3 * 32138 + 32768 >> 16;
/* 188 */     block[0 + off] = c0 + c1 + 32768 >> 16;
/* 189 */     block[2 + off] = c2 + c3 + 32768 >> 16;
/* 190 */     block[4 + off] = c0 - c1 + 32768 >> 16;
/* 191 */     block[6 + off] = c4 - c5 + 32768 >> 16;
/*     */   }
/*     */   
/*     */   private static void fdctCol(int[] block, int off) {
/* 195 */     int z0 = block[off + 0] - block[off + 56];
/* 196 */     int z1 = block[off + 8] - block[off + 48];
/* 197 */     int z2 = block[off + 16] - block[off + 40];
/* 198 */     int z3 = block[off + 24] - block[off + 32];
/* 199 */     int z4 = block[off + 0] + block[off + 56];
/* 200 */     int z5 = block[off + 24] + block[off + 32];
/* 201 */     int z6 = block[off + 8] + block[off + 48];
/* 202 */     int z7 = block[off + 16] + block[off + 40];
/*     */     
/* 204 */     int u0 = z4 - z5;
/* 205 */     int u1 = z6 - z7;
/* 206 */     int c0 = (z4 + z5) * 23170;
/* 207 */     int c1 = (z6 + z7) * 23170;
/*     */     
/* 209 */     int c2 = u0 * 30274;
/* 210 */     int c3 = u1 * 12540;
/* 211 */     int c4 = u0 * 12540;
/* 212 */     int c5 = u1 * 30274;
/*     */     
/* 214 */     block[8 + off] = z0 * 32138 + z1 * 27246 + z2 * 18205 + z3 * 6393 + 8192 >> 14;
/* 215 */     block[24 + off] = z0 * 27246 - z1 * 6393 - z2 * 32138 - z3 * 18205 + 8192 >> 14;
/* 216 */     block[40 + off] = z0 * 18205 - z1 * 32138 + z2 * 6393 + z3 * 27246 + 8192 >> 14;
/* 217 */     block[56 + off] = z0 * 6393 - z1 * 18205 + z2 * 27246 - z3 * 32138 + 8192 >> 14;
/* 218 */     block[0 + off] = c0 + c1 + 8192 >> 14;
/* 219 */     block[16 + off] = c2 + c3 + 8192 >> 14;
/* 220 */     block[32 + off] = c0 - c1 + 8192 >> 14;
/* 221 */     block[48 + off] = c4 - c5 + 8192 >> 14;
/*     */   }
/*     */ }


/* Location:              C:\Users\rapha\Downloads\aurora.jar!\META-INF\jars\jcodec-0.2.5.jar!\org\jcodec\common\dct\SimpleIDCT10Bit.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */