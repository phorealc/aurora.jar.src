/*    */ package org.jcodec.common.dct;
/*    */ 
/*    */ import java.util.Arrays;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class SparseIDCT
/*    */ {
/* 17 */   public static final int[][] COEFF = new int[64][];
/*    */   public static final int PRECISION = 13;
/*    */   public static final int DC_SHIFT = 10;
/*    */   
/*    */   static {
/* 22 */     COEFF[0] = new int[64];
/* 23 */     Arrays.fill(COEFF[0], 1024);
/*    */     
/* 25 */     int ac = 8192;
/* 26 */     for (int i = 1; i < 64; i++) {
/* 27 */       COEFF[i] = new int[64];
/* 28 */       COEFF[i][i] = ac;
/* 29 */       SimpleIDCT10Bit.idct10(COEFF[i], 0);
/*    */     } 
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public static final void start(int[] block, int dc) {
/* 42 */     dc <<= 10;
/* 43 */     for (int i = 0; i < 64; i += 4) {
/* 44 */       block[i + 0] = dc;
/* 45 */       block[i + 1] = dc;
/* 46 */       block[i + 2] = dc;
/* 47 */       block[i + 3] = dc;
/*    */     } 
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public static final void coeff(int[] block, int ind, int level) {
/* 59 */     for (int i = 0; i < 64; i += 4) {
/* 60 */       block[i] = block[i] + COEFF[ind][i] * level;
/* 61 */       block[i + 1] = block[i + 1] + COEFF[ind][i + 1] * level;
/* 62 */       block[i + 2] = block[i + 2] + COEFF[ind][i + 2] * level;
/* 63 */       block[i + 3] = block[i + 3] + COEFF[ind][i + 3] * level;
/*    */     } 
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public static final void finish(int[] block) {
/* 73 */     for (int i = 0; i < 64; i += 4) {
/* 74 */       block[i] = div(block[i]);
/* 75 */       block[i + 1] = div(block[i + 1]);
/* 76 */       block[i + 2] = div(block[i + 2]);
/* 77 */       block[i + 3] = div(block[i + 3]);
/*    */     } 
/*    */   }
/*    */   
/*    */   private static final int div(int x) {
/* 82 */     int m = x >> 31;
/* 83 */     int n = x >>> 31;
/* 84 */     return ((x ^ m) + n >> 13 ^ m) + n;
/*    */   }
/*    */ }


/* Location:              C:\Users\rapha\Downloads\aurora.jar!\META-INF\jars\jcodec-0.2.5.jar!\org\jcodec\common\dct\SparseIDCT.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */