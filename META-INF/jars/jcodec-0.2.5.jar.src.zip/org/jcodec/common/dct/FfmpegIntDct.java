/*     */ package org.jcodec.common.dct;
/*     */ 
/*     */ import java.nio.ShortBuffer;
/*     */ 
/*     */ 
/*     */ public class FfmpegIntDct
/*     */ {
/*     */   private static final int DCTSIZE = 8;
/*     */   private static final int DCTSIZE_6 = 48;
/*     */   private static final int DCTSIZE_5 = 40;
/*     */   private static final int DCTSIZE_4 = 32;
/*     */   private static final int DCTSIZE_3 = 24;
/*     */   private static final int DCTSIZE_2 = 16;
/*     */   private static final int DCTSIZE_1 = 8;
/*     */   private static final int DCTSIZE_7 = 56;
/*     */   private static final int DCTSIZE_0 = 0;
/*     */   private static final int PASS1_BITS = 2;
/*     */   private static final int CONST_BITS = 13;
/*     */   private static final int D1 = 11;
/*     */   private static final int D2 = 18;
/*     */   private static final int ONEHALF_11 = 1024;
/*     */   private static final int ONEHALF_18 = 131072;
/*     */   private static final short FIX_0_211164243 = 1730;
/*     */   private static final short FIX_0_275899380 = 2260;
/*     */   private static final short FIX_0_298631336 = 2446;
/*     */   private static final short FIX_0_390180644 = 3196;
/*     */   
/*     */   public short[] decode(short[] orig) {
/*  29 */     ShortBuffer data = ShortBuffer.wrap(orig);
/*  30 */     pass1(data);
/*  31 */     pass2(data);
/*  32 */     return orig;
/*     */   }
/*     */   private static final short FIX_0_509795579 = 4176; private static final short FIX_0_541196100 = 4433; private static final short FIX_0_601344887 = 4926; private static final short FIX_0_765366865 = 6270; private static final short FIX_0_785694958 = 6436; private static final short FIX_0_899976223 = 7373; private static final short FIX_1_061594337 = 8697; private static final short FIX_1_111140466 = 9102; private static final short FIX_1_175875602 = 9633; private static final short FIX_1_306562965 = 10703; private static final short FIX_1_387039845 = 11363; private static final short FIX_1_451774981 = 11893; private static final short FIX_1_501321110 = 12299; private static final short FIX_1_662939225 = 13623; private static final short FIX_1_847759065 = 15137; private static final short FIX_1_961570560 = 16069; private static final short FIX_2_053119869 = 16819; private static final short FIX_2_172734803 = 17799; private static final short FIX_2_562915447 = 20995; private static final short FIX_3_072711026 = 25172;
/*     */   private static ShortBuffer advance(ShortBuffer dataptr, int size) {
/*  36 */     dataptr.position(dataptr.position() + size);
/*  37 */     return dataptr.slice();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static final void pass1(ShortBuffer data) {
/*  88 */     ShortBuffer dataptr = data.duplicate();
/*     */     
/*  90 */     for (int rowctr = 7; rowctr >= 0; rowctr--) {
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 106 */       int d0 = dataptr.get(0);
/* 107 */       int d2 = dataptr.get(1);
/* 108 */       int d4 = dataptr.get(2);
/* 109 */       int d6 = dataptr.get(3);
/* 110 */       int d1 = dataptr.get(4);
/* 111 */       int d3 = dataptr.get(5);
/* 112 */       int d5 = dataptr.get(6);
/* 113 */       int d7 = dataptr.get(7);
/*     */       
/* 115 */       if ((d1 | d2 | d3 | d4 | d5 | d6 | d7) == 0) {
/*     */         
/* 117 */         if (d0 != 0) {
/*     */           
/* 119 */           int dcval = d0 << 2;
/* 120 */           for (int i = 0; i < 8; i++) {
/* 121 */             dataptr.put(i, (short)dcval);
/*     */           }
/*     */         } 
/*     */ 
/*     */ 
/*     */         
/* 127 */         dataptr = advance(dataptr, 8);
/*     */       } else {
/*     */         int tmp2, tmp3, tmp0, tmp1, tmp10, tmp13, tmp11, tmp12;
/*     */ 
/*     */ 
/*     */         
/* 133 */         if (d6 != 0) {
/* 134 */           if (d2 != 0) {
/*     */             
/* 136 */             int z1 = MULTIPLY(d2 + d6, (short)4433);
/* 137 */             tmp2 = z1 + MULTIPLY(-d6, (short)15137);
/* 138 */             tmp3 = z1 + MULTIPLY(d2, (short)6270);
/*     */             
/* 140 */             tmp0 = d0 + d4 << 13;
/* 141 */             tmp1 = d0 - d4 << 13;
/*     */             
/* 143 */             tmp10 = tmp0 + tmp3;
/* 144 */             tmp13 = tmp0 - tmp3;
/* 145 */             tmp11 = tmp1 + tmp2;
/* 146 */             tmp12 = tmp1 - tmp2;
/*     */           } else {
/*     */             
/* 149 */             tmp2 = MULTIPLY(-d6, (short)10703);
/* 150 */             tmp3 = MULTIPLY(d6, (short)4433);
/*     */             
/* 152 */             tmp0 = d0 + d4 << 13;
/* 153 */             tmp1 = d0 - d4 << 13;
/*     */             
/* 155 */             tmp10 = tmp0 + tmp3;
/* 156 */             tmp13 = tmp0 - tmp3;
/* 157 */             tmp11 = tmp1 + tmp2;
/* 158 */             tmp12 = tmp1 - tmp2;
/*     */           }
/*     */         
/* 161 */         } else if (d2 != 0) {
/*     */           
/* 163 */           tmp2 = MULTIPLY(d2, (short)4433);
/* 164 */           tmp3 = MULTIPLY(d2, (short)10703);
/*     */           
/* 166 */           tmp0 = d0 + d4 << 13;
/* 167 */           tmp1 = d0 - d4 << 13;
/*     */           
/* 169 */           tmp10 = tmp0 + tmp3;
/* 170 */           tmp13 = tmp0 - tmp3;
/* 171 */           tmp11 = tmp1 + tmp2;
/* 172 */           tmp12 = tmp1 - tmp2;
/*     */         } else {
/*     */           
/* 175 */           tmp10 = tmp13 = d0 + d4 << 13;
/* 176 */           tmp11 = tmp12 = d0 - d4 << 13;
/*     */         } 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */         
/* 185 */         if (d7 != 0) {
/* 186 */           if (d5 != 0) {
/* 187 */             if (d3 != 0) {
/* 188 */               if (d1 != 0) {
/*     */                 
/* 190 */                 int z1 = d7 + d1;
/* 191 */                 int z2 = d5 + d3;
/* 192 */                 int z3 = d7 + d3;
/* 193 */                 int z4 = d5 + d1;
/* 194 */                 int z5 = MULTIPLY(z3 + z4, (short)9633);
/*     */                 
/* 196 */                 tmp0 = MULTIPLY(d7, (short)2446);
/* 197 */                 tmp1 = MULTIPLY(d5, (short)16819);
/* 198 */                 tmp2 = MULTIPLY(d3, (short)25172);
/* 199 */                 tmp3 = MULTIPLY(d1, (short)12299);
/* 200 */                 z1 = MULTIPLY(-z1, (short)7373);
/* 201 */                 z2 = MULTIPLY(-z2, (short)20995);
/* 202 */                 z3 = MULTIPLY(-z3, (short)16069);
/* 203 */                 z4 = MULTIPLY(-z4, (short)3196);
/*     */                 
/* 205 */                 z3 += z5;
/* 206 */                 z4 += z5;
/*     */                 
/* 208 */                 tmp0 += z1 + z3;
/* 209 */                 tmp1 += z2 + z4;
/* 210 */                 tmp2 += z2 + z3;
/* 211 */                 tmp3 += z1 + z4;
/*     */               } else {
/*     */                 
/* 214 */                 int z2 = d5 + d3;
/* 215 */                 int z3 = d7 + d3;
/* 216 */                 int z5 = MULTIPLY(z3 + d5, (short)9633);
/*     */                 
/* 218 */                 tmp0 = MULTIPLY(d7, (short)2446);
/* 219 */                 tmp1 = MULTIPLY(d5, (short)16819);
/* 220 */                 tmp2 = MULTIPLY(d3, (short)25172);
/* 221 */                 int z1 = MULTIPLY(-d7, (short)7373);
/* 222 */                 z2 = MULTIPLY(-z2, (short)20995);
/* 223 */                 z3 = MULTIPLY(-z3, (short)16069);
/* 224 */                 int z4 = MULTIPLY(-d5, (short)3196);
/*     */                 
/* 226 */                 z3 += z5;
/* 227 */                 z4 += z5;
/*     */                 
/* 229 */                 tmp0 += z1 + z3;
/* 230 */                 tmp1 += z2 + z4;
/* 231 */                 tmp2 += z2 + z3;
/* 232 */                 tmp3 = z1 + z4;
/*     */               }
/*     */             
/* 235 */             } else if (d1 != 0) {
/*     */               
/* 237 */               int z1 = d7 + d1;
/* 238 */               int z4 = d5 + d1;
/* 239 */               int z5 = MULTIPLY(d7 + z4, (short)9633);
/*     */               
/* 241 */               tmp0 = MULTIPLY(d7, (short)2446);
/* 242 */               tmp1 = MULTIPLY(d5, (short)16819);
/* 243 */               tmp3 = MULTIPLY(d1, (short)12299);
/* 244 */               z1 = MULTIPLY(-z1, (short)7373);
/* 245 */               int z2 = MULTIPLY(-d5, (short)20995);
/* 246 */               int z3 = MULTIPLY(-d7, (short)16069);
/* 247 */               z4 = MULTIPLY(-z4, (short)3196);
/*     */               
/* 249 */               z3 += z5;
/* 250 */               z4 += z5;
/*     */               
/* 252 */               tmp0 += z1 + z3;
/* 253 */               tmp1 += z2 + z4;
/* 254 */               tmp2 = z2 + z3;
/* 255 */               tmp3 += z1 + z4;
/*     */             } else {
/*     */               
/* 258 */               tmp0 = MULTIPLY(-d7, (short)4926);
/* 259 */               int z1 = MULTIPLY(-d7, (short)7373);
/* 260 */               int z3 = MULTIPLY(-d7, (short)16069);
/* 261 */               tmp1 = MULTIPLY(-d5, (short)4176);
/* 262 */               int z2 = MULTIPLY(-d5, (short)20995);
/* 263 */               int z4 = MULTIPLY(-d5, (short)3196);
/* 264 */               int z5 = MULTIPLY(d5 + d7, (short)9633);
/*     */               
/* 266 */               z3 += z5;
/* 267 */               z4 += z5;
/*     */               
/* 269 */               tmp0 += z3;
/* 270 */               tmp1 += z4;
/* 271 */               tmp2 = z2 + z3;
/* 272 */               tmp3 = z1 + z4;
/*     */             }
/*     */           
/*     */           }
/* 276 */           else if (d3 != 0) {
/* 277 */             if (d1 != 0) {
/*     */               
/* 279 */               int z1 = d7 + d1;
/* 280 */               int z3 = d7 + d3;
/* 281 */               int z5 = MULTIPLY(z3 + d1, (short)9633);
/*     */               
/* 283 */               tmp0 = MULTIPLY(d7, (short)2446);
/* 284 */               tmp2 = MULTIPLY(d3, (short)25172);
/* 285 */               tmp3 = MULTIPLY(d1, (short)12299);
/* 286 */               z1 = MULTIPLY(-z1, (short)7373);
/* 287 */               int z2 = MULTIPLY(-d3, (short)20995);
/* 288 */               z3 = MULTIPLY(-z3, (short)16069);
/* 289 */               int z4 = MULTIPLY(-d1, (short)3196);
/*     */               
/* 291 */               z3 += z5;
/* 292 */               z4 += z5;
/*     */               
/* 294 */               tmp0 += z1 + z3;
/* 295 */               tmp1 = z2 + z4;
/* 296 */               tmp2 += z2 + z3;
/* 297 */               tmp3 += z1 + z4;
/*     */             } else {
/*     */               
/* 300 */               int z3 = d7 + d3;
/*     */               
/* 302 */               tmp0 = MULTIPLY(-d7, (short)4926);
/* 303 */               int z1 = MULTIPLY(-d7, (short)7373);
/* 304 */               tmp2 = MULTIPLY(d3, (short)4176);
/* 305 */               int z2 = MULTIPLY(-d3, (short)20995);
/* 306 */               int z5 = MULTIPLY(z3, (short)9633);
/* 307 */               z3 = MULTIPLY(-z3, (short)6436);
/*     */               
/* 309 */               tmp0 += z3;
/* 310 */               tmp1 = z2 + z5;
/* 311 */               tmp2 += z3;
/* 312 */               tmp3 = z1 + z5;
/*     */             }
/*     */           
/* 315 */           } else if (d1 != 0) {
/*     */             
/* 317 */             int z1 = d7 + d1;
/* 318 */             int z5 = MULTIPLY(z1, (short)9633);
/*     */             
/* 320 */             z1 = MULTIPLY(z1, (short)2260);
/* 321 */             int z3 = MULTIPLY(-d7, (short)16069);
/* 322 */             tmp0 = MULTIPLY(-d7, (short)13623);
/* 323 */             int z4 = MULTIPLY(-d1, (short)3196);
/* 324 */             tmp3 = MULTIPLY(d1, (short)9102);
/*     */             
/* 326 */             tmp0 += z1;
/* 327 */             tmp1 = z4 + z5;
/* 328 */             tmp2 = z3 + z5;
/* 329 */             tmp3 += z1;
/*     */           } else {
/*     */             
/* 332 */             tmp0 = MULTIPLY(-d7, (short)11363);
/* 333 */             tmp1 = MULTIPLY(d7, (short)9633);
/* 334 */             tmp2 = MULTIPLY(-d7, (short)6436);
/* 335 */             tmp3 = MULTIPLY(d7, (short)2260);
/*     */           
/*     */           }
/*     */         
/*     */         }
/* 340 */         else if (d5 != 0) {
/* 341 */           if (d3 != 0) {
/* 342 */             if (d1 != 0) {
/*     */               
/* 344 */               int z2 = d5 + d3;
/* 345 */               int z4 = d5 + d1;
/* 346 */               int z5 = MULTIPLY(d3 + z4, (short)9633);
/*     */               
/* 348 */               tmp1 = MULTIPLY(d5, (short)16819);
/* 349 */               tmp2 = MULTIPLY(d3, (short)25172);
/* 350 */               tmp3 = MULTIPLY(d1, (short)12299);
/* 351 */               int z1 = MULTIPLY(-d1, (short)7373);
/* 352 */               z2 = MULTIPLY(-z2, (short)20995);
/* 353 */               int z3 = MULTIPLY(-d3, (short)16069);
/* 354 */               z4 = MULTIPLY(-z4, (short)3196);
/*     */               
/* 356 */               z3 += z5;
/* 357 */               z4 += z5;
/*     */               
/* 359 */               tmp0 = z1 + z3;
/* 360 */               tmp1 += z2 + z4;
/* 361 */               tmp2 += z2 + z3;
/* 362 */               tmp3 += z1 + z4;
/*     */             } else {
/*     */               
/* 365 */               int z2 = d5 + d3;
/*     */               
/* 367 */               int z5 = MULTIPLY(z2, (short)9633);
/* 368 */               tmp1 = MULTIPLY(d5, (short)13623);
/* 369 */               int z4 = MULTIPLY(-d5, (short)3196);
/* 370 */               z2 = MULTIPLY(-z2, (short)11363);
/* 371 */               tmp2 = MULTIPLY(d3, (short)9102);
/* 372 */               int z3 = MULTIPLY(-d3, (short)16069);
/*     */               
/* 374 */               tmp0 = z3 + z5;
/* 375 */               tmp1 += z2;
/* 376 */               tmp2 += z2;
/* 377 */               tmp3 = z4 + z5;
/*     */             }
/*     */           
/* 380 */           } else if (d1 != 0) {
/*     */             
/* 382 */             int z4 = d5 + d1;
/*     */             
/* 384 */             int z5 = MULTIPLY(z4, (short)9633);
/* 385 */             int z1 = MULTIPLY(-d1, (short)7373);
/* 386 */             tmp3 = MULTIPLY(d1, (short)4926);
/* 387 */             tmp1 = MULTIPLY(-d5, (short)4176);
/* 388 */             int z2 = MULTIPLY(-d5, (short)20995);
/* 389 */             z4 = MULTIPLY(z4, (short)6436);
/*     */             
/* 391 */             tmp0 = z1 + z5;
/* 392 */             tmp1 += z4;
/* 393 */             tmp2 = z2 + z5;
/* 394 */             tmp3 += z4;
/*     */           } else {
/*     */             
/* 397 */             tmp0 = MULTIPLY(d5, (short)9633);
/* 398 */             tmp1 = MULTIPLY(d5, (short)2260);
/* 399 */             tmp2 = MULTIPLY(-d5, (short)11363);
/* 400 */             tmp3 = MULTIPLY(d5, (short)6436);
/*     */           }
/*     */         
/*     */         }
/* 404 */         else if (d3 != 0) {
/* 405 */           if (d1 != 0) {
/*     */             
/* 407 */             int z5 = d1 + d3;
/* 408 */             tmp3 = MULTIPLY(d1, (short)1730);
/* 409 */             tmp2 = MULTIPLY(-d3, (short)11893);
/* 410 */             int z1 = MULTIPLY(d1, (short)8697);
/* 411 */             int z2 = MULTIPLY(-d3, (short)17799);
/* 412 */             int z4 = MULTIPLY(z5, (short)6436);
/* 413 */             z5 = MULTIPLY(z5, (short)9633);
/*     */             
/* 415 */             tmp0 = z1 - z4;
/* 416 */             tmp1 = z2 + z4;
/* 417 */             tmp2 += z5;
/* 418 */             tmp3 += z5;
/*     */           } else {
/*     */             
/* 421 */             tmp0 = MULTIPLY(-d3, (short)6436);
/* 422 */             tmp1 = MULTIPLY(-d3, (short)11363);
/* 423 */             tmp2 = MULTIPLY(-d3, (short)2260);
/* 424 */             tmp3 = MULTIPLY(d3, (short)9633);
/*     */           }
/*     */         
/* 427 */         } else if (d1 != 0) {
/*     */           
/* 429 */           tmp0 = MULTIPLY(d1, (short)2260);
/* 430 */           tmp1 = MULTIPLY(d1, (short)6436);
/* 431 */           tmp2 = MULTIPLY(d1, (short)9633);
/* 432 */           tmp3 = MULTIPLY(d1, (short)11363);
/*     */         } else {
/*     */           
/* 435 */           tmp0 = tmp1 = tmp2 = tmp3 = 0;
/*     */         } 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */         
/* 442 */         dataptr.put(0, DESCALE11(tmp10 + tmp3));
/* 443 */         dataptr.put(7, DESCALE11(tmp10 - tmp3));
/* 444 */         dataptr.put(1, DESCALE11(tmp11 + tmp2));
/* 445 */         dataptr.put(6, DESCALE11(tmp11 - tmp2));
/* 446 */         dataptr.put(2, DESCALE11(tmp12 + tmp1));
/* 447 */         dataptr.put(5, DESCALE11(tmp12 - tmp1));
/* 448 */         dataptr.put(3, DESCALE11(tmp13 + tmp0));
/* 449 */         dataptr.put(4, DESCALE11(tmp13 - tmp0));
/*     */         
/* 451 */         dataptr = advance(dataptr, 8);
/*     */       } 
/*     */     } 
/*     */   }
/*     */   
/*     */   private static int MULTIPLY(int x, short y) {
/* 457 */     return y * (short)x;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static final void pass2(ShortBuffer data) {
/* 468 */     ShortBuffer dataptr = data.duplicate();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 474 */     for (int rowctr = 7; rowctr >= 0; rowctr--) {
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 484 */       int tmp0, tmp1, tmp2, tmp3, tmp10, tmp11, tmp12, tmp13, d0 = dataptr.get(0);
/* 485 */       int d1 = dataptr.get(8);
/* 486 */       int d2 = dataptr.get(16);
/* 487 */       int d3 = dataptr.get(24);
/* 488 */       int d4 = dataptr.get(32);
/* 489 */       int d5 = dataptr.get(40);
/* 490 */       int d6 = dataptr.get(48);
/* 491 */       int d7 = dataptr.get(56);
/*     */ 
/*     */ 
/*     */       
/* 495 */       if (d6 != 0) {
/* 496 */         if (d2 != 0) {
/*     */           
/* 498 */           int z1 = MULTIPLY(d2 + d6, (short)4433);
/* 499 */           tmp2 = z1 + MULTIPLY(-d6, (short)15137);
/* 500 */           tmp3 = z1 + MULTIPLY(d2, (short)6270);
/*     */           
/* 502 */           tmp0 = d0 + d4 << 13;
/* 503 */           tmp1 = d0 - d4 << 13;
/*     */           
/* 505 */           tmp10 = tmp0 + tmp3;
/* 506 */           tmp13 = tmp0 - tmp3;
/* 507 */           tmp11 = tmp1 + tmp2;
/* 508 */           tmp12 = tmp1 - tmp2;
/*     */         } else {
/*     */           
/* 511 */           tmp2 = MULTIPLY(-d6, (short)10703);
/* 512 */           tmp3 = MULTIPLY(d6, (short)4433);
/*     */           
/* 514 */           tmp0 = d0 + d4 << 13;
/* 515 */           tmp1 = d0 - d4 << 13;
/*     */           
/* 517 */           tmp10 = tmp0 + tmp3;
/* 518 */           tmp13 = tmp0 - tmp3;
/* 519 */           tmp11 = tmp1 + tmp2;
/* 520 */           tmp12 = tmp1 - tmp2;
/*     */         }
/*     */       
/* 523 */       } else if (d2 != 0) {
/*     */         
/* 525 */         tmp2 = MULTIPLY(d2, (short)4433);
/* 526 */         tmp3 = MULTIPLY(d2, (short)10703);
/*     */         
/* 528 */         tmp0 = d0 + d4 << 13;
/* 529 */         tmp1 = d0 - d4 << 13;
/*     */         
/* 531 */         tmp10 = tmp0 + tmp3;
/* 532 */         tmp13 = tmp0 - tmp3;
/* 533 */         tmp11 = tmp1 + tmp2;
/* 534 */         tmp12 = tmp1 - tmp2;
/*     */       } else {
/*     */         
/* 537 */         tmp10 = tmp13 = d0 + d4 << 13;
/* 538 */         tmp11 = tmp12 = d0 - d4 << 13;
/*     */       } 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 546 */       if (d7 != 0) {
/* 547 */         if (d5 != 0) {
/* 548 */           if (d3 != 0) {
/* 549 */             if (d1 != 0) {
/*     */               
/* 551 */               int z1 = d7 + d1;
/* 552 */               int z2 = d5 + d3;
/* 553 */               int z3 = d7 + d3;
/* 554 */               int z4 = d5 + d1;
/* 555 */               int z5 = MULTIPLY(z3 + z4, (short)9633);
/*     */               
/* 557 */               tmp0 = MULTIPLY(d7, (short)2446);
/* 558 */               tmp1 = MULTIPLY(d5, (short)16819);
/* 559 */               tmp2 = MULTIPLY(d3, (short)25172);
/* 560 */               tmp3 = MULTIPLY(d1, (short)12299);
/* 561 */               z1 = MULTIPLY(-z1, (short)7373);
/* 562 */               z2 = MULTIPLY(-z2, (short)20995);
/* 563 */               z3 = MULTIPLY(-z3, (short)16069);
/* 564 */               z4 = MULTIPLY(-z4, (short)3196);
/*     */               
/* 566 */               z3 += z5;
/* 567 */               z4 += z5;
/*     */               
/* 569 */               tmp0 += z1 + z3;
/* 570 */               tmp1 += z2 + z4;
/* 571 */               tmp2 += z2 + z3;
/* 572 */               tmp3 += z1 + z4;
/*     */             } else {
/*     */               
/* 575 */               int z1 = d7;
/* 576 */               int z2 = d5 + d3;
/* 577 */               int z3 = d7 + d3;
/* 578 */               int z5 = MULTIPLY(z3 + d5, (short)9633);
/*     */               
/* 580 */               tmp0 = MULTIPLY(d7, (short)2446);
/* 581 */               tmp1 = MULTIPLY(d5, (short)16819);
/* 582 */               tmp2 = MULTIPLY(d3, (short)25172);
/* 583 */               z1 = MULTIPLY(-d7, (short)7373);
/* 584 */               z2 = MULTIPLY(-z2, (short)20995);
/* 585 */               z3 = MULTIPLY(-z3, (short)16069);
/* 586 */               int z4 = MULTIPLY(-d5, (short)3196);
/*     */               
/* 588 */               z3 += z5;
/* 589 */               z4 += z5;
/*     */               
/* 591 */               tmp0 += z1 + z3;
/* 592 */               tmp1 += z2 + z4;
/* 593 */               tmp2 += z2 + z3;
/* 594 */               tmp3 = z1 + z4;
/*     */             }
/*     */           
/* 597 */           } else if (d1 != 0) {
/*     */             
/* 599 */             int z1 = d7 + d1;
/* 600 */             int z2 = d5;
/* 601 */             int z3 = d7;
/* 602 */             int z4 = d5 + d1;
/* 603 */             int z5 = MULTIPLY(z3 + z4, (short)9633);
/*     */             
/* 605 */             tmp0 = MULTIPLY(d7, (short)2446);
/* 606 */             tmp1 = MULTIPLY(d5, (short)16819);
/* 607 */             tmp3 = MULTIPLY(d1, (short)12299);
/* 608 */             z1 = MULTIPLY(-z1, (short)7373);
/* 609 */             z2 = MULTIPLY(-d5, (short)20995);
/* 610 */             z3 = MULTIPLY(-d7, (short)16069);
/* 611 */             z4 = MULTIPLY(-z4, (short)3196);
/*     */             
/* 613 */             z3 += z5;
/* 614 */             z4 += z5;
/*     */             
/* 616 */             tmp0 += z1 + z3;
/* 617 */             tmp1 += z2 + z4;
/* 618 */             tmp2 = z2 + z3;
/* 619 */             tmp3 += z1 + z4;
/*     */           } else {
/*     */             
/* 622 */             tmp0 = MULTIPLY(-d7, (short)4926);
/* 623 */             int z1 = MULTIPLY(-d7, (short)7373);
/* 624 */             int z3 = MULTIPLY(-d7, (short)16069);
/* 625 */             tmp1 = MULTIPLY(-d5, (short)4176);
/* 626 */             int z2 = MULTIPLY(-d5, (short)20995);
/* 627 */             int z4 = MULTIPLY(-d5, (short)3196);
/* 628 */             int z5 = MULTIPLY(d5 + d7, (short)9633);
/*     */             
/* 630 */             z3 += z5;
/* 631 */             z4 += z5;
/*     */             
/* 633 */             tmp0 += z3;
/* 634 */             tmp1 += z4;
/* 635 */             tmp2 = z2 + z3;
/* 636 */             tmp3 = z1 + z4;
/*     */           }
/*     */         
/*     */         }
/* 640 */         else if (d3 != 0) {
/* 641 */           if (d1 != 0) {
/*     */             
/* 643 */             int z1 = d7 + d1;
/* 644 */             int z3 = d7 + d3;
/* 645 */             int z5 = MULTIPLY(z3 + d1, (short)9633);
/*     */             
/* 647 */             tmp0 = MULTIPLY(d7, (short)2446);
/* 648 */             tmp2 = MULTIPLY(d3, (short)25172);
/* 649 */             tmp3 = MULTIPLY(d1, (short)12299);
/* 650 */             z1 = MULTIPLY(-z1, (short)7373);
/* 651 */             int z2 = MULTIPLY(-d3, (short)20995);
/* 652 */             z3 = MULTIPLY(-z3, (short)16069);
/* 653 */             int z4 = MULTIPLY(-d1, (short)3196);
/*     */             
/* 655 */             z3 += z5;
/* 656 */             z4 += z5;
/*     */             
/* 658 */             tmp0 += z1 + z3;
/* 659 */             tmp1 = z2 + z4;
/* 660 */             tmp2 += z2 + z3;
/* 661 */             tmp3 += z1 + z4;
/*     */           } else {
/*     */             
/* 664 */             int z3 = d7 + d3;
/*     */             
/* 666 */             tmp0 = MULTIPLY(-d7, (short)4926);
/* 667 */             int z1 = MULTIPLY(-d7, (short)7373);
/* 668 */             tmp2 = MULTIPLY(d3, (short)4176);
/* 669 */             int z2 = MULTIPLY(-d3, (short)20995);
/* 670 */             int z5 = MULTIPLY(z3, (short)9633);
/* 671 */             z3 = MULTIPLY(-z3, (short)6436);
/*     */             
/* 673 */             tmp0 += z3;
/* 674 */             tmp1 = z2 + z5;
/* 675 */             tmp2 += z3;
/* 676 */             tmp3 = z1 + z5;
/*     */           }
/*     */         
/* 679 */         } else if (d1 != 0) {
/*     */           
/* 681 */           int z1 = d7 + d1;
/* 682 */           int z5 = MULTIPLY(z1, (short)9633);
/*     */           
/* 684 */           z1 = MULTIPLY(z1, (short)2260);
/* 685 */           int z3 = MULTIPLY(-d7, (short)16069);
/* 686 */           tmp0 = MULTIPLY(-d7, (short)13623);
/* 687 */           int z4 = MULTIPLY(-d1, (short)3196);
/* 688 */           tmp3 = MULTIPLY(d1, (short)9102);
/*     */           
/* 690 */           tmp0 += z1;
/* 691 */           tmp1 = z4 + z5;
/* 692 */           tmp2 = z3 + z5;
/* 693 */           tmp3 += z1;
/*     */         } else {
/*     */           
/* 696 */           tmp0 = MULTIPLY(-d7, (short)11363);
/* 697 */           tmp1 = MULTIPLY(d7, (short)9633);
/* 698 */           tmp2 = MULTIPLY(-d7, (short)6436);
/* 699 */           tmp3 = MULTIPLY(d7, (short)2260);
/*     */         
/*     */         }
/*     */       
/*     */       }
/* 704 */       else if (d5 != 0) {
/* 705 */         if (d3 != 0) {
/* 706 */           if (d1 != 0) {
/*     */             
/* 708 */             int z2 = d5 + d3;
/* 709 */             int z4 = d5 + d1;
/* 710 */             int z5 = MULTIPLY(d3 + z4, (short)9633);
/*     */             
/* 712 */             tmp1 = MULTIPLY(d5, (short)16819);
/* 713 */             tmp2 = MULTIPLY(d3, (short)25172);
/* 714 */             tmp3 = MULTIPLY(d1, (short)12299);
/* 715 */             int z1 = MULTIPLY(-d1, (short)7373);
/* 716 */             z2 = MULTIPLY(-z2, (short)20995);
/* 717 */             int z3 = MULTIPLY(-d3, (short)16069);
/* 718 */             z4 = MULTIPLY(-z4, (short)3196);
/*     */             
/* 720 */             z3 += z5;
/* 721 */             z4 += z5;
/*     */             
/* 723 */             tmp0 = z1 + z3;
/* 724 */             tmp1 += z2 + z4;
/* 725 */             tmp2 += z2 + z3;
/* 726 */             tmp3 += z1 + z4;
/*     */           } else {
/*     */             
/* 729 */             int z2 = d5 + d3;
/*     */             
/* 731 */             int z5 = MULTIPLY(z2, (short)9633);
/* 732 */             tmp1 = MULTIPLY(d5, (short)13623);
/* 733 */             int z4 = MULTIPLY(-d5, (short)3196);
/* 734 */             z2 = MULTIPLY(-z2, (short)11363);
/* 735 */             tmp2 = MULTIPLY(d3, (short)9102);
/* 736 */             int z3 = MULTIPLY(-d3, (short)16069);
/*     */             
/* 738 */             tmp0 = z3 + z5;
/* 739 */             tmp1 += z2;
/* 740 */             tmp2 += z2;
/* 741 */             tmp3 = z4 + z5;
/*     */           }
/*     */         
/* 744 */         } else if (d1 != 0) {
/*     */           
/* 746 */           int z4 = d5 + d1;
/*     */           
/* 748 */           int z5 = MULTIPLY(z4, (short)9633);
/* 749 */           int z1 = MULTIPLY(-d1, (short)7373);
/* 750 */           tmp3 = MULTIPLY(d1, (short)4926);
/* 751 */           tmp1 = MULTIPLY(-d5, (short)4176);
/* 752 */           int z2 = MULTIPLY(-d5, (short)20995);
/* 753 */           z4 = MULTIPLY(z4, (short)6436);
/*     */           
/* 755 */           tmp0 = z1 + z5;
/* 756 */           tmp1 += z4;
/* 757 */           tmp2 = z2 + z5;
/* 758 */           tmp3 += z4;
/*     */         } else {
/*     */           
/* 761 */           tmp0 = MULTIPLY(d5, (short)9633);
/* 762 */           tmp1 = MULTIPLY(d5, (short)2260);
/* 763 */           tmp2 = MULTIPLY(-d5, (short)11363);
/* 764 */           tmp3 = MULTIPLY(d5, (short)6436);
/*     */         }
/*     */       
/*     */       }
/* 768 */       else if (d3 != 0) {
/* 769 */         if (d1 != 0) {
/*     */           
/* 771 */           int z5 = d1 + d3;
/* 772 */           tmp3 = MULTIPLY(d1, (short)1730);
/* 773 */           tmp2 = MULTIPLY(-d3, (short)11893);
/* 774 */           int z1 = MULTIPLY(d1, (short)8697);
/* 775 */           int z2 = MULTIPLY(-d3, (short)17799);
/* 776 */           int z4 = MULTIPLY(z5, (short)6436);
/* 777 */           z5 = MULTIPLY(z5, (short)9633);
/*     */           
/* 779 */           tmp0 = z1 - z4;
/* 780 */           tmp1 = z2 + z4;
/* 781 */           tmp2 += z5;
/* 782 */           tmp3 += z5;
/*     */         } else {
/*     */           
/* 785 */           tmp0 = MULTIPLY(-d3, (short)6436);
/* 786 */           tmp1 = MULTIPLY(-d3, (short)11363);
/* 787 */           tmp2 = MULTIPLY(-d3, (short)2260);
/* 788 */           tmp3 = MULTIPLY(d3, (short)9633);
/*     */         }
/*     */       
/* 791 */       } else if (d1 != 0) {
/*     */         
/* 793 */         tmp0 = MULTIPLY(d1, (short)2260);
/* 794 */         tmp1 = MULTIPLY(d1, (short)6436);
/* 795 */         tmp2 = MULTIPLY(d1, (short)9633);
/* 796 */         tmp3 = MULTIPLY(d1, (short)11363);
/*     */       } else {
/*     */         
/* 799 */         tmp0 = tmp1 = tmp2 = tmp3 = 0;
/*     */       } 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 807 */       dataptr.put(0, DESCALE18(tmp10 + tmp3));
/* 808 */       dataptr.put(56, DESCALE18(tmp10 - tmp3));
/* 809 */       dataptr.put(8, DESCALE18(tmp11 + tmp2));
/* 810 */       dataptr.put(48, DESCALE18(tmp11 - tmp2));
/* 811 */       dataptr.put(16, DESCALE18(tmp12 + tmp1));
/* 812 */       dataptr.put(40, DESCALE18(tmp12 - tmp1));
/* 813 */       dataptr.put(24, DESCALE18(tmp13 + tmp0));
/* 814 */       dataptr.put(32, DESCALE18(tmp13 - tmp0));
/*     */       
/* 816 */       dataptr = advance(dataptr, 1);
/*     */     } 
/*     */   }
/*     */   
/*     */   private static final int DESCALE(int x, int n) {
/* 821 */     return x + (1 << n - 1) >> n;
/*     */   }
/*     */   
/*     */   private static final short DESCALE11(int x) {
/* 825 */     return (short)(x + 1024 >> 11);
/*     */   }
/*     */   
/*     */   private static final short DESCALE18(int x) {
/* 829 */     return (short)(x + 131072 >> 18);
/*     */   }
/*     */ }


/* Location:              C:\Users\rapha\Downloads\aurora.jar!\META-INF\jars\jcodec-0.2.5.jar!\org\jcodec\common\dct\FfmpegIntDct.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */