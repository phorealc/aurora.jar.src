/*     */ package org.jcodec.common.dct;
/*     */ 
/*     */ import java.nio.IntBuffer;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class IntDCT
/*     */   extends DCT
/*     */ {
/*  12 */   public static final IntDCT INSTANCE = new IntDCT();
/*     */   
/*     */   private static final int DCTSIZE = 8;
/*     */   private static final int PASS1_BITS = 2;
/*     */   private static final int MAXJSAMPLE = 255;
/*     */   private static final int CENTERJSAMPLE = 128;
/*     */   private static final int RANGE_MASK = 1023;
/*     */   
/*     */   public int[] decode(int[] orig) {
/*  21 */     IntBuffer inptr = IntBuffer.wrap(orig);
/*  22 */     IntBuffer workspace = IntBuffer.allocate(64);
/*  23 */     IntBuffer outptr = IntBuffer.allocate(64);
/*  24 */     doDecode(inptr, workspace, outptr);
/*  25 */     return outptr.array();
/*     */   }
/*     */ 
/*     */   
/*     */   protected static IntBuffer doDecode(IntBuffer inptr, IntBuffer workspace, IntBuffer outptr) {
/*  30 */     pass1(inptr, workspace.duplicate());
/*  31 */     pass2(outptr, workspace.duplicate());
/*  32 */     return outptr;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static void pass2(IntBuffer outptr, IntBuffer wsptr) {
/*  42 */     for (int ctr = 0; ctr < 8; ctr++) {
/*     */ 
/*     */ 
/*     */       
/*  46 */       int z2 = wsptr.get(2);
/*  47 */       int z3 = wsptr.get(6);
/*     */       
/*  49 */       int z1 = MULTIPLY(z2 + z3, FIX_0_541196100);
/*  50 */       int tmp2 = z1 + MULTIPLY(z3, -FIX_1_847759065);
/*  51 */       int tmp3 = z1 + MULTIPLY(z2, FIX_0_765366865);
/*     */       
/*  53 */       int tmp0 = wsptr.get(0) + wsptr.get(4) << 13;
/*  54 */       int tmp1 = wsptr.get(0) - wsptr.get(4) << 13;
/*     */       
/*  56 */       int tmp10 = tmp0 + tmp3;
/*  57 */       int tmp13 = tmp0 - tmp3;
/*  58 */       int tmp11 = tmp1 + tmp2;
/*  59 */       int tmp12 = tmp1 - tmp2;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/*  66 */       tmp0 = wsptr.get(7);
/*  67 */       tmp1 = wsptr.get(5);
/*  68 */       tmp2 = wsptr.get(3);
/*  69 */       tmp3 = wsptr.get(1);
/*     */       
/*  71 */       z1 = tmp0 + tmp3;
/*  72 */       z2 = tmp1 + tmp2;
/*  73 */       z3 = tmp0 + tmp2;
/*  74 */       int z4 = tmp1 + tmp3;
/*  75 */       int z5 = MULTIPLY(z3 + z4, FIX_1_175875602);
/*     */       
/*  77 */       tmp0 = MULTIPLY(tmp0, FIX_0_298631336);
/*  78 */       tmp1 = MULTIPLY(tmp1, FIX_2_053119869);
/*  79 */       tmp2 = MULTIPLY(tmp2, FIX_3_072711026);
/*  80 */       tmp3 = MULTIPLY(tmp3, FIX_1_501321110);
/*  81 */       z1 = MULTIPLY(z1, -FIX_0_899976223);
/*  82 */       z2 = MULTIPLY(z2, -FIX_2_562915447);
/*  83 */       z3 = MULTIPLY(z3, -FIX_1_961570560);
/*  84 */       z4 = MULTIPLY(z4, -FIX_0_390180644);
/*     */       
/*  86 */       z3 += z5;
/*  87 */       z4 += z5;
/*     */       
/*  89 */       tmp0 += z1 + z3;
/*  90 */       tmp1 += z2 + z4;
/*  91 */       tmp2 += z2 + z3;
/*  92 */       tmp3 += z1 + z4;
/*     */ 
/*     */ 
/*     */       
/*  96 */       int D = 18;
/*  97 */       outptr.put(range_limit(DESCALE(tmp10 + tmp3, D) & 0x3FF));
/*  98 */       outptr.put(range_limit(DESCALE(tmp11 + tmp2, D) & 0x3FF));
/*  99 */       outptr.put(range_limit(DESCALE(tmp12 + tmp1, D) & 0x3FF));
/* 100 */       outptr.put(range_limit(DESCALE(tmp13 + tmp0, D) & 0x3FF));
/* 101 */       outptr.put(range_limit(DESCALE(tmp13 - tmp0, D) & 0x3FF));
/* 102 */       outptr.put(range_limit(DESCALE(tmp12 - tmp1, D) & 0x3FF));
/* 103 */       outptr.put(range_limit(DESCALE(tmp11 - tmp2, D) & 0x3FF));
/* 104 */       outptr.put(range_limit(DESCALE(tmp10 - tmp3, D) & 0x3FF));
/*     */       
/* 106 */       wsptr = doAdvance(wsptr, 8);
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public static int range_limit(int i) {
/* 112 */     return idct_sample_range_limit.get(i + 256);
/*     */   }
/*     */ 
/*     */   
/* 116 */   private static final IntBuffer sample_range_limit = IntBuffer.allocate(1408);
/*     */   
/* 118 */   private static final IntBuffer idct_sample_range_limit = IntBuffer.allocate(sample_range_limit.capacity() - 128); private static final int CONST_BITS = 13;
/*     */   static {
/* 120 */     prepare_range_limit_table();
/*     */   }
/*     */   private static final int ONE_HALF = 4096;
/*     */   
/*     */   private static void prepare_range_limit_table() {
/* 125 */     sample_range_limit.position(256); int i;
/* 126 */     for (i = 0; i < 128; i++) {
/* 127 */       sample_range_limit.put(i);
/*     */     }
/* 129 */     for (i = -128; i < 0; i++) {
/* 130 */       sample_range_limit.put(i);
/*     */     }
/* 132 */     for (i = 0; i < 384; i++) {
/* 133 */       sample_range_limit.put(-1);
/*     */     }
/* 135 */     for (i = 0; i < 384; i++) {
/* 136 */       sample_range_limit.put(0);
/*     */     }
/* 138 */     for (i = 0; i < 128; i++) {
/* 139 */       sample_range_limit.put(i);
/*     */     }
/*     */     
/* 142 */     for (i = 0; i < idct_sample_range_limit.capacity(); i++) {
/* 143 */       idct_sample_range_limit.put(sample_range_limit.get(i + 128) & 0xFF);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static boolean shortcut(IntBuffer inptr, IntBuffer wsptr) {
/* 159 */     if (inptr.get(8) == 0 && inptr.get(16) == 0 && inptr
/* 160 */       .get(24) == 0 && inptr.get(32) == 0 && inptr
/* 161 */       .get(40) == 0 && inptr.get(48) == 0 && inptr
/* 162 */       .get(56) == 0) {
/*     */       
/* 164 */       int dcval = inptr.get(0) << 2;
/*     */       
/* 166 */       wsptr.put(0, dcval);
/* 167 */       wsptr.put(8, dcval);
/* 168 */       wsptr.put(16, dcval);
/* 169 */       wsptr.put(24, dcval);
/* 170 */       wsptr.put(32, dcval);
/* 171 */       wsptr.put(40, dcval);
/* 172 */       wsptr.put(48, dcval);
/* 173 */       wsptr.put(56, dcval);
/*     */       
/* 175 */       inptr = advance(inptr);
/* 176 */       wsptr = advance(wsptr);
/* 177 */       return true;
/*     */     } 
/* 179 */     return false;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static void pass1(IntBuffer inptr, IntBuffer wsptr) {
/* 190 */     for (int ctr = 8; ctr > 0; ctr--) {
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 196 */       int z2 = inptr.get(16);
/* 197 */       int z3 = inptr.get(48);
/* 198 */       int z1 = MULTIPLY(z2 + z3, FIX_0_541196100);
/* 199 */       int tmp2 = z1 + MULTIPLY(z3, -FIX_1_847759065);
/* 200 */       int tmp3 = z1 + MULTIPLY(z2, FIX_0_765366865);
/* 201 */       z2 = inptr.get(0);
/* 202 */       z3 = inptr.get(32);
/* 203 */       int tmp0 = z2 + z3 << 13;
/* 204 */       int tmp1 = z2 - z3 << 13;
/* 205 */       int tmp10 = tmp0 + tmp3;
/* 206 */       int tmp13 = tmp0 - tmp3;
/* 207 */       int tmp11 = tmp1 + tmp2;
/* 208 */       int tmp12 = tmp1 - tmp2;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 214 */       tmp0 = inptr.get(56);
/* 215 */       tmp1 = inptr.get(40);
/* 216 */       tmp2 = inptr.get(24);
/* 217 */       tmp3 = inptr.get(8);
/* 218 */       z1 = tmp0 + tmp3;
/* 219 */       z2 = tmp1 + tmp2;
/* 220 */       z3 = tmp0 + tmp2;
/* 221 */       int z4 = tmp1 + tmp3;
/* 222 */       int z5 = MULTIPLY(z3 + z4, FIX_1_175875602);
/*     */       
/* 224 */       tmp0 = MULTIPLY(tmp0, FIX_0_298631336);
/* 225 */       tmp1 = MULTIPLY(tmp1, FIX_2_053119869);
/* 226 */       tmp2 = MULTIPLY(tmp2, FIX_3_072711026);
/* 227 */       tmp3 = MULTIPLY(tmp3, FIX_1_501321110);
/* 228 */       z1 = MULTIPLY(z1, -FIX_0_899976223);
/* 229 */       z2 = MULTIPLY(z2, -FIX_2_562915447);
/* 230 */       z3 = MULTIPLY(z3, -FIX_1_961570560);
/* 231 */       z4 = MULTIPLY(z4, -FIX_0_390180644);
/* 232 */       z3 += z5;
/* 233 */       z4 += z5;
/*     */       
/* 235 */       tmp0 += z1 + z3;
/* 236 */       tmp1 += z2 + z4;
/* 237 */       tmp2 += z2 + z3;
/* 238 */       tmp3 += z1 + z4;
/*     */ 
/*     */ 
/*     */       
/* 242 */       int D = 11;
/* 243 */       wsptr.put(0, DESCALE(tmp10 + tmp3, D));
/* 244 */       wsptr.put(56, DESCALE(tmp10 - tmp3, D));
/* 245 */       wsptr.put(8, DESCALE(tmp11 + tmp2, D));
/* 246 */       wsptr.put(48, DESCALE(tmp11 - tmp2, D));
/* 247 */       wsptr.put(16, DESCALE(tmp12 + tmp1, D));
/* 248 */       wsptr.put(40, DESCALE(tmp12 - tmp1, D));
/* 249 */       wsptr.put(24, DESCALE(tmp13 + tmp0, D));
/* 250 */       wsptr.put(32, DESCALE(tmp13 - tmp0, D));
/* 251 */       inptr = advance(inptr);
/* 252 */       wsptr = advance(wsptr);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static IntBuffer advance(IntBuffer ptr) {
/* 260 */     return doAdvance(ptr, 1);
/*     */   }
/*     */   
/*     */   private static IntBuffer doAdvance(IntBuffer ptr, int size) {
/* 264 */     ptr.position(ptr.position() + size);
/* 265 */     return ptr.slice();
/*     */   }
/*     */   
/*     */   static int DESCALE(int x, int n) {
/* 269 */     return RIGHT_SHIFT(x + (1 << n - 1), n);
/*     */   }
/*     */   
/*     */   private static int RIGHT_SHIFT(int x, int shft) {
/* 273 */     return x >> shft;
/*     */   }
/*     */   
/*     */   private static int MULTIPLY(int i, int j) {
/* 277 */     return i * j;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private static int FIX(double x) {
/* 283 */     return (int)(x * 8192.0D + 0.5D);
/*     */   }
/*     */   
/* 286 */   private static final int FIX_0_298631336 = FIX(0.298631336D);
/* 287 */   private static final int FIX_0_390180644 = FIX(0.390180644D);
/* 288 */   private static final int FIX_0_541196100 = FIX(0.5411961D);
/* 289 */   private static final int FIX_0_765366865 = FIX(0.765366865D);
/* 290 */   private static final int FIX_0_899976223 = FIX(0.899976223D);
/* 291 */   private static final int FIX_1_175875602 = FIX(1.175875602D);
/* 292 */   private static final int FIX_1_501321110 = FIX(1.50132111D);
/* 293 */   private static final int FIX_1_847759065 = FIX(1.847759065D);
/* 294 */   private static final int FIX_1_961570560 = FIX(1.96157056D);
/* 295 */   private static final int FIX_2_053119869 = FIX(2.053119869D);
/* 296 */   private static final int FIX_2_562915447 = FIX(2.562915447D);
/* 297 */   private static final int FIX_3_072711026 = FIX(3.072711026D);
/*     */ }


/* Location:              C:\Users\rapha\Downloads\aurora.jar!\META-INF\jars\jcodec-0.2.5.jar!\org\jcodec\common\dct\IntDCT.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */