/*    */ package org.jcodec.common.dct;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class IDCT2x2
/*    */ {
/*    */   public static void idct(int[] blk, int off) {
/* 13 */     int x0 = blk[off], x1 = blk[off + 1], x2 = blk[off + 2], x3 = blk[off + 3];
/*    */     
/* 15 */     int t0 = x0 + x2;
/* 16 */     int t2 = x0 - x2;
/*    */     
/* 18 */     int t1 = x1 + x3;
/* 19 */     int t3 = x1 - x3;
/*    */     
/* 21 */     blk[off] = t0 + t1 >> 3;
/* 22 */     blk[off + 1] = t0 - t1 >> 3;
/* 23 */     blk[off + 2] = t2 + t3 >> 3;
/* 24 */     blk[off + 3] = t2 - t3 >> 3;
/*    */   }
/*    */ }


/* Location:              C:\Users\rapha\Downloads\aurora.jar!\META-INF\jars\jcodec-0.2.5.jar!\org\jcodec\common\dct\IDCT2x2.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */