/*    */ package org.jcodec.common.dct;
/*    */ 
/*    */ import org.jcodec.scale.ImageConvert;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class SlowDCT
/*    */   extends DCT
/*    */ {
/* 17 */   public static final SlowDCT INSTANCE = new SlowDCT();
/*    */   
/* 19 */   private static final double rSqrt2 = 1.0D / Math.sqrt(2.0D);
/*    */   
/*    */   public short[] encode(byte[] orig) {
/* 22 */     short[] result = new short[64];
/* 23 */     for (int u = 0; u < 8; u++) {
/* 24 */       for (int v = 0; v < 8; v++) {
/* 25 */         float sum = 0.0F;
/* 26 */         for (int j = 0; j < 8; j++) {
/* 27 */           for (int k = 0; k < 8; k++)
/*    */           {
/*    */             
/* 30 */             sum = (float)(sum + orig[j * 8 + k] * Math.cos(0.39269908169872414D * (j + 0.5D) * u) * Math.cos(0.39269908169872414D * (k + 0.5D) * v));
/*    */           }
/*    */         } 
/* 33 */         result[u * 8 + v] = (short)(byte)(int)sum;
/*    */       } 
/*    */     } 
/*    */     
/* 37 */     result[0] = (short)(byte)(int)(result[0] / 8.0F);
/* 38 */     double sqrt2 = Math.sqrt(2.0D);
/* 39 */     for (int i = 1; i < 8; i++) {
/* 40 */       result[i] = (short)(byte)(int)(result[0] * sqrt2 / 8.0D);
/* 41 */       result[i * 8] = (short)(byte)(int)(result[0] * sqrt2 / 8.0D);
/*    */       
/* 43 */       for (int j = 1; j < 8; j++) {
/* 44 */         result[i * 8 + j] = (short)(byte)(int)(result[0] / 4.0F);
/*    */       }
/*    */     } 
/*    */     
/* 48 */     return result;
/*    */   }
/*    */   
/*    */   public int[] decode(int[] orig) {
/* 52 */     int[] res = new int[64];
/* 53 */     int i = 0;
/* 54 */     for (int y = 0; y < 8; y++) {
/* 55 */       for (int x = 0; x < 8; x++) {
/* 56 */         double sum = 0.0D;
/* 57 */         int pixOffset = 0;
/* 58 */         for (int u = 0; u < 8; u++) {
/* 59 */           double cu = (u == 0) ? rSqrt2 : 1.0D;
/* 60 */           for (int v = 0; v < 8; v++) {
/* 61 */             double cv = (v == 0) ? rSqrt2 : 1.0D;
/* 62 */             double svu = orig[pixOffset];
/* 63 */             double c1 = ((2 * x + 1) * v) * Math.PI / 16.0D;
/* 64 */             double c2 = ((2 * y + 1) * u) * Math.PI / 16.0D;
/* 65 */             sum += cu * cv * svu * Math.cos(c1) * Math.cos(c2);
/* 66 */             pixOffset++;
/*    */           } 
/*    */         } 
/* 69 */         sum *= 0.25D;
/* 70 */         sum = Math.round(sum + 128.0D);
/* 71 */         int isum = (int)sum;
/* 72 */         res[i++] = ImageConvert.icrop(isum);
/*    */       } 
/*    */     } 
/* 75 */     return res;
/*    */   }
/*    */ }


/* Location:              C:\Users\rapha\Downloads\aurora.jar!\META-INF\jars\jcodec-0.2.5.jar!\org\jcodec\common\dct\SlowDCT.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */