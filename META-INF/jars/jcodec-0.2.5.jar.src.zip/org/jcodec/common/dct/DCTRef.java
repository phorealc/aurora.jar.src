/*    */ package org.jcodec.common.dct;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class DCTRef
/*    */ {
/* 15 */   static double[] coefficients = new double[64];
/*    */   
/*    */   static {
/* 18 */     for (int j = 0; j < 8; j++) {
/* 19 */       coefficients[j] = Math.sqrt(0.125D);
/* 20 */       for (int i = 8; i < 64; i += 8) {
/* 21 */         coefficients[i + j] = 0.5D * Math.cos(i * (j + 0.5D) * Math.PI / 64.0D);
/*    */       }
/*    */     } 
/*    */   }
/*    */ 
/*    */   
/*    */   public static void fdct(int[] block, int off) {
/* 28 */     double[] out = new double[64];
/*    */     int i;
/* 30 */     for (i = 0; i < 64; i += 8) {
/* 31 */       for (int k = 0; k < 8; k++) {
/* 32 */         double tmp = 0.0D;
/* 33 */         for (int m = 0; m < 8; m++) {
/* 34 */           tmp += coefficients[i + m] * block[m * 8 + k + off];
/*    */         }
/* 36 */         out[i + k] = tmp * 4.0D;
/*    */       } 
/*    */     } 
/*    */     
/* 40 */     for (int j = 0; j < 8; j++) {
/* 41 */       for (i = 0; i < 64; i += 8) {
/* 42 */         double tmp = 0.0D;
/* 43 */         for (int k = 0; k < 8; k++) {
/* 44 */           tmp += out[i + k] * coefficients[j * 8 + k];
/*    */         }
/* 46 */         block[i + j + off] = (int)(tmp + 0.499999999999D);
/*    */       } 
/*    */     } 
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public static void idct(int[] block, int off) {
/* 54 */     double[] out = new double[64];
/*    */     
/*    */     int i;
/* 57 */     for (i = 0; i < 64; i += 8) {
/* 58 */       for (int j = 0; j < 8; j++) {
/* 59 */         double tmp = 0.0D;
/* 60 */         for (int k = 0; k < 8; k++) {
/* 61 */           tmp += block[i + k] * coefficients[k * 8 + j];
/*    */         }
/* 63 */         out[i + j] = tmp;
/*    */       } 
/*    */     } 
/*    */ 
/*    */     
/* 68 */     for (i = 0; i < 8; i++) {
/* 69 */       for (int j = 0; j < 8; j++) {
/* 70 */         double tmp = 0.0D;
/* 71 */         for (int k = 0; k < 64; k += 8) {
/* 72 */           tmp += coefficients[k + i] * out[k + j];
/*    */         }
/* 74 */         block[i * 8 + j] = (int)(tmp + 0.5D);
/*    */       } 
/*    */     } 
/*    */   }
/*    */ }


/* Location:              C:\Users\rapha\Downloads\aurora.jar!\META-INF\jars\jcodec-0.2.5.jar!\org\jcodec\common\dct\DCTRef.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */