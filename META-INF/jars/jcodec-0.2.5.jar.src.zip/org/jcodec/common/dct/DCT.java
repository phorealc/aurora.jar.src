/*    */ package org.jcodec.common.dct;
/*    */ 
/*    */ import org.jcodec.api.NotSupportedException;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public abstract class DCT
/*    */ {
/*    */   public short[] encode(byte[] orig) {
/* 13 */     throw new NotSupportedException("");
/*    */   }
/*    */   
/*    */   public abstract int[] decode(int[] paramArrayOfint);
/*    */   
/*    */   public void decodeAll(int[][] src) {
/* 19 */     for (int i = 0; i < src.length; i++)
/* 20 */       src[i] = decode(src[i]); 
/*    */   }
/*    */ }


/* Location:              C:\Users\rapha\Downloads\aurora.jar!\META-INF\jars\jcodec-0.2.5.jar!\org\jcodec\common\dct\DCT.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */