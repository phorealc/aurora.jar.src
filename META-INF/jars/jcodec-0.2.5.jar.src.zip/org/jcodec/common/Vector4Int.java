/*    */ package org.jcodec.common;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class Vector4Int
/*    */ {
/*    */   public static int el8_0(int packed) {
/* 14 */     return packed << 24 >> 24;
/*    */   }
/*    */   
/*    */   public static int el8_1(int packed) {
/* 18 */     return packed << 16 >> 24;
/*    */   }
/*    */   
/*    */   public static int el8_2(int packed) {
/* 22 */     return packed << 8 >> 24;
/*    */   }
/*    */   
/*    */   public static int el8_3(int packed) {
/* 26 */     return packed >> 24;
/*    */   }
/*    */   
/*    */   public static int el8(int packed, int n) {
/* 30 */     switch (n) {
/*    */       case 0:
/* 32 */         return el8_0(packed);
/*    */       case 1:
/* 34 */         return el8_1(packed);
/*    */       case 2:
/* 36 */         return el8_2(packed);
/*    */     } 
/* 38 */     return el8_3(packed);
/*    */   }
/*    */ 
/*    */   
/*    */   public static int set8_0(int packed, int el) {
/* 43 */     return packed & 0xFFFFFF00 | el & 0xFF;
/*    */   }
/*    */   
/*    */   public static int set8_1(int packed, int el) {
/* 47 */     return packed & 0xFFFF00FF | (el & 0xFF) << 8;
/*    */   }
/*    */   
/*    */   public static int set8_2(int packed, int el) {
/* 51 */     return packed & 0xFF00FFFF | (el & 0xFF) << 16;
/*    */   }
/*    */   
/*    */   public static int set8_3(int packed, int el) {
/* 55 */     return packed & 0xFF00FFFF | (el & 0xFF) << 24;
/*    */   }
/*    */   
/*    */   public static int set8(int packed, int el, int n) {
/* 59 */     switch (n) {
/*    */       case 0:
/* 61 */         return set8_0(packed, el);
/*    */       case 1:
/* 63 */         return set8_1(packed, el);
/*    */       case 2:
/* 65 */         return set8_2(packed, el);
/*    */     } 
/* 67 */     return set8_3(packed, el);
/*    */   }
/*    */ 
/*    */   
/*    */   public static int pack8(int el0, int el1, int el2, int el3) {
/* 72 */     return (el3 & 0xFF) << 24 | (el2 & 0xFF) << 16 | (el1 & 0xFF) << 8 | el0 & 0xFF;
/*    */   }
/*    */ }


/* Location:              C:\Users\rapha\Downloads\aurora.jar!\META-INF\jars\jcodec-0.2.5.jar!\org\jcodec\common\Vector4Int.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */