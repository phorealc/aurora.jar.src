/*     */ package org.jcodec.common;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class AudioFormat
/*     */ {
/*     */   private int sampleRate;
/*     */   private int sampleSizeInBits;
/*     */   private int channelCount;
/*     */   private boolean signed;
/*     */   private boolean bigEndian;
/*  19 */   public static AudioFormat STEREO_48K_S16_BE = new AudioFormat(48000, 16, 2, true, true);
/*  20 */   public static AudioFormat STEREO_48K_S16_LE = new AudioFormat(48000, 16, 2, true, false);
/*     */   
/*  22 */   public static AudioFormat STEREO_48K_S24_BE = new AudioFormat(48000, 24, 2, true, true);
/*  23 */   public static AudioFormat STEREO_48K_S24_LE = new AudioFormat(48000, 24, 2, true, false);
/*     */   
/*  25 */   public static AudioFormat MONO_48K_S16_BE = new AudioFormat(48000, 16, 1, true, true);
/*  26 */   public static AudioFormat MONO_48K_S16_LE = new AudioFormat(48000, 16, 1, true, false);
/*     */   
/*  28 */   public static AudioFormat MONO_48K_S24_BE = new AudioFormat(48000, 24, 1, true, true);
/*  29 */   public static AudioFormat MONO_48K_S24_LE = new AudioFormat(48000, 24, 1, true, false);
/*     */   
/*  31 */   public static AudioFormat STEREO_44K_S16_BE = new AudioFormat(44100, 16, 2, true, true);
/*  32 */   public static AudioFormat STEREO_44K_S16_LE = new AudioFormat(44100, 16, 2, true, false);
/*     */   
/*  34 */   public static AudioFormat STEREO_44K_S24_BE = new AudioFormat(44100, 24, 2, true, true);
/*  35 */   public static AudioFormat STEREO_44K_S24_LE = new AudioFormat(44100, 24, 2, true, false);
/*     */   
/*  37 */   public static AudioFormat MONO_44K_S16_BE = new AudioFormat(44100, 16, 1, true, true);
/*  38 */   public static AudioFormat MONO_44K_S16_LE = new AudioFormat(44100, 16, 1, true, false);
/*     */   
/*  40 */   public static AudioFormat MONO_44K_S24_BE = new AudioFormat(44100, 24, 1, true, true);
/*  41 */   public static AudioFormat MONO_44K_S24_LE = new AudioFormat(44100, 24, 1, true, false);
/*     */   
/*     */   public static AudioFormat STEREO_S16_BE(int rate) {
/*  44 */     return new AudioFormat(rate, 16, 2, true, true);
/*     */   }
/*     */   
/*     */   public static AudioFormat STEREO_S16_LE(int rate) {
/*  48 */     return new AudioFormat(rate, 16, 2, true, false);
/*     */   }
/*     */   
/*     */   public static AudioFormat STEREO_S24_BE(int rate) {
/*  52 */     return new AudioFormat(rate, 24, 2, true, true);
/*     */   }
/*     */   
/*     */   public static AudioFormat STEREO_S24_LE(int rate) {
/*  56 */     return new AudioFormat(rate, 24, 2, true, false);
/*     */   }
/*     */   
/*     */   public static AudioFormat MONO_S16_BE(int rate) {
/*  60 */     return new AudioFormat(rate, 16, 1, true, true);
/*     */   }
/*     */   
/*     */   public static AudioFormat MONO_S16_LE(int rate) {
/*  64 */     return new AudioFormat(rate, 16, 1, true, false);
/*     */   }
/*     */   
/*     */   public static AudioFormat MONO_S24_BE(int rate) {
/*  68 */     return new AudioFormat(rate, 24, 1, true, true);
/*     */   }
/*     */   
/*     */   public static AudioFormat MONO_S24_LE(int rate) {
/*  72 */     return new AudioFormat(rate, 24, 1, true, false);
/*     */   }
/*     */   
/*     */   public static AudioFormat NCH_48K_S16_BE(int n) {
/*  76 */     return new AudioFormat(48000, 16, n, true, true);
/*     */   }
/*     */   
/*     */   public static AudioFormat NCH_48K_S16_LE(int n) {
/*  80 */     return new AudioFormat(48000, 16, n, true, false);
/*     */   }
/*     */   
/*     */   public static AudioFormat NCH_48K_S24_BE(int n) {
/*  84 */     return new AudioFormat(48000, 24, n, true, true);
/*     */   }
/*     */   
/*     */   public static AudioFormat NCH_48K_S24_LE(int n) {
/*  88 */     return new AudioFormat(48000, 24, n, true, false);
/*     */   }
/*     */   
/*     */   public static AudioFormat NCH_44K_S16_BE(int n) {
/*  92 */     return new AudioFormat(44100, 16, n, true, true);
/*     */   }
/*     */   
/*     */   public static AudioFormat NCH_44K_S16_LE(int n) {
/*  96 */     return new AudioFormat(44100, 16, n, true, false);
/*     */   }
/*     */   
/*     */   public static AudioFormat NCH_44K_S24_BE(int n) {
/* 100 */     return new AudioFormat(44100, 24, n, true, true);
/*     */   }
/*     */   
/*     */   public static AudioFormat NCH_44K_S24_LE(int n) {
/* 104 */     return new AudioFormat(44100, 24, n, true, false);
/*     */   }
/*     */   
/*     */   public static AudioFormat createAudioFormat(AudioFormat format) {
/* 108 */     return new AudioFormat(format.sampleRate, format.sampleSizeInBits, format.channelCount, format.signed, format.bigEndian);
/*     */   }
/*     */   
/*     */   public static AudioFormat createAudioFormat2(AudioFormat format, int newSampleRate) {
/* 112 */     AudioFormat af = new AudioFormat(format.sampleRate, format.sampleSizeInBits, format.channelCount, format.signed, format.bigEndian);
/* 113 */     af.sampleRate = newSampleRate;
/* 114 */     return af;
/*     */   }
/*     */   
/*     */   public AudioFormat(int sampleRate, int sampleSizeInBits, int channelCount, boolean signed, boolean bigEndian) {
/* 118 */     this.sampleRate = sampleRate;
/* 119 */     this.sampleSizeInBits = sampleSizeInBits;
/* 120 */     this.channelCount = channelCount;
/* 121 */     this.signed = signed;
/* 122 */     this.bigEndian = bigEndian;
/*     */   }
/*     */   
/*     */   public int getChannels() {
/* 126 */     return this.channelCount;
/*     */   }
/*     */   
/*     */   public int getSampleSizeInBits() {
/* 130 */     return this.sampleSizeInBits;
/*     */   }
/*     */   
/*     */   public int getSampleRate() {
/* 134 */     return this.sampleRate;
/*     */   }
/*     */   
/*     */   public short getFrameSize() {
/* 138 */     return (short)((this.sampleSizeInBits >> 3) * this.channelCount);
/*     */   }
/*     */   
/*     */   public int getFrameRate() {
/* 142 */     return this.sampleRate;
/*     */   }
/*     */   
/*     */   public boolean isBigEndian() {
/* 146 */     return this.bigEndian;
/*     */   }
/*     */   
/*     */   public boolean isSigned() {
/* 150 */     return this.signed;
/*     */   }
/*     */   
/*     */   public int bytesToFrames(int bytes) {
/* 154 */     return bytes / (this.channelCount * this.sampleSizeInBits >> 3);
/*     */   }
/*     */   
/*     */   public int framesToBytes(int samples) {
/* 158 */     return samples * (this.channelCount * this.sampleSizeInBits >> 3);
/*     */   }
/*     */   
/*     */   public int bytesToSamples(int bytes) {
/* 162 */     return bytes / (this.sampleSizeInBits >> 3);
/*     */   }
/*     */   
/*     */   public int samplesToBytes(int samples) {
/* 166 */     return samples * (this.sampleSizeInBits >> 3);
/*     */   }
/*     */ }


/* Location:              C:\Users\rapha\Downloads\aurora.jar!\META-INF\jars\jcodec-0.2.5.jar!\org\jcodec\common\AudioFormat.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */