package org.jcodec.common;

import java.io.IOException;

public interface Muxer {
  MuxerTrack addVideoTrack(Codec paramCodec, VideoCodecMeta paramVideoCodecMeta);
  
  MuxerTrack addAudioTrack(Codec paramCodec, AudioCodecMeta paramAudioCodecMeta);
  
  void finish() throws IOException;
}


/* Location:              C:\Users\rapha\Downloads\aurora.jar!\META-INF\jars\jcodec-0.2.5.jar!\org\jcodec\common\Muxer.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */