package org.jcodec.common;

public interface SaveRestore {
  void save();
  
  void restore();
}


/* Location:              C:\Users\rapha\Downloads\aurora.jar!\META-INF\jars\jcodec-0.2.5.jar!\org\jcodec\common\SaveRestore.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */