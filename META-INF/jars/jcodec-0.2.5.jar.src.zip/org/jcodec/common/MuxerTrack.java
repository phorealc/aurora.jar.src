package org.jcodec.common;

import java.io.IOException;
import org.jcodec.common.model.Packet;

public interface MuxerTrack {
  void addFrame(Packet paramPacket) throws IOException;
}


/* Location:              C:\Users\rapha\Downloads\aurora.jar!\META-INF\jars\jcodec-0.2.5.jar!\org\jcodec\common\MuxerTrack.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */