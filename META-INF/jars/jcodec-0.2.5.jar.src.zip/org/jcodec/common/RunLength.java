/*     */ package org.jcodec.common;
/*     */ 
/*     */ import java.nio.ByteBuffer;
/*     */ import org.jcodec.common.io.NIOUtils;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class RunLength
/*     */ {
/*  17 */   protected IntArrayList counts = IntArrayList.createIntArrayList();
/*     */ 
/*     */   
/*     */   public int estimateSize() {
/*  21 */     int[] counts = getCounts();
/*  22 */     int recCount = 0;
/*  23 */     for (int i = 0; i < counts.length; i++, recCount++) {
/*  24 */       int count = counts[i];
/*  25 */       while (count >= 256) {
/*  26 */         recCount++;
/*  27 */         count -= 256;
/*     */       } 
/*     */     } 
/*  30 */     return recCount * recSize() + 4;
/*     */   }
/*     */ 
/*     */   
/*     */   protected abstract int recSize();
/*     */   
/*     */   protected abstract void finish();
/*     */   
/*     */   public int[] getCounts() {
/*  39 */     finish();
/*  40 */     return this.counts.toArray();
/*     */   }
/*     */   
/*     */   public static class Integer
/*     */     extends RunLength {
/*     */     private static final int MIN_VALUE = -2147483648;
/*     */     private int lastValue;
/*  47 */     private int count = 0;
/*     */     
/*     */     private IntArrayList values;
/*     */ 
/*     */     
/*     */     public Integer() {
/*  53 */       this.lastValue = Integer.MIN_VALUE;
/*  54 */       this.values = IntArrayList.createIntArrayList();
/*     */     }
/*     */     
/*     */     public void add(int value) {
/*  58 */       if (this.lastValue == Integer.MIN_VALUE || this.lastValue != value) {
/*  59 */         if (this.lastValue != Integer.MIN_VALUE) {
/*  60 */           this.values.add(this.lastValue);
/*  61 */           this.counts.add(this.count);
/*  62 */           this.count = 0;
/*     */         } 
/*  64 */         this.lastValue = value;
/*     */       } 
/*  66 */       this.count++;
/*     */     }
/*     */     
/*     */     public int[] getValues() {
/*  70 */       finish();
/*  71 */       return this.values.toArray();
/*     */     }
/*     */     
/*     */     protected void finish() {
/*  75 */       if (this.lastValue != Integer.MIN_VALUE) {
/*  76 */         this.values.add(this.lastValue);
/*  77 */         this.counts.add(this.count);
/*  78 */         this.lastValue = Integer.MIN_VALUE;
/*  79 */         this.count = 0;
/*     */       } 
/*     */     }
/*     */     
/*     */     public void serialize(ByteBuffer bb) {
/*  84 */       ByteBuffer dup = bb.duplicate();
/*  85 */       int[] counts = getCounts();
/*  86 */       int[] values = getValues();
/*  87 */       NIOUtils.skip(bb, 4);
/*  88 */       int recCount = 0;
/*  89 */       for (int i = 0; i < counts.length; i++, recCount++) {
/*  90 */         int count = counts[i];
/*  91 */         while (count >= 256) {
/*  92 */           bb.put((byte)-1);
/*  93 */           bb.putInt(values[i]);
/*  94 */           recCount++;
/*  95 */           count -= 256;
/*     */         } 
/*  97 */         bb.put((byte)(count - 1));
/*  98 */         bb.putInt(values[i]);
/*     */       } 
/* 100 */       dup.putInt(recCount);
/*     */     }
/*     */     
/*     */     public static Integer parse(ByteBuffer bb) {
/* 104 */       Integer rl = new Integer();
/* 105 */       int recCount = bb.getInt();
/* 106 */       for (int i = 0; i < recCount; i++) {
/* 107 */         int count = (bb.get() & 0xFF) + 1;
/* 108 */         int value = bb.getInt();
/* 109 */         rl.counts.add(count);
/* 110 */         rl.values.add(value);
/*     */       } 
/* 112 */       return rl;
/*     */     }
/*     */     
/*     */     protected int recSize() {
/* 116 */       return 5;
/*     */     }
/*     */     
/*     */     public int[] flattern() {
/* 120 */       int[] counts = getCounts();
/* 121 */       int total = 0;
/* 122 */       for (int i = 0; i < counts.length; i++) {
/* 123 */         total += counts[i];
/*     */       }
/* 125 */       int[] values = getValues();
/* 126 */       int[] result = new int[total];
/* 127 */       for (int j = 0, ind = 0; j < counts.length; j++) {
/* 128 */         for (int k = 0; k < counts[j]; k++, ind++)
/* 129 */           result[ind] = values[j]; 
/*     */       } 
/* 131 */       return result;
/*     */     }
/*     */   }
/*     */   
/*     */   public static class Long
/*     */     extends RunLength {
/*     */     private static final long MIN_VALUE = -9223372036854775808L;
/*     */     private long lastValue;
/* 139 */     private int count = 0;
/*     */     
/*     */     private LongArrayList values;
/*     */ 
/*     */     
/*     */     public Long() {
/* 145 */       this.lastValue = Long.MIN_VALUE;
/* 146 */       this.values = LongArrayList.createLongArrayList();
/*     */     }
/*     */     
/*     */     public void add(long value) {
/* 150 */       if (this.lastValue == Long.MIN_VALUE || this.lastValue != value) {
/* 151 */         if (this.lastValue != Long.MIN_VALUE) {
/* 152 */           this.values.add(this.lastValue);
/* 153 */           this.counts.add(this.count);
/* 154 */           this.count = 0;
/*     */         } 
/* 156 */         this.lastValue = value;
/*     */       } 
/* 158 */       this.count++;
/*     */     }
/*     */     
/*     */     public int[] getCounts() {
/* 162 */       finish();
/* 163 */       return this.counts.toArray();
/*     */     }
/*     */     
/*     */     public long[] getValues() {
/* 167 */       finish();
/* 168 */       return this.values.toArray();
/*     */     }
/*     */     
/*     */     protected void finish() {
/* 172 */       if (this.lastValue != Long.MIN_VALUE) {
/* 173 */         this.values.add(this.lastValue);
/* 174 */         this.counts.add(this.count);
/* 175 */         this.lastValue = Long.MIN_VALUE;
/* 176 */         this.count = 0;
/*     */       } 
/*     */     }
/*     */     
/*     */     public void serialize(ByteBuffer bb) {
/* 181 */       ByteBuffer dup = bb.duplicate();
/* 182 */       int[] counts = getCounts();
/* 183 */       long[] values = getValues();
/* 184 */       NIOUtils.skip(bb, 4);
/* 185 */       int recCount = 0;
/* 186 */       for (int i = 0; i < counts.length; i++, recCount++) {
/* 187 */         int count = counts[i];
/* 188 */         while (count >= 256) {
/* 189 */           bb.put((byte)-1);
/* 190 */           bb.putLong(values[i]);
/* 191 */           recCount++;
/* 192 */           count -= 256;
/*     */         } 
/* 194 */         bb.put((byte)(count - 1));
/* 195 */         bb.putLong(values[i]);
/*     */       } 
/* 197 */       dup.putInt(recCount);
/*     */     }
/*     */     
/*     */     public static Long parse(ByteBuffer bb) {
/* 201 */       Long rl = new Long();
/* 202 */       int recCount = bb.getInt();
/* 203 */       for (int i = 0; i < recCount; i++) {
/* 204 */         int count = (bb.get() & 0xFF) + 1;
/* 205 */         long value = bb.getLong();
/* 206 */         rl.counts.add(count);
/* 207 */         rl.values.add(value);
/*     */       } 
/* 209 */       return rl;
/*     */     }
/*     */ 
/*     */     
/*     */     protected int recSize() {
/* 214 */       return 9;
/*     */     }
/*     */     
/*     */     public long[] flattern() {
/* 218 */       int[] counts = getCounts();
/* 219 */       int total = 0;
/* 220 */       for (int i = 0; i < counts.length; i++) {
/* 221 */         total += counts[i];
/*     */       }
/* 223 */       long[] values = getValues();
/* 224 */       long[] result = new long[total];
/* 225 */       for (int j = 0, ind = 0; j < counts.length; j++) {
/* 226 */         for (int k = 0; k < counts[j]; k++, ind++)
/* 227 */           result[ind] = values[j]; 
/*     */       } 
/* 229 */       return result;
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\rapha\Downloads\aurora.jar!\META-INF\jars\jcodec-0.2.5.jar!\org\jcodec\common\RunLength.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */