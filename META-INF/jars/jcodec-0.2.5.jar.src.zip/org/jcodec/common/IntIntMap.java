/*    */ package org.jcodec.common;
/*    */ 
/*    */ import java.util.Arrays;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class IntIntMap
/*    */ {
/*    */   private static final int GROW_BY = 128;
/*    */   private static final int MIN_VALUE = -2147483648;
/*    */   private int[] storage;
/*    */   private int _size;
/*    */   
/*    */   public IntIntMap() {
/* 22 */     this.storage = createArray(128);
/* 23 */     Arrays.fill(this.storage, -2147483648);
/*    */   }
/*    */   
/*    */   public void put(int key, int val) {
/* 27 */     if (val == Integer.MIN_VALUE) {
/* 28 */       throw new IllegalArgumentException("This implementation can not store -2147483648");
/*    */     }
/* 30 */     if (this.storage.length <= key) {
/* 31 */       int[] ns = createArray(key + 128);
/* 32 */       System.arraycopy(this.storage, 0, ns, 0, this.storage.length);
/* 33 */       Arrays.fill(ns, this.storage.length, ns.length, -2147483648);
/* 34 */       this.storage = ns;
/*    */     } 
/* 36 */     if (this.storage[key] == Integer.MIN_VALUE)
/* 37 */       this._size++; 
/* 38 */     this.storage[key] = val;
/*    */   }
/*    */   
/*    */   public int get(int key) {
/* 42 */     return (key >= this.storage.length) ? Integer.MIN_VALUE : this.storage[key];
/*    */   }
/*    */   
/*    */   public boolean contains(int key) {
/* 46 */     return (key >= 0 && key < this.storage.length);
/*    */   }
/*    */   
/*    */   public int[] keys() {
/* 50 */     int[] result = new int[this._size];
/* 51 */     for (int i = 0, r = 0; i < this.storage.length; i++) {
/* 52 */       if (this.storage[i] != Integer.MIN_VALUE)
/* 53 */         result[r++] = i; 
/*    */     } 
/* 55 */     return result;
/*    */   }
/*    */   
/*    */   public void clear() {
/* 59 */     for (int i = 0; i < this.storage.length; i++)
/* 60 */       this.storage[i] = Integer.MIN_VALUE; 
/* 61 */     this._size = 0;
/*    */   }
/*    */   
/*    */   public int size() {
/* 65 */     return this._size;
/*    */   }
/*    */   
/*    */   public void remove(int key) {
/* 69 */     if (this.storage[key] != Integer.MIN_VALUE)
/* 70 */       this._size--; 
/* 71 */     this.storage[key] = Integer.MIN_VALUE;
/*    */   }
/*    */   
/*    */   public int[] values() {
/* 75 */     int[] result = createArray(this._size);
/* 76 */     for (int i = 0, r = 0; i < this.storage.length; i++) {
/* 77 */       if (this.storage[i] != Integer.MIN_VALUE)
/* 78 */         result[r++] = this.storage[i]; 
/*    */     } 
/* 80 */     return result;
/*    */   }
/*    */   
/*    */   private static int[] createArray(int size) {
/* 84 */     return new int[size];
/*    */   }
/*    */ }


/* Location:              C:\Users\rapha\Downloads\aurora.jar!\META-INF\jars\jcodec-0.2.5.jar!\org\jcodec\common\IntIntMap.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */