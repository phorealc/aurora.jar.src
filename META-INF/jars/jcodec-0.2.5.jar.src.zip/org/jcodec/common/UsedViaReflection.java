package org.jcodec.common;

public @interface UsedViaReflection {}


/* Location:              C:\Users\rapha\Downloads\aurora.jar!\META-INF\jars\jcodec-0.2.5.jar!\org\jcodec\common\UsedViaReflection.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */