/*    */ package org.jcodec.common;
/*    */ 
/*    */ import java.nio.ByteBuffer;
/*    */ import org.jcodec.common.model.Picture;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public abstract class VideoDecoder
/*    */ {
/*    */   private byte[][] byteBuffer;
/*    */   
/*    */   public abstract Picture decodeFrame(ByteBuffer paramByteBuffer, byte[][] paramArrayOfbyte);
/*    */   
/*    */   public abstract VideoCodecMeta getCodecMeta(ByteBuffer paramByteBuffer);
/*    */   
/*    */   protected byte[][] getSameSizeBuffer(int[][] buffer) {
/* 31 */     if (this.byteBuffer == null || this.byteBuffer.length != buffer.length || (this.byteBuffer[0]).length != (buffer[0]).length)
/* 32 */       this.byteBuffer = ArrayUtil.create2D((buffer[0]).length, buffer.length); 
/* 33 */     return this.byteBuffer;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public VideoDecoder downscaled(int ratio) {
/* 42 */     if (ratio == 1)
/* 43 */       return this; 
/* 44 */     return null;
/*    */   }
/*    */ }


/* Location:              C:\Users\rapha\Downloads\aurora.jar!\META-INF\jars\jcodec-0.2.5.jar!\org\jcodec\common\VideoDecoder.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */