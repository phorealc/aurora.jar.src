/*     */ package org.jcodec.common;
/*     */ 
/*     */ import java.nio.ByteBuffer;
/*     */ import java.util.Arrays;
/*     */ import org.jcodec.common.io.BitWriter;
/*     */ import org.jcodec.common.io.VLC;
/*     */ import org.jcodec.common.tools.MathUtil;
/*     */ import org.jcodec.platform.Platform;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class DictionaryCompressor
/*     */ {
/*     */   protected VLC buildCodes(int[] counts, int esc) {
/*  22 */     int[] codes = new int[counts.length];
/*  23 */     int[] codeSizes = new int[counts.length];
/*  24 */     int code = 0;
/*  25 */     for (; code < Math.min(codes.length, esc); code++) {
/*  26 */       int max = 0;
/*  27 */       for (int j = 0; j < counts.length; j++) {
/*  28 */         if (counts[j] > counts[max]) {
/*  29 */           max = j;
/*     */         }
/*     */       } 
/*  32 */       codes[max] = code;
/*  33 */       codeSizes[max] = Math.max(1, MathUtil.log2(code));
/*  34 */       counts[max] = Integer.MIN_VALUE;
/*     */     } 
/*  36 */     int escSize = MathUtil.log2(esc);
/*  37 */     for (int i = 0; i < counts.length; i++) {
/*  38 */       if (counts[i] >= 0) {
/*  39 */         codes[i] = esc;
/*  40 */         codeSizes[i] = escSize;
/*     */       } 
/*     */     } 
/*  43 */     return new VLC(codes, codeSizes);
/*     */   }
/*     */   
/*     */   public static class Long extends DictionaryCompressor {
/*     */     public void compress(long[] values, ByteBuffer bb) {
/*  48 */       RunLength.Long rl = getValueStats(values);
/*  49 */       int[] counts = rl.getCounts();
/*  50 */       long[] keys = rl.getValues();
/*  51 */       VLC vlc = buildCodes(counts, values.length / 10);
/*  52 */       int[] codes = vlc.getCodes();
/*  53 */       int[] codeSizes = vlc.getCodeSizes();
/*  54 */       bb.putInt(codes.length);
/*  55 */       for (int i = 0; i < codes.length; i++) {
/*  56 */         bb.put((byte)codeSizes[i]);
/*  57 */         bb.putShort((short)(codes[i] >>> 16));
/*  58 */         bb.putLong(keys[i]);
/*     */       } 
/*     */       
/*  61 */       BitWriter br = new BitWriter(bb);
/*  62 */       for (int j = 0; j < values.length; j++) {
/*  63 */         long l = values[j];
/*  64 */         for (int k = 0; k < keys.length; k++) {
/*  65 */           if (keys[k] == l) {
/*  66 */             vlc.writeVLC(br, k);
/*  67 */             if (codes[k] == 15)
/*  68 */               br.writeNBit(16, k); 
/*     */           } 
/*     */         } 
/*  71 */       }  br.flush();
/*     */     }
/*     */     
/*     */     private RunLength.Long getValueStats(long[] values) {
/*  75 */       long[] copy = Platform.copyOfLong(values, values.length);
/*  76 */       Arrays.sort(copy);
/*  77 */       RunLength.Long rl = new RunLength.Long();
/*  78 */       for (int i = 0; i < copy.length; i++) {
/*  79 */         long l = copy[i];
/*  80 */         rl.add(l);
/*     */       } 
/*  82 */       return rl;
/*     */     }
/*     */   }
/*     */   
/*     */   public static class Int extends DictionaryCompressor {
/*     */     public void compress(int[] values, ByteBuffer bb) {
/*  88 */       RunLength.Integer rl = getValueStats(values);
/*  89 */       int[] counts = rl.getCounts();
/*  90 */       int[] keys = rl.getValues();
/*  91 */       int esc = Math.max(1, (1 << MathUtil.log2(counts.length) - 2) - 1);
/*  92 */       VLC vlc = buildCodes(counts, esc);
/*  93 */       int[] codes = vlc.getCodes();
/*  94 */       int[] codeSizes = vlc.getCodeSizes();
/*  95 */       bb.putInt(codes.length);
/*  96 */       for (int i = 0; i < codes.length; i++) {
/*  97 */         bb.put((byte)codeSizes[i]);
/*  98 */         bb.putShort((short)(codes[i] >>> 16));
/*  99 */         bb.putInt(keys[i]);
/*     */       } 
/*     */       
/* 102 */       BitWriter br = new BitWriter(bb);
/* 103 */       for (int j = 0; j < values.length; j++) {
/* 104 */         int l = values[j];
/* 105 */         for (int k = 0; k < keys.length; k++) {
/* 106 */           if (keys[k] == l) {
/* 107 */             vlc.writeVLC(br, k);
/* 108 */             if (codes[k] == esc)
/* 109 */               br.writeNBit(k, 16); 
/*     */           } 
/*     */         } 
/* 112 */       }  br.flush();
/*     */     }
/*     */     
/*     */     private RunLength.Integer getValueStats(int[] values) {
/* 116 */       int[] copy = Platform.copyOfInt(values, values.length);
/* 117 */       Arrays.sort(copy);
/* 118 */       RunLength.Integer rl = new RunLength.Integer();
/* 119 */       for (int i = 0; i < copy.length; i++) {
/* 120 */         int l = copy[i];
/* 121 */         rl.add(l);
/*     */       } 
/* 123 */       return rl;
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\rapha\Downloads\aurora.jar!\META-INF\jars\jcodec-0.2.5.jar!\org\jcodec\common\DictionaryCompressor.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */