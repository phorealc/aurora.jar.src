/*     */ package org.jcodec.common;
/*     */ 
/*     */ import java.nio.ByteBuffer;
/*     */ import java.nio.ByteOrder;
/*     */ import org.jcodec.common.model.Label;
/*     */ 
/*     */ public class AudioCodecMeta extends CodecMeta {
/*     */   private int sampleSize;
/*     */   private int channelCount;
/*     */   private int sampleRate;
/*     */   private ByteOrder endian;
/*     */   private int samplesPerPacket;
/*     */   private int bytesPerPacket;
/*     */   private int bytesPerFrame;
/*     */   private boolean pcm;
/*     */   private Label[] labels;
/*     */   
/*     */   public static AudioCodecMeta createAudioCodecMeta(String fourcc, int sampleSize, int channelCount, int sampleRate, ByteOrder endian, boolean pcm, Label[] labels, ByteBuffer codecPrivate) {
/*  19 */     AudioCodecMeta self = new AudioCodecMeta(fourcc, codecPrivate);
/*  20 */     self.sampleSize = sampleSize;
/*  21 */     self.channelCount = channelCount;
/*  22 */     self.sampleRate = sampleRate;
/*  23 */     self.endian = endian;
/*  24 */     self.pcm = pcm;
/*  25 */     self.labels = labels;
/*  26 */     return self;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public static AudioCodecMeta createAudioCodecMeta2(String fourcc, int sampleSize, int channelCount, int sampleRate, ByteOrder endian, boolean pcm, Label[] labels, int samplesPerPacket, int bytesPerPacket, int bytesPerFrame, ByteBuffer codecPrivate) {
/*  32 */     AudioCodecMeta self = new AudioCodecMeta(fourcc, codecPrivate);
/*  33 */     self.sampleSize = sampleSize;
/*  34 */     self.channelCount = channelCount;
/*  35 */     self.sampleRate = sampleRate;
/*  36 */     self.endian = endian;
/*  37 */     self.samplesPerPacket = samplesPerPacket;
/*  38 */     self.bytesPerPacket = bytesPerPacket;
/*  39 */     self.bytesPerFrame = bytesPerFrame;
/*  40 */     self.pcm = pcm;
/*  41 */     self.labels = labels;
/*  42 */     return self;
/*     */   }
/*     */ 
/*     */   
/*     */   public static AudioCodecMeta createAudioCodecMeta3(String fourcc, ByteBuffer codecPrivate, AudioFormat format, boolean pcm, Label[] labels) {
/*  47 */     AudioCodecMeta self = new AudioCodecMeta(fourcc, codecPrivate);
/*  48 */     self.sampleSize = format.getSampleSizeInBits() >> 3;
/*  49 */     self.channelCount = format.getChannels();
/*  50 */     self.sampleRate = format.getSampleRate();
/*  51 */     self.endian = format.isBigEndian() ? ByteOrder.BIG_ENDIAN : ByteOrder.LITTLE_ENDIAN;
/*  52 */     self.pcm = pcm;
/*  53 */     self.labels = labels;
/*  54 */     return self;
/*     */   }
/*     */   
/*     */   public AudioCodecMeta(String fourcc, ByteBuffer codecPrivate) {
/*  58 */     super(fourcc, codecPrivate);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int getFrameSize() {
/*  72 */     return this.sampleSize * this.channelCount;
/*     */   }
/*     */   
/*     */   public int getSampleRate() {
/*  76 */     return this.sampleRate;
/*     */   }
/*     */   
/*     */   public int getSampleSize() {
/*  80 */     return this.sampleSize;
/*     */   }
/*     */   
/*     */   public int getChannelCount() {
/*  84 */     return this.channelCount;
/*     */   }
/*     */   
/*     */   public int getSamplesPerPacket() {
/*  88 */     return this.samplesPerPacket;
/*     */   }
/*     */   
/*     */   public int getBytesPerPacket() {
/*  92 */     return this.bytesPerPacket;
/*     */   }
/*     */   
/*     */   public int getBytesPerFrame() {
/*  96 */     return this.bytesPerFrame;
/*     */   }
/*     */   
/*     */   public ByteOrder getEndian() {
/* 100 */     return this.endian;
/*     */   }
/*     */   
/*     */   public boolean isPCM() {
/* 104 */     return this.pcm;
/*     */   }
/*     */   
/*     */   public AudioFormat getFormat() {
/* 108 */     return new AudioFormat(this.sampleRate, this.sampleSize << 3, this.channelCount, true, (this.endian == ByteOrder.BIG_ENDIAN));
/*     */   }
/*     */   
/*     */   public Label[] getChannelLabels() {
/* 112 */     return this.labels;
/*     */   }
/*     */   
/*     */   public static AudioCodecMeta fromAudioFormat(AudioFormat format) {
/* 116 */     AudioCodecMeta self = new AudioCodecMeta(null, null);
/* 117 */     self.sampleSize = format.getSampleSizeInBits() >> 3;
/* 118 */     self.channelCount = format.getChannels();
/* 119 */     self.sampleRate = format.getSampleRate();
/* 120 */     self.endian = format.isBigEndian() ? ByteOrder.BIG_ENDIAN : ByteOrder.LITTLE_ENDIAN;
/* 121 */     self.pcm = false;
/* 122 */     return self;
/*     */   }
/*     */ }


/* Location:              C:\Users\rapha\Downloads\aurora.jar!\META-INF\jars\jcodec-0.2.5.jar!\org\jcodec\common\AudioCodecMeta.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */