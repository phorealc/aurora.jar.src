package org.jcodec.common;

import java.io.Closeable;
import java.util.List;

public interface Demuxer extends Closeable {
  List<? extends DemuxerTrack> getTracks();
  
  List<? extends DemuxerTrack> getVideoTracks();
  
  List<? extends DemuxerTrack> getAudioTracks();
}


/* Location:              C:\Users\rapha\Downloads\aurora.jar!\META-INF\jars\jcodec-0.2.5.jar!\org\jcodec\common\Demuxer.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */