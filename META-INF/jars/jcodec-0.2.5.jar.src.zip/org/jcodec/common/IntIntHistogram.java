/*    */ package org.jcodec.common;
/*    */ 
/*    */ public class IntIntHistogram extends IntIntMap {
/*  4 */   private int maxBin = -1;
/*    */   
/*    */   public int max() {
/*  7 */     return this.maxBin;
/*    */   }
/*    */   
/*    */   public void increment(int bin) {
/* 11 */     int count = get(bin);
/* 12 */     count = (count == Integer.MIN_VALUE) ? 1 : (1 + count);
/* 13 */     put(bin, count);
/*    */     
/* 15 */     if (this.maxBin == -1)
/* 16 */       this.maxBin = bin; 
/* 17 */     int maxCount = get(this.maxBin);
/* 18 */     if (count > maxCount) {
/* 19 */       this.maxBin = bin;
/* 20 */       maxCount = count;
/*    */     } 
/*    */   }
/*    */ }


/* Location:              C:\Users\rapha\Downloads\aurora.jar!\META-INF\jars\jcodec-0.2.5.jar!\org\jcodec\common\IntIntHistogram.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */