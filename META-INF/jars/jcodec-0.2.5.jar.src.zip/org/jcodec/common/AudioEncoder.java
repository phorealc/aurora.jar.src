package org.jcodec.common;

import java.nio.ByteBuffer;

public interface AudioEncoder {
  ByteBuffer encode(ByteBuffer paramByteBuffer1, ByteBuffer paramByteBuffer2);
}


/* Location:              C:\Users\rapha\Downloads\aurora.jar!\META-INF\jars\jcodec-0.2.5.jar!\org\jcodec\common\AudioEncoder.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */