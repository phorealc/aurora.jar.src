package org.jcodec.common;

import java.util.concurrent.Callable;

public interface PriorityCallable<T> extends Callable<T> {
  int getPriority();
}


/* Location:              C:\Users\rapha\Downloads\aurora.jar!\META-INF\jars\jcodec-0.2.5.jar!\org\jcodec\common\PriorityCallable.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */