package org.jcodec.common;

import java.io.IOException;
import java.nio.ByteBuffer;
import org.jcodec.common.model.AudioBuffer;

public interface AudioDecoder {
  AudioBuffer decodeFrame(ByteBuffer paramByteBuffer1, ByteBuffer paramByteBuffer2) throws IOException;
  
  AudioCodecMeta getCodecMeta(ByteBuffer paramByteBuffer) throws IOException;
}


/* Location:              C:\Users\rapha\Downloads\aurora.jar!\META-INF\jars\jcodec-0.2.5.jar!\org\jcodec\common\AudioDecoder.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */