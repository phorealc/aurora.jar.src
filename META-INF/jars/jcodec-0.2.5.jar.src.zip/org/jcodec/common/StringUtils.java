/*     */ package org.jcodec.common;
/*     */ 
/*     */ import java.util.ArrayList;
/*     */ import java.util.List;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class StringUtils
/*     */ {
/*  17 */   public static final String[] zeroPad00 = new String[] { "00", "01", "02", "03", "04", "05", "06", "07", "08", "09" };
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static String[] splitWorker4(String str, String separatorChars, int max, boolean preserveAllTokens) {
/*  24 */     if (str == null) {
/*  25 */       return null;
/*     */     }
/*  27 */     int len = str.length();
/*  28 */     if (len == 0) {
/*  29 */       return new String[0];
/*     */     }
/*  31 */     List<String> list = new ArrayList<String>();
/*  32 */     int sizePlus1 = 1;
/*  33 */     int i = 0, start = 0;
/*  34 */     boolean match = false;
/*  35 */     boolean lastMatch = false;
/*  36 */     if (separatorChars == null) {
/*     */       
/*  38 */       while (i < len) {
/*  39 */         if (Character.isWhitespace(str.charAt(i))) {
/*  40 */           if (match || preserveAllTokens) {
/*  41 */             lastMatch = true;
/*  42 */             if (sizePlus1++ == max) {
/*  43 */               i = len;
/*  44 */               lastMatch = false;
/*     */             } 
/*  46 */             list.add(str.substring(start, i));
/*  47 */             match = false;
/*     */           } 
/*  49 */           start = ++i;
/*     */           continue;
/*     */         } 
/*  52 */         lastMatch = false;
/*  53 */         match = true;
/*  54 */         i++;
/*     */       } 
/*  56 */     } else if (separatorChars.length() == 1) {
/*     */       
/*  58 */       char sep = separatorChars.charAt(0);
/*  59 */       while (i < len) {
/*  60 */         if (str.charAt(i) == sep) {
/*  61 */           if (match || preserveAllTokens) {
/*  62 */             lastMatch = true;
/*  63 */             if (sizePlus1++ == max) {
/*  64 */               i = len;
/*  65 */               lastMatch = false;
/*     */             } 
/*  67 */             list.add(str.substring(start, i));
/*  68 */             match = false;
/*     */           } 
/*  70 */           start = ++i;
/*     */           continue;
/*     */         } 
/*  73 */         lastMatch = false;
/*  74 */         match = true;
/*  75 */         i++;
/*     */       } 
/*     */     } else {
/*     */       
/*  79 */       while (i < len) {
/*  80 */         if (separatorChars.indexOf(str.charAt(i)) >= 0) {
/*  81 */           if (match || preserveAllTokens) {
/*  82 */             lastMatch = true;
/*  83 */             if (sizePlus1++ == max) {
/*  84 */               i = len;
/*  85 */               lastMatch = false;
/*     */             } 
/*  87 */             list.add(str.substring(start, i));
/*  88 */             match = false;
/*     */           } 
/*  90 */           start = ++i;
/*     */           continue;
/*     */         } 
/*  93 */         lastMatch = false;
/*  94 */         match = true;
/*  95 */         i++;
/*     */       } 
/*     */     } 
/*  98 */     if (match || (preserveAllTokens && lastMatch)) {
/*  99 */       list.add(str.substring(start, i));
/*     */     }
/* 101 */     return list.<String>toArray(new String[list.size()]);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private static String[] splitWorker(String str, char separatorChar, boolean preserveAllTokens) {
/* 107 */     if (str == null) {
/* 108 */       return null;
/*     */     }
/* 110 */     int len = str.length();
/* 111 */     if (len == 0) {
/* 112 */       return new String[0];
/*     */     }
/* 114 */     List<String> list = new ArrayList<String>();
/* 115 */     int i = 0, start = 0;
/* 116 */     boolean match = false;
/* 117 */     boolean lastMatch = false;
/* 118 */     while (i < len) {
/* 119 */       if (str.charAt(i) == separatorChar) {
/* 120 */         if (match || preserveAllTokens) {
/* 121 */           list.add(str.substring(start, i));
/* 122 */           match = false;
/* 123 */           lastMatch = true;
/*     */         } 
/* 125 */         start = ++i;
/*     */         continue;
/*     */       } 
/* 128 */       lastMatch = false;
/* 129 */       match = true;
/* 130 */       i++;
/*     */     } 
/* 132 */     if (match || (preserveAllTokens && lastMatch)) {
/* 133 */       list.add(str.substring(start, i));
/*     */     }
/* 135 */     return list.<String>toArray(new String[list.size()]);
/*     */   }
/*     */   
/*     */   public static String[] split(String str) {
/* 139 */     return splitS3(str, null, -1);
/*     */   }
/*     */   
/*     */   public static String[] splitS(String str, String separatorChars) {
/* 143 */     return splitWorker4(str, separatorChars, -1, false);
/*     */   }
/*     */   
/*     */   public static String[] splitS3(String str, String separatorChars, int max) {
/* 147 */     return splitWorker4(str, separatorChars, max, false);
/*     */   }
/*     */   
/*     */   public static String[] splitC(String str, char separatorChar) {
/* 151 */     return splitWorker(str, separatorChar, false);
/*     */   }
/*     */   
/*     */   public static boolean isEmpty(String str) {
/* 155 */     return (str == null || str.length() == 0);
/*     */   }
/*     */   
/*     */   private static boolean isDelimiter(char ch, char[] delimiters) {
/* 159 */     if (delimiters == null) {
/* 160 */       return Character.isWhitespace(ch);
/*     */     }
/* 162 */     for (int i = 0, isize = delimiters.length; i < isize; i++) {
/* 163 */       if (ch == delimiters[i]) {
/* 164 */         return true;
/*     */       }
/*     */     } 
/* 167 */     return false;
/*     */   }
/*     */   
/*     */   public static String capitaliseAllWords(String str) {
/* 171 */     return capitalize(str);
/*     */   }
/*     */   
/*     */   public static String capitalize(String str) {
/* 175 */     return capitalizeD(str, null);
/*     */   }
/*     */   
/*     */   public static String capitalizeD(String str, char[] delimiters) {
/* 179 */     int delimLen = (delimiters == null) ? -1 : delimiters.length;
/* 180 */     if (str == null || str.length() == 0 || delimLen == 0) {
/* 181 */       return str;
/*     */     }
/* 183 */     int strLen = str.length();
/* 184 */     StringBuilder buffer = new StringBuilder(strLen);
/* 185 */     boolean capitalizeNext = true;
/* 186 */     for (int i = 0; i < strLen; i++) {
/* 187 */       char ch = str.charAt(i);
/*     */       
/* 189 */       if (isDelimiter(ch, delimiters)) {
/* 190 */         buffer.append(ch);
/* 191 */         capitalizeNext = true;
/* 192 */       } else if (capitalizeNext) {
/* 193 */         buffer.append(Character.toTitleCase(ch));
/* 194 */         capitalizeNext = false;
/*     */       } else {
/* 196 */         buffer.append(ch);
/*     */       } 
/*     */     } 
/* 199 */     return buffer.toString();
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public static String join(Object[] array) {
/* 205 */     return joinS(array, null);
/*     */   }
/*     */ 
/*     */   
/*     */   public static String join2(Object[] array, char separator) {
/* 210 */     if (array == null) {
/* 211 */       return null;
/*     */     }
/*     */     
/* 214 */     return join4(array, separator, 0, array.length);
/*     */   }
/*     */ 
/*     */   
/*     */   public static String join4(Object[] array, char separator, int startIndex, int endIndex) {
/* 219 */     if (array == null) {
/* 220 */       return null;
/*     */     }
/* 222 */     int bufSize = endIndex - startIndex;
/* 223 */     if (bufSize <= 0) {
/* 224 */       return "";
/*     */     }
/*     */     
/* 227 */     bufSize *= ((array[startIndex] == null) ? 16 : array[startIndex].toString().length()) + 1;
/* 228 */     StringBuilder buf = new StringBuilder(bufSize);
/*     */     
/* 230 */     for (int i = startIndex; i < endIndex; i++) {
/* 231 */       if (i > startIndex) {
/* 232 */         buf.append(separator);
/*     */       }
/* 234 */       if (array[i] != null) {
/* 235 */         buf.append(array[i]);
/*     */       }
/*     */     } 
/* 238 */     return buf.toString();
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public static String joinS(Object[] array, String separator) {
/* 244 */     if (array == null) {
/* 245 */       return null;
/*     */     }
/* 247 */     return joinS4(array, separator, 0, array.length);
/*     */   }
/*     */ 
/*     */   
/*     */   public static String joinS4(Object[] array, String separator, int startIndex, int endIndex) {
/* 252 */     if (array == null) {
/* 253 */       return null;
/*     */     }
/* 255 */     if (separator == null) {
/* 256 */       separator = "";
/*     */     }
/*     */ 
/*     */ 
/*     */     
/* 261 */     int bufSize = endIndex - startIndex;
/* 262 */     if (bufSize <= 0) {
/* 263 */       return "";
/*     */     }
/*     */     
/* 266 */     bufSize *= ((array[startIndex] == null) ? 16 : array[startIndex].toString().length()) + separator
/* 267 */       .length();
/*     */     
/* 269 */     StringBuilder buf = new StringBuilder(bufSize);
/*     */     
/* 271 */     for (int i = startIndex; i < endIndex; i++) {
/* 272 */       if (i > startIndex) {
/* 273 */         buf.append(separator);
/*     */       }
/* 275 */       if (array[i] != null) {
/* 276 */         buf.append(array[i]);
/*     */       }
/*     */     } 
/* 279 */     return buf.toString();
/*     */   }
/*     */   
/*     */   public static String zeroPad2(int x) {
/* 283 */     if (x >= 0 && x < 10) {
/* 284 */       return zeroPad00[x];
/*     */     }
/* 286 */     return "" + x;
/*     */   }
/*     */   
/*     */   public static String zeroPad3(int n) {
/* 290 */     String s1 = zeroPad2(n);
/* 291 */     return (s1.length() == 2) ? ("0" + s1) : s1;
/*     */   }
/*     */ }


/* Location:              C:\Users\rapha\Downloads\aurora.jar!\META-INF\jars\jcodec-0.2.5.jar!\org\jcodec\common\StringUtils.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */