/*     */ package org.jcodec.common;
/*     */ 
/*     */ import java.util.HashMap;
/*     */ import java.util.LinkedList;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import java.util.Set;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class Tuple
/*     */ {
/*     */   public static class _1<T0>
/*     */   {
/*     */     public final T0 v0;
/*     */     
/*     */     public _1(T0 v0) {
/*  23 */       this.v0 = v0;
/*     */     }
/*     */   }
/*     */   
/*     */   public static class _2<T0, T1> {
/*     */     public final T0 v0;
/*     */     public final T1 v1;
/*     */     
/*     */     public _2(T0 v0, T1 v1) {
/*  32 */       this.v0 = v0;
/*  33 */       this.v1 = v1;
/*     */     }
/*     */   }
/*     */   
/*     */   public static class _3<T0, T1, T2> {
/*     */     public final T0 v0;
/*     */     public final T1 v1;
/*     */     public final T2 v2;
/*     */     
/*     */     public _3(T0 v0, T1 v1, T2 v2) {
/*  43 */       this.v0 = v0;
/*  44 */       this.v1 = v1;
/*  45 */       this.v2 = v2;
/*     */     }
/*     */   }
/*     */   
/*     */   public static class _4<T0, T1, T2, T3> {
/*     */     public final T0 v0;
/*     */     public final T1 v1;
/*     */     public final T2 v2;
/*     */     public final T3 v3;
/*     */     
/*     */     public _4(T0 v0, T1 v1, T2 v2, T3 v3) {
/*  56 */       this.v0 = v0;
/*  57 */       this.v1 = v1;
/*  58 */       this.v2 = v2;
/*  59 */       this.v3 = v3;
/*     */     }
/*     */   }
/*     */   
/*     */   public static <T0> _1<T0> single(T0 v0) {
/*  64 */     return new _1<T0>(v0);
/*     */   }
/*     */   
/*     */   public static <T0, T1> _2<T0, T1> pair(T0 v0, T1 v1) {
/*  68 */     return new _2<T0, T1>(v0, v1);
/*     */   }
/*     */   
/*     */   public static <T0, T1, T2> _3<T0, T1, T2> triple(T0 v0, T1 v1, T2 v2) {
/*  72 */     return new _3<T0, T1, T2>(v0, v1, v2);
/*     */   }
/*     */   
/*     */   public static <T0, T1, T2, T3> _4<T0, T1, T2, T3> quad(T0 v0, T1 v1, T2 v2, T3 v3) {
/*  76 */     return new _4<T0, T1, T2, T3>(v0, v1, v2, v3);
/*     */   }
/*     */   
/*     */   public static <T0, T1> Map<T0, T1> asMap(Iterable<_2<T0, T1>> it) {
/*  80 */     HashMap<T0, T1> result = new HashMap<T0, T1>();
/*  81 */     for (_2<T0, T1> el : it) {
/*  82 */       result.put(el.v0, el.v1);
/*     */     }
/*  84 */     return result;
/*     */   }
/*     */   
/*     */   public static <T0, T1> Map<T0, T1> arrayAsMap(_2<T0, T1>[] arr) {
/*  88 */     HashMap<T0, T1> result = new HashMap<T0, T1>();
/*  89 */     for (int i = 0; i < arr.length; i++) {
/*  90 */       _2<T0, T1> el = arr[i];
/*  91 */       result.put(el.v0, el.v1);
/*     */     } 
/*  93 */     return result;
/*     */   }
/*     */   
/*     */   public static <T0, T1> List<_2<T0, T1>> asList(Map<T0, T1> m) {
/*  97 */     LinkedList<_2<T0, T1>> result = new LinkedList<_2<T0, T1>>();
/*  98 */     Set<Map.Entry<T0, T1>> entrySet = m.entrySet();
/*  99 */     for (Map.Entry<T0, T1> entry : entrySet) {
/* 100 */       result.add(pair(entry.getKey(), entry.getValue()));
/*     */     }
/* 102 */     return result;
/*     */   }
/*     */   
/*     */   public static <T0> List<T0> _1_project0(List<_1<T0>> temp) {
/* 106 */     List<T0> result = new LinkedList<T0>();
/* 107 */     for (_1<T0> _1 : temp) {
/* 108 */       result.add(_1.v0);
/*     */     }
/* 110 */     return result;
/*     */   }
/*     */   
/*     */   public static <T0, T1> List<T0> _2_project0(List<_2<T0, T1>> temp) {
/* 114 */     List<T0> result = new LinkedList<T0>();
/* 115 */     for (_2<T0, T1> _2 : temp) {
/* 116 */       result.add(_2.v0);
/*     */     }
/* 118 */     return result;
/*     */   }
/*     */   
/*     */   public static <T0, T1> List<T1> _2_project1(List<_2<T0, T1>> temp) {
/* 122 */     List<T1> result = new LinkedList<T1>();
/* 123 */     for (_2<T0, T1> _2 : temp) {
/* 124 */       result.add(_2.v1);
/*     */     }
/* 126 */     return result;
/*     */   }
/*     */   
/*     */   public static <T0, T1, T2, T3> List<T0> _3_project0(List<_3<T0, T1, T2>> temp) {
/* 130 */     List<T0> result = new LinkedList<T0>();
/* 131 */     for (_3<T0, T1, T2> _3 : temp) {
/* 132 */       result.add(_3.v0);
/*     */     }
/* 134 */     return result;
/*     */   }
/*     */   
/*     */   public static <T0, T1, T2, T3> List<T1> _3_project1(List<_3<T0, T1, T2>> temp) {
/* 138 */     List<T1> result = new LinkedList<T1>();
/* 139 */     for (_3<T0, T1, T2> _3 : temp) {
/* 140 */       result.add(_3.v1);
/*     */     }
/* 142 */     return result;
/*     */   }
/*     */   
/*     */   public static <T0, T1, T2, T3> List<T2> _3_project2(List<_3<T0, T1, T2>> temp) {
/* 146 */     List<T2> result = new LinkedList<T2>();
/* 147 */     for (_3<T0, T1, T2> _3 : temp) {
/* 148 */       result.add(_3.v2);
/*     */     }
/* 150 */     return result;
/*     */   }
/*     */   
/*     */   public static <T0, T1, T2, T3> List<T0> _4_project0(List<_4<T0, T1, T2, T3>> temp) {
/* 154 */     List<T0> result = new LinkedList<T0>();
/* 155 */     for (_4<T0, T1, T2, T3> _4 : temp) {
/* 156 */       result.add(_4.v0);
/*     */     }
/* 158 */     return result;
/*     */   }
/*     */   
/*     */   public static <T0, T1, T2, T3> List<T1> _4_project1(List<_4<T0, T1, T2, T3>> temp) {
/* 162 */     List<T1> result = new LinkedList<T1>();
/* 163 */     for (_4<T0, T1, T2, T3> _4 : temp) {
/* 164 */       result.add(_4.v1);
/*     */     }
/* 166 */     return result;
/*     */   }
/*     */   
/*     */   public static <T0, T1, T2, T3> List<T2> _4_project2(List<_4<T0, T1, T2, T3>> temp) {
/* 170 */     List<T2> result = new LinkedList<T2>();
/* 171 */     for (_4<T0, T1, T2, T3> _4 : temp) {
/* 172 */       result.add(_4.v2);
/*     */     }
/* 174 */     return result;
/*     */   }
/*     */   
/*     */   public static <T0, T1, T2, T3> List<T3> _4_project3(List<_4<T0, T1, T2, T3>> temp) {
/* 178 */     List<T3> result = new LinkedList<T3>();
/* 179 */     for (_4<T0, T1, T2, T3> _4 : temp) {
/* 180 */       result.add(_4.v3);
/*     */     }
/* 182 */     return result;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static <T0, U> List<_1<U>> _1map0(List<_1<T0>> l, Mapper<T0, U> mapper) {
/* 190 */     LinkedList<_1<U>> result = new LinkedList<_1<U>>();
/* 191 */     for (_1<T0> _1 : l) {
/* 192 */       result.add(single(mapper.map(_1.v0)));
/*     */     }
/* 194 */     return result;
/*     */   }
/*     */   
/*     */   public static <T0, T1, U> List<_2<U, T1>> _2map0(List<_2<T0, T1>> l, Mapper<T0, U> mapper) {
/* 198 */     LinkedList<_2<U, T1>> result = new LinkedList<_2<U, T1>>();
/* 199 */     for (_2<T0, T1> _2 : l) {
/* 200 */       result.add(pair(mapper.map(_2.v0), _2.v1));
/*     */     }
/* 202 */     return result;
/*     */   }
/*     */   
/*     */   public static <T0, T1, U> List<_2<T0, U>> _2map1(List<_2<T0, T1>> l, Mapper<T1, U> mapper) {
/* 206 */     LinkedList<_2<T0, U>> result = new LinkedList<_2<T0, U>>();
/* 207 */     for (_2<T0, T1> _2 : l) {
/* 208 */       result.add(pair(_2.v0, mapper.map(_2.v1)));
/*     */     }
/* 210 */     return result;
/*     */   }
/*     */   
/*     */   public static <T0, T1, T2, U> List<_3<U, T1, T2>> _3map0(List<_3<T0, T1, T2>> l, Mapper<T0, U> mapper) {
/* 214 */     LinkedList<_3<U, T1, T2>> result = new LinkedList<_3<U, T1, T2>>();
/* 215 */     for (_3<T0, T1, T2> _3 : l) {
/* 216 */       result.add(triple(mapper.map(_3.v0), _3.v1, _3.v2));
/*     */     }
/* 218 */     return result;
/*     */   }
/*     */   
/*     */   public static <T0, T1, T2, U> List<_3<T0, U, T2>> _3map1(List<_3<T0, T1, T2>> l, Mapper<T1, U> mapper) {
/* 222 */     LinkedList<_3<T0, U, T2>> result = new LinkedList<_3<T0, U, T2>>();
/* 223 */     for (_3<T0, T1, T2> _3 : l) {
/* 224 */       result.add(triple(_3.v0, mapper.map(_3.v1), _3.v2));
/*     */     }
/* 226 */     return result;
/*     */   }
/*     */   
/*     */   public static <T0, T1, T2, U> List<_3<T0, T1, U>> _3map3(List<_3<T0, T1, T2>> l, Mapper<T2, U> mapper) {
/* 230 */     LinkedList<_3<T0, T1, U>> result = new LinkedList<_3<T0, T1, U>>();
/* 231 */     for (_3<T0, T1, T2> _3 : l) {
/* 232 */       result.add(triple(_3.v0, _3.v1, mapper.map(_3.v2)));
/*     */     }
/* 234 */     return result;
/*     */   }
/*     */   
/*     */   public static <T0, T1, T2, T3, U> List<_4<U, T1, T2, T3>> _4map0(List<_4<T0, T1, T2, T3>> l, Mapper<T0, U> mapper) {
/* 238 */     LinkedList<_4<U, T1, T2, T3>> result = new LinkedList<_4<U, T1, T2, T3>>();
/* 239 */     for (_4<T0, T1, T2, T3> _4 : l) {
/* 240 */       result.add(quad(mapper.map(_4.v0), _4.v1, _4.v2, _4.v3));
/*     */     }
/* 242 */     return result;
/*     */   }
/*     */   
/*     */   public static <T0, T1, T2, T3, U> List<_4<T0, U, T2, T3>> _4map1(List<_4<T0, T1, T2, T3>> l, Mapper<T1, U> mapper) {
/* 246 */     LinkedList<_4<T0, U, T2, T3>> result = new LinkedList<_4<T0, U, T2, T3>>();
/* 247 */     for (_4<T0, T1, T2, T3> _4 : l) {
/* 248 */       result.add(quad(_4.v0, mapper.map(_4.v1), _4.v2, _4.v3));
/*     */     }
/* 250 */     return result;
/*     */   }
/*     */   
/*     */   public static <T0, T1, T2, T3, U> List<_4<T0, T1, U, T3>> _4map3(List<_4<T0, T1, T2, T3>> l, Mapper<T2, U> mapper) {
/* 254 */     LinkedList<_4<T0, T1, U, T3>> result = new LinkedList<_4<T0, T1, U, T3>>();
/* 255 */     for (_4<T0, T1, T2, T3> _4 : l) {
/* 256 */       result.add(quad(_4.v0, _4.v1, mapper.map(_4.v2), _4.v3));
/*     */     }
/* 258 */     return result;
/*     */   }
/*     */   
/*     */   public static <T0, T1, T2, T3, U> List<_4<T0, T1, T2, U>> _4map4(List<_4<T0, T1, T2, T3>> l, Mapper<T3, U> mapper) {
/* 262 */     LinkedList<_4<T0, T1, T2, U>> result = new LinkedList<_4<T0, T1, T2, U>>();
/* 263 */     for (_4<T0, T1, T2, T3> _4 : l) {
/* 264 */       result.add(quad(_4.v0, _4.v1, _4.v2, mapper.map(_4.v3)));
/*     */     }
/* 266 */     return result;
/*     */   }
/*     */   
/*     */   public static interface Mapper<T, U> {
/*     */     U map(T param1T);
/*     */   }
/*     */ }


/* Location:              C:\Users\rapha\Downloads\aurora.jar!\META-INF\jars\jcodec-0.2.5.jar!\org\jcodec\common\Tuple.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */