/*      */ package org.jcodec.common;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ public final class Preconditions
/*      */ {
/*      */   public static void checkArgument(boolean expression) {
/*  102 */     if (!expression) {
/*  103 */       throw new IllegalArgumentException();
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static void checkArgument(boolean expression, Object errorMessage) {
/*  116 */     if (!expression) {
/*  117 */       throw new IllegalArgumentException(String.valueOf(errorMessage));
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static void checkArgument(boolean expression, String errorMessageTemplate, Object... errorMessageArgs) {
/*  140 */     if (!expression) {
/*  141 */       throw new IllegalArgumentException(format(errorMessageTemplate, errorMessageArgs));
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static void checkArgument(boolean b, String errorMessageTemplate, char p1) {
/*  151 */     if (!b) {
/*  152 */       throw new IllegalArgumentException(format(errorMessageTemplate, new Object[] { Character.valueOf(p1) }));
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static void checkArgument(boolean b, String errorMessageTemplate, int p1) {
/*  162 */     if (!b) {
/*  163 */       throw new IllegalArgumentException(format(errorMessageTemplate, new Object[] { Integer.valueOf(p1) }));
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static void checkArgument(boolean b, String errorMessageTemplate, long p1) {
/*  173 */     if (!b) {
/*  174 */       throw new IllegalArgumentException(format(errorMessageTemplate, new Object[] { Long.valueOf(p1) }));
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static void checkArgument(boolean b, String errorMessageTemplate, Object p1) {
/*  185 */     if (!b) {
/*  186 */       throw new IllegalArgumentException(format(errorMessageTemplate, new Object[] { p1 }));
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static void checkArgument(boolean b, String errorMessageTemplate, char p1, char p2) {
/*  197 */     if (!b) {
/*  198 */       throw new IllegalArgumentException(format(errorMessageTemplate, new Object[] { Character.valueOf(p1), Character.valueOf(p2) }));
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static void checkArgument(boolean b, String errorMessageTemplate, char p1, int p2) {
/*  209 */     if (!b) {
/*  210 */       throw new IllegalArgumentException(format(errorMessageTemplate, new Object[] { Character.valueOf(p1), Integer.valueOf(p2) }));
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static void checkArgument(boolean b, String errorMessageTemplate, char p1, long p2) {
/*  221 */     if (!b) {
/*  222 */       throw new IllegalArgumentException(format(errorMessageTemplate, new Object[] { Character.valueOf(p1), Long.valueOf(p2) }));
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static void checkArgument(boolean b, String errorMessageTemplate, char p1, Object p2) {
/*  233 */     if (!b) {
/*  234 */       throw new IllegalArgumentException(format(errorMessageTemplate, new Object[] { Character.valueOf(p1), p2 }));
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static void checkArgument(boolean b, String errorMessageTemplate, int p1, char p2) {
/*  245 */     if (!b) {
/*  246 */       throw new IllegalArgumentException(format(errorMessageTemplate, new Object[] { Integer.valueOf(p1), Character.valueOf(p2) }));
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static void checkArgument(boolean b, String errorMessageTemplate, int p1, int p2) {
/*  257 */     if (!b) {
/*  258 */       throw new IllegalArgumentException(format(errorMessageTemplate, new Object[] { Integer.valueOf(p1), Integer.valueOf(p2) }));
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static void checkArgument(boolean b, String errorMessageTemplate, int p1, long p2) {
/*  269 */     if (!b) {
/*  270 */       throw new IllegalArgumentException(format(errorMessageTemplate, new Object[] { Integer.valueOf(p1), Long.valueOf(p2) }));
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static void checkArgument(boolean b, String errorMessageTemplate, int p1, Object p2) {
/*  281 */     if (!b) {
/*  282 */       throw new IllegalArgumentException(format(errorMessageTemplate, new Object[] { Integer.valueOf(p1), p2 }));
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static void checkArgument(boolean b, String errorMessageTemplate, long p1, char p2) {
/*  293 */     if (!b) {
/*  294 */       throw new IllegalArgumentException(format(errorMessageTemplate, new Object[] { Long.valueOf(p1), Character.valueOf(p2) }));
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static void checkArgument(boolean b, String errorMessageTemplate, long p1, int p2) {
/*  305 */     if (!b) {
/*  306 */       throw new IllegalArgumentException(format(errorMessageTemplate, new Object[] { Long.valueOf(p1), Integer.valueOf(p2) }));
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static void checkArgument(boolean b, String errorMessageTemplate, long p1, long p2) {
/*  317 */     if (!b) {
/*  318 */       throw new IllegalArgumentException(format(errorMessageTemplate, new Object[] { Long.valueOf(p1), Long.valueOf(p2) }));
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static void checkArgument(boolean b, String errorMessageTemplate, long p1, Object p2) {
/*  329 */     if (!b) {
/*  330 */       throw new IllegalArgumentException(format(errorMessageTemplate, new Object[] { Long.valueOf(p1), p2 }));
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static void checkArgument(boolean b, String errorMessageTemplate, Object p1, char p2) {
/*  341 */     if (!b) {
/*  342 */       throw new IllegalArgumentException(format(errorMessageTemplate, new Object[] { p1, Character.valueOf(p2) }));
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static void checkArgument(boolean b, String errorMessageTemplate, Object p1, int p2) {
/*  353 */     if (!b) {
/*  354 */       throw new IllegalArgumentException(format(errorMessageTemplate, new Object[] { p1, Integer.valueOf(p2) }));
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static void checkArgument(boolean b, String errorMessageTemplate, Object p1, long p2) {
/*  365 */     if (!b) {
/*  366 */       throw new IllegalArgumentException(format(errorMessageTemplate, new Object[] { p1, Long.valueOf(p2) }));
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static void checkArgument(boolean b, String errorMessageTemplate, Object p1, Object p2) {
/*  377 */     if (!b) {
/*  378 */       throw new IllegalArgumentException(format(errorMessageTemplate, new Object[] { p1, p2 }));
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static void checkArgument(boolean b, String errorMessageTemplate, Object p1, Object p2, Object p3) {
/*  393 */     if (!b) {
/*  394 */       throw new IllegalArgumentException(format(errorMessageTemplate, new Object[] { p1, p2, p3 }));
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static void checkArgument(boolean b, String errorMessageTemplate, Object p1, Object p2, Object p3, Object p4) {
/*  410 */     if (!b) {
/*  411 */       throw new IllegalArgumentException(format(errorMessageTemplate, new Object[] { p1, p2, p3, p4 }));
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static void checkState(boolean expression) {
/*  423 */     if (!expression) {
/*  424 */       throw new IllegalStateException();
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static void checkState(boolean expression, Object errorMessage) {
/*  438 */     if (!expression) {
/*  439 */       throw new IllegalStateException(String.valueOf(errorMessage));
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static void checkState(boolean expression, String errorMessageTemplate, Object... errorMessageArgs) {
/*  463 */     if (!expression) {
/*  464 */       throw new IllegalStateException(format(errorMessageTemplate, errorMessageArgs));
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static void checkState(boolean b, String errorMessageTemplate, char p1) {
/*  475 */     if (!b) {
/*  476 */       throw new IllegalStateException(format(errorMessageTemplate, new Object[] { Character.valueOf(p1) }));
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static void checkState(boolean b, String errorMessageTemplate, int p1) {
/*  487 */     if (!b) {
/*  488 */       throw new IllegalStateException(format(errorMessageTemplate, new Object[] { Integer.valueOf(p1) }));
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static void checkState(boolean b, String errorMessageTemplate, long p1) {
/*  499 */     if (!b) {
/*  500 */       throw new IllegalStateException(format(errorMessageTemplate, new Object[] { Long.valueOf(p1) }));
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static void checkState(boolean b, String errorMessageTemplate, Object p1) {
/*  512 */     if (!b) {
/*  513 */       throw new IllegalStateException(format(errorMessageTemplate, new Object[] { p1 }));
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static void checkState(boolean b, String errorMessageTemplate, char p1, char p2) {
/*  525 */     if (!b) {
/*  526 */       throw new IllegalStateException(format(errorMessageTemplate, new Object[] { Character.valueOf(p1), Character.valueOf(p2) }));
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static void checkState(boolean b, String errorMessageTemplate, char p1, int p2) {
/*  537 */     if (!b) {
/*  538 */       throw new IllegalStateException(format(errorMessageTemplate, new Object[] { Character.valueOf(p1), Integer.valueOf(p2) }));
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static void checkState(boolean b, String errorMessageTemplate, char p1, long p2) {
/*  550 */     if (!b) {
/*  551 */       throw new IllegalStateException(format(errorMessageTemplate, new Object[] { Character.valueOf(p1), Long.valueOf(p2) }));
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static void checkState(boolean b, String errorMessageTemplate, char p1, Object p2) {
/*  563 */     if (!b) {
/*  564 */       throw new IllegalStateException(format(errorMessageTemplate, new Object[] { Character.valueOf(p1), p2 }));
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static void checkState(boolean b, String errorMessageTemplate, int p1, char p2) {
/*  575 */     if (!b) {
/*  576 */       throw new IllegalStateException(format(errorMessageTemplate, new Object[] { Integer.valueOf(p1), Character.valueOf(p2) }));
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static void checkState(boolean b, String errorMessageTemplate, int p1, int p2) {
/*  587 */     if (!b) {
/*  588 */       throw new IllegalStateException(format(errorMessageTemplate, new Object[] { Integer.valueOf(p1), Integer.valueOf(p2) }));
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static void checkState(boolean b, String errorMessageTemplate, int p1, long p2) {
/*  599 */     if (!b) {
/*  600 */       throw new IllegalStateException(format(errorMessageTemplate, new Object[] { Integer.valueOf(p1), Long.valueOf(p2) }));
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static void checkState(boolean b, String errorMessageTemplate, int p1, Object p2) {
/*  612 */     if (!b) {
/*  613 */       throw new IllegalStateException(format(errorMessageTemplate, new Object[] { Integer.valueOf(p1), p2 }));
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static void checkState(boolean b, String errorMessageTemplate, long p1, char p2) {
/*  625 */     if (!b) {
/*  626 */       throw new IllegalStateException(format(errorMessageTemplate, new Object[] { Long.valueOf(p1), Character.valueOf(p2) }));
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static void checkState(boolean b, String errorMessageTemplate, long p1, int p2) {
/*  637 */     if (!b) {
/*  638 */       throw new IllegalStateException(format(errorMessageTemplate, new Object[] { Long.valueOf(p1), Integer.valueOf(p2) }));
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static void checkState(boolean b, String errorMessageTemplate, long p1, long p2) {
/*  650 */     if (!b) {
/*  651 */       throw new IllegalStateException(format(errorMessageTemplate, new Object[] { Long.valueOf(p1), Long.valueOf(p2) }));
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static void checkState(boolean b, String errorMessageTemplate, long p1, Object p2) {
/*  663 */     if (!b) {
/*  664 */       throw new IllegalStateException(format(errorMessageTemplate, new Object[] { Long.valueOf(p1), p2 }));
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static void checkState(boolean b, String errorMessageTemplate, Object p1, char p2) {
/*  676 */     if (!b) {
/*  677 */       throw new IllegalStateException(format(errorMessageTemplate, new Object[] { p1, Character.valueOf(p2) }));
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static void checkState(boolean b, String errorMessageTemplate, Object p1, int p2) {
/*  689 */     if (!b) {
/*  690 */       throw new IllegalStateException(format(errorMessageTemplate, new Object[] { p1, Integer.valueOf(p2) }));
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static void checkState(boolean b, String errorMessageTemplate, Object p1, long p2) {
/*  702 */     if (!b) {
/*  703 */       throw new IllegalStateException(format(errorMessageTemplate, new Object[] { p1, Long.valueOf(p2) }));
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static void checkState(boolean b, String errorMessageTemplate, Object p1, Object p2) {
/*  715 */     if (!b) {
/*  716 */       throw new IllegalStateException(format(errorMessageTemplate, new Object[] { p1, p2 }));
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static void checkState(boolean b, String errorMessageTemplate, Object p1, Object p2, Object p3) {
/*  732 */     if (!b) {
/*  733 */       throw new IllegalStateException(format(errorMessageTemplate, new Object[] { p1, p2, p3 }));
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static void checkState(boolean b, String errorMessageTemplate, Object p1, Object p2, Object p3, Object p4) {
/*  750 */     if (!b) {
/*  751 */       throw new IllegalStateException(format(errorMessageTemplate, new Object[] { p1, p2, p3, p4 }));
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static <T> T checkNotNull(T reference) {
/*  764 */     if (reference == null) {
/*  765 */       throw new NullPointerException();
/*      */     }
/*  767 */     return reference;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static <T> T checkNotNull(T reference, Object errorMessage) {
/*  781 */     if (reference == null) {
/*  782 */       throw new NullPointerException(String.valueOf(errorMessage));
/*      */     }
/*  784 */     return reference;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static <T> T checkNotNull(T reference, String errorMessageTemplate, Object... errorMessageArgs) {
/*  804 */     if (reference == null)
/*      */     {
/*  806 */       throw new NullPointerException(format(errorMessageTemplate, errorMessageArgs));
/*      */     }
/*  808 */     return reference;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static <T> T checkNotNull(T obj, String errorMessageTemplate, char p1) {
/*  818 */     if (obj == null) {
/*  819 */       throw new NullPointerException(format(errorMessageTemplate, new Object[] { Character.valueOf(p1) }));
/*      */     }
/*  821 */     return obj;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static <T> T checkNotNull(T obj, String errorMessageTemplate, int p1) {
/*  831 */     if (obj == null) {
/*  832 */       throw new NullPointerException(format(errorMessageTemplate, new Object[] { Integer.valueOf(p1) }));
/*      */     }
/*  834 */     return obj;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static <T> T checkNotNull(T obj, String errorMessageTemplate, long p1) {
/*  844 */     if (obj == null) {
/*  845 */       throw new NullPointerException(format(errorMessageTemplate, new Object[] { Long.valueOf(p1) }));
/*      */     }
/*  847 */     return obj;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static <T> T checkNotNull(T obj, String errorMessageTemplate, Object p1) {
/*  858 */     if (obj == null) {
/*  859 */       throw new NullPointerException(format(errorMessageTemplate, new Object[] { p1 }));
/*      */     }
/*  861 */     return obj;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static <T> T checkNotNull(T obj, String errorMessageTemplate, char p1, char p2) {
/*  871 */     if (obj == null) {
/*  872 */       throw new NullPointerException(format(errorMessageTemplate, new Object[] { Character.valueOf(p1), Character.valueOf(p2) }));
/*      */     }
/*  874 */     return obj;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static <T> T checkNotNull(T obj, String errorMessageTemplate, char p1, int p2) {
/*  884 */     if (obj == null) {
/*  885 */       throw new NullPointerException(format(errorMessageTemplate, new Object[] { Character.valueOf(p1), Integer.valueOf(p2) }));
/*      */     }
/*  887 */     return obj;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static <T> T checkNotNull(T obj, String errorMessageTemplate, char p1, long p2) {
/*  897 */     if (obj == null) {
/*  898 */       throw new NullPointerException(format(errorMessageTemplate, new Object[] { Character.valueOf(p1), Long.valueOf(p2) }));
/*      */     }
/*  900 */     return obj;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static <T> T checkNotNull(T obj, String errorMessageTemplate, char p1, Object p2) {
/*  911 */     if (obj == null) {
/*  912 */       throw new NullPointerException(format(errorMessageTemplate, new Object[] { Character.valueOf(p1), p2 }));
/*      */     }
/*  914 */     return obj;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static <T> T checkNotNull(T obj, String errorMessageTemplate, int p1, char p2) {
/*  924 */     if (obj == null) {
/*  925 */       throw new NullPointerException(format(errorMessageTemplate, new Object[] { Integer.valueOf(p1), Character.valueOf(p2) }));
/*      */     }
/*  927 */     return obj;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static <T> T checkNotNull(T obj, String errorMessageTemplate, int p1, int p2) {
/*  937 */     if (obj == null) {
/*  938 */       throw new NullPointerException(format(errorMessageTemplate, new Object[] { Integer.valueOf(p1), Integer.valueOf(p2) }));
/*      */     }
/*  940 */     return obj;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static <T> T checkNotNull(T obj, String errorMessageTemplate, int p1, long p2) {
/*  950 */     if (obj == null) {
/*  951 */       throw new NullPointerException(format(errorMessageTemplate, new Object[] { Integer.valueOf(p1), Long.valueOf(p2) }));
/*      */     }
/*  953 */     return obj;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static <T> T checkNotNull(T obj, String errorMessageTemplate, int p1, Object p2) {
/*  964 */     if (obj == null) {
/*  965 */       throw new NullPointerException(format(errorMessageTemplate, new Object[] { Integer.valueOf(p1), p2 }));
/*      */     }
/*  967 */     return obj;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static <T> T checkNotNull(T obj, String errorMessageTemplate, long p1, char p2) {
/*  977 */     if (obj == null) {
/*  978 */       throw new NullPointerException(format(errorMessageTemplate, new Object[] { Long.valueOf(p1), Character.valueOf(p2) }));
/*      */     }
/*  980 */     return obj;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static <T> T checkNotNull(T obj, String errorMessageTemplate, long p1, int p2) {
/*  990 */     if (obj == null) {
/*  991 */       throw new NullPointerException(format(errorMessageTemplate, new Object[] { Long.valueOf(p1), Integer.valueOf(p2) }));
/*      */     }
/*  993 */     return obj;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static <T> T checkNotNull(T obj, String errorMessageTemplate, long p1, long p2) {
/* 1003 */     if (obj == null) {
/* 1004 */       throw new NullPointerException(format(errorMessageTemplate, new Object[] { Long.valueOf(p1), Long.valueOf(p2) }));
/*      */     }
/* 1006 */     return obj;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static <T> T checkNotNull(T obj, String errorMessageTemplate, long p1, Object p2) {
/* 1017 */     if (obj == null) {
/* 1018 */       throw new NullPointerException(format(errorMessageTemplate, new Object[] { Long.valueOf(p1), p2 }));
/*      */     }
/* 1020 */     return obj;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static <T> T checkNotNull(T obj, String errorMessageTemplate, Object p1, char p2) {
/* 1031 */     if (obj == null) {
/* 1032 */       throw new NullPointerException(format(errorMessageTemplate, new Object[] { p1, Character.valueOf(p2) }));
/*      */     }
/* 1034 */     return obj;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static <T> T checkNotNull(T obj, String errorMessageTemplate, Object p1, int p2) {
/* 1045 */     if (obj == null) {
/* 1046 */       throw new NullPointerException(format(errorMessageTemplate, new Object[] { p1, Integer.valueOf(p2) }));
/*      */     }
/* 1048 */     return obj;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static <T> T checkNotNull(T obj, String errorMessageTemplate, Object p1, long p2) {
/* 1059 */     if (obj == null) {
/* 1060 */       throw new NullPointerException(format(errorMessageTemplate, new Object[] { p1, Long.valueOf(p2) }));
/*      */     }
/* 1062 */     return obj;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static <T> T checkNotNull(T obj, String errorMessageTemplate, Object p1, Object p2) {
/* 1073 */     if (obj == null) {
/* 1074 */       throw new NullPointerException(format(errorMessageTemplate, new Object[] { p1, p2 }));
/*      */     }
/* 1076 */     return obj;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static <T> T checkNotNull(T obj, String errorMessageTemplate, Object p1, Object p2, Object p3) {
/* 1091 */     if (obj == null) {
/* 1092 */       throw new NullPointerException(format(errorMessageTemplate, new Object[] { p1, p2, p3 }));
/*      */     }
/* 1094 */     return obj;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static <T> T checkNotNull(T obj, String errorMessageTemplate, Object p1, Object p2, Object p3, Object p4) {
/* 1110 */     if (obj == null) {
/* 1111 */       throw new NullPointerException(format(errorMessageTemplate, new Object[] { p1, p2, p3, p4 }));
/*      */     }
/* 1113 */     return obj;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static int checkElementIndex(int index, int size) {
/* 1154 */     return checkElementIndex(index, size, "index");
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static int checkElementIndex(int index, int size, String desc) {
/* 1171 */     if (index < 0 || index >= size) {
/* 1172 */       throw new IndexOutOfBoundsException(badElementIndex(index, size, desc));
/*      */     }
/* 1174 */     return index;
/*      */   }
/*      */   
/*      */   private static String badElementIndex(int index, int size, String desc) {
/* 1178 */     if (index < 0)
/* 1179 */       return format("%s (%s) must not be negative", new Object[] { desc, Integer.valueOf(index) }); 
/* 1180 */     if (size < 0) {
/* 1181 */       throw new IllegalArgumentException("negative size: " + size);
/*      */     }
/* 1183 */     return format("%s (%s) must be less than size (%s)", new Object[] { desc, Integer.valueOf(index), Integer.valueOf(size) });
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static int checkPositionIndex(int index, int size) {
/* 1199 */     return checkPositionIndex(index, size, "index");
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static int checkPositionIndex(int index, int size, String desc) {
/* 1216 */     if (index < 0 || index > size) {
/* 1217 */       throw new IndexOutOfBoundsException(badPositionIndex(index, size, desc));
/*      */     }
/* 1219 */     return index;
/*      */   }
/*      */   
/*      */   private static String badPositionIndex(int index, int size, String desc) {
/* 1223 */     if (index < 0)
/* 1224 */       return format("%s (%s) must not be negative", new Object[] { desc, Integer.valueOf(index) }); 
/* 1225 */     if (size < 0) {
/* 1226 */       throw new IllegalArgumentException("negative size: " + size);
/*      */     }
/* 1228 */     return format("%s (%s) must not be greater than size (%s)", new Object[] { desc, Integer.valueOf(index), Integer.valueOf(size) });
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static void checkPositionIndexes(int start, int end, int size) {
/* 1246 */     if (start < 0 || end < start || end > size) {
/* 1247 */       throw new IndexOutOfBoundsException(badPositionIndexes(start, end, size));
/*      */     }
/*      */   }
/*      */   
/*      */   private static String badPositionIndexes(int start, int end, int size) {
/* 1252 */     if (start < 0 || start > size) {
/* 1253 */       return badPositionIndex(start, size, "start index");
/*      */     }
/* 1255 */     if (end < 0 || end > size) {
/* 1256 */       return badPositionIndex(end, size, "end index");
/*      */     }
/*      */     
/* 1259 */     return format("end index (%s) must not be less than start index (%s)", new Object[] { Integer.valueOf(end), Integer.valueOf(start) });
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   static String format(String template, Object... args) {
/* 1274 */     if (args == null) {
/* 1275 */       throw new NullPointerException();
/*      */     }
/* 1277 */     template = String.valueOf(template);
/*      */ 
/*      */     
/* 1280 */     StringBuilder builder = new StringBuilder(template.length() + 16 * args.length);
/* 1281 */     int templateStart = 0;
/* 1282 */     int i = 0;
/* 1283 */     while (i < args.length) {
/* 1284 */       int placeholderStart = template.indexOf("%s", templateStart);
/* 1285 */       if (placeholderStart == -1) {
/*      */         break;
/*      */       }
/* 1288 */       builder.append(template, templateStart, placeholderStart);
/* 1289 */       builder.append(args[i++]);
/* 1290 */       templateStart = placeholderStart + 2;
/*      */     } 
/* 1292 */     builder.append(template, templateStart, template.length());
/*      */ 
/*      */     
/* 1295 */     if (i < args.length) {
/* 1296 */       builder.append(" [");
/* 1297 */       builder.append(args[i++]);
/* 1298 */       while (i < args.length) {
/* 1299 */         builder.append(", ");
/* 1300 */         builder.append(args[i++]);
/*      */       } 
/* 1302 */       builder.append(']');
/*      */     } 
/*      */     
/* 1305 */     return builder.toString();
/*      */   }
/*      */ }


/* Location:              C:\Users\rapha\Downloads\aurora.jar!\META-INF\jars\jcodec-0.2.5.jar!\org\jcodec\common\Preconditions.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */