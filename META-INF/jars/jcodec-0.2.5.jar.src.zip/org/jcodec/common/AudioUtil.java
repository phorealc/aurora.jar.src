/*     */ package org.jcodec.common;
/*     */ 
/*     */ import java.nio.ByteBuffer;
/*     */ import java.nio.FloatBuffer;
/*     */ import org.jcodec.api.NotSupportedException;
/*     */ import org.jcodec.common.tools.MathUtil;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class AudioUtil
/*     */ {
/*     */   private static final float f24 = 8388607.0F;
/*     */   private static final float f16 = 32767.0F;
/*     */   public static final float r16 = 3.0517578E-5F;
/*     */   public static final float r24 = 1.1920929E-7F;
/*     */   
/*     */   public static void toFloat(AudioFormat format, ByteBuffer buf, FloatBuffer floatBuf) {
/*  35 */     if (!format.isSigned()) {
/*  36 */       throw new NotSupportedException("Unsigned PCM is not supported ( yet? ).");
/*     */     }
/*  38 */     if (format.getSampleSizeInBits() != 16 && format.getSampleSizeInBits() != 24) {
/*  39 */       throw new NotSupportedException(format.getSampleSizeInBits() + " bit PCM is not supported ( yet? ).");
/*     */     }
/*  41 */     if (format.isBigEndian()) {
/*  42 */       if (format.getSampleSizeInBits() == 16) {
/*  43 */         toFloat16BE(buf, floatBuf);
/*     */       } else {
/*  45 */         toFloat24BE(buf, floatBuf);
/*     */       }
/*     */     
/*  48 */     } else if (format.getSampleSizeInBits() == 16) {
/*  49 */       toFloat16LE(buf, floatBuf);
/*     */     } else {
/*  51 */       toFloat24LE(buf, floatBuf);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static void fromFloat(FloatBuffer floatBuf, AudioFormat format, ByteBuffer buf) {
/*  68 */     if (!format.isSigned()) {
/*  69 */       throw new NotSupportedException("Unsigned PCM is not supported ( yet? ).");
/*     */     }
/*  71 */     if (format.getSampleSizeInBits() != 16 && format.getSampleSizeInBits() != 24) {
/*  72 */       throw new NotSupportedException(format.getSampleSizeInBits() + " bit PCM is not supported ( yet? ).");
/*     */     }
/*  74 */     if (format.isBigEndian()) {
/*  75 */       if (format.getSampleSizeInBits() == 16) {
/*  76 */         fromFloat16BE(buf, floatBuf);
/*     */       } else {
/*  78 */         fromFloat24BE(buf, floatBuf);
/*     */       }
/*     */     
/*  81 */     } else if (format.getSampleSizeInBits() == 16) {
/*  82 */       fromFloat16LE(buf, floatBuf);
/*     */     } else {
/*  84 */       fromFloat24LE(buf, floatBuf);
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   private static void toFloat24LE(ByteBuffer buf, FloatBuffer out) {
/*  90 */     while (buf.remaining() >= 3 && out.hasRemaining()) {
/*  91 */       out.put(1.1920929E-7F * (((buf.get() & 0xFF) << 8 | (buf.get() & 0xFF) << 16 | (buf.get() & 0xFF) << 24) >> 8));
/*     */     }
/*     */   }
/*     */   
/*     */   private static void toFloat16LE(ByteBuffer buf, FloatBuffer out) {
/*  96 */     while (buf.remaining() >= 2 && out.hasRemaining()) {
/*  97 */       out.put(3.0517578E-5F * (short)(buf.get() & 0xFF | (buf.get() & 0xFF) << 8));
/*     */     }
/*     */   }
/*     */   
/*     */   private static void toFloat24BE(ByteBuffer buf, FloatBuffer out) {
/* 102 */     while (buf.remaining() >= 3 && out.hasRemaining()) {
/* 103 */       out.put(1.1920929E-7F * (((buf.get() & 0xFF) << 24 | (buf.get() & 0xFF) << 16 | (buf.get() & 0xFF) << 8) >> 8));
/*     */     }
/*     */   }
/*     */   
/*     */   private static void toFloat16BE(ByteBuffer buf, FloatBuffer out) {
/* 108 */     while (buf.remaining() >= 2 && out.hasRemaining()) {
/* 109 */       out.put(3.0517578E-5F * (short)((buf.get() & 0xFF) << 8 | buf.get() & 0xFF));
/*     */     }
/*     */   }
/*     */   
/*     */   private static void fromFloat24LE(ByteBuffer buf, FloatBuffer _in) {
/* 114 */     while (buf.remaining() >= 3 && _in.hasRemaining()) {
/* 115 */       int val = MathUtil.clip((int)(_in.get() * 8388607.0F), -8388608, 8388607) & 0xFFFFFF;
/* 116 */       buf.put((byte)val);
/* 117 */       buf.put((byte)(val >> 8));
/* 118 */       buf.put((byte)(val >> 16));
/*     */     } 
/*     */   }
/*     */   
/*     */   private static void fromFloat16LE(ByteBuffer buf, FloatBuffer _in) {
/* 123 */     while (buf.remaining() >= 2 && _in.hasRemaining()) {
/* 124 */       int val = MathUtil.clip((int)(_in.get() * 32767.0F), -32768, 32767) & 0xFFFF;
/* 125 */       buf.put((byte)val);
/* 126 */       buf.put((byte)(val >> 8));
/*     */     } 
/*     */   }
/*     */   
/*     */   private static void fromFloat24BE(ByteBuffer buf, FloatBuffer _in) {
/* 131 */     while (buf.remaining() >= 3 && _in.hasRemaining()) {
/* 132 */       int val = MathUtil.clip((int)(_in.get() * 8388607.0F), -8388608, 8388607) & 0xFFFFFF;
/* 133 */       buf.put((byte)(val >> 16));
/* 134 */       buf.put((byte)(val >> 8));
/* 135 */       buf.put((byte)val);
/*     */     } 
/*     */   }
/*     */   
/*     */   private static void fromFloat16BE(ByteBuffer buf, FloatBuffer _in) {
/* 140 */     while (buf.remaining() >= 2 && _in.hasRemaining()) {
/* 141 */       int val = MathUtil.clip((int)(_in.get() * 32767.0F), -32768, 32767) & 0xFFFF;
/* 142 */       buf.put((byte)(val >> 8));
/* 143 */       buf.put((byte)val);
/*     */     } 
/*     */   }
/*     */   
/*     */   public static int fromInt(int[] data, int len, AudioFormat format, ByteBuffer buf) {
/* 148 */     if (!format.isSigned()) {
/* 149 */       throw new NotSupportedException("Unsigned PCM is not supported ( yet? ).");
/*     */     }
/* 151 */     if (format.getSampleSizeInBits() != 16 && format.getSampleSizeInBits() != 24) {
/* 152 */       throw new NotSupportedException(format.getSampleSizeInBits() + " bit PCM is not supported ( yet? ).");
/*     */     }
/* 154 */     if (format.isBigEndian()) {
/* 155 */       if (format.getSampleSizeInBits() == 16) {
/* 156 */         return fromInt16BE(buf, data, len);
/*     */       }
/* 158 */       return fromInt24BE(buf, data, len);
/*     */     } 
/*     */     
/* 161 */     if (format.getSampleSizeInBits() == 16) {
/* 162 */       return fromInt16LE(buf, data, len);
/*     */     }
/* 164 */     return fromInt24LE(buf, data, len);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private static int fromInt24LE(ByteBuffer buf, int[] out, int len) {
/* 170 */     int samples = 0;
/* 171 */     while (buf.remaining() >= 3 && samples < len) {
/* 172 */       int val = out[samples++];
/* 173 */       buf.put((byte)val);
/* 174 */       buf.put((byte)(val >> 8));
/* 175 */       buf.put((byte)(val >> 16));
/*     */     } 
/* 177 */     return samples;
/*     */   }
/*     */   
/*     */   private static int fromInt16LE(ByteBuffer buf, int[] out, int len) {
/* 181 */     int samples = 0;
/* 182 */     while (buf.remaining() >= 2 && samples < len) {
/* 183 */       int val = out[samples++];
/* 184 */       buf.put((byte)val);
/* 185 */       buf.put((byte)(val >> 8));
/*     */     } 
/* 187 */     return samples;
/*     */   }
/*     */   
/*     */   private static int fromInt24BE(ByteBuffer buf, int[] out, int len) {
/* 191 */     int samples = 0;
/* 192 */     while (buf.remaining() >= 3 && samples < len) {
/* 193 */       int val = out[samples++];
/* 194 */       buf.put((byte)(val >> 16));
/* 195 */       buf.put((byte)(val >> 8));
/* 196 */       buf.put((byte)val);
/*     */     } 
/* 198 */     return samples;
/*     */   }
/*     */   
/*     */   private static int fromInt16BE(ByteBuffer buf, int[] out, int len) {
/* 202 */     int samples = 0;
/* 203 */     while (buf.remaining() >= 2 && samples < len) {
/* 204 */       int val = out[samples++];
/* 205 */       buf.put((byte)(val >> 8));
/* 206 */       buf.put((byte)val);
/*     */     } 
/* 208 */     return samples;
/*     */   }
/*     */   
/*     */   public static int toInt(AudioFormat format, ByteBuffer buf, int[] samples) {
/* 212 */     if (!format.isSigned()) {
/* 213 */       throw new NotSupportedException("Unsigned PCM is not supported ( yet? ).");
/*     */     }
/* 215 */     if (format.getSampleSizeInBits() != 16 && format.getSampleSizeInBits() != 24) {
/* 216 */       throw new NotSupportedException(format.getSampleSizeInBits() + " bit PCM is not supported ( yet? ).");
/*     */     }
/* 218 */     if (format.isBigEndian()) {
/* 219 */       if (format.getSampleSizeInBits() == 16) {
/* 220 */         return toInt16BE(buf, samples);
/*     */       }
/* 222 */       return toInt24BE(buf, samples);
/*     */     } 
/*     */     
/* 225 */     if (format.getSampleSizeInBits() == 16) {
/* 226 */       return toInt16LE(buf, samples);
/*     */     }
/* 228 */     return toInt24LE(buf, samples);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private static int toInt24LE(ByteBuffer buf, int[] out) {
/* 234 */     int samples = 0;
/* 235 */     while (buf.remaining() >= 3 && samples < out.length) {
/* 236 */       out[samples++] = ((buf.get() & 0xFF) << 8 | (buf.get() & 0xFF) << 16 | (buf.get() & 0xFF) << 24) >> 8;
/*     */     }
/* 238 */     return samples;
/*     */   }
/*     */   
/*     */   private static int toInt16LE(ByteBuffer buf, int[] out) {
/* 242 */     int samples = 0;
/* 243 */     while (buf.remaining() >= 2 && samples < out.length) {
/* 244 */       out[samples++] = (short)(buf.get() & 0xFF | (buf.get() & 0xFF) << 8);
/*     */     }
/* 246 */     return samples;
/*     */   }
/*     */   
/*     */   private static int toInt24BE(ByteBuffer buf, int[] out) {
/* 250 */     int samples = 0;
/* 251 */     while (buf.remaining() >= 3 && samples < out.length) {
/* 252 */       out[samples++] = ((buf.get() & 0xFF) << 24 | (buf.get() & 0xFF) << 16 | (buf.get() & 0xFF) << 8) >> 8;
/*     */     }
/* 254 */     return samples;
/*     */   }
/*     */   
/*     */   private static int toInt16BE(ByteBuffer buf, int[] out) {
/* 258 */     int samples = 0;
/* 259 */     while (buf.remaining() >= 2 && samples < out.length) {
/* 260 */       out[samples++] = (short)((buf.get() & 0xFF) << 8 | buf.get() & 0xFF);
/*     */     }
/* 262 */     return samples;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static void interleave(AudioFormat format, ByteBuffer[] ins, ByteBuffer outb) {
/* 274 */     int bytesPerSample = format.getSampleSizeInBits() >> 3;
/* 275 */     int bytesPerFrame = bytesPerSample * ins.length;
/*     */     
/* 277 */     int max = 0;
/* 278 */     for (int i = 0; i < ins.length; i++) {
/* 279 */       if (ins[i].remaining() > max)
/* 280 */         max = ins[i].remaining(); 
/*     */     } 
/* 282 */     for (int frames = 0; frames < max && outb.remaining() >= bytesPerFrame; frames++) {
/* 283 */       for (int j = 0; j < ins.length; j++) {
/* 284 */         if (ins[j].remaining() < bytesPerSample) {
/* 285 */           for (int k = 0; k < bytesPerSample; k++)
/* 286 */             outb.put((byte)0); 
/*     */         } else {
/* 288 */           for (int k = 0; k < bytesPerSample; k++) {
/* 289 */             outb.put(ins[j].get());
/*     */           }
/*     */         } 
/*     */       } 
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static void deinterleave(AudioFormat format, ByteBuffer inb, ByteBuffer[] outs) {
/* 305 */     int bytesPerSample = format.getSampleSizeInBits() >> 3;
/* 306 */     int bytesPerFrame = bytesPerSample * outs.length;
/*     */     
/* 308 */     while (inb.remaining() >= bytesPerFrame) {
/* 309 */       for (int j = 0; j < outs.length; j++) {
/* 310 */         for (int i = 0; i < bytesPerSample; i++)
/* 311 */           outs[j].put(inb.get()); 
/*     */       } 
/*     */     } 
/*     */   }
/*     */ }


/* Location:              C:\Users\rapha\Downloads\aurora.jar!\META-INF\jars\jcodec-0.2.5.jar!\org\jcodec\common\AudioUtil.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */