/*    */ package org.jcodec.common.tools;
/*    */ 
/*    */ import java.nio.ShortBuffer;
/*    */ import org.jcodec.common.ArrayUtil;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class Debug
/*    */ {
/*    */   public static final void print8x8i(int[] output) {
/* 16 */     int i = 0;
/* 17 */     for (int x = 0; x < 8; x++) {
/* 18 */       for (int y = 0; y < 8; y++) {
/* 19 */         System.out.printf("%3d, ", new Object[] { Integer.valueOf(output[i]) });
/* 20 */         i++;
/*    */       } 
/* 22 */       System.out.println();
/*    */     } 
/*    */   }
/*    */   
/*    */   public static final void print8x8s(short[] output) {
/* 27 */     int i = 0;
/* 28 */     for (int x = 0; x < 8; x++) {
/* 29 */       for (int y = 0; y < 8; y++) {
/* 30 */         System.out.printf("%3d, ", new Object[] { Short.valueOf(output[i]) });
/* 31 */         i++;
/*    */       } 
/* 33 */       System.out.println();
/*    */     } 
/*    */   }
/*    */   
/*    */   public static final void print8x8sb(ShortBuffer output) {
/* 38 */     for (int x = 0; x < 8; x++) {
/* 39 */       for (int y = 0; y < 8; y++) {
/* 40 */         System.out.printf("%3d, ", new Object[] { Short.valueOf(output.get()) });
/*    */       } 
/* 42 */       System.out.println();
/*    */     } 
/*    */   }
/*    */   
/*    */   public static void prints(short[] table) {
/* 47 */     int i = 0;
/* 48 */     for (int x = 0; x < 8; x++) {
/* 49 */       for (int y = 0; y < 8; y++) {
/* 50 */         System.out.printf("%3d, ", new Object[] { Short.valueOf(table[i]) });
/* 51 */         i++;
/*    */       } 
/* 53 */       System.out.println();
/*    */     } 
/*    */   }
/*    */   
/*    */   public static void trace(Object... arguments) {
/* 58 */     if (debug && arguments.length > 0) {
/* 59 */       String format = (String)arguments[0];
/* 60 */       ArrayUtil.shiftLeft1(arguments);
/* 61 */       System.out.printf(format + ": %d\n", arguments);
/*    */     } 
/*    */   }
/*    */   
/*    */   public static boolean debug = false;
/*    */   
/*    */   public static void printInt(int i) {
/* 68 */     if (debug)
/* 69 */       System.out.print(i); 
/*    */   }
/*    */   
/*    */   public static void print(String string) {
/* 73 */     if (debug)
/* 74 */       System.out.print(string); 
/*    */   }
/*    */   
/*    */   public static void println(String string) {
/* 78 */     if (debug)
/* 79 */       System.out.println(string); 
/*    */   }
/*    */ }


/* Location:              C:\Users\rapha\Downloads\aurora.jar!\META-INF\jars\jcodec-0.2.5.jar!\org\jcodec\common\tools\Debug.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */