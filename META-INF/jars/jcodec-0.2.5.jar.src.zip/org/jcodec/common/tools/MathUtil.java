/*     */ package org.jcodec.common.tools;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class MathUtil
/*     */ {
/*  14 */   private static final int[] logTab = new int[] { 0, 0, 1, 1, 2, 2, 2, 2, 3, 3, 3, 3, 3, 3, 3, 3, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7 };
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  23 */   private static final int[] reverseTab = new int[] { 0, 128, 64, 192, 32, 160, 96, 224, 16, 144, 80, 208, 48, 176, 112, 240, 8, 136, 72, 200, 40, 168, 104, 232, 24, 152, 88, 216, 56, 184, 120, 248, 4, 132, 68, 196, 36, 164, 100, 228, 20, 148, 84, 212, 52, 180, 116, 244, 12, 140, 76, 204, 44, 172, 108, 236, 28, 156, 92, 220, 60, 188, 124, 252, 2, 130, 66, 194, 34, 162, 98, 226, 18, 146, 82, 210, 50, 178, 114, 242, 10, 138, 74, 202, 42, 170, 106, 234, 26, 154, 90, 218, 58, 186, 122, 250, 6, 134, 70, 198, 38, 166, 102, 230, 22, 150, 86, 214, 54, 182, 118, 246, 14, 142, 78, 206, 46, 174, 110, 238, 30, 158, 94, 222, 62, 190, 126, 254, 1, 129, 65, 193, 33, 161, 97, 225, 17, 145, 81, 209, 49, 177, 113, 241, 9, 137, 73, 201, 41, 169, 105, 233, 25, 153, 89, 217, 57, 185, 121, 249, 5, 133, 69, 197, 37, 165, 101, 229, 21, 149, 85, 213, 53, 181, 117, 245, 13, 141, 77, 205, 45, 173, 109, 237, 29, 157, 93, 221, 61, 189, 125, 253, 3, 131, 67, 195, 35, 163, 99, 227, 19, 147, 83, 211, 51, 179, 115, 243, 11, 139, 75, 203, 43, 171, 107, 235, 27, 155, 91, 219, 59, 187, 123, 251, 7, 135, 71, 199, 39, 167, 103, 231, 23, 151, 87, 215, 55, 183, 119, 247, 15, 143, 79, 207, 47, 175, 111, 239, 31, 159, 95, 223, 63, 191, 127, 255 };
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static int log2(int v) {
/*  40 */     int n = 0;
/*  41 */     if ((v & 0xFFFF0000) != 0) {
/*  42 */       v >>= 16;
/*  43 */       n += 16;
/*     */     } 
/*  45 */     if ((v & 0xFF00) != 0) {
/*  46 */       v >>= 8;
/*  47 */       n += 8;
/*     */     } 
/*  49 */     n += logTab[v];
/*     */     
/*  51 */     return n;
/*     */   }
/*     */   
/*     */   public static int log2l(long v) {
/*  55 */     int n = 0;
/*  56 */     if ((v & 0xFFFFFFFF00000000L) != 0L) {
/*  57 */       v >>= 32L;
/*  58 */       n += 32;
/*     */     } 
/*  60 */     if ((v & 0xFFFF0000L) != 0L) {
/*  61 */       v >>= 16L;
/*  62 */       n += 16;
/*     */     } 
/*  64 */     if ((v & 0xFF00L) != 0L) {
/*  65 */       v >>= 8L;
/*  66 */       n += 8;
/*     */     } 
/*  68 */     n += logTab[(int)v];
/*     */     
/*  70 */     return n;
/*     */   }
/*     */   
/*     */   public static int log2Slow(int val) {
/*  74 */     int i = 0;
/*  75 */     while ((val & Integer.MIN_VALUE) == 0) {
/*  76 */       val <<= 1;
/*  77 */       i++;
/*     */     } 
/*  79 */     return 31 - i;
/*     */   }
/*     */   
/*     */   public static int gcd(int a, int b) {
/*  83 */     if (b != 0) {
/*  84 */       return gcd(b, a % b);
/*     */     }
/*  86 */     return a;
/*     */   }
/*     */   
/*     */   public static long gcdLong(long a, long b) {
/*  90 */     if (b != 0L) {
/*  91 */       return gcdLong(b, a % b);
/*     */     }
/*  93 */     return a;
/*     */   }
/*     */   
/*     */   public static final int clip(int val, int from, int to) {
/*  97 */     return (val < from) ? from : ((val > to) ? to : val);
/*     */   }
/*     */   
/*     */   public static final int clipMax(int val, int max) {
/* 101 */     return (val < max) ? val : max;
/*     */   }
/*     */ 
/*     */   
/*     */   public static int cubeRoot(int n) {
/* 106 */     return 0;
/*     */   }
/*     */   
/*     */   public static final int reverse(int b) {
/* 110 */     return reverseTab[b & 0xFF];
/*     */   }
/*     */   
/*     */   public static int nextPowerOfTwo(int n) {
/* 114 */     n--;
/* 115 */     n |= n >> 1;
/* 116 */     n |= n >> 2;
/* 117 */     n |= n >> 4;
/* 118 */     n |= n >> 8;
/* 119 */     n |= n >> 16;
/* 120 */     n++;
/* 121 */     return n;
/*     */   }
/*     */   
/*     */   public static final int abs(int val) {
/* 125 */     int sign = val >> 31;
/* 126 */     return (val ^ sign) - sign;
/*     */   }
/*     */   
/*     */   public static final int golomb(int signedLevel) {
/* 130 */     if (signedLevel == 0)
/* 131 */       return 0; 
/* 132 */     return (abs(signedLevel) << 1) - ((signedLevel ^ 0xFFFFFFFF) >>> 31);
/*     */   }
/*     */   
/*     */   public static final int toSigned(int val, int sign) {
/* 136 */     return (val ^ sign) - sign;
/*     */   }
/*     */   
/*     */   public static final int sign(int val) {
/* 140 */     return -(val >> 31);
/*     */   }
/*     */   
/*     */   public static int wrap(int picNo, int maxFrames) {
/* 144 */     return (picNo < 0) ? (picNo + maxFrames) : ((picNo >= maxFrames) ? (picNo - maxFrames) : picNo);
/*     */   }
/*     */   
/*     */   public static int max3(int a, int b, int c) {
/* 148 */     return Math.max(Math.max(a, b), c);
/*     */   }
/*     */ }


/* Location:              C:\Users\rapha\Downloads\aurora.jar!\META-INF\jars\jcodec-0.2.5.jar!\org\jcodec\common\tools\MathUtil.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */