/*    */ package org.jcodec.common.tools;
/*    */ 
/*    */ import java.io.Closeable;
/*    */ import java.io.File;
/*    */ import java.io.IOException;
/*    */ import java.nio.ByteBuffer;
/*    */ import java.nio.channels.ReadableByteChannel;
/*    */ import java.nio.channels.WritableByteChannel;
/*    */ import org.jcodec.codecs.wav.WavHeader;
/*    */ import org.jcodec.common.AudioUtil;
/*    */ import org.jcodec.common.io.FileChannelWrapper;
/*    */ import org.jcodec.common.io.IOUtils;
/*    */ import org.jcodec.common.io.NIOUtils;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class WavMerge
/*    */ {
/*    */   public static void main1(String[] args) throws Exception {
/* 26 */     if (args.length < 3) {
/* 27 */       System.out.println("wavmerge <output wav> <input wav> .... <input wav>");
/* 28 */       System.exit(-1);
/*    */     } 
/* 30 */     File out = new File(args[0]);
/* 31 */     File[] ins = new File[args.length - 1];
/* 32 */     for (int i = 1; i < args.length; i++)
/* 33 */       ins[i - 1] = new File(args[i]); 
/* 34 */     merge(out, ins);
/*    */   }
/*    */   
/*    */   public static void merge(File result, File[] src) throws IOException {
/*    */     FileChannelWrapper fileChannelWrapper;
/* 39 */     WritableByteChannel out = null;
/* 40 */     ReadableByteChannel[] inputs = new ReadableByteChannel[src.length];
/* 41 */     WavHeader[] headers = new WavHeader[src.length];
/* 42 */     ByteBuffer[] ins = new ByteBuffer[src.length];
/*    */     try {
/* 44 */       int sampleSize = -1;
/* 45 */       for (int i = 0; i < src.length; i++) {
/* 46 */         inputs[i] = (ReadableByteChannel)NIOUtils.readableChannel(src[i]);
/* 47 */         WavHeader hdr = WavHeader.readChannel(inputs[i]);
/* 48 */         if (sampleSize != -1 && sampleSize != hdr.fmt.bitsPerSample)
/* 49 */           throw new RuntimeException("Input files have different sample sizes"); 
/* 50 */         sampleSize = hdr.fmt.bitsPerSample;
/* 51 */         headers[i] = hdr;
/* 52 */         ins[i] = ByteBuffer.allocate(hdr.getFormat().framesToBytes(4096));
/*    */       } 
/* 54 */       ByteBuffer outb = ByteBuffer.allocate(headers[0].getFormat().framesToBytes(4096) * src.length);
/*    */       
/* 56 */       WavHeader newHeader = WavHeader.multiChannelWav(headers);
/* 57 */       fileChannelWrapper = NIOUtils.writableChannel(result);
/* 58 */       newHeader.write((WritableByteChannel)fileChannelWrapper);
/*    */       
/* 60 */       boolean readOnce = true; while (true) {
/* 61 */         readOnce = false;
/* 62 */         for (int j = 0; j < ins.length; j++) {
/* 63 */           if (inputs[j] != null) {
/* 64 */             ins[j].clear();
/* 65 */             if (inputs[j].read(ins[j]) == -1) {
/* 66 */               NIOUtils.closeQuietly(inputs[j]);
/* 67 */               inputs[j] = null;
/*    */             } else {
/* 69 */               readOnce = true;
/* 70 */             }  ins[j].flip();
/*    */           } 
/*    */         } 
/* 73 */         if (!readOnce)
/*    */           break; 
/* 75 */         outb.clear();
/* 76 */         AudioUtil.interleave(headers[0].getFormat(), ins, outb);
/* 77 */         outb.flip();
/* 78 */         fileChannelWrapper.write(outb);
/*    */       } 
/*    */     } finally {
/* 81 */       IOUtils.closeQuietly((Closeable)fileChannelWrapper);
/* 82 */       for (ReadableByteChannel inputStream : inputs)
/* 83 */         IOUtils.closeQuietly(inputStream); 
/*    */     } 
/*    */   }
/*    */ }


/* Location:              C:\Users\rapha\Downloads\aurora.jar!\META-INF\jars\jcodec-0.2.5.jar!\org\jcodec\common\tools\WavMerge.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */