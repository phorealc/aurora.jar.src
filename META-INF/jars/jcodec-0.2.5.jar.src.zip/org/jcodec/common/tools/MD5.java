/*    */ package org.jcodec.common.tools;
/*    */ 
/*    */ import java.nio.ByteBuffer;
/*    */ import java.security.MessageDigest;
/*    */ import java.security.NoSuchAlgorithmException;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class MD5
/*    */ {
/*    */   public static String md5sumBytes(byte[] bytes) {
/* 16 */     MessageDigest md5 = getDigest();
/* 17 */     md5.update(bytes);
/* 18 */     return digestToString(md5.digest());
/*    */   }
/*    */   
/*    */   private static String digestToString(byte[] digest) {
/* 22 */     StringBuilder sb = new StringBuilder();
/* 23 */     for (int i = 0; i < digest.length; i++) {
/* 24 */       byte item = digest[i];
/* 25 */       int b = item & 0xFF;
/* 26 */       if (b < 16)
/* 27 */         sb.append("0"); 
/* 28 */       sb.append(Integer.toHexString(b));
/*    */     } 
/*    */     
/* 31 */     return sb.toString();
/*    */   }
/*    */   
/*    */   public static String md5sum(ByteBuffer bytes) {
/* 35 */     MessageDigest md5 = getDigest();
/* 36 */     md5.update(bytes);
/* 37 */     byte[] digest = md5.digest();
/* 38 */     return digestToString(digest);
/*    */   }
/*    */   
/*    */   public static MessageDigest getDigest() {
/*    */     MessageDigest md5;
/*    */     try {
/* 44 */       md5 = MessageDigest.getInstance("MD5");
/* 45 */     } catch (NoSuchAlgorithmException e) {
/* 46 */       throw new RuntimeException(e);
/*    */     } 
/* 48 */     return md5;
/*    */   }
/*    */ }


/* Location:              C:\Users\rapha\Downloads\aurora.jar!\META-INF\jars\jcodec-0.2.5.jar!\org\jcodec\common\tools\MD5.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */