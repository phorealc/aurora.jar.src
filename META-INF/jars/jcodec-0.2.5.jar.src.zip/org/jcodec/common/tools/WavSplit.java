/*    */ package org.jcodec.common.tools;
/*    */ 
/*    */ import java.io.File;
/*    */ import java.io.IOException;
/*    */ import java.nio.ByteBuffer;
/*    */ import java.nio.channels.ReadableByteChannel;
/*    */ import java.nio.channels.WritableByteChannel;
/*    */ import java.util.Arrays;
/*    */ import org.jcodec.codecs.wav.WavHeader;
/*    */ import org.jcodec.common.AudioFormat;
/*    */ import org.jcodec.common.AudioUtil;
/*    */ import org.jcodec.common.Preconditions;
/*    */ import org.jcodec.common.io.FileChannelWrapper;
/*    */ import org.jcodec.common.io.NIOUtils;
/*    */ import org.jcodec.common.io.SeekableByteChannel;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class WavSplit
/*    */ {
/* 29 */   public static final MainUtils.Flag FLAG_PATTERN = MainUtils.Flag.flag("pattern", "p", "Output file name pattern, i.e. out%02d.wav");
/* 30 */   private static final MainUtils.Flag[] ALL_FLAGS = new MainUtils.Flag[] { FLAG_PATTERN };
/*    */   public static void main1(String[] args) throws Exception {
/* 32 */     MainUtils.Cmd cmd = MainUtils.parseArguments(args, ALL_FLAGS);
/* 33 */     if (cmd.argsLength() < 1) {
/* 34 */       MainUtils.printHelp(ALL_FLAGS, Arrays.asList(new String[] { "filename.wav" }));
/* 35 */       System.exit(-1);
/*    */     } 
/*    */     
/* 38 */     File s = new File(args[0]);
/* 39 */     String pattern = cmd.getStringFlagD(FLAG_PATTERN, "c%02d.wav");
/*    */     
/* 41 */     WavHeader wavHeader = WavHeader.read(s);
/*    */     
/* 43 */     System.out.println("WAV: " + wavHeader.getFormat());
/*    */     
/* 45 */     Preconditions.checkState((2 == wavHeader.fmt.numChannels));
/* 46 */     int dataOffset = wavHeader.dataOffset;
/* 47 */     FileChannelWrapper is = NIOUtils.readableChannel(s);
/* 48 */     is.setPosition(dataOffset);
/*    */     
/* 50 */     int channels = wavHeader.getFormat().getChannels();
/* 51 */     SeekableByteChannel[] out = new SeekableByteChannel[channels]; int i;
/* 52 */     for (i = 0; i < channels; i++) {
/* 53 */       out[i] = (SeekableByteChannel)NIOUtils.writableChannel(new File(s.getParentFile(), String.format(pattern, new Object[] { Integer.valueOf(i) })));
/* 54 */       WavHeader.copyWithChannels(wavHeader, 1).write((WritableByteChannel)out[i]);
/*    */     } 
/*    */     
/* 57 */     copy(wavHeader.getFormat(), (ReadableByteChannel)is, out);
/*    */     
/* 59 */     for (i = 0; i < channels; i++) {
/* 60 */       out[i].close();
/*    */     }
/*    */   }
/*    */   
/*    */   private static void copy(AudioFormat format, ReadableByteChannel is, SeekableByteChannel[] out) throws IOException {
/* 65 */     ByteBuffer[] outs = new ByteBuffer[out.length];
/* 66 */     for (int i = 0; i < out.length; i++) {
/* 67 */       outs[i] = ByteBuffer.allocate(format.framesToBytes(4096));
/*    */     }
/* 69 */     ByteBuffer inb = ByteBuffer.allocate(format.framesToBytes(4096) * out.length);
/*    */     
/* 71 */     while (is.read(inb) != -1) {
/* 72 */       inb.flip();
/* 73 */       AudioUtil.deinterleave(format, inb, outs);
/* 74 */       inb.clear();
/* 75 */       for (int j = 0; j < out.length; j++) {
/* 76 */         outs[j].flip();
/* 77 */         out[j].write(outs[j]);
/* 78 */         outs[j].clear();
/*    */       } 
/*    */     } 
/*    */   }
/*    */ }


/* Location:              C:\Users\rapha\Downloads\aurora.jar!\META-INF\jars\jcodec-0.2.5.jar!\org\jcodec\common\tools\WavSplit.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */