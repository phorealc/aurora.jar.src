/*    */ package org.jcodec.common.tools;
/*    */ 
/*    */ import org.jcodec.common.model.ColorSpace;
/*    */ import org.jcodec.common.model.Picture;
/*    */ import org.jcodec.common.model.Rect;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class ImageOP
/*    */ {
/*    */   public static void subImageWithFillInt(int[] src, int width, int height, int[] dst, int dstW, int dstH, int offX, int offY) {
/* 27 */     int srcHeight = Math.min(height - offY, dstH);
/* 28 */     int srcWidth = Math.min(width - offX, dstW);
/* 29 */     int srcStride = width;
/*    */     
/* 31 */     int dstOff = 0, srcOff = offY * srcStride + offX;
/*    */     int i;
/* 33 */     for (i = 0; i < srcHeight; i++) {
/*    */       int j;
/* 35 */       for (j = 0; j < srcWidth; j++) {
/* 36 */         dst[dstOff + j] = src[srcOff + j];
/*    */       }
/* 38 */       int lastPix = dst[j - 1];
/* 39 */       for (; j < dstW; j++)
/* 40 */         dst[dstOff + j] = lastPix; 
/* 41 */       srcOff += srcStride;
/* 42 */       dstOff += dstW;
/*    */     } 
/* 44 */     int lastLine = dstOff - dstW;
/* 45 */     for (; i < dstH; i++) {
/* 46 */       System.arraycopy(dst, lastLine, dst, dstOff, dstW);
/* 47 */       dstOff += dstW;
/*    */     } 
/*    */   }
/*    */ 
/*    */   
/*    */   public static void subImageWithFill(byte[] src, int width, int height, byte[] dst, int dstW, int dstH, int offX, int offY) {
/* 53 */     int srcHeight = Math.min(height - offY, dstH);
/* 54 */     int srcWidth = Math.min(width - offX, dstW);
/* 55 */     int srcStride = width;
/*    */     
/* 57 */     int dstOff = 0, srcOff = offY * srcStride + offX;
/*    */     int i;
/* 59 */     for (i = 0; i < srcHeight; i++) {
/*    */       int j;
/* 61 */       for (j = 0; j < srcWidth; j++) {
/* 62 */         dst[dstOff + j] = src[srcOff + j];
/*    */       }
/* 64 */       byte lastPix = dst[j - 1];
/* 65 */       for (; j < dstW; j++)
/* 66 */         dst[dstOff + j] = lastPix; 
/* 67 */       srcOff += srcStride;
/* 68 */       dstOff += dstW;
/*    */     } 
/* 70 */     int lastLine = dstOff - dstW;
/* 71 */     for (; i < dstH; i++) {
/* 72 */       System.arraycopy(dst, lastLine, dst, dstOff, dstW);
/* 73 */       dstOff += dstW;
/*    */     } 
/*    */   }
/*    */   
/*    */   public static void subImageWithFillPic8(Picture _in, Picture out, Rect rect) {
/* 78 */     int width = _in.getWidth();
/* 79 */     int height = _in.getHeight();
/* 80 */     ColorSpace color = _in.getColor();
/* 81 */     byte[][] data = _in.getData();
/*    */     
/* 83 */     for (int i = 0; i < data.length; i++)
/* 84 */       subImageWithFill(data[i], width >> color.compWidth[i], height >> color.compHeight[i], out
/* 85 */           .getPlaneData(i), rect.getWidth() >> color.compWidth[i], rect
/* 86 */           .getHeight() >> color.compHeight[i], rect.getX() >> color.compWidth[i], rect
/* 87 */           .getY() >> color.compHeight[i]); 
/*    */   }
/*    */ }


/* Location:              C:\Users\rapha\Downloads\aurora.jar!\META-INF\jars\jcodec-0.2.5.jar!\org\jcodec\common\tools\ImageOP.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */