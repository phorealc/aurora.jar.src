/*     */ package org.jcodec.common.tools;
/*     */ 
/*     */ import java.io.File;
/*     */ import java.io.IOException;
/*     */ import java.io.InputStream;
/*     */ import java.io.PrintStream;
/*     */ import java.lang.reflect.Array;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Arrays;
/*     */ import java.util.Collections;
/*     */ import java.util.EnumSet;
/*     */ import java.util.HashMap;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import java.util.Properties;
/*     */ import java.util.regex.Matcher;
/*     */ import java.util.regex.Pattern;
/*     */ import org.jcodec.common.StringUtils;
/*     */ import org.jcodec.common.io.IOUtils;
/*     */ import org.jcodec.platform.Platform;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class MainUtils
/*     */ {
/*     */   private static final String KEY_GIT_REVISION = "git.commit.id.abbrev";
/*     */   private static final String JCODEC_LOG_SINK_COLOR = "jcodec.colorPrint";
/*     */   private static final String GIT_PROPERTIES = "git.properties";
/*  36 */   public static boolean isColorSupported = (System.console() != null || 
/*  37 */     Boolean.parseBoolean(System.getProperty("jcodec.colorPrint")));
/*     */   
/*     */   public enum FlagType {
/*  40 */     VOID, STRING, INT, LONG, DOUBLE, MULT, ENUM, ANY;
/*     */   }
/*     */   
/*     */   public static class Flag {
/*     */     private String longName;
/*     */     private String shortName;
/*     */     private String description;
/*     */     private MainUtils.FlagType type;
/*     */     
/*     */     public Flag(String longName, String shortName, String description, MainUtils.FlagType type) {
/*  50 */       this.longName = longName;
/*  51 */       this.shortName = shortName;
/*  52 */       this.description = description;
/*  53 */       this.type = type;
/*     */     }
/*     */     
/*     */     public static Flag flag(String longName, String shortName, String description) {
/*  57 */       return new Flag(longName, shortName, description, MainUtils.FlagType.ANY);
/*     */     }
/*     */     
/*     */     public String getLongName() {
/*  61 */       return this.longName;
/*     */     }
/*     */     
/*     */     public String getDescription() {
/*  65 */       return this.description;
/*     */     }
/*     */     
/*     */     public String getShortName() {
/*  69 */       return this.shortName;
/*     */     }
/*     */     
/*     */     public MainUtils.FlagType getType() {
/*  73 */       return this.type;
/*     */     }
/*     */   }
/*     */   
/*     */   public static class Cmd
/*     */   {
/*     */     public Map<String, String> longFlags;
/*     */     public Map<String, String> shortFlags;
/*     */     public String[] args;
/*     */     private Map<String, String>[] longArgFlags;
/*     */     private Map<String, String>[] shortArgFlags;
/*     */     
/*     */     public Cmd(Map<String, String> longFlags, Map<String, String> shortFlags, String[] args, Map<String, String>[] longArgFlags, Map<String, String>[] shortArgFlags) {
/*  86 */       this.args = args;
/*  87 */       this.longFlags = longFlags;
/*  88 */       this.shortFlags = shortFlags;
/*  89 */       this.longArgFlags = longArgFlags;
/*  90 */       this.shortArgFlags = shortArgFlags;
/*     */     }
/*     */ 
/*     */     
/*     */     private Long getLongFlagInternal(Map<String, String> longFlags, Map<String, String> shortFlags, MainUtils.Flag flag, Long defaultValue) {
/*  95 */       return longFlags.containsKey(flag.getLongName()) ? new Long(longFlags.get(flag.getLongName())) : (
/*  96 */         shortFlags.containsKey(flag.getShortName()) ? new Long(shortFlags.get(flag.getShortName())) : defaultValue);
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     private Integer getIntegerFlagInternal(Map<String, String> longFlags, Map<String, String> shortFlags, MainUtils.Flag flag, Integer defaultValue) {
/* 102 */       return longFlags.containsKey(flag.getLongName()) ? new Integer(longFlags.get(flag.getLongName())) : (
/* 103 */         shortFlags.containsKey(flag.getShortName()) ? new Integer(shortFlags.get(flag.getShortName())) : defaultValue);
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     private Boolean getBooleanFlagInternal(Map<String, String> longFlags, Map<String, String> shortFlags, MainUtils.Flag flag, Boolean defaultValue) {
/* 109 */       return Boolean.valueOf(longFlags.containsKey(flag.getLongName()) ? (
/* 110 */           !"false".equalsIgnoreCase(longFlags.get(flag.getLongName()))) : (
/* 111 */           shortFlags.containsKey(flag.getShortName()) ? (
/* 112 */           !"false".equalsIgnoreCase(shortFlags.get(flag.getShortName()))) : defaultValue.booleanValue()));
/*     */     }
/*     */ 
/*     */     
/*     */     private Double getDoubleFlagInternal(Map<String, String> longFlags, Map<String, String> shortFlags, MainUtils.Flag flag, Double defaultValue) {
/* 117 */       return longFlags.containsKey(flag.getLongName()) ? new Double(longFlags.get(flag.getLongName())) : (
/* 118 */         shortFlags.containsKey(flag.getShortName()) ? new Double(shortFlags.get(flag.getShortName())) : defaultValue);
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     private String getStringFlagInternal(Map<String, String> longFlags, Map<String, String> shortFlags, MainUtils.Flag flag, String defaultValue) {
/* 124 */       return longFlags.containsKey(flag.getLongName()) ? longFlags.get(flag.getLongName()) : (
/* 125 */         shortFlags.containsKey(flag.getShortName()) ? shortFlags.get(flag.getShortName()) : defaultValue);
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     private int[] getMultiIntegerFlagInternal(Map<String, String> longFlags, Map<String, String> shortFlags, MainUtils.Flag flag, int[] defaultValue) {
/*     */       String flagValue;
/* 132 */       if (longFlags.containsKey(flag.getLongName())) {
/* 133 */         flagValue = longFlags.get(flag.getLongName());
/* 134 */       } else if (shortFlags.containsKey(flag.getShortName())) {
/* 135 */         flagValue = shortFlags.get(flag.getShortName());
/*     */       } else {
/* 137 */         return defaultValue;
/* 138 */       }  String[] split = StringUtils.splitS(flagValue, ",");
/* 139 */       int[] result = new int[split.length];
/* 140 */       for (int i = 0; i < split.length; i++)
/* 141 */         result[i] = Integer.parseInt(split[i]); 
/* 142 */       return result;
/*     */     }
/*     */ 
/*     */     
/*     */     private <T extends Enum<T>> T getEnumFlagInternal(Map<String, String> longFlags, Map<String, String> shortFlags, MainUtils.Flag flag, T defaultValue, Class<T> class1) {
/*     */       String flagValue;
/* 148 */       if (longFlags.containsKey(flag.getLongName())) {
/* 149 */         flagValue = longFlags.get(flag.getLongName());
/* 150 */       } else if (shortFlags.containsKey(flag.getShortName())) {
/* 151 */         flagValue = shortFlags.get(flag.getShortName());
/*     */       } else {
/* 153 */         return defaultValue;
/*     */       } 
/* 155 */       String strVal = flagValue.toLowerCase();
/* 156 */       EnumSet<T> allOf = EnumSet.allOf(class1);
/* 157 */       for (Enum enum_ : allOf) {
/* 158 */         if (enum_.name().toLowerCase().equals(strVal))
/* 159 */           return (T)enum_; 
/*     */       } 
/* 161 */       return null;
/*     */     }
/*     */     
/*     */     public Long getLongFlagD(MainUtils.Flag flagName, Long defaultValue) {
/* 165 */       return getLongFlagInternal(this.longFlags, this.shortFlags, flagName, defaultValue);
/*     */     }
/*     */     
/*     */     public Long getLongFlag(MainUtils.Flag flagName) {
/* 169 */       return getLongFlagInternal(this.longFlags, this.shortFlags, flagName, null);
/*     */     }
/*     */     
/*     */     public Long getLongFlagID(int arg, MainUtils.Flag flagName, Long defaultValue) {
/* 173 */       return getLongFlagInternal(this.longArgFlags[arg], this.shortArgFlags[arg], flagName, defaultValue);
/*     */     }
/*     */     
/*     */     public Long getLongFlagI(int arg, MainUtils.Flag flagName) {
/* 177 */       return getLongFlagInternal(this.longArgFlags[arg], this.shortArgFlags[arg], flagName, null);
/*     */     }
/*     */     
/*     */     public Integer getIntegerFlagD(MainUtils.Flag flagName, Integer defaultValue) {
/* 181 */       return getIntegerFlagInternal(this.longFlags, this.shortFlags, flagName, defaultValue);
/*     */     }
/*     */     
/*     */     public Integer getIntegerFlag(MainUtils.Flag flagName) {
/* 185 */       return getIntegerFlagInternal(this.longFlags, this.shortFlags, flagName, null);
/*     */     }
/*     */     
/*     */     public Integer getIntegerFlagID(int arg, MainUtils.Flag flagName, Integer defaultValue) {
/* 189 */       return getIntegerFlagInternal(this.longArgFlags[arg], this.shortArgFlags[arg], flagName, defaultValue);
/*     */     }
/*     */     
/*     */     public Integer getIntegerFlagI(int arg, MainUtils.Flag flagName) {
/* 193 */       return getIntegerFlagInternal(this.longArgFlags[arg], this.shortArgFlags[arg], flagName, null);
/*     */     }
/*     */     
/*     */     public Boolean getBooleanFlagD(MainUtils.Flag flagName, Boolean defaultValue) {
/* 197 */       return getBooleanFlagInternal(this.longFlags, this.shortFlags, flagName, defaultValue);
/*     */     }
/*     */     
/*     */     public Boolean getBooleanFlag(MainUtils.Flag flagName) {
/* 201 */       return getBooleanFlagInternal(this.longFlags, this.shortFlags, flagName, Boolean.valueOf(false));
/*     */     }
/*     */     
/*     */     public Boolean getBooleanFlagID(int arg, MainUtils.Flag flagName, Boolean defaultValue) {
/* 205 */       return getBooleanFlagInternal(this.longArgFlags[arg], this.shortArgFlags[arg], flagName, defaultValue);
/*     */     }
/*     */     
/*     */     public Boolean getBooleanFlagI(int arg, MainUtils.Flag flagName) {
/* 209 */       return getBooleanFlagInternal(this.longArgFlags[arg], this.shortArgFlags[arg], flagName, Boolean.valueOf(false));
/*     */     }
/*     */     
/*     */     public Double getDoubleFlagD(MainUtils.Flag flagName, Double defaultValue) {
/* 213 */       return getDoubleFlagInternal(this.longFlags, this.shortFlags, flagName, defaultValue);
/*     */     }
/*     */     
/*     */     public Double getDoubleFlag(MainUtils.Flag flagName) {
/* 217 */       return getDoubleFlagInternal(this.longFlags, this.shortFlags, flagName, null);
/*     */     }
/*     */     
/*     */     public Double getDoubleFlagID(int arg, MainUtils.Flag flagName, Double defaultValue) {
/* 221 */       return getDoubleFlagInternal(this.longArgFlags[arg], this.shortArgFlags[arg], flagName, defaultValue);
/*     */     }
/*     */     
/*     */     public Double getDoubleFlagI(int arg, MainUtils.Flag flagName) {
/* 225 */       return getDoubleFlagInternal(this.longArgFlags[arg], this.shortArgFlags[arg], flagName, null);
/*     */     }
/*     */     
/*     */     public String getStringFlagD(MainUtils.Flag flagName, String defaultValue) {
/* 229 */       return getStringFlagInternal(this.longFlags, this.shortFlags, flagName, defaultValue);
/*     */     }
/*     */     
/*     */     public String getStringFlag(MainUtils.Flag flagName) {
/* 233 */       return getStringFlagInternal(this.longFlags, this.shortFlags, flagName, null);
/*     */     }
/*     */     
/*     */     public String getStringFlagID(int arg, MainUtils.Flag flagName, String defaultValue) {
/* 237 */       return getStringFlagInternal(this.longArgFlags[arg], this.shortArgFlags[arg], flagName, defaultValue);
/*     */     }
/*     */     
/*     */     public String getStringFlagI(int arg, MainUtils.Flag flagName) {
/* 241 */       return getStringFlagInternal(this.longArgFlags[arg], this.shortArgFlags[arg], flagName, null);
/*     */     }
/*     */     
/*     */     public int[] getMultiIntegerFlagD(MainUtils.Flag flagName, int[] defaultValue) {
/* 245 */       return getMultiIntegerFlagInternal(this.longFlags, this.shortFlags, flagName, defaultValue);
/*     */     }
/*     */     
/*     */     public int[] getMultiIntegerFlag(MainUtils.Flag flagName) {
/* 249 */       return getMultiIntegerFlagInternal(this.longFlags, this.shortFlags, flagName, new int[0]);
/*     */     }
/*     */     
/*     */     public int[] getMultiIntegerFlagID(int arg, MainUtils.Flag flagName, int[] defaultValue) {
/* 253 */       return getMultiIntegerFlagInternal(this.longArgFlags[arg], this.shortArgFlags[arg], flagName, defaultValue);
/*     */     }
/*     */     
/*     */     public int[] getMultiIntegerFlagI(int arg, MainUtils.Flag flagName) {
/* 257 */       return getMultiIntegerFlagInternal(this.longArgFlags[arg], this.shortArgFlags[arg], flagName, new int[0]);
/*     */     }
/*     */     
/*     */     public <T extends Enum<T>> T getEnumFlagD(MainUtils.Flag flagName, T defaultValue, Class<T> class1) {
/* 261 */       return getEnumFlagInternal(this.longFlags, this.shortFlags, flagName, defaultValue, class1);
/*     */     }
/*     */     
/*     */     public <T extends Enum<T>> T getEnumFlag(MainUtils.Flag flagName, Class<T> class1) {
/* 265 */       return getEnumFlagInternal(this.longFlags, this.shortFlags, flagName, null, class1);
/*     */     }
/*     */     
/*     */     public <T extends Enum<T>> T getEnumFlagID(int arg, MainUtils.Flag flagName, T defaultValue, Class<T> class1) {
/* 269 */       return getEnumFlagInternal(this.longArgFlags[arg], this.shortArgFlags[arg], flagName, defaultValue, class1);
/*     */     }
/*     */     
/*     */     public <T extends Enum<T>> T getEnumFlagI(int arg, MainUtils.Flag flagName, Class<T> class1) {
/* 273 */       return getEnumFlagInternal(this.longArgFlags[arg], this.shortArgFlags[arg], flagName, null, class1);
/*     */     }
/*     */     
/*     */     public String getArg(int i) {
/* 277 */       return (i < this.args.length) ? this.args[i] : null;
/*     */     }
/*     */     
/*     */     public int argsLength() {
/* 281 */       return this.args.length;
/*     */     }
/*     */     
/*     */     public void popArg() {
/* 285 */       this.args = (String[])Platform.copyOfRangeO((Object[])this.args, 1, this.args.length);
/*     */     }
/*     */   }
/*     */ 
/*     */   
/* 290 */   private static Pattern flagPattern = Pattern.compile("^--([^=]+)=(.*)$");
/*     */   
/*     */   public static Cmd parseArguments(String[] args, Flag[] flags) {
/* 293 */     Map<String, String> longFlags = new HashMap<String, String>();
/* 294 */     Map<String, String> shortFlags = new HashMap<String, String>();
/* 295 */     Map<String, String> allLongFlags = new HashMap<String, String>();
/* 296 */     Map<String, String> allShortFlags = new HashMap<String, String>();
/* 297 */     List<String> outArgs = new ArrayList<String>();
/* 298 */     List<Map<String, String>> argLongFlags = new ArrayList<Map<String, String>>();
/* 299 */     List<Map<String, String>> argShortFlags = new ArrayList<Map<String, String>>();
/* 300 */     int arg = 0;
/* 301 */     for (; arg < args.length; arg++) {
/* 302 */       if (args[arg].startsWith("--")) {
/* 303 */         Matcher matcher = flagPattern.matcher(args[arg]);
/* 304 */         if (matcher.matches()) {
/* 305 */           longFlags.put(matcher.group(1), matcher.group(2));
/*     */         } else {
/* 307 */           longFlags.put(args[arg].substring(2), "true");
/*     */         } 
/* 309 */       } else if (args[arg].startsWith("-")) {
/* 310 */         String shortName = args[arg].substring(1);
/* 311 */         boolean found = false;
/* 312 */         for (Flag flag : flags) {
/* 313 */           if (shortName.equals(flag.getShortName())) {
/* 314 */             found = true;
/* 315 */             if (flag.getType() != FlagType.VOID) {
/* 316 */               shortFlags.put(shortName, args[++arg]);
/*     */             } else {
/* 318 */               shortFlags.put(shortName, "true");
/*     */             } 
/*     */           } 
/* 321 */         }  if (!found)
/* 322 */           arg++; 
/*     */       } else {
/* 324 */         allLongFlags.putAll(longFlags);
/* 325 */         allShortFlags.putAll(shortFlags);
/* 326 */         outArgs.add(args[arg]);
/* 327 */         argLongFlags.add(longFlags);
/* 328 */         argShortFlags.add(shortFlags);
/* 329 */         longFlags = new HashMap<String, String>();
/* 330 */         shortFlags = new HashMap<String, String>();
/*     */       } 
/*     */     } 
/*     */     
/* 334 */     return new Cmd(allLongFlags, allShortFlags, outArgs.<String>toArray(new String[0]), argLongFlags
/* 335 */         .<Map<String, String>>toArray((Map<String, String>[])Array.newInstance(longFlags.getClass(), 0)), argShortFlags
/* 336 */         .<Map<String, String>>toArray((Map<String, String>[])Array.newInstance(shortFlags.getClass(), 0)));
/*     */   }
/*     */   
/*     */   public static void printHelpArgs(Flag[] flags, String[] args) {
/* 340 */     printHelpOut(System.out, "", flags, Arrays.asList(args));
/*     */   }
/*     */   
/*     */   public static void printHelp(Flag[] flags, List<String> params) {
/* 344 */     printHelpOut(System.out, "", flags, params);
/*     */   }
/*     */   
/*     */   public static void printHelpNoFlags(String... arguments) {
/* 348 */     printHelpOut(System.out, "", new Flag[0], Arrays.asList(arguments));
/*     */   }
/*     */   
/*     */   public static void printHelpCmdVa(String command, Flag[] flags, String args) {
/* 352 */     printHelpOut(System.out, command, flags, Collections.singletonList(args));
/*     */   }
/*     */   
/*     */   public static void printHelpCmd(String command, Flag[] flags, List<String> params) {
/* 356 */     printHelpOut(System.out, command, flags, params);
/*     */   }
/*     */   
/*     */   private static String getGitRevision() {
/* 360 */     InputStream is = null;
/*     */     
/* 362 */     try { is = Thread.currentThread().getContextClassLoader().getResourceAsStream("git.properties");
/* 363 */       if (is == null)
/* 364 */         return null; 
/* 365 */       Properties properties = new Properties();
/* 366 */       properties.load(is);
/* 367 */       return (String)properties.get("git.commit.id.abbrev"); }
/* 368 */     catch (IOException iOException) {  }
/*     */     finally
/* 370 */     { IOUtils.closeQuietly(is); }
/*     */     
/* 372 */     return null;
/*     */   }
/*     */   
/*     */   public static void printHelpOut(PrintStream out, String command, Flag[] flags, List<String> params) {
/* 376 */     String version = MainUtils.class.getPackage().getImplementationVersion();
/* 377 */     String gitRevision = getGitRevision();
/* 378 */     if (command == null || command.isEmpty())
/* 379 */       command = "jcodec"; 
/* 380 */     if (gitRevision != null || version != null) {
/* 381 */       out.println(command + bold(((version != null) ? (" v." + version) : "") + ((gitRevision != null) ? (" rev. " + gitRevision) : "")));
/*     */       
/* 383 */       out.println();
/*     */     } 
/* 385 */     out.print(bold("Syntax: " + command));
/* 386 */     StringBuilder sample = new StringBuilder();
/* 387 */     StringBuilder detail = new StringBuilder();
/* 388 */     for (Flag flag : flags) {
/* 389 */       sample.append(" [");
/* 390 */       detail.append("\t");
/* 391 */       if (flag.getLongName() != null) {
/* 392 */         sample.append(bold(color("--" + flag.getLongName() + "=<value>", ANSIColor.MAGENTA)));
/* 393 */         detail.append(bold(color("--" + flag.getLongName(), ANSIColor.MAGENTA)));
/*     */       } 
/* 395 */       if (flag.getShortName() != null) {
/* 396 */         if (flag.getLongName() != null) {
/* 397 */           sample.append(" (");
/* 398 */           detail.append(" (");
/*     */         } 
/* 400 */         sample.append(bold(color("-" + flag.getShortName() + " <value>", ANSIColor.MAGENTA)));
/* 401 */         detail.append(bold(color("-" + flag.getShortName(), ANSIColor.MAGENTA)));
/* 402 */         if (flag.getLongName() != null) {
/* 403 */           sample.append(")");
/* 404 */           detail.append(")");
/*     */         } 
/*     */       } 
/* 407 */       sample.append("]");
/* 408 */       detail.append("\t\t" + flag.getDescription() + "\n");
/*     */     } 
/* 410 */     for (String param : params) {
/* 411 */       if (param.charAt(0) != '?') {
/* 412 */         sample.append(bold(" <" + param + ">")); continue;
/*     */       } 
/* 414 */       sample.append(bold(" [" + param.substring(1) + "]"));
/*     */     } 
/* 416 */     out.println(sample);
/* 417 */     out.println(bold("Where:"));
/* 418 */     out.println(detail);
/*     */   }
/*     */   
/*     */   public enum ANSIColor {
/* 422 */     BLACK, RED, GREEN, BROWN, BLUE, MAGENTA, CYAN, GREY;
/*     */   }
/*     */   
/*     */   public static String bold(String str) {
/* 426 */     return isColorSupported ? ("\033[1m" + str + "\033[0m") : str;
/*     */   }
/*     */   
/*     */   public static String colorString(String str, String placeholder) {
/* 430 */     return isColorSupported ? ("\033[" + placeholder + "m" + str + "\033[0m") : str;
/*     */   }
/*     */   
/*     */   public static String color(String str, ANSIColor fg) {
/* 434 */     return isColorSupported ? ("\033[" + (30 + (fg.ordinal() & 0x7)) + "m" + str + "\033[0m") : str;
/*     */   }
/*     */   
/*     */   public static String colorBright(String str, ANSIColor fg, boolean bright) {
/* 438 */     return isColorSupported ? ("\033[" + (30 + (fg.ordinal() & 0x7)) + ";" + (bright ? 1 : 2) + "m" + str + "\033[0m") : str;
/*     */   }
/*     */ 
/*     */   
/*     */   public static String color3(String str, ANSIColor fg, ANSIColor bg) {
/* 443 */     return isColorSupported ? ("\033[" + (30 + (fg
/* 444 */       .ordinal() & 0x7)) + ";" + (40 + (bg.ordinal() & 0x7)) + ";1m" + str + "\033[0m") : str;
/*     */   }
/*     */ 
/*     */   
/*     */   public static String color4(String str, ANSIColor fg, ANSIColor bg, boolean bright) {
/* 449 */     return isColorSupported ? ("\033[" + (30 + (fg.ordinal() & 0x7)) + ";" + (40 + (bg.ordinal() & 0x7)) + ";" + (bright ? 1 : 2) + "m" + str + "\033[0m") : str;
/*     */   }
/*     */ 
/*     */   
/*     */   public static File tildeExpand(String path) {
/* 454 */     if (path.startsWith("~")) {
/* 455 */       path = path.replaceFirst("~", System.getProperty("user.home"));
/*     */     }
/* 457 */     return new File(path);
/*     */   }
/*     */ }


/* Location:              C:\Users\rapha\Downloads\aurora.jar!\META-INF\jars\jcodec-0.2.5.jar!\org\jcodec\common\tools\MainUtils.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */