/*     */ package org.jcodec.common.tools;
/*     */ 
/*     */ import java.lang.reflect.Array;
/*     */ import java.lang.reflect.Method;
/*     */ import java.lang.reflect.Modifier;
/*     */ import java.nio.ByteBuffer;
/*     */ import java.util.ArrayList;
/*     */ import java.util.HashSet;
/*     */ import java.util.Iterator;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import java.util.Set;
/*     */ import org.jcodec.common.IntArrayList;
/*     */ import org.jcodec.common.io.NIOUtils;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ToJSON
/*     */ {
/*  33 */   private static final Set<Class> primitive = (Set)new HashSet<Class<?>>();
/*  34 */   private static final Set<String> omitMethods = new HashSet<String>();
/*     */   
/*     */   static {
/*  37 */     primitive.add(Boolean.class);
/*  38 */     primitive.add(Byte.class);
/*  39 */     primitive.add(Short.class);
/*  40 */     primitive.add(Integer.class);
/*  41 */     primitive.add(Long.class);
/*  42 */     primitive.add(Float.class);
/*  43 */     primitive.add(Double.class);
/*  44 */     primitive.add(Character.class);
/*     */ 
/*     */ 
/*     */     
/*  48 */     omitMethods.add("getClass");
/*  49 */     omitMethods.add("get");
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static String toJSON(Object obj) {
/*  59 */     StringBuilder builder = new StringBuilder();
/*  60 */     IntArrayList stack = IntArrayList.createIntArrayList();
/*  61 */     toJSONSub(obj, stack, builder);
/*  62 */     return builder.toString();
/*     */   }
/*     */   
/*     */   private static void toJSONSub(Object obj, IntArrayList stack, StringBuilder builder) {
/*  66 */     if (obj == null) {
/*  67 */       builder.append("null");
/*     */       
/*     */       return;
/*     */     } 
/*  71 */     String className = obj.getClass().getName();
/*  72 */     if (className.startsWith("java.lang") && !className.equals("java.lang.String")) {
/*  73 */       builder.append("null");
/*     */       
/*     */       return;
/*     */     } 
/*  77 */     int id = System.identityHashCode(obj);
/*  78 */     if (stack.contains(id)) {
/*  79 */       builder.append("null");
/*     */       return;
/*     */     } 
/*  82 */     stack.push(id);
/*     */     
/*  84 */     if (obj instanceof ByteBuffer) {
/*  85 */       obj = NIOUtils.toArray((ByteBuffer)obj);
/*     */     }
/*  87 */     if (obj == null) {
/*  88 */       builder.append("null");
/*  89 */     } else if (obj instanceof String) {
/*  90 */       builder.append("\"");
/*  91 */       escape((String)obj, builder);
/*  92 */       builder.append("\"");
/*  93 */     } else if (obj instanceof Map) {
/*  94 */       Iterator<Map.Entry> it = ((Map)obj).entrySet().iterator();
/*  95 */       builder.append("{");
/*  96 */       while (it.hasNext()) {
/*  97 */         Map.Entry e = it.next();
/*  98 */         builder.append("\"");
/*  99 */         builder.append(e.getKey());
/* 100 */         builder.append("\":");
/* 101 */         toJSONSub(e.getValue(), stack, builder);
/* 102 */         if (it.hasNext())
/* 103 */           builder.append(","); 
/*     */       } 
/* 105 */       builder.append("}");
/* 106 */     } else if (obj instanceof Iterable) {
/* 107 */       Iterator it = ((Iterable)obj).iterator();
/* 108 */       builder.append("[");
/* 109 */       while (it.hasNext()) {
/* 110 */         toJSONSub(it.next(), stack, builder);
/* 111 */         if (it.hasNext())
/* 112 */           builder.append(","); 
/*     */       } 
/* 114 */       builder.append("]");
/* 115 */     } else if (obj instanceof Object[]) {
/* 116 */       builder.append("[");
/* 117 */       int len = Array.getLength(obj);
/* 118 */       for (int i = 0; i < len; i++) {
/* 119 */         toJSONSub(Array.get(obj, i), stack, builder);
/* 120 */         if (i < len - 1)
/* 121 */           builder.append(","); 
/*     */       } 
/* 123 */       builder.append("]");
/* 124 */     } else if (obj instanceof long[]) {
/* 125 */       long[] a = (long[])obj;
/* 126 */       builder.append("[");
/* 127 */       for (int i = 0; i < a.length; i++) {
/* 128 */         builder.append(String.format("0x%016x", new Object[] { Long.valueOf(a[i]) }));
/* 129 */         if (i < a.length - 1)
/* 130 */           builder.append(","); 
/*     */       } 
/* 132 */       builder.append("]");
/* 133 */     } else if (obj instanceof int[]) {
/* 134 */       int[] a = (int[])obj;
/* 135 */       builder.append("[");
/* 136 */       for (int i = 0; i < a.length; i++) {
/* 137 */         builder.append(String.format("0x%08x", new Object[] { Integer.valueOf(a[i]) }));
/* 138 */         if (i < a.length - 1)
/* 139 */           builder.append(","); 
/*     */       } 
/* 141 */       builder.append("]");
/* 142 */     } else if (obj instanceof float[]) {
/* 143 */       float[] a = (float[])obj;
/* 144 */       builder.append("[");
/* 145 */       for (int i = 0; i < a.length; i++) {
/* 146 */         builder.append(String.format("%.3f", new Object[] { Float.valueOf(a[i]) }));
/* 147 */         if (i < a.length - 1)
/* 148 */           builder.append(","); 
/*     */       } 
/* 150 */       builder.append("]");
/* 151 */     } else if (obj instanceof double[]) {
/* 152 */       double[] a = (double[])obj;
/* 153 */       builder.append("[");
/* 154 */       for (int i = 0; i < a.length; i++) {
/* 155 */         builder.append(String.format("%.6f", new Object[] { Double.valueOf(a[i]) }));
/* 156 */         if (i < a.length - 1)
/* 157 */           builder.append(","); 
/*     */       } 
/* 159 */       builder.append("]");
/* 160 */     } else if (obj instanceof short[]) {
/* 161 */       short[] a = (short[])obj;
/* 162 */       builder.append("[");
/* 163 */       for (int i = 0; i < a.length; i++) {
/* 164 */         builder.append(String.format("0x%04x", new Object[] { Short.valueOf(a[i]) }));
/* 165 */         if (i < a.length - 1)
/* 166 */           builder.append(","); 
/*     */       } 
/* 168 */       builder.append("]");
/* 169 */     } else if (obj instanceof byte[]) {
/* 170 */       byte[] a = (byte[])obj;
/* 171 */       builder.append("[");
/* 172 */       for (int i = 0; i < a.length; i++) {
/* 173 */         builder.append(String.format("0x%02x", new Object[] { Byte.valueOf(a[i]) }));
/* 174 */         if (i < a.length - 1)
/* 175 */           builder.append(","); 
/*     */       } 
/* 177 */       builder.append("]");
/* 178 */     } else if (obj instanceof boolean[]) {
/* 179 */       boolean[] a = (boolean[])obj;
/* 180 */       builder.append("[");
/* 181 */       for (int i = 0; i < a.length; i++) {
/* 182 */         builder.append(a[i]);
/* 183 */         if (i < a.length - 1)
/* 184 */           builder.append(","); 
/*     */       } 
/* 186 */       builder.append("]");
/* 187 */     } else if (obj.getClass().isEnum()) {
/* 188 */       builder.append(String.valueOf(obj));
/*     */     } else {
/* 190 */       builder.append("{");
/* 191 */       Method[] methods = obj.getClass().getMethods();
/* 192 */       List<Method> filteredMethods = new ArrayList<Method>();
/* 193 */       for (Method method : methods) {
/* 194 */         if (!omitMethods.contains(method.getName()) && isGetter(method))
/*     */         {
/* 196 */           filteredMethods.add(method); } 
/*     */       } 
/* 198 */       Iterator<Method> iterator = filteredMethods.iterator();
/* 199 */       while (iterator.hasNext()) {
/* 200 */         Method method = iterator.next();
/* 201 */         String name = toName(method);
/* 202 */         invoke(obj, stack, builder, method, name);
/* 203 */         if (iterator.hasNext())
/* 204 */           builder.append(","); 
/*     */       } 
/* 206 */       builder.append("}");
/*     */     } 
/*     */     
/* 209 */     stack.pop();
/*     */   }
/*     */   
/*     */   private static void invoke(Object obj, IntArrayList stack, StringBuilder builder, Method method, String name) {
/*     */     try {
/* 214 */       Object invoke = method.invoke(obj, new Object[0]);
/* 215 */       builder.append('"');
/* 216 */       builder.append(name);
/* 217 */       builder.append("\":");
/* 218 */       if (invoke != null && primitive.contains(invoke.getClass()))
/* 219 */       { builder.append(invoke); }
/*     */       else
/* 221 */       { toJSONSub(invoke, stack, builder); } 
/* 222 */     } catch (Exception exception) {}
/*     */   }
/*     */ 
/*     */   
/*     */   private static void escape(String invoke, StringBuilder sb) {
/* 227 */     char[] ch = invoke.toCharArray();
/* 228 */     for (char c : ch) {
/* 229 */       if (c < ' ') {
/* 230 */         sb.append(String.format("\\%02x", new Object[] { Integer.valueOf(c) }));
/*     */       } else {
/* 232 */         sb.append(c);
/*     */       } 
/*     */     } 
/*     */   }
/*     */   private static String toName(Method method) {
/* 237 */     if (!isGetter(method)) {
/* 238 */       throw new IllegalArgumentException("Not a getter");
/*     */     }
/* 240 */     char[] name = method.getName().toCharArray();
/* 241 */     int ind = (name[0] == 'g') ? 3 : 2;
/* 242 */     name[ind] = Character.toLowerCase(name[ind]);
/* 243 */     return new String(name, ind, name.length - ind);
/*     */   }
/*     */   
/*     */   private static boolean isGetter(Method method) {
/* 247 */     if (!Modifier.isPublic(method.getModifiers()))
/* 248 */       return false; 
/* 249 */     if (!method.getName().startsWith("get") && (
/* 250 */       !method.getName().startsWith("is") || method.getReturnType() != boolean.class))
/* 251 */       return false; 
/* 252 */     if ((method.getParameterTypes()).length != 0) {
/* 253 */       return false;
/*     */     }
/*     */     
/* 256 */     return true;
/*     */   }
/*     */ }


/* Location:              C:\Users\rapha\Downloads\aurora.jar!\META-INF\jars\jcodec-0.2.5.jar!\org\jcodec\common\tools\ToJSON.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */