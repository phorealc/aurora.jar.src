/*    */ package org.jcodec.common;
/*    */ 
/*    */ import java.nio.ByteBuffer;
/*    */ import org.jcodec.common.model.ColorSpace;
/*    */ import org.jcodec.common.model.Picture;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public abstract class VideoEncoder
/*    */ {
/*    */   public abstract EncodedFrame encodeFrame(Picture paramPicture, ByteBuffer paramByteBuffer);
/*    */   
/*    */   public abstract ColorSpace[] getSupportedColorSpaces();
/*    */   
/*    */   public abstract int estimateBufferSize(Picture paramPicture);
/*    */   
/*    */   public static class EncodedFrame
/*    */   {
/*    */     private ByteBuffer data;
/*    */     private boolean keyFrame;
/*    */     
/*    */     public EncodedFrame(ByteBuffer data, boolean keyFrame) {
/* 27 */       this.data = data;
/* 28 */       this.keyFrame = keyFrame;
/*    */     }
/*    */     
/*    */     public ByteBuffer getData() {
/* 32 */       return this.data;
/*    */     }
/*    */     public boolean isKeyFrame() {
/* 35 */       return this.keyFrame;
/*    */     }
/*    */   }
/*    */ }


/* Location:              C:\Users\rapha\Downloads\aurora.jar!\META-INF\jars\jcodec-0.2.5.jar!\org\jcodec\common\VideoEncoder.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */