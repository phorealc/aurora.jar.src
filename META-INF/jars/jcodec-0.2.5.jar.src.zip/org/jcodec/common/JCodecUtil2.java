/*    */ package org.jcodec.common;
/*    */ 
/*    */ import java.nio.ByteBuffer;
/*    */ import org.jcodec.common.tools.MathUtil;
/*    */ import org.jcodec.platform.Platform;
/*    */ 
/*    */ public class JCodecUtil2
/*    */ {
/*    */   public static void writeBER32(ByteBuffer buffer, int value) {
/* 10 */     buffer.put((byte)(value >> 21 | 0x80));
/* 11 */     buffer.put((byte)(value >> 14 | 0x80));
/* 12 */     buffer.put((byte)(value >> 7 | 0x80));
/* 13 */     buffer.put((byte)(value & 0x7F));
/*    */   }
/*    */   
/*    */   public static int readBER32(ByteBuffer input) {
/* 17 */     int size = 0;
/* 18 */     for (int i = 0; i < 4; i++) {
/* 19 */       byte b = input.get();
/* 20 */       size = size << 7 | b & Byte.MAX_VALUE;
/* 21 */       if ((b & 0xFF) >> 7 == 0)
/*    */         break; 
/*    */     } 
/* 24 */     return size;
/*    */   }
/*    */   
/*    */   public static void writeBER32Var(ByteBuffer bb, int value) {
/* 28 */     for (int i = 0, bits = MathUtil.log2(value); i < 4 && bits > 0; i++) {
/* 29 */       bits -= 7;
/* 30 */       int out = value >> bits;
/* 31 */       if (bits > 0)
/* 32 */         out |= 0x80; 
/* 33 */       bb.put((byte)out);
/*    */     } 
/*    */   }
/*    */   
/*    */   public static byte[] asciiString(String fourcc) {
/* 38 */     return Platform.getBytes(fourcc);
/*    */   }
/*    */   
/*    */   public static int[] getAsIntArray(ByteBuffer yuv, int size) {
/* 42 */     byte[] b = new byte[size];
/* 43 */     int[] result = new int[size];
/* 44 */     yuv.get(b);
/* 45 */     for (int i = 0; i < b.length; i++) {
/* 46 */       result[i] = b[i] & 0xFF;
/*    */     }
/* 48 */     return result;
/*    */   }
/*    */   
/*    */   public static String removeExtension(String name) {
/* 52 */     if (name == null)
/* 53 */       return null; 
/* 54 */     return name.replaceAll("\\.[^\\.]+$", "");
/*    */   }
/*    */ }


/* Location:              C:\Users\rapha\Downloads\aurora.jar!\META-INF\jars\jcodec-0.2.5.jar!\org\jcodec\common\JCodecUtil2.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */