/*     */ package org.jcodec.common;
/*     */ 
/*     */ import java.io.File;
/*     */ import java.io.FileInputStream;
/*     */ import java.io.IOException;
/*     */ import java.nio.ByteBuffer;
/*     */ import java.nio.channels.FileChannel;
/*     */ import org.jcodec.common.io.AutoPool;
/*     */ import org.jcodec.common.io.AutoResource;
/*     */ import org.jcodec.common.io.SeekableByteChannel;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class AutoFileChannelWrapper
/*     */   implements SeekableByteChannel, AutoResource
/*     */ {
/*     */   private static final long THRESHOLD = 5000L;
/*     */   private FileChannel ch;
/*     */   private File file;
/*     */   private long savedPos;
/*     */   private long curTime;
/*     */   private long accessTime;
/*     */   
/*     */   public AutoFileChannelWrapper(File file) throws IOException {
/*  33 */     this.file = file;
/*  34 */     this.curTime = System.currentTimeMillis();
/*  35 */     AutoPool.getInstance().add(this);
/*  36 */     ensureOpen();
/*     */   }
/*     */   
/*     */   private void ensureOpen() throws IOException {
/*  40 */     this.accessTime = this.curTime;
/*  41 */     if (this.ch == null || !this.ch.isOpen()) {
/*  42 */       this.ch = (new FileInputStream(this.file)).getChannel();
/*  43 */       this.ch.position(this.savedPos);
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public int read(ByteBuffer arg0) throws IOException {
/*  49 */     ensureOpen();
/*  50 */     int r = this.ch.read(arg0);
/*  51 */     this.savedPos = this.ch.position();
/*  52 */     return r;
/*     */   }
/*     */ 
/*     */   
/*     */   public void close() throws IOException {
/*  57 */     if (this.ch != null && this.ch.isOpen()) {
/*  58 */       this.savedPos = this.ch.position();
/*  59 */       this.ch.close();
/*  60 */       this.ch = null;
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean isOpen() {
/*  66 */     return (this.ch != null && this.ch.isOpen());
/*     */   }
/*     */ 
/*     */   
/*     */   public int write(ByteBuffer arg0) throws IOException {
/*  71 */     ensureOpen();
/*  72 */     int w = this.ch.write(arg0);
/*  73 */     this.savedPos = this.ch.position();
/*  74 */     return w;
/*     */   }
/*     */ 
/*     */   
/*     */   public long position() throws IOException {
/*  79 */     ensureOpen();
/*  80 */     return this.ch.position();
/*     */   }
/*     */ 
/*     */   
/*     */   public SeekableByteChannel setPosition(long newPosition) throws IOException {
/*  85 */     ensureOpen();
/*  86 */     this.ch.position(newPosition);
/*  87 */     this.savedPos = newPosition;
/*  88 */     return this;
/*     */   }
/*     */ 
/*     */   
/*     */   public long size() throws IOException {
/*  93 */     ensureOpen();
/*  94 */     return this.ch.size();
/*     */   }
/*     */ 
/*     */   
/*     */   public SeekableByteChannel truncate(long size) throws IOException {
/*  99 */     ensureOpen();
/* 100 */     this.ch.truncate(size);
/* 101 */     this.savedPos = this.ch.position();
/* 102 */     return this;
/*     */   }
/*     */ 
/*     */   
/*     */   public void setCurTime(long curTime) {
/* 107 */     this.curTime = curTime;
/* 108 */     if (this.ch != null && this.ch.isOpen() && curTime - this.accessTime > 5000L)
/*     */       try {
/* 110 */         close();
/* 111 */       } catch (IOException e) {
/* 112 */         throw new RuntimeException(e);
/*     */       }  
/*     */   }
/*     */ }


/* Location:              C:\Users\rapha\Downloads\aurora.jar!\META-INF\jars\jcodec-0.2.5.jar!\org\jcodec\common\AutoFileChannelWrapper.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */