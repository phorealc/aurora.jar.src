/*    */ package org.jcodec.common;
/*    */ 
/*    */ import java.nio.ByteBuffer;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class CodecMeta
/*    */ {
/*    */   private String fourcc;
/*    */   private ByteBuffer codecPrivate;
/*    */   
/*    */   public CodecMeta(String fourcc, ByteBuffer codecPrivate) {
/* 20 */     this.fourcc = fourcc;
/* 21 */     this.codecPrivate = codecPrivate;
/*    */   }
/*    */   
/*    */   public String getFourcc() {
/* 25 */     return this.fourcc;
/*    */   }
/*    */   
/*    */   public ByteBuffer getCodecPrivate() {
/* 29 */     return this.codecPrivate;
/*    */   }
/*    */ }


/* Location:              C:\Users\rapha\Downloads\aurora.jar!\META-INF\jars\jcodec-0.2.5.jar!\org\jcodec\common\CodecMeta.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */