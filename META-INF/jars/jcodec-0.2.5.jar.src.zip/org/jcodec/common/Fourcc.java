/*    */ package org.jcodec.common;
/*    */ 
/*    */ import org.jcodec.platform.Platform;
/*    */ 
/*    */ public class Fourcc
/*    */ {
/*    */   public static int makeInt(byte b3, byte b2, byte b1, byte b0) {
/*  8 */     return b3 << 24 | (b2 & 0xFF) << 16 | (b1 & 0xFF) << 8 | b0 & 0xFF;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public static int intFourcc(String string) {
/* 15 */     byte[] b = Platform.getBytes(string);
/* 16 */     return makeInt(b[0], b[1], b[2], b[3]);
/*    */   }
/*    */   
/* 19 */   public static final int ftyp = intFourcc("ftyp");
/* 20 */   public static final int free = intFourcc("free");
/* 21 */   public static final int moov = intFourcc("moov");
/* 22 */   public static final int mdat = intFourcc("mdat");
/* 23 */   public static final int wide = intFourcc("wide");
/*    */ }


/* Location:              C:\Users\rapha\Downloads\aurora.jar!\META-INF\jars\jcodec-0.2.5.jar!\org\jcodec\common\Fourcc.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */