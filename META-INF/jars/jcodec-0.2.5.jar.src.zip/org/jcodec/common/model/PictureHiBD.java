/*     */ package org.jcodec.common.model;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class PictureHiBD
/*     */ {
/*     */   private ColorSpace color;
/*     */   private int width;
/*     */   private int height;
/*     */   private int[][] data;
/*     */   private Rect crop;
/*     */   private int bitDepth;
/*     */   
/*     */   public static PictureHiBD createPicture(int width, int height, int[][] data, ColorSpace color) {
/*  28 */     return new PictureHiBD(width, height, data, color, 8, new Rect(0, 0, width, height));
/*     */   }
/*     */   
/*     */   public static PictureHiBD createPictureWithDepth(int width, int height, int[][] data, ColorSpace color, int bitDepth) {
/*  32 */     return new PictureHiBD(width, height, data, color, bitDepth, new Rect(0, 0, width, height));
/*     */   }
/*     */   
/*     */   public static PictureHiBD createPictureCropped(int width, int height, int[][] data, ColorSpace color, Rect crop) {
/*  36 */     return new PictureHiBD(width, height, data, color, 8, crop);
/*     */   }
/*     */   
/*     */   public PictureHiBD(int width, int height, int[][] data, ColorSpace color, int bitDepth, Rect crop) {
/*  40 */     this.width = width;
/*  41 */     this.height = height;
/*  42 */     this.data = data;
/*  43 */     this.color = color;
/*  44 */     this.crop = crop;
/*  45 */     this.bitDepth = bitDepth;
/*     */   }
/*     */   
/*     */   public static PictureHiBD clonePicture(PictureHiBD other) {
/*  49 */     return new PictureHiBD(other.width, other.height, other.data, other.color, other.bitDepth, other.crop);
/*     */   }
/*     */   
/*     */   public static PictureHiBD create(int width, int height, ColorSpace colorSpace) {
/*  53 */     return doCreate(width, height, colorSpace, 8, null);
/*     */   }
/*     */   
/*     */   public static PictureHiBD createWithDepth(int width, int height, ColorSpace colorSpace, int bitDepth) {
/*  57 */     return doCreate(width, height, colorSpace, bitDepth, null);
/*     */   }
/*     */   
/*     */   public static PictureHiBD createCropped(int width, int height, ColorSpace colorSpace, Rect crop) {
/*  61 */     return doCreate(width, height, colorSpace, 8, crop);
/*     */   }
/*     */   
/*     */   public static PictureHiBD doCreate(int width, int height, ColorSpace colorSpace, int bitDepth, Rect crop) {
/*  65 */     int[] planeSizes = new int[4];
/*  66 */     for (int i = 0; i < colorSpace.nComp; i++) {
/*  67 */       planeSizes[colorSpace.compPlane[i]] = planeSizes[colorSpace.compPlane[i]] + (width >> colorSpace.compWidth[i]) * (height >> colorSpace.compHeight[i]);
/*     */     }
/*     */     
/*  70 */     int nPlanes = 0;
/*  71 */     for (int j = 0; j < 4; j++) {
/*  72 */       nPlanes += (planeSizes[j] != 0) ? 1 : 0;
/*     */     }
/*  74 */     int[][] data = new int[nPlanes][];
/*  75 */     for (int k = 0, plane = 0; k < 4; k++) {
/*  76 */       if (planeSizes[k] != 0) {
/*  77 */         data[plane++] = new int[planeSizes[k]];
/*     */       }
/*     */     } 
/*     */     
/*  81 */     return new PictureHiBD(width, height, data, colorSpace, 8, crop);
/*     */   }
/*     */ 
/*     */   
/*     */   public int getWidth() {
/*  86 */     return this.width;
/*     */   }
/*     */   
/*     */   public int getHeight() {
/*  90 */     return this.height;
/*     */   }
/*     */   
/*     */   public int[] getPlaneData(int plane) {
/*  94 */     return this.data[plane];
/*     */   }
/*     */   
/*     */   public ColorSpace getColor() {
/*  98 */     return this.color;
/*     */   }
/*     */   
/*     */   public int[][] getData() {
/* 102 */     return this.data;
/*     */   }
/*     */   
/*     */   public Rect getCrop() {
/* 106 */     return this.crop;
/*     */   }
/*     */   
/*     */   public int getPlaneWidth(int plane) {
/* 110 */     return this.width >> this.color.compWidth[plane];
/*     */   }
/*     */   
/*     */   public int getPlaneHeight(int plane) {
/* 114 */     return this.height >> this.color.compHeight[plane];
/*     */   }
/*     */   
/*     */   public boolean compatible(PictureHiBD src) {
/* 118 */     return (src.color == this.color && src.width == this.width && src.height == this.height);
/*     */   }
/*     */   
/*     */   public PictureHiBD createCompatible() {
/* 122 */     return create(this.width, this.height, this.color);
/*     */   }
/*     */   
/*     */   public void copyFrom(PictureHiBD src) {
/* 126 */     if (!compatible(src))
/* 127 */       throw new IllegalArgumentException("Can not copy to incompatible picture"); 
/* 128 */     for (int plane = 0; plane < this.color.nComp; plane++) {
/* 129 */       if (this.data[plane] != null)
/*     */       {
/* 131 */         System.arraycopy(src.data[plane], 0, this.data[plane], 0, (this.width >> this.color.compWidth[plane]) * (this.height >> this.color.compHeight[plane]));
/*     */       }
/*     */     } 
/*     */   }
/*     */   
/*     */   public PictureHiBD cropped() {
/* 137 */     if (this.crop == null || (this.crop
/* 138 */       .getX() == 0 && this.crop.getY() == 0 && this.crop.getWidth() == this.width && this.crop.getHeight() == this.height))
/* 139 */       return this; 
/* 140 */     PictureHiBD result = create(this.crop.getWidth(), this.crop.getHeight(), this.color);
/*     */     
/* 142 */     for (int plane = 0; plane < this.color.nComp; plane++) {
/* 143 */       if (this.data[plane] != null)
/*     */       {
/* 145 */         cropSub(this.data[plane], this.crop.getX() >> this.color.compWidth[plane], this.crop.getY() >> this.color.compHeight[plane], this.crop
/* 146 */             .getWidth() >> this.color.compWidth[plane], this.crop.getHeight() >> this.color.compHeight[plane], this.width >> this.color.compWidth[plane], result.data[plane]);
/*     */       }
/*     */     } 
/*     */     
/* 150 */     return result;
/*     */   }
/*     */   
/*     */   private void cropSub(int[] src, int x, int y, int w, int h, int srcStride, int[] tgt) {
/* 154 */     int srcOff = y * srcStride + x, dstOff = 0;
/* 155 */     for (int i = 0; i < h; i++) {
/* 156 */       for (int j = 0; j < w; j++) {
/* 157 */         tgt[dstOff + j] = src[srcOff + j];
/*     */       }
/* 159 */       srcOff += srcStride;
/* 160 */       dstOff += w;
/*     */     } 
/*     */   }
/*     */   
/*     */   public void setCrop(Rect crop) {
/* 165 */     this.crop = crop;
/*     */   }
/*     */   
/*     */   public int getCroppedWidth() {
/* 169 */     return (this.crop == null) ? this.width : this.crop.getWidth();
/*     */   }
/*     */   
/*     */   public int getCroppedHeight() {
/* 173 */     return (this.crop == null) ? this.height : this.crop.getHeight();
/*     */   }
/*     */   
/*     */   public void setBitDepth(int bitDepth) {
/* 177 */     this.bitDepth = bitDepth;
/*     */   }
/*     */   
/*     */   public int getBitDepth() {
/* 181 */     return this.bitDepth;
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean equals(Object obj) {
/* 186 */     if (obj == null || !(obj instanceof PictureHiBD))
/* 187 */       return false; 
/* 188 */     PictureHiBD other = (PictureHiBD)obj;
/*     */     
/* 190 */     if (other.getCroppedWidth() != getCroppedWidth() || other.getCroppedHeight() != getCroppedHeight() || other
/* 191 */       .getColor() != this.color) {
/* 192 */       return false;
/*     */     }
/* 194 */     for (int i = 0; i < (getData()).length; i++) {
/* 195 */       if (!planeEquals(other, i))
/* 196 */         return false; 
/* 197 */     }  return true;
/*     */   }
/*     */   
/*     */   private boolean planeEquals(PictureHiBD other, int plane) {
/* 201 */     int cw = this.color.compWidth[plane];
/* 202 */     int ch = this.color.compHeight[plane];
/*     */     
/* 204 */     int offA = (other.getCrop() == null) ? 0 : ((other.getCrop().getX() >> cw) + (other.getCrop().getY() >> ch) * (other.getWidth() >> cw));
/* 205 */     int offB = (this.crop == null) ? 0 : ((this.crop.getX() >> cw) + (this.crop.getY() >> ch) * (this.width >> cw));
/*     */     
/* 207 */     int[] planeData = other.getPlaneData(plane);
/* 208 */     for (int i = 0; i < getCroppedHeight() >> ch; i++, offA += other.getWidth() >> cw, offB += this.width >> cw) {
/* 209 */       for (int j = 0; j < getCroppedWidth() >> cw; j++) {
/* 210 */         if (planeData[offA + j] != this.data[plane][offB + j])
/* 211 */           return false; 
/*     */       } 
/*     */     } 
/* 214 */     return true;
/*     */   }
/*     */ }


/* Location:              C:\Users\rapha\Downloads\aurora.jar!\META-INF\jars\jcodec-0.2.5.jar!\org\jcodec\common\model\PictureHiBD.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */