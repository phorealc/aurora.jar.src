/*     */ package org.jcodec.common.model;
/*     */ 
/*     */ import org.jcodec.common.StringUtils;
/*     */ import org.jcodec.common.tools.MathUtil;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class RationalLarge
/*     */ {
/*  15 */   public static final RationalLarge ONE = new RationalLarge(1L, 1L);
/*  16 */   public static final RationalLarge HALF = new RationalLarge(1L, 2L);
/*  17 */   public static final RationalLarge ZERO = new RationalLarge(0L, 1L);
/*     */   
/*     */   final long num;
/*     */   final long den;
/*     */   
/*     */   public RationalLarge(long num, long den) {
/*  23 */     this.num = num;
/*  24 */     this.den = den;
/*     */   }
/*     */   
/*     */   public long getNum() {
/*  28 */     return this.num;
/*     */   }
/*     */   
/*     */   public long getDen() {
/*  32 */     return this.den;
/*     */   }
/*     */   
/*     */   public static RationalLarge parse(String string) {
/*  36 */     String[] split = StringUtils.splitS(string, ":");
/*  37 */     return (split.length > 1) ? R(Long.parseLong(split[0]), Long.parseLong(split[1])) : 
/*  38 */       R(Long.parseLong(string), 1L);
/*     */   }
/*     */ 
/*     */   
/*     */   public int hashCode() {
/*  43 */     int prime = 31;
/*  44 */     int result = 1;
/*  45 */     result = 31 * result + (int)(this.den ^ this.den >>> 32L);
/*  46 */     result = 31 * result + (int)(this.num ^ this.num >>> 32L);
/*  47 */     return result;
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean equals(Object obj) {
/*  52 */     if (this == obj)
/*  53 */       return true; 
/*  54 */     if (obj == null)
/*  55 */       return false; 
/*  56 */     if (getClass() != obj.getClass())
/*  57 */       return false; 
/*  58 */     RationalLarge other = (RationalLarge)obj;
/*  59 */     if (this.den != other.den)
/*  60 */       return false; 
/*  61 */     if (this.num != other.num)
/*  62 */       return false; 
/*  63 */     return true;
/*     */   }
/*     */   
/*     */   public long multiplyS(long scalar) {
/*  67 */     return this.num * scalar / this.den;
/*     */   }
/*     */   
/*     */   public long divideS(long scalar) {
/*  71 */     return this.den * scalar / this.num;
/*     */   }
/*     */   
/*     */   public long divideByS(long scalar) {
/*  75 */     return this.num / this.den * scalar;
/*     */   }
/*     */   
/*     */   public RationalLarge flip() {
/*  79 */     return new RationalLarge(this.den, this.num);
/*     */   }
/*     */   
/*     */   public static RationalLarge R(long num, long den) {
/*  83 */     return new RationalLarge(num, den);
/*     */   }
/*     */   
/*     */   public static RationalLarge R1(long num) {
/*  87 */     return R(num, 1L);
/*     */   }
/*     */   
/*     */   public boolean lessThen(RationalLarge sec) {
/*  91 */     return (this.num * sec.den < sec.num * this.den);
/*     */   }
/*     */   
/*     */   public boolean greaterThen(RationalLarge sec) {
/*  95 */     return (this.num * sec.den > sec.num * this.den);
/*     */   }
/*     */   
/*     */   public boolean smallerOrEqualTo(RationalLarge sec) {
/*  99 */     return (this.num * sec.den <= sec.num * this.den);
/*     */   }
/*     */   
/*     */   public boolean greaterOrEqualTo(RationalLarge sec) {
/* 103 */     return (this.num * sec.den >= sec.num * this.den);
/*     */   }
/*     */   
/*     */   public boolean equalsLarge(RationalLarge other) {
/* 107 */     return (this.num * other.den == other.num * this.den);
/*     */   }
/*     */   
/*     */   public RationalLarge plus(RationalLarge other) {
/* 111 */     return reduceLong(this.num * other.den + other.num * this.den, this.den * other.den);
/*     */   }
/*     */   
/*     */   public RationalLarge plusR(Rational other) {
/* 115 */     return reduceLong(this.num * other.den + other.num * this.den, this.den * other.den);
/*     */   }
/*     */   
/*     */   public RationalLarge minus(RationalLarge other) {
/* 119 */     return reduceLong(this.num * other.den - other.num * this.den, this.den * other.den);
/*     */   }
/*     */   
/*     */   public RationalLarge minusR(Rational other) {
/* 123 */     return reduceLong(this.num * other.den - other.num * this.den, this.den * other.den);
/*     */   }
/*     */   
/*     */   public RationalLarge plusLong(long scalar) {
/* 127 */     return new RationalLarge(this.num + scalar * this.den, this.den);
/*     */   }
/*     */   
/*     */   public RationalLarge minusLong(long scalar) {
/* 131 */     return new RationalLarge(this.num - scalar * this.den, this.den);
/*     */   }
/*     */   
/*     */   public RationalLarge multiplyLong(long scalar) {
/* 135 */     return new RationalLarge(this.num * scalar, this.den);
/*     */   }
/*     */   
/*     */   public RationalLarge divideLong(long scalar) {
/* 139 */     return new RationalLarge(this.den * scalar, this.num);
/*     */   }
/*     */   
/*     */   public RationalLarge divideByLong(long scalar) {
/* 143 */     return new RationalLarge(this.num, this.den * scalar);
/*     */   }
/*     */   
/*     */   public RationalLarge multiply(RationalLarge other) {
/* 147 */     return reduceLong(this.num * other.num, this.den * other.den);
/*     */   }
/*     */   
/*     */   public RationalLarge multiplyR(Rational other) {
/* 151 */     return reduceLong(this.num * other.num, this.den * other.den);
/*     */   }
/*     */   
/*     */   public RationalLarge divideRL(RationalLarge other) {
/* 155 */     return reduceLong(other.num * this.den, other.den * this.num);
/*     */   }
/*     */   
/*     */   public RationalLarge divideR(Rational other) {
/* 159 */     return reduceLong(other.num * this.den, other.den * this.num);
/*     */   }
/*     */   
/*     */   public RationalLarge divideBy(RationalLarge other) {
/* 163 */     return reduceLong(this.num * other.den, this.den * other.num);
/*     */   }
/*     */   
/*     */   public RationalLarge divideByR(Rational other) {
/* 167 */     return reduceLong(this.num * other.den, this.den * other.num);
/*     */   }
/*     */   
/*     */   public double scalar() {
/* 171 */     return this.num / this.den;
/*     */   }
/*     */   
/*     */   public long scalarClip() {
/* 175 */     return this.num / this.den;
/*     */   }
/*     */ 
/*     */   
/*     */   public String toString() {
/* 180 */     return this.num + ":" + this.den;
/*     */   }
/*     */   
/*     */   public static RationalLarge reduceLong(long num, long den) {
/* 184 */     long gcd = MathUtil.gcdLong(num, den);
/* 185 */     return new RationalLarge(num / gcd, den / gcd);
/*     */   }
/*     */ }


/* Location:              C:\Users\rapha\Downloads\aurora.jar!\META-INF\jars\jcodec-0.2.5.jar!\org\jcodec\common\model\RationalLarge.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */