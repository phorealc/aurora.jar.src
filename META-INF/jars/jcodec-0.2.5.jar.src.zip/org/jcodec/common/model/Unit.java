/*    */ package org.jcodec.common.model;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public enum Unit
/*    */ {
/* 11 */   FRAME, SEC;
/*    */ }


/* Location:              C:\Users\rapha\Downloads\aurora.jar!\META-INF\jars\jcodec-0.2.5.jar!\org\jcodec\common\model\Unit.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */