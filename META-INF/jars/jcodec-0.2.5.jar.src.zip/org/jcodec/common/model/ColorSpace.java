/*     */ package org.jcodec.common.model;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class ColorSpace
/*     */ {
/*     */   public static final int MAX_PLANES = 4;
/*     */   public int nComp;
/*     */   public int[] compPlane;
/*     */   public int[] compWidth;
/*     */   public int[] compHeight;
/*     */   public boolean planar;
/*     */   private String _name;
/*     */   public int bitsPerPixel;
/*     */   
/*     */   private ColorSpace(String name, int nComp, int[] compPlane, int[] compWidth, int[] compHeight, boolean planar) {
/*  29 */     this._name = name;
/*  30 */     this.nComp = nComp;
/*  31 */     this.compPlane = compPlane;
/*  32 */     this.compWidth = compWidth;
/*  33 */     this.compHeight = compHeight;
/*  34 */     this.planar = planar;
/*  35 */     this.bitsPerPixel = calcBitsPerPixel(nComp, compWidth, compHeight);
/*     */   }
/*     */ 
/*     */   
/*     */   public String toString() {
/*  40 */     return this._name;
/*     */   }
/*     */   
/*     */   private static int calcBitsPerPixel(int nComp, int[] compWidth, int[] compHeight) {
/*  44 */     int bitsPerPixel = 0;
/*  45 */     for (int i = 0; i < nComp; i++) {
/*  46 */       bitsPerPixel += 8 >> compWidth[i] >> compHeight[i];
/*     */     }
/*  48 */     return bitsPerPixel;
/*     */   }
/*     */   
/*     */   public int getWidthMask() {
/*  52 */     return ((this.nComp > 1) ? this.compWidth[1] : 0) ^ 0xFFFFFFFF;
/*     */   }
/*     */   
/*     */   public int getHeightMask() {
/*  56 */     return ((this.nComp > 1) ? this.compHeight[1] : 0) ^ 0xFFFFFFFF;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean matches(ColorSpace inputColor) {
/*  68 */     if (inputColor == this)
/*  69 */       return true; 
/*  70 */     if (inputColor == ANY || this == ANY)
/*  71 */       return true; 
/*  72 */     if ((inputColor == ANY_INTERLEAVED || this == ANY_INTERLEAVED || inputColor == ANY_PLANAR || this == ANY_PLANAR) && inputColor.planar == this.planar)
/*     */     {
/*  74 */       return true; } 
/*  75 */     return false;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Size compSize(Size size, int comp) {
/*  84 */     if (this.compWidth[comp] == 0 && this.compHeight[comp] == 0)
/*  85 */       return size; 
/*  86 */     return new Size(size.getWidth() >> this.compWidth[comp], size.getHeight() >> this.compHeight[comp]);
/*     */   }
/*     */   
/*  89 */   private static final int[] _000 = new int[] { 0, 0, 0 };
/*  90 */   private static final int[] _011 = new int[] { 0, 1, 1 };
/*  91 */   private static final int[] _012 = new int[] { 0, 1, 2 };
/*  92 */   public static final ColorSpace BGR = new ColorSpace("BGR", 3, _000, _000, _000, false);
/*  93 */   public static final ColorSpace RGB = new ColorSpace("RGB", 3, _000, _000, _000, false);
/*  94 */   public static final ColorSpace YUV420 = new ColorSpace("YUV420", 3, _012, _011, _011, true);
/*  95 */   public static final ColorSpace YUV420J = new ColorSpace("YUV420J", 3, _012, _011, _011, true);
/*  96 */   public static final ColorSpace YUV422 = new ColorSpace("YUV422", 3, _012, _011, _000, true);
/*  97 */   public static final ColorSpace YUV422J = new ColorSpace("YUV422J", 3, _012, _011, _000, true);
/*  98 */   public static final ColorSpace YUV444 = new ColorSpace("YUV444", 3, _012, _000, _000, true);
/*  99 */   public static final ColorSpace YUV444J = new ColorSpace("YUV444J", 3, _012, _000, _000, true);
/* 100 */   public static final ColorSpace YUV422_10 = new ColorSpace("YUV422_10", 3, _012, _011, _000, true);
/* 101 */   public static final ColorSpace GREY = new ColorSpace("GREY", 1, new int[] { 0 }, new int[] { 0 }, new int[] { 0 }, true);
/* 102 */   public static final ColorSpace MONO = new ColorSpace("MONO", 1, _000, _000, _000, true);
/* 103 */   public static final ColorSpace YUV444_10 = new ColorSpace("YUV444_10", 3, _012, _000, _000, true);
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 108 */   public static final ColorSpace ANY = new ColorSpace("ANY", 0, null, null, null, true);
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 113 */   public static final ColorSpace ANY_PLANAR = new ColorSpace("ANY_PLANAR", 0, null, null, null, true);
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 118 */   public static final ColorSpace ANY_INTERLEAVED = new ColorSpace("ANY_INTERLEAVED", 0, null, null, null, false);
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 123 */   public static final ColorSpace SAME = new ColorSpace("SAME", 0, null, null, null, false);
/*     */ }


/* Location:              C:\Users\rapha\Downloads\aurora.jar!\META-INF\jars\jcodec-0.2.5.jar!\org\jcodec\common\model\ColorSpace.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */