/*    */ package org.jcodec.common.model;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class Plane
/*    */ {
/*    */   int[] data;
/*    */   Size size;
/*    */   
/*    */   public Plane(int[] data, Size size) {
/* 16 */     this.data = data;
/* 17 */     this.size = size;
/*    */   }
/*    */   
/*    */   public int[] getData() {
/* 21 */     return this.data;
/*    */   }
/*    */   
/*    */   public Size getSize() {
/* 25 */     return this.size;
/*    */   }
/*    */ }


/* Location:              C:\Users\rapha\Downloads\aurora.jar!\META-INF\jars\jcodec-0.2.5.jar!\org\jcodec\common\model\Plane.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */