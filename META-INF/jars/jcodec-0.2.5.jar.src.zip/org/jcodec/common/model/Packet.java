/*     */ package org.jcodec.common.model;
/*     */ 
/*     */ import java.nio.ByteBuffer;
/*     */ import java.util.Comparator;
/*     */ 
/*     */ public class Packet
/*     */ {
/*     */   public ByteBuffer data;
/*     */   public long pts;
/*     */   public int timescale;
/*     */   public long duration;
/*     */   public long frameNo;
/*     */   public FrameType frameType;
/*     */   public TapeTimecode tapeTimecode;
/*     */   public int displayOrder;
/*     */   
/*     */   public enum FrameType {
/*  18 */     KEY, INTER, UNKNOWN;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Packet createPacket(ByteBuffer data, long pts, int timescale, long duration, long frameNo, FrameType frameType, TapeTimecode tapeTimecode) {
/*  32 */     return new Packet(data, pts, timescale, duration, frameNo, frameType, tapeTimecode, 0);
/*     */   }
/*     */   
/*     */   public static Packet createPacketWithData(Packet other, ByteBuffer data) {
/*  36 */     return new Packet(data, other.pts, other.timescale, other.duration, other.frameNo, other.frameType, other.tapeTimecode, other.displayOrder);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public Packet(ByteBuffer data, long pts, int timescale, long duration, long frameNo, FrameType frameType, TapeTimecode tapeTimecode, int displayOrder) {
/*  42 */     this.data = data;
/*  43 */     this.pts = pts;
/*  44 */     this.timescale = timescale;
/*  45 */     this.duration = duration;
/*  46 */     this.frameNo = frameNo;
/*  47 */     this.frameType = frameType;
/*  48 */     this.tapeTimecode = tapeTimecode;
/*  49 */     this.displayOrder = displayOrder;
/*     */   }
/*     */   
/*     */   public ByteBuffer getData() {
/*  53 */     return this.data.duplicate();
/*     */   }
/*     */   
/*     */   public long getPts() {
/*  57 */     return this.pts;
/*     */   }
/*     */   
/*     */   public int getTimescale() {
/*  61 */     return this.timescale;
/*     */   }
/*     */   
/*     */   public long getDuration() {
/*  65 */     return this.duration;
/*     */   }
/*     */   
/*     */   public long getFrameNo() {
/*  69 */     return this.frameNo;
/*     */   }
/*     */   
/*     */   public void setTimescale(int timescale) {
/*  73 */     this.timescale = timescale;
/*     */   }
/*     */   
/*     */   public TapeTimecode getTapeTimecode() {
/*  77 */     return this.tapeTimecode;
/*     */   }
/*     */   
/*     */   public void setTapeTimecode(TapeTimecode tapeTimecode) {
/*  81 */     this.tapeTimecode = tapeTimecode;
/*     */   }
/*     */   
/*     */   public int getDisplayOrder() {
/*  85 */     return this.displayOrder;
/*     */   }
/*     */   
/*     */   public void setDisplayOrder(int displayOrder) {
/*  89 */     this.displayOrder = displayOrder;
/*     */   }
/*     */   
/*     */   public FrameType getFrameType() {
/*  93 */     return this.frameType;
/*     */   }
/*     */   
/*     */   public void setFrameType(FrameType frameType) {
/*  97 */     this.frameType = frameType;
/*     */   }
/*     */   
/*     */   public RationalLarge getPtsR() {
/* 101 */     return RationalLarge.R(this.pts, this.timescale);
/*     */   }
/*     */   
/*     */   public double getPtsD() {
/* 105 */     return this.pts / this.timescale;
/*     */   }
/*     */   
/*     */   public double getDurationD() {
/* 109 */     return this.duration / this.timescale;
/*     */   }
/*     */   
/*     */   public void setData(ByteBuffer data) {
/* 113 */     this.data = data;
/*     */   }
/*     */   
/*     */   public void setPts(long pts) {
/* 117 */     this.pts = pts;
/*     */   }
/*     */   
/* 120 */   public static final Comparator<Packet> FRAME_ASC = new Comparator<Packet>() {
/*     */       public int compare(Packet o1, Packet o2) {
/* 122 */         if (o1 == null && o2 == null)
/* 123 */           return 0; 
/* 124 */         if (o1 == null)
/* 125 */           return -1; 
/* 126 */         if (o2 == null)
/* 127 */           return 1; 
/* 128 */         return (o1.frameNo < o2.frameNo) ? -1 : ((o1.frameNo == o2.frameNo) ? 0 : 1);
/*     */       }
/*     */     };
/*     */   
/*     */   public void setDuration(long duration) {
/* 133 */     this.duration = duration;
/*     */   }
/*     */   
/*     */   public boolean isKeyFrame() {
/* 137 */     return (this.frameType == FrameType.KEY);
/*     */   }
/*     */ }


/* Location:              C:\Users\rapha\Downloads\aurora.jar!\META-INF\jars\jcodec-0.2.5.jar!\org\jcodec\common\model\Packet.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */