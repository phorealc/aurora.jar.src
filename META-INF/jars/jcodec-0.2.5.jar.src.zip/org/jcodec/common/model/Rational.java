/*     */ package org.jcodec.common.model;
/*     */ 
/*     */ import org.jcodec.common.tools.MathUtil;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class Rational
/*     */ {
/*  19 */   public static final Rational ONE = new Rational(1, 1);
/*  20 */   public static final Rational HALF = new Rational(1, 2);
/*  21 */   public static final Rational ZERO = new Rational(0, 1);
/*     */   public final int num;
/*     */   public final int den;
/*     */   
/*     */   public static Rational R(int num, int den) {
/*  26 */     return new Rational(num, den);
/*     */   }
/*     */   
/*     */   public static Rational R1(int num) {
/*  30 */     return R(num, 1);
/*     */   }
/*     */   
/*     */   public Rational(int num, int den) {
/*  34 */     this.num = num;
/*  35 */     this.den = den;
/*     */   }
/*     */   
/*     */   public int getNum() {
/*  39 */     return this.num;
/*     */   }
/*     */   
/*     */   public int getDen() {
/*  43 */     return this.den;
/*     */   }
/*     */   
/*     */   public static Rational parseRational(String string) {
/*  47 */     return parse(string);
/*     */   }
/*     */   
/*     */   public static Rational parse(String string) {
/*  51 */     int idx = string.indexOf(":");
/*  52 */     if (idx < 0) {
/*  53 */       idx = string.indexOf("/");
/*     */     }
/*  55 */     if (idx > 0) {
/*  56 */       String num = string.substring(0, idx);
/*  57 */       String den = string.substring(idx + 1);
/*  58 */       return new Rational(Integer.parseInt(num), Integer.parseInt(den));
/*     */     } 
/*  60 */     return R(Integer.parseInt(string), 1);
/*     */   }
/*     */ 
/*     */   
/*     */   public int hashCode() {
/*  65 */     int prime = 31;
/*  66 */     int result = 1;
/*  67 */     result = 31 * result + this.den;
/*  68 */     result = 31 * result + this.num;
/*  69 */     return result;
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean equals(Object obj) {
/*  74 */     if (this == obj)
/*  75 */       return true; 
/*  76 */     if (obj == null)
/*  77 */       return false; 
/*  78 */     if (getClass() != obj.getClass())
/*  79 */       return false; 
/*  80 */     Rational other = (Rational)obj;
/*  81 */     if (this.den != other.den)
/*  82 */       return false; 
/*  83 */     if (this.num != other.num)
/*  84 */       return false; 
/*  85 */     return true;
/*     */   }
/*     */   
/*     */   public int multiplyS(int val) {
/*  89 */     return (int)(this.num * val / this.den);
/*     */   }
/*     */   
/*     */   public int divideS(int val) {
/*  93 */     return (int)(this.den * val / this.num);
/*     */   }
/*     */   
/*     */   public int divideByS(int val) {
/*  97 */     return this.num / this.den * val;
/*     */   }
/*     */   
/*     */   public long multiplyLong(long val) {
/* 101 */     return this.num * val / this.den;
/*     */   }
/*     */   
/*     */   public long divideLong(long val) {
/* 105 */     return this.den * val / this.num;
/*     */   }
/*     */   
/*     */   public Rational flip() {
/* 109 */     return new Rational(this.den, this.num);
/*     */   }
/*     */   
/*     */   public boolean smallerThen(Rational sec) {
/* 113 */     return (this.num * sec.den < sec.num * this.den);
/*     */   }
/*     */   
/*     */   public boolean greaterThen(Rational sec) {
/* 117 */     return (this.num * sec.den > sec.num * this.den);
/*     */   }
/*     */   
/*     */   public boolean smallerOrEqualTo(Rational sec) {
/* 121 */     return (this.num * sec.den <= sec.num * this.den);
/*     */   }
/*     */   
/*     */   public boolean greaterOrEqualTo(Rational sec) {
/* 125 */     return (this.num * sec.den >= sec.num * this.den);
/*     */   }
/*     */   
/*     */   public boolean equalsRational(Rational other) {
/* 129 */     return (this.num * other.den == other.num * this.den);
/*     */   }
/*     */   
/*     */   public Rational plus(Rational other) {
/* 133 */     return reduce(this.num * other.den + other.num * this.den, this.den * other.den);
/*     */   }
/*     */   
/*     */   public RationalLarge plusLarge(RationalLarge other) {
/* 137 */     return RationalLarge.reduceLong(this.num * other.den + other.num * this.den, this.den * other.den);
/*     */   }
/*     */   
/*     */   public Rational minus(Rational other) {
/* 141 */     return reduce(this.num * other.den - other.num * this.den, this.den * other.den);
/*     */   }
/*     */   
/*     */   public RationalLarge minusLarge(RationalLarge other) {
/* 145 */     return RationalLarge.reduceLong(this.num * other.den - other.num * this.den, this.den * other.den);
/*     */   }
/*     */   
/*     */   public Rational plusInt(int scalar) {
/* 149 */     return new Rational(this.num + scalar * this.den, this.den);
/*     */   }
/*     */   
/*     */   public Rational minusInt(int scalar) {
/* 153 */     return new Rational(this.num - scalar * this.den, this.den);
/*     */   }
/*     */   
/*     */   public Rational multiplyInt(int scalar) {
/* 157 */     return new Rational(this.num * scalar, this.den);
/*     */   }
/*     */   
/*     */   public Rational divideInt(int scalar) {
/* 161 */     return new Rational(this.den * scalar, this.num);
/*     */   }
/*     */   
/*     */   public Rational divideByInt(int scalar) {
/* 165 */     return new Rational(this.num, this.den * scalar);
/*     */   }
/*     */   
/*     */   public Rational multiply(Rational other) {
/* 169 */     return reduce(this.num * other.num, this.den * other.den);
/*     */   }
/*     */   
/*     */   public RationalLarge multiplyLarge(RationalLarge other) {
/* 173 */     return RationalLarge.reduceLong(this.num * other.num, this.den * other.den);
/*     */   }
/*     */   
/*     */   public Rational divide(Rational other) {
/* 177 */     return reduce(other.num * this.den, other.den * this.num);
/*     */   }
/*     */   
/*     */   public RationalLarge divideLarge(RationalLarge other) {
/* 181 */     return RationalLarge.reduceLong(other.num * this.den, other.den * this.num);
/*     */   }
/*     */   
/*     */   public Rational divideBy(Rational other) {
/* 185 */     return reduce(this.num * other.den, this.den * other.num);
/*     */   }
/*     */   
/*     */   public RationalLarge divideByLarge(RationalLarge other) {
/* 189 */     return RationalLarge.reduceLong(this.num * other.den, this.den * other.num);
/*     */   }
/*     */   
/*     */   public float scalar() {
/* 193 */     return this.num / this.den;
/*     */   }
/*     */   
/*     */   public int scalarClip() {
/* 197 */     return this.num / this.den;
/*     */   }
/*     */   
/*     */   public static Rational reduce(int num, int den) {
/* 201 */     int gcd = MathUtil.gcd(num, den);
/* 202 */     return new Rational(num / gcd, den / gcd);
/*     */   }
/*     */   
/*     */   public static Rational reduceRational(Rational r) {
/* 206 */     return reduce(r.getNum(), r.getDen());
/*     */   }
/*     */ 
/*     */   
/*     */   public String toString() {
/* 211 */     return this.num + "/" + this.den;
/*     */   }
/*     */   
/*     */   public double toDouble() {
/* 215 */     return this.num / this.den;
/*     */   }
/*     */ }


/* Location:              C:\Users\rapha\Downloads\aurora.jar!\META-INF\jars\jcodec-0.2.5.jar!\org\jcodec\common\model\Rational.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */