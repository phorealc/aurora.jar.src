/*    */ package org.jcodec.common.model;
/*    */ 
/*    */ import java.nio.ByteBuffer;
/*    */ import org.jcodec.common.AudioFormat;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class AudioFrame
/*    */   extends AudioBuffer
/*    */ {
/*    */   private long pts;
/*    */   private long duration;
/*    */   private long timescale;
/*    */   private int frameNo;
/*    */   
/*    */   public AudioFrame(ByteBuffer buffer, AudioFormat format, int nFrames, long pts, long duration, long timescale, int frameNo) {
/* 21 */     super(buffer, format, nFrames);
/* 22 */     this.pts = pts;
/* 23 */     this.duration = duration;
/* 24 */     this.timescale = timescale;
/* 25 */     this.frameNo = frameNo;
/*    */   }
/*    */   
/*    */   public long getPts() {
/* 29 */     return this.pts;
/*    */   }
/*    */   
/*    */   public long getDuration() {
/* 33 */     return this.duration;
/*    */   }
/*    */   
/*    */   public long getTimescale() {
/* 37 */     return this.timescale;
/*    */   }
/*    */   
/*    */   public int getFrameNo() {
/* 41 */     return this.frameNo;
/*    */   }
/*    */ }


/* Location:              C:\Users\rapha\Downloads\aurora.jar!\META-INF\jars\jcodec-0.2.5.jar!\org\jcodec\common\model\AudioFrame.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */