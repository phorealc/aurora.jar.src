/*    */ package org.jcodec.common.model;
/*    */ 
/*    */ import java.util.List;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class Frame
/*    */ {
/*    */   private Picture pic;
/*    */   private RationalLarge pts;
/*    */   private RationalLarge duration;
/*    */   private Rational pixelAspect;
/*    */   private TapeTimecode tapeTimecode;
/*    */   private int frameNo;
/*    */   private List<String> messages;
/*    */   
/*    */   public Frame(Picture pic, RationalLarge pts, RationalLarge duration, Rational pixelAspect, int frameNo, TapeTimecode tapeTimecode, List<String> messages) {
/* 22 */     this.pic = pic;
/* 23 */     this.pts = pts;
/* 24 */     this.duration = duration;
/* 25 */     this.pixelAspect = pixelAspect;
/* 26 */     this.tapeTimecode = tapeTimecode;
/* 27 */     this.frameNo = frameNo;
/* 28 */     this.messages = messages;
/*    */   }
/*    */   
/*    */   public Picture getPic() {
/* 32 */     return this.pic;
/*    */   }
/*    */   
/*    */   public RationalLarge getPts() {
/* 36 */     return this.pts;
/*    */   }
/*    */   
/*    */   public RationalLarge getDuration() {
/* 40 */     return this.duration;
/*    */   }
/*    */   
/*    */   public Rational getPixelAspect() {
/* 44 */     return this.pixelAspect;
/*    */   }
/*    */   
/*    */   public TapeTimecode getTapeTimecode() {
/* 48 */     return this.tapeTimecode;
/*    */   }
/*    */   
/*    */   public int getFrameNo() {
/* 52 */     return this.frameNo;
/*    */   }
/*    */   
/*    */   public List<String> getMessages() {
/* 56 */     return this.messages;
/*    */   }
/*    */   
/*    */   public boolean isAvailable() {
/* 60 */     return true;
/*    */   }
/*    */ }


/* Location:              C:\Users\rapha\Downloads\aurora.jar!\META-INF\jars\jcodec-0.2.5.jar!\org\jcodec\common\model\Frame.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */