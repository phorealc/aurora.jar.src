/*    */ package org.jcodec.common.model;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class Size
/*    */ {
/*    */   private int width;
/*    */   private int height;
/*    */   
/*    */   public Size(int width, int height) {
/* 15 */     this.width = width;
/* 16 */     this.height = height;
/*    */   }
/*    */   
/*    */   public int getWidth() {
/* 20 */     return this.width;
/*    */   }
/*    */   
/*    */   public int getHeight() {
/* 24 */     return this.height;
/*    */   }
/*    */ 
/*    */   
/*    */   public int hashCode() {
/* 29 */     int prime = 31;
/* 30 */     int result = 1;
/* 31 */     result = 31 * result + this.height;
/* 32 */     result = 31 * result + this.width;
/* 33 */     return result;
/*    */   }
/*    */ 
/*    */   
/*    */   public boolean equals(Object obj) {
/* 38 */     if (this == obj)
/* 39 */       return true; 
/* 40 */     if (obj == null)
/* 41 */       return false; 
/* 42 */     if (getClass() != obj.getClass())
/* 43 */       return false; 
/* 44 */     Size other = (Size)obj;
/* 45 */     if (this.height != other.height)
/* 46 */       return false; 
/* 47 */     if (this.width != other.width)
/* 48 */       return false; 
/* 49 */     return true;
/*    */   }
/*    */ }


/* Location:              C:\Users\rapha\Downloads\aurora.jar!\META-INF\jars\jcodec-0.2.5.jar!\org\jcodec\common\model\Size.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */