/*    */ package org.jcodec.common.model;
/*    */ 
/*    */ import org.jcodec.common.StringUtils;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class TapeTimecode
/*    */ {
/* 16 */   public static final TapeTimecode ZERO_TAPE_TIMECODE = new TapeTimecode((short)0, (byte)0, (byte)0, (byte)0, false, 0);
/*    */   
/*    */   private final short hour;
/*    */   private final byte minute;
/*    */   private final byte second;
/*    */   private final byte frame;
/*    */   private final boolean dropFrame;
/*    */   private final int tapeFps;
/*    */   
/*    */   public TapeTimecode(short hour, byte minute, byte second, byte frame, boolean dropFrame, int tapeFps) {
/* 26 */     this.hour = hour;
/* 27 */     this.minute = minute;
/* 28 */     this.second = second;
/* 29 */     this.frame = frame;
/* 30 */     this.dropFrame = dropFrame;
/* 31 */     this.tapeFps = tapeFps;
/*    */   }
/*    */   
/*    */   public short getHour() {
/* 35 */     return this.hour;
/*    */   }
/*    */   
/*    */   public byte getMinute() {
/* 39 */     return this.minute;
/*    */   }
/*    */   
/*    */   public byte getSecond() {
/* 43 */     return this.second;
/*    */   }
/*    */   
/*    */   public byte getFrame() {
/* 47 */     return this.frame;
/*    */   }
/*    */   
/*    */   public boolean isDropFrame() {
/* 51 */     return this.dropFrame;
/*    */   }
/*    */   
/*    */   public int getTapeFps() {
/* 55 */     return this.tapeFps;
/*    */   }
/*    */ 
/*    */   
/*    */   public String toString() {
/* 60 */     return StringUtils.zeroPad2(this.hour) + ":" + 
/* 61 */       StringUtils.zeroPad2(this.minute) + ":" + 
/* 62 */       StringUtils.zeroPad2(this.second) + (this.dropFrame ? ";" : ":") + 
/* 63 */       StringUtils.zeroPad2(this.frame);
/*    */   }
/*    */   
/*    */   public static TapeTimecode tapeTimecode(long frame, boolean dropFrame, int tapeFps) {
/* 67 */     if (dropFrame) {
/* 68 */       long D = frame / 17982L;
/* 69 */       long M = frame % 17982L;
/* 70 */       frame += 18L * D + 2L * (M - 2L) / 1798L;
/*    */     } 
/* 72 */     long sec = frame / tapeFps;
/* 73 */     return new TapeTimecode((short)(int)(sec / 3600L), (byte)(int)(sec / 60L % 60L), (byte)(int)(sec % 60L), (byte)(int)(frame % tapeFps), dropFrame, tapeFps);
/*    */   }
/*    */ }


/* Location:              C:\Users\rapha\Downloads\aurora.jar!\META-INF\jars\jcodec-0.2.5.jar!\org\jcodec\common\model\TapeTimecode.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */