/*     */ package org.jcodec.common.model;
/*     */ 
/*     */ import java.util.ArrayList;
/*     */ import java.util.List;
/*     */ import java.util.regex.Pattern;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class Label
/*     */ {
/*  15 */   private static final List<Label> _values = new ArrayList<Label>();
/*     */ 
/*     */   
/*  18 */   public static final Label Unknown = new Label(-1);
/*     */ 
/*     */   
/*  21 */   public static final Label Unused = new Label(0);
/*     */ 
/*     */   
/*  24 */   public static final Label UseCoordinates = new Label(100);
/*     */   
/*  26 */   public static final Label Left = new Label(1);
/*  27 */   public static final Label Right = new Label(2);
/*  28 */   public static final Label Center = new Label(3);
/*  29 */   public static final Label LFEScreen = new Label(4);
/*     */ 
/*     */   
/*  32 */   public static final Label LeftSurround = new Label(5);
/*     */ 
/*     */   
/*  35 */   public static final Label RightSurround = new Label(6);
/*  36 */   public static final Label LeftCenter = new Label(7);
/*  37 */   public static final Label RightCenter = new Label(8);
/*     */ 
/*     */   
/*  40 */   public static final Label CenterSurround = new Label(9);
/*     */ 
/*     */   
/*  43 */   public static final Label LeftSurroundDirect = new Label(10);
/*     */ 
/*     */   
/*  46 */   public static final Label RightSurroundDirect = new Label(11);
/*  47 */   public static final Label TopCenterSurround = new Label(12);
/*     */ 
/*     */   
/*  50 */   public static final Label VerticalHeightLeft = new Label(13);
/*     */ 
/*     */   
/*  53 */   public static final Label VerticalHeightCenter = new Label(14);
/*     */ 
/*     */   
/*  56 */   public static final Label VerticalHeightRight = new Label(15);
/*  57 */   public static final Label TopBackLeft = new Label(16);
/*  58 */   public static final Label TopBackCenter = new Label(17);
/*  59 */   public static final Label TopBackRight = new Label(18);
/*     */   
/*  61 */   public static final Label RearSurroundLeft = new Label(33);
/*  62 */   public static final Label RearSurroundRight = new Label(34);
/*  63 */   public static final Label LeftWide = new Label(35);
/*  64 */   public static final Label RightWide = new Label(36);
/*  65 */   public static final Label LFE2 = new Label(37);
/*     */ 
/*     */   
/*  68 */   public static final Label LeftTotal = new Label(38);
/*     */ 
/*     */   
/*  71 */   public static final Label RightTotal = new Label(39);
/*  72 */   public static final Label HearingImpaired = new Label(40);
/*  73 */   public static final Label Narration = new Label(41);
/*  74 */   public static final Label Mono = new Label(42);
/*  75 */   public static final Label DialogCentricMix = new Label(43);
/*     */ 
/*     */   
/*  78 */   public static final Label CenterSurroundDirect = new Label(44);
/*  79 */   public static final Label Ambisonic_W = new Label(200);
/*  80 */   public static final Label Ambisonic_X = new Label(201);
/*  81 */   public static final Label Ambisonic_Y = new Label(202);
/*  82 */   public static final Label Ambisonic_Z = new Label(203);
/*     */ 
/*     */   
/*  85 */   public static final Label MS_Mid = new Label(204);
/*  86 */   public static final Label MS_Side = new Label(205);
/*     */ 
/*     */   
/*  89 */   public static final Label XY_X = new Label(206);
/*  90 */   public static final Label XY_Y = new Label(207);
/*     */   
/*  92 */   public static final Label HeadphonesLeft = new Label(301);
/*  93 */   public static final Label HeadphonesRight = new Label(302);
/*  94 */   public static final Label ClickTrack = new Label(304);
/*  95 */   public static final Label ForeignLanguage = new Label(305);
/*     */ 
/*     */   
/*  98 */   public static final Label Discrete = new Label(400);
/*     */ 
/*     */   
/* 101 */   public static final Label Discrete_0 = new Label(65536);
/*     */   
/* 103 */   public static final Label Discrete_1 = new Label(65537);
/*     */   
/* 105 */   public static final Label Discrete_2 = new Label(65538);
/*     */   
/* 107 */   public static final Label Discrete_3 = new Label(65539);
/*     */   
/* 109 */   public static final Label Discrete_4 = new Label(65540);
/*     */   
/* 111 */   public static final Label Discrete_5 = new Label(65541);
/*     */   
/* 113 */   public static final Label Discrete_6 = new Label(65542);
/*     */   
/* 115 */   public static final Label Discrete_7 = new Label(65543);
/*     */   
/* 117 */   public static final Label Discrete_8 = new Label(65544);
/*     */   
/* 119 */   public static final Label Discrete_9 = new Label(65545);
/*     */   
/* 121 */   public static final Label Discrete_10 = new Label(65546);
/*     */   
/* 123 */   public static final Label Discrete_11 = new Label(65547);
/*     */   
/* 125 */   public static final Label Discrete_12 = new Label(65548);
/*     */   
/* 127 */   public static final Label Discrete_13 = new Label(65549);
/*     */   
/* 129 */   public static final Label Discrete_14 = new Label(65550);
/*     */   
/* 131 */   public static final Label Discrete_15 = new Label(65551);
/*     */   
/* 133 */   public static final Label Discrete_65535 = new Label(131071);
/*     */   
/*     */   final int labelVal;
/*     */   public final long bitmapVal;
/* 137 */   public static final Pattern channelMappingRegex = Pattern.compile("[_\\ \\.][a-zA-Z]+$");
/*     */   
/*     */   private Label(int val) {
/* 140 */     this.labelVal = val;
/* 141 */     this.bitmapVal = (this.labelVal > 18 || this.labelVal < 1) ? 0L : (1 << this.labelVal - 1);
/* 142 */     _values.add(this);
/*     */   }
/*     */   
/*     */   public static Label[] values() {
/* 146 */     return _values.<Label>toArray(new Label[0]);
/*     */   }
/*     */   
/*     */   public static Label getByVal(int val) {
/* 150 */     Label[] values = values();
/* 151 */     for (int i = 0; i < values.length; i++) {
/* 152 */       Label label = values[i];
/* 153 */       if (label.labelVal == val)
/* 154 */         return label; 
/*     */     } 
/* 156 */     return Mono;
/*     */   }
/*     */   
/*     */   public int getVal() {
/* 160 */     return this.labelVal;
/*     */   }
/*     */ }


/* Location:              C:\Users\rapha\Downloads\aurora.jar!\META-INF\jars\jcodec-0.2.5.jar!\org\jcodec\common\model\Label.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */