/*    */ package org.jcodec.common.model;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class Rect
/*    */ {
/*    */   private int x;
/*    */   private int y;
/*    */   private int width;
/*    */   private int height;
/*    */   
/*    */   public Rect(int x, int y, int width, int height) {
/* 17 */     this.x = x;
/* 18 */     this.y = y;
/* 19 */     this.width = width;
/* 20 */     this.height = height;
/*    */   }
/*    */   
/*    */   public int getX() {
/* 24 */     return this.x;
/*    */   }
/*    */   
/*    */   public int getY() {
/* 28 */     return this.y;
/*    */   }
/*    */   
/*    */   public int getWidth() {
/* 32 */     return this.width;
/*    */   }
/*    */   
/*    */   public int getHeight() {
/* 36 */     return this.height;
/*    */   }
/*    */ 
/*    */   
/*    */   public int hashCode() {
/* 41 */     int prime = 31;
/* 42 */     int result = 1;
/* 43 */     result = 31 * result + this.height;
/* 44 */     result = 31 * result + this.width;
/* 45 */     result = 31 * result + this.x;
/* 46 */     result = 31 * result + this.y;
/* 47 */     return result;
/*    */   }
/*    */ 
/*    */   
/*    */   public boolean equals(Object obj) {
/* 52 */     if (this == obj)
/* 53 */       return true; 
/* 54 */     if (obj == null)
/* 55 */       return false; 
/* 56 */     if (getClass() != obj.getClass())
/* 57 */       return false; 
/* 58 */     Rect other = (Rect)obj;
/* 59 */     if (this.height != other.height)
/* 60 */       return false; 
/* 61 */     if (this.width != other.width)
/* 62 */       return false; 
/* 63 */     if (this.x != other.x)
/* 64 */       return false; 
/* 65 */     if (this.y != other.y)
/* 66 */       return false; 
/* 67 */     return true;
/*    */   }
/*    */ 
/*    */   
/*    */   public String toString() {
/* 72 */     return "Rect [x=" + this.x + ", y=" + this.y + ", width=" + this.width + ", height=" + this.height + "]";
/*    */   }
/*    */ }


/* Location:              C:\Users\rapha\Downloads\aurora.jar!\META-INF\jars\jcodec-0.2.5.jar!\org\jcodec\common\model\Rect.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */