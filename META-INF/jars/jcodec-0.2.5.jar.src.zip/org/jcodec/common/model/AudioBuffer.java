/*    */ package org.jcodec.common.model;
/*    */ 
/*    */ import java.nio.ByteBuffer;
/*    */ import org.jcodec.common.AudioFormat;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class AudioBuffer
/*    */ {
/*    */   protected ByteBuffer data;
/*    */   protected AudioFormat format;
/*    */   protected int nFrames;
/*    */   
/*    */   public AudioBuffer(ByteBuffer data, AudioFormat format, int nFrames) {
/* 21 */     this.data = data;
/* 22 */     this.format = format;
/* 23 */     this.nFrames = nFrames;
/*    */   }
/*    */   
/*    */   public ByteBuffer getData() {
/* 27 */     return this.data;
/*    */   }
/*    */   
/*    */   public AudioFormat getFormat() {
/* 31 */     return this.format;
/*    */   }
/*    */   
/*    */   public int getNFrames() {
/* 35 */     return this.nFrames;
/*    */   }
/*    */ }


/* Location:              C:\Users\rapha\Downloads\aurora.jar!\META-INF\jars\jcodec-0.2.5.jar!\org\jcodec\common\model\AudioBuffer.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */