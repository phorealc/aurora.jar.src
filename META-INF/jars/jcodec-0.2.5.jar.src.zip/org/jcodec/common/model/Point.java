/*    */ package org.jcodec.common.model;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class Point
/*    */ {
/*    */   private int x;
/*    */   private int y;
/*    */   
/*    */   public Point(int x, int y) {
/* 15 */     this.x = x;
/* 16 */     this.y = y;
/*    */   }
/*    */   
/*    */   public int getX() {
/* 20 */     return this.x;
/*    */   }
/*    */   
/*    */   public int getY() {
/* 24 */     return this.y;
/*    */   }
/*    */ }


/* Location:              C:\Users\rapha\Downloads\aurora.jar!\META-INF\jars\jcodec-0.2.5.jar!\org\jcodec\common\model\Point.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */