/*     */ package org.jcodec.common.model;
/*     */ 
/*     */ import java.util.Arrays;
/*     */ import org.jcodec.common.tools.MathUtil;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class Picture
/*     */ {
/*     */   private ColorSpace color;
/*     */   private int width;
/*     */   private int height;
/*     */   private byte[][] data;
/*     */   private byte[][] lowBits;
/*     */   private int lowBitsNum;
/*     */   private Rect crop;
/*     */   
/*     */   public static Picture createPicture(int width, int height, byte[][] data, ColorSpace color) {
/*  33 */     return new Picture(width, height, data, (byte[][])null, color, 0, new Rect(0, 0, width, height));
/*     */   }
/*     */ 
/*     */   
/*     */   public static Picture createPictureHiBD(int width, int height, byte[][] data, byte[][] lowBits, ColorSpace color, int lowBitsNum) {
/*  38 */     return new Picture(width, height, data, lowBits, color, lowBitsNum, new Rect(0, 0, width, height));
/*     */   }
/*     */   
/*     */   public Picture(int width, int height, byte[][] data, byte[][] lowBits, ColorSpace color, int lowBitsNum, Rect crop) {
/*  42 */     this.width = width;
/*  43 */     this.height = height;
/*  44 */     this.data = data;
/*  45 */     this.lowBits = lowBits;
/*  46 */     this.color = color;
/*  47 */     this.lowBitsNum = lowBitsNum;
/*  48 */     this.crop = crop;
/*     */     
/*  50 */     if (color != null) {
/*  51 */       for (int i = 0; i < color.nComp; i++) {
/*  52 */         int mask = 255 >> 8 - color.compWidth[i];
/*  53 */         if ((width & mask) != 0) {
/*  54 */           throw new IllegalArgumentException("Component " + i + " width should be a multiple of " + (1 << color.compWidth[i]) + " for colorspace: " + color);
/*     */         }
/*  56 */         if (crop != null && (crop.getWidth() & mask) != 0) {
/*  57 */           throw new IllegalArgumentException("Component " + i + " cropped width should be a multiple of " + (1 << color.compWidth[i]) + " for colorspace: " + color);
/*     */         }
/*  59 */         mask = 255 >> 8 - color.compHeight[i];
/*  60 */         if ((height & mask) != 0) {
/*  61 */           throw new IllegalArgumentException("Component " + i + " height should be a multiple of " + (1 << color.compHeight[i]) + " for colorspace: " + color);
/*     */         }
/*  63 */         if (crop != null && (crop.getHeight() & mask) != 0) {
/*  64 */           throw new IllegalArgumentException("Component " + i + " cropped height should be a multiple of " + (1 << color.compHeight[i]) + " for colorspace: " + color);
/*     */         }
/*     */       } 
/*     */     }
/*     */   }
/*     */   
/*     */   public static Picture copyPicture(Picture other) {
/*  71 */     return new Picture(other.width, other.height, other.data, other.lowBits, other.color, 0, other.crop);
/*     */   }
/*     */   
/*     */   public static Picture create(int width, int height, ColorSpace colorSpace) {
/*  75 */     return createCropped(width, height, colorSpace, null);
/*     */   }
/*     */   
/*     */   public static Picture createCropped(int width, int height, ColorSpace colorSpace, Rect crop) {
/*  79 */     int[] planeSizes = new int[4];
/*  80 */     for (int i = 0; i < colorSpace.nComp; i++) {
/*  81 */       planeSizes[colorSpace.compPlane[i]] = planeSizes[colorSpace.compPlane[i]] + (width >> colorSpace.compWidth[i]) * (height >> colorSpace.compHeight[i]);
/*     */     }
/*     */     
/*  84 */     int nPlanes = 0;
/*  85 */     for (int j = 0; j < 4; j++) {
/*  86 */       nPlanes += (planeSizes[j] != 0) ? 1 : 0;
/*     */     }
/*  88 */     byte[][] data = new byte[nPlanes][];
/*  89 */     for (int k = 0, plane = 0; k < 4; k++) {
/*  90 */       if (planeSizes[k] != 0) {
/*  91 */         data[plane++] = new byte[planeSizes[k]];
/*     */       }
/*     */     } 
/*  94 */     return new Picture(width, height, data, (byte[][])null, colorSpace, 0, crop);
/*     */   }
/*     */   
/*     */   public static Picture createCroppedHiBD(int width, int height, int lowBitsNum, ColorSpace colorSpace, Rect crop) {
/*  98 */     Picture result = createCropped(width, height, colorSpace, crop);
/*  99 */     if (lowBitsNum <= 0)
/* 100 */       return result; 
/* 101 */     byte[][] data = result.getData();
/* 102 */     int nPlanes = data.length;
/*     */     
/* 104 */     byte[][] lowBits = new byte[nPlanes][];
/* 105 */     for (int i = 0, plane = 0; i < nPlanes; i++) {
/* 106 */       lowBits[plane++] = new byte[(data[i]).length];
/*     */     }
/* 108 */     result.setLowBits(lowBits);
/* 109 */     result.setLowBitsNum(lowBitsNum);
/*     */     
/* 111 */     return result;
/*     */   }
/*     */   
/*     */   private void setLowBitsNum(int lowBitsNum) {
/* 115 */     this.lowBitsNum = lowBitsNum;
/*     */   }
/*     */   
/*     */   private void setLowBits(byte[][] lowBits) {
/* 119 */     this.lowBits = lowBits;
/*     */   }
/*     */   
/*     */   public int getWidth() {
/* 123 */     return this.width;
/*     */   }
/*     */   
/*     */   public int getHeight() {
/* 127 */     return this.height;
/*     */   }
/*     */   
/*     */   public byte[] getPlaneData(int plane) {
/* 131 */     return this.data[plane];
/*     */   }
/*     */   
/*     */   public ColorSpace getColor() {
/* 135 */     return this.color;
/*     */   }
/*     */   
/*     */   public byte[][] getData() {
/* 139 */     return this.data;
/*     */   }
/*     */   
/*     */   public byte[][] getLowBits() {
/* 143 */     return this.lowBits;
/*     */   }
/*     */ 
/*     */   
/*     */   public Rect getCrop() {
/* 148 */     return this.crop;
/*     */   }
/*     */   
/*     */   public int getPlaneWidth(int plane) {
/* 152 */     return this.width >> this.color.compWidth[plane];
/*     */   }
/*     */   
/*     */   public int getPlaneHeight(int plane) {
/* 156 */     return this.height >> this.color.compHeight[plane];
/*     */   }
/*     */   
/*     */   public boolean compatible(Picture src) {
/* 160 */     return (src.color == this.color && src.width == this.width && src.height == this.height);
/*     */   }
/*     */   
/*     */   public Picture createCompatible() {
/* 164 */     return create(this.width, this.height, this.color);
/*     */   }
/*     */   
/*     */   public void copyFrom(Picture src) {
/* 168 */     if (!compatible(src))
/* 169 */       throw new IllegalArgumentException("Can not copy to incompatible picture"); 
/* 170 */     for (int plane = 0; plane < this.color.nComp; plane++) {
/* 171 */       if (this.data[plane] != null)
/*     */       {
/* 173 */         System.arraycopy(src.data[plane], 0, this.data[plane], 0, (this.width >> this.color.compWidth[plane]) * (this.height >> this.color.compHeight[plane]));
/*     */       }
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Picture cloneCropped() {
/* 184 */     if (cropNeeded()) {
/* 185 */       return cropped();
/*     */     }
/* 187 */     Picture clone = createCompatible();
/* 188 */     clone.copyFrom(this);
/* 189 */     return clone;
/*     */   }
/*     */ 
/*     */   
/*     */   public Picture cropped() {
/* 194 */     if (!cropNeeded())
/* 195 */       return this; 
/* 196 */     Picture result = create(this.crop.getWidth(), this.crop.getHeight(), this.color);
/*     */     
/* 198 */     if (this.color.planar) {
/* 199 */       for (int plane = 0; plane < this.data.length; plane++) {
/* 200 */         if (this.data[plane] != null)
/*     */         {
/* 202 */           cropSub(this.data[plane], this.crop.getX() >> this.color.compWidth[plane], this.crop.getY() >> this.color.compHeight[plane], this.crop
/* 203 */               .getWidth() >> this.color.compWidth[plane], this.crop.getHeight() >> this.color.compHeight[plane], this.width >> this.color.compWidth[plane], this.crop
/* 204 */               .getWidth() >> this.color.compWidth[plane], result.data[plane]); } 
/*     */       } 
/*     */     } else {
/* 207 */       cropSub(this.data[0], this.crop.getX(), this.crop.getY(), this.crop.getWidth(), this.crop
/* 208 */           .getHeight(), this.width * this.color.nComp, this.crop.getWidth() * this.color.nComp, result.data[0]);
/*     */     } 
/*     */     
/* 211 */     return result;
/*     */   }
/*     */   
/*     */   protected boolean cropNeeded() {
/* 215 */     return (this.crop != null && (this.crop
/* 216 */       .getX() != 0 || this.crop.getY() != 0 || this.crop.getWidth() != this.width || this.crop.getHeight() != this.height));
/*     */   }
/*     */   
/*     */   private void cropSub(byte[] src, int x, int y, int w, int h, int srcStride, int dstStride, byte[] tgt) {
/* 220 */     int srcOff = y * srcStride + x, dstOff = 0;
/* 221 */     for (int i = 0; i < h; i++) {
/* 222 */       for (int j = 0; j < dstStride; j++) {
/* 223 */         tgt[dstOff + j] = src[srcOff + j];
/*     */       }
/* 225 */       srcOff += srcStride;
/* 226 */       dstOff += dstStride;
/*     */     } 
/*     */   }
/*     */   
/*     */   public void setCrop(Rect crop) {
/* 231 */     this.crop = crop;
/*     */   }
/*     */   
/*     */   public int getCroppedWidth() {
/* 235 */     return (this.crop == null) ? this.width : this.crop.getWidth();
/*     */   }
/*     */   
/*     */   public int getCroppedHeight() {
/* 239 */     return (this.crop == null) ? this.height : this.crop.getHeight();
/*     */   }
/*     */   
/*     */   public int getLowBitsNum() {
/* 243 */     return this.lowBitsNum;
/*     */   }
/*     */   
/*     */   public static Picture fromPictureHiBD(PictureHiBD pic) {
/* 247 */     int lowBitsNum = pic.getBitDepth() - 8;
/* 248 */     int lowBitsRound = 1 << lowBitsNum >> 1;
/*     */     
/* 250 */     Picture result = createCroppedHiBD(pic.getWidth(), pic.getHeight(), lowBitsNum, pic.getColor(), pic
/* 251 */         .getCrop());
/*     */     
/* 253 */     for (int i = 0; i < Math.min((pic.getData()).length, (result.getData()).length); i++) {
/* 254 */       for (int j = 0; j < Math.min((pic.getData()[i]).length, (result.getData()[i]).length); j++) {
/* 255 */         int val = pic.getData()[i][j];
/* 256 */         int round = MathUtil.clip(val + lowBitsRound >> lowBitsNum, 0, 255);
/* 257 */         result.getData()[i][j] = (byte)(round - 128);
/*     */       } 
/*     */     } 
/*     */     
/* 261 */     byte[][] lowBits = result.getLowBits();
/* 262 */     if (lowBits != null) {
/* 263 */       for (int j = 0; j < Math.min((pic.getData()).length, (result.getData()).length); j++) {
/* 264 */         for (int k = 0; k < Math.min((pic.getData()[j]).length, (result.getData()[j]).length); k++) {
/* 265 */           int val = pic.getData()[j][k];
/* 266 */           int round = MathUtil.clip(val + lowBitsRound >> lowBitsNum, 0, 255);
/* 267 */           lowBits[j][k] = (byte)(val - (round << 2));
/*     */         } 
/*     */       } 
/*     */     }
/*     */     
/* 272 */     return result;
/*     */   }
/*     */   
/*     */   public PictureHiBD toPictureHiBD() {
/* 276 */     PictureHiBD create = PictureHiBD.doCreate(this.width, this.height, this.color, this.lowBitsNum + 8, this.crop);
/*     */     
/* 278 */     return toPictureHiBDInternal(create);
/*     */   }
/*     */   
/*     */   public PictureHiBD toPictureHiBDWithBuffer(int[][] buffer) {
/* 282 */     PictureHiBD create = new PictureHiBD(this.width, this.height, buffer, this.color, this.lowBitsNum + 8, this.crop);
/*     */     
/* 284 */     return toPictureHiBDInternal(create);
/*     */   }
/*     */   
/*     */   private PictureHiBD toPictureHiBDInternal(PictureHiBD pic) {
/* 288 */     int[][] dstData = pic.getData();
/*     */     int i;
/* 290 */     for (i = 0; i < this.data.length; i++) {
/* 291 */       int planeSize = getPlaneWidth(i) * getPlaneHeight(i);
/* 292 */       for (int j = 0; j < planeSize; j++) {
/* 293 */         dstData[i][j] = this.data[i][j] + 128 << this.lowBitsNum;
/*     */       }
/*     */     } 
/*     */     
/* 297 */     if (this.lowBits != null) {
/* 298 */       for (i = 0; i < this.lowBits.length; i++) {
/* 299 */         int planeSize = getPlaneWidth(i) * getPlaneHeight(i);
/* 300 */         for (int j = 0; j < planeSize; j++) {
/* 301 */           dstData[i][j] = dstData[i][j] + this.lowBits[i][j];
/*     */         }
/*     */       } 
/*     */     }
/*     */     
/* 306 */     return pic;
/*     */   }
/*     */   
/*     */   public void fill(int val) {
/* 310 */     for (int i = 0; i < this.data.length; i++) {
/* 311 */       Arrays.fill(this.data[i], (byte)val);
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean equals(Object obj) {
/* 317 */     if (obj == null || !(obj instanceof Picture))
/* 318 */       return false; 
/* 319 */     Picture other = (Picture)obj;
/*     */     
/* 321 */     if (other.getCroppedWidth() != getCroppedWidth() || other.getCroppedHeight() != getCroppedHeight() || other
/* 322 */       .getColor() != this.color) {
/* 323 */       return false;
/*     */     }
/* 325 */     for (int i = 0; i < (getData()).length; i++) {
/* 326 */       if (!planeEquals(other, i))
/* 327 */         return false; 
/* 328 */     }  return true;
/*     */   }
/*     */   
/*     */   private boolean planeEquals(Picture other, int plane) {
/* 332 */     int cw = this.color.compWidth[plane];
/* 333 */     int ch = this.color.compHeight[plane];
/*     */     
/* 335 */     int offA = (other.getCrop() == null) ? 0 : ((other.getCrop().getX() >> cw) + (other.getCrop().getY() >> ch) * (other.getWidth() >> cw));
/* 336 */     int offB = (this.crop == null) ? 0 : ((this.crop.getX() >> cw) + (this.crop.getY() >> ch) * (this.width >> cw));
/*     */     
/* 338 */     byte[] planeData = other.getPlaneData(plane);
/* 339 */     for (int i = 0; i < getCroppedHeight() >> ch; i++, offA += other.getWidth() >> cw, offB += this.width >> cw) {
/* 340 */       for (int j = 0; j < getCroppedWidth() >> cw; j++) {
/* 341 */         if (planeData[offA + j] != this.data[plane][offB + j])
/* 342 */           return false; 
/*     */       } 
/*     */     } 
/* 345 */     return true;
/*     */   }
/*     */   
/*     */   public int getStartX() {
/* 349 */     return (this.crop == null) ? 0 : this.crop.getX();
/*     */   }
/*     */   
/*     */   public int getStartY() {
/* 353 */     return (this.crop == null) ? 0 : this.crop.getY();
/*     */   }
/*     */   
/*     */   public boolean isHiBD() {
/* 357 */     return (this.lowBits != null);
/*     */   }
/*     */   
/*     */   public Size getSize() {
/* 361 */     return new Size(this.width, this.height);
/*     */   }
/*     */ }


/* Location:              C:\Users\rapha\Downloads\aurora.jar!\META-INF\jars\jcodec-0.2.5.jar!\org\jcodec\common\model\Picture.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */