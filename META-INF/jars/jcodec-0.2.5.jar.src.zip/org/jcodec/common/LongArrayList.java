/*     */ package org.jcodec.common;
/*     */ 
/*     */ import java.util.Arrays;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class LongArrayList
/*     */ {
/*     */   private static final int DEFAULT_GROW_AMOUNT = 128;
/*     */   private long[] storage;
/*     */   private int limit;
/*     */   private int start;
/*     */   private int growAmount;
/*     */   
/*     */   public static LongArrayList createLongArrayList() {
/*  24 */     return new LongArrayList(128);
/*     */   }
/*     */   
/*     */   public LongArrayList(int growAmount) {
/*  28 */     this.growAmount = growAmount;
/*  29 */     this.storage = new long[growAmount];
/*     */   }
/*     */   
/*     */   public long[] toArray() {
/*  33 */     long[] result = new long[this.limit - this.start];
/*  34 */     System.arraycopy(this.storage, this.start, result, 0, this.limit - this.start);
/*  35 */     return result;
/*     */   }
/*     */   
/*     */   public void add(long val) {
/*  39 */     if (this.limit > this.storage.length - 1) {
/*  40 */       long[] ns = new long[this.storage.length + this.growAmount - this.start];
/*  41 */       System.arraycopy(this.storage, this.start, ns, 0, this.storage.length - this.start);
/*  42 */       this.storage = ns;
/*  43 */       this.limit -= this.start;
/*  44 */       this.start = 0;
/*     */     } 
/*  46 */     this.storage[this.limit++] = val;
/*     */   }
/*     */   
/*     */   public void push(long id) {
/*  50 */     add(id);
/*     */   }
/*     */   
/*     */   public long pop() {
/*  54 */     if (this.limit <= this.start)
/*  55 */       throw new IllegalStateException(); 
/*  56 */     return this.storage[this.limit--];
/*     */   }
/*     */   
/*     */   public void set(int index, int value) {
/*  60 */     this.storage[index + this.start] = value;
/*     */   }
/*     */   
/*     */   public long get(int index) {
/*  64 */     return this.storage[index + this.start];
/*     */   }
/*     */   
/*     */   public long shift() {
/*  68 */     if (this.start >= this.limit)
/*  69 */       throw new IllegalStateException(); 
/*  70 */     return this.storage[this.start++];
/*     */   }
/*     */   
/*     */   public void fill(int from, int to, int val) {
/*  74 */     if (to > this.storage.length) {
/*  75 */       long[] ns = new long[to + this.growAmount - this.start];
/*  76 */       System.arraycopy(this.storage, this.start, ns, 0, this.storage.length - this.start);
/*  77 */       this.storage = ns;
/*     */     } 
/*  79 */     Arrays.fill(this.storage, from, to, val);
/*  80 */     this.limit = Math.max(this.limit, to);
/*     */   }
/*     */   
/*     */   public int size() {
/*  84 */     return this.limit - this.start;
/*     */   }
/*     */   
/*     */   public void addAll(long[] other) {
/*  88 */     if (this.limit + other.length >= this.storage.length) {
/*  89 */       long[] ns = new long[this.limit + this.growAmount + other.length - this.start];
/*  90 */       System.arraycopy(this.storage, this.start, ns, 0, this.limit);
/*  91 */       this.storage = ns;
/*     */     } 
/*  93 */     System.arraycopy(other, 0, this.storage, this.limit, other.length);
/*  94 */     this.limit += other.length;
/*     */   }
/*     */   
/*     */   public void clear() {
/*  98 */     this.limit = 0;
/*  99 */     this.start = 0;
/*     */   }
/*     */   
/*     */   public boolean contains(long needle) {
/* 103 */     for (int i = this.start; i < this.limit; i++) {
/* 104 */       if (this.storage[i] == needle)
/* 105 */         return true; 
/* 106 */     }  return false;
/*     */   }
/*     */ }


/* Location:              C:\Users\rapha\Downloads\aurora.jar!\META-INF\jars\jcodec-0.2.5.jar!\org\jcodec\common\LongArrayList.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */