/*    */ package org.jcodec.common;
/*    */ 
/*    */ import java.nio.ByteBuffer;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class DemuxerTrackMeta
/*    */ {
/*    */   private TrackType type;
/*    */   private Codec codec;
/*    */   private double totalDuration;
/*    */   private int[] seekFrames;
/*    */   private int totalFrames;
/*    */   private ByteBuffer codecPrivate;
/*    */   private VideoCodecMeta videoCodecMeta;
/*    */   private AudioCodecMeta audioCodecMeta;
/*    */   private int index;
/*    */   private Orientation orientation;
/*    */   
/*    */   public enum Orientation
/*    */   {
/* 27 */     D_0, D_90, D_180, D_270;
/*    */   }
/*    */   
/*    */   public DemuxerTrackMeta(TrackType type, Codec codec, double totalDuration, int[] seekFrames, int totalFrames, ByteBuffer codecPrivate, VideoCodecMeta videoCodecMeta, AudioCodecMeta audioCodecMeta) {
/* 31 */     this.type = type;
/* 32 */     this.codec = codec;
/* 33 */     this.totalDuration = totalDuration;
/* 34 */     this.seekFrames = seekFrames;
/* 35 */     this.totalFrames = totalFrames;
/* 36 */     this.codecPrivate = codecPrivate;
/* 37 */     this.videoCodecMeta = videoCodecMeta;
/* 38 */     this.audioCodecMeta = audioCodecMeta;
/* 39 */     this.orientation = Orientation.D_0;
/*    */   }
/*    */   
/*    */   public TrackType getType() {
/* 43 */     return this.type;
/*    */   }
/*    */   
/*    */   public Codec getCodec() {
/* 47 */     return this.codec;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public double getTotalDuration() {
/* 54 */     return this.totalDuration;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public int[] getSeekFrames() {
/* 63 */     return this.seekFrames;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public int getTotalFrames() {
/* 70 */     return this.totalFrames;
/*    */   }
/*    */   
/*    */   public int getIndex() {
/* 74 */     return this.index;
/*    */   }
/*    */   
/*    */   public ByteBuffer getCodecPrivate() {
/* 78 */     return this.codecPrivate;
/*    */   }
/*    */   
/*    */   public VideoCodecMeta getVideoCodecMeta() {
/* 82 */     return this.videoCodecMeta;
/*    */   }
/*    */   
/*    */   public AudioCodecMeta getAudioCodecMeta() {
/* 86 */     return this.audioCodecMeta;
/*    */   }
/*    */   
/*    */   public void setOrientation(Orientation orientation) {
/* 90 */     this.orientation = orientation;
/*    */   }
/*    */   
/*    */   public Orientation getOrientation() {
/* 94 */     return this.orientation;
/*    */   }
/*    */ }


/* Location:              C:\Users\rapha\Downloads\aurora.jar!\META-INF\jars\jcodec-0.2.5.jar!\org\jcodec\common\DemuxerTrackMeta.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */