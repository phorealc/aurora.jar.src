/*     */ package org.jcodec.common;
/*     */ 
/*     */ import java.util.LinkedHashMap;
/*     */ import java.util.Map;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class Codec
/*     */ {
/*  17 */   public static final Codec H264 = new Codec("H264", TrackType.VIDEO);
/*  18 */   public static final Codec MPEG2 = new Codec("MPEG2", TrackType.VIDEO);
/*  19 */   public static final Codec MPEG4 = new Codec("MPEG4", TrackType.VIDEO);
/*  20 */   public static final Codec PRORES = new Codec("PRORES", TrackType.VIDEO);
/*  21 */   public static final Codec DV = new Codec("DV", TrackType.VIDEO);
/*  22 */   public static final Codec VC1 = new Codec("VC1", TrackType.VIDEO);
/*  23 */   public static final Codec VC3 = new Codec("VC3", TrackType.VIDEO);
/*  24 */   public static final Codec V210 = new Codec("V210", TrackType.VIDEO);
/*  25 */   public static final Codec SORENSON = new Codec("SORENSON", TrackType.VIDEO);
/*  26 */   public static final Codec FLASH_SCREEN_VIDEO = new Codec("FLASH_SCREEN_VIDEO", TrackType.VIDEO);
/*  27 */   public static final Codec FLASH_SCREEN_V2 = new Codec("FLASH_SCREEN_V2", TrackType.VIDEO);
/*  28 */   public static final Codec PNG = new Codec("PNG", TrackType.VIDEO);
/*  29 */   public static final Codec JPEG = new Codec("JPEG", TrackType.VIDEO);
/*  30 */   public static final Codec J2K = new Codec("J2K", TrackType.VIDEO);
/*  31 */   public static final Codec VP6 = new Codec("VP6", TrackType.VIDEO);
/*  32 */   public static final Codec VP8 = new Codec("VP8", TrackType.VIDEO);
/*  33 */   public static final Codec VP9 = new Codec("VP9", TrackType.VIDEO);
/*  34 */   public static final Codec VORBIS = new Codec("VORBIS", TrackType.VIDEO);
/*  35 */   public static final Codec AAC = new Codec("AAC", TrackType.AUDIO);
/*  36 */   public static final Codec MP3 = new Codec("MP3", TrackType.AUDIO);
/*  37 */   public static final Codec MP2 = new Codec("MP2", TrackType.AUDIO);
/*  38 */   public static final Codec MP1 = new Codec("MP1", TrackType.AUDIO);
/*  39 */   public static final Codec AC3 = new Codec("AC3", TrackType.AUDIO);
/*  40 */   public static final Codec DTS = new Codec("DTS", TrackType.AUDIO);
/*  41 */   public static final Codec TRUEHD = new Codec("TRUEHD", TrackType.AUDIO);
/*  42 */   public static final Codec PCM_DVD = new Codec("PCM_DVD", TrackType.AUDIO);
/*  43 */   public static final Codec PCM = new Codec("PCM", TrackType.AUDIO);
/*  44 */   public static final Codec ADPCM = new Codec("ADPCM", TrackType.AUDIO);
/*  45 */   public static final Codec ALAW = new Codec("ALAW", TrackType.AUDIO);
/*  46 */   public static final Codec NELLYMOSER = new Codec("NELLYMOSER", TrackType.AUDIO);
/*  47 */   public static final Codec G711 = new Codec("G711", TrackType.AUDIO);
/*  48 */   public static final Codec SPEEX = new Codec("SPEEX", TrackType.AUDIO);
/*  49 */   public static final Codec RAW = new Codec("RAW", null);
/*  50 */   public static final Codec TIMECODE = new Codec("TIMECODE", TrackType.OTHER);
/*     */   
/*  52 */   private static final Map<String, Codec> _values = new LinkedHashMap<String, Codec>();
/*     */   static {
/*  54 */     _values.put("H264", H264);
/*  55 */     _values.put("MPEG2", MPEG2);
/*  56 */     _values.put("MPEG4", MPEG4);
/*  57 */     _values.put("PRORES", PRORES);
/*  58 */     _values.put("DV", DV);
/*  59 */     _values.put("VC1", VC1);
/*  60 */     _values.put("VC3", VC3);
/*  61 */     _values.put("V210", V210);
/*  62 */     _values.put("SORENSON", SORENSON);
/*  63 */     _values.put("FLASH_SCREEN_VIDEO", FLASH_SCREEN_VIDEO);
/*  64 */     _values.put("FLASH_SCREEN_V2", FLASH_SCREEN_V2);
/*  65 */     _values.put("PNG", PNG);
/*  66 */     _values.put("JPEG", JPEG);
/*  67 */     _values.put("J2K", J2K);
/*  68 */     _values.put("VP6", VP6);
/*  69 */     _values.put("VP8", VP8);
/*  70 */     _values.put("VP9", VP9);
/*  71 */     _values.put("VORBIS", VORBIS);
/*  72 */     _values.put("AAC", AAC);
/*  73 */     _values.put("MP3", MP3);
/*  74 */     _values.put("MP2", MP2);
/*  75 */     _values.put("MP1", MP1);
/*  76 */     _values.put("AC3", AC3);
/*  77 */     _values.put("DTS", DTS);
/*  78 */     _values.put("TRUEHD", TRUEHD);
/*  79 */     _values.put("PCM_DVD", PCM_DVD);
/*  80 */     _values.put("PCM", PCM);
/*  81 */     _values.put("ADPCM", ADPCM);
/*  82 */     _values.put("ALAW", ALAW);
/*  83 */     _values.put("NELLYMOSER", NELLYMOSER);
/*  84 */     _values.put("G711", G711);
/*  85 */     _values.put("SPEEX", SPEEX);
/*  86 */     _values.put("RAW", RAW);
/*  87 */     _values.put("TIMECODE", TIMECODE);
/*     */   }
/*     */   
/*     */   private final String _name;
/*     */   private final TrackType type;
/*     */   
/*     */   public Codec(String name, TrackType type) {
/*  94 */     this._name = name;
/*  95 */     this.type = type;
/*     */   }
/*     */   
/*     */   public TrackType getType() {
/*  99 */     return this.type;
/*     */   }
/*     */   
/*     */   public static Codec codecByFourcc(String fourcc) {
/* 103 */     if (fourcc.equals("avc1"))
/* 104 */       return H264; 
/* 105 */     if (fourcc.equals("m1v1") || fourcc.equals("m2v1"))
/* 106 */       return MPEG2; 
/* 107 */     if (fourcc.equals("apco") || fourcc.equals("apcs") || fourcc.equals("apcn") || fourcc.equals("apch") || fourcc
/* 108 */       .equals("ap4h"))
/* 109 */       return PRORES; 
/* 110 */     if (fourcc.equals("mp4a"))
/* 111 */       return AAC; 
/* 112 */     if (fourcc.equals("jpeg")) {
/* 113 */       return JPEG;
/*     */     }
/* 115 */     return null;
/*     */   }
/*     */   
/*     */   public static Codec valueOf(String s) {
/* 119 */     return _values.get(s);
/*     */   }
/*     */ 
/*     */   
/*     */   public String toString() {
/* 124 */     return this._name;
/*     */   }
/*     */   
/*     */   public String name() {
/* 128 */     return this._name;
/*     */   }
/*     */ }


/* Location:              C:\Users\rapha\Downloads\aurora.jar!\META-INF\jars\jcodec-0.2.5.jar!\org\jcodec\common\Codec.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */