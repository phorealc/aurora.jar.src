/*    */ package org.jcodec.common;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class Ints
/*    */ {
/*    */   public static int checkedCast(long value) {
/* 13 */     int result = (int)value;
/* 14 */     if (result != value)
/*    */     {
/* 16 */       throw new IllegalArgumentException("Out of range: " + value);
/*    */     }
/* 18 */     return result;
/*    */   }
/*    */ }


/* Location:              C:\Users\rapha\Downloads\aurora.jar!\META-INF\jars\jcodec-0.2.5.jar!\org\jcodec\common\Ints.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */