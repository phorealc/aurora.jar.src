package org.jcodec.common;

import java.io.IOException;

public interface SeekableDemuxerTrack extends DemuxerTrack {
  boolean gotoFrame(long paramLong) throws IOException;
  
  boolean gotoSyncFrame(long paramLong) throws IOException;
  
  long getCurFrame();
  
  void seek(double paramDouble) throws IOException;
}


/* Location:              C:\Users\rapha\Downloads\aurora.jar!\META-INF\jars\jcodec-0.2.5.jar!\org\jcodec\common\SeekableDemuxerTrack.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */