/*    */ package org.jcodec.common;
/*    */ 
/*    */ import java.util.Arrays;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class IntArrayList
/*    */ {
/*    */   private static final int DEFAULT_GROW_AMOUNT = 128;
/*    */   private int[] storage;
/*    */   private int _size;
/*    */   private int growAmount;
/*    */   
/*    */   public static IntArrayList createIntArrayList() {
/* 22 */     return new IntArrayList(128);
/*    */   }
/*    */   
/*    */   public IntArrayList(int growAmount) {
/* 26 */     this.growAmount = growAmount;
/* 27 */     this.storage = new int[growAmount];
/*    */   }
/*    */   
/*    */   public int[] toArray() {
/* 31 */     int[] result = new int[this._size];
/* 32 */     System.arraycopy(this.storage, 0, result, 0, this._size);
/* 33 */     return result;
/*    */   }
/*    */   
/*    */   public void add(int val) {
/* 37 */     if (this._size >= this.storage.length) {
/* 38 */       int[] ns = new int[this.storage.length + this.growAmount];
/* 39 */       System.arraycopy(this.storage, 0, ns, 0, this.storage.length);
/* 40 */       this.storage = ns;
/*    */     } 
/* 42 */     this.storage[this._size++] = val;
/*    */   }
/*    */   
/*    */   public void push(int id) {
/* 46 */     add(id);
/*    */   }
/*    */   
/*    */   public void pop() {
/* 50 */     if (this._size == 0)
/*    */       return; 
/* 52 */     this._size--;
/*    */   }
/*    */   
/*    */   public void set(int index, int value) {
/* 56 */     this.storage[index] = value;
/*    */   }
/*    */   
/*    */   public int get(int index) {
/* 60 */     return this.storage[index];
/*    */   }
/*    */   
/*    */   public void fill(int start, int end, int val) {
/* 64 */     if (end > this.storage.length) {
/* 65 */       int[] ns = new int[end + this.growAmount];
/* 66 */       System.arraycopy(this.storage, 0, ns, 0, this.storage.length);
/* 67 */       this.storage = ns;
/*    */     } 
/* 69 */     Arrays.fill(this.storage, start, end, val);
/* 70 */     this._size = Math.max(this._size, end);
/*    */   }
/*    */   
/*    */   public int size() {
/* 74 */     return this._size;
/*    */   }
/*    */   
/*    */   public void addAll(int[] other) {
/* 78 */     if (this._size + other.length >= this.storage.length) {
/* 79 */       int[] ns = new int[this._size + this.growAmount + other.length];
/* 80 */       System.arraycopy(this.storage, 0, ns, 0, this._size);
/* 81 */       this.storage = ns;
/*    */     } 
/* 83 */     System.arraycopy(other, 0, this.storage, this._size, other.length);
/* 84 */     this._size += other.length;
/*    */   }
/*    */   
/*    */   public void clear() {
/* 88 */     this._size = 0;
/*    */   }
/*    */   
/*    */   public boolean contains(int needle) {
/* 92 */     for (int i = 0; i < this._size; i++) {
/* 93 */       if (this.storage[i] == needle)
/* 94 */         return true; 
/* 95 */     }  return false;
/*    */   }
/*    */ }


/* Location:              C:\Users\rapha\Downloads\aurora.jar!\META-INF\jars\jcodec-0.2.5.jar!\org\jcodec\common\IntArrayList.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */