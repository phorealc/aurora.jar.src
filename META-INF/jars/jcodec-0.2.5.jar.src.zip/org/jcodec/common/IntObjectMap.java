/*    */ package org.jcodec.common;
/*    */ 
/*    */ import java.lang.reflect.Array;
/*    */ import org.jcodec.platform.Platform;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class IntObjectMap<T>
/*    */ {
/*    */   private static final int GROW_BY = 128;
/* 21 */   private Object[] storage = new Object[128];
/*    */   private int _size;
/*    */   
/*    */   public void put(int key, T val) {
/* 25 */     if (this.storage.length <= key) {
/* 26 */       Object[] ns = new Object[key + 128];
/* 27 */       System.arraycopy(this.storage, 0, ns, 0, this.storage.length);
/* 28 */       this.storage = ns;
/*    */     } 
/* 30 */     if (this.storage[key] == null)
/* 31 */       this._size++; 
/* 32 */     this.storage[key] = val;
/*    */   }
/*    */ 
/*    */   
/*    */   public T get(int key) {
/* 37 */     return (key >= this.storage.length) ? null : (T)this.storage[key];
/*    */   }
/*    */   
/*    */   public int[] keys() {
/* 41 */     int[] result = new int[this._size];
/* 42 */     for (int i = 0, r = 0; i < this.storage.length; i++) {
/* 43 */       if (this.storage[i] != null)
/* 44 */         result[r++] = i; 
/*    */     } 
/* 46 */     return result;
/*    */   }
/*    */   
/*    */   public void clear() {
/* 50 */     for (int i = 0; i < this.storage.length; i++)
/* 51 */       this.storage[i] = null; 
/* 52 */     this._size = 0;
/*    */   }
/*    */   
/*    */   public int size() {
/* 56 */     return this._size;
/*    */   }
/*    */   
/*    */   public void remove(int key) {
/* 60 */     if (this.storage[key] != null)
/* 61 */       this._size--; 
/* 62 */     this.storage[key] = null;
/*    */   }
/*    */ 
/*    */   
/*    */   public T[] values(T[] runtime) {
/* 67 */     T[] result = (T[])Array.newInstance(Platform.arrayComponentType((Object[])runtime), this._size);
/* 68 */     for (int i = 0, r = 0; i < this.storage.length; i++) {
/* 69 */       if (this.storage[i] != null)
/* 70 */         result[r++] = (T)this.storage[i]; 
/*    */     } 
/* 72 */     return result;
/*    */   }
/*    */ }


/* Location:              C:\Users\rapha\Downloads\aurora.jar!\META-INF\jars\jcodec-0.2.5.jar!\org\jcodec\common\IntObjectMap.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */