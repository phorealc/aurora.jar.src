/*    */ package com.zigythebird.bendable_cuboids.impl;
/*    */ 
/*    */ import org.joml.Vector3f;
/*    */ 
/*    */ public class Vertex
/*    */   implements IVertex {
/*    */   protected final Vector3f pos;
/*    */   public final float u;
/*    */   public final float v;
/*    */   
/*    */   public Vertex(float x, float y, float z, float u, float v) {
/* 12 */     this(new Vector3f(x, y, z), u, v);
/*    */   }
/*    */   
/*    */   public Vertex(Vector3f pos, float u, float v) {
/* 16 */     this.pos = pos;
/* 17 */     this.u = u;
/* 18 */     this.v = v;
/*    */   }
/*    */ 
/*    */   
/*    */   public Vector3f getPos() {
/* 23 */     return this.pos;
/*    */   }
/*    */ 
/*    */   
/*    */   public float getU() {
/* 28 */     return this.u;
/*    */   }
/*    */ 
/*    */   
/*    */   public float getV() {
/* 33 */     return this.v;
/*    */   }
/*    */ 
/*    */   
/*    */   public IVertex remap(float u, float v) {
/* 38 */     return new Vertex(this.pos, u, v);
/*    */   }
/*    */ }


/* Location:              C:\Users\rapha\Downloads\aurora.jar!\META-INF\jars\bendable-cuboids-p5LKzVqY.jar!\com\zigythebird\bendable_cuboids\impl\Vertex.class
 * Java compiler version: 21 (65.0)
 * JD-Core Version:       1.1.3
 */