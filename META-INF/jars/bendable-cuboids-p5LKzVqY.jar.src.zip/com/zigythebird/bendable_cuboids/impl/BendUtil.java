/*     */ package com.zigythebird.bendable_cuboids.impl;
/*     */ import com.zigythebird.bendable_cuboids.api.BendableCube;
/*     */ import java.util.function.Function;
/*     */ import net.minecraft.class_2350;
/*     */ import net.minecraft.class_4587;
/*     */ import org.joml.Matrix4f;
/*     */ import org.joml.Matrix4fc;
/*     */ import org.joml.Vector3f;
/*     */ import org.joml.Vector3fc;
/*     */ import org.joml.Vector4f;
/*     */ 
/*     */ public class BendUtil {
/*  13 */   private static final Vector3f Z_AXIS = new Vector3f(0.0F, 0.0F, 1.0F);
/*     */   
/*     */   public static Function<Vector3f, Vector3f> getBend(BendableCube cuboid) {
/*  16 */     return getBend(cuboid, cuboid.getBend());
/*     */   }
/*     */   
/*     */   public static Function<Vector3f, Vector3f> getBend(BendableCube cuboid, float bendValue) {
/*  20 */     return getBend(cuboid.getBendX(), cuboid.getBendY(), cuboid.getBendZ(), cuboid
/*  21 */         .getBasePlane(), cuboid.getOtherPlane(), cuboid.isBendInverted(), false, cuboid.bendHeight(), cuboid
/*  22 */         .getExtentZ(), bendValue);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Function<Vector3f, Vector3f> getBend(float bendX, float bendY, float bendZ, Plane basePlane, Plane otherPlane, boolean isBendInverted, boolean mirrorBend, float bendHeight, float extentZ, float bendValue) {
/*  32 */     if (bendValue == 0.0F) return Function.identity(); 
/*  33 */     if (mirrorBend) bendValue *= -1.0F; 
/*  34 */     float finalBend = bendValue;
/*  35 */     Matrix4f transformMatrix = applyBendToMatrix(new Matrix4f(), bendX, bendY, bendZ, bendValue);
/*     */     
/*  37 */     float halfSize = bendHeight / 2.0F;
/*     */     
/*  39 */     return pos -> {
/*     */         float distFromBase = Math.abs(basePlane.distanceTo(pos));
/*     */         
/*     */         float distFromOther = Math.abs(otherPlane.distanceTo(pos));
/*     */         
/*     */         float s = (float)Math.tan((finalBend / 2.0F)) * pos.z * 2.0F / extentZ;
/*     */         if (mirrorBend || !isBendInverted) {
/*     */           float temp = distFromBase;
/*     */           distFromBase = distFromOther;
/*     */           distFromOther = temp;
/*     */         } 
/*  50 */         float v = halfSize - ((isBendInverted ? (s < 0.0F) : (s >= 0.0F)) ? Math.min(Math.abs(s) / 2.0F, 1.0F) : Math.abs(s));
/*     */         boolean isAboveNinetyDegrees = (Math.abs(clampToRadian(finalBend)) > 1.5708D);
/*     */         if (distFromBase < distFromOther) {
/*     */           if (!isAboveNinetyDegrees && distFromBase + distFromOther <= bendHeight && distFromBase > v) {
/*     */             pos.y = bendY + s;
/*     */           }
/*     */           Vector4f reposVector = new Vector4f((Vector3fc)pos, 1.0F);
/*     */           reposVector.mul((Matrix4fc)transformMatrix);
/*     */           pos = new Vector3f(reposVector.x, reposVector.y, reposVector.z);
/*     */         } else if (!isAboveNinetyDegrees && distFromBase + distFromOther <= bendHeight && distFromOther > v) {
/*     */           pos.y = bendY - s;
/*     */         } 
/*     */         return pos;
/*     */       };
/*     */   }
/*     */   
/*     */   public static Function<Vector3f, Vector3f> getBendLegacy(BendableCube cuboid, float bendValue) {
/*  67 */     return getBendLegacy(cuboid.getBendDirection(), cuboid.getBendX(), cuboid.getBendY(), cuboid.getBendZ(), cuboid
/*  68 */         .getBasePlane(), cuboid.getOtherPlane(), cuboid.isBendInverted(), false, cuboid.bendHeight(), bendValue);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Function<Vector3f, Vector3f> getBendLegacy(class_2350 bendDirection, float bendX, float bendY, float bendZ, Plane basePlane, Plane otherPlane, boolean isBendInverted, boolean mirrorBend, float bendHeight, float bendValue) {
/*  77 */     if (mirrorBend) bendValue *= -1.0F; 
/*  78 */     float finalBend = bendValue;
/*  79 */     Matrix4f transformMatrix = applyBendToMatrix(new Matrix4f(), bendX, bendY, bendZ, bendValue);
/*     */ 
/*     */ 
/*     */     
/*  83 */     Vector3f directionUnit = bendDirection.method_23955();
/*  84 */     directionUnit.cross((Vector3fc)Z_AXIS);
/*     */     
/*  86 */     Plane bendPlane = new Plane(directionUnit, new Vector3f(bendX, bendY, bendZ));
/*  87 */     float halfSize = bendHeight / 2.0F;
/*     */     
/*  89 */     return pos -> {
/*     */         float distFromBend = isBendInverted ? -bendPlane.distanceTo(pos) : bendPlane.distanceTo(pos);
/*     */         float distFromBase = basePlane.distanceTo(pos);
/*     */         float distFromOther = otherPlane.distanceTo(pos);
/*     */         Vector3f x = bendDirection.method_23955();
/*     */         if (mirrorBend) {
/*     */           float temp = distFromBase;
/*     */           distFromBase = distFromOther;
/*     */           distFromOther = temp;
/*     */           distFromBend *= -1.0F;
/*     */         } 
/*     */         double s = Math.tan((finalBend / 2.0F)) * distFromBend;
/*     */         boolean isInBendArea = (Math.abs(distFromBase) + Math.abs(distFromOther) <= Math.abs(bendHeight));
/*     */         if (Math.abs(distFromBase) < Math.abs(distFromOther)) {
/*     */           if (isInBendArea) {
/*     */             x.mul((float)((-distFromBase / halfSize) * s));
/*     */             pos.add((Vector3fc)x);
/*     */           } 
/*     */           Vector4f reposVector = new Vector4f((Vector3fc)pos, 1.0F);
/*     */           reposVector.mul((Matrix4fc)transformMatrix);
/*     */           pos = new Vector3f(reposVector.x, reposVector.y, reposVector.z);
/*     */         } else if (isInBendArea) {
/*     */           x.mul((float)((-distFromOther / halfSize) * s));
/*     */           pos.add((Vector3fc)x);
/*     */         } 
/*     */         return pos;
/*     */       };
/*     */   }
/*     */ 
/*     */   
/*     */   public static Matrix4f applyBendToMatrix(Matrix4f transformMatrix, float bendX, float bendY, float bendZ, float bendValue) {
/* 120 */     transformMatrix.translate(bendX, bendY, bendZ);
/* 121 */     transformMatrix.rotateX(bendValue);
/* 122 */     transformMatrix.translate(-bendX, -bendY, -bendZ);
/*     */     
/* 124 */     return transformMatrix;
/*     */   }
/*     */   
/*     */   public static class_4587 applyBendToMatrix(class_4587 transformMatrix, float bendX, float bendY, float bendZ, float bendValue) {
/* 128 */     transformMatrix.method_46416(bendX, bendY, bendZ);
/* 129 */     transformMatrix.method_22907((Quaternionfc)class_7833.field_40714.rotation(bendValue));
/* 130 */     transformMatrix.method_46416(-bendX, -bendY, -bendZ);
/*     */     
/* 132 */     return transformMatrix;
/*     */   }
/*     */   
/*     */   public static float clampToRadian(float f) {
/* 136 */     double a = 6.283185307179586D;
/* 137 */     double b = (f + Math.PI) % 6.283185307179586D;
/* 138 */     if (b < 0.0D) {
/* 139 */       b += 6.283185307179586D;
/*     */     }
/* 141 */     return (float)(b - Math.PI);
/*     */   }
/*     */ }


/* Location:              C:\Users\rapha\Downloads\aurora.jar!\META-INF\jars\bendable-cuboids-p5LKzVqY.jar!\com\zigythebird\bendable_cuboids\impl\BendUtil.class
 * Java compiler version: 21 (65.0)
 * JD-Core Version:       1.1.3
 */