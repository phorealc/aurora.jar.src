/*     */ package com.zigythebird.bendable_cuboids.impl;
/*     */ 
/*     */ import com.zigythebird.bendable_cuboids.api.BendableCube;
/*     */ import com.zigythebird.bendable_cuboids.api.SodiumHelper;
/*     */ import java.util.ArrayList;
/*     */ import java.util.HashMap;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import java.util.Objects;
/*     */ import java.util.Set;
/*     */ import java.util.function.Function;
/*     */ import net.minecraft.class_2350;
/*     */ import net.minecraft.class_4587;
/*     */ import net.minecraft.class_4588;
/*     */ import net.minecraft.class_630;
/*     */ import org.jetbrains.annotations.Nullable;
/*     */ import org.joml.Vector3f;
/*     */ import org.joml.Vector3fc;
/*     */ 
/*     */ public class BendableCuboid extends class_630.class_628 implements BendableCube, SodiumHelper {
/*     */   @Nullable
/*     */   private final Quad[] sides;
/*     */   @Nullable
/*     */   private final RememberingPos[] positions;
/*     */   protected final float fixX;
/*     */   protected final float fixY;
/*     */   protected final float fixZ;
/*     */   protected final Plane basePlane;
/*     */   protected final Plane otherPlane;
/*     */   protected final float fullSize;
/*     */   protected final float extentZ;
/*     */   protected final class_2350 direction;
/*     */   protected final int pivot;
/*     */   protected float bend;
/*     */   private boolean useSodiumRendering = true;
/*     */   
/*     */   public BendableCuboid(int texCoordU, int texCoordV, float originX, float originY, float originZ, float dimensionX, float dimensionY, float dimensionZ, float growX, float growY, float growZ, boolean mirror, float texScaleU, float texScaleV, Set<class_2350> visibleFaces, class_2350 direction, int pivot) {
/*  38 */     super(texCoordU, texCoordV, originX, originY, originZ, dimensionX, dimensionY, dimensionZ, growX, growY, growZ, mirror, texScaleU, texScaleV, visibleFaces);
/*     */     
/*  40 */     List<Quad> planes = new ArrayList<>();
/*  41 */     Map<Vector3f, RememberingPos> positions = new HashMap<>();
/*  42 */     float pminX = this.field_3645 - growX, pminY = this.field_3644 - growY, pminZ = this.field_3643 - growZ, pmaxX = this.field_3648 + growX, pmaxY = this.field_3647 + growY, pmaxZ = this.field_3646 + growZ;
/*  43 */     if (mirror) {
/*  44 */       float tmp = pminX;
/*  45 */       pminX = pmaxX;
/*  46 */       pmaxX = tmp;
/*     */     } 
/*     */     
/*  49 */     this.extentZ = (Math.abs(pminZ) + Math.abs(pmaxZ)) / 2.0F;
/*     */     
/*  51 */     Vector3f[] vertices = new Vector3f[8];
/*     */     
/*  53 */     vertices[0] = new Vector3f(pminX, pminY, pminZ);
/*  54 */     vertices[1] = new Vector3f(pmaxX, pminY, pminZ);
/*  55 */     vertices[2] = new Vector3f(pmaxX, pmaxY, pminZ);
/*  56 */     vertices[3] = new Vector3f(pminX, pmaxY, pminZ);
/*  57 */     vertices[4] = new Vector3f(pminX, pminY, pmaxZ);
/*  58 */     vertices[5] = new Vector3f(pmaxX, pminY, pmaxZ);
/*  59 */     vertices[6] = new Vector3f(pmaxX, pmaxY, pmaxZ);
/*  60 */     vertices[7] = new Vector3f(pminX, pmaxY, pmaxZ);
/*     */     
/*  62 */     float j = texCoordU;
/*  63 */     float k = texCoordU + dimensionZ;
/*  64 */     float l = texCoordU + dimensionZ + dimensionX;
/*  65 */     float m = texCoordU + dimensionZ + dimensionX + dimensionX;
/*  66 */     float n = texCoordU + dimensionZ + dimensionX + dimensionZ;
/*  67 */     float o = texCoordU + dimensionZ + dimensionX + dimensionZ + dimensionX;
/*  68 */     float p = texCoordV;
/*  69 */     float q = texCoordV + dimensionZ;
/*  70 */     float r = texCoordV + dimensionZ + dimensionY;
/*  71 */     if (visibleFaces.contains(class_2350.field_11033)) Quad.createAndAddQuads(planes, positions, new Vector3f[] { vertices[5], vertices[4], vertices[1] }, k, p, l, q, texScaleU, texScaleV, mirror); 
/*  72 */     if (visibleFaces.contains(class_2350.field_11036)) Quad.createAndAddQuads(planes, positions, new Vector3f[] { vertices[2], vertices[3], vertices[6] }, l, q, m, p, texScaleU, texScaleV, mirror); 
/*  73 */     if (visibleFaces.contains(class_2350.field_11039)) Quad.createAndAddQuads(planes, positions, new Vector3f[] { vertices[0], vertices[4], vertices[3] }, j, q, k, r, texScaleU, texScaleV, mirror); 
/*  74 */     if (visibleFaces.contains(class_2350.field_11043)) Quad.createAndAddQuads(planes, positions, new Vector3f[] { vertices[1], vertices[0], vertices[2] }, k, q, l, r, texScaleU, texScaleV, mirror); 
/*  75 */     if (visibleFaces.contains(class_2350.field_11034)) Quad.createAndAddQuads(planes, positions, new Vector3f[] { vertices[5], vertices[1], vertices[6] }, l, q, n, r, texScaleU, texScaleV, mirror); 
/*  76 */     if (visibleFaces.contains(class_2350.field_11035)) Quad.createAndAddQuads(planes, positions, new Vector3f[] { vertices[4], vertices[5], vertices[7] }, n, q, o, r, texScaleU, texScaleV, mirror);
/*     */     
/*  78 */     this.sides = planes.<Quad>toArray(new Quad[0]);
/*  79 */     this.positions = (RememberingPos[])positions.values().toArray((Object[])new RememberingPos[0]);
/*  80 */     iteratePositions(Function.identity());
/*     */     
/*  82 */     this.direction = Objects.<class_2350>requireNonNull(direction);
/*  83 */     this.pivot = pivot;
/*  84 */     direction = class_2350.field_11036;
/*     */     
/*  86 */     Vector3f pivotVec = new Vector3f();
/*  87 */     if (pivot >= 0) {
/*  88 */       float size = direction.method_23955().mul(dimensionX, dimensionY, dimensionZ).length();
/*  89 */       if (pivot <= size) {
/*  90 */         pivotVec = direction.method_23955().mul(size - (pivot * 2));
/*  91 */         vertices[6] = vertices[6].sub((Vector3fc)pivotVec);
/*     */       } 
/*     */     } 
/*  94 */     this.basePlane = new Plane(direction.method_23955(), vertices[6]);
/*  95 */     this.otherPlane = new Plane(direction.method_23955(), vertices[0]);
/*     */     
/*  97 */     this.fullSize = -direction.method_23955().dot((Vector3fc)vertices[0]) + direction.method_23955().dot((Vector3fc)vertices[6]);
/*  98 */     this.fixX = (dimensionX + this.field_3645 + this.field_3645 - pivotVec.x()) / 2.0F;
/*  99 */     this.fixY = (dimensionY + this.field_3644 + this.field_3644 - pivotVec.y()) / 2.0F;
/* 100 */     this.fixZ = (dimensionZ + this.field_3643 + this.field_3643 - pivotVec.z()) / 2.0F;
/*     */   }
/*     */ 
/*     */   
/*     */   public void bc$useSodiumRendering(boolean use) {
/* 105 */     this.useSodiumRendering = use;
/*     */   }
/*     */ 
/*     */   
/*     */   public void method_32089(class_4587.class_4665 pose, class_4588 buffer, int packedLight, int packedOverlay, int color) {
/* 110 */     if ((this.useSodiumRendering && this.bend == 0.0F) || this.sides == null) {
/* 111 */       super.method_32089(pose, buffer, packedLight, packedOverlay, color);
/*     */       
/*     */       return;
/*     */     } 
/* 115 */     for (Quad quad : this.sides) {
/* 116 */       quad.render(pose, buffer, packedLight, packedOverlay, color);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void applyBend(float bendValue) {
/* 129 */     if (Math.abs(bendValue) < 1.0E-4F) bendValue = 0.0F; 
/* 130 */     if (this.bend == bendValue)
/*     */       return; 
/* 132 */     this.bend = bendValue;
/* 133 */     iteratePositions(BendUtil.getBend(this, bendValue));
/*     */   }
/*     */ 
/*     */   
/*     */   public class_2350 getBendDirection() {
/* 138 */     return this.direction;
/*     */   }
/*     */ 
/*     */   
/*     */   public int getBendPivot() {
/* 143 */     return this.pivot;
/*     */   }
/*     */ 
/*     */   
/*     */   public float getBendX() {
/* 148 */     return this.fixX;
/*     */   }
/*     */ 
/*     */   
/*     */   public float getBendY() {
/* 153 */     return this.fixY;
/*     */   }
/*     */ 
/*     */   
/*     */   public float getBendZ() {
/* 158 */     return this.fixZ;
/*     */   }
/*     */ 
/*     */   
/*     */   public float getExtentZ() {
/* 163 */     return this.extentZ;
/*     */   }
/*     */ 
/*     */   
/*     */   public Plane getBasePlane() {
/* 168 */     return this.basePlane;
/*     */   }
/*     */ 
/*     */   
/*     */   public Plane getOtherPlane() {
/* 173 */     return this.otherPlane;
/*     */   }
/*     */ 
/*     */   
/*     */   public float bendHeight() {
/* 178 */     return this.fullSize;
/*     */   }
/*     */ 
/*     */   
/*     */   public float getBend() {
/* 183 */     return this.bend;
/*     */   }
/*     */   
/*     */   public void iteratePositions(Function<Vector3f, Vector3f> function) {
/* 187 */     if (this.positions == null)
/* 188 */       return;  for (RememberingPos pos : this.positions) {
/* 189 */       pos.setPos(function.apply(pos.getOriginalPos()));
/*     */     }
/*     */   }
/*     */   
/*     */   private void resetBend() {
/* 194 */     if (this.positions == null)
/* 195 */       return;  for (RememberingPos pos : this.positions)
/* 196 */       pos.setPos(pos.getOriginalPos()); 
/*     */   }
/*     */ }


/* Location:              C:\Users\rapha\Downloads\aurora.jar!\META-INF\jars\bendable-cuboids-p5LKzVqY.jar!\com\zigythebird\bendable_cuboids\impl\BendableCuboid.class
 * Java compiler version: 21 (65.0)
 * JD-Core Version:       1.1.3
 */