/*    */ package com.zigythebird.bendable_cuboids.impl;
/*    */ 
/*    */ import org.joml.Vector3f;
/*    */ import org.joml.Vector3fc;
/*    */ 
/*    */ 
/*    */ 
/*    */ public class Plane
/*    */ {
/*    */   public final Vector3f normal;
/*    */   private final float normDistance;
/*    */   
/*    */   public Plane(Vector3f normal, Vector3f position) {
/* 14 */     this.normal = normal;
/* 15 */     this.normal.normalize();
/* 16 */     this.normDistance = -this.normal.dot((Vector3fc)position);
/*    */   }
/*    */   
/*    */   public Plane(Vector3f normal, float normDistance) {
/* 20 */     this.normal = normal;
/* 21 */     this.normDistance = normDistance;
/*    */   }
/*    */   
/*    */   public Plane scaled(float scalar) {
/* 25 */     return new Plane(new Vector3f((Vector3fc)this.normal), this.normDistance * scalar);
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public float distanceTo(Vector3f pos) {
/* 34 */     return this.normal.dot((Vector3fc)pos) + this.normDistance;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public float distanceTo(Plane otherPlane) {
/* 43 */     Vector3f tmp = new Vector3f((Vector3fc)this.normal);
/* 44 */     tmp.cross((Vector3fc)otherPlane.normal);
/*    */     
/* 46 */     if (tmp.dot((Vector3fc)tmp) < 0.01D) {
/* 47 */       return this.normDistance + this.normal.dot((Vector3fc)otherPlane.normal) * otherPlane.normDistance;
/*    */     }
/*    */     
/* 50 */     return 0.0F;
/*    */   }
/*    */ }


/* Location:              C:\Users\rapha\Downloads\aurora.jar!\META-INF\jars\bendable-cuboids-p5LKzVqY.jar!\com\zigythebird\bendable_cuboids\impl\Plane.class
 * Java compiler version: 21 (65.0)
 * JD-Core Version:       1.1.3
 */