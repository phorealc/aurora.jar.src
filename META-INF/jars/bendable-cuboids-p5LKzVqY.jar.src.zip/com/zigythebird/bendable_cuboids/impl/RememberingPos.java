/*    */ package com.zigythebird.bendable_cuboids.impl;
/*    */ 
/*    */ import java.util.Objects;
/*    */ import org.joml.Vector3f;
/*    */ import org.joml.Vector3fc;
/*    */ 
/*    */ public class RememberingPos {
/*    */   final Vector3f originPos;
/*  9 */   Vector3f currentPos = null;
/*    */   
/*    */   public RememberingPos(Vector3f originPos) {
/* 12 */     this.originPos = originPos;
/*    */   }
/*    */   
/*    */   public RememberingPos(float x, float y, float z) {
/* 16 */     this(new Vector3f(x, y, z));
/*    */   }
/*    */   
/*    */   public boolean equals(Object o) {
/*    */     RememberingPos that;
/* 21 */     if (this == o) return true; 
/* 22 */     if (o instanceof RememberingPos) { that = (RememberingPos)o; } else { return false; }
/*    */     
/* 24 */     if (!this.originPos.equals(that.originPos)) return false; 
/* 25 */     return Objects.equals(this.currentPos, that.currentPos);
/*    */   }
/*    */ 
/*    */   
/*    */   public int hashCode() {
/* 30 */     int result = this.originPos.hashCode();
/* 31 */     result = 31 * result + ((this.currentPos != null) ? this.currentPos.hashCode() : 0);
/* 32 */     return result;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public Vector3f getOriginalPos() {
/* 39 */     return new Vector3f((Vector3fc)this.originPos);
/*    */   }
/*    */   
/*    */   public Vector3f getPos() {
/* 43 */     return this.currentPos;
/*    */   }
/*    */   
/*    */   public void setPos(Vector3f vector3f) {
/* 47 */     this.currentPos = vector3f;
/*    */   }
/*    */ }


/* Location:              C:\Users\rapha\Downloads\aurora.jar!\META-INF\jars\bendable-cuboids-p5LKzVqY.jar!\com\zigythebird\bendable_cuboids\impl\RememberingPos.class
 * Java compiler version: 21 (65.0)
 * JD-Core Version:       1.1.3
 */