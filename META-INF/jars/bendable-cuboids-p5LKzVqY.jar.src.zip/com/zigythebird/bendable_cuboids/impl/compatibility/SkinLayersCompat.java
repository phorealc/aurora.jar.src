/*    */ package com.zigythebird.bendable_cuboids.impl.compatibility;
/*    */ 
/*    */ import com.zigythebird.bendable_cuboids.BendableCuboidsMod;
/*    */ import com.zigythebird.bendable_cuboids.api.BendableCube;
/*    */ import com.zigythebird.bendable_cuboids.impl.BendUtil;
/*    */ import com.zigythebird.bendable_cuboids.impl.BendableCuboid;
/*    */ import com.zigythebird.bendable_cuboids.impl.RememberingPos;
/*    */ import dev.tr7zw.skinlayers.api.BoxBuilder;
/*    */ import dev.tr7zw.skinlayers.api.MeshTransformer;
/*    */ import dev.tr7zw.skinlayers.api.MeshTransformerProvider;
/*    */ import dev.tr7zw.skinlayers.api.SkinLayersAPI;
/*    */ import java.util.EnumSet;
/*    */ import java.util.Set;
/*    */ import net.minecraft.class_2350;
/*    */ import net.minecraft.class_630;
/*    */ import org.jetbrains.annotations.Nullable;
/*    */ import org.joml.Vector3f;
/*    */ import org.joml.Vector3fc;
/*    */ import org.joml.Vector4f;
/*    */ 
/*    */ public class SkinLayersCompat
/*    */   implements MeshTransformerProvider, MeshTransformer {
/* 23 */   private static final Set<class_2350> ALL_VISIBLE = EnumSet.allOf(class_2350.class);
/*    */ 
/*    */   
/*    */   protected final MeshTransformerProvider parent;
/*    */ 
/*    */   
/*    */   protected SkinLayersCompat(MeshTransformerProvider parent) {
/* 30 */     this.parent = parent;
/*    */   } @Nullable
/*    */   protected BendableCube original; @Nullable
/*    */   protected MeshTransformer transformer; public static void setupTransformer() {
/* 34 */     SkinLayersAPI.setupMeshTransformerProvider(new SkinLayersCompat(SkinLayersAPI.getMeshTransformerProvider()));
/* 35 */     SkinLayersAPI.setupBoxBuilder(boxDefinition -> (boxDefinition.height() != 12.0F) ? BoxBuilder.DEFAULT.build(boxDefinition) : new BendableCuboid(boxDefinition.u(), boxDefinition.v(), boxDefinition.x(), boxDefinition.y(), boxDefinition.z(), boxDefinition.width(), boxDefinition.height(), boxDefinition.depth(), 0.0F, 0.0F, 0.0F, boxDefinition.mirror(), boxDefinition.textureWidth(), boxDefinition.textureHeight(), ALL_VISIBLE, (boxDefinition.width() == 8.0F) ? class_2350.field_11033 : class_2350.field_11036, -1));
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public MeshTransformer prepareTransformer(@Nullable class_630 modelPart) {
/* 43 */     if (modelPart == null) {
/* 44 */       BendableCuboidsMod.LOGGER.error("3dskinlayers passed a null part of the model, please report this to TR!", new Throwable());
/* 45 */       return this.parent.prepareTransformer(null);
/*    */     } 
/*    */     
/* 48 */     this.original = modelPart.bc$getCuboid(0);
/* 49 */     this.transformer = this.parent.prepareTransformer(modelPart);
/* 50 */     return this;
/*    */   }
/*    */ 
/*    */   
/*    */   public void transform(Vector3f vector3f, Vector4f[] vector4fs) {
/* 55 */     if (this.original == null || this.original.getBend() == 0.0F)
/* 56 */       return;  for (Vector4f vector4f : vector4fs) {
/* 57 */       vector4f.mul(16.0F);
/* 58 */       RememberingPos pos = new RememberingPos(new Vector3f(vector4f.x, vector4f.y, vector4f.z));
/* 59 */       pos.setPos(BendUtil.getBend(this.original).apply(pos.getOriginalPos()));
/* 60 */       vector4f.set((Vector3fc)pos.getPos(), vector4f.w);
/* 61 */       vector4f.div(16.0F);
/*    */     } 
/* 63 */     vector3f.set((Vector3fc)calculateNormal(vector4fs));
/*    */   }
/*    */ 
/*    */   
/*    */   public void transform(class_630.class_628 cube) {
/* 68 */     if (cube instanceof BendableCube) { BendableCube bendableCube = (BendableCube)cube;
/* 69 */       if (this.original == null || this.original.getBend() == 0.0F) {
/* 70 */         bendableCube.applyBend(0.0F);
/* 71 */         if (this.transformer != null) {
/* 72 */           this.transformer.transform(cube);
/*    */         }
/*    */         return;
/*    */       } 
/* 76 */       bendableCube.bc$copyState(this.original); }
/*    */   
/*    */   }
/*    */   
/*    */   public static Vector3f calculateNormal(Vector4f[] vertices) {
/* 81 */     Vector3f buf = new Vector3f((vertices[3]).x, (vertices[3]).y, (vertices[3]).z);
/* 82 */     buf.negate();
/* 83 */     Vector3f vecB = new Vector3f((vertices[1]).x, (vertices[1]).y, (vertices[1]).z);
/* 84 */     vecB.add((Vector3fc)buf);
/* 85 */     buf = new Vector3f((vertices[2]).x, (vertices[2]).y, (vertices[2]).z);
/* 86 */     buf.negate();
/* 87 */     Vector3f vecA = new Vector3f((vertices[0]).x, (vertices[0]).y, (vertices[0]).z);
/* 88 */     vecA.add((Vector3fc)buf);
/* 89 */     vecA.cross((Vector3fc)vecB);
/*    */     
/* 91 */     return vecA.normalize().isFinite() ? vecA : class_2350.field_11043.method_23955();
/*    */   }
/*    */ }


/* Location:              C:\Users\rapha\Downloads\aurora.jar!\META-INF\jars\bendable-cuboids-p5LKzVqY.jar!\com\zigythebird\bendable_cuboids\impl\compatibility\SkinLayersCompat.class
 * Java compiler version: 21 (65.0)
 * JD-Core Version:       1.1.3
 */