/*    */ package com.zigythebird.bendable_cuboids.impl.compatibility;
/*    */ 
/*    */ import com.zigythebird.bendable_cuboids.api.BendableCube;
/*    */ import com.zigythebird.bendable_cuboids.impl.BendUtil;
/*    */ import net.minecraft.class_4587;
/*    */ import net.minecraft.class_630;
/*    */ 
/*    */ 
/*    */ public class PlayerBendHelper
/*    */ {
/*    */   public static void resetBend(class_630 modelPart) {
/* 12 */     bend(modelPart, 0.0F);
/*    */   }
/*    */   
/*    */   public static void bend(class_630 modelPart, float rotation) {
/* 16 */     BendableCube cube = modelPart.bc$getCuboid(0);
/* 17 */     if (cube == null)
/* 18 */       return;  cube.applyBend(rotation);
/*    */   }
/*    */   
/*    */   public static void applyTorsoBendToMatrix(class_4587 poseStack, float bend) {
/* 22 */     BendUtil.applyBendToMatrix(poseStack, 0.0F, 0.375F, 0.0F, bend);
/*    */   }
/*    */ }


/* Location:              C:\Users\rapha\Downloads\aurora.jar!\META-INF\jars\bendable-cuboids-p5LKzVqY.jar!\com\zigythebird\bendable_cuboids\impl\compatibility\PlayerBendHelper.class
 * Java compiler version: 21 (65.0)
 * JD-Core Version:       1.1.3
 */