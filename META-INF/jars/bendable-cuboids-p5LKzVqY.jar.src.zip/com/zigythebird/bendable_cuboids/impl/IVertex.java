package com.zigythebird.bendable_cuboids.impl;

import org.joml.Vector3f;

public interface IVertex {
  Vector3f getPos();
  
  float getU();
  
  float getV();
  
  IVertex remap(float paramFloat1, float paramFloat2);
}


/* Location:              C:\Users\rapha\Downloads\aurora.jar!\META-INF\jars\bendable-cuboids-p5LKzVqY.jar!\com\zigythebird\bendable_cuboids\impl\IVertex.class
 * Java compiler version: 21 (65.0)
 * JD-Core Version:       1.1.3
 */