/*     */ package com.zigythebird.bendable_cuboids.impl;
/*     */ 
/*     */ import java.util.Arrays;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import net.minecraft.class_2350;
/*     */ import net.minecraft.class_3532;
/*     */ import net.minecraft.class_4587;
/*     */ import net.minecraft.class_4588;
/*     */ import org.joml.Matrix3fc;
/*     */ import org.joml.Matrix4fc;
/*     */ import org.joml.Vector3f;
/*     */ import org.joml.Vector3fc;
/*     */ import org.joml.Vector4f;
/*     */ 
/*     */ 
/*     */ public class Quad
/*     */ {
/*     */   public final RepositionableVertex[] vertices;
/*     */   
/*     */   public Quad(RememberingPos[] vertices, float u1, float v1, float u2, float v2, boolean flip) {
/*  22 */     this.vertices = new RepositionableVertex[4];
/*  23 */     this.vertices[0] = new RepositionableVertex(u2, v1, vertices[0]);
/*  24 */     this.vertices[1] = new RepositionableVertex(u1, v1, vertices[1]);
/*  25 */     this.vertices[2] = new RepositionableVertex(u1, v2, vertices[2]);
/*  26 */     this.vertices[3] = new RepositionableVertex(u2, v2, vertices[3]);
/*  27 */     if (flip) {
/*  28 */       int i = vertices.length;
/*     */       
/*  30 */       for (int j = 0; j < i / 2; j++) {
/*  31 */         RepositionableVertex vertex = this.vertices[j];
/*  32 */         this.vertices[j] = this.vertices[i - 1 - j];
/*  33 */         this.vertices[i - 1 - j] = vertex;
/*     */       } 
/*     */     } 
/*     */   }
/*     */   
/*     */   public void render(class_4587.class_4665 matrices, class_4588 vertexConsumer, int light, int overlay, int color) {
/*  39 */     Vector3f normal = getDirection();
/*  40 */     normal.mul((Matrix3fc)matrices.method_23762());
/*     */     
/*  42 */     for (int i = 0; i != 4; i++) {
/*  43 */       IVertex vertex = this.vertices[i];
/*  44 */       Vector3f vertexPos = vertex.getPos();
/*  45 */       Vector4f pos = new Vector4f(vertexPos.x / 16.0F, vertexPos.y / 16.0F, vertexPos.z / 16.0F, 1.0F);
/*  46 */       pos.mul((Matrix4fc)matrices.method_23761());
/*  47 */       vertexConsumer.method_23919(pos.x, pos.y, pos.z, color, vertex.getU(), vertex.getV(), overlay, light, normal.x, normal.y, normal.z);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private Vector3f getDirection() {
/*  56 */     Vector3f buf = new Vector3f((Vector3fc)this.vertices[3].getPos());
/*  57 */     buf.mul(-1.0F);
/*  58 */     Vector3f vecB = new Vector3f((Vector3fc)this.vertices[1].getPos());
/*  59 */     vecB.add((Vector3fc)buf);
/*  60 */     buf = new Vector3f((Vector3fc)this.vertices[2].getPos());
/*  61 */     buf.mul(-1.0F);
/*  62 */     Vector3f vecA = new Vector3f((Vector3fc)this.vertices[0].getPos());
/*  63 */     vecA.add((Vector3fc)buf);
/*  64 */     vecA.cross((Vector3fc)vecB);
/*     */     
/*  66 */     return vecA.normalize().isFinite() ? vecA : class_2350.field_11043.method_23955();
/*     */   }
/*     */ 
/*     */   
/*     */   public static void createAndAddQuads(List<Quad> quads, Map<Vector3f, RememberingPos> positions, Vector3f[] edges, float u1, float v1, float u2, float v2, float textureWidth, float textureHeight, boolean mirror) {
/*  71 */     boolean positiveDirection = (v2 > v1);
/*  72 */     float totalTexHeight = class_3532.method_15379(v2 - v1);
/*     */     
/*  74 */     Vector3f origin = edges[0];
/*  75 */     Vector3f vecV = (new Vector3f((Vector3fc)edges[2])).sub((Vector3fc)origin);
/*  76 */     float vFracScale = (v1 == v2) ? 0.0F : (1.0F / (v2 - v1));
/*  77 */     Vector3f vecU = (new Vector3f((Vector3fc)edges[1])).sub((Vector3fc)origin);
/*  78 */     float uFracScale = (u1 == u2) ? 0.0F : (1.0F / (u2 - u1));
/*     */     
/*  80 */     Vector3f vPos = new Vector3f((Vector3fc)origin);
/*  81 */     Vector3f nextVPos = new Vector3f((Vector3fc)edges[1]);
/*  82 */     Vector3f vStep = new Vector3f();
/*     */     
/*  84 */     float[] quadHeights = null;
/*  85 */     int segmentHeight = 0;
/*  86 */     if (totalTexHeight > 0.0F && totalTexHeight % 3.0F == 0.0F) {
/*  87 */       segmentHeight = (int)(totalTexHeight / 3.0F);
/*  88 */       if (segmentHeight > 0) {
/*  89 */         quadHeights = new float[2 + segmentHeight];
/*  90 */         quadHeights[0] = segmentHeight;
/*  91 */         Arrays.fill(quadHeights, 1, 1 + segmentHeight, 1.0F);
/*  92 */         quadHeights[1 + segmentHeight] = segmentHeight;
/*     */       } 
/*     */     } 
/*     */     
/*  96 */     int layerIndex = 0;
/*     */     float localV;
/*  98 */     for (localV = v1; positiveDirection ? (localV < v2) : (localV > v2); ) {
/*     */       float dv;
/* 100 */       boolean isMiddleSegment = false;
/* 101 */       if (quadHeights != null) {
/* 102 */         if (layerIndex >= quadHeights.length) {
/*     */           break;
/*     */         }
/* 105 */         dv = positiveDirection ? quadHeights[layerIndex] : -quadHeights[layerIndex];
/* 106 */         if (layerIndex > 0 && layerIndex <= segmentHeight) {
/* 107 */           isMiddleSegment = true;
/*     */         }
/* 109 */         layerIndex++;
/*     */       } else {
/* 111 */         dv = positiveDirection ? 1.0F : -1.0F;
/*     */       } 
/*     */       
/* 114 */       float localV2 = localV + dv;
/* 115 */       if (quadHeights == null) {
/* 116 */         if (positiveDirection) {
/* 117 */           if (localV2 > v2) {
/* 118 */             localV2 = v2;
/*     */           }
/*     */         }
/* 121 */         else if (localV2 < v2) {
/* 122 */           localV2 = v2;
/*     */         } 
/*     */       }
/*     */ 
/*     */       
/* 127 */       float actual_dv = localV2 - localV;
/* 128 */       if (actual_dv == 0.0F)
/* 129 */         break;  vStep.set((Vector3fc)vecV).mul(actual_dv * vFracScale);
/*     */       
/* 131 */       if (isMiddleSegment && class_3532.method_15379(u2 - u1) > 1.0F) {
/* 132 */         boolean uPositive = (u2 > u1);
/* 133 */         float du = uPositive ? 1.0F : -1.0F;
/*     */         
/* 135 */         Vector3f uScanPosBottom = new Vector3f((Vector3fc)vPos);
/* 136 */         Vector3f uScanPosTop = (new Vector3f((Vector3fc)vPos)).add((Vector3fc)vStep);
/*     */         float localU;
/* 138 */         for (localU = u2; localU != u1; localU -= du) {
/* 139 */           float localU2 = localU - du;
/* 140 */           if (uPositive)
/* 141 */           { if (localU2 > u2) localU2 = u2;
/*     */              }
/* 143 */           else if (localU2 < u2) { localU2 = u2; }
/*     */           
/* 145 */           if (localU == localU2)
/*     */             break; 
/* 147 */           float actual_du = localU2 - localU;
/* 148 */           Vector3f uStep = (new Vector3f((Vector3fc)vecU)).mul(actual_du * uFracScale);
/*     */           
/* 150 */           RememberingPos bottomLeft = getOrCreate(positions, uScanPosBottom);
/* 151 */           RememberingPos topLeft = getOrCreate(positions, uScanPosTop);
/*     */           
/* 153 */           uScanPosBottom.sub((Vector3fc)uStep);
/* 154 */           uScanPosTop.sub((Vector3fc)uStep);
/*     */           
/* 156 */           RememberingPos bottomRight = getOrCreate(positions, uScanPosBottom);
/* 157 */           RememberingPos topRight = getOrCreate(positions, uScanPosTop);
/*     */           
/* 159 */           quads.add(new Quad(new RememberingPos[] { bottomLeft, bottomRight, topRight, topLeft }, localU2 / textureWidth, localV / textureHeight, localU / textureWidth, localV2 / textureHeight, mirror));
/*     */         } 
/*     */         
/* 162 */         vPos.add((Vector3fc)vStep);
/* 163 */         nextVPos.add((Vector3fc)vStep);
/*     */       } else {
/* 165 */         RememberingPos rp3 = getOrCreate(positions, vPos);
/* 166 */         RememberingPos rp0 = getOrCreate(positions, nextVPos);
/* 167 */         vPos.add((Vector3fc)vStep);
/* 168 */         nextVPos.add((Vector3fc)vStep);
/* 169 */         RememberingPos rp2 = getOrCreate(positions, vPos);
/* 170 */         RememberingPos rp1 = getOrCreate(positions, nextVPos);
/* 171 */         quads.add(new Quad(new RememberingPos[] { rp3, rp0, rp1, rp2 }, u1 / textureWidth, localV / textureHeight, u2 / textureWidth, localV2 / textureHeight, mirror));
/*     */       } 
/*     */       
/* 174 */       localV = localV2;
/*     */     } 
/*     */   }
/*     */   
/*     */   public static RememberingPos getOrCreate(Map<Vector3f, RememberingPos> positions, Vector3f pos) {
/* 179 */     return positions.computeIfAbsent(pos, p -> new RememberingPos(new Vector3f((Vector3fc)p)));
/*     */   }
/*     */ }


/* Location:              C:\Users\rapha\Downloads\aurora.jar!\META-INF\jars\bendable-cuboids-p5LKzVqY.jar!\com\zigythebird\bendable_cuboids\impl\Quad.class
 * Java compiler version: 21 (65.0)
 * JD-Core Version:       1.1.3
 */