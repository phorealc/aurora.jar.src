/*    */ package com.zigythebird.bendable_cuboids;
/*    */ 
/*    */ import java.util.List;
/*    */ import java.util.Set;
/*    */ import org.objectweb.asm.tree.ClassNode;
/*    */ import org.spongepowered.asm.mixin.extensibility.IMixinConfigPlugin;
/*    */ import org.spongepowered.asm.mixin.extensibility.IMixinInfo;
/*    */ import org.spongepowered.asm.service.MixinService;
/*    */ 
/*    */ 
/*    */ public class ModMixinPlugin
/*    */   implements IMixinConfigPlugin
/*    */ {
/*    */   public boolean shouldApplyMixin(String targetClassName, String mixinClassName) {
/* 15 */     return (!mixinClassName.endsWith("_playerAnim") || hasClass("com.zigythebird.playeranim.PlayerAnimLibMod"));
/*    */   }
/*    */ 
/*    */   
/*    */   private static boolean hasClass(String name) {
/*    */     try {
/* 21 */       MixinService.getService().getBytecodeProvider().getClassNode(name);
/* 22 */       return true;
/* 23 */     } catch (ClassNotFoundException|java.io.IOException e) {
/* 24 */       return false;
/*    */     } 
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public void onLoad(String mixinPackage) {}
/*    */ 
/*    */ 
/*    */   
/*    */   public String getRefMapperConfig() {
/* 35 */     return null;
/*    */   }
/*    */ 
/*    */   
/*    */   public void acceptTargets(Set<String> myTargets, Set<String> otherTargets) {}
/*    */ 
/*    */   
/*    */   public List<String> getMixins() {
/* 43 */     return null;
/*    */   }
/*    */   
/*    */   public void preApply(String targetClassName, ClassNode targetClass, String mixinClassName, IMixinInfo mixinInfo) {}
/*    */   
/*    */   public void postApply(String targetClassName, ClassNode targetClass, String mixinClassName, IMixinInfo mixinInfo) {}
/*    */ }


/* Location:              C:\Users\rapha\Downloads\aurora.jar!\META-INF\jars\bendable-cuboids-p5LKzVqY.jar!\com\zigythebird\bendable_cuboids\ModMixinPlugin.class
 * Java compiler version: 21 (65.0)
 * JD-Core Version:       1.1.3
 */