/*    */ package com.zigythebird.bendable_cuboids.fabric;
/*    */ 
/*    */ import com.zigythebird.bendable_cuboids.BendableCuboidsMod;
/*    */ import net.fabricmc.api.ClientModInitializer;
/*    */ import net.fabricmc.loader.api.FabricLoader;
/*    */ 
/*    */ public class BendableCuboidsModFabric
/*    */   extends BendableCuboidsMod implements ClientModInitializer {
/*    */   public void onInitializeClient() {
/* 10 */     if (FabricLoader.getInstance().isModLoaded("skinlayers3d")) setupSkinLayersTransformer(); 
/*    */   }
/*    */ }


/* Location:              C:\Users\rapha\Downloads\aurora.jar!\META-INF\jars\bendable-cuboids-p5LKzVqY.jar!\com\zigythebird\bendable_cuboids\fabric\BendableCuboidsModFabric.class
 * Java compiler version: 21 (65.0)
 * JD-Core Version:       1.1.3
 */