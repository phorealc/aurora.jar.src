/*    */ package com.zigythebird.bendable_cuboids.mixin;
/*    */ 
/*    */ import com.zigythebird.bendable_cuboids.api.BendableCube;
/*    */ import com.zigythebird.bendable_cuboids.api.BendableModelPart;
/*    */ import com.zigythebird.bendable_cuboids.api.SodiumHelper;
/*    */ import java.util.List;
/*    */ import java.util.Map;
/*    */ import net.minecraft.class_630;
/*    */ import org.jetbrains.annotations.Nullable;
/*    */ import org.spongepowered.asm.mixin.Final;
/*    */ import org.spongepowered.asm.mixin.Mixin;
/*    */ import org.spongepowered.asm.mixin.Shadow;
/*    */ 
/*    */ @Mixin({class_630.class})
/*    */ public class ModelPartMixin
/*    */   implements BendableModelPart, SodiumHelper {
/*    */   @Shadow
/*    */   @Final
/*    */   public List<class_630.class_628> field_3663;
/*    */   @Shadow
/*    */   @Final
/*    */   public Map<String, class_630> field_3661;
/*    */   
/*    */   @Nullable
/*    */   public BendableCube bc$getCuboid(int index) {
/* 26 */     if (index >= this.field_3663.size() || index < 0) return null; 
/* 27 */     BendableCube bendableCube1 = (BendableCube)this.field_3663.get(index), bendableCube = bendableCube1; return (bendableCube1 instanceof BendableCube) ? bendableCube : null;
/*    */   }
/*    */ 
/*    */   
/*    */   public void bc$useSodiumRendering(boolean use) {
/* 32 */     for (class_630.class_628 cube : this.field_3663) {
/* 33 */       if (cube instanceof SodiumHelper) { SodiumHelper helper = (SodiumHelper)cube;
/* 34 */         helper.bc$useSodiumRendering(use); }
/*    */     
/*    */     } 
/* 37 */     for (class_630 child : this.field_3661.values())
/* 38 */       child.bc$useSodiumRendering(use); 
/*    */   }
/*    */ }


/* Location:              C:\Users\rapha\Downloads\aurora.jar!\META-INF\jars\bendable-cuboids-p5LKzVqY.jar!\com\zigythebird\bendable_cuboids\mixin\ModelPartMixin.class
 * Java compiler version: 21 (65.0)
 * JD-Core Version:       1.1.3
 */