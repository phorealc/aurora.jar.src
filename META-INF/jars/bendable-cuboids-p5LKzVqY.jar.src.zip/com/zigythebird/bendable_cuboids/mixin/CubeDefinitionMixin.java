/*    */ package com.zigythebird.bendable_cuboids.mixin;
/*    */ 
/*    */ import com.zigythebird.bendable_cuboids.api.ICubeDefinition;
/*    */ import com.zigythebird.bendable_cuboids.impl.BendableCuboid;
/*    */ import java.util.Set;
/*    */ import net.minecraft.class_2350;
/*    */ import net.minecraft.class_5604;
/*    */ import net.minecraft.class_5605;
/*    */ import net.minecraft.class_5611;
/*    */ import org.joml.Vector3fc;
/*    */ import org.spongepowered.asm.mixin.Final;
/*    */ import org.spongepowered.asm.mixin.Mixin;
/*    */ import org.spongepowered.asm.mixin.Shadow;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ @Mixin({class_5604.class})
/*    */ public class CubeDefinitionMixin
/*    */   implements ICubeDefinition
/*    */ {
/*    */   @Shadow
/*    */   @Final
/*    */   private class_5611 field_27713;
/*    */   @Shadow
/*    */   @Final
/*    */   private Vector3fc field_27709;
/*    */   @Shadow
/*    */   @Final
/*    */   private Vector3fc field_27710;
/*    */   
/*    */   public BendableCuboid bakeBendableCuboid(int texWidth, int texHeight, class_2350 direction, int pivot) {
/* 34 */     return new BendableCuboid((int)this.field_27713.comp_5231(), (int)this.field_27713.comp_5232(), this.field_27709.x(), this.field_27709.y(), this.field_27709.z(), this.field_27710.x(), this.field_27710.y(), this.field_27710.z(), this.field_27711.field_27716, this.field_27711.field_27717, this.field_27711.field_27718, this.field_27712, texWidth * this.field_27714.comp_5231(), texHeight * this.field_27714.comp_5232(), this.field_42887, direction, pivot);
/*    */   }
/*    */   
/*    */   @Shadow
/*    */   @Final
/*    */   private class_5605 field_27711;
/*    */   @Shadow
/*    */   @Final
/*    */   private boolean field_27712;
/*    */   @Shadow
/*    */   @Final
/*    */   private class_5611 field_27714;
/*    */   @Shadow
/*    */   @Final
/*    */   private Set<class_2350> field_42887;
/*    */ }


/* Location:              C:\Users\rapha\Downloads\aurora.jar!\META-INF\jars\bendable-cuboids-p5LKzVqY.jar!\com\zigythebird\bendable_cuboids\mixin\CubeDefinitionMixin.class
 * Java compiler version: 21 (65.0)
 * JD-Core Version:       1.1.3
 */