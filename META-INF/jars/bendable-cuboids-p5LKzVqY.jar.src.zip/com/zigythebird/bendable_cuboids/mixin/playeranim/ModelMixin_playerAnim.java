/*    */ package com.zigythebird.bendable_cuboids.mixin.playeranim;
/*    */ 
/*    */ import com.llamalad7.mixinextras.sugar.Share;
/*    */ import com.llamalad7.mixinextras.sugar.ref.LocalBooleanRef;
/*    */ import com.zigythebird.bendable_cuboids.api.IMutableModel;
/*    */ import com.zigythebird.playeranim.animation.AvatarAnimManager;
/*    */ import net.minecraft.class_3879;
/*    */ import net.minecraft.class_4587;
/*    */ import net.minecraft.class_4588;
/*    */ import net.minecraft.class_630;
/*    */ import org.spongepowered.asm.mixin.Mixin;
/*    */ import org.spongepowered.asm.mixin.Shadow;
/*    */ import org.spongepowered.asm.mixin.injection.At;
/*    */ import org.spongepowered.asm.mixin.injection.Inject;
/*    */ import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
/*    */ 
/*    */ @Mixin({class_3879.class})
/*    */ public abstract class ModelMixin_playerAnim
/*    */ {
/*    */   @Shadow
/*    */   public abstract class_630 method_63512();
/*    */   
/*    */   @Inject(method = {"method_62100(Lnet/minecraft/class_4587;Lnet/minecraft/class_4588;III)V"}, at = {@At("HEAD")})
/*    */   public void bc$render(class_4587 poseStack, class_4588 buffer, int packedLight, int packedOverlay, int color, CallbackInfo ci, @Share("palActive") LocalBooleanRef palActive) {
/* 25 */     ModelMixin_playerAnim modelMixin_playerAnim = this; IMutableModel mutable = (IMutableModel)modelMixin_playerAnim; AvatarAnimManager manager = (modelMixin_playerAnim instanceof IMutableModel) ? mutable.bc$getAnimation() : null;
/* 26 */     palActive.set((manager != null && manager.isActive()));
/*    */     
/* 28 */     if (palActive.get()) method_63512().bc$useSodiumRendering(false); 
/*    */   }
/*    */   
/*    */   @Inject(method = {"method_62100(Lnet/minecraft/class_4587;Lnet/minecraft/class_4588;III)V"}, at = {@At("TAIL")})
/*    */   public void bc$renderTail(class_4587 poseStack, class_4588 buffer, int packedLight, int packedOverlay, int color, CallbackInfo ci, @Share("palActive") LocalBooleanRef palActive) {
/* 33 */     if (palActive.get()) method_63512().bc$useSodiumRendering(true); 
/*    */   }
/*    */ }


/* Location:              C:\Users\rapha\Downloads\aurora.jar!\META-INF\jars\bendable-cuboids-p5LKzVqY.jar!\com\zigythebird\bendable_cuboids\mixin\playeranim\ModelMixin_playerAnim.class
 * Java compiler version: 21 (65.0)
 * JD-Core Version:       1.1.3
 */