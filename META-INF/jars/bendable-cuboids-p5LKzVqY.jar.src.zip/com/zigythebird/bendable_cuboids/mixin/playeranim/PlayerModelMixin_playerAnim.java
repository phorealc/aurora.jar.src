/*     */ package com.zigythebird.bendable_cuboids.mixin.playeranim;
/*     */ 
/*     */ import com.zigythebird.bendable_cuboids.api.IMutableModel;
/*     */ import com.zigythebird.bendable_cuboids.impl.compatibility.PlayerBendHelper;
/*     */ import com.zigythebird.playeranim.accessors.IBoneUpdater;
/*     */ import com.zigythebird.playeranim.animation.AvatarAnimManager;
/*     */ import com.zigythebird.playeranimcore.bones.PlayerAnimBone;
/*     */ import net.minecraft.class_10055;
/*     */ import net.minecraft.class_572;
/*     */ import net.minecraft.class_591;
/*     */ import net.minecraft.class_630;
/*     */ import org.jetbrains.annotations.Nullable;
/*     */ import org.spongepowered.asm.mixin.Final;
/*     */ import org.spongepowered.asm.mixin.Mixin;
/*     */ import org.spongepowered.asm.mixin.Shadow;
/*     */ import org.spongepowered.asm.mixin.Unique;
/*     */ import org.spongepowered.asm.mixin.injection.At;
/*     */ import org.spongepowered.asm.mixin.injection.Inject;
/*     */ import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
/*     */ 
/*     */ @Mixin(value = {class_591.class}, priority = 2002)
/*     */ public abstract class PlayerModelMixin_playerAnim extends class_572<class_10055> implements IBoneUpdater, IMutableModel {
/*     */   @Shadow
/*     */   @Final
/*     */   public class_630 field_3483;
/*     */   @Shadow
/*     */   @Final
/*     */   public class_630 field_3486;
/*     */   @Shadow
/*     */   @Final
/*     */   public class_630 field_3484;
/*     */   @Shadow
/*     */   @Final
/*     */   public class_630 field_3479;
/*     */   @Shadow
/*     */   @Final
/*     */   public class_630 field_3482;
/*     */   @Unique
/*  39 */   private AvatarAnimManager bc$animation = null;
/*     */ 
/*     */   
/*     */   public PlayerModelMixin_playerAnim(class_630 root) {
/*  43 */     super(root);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Inject(method = {"pal$updatePart(Lcom/zigythebird/playeranim/animation/AvatarAnimManager;Lnet/minecraft/client/model/geom/ModelPart;Lcom/zigythebird/playeranimcore/bones/PlayerAnimBone;)V", "pal$updatePart(Lcom/zigythebird/playeranim/animation/AvatarAnimManager;Lnet/minecraft/class_630;Lcom/zigythebird/playeranimcore/bones/PlayerAnimBone;)V"}, at = {@At("RETURN")})
/*     */   public void bc$updatePart(AvatarAnimManager emote, class_630 part, PlayerAnimBone bone, CallbackInfo ci) {
/*  57 */     this.bc$animation = emote;
/*     */     
/*  59 */     if (this.field_3398 == part)
/*  60 */       return;  PlayerBendHelper.bend(part, bone.getBend());
/*     */ 
/*     */     
/*  63 */     if (this.field_3391 == part) {
/*  64 */       PlayerBendHelper.bend(this.field_3483, bone.getBend());
/*  65 */     } else if (this.field_3401 == part) {
/*  66 */       PlayerBendHelper.bend(this.field_3486, bone.getBend());
/*  67 */     } else if (this.field_27433 == part) {
/*  68 */       PlayerBendHelper.bend(this.field_3484, bone.getBend());
/*  69 */     } else if (this.field_3392 == part) {
/*  70 */       PlayerBendHelper.bend(this.field_3479, bone.getBend());
/*  71 */     } else if (this.field_3397 == part) {
/*  72 */       PlayerBendHelper.bend(this.field_3482, bone.getBend());
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Inject(method = {"pal$resetAll(Lcom/zigythebird/playeranim/animation/AvatarAnimManager;)V"}, at = {@At("RETURN")})
/*     */   public void bc$resetAll(@Nullable AvatarAnimManager emote, CallbackInfo ci) {
/*  84 */     PlayerBendHelper.resetBend(this.field_3391);
/*  85 */     PlayerBendHelper.resetBend(this.field_27433);
/*  86 */     PlayerBendHelper.resetBend(this.field_3401);
/*  87 */     PlayerBendHelper.resetBend(this.field_3397);
/*  88 */     PlayerBendHelper.resetBend(this.field_3392);
/*     */     
/*  90 */     PlayerBendHelper.resetBend(this.field_3483);
/*  91 */     PlayerBendHelper.resetBend(this.field_3484);
/*  92 */     PlayerBendHelper.resetBend(this.field_3486);
/*  93 */     PlayerBendHelper.resetBend(this.field_3482);
/*  94 */     PlayerBendHelper.resetBend(this.field_3479);
/*     */     
/*  96 */     this.bc$animation = null;
/*     */   }
/*     */   
/*     */   @Nullable
/*     */   public AvatarAnimManager bc$getAnimation() {
/* 101 */     return this.bc$animation;
/*     */   }
/*     */ }


/* Location:              C:\Users\rapha\Downloads\aurora.jar!\META-INF\jars\bendable-cuboids-p5LKzVqY.jar!\com\zigythebird\bendable_cuboids\mixin\playeranim\PlayerModelMixin_playerAnim.class
 * Java compiler version: 21 (65.0)
 * JD-Core Version:       1.1.3
 */