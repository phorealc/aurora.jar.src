/*    */ package com.zigythebird.bendable_cuboids.mixin.playeranim;
/*    */ 
/*    */ import com.llamalad7.mixinextras.injector.wrapoperation.Operation;
/*    */ import com.llamalad7.mixinextras.injector.wrapoperation.WrapOperation;
/*    */ import com.llamalad7.mixinextras.sugar.Local;
/*    */ import it.unimi.dsi.fastutil.Pair;
/*    */ import java.util.Collections;
/*    */ import java.util.HashMap;
/*    */ import java.util.Map;
/*    */ import net.minecraft.class_2350;
/*    */ import net.minecraft.class_5599;
/*    */ import net.minecraft.class_5601;
/*    */ import net.minecraft.class_5607;
/*    */ import net.minecraft.class_630;
/*    */ import org.spongepowered.asm.mixin.Mixin;
/*    */ import org.spongepowered.asm.mixin.injection.At;
/*    */ 
/*    */ 
/*    */ 
/*    */ @Mixin({class_5599.class})
/*    */ public class EntityModelSetMixin_playerAnim
/*    */ {
/*    */   @WrapOperation(method = {"method_32072(Lnet/minecraft/class_5601;)Lnet/minecraft/class_630;"}, at = {@At(value = "INVOKE", target = "Lnet/minecraft/class_5607;method_32109()Lnet/minecraft/class_630;")})
/*    */   private class_630 bakeLayerWithBendsForPlayer(class_5607 instance, Operation<class_630> original, @Local class_5607 layerDefinition, @Local(argsOnly = true) class_5601 modelLayerLocation) {
/* 25 */     if ("minecraft".equals(modelLayerLocation.comp_2995().method_12836()) && ("player"
/* 26 */       .equals(modelLayerLocation.comp_2995().method_12832()) || "player_slim".equals(modelLayerLocation.comp_2995().method_12832()))) {
/* 27 */       Map<String, Pair<class_2350, Integer>> cuboidDataMap = new HashMap<>();
/* 28 */       cuboidDataMap.put("cape", Pair.of(class_2350.field_11036, Integer.valueOf(6)));
/* 29 */       cuboidDataMap.put("body", Pair.of(class_2350.field_11033, Integer.valueOf(-1)));
/* 30 */       cuboidDataMap.put("jacket", Pair.of(class_2350.field_11033, Integer.valueOf(-1)));
/* 31 */       return layerDefinition.bakeRootWithBends(cuboidDataMap, Collections.singleton("head"));
/*    */     } 
/* 33 */     return (class_630)original.call(new Object[] { instance });
/*    */   }
/*    */ }


/* Location:              C:\Users\rapha\Downloads\aurora.jar!\META-INF\jars\bendable-cuboids-p5LKzVqY.jar!\com\zigythebird\bendable_cuboids\mixin\playeranim\EntityModelSetMixin_playerAnim.class
 * Java compiler version: 21 (65.0)
 * JD-Core Version:       1.1.3
 */