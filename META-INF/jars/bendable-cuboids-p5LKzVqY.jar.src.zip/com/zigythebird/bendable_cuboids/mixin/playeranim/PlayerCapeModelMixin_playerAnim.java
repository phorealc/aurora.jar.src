/*    */ package com.zigythebird.bendable_cuboids.mixin.playeranim;
/*    */ 
/*    */ import com.zigythebird.bendable_cuboids.impl.compatibility.PlayerBendHelper;
/*    */ import com.zigythebird.playeranim.accessors.IBoneUpdater;
/*    */ import com.zigythebird.playeranim.animation.AvatarAnimManager;
/*    */ import com.zigythebird.playeranimcore.bones.PlayerAnimBone;
/*    */ import net.minecraft.class_630;
/*    */ import net.minecraft.class_9950;
/*    */ import org.jetbrains.annotations.Nullable;
/*    */ import org.spongepowered.asm.mixin.Final;
/*    */ import org.spongepowered.asm.mixin.Mixin;
/*    */ import org.spongepowered.asm.mixin.Shadow;
/*    */ import org.spongepowered.asm.mixin.injection.At;
/*    */ import org.spongepowered.asm.mixin.injection.Inject;
/*    */ import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ @Mixin({class_9950.class})
/*    */ public class PlayerCapeModelMixin_playerAnim
/*    */   implements IBoneUpdater
/*    */ {
/*    */   @Shadow
/*    */   @Final
/*    */   private class_630 field_52927;
/*    */   
/*    */   @Inject(method = {"pal$updatePart(Lcom/zigythebird/playeranim/animation/AvatarAnimManager;Lnet/minecraft/client/model/geom/ModelPart;Lcom/zigythebird/playeranimcore/bones/PlayerAnimBone;)V", "pal$updatePart(Lcom/zigythebird/playeranim/animation/AvatarAnimManager;Lnet/minecraft/class_630;Lcom/zigythebird/playeranimcore/bones/PlayerAnimBone;)V"}, at = {@At("RETURN")})
/*    */   public void bc$updatePart(AvatarAnimManager manager, class_630 part, PlayerAnimBone bone, CallbackInfo ci) {
/* 34 */     if (this.field_52927 != part)
/*    */       return; 
/* 36 */     float bend = bone.getBend();
/* 37 */     if (Math.abs(bend) > 1.0E-4F) {
/* 38 */       float torsoBend = manager.get3DTransform(new PlayerAnimBone("torso")).getBend();
/* 39 */       if (torsoBend < 0.0F) bend += torsoBend;
/*    */     
/*    */     } 
/* 42 */     PlayerBendHelper.bend(this.field_52927, bend);
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   @Inject(method = {"pal$resetAll(Lcom/zigythebird/playeranim/animation/AvatarAnimManager;)V"}, at = {@At("RETURN")})
/*    */   public void bc$resetAll(@Nullable AvatarAnimManager emote, CallbackInfo ci) {
/* 53 */     PlayerBendHelper.resetBend(this.field_52927);
/*    */   }
/*    */ }


/* Location:              C:\Users\rapha\Downloads\aurora.jar!\META-INF\jars\bendable-cuboids-p5LKzVqY.jar!\com\zigythebird\bendable_cuboids\mixin\playeranim\PlayerCapeModelMixin_playerAnim.class
 * Java compiler version: 21 (65.0)
 * JD-Core Version:       1.1.3
 */