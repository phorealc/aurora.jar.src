/*    */ package com.zigythebird.bendable_cuboids.mixin.playeranim;
/*    */ import com.zigythebird.playeranim.accessors.IAvatarAnimationState;
/*    */ import com.zigythebird.playeranimcore.bones.PlayerAnimBone;
/*    */ import net.minecraft.class_10426;
/*    */ import net.minecraft.class_10444;
/*    */ import net.minecraft.class_11659;
/*    */ import net.minecraft.class_1306;
/*    */ import net.minecraft.class_1799;
/*    */ import net.minecraft.class_4587;
/*    */ import net.minecraft.class_7833;
/*    */ import net.minecraft.class_989;
/*    */ import org.joml.Quaternionfc;
/*    */ import org.spongepowered.asm.mixin.Mixin;
/*    */ import org.spongepowered.asm.mixin.Unique;
/*    */ import org.spongepowered.asm.mixin.injection.At;
/*    */ import org.spongepowered.asm.mixin.injection.Inject;
/*    */ 
/*    */ @Mixin({class_989.class})
/*    */ public class ItemInHandLayerMixin_playerAnim<S extends class_10426> {
/*    */   @Unique
/* 21 */   private final PlayerAnimBone bendableCuboids$rightArm = new PlayerAnimBone("right_arm");
/*    */   @Unique
/* 23 */   private final PlayerAnimBone bendableCuboids$leftArm = new PlayerAnimBone("left_arm");
/*    */ 
/*    */   
/*    */   @Inject(method = {"method_4192(Lnet/minecraft/class_10426;Lnet/minecraft/class_10444;Lnet/minecraft/class_1799;Lnet/minecraft/class_1306;Lnet/minecraft/class_4587;Lnet/minecraft/class_11659;I)V"}, at = {@At(value = "INVOKE", target = "Lnet/minecraft/class_4587;method_22907(Lorg/joml/Quaternionfc;)V", ordinal = 0)})
/*    */   private void renderMixin(S armedEntityRenderState, class_10444 itemStackRenderState, class_1799 itemStack, class_1306 humanoidArm, class_4587 poseStack, class_11659 submitNodeCollector, int i, CallbackInfo ci) {
/* 28 */     if (armedEntityRenderState instanceof IAvatarAnimationState) { IAvatarAnimationState state = (IAvatarAnimationState)armedEntityRenderState;
/* 29 */       if (state.playerAnimLib$getAnimManager().isActive()) {
/* 30 */         PlayerAnimBone bone = (humanoidArm == class_1306.field_6182) ? this.bendableCuboids$leftArm : this.bendableCuboids$rightArm;
/* 31 */         bone.bend = 0.0F;
/* 32 */         state.playerAnimLib$getAnimManager().get3DTransform(bone);
/* 33 */         float offset = 0.25F;
/* 34 */         poseStack.method_46416(0.0F, offset, 0.0F);
/* 35 */         poseStack.method_22907((Quaternionfc)class_7833.field_40714.rotation(bone.getBend()));
/* 36 */         poseStack.method_46416(0.0F, -offset, 0.0F);
/*    */       }  }
/*    */   
/*    */   }
/*    */ }


/* Location:              C:\Users\rapha\Downloads\aurora.jar!\META-INF\jars\bendable-cuboids-p5LKzVqY.jar!\com\zigythebird\bendable_cuboids\mixin\playeranim\ItemInHandLayerMixin_playerAnim.class
 * Java compiler version: 21 (65.0)
 * JD-Core Version:       1.1.3
 */