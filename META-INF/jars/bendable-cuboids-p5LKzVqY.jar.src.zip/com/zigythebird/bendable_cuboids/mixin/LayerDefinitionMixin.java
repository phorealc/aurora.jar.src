/*    */ package com.zigythebird.bendable_cuboids.mixin;
/*    */ 
/*    */ import com.zigythebird.bendable_cuboids.api.ILayerDefinition;
/*    */ import it.unimi.dsi.fastutil.Pair;
/*    */ import java.util.Map;
/*    */ import java.util.Set;
/*    */ import net.minecraft.class_2350;
/*    */ import net.minecraft.class_5607;
/*    */ import net.minecraft.class_5608;
/*    */ import net.minecraft.class_5609;
/*    */ import net.minecraft.class_630;
/*    */ import org.spongepowered.asm.mixin.Final;
/*    */ import org.spongepowered.asm.mixin.Mixin;
/*    */ import org.spongepowered.asm.mixin.Shadow;
/*    */ 
/*    */ @Mixin({class_5607.class})
/*    */ public class LayerDefinitionMixin implements ILayerDefinition {
/*    */   @Shadow
/*    */   @Final
/*    */   private class_5609 field_27723;
/*    */   @Shadow
/*    */   @Final
/*    */   private class_5608 field_27724;
/*    */   
/*    */   public class_630 bakeRootWithBends(Map<String, Pair<class_2350, Integer>> cuboidDataMap, Set<String> noBends) {
/* 26 */     return this.field_27723.method_32111().bakeBendablePart(this.field_27724.field_27725, this.field_27724.field_27726, cuboidDataMap, noBends, "root");
/*    */   }
/*    */ }


/* Location:              C:\Users\rapha\Downloads\aurora.jar!\META-INF\jars\bendable-cuboids-p5LKzVqY.jar!\com\zigythebird\bendable_cuboids\mixin\LayerDefinitionMixin.class
 * Java compiler version: 21 (65.0)
 * JD-Core Version:       1.1.3
 */