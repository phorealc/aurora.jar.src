/*    */ package com.zigythebird.bendable_cuboids.mixin;
/*    */ 
/*    */ import com.google.common.collect.ImmutableList;
/*    */ import com.zigythebird.bendable_cuboids.api.IPartDefinition;
/*    */ import com.zigythebird.bendable_cuboids.impl.BendableCuboid;
/*    */ import it.unimi.dsi.fastutil.Pair;
/*    */ import it.unimi.dsi.fastutil.objects.Object2ObjectArrayMap;
/*    */ import java.util.List;
/*    */ import java.util.Map;
/*    */ import java.util.Set;
/*    */ import java.util.function.Supplier;
/*    */ import java.util.stream.Collectors;
/*    */ import net.minecraft.class_2350;
/*    */ import net.minecraft.class_5603;
/*    */ import net.minecraft.class_5604;
/*    */ import net.minecraft.class_5610;
/*    */ import net.minecraft.class_630;
/*    */ import org.spongepowered.asm.mixin.Final;
/*    */ import org.spongepowered.asm.mixin.Mixin;
/*    */ import org.spongepowered.asm.mixin.Shadow;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ @Mixin({class_5610.class})
/*    */ public abstract class PartDefinitionMixin
/*    */   implements IPartDefinition
/*    */ {
/*    */   @Shadow
/*    */   @Final
/*    */   private Map<String, class_5610> field_27730;
/*    */   
/*    */   public class_630 bakeBendablePart(int texWidth, int texHeight, Map<String, Pair<class_2350, Integer>> cuboidDataMap, Set<String> noBends, String name) {
/* 34 */     if (noBends.contains(name)) return method_32112(texWidth, texHeight); 
/* 35 */     Pair<class_2350, Integer> cuboidData = cuboidDataMap.getOrDefault(name, Pair.of(class_2350.field_11036, Integer.valueOf(-1)));
/* 36 */     Object2ObjectArrayMap<String, class_630> object2objectarraymap = (Object2ObjectArrayMap<String, class_630>)this.field_27730.entrySet().stream().collect(Collectors.toMap(Map.Entry::getKey, partDefinitionMap -> ((IPartDefinition)partDefinitionMap.getValue()).bakeBendablePart(texWidth, texHeight, cuboidDataMap, noBends, (String)partDefinitionMap.getKey()), (modelPart, modelPart1) -> modelPart, Object2ObjectArrayMap::new));
/* 37 */     List<class_630.class_628> list = (List<class_630.class_628>)this.field_27728.stream().map(definition -> definition.bakeBendableCuboid(texWidth, texHeight, (class_2350)cuboidData.left(), ((Integer)cuboidData.right()).intValue())).collect(ImmutableList.toImmutableList());
/* 38 */     class_630 modelpart = new class_630(list, (Map)object2objectarraymap);
/* 39 */     modelpart.method_41918(this.field_27729);
/* 40 */     modelpart.method_32085(this.field_27729);
/* 41 */     return modelpart;
/*    */   }
/*    */   
/*    */   @Shadow
/*    */   @Final
/*    */   private List<class_5604> field_27728;
/*    */   @Shadow
/*    */   @Final
/*    */   private class_5603 field_27729;
/*    */   
/*    */   @Shadow
/*    */   public abstract class_630 method_32112(int paramInt1, int paramInt2);
/*    */ }


/* Location:              C:\Users\rapha\Downloads\aurora.jar!\META-INF\jars\bendable-cuboids-p5LKzVqY.jar!\com\zigythebird\bendable_cuboids\mixin\PartDefinitionMixin.class
 * Java compiler version: 21 (65.0)
 * JD-Core Version:       1.1.3
 */