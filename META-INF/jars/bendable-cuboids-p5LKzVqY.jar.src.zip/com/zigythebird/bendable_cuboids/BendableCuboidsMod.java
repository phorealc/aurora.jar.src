/*    */ package com.zigythebird.bendable_cuboids;
/*    */ 
/*    */ import com.zigythebird.bendable_cuboids.impl.compatibility.SkinLayersCompat;
/*    */ import org.slf4j.Logger;
/*    */ import org.slf4j.LoggerFactory;
/*    */ 
/*    */ public abstract class BendableCuboidsMod {
/*  8 */   public static final Logger LOGGER = LoggerFactory.getLogger("BendableCuboids");
/*    */   
/*    */   public void setupSkinLayersTransformer() {
/*    */     try {
/* 12 */       SkinLayersCompat.setupTransformer();
/* 13 */     } catch (Throwable throwable) {}
/*    */   }
/*    */ }


/* Location:              C:\Users\rapha\Downloads\aurora.jar!\META-INF\jars\bendable-cuboids-p5LKzVqY.jar!\com\zigythebird\bendable_cuboids\BendableCuboidsMod.class
 * Java compiler version: 21 (65.0)
 * JD-Core Version:       1.1.3
 */