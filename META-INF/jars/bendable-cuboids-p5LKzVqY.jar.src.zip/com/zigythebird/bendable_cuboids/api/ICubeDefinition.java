package com.zigythebird.bendable_cuboids.api;

import com.zigythebird.bendable_cuboids.impl.BendableCuboid;
import net.minecraft.class_2350;

public interface ICubeDefinition {
  BendableCuboid bakeBendableCuboid(int paramInt1, int paramInt2, class_2350 paramclass_2350, int paramInt3);
}


/* Location:              C:\Users\rapha\Downloads\aurora.jar!\META-INF\jars\bendable-cuboids-p5LKzVqY.jar!\com\zigythebird\bendable_cuboids\api\ICubeDefinition.class
 * Java compiler version: 21 (65.0)
 * JD-Core Version:       1.1.3
 */