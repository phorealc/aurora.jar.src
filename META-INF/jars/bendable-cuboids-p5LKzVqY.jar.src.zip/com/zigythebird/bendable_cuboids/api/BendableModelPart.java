package com.zigythebird.bendable_cuboids.api;

import org.jetbrains.annotations.Nullable;

public interface BendableModelPart {
  @Nullable
  BendableCube bc$getCuboid(int paramInt);
}


/* Location:              C:\Users\rapha\Downloads\aurora.jar!\META-INF\jars\bendable-cuboids-p5LKzVqY.jar!\com\zigythebird\bendable_cuboids\api\BendableModelPart.class
 * Java compiler version: 21 (65.0)
 * JD-Core Version:       1.1.3
 */