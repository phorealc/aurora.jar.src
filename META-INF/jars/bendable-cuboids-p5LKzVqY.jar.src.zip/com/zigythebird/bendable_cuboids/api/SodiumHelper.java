package com.zigythebird.bendable_cuboids.api;

public interface SodiumHelper {
  default void bc$useSodiumRendering(boolean use) {}
}


/* Location:              C:\Users\rapha\Downloads\aurora.jar!\META-INF\jars\bendable-cuboids-p5LKzVqY.jar!\com\zigythebird\bendable_cuboids\api\SodiumHelper.class
 * Java compiler version: 21 (65.0)
 * JD-Core Version:       1.1.3
 */