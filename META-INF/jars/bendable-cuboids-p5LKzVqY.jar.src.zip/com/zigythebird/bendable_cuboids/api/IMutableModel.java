package com.zigythebird.bendable_cuboids.api;

import com.zigythebird.playeranim.animation.AvatarAnimManager;
import org.jetbrains.annotations.ApiStatus.Internal;
import org.jetbrains.annotations.Nullable;

@Internal
public interface IMutableModel {
  @Nullable
  AvatarAnimManager bc$getAnimation();
}


/* Location:              C:\Users\rapha\Downloads\aurora.jar!\META-INF\jars\bendable-cuboids-p5LKzVqY.jar!\com\zigythebird\bendable_cuboids\api\IMutableModel.class
 * Java compiler version: 21 (65.0)
 * JD-Core Version:       1.1.3
 */