package com.zigythebird.bendable_cuboids.api;

import it.unimi.dsi.fastutil.Pair;
import java.util.Map;
import java.util.Set;
import net.minecraft.class_2350;
import net.minecraft.class_630;

public interface ILayerDefinition {
  class_630 bakeRootWithBends(Map<String, Pair<class_2350, Integer>> paramMap, Set<String> paramSet);
}


/* Location:              C:\Users\rapha\Downloads\aurora.jar!\META-INF\jars\bendable-cuboids-p5LKzVqY.jar!\com\zigythebird\bendable_cuboids\api\ILayerDefinition.class
 * Java compiler version: 21 (65.0)
 * JD-Core Version:       1.1.3
 */