package com.zigythebird.bendable_cuboids.api;

import it.unimi.dsi.fastutil.Pair;
import java.util.Map;
import java.util.Set;
import net.minecraft.class_2350;
import net.minecraft.class_630;

public interface IPartDefinition {
  class_630 bakeBendablePart(int paramInt1, int paramInt2, Map<String, Pair<class_2350, Integer>> paramMap, Set<String> paramSet, String paramString);
}


/* Location:              C:\Users\rapha\Downloads\aurora.jar!\META-INF\jars\bendable-cuboids-p5LKzVqY.jar!\com\zigythebird\bendable_cuboids\api\IPartDefinition.class
 * Java compiler version: 21 (65.0)
 * JD-Core Version:       1.1.3
 */