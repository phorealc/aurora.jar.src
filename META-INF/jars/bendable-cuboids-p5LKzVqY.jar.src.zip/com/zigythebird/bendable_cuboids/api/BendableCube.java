/*    */ package com.zigythebird.bendable_cuboids.api;
/*    */ 
/*    */ import com.zigythebird.bendable_cuboids.impl.Plane;
/*    */ import net.minecraft.class_2350;
/*    */ import org.jetbrains.annotations.Nullable;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public interface BendableCube
/*    */   extends Bendable
/*    */ {
/*    */   void applyBend(float paramFloat);
/*    */   
/*    */   default void applyBendDegrees(float bendValue) {
/* 25 */     applyBend(bendValue * 0.017453292F);
/*    */   }
/*    */ 
/*    */   
/*    */   @Nullable
/*    */   class_2350 getBendDirection();
/*    */ 
/*    */   
/*    */   int getBendPivot();
/*    */   
/*    */   float getBendX();
/*    */   
/*    */   float getBendY();
/*    */   
/*    */   float getBendZ();
/*    */   
/*    */   float getExtentZ();
/*    */   
/*    */   Plane getBasePlane();
/*    */   
/*    */   Plane getOtherPlane();
/*    */   
/*    */   float bendHeight();
/*    */   
/*    */   default boolean isBendInverted() {
/* 50 */     class_2350 direction = getBendDirection();
/* 51 */     if (direction == null) return false; 
/* 52 */     return (direction.method_10171() == class_2350.class_2352.field_11056);
/*    */   }
/*    */   
/*    */   default void bc$copyState(BendableCube other) {
/* 56 */     if (getBendDirection() != null) applyBend(other.getBend()); 
/*    */   }
/*    */ }


/* Location:              C:\Users\rapha\Downloads\aurora.jar!\META-INF\jars\bendable-cuboids-p5LKzVqY.jar!\com\zigythebird\bendable_cuboids\api\BendableCube.class
 * Java compiler version: 21 (65.0)
 * JD-Core Version:       1.1.3
 */