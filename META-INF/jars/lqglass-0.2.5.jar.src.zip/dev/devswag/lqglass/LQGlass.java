/*     */ package dev.devswag.lqglass;
/*     */ 
/*     */ import dev.devswag.lqglass.hud.GlassHudElement;
/*     */ import dev.devswag.lqglass.hud.HudEditorScreen;
/*     */ import dev.devswag.lqglass.hud.HudLayoutStore;
/*     */ import dev.devswag.lqglass.hud.HudRegistry;
/*     */ import dev.devswag.lqglass.state.SettingValue;
/*     */ import dev.devswag.lqglass.style.LiquidGlassTheme;
/*     */ import dev.devswag.lqglass.ui.GlassPlayground;
/*     */ import dev.devswag.lqglass.ui.GlassScreen;
/*     */ import dev.devswag.lqglass.ui.SettingsScreen;
/*     */ import dev.devswag.lqglass.ui.UiComponent;
/*     */ import dev.devswag.lqglass.ui.components.Button;
/*     */ import dev.devswag.lqglass.ui.components.Dropdown;
/*     */ import dev.devswag.lqglass.ui.components.GlassPanel;
/*     */ import dev.devswag.lqglass.ui.components.Slider;
/*     */ import dev.devswag.lqglass.ui.components.Toggle;
/*     */ import java.util.List;
/*     */ import net.fabricmc.loader.api.FabricLoader;
/*     */ import net.minecraft.class_2561;
/*     */ import net.minecraft.class_2960;
/*     */ import net.minecraft.class_310;
/*     */ import net.minecraft.class_437;
/*     */ import org.slf4j.Logger;
/*     */ import org.slf4j.LoggerFactory;
/*     */ 
/*     */ public final class LQGlass
/*     */ {
/*     */   public static final String MOD_ID = "lqglass";
/*  30 */   public static final Logger LOG = LoggerFactory.getLogger("lqglass");
/*     */   
/*  32 */   private static LiquidGlassTheme theme = LiquidGlassTheme.dark();
/*  33 */   private static final HudLayoutStore HUD_LAYOUTS = new HudLayoutStore(
/*  34 */       FabricLoader.getInstance().getConfigDir().resolve("lqglass-hud.properties"));
/*  35 */   private static final HudRegistry HUD = new HudRegistry();
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static class_2960 id(String path) {
/*  41 */     return class_2960.method_60655("lqglass", path);
/*     */   }
/*     */   
/*     */   public static LiquidGlassTheme theme() {
/*  45 */     return theme;
/*     */   }
/*     */   
/*     */   public static void theme(LiquidGlassTheme theme) {
/*  49 */     if (theme == null)
/*  50 */       throw new IllegalArgumentException("theme"); 
/*  51 */     LQGlass.theme = theme;
/*     */   }
/*     */   
/*     */   public static HudRegistry hud() {
/*  55 */     return HUD;
/*     */   }
/*     */   
/*     */   public static HudLayoutStore hudLayouts() {
/*  59 */     return HUD_LAYOUTS;
/*     */   }
/*     */   
/*     */   public static GlassScreen createScreen(String title, UiComponent root) {
/*  63 */     return new GlassScreen((class_2561)class_2561.method_43470((title == null) ? "" : title), root, theme);
/*     */   }
/*     */   
/*     */   public static GlassScreen createComponentScreen(class_2561 title, UiComponent root) {
/*  67 */     return new GlassScreen(title, root, theme);
/*     */   }
/*     */   
/*     */   public static GlassScreen createMaterialPlayground() {
/*  71 */     return GlassPlayground.create();
/*     */   }
/*     */   
/*     */   public static void openMaterialPlayground() {
/*  75 */     class_310.method_1551().method_1507((class_437)createMaterialPlayground());
/*     */   }
/*     */   
/*     */   public static SettingsScreen createSettingsScreen(String title) {
/*  79 */     return new SettingsScreen(title, theme);
/*     */   }
/*     */   
/*     */   public static GlassPanel createPanel() {
/*  83 */     return new GlassPanel();
/*     */   }
/*     */   
/*     */   public static Button createButton(String label, Runnable action) {
/*  87 */     return new Button(label, action);
/*     */   }
/*     */   
/*     */   public static Button createComponentButton(class_2561 label, Runnable action) {
/*  91 */     return Button.fromComponent(label, action);
/*     */   }
/*     */   
/*     */   public static Toggle createToggle(String label, SettingValue<Boolean> value) {
/*  95 */     return new Toggle(label, value);
/*     */   }
/*     */   
/*     */   public static Slider createSlider(String label, SettingValue<Double> value, double min, double max, double step) {
/*  99 */     return new Slider(label, value, min, max, step);
/*     */   }
/*     */   
/*     */   public static <T> Dropdown<T> createDropdown(String label, SettingValue<T> value, List<T> options) {
/* 103 */     return new Dropdown(label, value, options);
/*     */   }
/*     */   
/*     */   public static GlassHudElement createHudElement(class_2960 id, UiComponent root, int width, int height) {
/* 107 */     return new GlassHudElement(id, root, width, height);
/*     */   }
/*     */   
/*     */   public static HudEditorScreen createHudEditor() {
/* 111 */     return new HudEditorScreen(HUD, HUD_LAYOUTS);
/*     */   }
/*     */   
/*     */   public static void saveHudLayout() {
/* 115 */     for (GlassHudElement element : HUD.elements())
/* 116 */       HUD_LAYOUTS.capture(element); 
/* 117 */     HUD_LAYOUTS.save();
/*     */   }
/*     */   
/*     */   public static void shutdown() {
/* 121 */     saveHudLayout();
/* 122 */     HUD.clear();
/*     */   }
/*     */ }


/* Location:              C:\Users\rapha\Downloads\aurora.jar!\META-INF\jars\lqglass-0.2.5.jar!\dev\devswag\lqglass\LQGlass.class
 * Java compiler version: 21 (65.0)
 * JD-Core Version:       1.1.3
 */