/*    */ package dev.devswag.lqglass.style;public final class LiquidGlassTheme extends Record { private final ComponentStyle panel;
/*    */   private final ComponentStyle control;
/*    */   private final ComponentStyle tooltip;
/*    */   private final int backgroundDim;
/*    */   
/*  6 */   public LiquidGlassTheme(ComponentStyle panel, ComponentStyle control, ComponentStyle tooltip, int backgroundDim) { this.panel = panel; this.control = control; this.tooltip = tooltip; this.backgroundDim = backgroundDim; } public final String toString() { // Byte code:
/*    */     //   0: aload_0
/*    */     //   1: <illegal opcode> toString : (Ldev/devswag/lqglass/style/LiquidGlassTheme;)Ljava/lang/String;
/*    */     //   6: areturn
/*    */     // Line number table:
/*    */     //   Java source line number -> byte code offset
/*    */     //   #6	-> 0
/*    */     // Local variable table:
/*    */     //   start	length	slot	name	descriptor
/*  6 */     //   0	7	0	this	Ldev/devswag/lqglass/style/LiquidGlassTheme; } public ComponentStyle panel() { return this.panel; } public final int hashCode() { // Byte code:
/*    */     //   0: aload_0
/*    */     //   1: <illegal opcode> hashCode : (Ldev/devswag/lqglass/style/LiquidGlassTheme;)I
/*    */     //   6: ireturn
/*    */     // Line number table:
/*    */     //   Java source line number -> byte code offset
/*    */     //   #6	-> 0
/*    */     // Local variable table:
/*    */     //   start	length	slot	name	descriptor
/*    */     //   0	7	0	this	Ldev/devswag/lqglass/style/LiquidGlassTheme; } public final boolean equals(Object o) { // Byte code:
/*    */     //   0: aload_0
/*    */     //   1: aload_1
/*    */     //   2: <illegal opcode> equals : (Ldev/devswag/lqglass/style/LiquidGlassTheme;Ljava/lang/Object;)Z
/*    */     //   7: ireturn
/*    */     // Line number table:
/*    */     //   Java source line number -> byte code offset
/*    */     //   #6	-> 0
/*    */     // Local variable table:
/*    */     //   start	length	slot	name	descriptor
/*    */     //   0	8	0	this	Ldev/devswag/lqglass/style/LiquidGlassTheme;
/*  6 */     //   0	8	1	o	Ljava/lang/Object; } public ComponentStyle control() { return this.control; } public ComponentStyle tooltip() { return this.tooltip; } public int backgroundDim() { return this.backgroundDim; }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public static LiquidGlassTheme dark() {
/* 16 */     ComponentStyle panel = new ComponentStyle(GlassPresets.DARK, -657414, -5327164, -8607489, 553648127, 855638015, 1719239055, Insets.all(12), 8, 140);
/*    */ 
/*    */ 
/*    */     
/* 20 */     ComponentStyle control = new ComponentStyle(GlassPresets.SUBTLE, -657414, -5327164, -8607489, 687865855, 989855743, 1719239055, Insets.xy(9, 6), 6, 120);
/*    */ 
/*    */ 
/*    */     
/* 24 */     ComponentStyle tooltip = new ComponentStyle(GlassPresets.STRONG.radius(7), -1, -4472114, -8607489, 0, 0, 1719239055, Insets.xy(8, 6), 4, 80);
/*    */     
/* 26 */     return new LiquidGlassTheme(panel, control, tooltip, 1375731712);
/*    */   } }


/* Location:              C:\Users\rapha\Downloads\aurora.jar!\META-INF\jars\lqglass-0.2.5.jar!\dev\devswag\lqglass\style\LiquidGlassTheme.class
 * Java compiler version: 21 (65.0)
 * JD-Core Version:       1.1.3
 */