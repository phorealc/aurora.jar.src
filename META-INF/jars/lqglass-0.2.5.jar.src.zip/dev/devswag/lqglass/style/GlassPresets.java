/*    */ package dev.devswag.lqglass.style;
/*    */ 
/*    */ public final class GlassPresets {
/*  4 */   public static final GlassStyle SUBTLE = new GlassStyle(-1340465884, 0.42F, 0.45F, 0.08F, 1.02F, 1.02F, 0.02F, 1174405119, 10, 1174405120, 5, 419430399, 352321535, 0.22F, true);
/*    */ 
/*    */ 
/*    */   
/*  8 */   public static final GlassStyle FROSTED = (new GlassStyle(-639046155, 0.56F, 0.9F, 0.04F, 0.88F, 1.06F, 0.05F, 1895825407, 13, 1107296256, 7, 956301311, 620756991, 0.34F, true))
/*    */ 
/*    */     
/* 11 */     .blurSpread(0.45F).edgeWidth(10.0F);
/*    */   
/* 13 */   public static final GlassStyle CLEAR = (new GlassStyle(1879048191, 0.25F, 0.35F, 0.18F, 1.08F, 1.04F, 0.01F, 1761607679, 12, 855638016, 5, 822083583, 553648127, 0.44F, true))
/*    */ 
/*    */     
/* 16 */     .roughness(0.12F);
/*    */   
/* 18 */   public static final GlassStyle STRONG = (new GlassStyle(-702865366, 0.68F, 1.0F, 0.1F, 0.92F, 1.1F, 0.04F, 1728053247, 14, 1711276032, 9, 788529151, 553648127, 0.38F, true))
/*    */ 
/*    */     
/* 21 */     .blurSpread(0.7F);
/*    */   
/* 23 */   public static final GlassStyle DARK = (new GlassStyle(-535817704, 0.72F, 0.78F, 0.08F, 0.88F, 1.08F, 0.025F, 1124073471, 12, 1879048192, 8, 553648127, 318767103, 0.28F, true))
/*    */ 
/*    */     
/* 26 */     .roughness(0.48F).blurSpread(0.3F);
/*    */   
/* 28 */   public static final GlassStyle LIGHT = (new GlassStyle(-353241862, 0.62F, 0.72F, 0.06F, 0.95F, 1.04F, 0.03F, -1996488705, 12, 939524096, 6, 1191182335, 822083583, 0.3F, true))
/*    */ 
/*    */     
/* 31 */     .blurSpread(0.3F);
/*    */   
/* 33 */   public static final GlassStyle HUD = new GlassStyle(-803726558, 0.58F, 0.0F, 0.0F, 0.95F, 1.04F, 0.015F, 922746879, 8, 1375731712, 5, 419430399, 285212671, 0.2F, false);
/*    */ 
/*    */ 
/*    */   
/* 37 */   public static final GlassStyle CRYSTAL = CLEAR
/* 38 */     .tintGradient(1308622847, -2133393409)
/* 39 */     .opacity(0.36F).blurBlend(0.2F).refraction(0.72F)
/* 40 */     .cornerRadii(24, 8, 28, 8).highlight(0.85F)
/* 41 */     .chromaticAberration(0.08F).roughness(0.08F).lightAngle(236.0F)
/* 42 */     .blurSpread(0.12F).edgeWidth(12.0F).edgeLight(-419430401);
/*    */   
/* 44 */   public static final GlassStyle AURORA = CLEAR
/* 45 */     .tintGradient(2017918944, -2007080193)
/* 46 */     .opacity(0.34F).blurBlend(0.42F).refraction(0.64F)
/* 47 */     .cornerRadii(30, 12, 30, 12).highlight(0.8F)
/* 48 */     .chromaticAberration(0.34F).iridescence(0.82F).roughness(0.14F).lightAngle(228.0F)
/* 49 */     .blurSpread(0.58F).edgeWidth(15.0F).tintAngle(120.0F).edgeLight(-792334337);
/*    */   
/* 51 */   public static final GlassStyle PRISM = CLEAR
/* 52 */     .tintGradient(1616767999, 1895790031)
/* 53 */     .opacity(0.27F).blurBlend(0.16F).refraction(0.9F)
/* 54 */     .chromaticAberration(0.78F).iridescence(0.94F).roughness(0.1F).lightAngle(214.0F)
/* 55 */     .blurSpread(0.07F).edgeWidth(16.0F).tintAngle(25.0F).edgeLight(-385881601);
/*    */   
/* 57 */   public static final GlassStyle AMBER = (new GlassStyle(-922766774, 0.34F, 0.52F, 0.22F, 0.96F, 1.12F, 0.025F, -1795169632, 22, 1880033024, 12, 822072714, 1358929218, 0.62F, true))
/*    */ 
/*    */     
/* 60 */     .tintGradient(-922766774, -1577095613)
/* 61 */     .cornerRadii(28, 8, 28, 8).roughness(0.2F).lightAngle(220.0F)
/* 62 */     .blurSpread(0.42F).edgeWidth(11.0F).tintAngle(110.0F).edgeLight(-7505);
/*    */   
/* 64 */   public static final GlassStyle MIDNIGHT = (new GlassStyle(-602597073, 0.62F, 0.72F, 0.3F, 1.1F, 1.18F, 0.035F, -2142544129, 18, -1728053230, 16, 944463615, 1615809535, 0.9F, true))
/*    */ 
/*    */     
/* 67 */     .tintGradient(-602597073, -751689642)
/* 68 */     .chromaticAberration(0.26F).iridescence(0.36F).roughness(0.22F).lightAngle(238.0F)
/* 69 */     .blurSpread(0.65F).edgeWidth(18.0F).tintAngle(65.0F).edgeLight(-1046563585);
/*    */ }


/* Location:              C:\Users\rapha\Downloads\aurora.jar!\META-INF\jars\lqglass-0.2.5.jar!\dev\devswag\lqglass\style\GlassPresets.class
 * Java compiler version: 21 (65.0)
 * JD-Core Version:       1.1.3
 */