/*    */ package dev.devswag.lqglass.style;
/*    */ public final class ComponentStyle extends Record { private final GlassStyle glass; private final int text; private final int secondaryText;
/*    */   private final int accent;
/*    */   private final int hover;
/*    */   
/*  6 */   public int animationMs() { return this.animationMs; } private final int pressed; private final int disabled; private final Insets padding; private final int gap; private final int animationMs; public int gap() { return this.gap; } public Insets padding() { return this.padding; } public int disabled() { return this.disabled; } public int pressed() { return this.pressed; } public int hover() { return this.hover; } public int accent() { return this.accent; } public int secondaryText() { return this.secondaryText; } public int text() { return this.text; } public GlassStyle glass() { return this.glass; }
/*    */   
/*    */   public final boolean equals(Object o) {
/*    */     // Byte code:
/*    */     //   0: aload_0
/*    */     //   1: aload_1
/*    */     //   2: <illegal opcode> equals : (Ldev/devswag/lqglass/style/ComponentStyle;Ljava/lang/Object;)Z
/*    */     //   7: ireturn
/*    */     // Line number table:
/*    */     //   Java source line number -> byte code offset
/*    */     //   #6	-> 0
/*    */     // Local variable table:
/*    */     //   start	length	slot	name	descriptor
/*    */     //   0	8	0	this	Ldev/devswag/lqglass/style/ComponentStyle;
/*    */     //   0	8	1	o	Ljava/lang/Object;
/*    */   }
/*    */   public final int hashCode() {
/*    */     // Byte code:
/*    */     //   0: aload_0
/*    */     //   1: <illegal opcode> hashCode : (Ldev/devswag/lqglass/style/ComponentStyle;)I
/*    */     //   6: ireturn
/*    */     // Line number table:
/*    */     //   Java source line number -> byte code offset
/*    */     //   #6	-> 0
/*    */     // Local variable table:
/*    */     //   start	length	slot	name	descriptor
/*    */     //   0	7	0	this	Ldev/devswag/lqglass/style/ComponentStyle;
/*    */   }
/*    */   
/*    */   public final String toString() {
/*    */     // Byte code:
/*    */     //   0: aload_0
/*    */     //   1: <illegal opcode> toString : (Ldev/devswag/lqglass/style/ComponentStyle;)Ljava/lang/String;
/*    */     //   6: areturn
/*    */     // Line number table:
/*    */     //   Java source line number -> byte code offset
/*    */     //   #6	-> 0
/*    */     // Local variable table:
/*    */     //   start	length	slot	name	descriptor
/*    */     //   0	7	0	this	Ldev/devswag/lqglass/style/ComponentStyle;
/*    */   }
/*    */   
/*    */   public ComponentStyle(GlassStyle glass, int text, int secondaryText, int accent, int hover, int pressed, int disabled, Insets padding, int gap, int animationMs) {
/* 20 */     padding = (padding == null) ? Insets.ZERO : padding;
/* 21 */     gap = Math.max(0, gap);
/* 22 */     animationMs = Math.max(0, animationMs);
/*    */     this.glass = glass;
/*    */     this.text = text;
/*    */     this.secondaryText = secondaryText;
/*    */     this.accent = accent;
/*    */     this.hover = hover;
/*    */     this.pressed = pressed;
/*    */     this.disabled = disabled;
/*    */     this.padding = padding;
/*    */     this.gap = gap;
/*    */     this.animationMs = animationMs;
/*    */   } }


/* Location:              C:\Users\rapha\Downloads\aurora.jar!\META-INF\jars\lqglass-0.2.5.jar!\dev\devswag\lqglass\style\ComponentStyle.class
 * Java compiler version: 21 (65.0)
 * JD-Core Version:       1.1.3
 */