/*     */ package dev.devswag.lqglass.style;
/*     */ public final class GlassStyle extends Record { private final int tint; private final float opacity; private final float blur; private final float refraction; private final float saturation; private final float contrast; private final float noise; private final int borderColor; private final int radius; private final int shadowColor; private final int shadowSize; private final int innerGlow; private final int outerGlow; private final float highlight;
/*     */   private final boolean mouseReactive;
/*     */   
/*   5 */   public int tint() { return this.tint; } private final int topRightRadius; private final int bottomRightRadius; private final int bottomLeftRadius; private final int tintBottom; private final float chromaticAberration; private final float iridescence; private final float roughness; private final float lightAngle; private final float blurSpread; private final float edgeWidth; private final float tintAngle; private final int edgeLight; public final String toString() { // Byte code:
/*     */     //   0: aload_0
/*     */     //   1: <illegal opcode> toString : (Ldev/devswag/lqglass/style/GlassStyle;)Ljava/lang/String;
/*     */     //   6: areturn
/*     */     // Line number table:
/*     */     //   Java source line number -> byte code offset
/*     */     //   #5	-> 0
/*     */     // Local variable table:
/*     */     //   start	length	slot	name	descriptor
/*     */     //   0	7	0	this	Ldev/devswag/lqglass/style/GlassStyle; } public final int hashCode() { // Byte code:
/*     */     //   0: aload_0
/*     */     //   1: <illegal opcode> hashCode : (Ldev/devswag/lqglass/style/GlassStyle;)I
/*     */     //   6: ireturn
/*     */     // Line number table:
/*     */     //   Java source line number -> byte code offset
/*     */     //   #5	-> 0
/*     */     // Local variable table:
/*     */     //   start	length	slot	name	descriptor
/*     */     //   0	7	0	this	Ldev/devswag/lqglass/style/GlassStyle; } public final boolean equals(Object o) { // Byte code:
/*     */     //   0: aload_0
/*     */     //   1: aload_1
/*     */     //   2: <illegal opcode> equals : (Ldev/devswag/lqglass/style/GlassStyle;Ljava/lang/Object;)Z
/*     */     //   7: ireturn
/*     */     // Line number table:
/*     */     //   Java source line number -> byte code offset
/*     */     //   #5	-> 0
/*     */     // Local variable table:
/*     */     //   start	length	slot	name	descriptor
/*     */     //   0	8	0	this	Ldev/devswag/lqglass/style/GlassStyle;
/*   5 */     //   0	8	1	o	Ljava/lang/Object; } public float opacity() { return this.opacity; } public float blur() { return this.blur; } public float refraction() { return this.refraction; } public float saturation() { return this.saturation; } public float contrast() { return this.contrast; } public float noise() { return this.noise; } public int borderColor() { return this.borderColor; } public int radius() { return this.radius; } public int shadowColor() { return this.shadowColor; } public int shadowSize() { return this.shadowSize; } public int innerGlow() { return this.innerGlow; } public int outerGlow() { return this.outerGlow; } public float highlight() { return this.highlight; } public boolean mouseReactive() { return this.mouseReactive; } public int topRightRadius() { return this.topRightRadius; } public int bottomRightRadius() { return this.bottomRightRadius; } public int bottomLeftRadius() { return this.bottomLeftRadius; } public int tintBottom() { return this.tintBottom; } public float chromaticAberration() { return this.chromaticAberration; } public float iridescence() { return this.iridescence; } public float roughness() { return this.roughness; } public float lightAngle() { return this.lightAngle; } public float blurSpread() { return this.blurSpread; } public float edgeWidth() { return this.edgeWidth; } public float tintAngle() { return this.tintAngle; } public int edgeLight() { return this.edgeLight; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public GlassStyle(int tint, float opacity, float blur, float refraction, float saturation, float contrast, float noise, int borderColor, int radius, int shadowColor, int shadowSize, int innerGlow, int outerGlow, float highlight, boolean mouseReactive) {
/*  37 */     this(tint, opacity, blur, refraction, saturation, contrast, noise, borderColor, radius, shadowColor, shadowSize, innerGlow, outerGlow, highlight, mouseReactive, radius, radius, radius, tint, 0.0F, 0.0F, 0.22F, 240.0F, 0.0F, 0.0F, 90.0F, -1);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public GlassStyle(int tint, float opacity, float blur, float refraction, float saturation, float contrast, float noise, int borderColor, int radius, int shadowColor, int shadowSize, int innerGlow, int outerGlow, float highlight, boolean mouseReactive, int topRightRadius, int bottomRightRadius, int bottomLeftRadius, int tintBottom, float chromaticAberration, float iridescence, float roughness, float lightAngle) {
/*  47 */     this(tint, opacity, blur, refraction, saturation, contrast, noise, borderColor, radius, shadowColor, shadowSize, innerGlow, outerGlow, highlight, mouseReactive, topRightRadius, bottomRightRadius, bottomLeftRadius, tintBottom, chromaticAberration, iridescence, roughness, lightAngle, 0.0F, 0.0F, 90.0F, -1);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public GlassStyle(int tint, float opacity, float blur, float refraction, float saturation, float contrast, float noise, int borderColor, int radius, int shadowColor, int shadowSize, int innerGlow, int outerGlow, float highlight, boolean mouseReactive, int topRightRadius, int bottomRightRadius, int bottomLeftRadius, int tintBottom, float chromaticAberration, float iridescence, float roughness, float lightAngle, float blurSpread, float edgeWidth, float tintAngle, int edgeLight)
/*     */   {
/*  54 */     opacity = unit(opacity, "opacity");
/*  55 */     blur = unit(blur, "blur");
/*  56 */     refraction = unit(refraction, "refraction");
/*  57 */     saturation = GlassMath.clamp(GlassMath.finite(saturation, "saturation"), 0.0F, 4.0F);
/*  58 */     contrast = GlassMath.clamp(GlassMath.finite(contrast, "contrast"), 0.0F, 4.0F);
/*  59 */     noise = unit(noise, "noise");
/*  60 */     radius = clampRadius(radius);
/*  61 */     topRightRadius = clampRadius(topRightRadius);
/*  62 */     bottomRightRadius = clampRadius(bottomRightRadius);
/*  63 */     bottomLeftRadius = clampRadius(bottomLeftRadius);
/*  64 */     shadowSize = Math.max(0, Math.min(48, shadowSize));
/*  65 */     highlight = unit(highlight, "highlight");
/*  66 */     chromaticAberration = unit(chromaticAberration, "chromaticAberration");
/*  67 */     iridescence = unit(iridescence, "iridescence");
/*  68 */     roughness = unit(roughness, "roughness");
/*  69 */     lightAngle = GlassMath.finite(lightAngle, "lightAngle") % 360.0F;
/*  70 */     if (lightAngle < 0.0F)
/*  71 */       lightAngle += 360.0F; 
/*  72 */     blurSpread = unit(blurSpread, "blurSpread");
/*  73 */     edgeWidth = GlassMath.clamp(GlassMath.finite(edgeWidth, "edgeWidth"), 0.0F, 24.0F);
/*  74 */     tintAngle = GlassMath.finite(tintAngle, "tintAngle") % 360.0F;
/*  75 */     if (tintAngle < 0.0F)
/*  76 */       tintAngle += 360.0F;  this.tint = tint; this.opacity = opacity; this.blur = blur; this.refraction = refraction; this.saturation = saturation; this.contrast = contrast; this.noise = noise; this.borderColor = borderColor; this.radius = radius; this.shadowColor = shadowColor; this.shadowSize = shadowSize; this.innerGlow = innerGlow; this.outerGlow = outerGlow; this.highlight = highlight; this.mouseReactive = mouseReactive; this.topRightRadius = topRightRadius; this.bottomRightRadius = bottomRightRadius; this.bottomLeftRadius = bottomLeftRadius; this.tintBottom = tintBottom; this.chromaticAberration = chromaticAberration; this.iridescence = iridescence; this.roughness = roughness; this.lightAngle = lightAngle;
/*     */     this.blurSpread = blurSpread;
/*     */     this.edgeWidth = edgeWidth;
/*     */     this.tintAngle = tintAngle;
/*  80 */     this.edgeLight = edgeLight; } public GlassStyle opacity(float value) { return copy(this.tint, this.tintBottom, value, this.blur, this.refraction, this.saturation, this.contrast, this.noise, this.borderColor, this.radius, this.topRightRadius, this.bottomRightRadius, this.bottomLeftRadius, this.shadowColor, this.shadowSize, this.innerGlow, this.outerGlow, this.highlight, this.mouseReactive, this.chromaticAberration, this.iridescence, this.roughness, this.lightAngle, this.blurSpread, this.edgeWidth, this.tintAngle, this.edgeLight); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public GlassStyle radius(int value) {
/*  87 */     int r = clampRadius(value);
/*  88 */     return cornerRadii(r, r, r, r);
/*     */   }
/*     */   
/*     */   public GlassStyle cornerRadii(int topLeft, int topRight, int bottomRight, int bottomLeft) {
/*  92 */     return copy(this.tint, this.tintBottom, this.opacity, this.blur, this.refraction, this.saturation, this.contrast, this.noise, this.borderColor, topLeft, topRight, bottomRight, bottomLeft, this.shadowColor, this.shadowSize, this.innerGlow, this.outerGlow, this.highlight, this.mouseReactive, this.chromaticAberration, this.iridescence, this.roughness, this.lightAngle, this.blurSpread, this.edgeWidth, this.tintAngle, this.edgeLight);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int topLeftRadius() {
/*  99 */     return this.radius;
/*     */   }
/*     */   
/*     */   public GlassStyle blur(float value) {
/* 103 */     return copy(this.tint, this.tintBottom, this.opacity, value, this.refraction, this.saturation, this.contrast, this.noise, this.borderColor, this.radius, this.topRightRadius, this.bottomRightRadius, this.bottomLeftRadius, this.shadowColor, this.shadowSize, this.innerGlow, this.outerGlow, this.highlight, this.mouseReactive, this.chromaticAberration, this.iridescence, this.roughness, this.lightAngle, this.blurSpread, this.edgeWidth, this.tintAngle, this.edgeLight);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public GlassStyle blurBlend(float value) {
/* 110 */     return blur(value);
/*     */   }
/*     */   
/*     */   public GlassStyle refraction(float value) {
/* 114 */     return copy(this.tint, this.tintBottom, this.opacity, this.blur, value, this.saturation, this.contrast, this.noise, this.borderColor, this.radius, this.topRightRadius, this.bottomRightRadius, this.bottomLeftRadius, this.shadowColor, this.shadowSize, this.innerGlow, this.outerGlow, this.highlight, this.mouseReactive, this.chromaticAberration, this.iridescence, this.roughness, this.lightAngle, this.blurSpread, this.edgeWidth, this.tintAngle, this.edgeLight);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public GlassStyle tint(int value) {
/* 121 */     return tintGradient(value, value);
/*     */   }
/*     */   
/*     */   public GlassStyle tintGradient(int top, int bottom) {
/* 125 */     return copy(top, bottom, this.opacity, this.blur, this.refraction, this.saturation, this.contrast, this.noise, this.borderColor, this.radius, this.topRightRadius, this.bottomRightRadius, this.bottomLeftRadius, this.shadowColor, this.shadowSize, this.innerGlow, this.outerGlow, this.highlight, this.mouseReactive, this.chromaticAberration, this.iridescence, this.roughness, this.lightAngle, this.blurSpread, this.edgeWidth, this.tintAngle, this.edgeLight);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public GlassStyle highlight(float value) {
/* 132 */     return copy(this.tint, this.tintBottom, this.opacity, this.blur, this.refraction, this.saturation, this.contrast, this.noise, this.borderColor, this.radius, this.topRightRadius, this.bottomRightRadius, this.bottomLeftRadius, this.shadowColor, this.shadowSize, this.innerGlow, this.outerGlow, value, this.mouseReactive, this.chromaticAberration, this.iridescence, this.roughness, this.lightAngle, this.blurSpread, this.edgeWidth, this.tintAngle, this.edgeLight);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public GlassStyle saturation(float value) {
/* 139 */     return copy(this.tint, this.tintBottom, this.opacity, this.blur, this.refraction, value, this.contrast, this.noise, this.borderColor, this.radius, this.topRightRadius, this.bottomRightRadius, this.bottomLeftRadius, this.shadowColor, this.shadowSize, this.innerGlow, this.outerGlow, this.highlight, this.mouseReactive, this.chromaticAberration, this.iridescence, this.roughness, this.lightAngle, this.blurSpread, this.edgeWidth, this.tintAngle, this.edgeLight);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public GlassStyle contrast(float value) {
/* 146 */     return copy(this.tint, this.tintBottom, this.opacity, this.blur, this.refraction, this.saturation, value, this.noise, this.borderColor, this.radius, this.topRightRadius, this.bottomRightRadius, this.bottomLeftRadius, this.shadowColor, this.shadowSize, this.innerGlow, this.outerGlow, this.highlight, this.mouseReactive, this.chromaticAberration, this.iridescence, this.roughness, this.lightAngle, this.blurSpread, this.edgeWidth, this.tintAngle, this.edgeLight);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public GlassStyle noise(float value) {
/* 153 */     return copy(this.tint, this.tintBottom, this.opacity, this.blur, this.refraction, this.saturation, this.contrast, value, this.borderColor, this.radius, this.topRightRadius, this.bottomRightRadius, this.bottomLeftRadius, this.shadowColor, this.shadowSize, this.innerGlow, this.outerGlow, this.highlight, this.mouseReactive, this.chromaticAberration, this.iridescence, this.roughness, this.lightAngle, this.blurSpread, this.edgeWidth, this.tintAngle, this.edgeLight);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public GlassStyle borderColor(int value) {
/* 160 */     return copy(this.tint, this.tintBottom, this.opacity, this.blur, this.refraction, this.saturation, this.contrast, this.noise, value, this.radius, this.topRightRadius, this.bottomRightRadius, this.bottomLeftRadius, this.shadowColor, this.shadowSize, this.innerGlow, this.outerGlow, this.highlight, this.mouseReactive, this.chromaticAberration, this.iridescence, this.roughness, this.lightAngle, this.blurSpread, this.edgeWidth, this.tintAngle, this.edgeLight);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public GlassStyle shadow(int color, int size) {
/* 167 */     return copy(this.tint, this.tintBottom, this.opacity, this.blur, this.refraction, this.saturation, this.contrast, this.noise, this.borderColor, this.radius, this.topRightRadius, this.bottomRightRadius, this.bottomLeftRadius, color, size, this.innerGlow, this.outerGlow, this.highlight, this.mouseReactive, this.chromaticAberration, this.iridescence, this.roughness, this.lightAngle, this.blurSpread, this.edgeWidth, this.tintAngle, this.edgeLight);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public GlassStyle innerGlow(int color) {
/* 174 */     return copy(this.tint, this.tintBottom, this.opacity, this.blur, this.refraction, this.saturation, this.contrast, this.noise, this.borderColor, this.radius, this.topRightRadius, this.bottomRightRadius, this.bottomLeftRadius, this.shadowColor, this.shadowSize, color, this.outerGlow, this.highlight, this.mouseReactive, this.chromaticAberration, this.iridescence, this.roughness, this.lightAngle, this.blurSpread, this.edgeWidth, this.tintAngle, this.edgeLight);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public GlassStyle outerGlow(int color) {
/* 181 */     return copy(this.tint, this.tintBottom, this.opacity, this.blur, this.refraction, this.saturation, this.contrast, this.noise, this.borderColor, this.radius, this.topRightRadius, this.bottomRightRadius, this.bottomLeftRadius, this.shadowColor, this.shadowSize, this.innerGlow, color, this.highlight, this.mouseReactive, this.chromaticAberration, this.iridescence, this.roughness, this.lightAngle, this.blurSpread, this.edgeWidth, this.tintAngle, this.edgeLight);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public GlassStyle mouseReactive(boolean value) {
/* 188 */     return copy(this.tint, this.tintBottom, this.opacity, this.blur, this.refraction, this.saturation, this.contrast, this.noise, this.borderColor, this.radius, this.topRightRadius, this.bottomRightRadius, this.bottomLeftRadius, this.shadowColor, this.shadowSize, this.innerGlow, this.outerGlow, this.highlight, value, this.chromaticAberration, this.iridescence, this.roughness, this.lightAngle, this.blurSpread, this.edgeWidth, this.tintAngle, this.edgeLight);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public GlassStyle chromaticAberration(float value) {
/* 195 */     return copy(this.tint, this.tintBottom, this.opacity, this.blur, this.refraction, this.saturation, this.contrast, this.noise, this.borderColor, this.radius, this.topRightRadius, this.bottomRightRadius, this.bottomLeftRadius, this.shadowColor, this.shadowSize, this.innerGlow, this.outerGlow, this.highlight, this.mouseReactive, value, this.iridescence, this.roughness, this.lightAngle, this.blurSpread, this.edgeWidth, this.tintAngle, this.edgeLight);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public GlassStyle iridescence(float value) {
/* 202 */     return copy(this.tint, this.tintBottom, this.opacity, this.blur, this.refraction, this.saturation, this.contrast, this.noise, this.borderColor, this.radius, this.topRightRadius, this.bottomRightRadius, this.bottomLeftRadius, this.shadowColor, this.shadowSize, this.innerGlow, this.outerGlow, this.highlight, this.mouseReactive, this.chromaticAberration, value, this.roughness, this.lightAngle, this.blurSpread, this.edgeWidth, this.tintAngle, this.edgeLight);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public GlassStyle roughness(float value) {
/* 209 */     return copy(this.tint, this.tintBottom, this.opacity, this.blur, this.refraction, this.saturation, this.contrast, this.noise, this.borderColor, this.radius, this.topRightRadius, this.bottomRightRadius, this.bottomLeftRadius, this.shadowColor, this.shadowSize, this.innerGlow, this.outerGlow, this.highlight, this.mouseReactive, this.chromaticAberration, this.iridescence, value, this.lightAngle, this.blurSpread, this.edgeWidth, this.tintAngle, this.edgeLight);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public GlassStyle lightAngle(float degrees) {
/* 216 */     return copy(this.tint, this.tintBottom, this.opacity, this.blur, this.refraction, this.saturation, this.contrast, this.noise, this.borderColor, this.radius, this.topRightRadius, this.bottomRightRadius, this.bottomLeftRadius, this.shadowColor, this.shadowSize, this.innerGlow, this.outerGlow, this.highlight, this.mouseReactive, this.chromaticAberration, this.iridescence, this.roughness, degrees, this.blurSpread, this.edgeWidth, this.tintAngle, this.edgeLight);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public GlassStyle blurSpread(float value) {
/* 223 */     return copy(this.tint, this.tintBottom, this.opacity, this.blur, this.refraction, this.saturation, this.contrast, this.noise, this.borderColor, this.radius, this.topRightRadius, this.bottomRightRadius, this.bottomLeftRadius, this.shadowColor, this.shadowSize, this.innerGlow, this.outerGlow, this.highlight, this.mouseReactive, this.chromaticAberration, this.iridescence, this.roughness, this.lightAngle, value, this.edgeWidth, this.tintAngle, this.edgeLight);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public GlassStyle edgeWidth(float value) {
/* 230 */     return copy(this.tint, this.tintBottom, this.opacity, this.blur, this.refraction, this.saturation, this.contrast, this.noise, this.borderColor, this.radius, this.topRightRadius, this.bottomRightRadius, this.bottomLeftRadius, this.shadowColor, this.shadowSize, this.innerGlow, this.outerGlow, this.highlight, this.mouseReactive, this.chromaticAberration, this.iridescence, this.roughness, this.lightAngle, this.blurSpread, value, this.tintAngle, this.edgeLight);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public GlassStyle tintAngle(float degrees) {
/* 237 */     return copy(this.tint, this.tintBottom, this.opacity, this.blur, this.refraction, this.saturation, this.contrast, this.noise, this.borderColor, this.radius, this.topRightRadius, this.bottomRightRadius, this.bottomLeftRadius, this.shadowColor, this.shadowSize, this.innerGlow, this.outerGlow, this.highlight, this.mouseReactive, this.chromaticAberration, this.iridescence, this.roughness, this.lightAngle, this.blurSpread, this.edgeWidth, degrees, this.edgeLight);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public GlassStyle edgeLight(int color) {
/* 244 */     return copy(this.tint, this.tintBottom, this.opacity, this.blur, this.refraction, this.saturation, this.contrast, this.noise, this.borderColor, this.radius, this.topRightRadius, this.bottomRightRadius, this.bottomLeftRadius, this.shadowColor, this.shadowSize, this.innerGlow, this.outerGlow, this.highlight, this.mouseReactive, this.chromaticAberration, this.iridescence, this.roughness, this.lightAngle, this.blurSpread, this.edgeWidth, this.tintAngle, color);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private GlassStyle copy(int tint, int tintBottom, float opacity, float blur, float refraction, float saturation, float contrast, float noise, int borderColor, int radius, int topRightRadius, int bottomRightRadius, int bottomLeftRadius, int shadowColor, int shadowSize, int innerGlow, int outerGlow, float highlight, boolean mouseReactive, float chromaticAberration, float iridescence, float roughness, float lightAngle, float blurSpread, float edgeWidth, float tintAngle, int edgeLight) {
/* 257 */     return new GlassStyle(tint, opacity, blur, refraction, saturation, contrast, noise, borderColor, radius, shadowColor, shadowSize, innerGlow, outerGlow, highlight, mouseReactive, topRightRadius, bottomRightRadius, bottomLeftRadius, tintBottom, chromaticAberration, iridescence, roughness, lightAngle, blurSpread, edgeWidth, tintAngle, edgeLight);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static int clampRadius(int value) {
/* 265 */     return Math.max(0, Math.min(128, value));
/*     */   }
/*     */   
/*     */   private static float unit(float value, String name) {
/* 269 */     return GlassMath.clamp(GlassMath.finite(value, name), 0.0F, 1.0F);
/*     */   } }


/* Location:              C:\Users\rapha\Downloads\aurora.jar!\META-INF\jars\lqglass-0.2.5.jar!\dev\devswag\lqglass\style\GlassStyle.class
 * Java compiler version: 21 (65.0)
 * JD-Core Version:       1.1.3
 */