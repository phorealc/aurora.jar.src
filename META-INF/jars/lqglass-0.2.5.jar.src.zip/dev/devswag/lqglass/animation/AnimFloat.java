/*    */ package dev.devswag.lqglass.animation;
/*    */ 
/*    */ 
/*    */ public final class AnimFloat
/*    */ {
/*    */   private float from;
/*    */   private float value;
/*    */   private float target;
/*    */   private long start;
/*    */   private int duration;
/* 11 */   private Easing easing = Easing.OUT_CUBIC;
/*    */   
/*    */   public AnimFloat(float value) {
/* 14 */     this.from = value;
/* 15 */     this.value = value;
/* 16 */     this.target = value;
/*    */   }
/*    */   
/*    */   public float value() {
/* 20 */     return this.value;
/*    */   }
/*    */   
/*    */   public float target() {
/* 24 */     return this.target;
/*    */   }
/*    */   
/*    */   public void snap(float value) {
/* 28 */     this.from = value;
/* 29 */     this.value = value;
/* 30 */     this.target = value;
/* 31 */     this.duration = 0;
/*    */   }
/*    */   
/*    */   public void animate(float target, int durationMs, Easing easing, long now) {
/* 35 */     update(now);
/* 36 */     this.from = this.value;
/* 37 */     this.target = target;
/* 38 */     this.duration = Math.max(0, durationMs);
/* 39 */     this.easing = (easing == null) ? Easing.LINEAR : easing;
/* 40 */     this.start = now;
/* 41 */     if (this.duration == 0)
/* 42 */       this.value = target; 
/*    */   }
/*    */   
/*    */   public float update(long now) {
/* 46 */     if (this.value == this.target || this.duration <= 0) {
/* 47 */       return this.value;
/*    */     }
/* 49 */     float t = Math.max(0.0F, Math.min(1.0F, (float)(now - this.start) / this.duration));
/* 50 */     this.value = this.from + (this.target - this.from) * this.easing.apply(t);
/* 51 */     if (t >= 1.0F)
/* 52 */       this.value = this.target; 
/* 53 */     return this.value;
/*    */   }
/*    */ }


/* Location:              C:\Users\rapha\Downloads\aurora.jar!\META-INF\jars\lqglass-0.2.5.jar!\dev\devswag\lqglass\animation\AnimFloat.class
 * Java compiler version: 21 (65.0)
 * JD-Core Version:       1.1.3
 */