/*    */ package dev.devswag.lqglass.animation;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public final class UiMotion
/*    */ {
/*    */   private static volatile boolean reducedMotion;
/*    */   
/*    */   public static boolean reducedMotion() {
/* 11 */     return reducedMotion;
/*    */   }
/*    */   
/*    */   public static void reducedMotion(boolean reduced) {
/* 15 */     reducedMotion = reduced;
/*    */   }
/*    */   
/*    */   public static int duration(int milliseconds) {
/* 19 */     return reducedMotion ? 0 : Math.max(0, milliseconds);
/*    */   }
/*    */ }


/* Location:              C:\Users\rapha\Downloads\aurora.jar!\META-INF\jars\lqglass-0.2.5.jar!\dev\devswag\lqglass\animation\UiMotion.class
 * Java compiler version: 21 (65.0)
 * JD-Core Version:       1.1.3
 */