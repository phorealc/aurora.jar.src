/*     */ package dev.devswag.lqglass.ui;
/*     */ 
/*     */ import dev.devswag.lqglass.render.GlassRenderer;
/*     */ import dev.devswag.lqglass.style.LiquidGlassTheme;
/*     */ import dev.devswag.lqglass.ui.components.GlassDialog;
/*     */ import dev.devswag.lqglass.ui.components.LayerStack;
/*     */ import dev.devswag.lqglass.ui.components.ToastStack;
/*     */ import java.util.Objects;
/*     */ import java.util.function.Consumer;
/*     */ import net.minecraft.class_11905;
/*     */ import net.minecraft.class_11908;
/*     */ import net.minecraft.class_11909;
/*     */ import net.minecraft.class_156;
/*     */ import net.minecraft.class_2561;
/*     */ import net.minecraft.class_332;
/*     */ import net.minecraft.class_437;
/*     */ 
/*     */ public class GlassScreen
/*     */   extends class_437 {
/*     */   private final UiComponent root;
/*     */   private final LiquidGlassTheme theme;
/*  22 */   private final GlassRenderer renderer = new GlassRenderer();
/*     */   private final InputRouter input;
/*  24 */   private final ToastStack toasts = new ToastStack();
/*     */   
/*  26 */   private int laidOutWidth = -1;
/*  27 */   private int laidOutHeight = -1;
/*     */   private boolean debug;
/*     */   
/*     */   public GlassScreen(class_2561 title, UiComponent root, LiquidGlassTheme theme) {
/*  31 */     super(title);
/*  32 */     if (root == null)
/*  33 */       throw new IllegalArgumentException("root"); 
/*  34 */     this.root = root;
/*  35 */     this.theme = (theme == null) ? LiquidGlassTheme.dark() : theme;
/*  36 */     this.input = new InputRouter(root);
/*     */   }
/*     */   
/*     */   public UiComponent root() {
/*  40 */     return this.root;
/*     */   }
/*     */   
/*     */   public GlassRenderer renderer() {
/*  44 */     return this.renderer;
/*     */   }
/*     */   
/*     */   public InputRouter input() {
/*  48 */     return this.input;
/*     */   }
/*     */   
/*     */   public GlassScreen onNarration(Consumer<class_2561> narrationSink) {
/*  52 */     this.input.onNarration(narrationSink);
/*  53 */     return this;
/*     */   }
/*     */   
/*     */   public ToastStack toasts() {
/*  57 */     return this.toasts;
/*     */   }
/*     */   
/*     */   public GlassDialog showDialog(GlassDialog dialog) {
/*  61 */     LayerStack stack = findLayerStack(this.root);
/*  62 */     if (stack == null)
/*  63 */       throw new IllegalStateException("Screen tree has no LayerStack"); 
/*  64 */     return stack.showDialog(dialog);
/*     */   }
/*     */   
/*     */   public GlassScreen debug(boolean debug) {
/*  68 */     this.debug = debug;
/*  69 */     return this;
/*     */   }
/*     */   
/*     */   public boolean debug() {
/*  73 */     return this.debug;
/*     */   }
/*     */ 
/*     */   
/*     */   protected void method_25426() {
/*  78 */     this.root.mount();
/*  79 */     this.toasts.mount();
/*  80 */     this.root.invalidateLayout();
/*     */   }
/*     */ 
/*     */   
/*     */   public void method_25432() {
/*  85 */     this.input.clear();
/*  86 */     this.toasts.unmount();
/*  87 */     this.root.unmount();
/*     */   }
/*     */ 
/*     */   
/*     */   public void method_25393() {
/*  92 */     this.root.tick();
/*  93 */     this.toasts.tick();
/*     */   }
/*     */ 
/*     */   
/*     */   public void method_25420(class_332 graphics, int mouseX, int mouseY, float delta) {
/*  98 */     this.renderer.beginFrame(true, mouseX, mouseY);
/*  99 */     if (this.theme.backgroundDim() >>> 24 != 0) {
/* 100 */       graphics.method_25294(0, 0, this.field_22789, this.field_22790, this.theme.backgroundDim());
/*     */     }
/*     */   }
/*     */   
/*     */   public void method_25394(class_332 graphics, int mouseX, int mouseY, float delta) {
/* 105 */     if (this.laidOutWidth != this.field_22789 || this.laidOutHeight != this.field_22790 || this.root.layoutDirty()) {
/* 106 */       this.root.layout(new UiBounds(0, 0, this.field_22789, this.field_22790));
/* 107 */       this.laidOutWidth = this.field_22789;
/* 108 */       this.laidOutHeight = this.field_22790;
/*     */     } 
/*     */     
/* 111 */     UiContext context = new UiContext(graphics, this.renderer, this.theme, mouseX, mouseY, delta, class_156.method_658());
/* 112 */     this.root.render(context);
/* 113 */     this.toasts.layout(new UiBounds(0, 0, this.field_22789, this.field_22790));
/* 114 */     this.toasts.render(context);
/*     */     
/* 116 */     if (this.debug) {
/* 117 */       graphics.method_71048();
/* 118 */       DebugOverlay.render(graphics, this.root, this.input, this.renderer);
/*     */     } 
/*     */     
/* 121 */     renderTooltip(graphics, mouseX, mouseY);
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean method_25402(class_11909 event, boolean doubled) {
/* 126 */     return (this.input.mouseDown(event.comp_4798(), event.comp_4799(), event.method_74245(), event.comp_4797(), doubled) || super
/* 127 */       .method_25402(event, doubled));
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean method_25406(class_11909 event) {
/* 132 */     return (this.input.mouseUp(event.comp_4798(), event.comp_4799(), event.method_74245(), event.comp_4797()) || super
/* 133 */       .method_25406(event));
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean method_25403(class_11909 event, double dx, double dy) {
/* 138 */     return (this.input.mouseDrag(event.comp_4798(), event.comp_4799(), event.method_74245(), dx, dy) || super
/* 139 */       .method_25403(event, dx, dy));
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean method_25401(double mouseX, double mouseY, double horizontal, double vertical) {
/* 144 */     return (this.input.scroll(mouseX, mouseY, horizontal, vertical) || super
/* 145 */       .method_25401(mouseX, mouseY, horizontal, vertical));
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean method_25404(class_11908 event) {
/* 150 */     return (this.input.keyPressed(event) || super.method_25404(event));
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean method_16803(class_11908 event) {
/* 155 */     return (this.input.keyReleased(event) || super.method_16803(event));
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean method_25400(class_11905 event) {
/* 160 */     return (this.input.charTyped(event) || super.method_25400(event));
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean method_25421() {
/* 165 */     return false;
/*     */   }
/*     */   
/*     */   private LayerStack findLayerStack(UiComponent component) {
/* 169 */     if (component instanceof LayerStack) { LayerStack stack = (LayerStack)component;
/* 170 */       return stack; }
/* 171 */      for (UiComponent child : component.children()) {
/* 172 */       LayerStack stack = findLayerStack(child);
/* 173 */       if (stack != null)
/* 174 */         return stack; 
/*     */     } 
/* 176 */     return null;
/*     */   }
/*     */   
/*     */   private void renderTooltip(class_332 graphics, int mouseX, int mouseY) {
/* 180 */     UiComponent hit = this.root.findTop(mouseX, mouseY);
/* 181 */     if (hit == null || hit.tooltip() == null || hit.tooltip().isBlank()) {
/*     */       return;
/*     */     }
/* 184 */     String text = hit.tooltip();
/* 185 */     int w = this.field_22793.method_1727(text) + 16;
/* 186 */     Objects.requireNonNull(this.field_22793); int h = 9 + 12;
/* 187 */     int x = Math.min(this.field_22789 - w - 4, mouseX + 10);
/* 188 */     int y = Math.min(this.field_22790 - h - 4, mouseY + 10);
/*     */     
/* 190 */     graphics.method_71048();
/* 191 */     UiBounds b = new UiBounds(Math.max(4, x), Math.max(4, y), w, h);
/* 192 */     this.renderer.surface(graphics, b, this.theme.tooltip().glass());
/* 193 */     graphics.method_51433(this.field_22793, text, b.x() + 8, b.y() + 6, this.theme.tooltip().text(), false);
/*     */   }
/*     */ }


/* Location:              C:\Users\rapha\Downloads\aurora.jar!\META-INF\jars\lqglass-0.2.5.jar!\dev\devswag\lqglas\\ui\GlassScreen.class
 * Java compiler version: 21 (65.0)
 * JD-Core Version:       1.1.3
 */