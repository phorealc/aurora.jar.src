/*     */ package dev.devswag.lqglass.ui;
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class LayoutSpec
/*     */ {
/*     */   private final Runnable dirty;
/*   8 */   private Length width = Length.AUTO;
/*   9 */   private Length height = Length.AUTO;
/*  10 */   private Insets margin = Insets.ZERO;
/*  11 */   private Insets padding = Insets.ZERO;
/*     */   private int minWidth;
/*     */   private int minHeight;
/*  14 */   private int maxWidth = Integer.MAX_VALUE;
/*  15 */   private int maxHeight = Integer.MAX_VALUE;
/*     */   private float grow;
/*  17 */   private float shrink = 1.0F;
/*     */   private int x;
/*     */   private int y;
/*     */   
/*     */   public LayoutSpec() {
/*  22 */     this(() -> {
/*     */         
/*     */         });
/*     */   }
/*     */   LayoutSpec(Runnable dirty) {
/*  27 */     this.dirty = dirty;
/*     */   }
/*     */   
/*     */   public Length width() {
/*  31 */     return this.width;
/*     */   }
/*     */   
/*     */   public LayoutSpec width(Length width) {
/*  35 */     this.width = (width == null) ? Length.AUTO : width;
/*  36 */     this.dirty.run();
/*  37 */     return this;
/*     */   }
/*     */   
/*     */   public Length height() {
/*  41 */     return this.height;
/*     */   }
/*     */   
/*     */   public LayoutSpec height(Length height) {
/*  45 */     this.height = (height == null) ? Length.AUTO : height;
/*  46 */     this.dirty.run();
/*  47 */     return this;
/*     */   }
/*     */   
/*     */   public LayoutSpec size(int width, int height) {
/*  51 */     this.width = Length.px(width);
/*  52 */     this.height = Length.px(height);
/*  53 */     this.dirty.run();
/*  54 */     return this;
/*     */   }
/*     */   
/*     */   public Insets margin() {
/*  58 */     return this.margin;
/*     */   }
/*     */   
/*     */   public LayoutSpec margin(Insets margin) {
/*  62 */     this.margin = (margin == null) ? Insets.ZERO : margin;
/*  63 */     this.dirty.run();
/*  64 */     return this;
/*     */   }
/*     */   
/*     */   public Insets padding() {
/*  68 */     return this.padding;
/*     */   }
/*     */   
/*     */   public LayoutSpec padding(Insets padding) {
/*  72 */     this.padding = (padding == null) ? Insets.ZERO : padding;
/*  73 */     this.dirty.run();
/*  74 */     return this;
/*     */   }
/*     */   
/*     */   public int minWidth() {
/*  78 */     return this.minWidth;
/*     */   }
/*     */   
/*     */   public int minHeight() {
/*  82 */     return this.minHeight;
/*     */   }
/*     */   
/*     */   public LayoutSpec minSize(int width, int height) {
/*  86 */     this.minWidth = Math.max(0, width);
/*  87 */     this.minHeight = Math.max(0, height);
/*  88 */     this.dirty.run();
/*  89 */     return this;
/*     */   }
/*     */   
/*     */   public int maxWidth() {
/*  93 */     return this.maxWidth;
/*     */   }
/*     */   
/*     */   public int maxHeight() {
/*  97 */     return this.maxHeight;
/*     */   }
/*     */   
/*     */   public LayoutSpec maxSize(int width, int height) {
/* 101 */     this.maxWidth = Math.max(0, width);
/* 102 */     this.maxHeight = Math.max(0, height);
/* 103 */     this.dirty.run();
/* 104 */     return this;
/*     */   }
/*     */   
/*     */   public float grow() {
/* 108 */     return this.grow;
/*     */   }
/*     */   
/*     */   public LayoutSpec grow(float grow) {
/* 112 */     this.grow = Math.max(0.0F, grow);
/* 113 */     this.dirty.run();
/* 114 */     return this;
/*     */   }
/*     */   
/*     */   public float shrink() {
/* 118 */     return this.shrink;
/*     */   }
/*     */   
/*     */   public LayoutSpec shrink(float shrink) {
/* 122 */     this.shrink = Math.max(0.0F, shrink);
/* 123 */     this.dirty.run();
/* 124 */     return this;
/*     */   }
/*     */   
/*     */   public int x() {
/* 128 */     return this.x;
/*     */   }
/*     */   
/*     */   public int y() {
/* 132 */     return this.y;
/*     */   }
/*     */   
/*     */   public LayoutSpec position(int x, int y) {
/* 136 */     this.x = x;
/* 137 */     this.y = y;
/* 138 */     this.dirty.run();
/* 139 */     return this;
/*     */   }
/*     */   
/*     */   public int clampWidth(int width) {
/* 143 */     return Math.max(this.minWidth, Math.min(this.maxWidth, width));
/*     */   }
/*     */   
/*     */   public int clampHeight(int height) {
/* 147 */     return Math.max(this.minHeight, Math.min(this.maxHeight, height));
/*     */   }
/*     */ }


/* Location:              C:\Users\rapha\Downloads\aurora.jar!\META-INF\jars\lqglass-0.2.5.jar!\dev\devswag\lqglas\\ui\LayoutSpec.class
 * Java compiler version: 21 (65.0)
 * JD-Core Version:       1.1.3
 */