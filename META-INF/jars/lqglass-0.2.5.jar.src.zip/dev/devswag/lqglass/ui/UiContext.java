/*    */ package dev.devswag.lqglass.ui;
/*    */ public final class UiContext extends Record { private final class_332 graphics;
/*    */   private final GlassRenderer glass;
/*    */   private final LiquidGlassTheme theme;
/*    */   private final int mouseX;
/*    */   private final int mouseY;
/*    */   private final float delta;
/*    */   private final long now;
/*    */   
/* 10 */   public UiContext(class_332 graphics, GlassRenderer glass, LiquidGlassTheme theme, int mouseX, int mouseY, float delta, long now) { this.graphics = graphics; this.glass = glass; this.theme = theme; this.mouseX = mouseX; this.mouseY = mouseY; this.delta = delta; this.now = now; } public final String toString() { // Byte code:
/*    */     //   0: aload_0
/*    */     //   1: <illegal opcode> toString : (Ldev/devswag/lqglass/ui/UiContext;)Ljava/lang/String;
/*    */     //   6: areturn
/*    */     // Line number table:
/*    */     //   Java source line number -> byte code offset
/*    */     //   #10	-> 0
/*    */     // Local variable table:
/*    */     //   start	length	slot	name	descriptor
/* 10 */     //   0	7	0	this	Ldev/devswag/lqglass/ui/UiContext; } public class_332 graphics() { return this.graphics; } public final int hashCode() { // Byte code:
/*    */     //   0: aload_0
/*    */     //   1: <illegal opcode> hashCode : (Ldev/devswag/lqglass/ui/UiContext;)I
/*    */     //   6: ireturn
/*    */     // Line number table:
/*    */     //   Java source line number -> byte code offset
/*    */     //   #10	-> 0
/*    */     // Local variable table:
/*    */     //   start	length	slot	name	descriptor
/*    */     //   0	7	0	this	Ldev/devswag/lqglass/ui/UiContext; } public final boolean equals(Object o) { // Byte code:
/*    */     //   0: aload_0
/*    */     //   1: aload_1
/*    */     //   2: <illegal opcode> equals : (Ldev/devswag/lqglass/ui/UiContext;Ljava/lang/Object;)Z
/*    */     //   7: ireturn
/*    */     // Line number table:
/*    */     //   Java source line number -> byte code offset
/*    */     //   #10	-> 0
/*    */     // Local variable table:
/*    */     //   start	length	slot	name	descriptor
/*    */     //   0	8	0	this	Ldev/devswag/lqglass/ui/UiContext;
/* 10 */     //   0	8	1	o	Ljava/lang/Object; } public GlassRenderer glass() { return this.glass; } public LiquidGlassTheme theme() { return this.theme; } public int mouseX() { return this.mouseX; } public int mouseY() { return this.mouseY; } public float delta() { return this.delta; } public long now() { return this.now; }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public class_327 font() {
/* 21 */     return (class_310.method_1551()).field_1772;
/*    */   } }


/* Location:              C:\Users\rapha\Downloads\aurora.jar!\META-INF\jars\lqglass-0.2.5.jar!\dev\devswag\lqglas\\ui\UiContext.class
 * Java compiler version: 21 (65.0)
 * JD-Core Version:       1.1.3
 */