/*    */ package dev.devswag.lqglass.ui;
/*    */ public final class UiBounds extends Record { private final int x; private final int y; private final int width;
/*    */   
/*  4 */   public int x() { return this.x; } private final int height; public final String toString() { // Byte code:
/*    */     //   0: aload_0
/*    */     //   1: <illegal opcode> toString : (Ldev/devswag/lqglass/ui/UiBounds;)Ljava/lang/String;
/*    */     //   6: areturn
/*    */     // Line number table:
/*    */     //   Java source line number -> byte code offset
/*    */     //   #4	-> 0
/*    */     // Local variable table:
/*    */     //   start	length	slot	name	descriptor
/*    */     //   0	7	0	this	Ldev/devswag/lqglass/ui/UiBounds; } public final int hashCode() { // Byte code:
/*    */     //   0: aload_0
/*    */     //   1: <illegal opcode> hashCode : (Ldev/devswag/lqglass/ui/UiBounds;)I
/*    */     //   6: ireturn
/*    */     // Line number table:
/*    */     //   Java source line number -> byte code offset
/*    */     //   #4	-> 0
/*    */     // Local variable table:
/*    */     //   start	length	slot	name	descriptor
/*    */     //   0	7	0	this	Ldev/devswag/lqglass/ui/UiBounds; } public final boolean equals(Object o) { // Byte code:
/*    */     //   0: aload_0
/*    */     //   1: aload_1
/*    */     //   2: <illegal opcode> equals : (Ldev/devswag/lqglass/ui/UiBounds;Ljava/lang/Object;)Z
/*    */     //   7: ireturn
/*    */     // Line number table:
/*    */     //   Java source line number -> byte code offset
/*    */     //   #4	-> 0
/*    */     // Local variable table:
/*    */     //   start	length	slot	name	descriptor
/*    */     //   0	8	0	this	Ldev/devswag/lqglass/ui/UiBounds;
/*  4 */     //   0	8	1	o	Ljava/lang/Object; } public int y() { return this.y; } public int width() { return this.width; } public int height() { return this.height; }
/*    */ 
/*    */   
/*  7 */   public UiBounds(int x, int y, int width, int height) { width = Math.max(0, width);
/*  8 */     height = Math.max(0, height);
/*    */     this.x = x;
/*    */     this.y = y;
/*    */     this.width = width;
/* 12 */     this.height = height; } public int right() { return this.x + this.width; }
/*    */ 
/*    */   
/*    */   public int bottom() {
/* 16 */     return this.y + this.height;
/*    */   }
/*    */   
/*    */   public boolean contains(double px, double py) {
/* 20 */     return (px >= this.x && py >= this.y && px < right() && py < bottom());
/*    */   }
/*    */   
/*    */   public UiBounds inset(Insets insets) {
/* 24 */     int nx = this.x + insets.left();
/* 25 */     int ny = this.y + insets.top();
/* 26 */     return new UiBounds(nx, ny, 
/* 27 */         Math.max(0, this.width - insets.horizontal()), 
/* 28 */         Math.max(0, this.height - insets.vertical()));
/*    */   }
/*    */   
/*    */   public UiBounds translate(int dx, int dy) {
/* 32 */     return new UiBounds(this.x + dx, this.y + dy, this.width, this.height);
/*    */   } }


/* Location:              C:\Users\rapha\Downloads\aurora.jar!\META-INF\jars\lqglass-0.2.5.jar!\dev\devswag\lqglas\\ui\UiBounds.class
 * Java compiler version: 21 (65.0)
 * JD-Core Version:       1.1.3
 */