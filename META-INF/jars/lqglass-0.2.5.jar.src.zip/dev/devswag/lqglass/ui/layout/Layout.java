package dev.devswag.lqglass.ui.layout;

import dev.devswag.lqglass.ui.UiBounds;
import dev.devswag.lqglass.ui.UiComponent;
import dev.devswag.lqglass.ui.UiSize;

public interface Layout {
  UiSize measure(UiComponent paramUiComponent, int paramInt1, int paramInt2);
  
  void layout(UiComponent paramUiComponent, UiBounds paramUiBounds);
}


/* Location:              C:\Users\rapha\Downloads\aurora.jar!\META-INF\jars\lqglass-0.2.5.jar!\dev\devswag\lqglas\\ui\layout\Layout.class
 * Java compiler version: 21 (65.0)
 * JD-Core Version:       1.1.3
 */