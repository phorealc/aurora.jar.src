/*     */ package dev.devswag.lqglass.ui.layout;
/*     */ 
/*     */ import dev.devswag.lqglass.ui.Insets;
/*     */ import dev.devswag.lqglass.ui.UiBounds;
/*     */ import dev.devswag.lqglass.ui.UiComponent;
/*     */ import dev.devswag.lqglass.ui.UiSize;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ final class Flow
/*     */   extends Record
/*     */   implements Layout
/*     */ {
/*     */   private final int gap;
/*     */   
/*     */   private Flow(int gap) {
/* 270 */     this.gap = gap; } public final String toString() { // Byte code:
/*     */     //   0: aload_0
/*     */     //   1: <illegal opcode> toString : (Ldev/devswag/lqglass/ui/layout/Layouts$Flow;)Ljava/lang/String;
/*     */     //   6: areturn
/*     */     // Line number table:
/*     */     //   Java source line number -> byte code offset
/*     */     //   #270	-> 0
/*     */     // Local variable table:
/*     */     //   start	length	slot	name	descriptor
/* 270 */     //   0	7	0	this	Ldev/devswag/lqglass/ui/layout/Layouts$Flow; } public int gap() { return this.gap; }
/*     */   public final int hashCode() { // Byte code:
/*     */     //   0: aload_0
/*     */     //   1: <illegal opcode> hashCode : (Ldev/devswag/lqglass/ui/layout/Layouts$Flow;)I
/*     */     //   6: ireturn
/*     */     // Line number table:
/*     */     //   Java source line number -> byte code offset
/*     */     //   #270	-> 0
/*     */     // Local variable table:
/*     */     //   start	length	slot	name	descriptor
/*     */     //   0	7	0	this	Ldev/devswag/lqglass/ui/layout/Layouts$Flow; } public final boolean equals(Object o) {
/*     */     // Byte code:
/*     */     //   0: aload_0
/*     */     //   1: aload_1
/*     */     //   2: <illegal opcode> equals : (Ldev/devswag/lqglass/ui/layout/Layouts$Flow;Ljava/lang/Object;)Z
/*     */     //   7: ireturn
/*     */     // Line number table:
/*     */     //   Java source line number -> byte code offset
/*     */     //   #270	-> 0
/*     */     // Local variable table:
/*     */     //   start	length	slot	name	descriptor
/*     */     //   0	8	0	this	Ldev/devswag/lqglass/ui/layout/Layouts$Flow;
/*     */     //   0	8	1	o	Ljava/lang/Object;
/*     */   } public UiSize measure(UiComponent parent, int maxWidth, int maxHeight) {
/* 274 */     int x = 0;
/* 275 */     int y = 0;
/* 276 */     int rowH = 0;
/* 277 */     int widest = 0;
/* 278 */     for (UiComponent c : parent.children()) {
/* 279 */       if (!c.visible())
/*     */         continue; 
/* 281 */       UiSize s = c.measure(maxWidth, maxHeight);
/* 282 */       if (x > 0 && x + s.width() > maxWidth) {
/* 283 */         y += rowH + this.gap;
/* 284 */         x = 0;
/* 285 */         rowH = 0;
/*     */       } 
/* 287 */       widest = Math.max(widest, x + s.width());
/* 288 */       x += s.width() + this.gap;
/* 289 */       rowH = Math.max(rowH, s.height());
/*     */     } 
/* 291 */     Insets p = parent.layoutSpec().padding();
/* 292 */     return new UiSize(widest + p.horizontal(), y + rowH + p.vertical());
/*     */   }
/*     */ 
/*     */   
/*     */   public void layout(UiComponent parent, UiBounds raw) {
/* 297 */     UiBounds content = raw.inset(parent.layoutSpec().padding());
/* 298 */     int x = content.x();
/* 299 */     int y = content.y();
/* 300 */     int rowH = 0;
/* 301 */     for (UiComponent c : parent.children()) {
/* 302 */       if (!c.visible())
/*     */         continue; 
/* 304 */       int w = Layouts.width(c, content.width());
/* 305 */       int h = Layouts.height(c, content.height());
/* 306 */       if (x > content.x() && x + w > content.right()) {
/* 307 */         x = content.x();
/* 308 */         y += rowH + this.gap;
/* 309 */         rowH = 0;
/*     */       } 
/* 311 */       c.layout(new UiBounds(x, y, w, h));
/* 312 */       x += w + this.gap;
/* 313 */       rowH = Math.max(rowH, h);
/*     */     } 
/*     */   }
/*     */ }


/* Location:              C:\Users\rapha\Downloads\aurora.jar!\META-INF\jars\lqglass-0.2.5.jar!\dev\devswag\lqglas\\ui\layout\Layouts$Flow.class
 * Java compiler version: 21 (65.0)
 * JD-Core Version:       1.1.3
 */