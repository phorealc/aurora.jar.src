/*     */ package dev.devswag.lqglass.ui.layout;
/*     */ 
/*     */ import dev.devswag.lqglass.ui.Insets;
/*     */ import dev.devswag.lqglass.ui.UiBounds;
/*     */ import dev.devswag.lqglass.ui.UiComponent;
/*     */ import dev.devswag.lqglass.ui.UiSize;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ final class Stack
/*     */   extends Record
/*     */   implements Layout
/*     */ {
/*     */   private final Layouts.Align horizontal;
/*     */   private final Layouts.Align vertical;
/*     */   
/*     */   public final String toString() {
/*     */     // Byte code:
/*     */     //   0: aload_0
/*     */     //   1: <illegal opcode> toString : (Ldev/devswag/lqglass/ui/layout/Layouts$Stack;)Ljava/lang/String;
/*     */     //   6: areturn
/*     */     // Line number table:
/*     */     //   Java source line number -> byte code offset
/*     */     //   #187	-> 0
/*     */     // Local variable table:
/*     */     //   start	length	slot	name	descriptor
/*     */     //   0	7	0	this	Ldev/devswag/lqglass/ui/layout/Layouts$Stack;
/*     */   }
/*     */   
/*     */   public final int hashCode() {
/*     */     // Byte code:
/*     */     //   0: aload_0
/*     */     //   1: <illegal opcode> hashCode : (Ldev/devswag/lqglass/ui/layout/Layouts$Stack;)I
/*     */     //   6: ireturn
/*     */     // Line number table:
/*     */     //   Java source line number -> byte code offset
/*     */     //   #187	-> 0
/*     */     // Local variable table:
/*     */     //   start	length	slot	name	descriptor
/*     */     //   0	7	0	this	Ldev/devswag/lqglass/ui/layout/Layouts$Stack;
/*     */   }
/*     */   
/*     */   public final boolean equals(Object o) {
/*     */     // Byte code:
/*     */     //   0: aload_0
/*     */     //   1: aload_1
/*     */     //   2: <illegal opcode> equals : (Ldev/devswag/lqglass/ui/layout/Layouts$Stack;Ljava/lang/Object;)Z
/*     */     //   7: ireturn
/*     */     // Line number table:
/*     */     //   Java source line number -> byte code offset
/*     */     //   #187	-> 0
/*     */     // Local variable table:
/*     */     //   start	length	slot	name	descriptor
/*     */     //   0	8	0	this	Ldev/devswag/lqglass/ui/layout/Layouts$Stack;
/*     */     //   0	8	1	o	Ljava/lang/Object;
/*     */   }
/*     */   
/*     */   private Stack(Layouts.Align horizontal, Layouts.Align vertical) {
/* 187 */     this.horizontal = horizontal; this.vertical = vertical; } public Layouts.Align horizontal() { return this.horizontal; } public Layouts.Align vertical() { return this.vertical; }
/*     */ 
/*     */   
/*     */   public UiSize measure(UiComponent parent, int maxWidth, int maxHeight) {
/* 191 */     int w = 0;
/* 192 */     int h = 0;
/* 193 */     for (UiComponent c : parent.children()) {
/* 194 */       if (!c.visible())
/*     */         continue; 
/* 196 */       UiSize s = c.measure(maxWidth, maxHeight);
/* 197 */       Insets m = c.layoutSpec().margin();
/* 198 */       w = Math.max(w, s.width() + m.horizontal());
/* 199 */       h = Math.max(h, s.height() + m.vertical());
/*     */     } 
/* 201 */     Insets p = parent.layoutSpec().padding();
/* 202 */     return new UiSize(w + p.horizontal(), h + p.vertical());
/*     */   }
/*     */ 
/*     */   
/*     */   public void layout(UiComponent parent, UiBounds raw) {
/* 207 */     UiBounds content = raw.inset(parent.layoutSpec().padding());
/* 208 */     for (UiComponent c : parent.children()) {
/* 209 */       if (!c.visible())
/*     */         continue; 
/* 211 */       Insets m = c.layoutSpec().margin();
/* 212 */       int availableW = Math.max(0, content.width() - m.horizontal());
/* 213 */       int availableH = Math.max(0, content.height() - m.vertical());
/* 214 */       int w = (this.horizontal == Layouts.Align.STRETCH) ? availableW : Layouts.width(c, availableW);
/* 215 */       int h = (this.vertical == Layouts.Align.STRETCH) ? availableH : Layouts.height(c, availableH);
/* 216 */       int x = aligned(content.x() + m.left(), availableW, w, this.horizontal);
/* 217 */       int y = aligned(content.y() + m.top(), availableH, h, this.vertical);
/* 218 */       c.layout(new UiBounds(x, y, w, h));
/*     */     } 
/*     */   }
/*     */   
/*     */   private int aligned(int start, int available, int size, Layouts.Align align) {
/* 223 */     switch (align.ordinal()) { case 1: case 2:  }  return 
/*     */ 
/*     */       
/* 226 */       start;
/*     */   }
/*     */ }


/* Location:              C:\Users\rapha\Downloads\aurora.jar!\META-INF\jars\lqglass-0.2.5.jar!\dev\devswag\lqglas\\ui\layout\Layouts$Stack.class
 * Java compiler version: 21 (65.0)
 * JD-Core Version:       1.1.3
 */