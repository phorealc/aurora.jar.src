/*     */ package dev.devswag.lqglass.ui.layout;
/*     */ 
/*     */ import dev.devswag.lqglass.ui.Insets;
/*     */ import dev.devswag.lqglass.ui.UiBounds;
/*     */ import dev.devswag.lqglass.ui.UiComponent;
/*     */ import dev.devswag.lqglass.ui.UiSize;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ final class Grid
/*     */   extends Record
/*     */   implements Layout
/*     */ {
/*     */   private final int columns;
/*     */   private final int gap;
/*     */   
/*     */   public final String toString() {
/*     */     // Byte code:
/*     */     //   0: aload_0
/*     */     //   1: <illegal opcode> toString : (Ldev/devswag/lqglass/ui/layout/Layouts$Grid;)Ljava/lang/String;
/*     */     //   6: areturn
/*     */     // Line number table:
/*     */     //   Java source line number -> byte code offset
/*     */     //   #231	-> 0
/*     */     // Local variable table:
/*     */     //   start	length	slot	name	descriptor
/*     */     //   0	7	0	this	Ldev/devswag/lqglass/ui/layout/Layouts$Grid;
/*     */   }
/*     */   
/*     */   public final int hashCode() {
/*     */     // Byte code:
/*     */     //   0: aload_0
/*     */     //   1: <illegal opcode> hashCode : (Ldev/devswag/lqglass/ui/layout/Layouts$Grid;)I
/*     */     //   6: ireturn
/*     */     // Line number table:
/*     */     //   Java source line number -> byte code offset
/*     */     //   #231	-> 0
/*     */     // Local variable table:
/*     */     //   start	length	slot	name	descriptor
/*     */     //   0	7	0	this	Ldev/devswag/lqglass/ui/layout/Layouts$Grid;
/*     */   }
/*     */   
/*     */   public final boolean equals(Object o) {
/*     */     // Byte code:
/*     */     //   0: aload_0
/*     */     //   1: aload_1
/*     */     //   2: <illegal opcode> equals : (Ldev/devswag/lqglass/ui/layout/Layouts$Grid;Ljava/lang/Object;)Z
/*     */     //   7: ireturn
/*     */     // Line number table:
/*     */     //   Java source line number -> byte code offset
/*     */     //   #231	-> 0
/*     */     // Local variable table:
/*     */     //   start	length	slot	name	descriptor
/*     */     //   0	8	0	this	Ldev/devswag/lqglass/ui/layout/Layouts$Grid;
/*     */     //   0	8	1	o	Ljava/lang/Object;
/*     */   }
/*     */   
/*     */   private Grid(int columns, int gap) {
/* 231 */     this.columns = columns; this.gap = gap; } public int columns() { return this.columns; } public int gap() { return this.gap; }
/*     */ 
/*     */   
/*     */   public UiSize measure(UiComponent parent, int maxWidth, int maxHeight) {
/* 235 */     int rows = Math.max(1, (parent.visibleChildCount() + this.columns - 1) / this.columns);
/* 236 */     int h = 0;
/* 237 */     for (UiComponent c : parent.children()) {
/* 238 */       if (c.visible())
/* 239 */         h = Math.max(h, c.measure(Math.max(0, maxWidth / this.columns), maxHeight).height()); 
/*     */     } 
/* 241 */     Insets p = parent.layoutSpec().padding();
/* 242 */     return new UiSize(maxWidth, rows * h + Math.max(0, rows - 1) * this.gap + p.vertical());
/*     */   }
/*     */ 
/*     */   
/*     */   public void layout(UiComponent parent, UiBounds raw) {
/* 247 */     UiBounds content = raw.inset(parent.layoutSpec().padding());
/* 248 */     int cellW = Math.max(0, (content.width() - this.gap * (this.columns - 1)) / this.columns);
/* 249 */     int col = 0;
/* 250 */     int y = content.y();
/* 251 */     int rowH = 0;
/*     */     
/* 253 */     for (UiComponent c : parent.children()) {
/* 254 */       if (!c.visible())
/*     */         continue; 
/* 256 */       int h = Layouts.height(c, content.height());
/* 257 */       rowH = Math.max(rowH, h);
/* 258 */       int x = content.x() + col * (cellW + this.gap);
/* 259 */       c.layout(new UiBounds(x, y, cellW, h));
/* 260 */       col++;
/* 261 */       if (col == this.columns) {
/* 262 */         col = 0;
/* 263 */         y += rowH + this.gap;
/* 264 */         rowH = 0;
/*     */       } 
/*     */     } 
/*     */   }
/*     */ }


/* Location:              C:\Users\rapha\Downloads\aurora.jar!\META-INF\jars\lqglass-0.2.5.jar!\dev\devswag\lqglas\\ui\layout\Layouts$Grid.class
 * Java compiler version: 21 (65.0)
 * JD-Core Version:       1.1.3
 */