/*     */ package dev.devswag.lqglass.ui.layout;
/*     */ 
/*     */ import dev.devswag.lqglass.ui.Insets;
/*     */ import dev.devswag.lqglass.ui.LayoutSpec;
/*     */ import dev.devswag.lqglass.ui.Length;
/*     */ import dev.devswag.lqglass.ui.UiBounds;
/*     */ import dev.devswag.lqglass.ui.UiComponent;
/*     */ import dev.devswag.lqglass.ui.UiSize;
/*     */ import java.util.List;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ final class Box
/*     */   extends Record
/*     */   implements Layout
/*     */ {
/*     */   private final boolean horizontal;
/*     */   private final int gap;
/*     */   private final Layouts.Align align;
/*     */   private final Layouts.Justify justify;
/*     */   
/*     */   public final String toString() {
/*     */     // Byte code:
/*     */     //   0: aload_0
/*     */     //   1: <illegal opcode> toString : (Ldev/devswag/lqglass/ui/layout/Layouts$Box;)Ljava/lang/String;
/*     */     //   6: areturn
/*     */     // Line number table:
/*     */     //   Java source line number -> byte code offset
/*     */     //   #83	-> 0
/*     */     // Local variable table:
/*     */     //   start	length	slot	name	descriptor
/*     */     //   0	7	0	this	Ldev/devswag/lqglass/ui/layout/Layouts$Box;
/*     */   }
/*     */   
/*     */   public final int hashCode() {
/*     */     // Byte code:
/*     */     //   0: aload_0
/*     */     //   1: <illegal opcode> hashCode : (Ldev/devswag/lqglass/ui/layout/Layouts$Box;)I
/*     */     //   6: ireturn
/*     */     // Line number table:
/*     */     //   Java source line number -> byte code offset
/*     */     //   #83	-> 0
/*     */     // Local variable table:
/*     */     //   start	length	slot	name	descriptor
/*     */     //   0	7	0	this	Ldev/devswag/lqglass/ui/layout/Layouts$Box;
/*     */   }
/*     */   
/*     */   public final boolean equals(Object o) {
/*     */     // Byte code:
/*     */     //   0: aload_0
/*     */     //   1: aload_1
/*     */     //   2: <illegal opcode> equals : (Ldev/devswag/lqglass/ui/layout/Layouts$Box;Ljava/lang/Object;)Z
/*     */     //   7: ireturn
/*     */     // Line number table:
/*     */     //   Java source line number -> byte code offset
/*     */     //   #83	-> 0
/*     */     // Local variable table:
/*     */     //   start	length	slot	name	descriptor
/*     */     //   0	8	0	this	Ldev/devswag/lqglass/ui/layout/Layouts$Box;
/*     */     //   0	8	1	o	Ljava/lang/Object;
/*     */   }
/*     */   
/*     */   private Box(boolean horizontal, int gap, Layouts.Align align, Layouts.Justify justify) {
/*  83 */     this.horizontal = horizontal; this.gap = gap; this.align = align; this.justify = justify; } public boolean horizontal() { return this.horizontal; } public int gap() { return this.gap; } public Layouts.Align align() { return this.align; } public Layouts.Justify justify() { return this.justify; }
/*     */ 
/*     */   
/*     */   public UiSize measure(UiComponent parent, int maxWidth, int maxHeight) {
/*  87 */     int main = 0;
/*  88 */     int cross = 0;
/*  89 */     int visible = 0;
/*  90 */     for (UiComponent c : parent.children()) {
/*  91 */       if (!c.visible())
/*     */         continue; 
/*  93 */       UiSize size = c.measure(maxWidth, maxHeight);
/*  94 */       Insets m = c.layoutSpec().margin();
/*  95 */       main += this.horizontal ? (size.width() + m.horizontal()) : (size.height() + m.vertical());
/*  96 */       cross = Math.max(cross, this.horizontal ? (size.height() + m.vertical()) : (size.width() + m.horizontal()));
/*  97 */       visible++;
/*     */     } 
/*  99 */     if (visible > 1)
/* 100 */       main += this.gap * (visible - 1); 
/* 101 */     Insets p = parent.layoutSpec().padding();
/* 102 */     return this.horizontal ? 
/* 103 */       new UiSize(main + p.horizontal(), cross + p.vertical()) : 
/* 104 */       new UiSize(cross + p.horizontal(), main + p.vertical());
/*     */   }
/*     */ 
/*     */   
/*     */   public void layout(UiComponent parent, UiBounds raw) {
/* 109 */     UiBounds content = raw.inset(parent.layoutSpec().padding());
/* 110 */     List<UiComponent> children = parent.children();
/* 111 */     int count = 0;
/* 112 */     int fixed = 0;
/* 113 */     float grow = 0.0F;
/* 114 */     float shrinkWeight = 0.0F;
/*     */     
/* 116 */     for (UiComponent c : children) {
/* 117 */       if (!c.visible())
/*     */         continue; 
/* 119 */       LayoutSpec spec = c.layoutSpec();
/* 120 */       Insets m = spec.margin();
/* 121 */       int natural = this.horizontal ? Layouts.width(c, content.width()) : Layouts.height(c, content.height());
/* 122 */       if ((this.horizontal ? spec.width() : spec.height()).unit() != Length.Unit.FILL && spec.grow() <= 0.0F) {
/* 123 */         fixed += natural + (this.horizontal ? m.horizontal() : m.vertical());
/* 124 */         shrinkWeight += natural * spec.shrink();
/*     */       } else {
/* 126 */         grow += Math.max(1.0F, spec.grow());
/*     */       } 
/* 128 */       count++;
/*     */     } 
/*     */     
/* 131 */     if (count > 1) {
/* 132 */       fixed += this.gap * (count - 1);
/*     */     }
/* 134 */     int availableMain = this.horizontal ? content.width() : content.height();
/* 135 */     int overflow = Math.max(0, fixed - availableMain);
/* 136 */     int remaining = Math.max(0, availableMain - fixed);
/* 137 */     int used = (grow > 0.0F) ? availableMain : Math.min(fixed, availableMain);
/* 138 */     int cursor = this.horizontal ? content.x() : content.y();
/*     */     
/* 140 */     if (this.justify == Layouts.Justify.CENTER) {
/* 141 */       cursor += Math.max(0, (availableMain - used) / 2);
/* 142 */     } else if (this.justify == Layouts.Justify.END) {
/* 143 */       cursor += Math.max(0, availableMain - used);
/*     */     } 
/* 145 */     int dynamicGap = this.gap;
/* 146 */     if (this.justify == Layouts.Justify.SPACE_BETWEEN && count > 1 && grow == 0.0F) {
/* 147 */       dynamicGap = this.gap + Math.max(0, (availableMain - used) / (count - 1));
/*     */     }
/* 149 */     for (UiComponent c : children) {
/* 150 */       if (!c.visible()) {
/*     */         continue;
/*     */       }
/* 153 */       LayoutSpec spec = c.layoutSpec();
/* 154 */       Insets m = spec.margin();
/* 155 */       int main = this.horizontal ? Layouts.width(c, content.width()) : Layouts.height(c, content.height());
/* 156 */       if ((this.horizontal ? spec.width() : spec.height()).unit() == Length.Unit.FILL || spec.grow() > 0.0F) {
/* 157 */         float weight = Math.max(1.0F, spec.grow());
/* 158 */         main = Math.round(remaining * weight / Math.max(1.0F, grow));
/* 159 */       } else if (overflow > 0 && spec.shrink() > 0.0F && shrinkWeight > 0.0F) {
/* 160 */         int cut = Math.round(overflow * main * spec.shrink() / shrinkWeight);
/*     */ 
/*     */         
/* 163 */         main = this.horizontal ? spec.clampWidth(Math.max(0, main - cut)) : spec.clampHeight(Math.max(0, main - cut));
/*     */       } 
/*     */       
/* 166 */       int crossAvailable = this.horizontal ? (content.height() - m.vertical()) : (content.width() - m.horizontal());
/* 167 */       int cross = this.horizontal ? Layouts.height(c, crossAvailable) : Layouts.width(c, crossAvailable);
/* 168 */       if (this.align == Layouts.Align.STRETCH) {
/* 169 */         cross = Math.max(0, crossAvailable);
/*     */       }
/* 171 */       int crossPos = this.horizontal ? (content.y() + m.top()) : (content.x() + m.left());
/* 172 */       if (this.align == Layouts.Align.CENTER) {
/* 173 */         crossPos += Math.max(0, (crossAvailable - cross) / 2);
/* 174 */       } else if (this.align == Layouts.Align.END) {
/* 175 */         crossPos += Math.max(0, crossAvailable - cross);
/*     */       } 
/* 177 */       cursor += this.horizontal ? m.left() : m.top();
/*     */ 
/*     */       
/* 180 */       UiBounds b = this.horizontal ? new UiBounds(cursor, crossPos, main, cross) : new UiBounds(crossPos, cursor, cross, main);
/* 181 */       c.layout(b);
/* 182 */       cursor += main + (this.horizontal ? m.right() : m.bottom()) + dynamicGap;
/*     */     } 
/*     */   }
/*     */ }


/* Location:              C:\Users\rapha\Downloads\aurora.jar!\META-INF\jars\lqglass-0.2.5.jar!\dev\devswag\lqglas\\ui\layout\Layouts$Box.class
 * Java compiler version: 21 (65.0)
 * JD-Core Version:       1.1.3
 */