/*     */ package dev.devswag.lqglass.ui;
/*     */ 
/*     */ import java.util.ArrayList;
/*     */ import java.util.IdentityHashMap;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import java.util.function.Consumer;
/*     */ import net.minecraft.class_11905;
/*     */ import net.minecraft.class_11908;
/*     */ import net.minecraft.class_2561;
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class InputRouter
/*     */ {
/*     */   private final UiComponent root;
/*     */   private UiComponent focused;
/*     */   private UiComponent captured;
/*     */   private UiComponent currentScope;
/*  20 */   private final Map<UiComponent, UiComponent> savedFocus = new IdentityHashMap<>(); private Consumer<class_2561> narrationSink = component -> {
/*     */     
/*     */     };
/*     */   
/*     */   public InputRouter(UiComponent root) {
/*  25 */     this.root = root;
/*  26 */     UiComponent scope = root.focusScopeRoot();
/*  27 */     this.currentScope = (scope == null) ? root : scope;
/*     */   }
/*     */   
/*     */   public UiComponent focused() {
/*  31 */     return this.focused;
/*     */   }
/*     */   
/*     */   public InputRouter onNarration(Consumer<class_2561> narrationSink) {
/*  35 */     this
/*  36 */       .narrationSink = (narrationSink == null) ? (component -> {  }) : narrationSink;
/*  37 */     return this;
/*     */   }
/*     */   
/*     */   public boolean mouseDown(double x, double y, int button, int modifiers, boolean doubled) {
/*  41 */     syncFocusScope();
/*  42 */     UiComponent target = this.root.findTop(x, y);
/*     */     
/*  44 */     if (this.focused != null && target != this.focused && !isInside(target, this.focused)) {
/*  45 */       this.focused.onClickOutside(x, y);
/*     */     }
/*  47 */     for (UiComponent c = target; c != null; ) {
/*  48 */       InputResult result = c.onMouseDown(x, y, button, modifiers, doubled);
/*  49 */       if (result == InputResult.PASS) {
/*     */         c = c.parent(); continue;
/*     */       } 
/*  52 */       focus(nearestFocusable(c));
/*  53 */       if (result == InputResult.CAPTURE)
/*  54 */         this.captured = c; 
/*  55 */       syncFocusScope();
/*  56 */       return true;
/*     */     } 
/*     */     
/*  59 */     focus(null);
/*  60 */     syncFocusScope();
/*  61 */     return false;
/*     */   }
/*     */   
/*     */   public boolean mouseUp(double x, double y, int button, int modifiers) {
/*  65 */     UiComponent target = (this.captured != null) ? this.captured : this.root.findTop(x, y);
/*  66 */     this.captured = null;
/*     */     
/*  68 */     for (UiComponent c = target; c != null; c = c.parent()) {
/*  69 */       if (c.onMouseUp(x, y, button, modifiers)) {
/*  70 */         syncFocusScope();
/*  71 */         return true;
/*     */       } 
/*     */     } 
/*  74 */     syncFocusScope();
/*  75 */     return false;
/*     */   }
/*     */   
/*     */   public boolean mouseDrag(double x, double y, int button, double dx, double dy) {
/*  79 */     UiComponent target = (this.captured != null) ? this.captured : this.root.findTop(x, y);
/*  80 */     for (UiComponent c = target; c != null; c = c.parent()) {
/*  81 */       if (c.onMouseDrag(x, y, button, dx, dy))
/*  82 */         return true; 
/*  83 */     }  return false;
/*     */   }
/*     */   
/*     */   public boolean scroll(double x, double y, double horizontal, double vertical) {
/*  87 */     UiComponent target = this.root.findTop(x, y);
/*  88 */     for (UiComponent c = target; c != null; c = c.parent()) {
/*  89 */       if (c.onScroll(x, y, horizontal, vertical))
/*  90 */         return true; 
/*  91 */     }  return false;
/*     */   }
/*     */   
/*     */   public boolean keyPressed(class_11908 event) {
/*  95 */     syncFocusScope();
/*  96 */     if (event.comp_4795() == 258) {
/*  97 */       focusNext(((event.comp_4797() & 0x1) != 0));
/*  98 */       return true;
/*     */     } 
/*     */     
/* 101 */     for (UiComponent c = this.focused; c != null; ) {
/* 102 */       if (!c.onKeyPressed(event)) {
/*     */         c = c.parent(); continue;
/* 104 */       }  syncFocusScope();
/* 105 */       return true;
/*     */     } 
/*     */ 
/*     */     
/* 109 */     int dx = (event.comp_4795() == 263) ? -1 : ((event.comp_4795() == 262) ? 1 : 0);
/*     */     
/* 111 */     int dy = (event.comp_4795() == 265) ? -1 : ((event.comp_4795() == 264) ? 1 : 0);
/* 112 */     return (dx != 0 || dy != 0) ? moveFocus(dx, dy) : false;
/*     */   }
/*     */   
/*     */   public boolean keyReleased(class_11908 event) {
/* 116 */     for (UiComponent c = this.focused; c != null; c = c.parent()) {
/* 117 */       if (c.onKeyReleased(event))
/* 118 */         return true; 
/* 119 */     }  return false;
/*     */   }
/*     */   
/*     */   public boolean charTyped(class_11905 event) {
/* 123 */     for (UiComponent c = this.focused; c != null; c = c.parent()) {
/* 124 */       if (c.onCharTyped(event))
/* 125 */         return true; 
/* 126 */     }  return false;
/*     */   }
/*     */   
/*     */   public void clear() {
/* 130 */     this.captured = null;
/* 131 */     focus(null);
/*     */   }
/*     */   
/*     */   private void focusNext(boolean backwards) {
/* 135 */     List<UiComponent> focusable = focusableInScope();
/* 136 */     if (focusable.isEmpty()) {
/* 137 */       focus(null);
/*     */       
/*     */       return;
/*     */     } 
/* 141 */     int current = focusable.indexOf(this.focused);
/* 142 */     if (backwards) {
/* 143 */       current = (current <= 0) ? (focusable.size() - 1) : (current - 1);
/*     */     } else {
/* 145 */       current = (current < 0 || current == focusable.size() - 1) ? 0 : (current + 1);
/*     */     } 
/* 147 */     focus(focusable.get(current));
/*     */   }
/*     */   
/*     */   private boolean moveFocus(int dx, int dy) {
/* 151 */     List<UiComponent> focusable = focusableInScope();
/* 152 */     if (focusable.isEmpty())
/* 153 */       return false; 
/* 154 */     if (!focusable.contains(this.focused)) {
/* 155 */       focus(focusable.get(0));
/* 156 */       return true;
/*     */     } 
/*     */     
/* 159 */     UiBounds from = this.focused.bounds();
/* 160 */     double cx = from.x() + from.width() * 0.5D;
/* 161 */     double cy = from.y() + from.height() * 0.5D;
/* 162 */     UiComponent best = null;
/* 163 */     double bestScore = Double.MAX_VALUE;
/* 164 */     for (UiComponent candidate : focusable) {
/* 165 */       if (candidate == this.focused)
/*     */         continue; 
/* 167 */       UiBounds b = candidate.bounds();
/* 168 */       double ox = b.x() + b.width() * 0.5D - cx;
/* 169 */       double oy = b.y() + b.height() * 0.5D - cy;
/* 170 */       double primary = (dx != 0) ? (ox * dx) : (oy * dy);
/* 171 */       if (primary <= 0.0D)
/*     */         continue; 
/* 173 */       double cross = (dx != 0) ? Math.abs(oy) : Math.abs(ox);
/* 174 */       double score = primary * primary + cross * cross * 2.5D;
/* 175 */       if (score < bestScore) {
/* 176 */         bestScore = score;
/* 177 */         best = candidate;
/*     */       } 
/*     */     } 
/*     */     
/* 181 */     if (best == null)
/* 182 */       return false; 
/* 183 */     focus(best);
/* 184 */     return true;
/*     */   }
/*     */   
/*     */   private List<UiComponent> focusableInScope() {
/* 188 */     UiComponent scope = activeScope();
/* 189 */     List<UiComponent> focusable = new ArrayList<>();
/* 190 */     scope.collectFocusable(focusable);
/* 191 */     return focusable;
/*     */   }
/*     */   
/*     */   private UiComponent activeScope() {
/* 195 */     UiComponent scope = this.root.focusScopeRoot();
/* 196 */     return (scope == null) ? this.root : scope;
/*     */   }
/*     */   
/*     */   private void syncFocusScope() {
/* 200 */     UiComponent scope = activeScope();
/* 201 */     if (scope != this.currentScope) {
/* 202 */       if (this.focused != null && this.focused.isDescendantOf(this.currentScope))
/* 203 */         this.savedFocus.put(this.currentScope, this.focused); 
/* 204 */       this.currentScope = scope;
/* 205 */       UiComponent previous = this.savedFocus.remove(scope);
/* 206 */       if (previous != null && previous.isDescendantOf(scope)) {
/* 207 */         focus(previous);
/*     */       } else {
/* 209 */         focus(firstFocusable(scope));
/*     */       } 
/*     */       return;
/*     */     } 
/* 213 */     if (scope != this.root && this.focused == null) {
/* 214 */       focus(firstFocusable(scope));
/*     */       return;
/*     */     } 
/* 217 */     if (this.focused != null && !this.focused.isDescendantOf(scope))
/* 218 */       if (scope != this.root) {
/* 219 */         focus(firstFocusable(scope));
/*     */       } else {
/* 221 */         focus(null);
/*     */       }  
/*     */   }
/*     */   
/*     */   private UiComponent firstFocusable(UiComponent scope) {
/* 226 */     List<UiComponent> focusable = new ArrayList<>();
/* 227 */     scope.collectFocusable(focusable);
/* 228 */     return focusable.isEmpty() ? null : focusable.get(0);
/*     */   }
/*     */   
/*     */   private void focus(UiComponent next) {
/* 232 */     if (this.focused == next)
/*     */       return; 
/* 234 */     if (this.focused != null)
/* 235 */       this.focused.focused(false); 
/* 236 */     this.focused = next;
/* 237 */     if (this.focused != null) {
/* 238 */       this.focused.focused(true);
/* 239 */       class_2561 narration = this.focused.narration();
/* 240 */       if (narration != null)
/* 241 */         this.narrationSink.accept(narration); 
/*     */     } 
/*     */   }
/*     */   
/*     */   private UiComponent nearestFocusable(UiComponent c) {
/* 246 */     for (UiComponent p = c; p != null; p = p.parent()) {
/* 247 */       if (p.focusable())
/* 248 */         return p; 
/* 249 */     }  return null;
/*     */   }
/*     */   
/*     */   private boolean isInside(UiComponent child, UiComponent ancestor) {
/* 253 */     return (child != null && child.isDescendantOf(ancestor));
/*     */   }
/*     */ }


/* Location:              C:\Users\rapha\Downloads\aurora.jar!\META-INF\jars\lqglass-0.2.5.jar!\dev\devswag\lqglas\\ui\InputRouter.class
 * Java compiler version: 21 (65.0)
 * JD-Core Version:       1.1.3
 */