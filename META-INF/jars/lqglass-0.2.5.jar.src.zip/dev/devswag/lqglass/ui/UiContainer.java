/*   */ package dev.devswag.lqglass.ui;
/*   */ 
/*   */ import dev.devswag.lqglass.ui.layout.Layout;
/*   */ 
/*   */ public class UiContainer
/*   */   extends UiComponent
/*   */ {
/*   */   public UiContainer(Layout layout) {
/* 9 */     layout(layout);
/*   */   }
/*   */ }


/* Location:              C:\Users\rapha\Downloads\aurora.jar!\META-INF\jars\lqglass-0.2.5.jar!\dev\devswag\lqglas\\ui\UiContainer.class
 * Java compiler version: 21 (65.0)
 * JD-Core Version:       1.1.3
 */