/*    */ package dev.devswag.lqglass.ui;
/*    */ 
/*    */ import dev.devswag.lqglass.state.SettingGroup;
/*    */ import dev.devswag.lqglass.state.SettingValue;
/*    */ import dev.devswag.lqglass.style.LiquidGlassTheme;
/*    */ import dev.devswag.lqglass.ui.components.Button;
/*    */ import dev.devswag.lqglass.ui.components.GlassPanel;
/*    */ import dev.devswag.lqglass.ui.components.ScrollContainer;
/*    */ import dev.devswag.lqglass.ui.components.SearchField;
/*    */ import dev.devswag.lqglass.ui.layout.Layouts;
/*    */ import java.util.ArrayList;
/*    */ import java.util.List;
/*    */ import java.util.Objects;
/*    */ import net.minecraft.class_2561;
/*    */ 
/*    */ public final class SettingsScreen
/*    */   extends GlassScreen {
/*    */   private final Setup setup;
/* 19 */   private final SettingGroup settings = new SettingGroup();
/* 20 */   private final SettingValue<String> search = (new SettingValue("")).live(true);
/*    */   
/*    */   public SettingsScreen(String title, LiquidGlassTheme theme) {
/* 23 */     this(title, theme, new Setup());
/*    */   }
/*    */   
/*    */   private SettingsScreen(String title, LiquidGlassTheme theme, Setup setup) {
/* 27 */     super((class_2561)class_2561.method_43470((title == null) ? "" : title), setup.root, theme);
/* 28 */     this.setup = setup;
/* 29 */     Objects.requireNonNull(this.search); setup.searchField.value().listen(this.search::set);
/*    */   }
/*    */   
/*    */   public SettingGroup settings() {
/* 33 */     return this.settings;
/*    */   }
/*    */   
/*    */   public SettingValue<String> search() {
/* 37 */     return this.search;
/*    */   }
/*    */   
/*    */   public SettingsScreen category(String name, UiComponent page) {
/* 41 */     if (page == null) {
/* 42 */       throw new IllegalArgumentException("page");
/*    */     }
/* 44 */     int index = this.setup.pages.size();
/* 45 */     this.setup.pages.add(page);
/* 46 */     this.setup.content.add(page);
/* 47 */     this.setup.sidebar.add((UiComponent)new Button(name, () -> select(index)));
/*    */     
/* 49 */     if (this.setup.pages.size() == 1) {
/* 50 */       select(0);
/*    */     } else {
/* 52 */       page.visible(false);
/*    */     } 
/* 54 */     return this;
/*    */   }
/*    */   
/*    */   public void select(int index) {
/* 58 */     if (index < 0 || index >= this.setup.pages.size()) {
/*    */       return;
/*    */     }
/* 61 */     for (int i = 0; i < this.setup.pages.size(); i++)
/* 62 */       ((UiComponent)this.setup.pages.get(i)).visible((i == index)); 
/*    */   }
/*    */   
/*    */   private static final class Setup
/*    */   {
/* 67 */     private final UiContainer sidebar = new UiContainer(Layouts.column(6));
/* 68 */     private final UiContainer content = new UiContainer(Layouts.stack(Layouts.Align.STRETCH, Layouts.Align.START));
/* 69 */     private final SearchField searchField = new SearchField((new SettingValue("")).live(true));
/* 70 */     private final List<UiComponent> pages = new ArrayList<>();
/*    */     private final UiComponent root;
/*    */     
/*    */     private Setup() {
/* 74 */       GlassPanel side = new GlassPanel();
/* 75 */       side.layout(Layouts.column(8));
/* 76 */       side.layoutSpec().width(Length.px(150.0F)).padding(Insets.all(10));
/* 77 */       this.sidebar.layoutSpec().grow(1.0F);
/* 78 */       side.add(this.sidebar);
/*    */       
/* 80 */       GlassPanel main = new GlassPanel();
/* 81 */       main.layout(Layouts.column(8));
/* 82 */       main.layoutSpec().grow(1.0F).padding(Insets.all(10));
/* 83 */       main.add((UiComponent)this.searchField);
/*    */       
/* 85 */       ScrollContainer scroll = new ScrollContainer(this.content);
/* 86 */       scroll.layoutSpec().grow(1.0F);
/* 87 */       main.add((UiComponent)scroll);
/*    */       
/* 89 */       UiContainer row = new UiContainer(Layouts.row(10, Layouts.Align.STRETCH, Layouts.Justify.START));
/* 90 */       row.layoutSpec().padding(Insets.all(12));
/* 91 */       row.add((UiComponent)side);
/* 92 */       row.add((UiComponent)main);
/* 93 */       this.root = row;
/*    */     }
/*    */   }
/*    */ }


/* Location:              C:\Users\rapha\Downloads\aurora.jar!\META-INF\jars\lqglass-0.2.5.jar!\dev\devswag\lqglas\\ui\SettingsScreen.class
 * Java compiler version: 21 (65.0)
 * JD-Core Version:       1.1.3
 */