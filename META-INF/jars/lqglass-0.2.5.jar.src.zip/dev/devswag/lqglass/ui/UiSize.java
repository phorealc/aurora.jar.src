/*    */ package dev.devswag.lqglass.ui;public final class UiSize extends Record { private final int width;
/*    */   private final int height;
/*    */   
/*  4 */   public int height() { return this.height; } public int width() { return this.width; } public final boolean equals(Object o) {
/*    */     // Byte code:
/*    */     //   0: aload_0
/*    */     //   1: aload_1
/*    */     //   2: <illegal opcode> equals : (Ldev/devswag/lqglass/ui/UiSize;Ljava/lang/Object;)Z
/*    */     //   7: ireturn
/*    */     // Line number table:
/*    */     //   Java source line number -> byte code offset
/*    */     //   #4	-> 0
/*    */     // Local variable table:
/*    */     //   start	length	slot	name	descriptor
/*    */     //   0	8	0	this	Ldev/devswag/lqglass/ui/UiSize;
/*    */     //   0	8	1	o	Ljava/lang/Object;
/*  6 */   } public static final UiSize ZERO = new UiSize(0, 0);
/*    */   public final int hashCode() { // Byte code:
/*    */     //   0: aload_0
/*    */     //   1: <illegal opcode> hashCode : (Ldev/devswag/lqglass/ui/UiSize;)I
/*    */     //   6: ireturn
/*    */     // Line number table:
/*    */     //   Java source line number -> byte code offset
/*    */     //   #4	-> 0
/*    */     // Local variable table:
/*    */     //   start	length	slot	name	descriptor
/*    */     //   0	7	0	this	Ldev/devswag/lqglass/ui/UiSize; }
/*    */   public final String toString() { // Byte code:
/*    */     //   0: aload_0
/*    */     //   1: <illegal opcode> toString : (Ldev/devswag/lqglass/ui/UiSize;)Ljava/lang/String;
/*    */     //   6: areturn
/*    */     // Line number table:
/*    */     //   Java source line number -> byte code offset
/*    */     //   #4	-> 0
/*    */     // Local variable table:
/*    */     //   start	length	slot	name	descriptor
/*    */     //   0	7	0	this	Ldev/devswag/lqglass/ui/UiSize; } public UiSize(int width, int height) {
/*  9 */     width = Math.max(0, width);
/* 10 */     height = Math.max(0, height);
/*    */     this.width = width;
/*    */     this.height = height;
/*    */   } }


/* Location:              C:\Users\rapha\Downloads\aurora.jar!\META-INF\jars\lqglass-0.2.5.jar!\dev\devswag\lqglas\\ui\UiSize.class
 * Java compiler version: 21 (65.0)
 * JD-Core Version:       1.1.3
 */