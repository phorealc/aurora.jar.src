/*    */ package dev.devswag.lqglass.ui;
/*    */ public final class Insets extends Record { private final int top; private final int right; private final int bottom;
/*    */   
/*  4 */   public int top() { return this.top; } private final int left; public final String toString() { // Byte code:
/*    */     //   0: aload_0
/*    */     //   1: <illegal opcode> toString : (Ldev/devswag/lqglass/ui/Insets;)Ljava/lang/String;
/*    */     //   6: areturn
/*    */     // Line number table:
/*    */     //   Java source line number -> byte code offset
/*    */     //   #4	-> 0
/*    */     // Local variable table:
/*    */     //   start	length	slot	name	descriptor
/*    */     //   0	7	0	this	Ldev/devswag/lqglass/ui/Insets; } public final int hashCode() { // Byte code:
/*    */     //   0: aload_0
/*    */     //   1: <illegal opcode> hashCode : (Ldev/devswag/lqglass/ui/Insets;)I
/*    */     //   6: ireturn
/*    */     // Line number table:
/*    */     //   Java source line number -> byte code offset
/*    */     //   #4	-> 0
/*    */     // Local variable table:
/*    */     //   start	length	slot	name	descriptor
/*    */     //   0	7	0	this	Ldev/devswag/lqglass/ui/Insets; } public final boolean equals(Object o) { // Byte code:
/*    */     //   0: aload_0
/*    */     //   1: aload_1
/*    */     //   2: <illegal opcode> equals : (Ldev/devswag/lqglass/ui/Insets;Ljava/lang/Object;)Z
/*    */     //   7: ireturn
/*    */     // Line number table:
/*    */     //   Java source line number -> byte code offset
/*    */     //   #4	-> 0
/*    */     // Local variable table:
/*    */     //   start	length	slot	name	descriptor
/*    */     //   0	8	0	this	Ldev/devswag/lqglass/ui/Insets;
/*  4 */     //   0	8	1	o	Ljava/lang/Object; } public int right() { return this.right; } public int bottom() { return this.bottom; } public int left() { return this.left; }
/*    */   
/*  6 */   public static final Insets ZERO = new Insets(0, 0, 0, 0);
/*    */   
/*    */   public Insets(int top, int right, int bottom, int left) {
/*  9 */     top = Math.max(0, top);
/* 10 */     right = Math.max(0, right);
/* 11 */     bottom = Math.max(0, bottom);
/* 12 */     left = Math.max(0, left);
/*    */     this.top = top;
/*    */     this.right = right;
/*    */     this.bottom = bottom;
/* 16 */     this.left = left; } public static Insets all(int value) { return new Insets(value, value, value, value); }
/*    */ 
/*    */   
/*    */   public static Insets xy(int horizontal, int vertical) {
/* 20 */     return new Insets(vertical, horizontal, vertical, horizontal);
/*    */   }
/*    */   
/*    */   public int horizontal() {
/* 24 */     return this.left + this.right;
/*    */   }
/*    */   
/*    */   public int vertical() {
/* 28 */     return this.top + this.bottom;
/*    */   } }


/* Location:              C:\Users\rapha\Downloads\aurora.jar!\META-INF\jars\lqglass-0.2.5.jar!\dev\devswag\lqglas\\ui\Insets.class
 * Java compiler version: 21 (65.0)
 * JD-Core Version:       1.1.3
 */