/*    */ package dev.devswag.lqglass.ui;
/*    */ 
/*    */ import dev.devswag.lqglass.render.GlassCapabilities;
/*    */ import dev.devswag.lqglass.render.GlassRenderer;
/*    */ import dev.devswag.lqglass.render.RenderStats;
/*    */ import net.minecraft.class_310;
/*    */ import net.minecraft.class_332;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public final class DebugOverlay
/*    */ {
/*    */   public static void render(class_332 g, UiComponent root, InputRouter input, GlassRenderer renderer) {
/* 15 */     draw(g, root);
/* 16 */     UiComponent focused = input.focused();
/* 17 */     if (focused != null) {
/* 18 */       outline(g, focused.bounds(), -14249);
/*    */     }
/* 20 */     RenderStats stats = renderer.stats();
/* 21 */     GlassCapabilities caps = renderer.capabilities();
/* 22 */     g.method_25294(6, 6, 246, 70, -871690215);
/* 23 */     g.method_51433((class_310.method_1551()).field_1772, "LQGlass  " + 
/* 24 */         String.valueOf(stats.quality()) + "  " + String.valueOf(renderer.quality()), 12, 11, -1379585, false);
/*    */     
/* 26 */     g.method_51433((class_310.method_1551()).field_1772, "surfaces " + stats
/* 27 */         .surfaces() + "  shader " + stats.shaderSurfaces() + "  fallback " + stats
/* 28 */         .fallbackSurfaces(), 12, 25, -4601894, false);
/*    */     
/* 30 */     g.method_51433((class_310.method_1551()).field_1772, "blur " + stats
/* 31 */         .blurPasses() + "  captures " + stats.captures() + "  targets " + stats.targets(), 12, 39, -4601894, false);
/*    */     
/* 33 */     g.method_51433((class_310.method_1551()).field_1772, "shared " + 
/* 34 */         on(caps.sharedBlur()) + "  refract " + on(caps.refraction()) + "  clips " + stats
/* 35 */         .clipped(), 12, 53, -4601894, false);
/*    */   }
/*    */ 
/*    */   
/*    */   private static String on(boolean value) {
/* 40 */     return value ? "on" : "off";
/*    */   }
/*    */   
/*    */   private static void draw(class_332 g, UiComponent component) {
/* 44 */     if (!component.visible()) {
/*    */       return;
/*    */     }
/* 47 */     outline(g, component.bounds(), component.hovered() ? -864245505 : 1434233087);
/* 48 */     for (UiComponent child : component.children())
/* 49 */       draw(g, child); 
/*    */   }
/*    */   
/*    */   private static void outline(class_332 g, UiBounds b, int color) {
/* 53 */     g.method_25294(b.x(), b.y(), b.right(), b.y() + 1, color);
/* 54 */     g.method_25294(b.x(), b.bottom() - 1, b.right(), b.bottom(), color);
/* 55 */     g.method_25294(b.x(), b.y(), b.x() + 1, b.bottom(), color);
/* 56 */     g.method_25294(b.right() - 1, b.y(), b.right(), b.bottom(), color);
/*    */   }
/*    */ }


/* Location:              C:\Users\rapha\Downloads\aurora.jar!\META-INF\jars\lqglass-0.2.5.jar!\dev\devswag\lqglas\\ui\DebugOverlay.class
 * Java compiler version: 21 (65.0)
 * JD-Core Version:       1.1.3
 */