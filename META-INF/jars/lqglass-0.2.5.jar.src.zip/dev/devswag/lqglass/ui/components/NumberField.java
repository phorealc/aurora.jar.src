/*    */ package dev.devswag.lqglass.ui.components;
/*    */ 
/*    */ import dev.devswag.lqglass.state.SettingValue;
/*    */ 
/*    */ public final class NumberField
/*    */   extends TextField
/*    */ {
/*    */   private final SettingValue<Double> number;
/*    */   private final SettingValue<String> text;
/*    */   
/*    */   public NumberField(SettingValue<Double> number) {
/* 12 */     this(number, (new SettingValue(Double.toString(((Double)number.get()).doubleValue()), NumberField::validPartial)).live(true));
/*    */   }
/*    */   
/*    */   private NumberField(SettingValue<Double> number, SettingValue<String> text) {
/* 16 */     super(text);
/* 17 */     if (number == null)
/* 18 */       throw new IllegalArgumentException("number"); 
/* 19 */     this.number = number;
/* 20 */     this.text = text;
/* 21 */     text.listen(this::writeNumber);
/*    */   }
/*    */ 
/*    */   
/*    */   public void tick() {
/* 26 */     super.tick();
/* 27 */     if (!focused()) {
/* 28 */       String current = Double.toString(((Double)this.number.get()).doubleValue());
/* 29 */       if (!current.equals(this.text.get()))
/* 30 */         this.text.set(current); 
/*    */     } 
/*    */   }
/*    */   
/*    */   private void writeNumber(String value) {
/* 35 */     if (value == null || value.isBlank() || value.equals("-") || value.equals(".") || value.equals("-."))
/*    */       return; 
/*    */     try {
/* 38 */       this.number.set(Double.valueOf(Double.parseDouble(value)));
/* 39 */     } catch (NumberFormatException numberFormatException) {}
/*    */   }
/*    */ 
/*    */   
/*    */   private static boolean validPartial(String value) {
/* 44 */     if (value == null)
/* 45 */       return false; 
/* 46 */     if (value.isEmpty() || value.equals("-") || value.equals(".") || value.equals("-."))
/* 47 */       return true; 
/*    */     try {
/* 49 */       Double.parseDouble(value);
/* 50 */       return true;
/* 51 */     } catch (NumberFormatException ignored) {
/* 52 */       return false;
/*    */     } 
/*    */   }
/*    */ }


/* Location:              C:\Users\rapha\Downloads\aurora.jar!\META-INF\jars\lqglass-0.2.5.jar!\dev\devswag\lqglas\\ui\components\NumberField.class
 * Java compiler version: 21 (65.0)
 * JD-Core Version:       1.1.3
 */