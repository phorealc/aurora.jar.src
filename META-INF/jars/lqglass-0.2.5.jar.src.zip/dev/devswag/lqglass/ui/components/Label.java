/*     */ package dev.devswag.lqglass.ui.components;
/*     */ import dev.devswag.lqglass.style.ComponentStyle;
/*     */ import dev.devswag.lqglass.ui.UiComponent;
/*     */ import dev.devswag.lqglass.ui.UiContext;
/*     */ import dev.devswag.lqglass.ui.UiSize;
/*     */ import java.util.Objects;
/*     */ import java.util.function.Supplier;
/*     */ import net.minecraft.class_2561;
/*     */ import net.minecraft.class_327;
/*     */ import net.minecraft.class_5250;
/*     */ import net.minecraft.class_5348;
/*     */ import org.joml.Matrix3x2fStack;
/*     */ 
/*     */ public class Label extends UiComponent {
/*     */   private Supplier<String> text;
/*     */   private Supplier<class_2561> component;
/*  17 */   private TextAlign align = TextAlign.LEFT;
/*     */   private boolean wrap;
/*     */   private boolean ellipsis = true;
/*     */   private int color;
/*  21 */   private float scale = 1.0F;
/*     */   
/*     */   public Label(String text) {
/*  24 */     this(() -> (text == null) ? "" : text);
/*     */   }
/*     */   
/*     */   public Label(Supplier<String> text) {
/*  28 */     this.text = (text == null) ? (() -> "") : text;
/*     */   }
/*     */   
/*     */   public static Label from(class_2561 component) {
/*  32 */     return (new Label("")).component(component);
/*     */   }
/*     */   
/*     */   public Label text(String text) {
/*  36 */     this.component = null;
/*  37 */     this.text = (() -> (text == null) ? "" : text);
/*  38 */     invalidateLayout();
/*  39 */     return this;
/*     */   }
/*     */   
/*     */   public Label text(Supplier<String> text) {
/*  43 */     this.component = null;
/*  44 */     this.text = (text == null) ? (() -> "") : text;
/*  45 */     invalidateLayout();
/*  46 */     return this;
/*     */   }
/*     */   
/*     */   public Label component(class_2561 component) {
/*  50 */     this.component = (() -> (component == null) ? (class_2561)class_2561.method_43473() : component);
/*  51 */     this.text = (() -> valueComponent().getString());
/*  52 */     invalidateLayout();
/*  53 */     return this;
/*     */   }
/*     */   
/*     */   public Label component(Supplier<class_2561> component) {
/*  57 */     this.component = (component == null) ? (() -> class_2561.method_43473()) : component;
/*  58 */     this.text = (() -> valueComponent().getString());
/*  59 */     invalidateLayout();
/*  60 */     return this;
/*     */   }
/*     */   
/*     */   public Label align(TextAlign align) {
/*  64 */     this.align = (align == null) ? TextAlign.LEFT : align;
/*  65 */     return this;
/*     */   }
/*     */   
/*     */   public Label wrap(boolean wrap) {
/*  69 */     this.wrap = wrap;
/*  70 */     invalidateLayout();
/*  71 */     return this;
/*     */   }
/*     */   
/*     */   public Label ellipsis(boolean ellipsis) {
/*  75 */     this.ellipsis = ellipsis;
/*  76 */     return this;
/*     */   }
/*     */   
/*     */   public Label color(int color) {
/*  80 */     this.color = color;
/*  81 */     return this;
/*     */   }
/*     */   
/*     */   public Label scale(float scale) {
/*  85 */     if (!Float.isFinite(scale))
/*  86 */       throw new IllegalArgumentException("scale"); 
/*  87 */     this.scale = Math.max(0.25F, Math.min(8.0F, scale));
/*  88 */     invalidateLayout();
/*  89 */     return this;
/*     */   }
/*     */ 
/*     */   
/*     */   public class_2561 narration() {
/*  94 */     class_2561 accessible = super.narration();
/*  95 */     return (accessible == null) ? valueComponent() : accessible;
/*     */   }
/*     */ 
/*     */   
/*     */   protected UiSize measurePreferred(int maxWidth, int maxHeight) {
/* 100 */     class_327 font = (class_310.method_1551()).field_1772;
/* 101 */     class_2561 value = valueComponent();
/* 102 */     int naturalWidth = font.method_27525((class_5348)value);
/* 103 */     int available = (maxWidth == Integer.MAX_VALUE) ? naturalWidth : Math.max(1, Math.round(maxWidth / this.scale));
/* 104 */     int width = this.wrap ? Math.min(naturalWidth, available) : naturalWidth;
/* 105 */     Objects.requireNonNull(font); int height = this.wrap ? font.method_44378((class_5348)value, Math.max(1, width)) : 9;
/* 106 */     return new UiSize(Math.round(width * this.scale), Math.round(height * this.scale));
/*     */   }
/*     */ 
/*     */   
/*     */   protected void draw(UiContext ctx) {
/* 111 */     class_2561 value = valueComponent();
/* 112 */     if (value.getString().isEmpty()) {
/*     */       return;
/*     */     }
/* 115 */     ComponentStyle componentStyle = (style() != null) ? style() : ctx.theme().control();
/* 116 */     int textColor = (this.color != 0) ? this.color : (enabled() ? componentStyle.text() : componentStyle.disabled());
/*     */     
/* 118 */     Matrix3x2fStack pose = ctx.graphics().method_51448();
/* 119 */     pose.pushMatrix();
/* 120 */     pose.translate(bounds().x(), bounds().y());
/* 121 */     pose.scale(this.scale, this.scale);
/*     */     
/* 123 */     int width = Math.max(1, Math.round(bounds().width() / this.scale));
/* 124 */     if (this.wrap) {
/* 125 */       ctx.graphics().method_51440(ctx.font(), (class_5348)value, 0, 0, width, textColor, false);
/*     */     } else {
/* 127 */       class_5250 class_5250; if (this.ellipsis && ctx.font().method_27525((class_5348)value) > width) {
/* 128 */         String dots = "...";
/* 129 */         int room = Math.max(0, width - ctx.font().method_1727(dots));
/* 130 */         class_5250 = class_2561.method_43470(ctx.font().method_27523(value.getString(), room) + ctx.font().method_27523(value.getString(), room));
/*     */       } 
/*     */       
/* 133 */       int valueWidth = ctx.font().method_27525((class_5348)class_5250);
/* 134 */       switch (this.align) { case CENTER: 
/*     */         case RIGHT: 
/*     */         default:
/* 137 */           break; }  int x = 0;
/*     */       
/* 139 */       Objects.requireNonNull(ctx.font()); int y = Math.max(0, (Math.round(bounds().height() / this.scale) - 9) / 2);
/* 140 */       ctx.graphics().method_51439(ctx.font(), (class_2561)class_5250, x, y, textColor, false);
/*     */     } 
/*     */     
/* 143 */     pose.popMatrix();
/*     */   }
/*     */   
/*     */   private class_2561 valueComponent() {
/* 147 */     if (this.component != null) {
/* 148 */       class_2561 class_2561 = this.component.get();
/* 149 */       return (class_2561 == null) ? (class_2561)class_2561.method_43473() : class_2561;
/*     */     } 
/* 151 */     String value = this.text.get();
/* 152 */     return (class_2561)class_2561.method_43470((value == null) ? "" : value);
/*     */   }
/*     */ }


/* Location:              C:\Users\rapha\Downloads\aurora.jar!\META-INF\jars\lqglass-0.2.5.jar!\dev\devswag\lqglas\\ui\components\Label.class
 * Java compiler version: 21 (65.0)
 * JD-Core Version:       1.1.3
 */