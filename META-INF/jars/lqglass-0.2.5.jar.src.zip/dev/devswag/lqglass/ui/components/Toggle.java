/*     */ package dev.devswag.lqglass.ui.components;
/*     */ 
/*     */ import dev.devswag.lqglass.animation.AnimFloat;
/*     */ import dev.devswag.lqglass.animation.Easing;
/*     */ import dev.devswag.lqglass.animation.UiMotion;
/*     */ import dev.devswag.lqglass.state.SettingValue;
/*     */ import dev.devswag.lqglass.style.ComponentStyle;
/*     */ import dev.devswag.lqglass.ui.InputResult;
/*     */ import dev.devswag.lqglass.ui.Insets;
/*     */ import dev.devswag.lqglass.ui.UiComponent;
/*     */ import dev.devswag.lqglass.ui.UiContext;
/*     */ import dev.devswag.lqglass.ui.UiSize;
/*     */ import java.util.Objects;
/*     */ import net.minecraft.class_11908;
/*     */ import net.minecraft.class_2561;
/*     */ import net.minecraft.class_310;
/*     */ import net.minecraft.class_5348;
/*     */ 
/*     */ public class Toggle extends UiComponent {
/*     */   private final SettingValue<Boolean> value;
/*     */   private class_2561 label;
/*     */   private final AnimFloat switchPosition;
/*     */   
/*     */   public Toggle(String label, SettingValue<Boolean> value) {
/*  25 */     if (value == null)
/*  26 */       throw new IllegalArgumentException("value"); 
/*  27 */     this.label = (class_2561)class_2561.method_43470((label == null) ? "" : label);
/*  28 */     this.value = value;
/*  29 */     this.switchPosition = new AnimFloat(Boolean.TRUE.equals(value.get()) ? 1.0F : 0.0F);
/*     */   }
/*     */   
/*     */   public static Toggle fromComponent(class_2561 label, SettingValue<Boolean> value) {
/*  33 */     Toggle toggle = new Toggle("", value);
/*  34 */     toggle.label = (label == null) ? (class_2561)class_2561.method_43473() : label;
/*  35 */     return toggle;
/*     */   }
/*     */   
/*     */   public SettingValue<Boolean> value() {
/*  39 */     return this.value;
/*     */   }
/*     */   
/*     */   public Toggle label(String label) {
/*  43 */     this.label = (class_2561)class_2561.method_43470((label == null) ? "" : label);
/*  44 */     invalidateLayout();
/*  45 */     return this;
/*     */   }
/*     */   
/*     */   public Toggle component(class_2561 label) {
/*  49 */     this.label = (label == null) ? (class_2561)class_2561.method_43473() : label;
/*  50 */     invalidateLayout();
/*  51 */     return this;
/*     */   }
/*     */ 
/*     */   
/*     */   public class_2561 narration() {
/*  56 */     class_2561 accessible = super.narration();
/*  57 */     if (accessible != null)
/*  58 */       return accessible; 
/*  59 */     return (class_2561)class_2561.method_43470(this.label.getString() + this.label.getString());
/*     */   }
/*     */ 
/*     */   
/*     */   protected UiSize measurePreferred(int maxWidth, int maxHeight) {
/*  64 */     Insets p = (style() != null) ? style().padding() : Insets.xy(9, 6);
/*  65 */     int text = (class_310.method_1551()).field_1772.method_27525((class_5348)this.label);
/*  66 */     Objects.requireNonNull((class_310.method_1551()).field_1772); return new UiSize(text + 38 + p.horizontal(), Math.max(16, 9) + p.vertical());
/*     */   }
/*     */ 
/*     */   
/*     */   protected void draw(UiContext ctx) {
/*  71 */     ComponentStyle s = (style() != null) ? style() : ctx.theme().control();
/*  72 */     ctx.glass().surface(ctx.graphics(), bounds(), s.glass());
/*  73 */     if (hovered() && enabled()) {
/*  74 */       ctx.graphics().method_25294(bounds().x(), bounds().y(), bounds().right(), bounds().bottom(), s.hover());
/*     */     }
/*  76 */     Insets p = s.padding();
/*  77 */     Objects.requireNonNull(ctx.font()); int textY = bounds().y() + Math.max(0, (bounds().height() - 9) / 2);
/*  78 */     ctx.graphics().method_51439(ctx.font(), this.label, bounds().x() + p.left(), textY, 
/*  79 */         enabled() ? s.text() : s.disabled(), false);
/*     */     
/*  81 */     int w = 28;
/*  82 */     int h = 14;
/*  83 */     int x = bounds().right() - p.right() - w;
/*  84 */     int y = bounds().y() + (bounds().height() - h) / 2;
/*  85 */     boolean on = Boolean.TRUE.equals(this.value.get());
/*  86 */     float target = on ? 1.0F : 0.0F;
/*  87 */     if (this.switchPosition.target() != target)
/*  88 */       this.switchPosition.animate(target, UiMotion.duration(160), Easing.OUT_CUBIC, ctx.now()); 
/*  89 */     float t = this.switchPosition.update(ctx.now());
/*  90 */     int track = on ? s.accent() : 1717396592;
/*  91 */     ctx.graphics().method_25294(x, y, x + w, y + h, track);
/*     */     
/*  93 */     int knob = h - 4;
/*  94 */     int travel = w - knob - 4;
/*  95 */     int knobX = x + 2 + Math.round(travel * t);
/*  96 */     ctx.graphics().method_25294(knobX, y + 2, knobX + knob, y + h - 2, enabled() ? -1 : s.disabled());
/*     */     
/*  98 */     if (focused() && enabled()) {
/*  99 */       ctx.graphics().method_25294(bounds().x(), bounds().bottom() - 1, bounds().right(), bounds().bottom(), s.accent());
/*     */     }
/*     */   }
/*     */   
/*     */   protected boolean focusable() {
/* 104 */     return true;
/*     */   }
/*     */ 
/*     */   
/*     */   protected InputResult onMouseDown(double x, double y, int button, int modifiers, boolean doubled) {
/* 109 */     if (button != 0)
/* 110 */       return InputResult.PASS; 
/* 111 */     toggle();
/* 112 */     return InputResult.CONSUME;
/*     */   }
/*     */ 
/*     */   
/*     */   protected boolean onKeyPressed(class_11908 event) {
/* 117 */     if (event.comp_4795() != 32 && event.comp_4795() != 257)
/* 118 */       return false; 
/* 119 */     toggle();
/* 120 */     return true;
/*     */   }
/*     */   
/*     */   private void toggle() {
/* 124 */     if (enabled())
/* 125 */       this.value.set(Boolean.valueOf(!Boolean.TRUE.equals(this.value.get()))); 
/*     */   }
/*     */ }


/* Location:              C:\Users\rapha\Downloads\aurora.jar!\META-INF\jars\lqglass-0.2.5.jar!\dev\devswag\lqglas\\ui\components\Toggle.class
 * Java compiler version: 21 (65.0)
 * JD-Core Version:       1.1.3
 */