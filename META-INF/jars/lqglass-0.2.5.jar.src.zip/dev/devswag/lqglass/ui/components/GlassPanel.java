/*    */ package dev.devswag.lqglass.ui.components;
/*    */ 
/*    */ import dev.devswag.lqglass.style.ComponentStyle;
/*    */ import dev.devswag.lqglass.style.GlassStyle;
/*    */ import dev.devswag.lqglass.ui.UiComponent;
/*    */ import dev.devswag.lqglass.ui.UiContext;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class GlassPanel
/*    */   extends UiComponent
/*    */ {
/*    */   private GlassStyle glass;
/*    */   
/*    */   public GlassPanel glass(GlassStyle glass) {
/* 17 */     this.glass = glass;
/* 18 */     return this;
/*    */   }
/*    */   
/*    */   public GlassStyle glass() {
/* 22 */     return this.glass;
/*    */   }
/*    */ 
/*    */   
/*    */   protected void draw(UiContext ctx) {
/* 27 */     ComponentStyle componentStyle = (style() != null) ? style() : ctx.theme().panel();
/* 28 */     GlassStyle surface = (this.glass != null) ? this.glass : componentStyle.glass();
/* 29 */     ctx.glass().surface(ctx.graphics(), bounds(), surface);
/*    */   }
/*    */ }


/* Location:              C:\Users\rapha\Downloads\aurora.jar!\META-INF\jars\lqglass-0.2.5.jar!\dev\devswag\lqglas\\ui\components\GlassPanel.class
 * Java compiler version: 21 (65.0)
 * JD-Core Version:       1.1.3
 */