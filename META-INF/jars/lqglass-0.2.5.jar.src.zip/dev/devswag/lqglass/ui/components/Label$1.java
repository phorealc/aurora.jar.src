/*     */ package dev.devswag.lqglass.ui.components;


/* Location:              C:\Users\rapha\Downloads\aurora.jar!\META-INF\jars\lqglass-0.2.5.jar!\dev\devswag\lqglas\\ui\components\Label$1.class
 * Java compiler version: 21 (65.0)
 * JD-Core Version:       1.1.3
 */