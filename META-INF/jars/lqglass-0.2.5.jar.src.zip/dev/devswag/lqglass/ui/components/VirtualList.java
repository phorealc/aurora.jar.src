/*     */ package dev.devswag.lqglass.ui.components;
/*     */ 
/*     */ import dev.devswag.lqglass.ui.UiBounds;
/*     */ import dev.devswag.lqglass.ui.UiComponent;
/*     */ import dev.devswag.lqglass.ui.UiSize;
/*     */ import java.util.ArrayList;
/*     */ import java.util.List;
/*     */ import java.util.function.BiFunction;
/*     */ import net.minecraft.class_11908;
/*     */ 
/*     */ 
/*     */ public final class VirtualList<T>
/*     */   extends UiComponent
/*     */ {
/*  15 */   private List<T> items = List.of();
/*     */   private final BiFunction<T, Integer, UiComponent> rowFactory;
/*  17 */   private final List<UiComponent> rows = new ArrayList<>();
/*     */   private int rowHeight;
/*  19 */   private int preferredWidth = 180;
/*  20 */   private int firstIndex = -1;
/*  21 */   private int lastIndex = -1;
/*     */   private double scrollY;
/*     */   private double targetY;
/*  24 */   private int overscan = 1;
/*     */   
/*     */   public VirtualList(List<T> items, int rowHeight, BiFunction<T, Integer, UiComponent> rowFactory) {
/*  27 */     if (rowFactory == null)
/*  28 */       throw new IllegalArgumentException("rowFactory"); 
/*  29 */     this.rowFactory = rowFactory;
/*  30 */     rowHeight(rowHeight);
/*  31 */     items(items);
/*  32 */     clip(true);
/*     */   }
/*     */   
/*     */   public VirtualList<T> items(List<T> items) {
/*  36 */     this.items = (items == null) ? List.<T>of() : List.<T>copyOf(items);
/*  37 */     this.firstIndex = -1;
/*  38 */     this.lastIndex = -1;
/*  39 */     invalidateLayout();
/*  40 */     return this;
/*     */   }
/*     */   
/*     */   public List<T> items() {
/*  44 */     return this.items;
/*     */   }
/*     */   
/*     */   public VirtualList<T> rowHeight(int height) {
/*  48 */     this.rowHeight = Math.max(1, height);
/*  49 */     this.firstIndex = -1;
/*  50 */     invalidateLayout();
/*  51 */     return this;
/*     */   }
/*     */   
/*     */   public VirtualList<T> preferredWidth(int width) {
/*  55 */     this.preferredWidth = Math.max(1, width);
/*  56 */     invalidateLayout();
/*  57 */     return this;
/*     */   }
/*     */   
/*     */   public VirtualList<T> overscan(int rows) {
/*  61 */     this.overscan = Math.max(0, Math.min(8, rows));
/*  62 */     this.firstIndex = -1;
/*  63 */     invalidateLayout();
/*  64 */     return this;
/*     */   }
/*     */   
/*     */   public double scrollY() {
/*  68 */     return this.scrollY;
/*     */   }
/*     */   
/*     */   public void scrollTo(double y) {
/*  72 */     this.targetY = clamp(y, 0.0D, maxScroll());
/*  73 */     invalidateLayout();
/*     */   }
/*     */   
/*     */   public void scrollToIndex(int index) {
/*  77 */     if (this.items.isEmpty())
/*     */       return; 
/*  79 */     int row = Math.max(0, Math.min(this.items.size() - 1, index));
/*  80 */     int top = row * this.rowHeight;
/*  81 */     if (top < this.scrollY) {
/*  82 */       scrollTo(top);
/*  83 */     } else if ((top + this.rowHeight) > this.scrollY + bounds().height()) {
/*  84 */       scrollTo((top + this.rowHeight - bounds().height()));
/*     */     } 
/*     */   }
/*     */   public int renderedRowCount() {
/*  88 */     return this.rows.size();
/*     */   }
/*     */ 
/*     */   
/*     */   protected UiSize measurePreferred(int maxWidth, int maxHeight) {
/*  93 */     int width = (maxWidth == Integer.MAX_VALUE) ? this.preferredWidth : maxWidth;
/*  94 */     long fullHeight = this.items.size() * this.rowHeight;
/*  95 */     int height = (int)Math.min(Math.min(fullHeight, 2147483647L), maxHeight);
/*  96 */     return new UiSize(width, height);
/*     */   }
/*     */ 
/*     */   
/*     */   public void layout(UiBounds bounds) {
/* 101 */     super.layout(bounds);
/* 102 */     this.scrollY = clamp(this.scrollY, 0.0D, maxScroll());
/* 103 */     this.targetY = clamp(this.targetY, 0.0D, maxScroll());
/*     */     
/* 105 */     int start = Math.max(0, (int)(this.scrollY / this.rowHeight) - this.overscan);
/* 106 */     int end = Math.min(this.items.size(), (int)Math.ceil((this.scrollY + bounds.height()) / this.rowHeight) + this.overscan);
/* 107 */     if (start != this.firstIndex || end != this.lastIndex) {
/* 108 */       rebuild(start, end);
/*     */     }
/* 110 */     for (int i = 0; i < this.rows.size(); i++) {
/* 111 */       int itemIndex = this.firstIndex + i;
/* 112 */       ((UiComponent)this.rows.get(i)).layout(new UiBounds(bounds
/* 113 */             .x(), bounds
/* 114 */             .y() + itemIndex * this.rowHeight - (int)Math.round(this.scrollY), bounds
/* 115 */             .width(), this.rowHeight));
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void tick() {
/* 122 */     super.tick();
/* 123 */     double next = this.scrollY + (this.targetY - this.scrollY) * 0.35D;
/* 124 */     if (Math.abs(this.targetY - next) < 0.05D)
/* 125 */       next = this.targetY; 
/* 126 */     if (next != this.scrollY) {
/* 127 */       this.scrollY = next;
/* 128 */       invalidateLayout();
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   protected boolean onScroll(double x, double y, double horizontal, double vertical) {
/* 134 */     if (maxScroll() <= 0.0D || vertical == 0.0D)
/* 135 */       return false; 
/* 136 */     scrollTo(this.targetY - vertical * this.rowHeight * 2.0D);
/* 137 */     return true;
/*     */   }
/*     */ 
/*     */   
/*     */   protected boolean onKeyPressed(class_11908 event) {
/* 142 */     if (event.comp_4795() == 268 && !this.items.isEmpty()) {
/* 143 */       scrollTo(0.0D);
/* 144 */       return true;
/*     */     } 
/* 146 */     if (event.comp_4795() == 269 && !this.items.isEmpty()) {
/* 147 */       scrollTo(maxScroll());
/* 148 */       return true;
/*     */     } 
/* 150 */     return false;
/*     */   }
/*     */   
/*     */   private void rebuild(int start, int end) {
/* 154 */     clear();
/* 155 */     this.rows.clear();
/* 156 */     this.firstIndex = start;
/* 157 */     this.lastIndex = end;
/* 158 */     for (int i = start; i < end; i++) {
/* 159 */       UiComponent row = this.rowFactory.apply(this.items.get(i), Integer.valueOf(i));
/* 160 */       if (row == null)
/* 161 */         throw new IllegalStateException("rowFactory returned null for index " + i); 
/* 162 */       this.rows.add(row);
/* 163 */       add(row);
/*     */     } 
/*     */   }
/*     */   
/*     */   private double maxScroll() {
/* 168 */     return Math.max(0L, this.items.size() * this.rowHeight - bounds().height());
/*     */   }
/*     */   
/*     */   private double clamp(double value, double min, double max) {
/* 172 */     return Math.max(min, Math.min(max, value));
/*     */   }
/*     */ }


/* Location:              C:\Users\rapha\Downloads\aurora.jar!\META-INF\jars\lqglass-0.2.5.jar!\dev\devswag\lqglas\\ui\components\VirtualList.class
 * Java compiler version: 21 (65.0)
 * JD-Core Version:       1.1.3
 */