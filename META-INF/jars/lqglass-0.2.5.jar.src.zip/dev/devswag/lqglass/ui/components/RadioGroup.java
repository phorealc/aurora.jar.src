/*    */ package dev.devswag.lqglass.ui.components;
/*    */ 
/*    */ import dev.devswag.lqglass.state.SettingValue;
/*    */ import dev.devswag.lqglass.style.ComponentStyle;
/*    */ import dev.devswag.lqglass.ui.InputResult;
/*    */ import dev.devswag.lqglass.ui.Insets;
/*    */ import dev.devswag.lqglass.ui.UiComponent;
/*    */ import dev.devswag.lqglass.ui.UiContext;
/*    */ import dev.devswag.lqglass.ui.UiSize;
/*    */ import java.util.List;
/*    */ import java.util.Objects;
/*    */ import java.util.function.Function;
/*    */ import net.minecraft.class_310;
/*    */ 
/*    */ 
/*    */ public final class RadioGroup<T>
/*    */   extends UiComponent
/*    */ {
/*    */   private final SettingValue<T> value;
/*    */   private final List<T> options;
/* 21 */   private Function<T, String> formatter = String::valueOf;
/*    */   
/*    */   public RadioGroup(SettingValue<T> value, List<T> options) {
/* 24 */     if (value == null || options == null || options.isEmpty())
/* 25 */       throw new IllegalArgumentException("radio group"); 
/* 26 */     this.value = value;
/* 27 */     this.options = List.copyOf(options);
/*    */   }
/*    */   
/*    */   public RadioGroup<T> formatter(Function<T, String> formatter) {
/* 31 */     this.formatter = (formatter == null) ? String::valueOf : formatter;
/* 32 */     invalidateLayout();
/* 33 */     return this;
/*    */   }
/*    */ 
/*    */   
/*    */   protected UiSize measurePreferred(int maxWidth, int maxHeight) {
/* 38 */     Insets p = (style() != null) ? style().padding() : Insets.xy(9, 6);
/* 39 */     Objects.requireNonNull((class_310.method_1551()).field_1772); int row = 9 + 6;
/* 40 */     int width = 0;
/* 41 */     for (T option : this.options)
/* 42 */       width = Math.max(width, (class_310.method_1551()).field_1772.method_1727(text(option)) + 20); 
/* 43 */     return new UiSize(width + p.horizontal(), row * this.options.size() + p.vertical());
/*    */   }
/*    */ 
/*    */   
/*    */   protected void draw(UiContext ctx) {
/* 48 */     ComponentStyle s = (style() != null) ? style() : ctx.theme().control();
/* 49 */     ctx.glass().surface(ctx.graphics(), bounds(), s.glass());
/*    */     
/* 51 */     Insets p = s.padding();
/* 52 */     int row = rowHeight();
/* 53 */     for (int i = 0; i < this.options.size(); i++) {
/* 54 */       T option = this.options.get(i);
/* 55 */       int y = bounds().y() + p.top() + i * row;
/* 56 */       int cx = bounds().x() + p.left() + 5;
/* 57 */       int cy = y + row / 2;
/*    */       
/* 59 */       ctx.graphics().method_25294(cx - 5, cy - 5, cx + 5, cy + 5, -2006092672);
/* 60 */       ctx.graphics().method_25294(cx - 4, cy - 4, cx + 4, cy + 4, -871032801);
/* 61 */       if (option.equals(this.value.get())) {
/* 62 */         ctx.graphics().method_25294(cx - 2, cy - 2, cx + 3, cy + 3, s.accent());
/*    */       }
/*    */       
/* 65 */       Objects.requireNonNull(ctx.font()); ctx.graphics().method_51433(ctx.font(), text(option), cx + 10, y + Math.max(0, (row - 9) / 2), 
/* 66 */           enabled() ? s.text() : s.disabled(), false);
/*    */     } 
/*    */   }
/*    */ 
/*    */   
/*    */   protected boolean focusable() {
/* 72 */     return true;
/*    */   }
/*    */ 
/*    */   
/*    */   protected InputResult onMouseDown(double x, double y, int button, int modifiers, boolean doubled) {
/* 77 */     if (button != 0)
/* 78 */       return InputResult.PASS; 
/* 79 */     Insets p = (style() != null) ? style().padding() : Insets.xy(9, 6);
/* 80 */     int index = (int)((y - bounds().y() - p.top()) / rowHeight());
/* 81 */     if (index < 0 || index >= this.options.size())
/* 82 */       return InputResult.CONSUME; 
/* 83 */     this.value.set(this.options.get(index));
/* 84 */     return InputResult.CONSUME;
/*    */   }
/*    */   
/*    */   private int rowHeight() {
/* 88 */     Objects.requireNonNull((class_310.method_1551()).field_1772); return 9 + 6;
/*    */   }
/*    */   
/*    */   private String text(T option) {
/* 92 */     String text = this.formatter.apply(option);
/* 93 */     return (text == null) ? "" : text;
/*    */   }
/*    */ }


/* Location:              C:\Users\rapha\Downloads\aurora.jar!\META-INF\jars\lqglass-0.2.5.jar!\dev\devswag\lqglas\\ui\components\RadioGroup.class
 * Java compiler version: 21 (65.0)
 * JD-Core Version:       1.1.3
 */