/*     */ package dev.devswag.lqglass.ui.components;
/*     */ 
/*     */ import dev.devswag.lqglass.state.SettingValue;
/*     */ import dev.devswag.lqglass.style.ComponentStyle;
/*     */ import dev.devswag.lqglass.style.GlassPresets;
/*     */ import dev.devswag.lqglass.ui.InputResult;
/*     */ import dev.devswag.lqglass.ui.Insets;
/*     */ import dev.devswag.lqglass.ui.UiBounds;
/*     */ import dev.devswag.lqglass.ui.UiComponent;
/*     */ import dev.devswag.lqglass.ui.UiContext;
/*     */ import dev.devswag.lqglass.ui.UiSize;
/*     */ import java.util.LinkedHashSet;
/*     */ import java.util.List;
/*     */ import java.util.Objects;
/*     */ import java.util.Set;
/*     */ import java.util.function.Function;
/*     */ import net.minecraft.class_11908;
/*     */ import net.minecraft.class_2561;
/*     */ import net.minecraft.class_310;
/*     */ 
/*     */ public final class MultiSelect<T>
/*     */   extends UiComponent
/*     */ {
/*     */   private final SettingValue<Set<T>> value;
/*     */   private final List<T> options;
/*  26 */   private Function<T, String> formatter = String::valueOf;
/*     */   private Function<T, class_2561> componentFormatter;
/*     */   private final String label;
/*     */   private class_2561 componentLabel;
/*     */   private boolean open;
/*     */   
/*     */   public MultiSelect(String label, SettingValue<Set<T>> value, List<T> options) {
/*  33 */     if (value == null || options == null || options.isEmpty())
/*  34 */       throw new IllegalArgumentException("multi select"); 
/*  35 */     this.label = (label == null) ? "" : label;
/*  36 */     this.value = value;
/*  37 */     this.options = List.copyOf(options);
/*     */   }
/*     */   
/*     */   public MultiSelect<T> formatter(Function<T, String> formatter) {
/*  41 */     this.formatter = (formatter == null) ? String::valueOf : formatter;
/*  42 */     invalidateLayout();
/*  43 */     return this;
/*     */   }
/*     */   
/*     */   public MultiSelect<T> componentLabel(class_2561 label) {
/*  47 */     this.componentLabel = label;
/*  48 */     invalidateLayout();
/*  49 */     return this;
/*     */   }
/*     */   
/*     */   public MultiSelect<T> componentFormatter(Function<T, class_2561> formatter) {
/*  53 */     this.componentFormatter = formatter;
/*  54 */     invalidateLayout();
/*  55 */     return this;
/*     */   }
/*     */ 
/*     */   
/*     */   public class_2561 narration() {
/*  60 */     class_2561 accessible = super.narration();
/*  61 */     return (accessible == null) ? (class_2561)class_2561.method_43470(labelText().getString() + ": " + labelText().getString() + " selected") : accessible;
/*     */   }
/*     */ 
/*     */   
/*     */   protected UiSize measurePreferred(int maxWidth, int maxHeight) {
/*  66 */     Insets p = (style() != null) ? style().padding() : Insets.xy(9, 6);
/*  67 */     Objects.requireNonNull((class_310.method_1551()).field_1772); return new UiSize(170, 9 + p.vertical());
/*     */   }
/*     */ 
/*     */   
/*     */   protected void draw(UiContext ctx) {
/*  72 */     ComponentStyle s = (style() != null) ? style() : ctx.theme().control();
/*  73 */     ctx.glass().surface(ctx.graphics(), bounds(), s.glass());
/*     */     
/*  75 */     Insets p = s.padding();
/*  76 */     Objects.requireNonNull(ctx.font()); int y = bounds().y() + Math.max(0, (bounds().height() - 9) / 2);
/*  77 */     ctx.graphics().method_51439(ctx.font(), labelText(), bounds().x() + p.left(), y, enabled() ? s.text() : s.disabled(), false);
/*     */     
/*  79 */     String count = Integer.toString(current().size());
/*  80 */     ctx.graphics().method_51433(ctx.font(), count, bounds().right() - p.right() - ctx.font().method_1727(count) - 11, y, 
/*  81 */         enabled() ? s.secondaryText() : s.disabled(), false);
/*  82 */     ctx.graphics().method_51433(ctx.font(), this.open ? "▲" : "▼", bounds().right() - p.right() - 7, y, 
/*  83 */         enabled() ? s.secondaryText() : s.disabled(), false);
/*     */     
/*  85 */     if (!this.open) {
/*     */       return;
/*     */     }
/*  88 */     UiBounds popup = popup();
/*  89 */     ctx.graphics().method_71048();
/*  90 */     ctx.glass().surface(ctx.graphics(), popup, GlassPresets.STRONG);
/*     */     
/*  92 */     int row = rowHeight();
/*  93 */     for (int i = 0; i < this.options.size(); i++) {
/*  94 */       T option = this.options.get(i);
/*  95 */       int oy = popup.y() + i * row;
/*  96 */       if (current().contains(option)) {
/*  97 */         ctx.graphics().method_25294(popup.x() + 1, oy, popup.x() + 3, oy + row, s.accent());
/*     */       }
/*  99 */       Objects.requireNonNull(ctx.font()); ctx.graphics().method_51439(ctx.font(), componentText(option), popup.x() + p.left(), oy + (row - 9) / 2, s.text(), false);
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   protected boolean hitTest(double x, double y) {
/* 105 */     return (bounds().contains(x, y) || (this.open && popup().contains(x, y)));
/*     */   }
/*     */ 
/*     */   
/*     */   protected boolean focusable() {
/* 110 */     return true;
/*     */   }
/*     */ 
/*     */   
/*     */   protected InputResult onMouseDown(double x, double y, int button, int modifiers, boolean doubled) {
/* 115 */     if (button != 0) {
/* 116 */       return InputResult.PASS;
/*     */     }
/* 118 */     if (bounds().contains(x, y)) {
/* 119 */       this.open = !this.open;
/* 120 */       return InputResult.CONSUME;
/*     */     } 
/*     */     
/* 123 */     int index = optionAt(x, y);
/* 124 */     if (this.open && index >= 0) {
/* 125 */       LinkedHashSet<T> next = new LinkedHashSet<>(current());
/* 126 */       T option = this.options.get(index);
/* 127 */       if (!next.add(option))
/* 128 */         next.remove(option); 
/* 129 */       this.value.set(Set.copyOf(next));
/* 130 */       return InputResult.CONSUME;
/*     */     } 
/*     */     
/* 133 */     return InputResult.PASS;
/*     */   }
/*     */ 
/*     */   
/*     */   protected boolean onKeyPressed(class_11908 event) {
/* 138 */     if (event.comp_4795() == 256 && this.open) {
/* 139 */       this.open = false;
/* 140 */       return true;
/*     */     } 
/* 142 */     if (event.comp_4795() == 257 || event.comp_4795() == 32) {
/* 143 */       this.open = !this.open;
/* 144 */       return true;
/*     */     } 
/* 146 */     return false;
/*     */   }
/*     */ 
/*     */   
/*     */   protected void onClickOutside(double x, double y) {
/* 151 */     this.open = false;
/*     */   }
/*     */   
/*     */   private Set<T> current() {
/* 155 */     Set<T> set = (Set<T>)this.value.get();
/* 156 */     return (set == null) ? Set.<T>of() : set;
/*     */   }
/*     */   
/*     */   private int optionAt(double x, double y) {
/* 160 */     UiBounds popup = popup();
/* 161 */     if (!popup.contains(x, y))
/* 162 */       return -1; 
/* 163 */     int index = (int)((y - popup.y()) / rowHeight());
/* 164 */     return (index >= 0 && index < this.options.size()) ? index : -1;
/*     */   }
/*     */   
/*     */   private UiBounds popup() {
/* 168 */     return new UiBounds(bounds().x(), bounds().bottom() + 2, bounds().width(), rowHeight() * this.options.size());
/*     */   }
/*     */   
/*     */   private int rowHeight() {
/* 172 */     Insets p = (style() != null) ? style().padding() : Insets.xy(9, 6);
/* 173 */     Objects.requireNonNull((class_310.method_1551()).field_1772); return 9 + p.vertical();
/*     */   }
/*     */   
/*     */   private class_2561 labelText() {
/* 177 */     return (this.componentLabel == null) ? (class_2561)class_2561.method_43470(this.label) : this.componentLabel;
/*     */   }
/*     */   
/*     */   private class_2561 componentText(T option) {
/* 181 */     if (this.componentFormatter != null) {
/* 182 */       class_2561 class_25611 = this.componentFormatter.apply(option);
/* 183 */       if (class_25611 != null)
/* 184 */         return class_25611; 
/*     */     } 
/* 186 */     String value = this.formatter.apply(option);
/* 187 */     return (class_2561)class_2561.method_43470((value == null) ? "" : value);
/*     */   }
/*     */ }


/* Location:              C:\Users\rapha\Downloads\aurora.jar!\META-INF\jars\lqglass-0.2.5.jar!\dev\devswag\lqglas\\ui\components\MultiSelect.class
 * Java compiler version: 21 (65.0)
 * JD-Core Version:       1.1.3
 */