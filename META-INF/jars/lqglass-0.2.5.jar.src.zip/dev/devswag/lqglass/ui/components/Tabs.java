/*    */ package dev.devswag.lqglass.ui.components;
/*    */ 
/*    */ import dev.devswag.lqglass.state.SettingValue;
/*    */ import dev.devswag.lqglass.ui.UiComponent;
/*    */ import dev.devswag.lqglass.ui.UiContainer;
/*    */ import dev.devswag.lqglass.ui.layout.Layouts;
/*    */ import java.util.ArrayList;
/*    */ import java.util.List;
/*    */ 
/*    */ public final class Tabs
/*    */   extends UiContainer
/*    */ {
/* 13 */   private final UiContainer buttons = new UiContainer(Layouts.row(6));
/* 14 */   private final UiContainer content = new UiContainer(Layouts.stack(Layouts.Align.STRETCH, Layouts.Align.STRETCH));
/* 15 */   private final List<UiComponent> pages = new ArrayList<>();
/*    */   private final SettingValue<Integer> selected;
/*    */   
/*    */   public Tabs() {
/* 19 */     this(new SettingValue(Integer.valueOf(0), value -> (value != null && value.intValue() >= 0)));
/*    */   }
/*    */   
/*    */   public Tabs(SettingValue<Integer> selected) {
/* 23 */     super(Layouts.column(8));
/* 24 */     if (selected == null)
/* 25 */       throw new IllegalArgumentException("selected"); 
/* 26 */     this.selected = selected;
/* 27 */     add((UiComponent)this.buttons);
/* 28 */     add((UiComponent)this.content);
/* 29 */     this.content.layoutSpec().grow(1.0F);
/* 30 */     selected.listen(value -> refresh());
/*    */   }
/*    */   
/*    */   public Tabs addTab(String name, UiComponent page) {
/* 34 */     if (page == null) {
/* 35 */       throw new IllegalArgumentException("page");
/*    */     }
/* 37 */     int index = this.pages.size();
/* 38 */     this.pages.add(page);
/* 39 */     this.buttons.add(new Button(name, () -> select(index)));
/* 40 */     this.content.add(page);
/*    */     
/* 42 */     if (this.pages.size() == 1) {
/* 43 */       this.selected.set(Integer.valueOf(0));
/*    */     }
/* 45 */     refresh();
/* 46 */     return this;
/*    */   }
/*    */   
/*    */   public int selected() {
/* 50 */     return ((Integer)this.selected.get()).intValue();
/*    */   }
/*    */   
/*    */   public void select(int index) {
/* 54 */     if (index < 0 || index >= this.pages.size())
/*    */       return; 
/* 56 */     this.selected.set(Integer.valueOf(index));
/* 57 */     refresh();
/*    */   }
/*    */   
/*    */   private void refresh() {
/* 61 */     int index = ((Integer)this.selected.get()).intValue();
/* 62 */     for (int i = 0; i < this.pages.size(); i++)
/* 63 */       ((UiComponent)this.pages.get(i)).visible((i == index)); 
/*    */   }
/*    */ }


/* Location:              C:\Users\rapha\Downloads\aurora.jar!\META-INF\jars\lqglass-0.2.5.jar!\dev\devswag\lqglas\\ui\components\Tabs.class
 * Java compiler version: 21 (65.0)
 * JD-Core Version:       1.1.3
 */