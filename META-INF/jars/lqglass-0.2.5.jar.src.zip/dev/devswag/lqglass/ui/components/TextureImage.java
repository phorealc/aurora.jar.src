/*    */ package dev.devswag.lqglass.ui.components;
/*    */ 
/*    */ import dev.devswag.lqglass.ui.UiComponent;
/*    */ import dev.devswag.lqglass.ui.UiContext;
/*    */ import dev.devswag.lqglass.ui.UiSize;
/*    */ import net.minecraft.class_10799;
/*    */ import net.minecraft.class_2960;
/*    */ 
/*    */ public final class TextureImage
/*    */   extends UiComponent {
/*    */   private final class_2960 texture;
/*    */   private final int textureWidth;
/*    */   private final int textureHeight;
/*    */   private final int u;
/*    */   private final int v;
/*    */   private final int regionWidth;
/*    */   private final int regionHeight;
/*    */   
/*    */   public TextureImage(class_2960 texture, int width, int height) {
/* 20 */     this(texture, width, height, 0, 0, width, height);
/*    */   }
/*    */   
/*    */   public TextureImage(class_2960 texture, int textureWidth, int textureHeight, int u, int v, int regionWidth, int regionHeight) {
/* 24 */     if (texture == null)
/* 25 */       throw new IllegalArgumentException("texture"); 
/* 26 */     this.texture = texture;
/* 27 */     this.textureWidth = Math.max(1, textureWidth);
/* 28 */     this.textureHeight = Math.max(1, textureHeight);
/* 29 */     this.u = Math.max(0, u);
/* 30 */     this.v = Math.max(0, v);
/* 31 */     this.regionWidth = Math.max(1, regionWidth);
/* 32 */     this.regionHeight = Math.max(1, regionHeight);
/*    */   }
/*    */ 
/*    */   
/*    */   protected UiSize measurePreferred(int maxWidth, int maxHeight) {
/* 37 */     return new UiSize(this.regionWidth, this.regionHeight);
/*    */   }
/*    */ 
/*    */   
/*    */   protected void draw(UiContext ctx) {
/* 42 */     ctx.graphics().method_25302(class_10799.field_56883, this.texture, 
/* 43 */         bounds().x(), bounds().y(), this.u, this.v, bounds().width(), bounds().height(), this.regionWidth, this.regionHeight, this.textureWidth, this.textureHeight);
/*    */   }
/*    */ }


/* Location:              C:\Users\rapha\Downloads\aurora.jar!\META-INF\jars\lqglass-0.2.5.jar!\dev\devswag\lqglas\\ui\components\TextureImage.class
 * Java compiler version: 21 (65.0)
 * JD-Core Version:       1.1.3
 */