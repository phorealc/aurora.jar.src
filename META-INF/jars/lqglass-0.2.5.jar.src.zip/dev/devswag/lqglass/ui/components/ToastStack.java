/*    */ package dev.devswag.lqglass.ui.components;
/*    */ 
/*    */ import dev.devswag.lqglass.style.GlassPresets;
/*    */ import dev.devswag.lqglass.ui.UiBounds;
/*    */ import dev.devswag.lqglass.ui.UiComponent;
/*    */ import dev.devswag.lqglass.ui.UiContext;
/*    */ import java.util.ArrayList;
/*    */ import java.util.List;
/*    */ import java.util.Objects;
/*    */ import net.minecraft.class_156;
/*    */ import net.minecraft.class_2561;
/*    */ import net.minecraft.class_5348;
/*    */ 
/*    */ public final class ToastStack extends UiComponent {
/* 15 */   private final List<Entry> entries = new ArrayList<>();
/*    */   
/*    */   public ToastStack show(String message) {
/* 18 */     return show((class_2561)class_2561.method_43470((message == null) ? "" : message), 2600L);
/*    */   }
/*    */   
/*    */   public ToastStack show(class_2561 message) {
/* 22 */     return show(message, 2600L);
/*    */   }
/*    */   
/*    */   public ToastStack show(class_2561 message, long durationMs) {
/* 26 */     this.entries.add(new Entry((message == null) ? (class_2561)class_2561.method_43473() : message, class_156.method_658(), 
/* 27 */           Math.max(500L, durationMs)));
/* 28 */     while (this.entries.size() > 5)
/* 29 */       this.entries.remove(0); 
/* 30 */     return this;
/*    */   }
/*    */ 
/*    */   
/*    */   public void tick() {
/* 35 */     long now = System.currentTimeMillis();
/* 36 */     this.entries.removeIf(entry -> (now - entry.started >= entry.duration));
/*    */   }
/*    */ 
/*    */   
/*    */   protected void draw(UiContext ctx) {
/* 41 */     long now = ctx.now();
/* 42 */     int y = bounds().y() + 14;
/* 43 */     for (int i = this.entries.size() - 1; i >= 0; i--) {
/* 44 */       Entry entry = this.entries.get(i);
/* 45 */       long elapsed = now - entry.started;
/*    */ 
/*    */       
/* 48 */       float alpha = (elapsed > entry.duration - 280L) ? Math.max(0.0F, (float)(entry.duration - elapsed) / 280.0F) : Math.min(1.0F, (float)elapsed / 140.0F);
/* 49 */       int width = Math.min(Math.max(180, ctx.font().method_27525((class_5348)entry.message) + 28), Math.max(180, bounds().width() - 24));
/* 50 */       Objects.requireNonNull(ctx.font()); int height = 9 + 18;
/* 51 */       int x = bounds().right() - width - 14;
/* 52 */       UiBounds box = new UiBounds(x, y, width, height);
/* 53 */       ctx.glass().surface(ctx.graphics(), box, GlassPresets.DARK, alpha);
/* 54 */       int color = (int)(alpha * 255.0F) << 24 | 0xF7F8FC;
/*    */       
/* 56 */       Objects.requireNonNull(ctx.font()); ctx.graphics().method_51439(ctx.font(), entry.message, x + 14, y + (height - 9) / 2, color, false);
/* 57 */       y += height + 8;
/*    */     } 
/*    */   }
/*    */   private static final class Entry extends Record { private final class_2561 message; private final long started; private final long duration;
/* 61 */     private Entry(class_2561 message, long started, long duration) { this.message = message; this.started = started; this.duration = duration; } public final String toString() { // Byte code:
/*    */       //   0: aload_0
/*    */       //   1: <illegal opcode> toString : (Ldev/devswag/lqglass/ui/components/ToastStack$Entry;)Ljava/lang/String;
/*    */       //   6: areturn
/*    */       // Line number table:
/*    */       //   Java source line number -> byte code offset
/*    */       //   #61	-> 0
/*    */       // Local variable table:
/*    */       //   start	length	slot	name	descriptor
/* 61 */       //   0	7	0	this	Ldev/devswag/lqglass/ui/components/ToastStack$Entry; } public class_2561 message() { return this.message; } public final int hashCode() { // Byte code:
/*    */       //   0: aload_0
/*    */       //   1: <illegal opcode> hashCode : (Ldev/devswag/lqglass/ui/components/ToastStack$Entry;)I
/*    */       //   6: ireturn
/*    */       // Line number table:
/*    */       //   Java source line number -> byte code offset
/*    */       //   #61	-> 0
/*    */       // Local variable table:
/*    */       //   start	length	slot	name	descriptor
/*    */       //   0	7	0	this	Ldev/devswag/lqglass/ui/components/ToastStack$Entry; } public final boolean equals(Object o) { // Byte code:
/*    */       //   0: aload_0
/*    */       //   1: aload_1
/*    */       //   2: <illegal opcode> equals : (Ldev/devswag/lqglass/ui/components/ToastStack$Entry;Ljava/lang/Object;)Z
/*    */       //   7: ireturn
/*    */       // Line number table:
/*    */       //   Java source line number -> byte code offset
/*    */       //   #61	-> 0
/*    */       // Local variable table:
/*    */       //   start	length	slot	name	descriptor
/*    */       //   0	8	0	this	Ldev/devswag/lqglass/ui/components/ToastStack$Entry;
/* 61 */       //   0	8	1	o	Ljava/lang/Object; } public long started() { return this.started; } public long duration() { return this.duration; }
/*    */      }
/*    */ 
/*    */ }


/* Location:              C:\Users\rapha\Downloads\aurora.jar!\META-INF\jars\lqglass-0.2.5.jar!\dev\devswag\lqglas\\ui\components\ToastStack.class
 * Java compiler version: 21 (65.0)
 * JD-Core Version:       1.1.3
 */