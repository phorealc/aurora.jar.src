/*     */ package dev.devswag.lqglass.ui.components;
/*     */ 
/*     */ import dev.devswag.lqglass.state.SettingValue;
/*     */ import dev.devswag.lqglass.style.ComponentStyle;
/*     */ import dev.devswag.lqglass.ui.InputResult;
/*     */ import dev.devswag.lqglass.ui.Insets;
/*     */ import dev.devswag.lqglass.ui.UiComponent;
/*     */ import dev.devswag.lqglass.ui.UiContext;
/*     */ import dev.devswag.lqglass.ui.UiSize;
/*     */ import java.util.Objects;
/*     */ import net.minecraft.class_11908;
/*     */ import net.minecraft.class_2561;
/*     */ import net.minecraft.class_310;
/*     */ import net.minecraft.class_5348;
/*     */ 
/*     */ public class Checkbox
/*     */   extends UiComponent {
/*     */   private final SettingValue<Boolean> value;
/*     */   private String label;
/*     */   private class_2561 componentLabel;
/*     */   
/*     */   public Checkbox(String label, SettingValue<Boolean> value) {
/*  23 */     if (value == null)
/*  24 */       throw new IllegalArgumentException("value"); 
/*  25 */     this.label = (label == null) ? "" : label;
/*  26 */     this.value = value;
/*     */   }
/*     */   
/*     */   public SettingValue<Boolean> value() {
/*  30 */     return this.value;
/*     */   }
/*     */   
/*     */   public Checkbox componentLabel(class_2561 label) {
/*  34 */     this.componentLabel = label;
/*  35 */     invalidateLayout();
/*  36 */     return this;
/*     */   }
/*     */ 
/*     */   
/*     */   public class_2561 narration() {
/*  41 */     class_2561 accessible = super.narration();
/*  42 */     return (accessible == null) ? 
/*  43 */       (class_2561)class_2561.method_43470(labelText().getString() + labelText().getString()) : 
/*  44 */       accessible;
/*     */   }
/*     */ 
/*     */   
/*     */   protected UiSize measurePreferred(int maxWidth, int maxHeight) {
/*  49 */     Insets p = (style() != null) ? style().padding() : Insets.xy(9, 6);
/*     */     
/*  51 */     Objects.requireNonNull((class_310.method_1551()).field_1772); return new UiSize((class_310.method_1551()).field_1772.method_27525((class_5348)labelText()) + 20 + p.horizontal(), Math.max(14, 9) + p.vertical());
/*     */   }
/*     */ 
/*     */   
/*     */   protected void draw(UiContext ctx) {
/*  56 */     ComponentStyle s = (style() != null) ? style() : ctx.theme().control();
/*  57 */     ctx.glass().surface(ctx.graphics(), bounds(), s.glass());
/*  58 */     if (hovered() && enabled()) {
/*  59 */       ctx.graphics().method_25294(bounds().x(), bounds().y(), bounds().right(), bounds().bottom(), s.hover());
/*     */     }
/*  61 */     Insets p = s.padding();
/*  62 */     int size = 12;
/*  63 */     int x = bounds().x() + p.left();
/*  64 */     int y = bounds().y() + (bounds().height() - size) / 2;
/*  65 */     int border = Boolean.TRUE.equals(this.value.get()) ? s.accent() : -2006092672;
/*     */     
/*  67 */     ctx.graphics().method_25294(x, y, x + size, y + size, border);
/*  68 */     ctx.graphics().method_25294(x + 1, y + 1, x + size - 1, y + size - 1, -871032801);
/*  69 */     if (Boolean.TRUE.equals(this.value.get())) {
/*  70 */       ctx.graphics().method_25294(x + 3, y + 5, x + 5, y + 9, -1);
/*  71 */       ctx.graphics().method_25294(x + 5, y + 7, x + 10, y + 9, -1);
/*     */     } 
/*     */ 
/*     */     
/*  75 */     Objects.requireNonNull(ctx.font()); ctx.graphics().method_51439(ctx.font(), labelText(), x + size + 8, bounds().y() + Math.max(0, (bounds().height() - 9) / 2), 
/*  76 */         enabled() ? s.text() : s.disabled(), false);
/*     */   }
/*     */ 
/*     */   
/*     */   protected boolean focusable() {
/*  81 */     return true;
/*     */   }
/*     */ 
/*     */   
/*     */   protected InputResult onMouseDown(double x, double y, int button, int modifiers, boolean doubled) {
/*  86 */     if (button != 0)
/*  87 */       return InputResult.PASS; 
/*  88 */     toggle();
/*  89 */     return InputResult.CONSUME;
/*     */   }
/*     */ 
/*     */   
/*     */   protected boolean onKeyPressed(class_11908 event) {
/*  94 */     if (event.comp_4795() != 32 && event.comp_4795() != 257)
/*  95 */       return false; 
/*  96 */     toggle();
/*  97 */     return true;
/*     */   }
/*     */   
/*     */   private class_2561 labelText() {
/* 101 */     return (this.componentLabel == null) ? (class_2561)class_2561.method_43470(this.label) : this.componentLabel;
/*     */   }
/*     */   
/*     */   private void toggle() {
/* 105 */     if (enabled())
/* 106 */       this.value.set(Boolean.valueOf(!Boolean.TRUE.equals(this.value.get()))); 
/*     */   }
/*     */ }


/* Location:              C:\Users\rapha\Downloads\aurora.jar!\META-INF\jars\lqglass-0.2.5.jar!\dev\devswag\lqglas\\ui\components\Checkbox.class
 * Java compiler version: 21 (65.0)
 * JD-Core Version:       1.1.3
 */