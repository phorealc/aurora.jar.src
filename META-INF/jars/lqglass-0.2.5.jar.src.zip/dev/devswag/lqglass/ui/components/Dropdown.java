/*     */ package dev.devswag.lqglass.ui.components;
/*     */ 
/*     */ import dev.devswag.lqglass.state.SettingValue;
/*     */ import dev.devswag.lqglass.style.ComponentStyle;
/*     */ import dev.devswag.lqglass.style.GlassPresets;
/*     */ import dev.devswag.lqglass.ui.InputResult;
/*     */ import dev.devswag.lqglass.ui.Insets;
/*     */ import dev.devswag.lqglass.ui.UiBounds;
/*     */ import dev.devswag.lqglass.ui.UiComponent;
/*     */ import dev.devswag.lqglass.ui.UiContext;
/*     */ import dev.devswag.lqglass.ui.UiSize;
/*     */ import java.util.List;
/*     */ import java.util.Objects;
/*     */ import java.util.function.Function;
/*     */ import net.minecraft.class_11908;
/*     */ import net.minecraft.class_2561;
/*     */ import net.minecraft.class_310;
/*     */ import net.minecraft.class_5348;
/*     */ 
/*     */ public class Dropdown<T>
/*     */   extends UiComponent
/*     */ {
/*     */   private final SettingValue<T> value;
/*     */   private final List<T> options;
/*  25 */   private Function<T, String> formatter = String::valueOf;
/*     */   private Function<T, class_2561> componentFormatter;
/*     */   private String label;
/*     */   private class_2561 componentLabel;
/*     */   private boolean open;
/*  30 */   private int hoverIndex = -1;
/*     */   
/*     */   public Dropdown(String label, SettingValue<T> value, List<T> options) {
/*  33 */     if (value == null || options == null || options.isEmpty())
/*  34 */       throw new IllegalArgumentException("dropdown"); 
/*  35 */     this.label = (label == null) ? "" : label;
/*  36 */     this.value = value;
/*  37 */     this.options = List.copyOf(options);
/*     */   }
/*     */   
/*     */   public Dropdown<T> formatter(Function<T, String> formatter) {
/*  41 */     this.formatter = (formatter == null) ? String::valueOf : formatter;
/*  42 */     invalidateLayout();
/*  43 */     return this;
/*     */   }
/*     */   
/*     */   public Dropdown<T> componentLabel(class_2561 label) {
/*  47 */     this.componentLabel = label;
/*  48 */     invalidateLayout();
/*  49 */     return this;
/*     */   }
/*     */   
/*     */   public Dropdown<T> componentFormatter(Function<T, class_2561> formatter) {
/*  53 */     this.componentFormatter = formatter;
/*  54 */     invalidateLayout();
/*  55 */     return this;
/*     */   }
/*     */ 
/*     */   
/*     */   public class_2561 narration() {
/*  60 */     class_2561 accessible = super.narration();
/*  61 */     return (accessible == null) ? 
/*  62 */       (class_2561)class_2561.method_43470(labelText().getString() + ": " + labelText().getString()) : 
/*  63 */       accessible;
/*     */   }
/*     */   
/*     */   public boolean open() {
/*  67 */     return this.open;
/*     */   }
/*     */   
/*     */   public void close() {
/*  71 */     this.open = false;
/*  72 */     this.hoverIndex = -1;
/*     */   }
/*     */ 
/*     */   
/*     */   protected UiSize measurePreferred(int maxWidth, int maxHeight) {
/*  77 */     Insets p = (style() != null) ? style().padding() : Insets.xy(9, 6);
/*  78 */     int width = (class_310.method_1551()).field_1772.method_27525((class_5348)labelText()) + 80;
/*  79 */     for (T option : this.options)
/*  80 */       width = Math.max(width, (class_310.method_1551()).field_1772.method_27525((class_5348)componentText(option)) + 28); 
/*  81 */     Objects.requireNonNull((class_310.method_1551()).field_1772); return new UiSize(width + p.horizontal(), 9 + p.vertical());
/*     */   }
/*     */ 
/*     */   
/*     */   protected void draw(UiContext ctx) {
/*  86 */     ComponentStyle s = (style() != null) ? style() : ctx.theme().control();
/*  87 */     ctx.glass().surface(ctx.graphics(), bounds(), s.glass());
/*     */     
/*  89 */     if (hovered() && enabled()) {
/*  90 */       ctx.graphics().method_25294(bounds().x(), bounds().y(), bounds().right(), bounds().bottom(), s.hover());
/*     */     }
/*  92 */     Insets p = s.padding();
/*  93 */     Objects.requireNonNull(ctx.font()); int y = bounds().y() + Math.max(0, (bounds().height() - 9) / 2);
/*  94 */     ctx.graphics().method_51439(ctx.font(), labelText(), bounds().x() + p.left(), y, 
/*  95 */         enabled() ? s.text() : s.disabled(), false);
/*     */     
/*  97 */     class_2561 current = componentText((T)this.value.get());
/*  98 */     int x = bounds().right() - p.right() - ctx.font().method_27525((class_5348)current) - 10;
/*  99 */     ctx.graphics().method_51439(ctx.font(), current, x, y, enabled() ? s.secondaryText() : s.disabled(), false);
/* 100 */     ctx.graphics().method_51433(ctx.font(), this.open ? "▲" : "▼", bounds().right() - p.right() - 7, y, 
/* 101 */         enabled() ? s.secondaryText() : s.disabled(), false);
/*     */     
/* 103 */     if (!this.open) {
/*     */       return;
/*     */     }
/* 106 */     int row = rowHeight();
/* 107 */     UiBounds popup = new UiBounds(bounds().x(), bounds().bottom() + 2, bounds().width(), row * this.options.size());
/* 108 */     ctx.glass().surface(ctx.graphics(), popup, GlassPresets.STRONG);
/*     */     
/* 110 */     this.hoverIndex = optionAt(ctx.mouseX(), ctx.mouseY());
/* 111 */     for (int i = 0; i < this.options.size(); i++) {
/* 112 */       int oy = popup.y() + i * row;
/* 113 */       if (i == this.hoverIndex)
/* 114 */         ctx.graphics().method_25294(popup.x() + 1, oy, popup.right() - 1, oy + row, s.hover()); 
/* 115 */       if (this.options.get(i).equals(this.value.get())) {
/* 116 */         ctx.graphics().method_25294(popup.x() + 1, oy, popup.x() + 3, oy + row, s.accent());
/*     */       }
/* 118 */       class_2561 option = componentText(this.options.get(i));
/* 119 */       Objects.requireNonNull(ctx.font()); ctx.graphics().method_51439(ctx.font(), option, popup.x() + p.left(), oy + (row - 9) / 2, s
/* 120 */           .text(), false);
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   protected boolean hitTest(double x, double y) {
/* 126 */     if (bounds().contains(x, y))
/* 127 */       return true; 
/* 128 */     if (!this.open)
/* 129 */       return false; 
/* 130 */     return (x >= bounds().x() && x < bounds().right() && y >= (
/* 131 */       bounds().bottom() + 2) && y < (
/* 132 */       bounds().bottom() + 2 + rowHeight() * this.options.size()));
/*     */   }
/*     */ 
/*     */   
/*     */   protected boolean focusable() {
/* 137 */     return true;
/*     */   }
/*     */ 
/*     */   
/*     */   protected InputResult onMouseDown(double x, double y, int button, int modifiers, boolean doubled) {
/* 142 */     if (button != 0) {
/* 143 */       return InputResult.PASS;
/*     */     }
/* 145 */     if (bounds().contains(x, y)) {
/* 146 */       this.open = !this.open;
/* 147 */       return InputResult.CONSUME;
/*     */     } 
/*     */     
/* 150 */     int index = optionAt(x, y);
/* 151 */     if (this.open && index >= 0) {
/* 152 */       this.value.set(this.options.get(index));
/* 153 */       close();
/* 154 */       return InputResult.CONSUME;
/*     */     } 
/*     */     
/* 157 */     return InputResult.PASS;
/*     */   }
/*     */ 
/*     */   
/*     */   protected boolean onKeyPressed(class_11908 event) {
/* 162 */     if (event.comp_4795() == 256 && this.open) {
/* 163 */       close();
/* 164 */       return true;
/*     */     } 
/*     */     
/* 167 */     if (event.comp_4795() == 257 || event.comp_4795() == 32) {
/* 168 */       this.open = !this.open;
/* 169 */       return true;
/*     */     } 
/*     */     
/* 172 */     if (event.comp_4795() != 265 && event.comp_4795() != 264) {
/* 173 */       return false;
/*     */     }
/* 175 */     int index = this.options.indexOf(this.value.get());
/* 176 */     if (index < 0)
/* 177 */       index = 0; 
/* 178 */     index += (event.comp_4795() == 264) ? 1 : -1;
/* 179 */     if (index < 0)
/* 180 */       index = this.options.size() - 1; 
/* 181 */     if (index >= this.options.size())
/* 182 */       index = 0; 
/* 183 */     this.value.set(this.options.get(index));
/* 184 */     return true;
/*     */   }
/*     */ 
/*     */   
/*     */   protected void onClickOutside(double x, double y) {
/* 189 */     close();
/*     */   }
/*     */   
/*     */   private int optionAt(double x, double y) {
/* 193 */     if (!this.open || x < bounds().x() || x >= bounds().right())
/* 194 */       return -1; 
/* 195 */     int top = bounds().bottom() + 2;
/* 196 */     if (y < top)
/* 197 */       return -1; 
/* 198 */     int index = (int)((y - top) / rowHeight());
/* 199 */     return (index >= 0 && index < this.options.size()) ? index : -1;
/*     */   }
/*     */   
/*     */   private int rowHeight() {
/* 203 */     Insets p = (style() != null) ? style().padding() : Insets.xy(9, 6);
/* 204 */     Objects.requireNonNull((class_310.method_1551()).field_1772); return 9 + p.vertical();
/*     */   }
/*     */   
/*     */   private class_2561 labelText() {
/* 208 */     return (this.componentLabel == null) ? (class_2561)class_2561.method_43470(this.label) : this.componentLabel;
/*     */   }
/*     */   
/*     */   private class_2561 componentText(T option) {
/* 212 */     if (this.componentFormatter != null) {
/* 213 */       class_2561 class_25611 = this.componentFormatter.apply(option);
/* 214 */       if (class_25611 != null)
/* 215 */         return class_25611; 
/*     */     } 
/* 217 */     String value = this.formatter.apply(option);
/* 218 */     return (class_2561)class_2561.method_43470((value == null) ? "" : value);
/*     */   }
/*     */ }


/* Location:              C:\Users\rapha\Downloads\aurora.jar!\META-INF\jars\lqglass-0.2.5.jar!\dev\devswag\lqglas\\ui\components\Dropdown.class
 * Java compiler version: 21 (65.0)
 * JD-Core Version:       1.1.3
 */