/*    */ package dev.devswag.lqglass.ui.components;
/*    */ 
/*    */ import dev.devswag.lqglass.state.SettingValue;
/*    */ import dev.devswag.lqglass.ui.UiComponent;
/*    */ import dev.devswag.lqglass.ui.UiContainer;
/*    */ import dev.devswag.lqglass.ui.layout.Layouts;
/*    */ 
/*    */ public final class ExpandableSection
/*    */   extends UiContainer {
/*    */   private final UiComponent body;
/*    */   private final SettingValue<Boolean> expanded;
/*    */   
/*    */   public ExpandableSection(String title, UiComponent body) {
/* 14 */     this(title, body, new SettingValue(Boolean.valueOf(true)));
/*    */   }
/*    */   
/*    */   public ExpandableSection(String title, UiComponent body, SettingValue<Boolean> expanded) {
/* 18 */     super(Layouts.column(6));
/* 19 */     if (body == null || expanded == null) {
/* 20 */       throw new IllegalArgumentException("section");
/*    */     }
/* 22 */     this.body = body;
/* 23 */     this.expanded = expanded;
/* 24 */     add(new Button(() -> (Boolean.TRUE.equals(expanded.get()) ? "▼ " : "▶ ") + (Boolean.TRUE.equals(expanded.get()) ? "▼ " : "▶ "), this::toggle));
/* 25 */     add(body);
/* 26 */     body.visible(Boolean.TRUE.equals(expanded.get()));
/* 27 */     expanded.listen(value -> body.visible(Boolean.TRUE.equals(value)));
/*    */   }
/*    */   
/*    */   public SettingValue<Boolean> expanded() {
/* 31 */     return this.expanded;
/*    */   }
/*    */   
/*    */   public void toggle() {
/* 35 */     this.expanded.set(Boolean.valueOf(!Boolean.TRUE.equals(this.expanded.get())));
/* 36 */     this.body.visible(Boolean.TRUE.equals(this.expanded.get()));
/*    */   }
/*    */ }


/* Location:              C:\Users\rapha\Downloads\aurora.jar!\META-INF\jars\lqglass-0.2.5.jar!\dev\devswag\lqglas\\ui\components\ExpandableSection.class
 * Java compiler version: 21 (65.0)
 * JD-Core Version:       1.1.3
 */