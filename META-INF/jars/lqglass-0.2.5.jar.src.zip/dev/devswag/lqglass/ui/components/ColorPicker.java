/*     */ package dev.devswag.lqglass.ui.components;
/*     */ 
/*     */ import dev.devswag.lqglass.state.SettingValue;
/*     */ import dev.devswag.lqglass.style.ComponentStyle;
/*     */ import dev.devswag.lqglass.ui.InputResult;
/*     */ import dev.devswag.lqglass.ui.Insets;
/*     */ import dev.devswag.lqglass.ui.UiComponent;
/*     */ import dev.devswag.lqglass.ui.UiContext;
/*     */ import dev.devswag.lqglass.ui.UiSize;
/*     */ import java.util.Objects;
/*     */ import net.minecraft.class_310;
/*     */ 
/*     */ public final class ColorPicker
/*     */   extends UiComponent {
/*     */   private final SettingValue<Integer> value;
/*     */   private final String label;
/*  17 */   private int channel = -1;
/*     */   
/*     */   public ColorPicker(String label, SettingValue<Integer> value) {
/*  20 */     if (value == null)
/*  21 */       throw new IllegalArgumentException("value"); 
/*  22 */     this.label = (label == null) ? "" : label;
/*  23 */     this.value = value;
/*     */   }
/*     */   
/*     */   public SettingValue<Integer> value() {
/*  27 */     return this.value;
/*     */   }
/*     */ 
/*     */   
/*     */   protected UiSize measurePreferred(int maxWidth, int maxHeight) {
/*  32 */     Insets p = (style() != null) ? style().padding() : Insets.xy(9, 6);
/*  33 */     Objects.requireNonNull((class_310.method_1551()).field_1772); return new UiSize(180, 9 + 32 + p.vertical());
/*     */   }
/*     */ 
/*     */   
/*     */   protected void draw(UiContext ctx) {
/*  38 */     ComponentStyle s = (style() != null) ? style() : ctx.theme().control();
/*  39 */     ctx.glass().surface(ctx.graphics(), bounds(), s.glass());
/*     */     
/*  41 */     Insets p = s.padding();
/*  42 */     int color = color();
/*  43 */     int textY = bounds().y() + p.top();
/*  44 */     ctx.graphics().method_51433(ctx.font(), this.label, bounds().x() + p.left(), textY, enabled() ? s.text() : s.disabled(), false);
/*     */     
/*  46 */     String hex = String.format("#%08X", new Object[] { Integer.valueOf(color) });
/*  47 */     ctx.graphics().method_51433(ctx.font(), hex, bounds().right() - p.right() - ctx.font().method_1727(hex), textY, 
/*  48 */         enabled() ? s.secondaryText() : s.disabled(), false);
/*     */     
/*  50 */     int x1 = bounds().x() + p.left();
/*  51 */     int x2 = bounds().right() - p.right();
/*  52 */     Objects.requireNonNull(ctx.font()); int startY = textY + 9 + 5;
/*  53 */     int[] shifts = { 16, 8, 0, 24 };
/*  54 */     int[] bases = { -43691, -11141291, -11167233, -1 };
/*     */     
/*  56 */     for (int i = 0; i < 4; i++) {
/*  57 */       int y = startY + i * 6;
/*  58 */       int amount = color >>> shifts[i] & 0xFF;
/*  59 */       ctx.graphics().method_25294(x1, y, x2, y + 3, 861758576);
/*  60 */       int fill = x1 + Math.round(((x2 - x1) * amount) / 255.0F);
/*  61 */       ctx.graphics().method_25294(x1, y, fill, y + 3, bases[i]);
/*  62 */       ctx.graphics().method_25294(fill - 1, y - 1, fill + 2, y + 4, -1);
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   protected boolean focusable() {
/*  68 */     return true;
/*     */   }
/*     */ 
/*     */   
/*     */   protected InputResult onMouseDown(double x, double y, int button, int modifiers, boolean doubled) {
/*  73 */     if (button != 0) {
/*  74 */       return InputResult.PASS;
/*     */     }
/*  76 */     this.channel = channelAt(y);
/*  77 */     if (this.channel < 0) {
/*  78 */       return InputResult.PASS;
/*     */     }
/*  80 */     setChannel(this.channel, x);
/*  81 */     active(true);
/*  82 */     return InputResult.CAPTURE;
/*     */   }
/*     */ 
/*     */   
/*     */   protected boolean onMouseDrag(double x, double y, int button, double dx, double dy) {
/*  87 */     if (!active() || this.channel < 0 || button != 0)
/*  88 */       return false; 
/*  89 */     setChannel(this.channel, x);
/*  90 */     return true;
/*     */   }
/*     */ 
/*     */   
/*     */   protected boolean onMouseUp(double x, double y, int button, int modifiers) {
/*  95 */     if (!active() || button != 0)
/*  96 */       return false; 
/*  97 */     active(false);
/*  98 */     this.channel = -1;
/*  99 */     return true;
/*     */   }
/*     */   
/*     */   private int color() {
/* 103 */     Integer color = (Integer)this.value.get();
/* 104 */     return (color == null) ? -1 : color.intValue();
/*     */   }
/*     */   
/*     */   private int channelAt(double y) {
/* 108 */     Insets p = (style() != null) ? style().padding() : Insets.xy(9, 6);
/* 109 */     Objects.requireNonNull((class_310.method_1551()).field_1772); int start = bounds().y() + p.top() + 9 + 5;
/* 110 */     for (int i = 0; i < 4; i++) {
/* 111 */       int cy = start + i * 6;
/* 112 */       if (y >= (cy - 2) && y <= (cy + 5))
/* 113 */         return i; 
/*     */     } 
/* 115 */     return -1;
/*     */   }
/*     */   
/*     */   private void setChannel(int channel, double x) {
/* 119 */     Insets p = (style() != null) ? style().padding() : Insets.xy(9, 6);
/* 120 */     int x1 = bounds().x() + p.left();
/* 121 */     int x2 = bounds().right() - p.right();
/* 122 */     int amount = (x2 == x1) ? 0 : (int)Math.round(Math.max(0.0D, Math.min(1.0D, (x - x1) / (x2 - x1))) * 255.0D);
/* 123 */     int[] shifts = { 16, 8, 0, 24 };
/* 124 */     int shift = shifts[channel];
/* 125 */     int color = color();
/* 126 */     color = color & (255 << shift ^ 0xFFFFFFFF) | amount << shift;
/* 127 */     this.value.set(Integer.valueOf(color));
/*     */   }
/*     */ }


/* Location:              C:\Users\rapha\Downloads\aurora.jar!\META-INF\jars\lqglass-0.2.5.jar!\dev\devswag\lqglas\\ui\components\ColorPicker.class
 * Java compiler version: 21 (65.0)
 * JD-Core Version:       1.1.3
 */