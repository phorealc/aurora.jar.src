/*    */ package dev.devswag.lqglass.ui.components;
/*    */ 
/*    */ import dev.devswag.lqglass.ui.InputResult;
/*    */ import dev.devswag.lqglass.ui.Insets;
/*    */ import dev.devswag.lqglass.ui.Length;
/*    */ import dev.devswag.lqglass.ui.UiComponent;
/*    */ import dev.devswag.lqglass.ui.UiContainer;
/*    */ import dev.devswag.lqglass.ui.UiContext;
/*    */ import dev.devswag.lqglass.ui.layout.Layouts;
/*    */ import net.minecraft.class_11908;
/*    */ import net.minecraft.class_2561;
/*    */ 
/*    */ public final class GlassDialog
/*    */   extends UiContainer {
/*    */   private final Runnable cancelAction;
/*    */   private Runnable dismissAction = () -> {
/*    */     
/*    */     };
/*    */   
/*    */   public GlassDialog(class_2561 title, UiComponent body, class_2561 confirmLabel, Runnable confirmAction, Runnable cancelAction) {
/* 21 */     super(Layouts.stack(Layouts.Align.CENTER, Layouts.Align.CENTER));
/* 22 */     if (body == null)
/* 23 */       throw new IllegalArgumentException("body"); 
/* 24 */     focusScope(true);
/* 25 */     this
/* 26 */       .cancelAction = (cancelAction == null) ? (() -> {  }) : cancelAction;
/*    */     
/* 28 */     GlassPanel panel = new GlassPanel();
/* 29 */     panel.layout(Layouts.column(12));
/* 30 */     panel.layoutSpec().width(Length.px(380.0F));
/* 31 */     panel.layoutSpec().padding(Insets.xy(18, 16));
/* 32 */     panel.add(Label.from((title == null) ? (class_2561)class_2561.method_43473() : title).scale(1.15F));
/* 33 */     panel.add(body);
/*    */     
/* 35 */     UiContainer actions = new UiContainer(Layouts.row(8, Layouts.Align.CENTER, Layouts.Justify.END));
/* 36 */     Button cancel = Button.fromComponent((class_2561)class_2561.method_43470("Cancel"), this::cancel);
/* 37 */     Button confirm = Button.fromComponent((confirmLabel == null) ? (class_2561)class_2561.method_43470("OK") : confirmLabel, () -> {
/*    */           if (confirmAction != null)
/*    */             confirmAction.run(); 
/*    */           this.dismissAction.run();
/*    */         });
/* 42 */     actions.add(cancel);
/* 43 */     actions.add(confirm);
/* 44 */     panel.add((UiComponent)actions);
/* 45 */     add(panel);
/*    */   }
/*    */   
/*    */   public void onDismiss(Runnable action) {
/* 49 */     this
/* 50 */       .dismissAction = (action == null) ? (() -> {  }) : action;
/*    */   }
/*    */   
/*    */   public void cancel() {
/* 54 */     this.cancelAction.run();
/* 55 */     this.dismissAction.run();
/*    */   }
/*    */ 
/*    */   
/*    */   protected void draw(UiContext ctx) {
/* 60 */     ctx.graphics().method_25294(bounds().x(), bounds().y(), bounds().right(), bounds().bottom(), -1476395008);
/*    */   }
/*    */ 
/*    */   
/*    */   protected InputResult onMouseDown(double x, double y, int button, int modifiers, boolean doubled) {
/* 65 */     return InputResult.CONSUME;
/*    */   }
/*    */ 
/*    */   
/*    */   protected boolean onKeyPressed(class_11908 event) {
/* 70 */     if (event.comp_4795() != 256)
/* 71 */       return false; 
/* 72 */     cancel();
/* 73 */     return true;
/*    */   }
/*    */ }


/* Location:              C:\Users\rapha\Downloads\aurora.jar!\META-INF\jars\lqglass-0.2.5.jar!\dev\devswag\lqglas\\ui\components\GlassDialog.class
 * Java compiler version: 21 (65.0)
 * JD-Core Version:       1.1.3
 */