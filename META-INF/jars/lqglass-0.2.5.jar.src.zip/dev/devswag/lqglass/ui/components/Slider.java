/*     */ package dev.devswag.lqglass.ui.components;
/*     */ 
/*     */ import dev.devswag.lqglass.state.SettingValue;
/*     */ import dev.devswag.lqglass.style.ComponentStyle;
/*     */ import dev.devswag.lqglass.ui.InputResult;
/*     */ import dev.devswag.lqglass.ui.Insets;
/*     */ import dev.devswag.lqglass.ui.UiComponent;
/*     */ import dev.devswag.lqglass.ui.UiContext;
/*     */ import dev.devswag.lqglass.ui.UiSize;
/*     */ import java.text.DecimalFormat;
/*     */ import java.util.Objects;
/*     */ import net.minecraft.class_11908;
/*     */ import net.minecraft.class_2561;
/*     */ import net.minecraft.class_310;
/*     */ 
/*     */ 
/*     */ public class Slider
/*     */   extends UiComponent
/*     */ {
/*  20 */   private static final DecimalFormat FORMAT = new DecimalFormat("0.##");
/*     */   
/*     */   private final SettingValue<Double> value;
/*     */   private final double min;
/*     */   private final double max;
/*     */   private final double step;
/*     */   private String label;
/*     */   private class_2561 componentLabel;
/*     */   
/*     */   public Slider(String label, SettingValue<Double> value, double min, double max, double step) {
/*  30 */     if (value == null || !Double.isFinite(min) || !Double.isFinite(max) || max <= min)
/*  31 */       throw new IllegalArgumentException("slider"); 
/*  32 */     this.label = (label == null) ? "" : label;
/*  33 */     this.value = value;
/*  34 */     this.min = min;
/*  35 */     this.max = max;
/*  36 */     this.step = Math.max(0.0D, step);
/*     */   }
/*     */   
/*     */   public SettingValue<Double> value() {
/*  40 */     return this.value;
/*     */   }
/*     */   
/*     */   public Slider componentLabel(class_2561 label) {
/*  44 */     this.componentLabel = label;
/*  45 */     invalidateLayout();
/*  46 */     return this;
/*     */   }
/*     */ 
/*     */   
/*     */   public class_2561 narration() {
/*  51 */     class_2561 accessible = super.narration();
/*  52 */     return (accessible == null) ? 
/*  53 */       (class_2561)class_2561.method_43470(labelText().getString() + ": " + labelText().getString()) : 
/*  54 */       accessible;
/*     */   }
/*     */ 
/*     */   
/*     */   protected UiSize measurePreferred(int maxWidth, int maxHeight) {
/*  59 */     Insets p = (style() != null) ? style().padding() : Insets.xy(9, 6);
/*  60 */     Objects.requireNonNull((class_310.method_1551()).field_1772); return new UiSize(150, 9 + 16 + p.vertical());
/*     */   }
/*     */ 
/*     */   
/*     */   protected void draw(UiContext ctx) {
/*  65 */     ComponentStyle s = (style() != null) ? style() : ctx.theme().control();
/*  66 */     ctx.glass().surface(ctx.graphics(), bounds(), s.glass());
/*  67 */     if (hovered() && enabled()) {
/*  68 */       ctx.graphics().method_25294(bounds().x(), bounds().y(), bounds().right(), bounds().bottom(), s.hover());
/*     */     }
/*  70 */     Insets p = s.padding();
/*  71 */     String right = FORMAT.format(this.value.get());
/*  72 */     int textY = bounds().y() + p.top();
/*  73 */     ctx.graphics().method_51439(ctx.font(), labelText(), bounds().x() + p.left(), textY, 
/*  74 */         enabled() ? s.text() : s.disabled(), false);
/*  75 */     ctx.graphics().method_51433(ctx.font(), right, bounds().right() - p.right() - ctx.font().method_1727(right), textY, 
/*  76 */         enabled() ? s.secondaryText() : s.disabled(), false);
/*     */     
/*  78 */     int x1 = bounds().x() + p.left();
/*  79 */     int x2 = bounds().right() - p.right();
/*  80 */     int y = bounds().bottom() - p.bottom() - 5;
/*  81 */     ctx.graphics().method_25294(x1, y, x2, y + 3, 1717396592);
/*     */     
/*  83 */     double t = normalized(((Double)this.value.get()).doubleValue());
/*  84 */     int fill = x1 + (int)Math.round((x2 - x1) * t);
/*  85 */     ctx.graphics().method_25294(x1, y, fill, y + 3, s.accent());
/*  86 */     ctx.graphics().method_25294(fill - 2, y - 3, fill + 3, y + 6, enabled() ? -1 : s.disabled());
/*     */   }
/*     */ 
/*     */   
/*     */   protected boolean focusable() {
/*  91 */     return true;
/*     */   }
/*     */ 
/*     */   
/*     */   protected InputResult onMouseDown(double x, double y, int button, int modifiers, boolean doubled) {
/*  96 */     if (button != 0)
/*  97 */       return InputResult.PASS; 
/*  98 */     setFromMouse(x);
/*  99 */     active(true);
/* 100 */     return InputResult.CAPTURE;
/*     */   }
/*     */ 
/*     */   
/*     */   protected boolean onMouseDrag(double x, double y, int button, double dx, double dy) {
/* 105 */     if (!active() || button != 0)
/* 106 */       return false; 
/* 107 */     setFromMouse(x);
/* 108 */     return true;
/*     */   }
/*     */ 
/*     */   
/*     */   protected boolean onMouseUp(double x, double y, int button, int modifiers) {
/* 113 */     if (!active() || button != 0)
/* 114 */       return false; 
/* 115 */     active(false);
/* 116 */     return true;
/*     */   }
/*     */ 
/*     */   
/*     */   protected boolean onKeyPressed(class_11908 event) {
/* 121 */     if (event.comp_4795() != 263 && event.comp_4795() != 262)
/* 122 */       return false; 
/* 123 */     double amount = (this.step > 0.0D) ? this.step : ((this.max - this.min) / 100.0D);
/* 124 */     this.value.set(Double.valueOf(snap(((Double)this.value.get()).doubleValue() + ((event.comp_4795() == 262) ? amount : -amount))));
/* 125 */     return true;
/*     */   }
/*     */   
/*     */   private void setFromMouse(double mouseX) {
/* 129 */     ComponentStyle s = style();
/* 130 */     Insets p = (s != null) ? s.padding() : Insets.xy(9, 6);
/* 131 */     int x1 = bounds().x() + p.left();
/* 132 */     int x2 = bounds().right() - p.right();
/* 133 */     double t = (x2 == x1) ? 0.0D : ((mouseX - x1) / (x2 - x1));
/* 134 */     this.value.set(Double.valueOf(snap(this.min + Math.max(0.0D, Math.min(1.0D, t)) * (this.max - this.min))));
/*     */   }
/*     */   
/*     */   private double snap(double value) {
/* 138 */     double out = Math.max(this.min, Math.min(this.max, value));
/* 139 */     if (this.step > 0.0D)
/* 140 */       out = this.min + Math.round((out - this.min) / this.step) * this.step; 
/* 141 */     return Math.max(this.min, Math.min(this.max, out));
/*     */   }
/*     */   
/*     */   private double normalized(double value) {
/* 145 */     return Math.max(0.0D, Math.min(1.0D, (value - this.min) / (this.max - this.min)));
/*     */   }
/*     */   
/*     */   private class_2561 labelText() {
/* 149 */     return (this.componentLabel == null) ? (class_2561)class_2561.method_43470(this.label) : this.componentLabel;
/*     */   }
/*     */ }


/* Location:              C:\Users\rapha\Downloads\aurora.jar!\META-INF\jars\lqglass-0.2.5.jar!\dev\devswag\lqglas\\ui\components\Slider.class
 * Java compiler version: 21 (65.0)
 * JD-Core Version:       1.1.3
 */