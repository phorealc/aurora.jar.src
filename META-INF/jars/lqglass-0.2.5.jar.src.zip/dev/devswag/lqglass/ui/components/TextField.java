/*     */ package dev.devswag.lqglass.ui.components;
/*     */ 
/*     */ import dev.devswag.lqglass.state.SettingValue;
/*     */ import dev.devswag.lqglass.style.ComponentStyle;
/*     */ import dev.devswag.lqglass.ui.InputResult;
/*     */ import dev.devswag.lqglass.ui.Insets;
/*     */ import dev.devswag.lqglass.ui.UiComponent;
/*     */ import dev.devswag.lqglass.ui.UiContext;
/*     */ import dev.devswag.lqglass.ui.UiSize;
/*     */ import java.util.Objects;
/*     */ import net.minecraft.class_11905;
/*     */ import net.minecraft.class_11908;
/*     */ import net.minecraft.class_310;
/*     */ import net.minecraft.class_327;
/*     */ 
/*     */ 
/*     */ public class TextField
/*     */   extends UiComponent
/*     */ {
/*     */   private final SettingValue<String> value;
/*  21 */   private String placeholder = "";
/*     */   private int cursor;
/*     */   private int anchor;
/*     */   private int scroll;
/*  25 */   private int maxLength = 1024;
/*     */   
/*     */   public TextField(SettingValue<String> value) {
/*  28 */     if (value == null)
/*  29 */       throw new IllegalArgumentException("value"); 
/*  30 */     this.value = value;
/*  31 */     String text = text();
/*  32 */     this.cursor = text.length();
/*  33 */     this.anchor = this.cursor;
/*  34 */     clip(true);
/*     */   }
/*     */   
/*     */   public TextField placeholder(String placeholder) {
/*  38 */     this.placeholder = (placeholder == null) ? "" : placeholder;
/*  39 */     return this;
/*     */   }
/*     */   
/*     */   public TextField maxLength(int maxLength) {
/*  43 */     this.maxLength = Math.max(0, maxLength);
/*  44 */     trimToMax();
/*  45 */     return this;
/*     */   }
/*     */   
/*     */   public SettingValue<String> value() {
/*  49 */     return this.value;
/*     */   }
/*     */   
/*     */   public int cursor() {
/*  53 */     return this.cursor;
/*     */   }
/*     */   
/*     */   public boolean hasSelection() {
/*  57 */     return (this.cursor != this.anchor);
/*     */   }
/*     */   
/*     */   public String selectedText() {
/*  61 */     if (!hasSelection())
/*  62 */       return ""; 
/*  63 */     int from = Math.min(this.cursor, this.anchor);
/*  64 */     int to = Math.max(this.cursor, this.anchor);
/*  65 */     return text().substring(from, to);
/*     */   }
/*     */ 
/*     */   
/*     */   protected UiSize measurePreferred(int maxWidth, int maxHeight) {
/*  70 */     Insets p = (style() != null) ? style().padding() : Insets.xy(9, 6);
/*  71 */     Objects.requireNonNull((class_310.method_1551()).field_1772); return new UiSize(140, 9 + p.vertical());
/*     */   }
/*     */ 
/*     */   
/*     */   protected void draw(UiContext ctx) {
/*  76 */     ComponentStyle s = (style() != null) ? style() : ctx.theme().control();
/*  77 */     ctx.glass().surface(ctx.graphics(), bounds(), s.glass());
/*     */     
/*  79 */     if (focused()) {
/*  80 */       int c = s.accent();
/*  81 */       ctx.graphics().method_25294(bounds().x(), bounds().bottom() - 1, bounds().right(), bounds().bottom(), c);
/*  82 */     } else if (hovered() && enabled()) {
/*  83 */       ctx.graphics().method_25294(bounds().x(), bounds().y(), bounds().right(), bounds().bottom(), s.hover());
/*     */     } 
/*     */     
/*  86 */     Insets p = s.padding();
/*  87 */     int left = bounds().x() + p.left();
/*  88 */     int right = bounds().right() - p.right();
/*  89 */     Objects.requireNonNull(ctx.font()); int y = bounds().y() + Math.max(0, (bounds().height() - 9) / 2);
/*  90 */     String text = text();
/*     */     
/*  92 */     ensureCursorVisible(ctx.font(), Math.max(1, right - left));
/*  93 */     String visible = text.substring(this.scroll);
/*  94 */     visible = ctx.font().method_27523(visible, Math.max(1, right - left));
/*     */     
/*  96 */     if (text.isEmpty() && !focused() && !this.placeholder.isEmpty()) {
/*  97 */       ctx.graphics().method_51433(ctx.font(), this.placeholder, left, y, s.secondaryText(), false);
/*     */       
/*     */       return;
/*     */     } 
/* 101 */     if (hasSelection()) {
/* 102 */       int from = Math.max(this.scroll, Math.min(this.cursor, this.anchor));
/* 103 */       int to = Math.max(this.scroll, Math.max(this.cursor, this.anchor));
/* 104 */       int visibleEnd = this.scroll + visible.length();
/* 105 */       from = Math.min(from, visibleEnd);
/* 106 */       to = Math.min(to, visibleEnd);
/* 107 */       if (to > from) {
/* 108 */         int sx = left + ctx.font().method_1727(text.substring(this.scroll, from));
/* 109 */         int ex = left + ctx.font().method_1727(text.substring(this.scroll, to));
/* 110 */         Objects.requireNonNull(ctx.font()); ctx.graphics().method_25294(sx, y - 1, ex, y + 9 + 1, 1717210367);
/*     */       } 
/*     */     } 
/*     */     
/* 114 */     ctx.graphics().method_51433(ctx.font(), visible, left, y, enabled() ? s.text() : s.disabled(), false);
/*     */     
/* 116 */     if (focused() && enabled() && (ctx.now() / 500L & 0x1L) == 0L) {
/* 117 */       int shownCursor = Math.max(this.scroll, Math.min(this.cursor, this.scroll + visible.length()));
/* 118 */       int cx = left + ctx.font().method_1727(text.substring(this.scroll, shownCursor));
/* 119 */       Objects.requireNonNull(ctx.font()); ctx.graphics().method_25294(cx, y - 1, cx + 1, y + 9 + 1, s.accent());
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   protected boolean focusable() {
/* 125 */     return true;
/*     */   }
/*     */ 
/*     */   
/*     */   protected InputResult onMouseDown(double x, double y, int button, int modifiers, boolean doubled) {
/* 130 */     if (button != 0) {
/* 131 */       return InputResult.PASS;
/*     */     }
/* 133 */     int next = cursorAt(x);
/* 134 */     this.cursor = next;
/* 135 */     if ((modifiers & 0x1) == 0) {
/* 136 */       this.anchor = this.cursor;
/*     */     }
/* 138 */     if (doubled) {
/* 139 */       selectWord(this.cursor);
/*     */     }
/* 141 */     active(true);
/* 142 */     return InputResult.CAPTURE;
/*     */   }
/*     */ 
/*     */   
/*     */   protected boolean onMouseDrag(double x, double y, int button, double dx, double dy) {
/* 147 */     if (!active() || button != 0)
/* 148 */       return false; 
/* 149 */     this.cursor = cursorAt(x);
/* 150 */     return true;
/*     */   }
/*     */ 
/*     */   
/*     */   protected boolean onMouseUp(double x, double y, int button, int modifiers) {
/* 155 */     if (!active() || button != 0)
/* 156 */       return false; 
/* 157 */     active(false);
/* 158 */     return true;
/*     */   }
/*     */ 
/*     */   
/*     */   protected boolean onCharTyped(class_11905 event) {
/* 163 */     if (!enabled() || !event.method_74227())
/* 164 */       return false; 
/* 165 */     insert(event.method_74226());
/* 166 */     return true;
/*     */   }
/*     */ 
/*     */   
/*     */   protected boolean onKeyPressed(class_11908 event) {
/* 171 */     if (!enabled()) {
/* 172 */       return false;
/*     */     }
/* 174 */     int key = event.comp_4795();
/* 175 */     boolean shift = ((event.comp_4797() & 0x1) != 0);
/* 176 */     boolean control = ((event.comp_4797() & 0xA) != 0);
/*     */     
/* 178 */     if (control && key == 65) {
/* 179 */       this.anchor = 0;
/* 180 */       this.cursor = text().length();
/* 181 */       return true;
/*     */     } 
/*     */     
/* 184 */     if (control && key == 67) {
/* 185 */       if (hasSelection())
/* 186 */         (class_310.method_1551()).field_1774.method_1455(selectedText()); 
/* 187 */       return true;
/*     */     } 
/*     */     
/* 190 */     if (control && key == 88) {
/* 191 */       if (hasSelection()) {
/* 192 */         (class_310.method_1551()).field_1774.method_1455(selectedText());
/* 193 */         deleteSelection();
/*     */       } 
/* 195 */       return true;
/*     */     } 
/*     */     
/* 198 */     if (control && key == 86) {
/* 199 */       insert((class_310.method_1551()).field_1774.method_1460());
/* 200 */       return true;
/*     */     } 
/*     */     
/* 203 */     if (key == 259) {
/* 204 */       backspace();
/* 205 */       return true;
/*     */     } 
/*     */     
/* 208 */     if (key == 261) {
/* 209 */       deleteForward();
/* 210 */       return true;
/*     */     } 
/*     */     
/* 213 */     if (key == 263) {
/* 214 */       moveCursor(control ? previousWord(this.cursor) : previous(this.cursor), shift);
/* 215 */       return true;
/*     */     } 
/*     */     
/* 218 */     if (key == 262) {
/* 219 */       moveCursor(control ? nextWord(this.cursor) : next(this.cursor), shift);
/* 220 */       return true;
/*     */     } 
/*     */     
/* 223 */     if (key == 268) {
/* 224 */       moveCursor(0, shift);
/* 225 */       return true;
/*     */     } 
/*     */     
/* 228 */     if (key == 269) {
/* 229 */       moveCursor(text().length(), shift);
/* 230 */       return true;
/*     */     } 
/*     */     
/* 233 */     return false;
/*     */   }
/*     */   
/*     */   private void insert(String insert) {
/* 237 */     if (insert == null || insert.isEmpty()) {
/*     */       return;
/*     */     }
/* 240 */     String text = text();
/* 241 */     int from = Math.min(this.cursor, this.anchor);
/* 242 */     int to = Math.max(this.cursor, this.anchor);
/* 243 */     int room = Math.max(0, this.maxLength - text.length() - to - from);
/* 244 */     if (room == 0) {
/*     */       return;
/*     */     }
/* 247 */     if (insert.length() > room) {
/* 248 */       insert = insert.substring(0, room);
/*     */     }
/* 250 */     String next = text.substring(0, from) + text.substring(0, from) + insert;
/* 251 */     if (!this.value.set(next)) {
/*     */       return;
/*     */     }
/* 254 */     this.cursor = from + insert.length();
/* 255 */     this.anchor = this.cursor;
/*     */   }
/*     */   
/*     */   private void backspace() {
/* 259 */     if (deleteSelection())
/*     */       return; 
/* 261 */     if (this.cursor <= 0) {
/*     */       return;
/*     */     }
/* 264 */     int from = previous(this.cursor);
/* 265 */     replace(from, this.cursor, "");
/* 266 */     this.cursor = from;
/* 267 */     this.anchor = this.cursor;
/*     */   }
/*     */   
/*     */   private void deleteForward() {
/* 271 */     if (deleteSelection())
/*     */       return; 
/* 273 */     if (this.cursor >= text().length()) {
/*     */       return;
/*     */     }
/* 276 */     replace(this.cursor, next(this.cursor), "");
/* 277 */     this.anchor = this.cursor;
/*     */   }
/*     */   
/*     */   private boolean deleteSelection() {
/* 281 */     if (!hasSelection()) {
/* 282 */       return false;
/*     */     }
/* 284 */     int from = Math.min(this.cursor, this.anchor);
/* 285 */     int to = Math.max(this.cursor, this.anchor);
/* 286 */     if (!replace(from, to, "")) {
/* 287 */       return false;
/*     */     }
/* 289 */     this.cursor = from;
/* 290 */     this.anchor = from;
/* 291 */     return true;
/*     */   }
/*     */   
/*     */   private boolean replace(int from, int to, String replacement) {
/* 295 */     String text = text();
/* 296 */     return this.value.set(text.substring(0, from) + text.substring(0, from) + replacement);
/*     */   }
/*     */   
/*     */   private void moveCursor(int next, boolean keepSelection) {
/* 300 */     this.cursor = Math.max(0, Math.min(text().length(), next));
/* 301 */     if (!keepSelection)
/* 302 */       this.anchor = this.cursor; 
/*     */   }
/*     */   
/*     */   private int cursorAt(double mouseX) {
/* 306 */     class_327 font = (class_310.method_1551()).field_1772;
/* 307 */     Insets p = (style() != null) ? style().padding() : Insets.xy(9, 6);
/* 308 */     int left = bounds().x() + p.left();
/* 309 */     double target = Math.max(0.0D, mouseX - left);
/* 310 */     String text = text();
/*     */     
/* 312 */     int index = this.scroll;
/* 313 */     int lastWidth = 0;
/* 314 */     while (index < text.length()) {
/* 315 */       int next = next(index);
/* 316 */       int width = font.method_1727(text.substring(this.scroll, next));
/* 317 */       if (target < (lastWidth + width) / 2.0D)
/*     */         break; 
/* 319 */       lastWidth = width;
/* 320 */       index = next;
/*     */     } 
/* 322 */     return index;
/*     */   }
/*     */   
/*     */   private void ensureCursorVisible(class_327 font, int width) {
/* 326 */     String text = text();
/* 327 */     this.scroll = Math.min(this.scroll, text.length());
/*     */     
/* 329 */     if (this.cursor < this.scroll) {
/* 330 */       this.scroll = this.cursor;
/*     */     }
/* 332 */     while (this.scroll < this.cursor && font.method_1727(text.substring(this.scroll, this.cursor)) > width) {
/* 333 */       this.scroll = next(this.scroll);
/*     */     }
/* 335 */     while (this.scroll > 0) {
/* 336 */       int previous = previous(this.scroll);
/* 337 */       if (font.method_1727(text.substring(previous, this.cursor)) > width)
/*     */         break; 
/* 339 */       this.scroll = previous;
/*     */     } 
/*     */   }
/*     */   
/*     */   private void selectWord(int at) {
/* 344 */     String text = text();
/* 345 */     if (text.isEmpty()) {
/* 346 */       this.cursor = this.anchor = 0;
/*     */       
/*     */       return;
/*     */     } 
/* 350 */     int p = Math.min(Math.max(0, at), text.length());
/* 351 */     int start = p;
/* 352 */     int end = p;
/*     */     
/* 354 */     while (start > 0 && !Character.isWhitespace(text.charAt(start - 1)))
/* 355 */       start--; 
/* 356 */     while (end < text.length() && !Character.isWhitespace(text.charAt(end))) {
/* 357 */       end++;
/*     */     }
/* 359 */     this.anchor = start;
/* 360 */     this.cursor = end;
/*     */   }
/*     */   
/*     */   private int previousWord(int at) {
/* 364 */     String text = text();
/* 365 */     int p = Math.max(0, at);
/* 366 */     while (p > 0 && Character.isWhitespace(text.charAt(p - 1)))
/* 367 */       p--; 
/* 368 */     while (p > 0 && !Character.isWhitespace(text.charAt(p - 1)))
/* 369 */       p--; 
/* 370 */     return p;
/*     */   }
/*     */   
/*     */   private int nextWord(int at) {
/* 374 */     String text = text();
/* 375 */     int p = Math.min(text.length(), at);
/* 376 */     while (p < text.length() && !Character.isWhitespace(text.charAt(p)))
/* 377 */       p++; 
/* 378 */     while (p < text.length() && Character.isWhitespace(text.charAt(p)))
/* 379 */       p++; 
/* 380 */     return p;
/*     */   }
/*     */   
/*     */   private int previous(int index) {
/* 384 */     if (index <= 0)
/* 385 */       return 0; 
/* 386 */     return text().offsetByCodePoints(index, -1);
/*     */   }
/*     */   
/*     */   private int next(int index) {
/* 390 */     String text = text();
/* 391 */     if (index >= text.length())
/* 392 */       return text.length(); 
/* 393 */     return text.offsetByCodePoints(index, 1);
/*     */   }
/*     */   
/*     */   private void trimToMax() {
/* 397 */     String text = text();
/* 398 */     if (text.length() <= this.maxLength)
/*     */       return; 
/* 400 */     this.value.set(text.substring(0, this.maxLength));
/* 401 */     this.cursor = Math.min(this.cursor, this.maxLength);
/* 402 */     this.anchor = Math.min(this.anchor, this.maxLength);
/*     */   }
/*     */   
/*     */   private String text() {
/* 406 */     String text = (String)this.value.get();
/* 407 */     return (text == null) ? "" : text;
/*     */   }
/*     */ }


/* Location:              C:\Users\rapha\Downloads\aurora.jar!\META-INF\jars\lqglass-0.2.5.jar!\dev\devswag\lqglas\\ui\components\TextField.class
 * Java compiler version: 21 (65.0)
 * JD-Core Version:       1.1.3
 */