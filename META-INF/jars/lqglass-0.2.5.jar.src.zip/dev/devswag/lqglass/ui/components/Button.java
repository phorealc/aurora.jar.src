/*     */ package dev.devswag.lqglass.ui.components;
/*     */ 
/*     */ import dev.devswag.lqglass.style.ComponentStyle;
/*     */ import dev.devswag.lqglass.ui.InputResult;
/*     */ import dev.devswag.lqglass.ui.Insets;
/*     */ import dev.devswag.lqglass.ui.UiComponent;
/*     */ import dev.devswag.lqglass.ui.UiContext;
/*     */ import dev.devswag.lqglass.ui.UiSize;
/*     */ import java.util.Objects;
/*     */ import java.util.function.Supplier;
/*     */ import net.minecraft.class_11908;
/*     */ import net.minecraft.class_2561;
/*     */ import net.minecraft.class_310;
/*     */ import net.minecraft.class_5348;
/*     */ 
/*     */ public class Button
/*     */   extends UiComponent {
/*     */   private Supplier<String> label;
/*     */   private Supplier<class_2561> component;
/*     */   private Runnable action;
/*     */   
/*     */   public Button(String label, Runnable action) {
/*  23 */     this(() -> (label == null) ? "" : label, action);
/*     */   }
/*     */   
/*     */   public Button(Supplier<String> label, Runnable action) {
/*  27 */     this.label = (label == null) ? (() -> "") : label;
/*  28 */     this
/*  29 */       .action = (action == null) ? (() -> {  }) : action;
/*     */   }
/*     */   
/*     */   public static Button fromComponent(class_2561 label, Runnable action) {
/*  33 */     return (new Button("", action)).component(label);
/*     */   }
/*     */   
/*     */   public Button label(String label) {
/*  37 */     this.component = null;
/*  38 */     this.label = (() -> (label == null) ? "" : label);
/*  39 */     invalidateLayout();
/*  40 */     return this;
/*     */   }
/*     */   
/*     */   public Button component(class_2561 label) {
/*  44 */     this.component = (() -> (label == null) ? (class_2561)class_2561.method_43473() : label);
/*  45 */     invalidateLayout();
/*  46 */     return this;
/*     */   }
/*     */   
/*     */   public Button componentSupplier(Supplier<class_2561> label) {
/*  50 */     this.component = (label == null) ? (() -> class_2561.method_43473()) : label;
/*  51 */     invalidateLayout();
/*  52 */     return this;
/*     */   }
/*     */   
/*     */   public Button action(Runnable action) {
/*  56 */     this
/*  57 */       .action = (action == null) ? (() -> {  }) : action;
/*  58 */     return this;
/*     */   }
/*     */ 
/*     */   
/*     */   public class_2561 narration() {
/*  63 */     class_2561 accessible = super.narration();
/*  64 */     return (accessible == null) ? valueComponent() : accessible;
/*     */   }
/*     */ 
/*     */   
/*     */   protected UiSize measurePreferred(int maxWidth, int maxHeight) {
/*  69 */     Insets p = (style() != null) ? style().padding() : Insets.xy(9, 6);
/*     */     
/*  71 */     Objects.requireNonNull((class_310.method_1551()).field_1772); return new UiSize((class_310.method_1551()).field_1772.method_27525((class_5348)valueComponent()) + p.horizontal(), 9 + p.vertical());
/*     */   }
/*     */ 
/*     */   
/*     */   protected void draw(UiContext ctx) {
/*  76 */     ComponentStyle s = (style() != null) ? style() : ctx.theme().control();
/*  77 */     ctx.glass().surface(ctx.graphics(), bounds(), s.glass());
/*     */     
/*  79 */     if (active() && enabled()) {
/*  80 */       ctx.graphics().method_25294(bounds().x(), bounds().y(), bounds().right(), bounds().bottom(), s.pressed());
/*  81 */     } else if (hovered() && enabled()) {
/*  82 */       ctx.graphics().method_25294(bounds().x(), bounds().y(), bounds().right(), bounds().bottom(), s.hover());
/*     */     } 
/*  84 */     if (focused() && enabled()) {
/*  85 */       int c = s.accent();
/*  86 */       ctx.graphics().method_25294(bounds().x(), bounds().y(), bounds().right(), bounds().y() + 1, c);
/*  87 */       ctx.graphics().method_25294(bounds().x(), bounds().bottom() - 1, bounds().right(), bounds().bottom(), c);
/*     */     } 
/*     */     
/*  90 */     int color = enabled() ? s.text() : s.disabled();
/*     */     
/*  92 */     Objects.requireNonNull(ctx.font()); ctx.graphics().method_27534(ctx.font(), valueComponent(), bounds().x() + bounds().width() / 2, bounds().y() + Math.max(0, (bounds().height() - 9) / 2), color);
/*     */   }
/*     */ 
/*     */   
/*     */   protected boolean focusable() {
/*  97 */     return true;
/*     */   }
/*     */ 
/*     */   
/*     */   protected InputResult onMouseDown(double x, double y, int button, int modifiers, boolean doubled) {
/* 102 */     if (button != 0)
/* 103 */       return InputResult.PASS; 
/* 104 */     active(true);
/* 105 */     return InputResult.CAPTURE;
/*     */   }
/*     */ 
/*     */   
/*     */   protected boolean onMouseUp(double x, double y, int button, int modifiers) {
/* 110 */     if (button != 0 || !active()) {
/* 111 */       return false;
/*     */     }
/* 113 */     active(false);
/* 114 */     if (bounds().contains(x, y) && enabled())
/* 115 */       this.action.run(); 
/* 116 */     return true;
/*     */   }
/*     */ 
/*     */   
/*     */   protected boolean onKeyPressed(class_11908 event) {
/* 121 */     if (event.comp_4795() != 257 && event
/* 122 */       .comp_4795() != 335 && event
/* 123 */       .comp_4795() != 32) {
/* 124 */       return false;
/*     */     }
/* 126 */     if (enabled())
/* 127 */       this.action.run(); 
/* 128 */     return true;
/*     */   }
/*     */   
/*     */   private class_2561 valueComponent() {
/* 132 */     if (this.component != null) {
/* 133 */       class_2561 class_2561 = this.component.get();
/* 134 */       return (class_2561 == null) ? (class_2561)class_2561.method_43473() : class_2561;
/*     */     } 
/* 136 */     String value = this.label.get();
/* 137 */     return (class_2561)class_2561.method_43470((value == null) ? "" : value);
/*     */   }
/*     */ }


/* Location:              C:\Users\rapha\Downloads\aurora.jar!\META-INF\jars\lqglass-0.2.5.jar!\dev\devswag\lqglas\\ui\components\Button.class
 * Java compiler version: 21 (65.0)
 * JD-Core Version:       1.1.3
 */