/*    */ package dev.devswag.lqglass.ui.components;
/*    */ 
/*    */ import dev.devswag.lqglass.ui.UiComponent;
/*    */ import dev.devswag.lqglass.ui.UiContainer;
/*    */ import dev.devswag.lqglass.ui.layout.Layouts;
/*    */ import java.util.ArrayList;
/*    */ import java.util.List;
/*    */ import net.minecraft.class_11908;
/*    */ 
/*    */ 
/*    */ public final class LayerStack
/*    */   extends UiContainer
/*    */ {
/* 14 */   private final UiContainer overlays = new UiContainer(Layouts.stack(Layouts.Align.STRETCH, Layouts.Align.STRETCH));
/* 15 */   private final List<UiComponent> modals = new ArrayList<>();
/*    */   
/*    */   public LayerStack(UiComponent root) {
/* 18 */     super(Layouts.stack(Layouts.Align.STRETCH, Layouts.Align.STRETCH));
/* 19 */     if (root == null) {
/* 20 */       throw new IllegalArgumentException("root");
/*    */     }
/* 22 */     UiContainer base = new UiContainer(Layouts.stack(Layouts.Align.STRETCH, Layouts.Align.STRETCH));
/* 23 */     base.add(root);
/* 24 */     add((UiComponent)base);
/* 25 */     add((UiComponent)this.overlays);
/*    */   }
/*    */   
/*    */   public LayerStack show(UiComponent overlay) {
/* 29 */     this.overlays.add(overlay);
/* 30 */     return this;
/*    */   }
/*    */   
/*    */   public LayerStack showModal(UiComponent modal) {
/* 34 */     if (modal == null)
/* 35 */       throw new IllegalArgumentException("modal"); 
/* 36 */     modal.focusScope(true);
/* 37 */     if (!this.modals.contains(modal))
/* 38 */       this.modals.add(modal); 
/* 39 */     show(modal);
/* 40 */     return this;
/*    */   }
/*    */   
/*    */   public GlassDialog showDialog(GlassDialog dialog) {
/* 44 */     if (dialog == null)
/* 45 */       throw new IllegalArgumentException("dialog"); 
/* 46 */     dialog.onDismiss(() -> dismiss((UiComponent)dialog));
/* 47 */     showModal((UiComponent)dialog);
/* 48 */     return dialog;
/*    */   }
/*    */   
/*    */   public LayerStack dismiss(UiComponent overlay) {
/* 52 */     this.overlays.remove(overlay);
/* 53 */     if (overlay != null) {
/* 54 */       overlay.focusScope(false);
/* 55 */       this.modals.remove(overlay);
/*    */     } 
/* 57 */     return this;
/*    */   }
/*    */   
/*    */   public void dismissTop() {
/* 61 */     if (!this.modals.isEmpty()) {
/* 62 */       dismiss(this.modals.get(this.modals.size() - 1));
/*    */       return;
/*    */     } 
/* 65 */     int size = this.overlays.children().size();
/* 66 */     if (size > 0)
/* 67 */       dismiss(this.overlays.children().get(size - 1)); 
/*    */   }
/*    */   
/*    */   public void clearOverlays() {
/* 71 */     for (UiComponent modal : this.modals)
/* 72 */       modal.focusScope(false); 
/* 73 */     this.modals.clear();
/* 74 */     this.overlays.clear();
/*    */   }
/*    */ 
/*    */   
/*    */   protected boolean onKeyPressed(class_11908 event) {
/* 79 */     if (event.comp_4795() != 256 || this.modals.isEmpty())
/* 80 */       return false; 
/* 81 */     dismissTop();
/* 82 */     return true;
/*    */   }
/*    */ }


/* Location:              C:\Users\rapha\Downloads\aurora.jar!\META-INF\jars\lqglass-0.2.5.jar!\dev\devswag\lqglas\\ui\components\LayerStack.class
 * Java compiler version: 21 (65.0)
 * JD-Core Version:       1.1.3
 */