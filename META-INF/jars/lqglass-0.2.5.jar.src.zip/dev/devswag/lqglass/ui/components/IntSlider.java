/*     */ package dev.devswag.lqglass.ui.components;
/*     */ 
/*     */ import dev.devswag.lqglass.state.SettingValue;
/*     */ import dev.devswag.lqglass.style.ComponentStyle;
/*     */ import dev.devswag.lqglass.ui.InputResult;
/*     */ import dev.devswag.lqglass.ui.Insets;
/*     */ import dev.devswag.lqglass.ui.UiComponent;
/*     */ import dev.devswag.lqglass.ui.UiContext;
/*     */ import dev.devswag.lqglass.ui.UiSize;
/*     */ import java.util.Objects;
/*     */ import net.minecraft.class_11908;
/*     */ import net.minecraft.class_310;
/*     */ 
/*     */ public class IntSlider
/*     */   extends UiComponent
/*     */ {
/*     */   private final SettingValue<Integer> value;
/*     */   private final int min;
/*     */   private final int max;
/*     */   private final int step;
/*     */   private String label;
/*     */   
/*     */   public IntSlider(String label, SettingValue<Integer> value, int min, int max, int step) {
/*  24 */     if (value == null || max <= min)
/*  25 */       throw new IllegalArgumentException("slider"); 
/*  26 */     this.label = (label == null) ? "" : label;
/*  27 */     this.value = value;
/*  28 */     this.min = min;
/*  29 */     this.max = max;
/*  30 */     this.step = Math.max(1, step);
/*     */   }
/*     */ 
/*     */   
/*     */   protected UiSize measurePreferred(int maxWidth, int maxHeight) {
/*  35 */     Insets p = (style() != null) ? style().padding() : Insets.xy(9, 6);
/*  36 */     Objects.requireNonNull((class_310.method_1551()).field_1772); return new UiSize(150, 9 + 16 + p.vertical());
/*     */   }
/*     */ 
/*     */   
/*     */   protected void draw(UiContext ctx) {
/*  41 */     ComponentStyle s = (style() != null) ? style() : ctx.theme().control();
/*  42 */     ctx.glass().surface(ctx.graphics(), bounds(), s.glass());
/*     */     
/*  44 */     Insets p = s.padding();
/*  45 */     String right = Integer.toString(((Integer)this.value.get()).intValue());
/*  46 */     int textY = bounds().y() + p.top();
/*  47 */     ctx.graphics().method_51433(ctx.font(), this.label, bounds().x() + p.left(), textY, 
/*  48 */         enabled() ? s.text() : s.disabled(), false);
/*  49 */     ctx.graphics().method_51433(ctx.font(), right, bounds().right() - p.right() - ctx.font().method_1727(right), textY, 
/*  50 */         enabled() ? s.secondaryText() : s.disabled(), false);
/*     */     
/*  52 */     int x1 = bounds().x() + p.left();
/*  53 */     int x2 = bounds().right() - p.right();
/*  54 */     int y = bounds().bottom() - p.bottom() - 5;
/*  55 */     int fill = x1 + Math.round(((x2 - x1) * (((Integer)this.value.get()).intValue() - this.min)) / (this.max - this.min));
/*     */     
/*  57 */     ctx.graphics().method_25294(x1, y, x2, y + 3, 1717396592);
/*  58 */     ctx.graphics().method_25294(x1, y, fill, y + 3, s.accent());
/*  59 */     ctx.graphics().method_25294(fill - 2, y - 3, fill + 3, y + 6, enabled() ? -1 : s.disabled());
/*     */   }
/*     */ 
/*     */   
/*     */   protected boolean focusable() {
/*  64 */     return true;
/*     */   }
/*     */ 
/*     */   
/*     */   protected InputResult onMouseDown(double x, double y, int button, int modifiers, boolean doubled) {
/*  69 */     if (button != 0)
/*  70 */       return InputResult.PASS; 
/*  71 */     setFromMouse(x);
/*  72 */     active(true);
/*  73 */     return InputResult.CAPTURE;
/*     */   }
/*     */ 
/*     */   
/*     */   protected boolean onMouseDrag(double x, double y, int button, double dx, double dy) {
/*  78 */     if (!active() || button != 0)
/*  79 */       return false; 
/*  80 */     setFromMouse(x);
/*  81 */     return true;
/*     */   }
/*     */ 
/*     */   
/*     */   protected boolean onMouseUp(double x, double y, int button, int modifiers) {
/*  86 */     if (!active() || button != 0)
/*  87 */       return false; 
/*  88 */     active(false);
/*  89 */     return true;
/*     */   }
/*     */ 
/*     */   
/*     */   protected boolean onKeyPressed(class_11908 event) {
/*  94 */     if (event.comp_4795() != 263 && event.comp_4795() != 262)
/*  95 */       return false; 
/*  96 */     int next = ((Integer)this.value.get()).intValue() + ((event.comp_4795() == 262) ? this.step : -this.step);
/*  97 */     this.value.set(Integer.valueOf(Math.max(this.min, Math.min(this.max, next))));
/*  98 */     return true;
/*     */   }
/*     */   
/*     */   private void setFromMouse(double mouseX) {
/* 102 */     Insets p = (style() != null) ? style().padding() : Insets.xy(9, 6);
/* 103 */     int x1 = bounds().x() + p.left();
/* 104 */     int x2 = bounds().right() - p.right();
/* 105 */     double t = (x2 == x1) ? 0.0D : Math.max(0.0D, Math.min(1.0D, (mouseX - x1) / (x2 - x1)));
/* 106 */     int raw = this.min + (int)Math.round(t * (this.max - this.min));
/* 107 */     int snapped = this.min + Math.round((raw - this.min) / this.step) * this.step;
/* 108 */     this.value.set(Integer.valueOf(Math.max(this.min, Math.min(this.max, snapped))));
/*     */   }
/*     */ }


/* Location:              C:\Users\rapha\Downloads\aurora.jar!\META-INF\jars\lqglass-0.2.5.jar!\dev\devswag\lqglas\\ui\components\IntSlider.class
 * Java compiler version: 21 (65.0)
 * JD-Core Version:       1.1.3
 */