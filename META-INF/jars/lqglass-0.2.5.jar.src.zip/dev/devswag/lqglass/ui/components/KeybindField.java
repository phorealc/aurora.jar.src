/*    */ package dev.devswag.lqglass.ui.components;
/*    */ 
/*    */ import dev.devswag.lqglass.state.SettingValue;
/*    */ import dev.devswag.lqglass.style.ComponentStyle;
/*    */ import dev.devswag.lqglass.ui.InputResult;
/*    */ import dev.devswag.lqglass.ui.Insets;
/*    */ import dev.devswag.lqglass.ui.UiComponent;
/*    */ import dev.devswag.lqglass.ui.UiContext;
/*    */ import dev.devswag.lqglass.ui.UiSize;
/*    */ import java.util.Objects;
/*    */ import net.minecraft.class_11908;
/*    */ import net.minecraft.class_310;
/*    */ import org.lwjgl.glfw.GLFW;
/*    */ 
/*    */ public final class KeybindField extends UiComponent {
/*    */   private final SettingValue<Integer> value;
/*    */   private final String label;
/*    */   private boolean capturing;
/*    */   
/*    */   public KeybindField(String label, SettingValue<Integer> value) {
/* 21 */     if (value == null)
/* 22 */       throw new IllegalArgumentException("value"); 
/* 23 */     this.label = (label == null) ? "" : label;
/* 24 */     this.value = value;
/*    */   }
/*    */   
/*    */   public boolean capturing() {
/* 28 */     return this.capturing;
/*    */   }
/*    */ 
/*    */   
/*    */   protected UiSize measurePreferred(int maxWidth, int maxHeight) {
/* 33 */     Insets p = (style() != null) ? style().padding() : Insets.xy(9, 6);
/* 34 */     Objects.requireNonNull((class_310.method_1551()).field_1772); return new UiSize(170, 9 + p.vertical());
/*    */   }
/*    */ 
/*    */   
/*    */   protected void draw(UiContext ctx) {
/* 39 */     ComponentStyle s = (style() != null) ? style() : ctx.theme().control();
/* 40 */     ctx.glass().surface(ctx.graphics(), bounds(), s.glass());
/*    */     
/* 42 */     Insets p = s.padding();
/* 43 */     Objects.requireNonNull(ctx.font()); int y = bounds().y() + Math.max(0, (bounds().height() - 9) / 2);
/* 44 */     ctx.graphics().method_51433(ctx.font(), this.label, bounds().x() + p.left(), y, enabled() ? s.text() : s.disabled(), false);
/*    */     
/* 46 */     String text = this.capturing ? "press a key" : keyName((this.value.get() == null) ? -1 : ((Integer)this.value.get()).intValue());
/* 47 */     ctx.graphics().method_51433(ctx.font(), text, bounds().right() - p.right() - ctx.font().method_1727(text), y, 
/* 48 */         this.capturing ? s.accent() : s.secondaryText(), false);
/*    */   }
/*    */ 
/*    */   
/*    */   protected boolean focusable() {
/* 53 */     return true;
/*    */   }
/*    */ 
/*    */   
/*    */   protected InputResult onMouseDown(double x, double y, int button, int modifiers, boolean doubled) {
/* 58 */     if (button != 0)
/* 59 */       return InputResult.PASS; 
/* 60 */     this.capturing = true;
/* 61 */     return InputResult.CONSUME;
/*    */   }
/*    */ 
/*    */   
/*    */   protected boolean onKeyPressed(class_11908 event) {
/* 66 */     if (!this.capturing) {
/* 67 */       return false;
/*    */     }
/* 69 */     if (event.comp_4795() == 256) {
/* 70 */       this.capturing = false;
/* 71 */       return true;
/*    */     } 
/*    */     
/* 74 */     if (event.comp_4795() == 259 || event.comp_4795() == 261) {
/* 75 */       this.value.set(Integer.valueOf(-1));
/*    */     } else {
/* 77 */       this.value.set(Integer.valueOf(event.comp_4795()));
/*    */     } 
/* 79 */     this.capturing = false;
/* 80 */     return true;
/*    */   }
/*    */ 
/*    */   
/*    */   protected void onClickOutside(double x, double y) {
/* 85 */     this.capturing = false;
/*    */   }
/*    */   
/*    */   private String keyName(int key) {
/* 89 */     if (key == -1)
/* 90 */       return "none"; 
/* 91 */     String name = GLFW.glfwGetKeyName(key, 0);
/* 92 */     return (name == null) ? ("key " + key) : name.toUpperCase();
/*    */   }
/*    */ }


/* Location:              C:\Users\rapha\Downloads\aurora.jar!\META-INF\jars\lqglass-0.2.5.jar!\dev\devswag\lqglas\\ui\components\KeybindField.class
 * Java compiler version: 21 (65.0)
 * JD-Core Version:       1.1.3
 */