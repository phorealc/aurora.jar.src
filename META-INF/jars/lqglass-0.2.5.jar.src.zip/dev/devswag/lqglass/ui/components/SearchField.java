/*    */ package dev.devswag.lqglass.ui.components;
/*    */ 
/*    */ import dev.devswag.lqglass.state.SettingValue;
/*    */ 
/*    */ public final class SearchField
/*    */   extends TextField
/*    */ {
/*    */   public SearchField(SettingValue<String> value) {
/*  9 */     super(value);
/* 10 */     placeholder("Search...");
/*    */   }
/*    */ }


/* Location:              C:\Users\rapha\Downloads\aurora.jar!\META-INF\jars\lqglass-0.2.5.jar!\dev\devswag\lqglas\\ui\components\SearchField.class
 * Java compiler version: 21 (65.0)
 * JD-Core Version:       1.1.3
 */