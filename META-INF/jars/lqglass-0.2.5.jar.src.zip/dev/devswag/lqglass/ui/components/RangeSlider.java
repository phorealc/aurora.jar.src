/*     */ package dev.devswag.lqglass.ui.components;
/*     */ 
/*     */ import dev.devswag.lqglass.state.DoubleRange;
/*     */ import dev.devswag.lqglass.state.SettingValue;
/*     */ import dev.devswag.lqglass.style.ComponentStyle;
/*     */ import dev.devswag.lqglass.ui.InputResult;
/*     */ import dev.devswag.lqglass.ui.Insets;
/*     */ import dev.devswag.lqglass.ui.UiComponent;
/*     */ import dev.devswag.lqglass.ui.UiContext;
/*     */ import dev.devswag.lqglass.ui.UiSize;
/*     */ import java.text.DecimalFormat;
/*     */ import java.util.Objects;
/*     */ import net.minecraft.class_310;
/*     */ 
/*     */ 
/*     */ public final class RangeSlider
/*     */   extends UiComponent
/*     */ {
/*  19 */   private static final DecimalFormat FORMAT = new DecimalFormat("0.##");
/*     */   
/*     */   private final SettingValue<DoubleRange> value;
/*     */   
/*     */   private final double min;
/*     */   private final double max;
/*     */   private final double step;
/*     */   private final String label;
/*     */   private boolean upper;
/*     */   
/*     */   public RangeSlider(String label, SettingValue<DoubleRange> value, double min, double max, double step) {
/*  30 */     if (value == null || !Double.isFinite(min) || !Double.isFinite(max) || max <= min)
/*  31 */       throw new IllegalArgumentException("range slider"); 
/*  32 */     this.label = (label == null) ? "" : label;
/*  33 */     this.value = value;
/*  34 */     this.min = min;
/*  35 */     this.max = max;
/*  36 */     this.step = Math.max(0.0D, step);
/*     */   }
/*     */ 
/*     */   
/*     */   protected UiSize measurePreferred(int maxWidth, int maxHeight) {
/*  41 */     Insets p = (style() != null) ? style().padding() : Insets.xy(9, 6);
/*  42 */     Objects.requireNonNull((class_310.method_1551()).field_1772); return new UiSize(170, 9 + 16 + p.vertical());
/*     */   }
/*     */ 
/*     */   
/*     */   protected void draw(UiContext ctx) {
/*  47 */     ComponentStyle s = (style() != null) ? style() : ctx.theme().control();
/*  48 */     ctx.glass().surface(ctx.graphics(), bounds(), s.glass());
/*     */     
/*  50 */     Insets p = s.padding();
/*  51 */     DoubleRange range = (DoubleRange)this.value.get();
/*  52 */     String right = FORMAT.format(range.min()) + " - " + FORMAT.format(range.min());
/*  53 */     int textY = bounds().y() + p.top();
/*  54 */     ctx.graphics().method_51433(ctx.font(), this.label, bounds().x() + p.left(), textY, 
/*  55 */         enabled() ? s.text() : s.disabled(), false);
/*  56 */     ctx.graphics().method_51433(ctx.font(), right, bounds().right() - p.right() - ctx.font().method_1727(right), textY, 
/*  57 */         enabled() ? s.secondaryText() : s.disabled(), false);
/*     */     
/*  59 */     int x1 = bounds().x() + p.left();
/*  60 */     int x2 = bounds().right() - p.right();
/*  61 */     int y = bounds().bottom() - p.bottom() - 5;
/*  62 */     int low = x1 + (int)Math.round((x2 - x1) * normalized(range.min()));
/*  63 */     int high = x1 + (int)Math.round((x2 - x1) * normalized(range.max()));
/*     */     
/*  65 */     ctx.graphics().method_25294(x1, y, x2, y + 3, 1717396592);
/*  66 */     ctx.graphics().method_25294(low, y, high, y + 3, s.accent());
/*  67 */     ctx.graphics().method_25294(low - 2, y - 3, low + 3, y + 6, -1);
/*  68 */     ctx.graphics().method_25294(high - 2, y - 3, high + 3, y + 6, -1);
/*     */   }
/*     */ 
/*     */   
/*     */   protected boolean focusable() {
/*  73 */     return true;
/*     */   }
/*     */ 
/*     */   
/*     */   protected InputResult onMouseDown(double x, double y, int button, int modifiers, boolean doubled) {
/*  78 */     if (button != 0) {
/*  79 */       return InputResult.PASS;
/*     */     }
/*  81 */     double raw = valueAt(x);
/*  82 */     DoubleRange range = (DoubleRange)this.value.get();
/*  83 */     this.upper = (Math.abs(raw - range.max()) < Math.abs(raw - range.min()));
/*  84 */     set(raw);
/*  85 */     active(true);
/*  86 */     return InputResult.CAPTURE;
/*     */   }
/*     */ 
/*     */   
/*     */   protected boolean onMouseDrag(double x, double y, int button, double dx, double dy) {
/*  91 */     if (!active() || button != 0)
/*  92 */       return false; 
/*  93 */     set(valueAt(x));
/*  94 */     return true;
/*     */   }
/*     */ 
/*     */   
/*     */   protected boolean onMouseUp(double x, double y, int button, int modifiers) {
/*  99 */     if (!active() || button != 0)
/* 100 */       return false; 
/* 101 */     active(false);
/* 102 */     return true;
/*     */   }
/*     */   
/*     */   private void set(double raw) {
/* 106 */     DoubleRange current = (DoubleRange)this.value.get();
/* 107 */     double snapped = snap(raw);
/* 108 */     if (this.upper) {
/* 109 */       this.value.set(new DoubleRange(current.min(), Math.max(current.min(), snapped)));
/*     */     } else {
/* 111 */       this.value.set(new DoubleRange(Math.min(current.max(), snapped), current.max()));
/*     */     } 
/*     */   }
/*     */   private double valueAt(double mouseX) {
/* 115 */     Insets p = (style() != null) ? style().padding() : Insets.xy(9, 6);
/* 116 */     int x1 = bounds().x() + p.left();
/* 117 */     int x2 = bounds().right() - p.right();
/* 118 */     double t = (x2 == x1) ? 0.0D : Math.max(0.0D, Math.min(1.0D, (mouseX - x1) / (x2 - x1)));
/* 119 */     return this.min + t * (this.max - this.min);
/*     */   }
/*     */   
/*     */   private double snap(double value) {
/* 123 */     double out = Math.max(this.min, Math.min(this.max, value));
/* 124 */     if (this.step > 0.0D)
/* 125 */       out = this.min + Math.round((out - this.min) / this.step) * this.step; 
/* 126 */     return Math.max(this.min, Math.min(this.max, out));
/*     */   }
/*     */   
/*     */   private double normalized(double value) {
/* 130 */     return Math.max(0.0D, Math.min(1.0D, (value - this.min) / (this.max - this.min)));
/*     */   }
/*     */ }


/* Location:              C:\Users\rapha\Downloads\aurora.jar!\META-INF\jars\lqglass-0.2.5.jar!\dev\devswag\lqglas\\ui\components\RangeSlider.class
 * Java compiler version: 21 (65.0)
 * JD-Core Version:       1.1.3
 */