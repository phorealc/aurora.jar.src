/*     */ package dev.devswag.lqglass.ui.components;
/*     */ 
/*     */ import dev.devswag.lqglass.ui.InputResult;
/*     */ import dev.devswag.lqglass.ui.UiBounds;
/*     */ import dev.devswag.lqglass.ui.UiComponent;
/*     */ import dev.devswag.lqglass.ui.UiContext;
/*     */ import dev.devswag.lqglass.ui.UiSize;
/*     */ 
/*     */ public class ScrollContainer
/*     */   extends UiComponent
/*     */ {
/*     */   private final UiComponent content;
/*     */   private double scrollX;
/*     */   private double scrollY;
/*     */   private double targetX;
/*     */   private double targetY;
/*     */   private int contentWidth;
/*     */   private int contentHeight;
/*     */   private boolean horizontal;
/*     */   private boolean vertical = true;
/*     */   private boolean smooth = true;
/*  22 */   private int wheelStep = 22;
/*     */   private boolean draggingThumb;
/*     */   private double lastThumbY;
/*     */   
/*     */   public ScrollContainer(UiComponent content) {
/*  27 */     if (content == null)
/*  28 */       throw new IllegalArgumentException("content"); 
/*  29 */     this.content = content;
/*  30 */     add(content);
/*  31 */     clip(true);
/*     */   }
/*     */   
/*     */   public UiComponent content() {
/*  35 */     return this.content;
/*     */   }
/*     */   
/*     */   public ScrollContainer horizontal(boolean value) {
/*  39 */     this.horizontal = value;
/*  40 */     invalidateLayout();
/*  41 */     return this;
/*     */   }
/*     */   
/*     */   public ScrollContainer vertical(boolean value) {
/*  45 */     this.vertical = value;
/*  46 */     invalidateLayout();
/*  47 */     return this;
/*     */   }
/*     */   
/*     */   public ScrollContainer smooth(boolean value) {
/*  51 */     this.smooth = value;
/*  52 */     return this;
/*     */   }
/*     */   
/*     */   public ScrollContainer wheelStep(int value) {
/*  56 */     this.wheelStep = Math.max(1, value);
/*  57 */     return this;
/*     */   }
/*     */   
/*     */   public double scrollX() {
/*  61 */     return this.scrollX;
/*     */   }
/*     */   
/*     */   public double scrollY() {
/*  65 */     return this.scrollY;
/*     */   }
/*     */   
/*     */   public void scrollTo(double x, double y) {
/*  69 */     this.targetX = clamp(x, 0.0D, maxX());
/*  70 */     this.targetY = clamp(y, 0.0D, maxY());
/*  71 */     if (!this.smooth) {
/*  72 */       this.scrollX = this.targetX;
/*  73 */       this.scrollY = this.targetY;
/*     */     } 
/*  75 */     invalidateLayout();
/*     */   }
/*     */ 
/*     */   
/*     */   protected UiSize measurePreferred(int maxWidth, int maxHeight) {
/*  80 */     UiSize size = this.content.measure(
/*  81 */         this.horizontal ? Integer.MAX_VALUE : maxWidth, 
/*  82 */         this.vertical ? Integer.MAX_VALUE : maxHeight);
/*  83 */     return new UiSize(Math.min(maxWidth, size.width()), Math.min(maxHeight, size.height()));
/*     */   }
/*     */ 
/*     */   
/*     */   public void layout(UiBounds bounds) {
/*  88 */     super.layout(bounds);
/*     */     
/*  90 */     UiSize size = this.content.measure(
/*  91 */         this.horizontal ? Integer.MAX_VALUE : bounds.width(), 
/*  92 */         this.vertical ? Integer.MAX_VALUE : bounds.height());
/*     */     
/*  94 */     this.contentWidth = this.horizontal ? Math.max(bounds.width(), size.width()) : bounds.width();
/*  95 */     this.contentHeight = this.vertical ? Math.max(bounds.height(), size.height()) : bounds.height();
/*     */     
/*  97 */     this.targetX = clamp(this.targetX, 0.0D, maxX());
/*  98 */     this.targetY = clamp(this.targetY, 0.0D, maxY());
/*  99 */     this.scrollX = clamp(this.scrollX, 0.0D, maxX());
/* 100 */     this.scrollY = clamp(this.scrollY, 0.0D, maxY());
/*     */     
/* 102 */     this.content.layout(new UiBounds(bounds
/* 103 */           .x() - (int)Math.round(this.scrollX), bounds
/* 104 */           .y() - (int)Math.round(this.scrollY), this.contentWidth, this.contentHeight));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void tick() {
/* 111 */     super.tick();
/* 112 */     if (!this.smooth) {
/*     */       return;
/*     */     }
/* 115 */     double oldX = this.scrollX;
/* 116 */     double oldY = this.scrollY;
/* 117 */     this.scrollX += (this.targetX - this.scrollX) * 0.35D;
/* 118 */     this.scrollY += (this.targetY - this.scrollY) * 0.35D;
/*     */     
/* 120 */     if (Math.abs(this.targetX - this.scrollX) < 0.05D)
/* 121 */       this.scrollX = this.targetX; 
/* 122 */     if (Math.abs(this.targetY - this.scrollY) < 0.05D) {
/* 123 */       this.scrollY = this.targetY;
/*     */     }
/* 125 */     if (oldX != this.scrollX || oldY != this.scrollY) {
/* 126 */       invalidateLayout();
/*     */     }
/*     */   }
/*     */   
/*     */   protected void draw(UiContext ctx) {
/* 131 */     if (!this.vertical || maxY() <= 0.0D) {
/*     */       return;
/*     */     }
/* 134 */     int trackX = bounds().right() - 3;
/* 135 */     int trackH = bounds().height();
/* 136 */     int thumbH = Math.max(12, Math.round(trackH * bounds().height() / this.contentHeight));
/* 137 */     int travel = Math.max(1, trackH - thumbH);
/* 138 */     int y = bounds().y() + Math.round(travel * (float)(this.scrollY / Math.max(1.0D, maxY())));
/*     */     
/* 140 */     ctx.graphics().method_25294(trackX, bounds().y(), trackX + 2, bounds().bottom(), 576545904);
/* 141 */     ctx.graphics().method_25294(trackX, y, trackX + 2, y + thumbH, hovered() ? -1426063361 : 1728053247);
/*     */   }
/*     */ 
/*     */   
/*     */   protected boolean onScroll(double x, double y, double horizontalAmount, double verticalAmount) {
/* 146 */     if (this.vertical && maxY() > 0.0D && verticalAmount != 0.0D) {
/* 147 */       scrollTo(this.targetX, this.targetY - verticalAmount * this.wheelStep);
/* 148 */       return true;
/*     */     } 
/*     */     
/* 151 */     if (this.horizontal && maxX() > 0.0D && horizontalAmount != 0.0D) {
/* 152 */       scrollTo(this.targetX - horizontalAmount * this.wheelStep, this.targetY);
/* 153 */       return true;
/*     */     } 
/*     */     
/* 156 */     return false;
/*     */   }
/*     */ 
/*     */   
/*     */   protected InputResult onMouseDown(double x, double y, int button, int modifiers, boolean doubled) {
/* 161 */     if (button != 0 || !this.vertical || maxY() <= 0.0D)
/* 162 */       return InputResult.PASS; 
/* 163 */     if (x < (bounds().right() - 6)) {
/* 164 */       return InputResult.PASS;
/*     */     }
/* 166 */     this.draggingThumb = true;
/* 167 */     this.lastThumbY = y;
/* 168 */     active(true);
/* 169 */     return InputResult.CAPTURE;
/*     */   }
/*     */ 
/*     */   
/*     */   protected boolean onMouseDrag(double x, double y, int button, double dx, double dy) {
/* 174 */     if (!this.draggingThumb || button != 0) {
/* 175 */       return false;
/*     */     }
/* 177 */     int trackH = bounds().height();
/* 178 */     int thumbH = Math.max(12, Math.round(trackH * bounds().height() / this.contentHeight));
/* 179 */     int travel = Math.max(1, trackH - thumbH);
/* 180 */     double next = this.targetY + (y - this.lastThumbY) * maxY() / travel;
/* 181 */     this.lastThumbY = y;
/* 182 */     scrollTo(this.targetX, next);
/* 183 */     return true;
/*     */   }
/*     */ 
/*     */   
/*     */   protected boolean onMouseUp(double x, double y, int button, int modifiers) {
/* 188 */     if (!this.draggingThumb || button != 0)
/* 189 */       return false; 
/* 190 */     this.draggingThumb = false;
/* 191 */     active(false);
/* 192 */     return true;
/*     */   }
/*     */   
/*     */   private double maxX() {
/* 196 */     return Math.max(0, this.contentWidth - bounds().width());
/*     */   }
/*     */   
/*     */   private double maxY() {
/* 200 */     return Math.max(0, this.contentHeight - bounds().height());
/*     */   }
/*     */   
/*     */   private double clamp(double value, double min, double max) {
/* 204 */     return Math.max(min, Math.min(max, value));
/*     */   }
/*     */ }


/* Location:              C:\Users\rapha\Downloads\aurora.jar!\META-INF\jars\lqglass-0.2.5.jar!\dev\devswag\lqglas\\ui\components\ScrollContainer.class
 * Java compiler version: 21 (65.0)
 * JD-Core Version:       1.1.3
 */