/*     */ package dev.devswag.lqglass.ui;
/*     */ 
/*     */ import dev.devswag.lqglass.style.ComponentStyle;
/*     */ import dev.devswag.lqglass.ui.layout.Layout;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Collections;
/*     */ import java.util.List;
/*     */ import net.minecraft.class_11905;
/*     */ import net.minecraft.class_11908;
/*     */ import net.minecraft.class_2561;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class UiComponent
/*     */ {
/*  18 */   private final List<UiComponent> children = new ArrayList<>();
/*  19 */   private final List<UiComponent> childView = Collections.unmodifiableList(this.children);
/*  20 */   private final LayoutSpec layoutSpec = new LayoutSpec(this::invalidateLayout);
/*     */   
/*     */   private UiComponent parent;
/*  23 */   private UiBounds bounds = new UiBounds(0, 0, 0, 0);
/*     */   
/*     */   private Layout layout;
/*     */   private ComponentStyle style;
/*     */   private String tooltip;
/*     */   private String accessibilityLabel;
/*     */   private class_2561 accessibleName;
/*     */   private boolean focusScope;
/*     */   private boolean visible = true;
/*     */   private boolean enabled = true;
/*     */   private boolean clip;
/*     */   private boolean mounted;
/*     */   private boolean layoutDirty = true;
/*     */   private boolean hovered;
/*     */   private boolean focused;
/*     */   private boolean active;
/*     */   
/*     */   public UiBounds bounds() {
/*  41 */     return this.bounds;
/*     */   }
/*     */   
/*     */   public LayoutSpec layoutSpec() {
/*  45 */     return this.layoutSpec;
/*     */   }
/*     */   
/*     */   public UiComponent parent() {
/*  49 */     return this.parent;
/*     */   }
/*     */   
/*     */   public List<UiComponent> children() {
/*  53 */     return this.childView;
/*     */   }
/*     */   
/*     */   public int visibleChildCount() {
/*  57 */     int count = 0;
/*  58 */     for (UiComponent c : this.children) {
/*  59 */       if (c.visible)
/*  60 */         count++; 
/*  61 */     }  return count;
/*     */   }
/*     */   
/*     */   public UiComponent add(UiComponent child) {
/*  65 */     if (child == null || child == this)
/*  66 */       throw new IllegalArgumentException("child"); 
/*  67 */     if (child.parent != null)
/*  68 */       child.parent.remove(child); 
/*  69 */     this.children.add(child);
/*  70 */     child.parent = this;
/*  71 */     if (this.mounted)
/*  72 */       child.mount(); 
/*  73 */     invalidateLayout();
/*  74 */     return this;
/*     */   }
/*     */   
/*     */   public UiComponent remove(UiComponent child) {
/*  78 */     if (this.children.remove(child)) {
/*  79 */       if (child.mounted)
/*  80 */         child.unmount(); 
/*  81 */       child.parent = null;
/*  82 */       invalidateLayout();
/*     */     } 
/*  84 */     return this;
/*     */   }
/*     */   
/*     */   public void clear() {
/*  88 */     for (UiComponent child : this.children) {
/*  89 */       if (child.mounted)
/*  90 */         child.unmount(); 
/*  91 */       child.parent = null;
/*     */     } 
/*  93 */     this.children.clear();
/*  94 */     invalidateLayout();
/*     */   }
/*     */   
/*     */   public UiComponent layout(Layout layout) {
/*  98 */     this.layout = layout;
/*  99 */     invalidateLayout();
/* 100 */     return this;
/*     */   }
/*     */   
/*     */   public Layout layout() {
/* 104 */     return this.layout;
/*     */   }
/*     */   
/*     */   public UiComponent style(ComponentStyle style) {
/* 108 */     this.style = style;
/* 109 */     return this;
/*     */   }
/*     */   
/*     */   public ComponentStyle style() {
/* 113 */     return this.style;
/*     */   }
/*     */   
/*     */   public UiComponent tooltip(String tooltip) {
/* 117 */     this.tooltip = tooltip;
/* 118 */     return this;
/*     */   }
/*     */   
/*     */   public String tooltip() {
/* 122 */     return this.tooltip;
/*     */   }
/*     */   
/*     */   public UiComponent accessibilityLabel(String label) {
/* 126 */     this.accessibilityLabel = label;
/* 127 */     this.accessibleName = (label == null) ? null : (class_2561)class_2561.method_43470(label);
/* 128 */     return this;
/*     */   }
/*     */   
/*     */   public UiComponent componentAccessibilityLabel(class_2561 label) {
/* 132 */     this.accessibleName = label;
/* 133 */     this.accessibilityLabel = (label == null) ? null : label.getString();
/* 134 */     return this;
/*     */   }
/*     */   
/*     */   public String accessibilityLabel() {
/* 138 */     return this.accessibilityLabel;
/*     */   }
/*     */   
/*     */   public class_2561 narration() {
/* 142 */     if (this.accessibleName != null)
/* 143 */       return this.accessibleName; 
/* 144 */     return (this.tooltip == null || this.tooltip.isBlank()) ? null : (class_2561)class_2561.method_43470(this.tooltip);
/*     */   }
/*     */   
/*     */   public UiComponent visible(boolean visible) {
/* 148 */     if (this.visible != visible) {
/* 149 */       this.visible = visible;
/* 150 */       invalidateLayout();
/*     */     } 
/* 152 */     return this;
/*     */   }
/*     */   
/*     */   public boolean visible() {
/* 156 */     return this.visible;
/*     */   }
/*     */   
/*     */   public UiComponent enabled(boolean enabled) {
/* 160 */     this.enabled = enabled;
/* 161 */     if (!enabled)
/* 162 */       this.active = false; 
/* 163 */     return this;
/*     */   }
/*     */   
/*     */   public boolean enabled() {
/* 167 */     return this.enabled;
/*     */   }
/*     */   
/*     */   public UiComponent clip(boolean clip) {
/* 171 */     this.clip = clip;
/* 172 */     return this;
/*     */   }
/*     */   
/*     */   public boolean clip() {
/* 176 */     return this.clip;
/*     */   }
/*     */   
/*     */   public UiComponent focusScope(boolean focusScope) {
/* 180 */     this.focusScope = focusScope;
/* 181 */     return this;
/*     */   }
/*     */   
/*     */   public boolean focusScope() {
/* 185 */     return this.focusScope;
/*     */   }
/*     */   
/*     */   public boolean hovered() {
/* 189 */     return this.hovered;
/*     */   }
/*     */   
/*     */   public boolean focused() {
/* 193 */     return this.focused;
/*     */   }
/*     */   
/*     */   public boolean active() {
/* 197 */     return this.active;
/*     */   }
/*     */   
/*     */   public void active(boolean active) {
/* 201 */     this.active = active;
/*     */   }
/*     */   
/*     */   public boolean layoutDirty() {
/* 205 */     if (this.layoutDirty)
/* 206 */       return true; 
/* 207 */     for (UiComponent c : this.children) {
/* 208 */       if (c.layoutDirty())
/* 209 */         return true; 
/* 210 */     }  return false;
/*     */   }
/*     */   
/*     */   public void invalidateLayout() {
/* 214 */     if (this.layoutDirty)
/*     */       return; 
/* 216 */     this.layoutDirty = true;
/* 217 */     if (this.parent != null) {
/* 218 */       this.parent.invalidateLayout();
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   public UiSize measure(int maxWidth, int maxHeight) {
/* 224 */     UiSize size = (this.layout != null) ? this.layout.measure(this, maxWidth, maxHeight) : measurePreferred(maxWidth, maxHeight);
/*     */     
/* 226 */     return new UiSize(this.layoutSpec
/* 227 */         .clampWidth(resolve(this.layoutSpec.width(), size.width(), maxWidth)), this.layoutSpec
/* 228 */         .clampHeight(resolve(this.layoutSpec.height(), size.height(), maxHeight)));
/*     */   }
/*     */   
/*     */   public void layout(UiBounds bounds) {
/* 232 */     this.bounds = bounds;
/* 233 */     this.layoutDirty = false;
/* 234 */     if (this.layout != null)
/* 235 */       this.layout.layout(this, bounds); 
/*     */   }
/*     */   
/*     */   public final void render(UiContext ctx) {
/* 239 */     if (!this.visible) {
/*     */       return;
/*     */     }
/* 242 */     this.hovered = (this.enabled && this.bounds.contains(ctx.mouseX(), ctx.mouseY()));
/*     */     
/* 244 */     if (this.clip) {
/* 245 */       ctx.graphics().method_44379(this.bounds.x(), this.bounds.y(), this.bounds.right(), this.bounds.bottom());
/* 246 */       ctx.glass().stats().clip();
/*     */     } 
/*     */     
/* 249 */     draw(ctx);
/*     */     
/* 251 */     for (UiComponent child : this.children) {
/* 252 */       child.render(ctx);
/*     */     }
/* 254 */     if (this.clip)
/* 255 */       ctx.graphics().method_44380(); 
/*     */   }
/*     */   
/*     */   public void tick() {
/* 259 */     for (UiComponent child : this.children) {
/* 260 */       if (child.visible)
/* 261 */         child.tick(); 
/*     */     } 
/*     */   }
/*     */   public final void mount() {
/* 265 */     if (this.mounted)
/*     */       return; 
/* 267 */     this.mounted = true;
/* 268 */     onMount();
/* 269 */     for (UiComponent child : this.children)
/* 270 */       child.mount(); 
/*     */   }
/*     */   
/*     */   public final void unmount() {
/* 274 */     if (!this.mounted)
/*     */       return; 
/* 276 */     for (UiComponent child : this.children)
/* 277 */       child.unmount(); 
/* 278 */     onUnmount();
/* 279 */     this.mounted = false;
/* 280 */     this.focused = false;
/* 281 */     this.active = false;
/*     */   }
/*     */   
/*     */   UiComponent findTop(double x, double y) {
/* 285 */     if (!this.visible || !this.enabled) {
/* 286 */       return null;
/*     */     }
/* 288 */     boolean inside = hitTest(x, y);
/* 289 */     if (this.clip && !inside) {
/* 290 */       return null;
/*     */     }
/* 292 */     for (int i = this.children.size() - 1; i >= 0; i--) {
/* 293 */       UiComponent hit = ((UiComponent)this.children.get(i)).findTop(x, y);
/* 294 */       if (hit != null) {
/* 295 */         return hit;
/*     */       }
/*     */     } 
/* 298 */     return inside ? this : null;
/*     */   }
/*     */   
/*     */   void focused(boolean focused) {
/* 302 */     if (this.focused == focused)
/*     */       return; 
/* 304 */     this.focused = focused;
/* 305 */     onFocusChanged(focused);
/*     */   }
/*     */   
/*     */   void collectFocusable(List<UiComponent> out) {
/* 309 */     if (this.visible && this.enabled && focusable())
/* 310 */       out.add(this); 
/* 311 */     for (UiComponent child : this.children)
/* 312 */       child.collectFocusable(out); 
/*     */   }
/*     */   
/*     */   UiComponent focusScopeRoot() {
/* 316 */     if (this.focusScope)
/* 317 */       return this; 
/* 318 */     for (int i = this.children.size() - 1; i >= 0; i--) {
/* 319 */       UiComponent child = this.children.get(i);
/* 320 */       if (child.visible) {
/*     */         
/* 322 */         UiComponent scope = child.focusScopeRoot();
/* 323 */         if (scope != null)
/* 324 */           return scope; 
/*     */       } 
/* 326 */     }  return null;
/*     */   }
/*     */   
/*     */   boolean isDescendantOf(UiComponent ancestor) {
/* 330 */     for (UiComponent c = this; c != null; c = c.parent) {
/* 331 */       if (c == ancestor)
/* 332 */         return true; 
/* 333 */     }  return false;
/*     */   }
/*     */   
/*     */   protected UiSize measurePreferred(int maxWidth, int maxHeight) {
/* 337 */     return UiSize.ZERO;
/*     */   }
/*     */ 
/*     */   
/*     */   protected void draw(UiContext ctx) {}
/*     */ 
/*     */   
/*     */   protected void onMount() {}
/*     */ 
/*     */   
/*     */   protected void onUnmount() {}
/*     */   
/*     */   protected boolean focusable() {
/* 350 */     return false;
/*     */   }
/*     */   
/*     */   protected boolean hitTest(double x, double y) {
/* 354 */     return this.bounds.contains(x, y);
/*     */   }
/*     */ 
/*     */   
/*     */   protected void onFocusChanged(boolean focused) {}
/*     */ 
/*     */   
/*     */   protected void onClickOutside(double x, double y) {}
/*     */   
/*     */   protected InputResult onMouseDown(double x, double y, int button, int modifiers, boolean doubled) {
/* 364 */     return InputResult.PASS;
/*     */   }
/*     */   
/*     */   protected boolean onMouseUp(double x, double y, int button, int modifiers) {
/* 368 */     return false;
/*     */   }
/*     */   
/*     */   protected boolean onMouseDrag(double x, double y, int button, double dx, double dy) {
/* 372 */     return false;
/*     */   }
/*     */   
/*     */   protected boolean onScroll(double x, double y, double horizontal, double vertical) {
/* 376 */     return false;
/*     */   }
/*     */   
/*     */   protected boolean onKeyPressed(class_11908 event) {
/* 380 */     return false;
/*     */   }
/*     */   
/*     */   protected boolean onKeyReleased(class_11908 event) {
/* 384 */     return false;
/*     */   }
/*     */   
/*     */   protected boolean onCharTyped(class_11905 event) {
/* 388 */     return false;
/*     */   }
/*     */   
/*     */   private int resolve(Length length, int natural, int available) {
/* 392 */     if (available == Integer.MAX_VALUE && (length.unit() == Length.Unit.FILL || length.unit() == Length.Unit.PERCENT)) {
/* 393 */       return natural;
/*     */     }
/* 395 */     switch (length.unit()) { default: throw new MatchException(null, null);case AUTO: case PIXELS: case PERCENT: case FILL: break; }  return 
/*     */ 
/*     */ 
/*     */       
/* 399 */       available;
/*     */   }
/*     */ }


/* Location:              C:\Users\rapha\Downloads\aurora.jar!\META-INF\jars\lqglass-0.2.5.jar!\dev\devswag\lqglas\\ui\UiComponent.class
 * Java compiler version: 21 (65.0)
 * JD-Core Version:       1.1.3
 */