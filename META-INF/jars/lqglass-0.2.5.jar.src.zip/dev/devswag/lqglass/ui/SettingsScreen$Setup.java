/*    */ package dev.devswag.lqglass.ui;
/*    */ 
/*    */ import dev.devswag.lqglass.state.SettingValue;
/*    */ import dev.devswag.lqglass.ui.components.GlassPanel;
/*    */ import dev.devswag.lqglass.ui.components.ScrollContainer;
/*    */ import dev.devswag.lqglass.ui.components.SearchField;
/*    */ import dev.devswag.lqglass.ui.layout.Layouts;
/*    */ import java.util.ArrayList;
/*    */ import java.util.List;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ final class Setup
/*    */ {
/* 67 */   private final UiContainer sidebar = new UiContainer(Layouts.column(6));
/* 68 */   private final UiContainer content = new UiContainer(Layouts.stack(Layouts.Align.STRETCH, Layouts.Align.START));
/* 69 */   private final SearchField searchField = new SearchField((new SettingValue("")).live(true));
/* 70 */   private final List<UiComponent> pages = new ArrayList<>();
/*    */   private final UiComponent root;
/*    */   
/*    */   private Setup() {
/* 74 */     GlassPanel side = new GlassPanel();
/* 75 */     side.layout(Layouts.column(8));
/* 76 */     side.layoutSpec().width(Length.px(150.0F)).padding(Insets.all(10));
/* 77 */     this.sidebar.layoutSpec().grow(1.0F);
/* 78 */     side.add(this.sidebar);
/*    */     
/* 80 */     GlassPanel main = new GlassPanel();
/* 81 */     main.layout(Layouts.column(8));
/* 82 */     main.layoutSpec().grow(1.0F).padding(Insets.all(10));
/* 83 */     main.add((UiComponent)this.searchField);
/*    */     
/* 85 */     ScrollContainer scroll = new ScrollContainer(this.content);
/* 86 */     scroll.layoutSpec().grow(1.0F);
/* 87 */     main.add((UiComponent)scroll);
/*    */     
/* 89 */     UiContainer row = new UiContainer(Layouts.row(10, Layouts.Align.STRETCH, Layouts.Justify.START));
/* 90 */     row.layoutSpec().padding(Insets.all(12));
/* 91 */     row.add((UiComponent)side);
/* 92 */     row.add((UiComponent)main);
/* 93 */     this.root = row;
/*    */   }
/*    */ }


/* Location:              C:\Users\rapha\Downloads\aurora.jar!\META-INF\jars\lqglass-0.2.5.jar!\dev\devswag\lqglas\\ui\SettingsScreen$Setup.class
 * Java compiler version: 21 (65.0)
 * JD-Core Version:       1.1.3
 */