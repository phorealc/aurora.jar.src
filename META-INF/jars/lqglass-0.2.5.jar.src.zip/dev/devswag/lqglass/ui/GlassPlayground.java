/*     */ package dev.devswag.lqglass.ui;
/*     */ 
/*     */ import dev.devswag.lqglass.state.SettingValue;
/*     */ import dev.devswag.lqglass.style.GlassPresets;
/*     */ import dev.devswag.lqglass.style.GlassStyle;
/*     */ import dev.devswag.lqglass.style.LiquidGlassTheme;
/*     */ import dev.devswag.lqglass.ui.components.Button;
/*     */ import dev.devswag.lqglass.ui.components.ColorPicker;
/*     */ import dev.devswag.lqglass.ui.components.Dropdown;
/*     */ import dev.devswag.lqglass.ui.components.GlassPanel;
/*     */ import dev.devswag.lqglass.ui.components.Label;
/*     */ import dev.devswag.lqglass.ui.components.Slider;
/*     */ import dev.devswag.lqglass.ui.components.VirtualList;
/*     */ import dev.devswag.lqglass.ui.layout.Layouts;
/*     */ import java.util.List;
/*     */ import net.minecraft.class_2561;
/*     */ import net.minecraft.class_2583;
/*     */ import net.minecraft.class_310;
/*     */ 
/*     */ public final class GlassPlayground
/*     */ {
/*  22 */   private static final List<Material> MATERIALS = List.of(new Material[] { new Material("SUBTLE", GlassPresets.SUBTLE, "Low tint, quiet highlights, compact blur."), new Material("FROSTED", GlassPresets.FROSTED, "Soft white frost with broad light."), new Material("CLEAR", GlassPresets.CLEAR, "Bright, clear glass with restrained tint."), new Material("STRONG", GlassPresets.STRONG, "Deep blur and a confident edge."), new Material("DARK", GlassPresets.DARK, "Smoked graphite with warm specular light."), new Material("LIGHT", GlassPresets.LIGHT, "Pale glass for bright interfaces."), new Material("HUD", GlassPresets.HUD, "Low-cost translucent material for overlays."), new Material("CRYSTAL", GlassPresets.CRYSTAL, "Cool refraction with split corner geometry."), new Material("AURORA", GlassPresets.AURORA, "Teal-to-violet film and colored edge light."), new Material("PRISM", GlassPresets.PRISM, "Strong spectral separation and shifting color."), new Material("AMBER", GlassPresets.AMBER, "Golden tint fading into burnt orange."), new Material("MIDNIGHT", GlassPresets.MIDNIGHT, "Indigo smoke with a vivid purple rim.") });
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static GlassScreen create() {
/*  41 */     UiContainer root = new UiContainer(Layouts.stack(Layouts.Align.CENTER, Layouts.Align.CENTER));
/*  42 */     GlassPanel panel = new GlassPanel();
/*  43 */     panel.layout(Layouts.column(10));
/*  44 */     panel.layoutSpec().width(Length.percent(0.9F)).height(Length.percent(0.9F));
/*  45 */     panel.layoutSpec().maxSize(900, 700);
/*  46 */     panel.layoutSpec().padding(Insets.xy(18, 14));
/*     */ 
/*     */     
/*  49 */     Label title = Label.from((class_2561)class_2561.method_43470("Liquid glass lab").method_27694(style -> style.method_10982(Boolean.valueOf(true)))).scale(1.25F);
/*     */     
/*  51 */     Label intro = (new Label("Pick a material, tune its blur and optics, and watch the surface update live.")).color(-3089944);
/*  52 */     panel.add((UiComponent)title);
/*  53 */     panel.add((UiComponent)intro);
/*     */ 
/*     */     
/*  56 */     SettingValue<String> selected = (new SettingValue("AURORA", value -> MATERIALS.stream().anyMatch(()))).live(true);
/*  57 */     SettingValue<Double> refraction = (new SettingValue(Double.valueOf(0.64D), value -> (value != null && value.doubleValue() >= 0.0D && value.doubleValue() <= 1.0D))).live(true);
/*  58 */     SettingValue<Double> dispersion = (new SettingValue(Double.valueOf(0.34D), value -> (value != null && value.doubleValue() >= 0.0D && value.doubleValue() <= 1.0D))).live(true);
/*  59 */     SettingValue<Double> film = (new SettingValue(Double.valueOf(0.82D), value -> (value != null && value.doubleValue() >= 0.0D && value.doubleValue() <= 1.0D))).live(true);
/*  60 */     SettingValue<Double> roughness = (new SettingValue(Double.valueOf(0.14D), value -> (value != null && value.doubleValue() >= 0.0D && value.doubleValue() <= 1.0D))).live(true);
/*  61 */     SettingValue<Double> blurMix = (new SettingValue(Double.valueOf(0.42D), value -> (value != null && value.doubleValue() >= 0.0D && value.doubleValue() <= 1.0D))).live(true);
/*  62 */     SettingValue<Double> spread = (new SettingValue(Double.valueOf(0.58D), value -> (value != null && value.doubleValue() >= 0.0D && value.doubleValue() <= 1.0D))).live(true);
/*  63 */     SettingValue<Double> edgeWidth = (new SettingValue(Double.valueOf(15.0D), value -> (value != null && value.doubleValue() >= 0.0D && value.doubleValue() <= 24.0D))).live(true);
/*  64 */     SettingValue<Double> tintAngle = (new SettingValue(Double.valueOf(120.0D), value -> (value != null && value.doubleValue() >= 0.0D && value.doubleValue() <= 360.0D))).live(true);
/*  65 */     SettingValue<Integer> edgeLight = (new SettingValue(Integer.valueOf(-792334337), value -> (value != null))).live(true);
/*     */     
/*  67 */     GlassPanel preview = new GlassPanel();
/*  68 */     preview.layout(Layouts.stack(Layouts.Align.CENTER, Layouts.Align.CENTER));
/*  69 */     preview.layoutSpec().height(Length.px(88.0F));
/*  70 */     Label previewLabel = new Label(() -> (String)selected.get() + "  ·  blur " + (String)selected.get() + " / " + percent(((Double)blurMix.get()).floatValue()) + "   edge " + percent(((Double)spread.get()).floatValue()) + "px");
/*     */     
/*  72 */     previewLabel.scale(1.12F);
/*  73 */     preview.add((UiComponent)previewLabel);
/*  74 */     panel.add((UiComponent)preview);
/*     */     
/*  76 */     UiContainer controls = new UiContainer(Layouts.grid(3, 7));
/*     */ 
/*     */     
/*  79 */     Dropdown<String> material = (new Dropdown("Material", selected, MATERIALS.stream().map(Material::name).toList())).formatter(GlassPlayground::pretty);
/*  80 */     controls.add((UiComponent)material);
/*  81 */     controls.add((UiComponent)new Slider("Refraction", refraction, 0.0D, 1.0D, 0.01D));
/*  82 */     Slider blur = new Slider("Blur mix", blurMix, 0.0D, 1.0D, 0.01D);
/*  83 */     blur.tooltip("Mixes the sharp scene with LQGlass's shared blurred scene.");
/*  84 */     controls.add((UiComponent)blur);
/*  85 */     Slider blurSpread = new Slider("Blur spread", spread, 0.0D, 1.0D, 0.01D);
/*  86 */     blurSpread.tooltip("Wider per-panel blur sampling. Costs extra texture reads on large panels.");
/*  87 */     controls.add((UiComponent)blurSpread);
/*  88 */     controls.add((UiComponent)new Slider("Color split", dispersion, 0.0D, 1.0D, 0.01D));
/*  89 */     controls.add((UiComponent)new Slider("Iridescence", film, 0.0D, 1.0D, 0.01D));
/*  90 */     controls.add((UiComponent)new Slider("Roughness", roughness, 0.0D, 1.0D, 0.01D));
/*  91 */     controls.add((UiComponent)new Slider("Edge width", edgeWidth, 0.0D, 24.0D, 0.5D));
/*  92 */     controls.add((UiComponent)new Slider("Tint angle", tintAngle, 0.0D, 360.0D, 1.0D));
/*  93 */     panel.add(controls);
/*  94 */     panel.add((UiComponent)new ColorPicker("Edge light", edgeLight));
/*     */     
/*  96 */     List<Material> catalog = MATERIALS;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 104 */     VirtualList<Material> list = (new VirtualList(catalog, 70, (entry, index) -> { GlassPanel card = (new GlassPanel()).glass(entry.style); card.layout(Layouts.column(3)); card.layoutSpec().padding(Insets.xy(12, 8)); card.add((UiComponent)Label.from((class_2561)class_2561.method_43470(entry.name).method_27694(()))); card.add((UiComponent)(new Label(entry.description)).color(-2827031)); return (UiComponent)card; })).overscan(2);
/* 105 */     list.layoutSpec().height(Length.px(150.0F));
/* 106 */     panel.add((UiComponent)list);
/*     */     
/* 108 */     UiContainer footer = new UiContainer(Layouts.row(8, Layouts.Align.CENTER, Layouts.Justify.END));
/* 109 */     Button reset = new Button("Reset controls", () -> {
/*     */           selected.set("AURORA");
/*     */           refraction.set(Double.valueOf(0.64D));
/*     */           dispersion.set(Double.valueOf(0.34D));
/*     */           film.set(Double.valueOf(0.82D));
/*     */           roughness.set(Double.valueOf(0.14D));
/*     */           blurMix.set(Double.valueOf(0.42D));
/*     */           spread.set(Double.valueOf(0.58D));
/*     */           edgeWidth.set(Double.valueOf(15.0D));
/*     */           tintAngle.set(Double.valueOf(120.0D));
/*     */           edgeLight.set(Integer.valueOf(-792334337));
/*     */         });
/* 121 */     footer.add((UiComponent)reset);
/* 122 */     panel.add(footer);
/* 123 */     root.add((UiComponent)panel);
/*     */     
/* 125 */     Runnable refresh = () -> {
/*     */         Material base = material((String)selected.get());
/*     */ 
/*     */ 
/*     */ 
/*     */         
/*     */         preview.glass(base.style.refraction(((Double)refraction.get()).floatValue()).blurBlend(((Double)blurMix.get()).floatValue()).chromaticAberration(((Double)dispersion.get()).floatValue()).iridescence(((Double)film.get()).floatValue()).roughness(((Double)roughness.get()).floatValue()).blurSpread(((Double)spread.get()).floatValue()).edgeWidth(((Double)edgeWidth.get()).floatValue()).tintAngle(((Double)tintAngle.get()).floatValue()).edgeLight(((Integer)edgeLight.get()).intValue()));
/*     */       };
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 137 */     selected.listen(value -> {
/*     */           GlassStyle style = (material(value)).style;
/*     */           refraction.set(Double.valueOf(style.refraction()));
/*     */           blurMix.set(Double.valueOf(style.blur()));
/*     */           dispersion.set(Double.valueOf(style.chromaticAberration()));
/*     */           film.set(Double.valueOf(style.iridescence()));
/*     */           roughness.set(Double.valueOf(style.roughness()));
/*     */           spread.set(Double.valueOf(style.blurSpread()));
/*     */           edgeWidth.set(Double.valueOf(style.edgeWidth()));
/*     */           tintAngle.set(Double.valueOf(style.tintAngle()));
/*     */           edgeLight.set(Integer.valueOf(style.edgeLight()));
/*     */           refresh.run();
/*     */         });
/* 150 */     refraction.listen(value -> refresh.run());
/* 151 */     dispersion.listen(value -> refresh.run());
/* 152 */     film.listen(value -> refresh.run());
/* 153 */     roughness.listen(value -> refresh.run());
/* 154 */     blurMix.listen(value -> refresh.run());
/* 155 */     spread.listen(value -> refresh.run());
/* 156 */     edgeWidth.listen(value -> refresh.run());
/* 157 */     tintAngle.listen(value -> refresh.run());
/* 158 */     edgeLight.listen(value -> refresh.run());
/* 159 */     refresh.run();
/*     */     
/* 161 */     GlassScreen screen = new GlassScreen((class_2561)class_2561.method_43470("LQGlass material lab"), root, LiquidGlassTheme.dark());
/* 162 */     footer.add((UiComponent)new Button("Stats", () -> screen.debug(!screen.debug())));
/* 163 */     footer.add((UiComponent)new Button("Close", () -> class_310.method_1551().method_1507(null)));
/* 164 */     return screen;
/*     */   }
/*     */   
/*     */   public static void open() {
/* 168 */     class_310.method_1551().method_1507(create());
/*     */   }
/*     */   
/*     */   private static Material material(String name) {
/* 172 */     for (Material material : MATERIALS) {
/* 173 */       if (material.name.equals(name))
/* 174 */         return material; 
/* 175 */     }  return MATERIALS.get(0);
/*     */   }
/*     */   
/*     */   private static String percent(float value) {
/* 179 */     return "" + Math.round(value * 100.0F) + "%";
/*     */   }
/*     */   
/*     */   private static String pretty(String name) {
/* 183 */     String value = (name == null) ? "" : name.toLowerCase();
/* 184 */     return value.isEmpty() ? value : ("" + Character.toUpperCase(value.charAt(0)) + Character.toUpperCase(value.charAt(0)));
/*     */   }
/*     */   private static final class Material extends Record { private final String name; private final GlassStyle style; private final String description;
/* 187 */     private Material(String name, GlassStyle style, String description) { this.name = name; this.style = style; this.description = description; } public final String toString() { // Byte code:
/*     */       //   0: aload_0
/*     */       //   1: <illegal opcode> toString : (Ldev/devswag/lqglass/ui/GlassPlayground$Material;)Ljava/lang/String;
/*     */       //   6: areturn
/*     */       // Line number table:
/*     */       //   Java source line number -> byte code offset
/*     */       //   #187	-> 0
/*     */       // Local variable table:
/*     */       //   start	length	slot	name	descriptor
/* 187 */       //   0	7	0	this	Ldev/devswag/lqglass/ui/GlassPlayground$Material; } public String name() { return this.name; } public final int hashCode() { // Byte code:
/*     */       //   0: aload_0
/*     */       //   1: <illegal opcode> hashCode : (Ldev/devswag/lqglass/ui/GlassPlayground$Material;)I
/*     */       //   6: ireturn
/*     */       // Line number table:
/*     */       //   Java source line number -> byte code offset
/*     */       //   #187	-> 0
/*     */       // Local variable table:
/*     */       //   start	length	slot	name	descriptor
/*     */       //   0	7	0	this	Ldev/devswag/lqglass/ui/GlassPlayground$Material; } public final boolean equals(Object o) { // Byte code:
/*     */       //   0: aload_0
/*     */       //   1: aload_1
/*     */       //   2: <illegal opcode> equals : (Ldev/devswag/lqglass/ui/GlassPlayground$Material;Ljava/lang/Object;)Z
/*     */       //   7: ireturn
/*     */       // Line number table:
/*     */       //   Java source line number -> byte code offset
/*     */       //   #187	-> 0
/*     */       // Local variable table:
/*     */       //   start	length	slot	name	descriptor
/*     */       //   0	8	0	this	Ldev/devswag/lqglass/ui/GlassPlayground$Material;
/* 187 */       //   0	8	1	o	Ljava/lang/Object; } public GlassStyle style() { return this.style; } public String description() { return this.description; }
/*     */      }
/*     */ 
/*     */ }


/* Location:              C:\Users\rapha\Downloads\aurora.jar!\META-INF\jars\lqglass-0.2.5.jar!\dev\devswag\lqglas\\ui\GlassPlayground.class
 * Java compiler version: 21 (65.0)
 * JD-Core Version:       1.1.3
 */