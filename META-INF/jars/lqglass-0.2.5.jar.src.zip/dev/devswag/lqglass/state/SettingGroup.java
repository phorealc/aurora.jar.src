/*    */ package dev.devswag.lqglass.state;
/*    */ 
/*    */ import java.util.ArrayList;
/*    */ import java.util.List;
/*    */ 
/*    */ public final class SettingGroup
/*    */ {
/*  8 */   private final List<SettingValue<?>> values = new ArrayList<>();
/*    */   
/*    */   public <T> SettingValue<T> add(SettingValue<T> value) {
/* 11 */     if (value == null)
/* 12 */       throw new IllegalArgumentException("value"); 
/* 13 */     if (!this.values.contains(value))
/* 14 */       this.values.add(value); 
/* 15 */     return value;
/*    */   }
/*    */   
/*    */   public boolean dirty() {
/* 19 */     for (SettingValue<?> value : this.values) {
/* 20 */       if (value.dirty())
/* 21 */         return true; 
/* 22 */     }  return false;
/*    */   }
/*    */   
/*    */   public void apply() {
/* 26 */     for (SettingValue<?> value : this.values)
/* 27 */       value.apply(); 
/*    */   }
/*    */   
/*    */   public void reset() {
/* 31 */     for (SettingValue<?> value : this.values)
/* 32 */       value.reset(); 
/*    */   }
/*    */   
/*    */   public void revert() {
/* 36 */     for (SettingValue<?> value : this.values)
/* 37 */       value.revert(); 
/*    */   }
/*    */   
/*    */   public int size() {
/* 41 */     return this.values.size();
/*    */   }
/*    */ }


/* Location:              C:\Users\rapha\Downloads\aurora.jar!\META-INF\jars\lqglass-0.2.5.jar!\dev\devswag\lqglass\state\SettingGroup.class
 * Java compiler version: 21 (65.0)
 * JD-Core Version:       1.1.3
 */