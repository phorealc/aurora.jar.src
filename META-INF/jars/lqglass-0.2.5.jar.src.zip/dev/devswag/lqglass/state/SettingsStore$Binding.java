/*     */ package dev.devswag.lqglass.state;
/*     */ 
/*     */ import java.util.Properties;
/*     */ import java.util.function.Function;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ final class Binding<T>
/*     */ {
/*     */   private final SettingValue<T> setting;
/*     */   private final Function<T, String> encode;
/*     */   private final Function<String, T> decode;
/*     */   
/*     */   private Binding(SettingValue<T> setting, Function<T, String> encode, Function<String, T> decode) {
/* 101 */     this.setting = setting;
/* 102 */     this.encode = encode;
/* 103 */     this.decode = decode;
/*     */   }
/*     */   
/*     */   private void write(String key, Properties values) {
/* 107 */     String stored = this.encode.apply(this.setting.get());
/* 108 */     values.setProperty(key, (stored == null) ? "" : stored);
/*     */   }
/*     */   
/*     */   private void read(String stored) {
/*     */     try {
/* 113 */       T value = this.decode.apply(stored);
/* 114 */       if (this.setting.set(value))
/* 115 */         this.setting.apply(); 
/* 116 */     } catch (RuntimeException runtimeException) {}
/*     */   }
/*     */ }


/* Location:              C:\Users\rapha\Downloads\aurora.jar!\META-INF\jars\lqglass-0.2.5.jar!\dev\devswag\lqglass\state\SettingsStore$Binding.class
 * Java compiler version: 21 (65.0)
 * JD-Core Version:       1.1.3
 */