/*    */ package dev.devswag.lqglass.state;
/*    */ public final class DoubleRange extends Record { private final double min;
/*    */   
/*  4 */   public double max() { return this.max; } private final double max; public double min() { return this.min; }
/*    */   
/*    */   public DoubleRange(double min, double max) {
/*  7 */     if (!Double.isFinite(min) || !Double.isFinite(max))
/*  8 */       throw new IllegalArgumentException("range"); 
/*  9 */     if (min > max) {
/* 10 */       double swap = min;
/* 11 */       min = max;
/* 12 */       max = swap;
/*    */     } 
/*    */     this.min = min;
/*    */     this.max = max;
/*    */   }
/*    */   
/*    */   public final boolean equals(Object o) {
/*    */     // Byte code:
/*    */     //   0: aload_0
/*    */     //   1: aload_1
/*    */     //   2: <illegal opcode> equals : (Ldev/devswag/lqglass/state/DoubleRange;Ljava/lang/Object;)Z
/*    */     //   7: ireturn
/*    */     // Line number table:
/*    */     //   Java source line number -> byte code offset
/*    */     //   #4	-> 0
/*    */     // Local variable table:
/*    */     //   start	length	slot	name	descriptor
/*    */     //   0	8	0	this	Ldev/devswag/lqglass/state/DoubleRange;
/*    */     //   0	8	1	o	Ljava/lang/Object;
/*    */   }
/*    */   
/*    */   public final int hashCode() {
/*    */     // Byte code:
/*    */     //   0: aload_0
/*    */     //   1: <illegal opcode> hashCode : (Ldev/devswag/lqglass/state/DoubleRange;)I
/*    */     //   6: ireturn
/*    */     // Line number table:
/*    */     //   Java source line number -> byte code offset
/*    */     //   #4	-> 0
/*    */     // Local variable table:
/*    */     //   start	length	slot	name	descriptor
/*    */     //   0	7	0	this	Ldev/devswag/lqglass/state/DoubleRange;
/*    */   }
/*    */   
/*    */   public final String toString() {
/*    */     // Byte code:
/*    */     //   0: aload_0
/*    */     //   1: <illegal opcode> toString : (Ldev/devswag/lqglass/state/DoubleRange;)Ljava/lang/String;
/*    */     //   6: areturn
/*    */     // Line number table:
/*    */     //   Java source line number -> byte code offset
/*    */     //   #4	-> 0
/*    */     // Local variable table:
/*    */     //   start	length	slot	name	descriptor
/*    */     //   0	7	0	this	Ldev/devswag/lqglass/state/DoubleRange;
/*    */   } }


/* Location:              C:\Users\rapha\Downloads\aurora.jar!\META-INF\jars\lqglass-0.2.5.jar!\dev\devswag\lqglass\state\DoubleRange.class
 * Java compiler version: 21 (65.0)
 * JD-Core Version:       1.1.3
 */