/*     */ package dev.devswag.lqglass.state;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.io.InputStream;
/*     */ import java.io.OutputStream;
/*     */ import java.nio.file.Files;
/*     */ import java.nio.file.Path;
/*     */ import java.nio.file.attribute.FileAttribute;
/*     */ import java.util.LinkedHashMap;
/*     */ import java.util.Map;
/*     */ import java.util.Properties;
/*     */ import java.util.function.Function;
/*     */ 
/*     */ public final class SettingsStore {
/*     */   private final Path file;
/*  16 */   private final Map<String, Binding<?>> bindings = new LinkedHashMap<>();
/*  17 */   private final Properties values = new Properties();
/*     */   
/*     */   public SettingsStore(Path file) {
/*  20 */     if (file == null)
/*  21 */       throw new IllegalArgumentException("file"); 
/*  22 */     this.file = file;
/*     */   }
/*     */ 
/*     */   
/*     */   public <T> SettingsStore bind(String key, SettingValue<T> setting, Function<T, String> encode, Function<String, T> decode) {
/*  27 */     if (key == null || key.isBlank() || setting == null || encode == null || decode == null)
/*  28 */       throw new IllegalArgumentException("binding"); 
/*  29 */     if (this.bindings.containsKey(key)) {
/*  30 */       throw new IllegalArgumentException("Duplicate setting key: " + key);
/*     */     }
/*  32 */     this.bindings.put(key, new Binding(setting, encode, decode));
/*  33 */     return this;
/*     */   }
/*     */   
/*     */   public SettingsStore bindBoolean(String key, SettingValue<Boolean> setting) {
/*  37 */     return bind(key, setting, String::valueOf, text -> {
/*     */           if (!"true".equalsIgnoreCase(text) && !"false".equalsIgnoreCase(text))
/*     */             throw new IllegalArgumentException("boolean"); 
/*     */           return Boolean.valueOf(Boolean.parseBoolean(text));
/*     */         });
/*     */   }
/*     */   
/*     */   public SettingsStore bindInt(String key, SettingValue<Integer> setting) {
/*  45 */     return bind(key, setting, String::valueOf, Integer::valueOf);
/*     */   }
/*     */   
/*     */   public SettingsStore bindDouble(String key, SettingValue<Double> setting) {
/*  49 */     return bind(key, setting, String::valueOf, Double::valueOf);
/*     */   }
/*     */   
/*     */   public SettingsStore bindString(String key, SettingValue<String> setting) {
/*  53 */     return bind(key, setting, Function.identity(), Function.identity());
/*     */   }
/*     */   
/*     */   public <E extends Enum<E>> SettingsStore bindEnum(String key, SettingValue<E> setting, Class<E> type) {
/*  57 */     if (type == null)
/*  58 */       throw new IllegalArgumentException("type"); 
/*  59 */     return bind(key, setting, Enum::name, text -> Enum.valueOf(type, text));
/*     */   }
/*     */   
/*     */   public void load() {
/*  63 */     this.values.clear();
/*  64 */     if (Files.isRegularFile(this.file, new java.nio.file.LinkOption[0])) {
/*  65 */       try { InputStream in = Files.newInputStream(this.file, new java.nio.file.OpenOption[0]); 
/*  66 */         try { this.values.load(in);
/*  67 */           if (in != null) in.close();  } catch (Throwable throwable) { if (in != null) try { in.close(); } catch (Throwable throwable1) { throwable.addSuppressed(throwable1); }   throw throwable; }  } catch (IOException e)
/*  68 */       { throw new IllegalStateException("Could not load settings from " + String.valueOf(this.file), e); }
/*     */     
/*     */     }
/*     */     
/*  72 */     for (Map.Entry<String, Binding<?>> entry : this.bindings.entrySet()) {
/*  73 */       String stored = this.values.getProperty(entry.getKey());
/*  74 */       if (stored != null)
/*  75 */         ((Binding)entry.getValue()).read(stored); 
/*     */     } 
/*     */   }
/*     */   
/*     */   public void save() {
/*  80 */     for (Map.Entry<String, Binding<?>> entry : this.bindings.entrySet()) {
/*  81 */       ((Binding)entry.getValue()).write(entry.getKey(), this.values);
/*     */     }
/*     */     
/*  84 */     try { Path parent = this.file.getParent();
/*  85 */       if (parent != null)
/*  86 */         Files.createDirectories(parent, (FileAttribute<?>[])new FileAttribute[0]); 
/*  87 */       OutputStream out = Files.newOutputStream(this.file, new java.nio.file.OpenOption[0]); 
/*  88 */       try { this.values.store(out, "LQGlass settings");
/*  89 */         if (out != null) out.close();  } catch (Throwable throwable) { if (out != null)
/*  90 */           try { out.close(); } catch (Throwable throwable1) { throwable.addSuppressed(throwable1); }   throw throwable; }  } catch (IOException e)
/*  91 */     { throw new IllegalStateException("Could not save settings to " + String.valueOf(this.file), e); }
/*     */   
/*     */   }
/*     */   
/*     */   private static final class Binding<T> {
/*     */     private final SettingValue<T> setting;
/*     */     private final Function<T, String> encode;
/*     */     private final Function<String, T> decode;
/*     */     
/*     */     private Binding(SettingValue<T> setting, Function<T, String> encode, Function<String, T> decode) {
/* 101 */       this.setting = setting;
/* 102 */       this.encode = encode;
/* 103 */       this.decode = decode;
/*     */     }
/*     */     
/*     */     private void write(String key, Properties values) {
/* 107 */       String stored = this.encode.apply(this.setting.get());
/* 108 */       values.setProperty(key, (stored == null) ? "" : stored);
/*     */     }
/*     */     
/*     */     private void read(String stored) {
/*     */       try {
/* 113 */         T value = this.decode.apply(stored);
/* 114 */         if (this.setting.set(value))
/* 115 */           this.setting.apply(); 
/* 116 */       } catch (RuntimeException runtimeException) {}
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\rapha\Downloads\aurora.jar!\META-INF\jars\lqglass-0.2.5.jar!\dev\devswag\lqglass\state\SettingsStore.class
 * Java compiler version: 21 (65.0)
 * JD-Core Version:       1.1.3
 */