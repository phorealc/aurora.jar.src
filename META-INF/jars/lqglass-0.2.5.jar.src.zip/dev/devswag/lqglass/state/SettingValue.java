/*     */ package dev.devswag.lqglass.state;
/*     */ 
/*     */ import java.util.ArrayList;
/*     */ import java.util.List;
/*     */ import java.util.Objects;
/*     */ import java.util.function.Consumer;
/*     */ import java.util.function.Predicate;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class SettingValue<T>
/*     */ {
/*     */   private final T defaultValue;
/*     */   private final Predicate<T> validator;
/*  17 */   private final List<Consumer<T>> listeners = new ArrayList<>();
/*     */   
/*     */   private T value;
/*     */   private T appliedValue;
/*     */   private boolean live;
/*     */   
/*     */   public SettingValue(T defaultValue) {
/*  24 */     this(defaultValue, value -> true);
/*     */   }
/*     */   
/*     */   public SettingValue(T defaultValue, Predicate<T> validator) {
/*  28 */     this.defaultValue = defaultValue;
/*  29 */     this.value = defaultValue;
/*  30 */     this.appliedValue = defaultValue;
/*  31 */     this.validator = (validator == null) ? (value -> true) : validator;
/*     */   }
/*     */   
/*     */   public T get() {
/*  35 */     return this.value;
/*     */   }
/*     */   
/*     */   public T defaultValue() {
/*  39 */     return this.defaultValue;
/*     */   }
/*     */   
/*     */   public T appliedValue() {
/*  43 */     return this.appliedValue;
/*     */   }
/*     */   
/*     */   public boolean set(T value) {
/*  47 */     if (!this.validator.test(value))
/*  48 */       return false; 
/*  49 */     if (Objects.equals(this.value, value)) {
/*  50 */       return true;
/*     */     }
/*  52 */     this.value = value;
/*  53 */     if (this.live)
/*  54 */       notifyListeners(value); 
/*  55 */     return true;
/*     */   }
/*     */   
/*     */   public boolean valid(T value) {
/*  59 */     return this.validator.test(value);
/*     */   }
/*     */   
/*     */   public boolean dirty() {
/*  63 */     return !Objects.equals(this.value, this.appliedValue);
/*     */   }
/*     */   
/*     */   public boolean live() {
/*  67 */     return this.live;
/*     */   }
/*     */   
/*     */   public SettingValue<T> live(boolean live) {
/*  71 */     this.live = live;
/*  72 */     return this;
/*     */   }
/*     */   
/*     */   public void reset() {
/*  76 */     set(this.defaultValue);
/*     */   }
/*     */   
/*     */   public void revert() {
/*  80 */     T previous = this.value;
/*  81 */     this.value = this.appliedValue;
/*  82 */     if (this.live && !Objects.equals(previous, this.value))
/*  83 */       notifyListeners(this.value); 
/*     */   }
/*     */   
/*     */   public void apply() {
/*  87 */     if (!dirty())
/*     */       return; 
/*  89 */     this.appliedValue = this.value;
/*  90 */     if (!this.live)
/*  91 */       notifyListeners(this.value); 
/*     */   }
/*     */   
/*     */   public SettingValue<T> listen(Consumer<T> listener) {
/*  95 */     if (listener != null)
/*  96 */       this.listeners.add(listener); 
/*  97 */     return this;
/*     */   }
/*     */   
/*     */   private void notifyListeners(T value) {
/* 101 */     for (Consumer<T> listener : this.listeners)
/* 102 */       listener.accept(value); 
/*     */   }
/*     */ }


/* Location:              C:\Users\rapha\Downloads\aurora.jar!\META-INF\jars\lqglass-0.2.5.jar!\dev\devswag\lqglass\state\SettingValue.class
 * Java compiler version: 21 (65.0)
 * JD-Core Version:       1.1.3
 */