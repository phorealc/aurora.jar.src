/*    */ package dev.devswag.lqglass.mixin;
/*    */ 
/*    */ import com.mojang.blaze3d.buffers.GpuBufferSlice;
/*    */ import dev.devswag.lqglass.render.minecraft.GlassGpu;
/*    */ import net.minecraft.class_11228;
/*    */ import net.minecraft.class_11246;
/*    */ import org.spongepowered.asm.mixin.Final;
/*    */ import org.spongepowered.asm.mixin.Mixin;
/*    */ import org.spongepowered.asm.mixin.Shadow;
/*    */ import org.spongepowered.asm.mixin.injection.At;
/*    */ import org.spongepowered.asm.mixin.injection.Inject;
/*    */ import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
/*    */ 
/*    */ @Mixin({class_11228.class})
/*    */ abstract class GuiRendererMixin {
/*    */   @Shadow
/*    */   @Final
/*    */   private class_11246 field_59914;
/*    */   
/*    */   @Inject(method = {"method_70890"}, at = {@At("HEAD")})
/*    */   private void lqglass$prepare(GpuBufferSlice fog, CallbackInfo ci) {
/* 22 */     GlassGpu.prepare(this.field_59914);
/*    */   }
/*    */   
/*    */   @Inject(method = {"close"}, at = {@At("HEAD")})
/*    */   private void lqglass$close(CallbackInfo ci) {
/* 27 */     GlassGpu.close();
/*    */   }
/*    */ }


/* Location:              C:\Users\rapha\Downloads\aurora.jar!\META-INF\jars\lqglass-0.2.5.jar!\dev\devswag\lqglass\mixin\GuiRendererMixin.class
 * Java compiler version: 21 (65.0)
 * JD-Core Version:       1.1.3
 */