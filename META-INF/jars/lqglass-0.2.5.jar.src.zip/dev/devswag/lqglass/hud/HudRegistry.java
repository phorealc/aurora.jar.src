/*     */ package dev.devswag.lqglass.hud;
/*     */ 
/*     */ import dev.devswag.lqglass.LQGlass;
/*     */ import dev.devswag.lqglass.render.GlassRenderer;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Collections;
/*     */ import java.util.Comparator;
/*     */ import java.util.List;
/*     */ import net.minecraft.class_2960;
/*     */ import net.minecraft.class_310;
/*     */ import net.minecraft.class_332;
/*     */ import net.minecraft.class_9779;
/*     */ 
/*     */ 
/*     */ public final class HudRegistry
/*     */ {
/*  17 */   private final List<GlassHudElement> elements = new ArrayList<>();
/*  18 */   private final List<GlassHudElement> view = Collections.unmodifiableList(this.elements);
/*  19 */   private final GlassRenderer renderer = new GlassRenderer();
/*     */   
/*     */   public GlassHudElement add(GlassHudElement element) {
/*  22 */     if (element == null)
/*  23 */       throw new IllegalArgumentException("element"); 
/*  24 */     if (get(element.id()) != null) {
/*  25 */       throw new IllegalArgumentException("Duplicate HUD id: " + String.valueOf(element.id()));
/*     */     }
/*  27 */     element.rememberProfileDefaults();
/*  28 */     LQGlass.hudLayouts().apply(element);
/*  29 */     this.elements.add(element);
/*  30 */     element.mount();
/*  31 */     return element;
/*     */   }
/*     */   
/*     */   public boolean remove(class_2960 id) {
/*  35 */     for (int i = 0; i < this.elements.size(); ) {
/*  36 */       GlassHudElement element = this.elements.get(i);
/*  37 */       if (!element.id().equals(id)) {
/*     */         i++; continue;
/*     */       } 
/*  40 */       LQGlass.hudLayouts().capture(element);
/*  41 */       this.elements.remove(i);
/*  42 */       element.unmount();
/*  43 */       return true;
/*     */     } 
/*  45 */     return false;
/*     */   }
/*     */   
/*     */   public GlassHudElement get(class_2960 id) {
/*  49 */     for (GlassHudElement element : this.elements) {
/*  50 */       if (element.id().equals(id))
/*  51 */         return element; 
/*  52 */     }  return null;
/*     */   }
/*     */   
/*     */   public List<GlassHudElement> elements() {
/*  56 */     return this.view;
/*     */   }
/*     */   
/*     */   public GlassRenderer renderer() {
/*  60 */     return this.renderer;
/*     */   }
/*     */   
/*     */   public String profile() {
/*  64 */     return LQGlass.hudLayouts().profile();
/*     */   }
/*     */   
/*     */   public HudRegistry profile(String name) {
/*  68 */     if (name == null || name.isBlank())
/*  69 */       throw new IllegalArgumentException("profile"); 
/*  70 */     if (name.equals(profile()))
/*  71 */       return this; 
/*  72 */     for (GlassHudElement element : this.elements)
/*  73 */       LQGlass.hudLayouts().capture(element); 
/*  74 */     LQGlass.hudLayouts().profile(name);
/*  75 */     for (GlassHudElement element : this.elements) {
/*  76 */       element.restoreProfileDefaults();
/*  77 */       LQGlass.hudLayouts().apply(element);
/*     */     } 
/*  79 */     return this;
/*     */   }
/*     */   
/*     */   public void render(class_332 graphics, class_9779 tickCounter) {
/*  83 */     if (this.elements.isEmpty()) {
/*     */       return;
/*     */     }
/*  86 */     if (this.elements.size() > 1) {
/*  87 */       this.elements.sort(Comparator.comparingInt(GlassHudElement::zOrder));
/*     */     }
/*  89 */     class_310 mc = class_310.method_1551();
/*  90 */     int mouseX = (int)Math.round(mc.field_1729.method_68879(mc.method_22683()));
/*  91 */     int mouseY = (int)Math.round(mc.field_1729.method_68883(mc.method_22683()));
/*  92 */     float delta = tickCounter.method_60637(false);
/*     */     
/*  94 */     this.renderer.beginFrame(false, mouseX, mouseY);
/*  95 */     for (GlassHudElement element : this.elements)
/*  96 */       element.render(graphics, this.renderer, LQGlass.theme(), mouseX, mouseY, delta); 
/*     */   }
/*     */   
/*     */   public void tick() {
/* 100 */     for (GlassHudElement element : this.elements)
/* 101 */       element.tick(); 
/*     */   }
/*     */   
/*     */   public void invalidateRenderState() {
/* 105 */     this.renderer.invalidate();
/* 106 */     for (GlassHudElement element : this.elements)
/* 107 */       element.root().invalidateLayout(); 
/*     */   }
/*     */   
/*     */   public void clear() {
/* 111 */     for (GlassHudElement element : this.elements)
/* 112 */       element.unmount(); 
/* 113 */     this.elements.clear();
/* 114 */     this.renderer.invalidate();
/*     */   }
/*     */ }


/* Location:              C:\Users\rapha\Downloads\aurora.jar!\META-INF\jars\lqglass-0.2.5.jar!\dev\devswag\lqglass\hud\HudRegistry.class
 * Java compiler version: 21 (65.0)
 * JD-Core Version:       1.1.3
 */