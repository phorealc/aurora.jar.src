/*    */ package dev.devswag.lqglass.hud;
/*    */ 
/*    */ import dev.devswag.lqglass.ui.UiBounds;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public final class HudPlacement
/*    */ {
/* 10 */   private Anchor anchor = Anchor.TOP_LEFT;
/*    */   private float percentX;
/*    */   private float percentY;
/*    */   private int offsetX;
/*    */   private int offsetY;
/* 15 */   private float scale = 1.0F;
/*    */   private float rotation;
/*    */   
/*    */   public Anchor anchor() {
/* 19 */     return this.anchor;
/*    */   }
/*    */   
/*    */   public HudPlacement anchor(Anchor anchor) {
/* 23 */     this.anchor = (anchor == null) ? Anchor.TOP_LEFT : anchor;
/* 24 */     return this;
/*    */   }
/*    */   
/*    */   public float percentX() {
/* 28 */     return this.percentX;
/*    */   }
/*    */   
/*    */   public float percentY() {
/* 32 */     return this.percentY;
/*    */   }
/*    */   
/*    */   public HudPlacement percent(float x, float y) {
/* 36 */     this.percentX = clampPercent(x);
/* 37 */     this.percentY = clampPercent(y);
/* 38 */     return this;
/*    */   }
/*    */   
/*    */   public int offsetX() {
/* 42 */     return this.offsetX;
/*    */   }
/*    */   
/*    */   public int offsetY() {
/* 46 */     return this.offsetY;
/*    */   }
/*    */   
/*    */   public HudPlacement offset(int x, int y) {
/* 50 */     this.offsetX = x;
/* 51 */     this.offsetY = y;
/* 52 */     return this;
/*    */   }
/*    */   
/*    */   public float scale() {
/* 56 */     return this.scale;
/*    */   }
/*    */   
/*    */   public HudPlacement scale(float scale) {
/* 60 */     if (!Float.isFinite(scale))
/* 61 */       throw new IllegalArgumentException("scale"); 
/* 62 */     this.scale = Math.max(0.1F, Math.min(8.0F, scale));
/* 63 */     return this;
/*    */   }
/*    */   
/*    */   public float rotation() {
/* 67 */     return this.rotation;
/*    */   }
/*    */   
/*    */   public HudPlacement rotation(float degrees) {
/* 71 */     if (!Float.isFinite(degrees))
/* 72 */       throw new IllegalArgumentException("rotation"); 
/* 73 */     this.rotation = degrees;
/* 74 */     return this;
/*    */   }
/*    */   
/*    */   public UiBounds bounds(int screenWidth, int screenHeight, int width, int height) {
/* 78 */     int w = Math.max(0, Math.round(width * this.scale));
/* 79 */     int h = Math.max(0, Math.round(height * this.scale));
/* 80 */     int x = this.anchor.x(screenWidth, w) + Math.round(screenWidth * this.percentX) + this.offsetX;
/* 81 */     int y = this.anchor.y(screenHeight, h) + Math.round(screenHeight * this.percentY) + this.offsetY;
/* 82 */     return new UiBounds(x, y, w, h);
/*    */   }
/*    */   
/*    */   public void reset() {
/* 86 */     this.anchor = Anchor.TOP_LEFT;
/* 87 */     this.percentX = 0.0F;
/* 88 */     this.percentY = 0.0F;
/* 89 */     this.offsetX = 0;
/* 90 */     this.offsetY = 0;
/* 91 */     this.scale = 1.0F;
/* 92 */     this.rotation = 0.0F;
/*    */   }
/*    */   
/*    */   private float clampPercent(float value) {
/* 96 */     if (!Float.isFinite(value))
/* 97 */       throw new IllegalArgumentException("percent"); 
/* 98 */     return Math.max(-1.0F, Math.min(1.0F, value));
/*    */   }
/*    */ }


/* Location:              C:\Users\rapha\Downloads\aurora.jar!\META-INF\jars\lqglass-0.2.5.jar!\dev\devswag\lqglass\hud\HudPlacement.class
 * Java compiler version: 21 (65.0)
 * JD-Core Version:       1.1.3
 */