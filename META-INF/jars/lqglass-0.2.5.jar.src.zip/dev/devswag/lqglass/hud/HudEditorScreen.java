/*     */ package dev.devswag.lqglass.hud;
/*     */ 
/*     */ import dev.devswag.lqglass.LQGlass;
/*     */ import dev.devswag.lqglass.render.GlassRenderer;
/*     */ import dev.devswag.lqglass.ui.UiBounds;
/*     */ import java.util.Objects;
/*     */ import net.minecraft.class_11908;
/*     */ import net.minecraft.class_11909;
/*     */ import net.minecraft.class_2561;
/*     */ import net.minecraft.class_332;
/*     */ import net.minecraft.class_437;
/*     */ 
/*     */ public final class HudEditorScreen
/*     */   extends class_437 {
/*     */   private final HudRegistry registry;
/*     */   private final HudLayoutStore layouts;
/*     */   private GlassHudElement selected;
/*     */   private int dragStartX;
/*     */   private int dragStartY;
/*     */   private int startOffsetX;
/*     */   private int startOffsetY;
/*     */   private int startWidth;
/*     */   private int startHeight;
/*     */   private boolean resizing;
/*  25 */   private int grid = 4;
/*     */   
/*     */   public HudEditorScreen(HudRegistry registry, HudLayoutStore layouts) {
/*  28 */     super((class_2561)class_2561.method_43470("HUD Editor"));
/*  29 */     if (registry == null || layouts == null)
/*  30 */       throw new IllegalArgumentException("hud editor"); 
/*  31 */     this.registry = registry;
/*  32 */     this.layouts = layouts;
/*     */   }
/*     */   
/*     */   public GlassHudElement selected() {
/*  36 */     return this.selected;
/*     */   }
/*     */   
/*     */   public HudEditorScreen grid(int grid) {
/*  40 */     this.grid = Math.max(1, grid);
/*  41 */     return this;
/*     */   }
/*     */ 
/*     */   
/*     */   public void method_25420(class_332 graphics, int mouseX, int mouseY, float delta) {
/*  46 */     graphics.method_25294(0, 0, this.field_22789, this.field_22790, 1426063360);
/*     */   }
/*     */ 
/*     */   
/*     */   public void method_25394(class_332 graphics, int mouseX, int mouseY, float delta) {
/*  51 */     GlassRenderer renderer = this.registry.renderer();
/*  52 */     renderer.beginFrame(false, mouseX, mouseY);
/*     */     
/*  54 */     for (GlassHudElement element : this.registry.elements()) {
/*  55 */       element.render(graphics, renderer, LQGlass.theme(), mouseX, mouseY, delta);
/*     */       
/*  57 */       UiBounds b = element.placement().bounds(this.field_22789, this.field_22790, element.width(), element.height());
/*  58 */       int color = (element == this.selected) ? -8607489 : -1996488705;
/*  59 */       outline(graphics, b, color);
/*     */       
/*  61 */       if (element == this.selected) {
/*  62 */         graphics.method_25294(b.right() - 4, b.bottom() - 4, b.right() + 1, b.bottom() + 1, -8607489);
/*  63 */         Objects.requireNonNull(this.field_22793); graphics.method_51433(this.field_22793, element.id().toString(), b.x(), Math.max(2, b.y() - 9 - 2), -1, true);
/*     */       } 
/*     */     } 
/*     */     
/*  67 */     if (this.selected != null) {
/*  68 */       int cx = this.field_22789 / 2;
/*  69 */       int cy = this.field_22790 / 2;
/*  70 */       graphics.method_25294(cx, 0, cx + 1, this.field_22790, 1149020415);
/*  71 */       graphics.method_25294(0, cy, this.field_22789, cy + 1, 1149020415);
/*     */     } 
/*     */     
/*  74 */     Objects.requireNonNull(this.field_22793); graphics.method_51433(this.field_22793, "drag move  |  corner resize  |  wheel scale  |  r reset  |  l lock", 8, this.field_22790 - 9 - 8, -855638017, true);
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean method_25402(class_11909 event, boolean doubled) {
/*  79 */     if (event.method_74245() != 0) {
/*  80 */       return super.method_25402(event, doubled);
/*     */     }
/*  82 */     this.selected = find(event.comp_4798(), event.comp_4799());
/*  83 */     if (this.selected == null || this.selected.locked()) {
/*  84 */       return (this.selected != null);
/*     */     }
/*  86 */     UiBounds b = this.selected.placement().bounds(this.field_22789, this.field_22790, this.selected.width(), this.selected.height());
/*  87 */     this.resizing = (event.comp_4798() >= (b.right() - 7) && event.comp_4799() >= (b.bottom() - 7));
/*  88 */     this.dragStartX = (int)Math.round(event.comp_4798());
/*  89 */     this.dragStartY = (int)Math.round(event.comp_4799());
/*  90 */     this.startOffsetX = this.selected.placement().offsetX();
/*  91 */     this.startOffsetY = this.selected.placement().offsetY();
/*  92 */     this.startWidth = this.selected.width();
/*  93 */     this.startHeight = this.selected.height();
/*  94 */     return true;
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean method_25403(class_11909 event, double dx, double dy) {
/*  99 */     if (this.selected == null || this.selected.locked() || event.method_74245() != 0) {
/* 100 */       return super.method_25403(event, dx, dy);
/*     */     }
/* 102 */     int mx = (int)Math.round(event.comp_4798());
/* 103 */     int my = (int)Math.round(event.comp_4799());
/*     */     
/* 105 */     if (this.resizing) {
/* 106 */       float scale = this.selected.placement().scale();
/* 107 */       int w = this.startWidth + Math.round((mx - this.dragStartX) / scale);
/* 108 */       int h = this.startHeight + Math.round((my - this.dragStartY) / scale);
/* 109 */       this.selected.size(Math.max(8, snap(w)), Math.max(8, snap(h)));
/*     */     } else {
/* 111 */       this.selected.placement().offset(
/* 112 */           snap(this.startOffsetX + mx - this.dragStartX), 
/* 113 */           snap(this.startOffsetY + my - this.dragStartY));
/*     */     } 
/*     */     
/* 116 */     return true;
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean method_25406(class_11909 event) {
/* 121 */     if (this.selected != null && event.method_74245() == 0) {
/* 122 */       this.resizing = false;
/* 123 */       this.layouts.capture(this.selected);
/* 124 */       this.layouts.save();
/* 125 */       return true;
/*     */     } 
/* 127 */     return super.method_25406(event);
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean method_25401(double mouseX, double mouseY, double horizontal, double vertical) {
/* 132 */     if (this.selected == null || this.selected.locked()) {
/* 133 */       return super.method_25401(mouseX, mouseY, horizontal, vertical);
/*     */     }
/* 135 */     float scale = this.selected.placement().scale();
/* 136 */     this.selected.placement().scale(scale + (float)vertical * 0.05F);
/* 137 */     this.layouts.capture(this.selected);
/* 138 */     this.layouts.save();
/* 139 */     return true;
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean method_25404(class_11908 event) {
/* 144 */     if (event.comp_4795() == 256) {
/* 145 */       method_25419();
/* 146 */       return true;
/*     */     } 
/*     */     
/* 149 */     if (this.selected == null) {
/* 150 */       return super.method_25404(event);
/*     */     }
/* 152 */     if (event.comp_4795() == 82) {
/* 153 */       this.layouts.reset(this.selected.id());
/* 154 */       this.selected.placement().reset();
/* 155 */       this.layouts.capture(this.selected);
/* 156 */       this.layouts.save();
/* 157 */       return true;
/*     */     } 
/*     */     
/* 160 */     if (event.comp_4795() == 76) {
/* 161 */       this.selected.locked(!this.selected.locked());
/* 162 */       this.layouts.capture(this.selected);
/* 163 */       this.layouts.save();
/* 164 */       return true;
/*     */     } 
/*     */     
/* 167 */     return super.method_25404(event);
/*     */   }
/*     */   
/*     */   private GlassHudElement find(double x, double y) {
/* 171 */     for (int i = this.registry.elements().size() - 1; i >= 0; i--) {
/* 172 */       GlassHudElement element = this.registry.elements().get(i);
/* 173 */       if (element.visible()) {
/*     */         
/* 175 */         UiBounds b = element.placement().bounds(this.field_22789, this.field_22790, element.width(), element.height());
/* 176 */         if (b.contains(x, y))
/* 177 */           return element; 
/*     */       } 
/* 179 */     }  return null;
/*     */   }
/*     */   
/*     */   private int snap(int value) {
/* 183 */     return Math.round(value / this.grid) * this.grid;
/*     */   }
/*     */   
/*     */   private void outline(class_332 g, UiBounds b, int color) {
/* 187 */     g.method_25294(b.x(), b.y(), b.right(), b.y() + 1, color);
/* 188 */     g.method_25294(b.x(), b.bottom() - 1, b.right(), b.bottom(), color);
/* 189 */     g.method_25294(b.x(), b.y(), b.x() + 1, b.bottom(), color);
/* 190 */     g.method_25294(b.right() - 1, b.y(), b.right(), b.bottom(), color);
/*     */   }
/*     */ }


/* Location:              C:\Users\rapha\Downloads\aurora.jar!\META-INF\jars\lqglass-0.2.5.jar!\dev\devswag\lqglass\hud\HudEditorScreen.class
 * Java compiler version: 21 (65.0)
 * JD-Core Version:       1.1.3
 */