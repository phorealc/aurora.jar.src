/*     */ package dev.devswag.lqglass.hud;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.io.InputStream;
/*     */ import java.io.OutputStream;
/*     */ import java.nio.file.Files;
/*     */ import java.nio.file.Path;
/*     */ import java.nio.file.attribute.FileAttribute;
/*     */ import java.util.Properties;
/*     */ import java.util.Set;
/*     */ import java.util.TreeSet;
/*     */ import net.minecraft.class_2960;
/*     */ 
/*     */ public final class HudLayoutStore
/*     */ {
/*     */   private final Path file;
/*  17 */   private final Properties values = new Properties();
/*  18 */   private String profile = "default";
/*     */   
/*     */   public HudLayoutStore(Path file) {
/*  21 */     this.file = file;
/*  22 */     load();
/*     */   }
/*     */   
/*     */   public String profile() {
/*  26 */     return this.profile;
/*     */   }
/*     */   
/*     */   public HudLayoutStore profile(String name) {
/*  30 */     if (name == null || !name.matches("[a-zA-Z0-9_-]{1,32}"))
/*  31 */       throw new IllegalArgumentException("profile"); 
/*  32 */     this.profile = name;
/*  33 */     return this;
/*     */   }
/*     */   
/*     */   public Set<String> profiles() {
/*  37 */     Set<String> profiles = new TreeSet<>();
/*  38 */     profiles.add("default");
/*  39 */     for (String property : this.values.stringPropertyNames()) {
/*  40 */       if (!property.startsWith("profiles."))
/*     */         continue; 
/*  42 */       int end = property.indexOf('.', 9);
/*  43 */       if (end > 9)
/*  44 */         profiles.add(property.substring(9, end)); 
/*     */     } 
/*  46 */     return Set.copyOf(profiles);
/*     */   }
/*     */   
/*     */   public void apply(GlassHudElement element) {
/*  50 */     String key = key(element.id());
/*  51 */     HudPlacement p = element.placement();
/*     */     
/*  53 */     p.anchor(parseAnchor(this.values.getProperty(key + ".anchor"), p.anchor()));
/*  54 */     p.percent(
/*  55 */         readFloat(key + ".percentX", p.percentX()), 
/*  56 */         readFloat(key + ".percentY", p.percentY()));
/*  57 */     p.offset(
/*  58 */         readInt(key + ".offsetX", p.offsetX()), 
/*  59 */         readInt(key + ".offsetY", p.offsetY()));
/*  60 */     p.scale(readFloat(key + ".scale", p.scale()));
/*  61 */     p.rotation(readFloat(key + ".rotation", p.rotation()));
/*     */     
/*  63 */     element.size(
/*  64 */         readInt(key + ".width", element.width()), 
/*  65 */         readInt(key + ".height", element.height()));
/*  66 */     element.locked(Boolean.parseBoolean(this.values.getProperty(key + ".locked", Boolean.toString(element.locked()))));
/*     */   }
/*     */   
/*     */   public void capture(GlassHudElement element) {
/*  70 */     String key = key(element.id());
/*  71 */     HudPlacement p = element.placement();
/*     */     
/*  73 */     this.values.setProperty(key + ".anchor", p.anchor().name());
/*  74 */     this.values.setProperty(key + ".percentX", Float.toString(p.percentX()));
/*  75 */     this.values.setProperty(key + ".percentY", Float.toString(p.percentY()));
/*  76 */     this.values.setProperty(key + ".offsetX", Integer.toString(p.offsetX()));
/*  77 */     this.values.setProperty(key + ".offsetY", Integer.toString(p.offsetY()));
/*  78 */     this.values.setProperty(key + ".scale", Float.toString(p.scale()));
/*  79 */     this.values.setProperty(key + ".rotation", Float.toString(p.rotation()));
/*  80 */     this.values.setProperty(key + ".width", Integer.toString(element.width()));
/*  81 */     this.values.setProperty(key + ".height", Integer.toString(element.height()));
/*  82 */     this.values.setProperty(key + ".locked", Boolean.toString(element.locked()));
/*     */   }
/*     */   
/*     */   public void save() {
/*  86 */     this.values.setProperty("meta.activeProfile", this.profile);
/*     */     
/*  88 */     try { Path parent = this.file.getParent();
/*  89 */       if (parent != null)
/*  90 */         Files.createDirectories(parent, (FileAttribute<?>[])new FileAttribute[0]); 
/*  91 */       OutputStream out = Files.newOutputStream(this.file, new java.nio.file.OpenOption[0]); 
/*  92 */       try { this.values.store(out, "LQGlass HUD layout");
/*  93 */         if (out != null) out.close();  } catch (Throwable throwable) { if (out != null)
/*  94 */           try { out.close(); } catch (Throwable throwable1) { throwable.addSuppressed(throwable1); }   throw throwable; }  } catch (IOException e)
/*  95 */     { throw new IllegalStateException("Could not save HUD layout to " + String.valueOf(this.file), e); }
/*     */   
/*     */   }
/*     */   
/*     */   public void load() {
/* 100 */     this.values.clear();
/* 101 */     this.profile = "default";
/* 102 */     if (!Files.isRegularFile(this.file, new java.nio.file.LinkOption[0]))
/*     */       return; 
/*     */     
/* 105 */     try { InputStream in = Files.newInputStream(this.file, new java.nio.file.OpenOption[0]); 
/* 106 */       try { this.values.load(in);
/* 107 */         String storedProfile = this.values.getProperty("meta.activeProfile");
/* 108 */         if (storedProfile != null && storedProfile.matches("[a-zA-Z0-9_-]{1,32}"))
/* 109 */           this.profile = storedProfile; 
/* 110 */         if (in != null) in.close();  } catch (Throwable throwable) { if (in != null) try { in.close(); } catch (Throwable throwable1) { throwable.addSuppressed(throwable1); }   throw throwable; }  } catch (IOException e)
/* 111 */     { throw new IllegalStateException("Could not load HUD layout from " + String.valueOf(this.file), e); }
/*     */   
/*     */   }
/*     */   
/*     */   public void reset(class_2960 id) {
/* 116 */     String prefix = key(id) + ".";
/* 117 */     this.values.keySet().removeIf(k -> k.toString().startsWith(prefix));
/*     */   }
/*     */   
/*     */   private String key(class_2960 id) {
/* 121 */     String key = id.method_12836() + "." + id.method_12836();
/* 122 */     return this.profile.equals("default") ? key : ("profiles." + this.profile + "." + key);
/*     */   }
/*     */   
/*     */   private int readInt(String key, int fallback) {
/*     */     try {
/* 127 */       return Integer.parseInt(this.values.getProperty(key));
/* 128 */     } catch (RuntimeException ignored) {
/* 129 */       return fallback;
/*     */     } 
/*     */   }
/*     */   
/*     */   private float readFloat(String key, float fallback) {
/*     */     try {
/* 135 */       return Float.parseFloat(this.values.getProperty(key));
/* 136 */     } catch (RuntimeException ignored) {
/* 137 */       return fallback;
/*     */     } 
/*     */   }
/*     */   
/*     */   private Anchor parseAnchor(String value, Anchor fallback) {
/* 142 */     if (value == null)
/* 143 */       return fallback; 
/*     */     try {
/* 145 */       return Anchor.valueOf(value);
/* 146 */     } catch (IllegalArgumentException ignored) {
/* 147 */       return fallback;
/*     */     } 
/*     */   }
/*     */ }


/* Location:              C:\Users\rapha\Downloads\aurora.jar!\META-INF\jars\lqglass-0.2.5.jar!\dev\devswag\lqglass\hud\HudLayoutStore.class
 * Java compiler version: 21 (65.0)
 * JD-Core Version:       1.1.3
 */