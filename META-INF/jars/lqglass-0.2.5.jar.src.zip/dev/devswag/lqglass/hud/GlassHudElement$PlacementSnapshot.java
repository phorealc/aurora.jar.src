/*     */ package dev.devswag.lqglass.hud;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ final class PlacementSnapshot
/*     */   extends Record
/*     */ {
/*     */   private final Anchor anchor;
/*     */   private final float percentX;
/*     */   private final float percentY;
/*     */   private final int offsetX;
/*     */   private final int offsetY;
/*     */   private final float scale;
/*     */   private final float rotation;
/*     */   private final int width;
/*     */   private final int height;
/*     */   private final boolean locked;
/*     */   
/*     */   public final String toString() {
/*     */     // Byte code:
/*     */     //   0: aload_0
/*     */     //   1: <illegal opcode> toString : (Ldev/devswag/lqglass/hud/GlassHudElement$PlacementSnapshot;)Ljava/lang/String;
/*     */     //   6: areturn
/*     */     // Line number table:
/*     */     //   Java source line number -> byte code offset
/*     */     //   #111	-> 0
/*     */     // Local variable table:
/*     */     //   start	length	slot	name	descriptor
/*     */     //   0	7	0	this	Ldev/devswag/lqglass/hud/GlassHudElement$PlacementSnapshot;
/*     */   }
/*     */   
/*     */   public final int hashCode() {
/*     */     // Byte code:
/*     */     //   0: aload_0
/*     */     //   1: <illegal opcode> hashCode : (Ldev/devswag/lqglass/hud/GlassHudElement$PlacementSnapshot;)I
/*     */     //   6: ireturn
/*     */     // Line number table:
/*     */     //   Java source line number -> byte code offset
/*     */     //   #111	-> 0
/*     */     // Local variable table:
/*     */     //   start	length	slot	name	descriptor
/*     */     //   0	7	0	this	Ldev/devswag/lqglass/hud/GlassHudElement$PlacementSnapshot;
/*     */   }
/*     */   
/*     */   public final boolean equals(Object o) {
/*     */     // Byte code:
/*     */     //   0: aload_0
/*     */     //   1: aload_1
/*     */     //   2: <illegal opcode> equals : (Ldev/devswag/lqglass/hud/GlassHudElement$PlacementSnapshot;Ljava/lang/Object;)Z
/*     */     //   7: ireturn
/*     */     // Line number table:
/*     */     //   Java source line number -> byte code offset
/*     */     //   #111	-> 0
/*     */     // Local variable table:
/*     */     //   start	length	slot	name	descriptor
/*     */     //   0	8	0	this	Ldev/devswag/lqglass/hud/GlassHudElement$PlacementSnapshot;
/*     */     //   0	8	1	o	Ljava/lang/Object;
/*     */   }
/*     */   
/*     */   private PlacementSnapshot(Anchor anchor, float percentX, float percentY, int offsetX, int offsetY, float scale, float rotation, int width, int height, boolean locked) {
/* 111 */     this.anchor = anchor; this.percentX = percentX; this.percentY = percentY; this.offsetX = offsetX; this.offsetY = offsetY; this.scale = scale; this.rotation = rotation; this.width = width; this.height = height; this.locked = locked; } public Anchor anchor() { return this.anchor; } public float percentX() { return this.percentX; } public float percentY() { return this.percentY; } public int offsetX() { return this.offsetX; } public int offsetY() { return this.offsetY; } public float scale() { return this.scale; } public float rotation() { return this.rotation; } public int width() { return this.width; } public int height() { return this.height; } public boolean locked() { return this.locked; }
/*     */ 
/*     */ }


/* Location:              C:\Users\rapha\Downloads\aurora.jar!\META-INF\jars\lqglass-0.2.5.jar!\dev\devswag\lqglass\hud\GlassHudElement$PlacementSnapshot.class
 * Java compiler version: 21 (65.0)
 * JD-Core Version:       1.1.3
 */