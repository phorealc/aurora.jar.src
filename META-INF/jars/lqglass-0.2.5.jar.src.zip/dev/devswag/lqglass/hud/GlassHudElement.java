/*     */ package dev.devswag.lqglass.hud;
/*     */ 
/*     */ import dev.devswag.lqglass.render.GlassRenderer;
/*     */ import dev.devswag.lqglass.style.LiquidGlassTheme;
/*     */ import dev.devswag.lqglass.ui.UiBounds;
/*     */ import dev.devswag.lqglass.ui.UiComponent;
/*     */ import dev.devswag.lqglass.ui.UiContext;
/*     */ import java.util.function.BooleanSupplier;
/*     */ import net.minecraft.class_156;
/*     */ import net.minecraft.class_2960;
/*     */ import net.minecraft.class_332;
/*     */ import org.joml.Matrix3x2fStack;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class GlassHudElement
/*     */ {
/*     */   private final class_2960 id;
/*     */   private final UiComponent root;
/*     */   private final HudPlacement placement;
/*     */   private int width;
/*     */   private int height;
/*     */   private int zOrder;
/*     */   private boolean locked;
/*     */   private BooleanSupplier visible = () -> true;
/*     */   private PlacementSnapshot defaults;
/*     */   
/*     */   public GlassHudElement(class_2960 id, UiComponent root, int width, int height) {
/*  30 */     if (id == null || root == null)
/*  31 */       throw new IllegalArgumentException("id/root"); 
/*  32 */     this.id = id;
/*  33 */     this.root = root;
/*  34 */     this.width = Math.max(1, width);
/*  35 */     this.height = Math.max(1, height);
/*  36 */     this.placement = new HudPlacement();
/*     */   }
/*     */   
/*     */   public class_2960 id() {
/*  40 */     return this.id;
/*     */   }
/*     */   
/*     */   public UiComponent root() {
/*  44 */     return this.root;
/*     */   }
/*     */   
/*     */   public HudPlacement placement() {
/*  48 */     return this.placement;
/*     */   }
/*     */   
/*     */   public int width() {
/*  52 */     return this.width;
/*     */   }
/*     */   
/*     */   public int height() {
/*  56 */     return this.height;
/*     */   }
/*     */   
/*     */   public GlassHudElement size(int width, int height) {
/*  60 */     this.width = Math.max(1, width);
/*  61 */     this.height = Math.max(1, height);
/*  62 */     this.root.invalidateLayout();
/*  63 */     return this;
/*     */   }
/*     */   
/*     */   public int zOrder() {
/*  67 */     return this.zOrder;
/*     */   }
/*     */   
/*     */   public GlassHudElement zOrder(int zOrder) {
/*  71 */     this.zOrder = zOrder;
/*  72 */     return this;
/*     */   }
/*     */   
/*     */   public boolean locked() {
/*  76 */     return this.locked;
/*     */   }
/*     */   
/*     */   public GlassHudElement locked(boolean locked) {
/*  80 */     this.locked = locked;
/*  81 */     return this;
/*     */   }
/*     */   
/*     */   public GlassHudElement visibleWhen(BooleanSupplier visible) {
/*  85 */     this.visible = (visible == null) ? (() -> true) : visible;
/*  86 */     return this;
/*     */   }
/*     */   
/*     */   boolean visible() {
/*  90 */     return this.visible.getAsBoolean();
/*     */   }
/*     */   
/*     */   void rememberProfileDefaults() {
/*  94 */     this
/*  95 */       .defaults = new PlacementSnapshot(this.placement.anchor(), this.placement.percentX(), this.placement.percentY(), this.placement.offsetX(), this.placement.offsetY(), this.placement.scale(), this.placement.rotation(), this.width, this.height, this.locked);
/*     */   }
/*     */ 
/*     */   
/*     */   void restoreProfileDefaults() {
/* 100 */     if (this.defaults == null)
/*     */       return; 
/* 102 */     this.placement.anchor(this.defaults.anchor)
/* 103 */       .percent(this.defaults.percentX, this.defaults.percentY)
/* 104 */       .offset(this.defaults.offsetX, this.defaults.offsetY)
/* 105 */       .scale(this.defaults.scale)
/* 106 */       .rotation(this.defaults.rotation);
/* 107 */     size(this.defaults.width, this.defaults.height);
/* 108 */     this.locked = this.defaults.locked;
/*     */   }
/*     */   private static final class PlacementSnapshot extends Record { private final Anchor anchor; private final float percentX; private final float percentY; private final int offsetX; private final int offsetY; private final float scale; private final float rotation; private final int width; private final int height; private final boolean locked;
/* 111 */     private PlacementSnapshot(Anchor anchor, float percentX, float percentY, int offsetX, int offsetY, float scale, float rotation, int width, int height, boolean locked) { this.anchor = anchor; this.percentX = percentX; this.percentY = percentY; this.offsetX = offsetX; this.offsetY = offsetY; this.scale = scale; this.rotation = rotation; this.width = width; this.height = height; this.locked = locked; } public final String toString() { // Byte code:
/*     */       //   0: aload_0
/*     */       //   1: <illegal opcode> toString : (Ldev/devswag/lqglass/hud/GlassHudElement$PlacementSnapshot;)Ljava/lang/String;
/*     */       //   6: areturn
/*     */       // Line number table:
/*     */       //   Java source line number -> byte code offset
/*     */       //   #111	-> 0
/*     */       // Local variable table:
/*     */       //   start	length	slot	name	descriptor
/* 111 */       //   0	7	0	this	Ldev/devswag/lqglass/hud/GlassHudElement$PlacementSnapshot; } public Anchor anchor() { return this.anchor; } public final int hashCode() { // Byte code:
/*     */       //   0: aload_0
/*     */       //   1: <illegal opcode> hashCode : (Ldev/devswag/lqglass/hud/GlassHudElement$PlacementSnapshot;)I
/*     */       //   6: ireturn
/*     */       // Line number table:
/*     */       //   Java source line number -> byte code offset
/*     */       //   #111	-> 0
/*     */       // Local variable table:
/*     */       //   start	length	slot	name	descriptor
/*     */       //   0	7	0	this	Ldev/devswag/lqglass/hud/GlassHudElement$PlacementSnapshot; } public final boolean equals(Object o) { // Byte code:
/*     */       //   0: aload_0
/*     */       //   1: aload_1
/*     */       //   2: <illegal opcode> equals : (Ldev/devswag/lqglass/hud/GlassHudElement$PlacementSnapshot;Ljava/lang/Object;)Z
/*     */       //   7: ireturn
/*     */       // Line number table:
/*     */       //   Java source line number -> byte code offset
/*     */       //   #111	-> 0
/*     */       // Local variable table:
/*     */       //   start	length	slot	name	descriptor
/*     */       //   0	8	0	this	Ldev/devswag/lqglass/hud/GlassHudElement$PlacementSnapshot;
/* 111 */       //   0	8	1	o	Ljava/lang/Object; } public float percentX() { return this.percentX; } public float percentY() { return this.percentY; } public int offsetX() { return this.offsetX; } public int offsetY() { return this.offsetY; } public float scale() { return this.scale; } public float rotation() { return this.rotation; } public int width() { return this.width; } public int height() { return this.height; } public boolean locked() { return this.locked; }
/*     */      }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   void render(class_332 graphics, GlassRenderer renderer, LiquidGlassTheme theme, int mouseX, int mouseY, float delta) {
/* 118 */     if (!visible()) {
/*     */       return;
/*     */     }
/* 121 */     UiBounds screen = this.placement.bounds(graphics.method_51421(), graphics.method_51443(), this.width, this.height);
/* 122 */     float scale = this.placement.scale();
/* 123 */     int localMouseX = Math.round((mouseX - screen.x()) / scale);
/* 124 */     int localMouseY = Math.round((mouseY - screen.y()) / scale);
/*     */     
/* 126 */     if (this.root.layoutDirty()) {
/* 127 */       this.root.layout(new UiBounds(0, 0, this.width, this.height));
/*     */     }
/* 129 */     Matrix3x2fStack pose = graphics.method_51448();
/* 130 */     pose.pushMatrix();
/* 131 */     pose.translate(screen.x(), screen.y());
/* 132 */     pose.scale(scale, scale);
/*     */     
/* 134 */     float rotation = this.placement.rotation();
/* 135 */     if (rotation != 0.0F) {
/* 136 */       pose.translate(this.width / 2.0F, this.height / 2.0F);
/* 137 */       pose.rotate((float)Math.toRadians(rotation));
/* 138 */       pose.translate(-this.width / 2.0F, -this.height / 2.0F);
/*     */     } 
/*     */     
/* 141 */     this.root.render(new UiContext(graphics, renderer, theme, localMouseX, localMouseY, delta, class_156.method_658()));
/* 142 */     pose.popMatrix();
/*     */   }
/*     */   
/*     */   void tick() {
/* 146 */     if (visible())
/* 147 */       this.root.tick(); 
/*     */   }
/*     */   
/*     */   void mount() {
/* 151 */     this.root.mount();
/*     */   }
/*     */   
/*     */   void unmount() {
/* 155 */     this.root.unmount();
/*     */   }
/*     */ }


/* Location:              C:\Users\rapha\Downloads\aurora.jar!\META-INF\jars\lqglass-0.2.5.jar!\dev\devswag\lqglass\hud\GlassHudElement.class
 * Java compiler version: 21 (65.0)
 * JD-Core Version:       1.1.3
 */