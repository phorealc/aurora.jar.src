/*    */ package dev.devswag.lqglass;
/*    */ import dev.devswag.lqglass.render.minecraft.GlassGpu;
/*    */ import java.util.Objects;
/*    */ import net.fabricmc.api.ClientModInitializer;
/*    */ import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientLifecycleEvents;
/*    */ import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
/*    */ import net.fabricmc.fabric.api.client.rendering.v1.InvalidateRenderStateCallback;
/*    */ import net.fabricmc.fabric.api.client.rendering.v1.hud.HudElementRegistry;
/*    */ import net.fabricmc.fabric.api.resource.v1.ResourceLoader;
/*    */ import net.minecraft.class_310;
/*    */ import net.minecraft.class_3264;
/*    */ import net.minecraft.class_3300;
/*    */ import net.minecraft.class_3302;
/*    */ 
/*    */ public final class LQGlassClient implements ClientModInitializer {
/*    */   public void onInitializeClient() {
/* 17 */     Objects.requireNonNull(LQGlass.hud()); HudElementRegistry.addLast(LQGlass.id("hud"), LQGlass.hud()::render);
/* 18 */     ClientTickEvents.END_CLIENT_TICK.register(client -> LQGlass.hud().tick());
/* 19 */     InvalidateRenderStateCallback.EVENT.register(() -> {
/*    */           LQGlass.hud().invalidateRenderState();
/*    */           GlassGpu.invalidate();
/*    */         });
/* 23 */     ResourceLoader.get(class_3264.field_14188).registerReloader(LQGlass.id("glass"), (class_3302)(resources -> GlassGpu.invalidate()));
/*    */     
/* 25 */     ClientLifecycleEvents.CLIENT_STOPPING.register(client -> {
/*    */           try {
/*    */             LQGlass.shutdown();
/*    */           } finally {
/*    */             GlassGpu.close();
/*    */           } 
/*    */         });
/*    */   }
/*    */ }


/* Location:              C:\Users\rapha\Downloads\aurora.jar!\META-INF\jars\lqglass-0.2.5.jar!\dev\devswag\lqglass\LQGlassClient.class
 * Java compiler version: 21 (65.0)
 * JD-Core Version:       1.1.3
 */