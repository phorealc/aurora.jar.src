/*    */ package dev.devswag.lqglass.render;
/*    */ 
/*    */ import dev.devswag.lqglass.render.minecraft.GlassGpu;
/*    */ import dev.devswag.lqglass.render.minecraft.GlassSurfaceState;
/*    */ import dev.devswag.lqglass.style.GlassStyle;
/*    */ import dev.devswag.lqglass.ui.UiBounds;
/*    */ import net.minecraft.class_11244;
/*    */ import net.minecraft.class_332;
/*    */ 
/*    */ public final class GlassRenderer {
/* 11 */   private final RenderStats stats = new RenderStats();
/* 12 */   private GlassQuality quality = GlassQuality.FULL_GLASS;
/*    */   private boolean backdrop;
/*    */   private int mouseX;
/*    */   private int mouseY;
/*    */   
/*    */   public void beginFrame(boolean allowBackdrop, int mouseX, int mouseY) {
/* 18 */     this.backdrop = allowBackdrop;
/* 19 */     this.mouseX = mouseX;
/* 20 */     this.mouseY = mouseY;
/* 21 */     this.stats.reset(GlassQuality.BASIC);
/*    */   }
/*    */   
/*    */   public GlassRenderer quality(GlassQuality quality) {
/* 25 */     if (quality == null)
/* 26 */       throw new IllegalArgumentException("quality"); 
/* 27 */     this.quality = quality;
/* 28 */     return this;
/*    */   }
/*    */   
/*    */   public GlassQuality quality() {
/* 32 */     return this.quality;
/*    */   }
/*    */ 
/*    */   
/*    */   public void prepareSharedBlur(class_332 graphics) {
/* 37 */     this.backdrop = true;
/*    */   }
/*    */   
/*    */   public void surface(class_332 graphics, UiBounds bounds, GlassStyle style) {
/* 41 */     surface(graphics, bounds, style, 1.0F);
/*    */   }
/*    */   
/*    */   public void surface(class_332 graphics, UiBounds bounds, GlassStyle style, float visibility) {
/* 45 */     GlassMath.finite(visibility, "visibility");
/* 46 */     if (style == null || visibility <= 0.0F || bounds.width() == 0 || bounds.height() == 0) {
/*    */       return;
/*    */     }
/* 49 */     GlassSurfaceState state = new GlassSurfaceState(graphics, bounds, style, this.quality, this.backdrop, this.mouseX, this.mouseY, Math.min(1.0F, visibility), this.stats);
/* 50 */     if (state.comp_4274() == null)
/*    */       return; 
/* 52 */     this.stats.surface();
/* 53 */     graphics.field_59826.method_70919((class_11244)state);
/*    */   }
/*    */   
/*    */   public GlassCapabilities capabilities() {
/* 57 */     return GlassGpu.capabilities();
/*    */   }
/*    */   
/*    */   public RenderStats stats() {
/* 61 */     return this.stats;
/*    */   }
/*    */   
/*    */   public void invalidate() {
/* 65 */     this.stats.reset(GlassQuality.BASIC);
/*    */   }
/*    */ }


/* Location:              C:\Users\rapha\Downloads\aurora.jar!\META-INF\jars\lqglass-0.2.5.jar!\dev\devswag\lqglass\render\GlassRenderer.class
 * Java compiler version: 21 (65.0)
 * JD-Core Version:       1.1.3
 */