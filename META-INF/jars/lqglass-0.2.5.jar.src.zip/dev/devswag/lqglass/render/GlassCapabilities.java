/*   */ package dev.devswag.lqglass.render;public final class GlassCapabilities extends Record { private final boolean sharedBlur; private final boolean backgroundSampling; private final boolean refraction; private final boolean clipping;
/*   */   private final boolean mouseLighting;
/*   */   
/* 4 */   public GlassCapabilities(boolean sharedBlur, boolean backgroundSampling, boolean refraction, boolean clipping, boolean mouseLighting) { this.sharedBlur = sharedBlur; this.backgroundSampling = backgroundSampling; this.refraction = refraction; this.clipping = clipping; this.mouseLighting = mouseLighting; } public final String toString() { // Byte code:
/*   */     //   0: aload_0
/*   */     //   1: <illegal opcode> toString : (Ldev/devswag/lqglass/render/GlassCapabilities;)Ljava/lang/String;
/*   */     //   6: areturn
/*   */     // Line number table:
/*   */     //   Java source line number -> byte code offset
/*   */     //   #4	-> 0
/*   */     // Local variable table:
/*   */     //   start	length	slot	name	descriptor
/* 4 */     //   0	7	0	this	Ldev/devswag/lqglass/render/GlassCapabilities; } public boolean sharedBlur() { return this.sharedBlur; } public final int hashCode() { // Byte code:
/*   */     //   0: aload_0
/*   */     //   1: <illegal opcode> hashCode : (Ldev/devswag/lqglass/render/GlassCapabilities;)I
/*   */     //   6: ireturn
/*   */     // Line number table:
/*   */     //   Java source line number -> byte code offset
/*   */     //   #4	-> 0
/*   */     // Local variable table:
/*   */     //   start	length	slot	name	descriptor
/*   */     //   0	7	0	this	Ldev/devswag/lqglass/render/GlassCapabilities; } public final boolean equals(Object o) { // Byte code:
/*   */     //   0: aload_0
/*   */     //   1: aload_1
/*   */     //   2: <illegal opcode> equals : (Ldev/devswag/lqglass/render/GlassCapabilities;Ljava/lang/Object;)Z
/*   */     //   7: ireturn
/*   */     // Line number table:
/*   */     //   Java source line number -> byte code offset
/*   */     //   #4	-> 0
/*   */     // Local variable table:
/*   */     //   start	length	slot	name	descriptor
/*   */     //   0	8	0	this	Ldev/devswag/lqglass/render/GlassCapabilities;
/* 4 */     //   0	8	1	o	Ljava/lang/Object; } public boolean backgroundSampling() { return this.backgroundSampling; } public boolean refraction() { return this.refraction; } public boolean clipping() { return this.clipping; } public boolean mouseLighting() { return this.mouseLighting; }
/*   */    }


/* Location:              C:\Users\rapha\Downloads\aurora.jar!\META-INF\jars\lqglass-0.2.5.jar!\dev\devswag\lqglass\render\GlassCapabilities.class
 * Java compiler version: 21 (65.0)
 * JD-Core Version:       1.1.3
 */