/*     */ package dev.devswag.lqglass.render.minecraft;
/*     */ 
/*     */ import com.mojang.blaze3d.pipeline.RenderPipeline;
/*     */ import dev.devswag.lqglass.render.GlassMath;
/*     */ import dev.devswag.lqglass.render.GlassQuality;
/*     */ import dev.devswag.lqglass.render.RenderStats;
/*     */ import dev.devswag.lqglass.style.GlassStyle;
/*     */ import dev.devswag.lqglass.ui.UiBounds;
/*     */ import net.minecraft.class_10799;
/*     */ import net.minecraft.class_11231;
/*     */ import net.minecraft.class_11244;
/*     */ import net.minecraft.class_332;
/*     */ import net.minecraft.class_4588;
/*     */ import net.minecraft.class_8030;
/*     */ import org.joml.Matrix3x2f;
/*     */ import org.joml.Matrix3x2fc;
/*     */ 
/*     */ public final class GlassSurfaceState implements class_11244 {
/*     */   final UiBounds box;
/*     */   final GlassStyle style;
/*     */   final GlassQuality requested;
/*     */   final boolean backdrop;
/*     */   final float visibility;
/*     */   final float mouseX;
/*     */   final float mouseY;
/*     */   final float pixelScale;
/*     */   final RenderStats stats;
/*     */   private final Matrix3x2f pose;
/*     */   private final class_8030 scissor;
/*     */   private final class_8030 bounds;
/*     */   private final int padding;
/*  32 */   private class_11231 textures = class_11231.method_70899();
/*  33 */   private int row = -1;
/*     */ 
/*     */   
/*     */   public GlassSurfaceState(class_332 graphics, UiBounds box, GlassStyle style, GlassQuality quality, boolean backdrop, float mouseX, float mouseY, float visibility, RenderStats stats) {
/*  37 */     this.box = box;
/*  38 */     this.style = style;
/*  39 */     this.requested = quality;
/*  40 */     this.backdrop = backdrop;
/*  41 */     this.visibility = visibility;
/*  42 */     this.stats = stats;
/*  43 */     this.pose = new Matrix3x2f((Matrix3x2fc)graphics.method_51448());
/*  44 */     this.scissor = graphics.field_44659.method_70863();
/*  45 */     this.padding = Math.max((style.outerGlow() >>> 24 == 0) ? 3 : 12, style.shadowSize() * 2 + 4);
/*     */     
/*  47 */     class_8030 extent = (new class_8030(box.x() - this.padding, box.y() - this.padding, box.width() + this.padding * 2, box.height() + this.padding * 2)).method_71523((Matrix3x2fc)this.pose);
/*  48 */     this.bounds = (this.scissor == null) ? extent : extent.method_49701(this.scissor);
/*  49 */     float det = this.pose.m00() * this.pose.m11() - this.pose.m01() * this.pose.m10();
/*  50 */     if (Math.abs(det) > 1.0E-6F) {
/*  51 */       float dx = mouseX - this.pose.m20();
/*  52 */       float dy = mouseY - this.pose.m21();
/*  53 */       this.mouseX = (this.pose.m11() * dx - this.pose.m10() * dy) / det - box.x();
/*  54 */       this.mouseY = (-this.pose.m01() * dx + this.pose.m00() * dy) / det - box.y();
/*     */     } else {
/*  56 */       this.mouseX = this.mouseY = -100000.0F;
/*     */     } 
/*  58 */     this.pixelScale = (float)Math.sqrt(Math.abs(det));
/*     */   }
/*     */   
/*     */   void prepare(int row, class_11231 textures) {
/*  62 */     this.row = row;
/*  63 */     this.textures = textures;
/*     */   }
/*     */ 
/*     */   
/*     */   public RenderPipeline comp_4055() {
/*  68 */     return (this.row >= 0) ? GlassPipelines.SURFACE : class_10799.field_56879;
/*     */   }
/*     */   
/*     */   public class_11231 comp_4056() {
/*  72 */     return this.textures;
/*     */   }
/*     */   public class_8030 comp_4069() {
/*  75 */     return this.scissor;
/*     */   }
/*     */   public class_8030 comp_4274() {
/*  78 */     return this.bounds;
/*     */   }
/*     */   
/*     */   public void method_70917(class_4588 out) {
/*  82 */     if (this.row < 0) {
/*  83 */       fallback(out);
/*     */       return;
/*     */     } 
/*  86 */     vertex(out, -this.padding, -this.padding);
/*  87 */     vertex(out, -this.padding, (this.box.height() + this.padding));
/*  88 */     vertex(out, (this.box.width() + this.padding), (this.box.height() + this.padding));
/*  89 */     vertex(out, (this.box.width() + this.padding), -this.padding);
/*     */   }
/*     */   
/*     */   private void vertex(class_4588 out, float x, float y) {
/*  93 */     position(out, x + this.box.x(), y + this.box.y());
/*  94 */     out.method_39415(this.style.tint()).method_22913(x, y).method_22921(this.row, 0);
/*     */   }
/*     */   
/*     */   private void position(class_4588 out, float x, float y) {
/*  98 */     out.method_22912(this.pose.m00() * x + this.pose.m10() * y + this.pose.m20(), this.pose
/*  99 */         .m01() * x + this.pose.m11() * y + this.pose.m21(), 0.0F);
/*     */   }
/*     */   
/*     */   private void quad(class_4588 out, int x1, int y1, int x2, int y2, int color) {
/* 103 */     if (x1 >= x2 || y1 >= y2 || color >>> 24 == 0)
/*     */       return; 
/* 105 */     position(out, x1, y1); out.method_39415(color);
/* 106 */     position(out, x1, y2); out.method_39415(color);
/* 107 */     position(out, x2, y2); out.method_39415(color);
/* 108 */     position(out, x2, y1); out.method_39415(color);
/*     */   }
/*     */   
/*     */   private void fallback(class_4588 out) {
/* 112 */     int w = this.box.width();
/* 113 */     int h = this.box.height();
/* 114 */     int tl = Math.round(GlassMath.radius(this.style.radius(), w, h));
/* 115 */     int tr = Math.round(GlassMath.radius(this.style.topRightRadius(), w, h));
/* 116 */     int br = Math.round(GlassMath.radius(this.style.bottomRightRadius(), w, h));
/* 117 */     int bl = Math.round(GlassMath.radius(this.style.bottomLeftRadius(), w, h));
/* 118 */     float fit = 1.0F;
/* 119 */     if (tl + tr > w)
/* 120 */       fit = Math.min(fit, w / (tl + tr)); 
/* 121 */     if (bl + br > w)
/* 122 */       fit = Math.min(fit, w / (bl + br)); 
/* 123 */     if (tl + bl > h)
/* 124 */       fit = Math.min(fit, h / (tl + bl)); 
/* 125 */     if (tr + br > h)
/* 126 */       fit = Math.min(fit, h / (tr + br)); 
/* 127 */     tl = Math.round(tl * fit);
/* 128 */     tr = Math.round(tr * fit);
/* 129 */     br = Math.round(br * fit);
/* 130 */     bl = Math.round(bl * fit);
/* 131 */     int body = GlassMath.alpha(this.style.tint(), this.style.opacity() * this.visibility);
/* 132 */     int border = GlassMath.alpha(this.style.borderColor(), this.visibility);
/* 133 */     for (int y = 0; y < h; y++) {
/* 134 */       int left = GlassMath.leftInset(y, h, tl, bl);
/* 135 */       int right = GlassMath.rightInset(y, h, tr, br);
/* 136 */       int x1 = this.box.x() + left;
/* 137 */       int x2 = this.box.right() - right;
/* 138 */       int top = this.box.y() + y;
/* 139 */       if (y == 0 || y == h - 1) {
/* 140 */         quad(out, x1, top, x2, top + 1, border);
/*     */       } else {
/* 142 */         int innerLeft = Math.max(left, 1 + GlassMath.leftInset(y - 1, Math.max(0, h - 2), 
/* 143 */               Math.max(0, tl - 1), Math.max(0, bl - 1)));
/* 144 */         int innerRight = Math.max(right, 1 + GlassMath.rightInset(y - 1, Math.max(0, h - 2), 
/* 145 */               Math.max(0, tr - 1), Math.max(0, br - 1)));
/* 146 */         quad(out, x1, top, this.box.x() + innerLeft, top + 1, border);
/* 147 */         quad(out, this.box.x() + innerLeft, top, this.box.right() - innerRight, top + 1, body);
/* 148 */         quad(out, this.box.right() - innerRight, top, x2, top + 1, border);
/*     */       } 
/*     */     } 
/*     */   }
/*     */ }


/* Location:              C:\Users\rapha\Downloads\aurora.jar!\META-INF\jars\lqglass-0.2.5.jar!\dev\devswag\lqglass\render\minecraft\GlassSurfaceState.class
 * Java compiler version: 21 (65.0)
 * JD-Core Version:       1.1.3
 */