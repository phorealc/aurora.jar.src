/*     */ package dev.devswag.lqglass.render.minecraft;
/*     */ 
/*     */ import com.mojang.blaze3d.buffers.GpuBuffer;
/*     */ import com.mojang.blaze3d.pipeline.RenderPipeline;
/*     */ import com.mojang.blaze3d.systems.CommandEncoder;
/*     */ import com.mojang.blaze3d.systems.GpuDevice;
/*     */ import com.mojang.blaze3d.systems.RenderPass;
/*     */ import com.mojang.blaze3d.systems.RenderSystem;
/*     */ import com.mojang.blaze3d.textures.FilterMode;
/*     */ import com.mojang.blaze3d.textures.GpuTexture;
/*     */ import com.mojang.blaze3d.textures.GpuTextureView;
/*     */ import com.mojang.blaze3d.textures.TextureFormat;
/*     */ import dev.devswag.lqglass.LQGlass;
/*     */ import dev.devswag.lqglass.render.GlassCapabilities;
/*     */ import dev.devswag.lqglass.render.GlassQuality;
/*     */ import java.nio.ByteBuffer;
/*     */ import java.nio.ByteOrder;
/*     */ import java.util.ArrayList;
/*     */ import java.util.OptionalInt;
/*     */ import net.minecraft.class_1011;
/*     */ import net.minecraft.class_11231;
/*     */ import net.minecraft.class_11244;
/*     */ import net.minecraft.class_11246;
/*     */ import net.minecraft.class_12137;
/*     */ import net.minecraft.class_310;
/*     */ import org.lwjgl.system.MemoryStack;
/*     */ import org.lwjgl.system.MemoryUtil;
/*     */ 
/*     */ public final class GlassGpu {
/*     */   private static final int TEXTURE_USAGE = 13;
/*     */   private static final long MAX_SCENE_PIXELS = 8388608L;
/*  32 */   private static final ArrayList<GlassSurfaceState> surfaces = new ArrayList<>(128);
/*     */   
/*     */   private static GpuDevice device;
/*     */   
/*     */   private static GpuTexture data;
/*     */   
/*     */   private static GpuTextureView dataView;
/*     */   private static GpuTexture neutral;
/*     */   private static GpuTextureView neutralView;
/*     */   private static GpuTexture scene;
/*     */   private static GpuTextureView sceneView;
/*     */   private static GpuTexture blurA;
/*     */   private static GpuTextureView blurAView;
/*     */   private static GpuTexture blurB;
/*     */   private static GpuTextureView blurBView;
/*     */   private static GpuBuffer horizontal;
/*     */   private static GpuBuffer vertical;
/*     */   private static ByteBuffer upload;
/*     */   private static GpuTexture lastSource;
/*     */   private static int lastWidth;
/*     */   private static int lastHeight;
/*     */   private static volatile boolean invalidated = true;
/*     */   private static boolean shaderBroken;
/*     */   private static boolean blurBroken;
/*     */   private static boolean captureBroken;
/*     */   private static boolean sampled;
/*     */   private static boolean blurred;
/*     */   private static int captures;
/*     */   private static int blurPasses;
/*     */   private static int scale;
/*     */   private static int idle;
/*     */   
/*     */   public static void invalidate() {
/*  65 */     invalidated = true;
/*     */   }
/*     */   
/*     */   public static GlassCapabilities capabilities() {
/*  69 */     return new GlassCapabilities(blurred, sampled, (sampled && !shaderBroken), true, (data != null && !shaderBroken));
/*     */   }
/*     */   
/*     */   public static void prepare(class_11246 state) {
/*  73 */     RenderSystem.assertOnRenderThread();
/*  74 */     GpuDevice current = RenderSystem.getDevice();
/*  75 */     if (invalidated || device != current) {
/*  76 */       invalidated = false;
/*  77 */       release();
/*  78 */       device = current;
/*  79 */       shaderBroken = blurBroken = captureBroken = false;
/*     */     } 
/*  81 */     surfaces.clear();
/*  82 */     sampled = blurred = false;
/*  83 */     captures = blurPasses = 0;
/*  84 */     state.method_71060(element -> { GlassSurfaceState surface; if (element instanceof GlassSurfaceState) { surface = (GlassSurfaceState)element; } else { return; }  if (surface.requested == GlassQuality.BASIC || surfaces.size() >= 1024) { surface.stats.prepared(GlassQuality.BASIC, 0, 0, 0); return; }  surfaces.add(surface); }class_11246.class_11325.field_60315);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*  93 */     if (surfaces.isEmpty()) {
/*  94 */       if (++idle == 120)
/*  95 */         close(); 
/*     */       return;
/*     */     } 
/*  98 */     idle = 0;
/*  99 */     if (!shaderBroken) {
/*     */       try {
/* 101 */         int i; initialize();
/* 102 */         boolean wantScene = false;
/* 103 */         boolean wantBlur = false;
/* 104 */         for (GlassSurfaceState surface : surfaces) {
/* 105 */           boolean backdrop = wantsScene(surface);
/* 106 */           wantScene |= backdrop;
/* 107 */           i = wantBlur | ((backdrop && wantsBlur(surface)) ? 1 : 0);
/*     */         } 
/* 109 */         if (wantScene && (class_310.method_1551()).field_1687 != null)
/* 110 */           capture(i); 
/* 111 */         submit();
/*     */         return;
/* 113 */       } catch (RuntimeException e) {
/* 114 */         shaderBroken = true;
/* 115 */         release();
/* 116 */         LQGlass.LOG.error("LQGlass surface pipeline/data upload failed; using basic panels until resource reload", e);
/*     */       } 
/*     */     }
/* 119 */     for (GlassSurfaceState surface : surfaces) {
/* 120 */       surface.prepare(-1, class_11231.method_70899());
/* 121 */       surface.stats.prepared(GlassQuality.BASIC, captures, blurPasses, 0);
/*     */     } 
/*     */   }
/*     */   
/*     */   private static boolean wantsScene(GlassSurfaceState surface) {
/* 126 */     return (surface.backdrop && surface.requested != GlassQuality.TRANSLUCENT_GLASS);
/*     */   }
/*     */   
/*     */   private static boolean wantsBlur(GlassSurfaceState surface) {
/* 130 */     return (surface.style.blur() > 0.0F && (surface.requested == GlassQuality.FULL_GLASS || surface.requested == GlassQuality.BLURRED_GLASS));
/*     */   }
/*     */ 
/*     */   
/*     */   private static void initialize() {
/* 135 */     if (data != null)
/*     */       return; 
/* 137 */     requirePipeline(GlassPipelines.SURFACE);
/* 138 */     upload = MemoryUtil.memAlloc(147456).order(ByteOrder.LITTLE_ENDIAN);
/* 139 */     data = device.createTexture("LQGlass materials", 13, TextureFormat.RGBA8, 36, 1024, 1, 1);
/* 140 */     dataView = device.createTextureView(data);
/* 141 */     neutral = device.createTexture("LQGlass neutral", 13, TextureFormat.RGBA8, 1, 1, 1, 1);
/* 142 */     neutralView = device.createTextureView(neutral);
/* 143 */     device.createCommandEncoder().clearColorTexture(neutral, -14670544);
/*     */   }
/*     */   
/*     */   private static void capture(boolean wantBlur) {
/*     */     try {
/* 148 */       GpuTexture source = class_310.method_1551().method_1522().method_30277();
/* 149 */       if (source == null || source.isClosed())
/*     */         return; 
/* 151 */       int w = source.getWidth(0);
/* 152 */       int h = source.getHeight(0);
/* 153 */       if (source != lastSource || w != lastWidth || h != lastHeight) {
/* 154 */         releaseScene();
/* 155 */         lastSource = source;
/* 156 */         lastWidth = w;
/* 157 */         lastHeight = h;
/* 158 */         captureBroken = false;
/*     */       } 
/* 160 */       if (captureBroken)
/*     */         return; 
/* 162 */       if (w * h > 8388608L || source.getFormat() != TextureFormat.RGBA8 || (source
/* 163 */         .usage() & 0x2) == 0)
/* 164 */         throw new IllegalStateException("unsupported scene target: " + w + "x" + h + " " + String.valueOf(source.getFormat())); 
/* 165 */       if (scene == null) {
/* 166 */         scene = device.createTexture("LQGlass scene", 13, TextureFormat.RGBA8, w, h, 1, 1);
/* 167 */         sceneView = device.createTextureView(scene);
/*     */       } 
/* 169 */       CommandEncoder encoder = device.createCommandEncoder();
/* 170 */       encoder.copyTextureToTexture(source, scene, 0, 0, 0, 0, 0, w, h);
/* 171 */       captures++;
/* 172 */       sampled = true;
/* 173 */       if (wantBlur && !blurBroken)
/* 174 */         blur(encoder, w, h); 
/* 175 */     } catch (RuntimeException e) {
/* 176 */       captureBroken = true;
/* 177 */       sampled = blurred = false;
/* 178 */       releaseScene();
/* 179 */       LQGlass.LOG.warn("LQGlass scene capture unavailable; using analytic glass until target replacement or resource reload", e);
/*     */     } 
/*     */   }
/*     */   
/*     */   private static void blur(CommandEncoder encoder, int width, int height) {
/*     */     try {
/* 185 */       int nextScale = Math.max(1, Math.round(class_310.method_1551().method_22683().method_4495()));
/* 186 */       if (blurA == null || scale != nextScale) {
/* 187 */         releaseBlur();
/* 188 */         requirePipeline(GlassPipelines.BLUR);
/* 189 */         int w = Math.max(1, (width + 3) / 4);
/* 190 */         int h = Math.max(1, (height + 3) / 4);
/* 191 */         blurA = device.createTexture("LQGlass blur horizontal", 13, TextureFormat.RGBA8, w, h, 1, 1);
/* 192 */         blurAView = device.createTextureView(blurA);
/* 193 */         blurB = device.createTexture("LQGlass blur vertical", 13, TextureFormat.RGBA8, w, h, 1, 1);
/* 194 */         blurBView = device.createTextureView(blurB);
/* 195 */         scale = nextScale;
/* 196 */         horizontal = config(2.0F * scale / width, 0.0F);
/* 197 */         vertical = config(0.0F, 2.0F * scale / height);
/*     */       } 
/* 199 */       pass(encoder, sceneView, blurAView, horizontal);
/* 200 */       blurPasses++;
/* 201 */       pass(encoder, blurAView, blurBView, vertical);
/* 202 */       blurPasses++;
/* 203 */       blurred = true;
/* 204 */     } catch (RuntimeException e) {
/* 205 */       blurBroken = true;
/* 206 */       blurred = false;
/* 207 */       releaseBlur();
/* 208 */       LQGlass.LOG.warn("LQGlass shared blur pipeline failed; keeping sharp scene refraction until resource reload", e);
/*     */     } 
/*     */   }
/*     */   
/*     */   private static GpuBuffer config(float x, float y) {
/* 213 */     MemoryStack stack = MemoryStack.stackPush(); 
/* 214 */     try { ByteBuffer bytes = stack.malloc(16).order(ByteOrder.nativeOrder());
/* 215 */       bytes.putFloat(x).putFloat(y).putFloat(0.0F).putFloat(0.0F).flip();
/* 216 */       GpuBuffer gpuBuffer = device.createBuffer(() -> "LQGlass blur step", 128, bytes);
/* 217 */       if (stack != null) stack.close();  return gpuBuffer; } catch (Throwable throwable) { if (stack != null)
/*     */         try { stack.close(); }
/*     */         catch (Throwable throwable1) { throwable.addSuppressed(throwable1); }
/*     */           throw throwable; }
/* 221 */      } private static void pass(CommandEncoder encoder, GpuTextureView input, GpuTextureView output, GpuBuffer config) { RenderPass pass = encoder.createRenderPass(() -> "LQGlass shared blur", output, OptionalInt.empty()); 
/* 222 */     try { pass.setPipeline(GlassPipelines.BLUR);
/* 223 */       pass.bindTexture("Sampler0", input, RenderSystem.getSamplerCache().method_75294(FilterMode.LINEAR));
/* 224 */       pass.setUniform("BlurConfig", config);
/* 225 */       pass.draw(0, 3);
/* 226 */       if (pass != null) pass.close();  } catch (Throwable throwable) { if (pass != null)
/*     */         try { pass.close(); }
/*     */         catch (Throwable throwable1) { throwable.addSuppressed(throwable1); }
/*     */           throw throwable; }
/* 230 */      } private static void submit() { int guiScale = Math.max(1, Math.round(class_310.method_1551().method_22683().method_4495()));
/* 231 */     upload.clear();
/* 232 */     for (GlassSurfaceState surface : surfaces) {
/* 233 */       boolean capture = (sampled && wantsScene(surface));
/* 234 */       boolean blur = (capture && blurred && wantsBlur(surface));
/* 235 */       float refraction = (surface.requested == GlassQuality.BLURRED_GLASS) ? 0.0F : surface.style.refraction();
/* 236 */       if (surface.requested == GlassQuality.REDUCED_GLASS)
/* 237 */         refraction *= 0.35F; 
/* 238 */       GlassData.put(upload, surface, capture, blur, refraction, guiScale);
/*     */     } 
/* 240 */     upload.flip();
/* 241 */     device.createCommandEncoder().writeToTexture(data, upload, class_1011.class_1012.field_4997, 0, 0, 0, 0, 36, surfaces
/* 242 */         .size());
/* 243 */     class_12137 linear = RenderSystem.getSamplerCache().method_75294(FilterMode.LINEAR);
/* 244 */     class_12137 nearest = RenderSystem.getSamplerCache().method_75294(FilterMode.NEAREST);
/*     */     
/* 246 */     class_11231 textures = new class_11231(sampled ? sceneView : neutralView, blurred ? blurBView : neutralView, dataView, linear, linear, nearest);
/* 247 */     for (int i = 0; i < surfaces.size(); i++) {
/* 248 */       GlassSurfaceState surface = surfaces.get(i);
/* 249 */       boolean capture = (sampled && wantsScene(surface));
/* 250 */       boolean blur = (capture && blurred && wantsBlur(surface));
/*     */ 
/*     */       
/* 253 */       GlassQuality actual = !capture ? GlassQuality.TRANSLUCENT_GLASS : (blur ? ((surface.requested == GlassQuality.BLURRED_GLASS) ? GlassQuality.BLURRED_GLASS : GlassQuality.FULL_GLASS) : GlassQuality.REDUCED_GLASS);
/* 254 */       surface.prepare(i, textures);
/* 255 */       surface.stats.prepared(actual, captures, blurPasses, targetCount());
/*     */     }  }
/*     */ 
/*     */   
/*     */   private static int targetCount() {
/* 260 */     return ((scene == null) ? 0 : 1) + ((blurA == null) ? 0 : 1) + ((blurB == null) ? 0 : 1);
/*     */   }
/*     */   
/*     */   private static void requirePipeline(RenderPipeline pipeline) {
/* 264 */     if (!device.precompilePipeline(pipeline).isValid())
/* 265 */       throw new IllegalStateException("invalid shader pipeline " + String.valueOf(pipeline.getLocation())); 
/*     */   }
/*     */   
/*     */   public static void close() {
/* 269 */     RenderSystem.assertOnRenderThread();
/* 270 */     release();
/* 271 */     surfaces.clear();
/* 272 */     device = null;
/* 273 */     invalidated = true;
/*     */   }
/*     */   
/*     */   private static void release() {
/* 277 */     releaseScene();
/* 278 */     if (dataView != null) { dataView.close(); dataView = null; }
/* 279 */      if (data != null) { data.close(); data = null; }
/* 280 */      if (neutralView != null) { neutralView.close(); neutralView = null; }
/* 281 */      if (neutral != null) { neutral.close(); neutral = null; }
/* 282 */      if (upload != null) { MemoryUtil.memFree(upload); upload = null; }
/* 283 */      lastSource = null;
/* 284 */     sampled = blurred = false;
/*     */   }
/*     */   
/*     */   private static void releaseScene() {
/* 288 */     releaseBlur();
/* 289 */     if (sceneView != null) { sceneView.close(); sceneView = null; }
/* 290 */      if (scene != null) { scene.close(); scene = null; }
/*     */   
/*     */   }
/*     */   private static void releaseBlur() {
/* 294 */     if (horizontal != null) { horizontal.close(); horizontal = null; }
/* 295 */      if (vertical != null) { vertical.close(); vertical = null; }
/* 296 */      if (blurAView != null) { blurAView.close(); blurAView = null; }
/* 297 */      if (blurA != null) { blurA.close(); blurA = null; }
/* 298 */      if (blurBView != null) { blurBView.close(); blurBView = null; }
/* 299 */      if (blurB != null) { blurB.close(); blurB = null; }
/*     */   
/*     */   }
/*     */ }


/* Location:              C:\Users\rapha\Downloads\aurora.jar!\META-INF\jars\lqglass-0.2.5.jar!\dev\devswag\lqglass\render\minecraft\GlassGpu.class
 * Java compiler version: 21 (65.0)
 * JD-Core Version:       1.1.3
 */