/*    */ package dev.devswag.lqglass.render.minecraft;
/*    */ 
/*    */ import com.mojang.blaze3d.pipeline.BlendFunction;
/*    */ import com.mojang.blaze3d.pipeline.RenderPipeline;
/*    */ import com.mojang.blaze3d.platform.DepthTestFunction;
/*    */ import com.mojang.blaze3d.vertex.VertexFormat;
/*    */ import net.minecraft.class_10789;
/*    */ import net.minecraft.class_290;
/*    */ import net.minecraft.class_2960;
/*    */ 
/*    */ final class GlassPipelines
/*    */ {
/* 13 */   static final RenderPipeline SURFACE = RenderPipeline.builder(new RenderPipeline.Snippet[0])
/* 14 */     .withLocation(id("pipeline/glass"))
/* 15 */     .withVertexShader(id("core/glass"))
/* 16 */     .withFragmentShader(id("core/glass"))
/* 17 */     .withVertexFormat(class_290.field_20888, VertexFormat.class_5596.field_27382)
/* 18 */     .withUniform("DynamicTransforms", class_10789.field_60031)
/* 19 */     .withUniform("Projection", class_10789.field_60031)
/* 20 */     .withSampler("Sampler0").withSampler("Sampler1").withSampler("Sampler2")
/* 21 */     .withBlend(BlendFunction.TRANSLUCENT)
/* 22 */     .withDepthTestFunction(DepthTestFunction.NO_DEPTH_TEST)
/* 23 */     .withDepthWrite(false).withCull(false)
/* 24 */     .build();
/*    */   
/* 26 */   static final RenderPipeline BLUR = RenderPipeline.builder(new RenderPipeline.Snippet[0])
/* 27 */     .withLocation(id("pipeline/blur"))
/* 28 */     .withVertexShader(id("core/blur"))
/* 29 */     .withFragmentShader(id("core/blur"))
/* 30 */     .withVertexFormat(class_290.field_60033, VertexFormat.class_5596.field_27379)
/* 31 */     .withUniform("BlurConfig", class_10789.field_60031)
/* 32 */     .withSampler("Sampler0")
/* 33 */     .withoutBlend().withDepthTestFunction(DepthTestFunction.NO_DEPTH_TEST)
/* 34 */     .withDepthWrite(false).withCull(false)
/* 35 */     .build();
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   private static class_2960 id(String path) {
/* 41 */     return class_2960.method_60655("lqglass", path);
/*    */   }
/*    */ }


/* Location:              C:\Users\rapha\Downloads\aurora.jar!\META-INF\jars\lqglass-0.2.5.jar!\dev\devswag\lqglass\render\minecraft\GlassPipelines.class
 * Java compiler version: 21 (65.0)
 * JD-Core Version:       1.1.3
 */