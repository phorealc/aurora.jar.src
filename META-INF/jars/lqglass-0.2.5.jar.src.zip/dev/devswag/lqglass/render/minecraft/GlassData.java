/*    */ package dev.devswag.lqglass.render.minecraft;
/*    */ 
/*    */ import dev.devswag.lqglass.style.GlassStyle;
/*    */ import java.nio.ByteBuffer;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ final class GlassData
/*    */ {
/*    */   static final int COLUMNS = 36;
/*    */   static final int CAPACITY = 1024;
/*    */   
/*    */   static void put(ByteBuffer data, GlassSurfaceState s, boolean sampled, boolean blurred, float refraction, int guiScale) {
/* 15 */     GlassStyle g = s.style;
/* 16 */     data.putFloat(s.box.width()).putFloat(s.box.height()).putFloat(g.radius()).putFloat(g.opacity());
/* 17 */     data.putFloat(g.blur()).putFloat(refraction).putFloat(g.saturation()).putFloat(g.contrast());
/* 18 */     data.putFloat(g.noise()).putInt(g.borderColor()).putInt(g.shadowColor()).putFloat(g.shadowSize());
/* 19 */     data.putInt(g.innerGlow()).putInt(g.outerGlow()).putFloat(g.highlight()).putFloat(g.mouseReactive() ? 1.0F : 0.0F);
/* 20 */     data.putFloat(s.mouseX).putFloat(s.mouseY).putFloat(s.visibility).putFloat(sampled ? 1.0F : 0.0F);
/* 21 */     data.putFloat(blurred ? 1.0F : 0.0F).putFloat(guiScale * s.pixelScale);
/* 22 */     data.putFloat(g.topRightRadius()).putFloat(g.bottomRightRadius()).putFloat(g.bottomLeftRadius());
/* 23 */     data.putFloat(g.chromaticAberration()).putFloat(g.iridescence()).putFloat(g.roughness());
/* 24 */     data.putInt(g.tintBottom()).putFloat(g.lightAngle()).putFloat(g.blurSpread()).putFloat(g.edgeWidth());
/* 25 */     data.putFloat(g.tintAngle()).putInt(g.edgeLight()).putFloat(0.0F).putFloat(0.0F);
/*    */   }
/*    */ }


/* Location:              C:\Users\rapha\Downloads\aurora.jar!\META-INF\jars\lqglass-0.2.5.jar!\dev\devswag\lqglass\render\minecraft\GlassData.class
 * Java compiler version: 21 (65.0)
 * JD-Core Version:       1.1.3
 */