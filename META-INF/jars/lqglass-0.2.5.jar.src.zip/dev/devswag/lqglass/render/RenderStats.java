/*    */ package dev.devswag.lqglass.render;
/*    */ 
/*    */ public final class RenderStats
/*    */ {
/*    */   private int surfaces;
/*    */   private int fills;
/*    */   private int blurPasses;
/*    */   private int captures;
/*    */   private int targets;
/*    */   private int clipped;
/*    */   private int shaderSurfaces;
/*    */   private int fallbackSurfaces;
/* 13 */   private GlassQuality quality = GlassQuality.BASIC;
/*    */   
/* 15 */   public int surfaces() { return this.surfaces; }
/* 16 */   public int fills() { return this.fills; }
/* 17 */   public int blurPasses() { return this.blurPasses; }
/* 18 */   public int captures() { return this.captures; }
/* 19 */   public int targets() { return this.targets; }
/* 20 */   public int clipped() { return this.clipped; }
/* 21 */   public int shaderSurfaces() { return this.shaderSurfaces; }
/* 22 */   public int fallbackSurfaces() { return this.fallbackSurfaces; } public GlassQuality quality() {
/* 23 */     return this.quality;
/*    */   }
/*    */   void reset(GlassQuality quality) {
/* 26 */     this.surfaces = this.fills = this.blurPasses = this.captures = this.targets = this.clipped = this.shaderSurfaces = this.fallbackSurfaces = 0;
/* 27 */     this.quality = quality;
/*    */   }
/*    */   
/* 30 */   void surface() { this.surfaces++; }
/* 31 */   void fills(int count) { this.fills += count; }
/* 32 */   void blur() { this.blurPasses++; } public void clip() {
/* 33 */     this.clipped++;
/*    */   }
/*    */   public void prepared(GlassQuality actual, int captures, int passes, int targets) {
/* 36 */     this.captures = captures;
/* 37 */     this.blurPasses = passes;
/* 38 */     this.targets = targets;
/* 39 */     if (actual == GlassQuality.BASIC) {
/* 40 */       this.fallbackSurfaces++;
/*    */     } else {
/* 42 */       this.shaderSurfaces++;
/* 43 */     }  if (this.quality == GlassQuality.BASIC || actual.ordinal() < this.quality.ordinal())
/* 44 */       this.quality = actual; 
/*    */   }
/*    */ }


/* Location:              C:\Users\rapha\Downloads\aurora.jar!\META-INF\jars\lqglass-0.2.5.jar!\dev\devswag\lqglass\render\RenderStats.class
 * Java compiler version: 21 (65.0)
 * JD-Core Version:       1.1.3
 */