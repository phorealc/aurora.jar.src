/*    */ package dev.devswag.lqglass.render;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public final class GlassMath
/*    */ {
/*    */   public static float finite(float value, String name) {
/*  9 */     if (!Float.isFinite(value))
/* 10 */       throw new IllegalArgumentException(name + " must be finite"); 
/* 11 */     return value;
/*    */   }
/*    */   
/*    */   public static float clamp(float value, float min, float max) {
/* 15 */     return Math.max(min, Math.min(max, value));
/*    */   }
/*    */   
/*    */   public static float radius(float radius, float width, float height) {
/* 19 */     return Math.max(0.0F, Math.min(radius, Math.min(width, height) * 0.5F));
/*    */   }
/*    */   
/*    */   public static float distance(float x, float y, float width, float height, float radius) {
/* 23 */     float r = radius(radius, width, height);
/* 24 */     float dx = Math.abs(x - width * 0.5F) - width * 0.5F + r;
/* 25 */     float dy = Math.abs(y - height * 0.5F) - height * 0.5F + r;
/* 26 */     return (float)Math.hypot(Math.max(dx, 0.0F), Math.max(dy, 0.0F)) + 
/* 27 */       Math.min(Math.max(dx, dy), 0.0F) - r;
/*    */   }
/*    */   
/*    */   public static int inset(int y, int width, int height, int radius) {
/* 31 */     float r = radius(radius, width, height);
/* 32 */     return cornerInset(Math.min(y, height - 1 - y), Math.round(r));
/*    */   }
/*    */   
/*    */   public static int leftInset(int y, int height, int topLeft, int bottomLeft) {
/* 36 */     int depth = (y < topLeft) ? y : (height - 1 - y);
/* 37 */     int radius = (y < topLeft) ? topLeft : ((y >= height - bottomLeft) ? bottomLeft : 0);
/* 38 */     return cornerInset(depth, radius);
/*    */   }
/*    */   
/*    */   public static int rightInset(int y, int height, int topRight, int bottomRight) {
/* 42 */     int depth = (y < topRight) ? y : (height - 1 - y);
/* 43 */     int radius = (y < topRight) ? topRight : ((y >= height - bottomRight) ? bottomRight : 0);
/* 44 */     return cornerInset(depth, radius);
/*    */   }
/*    */   
/*    */   private static int cornerInset(int depth, int radius) {
/* 48 */     float r = Math.max(0, radius);
/* 49 */     float dy = Math.max(0.0F, r - depth + 0.5F);
/* 50 */     return Math.max(0, (int)Math.ceil(r - Math.sqrt(Math.max(0.0F, r * r - dy * dy)) - 0.5D));
/*    */   }
/*    */   
/*    */   public static int alpha(int color, float opacity) {
/* 54 */     return Math.round((color >>> 24) * clamp(opacity, 0.0F, 1.0F)) << 24 | color & 0xFFFFFF;
/*    */   }
/*    */   
/*    */   public static float fresnel(float cosine) {
/* 58 */     float t = 1.0F - clamp(cosine, 0.0F, 1.0F);
/* 59 */     return 0.04F + 0.96F * t * t * t * t * t;
/*    */   }
/*    */ }


/* Location:              C:\Users\rapha\Downloads\aurora.jar!\META-INF\jars\lqglass-0.2.5.jar!\dev\devswag\lqglass\render\GlassMath.class
 * Java compiler version: 21 (65.0)
 * JD-Core Version:       1.1.3
 */