/*     */ package imgui;
/*     */ 
/*     */ import imgui.binding.ImGuiStructDestroyable;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class ImGuiStorage
/*     */   extends ImGuiStructDestroyable
/*     */ {
/*     */   public ImGuiStorage() {}
/*     */   
/*     */   public ImGuiStorage(long ptr) {
/*  21 */     super(ptr);
/*     */   }
/*     */ 
/*     */   
/*     */   protected long create() {
/*  26 */     return nCreate();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private native long nCreate();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void clear() {
/*  43 */     nClear();
/*     */   }
/*     */ 
/*     */   
/*     */   private native void nClear();
/*     */ 
/*     */   
/*     */   public int getInt(int key) {
/*  51 */     return nGetInt(key);
/*     */   }
/*     */   
/*     */   public int getInt(int key, int defaultVal) {
/*  55 */     return nGetInt(key, defaultVal);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private native int nGetInt(int paramInt);
/*     */ 
/*     */   
/*     */   private native int nGetInt(int paramInt1, int paramInt2);
/*     */ 
/*     */   
/*     */   public void setInt(int key, int val) {
/*  67 */     nSetInt(key, val);
/*     */   }
/*     */ 
/*     */   
/*     */   private native void nSetInt(int paramInt1, int paramInt2);
/*     */ 
/*     */   
/*     */   public boolean getBool(int key) {
/*  75 */     return nGetBool(key);
/*     */   }
/*     */   
/*     */   public boolean getBool(int key, boolean defaultVal) {
/*  79 */     return nGetBool(key, defaultVal);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private native boolean nGetBool(int paramInt);
/*     */ 
/*     */   
/*     */   private native boolean nGetBool(int paramInt, boolean paramBoolean);
/*     */ 
/*     */   
/*     */   public void setBool(int key, boolean val) {
/*  91 */     nSetBool(key, val);
/*     */   }
/*     */ 
/*     */   
/*     */   private native void nSetBool(int paramInt, boolean paramBoolean);
/*     */ 
/*     */   
/*     */   public float getFloat(int key) {
/*  99 */     return nGetFloat(key);
/*     */   }
/*     */   
/*     */   public float getFloat(int key, float defaultVal) {
/* 103 */     return nGetFloat(key, defaultVal);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private native float nGetFloat(int paramInt);
/*     */ 
/*     */   
/*     */   private native float nGetFloat(int paramInt, float paramFloat);
/*     */ 
/*     */   
/*     */   public void setFloat(int key, float val) {
/* 115 */     nSetFloat(key, val);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private native void nSetFloat(int paramInt, float paramFloat);
/*     */ 
/*     */ 
/*     */   
/*     */   public void buildSortByKey() {
/* 126 */     nBuildSortByKey();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private native void nBuildSortByKey();
/*     */ 
/*     */ 
/*     */   
/*     */   public void setAllInt(int val) {
/* 137 */     nSetAllInt(val);
/*     */   }
/*     */   
/*     */   private native void nSetAllInt(int paramInt);
/*     */ }


/* Location:              C:\Users\rapha\Downloads\aurora.jar!\META-INF\jars\imgui-java-binding-1.90.0.jar!\imgui\ImGuiStorage.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */