/*    */ package imgui;
/*    */ 
/*    */ import java.util.ArrayList;
/*    */ import java.util.Arrays;
/*    */ import java.util.List;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public final class ImFontGlyphRangesBuilder
/*    */ {
/*    */   private static final int UNICODE_CODEPOINT_MAX = 65535;
/* 19 */   private final long[] usedChars = new long[8192];
/*    */   
/*    */   public ImFontGlyphRangesBuilder() {
/* 22 */     clear();
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public void addChar(char c) {
/* 29 */     setBit(c);
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public void addText(String text) {
/* 36 */     for (int i = 0; i < text.length(); i++) {
/* 37 */       addChar(text.charAt(i));
/*    */     }
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public void addRanges(short[] ranges) {
/* 45 */     for (int i = 0; i < ranges.length && 
/* 46 */       ranges[i] != 0; i += 2) {
/*    */ 
/*    */ 
/*    */       
/* 50 */       for (int k = ranges[i]; k <= ranges[i + 1]; k++) {
/* 51 */         addChar((char)k);
/*    */       }
/*    */     } 
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public short[] buildRanges() {
/* 61 */     List<Short> out = new ArrayList<>();
/* 62 */     for (int n = 0; n <= 65535; n++) {
/* 63 */       if (getBit(n)) {
/* 64 */         out.add(Short.valueOf((short)n));
/* 65 */         while (n < 65535 && getBit(n + 1)) {
/* 66 */           n++;
/*    */         }
/* 68 */         out.add(Short.valueOf((short)n));
/*    */       } 
/*    */     } 
/*    */     
/* 72 */     short[] result = new short[out.size() + 1];
/* 73 */     for (int i = 0; i < out.size(); i++) {
/* 74 */       result[i] = ((Short)out.get(i)).shortValue();
/*    */     }
/* 76 */     result[result.length - 1] = 0;
/* 77 */     return result;
/*    */   }
/*    */   
/*    */   public void clear() {
/* 81 */     Arrays.fill(this.usedChars, 0L);
/*    */   }
/*    */   
/*    */   public void setBit(int n) {
/* 85 */     int off = n >> 5;
/* 86 */     long mask = 1L << (int)(n & 0x1FL);
/* 87 */     this.usedChars[off] = this.usedChars[off] | mask;
/*    */   }
/*    */   
/*    */   public boolean getBit(int n) {
/* 91 */     int off = n >> 5;
/* 92 */     long mask = 1L << (int)(n & 0x1FL);
/* 93 */     return ((this.usedChars[off] & mask) > 0L);
/*    */   }
/*    */ }


/* Location:              C:\Users\rapha\Downloads\aurora.jar!\META-INF\jars\imgui-java-binding-1.90.0.jar!\imgui\ImFontGlyphRangesBuilder.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */