package imgui;

public final class ImGuiOnceUponAFrame {
  public static native boolean get();
}


/* Location:              C:\Users\rapha\Downloads\aurora.jar!\META-INF\jars\imgui-java-binding-1.90.0.jar!\imgui\ImGuiOnceUponAFrame.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */