/*      */ package imgui;
/*      */ 
/*      */ import imgui.binding.ImGuiStruct;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ public final class ImDrawList
/*      */   extends ImGuiStruct
/*      */ {
/*      */   public ImDrawList(long ptr) {
/*   18 */     super(ptr);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public int getFlags() {
/*   30 */     return nGetFlags();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setFlags(int value) {
/*   37 */     nSetFlags(value);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void addFlags(int flags) {
/*   44 */     setFlags(getFlags() | flags);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void removeFlags(int flags) {
/*   51 */     setFlags(getFlags() & (flags ^ 0xFFFFFFFF));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean hasFlags(int flags) {
/*   58 */     return ((getFlags() & flags) != 0);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private native int nGetFlags();
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private native void nSetFlags(int paramInt);
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public int getVtxCurrentIdx() {
/*   75 */     return nGetVtxCurrentIdx();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private native int nGetVtxCurrentIdx();
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void pushClipRect(ImVec2 clipRectMin, ImVec2 clipRectMax) {
/*   88 */     nPushClipRect(clipRectMin.x, clipRectMin.y, clipRectMax.x, clipRectMax.y);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void pushClipRect(float clipRectMinX, float clipRectMinY, float clipRectMaxX, float clipRectMaxY) {
/*   97 */     nPushClipRect(clipRectMinX, clipRectMinY, clipRectMaxX, clipRectMaxY);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void pushClipRect(ImVec2 clipRectMin, ImVec2 clipRectMax, boolean intersectWithCurrentClipRect) {
/*  106 */     nPushClipRect(clipRectMin.x, clipRectMin.y, clipRectMax.x, clipRectMax.y, intersectWithCurrentClipRect);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void pushClipRect(float clipRectMinX, float clipRectMinY, float clipRectMaxX, float clipRectMaxY, boolean intersectWithCurrentClipRect) {
/*  115 */     nPushClipRect(clipRectMinX, clipRectMinY, clipRectMaxX, clipRectMaxY, intersectWithCurrentClipRect);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private native void nPushClipRect(float paramFloat1, float paramFloat2, float paramFloat3, float paramFloat4);
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private native void nPushClipRect(float paramFloat1, float paramFloat2, float paramFloat3, float paramFloat4, boolean paramBoolean);
/*      */ 
/*      */ 
/*      */   
/*      */   public void pushClipRectFullScreen() {
/*  131 */     nPushClipRectFullScreen();
/*      */   }
/*      */ 
/*      */   
/*      */   private native void nPushClipRectFullScreen();
/*      */ 
/*      */   
/*      */   public void popClipRect() {
/*  139 */     nPopClipRect();
/*      */   }
/*      */ 
/*      */   
/*      */   private native void nPopClipRect();
/*      */ 
/*      */   
/*      */   public void pushTextureID(long textureId) {
/*  147 */     nPushTextureID(textureId);
/*      */   }
/*      */ 
/*      */   
/*      */   private native void nPushTextureID(long paramLong);
/*      */ 
/*      */   
/*      */   public void popTextureID() {
/*  155 */     nPopTextureID();
/*      */   }
/*      */ 
/*      */   
/*      */   private native void nPopTextureID();
/*      */ 
/*      */   
/*      */   public ImVec2 getClipRectMin() {
/*  163 */     ImVec2 dst = new ImVec2();
/*  164 */     nGetClipRectMin(dst);
/*  165 */     return dst;
/*      */   }
/*      */   
/*      */   public float getClipRectMinX() {
/*  169 */     return nGetClipRectMinX();
/*      */   }
/*      */   
/*      */   public float getClipRectMinY() {
/*  173 */     return nGetClipRectMinY();
/*      */   }
/*      */   
/*      */   public void getClipRectMin(ImVec2 dst) {
/*  177 */     nGetClipRectMin(dst);
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   private native void nGetClipRectMin(ImVec2 paramImVec2);
/*      */ 
/*      */ 
/*      */   
/*      */   private native float nGetClipRectMinX();
/*      */ 
/*      */   
/*      */   private native float nGetClipRectMinY();
/*      */ 
/*      */   
/*      */   public ImVec2 getClipRectMax() {
/*  193 */     ImVec2 dst = new ImVec2();
/*  194 */     nGetClipRectMax(dst);
/*  195 */     return dst;
/*      */   }
/*      */   
/*      */   public float getClipRectMaxX() {
/*  199 */     return nGetClipRectMaxX();
/*      */   }
/*      */   
/*      */   public float getClipRectMaxY() {
/*  203 */     return nGetClipRectMaxY();
/*      */   }
/*      */   
/*      */   public void getClipRectMax(ImVec2 dst) {
/*  207 */     nGetClipRectMax(dst);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private native void nGetClipRectMax(ImVec2 paramImVec2);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private native float nGetClipRectMaxX();
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private native float nGetClipRectMaxY();
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void addLine(ImVec2 p1, ImVec2 p2, int col) {
/*  231 */     nAddLine(p1.x, p1.y, p2.x, p2.y, col);
/*      */   }
/*      */   
/*      */   public void addLine(float p1X, float p1Y, float p2X, float p2Y, int col) {
/*  235 */     nAddLine(p1X, p1Y, p2X, p2Y, col);
/*      */   }
/*      */   
/*      */   public void addLine(ImVec2 p1, ImVec2 p2, int col, float thickness) {
/*  239 */     nAddLine(p1.x, p1.y, p2.x, p2.y, col, thickness);
/*      */   }
/*      */   
/*      */   public void addLine(float p1X, float p1Y, float p2X, float p2Y, int col, float thickness) {
/*  243 */     nAddLine(p1X, p1Y, p2X, p2Y, col, thickness);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private native void nAddLine(float paramFloat1, float paramFloat2, float paramFloat3, float paramFloat4, int paramInt);
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private native void nAddLine(float paramFloat1, float paramFloat2, float paramFloat3, float paramFloat4, int paramInt, float paramFloat5);
/*      */ 
/*      */ 
/*      */   
/*      */   public void addRect(ImVec2 pMin, ImVec2 pMax, int col) {
/*  259 */     nAddRect(pMin.x, pMin.y, pMax.x, pMax.y, col);
/*      */   }
/*      */   
/*      */   public void addRect(float pMinX, float pMinY, float pMaxX, float pMaxY, int col) {
/*  263 */     nAddRect(pMinX, pMinY, pMaxX, pMaxY, col);
/*      */   }
/*      */   
/*      */   public void addRect(ImVec2 pMin, ImVec2 pMax, int col, float rounding) {
/*  267 */     nAddRect(pMin.x, pMin.y, pMax.x, pMax.y, col, rounding);
/*      */   }
/*      */   
/*      */   public void addRect(float pMinX, float pMinY, float pMaxX, float pMaxY, int col, float rounding) {
/*  271 */     nAddRect(pMinX, pMinY, pMaxX, pMaxY, col, rounding);
/*      */   }
/*      */   
/*      */   public void addRect(ImVec2 pMin, ImVec2 pMax, int col, float rounding, int flags) {
/*  275 */     nAddRect(pMin.x, pMin.y, pMax.x, pMax.y, col, rounding, flags);
/*      */   }
/*      */   
/*      */   public void addRect(float pMinX, float pMinY, float pMaxX, float pMaxY, int col, float rounding, int flags) {
/*  279 */     nAddRect(pMinX, pMinY, pMaxX, pMaxY, col, rounding, flags);
/*      */   }
/*      */   
/*      */   public void addRect(ImVec2 pMin, ImVec2 pMax, int col, float rounding, int flags, float thickness) {
/*  283 */     nAddRect(pMin.x, pMin.y, pMax.x, pMax.y, col, rounding, flags, thickness);
/*      */   }
/*      */   
/*      */   public void addRect(float pMinX, float pMinY, float pMaxX, float pMaxY, int col, float rounding, int flags, float thickness) {
/*  287 */     nAddRect(pMinX, pMinY, pMaxX, pMaxY, col, rounding, flags, thickness);
/*      */   }
/*      */   
/*      */   public void addRect(ImVec2 pMin, ImVec2 pMax, int col, int flags, float thickness) {
/*  291 */     nAddRect(pMin.x, pMin.y, pMax.x, pMax.y, col, flags, thickness);
/*      */   }
/*      */   
/*      */   public void addRect(float pMinX, float pMinY, float pMaxX, float pMaxY, int col, int flags, float thickness) {
/*  295 */     nAddRect(pMinX, pMinY, pMaxX, pMaxY, col, flags, thickness);
/*      */   }
/*      */   
/*      */   public void addRect(ImVec2 pMin, ImVec2 pMax, int col, float rounding, float thickness) {
/*  299 */     nAddRect(pMin.x, pMin.y, pMax.x, pMax.y, col, rounding, thickness);
/*      */   }
/*      */   
/*      */   public void addRect(float pMinX, float pMinY, float pMaxX, float pMaxY, int col, float rounding, float thickness) {
/*  303 */     nAddRect(pMinX, pMinY, pMaxX, pMaxY, col, rounding, thickness);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private native void nAddRect(float paramFloat1, float paramFloat2, float paramFloat3, float paramFloat4, int paramInt);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private native void nAddRect(float paramFloat1, float paramFloat2, float paramFloat3, float paramFloat4, int paramInt, float paramFloat5);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private native void nAddRect(float paramFloat1, float paramFloat2, float paramFloat3, float paramFloat4, int paramInt1, float paramFloat5, int paramInt2);
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private native void nAddRect(float paramFloat1, float paramFloat2, float paramFloat3, float paramFloat4, int paramInt1, float paramFloat5, int paramInt2, float paramFloat6);
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private native void nAddRect(float paramFloat1, float paramFloat2, float paramFloat3, float paramFloat4, int paramInt1, int paramInt2, float paramFloat5);
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private native void nAddRect(float paramFloat1, float paramFloat2, float paramFloat3, float paramFloat4, int paramInt, float paramFloat5, float paramFloat6);
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void addRectFilled(ImVec2 pMin, ImVec2 pMax, int col) {
/*  343 */     nAddRectFilled(pMin.x, pMin.y, pMax.x, pMax.y, col);
/*      */   }
/*      */   
/*      */   public void addRectFilled(float pMinX, float pMinY, float pMaxX, float pMaxY, int col) {
/*  347 */     nAddRectFilled(pMinX, pMinY, pMaxX, pMaxY, col);
/*      */   }
/*      */   
/*      */   public void addRectFilled(ImVec2 pMin, ImVec2 pMax, int col, float rounding) {
/*  351 */     nAddRectFilled(pMin.x, pMin.y, pMax.x, pMax.y, col, rounding);
/*      */   }
/*      */   
/*      */   public void addRectFilled(float pMinX, float pMinY, float pMaxX, float pMaxY, int col, float rounding) {
/*  355 */     nAddRectFilled(pMinX, pMinY, pMaxX, pMaxY, col, rounding);
/*      */   }
/*      */   
/*      */   public void addRectFilled(ImVec2 pMin, ImVec2 pMax, int col, float rounding, int flags) {
/*  359 */     nAddRectFilled(pMin.x, pMin.y, pMax.x, pMax.y, col, rounding, flags);
/*      */   }
/*      */   
/*      */   public void addRectFilled(float pMinX, float pMinY, float pMaxX, float pMaxY, int col, float rounding, int flags) {
/*  363 */     nAddRectFilled(pMinX, pMinY, pMaxX, pMaxY, col, rounding, flags);
/*      */   }
/*      */   
/*      */   public void addRectFilled(ImVec2 pMin, ImVec2 pMax, int col, int flags) {
/*  367 */     nAddRectFilled(pMin.x, pMin.y, pMax.x, pMax.y, col, flags);
/*      */   }
/*      */   
/*      */   public void addRectFilled(float pMinX, float pMinY, float pMaxX, float pMaxY, int col, int flags) {
/*  371 */     nAddRectFilled(pMinX, pMinY, pMaxX, pMaxY, col, flags);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private native void nAddRectFilled(float paramFloat1, float paramFloat2, float paramFloat3, float paramFloat4, int paramInt);
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private native void nAddRectFilled(float paramFloat1, float paramFloat2, float paramFloat3, float paramFloat4, int paramInt, float paramFloat5);
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private native void nAddRectFilled(float paramFloat1, float paramFloat2, float paramFloat3, float paramFloat4, int paramInt1, float paramFloat5, int paramInt2);
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private native void nAddRectFilled(float paramFloat1, float paramFloat2, float paramFloat3, float paramFloat4, int paramInt1, int paramInt2);
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void addRectFilledMultiColor(ImVec2 pMin, ImVec2 pMax, int colUprLeft, int colUprRight, int colBotRight, int colBotLeft) {
/*  399 */     nAddRectFilledMultiColor(pMin.x, pMin.y, pMax.x, pMax.y, colUprLeft, colUprRight, colBotRight, colBotLeft);
/*      */   }
/*      */   
/*      */   public void addRectFilledMultiColor(float pMinX, float pMinY, float pMaxX, float pMaxY, int colUprLeft, int colUprRight, int colBotRight, int colBotLeft) {
/*  403 */     nAddRectFilledMultiColor(pMinX, pMinY, pMaxX, pMaxY, colUprLeft, colUprRight, colBotRight, colBotLeft);
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   private native void nAddRectFilledMultiColor(float paramFloat1, float paramFloat2, float paramFloat3, float paramFloat4, int paramInt1, int paramInt2, int paramInt3, int paramInt4);
/*      */ 
/*      */ 
/*      */   
/*      */   public void addQuad(ImVec2 p1, ImVec2 p2, ImVec2 p3, ImVec2 p4, int col) {
/*  413 */     nAddQuad(p1.x, p1.y, p2.x, p2.y, p3.x, p3.y, p4.x, p4.y, col);
/*      */   }
/*      */   
/*      */   public void addQuad(float p1X, float p1Y, float p2X, float p2Y, float p3X, float p3Y, float p4X, float p4Y, int col) {
/*  417 */     nAddQuad(p1X, p1Y, p2X, p2Y, p3X, p3Y, p4X, p4Y, col);
/*      */   }
/*      */   
/*      */   public void addQuad(ImVec2 p1, ImVec2 p2, ImVec2 p3, ImVec2 p4, int col, float thickness) {
/*  421 */     nAddQuad(p1.x, p1.y, p2.x, p2.y, p3.x, p3.y, p4.x, p4.y, col, thickness);
/*      */   }
/*      */   
/*      */   public void addQuad(float p1X, float p1Y, float p2X, float p2Y, float p3X, float p3Y, float p4X, float p4Y, int col, float thickness) {
/*  425 */     nAddQuad(p1X, p1Y, p2X, p2Y, p3X, p3Y, p4X, p4Y, col, thickness);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private native void nAddQuad(float paramFloat1, float paramFloat2, float paramFloat3, float paramFloat4, float paramFloat5, float paramFloat6, float paramFloat7, float paramFloat8, int paramInt);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private native void nAddQuad(float paramFloat1, float paramFloat2, float paramFloat3, float paramFloat4, float paramFloat5, float paramFloat6, float paramFloat7, float paramFloat8, int paramInt, float paramFloat9);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void addQuadFilled(ImVec2 p1, ImVec2 p2, ImVec2 p3, ImVec2 p4, int col) {
/*  445 */     nAddQuadFilled(p1.x, p1.y, p2.x, p2.y, p3.x, p3.y, p4.x, p4.y, col);
/*      */   }
/*      */   
/*      */   public void addQuadFilled(float p1X, float p1Y, float p2X, float p2Y, float p3X, float p3Y, float p4X, float p4Y, int col) {
/*  449 */     nAddQuadFilled(p1X, p1Y, p2X, p2Y, p3X, p3Y, p4X, p4Y, col);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private native void nAddQuadFilled(float paramFloat1, float paramFloat2, float paramFloat3, float paramFloat4, float paramFloat5, float paramFloat6, float paramFloat7, float paramFloat8, int paramInt);
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void addTriangle(ImVec2 p1, ImVec2 p2, ImVec2 p3, int col) {
/*  461 */     nAddTriangle(p1.x, p1.y, p2.x, p2.y, p3.x, p3.y, col);
/*      */   }
/*      */   
/*      */   public void addTriangle(float p1X, float p1Y, float p2X, float p2Y, float p3X, float p3Y, int col) {
/*  465 */     nAddTriangle(p1X, p1Y, p2X, p2Y, p3X, p3Y, col);
/*      */   }
/*      */   
/*      */   public void addTriangle(ImVec2 p1, ImVec2 p2, ImVec2 p3, int col, float thickness) {
/*  469 */     nAddTriangle(p1.x, p1.y, p2.x, p2.y, p3.x, p3.y, col, thickness);
/*      */   }
/*      */   
/*      */   public void addTriangle(float p1X, float p1Y, float p2X, float p2Y, float p3X, float p3Y, int col, float thickness) {
/*  473 */     nAddTriangle(p1X, p1Y, p2X, p2Y, p3X, p3Y, col, thickness);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private native void nAddTriangle(float paramFloat1, float paramFloat2, float paramFloat3, float paramFloat4, float paramFloat5, float paramFloat6, int paramInt);
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private native void nAddTriangle(float paramFloat1, float paramFloat2, float paramFloat3, float paramFloat4, float paramFloat5, float paramFloat6, int paramInt, float paramFloat7);
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void addTriangleFilled(ImVec2 p1, ImVec2 p2, ImVec2 p3, int col) {
/*  491 */     nAddTriangleFilled(p1.x, p1.y, p2.x, p2.y, p3.x, p3.y, col);
/*      */   }
/*      */   
/*      */   public void addTriangleFilled(float p1X, float p1Y, float p2X, float p2Y, float p3X, float p3Y, int col) {
/*  495 */     nAddTriangleFilled(p1X, p1Y, p2X, p2Y, p3X, p3Y, col);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private native void nAddTriangleFilled(float paramFloat1, float paramFloat2, float paramFloat3, float paramFloat4, float paramFloat5, float paramFloat6, int paramInt);
/*      */ 
/*      */ 
/*      */   
/*      */   public void addCircle(ImVec2 center, float radius, int col) {
/*  506 */     nAddCircle(center.x, center.y, radius, col);
/*      */   }
/*      */   
/*      */   public void addCircle(float centerX, float centerY, float radius, int col) {
/*  510 */     nAddCircle(centerX, centerY, radius, col);
/*      */   }
/*      */   
/*      */   public void addCircle(ImVec2 center, float radius, int col, int numSegments) {
/*  514 */     nAddCircle(center.x, center.y, radius, col, numSegments);
/*      */   }
/*      */   
/*      */   public void addCircle(float centerX, float centerY, float radius, int col, int numSegments) {
/*  518 */     nAddCircle(centerX, centerY, radius, col, numSegments);
/*      */   }
/*      */   
/*      */   public void addCircle(ImVec2 center, float radius, int col, int numSegments, float thickness) {
/*  522 */     nAddCircle(center.x, center.y, radius, col, numSegments, thickness);
/*      */   }
/*      */   
/*      */   public void addCircle(float centerX, float centerY, float radius, int col, int numSegments, float thickness) {
/*  526 */     nAddCircle(centerX, centerY, radius, col, numSegments, thickness);
/*      */   }
/*      */   
/*      */   public void addCircle(ImVec2 center, float radius, int col, float thickness) {
/*  530 */     nAddCircle(center.x, center.y, radius, col, thickness);
/*      */   }
/*      */   
/*      */   public void addCircle(float centerX, float centerY, float radius, int col, float thickness) {
/*  534 */     nAddCircle(centerX, centerY, radius, col, thickness);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private native void nAddCircle(float paramFloat1, float paramFloat2, float paramFloat3, int paramInt);
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private native void nAddCircle(float paramFloat1, float paramFloat2, float paramFloat3, int paramInt1, int paramInt2);
/*      */ 
/*      */ 
/*      */   
/*      */   private native void nAddCircle(float paramFloat1, float paramFloat2, float paramFloat3, int paramInt1, int paramInt2, float paramFloat4);
/*      */ 
/*      */ 
/*      */   
/*      */   private native void nAddCircle(float paramFloat1, float paramFloat2, float paramFloat3, int paramInt, float paramFloat4);
/*      */ 
/*      */ 
/*      */   
/*      */   public void addCircleFilled(ImVec2 center, float radius, int col) {
/*  558 */     nAddCircleFilled(center.x, center.y, radius, col);
/*      */   }
/*      */   
/*      */   public void addCircleFilled(float centerX, float centerY, float radius, int col) {
/*  562 */     nAddCircleFilled(centerX, centerY, radius, col);
/*      */   }
/*      */   
/*      */   public void addCircleFilled(ImVec2 center, float radius, int col, int numSegments) {
/*  566 */     nAddCircleFilled(center.x, center.y, radius, col, numSegments);
/*      */   }
/*      */   
/*      */   public void addCircleFilled(float centerX, float centerY, float radius, int col, int numSegments) {
/*  570 */     nAddCircleFilled(centerX, centerY, radius, col, numSegments);
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   private native void nAddCircleFilled(float paramFloat1, float paramFloat2, float paramFloat3, int paramInt);
/*      */ 
/*      */ 
/*      */   
/*      */   private native void nAddCircleFilled(float paramFloat1, float paramFloat2, float paramFloat3, int paramInt1, int paramInt2);
/*      */ 
/*      */ 
/*      */   
/*      */   public void addNgon(ImVec2 center, float radius, int col, int num_segments) {
/*  584 */     nAddNgon(center.x, center.y, radius, col, num_segments);
/*      */   }
/*      */   
/*      */   public void addNgon(float centerX, float centerY, float radius, int col, int num_segments) {
/*  588 */     nAddNgon(centerX, centerY, radius, col, num_segments);
/*      */   }
/*      */   
/*      */   public void addNgon(ImVec2 center, float radius, int col, int num_segments, float thickness) {
/*  592 */     nAddNgon(center.x, center.y, radius, col, num_segments, thickness);
/*      */   }
/*      */   
/*      */   public void addNgon(float centerX, float centerY, float radius, int col, int num_segments, float thickness) {
/*  596 */     nAddNgon(centerX, centerY, radius, col, num_segments, thickness);
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   private native void nAddNgon(float paramFloat1, float paramFloat2, float paramFloat3, int paramInt1, int paramInt2);
/*      */ 
/*      */ 
/*      */   
/*      */   private native void nAddNgon(float paramFloat1, float paramFloat2, float paramFloat3, int paramInt1, int paramInt2, float paramFloat4);
/*      */ 
/*      */ 
/*      */   
/*      */   public void addNgonFilled(ImVec2 center, float radius, int col, int num_segments) {
/*  610 */     nAddNgonFilled(center.x, center.y, radius, col, num_segments);
/*      */   }
/*      */   
/*      */   public void addNgonFilled(float centerX, float centerY, float radius, int col, int num_segments) {
/*  614 */     nAddNgonFilled(centerX, centerY, radius, col, num_segments);
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   private native void nAddNgonFilled(float paramFloat1, float paramFloat2, float paramFloat3, int paramInt1, int paramInt2);
/*      */ 
/*      */   
/*      */   public void addEllipse(ImVec2 center, ImVec2 radius, int col) {
/*  623 */     nAddEllipse(center.x, center.y, radius.x, radius.y, col);
/*      */   }
/*      */   
/*      */   public void addEllipse(float centerX, float centerY, float radiusX, float radiusY, int col) {
/*  627 */     nAddEllipse(centerX, centerY, radiusX, radiusY, col);
/*      */   }
/*      */   
/*      */   public void addEllipse(ImVec2 center, ImVec2 radius, int col, float rot) {
/*  631 */     nAddEllipse(center.x, center.y, radius.x, radius.y, col, rot);
/*      */   }
/*      */   
/*      */   public void addEllipse(float centerX, float centerY, float radiusX, float radiusY, int col, float rot) {
/*  635 */     nAddEllipse(centerX, centerY, radiusX, radiusY, col, rot);
/*      */   }
/*      */   
/*      */   public void addEllipse(ImVec2 center, ImVec2 radius, int col, float rot, float numSegments) {
/*  639 */     nAddEllipse(center.x, center.y, radius.x, radius.y, col, rot, numSegments);
/*      */   }
/*      */   
/*      */   public void addEllipse(float centerX, float centerY, float radiusX, float radiusY, int col, float rot, float numSegments) {
/*  643 */     nAddEllipse(centerX, centerY, radiusX, radiusY, col, rot, numSegments);
/*      */   }
/*      */   
/*      */   public void addEllipse(ImVec2 center, ImVec2 radius, int col, float rot, float numSegments, float thickness) {
/*  647 */     nAddEllipse(center.x, center.y, radius.x, radius.y, col, rot, numSegments, thickness);
/*      */   }
/*      */   
/*      */   public void addEllipse(float centerX, float centerY, float radiusX, float radiusY, int col, float rot, float numSegments, float thickness) {
/*  651 */     nAddEllipse(centerX, centerY, radiusX, radiusY, col, rot, numSegments, thickness);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private native void nAddEllipse(float paramFloat1, float paramFloat2, float paramFloat3, float paramFloat4, int paramInt);
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private native void nAddEllipse(float paramFloat1, float paramFloat2, float paramFloat3, float paramFloat4, int paramInt, float paramFloat5);
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private native void nAddEllipse(float paramFloat1, float paramFloat2, float paramFloat3, float paramFloat4, int paramInt, float paramFloat5, float paramFloat6);
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private native void nAddEllipse(float paramFloat1, float paramFloat2, float paramFloat3, float paramFloat4, int paramInt, float paramFloat5, float paramFloat6, float paramFloat7);
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void addEllipseFilled(ImVec2 center, ImVec2 radius, int col) {
/*  679 */     nAddEllipseFilled(center.x, center.y, radius.x, radius.y, col);
/*      */   }
/*      */   
/*      */   public void addEllipseFilled(float centerX, float centerY, float radiusX, float radiusY, int col) {
/*  683 */     nAddEllipseFilled(centerX, centerY, radiusX, radiusY, col);
/*      */   }
/*      */   
/*      */   public void addEllipseFilled(ImVec2 center, ImVec2 radius, int col, float rot) {
/*  687 */     nAddEllipseFilled(center.x, center.y, radius.x, radius.y, col, rot);
/*      */   }
/*      */   
/*      */   public void addEllipseFilled(float centerX, float centerY, float radiusX, float radiusY, int col, float rot) {
/*  691 */     nAddEllipseFilled(centerX, centerY, radiusX, radiusY, col, rot);
/*      */   }
/*      */   
/*      */   public void addEllipseFilled(ImVec2 center, ImVec2 radius, int col, float rot, float numSegments) {
/*  695 */     nAddEllipseFilled(center.x, center.y, radius.x, radius.y, col, rot, numSegments);
/*      */   }
/*      */   
/*      */   public void addEllipseFilled(float centerX, float centerY, float radiusX, float radiusY, int col, float rot, float numSegments) {
/*  699 */     nAddEllipseFilled(centerX, centerY, radiusX, radiusY, col, rot, numSegments);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private native void nAddEllipseFilled(float paramFloat1, float paramFloat2, float paramFloat3, float paramFloat4, int paramInt);
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private native void nAddEllipseFilled(float paramFloat1, float paramFloat2, float paramFloat3, float paramFloat4, int paramInt, float paramFloat5);
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private native void nAddEllipseFilled(float paramFloat1, float paramFloat2, float paramFloat3, float paramFloat4, int paramInt, float paramFloat5, float paramFloat6);
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void addText(ImVec2 pos, int col, String textBegin) {
/*  721 */     nAddText(pos.x, pos.y, col, textBegin);
/*      */   }
/*      */   
/*      */   public void addText(float posX, float posY, int col, String textBegin) {
/*  725 */     nAddText(posX, posY, col, textBegin);
/*      */   }
/*      */   
/*      */   public void addText(ImVec2 pos, int col, String textBegin, String textEnd) {
/*  729 */     nAddText(pos.x, pos.y, col, textBegin, textEnd);
/*      */   }
/*      */   
/*      */   public void addText(float posX, float posY, int col, String textBegin, String textEnd) {
/*  733 */     nAddText(posX, posY, col, textBegin, textEnd);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private native void nAddText(float paramFloat1, float paramFloat2, int paramInt, String paramString);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private native void nAddText(float paramFloat1, float paramFloat2, int paramInt, String paramString1, String paramString2);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void addText(ImFont font, int fontSize, ImVec2 pos, int col, String textBegin) {
/*  753 */     nAddText(font.ptr, fontSize, pos.x, pos.y, col, textBegin);
/*      */   }
/*      */   
/*      */   public void addText(ImFont font, int fontSize, float posX, float posY, int col, String textBegin) {
/*  757 */     nAddText(font.ptr, fontSize, posX, posY, col, textBegin);
/*      */   }
/*      */   
/*      */   public void addText(ImFont font, int fontSize, ImVec2 pos, int col, String textBegin, String textEnd) {
/*  761 */     nAddText(font.ptr, fontSize, pos.x, pos.y, col, textBegin, textEnd);
/*      */   }
/*      */   
/*      */   public void addText(ImFont font, int fontSize, float posX, float posY, int col, String textBegin, String textEnd) {
/*  765 */     nAddText(font.ptr, fontSize, posX, posY, col, textBegin, textEnd);
/*      */   }
/*      */   
/*      */   public void addText(ImFont font, int fontSize, ImVec2 pos, int col, String textBegin, String textEnd, float wrapWidth) {
/*  769 */     nAddText(font.ptr, fontSize, pos.x, pos.y, col, textBegin, textEnd, wrapWidth);
/*      */   }
/*      */   
/*      */   public void addText(ImFont font, int fontSize, float posX, float posY, int col, String textBegin, String textEnd, float wrapWidth) {
/*  773 */     nAddText(font.ptr, fontSize, posX, posY, col, textBegin, textEnd, wrapWidth);
/*      */   }
/*      */   
/*      */   public void addText(ImFont font, int fontSize, ImVec2 pos, int col, String textBegin, String textEnd, float wrapWidth, ImVec4 cpuFineClipRect) {
/*  777 */     nAddText(font.ptr, fontSize, pos.x, pos.y, col, textBegin, textEnd, wrapWidth, cpuFineClipRect.x, cpuFineClipRect.y, cpuFineClipRect.z, cpuFineClipRect.w);
/*      */   }
/*      */   
/*      */   public void addText(ImFont font, int fontSize, float posX, float posY, int col, String textBegin, String textEnd, float wrapWidth, float cpuFineClipRectX, float cpuFineClipRectY, float cpuFineClipRectZ, float cpuFineClipRectW) {
/*  781 */     nAddText(font.ptr, fontSize, posX, posY, col, textBegin, textEnd, wrapWidth, cpuFineClipRectX, cpuFineClipRectY, cpuFineClipRectZ, cpuFineClipRectW);
/*      */   }
/*      */   
/*      */   public void addText(ImFont font, int fontSize, ImVec2 pos, int col, String textBegin, float wrapWidth, ImVec4 cpuFineClipRect) {
/*  785 */     nAddText(font.ptr, fontSize, pos.x, pos.y, col, textBegin, wrapWidth, cpuFineClipRect.x, cpuFineClipRect.y, cpuFineClipRect.z, cpuFineClipRect.w);
/*      */   }
/*      */   
/*      */   public void addText(ImFont font, int fontSize, float posX, float posY, int col, String textBegin, float wrapWidth, float cpuFineClipRectX, float cpuFineClipRectY, float cpuFineClipRectZ, float cpuFineClipRectW) {
/*  789 */     nAddText(font.ptr, fontSize, posX, posY, col, textBegin, wrapWidth, cpuFineClipRectX, cpuFineClipRectY, cpuFineClipRectZ, cpuFineClipRectW);
/*      */   }
/*      */   
/*      */   public void addText(ImFont font, int fontSize, ImVec2 pos, int col, String textBegin, ImVec4 cpuFineClipRect) {
/*  793 */     nAddText(font.ptr, fontSize, pos.x, pos.y, col, textBegin, cpuFineClipRect.x, cpuFineClipRect.y, cpuFineClipRect.z, cpuFineClipRect.w);
/*      */   }
/*      */   
/*      */   public void addText(ImFont font, int fontSize, float posX, float posY, int col, String textBegin, float cpuFineClipRectX, float cpuFineClipRectY, float cpuFineClipRectZ, float cpuFineClipRectW) {
/*  797 */     nAddText(font.ptr, fontSize, posX, posY, col, textBegin, cpuFineClipRectX, cpuFineClipRectY, cpuFineClipRectZ, cpuFineClipRectW);
/*      */   }
/*      */   
/*      */   public void addText(ImFont font, int fontSize, ImVec2 pos, int col, String textBegin, String textEnd, ImVec4 cpuFineClipRect) {
/*  801 */     nAddText(font.ptr, fontSize, pos.x, pos.y, col, textBegin, textEnd, cpuFineClipRect.x, cpuFineClipRect.y, cpuFineClipRect.z, cpuFineClipRect.w);
/*      */   }
/*      */   
/*      */   public void addText(ImFont font, int fontSize, float posX, float posY, int col, String textBegin, String textEnd, float cpuFineClipRectX, float cpuFineClipRectY, float cpuFineClipRectZ, float cpuFineClipRectW) {
/*  805 */     nAddText(font.ptr, fontSize, posX, posY, col, textBegin, textEnd, cpuFineClipRectX, cpuFineClipRectY, cpuFineClipRectZ, cpuFineClipRectW);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private native void nAddText(long paramLong, int paramInt1, float paramFloat1, float paramFloat2, int paramInt2, String paramString);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private native void nAddText(long paramLong, int paramInt1, float paramFloat1, float paramFloat2, int paramInt2, String paramString1, String paramString2);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private native void nAddText(long paramLong, int paramInt1, float paramFloat1, float paramFloat2, int paramInt2, String paramString1, String paramString2, float paramFloat3);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private native void nAddText(long paramLong, int paramInt1, float paramFloat1, float paramFloat2, int paramInt2, String paramString1, String paramString2, float paramFloat3, float paramFloat4, float paramFloat5, float paramFloat6, float paramFloat7);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private native void nAddText(long paramLong, int paramInt1, float paramFloat1, float paramFloat2, int paramInt2, String paramString, float paramFloat3, float paramFloat4, float paramFloat5, float paramFloat6, float paramFloat7);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private native void nAddText(long paramLong, int paramInt1, float paramFloat1, float paramFloat2, int paramInt2, String paramString, float paramFloat3, float paramFloat4, float paramFloat5, float paramFloat6);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private native void nAddText(long paramLong, int paramInt1, float paramFloat1, float paramFloat2, int paramInt2, String paramString1, String paramString2, float paramFloat3, float paramFloat4, float paramFloat5, float paramFloat6);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void addBezierCubic(ImVec2 p1, ImVec2 p2, ImVec2 p3, ImVec2 p4, int col, float thickness) {
/*  873 */     nAddBezierCubic(p1.x, p1.y, p2.x, p2.y, p3.x, p3.y, p4.x, p4.y, col, thickness);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void addBezierCubic(float p1X, float p1Y, float p2X, float p2Y, float p3X, float p3Y, float p4X, float p4Y, int col, float thickness) {
/*  880 */     nAddBezierCubic(p1X, p1Y, p2X, p2Y, p3X, p3Y, p4X, p4Y, col, thickness);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void addBezierCubic(ImVec2 p1, ImVec2 p2, ImVec2 p3, ImVec2 p4, int col, float thickness, int numSegments) {
/*  887 */     nAddBezierCubic(p1.x, p1.y, p2.x, p2.y, p3.x, p3.y, p4.x, p4.y, col, thickness, numSegments);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void addBezierCubic(float p1X, float p1Y, float p2X, float p2Y, float p3X, float p3Y, float p4X, float p4Y, int col, float thickness, int numSegments) {
/*  894 */     nAddBezierCubic(p1X, p1Y, p2X, p2Y, p3X, p3Y, p4X, p4Y, col, thickness, numSegments);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private native void nAddBezierCubic(float paramFloat1, float paramFloat2, float paramFloat3, float paramFloat4, float paramFloat5, float paramFloat6, float paramFloat7, float paramFloat8, int paramInt, float paramFloat9);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private native void nAddBezierCubic(float paramFloat1, float paramFloat2, float paramFloat3, float paramFloat4, float paramFloat5, float paramFloat6, float paramFloat7, float paramFloat8, int paramInt1, float paramFloat9, int paramInt2);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void addBezierQuadratic(ImVec2 p1, ImVec2 p2, ImVec2 p3, int col, float thickness) {
/*  917 */     nAddBezierQuadratic(p1.x, p1.y, p2.x, p2.y, p3.x, p3.y, col, thickness);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void addBezierQuadratic(float p1X, float p1Y, float p2X, float p2Y, float p3X, float p3Y, int col, float thickness) {
/*  924 */     nAddBezierQuadratic(p1X, p1Y, p2X, p2Y, p3X, p3Y, col, thickness);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void addBezierQuadratic(ImVec2 p1, ImVec2 p2, ImVec2 p3, int col, float thickness, int numSegments) {
/*  931 */     nAddBezierQuadratic(p1.x, p1.y, p2.x, p2.y, p3.x, p3.y, col, thickness, numSegments);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void addBezierQuadratic(float p1X, float p1Y, float p2X, float p2Y, float p3X, float p3Y, int col, float thickness, int numSegments) {
/*  938 */     nAddBezierQuadratic(p1X, p1Y, p2X, p2Y, p3X, p3Y, col, thickness, numSegments);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private native void nAddBezierQuadratic(float paramFloat1, float paramFloat2, float paramFloat3, float paramFloat4, float paramFloat5, float paramFloat6, int paramInt, float paramFloat7);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private native void nAddBezierQuadratic(float paramFloat1, float paramFloat2, float paramFloat3, float paramFloat4, float paramFloat5, float paramFloat6, int paramInt1, float paramFloat7, int paramInt2);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void addPolyline(ImVec2[] points, int numPoints, int col, int imDrawFlags, float thickness) {
/*  960 */     nAddPolyline(points, numPoints, col, imDrawFlags, thickness);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private native void nAddPolyline(ImVec2[] paramArrayOfImVec2, int paramInt1, int paramInt2, int paramInt3, float paramFloat);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void addConvexPolyFilled(ImVec2[] points, int numPoints, int col) {
/*  976 */     nAddConvexPolyFilled(points, numPoints, col);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private native void nAddConvexPolyFilled(ImVec2[] paramArrayOfImVec2, int paramInt1, int paramInt2);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void addConcavePolyFilled(ImVec2[] points, int numPoints, int col) {
/*  992 */     nAddConcavePolyFilled(points, numPoints, col);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private native void nAddConcavePolyFilled(ImVec2[] paramArrayOfImVec2, int paramInt1, int paramInt2);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void addImage(long textureID, ImVec2 pMin, ImVec2 pMax) {
/* 1013 */     nAddImage(textureID, pMin.x, pMin.y, pMax.x, pMax.y);
/*      */   }
/*      */   
/*      */   public void addImage(long textureID, float pMinX, float pMinY, float pMaxX, float pMaxY) {
/* 1017 */     nAddImage(textureID, pMinX, pMinY, pMaxX, pMaxY);
/*      */   }
/*      */   
/*      */   public void addImage(long textureID, ImVec2 pMin, ImVec2 pMax, ImVec2 uvMin) {
/* 1021 */     nAddImage(textureID, pMin.x, pMin.y, pMax.x, pMax.y, uvMin.x, uvMin.y);
/*      */   }
/*      */   
/*      */   public void addImage(long textureID, float pMinX, float pMinY, float pMaxX, float pMaxY, float uvMinX, float uvMinY) {
/* 1025 */     nAddImage(textureID, pMinX, pMinY, pMaxX, pMaxY, uvMinX, uvMinY);
/*      */   }
/*      */   
/*      */   public void addImage(long textureID, ImVec2 pMin, ImVec2 pMax, ImVec2 uvMin, ImVec2 uvMax) {
/* 1029 */     nAddImage(textureID, pMin.x, pMin.y, pMax.x, pMax.y, uvMin.x, uvMin.y, uvMax.x, uvMax.y);
/*      */   }
/*      */   
/*      */   public void addImage(long textureID, float pMinX, float pMinY, float pMaxX, float pMaxY, float uvMinX, float uvMinY, float uvMaxX, float uvMaxY) {
/* 1033 */     nAddImage(textureID, pMinX, pMinY, pMaxX, pMaxY, uvMinX, uvMinY, uvMaxX, uvMaxY);
/*      */   }
/*      */   
/*      */   public void addImage(long textureID, ImVec2 pMin, ImVec2 pMax, ImVec2 uvMin, ImVec2 uvMax, int col) {
/* 1037 */     nAddImage(textureID, pMin.x, pMin.y, pMax.x, pMax.y, uvMin.x, uvMin.y, uvMax.x, uvMax.y, col);
/*      */   }
/*      */   
/*      */   public void addImage(long textureID, float pMinX, float pMinY, float pMaxX, float pMaxY, float uvMinX, float uvMinY, float uvMaxX, float uvMaxY, int col) {
/* 1041 */     nAddImage(textureID, pMinX, pMinY, pMaxX, pMaxY, uvMinX, uvMinY, uvMaxX, uvMaxY, col);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private native void nAddImage(long paramLong, float paramFloat1, float paramFloat2, float paramFloat3, float paramFloat4);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private native void nAddImage(long paramLong, float paramFloat1, float paramFloat2, float paramFloat3, float paramFloat4, float paramFloat5, float paramFloat6);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private native void nAddImage(long paramLong, float paramFloat1, float paramFloat2, float paramFloat3, float paramFloat4, float paramFloat5, float paramFloat6, float paramFloat7, float paramFloat8);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private native void nAddImage(long paramLong, float paramFloat1, float paramFloat2, float paramFloat3, float paramFloat4, float paramFloat5, float paramFloat6, float paramFloat7, float paramFloat8, int paramInt);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void addImageQuad(long textureID, ImVec2 p1, ImVec2 p2, ImVec2 p3, ImVec2 p4) {
/* 1074 */     nAddImageQuad(textureID, p1.x, p1.y, p2.x, p2.y, p3.x, p3.y, p4.x, p4.y);
/*      */   }
/*      */   
/*      */   public void addImageQuad(long textureID, float p1X, float p1Y, float p2X, float p2Y, float p3X, float p3Y, float p4X, float p4Y) {
/* 1078 */     nAddImageQuad(textureID, p1X, p1Y, p2X, p2Y, p3X, p3Y, p4X, p4Y);
/*      */   }
/*      */   
/*      */   public void addImageQuad(long textureID, ImVec2 p1, ImVec2 p2, ImVec2 p3, ImVec2 p4, ImVec2 uv1) {
/* 1082 */     nAddImageQuad(textureID, p1.x, p1.y, p2.x, p2.y, p3.x, p3.y, p4.x, p4.y, uv1.x, uv1.y);
/*      */   }
/*      */   
/*      */   public void addImageQuad(long textureID, float p1X, float p1Y, float p2X, float p2Y, float p3X, float p3Y, float p4X, float p4Y, float uv1X, float uv1Y) {
/* 1086 */     nAddImageQuad(textureID, p1X, p1Y, p2X, p2Y, p3X, p3Y, p4X, p4Y, uv1X, uv1Y);
/*      */   }
/*      */   
/*      */   public void addImageQuad(long textureID, ImVec2 p1, ImVec2 p2, ImVec2 p3, ImVec2 p4, ImVec2 uv1, ImVec2 uv2) {
/* 1090 */     nAddImageQuad(textureID, p1.x, p1.y, p2.x, p2.y, p3.x, p3.y, p4.x, p4.y, uv1.x, uv1.y, uv2.x, uv2.y);
/*      */   }
/*      */   
/*      */   public void addImageQuad(long textureID, float p1X, float p1Y, float p2X, float p2Y, float p3X, float p3Y, float p4X, float p4Y, float uv1X, float uv1Y, float uv2X, float uv2Y) {
/* 1094 */     nAddImageQuad(textureID, p1X, p1Y, p2X, p2Y, p3X, p3Y, p4X, p4Y, uv1X, uv1Y, uv2X, uv2Y);
/*      */   }
/*      */   
/*      */   public void addImageQuad(long textureID, ImVec2 p1, ImVec2 p2, ImVec2 p3, ImVec2 p4, ImVec2 uv1, ImVec2 uv2, ImVec2 uv3) {
/* 1098 */     nAddImageQuad(textureID, p1.x, p1.y, p2.x, p2.y, p3.x, p3.y, p4.x, p4.y, uv1.x, uv1.y, uv2.x, uv2.y, uv3.x, uv3.y);
/*      */   }
/*      */   
/*      */   public void addImageQuad(long textureID, float p1X, float p1Y, float p2X, float p2Y, float p3X, float p3Y, float p4X, float p4Y, float uv1X, float uv1Y, float uv2X, float uv2Y, float uv3X, float uv3Y) {
/* 1102 */     nAddImageQuad(textureID, p1X, p1Y, p2X, p2Y, p3X, p3Y, p4X, p4Y, uv1X, uv1Y, uv2X, uv2Y, uv3X, uv3Y);
/*      */   }
/*      */   
/*      */   public void addImageQuad(long textureID, ImVec2 p1, ImVec2 p2, ImVec2 p3, ImVec2 p4, ImVec2 uv1, ImVec2 uv2, ImVec2 uv3, ImVec2 uv4) {
/* 1106 */     nAddImageQuad(textureID, p1.x, p1.y, p2.x, p2.y, p3.x, p3.y, p4.x, p4.y, uv1.x, uv1.y, uv2.x, uv2.y, uv3.x, uv3.y, uv4.x, uv4.y);
/*      */   }
/*      */   
/*      */   public void addImageQuad(long textureID, float p1X, float p1Y, float p2X, float p2Y, float p3X, float p3Y, float p4X, float p4Y, float uv1X, float uv1Y, float uv2X, float uv2Y, float uv3X, float uv3Y, float uv4X, float uv4Y) {
/* 1110 */     nAddImageQuad(textureID, p1X, p1Y, p2X, p2Y, p3X, p3Y, p4X, p4Y, uv1X, uv1Y, uv2X, uv2Y, uv3X, uv3Y, uv4X, uv4Y);
/*      */   }
/*      */   
/*      */   public void addImageQuad(long textureID, ImVec2 p1, ImVec2 p2, ImVec2 p3, ImVec2 p4, ImVec2 uv1, ImVec2 uv2, ImVec2 uv3, ImVec2 uv4, int col) {
/* 1114 */     nAddImageQuad(textureID, p1.x, p1.y, p2.x, p2.y, p3.x, p3.y, p4.x, p4.y, uv1.x, uv1.y, uv2.x, uv2.y, uv3.x, uv3.y, uv4.x, uv4.y, col);
/*      */   }
/*      */   
/*      */   public void addImageQuad(long textureID, float p1X, float p1Y, float p2X, float p2Y, float p3X, float p3Y, float p4X, float p4Y, float uv1X, float uv1Y, float uv2X, float uv2Y, float uv3X, float uv3Y, float uv4X, float uv4Y, int col) {
/* 1118 */     nAddImageQuad(textureID, p1X, p1Y, p2X, p2Y, p3X, p3Y, p4X, p4Y, uv1X, uv1Y, uv2X, uv2Y, uv3X, uv3Y, uv4X, uv4Y, col);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private native void nAddImageQuad(long paramLong, float paramFloat1, float paramFloat2, float paramFloat3, float paramFloat4, float paramFloat5, float paramFloat6, float paramFloat7, float paramFloat8);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private native void nAddImageQuad(long paramLong, float paramFloat1, float paramFloat2, float paramFloat3, float paramFloat4, float paramFloat5, float paramFloat6, float paramFloat7, float paramFloat8, float paramFloat9, float paramFloat10);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private native void nAddImageQuad(long paramLong, float paramFloat1, float paramFloat2, float paramFloat3, float paramFloat4, float paramFloat5, float paramFloat6, float paramFloat7, float paramFloat8, float paramFloat9, float paramFloat10, float paramFloat11, float paramFloat12);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private native void nAddImageQuad(long paramLong, float paramFloat1, float paramFloat2, float paramFloat3, float paramFloat4, float paramFloat5, float paramFloat6, float paramFloat7, float paramFloat8, float paramFloat9, float paramFloat10, float paramFloat11, float paramFloat12, float paramFloat13, float paramFloat14);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private native void nAddImageQuad(long paramLong, float paramFloat1, float paramFloat2, float paramFloat3, float paramFloat4, float paramFloat5, float paramFloat6, float paramFloat7, float paramFloat8, float paramFloat9, float paramFloat10, float paramFloat11, float paramFloat12, float paramFloat13, float paramFloat14, float paramFloat15, float paramFloat16);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private native void nAddImageQuad(long paramLong, float paramFloat1, float paramFloat2, float paramFloat3, float paramFloat4, float paramFloat5, float paramFloat6, float paramFloat7, float paramFloat8, float paramFloat9, float paramFloat10, float paramFloat11, float paramFloat12, float paramFloat13, float paramFloat14, float paramFloat15, float paramFloat16, int paramInt);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void addImageRounded(long textureID, ImVec2 pMin, ImVec2 pMax, ImVec2 uvMin, ImVec2 uvMax, int col, float rounding) {
/* 1184 */     nAddImageRounded(textureID, pMin.x, pMin.y, pMax.x, pMax.y, uvMin.x, uvMin.y, uvMax.x, uvMax.y, col, rounding);
/*      */   }
/*      */   
/*      */   public void addImageRounded(long textureID, float pMinX, float pMinY, float pMaxX, float pMaxY, float uvMinX, float uvMinY, float uvMaxX, float uvMaxY, int col, float rounding) {
/* 1188 */     nAddImageRounded(textureID, pMinX, pMinY, pMaxX, pMaxY, uvMinX, uvMinY, uvMaxX, uvMaxY, col, rounding);
/*      */   }
/*      */   
/*      */   public void addImageRounded(long textureID, ImVec2 pMin, ImVec2 pMax, ImVec2 uvMin, ImVec2 uvMax, int col, float rounding, int imDrawFlags) {
/* 1192 */     nAddImageRounded(textureID, pMin.x, pMin.y, pMax.x, pMax.y, uvMin.x, uvMin.y, uvMax.x, uvMax.y, col, rounding, imDrawFlags);
/*      */   }
/*      */   
/*      */   public void addImageRounded(long textureID, float pMinX, float pMinY, float pMaxX, float pMaxY, float uvMinX, float uvMinY, float uvMaxX, float uvMaxY, int col, float rounding, int imDrawFlags) {
/* 1196 */     nAddImageRounded(textureID, pMinX, pMinY, pMaxX, pMaxY, uvMinX, uvMinY, uvMaxX, uvMaxY, col, rounding, imDrawFlags);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private native void nAddImageRounded(long paramLong, float paramFloat1, float paramFloat2, float paramFloat3, float paramFloat4, float paramFloat5, float paramFloat6, float paramFloat7, float paramFloat8, int paramInt, float paramFloat9);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private native void nAddImageRounded(long paramLong, float paramFloat1, float paramFloat2, float paramFloat3, float paramFloat4, float paramFloat5, float paramFloat6, float paramFloat7, float paramFloat8, int paramInt1, float paramFloat9, int paramInt2);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void pathClear() {
/* 1220 */     nPathClear();
/*      */   }
/*      */ 
/*      */   
/*      */   private native void nPathClear();
/*      */ 
/*      */   
/*      */   public void pathLineTo(ImVec2 pos) {
/* 1228 */     nPathLineTo(pos.x, pos.y);
/*      */   }
/*      */   
/*      */   public void pathLineTo(float posX, float posY) {
/* 1232 */     nPathLineTo(posX, posY);
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   private native void nPathLineTo(float paramFloat1, float paramFloat2);
/*      */ 
/*      */   
/*      */   public void pathLineToMergeDuplicate(ImVec2 pos) {
/* 1241 */     nPathLineToMergeDuplicate(pos.x, pos.y);
/*      */   }
/*      */   
/*      */   public void pathLineToMergeDuplicate(float posX, float posY) {
/* 1245 */     nPathLineToMergeDuplicate(posX, posY);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private native void nPathLineToMergeDuplicate(float paramFloat1, float paramFloat2);
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void pathFillConvex(int col) {
/* 1257 */     nPathFillConvex(col);
/*      */   }
/*      */ 
/*      */   
/*      */   private native void nPathFillConvex(int paramInt);
/*      */ 
/*      */   
/*      */   public void pathFillConcave(int col) {
/* 1265 */     nPathFillConcave(col);
/*      */   }
/*      */ 
/*      */   
/*      */   private native void nPathFillConcave(int paramInt);
/*      */ 
/*      */   
/*      */   public void pathStroke(int col) {
/* 1273 */     nPathStroke(col);
/*      */   }
/*      */   
/*      */   public void pathStroke(int col, int imDrawFlags) {
/* 1277 */     nPathStroke(col, imDrawFlags);
/*      */   }
/*      */   
/*      */   public void pathStroke(int col, int imDrawFlags, float thickness) {
/* 1281 */     nPathStroke(col, imDrawFlags, thickness);
/*      */   }
/*      */   
/*      */   public void pathStroke(int col, float thickness) {
/* 1285 */     nPathStroke(col, thickness);
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   private native void nPathStroke(int paramInt);
/*      */ 
/*      */ 
/*      */   
/*      */   private native void nPathStroke(int paramInt1, int paramInt2);
/*      */ 
/*      */ 
/*      */   
/*      */   private native void nPathStroke(int paramInt1, int paramInt2, float paramFloat);
/*      */ 
/*      */   
/*      */   private native void nPathStroke(int paramInt, float paramFloat);
/*      */ 
/*      */   
/*      */   public void pathArcTo(ImVec2 center, float radius, float aMin, float aMax) {
/* 1305 */     nPathArcTo(center.x, center.y, radius, aMin, aMax);
/*      */   }
/*      */   
/*      */   public void pathArcTo(float centerX, float centerY, float radius, float aMin, float aMax) {
/* 1309 */     nPathArcTo(centerX, centerY, radius, aMin, aMax);
/*      */   }
/*      */   
/*      */   public void pathArcTo(ImVec2 center, float radius, float aMin, float aMax, int numSegments) {
/* 1313 */     nPathArcTo(center.x, center.y, radius, aMin, aMax, numSegments);
/*      */   }
/*      */   
/*      */   public void pathArcTo(float centerX, float centerY, float radius, float aMin, float aMax, int numSegments) {
/* 1317 */     nPathArcTo(centerX, centerY, radius, aMin, aMax, numSegments);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private native void nPathArcTo(float paramFloat1, float paramFloat2, float paramFloat3, float paramFloat4, float paramFloat5);
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private native void nPathArcTo(float paramFloat1, float paramFloat2, float paramFloat3, float paramFloat4, float paramFloat5, int paramInt);
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void pathArcToFast(ImVec2 center, float radius, int aMinOf12, int aMaxOf12) {
/* 1334 */     nPathArcToFast(center.x, center.y, radius, aMinOf12, aMaxOf12);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void pathArcToFast(float centerX, float centerY, float radius, int aMinOf12, int aMaxOf12) {
/* 1341 */     nPathArcToFast(centerX, centerY, radius, aMinOf12, aMaxOf12);
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   private native void nPathArcToFast(float paramFloat1, float paramFloat2, float paramFloat3, int paramInt1, int paramInt2);
/*      */ 
/*      */   
/*      */   public void pathEllipticalArcTo(ImVec2 center, ImVec2 radius, float rot, float aMin, float aMax) {
/* 1350 */     nPathEllipticalArcTo(center.x, center.y, radius.x, radius.y, rot, aMin, aMax);
/*      */   }
/*      */   
/*      */   public void pathEllipticalArcTo(float centerX, float centerY, float radiusX, float radiusY, float rot, float aMin, float aMax) {
/* 1354 */     nPathEllipticalArcTo(centerX, centerY, radiusX, radiusY, rot, aMin, aMax);
/*      */   }
/*      */   
/*      */   public void pathEllipticalArcTo(ImVec2 center, ImVec2 radius, float rot, float aMin, float aMax, int numSegments) {
/* 1358 */     nPathEllipticalArcTo(center.x, center.y, radius.x, radius.y, rot, aMin, aMax, numSegments);
/*      */   }
/*      */   
/*      */   public void pathEllipticalArcTo(float centerX, float centerY, float radiusX, float radiusY, float rot, float aMin, float aMax, int numSegments) {
/* 1362 */     nPathEllipticalArcTo(centerX, centerY, radiusX, radiusY, rot, aMin, aMax, numSegments);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private native void nPathEllipticalArcTo(float paramFloat1, float paramFloat2, float paramFloat3, float paramFloat4, float paramFloat5, float paramFloat6, float paramFloat7);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private native void nPathEllipticalArcTo(float paramFloat1, float paramFloat2, float paramFloat3, float paramFloat4, float paramFloat5, float paramFloat6, float paramFloat7, int paramInt);
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void pathBezierCubicCurveTo(ImVec2 p2, ImVec2 p3, ImVec2 p4) {
/* 1381 */     nPathBezierCubicCurveTo(p2.x, p2.y, p3.x, p3.y, p4.x, p4.y);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void pathBezierCubicCurveTo(float p2X, float p2Y, float p3X, float p3Y, float p4X, float p4Y) {
/* 1388 */     nPathBezierCubicCurveTo(p2X, p2Y, p3X, p3Y, p4X, p4Y);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void pathBezierCubicCurveTo(ImVec2 p2, ImVec2 p3, ImVec2 p4, int numSegments) {
/* 1395 */     nPathBezierCubicCurveTo(p2.x, p2.y, p3.x, p3.y, p4.x, p4.y, numSegments);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void pathBezierCubicCurveTo(float p2X, float p2Y, float p3X, float p3Y, float p4X, float p4Y, int numSegments) {
/* 1402 */     nPathBezierCubicCurveTo(p2X, p2Y, p3X, p3Y, p4X, p4Y, numSegments);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private native void nPathBezierCubicCurveTo(float paramFloat1, float paramFloat2, float paramFloat3, float paramFloat4, float paramFloat5, float paramFloat6);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private native void nPathBezierCubicCurveTo(float paramFloat1, float paramFloat2, float paramFloat3, float paramFloat4, float paramFloat5, float paramFloat6, int paramInt);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void pathBezierQuadraticCurveTo(ImVec2 p2, ImVec2 p3) {
/* 1423 */     nPathBezierQuadraticCurveTo(p2.x, p2.y, p3.x, p3.y);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void pathBezierQuadraticCurveTo(float p2X, float p2Y, float p3X, float p3Y) {
/* 1430 */     nPathBezierQuadraticCurveTo(p2X, p2Y, p3X, p3Y);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void pathBezierQuadraticCurveTo(ImVec2 p2, ImVec2 p3, int numSegments) {
/* 1437 */     nPathBezierQuadraticCurveTo(p2.x, p2.y, p3.x, p3.y, numSegments);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void pathBezierQuadraticCurveTo(float p2X, float p2Y, float p3X, float p3Y, int numSegments) {
/* 1444 */     nPathBezierQuadraticCurveTo(p2X, p2Y, p3X, p3Y, numSegments);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private native void nPathBezierQuadraticCurveTo(float paramFloat1, float paramFloat2, float paramFloat3, float paramFloat4);
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private native void nPathBezierQuadraticCurveTo(float paramFloat1, float paramFloat2, float paramFloat3, float paramFloat4, int paramInt);
/*      */ 
/*      */ 
/*      */   
/*      */   public void pathRect(ImVec2 rectMin, ImVec2 rectMax) {
/* 1460 */     nPathRect(rectMin.x, rectMin.y, rectMax.x, rectMax.y);
/*      */   }
/*      */   
/*      */   public void pathRect(float rectMinX, float rectMinY, float rectMaxX, float rectMaxY) {
/* 1464 */     nPathRect(rectMinX, rectMinY, rectMaxX, rectMaxY);
/*      */   }
/*      */   
/*      */   public void pathRect(ImVec2 rectMin, ImVec2 rectMax, float rounding) {
/* 1468 */     nPathRect(rectMin.x, rectMin.y, rectMax.x, rectMax.y, rounding);
/*      */   }
/*      */   
/*      */   public void pathRect(float rectMinX, float rectMinY, float rectMaxX, float rectMaxY, float rounding) {
/* 1472 */     nPathRect(rectMinX, rectMinY, rectMaxX, rectMaxY, rounding);
/*      */   }
/*      */   
/*      */   public void pathRect(ImVec2 rectMin, ImVec2 rectMax, float rounding, int imDrawFlags) {
/* 1476 */     nPathRect(rectMin.x, rectMin.y, rectMax.x, rectMax.y, rounding, imDrawFlags);
/*      */   }
/*      */   
/*      */   public void pathRect(float rectMinX, float rectMinY, float rectMaxX, float rectMaxY, float rounding, int imDrawFlags) {
/* 1480 */     nPathRect(rectMinX, rectMinY, rectMaxX, rectMaxY, rounding, imDrawFlags);
/*      */   }
/*      */   
/*      */   public void pathRect(ImVec2 rectMin, ImVec2 rectMax, int imDrawFlags) {
/* 1484 */     nPathRect(rectMin.x, rectMin.y, rectMax.x, rectMax.y, imDrawFlags);
/*      */   }
/*      */   
/*      */   public void pathRect(float rectMinX, float rectMinY, float rectMaxX, float rectMaxY, int imDrawFlags) {
/* 1488 */     nPathRect(rectMinX, rectMinY, rectMaxX, rectMaxY, imDrawFlags);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private native void nPathRect(float paramFloat1, float paramFloat2, float paramFloat3, float paramFloat4);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private native void nPathRect(float paramFloat1, float paramFloat2, float paramFloat3, float paramFloat4, float paramFloat5);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private native void nPathRect(float paramFloat1, float paramFloat2, float paramFloat3, float paramFloat4, float paramFloat5, int paramInt);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private native void nPathRect(float paramFloat1, float paramFloat2, float paramFloat3, float paramFloat4, int paramInt);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void channelsSplit(int count) {
/* 1522 */     nChannelsSplit(count);
/*      */   }
/*      */ 
/*      */   
/*      */   private native void nChannelsSplit(int paramInt);
/*      */ 
/*      */   
/*      */   public void channelsMerge() {
/* 1530 */     nChannelsMerge();
/*      */   }
/*      */ 
/*      */   
/*      */   private native void nChannelsMerge();
/*      */ 
/*      */   
/*      */   public void channelsSetCurrent(int n) {
/* 1538 */     nChannelsSetCurrent(n);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private native void nChannelsSetCurrent(int paramInt);
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void primReserve(int idxCount, int vtxCount) {
/* 1550 */     nPrimReserve(idxCount, vtxCount);
/*      */   }
/*      */ 
/*      */   
/*      */   private native void nPrimReserve(int paramInt1, int paramInt2);
/*      */ 
/*      */   
/*      */   public void primUnreserve(int idxCount, int vtxCount) {
/* 1558 */     nPrimUnreserve(idxCount, vtxCount);
/*      */   }
/*      */ 
/*      */   
/*      */   private native void nPrimUnreserve(int paramInt1, int paramInt2);
/*      */ 
/*      */   
/*      */   public void primRect(ImVec2 a, ImVec2 b, int col) {
/* 1566 */     nPrimRect(a.x, a.y, b.x, b.y, col);
/*      */   }
/*      */   
/*      */   public void primRect(float aX, float aY, float bX, float bY, int col) {
/* 1570 */     nPrimRect(aX, aY, bX, bY, col);
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   private native void nPrimRect(float paramFloat1, float paramFloat2, float paramFloat3, float paramFloat4, int paramInt);
/*      */ 
/*      */ 
/*      */   
/*      */   public void primRectUV(ImVec2 a, ImVec2 b, ImVec2 uvA, ImVec2 uvB, int col) {
/* 1580 */     nPrimRectUV(a.x, a.y, b.x, b.y, uvA.x, uvA.y, uvB.x, uvB.y, col);
/*      */   }
/*      */   
/*      */   public void primRectUV(float aX, float aY, float bX, float bY, float uvAX, float uvAY, float uvBX, float uvBY, int col) {
/* 1584 */     nPrimRectUV(aX, aY, bX, bY, uvAX, uvAY, uvBX, uvBY, col);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private native void nPrimRectUV(float paramFloat1, float paramFloat2, float paramFloat3, float paramFloat4, float paramFloat5, float paramFloat6, float paramFloat7, float paramFloat8, int paramInt);
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void primQuadUV(ImVec2 a, ImVec2 b, ImVec2 c, ImVec2 d, ImVec2 uvA, ImVec2 uvB, ImVec2 uvC, ImVec2 uvD, int col) {
/* 1596 */     nPrimQuadUV(a.x, a.y, b.x, b.y, c.x, c.y, d.x, d.y, uvA.x, uvA.y, uvB.x, uvB.y, uvC.x, uvC.y, uvD.x, uvD.y, col);
/*      */   }
/*      */   
/*      */   public void primQuadUV(float aX, float aY, float bX, float bY, float cX, float cY, float dX, float dY, float uvAX, float uvAY, float uvBX, float uvBY, float uvCX, float uvCY, float uvDX, float uvDY, int col) {
/* 1600 */     nPrimQuadUV(aX, aY, bX, bY, cX, cY, dX, dY, uvAX, uvAY, uvBX, uvBY, uvCX, uvCY, uvDX, uvDY, col);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private native void nPrimQuadUV(float paramFloat1, float paramFloat2, float paramFloat3, float paramFloat4, float paramFloat5, float paramFloat6, float paramFloat7, float paramFloat8, float paramFloat9, float paramFloat10, float paramFloat11, float paramFloat12, float paramFloat13, float paramFloat14, float paramFloat15, float paramFloat16, int paramInt);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void primWriteVtx(ImVec2 pos, ImVec2 uv, int col) {
/* 1616 */     nPrimWriteVtx(pos.x, pos.y, uv.x, uv.y, col);
/*      */   }
/*      */   
/*      */   public void primWriteVtx(float posX, float posY, float uvX, float uvY, int col) {
/* 1620 */     nPrimWriteVtx(posX, posY, uvX, uvY, col);
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   private native void nPrimWriteVtx(float paramFloat1, float paramFloat2, float paramFloat3, float paramFloat4, int paramInt);
/*      */ 
/*      */ 
/*      */   
/*      */   public void primWriteIdx(int idx) {
/* 1630 */     nPrimWriteIdx(idx);
/*      */   }
/*      */ 
/*      */   
/*      */   private native void nPrimWriteIdx(int paramInt);
/*      */ 
/*      */   
/*      */   public void primVtx(ImVec2 pos, ImVec2 uv, int col) {
/* 1638 */     nPrimVtx(pos.x, pos.y, uv.x, uv.y, col);
/*      */   }
/*      */   
/*      */   public void primVtx(float posX, float posY, float uvX, float uvY, int col) {
/* 1642 */     nPrimVtx(posX, posY, uvX, uvY, col);
/*      */   }
/*      */   
/*      */   private native void nPrimVtx(float paramFloat1, float paramFloat2, float paramFloat3, float paramFloat4, int paramInt);
/*      */ }


/* Location:              C:\Users\rapha\Downloads\aurora.jar!\META-INF\jars\imgui-java-binding-1.90.0.jar!\imgui\ImDrawList.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */