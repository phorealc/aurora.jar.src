/*     */ package imgui;
/*     */ 
/*     */ import imgui.binding.ImGuiStructDestroyable;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class ImGuiKeyData
/*     */   extends ImGuiStructDestroyable
/*     */ {
/*     */   public ImGuiKeyData() {}
/*     */   
/*     */   public ImGuiKeyData(long ptr) {
/*  15 */     super(ptr);
/*     */   }
/*     */ 
/*     */   
/*     */   protected long create() {
/*  20 */     return nCreate();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private native long nCreate();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean getDown() {
/*  36 */     return nGetDown();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setDown(boolean value) {
/*  43 */     nSetDown(value);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private native boolean nGetDown();
/*     */ 
/*     */ 
/*     */   
/*     */   private native void nSetDown(boolean paramBoolean);
/*     */ 
/*     */ 
/*     */   
/*     */   public float getDownDuration() {
/*  58 */     return nGetDownDuration();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setDownDuration(float value) {
/*  65 */     nSetDownDuration(value);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private native float nGetDownDuration();
/*     */ 
/*     */ 
/*     */   
/*     */   private native void nSetDownDuration(float paramFloat);
/*     */ 
/*     */ 
/*     */   
/*     */   public float getDownDurationPrev() {
/*  80 */     return nGetDownDurationPrev();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setDownDurationPrev(float value) {
/*  87 */     nSetDownDurationPrev(value);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private native float nGetDownDurationPrev();
/*     */ 
/*     */ 
/*     */   
/*     */   private native void nSetDownDurationPrev(float paramFloat);
/*     */ 
/*     */ 
/*     */   
/*     */   public float getAnalogValue() {
/* 102 */     return nGetAnalogValue();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setAnalogValue(float value) {
/* 109 */     nSetAnalogValue(value);
/*     */   }
/*     */   
/*     */   private native float nGetAnalogValue();
/*     */   
/*     */   private native void nSetAnalogValue(float paramFloat);
/*     */ }


/* Location:              C:\Users\rapha\Downloads\aurora.jar!\META-INF\jars\imgui-java-binding-1.90.0.jar!\imgui\ImGuiKeyData.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */