package imgui.extension.imguiknobs.flag;

public final class ImGuiKnobFlags {
  public static final int None = 0;
  
  public static final int NoTitle = 1;
  
  public static final int NoInput = 2;
  
  public static final int ValueTooltip = 4;
  
  public static final int DragHorizontal = 8;
}


/* Location:              C:\Users\rapha\Downloads\aurora.jar!\META-INF\jars\imgui-java-binding-1.90.0.jar!\imgui\extension\imguiknobs\flag\ImGuiKnobFlags.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */