package imgui.extension.imguiknobs.flag;

public final class ImGuiKnobVariant {
  public static final int Tick = 1;
  
  public static final int Dot = 2;
  
  public static final int Wiper = 4;
  
  public static final int WiperOnly = 8;
  
  public static final int WiperDot = 16;
  
  public static final int Stepped = 32;
  
  public static final int Space = 64;
}


/* Location:              C:\Users\rapha\Downloads\aurora.jar!\META-INF\jars\imgui-java-binding-1.90.0.jar!\imgui\extension\imguiknobs\flag\ImGuiKnobVariant.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */