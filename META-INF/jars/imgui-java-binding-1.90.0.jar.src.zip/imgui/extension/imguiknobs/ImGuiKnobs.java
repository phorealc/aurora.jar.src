/*     */ package imgui.extension.imguiknobs;
/*     */ 
/*     */ import imgui.type.ImFloat;
/*     */ import imgui.type.ImInt;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class ImGuiKnobs
/*     */ {
/*     */   public static boolean knob(String label, ImFloat pValue, float vMin, float vMax) {
/*  31 */     return nKnob(label, (pValue != null) ? pValue.getData() : null, vMin, vMax);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static boolean knob(String label, ImFloat pValue, float vMin, float vMax, float speed) {
/*  49 */     return nKnob(label, (pValue != null) ? pValue.getData() : null, vMin, vMax, speed);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static boolean knob(String label, ImFloat pValue, float vMin, float vMax, float speed, String format) {
/*  69 */     return nKnob(label, (pValue != null) ? pValue.getData() : null, vMin, vMax, speed, format);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static boolean knob(String label, ImFloat pValue, float vMin, float vMax, float speed, String format, int variant) {
/*  89 */     return nKnob(label, (pValue != null) ? pValue.getData() : null, vMin, vMax, speed, format, variant);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static boolean knob(String label, ImFloat pValue, float vMin, float vMax, float speed, String format, int variant, float size) {
/* 111 */     return nKnob(label, (pValue != null) ? pValue.getData() : null, vMin, vMax, speed, format, variant, size);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static boolean knob(String label, ImFloat pValue, float vMin, float vMax, float speed, String format, int variant, float size, int flags) {
/* 133 */     return nKnob(label, (pValue != null) ? pValue.getData() : null, vMin, vMax, speed, format, variant, size, flags);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static boolean knob(String label, ImFloat pValue, float vMin, float vMax, float speed, String format, int variant, float size, int flags, int steps) {
/* 157 */     return nKnob(label, (pValue != null) ? pValue.getData() : null, vMin, vMax, speed, format, variant, size, flags, steps);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static boolean knob(String label, ImFloat pValue, float vMin, float vMax, String format, int variant, float size, int flags, int steps) {
/* 179 */     return nKnob(label, (pValue != null) ? pValue.getData() : null, vMin, vMax, format, variant, size, flags, steps);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static boolean knob(String label, ImFloat pValue, float vMin, float vMax, int variant, float size, int flags, int steps) {
/* 199 */     return nKnob(label, (pValue != null) ? pValue.getData() : null, vMin, vMax, variant, size, flags, steps);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static boolean knob(String label, ImFloat pValue, float vMin, float vMax, float speed, int variant, float size, int flags, int steps) {
/* 221 */     return nKnob(label, (pValue != null) ? pValue.getData() : null, vMin, vMax, speed, variant, size, flags, steps);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static boolean knob(String label, ImFloat pValue, float vMin, float vMax, float speed, float size, int flags, int steps) {
/* 243 */     return nKnob(label, (pValue != null) ? pValue.getData() : null, vMin, vMax, speed, size, flags, steps);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static boolean knob(String label, ImFloat pValue, float vMin, float vMax, float speed, int flags, int steps) {
/* 263 */     return nKnob(label, (pValue != null) ? pValue.getData() : null, vMin, vMax, speed, flags, steps);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static boolean knob(String label, ImFloat pValue, float vMin, float vMax, float speed, int steps) {
/* 283 */     return nKnob(label, (pValue != null) ? pValue.getData() : null, vMin, vMax, speed, steps);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static boolean knob(String label, ImFloat pValue, float vMin, float vMax, float speed, String format, float size, int flags, int steps) {
/* 307 */     return nKnob(label, (pValue != null) ? pValue.getData() : null, vMin, vMax, speed, format, size, flags, steps);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static boolean knob(String label, ImFloat pValue, float vMin, float vMax, float speed, String format, int variant, int flags, int steps) {
/* 329 */     return nKnob(label, (pValue != null) ? pValue.getData() : null, vMin, vMax, speed, format, variant, flags, steps);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static boolean knob(String label, ImFloat pValue, float vMin, float vMax, float speed, String format, int variant, int steps) {
/* 351 */     return nKnob(label, (pValue != null) ? pValue.getData() : null, vMin, vMax, speed, format, variant, steps);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static native boolean nKnob(String paramString, float[] paramArrayOffloat, float paramFloat1, float paramFloat2);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static native boolean nKnob(String paramString, float[] paramArrayOffloat, float paramFloat1, float paramFloat2, float paramFloat3);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static native boolean nKnob(String paramString1, float[] paramArrayOffloat, float paramFloat1, float paramFloat2, float paramFloat3, String paramString2);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static native boolean nKnob(String paramString1, float[] paramArrayOffloat, float paramFloat1, float paramFloat2, float paramFloat3, String paramString2, int paramInt);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static native boolean nKnob(String paramString1, float[] paramArrayOffloat, float paramFloat1, float paramFloat2, float paramFloat3, String paramString2, int paramInt, float paramFloat4);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static native boolean nKnob(String paramString1, float[] paramArrayOffloat, float paramFloat1, float paramFloat2, float paramFloat3, String paramString2, int paramInt1, float paramFloat4, int paramInt2);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static native boolean nKnob(String paramString1, float[] paramArrayOffloat, float paramFloat1, float paramFloat2, float paramFloat3, String paramString2, int paramInt1, float paramFloat4, int paramInt2, int paramInt3);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static native boolean nKnob(String paramString1, float[] paramArrayOffloat, float paramFloat1, float paramFloat2, String paramString2, int paramInt1, float paramFloat3, int paramInt2, int paramInt3);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static native boolean nKnob(String paramString, float[] paramArrayOffloat, float paramFloat1, float paramFloat2, int paramInt1, float paramFloat3, int paramInt2, int paramInt3);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static native boolean nKnob(String paramString, float[] paramArrayOffloat, float paramFloat1, float paramFloat2, float paramFloat3, int paramInt1, float paramFloat4, int paramInt2, int paramInt3);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static native boolean nKnob(String paramString, float[] paramArrayOffloat, float paramFloat1, float paramFloat2, float paramFloat3, float paramFloat4, int paramInt1, int paramInt2);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static native boolean nKnob(String paramString, float[] paramArrayOffloat, float paramFloat1, float paramFloat2, float paramFloat3, int paramInt1, int paramInt2);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static native boolean nKnob(String paramString, float[] paramArrayOffloat, float paramFloat1, float paramFloat2, float paramFloat3, int paramInt);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static native boolean nKnob(String paramString1, float[] paramArrayOffloat, float paramFloat1, float paramFloat2, float paramFloat3, String paramString2, float paramFloat4, int paramInt1, int paramInt2);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static native boolean nKnob(String paramString1, float[] paramArrayOffloat, float paramFloat1, float paramFloat2, float paramFloat3, String paramString2, int paramInt1, int paramInt2, int paramInt3);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static native boolean nKnob(String paramString1, float[] paramArrayOffloat, float paramFloat1, float paramFloat2, float paramFloat3, String paramString2, int paramInt1, int paramInt2);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static boolean knob(String label, ImInt pValue, int vMin, int vMax) {
/* 529 */     return nKnob(label, (pValue != null) ? pValue.getData() : null, vMin, vMax);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static boolean knob(String label, ImInt pValue, int vMin, int vMax, float speed) {
/* 547 */     return nKnob(label, (pValue != null) ? pValue.getData() : null, vMin, vMax, speed);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static boolean knob(String label, ImInt pValue, int vMin, int vMax, float speed, String format) {
/* 567 */     return nKnob(label, (pValue != null) ? pValue.getData() : null, vMin, vMax, speed, format);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static boolean knob(String label, ImInt pValue, int vMin, int vMax, float speed, String format, int variant) {
/* 587 */     return nKnob(label, (pValue != null) ? pValue.getData() : null, vMin, vMax, speed, format, variant);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static boolean knob(String label, ImInt pValue, int vMin, int vMax, float speed, String format, int variant, float size) {
/* 609 */     return nKnob(label, (pValue != null) ? pValue.getData() : null, vMin, vMax, speed, format, variant, size);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static boolean knob(String label, ImInt pValue, int vMin, int vMax, float speed, String format, int variant, float size, int flags) {
/* 631 */     return nKnob(label, (pValue != null) ? pValue.getData() : null, vMin, vMax, speed, format, variant, size, flags);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static boolean knob(String label, ImInt pValue, int vMin, int vMax, float speed, String format, int variant, float size, int flags, int steps) {
/* 655 */     return nKnob(label, (pValue != null) ? pValue.getData() : null, vMin, vMax, speed, format, variant, size, flags, steps);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static boolean knob(String label, ImInt pValue, int vMin, int vMax, String format, int variant, float size, int flags, int steps) {
/* 677 */     return nKnob(label, (pValue != null) ? pValue.getData() : null, vMin, vMax, format, variant, size, flags, steps);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static boolean knob(String label, ImInt pValue, int vMin, int vMax, int variant, float size, int flags, int steps) {
/* 697 */     return nKnob(label, (pValue != null) ? pValue.getData() : null, vMin, vMax, variant, size, flags, steps);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static boolean knob(String label, ImInt pValue, int vMin, int vMax, float speed, int variant, float size, int flags, int steps) {
/* 719 */     return nKnob(label, (pValue != null) ? pValue.getData() : null, vMin, vMax, speed, variant, size, flags, steps);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static boolean knob(String label, ImInt pValue, int vMin, int vMax, float speed, float size, int flags, int steps) {
/* 741 */     return nKnob(label, (pValue != null) ? pValue.getData() : null, vMin, vMax, speed, size, flags, steps);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static boolean knob(String label, ImInt pValue, int vMin, int vMax, float speed, int flags, int steps) {
/* 761 */     return nKnob(label, (pValue != null) ? pValue.getData() : null, vMin, vMax, speed, flags, steps);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static boolean knob(String label, ImInt pValue, int vMin, int vMax, float speed, int steps) {
/* 781 */     return nKnob(label, (pValue != null) ? pValue.getData() : null, vMin, vMax, speed, steps);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static boolean knob(String label, ImInt pValue, int vMin, int vMax, float speed, String format, float size, int flags, int steps) {
/* 805 */     return nKnob(label, (pValue != null) ? pValue.getData() : null, vMin, vMax, speed, format, size, flags, steps);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static boolean knob(String label, ImInt pValue, int vMin, int vMax, float speed, String format, int variant, int flags, int steps) {
/* 827 */     return nKnob(label, (pValue != null) ? pValue.getData() : null, vMin, vMax, speed, format, variant, flags, steps);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static boolean knob(String label, ImInt pValue, int vMin, int vMax, float speed, String format, int variant, int steps) {
/* 849 */     return nKnob(label, (pValue != null) ? pValue.getData() : null, vMin, vMax, speed, format, variant, steps);
/*     */   }
/*     */   
/*     */   private static native boolean nKnob(String paramString, int[] paramArrayOfint, int paramInt1, int paramInt2);
/*     */   
/*     */   private static native boolean nKnob(String paramString, int[] paramArrayOfint, int paramInt1, int paramInt2, float paramFloat);
/*     */   
/*     */   private static native boolean nKnob(String paramString1, int[] paramArrayOfint, int paramInt1, int paramInt2, float paramFloat, String paramString2);
/*     */   
/*     */   private static native boolean nKnob(String paramString1, int[] paramArrayOfint, int paramInt1, int paramInt2, float paramFloat, String paramString2, int paramInt3);
/*     */   
/*     */   private static native boolean nKnob(String paramString1, int[] paramArrayOfint, int paramInt1, int paramInt2, float paramFloat1, String paramString2, int paramInt3, float paramFloat2);
/*     */   
/*     */   private static native boolean nKnob(String paramString1, int[] paramArrayOfint, int paramInt1, int paramInt2, float paramFloat1, String paramString2, int paramInt3, float paramFloat2, int paramInt4);
/*     */   
/*     */   private static native boolean nKnob(String paramString1, int[] paramArrayOfint, int paramInt1, int paramInt2, float paramFloat1, String paramString2, int paramInt3, float paramFloat2, int paramInt4, int paramInt5);
/*     */   
/*     */   private static native boolean nKnob(String paramString1, int[] paramArrayOfint, int paramInt1, int paramInt2, String paramString2, int paramInt3, float paramFloat, int paramInt4, int paramInt5);
/*     */   
/*     */   private static native boolean nKnob(String paramString, int[] paramArrayOfint, int paramInt1, int paramInt2, int paramInt3, float paramFloat, int paramInt4, int paramInt5);
/*     */   
/*     */   private static native boolean nKnob(String paramString, int[] paramArrayOfint, int paramInt1, int paramInt2, float paramFloat1, int paramInt3, float paramFloat2, int paramInt4, int paramInt5);
/*     */   
/*     */   private static native boolean nKnob(String paramString, int[] paramArrayOfint, int paramInt1, int paramInt2, float paramFloat1, float paramFloat2, int paramInt3, int paramInt4);
/*     */   
/*     */   private static native boolean nKnob(String paramString, int[] paramArrayOfint, int paramInt1, int paramInt2, float paramFloat, int paramInt3, int paramInt4);
/*     */   
/*     */   private static native boolean nKnob(String paramString, int[] paramArrayOfint, int paramInt1, int paramInt2, float paramFloat, int paramInt3);
/*     */   
/*     */   private static native boolean nKnob(String paramString1, int[] paramArrayOfint, int paramInt1, int paramInt2, float paramFloat1, String paramString2, float paramFloat2, int paramInt3, int paramInt4);
/*     */   
/*     */   private static native boolean nKnob(String paramString1, int[] paramArrayOfint, int paramInt1, int paramInt2, float paramFloat, String paramString2, int paramInt3, int paramInt4, int paramInt5);
/*     */   
/*     */   private static native boolean nKnob(String paramString1, int[] paramArrayOfint, int paramInt1, int paramInt2, float paramFloat, String paramString2, int paramInt3, int paramInt4);
/*     */ }


/* Location:              C:\Users\rapha\Downloads\aurora.jar!\META-INF\jars\imgui-java-binding-1.90.0.jar!\imgui\extension\imguiknobs\ImGuiKnobs.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */