/*      */ package imgui.extension.nodeditor;
/*      */ 
/*      */ import imgui.ImDrawList;
/*      */ import imgui.ImVec2;
/*      */ import imgui.ImVec4;
/*      */ import imgui.type.ImLong;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ public final class NodeEditor
/*      */ {
/*      */   public static void setCurrentEditor(NodeEditorContext ctx) {
/*   36 */     nSetCurrentEditor(ctx.ptr);
/*      */   }
/*      */ 
/*      */   
/*      */   private static native void nSetCurrentEditor(long paramLong);
/*      */ 
/*      */   
/*      */   public static NodeEditorContext getCurrentEditor() {
/*   44 */     return new NodeEditorContext(nGetCurrentEditor());
/*      */   }
/*      */ 
/*      */   
/*      */   private static native long nGetCurrentEditor();
/*      */ 
/*      */   
/*      */   public static NodeEditorContext createEditor() {
/*   52 */     return new NodeEditorContext(nCreateEditor());
/*      */   }
/*      */   
/*      */   public static NodeEditorContext createEditor(NodeEditorConfig config) {
/*   56 */     return new NodeEditorContext(nCreateEditor(config.ptr));
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   private static native long nCreateEditor();
/*      */ 
/*      */   
/*      */   private static native long nCreateEditor(long paramLong);
/*      */ 
/*      */   
/*      */   public static void destroyEditor(NodeEditorContext ctx) {
/*   68 */     nDestroyEditor(ctx.ptr);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*   75 */   private static final NodeEditorStyle _GETSTYLE_1 = new NodeEditorStyle(0L);
/*      */   
/*      */   public static NodeEditorStyle getStyle() {
/*   78 */     _GETSTYLE_1.ptr = nGetStyle();
/*   79 */     return _GETSTYLE_1;
/*      */   }
/*      */   
/*      */   private static native void nDestroyEditor(long paramLong);
/*      */   
/*      */   private static native long nGetStyle();
/*      */   
/*      */   public static String getStyleColorName(int colorIndex) {
/*   87 */     return nGetStyleColorName(colorIndex);
/*      */   }
/*      */ 
/*      */   
/*      */   private static native String nGetStyleColorName(int paramInt);
/*      */ 
/*      */   
/*      */   public static void pushStyleColor(int colorIndex, ImVec4 color) {
/*   95 */     nPushStyleColor(colorIndex, color.x, color.y, color.z, color.w);
/*      */   }
/*      */   
/*      */   public static void pushStyleColor(int colorIndex, float colorX, float colorY, float colorZ, float colorW) {
/*   99 */     nPushStyleColor(colorIndex, colorX, colorY, colorZ, colorW);
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   private static native void nPushStyleColor(int paramInt, float paramFloat1, float paramFloat2, float paramFloat3, float paramFloat4);
/*      */ 
/*      */   
/*      */   public static void popStyleColor() {
/*  108 */     nPopStyleColor();
/*      */   }
/*      */   
/*      */   public static void popStyleColor(int count) {
/*  112 */     nPopStyleColor(count);
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   private static native void nPopStyleColor();
/*      */ 
/*      */   
/*      */   private static native void nPopStyleColor(int paramInt);
/*      */ 
/*      */   
/*      */   public static void pushStyleVar(int varIndex, float value) {
/*  124 */     nPushStyleVar(varIndex, value);
/*      */   }
/*      */ 
/*      */   
/*      */   private static native void nPushStyleVar(int paramInt, float paramFloat);
/*      */ 
/*      */   
/*      */   public static void pushStyleVar(int varIndex, ImVec2 value) {
/*  132 */     nPushStyleVar(varIndex, value.x, value.y);
/*      */   }
/*      */   
/*      */   public static void pushStyleVar(int varIndex, float valueX, float valueY) {
/*  136 */     nPushStyleVar(varIndex, valueX, valueY);
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   private static native void nPushStyleVar(int paramInt, float paramFloat1, float paramFloat2);
/*      */ 
/*      */   
/*      */   public static void pushStyleVar(int varIndex, ImVec4 value) {
/*  145 */     nPushStyleVar(varIndex, value.x, value.y, value.z, value.w);
/*      */   }
/*      */   
/*      */   public static void pushStyleVar(int varIndex, float valueX, float valueY, float valueZ, float valueW) {
/*  149 */     nPushStyleVar(varIndex, valueX, valueY, valueZ, valueW);
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   private static native void nPushStyleVar(int paramInt, float paramFloat1, float paramFloat2, float paramFloat3, float paramFloat4);
/*      */ 
/*      */   
/*      */   public static void popStyleVar() {
/*  158 */     nPopStyleVar();
/*      */   }
/*      */   
/*      */   public static void popStyleVar(int count) {
/*  162 */     nPopStyleVar(count);
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   private static native void nPopStyleVar();
/*      */ 
/*      */   
/*      */   private static native void nPopStyleVar(int paramInt);
/*      */ 
/*      */   
/*      */   public static void begin(String id) {
/*  174 */     nBegin(id);
/*      */   }
/*      */   
/*      */   public static void begin(String id, ImVec2 size) {
/*  178 */     nBegin(id, size.x, size.y);
/*      */   }
/*      */   
/*      */   public static void begin(String id, float sizeX, float sizeY) {
/*  182 */     nBegin(id, sizeX, sizeY);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private static native void nBegin(String paramString);
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private static native void nBegin(String paramString, float paramFloat1, float paramFloat2);
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static void end() {
/*  199 */     nEnd();
/*      */   }
/*      */ 
/*      */   
/*      */   private static native void nEnd();
/*      */ 
/*      */   
/*      */   public static void beginNode(long id) {
/*  207 */     nBeginNode(id);
/*      */   }
/*      */ 
/*      */   
/*      */   private static native void nBeginNode(long paramLong);
/*      */ 
/*      */   
/*      */   public static void beginPin(long id, int kind) {
/*  215 */     nBeginPin(id, kind);
/*      */   }
/*      */ 
/*      */   
/*      */   private static native void nBeginPin(long paramLong, int paramInt);
/*      */ 
/*      */   
/*      */   public static void pinRect(ImVec2 a, ImVec2 b) {
/*  223 */     nPinRect(a.x, a.y, b.x, b.y);
/*      */   }
/*      */   
/*      */   public static void pinRect(float aX, float aY, float bX, float bY) {
/*  227 */     nPinRect(aX, aY, bX, bY);
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   private static native void nPinRect(float paramFloat1, float paramFloat2, float paramFloat3, float paramFloat4);
/*      */ 
/*      */ 
/*      */   
/*      */   public static void pinPivotRect(ImVec2 a, ImVec2 b) {
/*  237 */     nPinPivotRect(a.x, a.y, b.x, b.y);
/*      */   }
/*      */   
/*      */   public static void pinPivotRect(float aX, float aY, float bX, float bY) {
/*  241 */     nPinPivotRect(aX, aY, bX, bY);
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   private static native void nPinPivotRect(float paramFloat1, float paramFloat2, float paramFloat3, float paramFloat4);
/*      */ 
/*      */ 
/*      */   
/*      */   public static void pinPivotSize(ImVec2 size) {
/*  251 */     nPinPivotSize(size.x, size.y);
/*      */   }
/*      */   
/*      */   public static void pinPivotSize(float sizeX, float sizeY) {
/*  255 */     nPinPivotSize(sizeX, sizeY);
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   private static native void nPinPivotSize(float paramFloat1, float paramFloat2);
/*      */ 
/*      */   
/*      */   public static void pinPivotScale(ImVec2 scale) {
/*  264 */     nPinPivotScale(scale.x, scale.y);
/*      */   }
/*      */   
/*      */   public static void pinPivotScale(float scaleX, float scaleY) {
/*  268 */     nPinPivotScale(scaleX, scaleY);
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   private static native void nPinPivotScale(float paramFloat1, float paramFloat2);
/*      */ 
/*      */   
/*      */   public static void pinPivotAlignment(ImVec2 alignment) {
/*  277 */     nPinPivotAlignment(alignment.x, alignment.y);
/*      */   }
/*      */   
/*      */   public static void pinPivotAlignment(float alignmentX, float alignmentY) {
/*  281 */     nPinPivotAlignment(alignmentX, alignmentY);
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   private static native void nPinPivotAlignment(float paramFloat1, float paramFloat2);
/*      */ 
/*      */   
/*      */   public static void endPin() {
/*  290 */     nEndPin();
/*      */   }
/*      */ 
/*      */   
/*      */   private static native void nEndPin();
/*      */ 
/*      */   
/*      */   public static void group(ImVec2 size) {
/*  298 */     nGroup(size.x, size.y);
/*      */   }
/*      */   
/*      */   public static void group(float sizeX, float sizeY) {
/*  302 */     nGroup(sizeX, sizeY);
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   private static native void nGroup(float paramFloat1, float paramFloat2);
/*      */ 
/*      */   
/*      */   public static void endNode() {
/*  311 */     nEndNode();
/*      */   }
/*      */ 
/*      */   
/*      */   private static native void nEndNode();
/*      */ 
/*      */   
/*      */   public static boolean beginGroupHint(long nodeId) {
/*  319 */     return nBeginGroupHint(nodeId);
/*      */   }
/*      */ 
/*      */   
/*      */   private static native boolean nBeginGroupHint(long paramLong);
/*      */ 
/*      */   
/*      */   public static ImVec2 getGroupMin() {
/*  327 */     ImVec2 dst = new ImVec2();
/*  328 */     nGetGroupMin(dst);
/*  329 */     return dst;
/*      */   }
/*      */   
/*      */   public static float getGroupMinX() {
/*  333 */     return nGetGroupMinX();
/*      */   }
/*      */   
/*      */   public static float getGroupMinY() {
/*  337 */     return nGetGroupMinY();
/*      */   }
/*      */   
/*      */   public static void getGroupMin(ImVec2 dst) {
/*  341 */     nGetGroupMin(dst);
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   private static native void nGetGroupMin(ImVec2 paramImVec2);
/*      */ 
/*      */ 
/*      */   
/*      */   private static native float nGetGroupMinX();
/*      */ 
/*      */   
/*      */   private static native float nGetGroupMinY();
/*      */ 
/*      */   
/*      */   public static ImVec2 getGroupMax() {
/*  357 */     ImVec2 dst = new ImVec2();
/*  358 */     nGetGroupMax(dst);
/*  359 */     return dst;
/*      */   }
/*      */   
/*      */   public static float getGroupMaxX() {
/*  363 */     return nGetGroupMaxX();
/*      */   }
/*      */   
/*      */   public static float getGroupMaxY() {
/*  367 */     return nGetGroupMaxY();
/*      */   }
/*      */   
/*      */   public static void getGroupMax(ImVec2 dst) {
/*  371 */     nGetGroupMax(dst);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  386 */   private static final ImDrawList _GETHINTFOREGROUNDDRAWLIST_1 = new ImDrawList(0L);
/*      */   
/*      */   public static ImDrawList getHintForegroundDrawList() {
/*  389 */     _GETHINTFOREGROUNDDRAWLIST_1.ptr = nGetHintForegroundDrawList();
/*  390 */     return _GETHINTFOREGROUNDDRAWLIST_1;
/*      */   }
/*      */   private static native void nGetGroupMax(ImVec2 paramImVec2);
/*      */   private static native float nGetGroupMaxX();
/*      */   
/*      */   private static native float nGetGroupMaxY();
/*      */   
/*  397 */   private static final ImDrawList _GETHINTBACKGROUNDDRAWLIST_1 = new ImDrawList(0L);
/*      */   private static native long nGetHintForegroundDrawList();
/*      */   public static ImDrawList getHintBackgroundDrawList() {
/*  400 */     _GETHINTBACKGROUNDDRAWLIST_1.ptr = nGetHintBackgroundDrawList();
/*  401 */     return _GETHINTBACKGROUNDDRAWLIST_1;
/*      */   }
/*      */ 
/*      */   
/*      */   private static native long nGetHintBackgroundDrawList();
/*      */ 
/*      */   
/*      */   public static void endGroupHint() {
/*  409 */     nEndGroupHint();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  416 */   private static final ImDrawList _GETNODEBACKGROUNDDRAWLIST_1040171299 = new ImDrawList(0L);
/*      */   private static native void nEndGroupHint();
/*      */   public static ImDrawList getNodeBackgroundDrawList(long nodeId) {
/*  419 */     _GETNODEBACKGROUNDDRAWLIST_1040171299.ptr = nGetNodeBackgroundDrawList(nodeId);
/*  420 */     return _GETNODEBACKGROUNDDRAWLIST_1040171299;
/*      */   }
/*      */ 
/*      */   
/*      */   private static native long nGetNodeBackgroundDrawList(long paramLong);
/*      */ 
/*      */   
/*      */   public static boolean link(long id, long startPinId, long endPinId) {
/*  428 */     return nLink(id, startPinId, endPinId);
/*      */   }
/*      */   
/*      */   public static boolean link(long id, long startPinId, long endPinId, ImVec4 color) {
/*  432 */     return nLink(id, startPinId, endPinId, color.x, color.y, color.z, color.w);
/*      */   }
/*      */   
/*      */   public static boolean link(long id, long startPinId, long endPinId, float colorX, float colorY, float colorZ, float colorW) {
/*  436 */     return nLink(id, startPinId, endPinId, colorX, colorY, colorZ, colorW);
/*      */   }
/*      */   
/*      */   public static boolean link(long id, long startPinId, long endPinId, ImVec4 color, float thickness) {
/*  440 */     return nLink(id, startPinId, endPinId, color.x, color.y, color.z, color.w, thickness);
/*      */   }
/*      */   
/*      */   public static boolean link(long id, long startPinId, long endPinId, float colorX, float colorY, float colorZ, float colorW, float thickness) {
/*  444 */     return nLink(id, startPinId, endPinId, colorX, colorY, colorZ, colorW, thickness);
/*      */   }
/*      */   
/*      */   public static boolean link(long id, long startPinId, long endPinId, float thickness) {
/*  448 */     return nLink(id, startPinId, endPinId, thickness);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private static native boolean nLink(long paramLong1, long paramLong2, long paramLong3);
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private static native boolean nLink(long paramLong1, long paramLong2, long paramLong3, float paramFloat1, float paramFloat2, float paramFloat3, float paramFloat4);
/*      */ 
/*      */ 
/*      */   
/*      */   private static native boolean nLink(long paramLong1, long paramLong2, long paramLong3, float paramFloat1, float paramFloat2, float paramFloat3, float paramFloat4, float paramFloat5);
/*      */ 
/*      */ 
/*      */   
/*      */   private static native boolean nLink(long paramLong1, long paramLong2, long paramLong3, float paramFloat);
/*      */ 
/*      */ 
/*      */   
/*      */   public static void flow(long linkId) {
/*  472 */     nFlow(linkId);
/*      */   }
/*      */   
/*      */   public static void flow(long linkId, int direction) {
/*  476 */     nFlow(linkId, direction);
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   private static native void nFlow(long paramLong);
/*      */ 
/*      */   
/*      */   private static native void nFlow(long paramLong, int paramInt);
/*      */ 
/*      */   
/*      */   public static boolean beginCreate() {
/*  488 */     return nBeginCreate();
/*      */   }
/*      */   
/*      */   public static boolean beginCreate(ImVec4 color) {
/*  492 */     return nBeginCreate(color.x, color.y, color.z, color.w);
/*      */   }
/*      */   
/*      */   public static boolean beginCreate(float colorX, float colorY, float colorZ, float colorW) {
/*  496 */     return nBeginCreate(colorX, colorY, colorZ, colorW);
/*      */   }
/*      */   
/*      */   public static boolean beginCreate(ImVec4 color, float thickness) {
/*  500 */     return nBeginCreate(color.x, color.y, color.z, color.w, thickness);
/*      */   }
/*      */   
/*      */   public static boolean beginCreate(float colorX, float colorY, float colorZ, float colorW, float thickness) {
/*  504 */     return nBeginCreate(colorX, colorY, colorZ, colorW, thickness);
/*      */   }
/*      */   
/*      */   public static boolean beginCreate(float thickness) {
/*  508 */     return nBeginCreate(thickness);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private static native boolean nBeginCreate();
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private static native boolean nBeginCreate(float paramFloat1, float paramFloat2, float paramFloat3, float paramFloat4);
/*      */ 
/*      */ 
/*      */   
/*      */   private static native boolean nBeginCreate(float paramFloat1, float paramFloat2, float paramFloat3, float paramFloat4, float paramFloat5);
/*      */ 
/*      */ 
/*      */   
/*      */   private static native boolean nBeginCreate(float paramFloat);
/*      */ 
/*      */ 
/*      */   
/*      */   public static boolean queryNewLink(ImLong startId, ImLong endId) {
/*  532 */     return nQueryNewLink((startId != null) ? startId.getData() : null, (endId != null) ? endId.getData() : null);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private static native boolean nQueryNewLink(long[] paramArrayOflong1, long[] paramArrayOflong2);
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static boolean queryNewLink(ImLong startId, ImLong endId, ImVec4 color) {
/*  545 */     return nQueryNewLink((startId != null) ? startId.getData() : null, (endId != null) ? endId.getData() : null, color.x, color.y, color.z, color.w);
/*      */   }
/*      */   
/*      */   public static boolean queryNewLink(ImLong startId, ImLong endId, float colorX, float colorY, float colorZ, float colorW) {
/*  549 */     return nQueryNewLink((startId != null) ? startId.getData() : null, (endId != null) ? endId.getData() : null, colorX, colorY, colorZ, colorW);
/*      */   }
/*      */   
/*      */   public static boolean queryNewLink(ImLong startId, ImLong endId, ImVec4 color, float thickness) {
/*  553 */     return nQueryNewLink((startId != null) ? startId.getData() : null, (endId != null) ? endId.getData() : null, color.x, color.y, color.z, color.w, thickness);
/*      */   }
/*      */   
/*      */   public static boolean queryNewLink(ImLong startId, ImLong endId, float colorX, float colorY, float colorZ, float colorW, float thickness) {
/*  557 */     return nQueryNewLink((startId != null) ? startId.getData() : null, (endId != null) ? endId.getData() : null, colorX, colorY, colorZ, colorW, thickness);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private static native boolean nQueryNewLink(long[] paramArrayOflong1, long[] paramArrayOflong2, float paramFloat1, float paramFloat2, float paramFloat3, float paramFloat4);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private static native boolean nQueryNewLink(long[] paramArrayOflong1, long[] paramArrayOflong2, float paramFloat1, float paramFloat2, float paramFloat3, float paramFloat4, float paramFloat5);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static boolean queryNewNode(ImLong pinId) {
/*  581 */     return nQueryNewNode((pinId != null) ? pinId.getData() : null);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private static native boolean nQueryNewNode(long[] paramArrayOflong);
/*      */ 
/*      */ 
/*      */   
/*      */   public static boolean queryNewNode(ImLong pinId, ImVec4 color) {
/*  592 */     return nQueryNewNode((pinId != null) ? pinId.getData() : null, color.x, color.y, color.z, color.w);
/*      */   }
/*      */   
/*      */   public static boolean queryNewNode(ImLong pinId, float colorX, float colorY, float colorZ, float colorW) {
/*  596 */     return nQueryNewNode((pinId != null) ? pinId.getData() : null, colorX, colorY, colorZ, colorW);
/*      */   }
/*      */   
/*      */   public static boolean queryNewNode(ImLong pinId, ImVec4 color, float thickness) {
/*  600 */     return nQueryNewNode((pinId != null) ? pinId.getData() : null, color.x, color.y, color.z, color.w, thickness);
/*      */   }
/*      */   
/*      */   public static boolean queryNewNode(ImLong pinId, float colorX, float colorY, float colorZ, float colorW, float thickness) {
/*  604 */     return nQueryNewNode((pinId != null) ? pinId.getData() : null, colorX, colorY, colorZ, colorW, thickness);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private static native boolean nQueryNewNode(long[] paramArrayOflong, float paramFloat1, float paramFloat2, float paramFloat3, float paramFloat4);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private static native boolean nQueryNewNode(long[] paramArrayOflong, float paramFloat1, float paramFloat2, float paramFloat3, float paramFloat4, float paramFloat5);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static boolean acceptNewItem() {
/*  624 */     return nAcceptNewItem();
/*      */   }
/*      */ 
/*      */   
/*      */   private static native boolean nAcceptNewItem();
/*      */ 
/*      */   
/*      */   public static boolean acceptNewItem(ImVec4 color) {
/*  632 */     return nAcceptNewItem(color.x, color.y, color.z, color.w);
/*      */   }
/*      */   
/*      */   public static boolean acceptNewItem(float colorX, float colorY, float colorZ, float colorW) {
/*  636 */     return nAcceptNewItem(colorX, colorY, colorZ, colorW);
/*      */   }
/*      */   
/*      */   public static boolean acceptNewItem(ImVec4 color, float thickness) {
/*  640 */     return nAcceptNewItem(color.x, color.y, color.z, color.w, thickness);
/*      */   }
/*      */   
/*      */   public static boolean acceptNewItem(float colorX, float colorY, float colorZ, float colorW, float thickness) {
/*  644 */     return nAcceptNewItem(colorX, colorY, colorZ, colorW, thickness);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private static native boolean nAcceptNewItem(float paramFloat1, float paramFloat2, float paramFloat3, float paramFloat4);
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private static native boolean nAcceptNewItem(float paramFloat1, float paramFloat2, float paramFloat3, float paramFloat4, float paramFloat5);
/*      */ 
/*      */ 
/*      */   
/*      */   public static void rejectNewItem() {
/*  660 */     nRejectNewItem();
/*      */   }
/*      */ 
/*      */   
/*      */   private static native void nRejectNewItem();
/*      */ 
/*      */   
/*      */   public static void rejectNewItem(ImVec4 color) {
/*  668 */     nRejectNewItem(color.x, color.y, color.z, color.w);
/*      */   }
/*      */   
/*      */   public static void rejectNewItem(float colorX, float colorY, float colorZ, float colorW) {
/*  672 */     nRejectNewItem(colorX, colorY, colorZ, colorW);
/*      */   }
/*      */   
/*      */   public static void rejectNewItem(ImVec4 color, float thickness) {
/*  676 */     nRejectNewItem(color.x, color.y, color.z, color.w, thickness);
/*      */   }
/*      */   
/*      */   public static void rejectNewItem(float colorX, float colorY, float colorZ, float colorW, float thickness) {
/*  680 */     nRejectNewItem(colorX, colorY, colorZ, colorW, thickness);
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   private static native void nRejectNewItem(float paramFloat1, float paramFloat2, float paramFloat3, float paramFloat4);
/*      */ 
/*      */ 
/*      */   
/*      */   private static native void nRejectNewItem(float paramFloat1, float paramFloat2, float paramFloat3, float paramFloat4, float paramFloat5);
/*      */ 
/*      */ 
/*      */   
/*      */   public static void endCreate() {
/*  694 */     nEndCreate();
/*      */   }
/*      */ 
/*      */   
/*      */   private static native void nEndCreate();
/*      */ 
/*      */   
/*      */   public static boolean beginDelete() {
/*  702 */     return nBeginDelete();
/*      */   }
/*      */ 
/*      */   
/*      */   private static native boolean nBeginDelete();
/*      */ 
/*      */   
/*      */   public static boolean queryDeletedLink(ImLong linkId) {
/*  710 */     return nQueryDeletedLink((linkId != null) ? linkId.getData() : null);
/*      */   }
/*      */   
/*      */   public static boolean queryDeletedLink(ImLong linkId, ImLong startId) {
/*  714 */     return nQueryDeletedLink((linkId != null) ? linkId.getData() : null, (startId != null) ? startId.getData() : null);
/*      */   }
/*      */   
/*      */   public static boolean queryDeletedLink(ImLong linkId, ImLong startId, ImLong endId) {
/*  718 */     return nQueryDeletedLink((linkId != null) ? linkId.getData() : null, (startId != null) ? startId.getData() : null, (endId != null) ? endId.getData() : null);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private static native boolean nQueryDeletedLink(long[] paramArrayOflong);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private static native boolean nQueryDeletedLink(long[] paramArrayOflong1, long[] paramArrayOflong2);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private static native boolean nQueryDeletedLink(long[] paramArrayOflong1, long[] paramArrayOflong2, long[] paramArrayOflong3);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static boolean queryDeletedNode(ImLong nodeId) {
/*  749 */     return nQueryDeletedNode((nodeId != null) ? nodeId.getData() : null);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private static native boolean nQueryDeletedNode(long[] paramArrayOflong);
/*      */ 
/*      */ 
/*      */   
/*      */   public static boolean acceptDeletedItem() {
/*  760 */     return nAcceptDeletedItem();
/*      */   }
/*      */   
/*      */   public static boolean acceptDeletedItem(boolean deleteDependencies) {
/*  764 */     return nAcceptDeletedItem(deleteDependencies);
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   private static native boolean nAcceptDeletedItem();
/*      */ 
/*      */   
/*      */   private static native boolean nAcceptDeletedItem(boolean paramBoolean);
/*      */ 
/*      */   
/*      */   public static void rejectDeletedItem() {
/*  776 */     nRejectDeletedItem();
/*      */   }
/*      */ 
/*      */   
/*      */   private static native void nRejectDeletedItem();
/*      */ 
/*      */   
/*      */   public static void endDelete() {
/*  784 */     nEndDelete();
/*      */   }
/*      */ 
/*      */   
/*      */   private static native void nEndDelete();
/*      */ 
/*      */   
/*      */   public static void setNodePosition(long nodeId, ImVec2 editorPosition) {
/*  792 */     nSetNodePosition(nodeId, editorPosition.x, editorPosition.y);
/*      */   }
/*      */   
/*      */   public static void setNodePosition(long nodeId, float editorPositionX, float editorPositionY) {
/*  796 */     nSetNodePosition(nodeId, editorPositionX, editorPositionY);
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   private static native void nSetNodePosition(long paramLong, float paramFloat1, float paramFloat2);
/*      */ 
/*      */   
/*      */   public static void setGroupSize(long nodeId, ImVec2 size) {
/*  805 */     nSetGroupSize(nodeId, size.x, size.y);
/*      */   }
/*      */   
/*      */   public static void setGroupSize(long nodeId, float sizeX, float sizeY) {
/*  809 */     nSetGroupSize(nodeId, sizeX, sizeY);
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   private static native void nSetGroupSize(long paramLong, float paramFloat1, float paramFloat2);
/*      */ 
/*      */   
/*      */   public static ImVec2 getNodePosition(long nodeId) {
/*  818 */     ImVec2 dst = new ImVec2();
/*  819 */     nGetNodePosition(dst, nodeId);
/*  820 */     return dst;
/*      */   }
/*      */   
/*      */   public static float getNodePositionX(long nodeId) {
/*  824 */     return nGetNodePositionX(nodeId);
/*      */   }
/*      */   
/*      */   public static float getNodePositionY(long nodeId) {
/*  828 */     return nGetNodePositionY(nodeId);
/*      */   }
/*      */   
/*      */   public static void getNodePosition(ImVec2 dst, long nodeId) {
/*  832 */     nGetNodePosition(dst, nodeId);
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   private static native void nGetNodePosition(ImVec2 paramImVec2, long paramLong);
/*      */ 
/*      */ 
/*      */   
/*      */   private static native float nGetNodePositionX(long paramLong);
/*      */ 
/*      */   
/*      */   private static native float nGetNodePositionY(long paramLong);
/*      */ 
/*      */   
/*      */   public static ImVec2 getNodeSize(long nodeId) {
/*  848 */     ImVec2 dst = new ImVec2();
/*  849 */     nGetNodeSize(dst, nodeId);
/*  850 */     return dst;
/*      */   }
/*      */   
/*      */   public static float getNodeSizeX(long nodeId) {
/*  854 */     return nGetNodeSizeX(nodeId);
/*      */   }
/*      */   
/*      */   public static float getNodeSizeY(long nodeId) {
/*  858 */     return nGetNodeSizeY(nodeId);
/*      */   }
/*      */   
/*      */   public static void getNodeSize(ImVec2 dst, long nodeId) {
/*  862 */     nGetNodeSize(dst, nodeId);
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   private static native void nGetNodeSize(ImVec2 paramImVec2, long paramLong);
/*      */ 
/*      */ 
/*      */   
/*      */   private static native float nGetNodeSizeX(long paramLong);
/*      */ 
/*      */   
/*      */   private static native float nGetNodeSizeY(long paramLong);
/*      */ 
/*      */   
/*      */   public static void centerNodeOnScreen(long nodeId) {
/*  878 */     nCenterNodeOnScreen(nodeId);
/*      */   }
/*      */ 
/*      */   
/*      */   private static native void nCenterNodeOnScreen(long paramLong);
/*      */ 
/*      */   
/*      */   public static void setNodeZPosition(long nodeId, float z) {
/*  886 */     nSetNodeZPosition(nodeId, z);
/*      */   }
/*      */ 
/*      */   
/*      */   private static native void nSetNodeZPosition(long paramLong, float paramFloat);
/*      */ 
/*      */   
/*      */   public static float getNodeZPosition(long nodeId) {
/*  894 */     return nGetNodeZPosition(nodeId);
/*      */   }
/*      */ 
/*      */   
/*      */   private static native float nGetNodeZPosition(long paramLong);
/*      */ 
/*      */   
/*      */   public static void restoreNodeState(long nodeId) {
/*  902 */     nRestoreNodeState(nodeId);
/*      */   }
/*      */ 
/*      */   
/*      */   private static native void nRestoreNodeState(long paramLong);
/*      */ 
/*      */   
/*      */   public static void suspend() {
/*  910 */     nSuspend();
/*      */   }
/*      */ 
/*      */   
/*      */   private static native void nSuspend();
/*      */ 
/*      */   
/*      */   public static void resume() {
/*  918 */     nResume();
/*      */   }
/*      */ 
/*      */   
/*      */   private static native void nResume();
/*      */ 
/*      */   
/*      */   public static boolean isSuspended() {
/*  926 */     return nIsSuspended();
/*      */   }
/*      */ 
/*      */   
/*      */   private static native boolean nIsSuspended();
/*      */ 
/*      */   
/*      */   public static boolean isActive() {
/*  934 */     return nIsActive();
/*      */   }
/*      */ 
/*      */   
/*      */   private static native boolean nIsActive();
/*      */ 
/*      */   
/*      */   public static boolean hasSelectionChanged() {
/*  942 */     return nHasSelectionChanged();
/*      */   }
/*      */ 
/*      */   
/*      */   private static native boolean nHasSelectionChanged();
/*      */ 
/*      */   
/*      */   public static int getSelectedObjectCount() {
/*  950 */     return nGetSelectedObjectCount();
/*      */   }
/*      */ 
/*      */   
/*      */   private static native int nGetSelectedObjectCount();
/*      */ 
/*      */   
/*      */   public static int getSelectedNodes(long[] nodes, int size) {
/*  958 */     return nGetSelectedNodes(nodes, size);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private static native int nGetSelectedNodes(long[] paramArrayOflong, int paramInt);
/*      */ 
/*      */ 
/*      */   
/*      */   public static int getSelectedLinks(long[] links, int size) {
/*  969 */     return nGetSelectedLinks(links, size);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private static native int nGetSelectedLinks(long[] paramArrayOflong, int paramInt);
/*      */ 
/*      */ 
/*      */   
/*      */   public static boolean isNodeSelected(long nodeId) {
/*  980 */     return nIsNodeSelected(nodeId);
/*      */   }
/*      */ 
/*      */   
/*      */   private static native boolean nIsNodeSelected(long paramLong);
/*      */ 
/*      */   
/*      */   public static boolean isLinkSelected(long linkId) {
/*  988 */     return nIsLinkSelected(linkId);
/*      */   }
/*      */ 
/*      */   
/*      */   private static native boolean nIsLinkSelected(long paramLong);
/*      */ 
/*      */   
/*      */   public static void clearSelection() {
/*  996 */     nClearSelection();
/*      */   }
/*      */ 
/*      */   
/*      */   private static native void nClearSelection();
/*      */ 
/*      */   
/*      */   public static void selectNode(long nodeId) {
/* 1004 */     nSelectNode(nodeId);
/*      */   }
/*      */   
/*      */   public static void selectNode(long nodeId, boolean append) {
/* 1008 */     nSelectNode(nodeId, append);
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   private static native void nSelectNode(long paramLong);
/*      */ 
/*      */   
/*      */   private static native void nSelectNode(long paramLong, boolean paramBoolean);
/*      */ 
/*      */   
/*      */   public static void selectLink(long linkId) {
/* 1020 */     nSelectLink(linkId);
/*      */   }
/*      */   
/*      */   public static void selectLink(long linkId, boolean append) {
/* 1024 */     nSelectLink(linkId, append);
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   private static native void nSelectLink(long paramLong);
/*      */ 
/*      */   
/*      */   private static native void nSelectLink(long paramLong, boolean paramBoolean);
/*      */ 
/*      */   
/*      */   public static void deselectNode(long nodeId) {
/* 1036 */     nDeselectNode(nodeId);
/*      */   }
/*      */ 
/*      */   
/*      */   private static native void nDeselectNode(long paramLong);
/*      */ 
/*      */   
/*      */   public static void deselectLink(long linkId) {
/* 1044 */     nDeselectLink(linkId);
/*      */   }
/*      */ 
/*      */   
/*      */   private static native void nDeselectLink(long paramLong);
/*      */ 
/*      */   
/*      */   public static boolean deleteNode(long nodeId) {
/* 1052 */     return nDeleteNode(nodeId);
/*      */   }
/*      */ 
/*      */   
/*      */   private static native boolean nDeleteNode(long paramLong);
/*      */ 
/*      */   
/*      */   public static boolean deleteLink(long linkId) {
/* 1060 */     return nDeleteLink(linkId);
/*      */   }
/*      */ 
/*      */   
/*      */   private static native boolean nDeleteLink(long paramLong);
/*      */ 
/*      */   
/*      */   public static boolean hasAnyLinksNode(long nodeId) {
/* 1068 */     return nHasAnyLinksNode(nodeId);
/*      */   }
/*      */ 
/*      */   
/*      */   private static native boolean nHasAnyLinksNode(long paramLong);
/*      */ 
/*      */   
/*      */   public static boolean hasAnyLinksPin(long pinId) {
/* 1076 */     return nHasAnyLinksPin(pinId);
/*      */   }
/*      */ 
/*      */   
/*      */   private static native boolean nHasAnyLinksPin(long paramLong);
/*      */ 
/*      */   
/*      */   public static int breakLinksNode(long nodeId) {
/* 1084 */     return nBreakLinksNode(nodeId);
/*      */   }
/*      */ 
/*      */   
/*      */   private static native int nBreakLinksNode(long paramLong);
/*      */ 
/*      */   
/*      */   public static int breakLinksPin(long pinId) {
/* 1092 */     return nBreakLinksPin(pinId);
/*      */   }
/*      */ 
/*      */   
/*      */   private static native int nBreakLinksPin(long paramLong);
/*      */ 
/*      */   
/*      */   public static void navigateToContent() {
/* 1100 */     nNavigateToContent();
/*      */   }
/*      */   
/*      */   public static void navigateToContent(float duration) {
/* 1104 */     nNavigateToContent(duration);
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   private static native void nNavigateToContent();
/*      */ 
/*      */   
/*      */   private static native void nNavigateToContent(float paramFloat);
/*      */ 
/*      */   
/*      */   public static void navigateToSelection() {
/* 1116 */     nNavigateToSelection();
/*      */   }
/*      */   
/*      */   public static void navigateToSelection(boolean zoomIn) {
/* 1120 */     nNavigateToSelection(zoomIn);
/*      */   }
/*      */   
/*      */   public static void navigateToSelection(boolean zoomIn, float duration) {
/* 1124 */     nNavigateToSelection(zoomIn, duration);
/*      */   }
/*      */   
/*      */   public static void navigateToSelection(float duration) {
/* 1128 */     nNavigateToSelection(duration);
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   private static native void nNavigateToSelection();
/*      */ 
/*      */ 
/*      */   
/*      */   private static native void nNavigateToSelection(boolean paramBoolean);
/*      */ 
/*      */ 
/*      */   
/*      */   private static native void nNavigateToSelection(boolean paramBoolean, float paramFloat);
/*      */ 
/*      */   
/*      */   private static native void nNavigateToSelection(float paramFloat);
/*      */ 
/*      */   
/*      */   public static boolean showNodeContextMenu(ImLong nodeId) {
/* 1148 */     return nShowNodeContextMenu((nodeId != null) ? nodeId.getData() : null);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private static native boolean nShowNodeContextMenu(long[] paramArrayOflong);
/*      */ 
/*      */ 
/*      */   
/*      */   public static boolean showPinContextMenu(ImLong pinId) {
/* 1159 */     return nShowPinContextMenu((pinId != null) ? pinId.getData() : null);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private static native boolean nShowPinContextMenu(long[] paramArrayOflong);
/*      */ 
/*      */ 
/*      */   
/*      */   public static boolean showLinkContextMenu(ImLong linkId) {
/* 1170 */     return nShowLinkContextMenu((linkId != null) ? linkId.getData() : null);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private static native boolean nShowLinkContextMenu(long[] paramArrayOflong);
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static native long getNodeWithContextMenu();
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static native long getPinWithContextMenu();
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static native long getLinkWithContextMenu();
/*      */ 
/*      */ 
/*      */   
/*      */   public static boolean showBackgroundContextMenu() {
/* 1196 */     return nShowBackgroundContextMenu();
/*      */   }
/*      */ 
/*      */   
/*      */   private static native boolean nShowBackgroundContextMenu();
/*      */ 
/*      */   
/*      */   public static void enableShortcuts(boolean enable) {
/* 1204 */     nEnableShortcuts(enable);
/*      */   }
/*      */ 
/*      */   
/*      */   private static native void nEnableShortcuts(boolean paramBoolean);
/*      */ 
/*      */   
/*      */   public static boolean areShortcutsEnabled() {
/* 1212 */     return nAreShortcutsEnabled();
/*      */   }
/*      */ 
/*      */   
/*      */   private static native boolean nAreShortcutsEnabled();
/*      */ 
/*      */   
/*      */   public static boolean beginShortcut() {
/* 1220 */     return nBeginShortcut();
/*      */   }
/*      */ 
/*      */   
/*      */   private static native boolean nBeginShortcut();
/*      */ 
/*      */   
/*      */   public static boolean acceptCut() {
/* 1228 */     return nAcceptCut();
/*      */   }
/*      */ 
/*      */   
/*      */   private static native boolean nAcceptCut();
/*      */ 
/*      */   
/*      */   public static boolean acceptCopy() {
/* 1236 */     return nAcceptCopy();
/*      */   }
/*      */ 
/*      */   
/*      */   private static native boolean nAcceptCopy();
/*      */ 
/*      */   
/*      */   public static boolean acceptPaste() {
/* 1244 */     return nAcceptPaste();
/*      */   }
/*      */ 
/*      */   
/*      */   private static native boolean nAcceptPaste();
/*      */ 
/*      */   
/*      */   public static boolean acceptDuplicate() {
/* 1252 */     return nAcceptDuplicate();
/*      */   }
/*      */ 
/*      */   
/*      */   private static native boolean nAcceptDuplicate();
/*      */ 
/*      */   
/*      */   public static boolean acceptCreateNode() {
/* 1260 */     return nAcceptCreateNode();
/*      */   }
/*      */ 
/*      */   
/*      */   private static native boolean nAcceptCreateNode();
/*      */ 
/*      */   
/*      */   public static int getActionContextSize() {
/* 1268 */     return nGetActionContextSize();
/*      */   }
/*      */ 
/*      */   
/*      */   private static native int nGetActionContextSize();
/*      */ 
/*      */   
/*      */   public static int getActionContextNodes(long[] nodes, int size) {
/* 1276 */     return nGetActionContextNodes(nodes, size);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private static native int nGetActionContextNodes(long[] paramArrayOflong, int paramInt);
/*      */ 
/*      */ 
/*      */   
/*      */   public static int getActionContextLinks(long[] links, int size) {
/* 1287 */     return nGetActionContextLinks(links, size);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private static native int nGetActionContextLinks(long[] paramArrayOflong, int paramInt);
/*      */ 
/*      */ 
/*      */   
/*      */   public static void endShortcut() {
/* 1298 */     nEndShortcut();
/*      */   }
/*      */ 
/*      */   
/*      */   private static native void nEndShortcut();
/*      */ 
/*      */   
/*      */   public static float getCurrentZoom() {
/* 1306 */     return nGetCurrentZoom();
/*      */   }
/*      */ 
/*      */   
/*      */   private static native float nGetCurrentZoom();
/*      */ 
/*      */   
/*      */   public static long getHoveredNode() {
/* 1314 */     return nGetHoveredNode();
/*      */   }
/*      */ 
/*      */   
/*      */   private static native long nGetHoveredNode();
/*      */ 
/*      */   
/*      */   public static long getHoveredPin() {
/* 1322 */     return nGetHoveredPin();
/*      */   }
/*      */ 
/*      */   
/*      */   private static native long nGetHoveredPin();
/*      */ 
/*      */   
/*      */   public static long getHoveredLink() {
/* 1330 */     return nGetHoveredLink();
/*      */   }
/*      */ 
/*      */   
/*      */   private static native long nGetHoveredLink();
/*      */ 
/*      */   
/*      */   public static long getDoubleClickedNode() {
/* 1338 */     return nGetDoubleClickedNode();
/*      */   }
/*      */ 
/*      */   
/*      */   private static native long nGetDoubleClickedNode();
/*      */ 
/*      */   
/*      */   public static long getDoubleClickedPin() {
/* 1346 */     return nGetDoubleClickedPin();
/*      */   }
/*      */ 
/*      */   
/*      */   private static native long nGetDoubleClickedPin();
/*      */ 
/*      */   
/*      */   public static long getDoubleClickedLink() {
/* 1354 */     return nGetDoubleClickedLink();
/*      */   }
/*      */ 
/*      */   
/*      */   private static native long nGetDoubleClickedLink();
/*      */ 
/*      */   
/*      */   public static boolean isBackgroundClicked() {
/* 1362 */     return nIsBackgroundClicked();
/*      */   }
/*      */ 
/*      */   
/*      */   private static native boolean nIsBackgroundClicked();
/*      */ 
/*      */   
/*      */   public static boolean isBackgroundDoubleClicked() {
/* 1370 */     return nIsBackgroundDoubleClicked();
/*      */   }
/*      */ 
/*      */   
/*      */   private static native boolean nIsBackgroundDoubleClicked();
/*      */ 
/*      */   
/*      */   public static boolean getLinkPins(long linkId, ImLong startPinId, ImLong endPinId) {
/* 1378 */     return nGetLinkPins(linkId, (startPinId != null) ? startPinId.getData() : null, (endPinId != null) ? endPinId.getData() : null);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private static native boolean nGetLinkPins(long paramLong, long[] paramArrayOflong1, long[] paramArrayOflong2);
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static boolean pinHadAnyLinks(long pinId) {
/* 1391 */     return nPinHadAnyLinks(pinId);
/*      */   }
/*      */ 
/*      */   
/*      */   private static native boolean nPinHadAnyLinks(long paramLong);
/*      */ 
/*      */   
/*      */   public static ImVec2 getScreenSize() {
/* 1399 */     ImVec2 dst = new ImVec2();
/* 1400 */     nGetScreenSize(dst);
/* 1401 */     return dst;
/*      */   }
/*      */   
/*      */   public static float getScreenSizeX() {
/* 1405 */     return nGetScreenSizeX();
/*      */   }
/*      */   
/*      */   public static float getScreenSizeY() {
/* 1409 */     return nGetScreenSizeY();
/*      */   }
/*      */   
/*      */   public static void getScreenSize(ImVec2 dst) {
/* 1413 */     nGetScreenSize(dst);
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   private static native void nGetScreenSize(ImVec2 paramImVec2);
/*      */ 
/*      */ 
/*      */   
/*      */   private static native float nGetScreenSizeX();
/*      */ 
/*      */   
/*      */   private static native float nGetScreenSizeY();
/*      */ 
/*      */   
/*      */   public static ImVec2 screenToCanvas(ImVec2 pos) {
/* 1429 */     ImVec2 dst = new ImVec2();
/* 1430 */     nScreenToCanvas(dst, pos.x, pos.y);
/* 1431 */     return dst;
/*      */   }
/*      */   
/*      */   public static ImVec2 screenToCanvas(float posX, float posY) {
/* 1435 */     ImVec2 dst = new ImVec2();
/* 1436 */     nScreenToCanvas(dst, posX, posY);
/* 1437 */     return dst;
/*      */   }
/*      */   
/*      */   public static float screenToCanvasX(ImVec2 pos) {
/* 1441 */     return nScreenToCanvasX(pos.x, pos.y);
/*      */   }
/*      */   
/*      */   public static float screenToCanvasY(ImVec2 pos) {
/* 1445 */     return nScreenToCanvasY(pos.x, pos.y);
/*      */   }
/*      */   
/*      */   public static void screenToCanvas(ImVec2 dst, ImVec2 pos) {
/* 1449 */     nScreenToCanvas(dst, pos.x, pos.y);
/*      */   }
/*      */   
/*      */   public static void screenToCanvas(ImVec2 dst, float posX, float posY) {
/* 1453 */     nScreenToCanvas(dst, posX, posY);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private static native void nScreenToCanvas(ImVec2 paramImVec2, float paramFloat1, float paramFloat2);
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private static native float nScreenToCanvasX(float paramFloat1, float paramFloat2);
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private static native float nScreenToCanvasY(float paramFloat1, float paramFloat2);
/*      */ 
/*      */ 
/*      */   
/*      */   public static ImVec2 canvasToScreen(ImVec2 pos) {
/* 1474 */     ImVec2 dst = new ImVec2();
/* 1475 */     nCanvasToScreen(dst, pos.x, pos.y);
/* 1476 */     return dst;
/*      */   }
/*      */   
/*      */   public static ImVec2 canvasToScreen(float posX, float posY) {
/* 1480 */     ImVec2 dst = new ImVec2();
/* 1481 */     nCanvasToScreen(dst, posX, posY);
/* 1482 */     return dst;
/*      */   }
/*      */   
/*      */   public static float canvasToScreenX(ImVec2 pos) {
/* 1486 */     return nCanvasToScreenX(pos.x, pos.y);
/*      */   }
/*      */   
/*      */   public static float canvasToScreenY(ImVec2 pos) {
/* 1490 */     return nCanvasToScreenY(pos.x, pos.y);
/*      */   }
/*      */   
/*      */   public static void canvasToScreen(ImVec2 dst, ImVec2 pos) {
/* 1494 */     nCanvasToScreen(dst, pos.x, pos.y);
/*      */   }
/*      */   
/*      */   public static void canvasToScreen(ImVec2 dst, float posX, float posY) {
/* 1498 */     nCanvasToScreen(dst, posX, posY);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private static native void nCanvasToScreen(ImVec2 paramImVec2, float paramFloat1, float paramFloat2);
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private static native float nCanvasToScreenX(float paramFloat1, float paramFloat2);
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private static native float nCanvasToScreenY(float paramFloat1, float paramFloat2);
/*      */ 
/*      */ 
/*      */   
/*      */   public static int getNodeCount() {
/* 1519 */     return nGetNodeCount();
/*      */   }
/*      */ 
/*      */   
/*      */   private static native int nGetNodeCount();
/*      */ 
/*      */   
/*      */   public static int getOrderedNodeIds(long[] nodes, int size) {
/* 1527 */     return nGetOrderedNodeIds(nodes, size);
/*      */   }
/*      */   
/*      */   private static native int nGetOrderedNodeIds(long[] paramArrayOflong, int paramInt);
/*      */ }


/* Location:              C:\Users\rapha\Downloads\aurora.jar!\META-INF\jars\imgui-java-binding-1.90.0.jar!\imgui\extension\nodeditor\NodeEditor.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */