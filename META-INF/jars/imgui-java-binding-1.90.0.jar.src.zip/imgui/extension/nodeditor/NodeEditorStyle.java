/*     */ package imgui.extension.nodeditor;
/*     */ 
/*     */ import imgui.ImVec2;
/*     */ import imgui.ImVec4;
/*     */ import imgui.binding.ImGuiStruct;
/*     */ 
/*     */ public final class NodeEditorStyle extends ImGuiStruct {
/*     */   public NodeEditorStyle(long ptr) {
/*   9 */     super(ptr);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ImVec4 getNodePadding() {
/*  18 */     ImVec4 dst = new ImVec4();
/*  19 */     nGetNodePadding(dst);
/*  20 */     return dst;
/*     */   }
/*     */   
/*     */   public float getNodePaddingX() {
/*  24 */     return nGetNodePaddingX();
/*     */   }
/*     */   
/*     */   public float getNodePaddingY() {
/*  28 */     return nGetNodePaddingY();
/*     */   }
/*     */   
/*     */   public float getNodePaddingZ() {
/*  32 */     return nGetNodePaddingZ();
/*     */   }
/*     */   
/*     */   public float getNodePaddingW() {
/*  36 */     return nGetNodePaddingW();
/*     */   }
/*     */   
/*     */   public void getNodePadding(ImVec4 dst) {
/*  40 */     nGetNodePadding(dst);
/*     */   }
/*     */   
/*     */   public void setNodePadding(ImVec4 value) {
/*  44 */     nSetNodePadding(value.x, value.y, value.z, value.w);
/*     */   }
/*     */   
/*     */   public void setNodePadding(float valueX, float valueY, float valueZ, float valueW) {
/*  48 */     nSetNodePadding(valueX, valueY, valueZ, valueW);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private native void nGetNodePadding(ImVec4 paramImVec4);
/*     */ 
/*     */ 
/*     */   
/*     */   private native float nGetNodePaddingX();
/*     */ 
/*     */ 
/*     */   
/*     */   private native float nGetNodePaddingY();
/*     */ 
/*     */ 
/*     */   
/*     */   private native float nGetNodePaddingZ();
/*     */ 
/*     */ 
/*     */   
/*     */   private native float nGetNodePaddingW();
/*     */ 
/*     */ 
/*     */   
/*     */   private native void nSetNodePadding(float paramFloat1, float paramFloat2, float paramFloat3, float paramFloat4);
/*     */ 
/*     */   
/*     */   public float getNodeRounding() {
/*  77 */     return nGetNodeRounding();
/*     */   }
/*     */   
/*     */   public void setNodeRounding(float value) {
/*  81 */     nSetNodeRounding(value);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private native float nGetNodeRounding();
/*     */ 
/*     */   
/*     */   private native void nSetNodeRounding(float paramFloat);
/*     */ 
/*     */   
/*     */   public float getNodeBorderWidth() {
/*  93 */     return nGetNodeBorderWidth();
/*     */   }
/*     */   
/*     */   public void setNodeBorderWidth(float value) {
/*  97 */     nSetNodeBorderWidth(value);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private native float nGetNodeBorderWidth();
/*     */ 
/*     */   
/*     */   private native void nSetNodeBorderWidth(float paramFloat);
/*     */ 
/*     */   
/*     */   public float getHoveredNodeBorderWidth() {
/* 109 */     return nGetHoveredNodeBorderWidth();
/*     */   }
/*     */   
/*     */   public void setHoveredNodeBorderWidth(float value) {
/* 113 */     nSetHoveredNodeBorderWidth(value);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private native float nGetHoveredNodeBorderWidth();
/*     */ 
/*     */   
/*     */   private native void nSetHoveredNodeBorderWidth(float paramFloat);
/*     */ 
/*     */   
/*     */   public float getHoverNodeBorderOffset() {
/* 125 */     return nGetHoverNodeBorderOffset();
/*     */   }
/*     */   
/*     */   public void setHoverNodeBorderOffset(float value) {
/* 129 */     nSetHoverNodeBorderOffset(value);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private native float nGetHoverNodeBorderOffset();
/*     */ 
/*     */   
/*     */   private native void nSetHoverNodeBorderOffset(float paramFloat);
/*     */ 
/*     */   
/*     */   public float getSelectedNodeBorderWidth() {
/* 141 */     return nGetSelectedNodeBorderWidth();
/*     */   }
/*     */   
/*     */   public void setSelectedNodeBorderWidth(float value) {
/* 145 */     nSetSelectedNodeBorderWidth(value);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private native float nGetSelectedNodeBorderWidth();
/*     */ 
/*     */   
/*     */   private native void nSetSelectedNodeBorderWidth(float paramFloat);
/*     */ 
/*     */   
/*     */   public float getSelectedNodeBorderOffset() {
/* 157 */     return nGetSelectedNodeBorderOffset();
/*     */   }
/*     */   
/*     */   public void setSelectedNodeBorderOffset(float value) {
/* 161 */     nSetSelectedNodeBorderOffset(value);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private native float nGetSelectedNodeBorderOffset();
/*     */ 
/*     */   
/*     */   private native void nSetSelectedNodeBorderOffset(float paramFloat);
/*     */ 
/*     */   
/*     */   public float getPinRounding() {
/* 173 */     return nGetPinRounding();
/*     */   }
/*     */   
/*     */   public void setPinRounding(float value) {
/* 177 */     nSetPinRounding(value);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private native float nGetPinRounding();
/*     */ 
/*     */   
/*     */   private native void nSetPinRounding(float paramFloat);
/*     */ 
/*     */   
/*     */   public float getPinBorderWidth() {
/* 189 */     return nGetPinBorderWidth();
/*     */   }
/*     */   
/*     */   public void setPinBorderWidth(float value) {
/* 193 */     nSetPinBorderWidth(value);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private native float nGetPinBorderWidth();
/*     */ 
/*     */   
/*     */   private native void nSetPinBorderWidth(float paramFloat);
/*     */ 
/*     */   
/*     */   public float getLinkStrength() {
/* 205 */     return nGetLinkStrength();
/*     */   }
/*     */   
/*     */   public void setLinkStrength(float value) {
/* 209 */     nSetLinkStrength(value);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private native float nGetLinkStrength();
/*     */ 
/*     */   
/*     */   private native void nSetLinkStrength(float paramFloat);
/*     */ 
/*     */   
/*     */   public ImVec2 getSourceDirection() {
/* 221 */     ImVec2 dst = new ImVec2();
/* 222 */     nGetSourceDirection(dst);
/* 223 */     return dst;
/*     */   }
/*     */   
/*     */   public float getSourceDirectionX() {
/* 227 */     return nGetSourceDirectionX();
/*     */   }
/*     */   
/*     */   public float getSourceDirectionY() {
/* 231 */     return nGetSourceDirectionY();
/*     */   }
/*     */   
/*     */   public void getSourceDirection(ImVec2 dst) {
/* 235 */     nGetSourceDirection(dst);
/*     */   }
/*     */   
/*     */   public void setSourceDirection(ImVec2 value) {
/* 239 */     nSetSourceDirection(value.x, value.y);
/*     */   }
/*     */   
/*     */   public void setSourceDirection(float valueX, float valueY) {
/* 243 */     nSetSourceDirection(valueX, valueY);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private native void nGetSourceDirection(ImVec2 paramImVec2);
/*     */ 
/*     */ 
/*     */   
/*     */   private native float nGetSourceDirectionX();
/*     */ 
/*     */ 
/*     */   
/*     */   private native float nGetSourceDirectionY();
/*     */ 
/*     */ 
/*     */   
/*     */   private native void nSetSourceDirection(float paramFloat1, float paramFloat2);
/*     */ 
/*     */   
/*     */   public ImVec2 getTargetDirection() {
/* 264 */     ImVec2 dst = new ImVec2();
/* 265 */     nGetTargetDirection(dst);
/* 266 */     return dst;
/*     */   }
/*     */   
/*     */   public float getTargetDirectionX() {
/* 270 */     return nGetTargetDirectionX();
/*     */   }
/*     */   
/*     */   public float getTargetDirectionY() {
/* 274 */     return nGetTargetDirectionY();
/*     */   }
/*     */   
/*     */   public void getTargetDirection(ImVec2 dst) {
/* 278 */     nGetTargetDirection(dst);
/*     */   }
/*     */   
/*     */   public void setTargetDirection(ImVec2 value) {
/* 282 */     nSetTargetDirection(value.x, value.y);
/*     */   }
/*     */   
/*     */   public void setTargetDirection(float valueX, float valueY) {
/* 286 */     nSetTargetDirection(valueX, valueY);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private native void nGetTargetDirection(ImVec2 paramImVec2);
/*     */ 
/*     */ 
/*     */   
/*     */   private native float nGetTargetDirectionX();
/*     */ 
/*     */ 
/*     */   
/*     */   private native float nGetTargetDirectionY();
/*     */ 
/*     */ 
/*     */   
/*     */   private native void nSetTargetDirection(float paramFloat1, float paramFloat2);
/*     */ 
/*     */   
/*     */   public float getScrollDuration() {
/* 307 */     return nGetScrollDuration();
/*     */   }
/*     */   
/*     */   public void setScrollDuration(float value) {
/* 311 */     nSetScrollDuration(value);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private native float nGetScrollDuration();
/*     */ 
/*     */   
/*     */   private native void nSetScrollDuration(float paramFloat);
/*     */ 
/*     */   
/*     */   public float getFlowMarkerDistance() {
/* 323 */     return nGetFlowMarkerDistance();
/*     */   }
/*     */   
/*     */   public void setFlowMarkerDistance(float value) {
/* 327 */     nSetFlowMarkerDistance(value);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private native float nGetFlowMarkerDistance();
/*     */ 
/*     */   
/*     */   private native void nSetFlowMarkerDistance(float paramFloat);
/*     */ 
/*     */   
/*     */   public float getFlowSpeed() {
/* 339 */     return nGetFlowSpeed();
/*     */   }
/*     */   
/*     */   public void setFlowSpeed(float value) {
/* 343 */     nSetFlowSpeed(value);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private native float nGetFlowSpeed();
/*     */ 
/*     */   
/*     */   private native void nSetFlowSpeed(float paramFloat);
/*     */ 
/*     */   
/*     */   public float getFlowDuration() {
/* 355 */     return nGetFlowDuration();
/*     */   }
/*     */   
/*     */   public void setFlowDuration(float value) {
/* 359 */     nSetFlowDuration(value);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private native float nGetFlowDuration();
/*     */ 
/*     */   
/*     */   private native void nSetFlowDuration(float paramFloat);
/*     */ 
/*     */   
/*     */   public ImVec2 getPivotAlignment() {
/* 371 */     ImVec2 dst = new ImVec2();
/* 372 */     nGetPivotAlignment(dst);
/* 373 */     return dst;
/*     */   }
/*     */   
/*     */   public float getPivotAlignmentX() {
/* 377 */     return nGetPivotAlignmentX();
/*     */   }
/*     */   
/*     */   public float getPivotAlignmentY() {
/* 381 */     return nGetPivotAlignmentY();
/*     */   }
/*     */   
/*     */   public void getPivotAlignment(ImVec2 dst) {
/* 385 */     nGetPivotAlignment(dst);
/*     */   }
/*     */   
/*     */   public void setPivotAlignment(ImVec2 value) {
/* 389 */     nSetPivotAlignment(value.x, value.y);
/*     */   }
/*     */   
/*     */   public void setPivotAlignment(float valueX, float valueY) {
/* 393 */     nSetPivotAlignment(valueX, valueY);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private native void nGetPivotAlignment(ImVec2 paramImVec2);
/*     */ 
/*     */ 
/*     */   
/*     */   private native float nGetPivotAlignmentX();
/*     */ 
/*     */ 
/*     */   
/*     */   private native float nGetPivotAlignmentY();
/*     */ 
/*     */ 
/*     */   
/*     */   private native void nSetPivotAlignment(float paramFloat1, float paramFloat2);
/*     */ 
/*     */   
/*     */   public ImVec2 getPivotSize() {
/* 414 */     ImVec2 dst = new ImVec2();
/* 415 */     nGetPivotSize(dst);
/* 416 */     return dst;
/*     */   }
/*     */   
/*     */   public float getPivotSizeX() {
/* 420 */     return nGetPivotSizeX();
/*     */   }
/*     */   
/*     */   public float getPivotSizeY() {
/* 424 */     return nGetPivotSizeY();
/*     */   }
/*     */   
/*     */   public void getPivotSize(ImVec2 dst) {
/* 428 */     nGetPivotSize(dst);
/*     */   }
/*     */   
/*     */   public void setPivotSize(ImVec2 value) {
/* 432 */     nSetPivotSize(value.x, value.y);
/*     */   }
/*     */   
/*     */   public void setPivotSize(float valueX, float valueY) {
/* 436 */     nSetPivotSize(valueX, valueY);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private native void nGetPivotSize(ImVec2 paramImVec2);
/*     */ 
/*     */ 
/*     */   
/*     */   private native float nGetPivotSizeX();
/*     */ 
/*     */ 
/*     */   
/*     */   private native float nGetPivotSizeY();
/*     */ 
/*     */ 
/*     */   
/*     */   private native void nSetPivotSize(float paramFloat1, float paramFloat2);
/*     */ 
/*     */   
/*     */   public ImVec2 getPivotScale() {
/* 457 */     ImVec2 dst = new ImVec2();
/* 458 */     nGetPivotScale(dst);
/* 459 */     return dst;
/*     */   }
/*     */   
/*     */   public float getPivotScaleX() {
/* 463 */     return nGetPivotScaleX();
/*     */   }
/*     */   
/*     */   public float getPivotScaleY() {
/* 467 */     return nGetPivotScaleY();
/*     */   }
/*     */   
/*     */   public void getPivotScale(ImVec2 dst) {
/* 471 */     nGetPivotScale(dst);
/*     */   }
/*     */   
/*     */   public void setPivotScale(ImVec2 value) {
/* 475 */     nSetPivotScale(value.x, value.y);
/*     */   }
/*     */   
/*     */   public void setPivotScale(float valueX, float valueY) {
/* 479 */     nSetPivotScale(valueX, valueY);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private native void nGetPivotScale(ImVec2 paramImVec2);
/*     */ 
/*     */ 
/*     */   
/*     */   private native float nGetPivotScaleX();
/*     */ 
/*     */ 
/*     */   
/*     */   private native float nGetPivotScaleY();
/*     */ 
/*     */ 
/*     */   
/*     */   private native void nSetPivotScale(float paramFloat1, float paramFloat2);
/*     */ 
/*     */   
/*     */   public float getPinCorners() {
/* 500 */     return nGetPinCorners();
/*     */   }
/*     */   
/*     */   public void setPinCorners(float value) {
/* 504 */     nSetPinCorners(value);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private native float nGetPinCorners();
/*     */ 
/*     */   
/*     */   private native void nSetPinCorners(float paramFloat);
/*     */ 
/*     */   
/*     */   public float getPinRadius() {
/* 516 */     return nGetPinRadius();
/*     */   }
/*     */   
/*     */   public void setPinRadius(float value) {
/* 520 */     nSetPinRadius(value);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private native float nGetPinRadius();
/*     */ 
/*     */   
/*     */   private native void nSetPinRadius(float paramFloat);
/*     */ 
/*     */   
/*     */   public float getPinArrowSize() {
/* 532 */     return nGetPinArrowSize();
/*     */   }
/*     */   
/*     */   public void setPinArrowSize(float value) {
/* 536 */     nSetPinArrowSize(value);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private native float nGetPinArrowSize();
/*     */ 
/*     */   
/*     */   private native void nSetPinArrowSize(float paramFloat);
/*     */ 
/*     */   
/*     */   public float getPinArrowWidth() {
/* 548 */     return nGetPinArrowWidth();
/*     */   }
/*     */   
/*     */   public void setPinArrowWidth(float value) {
/* 552 */     nSetPinArrowWidth(value);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private native float nGetPinArrowWidth();
/*     */ 
/*     */   
/*     */   private native void nSetPinArrowWidth(float paramFloat);
/*     */ 
/*     */   
/*     */   public float getGroupRounding() {
/* 564 */     return nGetGroupRounding();
/*     */   }
/*     */   
/*     */   public void setGroupRounding(float value) {
/* 568 */     nSetGroupRounding(value);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private native float nGetGroupRounding();
/*     */ 
/*     */   
/*     */   private native void nSetGroupRounding(float paramFloat);
/*     */ 
/*     */   
/*     */   public float getGroupBorderWidth() {
/* 580 */     return nGetGroupBorderWidth();
/*     */   }
/*     */   
/*     */   public void setGroupBorderWidth(float value) {
/* 584 */     nSetGroupBorderWidth(value);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private native float nGetGroupBorderWidth();
/*     */ 
/*     */   
/*     */   private native void nSetGroupBorderWidth(float paramFloat);
/*     */ 
/*     */   
/*     */   public float getHighlightConnectedLinks() {
/* 596 */     return nGetHighlightConnectedLinks();
/*     */   }
/*     */   
/*     */   public void setHighlightConnectedLinks(float value) {
/* 600 */     nSetHighlightConnectedLinks(value);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private native float nGetHighlightConnectedLinks();
/*     */ 
/*     */   
/*     */   private native void nSetHighlightConnectedLinks(float paramFloat);
/*     */ 
/*     */   
/*     */   public float getSnapLinkToPinDir() {
/* 612 */     return nGetSnapLinkToPinDir();
/*     */   }
/*     */   
/*     */   public void setSnapLinkToPinDir(float value) {
/* 616 */     nSetSnapLinkToPinDir(value);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private native float nGetSnapLinkToPinDir();
/*     */ 
/*     */   
/*     */   private native void nSetSnapLinkToPinDir(float paramFloat);
/*     */ 
/*     */   
/*     */   public ImVec4[] getColors() {
/* 628 */     return nGetColors();
/*     */   }
/*     */   
/*     */   public void setColors(ImVec4[] value) {
/* 632 */     nSetColors(value);
/*     */   }
/*     */   
/*     */   private native ImVec4[] nGetColors();
/*     */   
/*     */   private native void nSetColors(ImVec4[] paramArrayOfImVec4);
/*     */ }


/* Location:              C:\Users\rapha\Downloads\aurora.jar!\META-INF\jars\imgui-java-binding-1.90.0.jar!\imgui\extension\nodeditor\NodeEditorStyle.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */