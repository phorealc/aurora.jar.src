package imgui.extension.nodeditor.flag;

public final class NodeEditorFlowDirection {
  public static final int Forward = 0;
  
  public static final int Backward = 1;
}


/* Location:              C:\Users\rapha\Downloads\aurora.jar!\META-INF\jars\imgui-java-binding-1.90.0.jar!\imgui\extension\nodeditor\flag\NodeEditorFlowDirection.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */