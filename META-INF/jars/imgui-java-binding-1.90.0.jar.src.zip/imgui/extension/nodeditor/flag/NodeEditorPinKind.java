package imgui.extension.nodeditor.flag;

public final class NodeEditorPinKind {
  public static final int Input = 0;
  
  public static final int Output = 1;
}


/* Location:              C:\Users\rapha\Downloads\aurora.jar!\META-INF\jars\imgui-java-binding-1.90.0.jar!\imgui\extension\nodeditor\flag\NodeEditorPinKind.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */