package imgui.extension.nodeditor.flag;

public final class NodeEditorStyleVar {
  public static final int NodePadding = 0;
  
  public static final int NodeRounding = 1;
  
  public static final int NodeBorderWidth = 2;
  
  public static final int HoveredNodeBorderWidth = 3;
  
  public static final int SelectedNodeBorderWidth = 4;
  
  public static final int PinRounding = 5;
  
  public static final int PinBorderWidth = 6;
  
  public static final int LinkStrength = 7;
  
  public static final int SourceDirection = 8;
  
  public static final int TargetDirection = 9;
  
  public static final int ScrollDuration = 10;
  
  public static final int FlowMarkerDistance = 11;
  
  public static final int FlowSpeed = 12;
  
  public static final int FlowDuration = 13;
  
  public static final int PivotAlignment = 14;
  
  public static final int PivotSize = 15;
  
  public static final int PivotScale = 16;
  
  public static final int PinCorners = 17;
  
  public static final int PinRadius = 18;
  
  public static final int PinArrowSize = 19;
  
  public static final int PinArrowWidth = 20;
  
  public static final int GroupRounding = 21;
  
  public static final int GroupBorderWidth = 22;
  
  public static final int HighlightConnectedLinks = 23;
  
  public static final int SnapLinkToPinDir = 24;
  
  public static final int HoveredNodeBorderOffset = 25;
  
  public static final int SelectedNodeBorderOffset = 26;
  
  public static final int Count = 27;
}


/* Location:              C:\Users\rapha\Downloads\aurora.jar!\META-INF\jars\imgui-java-binding-1.90.0.jar!\imgui\extension\nodeditor\flag\NodeEditorStyleVar.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */