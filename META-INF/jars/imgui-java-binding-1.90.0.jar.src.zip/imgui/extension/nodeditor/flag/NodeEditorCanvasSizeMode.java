package imgui.extension.nodeditor.flag;

public final class NodeEditorCanvasSizeMode {
  public static final int FitVerticalView = 0;
  
  public static final int FitHorizontalView = 1;
  
  public static final int CenterOnly = 2;
}


/* Location:              C:\Users\rapha\Downloads\aurora.jar!\META-INF\jars\imgui-java-binding-1.90.0.jar!\imgui\extension\nodeditor\flag\NodeEditorCanvasSizeMode.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */