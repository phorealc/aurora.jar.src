/*     */ package imgui.extension.nodeditor;
/*     */ 
/*     */ import imgui.binding.ImGuiStructDestroyable;
/*     */ 
/*     */ public final class NodeEditorConfig
/*     */   extends ImGuiStructDestroyable {
/*     */   protected long create() {
/*   8 */     return nCreate();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private native long nCreate();
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getSettingsFile() {
/*  21 */     return nGetSettingsFile();
/*     */   }
/*     */   
/*     */   public void setSettingsFile(String value) {
/*  25 */     nSetSettingsFile(value);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private native String nGetSettingsFile();
/*     */ 
/*     */ 
/*     */   
/*     */   private native void nSetSettingsFile(String paramString);
/*     */ 
/*     */ 
/*     */   
/*     */   public int getCanvasSizeMode() {
/*  39 */     return nGetCanvasSizeMode();
/*     */   }
/*     */   
/*     */   public void setCanvasSizeMode(int value) {
/*  43 */     nSetCanvasSizeMode(value);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public native int nGetCanvasSizeMode();
/*     */ 
/*     */   
/*     */   public native void nSetCanvasSizeMode(int paramInt);
/*     */ 
/*     */   
/*     */   public int getDragButtonIndex() {
/*  55 */     return nGetDragButtonIndex();
/*     */   }
/*     */   
/*     */   public void setDragButtonIndex(int value) {
/*  59 */     nSetDragButtonIndex(value);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private native int nGetDragButtonIndex();
/*     */ 
/*     */   
/*     */   private native void nSetDragButtonIndex(int paramInt);
/*     */ 
/*     */   
/*     */   public int getSelectButtonIndex() {
/*  71 */     return nGetSelectButtonIndex();
/*     */   }
/*     */   
/*     */   public void setSelectButtonIndex(int value) {
/*  75 */     nSetSelectButtonIndex(value);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private native int nGetSelectButtonIndex();
/*     */ 
/*     */   
/*     */   private native void nSetSelectButtonIndex(int paramInt);
/*     */ 
/*     */   
/*     */   public int getNavigateButtonIndex() {
/*  87 */     return nGetNavigateButtonIndex();
/*     */   }
/*     */   
/*     */   public void setNavigateButtonIndex(int value) {
/*  91 */     nSetNavigateButtonIndex(value);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private native int nGetNavigateButtonIndex();
/*     */ 
/*     */   
/*     */   private native void nSetNavigateButtonIndex(int paramInt);
/*     */ 
/*     */   
/*     */   public int getContextMenuButtonIndex() {
/* 103 */     return nGetContextMenuButtonIndex();
/*     */   }
/*     */   
/*     */   public void setContextMenuButtonIndex(int value) {
/* 107 */     nSetContextMenuButtonIndex(value);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private native int nGetContextMenuButtonIndex();
/*     */ 
/*     */   
/*     */   private native void nSetContextMenuButtonIndex(int paramInt);
/*     */ 
/*     */   
/*     */   public boolean getEnableSmoothZoom() {
/* 119 */     return nGetEnableSmoothZoom();
/*     */   }
/*     */   
/*     */   public void setEnableSmoothZoom(boolean value) {
/* 123 */     nSetEnableSmoothZoom(value);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private native boolean nGetEnableSmoothZoom();
/*     */ 
/*     */   
/*     */   private native void nSetEnableSmoothZoom(boolean paramBoolean);
/*     */ 
/*     */   
/*     */   public float getSmoothZoomPower() {
/* 135 */     return nGetSmoothZoomPower();
/*     */   }
/*     */   
/*     */   public void setSmoothZoomPower(float value) {
/* 139 */     nSetSmoothZoomPower(value);
/*     */   }
/*     */   
/*     */   private native float nGetSmoothZoomPower();
/*     */   
/*     */   private native void nSetSmoothZoomPower(float paramFloat);
/*     */ }


/* Location:              C:\Users\rapha\Downloads\aurora.jar!\META-INF\jars\imgui-java-binding-1.90.0.jar!\imgui\extension\nodeditor\NodeEditorConfig.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */