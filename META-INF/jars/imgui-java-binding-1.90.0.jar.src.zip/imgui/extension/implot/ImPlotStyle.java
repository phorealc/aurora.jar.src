/*     */ package imgui.extension.implot;
/*     */ 
/*     */ import imgui.ImVec2;
/*     */ import imgui.ImVec4;
/*     */ import imgui.binding.ImGuiStructDestroyable;
/*     */ 
/*     */ public final class ImPlotStyle
/*     */   extends ImGuiStructDestroyable
/*     */ {
/*     */   public ImPlotStyle() {}
/*     */   
/*     */   public ImPlotStyle(long ptr) {
/*  13 */     super(ptr);
/*     */   }
/*     */ 
/*     */   
/*     */   protected long create() {
/*  18 */     return nCreate();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private native long nCreate();
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public float getLineWeight() {
/*  31 */     return nGetLineWeight();
/*     */   }
/*     */   
/*     */   public void setLineWeight(float value) {
/*  35 */     nSetLineWeight(value);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private native float nGetLineWeight();
/*     */ 
/*     */   
/*     */   private native void nSetLineWeight(float paramFloat);
/*     */ 
/*     */   
/*     */   public int getMarker() {
/*  47 */     return nGetMarker();
/*     */   }
/*     */   
/*     */   public void setMarker(int value) {
/*  51 */     nSetMarker(value);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private native int nGetMarker();
/*     */ 
/*     */   
/*     */   private native void nSetMarker(int paramInt);
/*     */ 
/*     */   
/*     */   public float getMarkerSize() {
/*  63 */     return nGetMarkerSize();
/*     */   }
/*     */   
/*     */   public void setMarkerSize(float value) {
/*  67 */     nSetMarkerSize(value);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private native float nGetMarkerSize();
/*     */ 
/*     */   
/*     */   private native void nSetMarkerSize(float paramFloat);
/*     */ 
/*     */   
/*     */   public float getMarkerWeight() {
/*  79 */     return nGetMarkerWeight();
/*     */   }
/*     */   
/*     */   public void setMarkerWeight(float value) {
/*  83 */     nSetMarkerWeight(value);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private native float nGetMarkerWeight();
/*     */ 
/*     */   
/*     */   private native void nSetMarkerWeight(float paramFloat);
/*     */ 
/*     */   
/*     */   public float getFillAlpha() {
/*  95 */     return nGetFillAlpha();
/*     */   }
/*     */   
/*     */   public void setFillAlpha(float value) {
/*  99 */     nSetFillAlpha(value);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private native float nGetFillAlpha();
/*     */ 
/*     */   
/*     */   private native void nSetFillAlpha(float paramFloat);
/*     */ 
/*     */   
/*     */   public float getErrorBarSize() {
/* 111 */     return nGetErrorBarSize();
/*     */   }
/*     */   
/*     */   public void setErrorBarSize(float value) {
/* 115 */     nSetErrorBarSize(value);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private native float nGetErrorBarSize();
/*     */ 
/*     */   
/*     */   private native void nSetErrorBarSize(float paramFloat);
/*     */ 
/*     */   
/*     */   public float getErrorBarWeight() {
/* 127 */     return nGetErrorBarWeight();
/*     */   }
/*     */   
/*     */   public void setErrorBarWeight(float value) {
/* 131 */     nSetErrorBarWeight(value);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private native float nGetErrorBarWeight();
/*     */ 
/*     */   
/*     */   private native void nSetErrorBarWeight(float paramFloat);
/*     */ 
/*     */   
/*     */   public float getDigitalBitHeight() {
/* 143 */     return nGetDigitalBitHeight();
/*     */   }
/*     */   
/*     */   public void setDigitalBitHeight(float value) {
/* 147 */     nSetDigitalBitHeight(value);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private native float nGetDigitalBitHeight();
/*     */ 
/*     */   
/*     */   private native void nSetDigitalBitHeight(float paramFloat);
/*     */ 
/*     */   
/*     */   public float getDigitalBitGap() {
/* 159 */     return nGetDigitalBitGap();
/*     */   }
/*     */   
/*     */   public void setDigitalBitGap(float value) {
/* 163 */     nSetDigitalBitGap(value);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private native float nGetDigitalBitGap();
/*     */ 
/*     */   
/*     */   private native void nSetDigitalBitGap(float paramFloat);
/*     */ 
/*     */   
/*     */   public float getPlotBorderSize() {
/* 175 */     return nGetPlotBorderSize();
/*     */   }
/*     */   
/*     */   public void setPlotBorderSize(float value) {
/* 179 */     nSetPlotBorderSize(value);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private native float nGetPlotBorderSize();
/*     */ 
/*     */   
/*     */   private native void nSetPlotBorderSize(float paramFloat);
/*     */ 
/*     */   
/*     */   public float getMinorAlpha() {
/* 191 */     return nGetMinorAlpha();
/*     */   }
/*     */   
/*     */   public void setMinorAlpha(float value) {
/* 195 */     nSetMinorAlpha(value);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private native float nGetMinorAlpha();
/*     */ 
/*     */   
/*     */   private native void nSetMinorAlpha(float paramFloat);
/*     */ 
/*     */   
/*     */   public ImVec2 getMajorTickLen() {
/* 207 */     ImVec2 dst = new ImVec2();
/* 208 */     nGetMajorTickLen(dst);
/* 209 */     return dst;
/*     */   }
/*     */   
/*     */   public float getMajorTickLenX() {
/* 213 */     return nGetMajorTickLenX();
/*     */   }
/*     */   
/*     */   public float getMajorTickLenY() {
/* 217 */     return nGetMajorTickLenY();
/*     */   }
/*     */   
/*     */   public void getMajorTickLen(ImVec2 dst) {
/* 221 */     nGetMajorTickLen(dst);
/*     */   }
/*     */   
/*     */   public void setMajorTickLen(ImVec2 value) {
/* 225 */     nSetMajorTickLen(value.x, value.y);
/*     */   }
/*     */   
/*     */   public void setMajorTickLen(float valueX, float valueY) {
/* 229 */     nSetMajorTickLen(valueX, valueY);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private native void nGetMajorTickLen(ImVec2 paramImVec2);
/*     */ 
/*     */ 
/*     */   
/*     */   private native float nGetMajorTickLenX();
/*     */ 
/*     */ 
/*     */   
/*     */   private native float nGetMajorTickLenY();
/*     */ 
/*     */ 
/*     */   
/*     */   private native void nSetMajorTickLen(float paramFloat1, float paramFloat2);
/*     */ 
/*     */   
/*     */   public ImVec2 getMinorTickLen() {
/* 250 */     ImVec2 dst = new ImVec2();
/* 251 */     nGetMinorTickLen(dst);
/* 252 */     return dst;
/*     */   }
/*     */   
/*     */   public float getMinorTickLenX() {
/* 256 */     return nGetMinorTickLenX();
/*     */   }
/*     */   
/*     */   public float getMinorTickLenY() {
/* 260 */     return nGetMinorTickLenY();
/*     */   }
/*     */   
/*     */   public void getMinorTickLen(ImVec2 dst) {
/* 264 */     nGetMinorTickLen(dst);
/*     */   }
/*     */   
/*     */   public void setMinorTickLen(ImVec2 value) {
/* 268 */     nSetMinorTickLen(value.x, value.y);
/*     */   }
/*     */   
/*     */   public void setMinorTickLen(float valueX, float valueY) {
/* 272 */     nSetMinorTickLen(valueX, valueY);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private native void nGetMinorTickLen(ImVec2 paramImVec2);
/*     */ 
/*     */ 
/*     */   
/*     */   private native float nGetMinorTickLenX();
/*     */ 
/*     */ 
/*     */   
/*     */   private native float nGetMinorTickLenY();
/*     */ 
/*     */ 
/*     */   
/*     */   private native void nSetMinorTickLen(float paramFloat1, float paramFloat2);
/*     */ 
/*     */   
/*     */   public ImVec2 getMajorTickSize() {
/* 293 */     ImVec2 dst = new ImVec2();
/* 294 */     nGetMajorTickSize(dst);
/* 295 */     return dst;
/*     */   }
/*     */   
/*     */   public float getMajorTickSizeX() {
/* 299 */     return nGetMajorTickSizeX();
/*     */   }
/*     */   
/*     */   public float getMajorTickSizeY() {
/* 303 */     return nGetMajorTickSizeY();
/*     */   }
/*     */   
/*     */   public void getMajorTickSize(ImVec2 dst) {
/* 307 */     nGetMajorTickSize(dst);
/*     */   }
/*     */   
/*     */   public void setMajorTickSize(ImVec2 value) {
/* 311 */     nSetMajorTickSize(value.x, value.y);
/*     */   }
/*     */   
/*     */   public void setMajorTickSize(float valueX, float valueY) {
/* 315 */     nSetMajorTickSize(valueX, valueY);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private native void nGetMajorTickSize(ImVec2 paramImVec2);
/*     */ 
/*     */ 
/*     */   
/*     */   private native float nGetMajorTickSizeX();
/*     */ 
/*     */ 
/*     */   
/*     */   private native float nGetMajorTickSizeY();
/*     */ 
/*     */ 
/*     */   
/*     */   private native void nSetMajorTickSize(float paramFloat1, float paramFloat2);
/*     */ 
/*     */   
/*     */   public ImVec2 getMinorTickSize() {
/* 336 */     ImVec2 dst = new ImVec2();
/* 337 */     nGetMinorTickSize(dst);
/* 338 */     return dst;
/*     */   }
/*     */   
/*     */   public float getMinorTickSizeX() {
/* 342 */     return nGetMinorTickSizeX();
/*     */   }
/*     */   
/*     */   public float getMinorTickSizeY() {
/* 346 */     return nGetMinorTickSizeY();
/*     */   }
/*     */   
/*     */   public void getMinorTickSize(ImVec2 dst) {
/* 350 */     nGetMinorTickSize(dst);
/*     */   }
/*     */   
/*     */   public void setMinorTickSize(ImVec2 value) {
/* 354 */     nSetMinorTickSize(value.x, value.y);
/*     */   }
/*     */   
/*     */   public void setMinorTickSize(float valueX, float valueY) {
/* 358 */     nSetMinorTickSize(valueX, valueY);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private native void nGetMinorTickSize(ImVec2 paramImVec2);
/*     */ 
/*     */ 
/*     */   
/*     */   private native float nGetMinorTickSizeX();
/*     */ 
/*     */ 
/*     */   
/*     */   private native float nGetMinorTickSizeY();
/*     */ 
/*     */ 
/*     */   
/*     */   private native void nSetMinorTickSize(float paramFloat1, float paramFloat2);
/*     */ 
/*     */   
/*     */   public ImVec2 getMajorGridSize() {
/* 379 */     ImVec2 dst = new ImVec2();
/* 380 */     nGetMajorGridSize(dst);
/* 381 */     return dst;
/*     */   }
/*     */   
/*     */   public float getMajorGridSizeX() {
/* 385 */     return nGetMajorGridSizeX();
/*     */   }
/*     */   
/*     */   public float getMajorGridSizeY() {
/* 389 */     return nGetMajorGridSizeY();
/*     */   }
/*     */   
/*     */   public void getMajorGridSize(ImVec2 dst) {
/* 393 */     nGetMajorGridSize(dst);
/*     */   }
/*     */   
/*     */   public void setMajorGridSize(ImVec2 value) {
/* 397 */     nSetMajorGridSize(value.x, value.y);
/*     */   }
/*     */   
/*     */   public void setMajorGridSize(float valueX, float valueY) {
/* 401 */     nSetMajorGridSize(valueX, valueY);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private native void nGetMajorGridSize(ImVec2 paramImVec2);
/*     */ 
/*     */ 
/*     */   
/*     */   private native float nGetMajorGridSizeX();
/*     */ 
/*     */ 
/*     */   
/*     */   private native float nGetMajorGridSizeY();
/*     */ 
/*     */ 
/*     */   
/*     */   private native void nSetMajorGridSize(float paramFloat1, float paramFloat2);
/*     */ 
/*     */   
/*     */   public ImVec2 getMinorGridSize() {
/* 422 */     ImVec2 dst = new ImVec2();
/* 423 */     nGetMinorGridSize(dst);
/* 424 */     return dst;
/*     */   }
/*     */   
/*     */   public float getMinorGridSizeX() {
/* 428 */     return nGetMinorGridSizeX();
/*     */   }
/*     */   
/*     */   public float getMinorGridSizeY() {
/* 432 */     return nGetMinorGridSizeY();
/*     */   }
/*     */   
/*     */   public void getMinorGridSize(ImVec2 dst) {
/* 436 */     nGetMinorGridSize(dst);
/*     */   }
/*     */   
/*     */   public void setMinorGridSize(ImVec2 value) {
/* 440 */     nSetMinorGridSize(value.x, value.y);
/*     */   }
/*     */   
/*     */   public void setMinorGridSize(float valueX, float valueY) {
/* 444 */     nSetMinorGridSize(valueX, valueY);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private native void nGetMinorGridSize(ImVec2 paramImVec2);
/*     */ 
/*     */ 
/*     */   
/*     */   private native float nGetMinorGridSizeX();
/*     */ 
/*     */ 
/*     */   
/*     */   private native float nGetMinorGridSizeY();
/*     */ 
/*     */ 
/*     */   
/*     */   private native void nSetMinorGridSize(float paramFloat1, float paramFloat2);
/*     */ 
/*     */   
/*     */   public ImVec2 getPlotPadding() {
/* 465 */     ImVec2 dst = new ImVec2();
/* 466 */     nGetPlotPadding(dst);
/* 467 */     return dst;
/*     */   }
/*     */   
/*     */   public float getPlotPaddingX() {
/* 471 */     return nGetPlotPaddingX();
/*     */   }
/*     */   
/*     */   public float getPlotPaddingY() {
/* 475 */     return nGetPlotPaddingY();
/*     */   }
/*     */   
/*     */   public void getPlotPadding(ImVec2 dst) {
/* 479 */     nGetPlotPadding(dst);
/*     */   }
/*     */   
/*     */   public void setPlotPadding(ImVec2 value) {
/* 483 */     nSetPlotPadding(value.x, value.y);
/*     */   }
/*     */   
/*     */   public void setPlotPadding(float valueX, float valueY) {
/* 487 */     nSetPlotPadding(valueX, valueY);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private native void nGetPlotPadding(ImVec2 paramImVec2);
/*     */ 
/*     */ 
/*     */   
/*     */   private native float nGetPlotPaddingX();
/*     */ 
/*     */ 
/*     */   
/*     */   private native float nGetPlotPaddingY();
/*     */ 
/*     */ 
/*     */   
/*     */   private native void nSetPlotPadding(float paramFloat1, float paramFloat2);
/*     */ 
/*     */   
/*     */   public ImVec2 getLabelPadding() {
/* 508 */     ImVec2 dst = new ImVec2();
/* 509 */     nGetLabelPadding(dst);
/* 510 */     return dst;
/*     */   }
/*     */   
/*     */   public float getLabelPaddingX() {
/* 514 */     return nGetLabelPaddingX();
/*     */   }
/*     */   
/*     */   public float getLabelPaddingY() {
/* 518 */     return nGetLabelPaddingY();
/*     */   }
/*     */   
/*     */   public void getLabelPadding(ImVec2 dst) {
/* 522 */     nGetLabelPadding(dst);
/*     */   }
/*     */   
/*     */   public void setLabelPadding(ImVec2 value) {
/* 526 */     nSetLabelPadding(value.x, value.y);
/*     */   }
/*     */   
/*     */   public void setLabelPadding(float valueX, float valueY) {
/* 530 */     nSetLabelPadding(valueX, valueY);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private native void nGetLabelPadding(ImVec2 paramImVec2);
/*     */ 
/*     */ 
/*     */   
/*     */   private native float nGetLabelPaddingX();
/*     */ 
/*     */ 
/*     */   
/*     */   private native float nGetLabelPaddingY();
/*     */ 
/*     */ 
/*     */   
/*     */   private native void nSetLabelPadding(float paramFloat1, float paramFloat2);
/*     */ 
/*     */   
/*     */   public ImVec2 getLegendPadding() {
/* 551 */     ImVec2 dst = new ImVec2();
/* 552 */     nGetLegendPadding(dst);
/* 553 */     return dst;
/*     */   }
/*     */   
/*     */   public float getLegendPaddingX() {
/* 557 */     return nGetLegendPaddingX();
/*     */   }
/*     */   
/*     */   public float getLegendPaddingY() {
/* 561 */     return nGetLegendPaddingY();
/*     */   }
/*     */   
/*     */   public void getLegendPadding(ImVec2 dst) {
/* 565 */     nGetLegendPadding(dst);
/*     */   }
/*     */   
/*     */   public void setLegendPadding(ImVec2 value) {
/* 569 */     nSetLegendPadding(value.x, value.y);
/*     */   }
/*     */   
/*     */   public void setLegendPadding(float valueX, float valueY) {
/* 573 */     nSetLegendPadding(valueX, valueY);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private native void nGetLegendPadding(ImVec2 paramImVec2);
/*     */ 
/*     */ 
/*     */   
/*     */   private native float nGetLegendPaddingX();
/*     */ 
/*     */ 
/*     */   
/*     */   private native float nGetLegendPaddingY();
/*     */ 
/*     */ 
/*     */   
/*     */   private native void nSetLegendPadding(float paramFloat1, float paramFloat2);
/*     */ 
/*     */   
/*     */   public ImVec2 getLegendInnerPadding() {
/* 594 */     ImVec2 dst = new ImVec2();
/* 595 */     nGetLegendInnerPadding(dst);
/* 596 */     return dst;
/*     */   }
/*     */   
/*     */   public float getLegendInnerPaddingX() {
/* 600 */     return nGetLegendInnerPaddingX();
/*     */   }
/*     */   
/*     */   public float getLegendInnerPaddingY() {
/* 604 */     return nGetLegendInnerPaddingY();
/*     */   }
/*     */   
/*     */   public void getLegendInnerPadding(ImVec2 dst) {
/* 608 */     nGetLegendInnerPadding(dst);
/*     */   }
/*     */   
/*     */   public void setLegendInnerPadding(ImVec2 value) {
/* 612 */     nSetLegendInnerPadding(value.x, value.y);
/*     */   }
/*     */   
/*     */   public void setLegendInnerPadding(float valueX, float valueY) {
/* 616 */     nSetLegendInnerPadding(valueX, valueY);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private native void nGetLegendInnerPadding(ImVec2 paramImVec2);
/*     */ 
/*     */ 
/*     */   
/*     */   private native float nGetLegendInnerPaddingX();
/*     */ 
/*     */ 
/*     */   
/*     */   private native float nGetLegendInnerPaddingY();
/*     */ 
/*     */ 
/*     */   
/*     */   private native void nSetLegendInnerPadding(float paramFloat1, float paramFloat2);
/*     */ 
/*     */   
/*     */   public ImVec2 getLegendSpacing() {
/* 637 */     ImVec2 dst = new ImVec2();
/* 638 */     nGetLegendSpacing(dst);
/* 639 */     return dst;
/*     */   }
/*     */   
/*     */   public float getLegendSpacingX() {
/* 643 */     return nGetLegendSpacingX();
/*     */   }
/*     */   
/*     */   public float getLegendSpacingY() {
/* 647 */     return nGetLegendSpacingY();
/*     */   }
/*     */   
/*     */   public void getLegendSpacing(ImVec2 dst) {
/* 651 */     nGetLegendSpacing(dst);
/*     */   }
/*     */   
/*     */   public void setLegendSpacing(ImVec2 value) {
/* 655 */     nSetLegendSpacing(value.x, value.y);
/*     */   }
/*     */   
/*     */   public void setLegendSpacing(float valueX, float valueY) {
/* 659 */     nSetLegendSpacing(valueX, valueY);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private native void nGetLegendSpacing(ImVec2 paramImVec2);
/*     */ 
/*     */ 
/*     */   
/*     */   private native float nGetLegendSpacingX();
/*     */ 
/*     */ 
/*     */   
/*     */   private native float nGetLegendSpacingY();
/*     */ 
/*     */ 
/*     */   
/*     */   private native void nSetLegendSpacing(float paramFloat1, float paramFloat2);
/*     */ 
/*     */   
/*     */   public ImVec2 getMousePosPadding() {
/* 680 */     ImVec2 dst = new ImVec2();
/* 681 */     nGetMousePosPadding(dst);
/* 682 */     return dst;
/*     */   }
/*     */   
/*     */   public float getMousePosPaddingX() {
/* 686 */     return nGetMousePosPaddingX();
/*     */   }
/*     */   
/*     */   public float getMousePosPaddingY() {
/* 690 */     return nGetMousePosPaddingY();
/*     */   }
/*     */   
/*     */   public void getMousePosPadding(ImVec2 dst) {
/* 694 */     nGetMousePosPadding(dst);
/*     */   }
/*     */   
/*     */   public void setMousePosPadding(ImVec2 value) {
/* 698 */     nSetMousePosPadding(value.x, value.y);
/*     */   }
/*     */   
/*     */   public void setMousePosPadding(float valueX, float valueY) {
/* 702 */     nSetMousePosPadding(valueX, valueY);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private native void nGetMousePosPadding(ImVec2 paramImVec2);
/*     */ 
/*     */ 
/*     */   
/*     */   private native float nGetMousePosPaddingX();
/*     */ 
/*     */ 
/*     */   
/*     */   private native float nGetMousePosPaddingY();
/*     */ 
/*     */ 
/*     */   
/*     */   private native void nSetMousePosPadding(float paramFloat1, float paramFloat2);
/*     */ 
/*     */   
/*     */   public ImVec2 getAnnotationPadding() {
/* 723 */     ImVec2 dst = new ImVec2();
/* 724 */     nGetAnnotationPadding(dst);
/* 725 */     return dst;
/*     */   }
/*     */   
/*     */   public float getAnnotationPaddingX() {
/* 729 */     return nGetAnnotationPaddingX();
/*     */   }
/*     */   
/*     */   public float getAnnotationPaddingY() {
/* 733 */     return nGetAnnotationPaddingY();
/*     */   }
/*     */   
/*     */   public void getAnnotationPadding(ImVec2 dst) {
/* 737 */     nGetAnnotationPadding(dst);
/*     */   }
/*     */   
/*     */   public void setAnnotationPadding(ImVec2 value) {
/* 741 */     nSetAnnotationPadding(value.x, value.y);
/*     */   }
/*     */   
/*     */   public void setAnnotationPadding(float valueX, float valueY) {
/* 745 */     nSetAnnotationPadding(valueX, valueY);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private native void nGetAnnotationPadding(ImVec2 paramImVec2);
/*     */ 
/*     */ 
/*     */   
/*     */   private native float nGetAnnotationPaddingX();
/*     */ 
/*     */ 
/*     */   
/*     */   private native float nGetAnnotationPaddingY();
/*     */ 
/*     */ 
/*     */   
/*     */   private native void nSetAnnotationPadding(float paramFloat1, float paramFloat2);
/*     */ 
/*     */   
/*     */   public ImVec2 getFitPadding() {
/* 766 */     ImVec2 dst = new ImVec2();
/* 767 */     nGetFitPadding(dst);
/* 768 */     return dst;
/*     */   }
/*     */   
/*     */   public float getFitPaddingX() {
/* 772 */     return nGetFitPaddingX();
/*     */   }
/*     */   
/*     */   public float getFitPaddingY() {
/* 776 */     return nGetFitPaddingY();
/*     */   }
/*     */   
/*     */   public void getFitPadding(ImVec2 dst) {
/* 780 */     nGetFitPadding(dst);
/*     */   }
/*     */   
/*     */   public void setFitPadding(ImVec2 value) {
/* 784 */     nSetFitPadding(value.x, value.y);
/*     */   }
/*     */   
/*     */   public void setFitPadding(float valueX, float valueY) {
/* 788 */     nSetFitPadding(valueX, valueY);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private native void nGetFitPadding(ImVec2 paramImVec2);
/*     */ 
/*     */ 
/*     */   
/*     */   private native float nGetFitPaddingX();
/*     */ 
/*     */ 
/*     */   
/*     */   private native float nGetFitPaddingY();
/*     */ 
/*     */ 
/*     */   
/*     */   private native void nSetFitPadding(float paramFloat1, float paramFloat2);
/*     */ 
/*     */   
/*     */   public ImVec2 getPlotDefaultSize() {
/* 809 */     ImVec2 dst = new ImVec2();
/* 810 */     nGetPlotDefaultSize(dst);
/* 811 */     return dst;
/*     */   }
/*     */   
/*     */   public float getPlotDefaultSizeX() {
/* 815 */     return nGetPlotDefaultSizeX();
/*     */   }
/*     */   
/*     */   public float getPlotDefaultSizeY() {
/* 819 */     return nGetPlotDefaultSizeY();
/*     */   }
/*     */   
/*     */   public void getPlotDefaultSize(ImVec2 dst) {
/* 823 */     nGetPlotDefaultSize(dst);
/*     */   }
/*     */   
/*     */   public void setPlotDefaultSize(ImVec2 value) {
/* 827 */     nSetPlotDefaultSize(value.x, value.y);
/*     */   }
/*     */   
/*     */   public void setPlotDefaultSize(float valueX, float valueY) {
/* 831 */     nSetPlotDefaultSize(valueX, valueY);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private native void nGetPlotDefaultSize(ImVec2 paramImVec2);
/*     */ 
/*     */ 
/*     */   
/*     */   private native float nGetPlotDefaultSizeX();
/*     */ 
/*     */ 
/*     */   
/*     */   private native float nGetPlotDefaultSizeY();
/*     */ 
/*     */ 
/*     */   
/*     */   private native void nSetPlotDefaultSize(float paramFloat1, float paramFloat2);
/*     */ 
/*     */   
/*     */   public ImVec2 getPlotMinSize() {
/* 852 */     ImVec2 dst = new ImVec2();
/* 853 */     nGetPlotMinSize(dst);
/* 854 */     return dst;
/*     */   }
/*     */   
/*     */   public float getPlotMinSizeX() {
/* 858 */     return nGetPlotMinSizeX();
/*     */   }
/*     */   
/*     */   public float getPlotMinSizeY() {
/* 862 */     return nGetPlotMinSizeY();
/*     */   }
/*     */   
/*     */   public void getPlotMinSize(ImVec2 dst) {
/* 866 */     nGetPlotMinSize(dst);
/*     */   }
/*     */   
/*     */   public void setPlotMinSize(ImVec2 value) {
/* 870 */     nSetPlotMinSize(value.x, value.y);
/*     */   }
/*     */   
/*     */   public void setPlotMinSize(float valueX, float valueY) {
/* 874 */     nSetPlotMinSize(valueX, valueY);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private native void nGetPlotMinSize(ImVec2 paramImVec2);
/*     */ 
/*     */ 
/*     */   
/*     */   private native float nGetPlotMinSizeX();
/*     */ 
/*     */ 
/*     */   
/*     */   private native float nGetPlotMinSizeY();
/*     */ 
/*     */ 
/*     */   
/*     */   private native void nSetPlotMinSize(float paramFloat1, float paramFloat2);
/*     */ 
/*     */   
/*     */   public ImVec4[] getColors() {
/* 895 */     return nGetColors();
/*     */   }
/*     */   
/*     */   public void setColors(ImVec4[] value) {
/* 899 */     nSetColors(value);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private native ImVec4[] nGetColors();
/*     */ 
/*     */   
/*     */   private native void nSetColors(ImVec4[] paramArrayOfImVec4);
/*     */ 
/*     */   
/*     */   public int getColormap() {
/* 911 */     return nGetColormap();
/*     */   }
/*     */   
/*     */   public void setColormap(int value) {
/* 915 */     nSetColormap(value);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private native int nGetColormap();
/*     */ 
/*     */   
/*     */   private native void nSetColormap(int paramInt);
/*     */ 
/*     */   
/*     */   public boolean getUseLocalTime() {
/* 927 */     return nGetUseLocalTime();
/*     */   }
/*     */   
/*     */   public void setUseLocalTime(boolean value) {
/* 931 */     nSetUseLocalTime(value);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private native boolean nGetUseLocalTime();
/*     */ 
/*     */   
/*     */   private native void nSetUseLocalTime(boolean paramBoolean);
/*     */ 
/*     */   
/*     */   public boolean getUseISO8601() {
/* 943 */     return nGetUseISO8601();
/*     */   }
/*     */   
/*     */   public void setUseISO8601(boolean value) {
/* 947 */     nSetUseISO8601(value);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private native boolean nGetUseISO8601();
/*     */ 
/*     */   
/*     */   private native void nSetUseISO8601(boolean paramBoolean);
/*     */ 
/*     */   
/*     */   public boolean getUse24HourClock() {
/* 959 */     return nGetUse24HourClock();
/*     */   }
/*     */   
/*     */   public void setUse24HourClock(boolean value) {
/* 963 */     nSetUse24HourClock(value);
/*     */   }
/*     */   
/*     */   private native boolean nGetUse24HourClock();
/*     */   
/*     */   private native void nSetUse24HourClock(boolean paramBoolean);
/*     */ }


/* Location:              C:\Users\rapha\Downloads\aurora.jar!\META-INF\jars\imgui-java-binding-1.90.0.jar!\imgui\extension\implot\ImPlotStyle.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */