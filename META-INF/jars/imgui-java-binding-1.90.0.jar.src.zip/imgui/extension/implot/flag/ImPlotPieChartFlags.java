package imgui.extension.implot.flag;

public final class ImPlotPieChartFlags {
  public static final int None = 0;
  
  public static final int Normalize = 1024;
  
  public static final int IgnoreHidden = 2048;
}


/* Location:              C:\Users\rapha\Downloads\aurora.jar!\META-INF\jars\imgui-java-binding-1.90.0.jar!\imgui\extension\implot\flag\ImPlotPieChartFlags.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */