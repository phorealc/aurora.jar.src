package imgui.extension.implot.flag;

public final class ImPlotBin {
  public static final int Sqrt = -1;
  
  public static final int Sturges = -2;
  
  public static final int Rice = -3;
  
  public static final int Scott = -4;
}


/* Location:              C:\Users\rapha\Downloads\aurora.jar!\META-INF\jars\imgui-java-binding-1.90.0.jar!\imgui\extension\implot\flag\ImPlotBin.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */