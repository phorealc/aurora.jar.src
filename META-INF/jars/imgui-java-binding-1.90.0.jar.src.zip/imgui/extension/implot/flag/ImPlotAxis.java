package imgui.extension.implot.flag;

public final class ImPlotAxis {
  public static final int X1 = 0;
  
  public static final int X2 = 1;
  
  public static final int X3 = 2;
  
  public static final int Y1 = 3;
  
  public static final int Y2 = 4;
  
  public static final int Y3 = 5;
  
  public static final int COUNT = 6;
}


/* Location:              C:\Users\rapha\Downloads\aurora.jar!\META-INF\jars\imgui-java-binding-1.90.0.jar!\imgui\extension\implot\flag\ImPlotAxis.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */