package imgui.extension.implot.flag;

public final class ImPlotFlags {
  public static final int None = 0;
  
  public static final int NoTitle = 1;
  
  public static final int NoLegend = 2;
  
  public static final int NoMouseText = 4;
  
  public static final int NoInputs = 8;
  
  public static final int NoMenus = 16;
  
  public static final int NoBoxSelect = 32;
  
  public static final int NoFrame = 64;
  
  public static final int Equal = 128;
  
  public static final int Crosshairs = 256;
  
  public static final int CanvasOnly = 55;
}


/* Location:              C:\Users\rapha\Downloads\aurora.jar!\META-INF\jars\imgui-java-binding-1.90.0.jar!\imgui\extension\implot\flag\ImPlotFlags.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */