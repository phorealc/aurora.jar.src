package imgui.extension.implot.flag;

public final class ImPlotLocation {
  public static final int Center = 0;
  
  public static final int North = 1;
  
  public static final int South = 2;
  
  public static final int West = 4;
  
  public static final int East = 8;
  
  public static final int NorthWest = 5;
  
  public static final int NorthEast = 9;
  
  public static final int SouthWest = 6;
  
  public static final int SouthEast = 10;
}


/* Location:              C:\Users\rapha\Downloads\aurora.jar!\META-INF\jars\imgui-java-binding-1.90.0.jar!\imgui\extension\implot\flag\ImPlotLocation.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */