package imgui.extension.implot.flag;

public final class ImPlotScatterFlags {
  public static final int None = 0;
  
  public static final int NoClip = 1024;
}


/* Location:              C:\Users\rapha\Downloads\aurora.jar!\META-INF\jars\imgui-java-binding-1.90.0.jar!\imgui\extension\implot\flag\ImPlotScatterFlags.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */