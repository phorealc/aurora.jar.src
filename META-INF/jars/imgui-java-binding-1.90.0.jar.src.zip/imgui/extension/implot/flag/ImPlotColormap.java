package imgui.extension.implot.flag;

public final class ImPlotColormap {
  public static final int Deep = 0;
  
  public static final int Dark = 1;
  
  public static final int Pastel = 2;
  
  public static final int Paired = 3;
  
  public static final int Viridis = 4;
  
  public static final int Plasma = 5;
  
  public static final int Hot = 6;
  
  public static final int Cool = 7;
  
  public static final int Pink = 8;
  
  public static final int Jet = 9;
  
  public static final int Twilight = 10;
  
  public static final int RdBu = 11;
  
  public static final int BrBG = 12;
  
  public static final int PiYG = 13;
  
  public static final int Spectral = 14;
  
  public static final int Greys = 15;
}


/* Location:              C:\Users\rapha\Downloads\aurora.jar!\META-INF\jars\imgui-java-binding-1.90.0.jar!\imgui\extension\implot\flag\ImPlotColormap.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */