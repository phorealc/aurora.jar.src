package imgui.extension.implot.flag;

public final class ImPlotScale {
  public static final int Linear = 0;
  
  public static final int Time = 1;
  
  public static final int Log10 = 2;
  
  public static final int SymLog = 3;
}


/* Location:              C:\Users\rapha\Downloads\aurora.jar!\META-INF\jars\imgui-java-binding-1.90.0.jar!\imgui\extension\implot\flag\ImPlotScale.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */