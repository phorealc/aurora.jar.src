package imgui.extension.implot.flag;

public final class ImPlotDragToolFlags {
  public static final int None = 0;
  
  public static final int NoCursors = 1;
  
  public static final int NoFit = 2;
  
  public static final int NoInputs = 4;
  
  public static final int Delayed = 8;
}


/* Location:              C:\Users\rapha\Downloads\aurora.jar!\META-INF\jars\imgui-java-binding-1.90.0.jar!\imgui\extension\implot\flag\ImPlotDragToolFlags.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */