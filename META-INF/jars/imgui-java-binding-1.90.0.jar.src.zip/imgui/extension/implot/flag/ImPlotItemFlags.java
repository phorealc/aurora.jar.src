package imgui.extension.implot.flag;

public final class ImPlotItemFlags {
  public static final int None = 0;
  
  public static final int NoLegend = 1;
  
  public static final int NoFit = 2;
}


/* Location:              C:\Users\rapha\Downloads\aurora.jar!\META-INF\jars\imgui-java-binding-1.90.0.jar!\imgui\extension\implot\flag\ImPlotItemFlags.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */