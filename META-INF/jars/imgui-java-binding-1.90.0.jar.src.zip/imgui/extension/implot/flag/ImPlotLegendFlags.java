package imgui.extension.implot.flag;

public final class ImPlotLegendFlags {
  public static final int None = 0;
  
  public static final int NoButtons = 1;
  
  public static final int NoHighlightItem = 2;
  
  public static final int NoHighlightAxis = 4;
  
  public static final int NoMenus = 8;
  
  public static final int Outside = 16;
  
  public static final int Horizontal = 32;
  
  public static final int Sort = 64;
}


/* Location:              C:\Users\rapha\Downloads\aurora.jar!\META-INF\jars\imgui-java-binding-1.90.0.jar!\imgui\extension\implot\flag\ImPlotLegendFlags.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */