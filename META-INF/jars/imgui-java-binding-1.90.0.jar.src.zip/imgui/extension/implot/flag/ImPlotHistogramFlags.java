package imgui.extension.implot.flag;

public final class ImPlotHistogramFlags {
  public static final int None = 0;
  
  public static final int Horizontal = 1024;
  
  public static final int Cumulative = 2048;
  
  public static final int Density = 4096;
  
  public static final int NoOutliers = 8192;
  
  public static final int ColMajor = 16384;
}


/* Location:              C:\Users\rapha\Downloads\aurora.jar!\META-INF\jars\imgui-java-binding-1.90.0.jar!\imgui\extension\implot\flag\ImPlotHistogramFlags.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */