package imgui.extension.implot.flag;

public final class ImPlotLineFlags {
  public static final int None = 0;
  
  public static final int Segments = 1024;
  
  public static final int Loop = 2048;
  
  public static final int SkipNaN = 4096;
  
  public static final int NoClip = 8192;
  
  public static final int Shaded = 16384;
}


/* Location:              C:\Users\rapha\Downloads\aurora.jar!\META-INF\jars\imgui-java-binding-1.90.0.jar!\imgui\extension\implot\flag\ImPlotLineFlags.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */