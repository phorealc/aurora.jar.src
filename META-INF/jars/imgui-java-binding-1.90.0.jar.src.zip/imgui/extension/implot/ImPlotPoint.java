/*    */ package imgui.extension.implot;
/*    */ 
/*    */ import imgui.ImVec2;
/*    */ import java.util.Objects;
/*    */ 
/*    */ public final class ImPlotPoint
/*    */   implements Cloneable
/*    */ {
/*    */   public double x;
/*    */   public double y;
/*    */   
/*    */   public ImPlotPoint() {}
/*    */   
/*    */   public ImPlotPoint(double x, double y) {
/* 15 */     set(x, y);
/*    */   }
/*    */   
/*    */   public ImPlotPoint(ImVec2 value) {
/* 19 */     set(value.x, value.y);
/*    */   }
/*    */   
/*    */   public ImPlotPoint(ImPlotPoint value) {
/* 23 */     set(value.x, value.y);
/*    */   }
/*    */   
/*    */   public ImPlotPoint set(double x, double y) {
/* 27 */     this.x = x;
/* 28 */     this.y = y;
/* 29 */     return this;
/*    */   }
/*    */   
/*    */   public ImPlotPoint set(ImPlotPoint value) {
/* 33 */     return set(value.x, value.y);
/*    */   }
/*    */   
/*    */   public ImPlotPoint set(ImVec2 value) {
/* 37 */     return set(value.x, value.y);
/*    */   }
/*    */   
/*    */   public ImPlotPoint plus(double x, double y) {
/* 41 */     this.x += x;
/* 42 */     this.y += y;
/* 43 */     return this;
/*    */   }
/*    */   
/*    */   public ImPlotPoint plus(ImPlotPoint value) {
/* 47 */     return plus(value.x, value.y);
/*    */   }
/*    */   
/*    */   public ImPlotPoint minus(double x, double y) {
/* 51 */     this.x -= x;
/* 52 */     this.y -= y;
/* 53 */     return this;
/*    */   }
/*    */   
/*    */   public ImPlotPoint minus(ImPlotPoint value) {
/* 57 */     return minus(value.x, value.y);
/*    */   }
/*    */   
/*    */   public ImPlotPoint times(double x, double y) {
/* 61 */     this.x *= x;
/* 62 */     this.y *= y;
/* 63 */     return this;
/*    */   }
/*    */   
/*    */   public ImPlotPoint times(ImPlotPoint value) {
/* 67 */     return times(value.x, value.y);
/*    */   }
/*    */ 
/*    */   
/*    */   public String toString() {
/* 72 */     return "ImPlotPoint{x=" + this.x + ", y=" + this.y + '}';
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public boolean equals(Object o) {
/* 80 */     if (this == o) {
/* 81 */       return true;
/*    */     }
/* 83 */     if (o == null || getClass() != o.getClass()) {
/* 84 */       return false;
/*    */     }
/* 86 */     ImPlotPoint imPlotPoint = (ImPlotPoint)o;
/* 87 */     return (Double.compare(imPlotPoint.x, this.x) == 0 && Double.compare(imPlotPoint.y, this.y) == 0);
/*    */   }
/*    */ 
/*    */   
/*    */   public int hashCode() {
/* 92 */     return Objects.hash(new Object[] { Double.valueOf(this.x), Double.valueOf(this.y) });
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public ImPlotPoint clone() {
/* 98 */     return new ImPlotPoint(this);
/*    */   }
/*    */ }


/* Location:              C:\Users\rapha\Downloads\aurora.jar!\META-INF\jars\imgui-java-binding-1.90.0.jar!\imgui\extension\implot\ImPlotPoint.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */