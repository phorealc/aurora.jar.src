/*   */ package imgui.extension.implot;
/*   */ 
/*   */ import imgui.binding.ImGuiStruct;
/*   */ 
/*   */ public final class ImPlotContext extends ImGuiStruct {
/*   */   public ImPlotContext(long ptr) {
/* 7 */     super(ptr);
/*   */   }
/*   */ }


/* Location:              C:\Users\rapha\Downloads\aurora.jar!\META-INF\jars\imgui-java-binding-1.90.0.jar!\imgui\extension\implot\ImPlotContext.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */