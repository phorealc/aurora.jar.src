/*       */ package imgui.extension.implot;
/*       */ 
/*       */ import imgui.ImDrawList;
/*       */ import imgui.ImVec2;
/*       */ import imgui.ImVec4;
/*       */ import imgui.internal.ImGuiContext;
/*       */ import imgui.type.ImBoolean;
/*       */ import imgui.type.ImDouble;
/*       */ import imgui.type.ImFloat;
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ public final class ImPlot
/*       */ {
/*       */   public static ImPlotContext createContext() {
/*    27 */     return new ImPlotContext(nCreateContext());
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   private static native long nCreateContext();
/*       */ 
/*       */ 
/*       */   
/*       */   public static void destroyContext() {
/*    38 */     nDestroyContext();
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static void destroyContext(ImPlotContext ctx) {
/*    45 */     nDestroyContext(ctx.ptr);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   private static native void nDestroyContext();
/*       */ 
/*       */ 
/*       */   
/*       */   private static native void nDestroyContext(long paramLong);
/*       */ 
/*       */ 
/*       */   
/*       */   public static ImPlotContext getCurrentContext() {
/*    60 */     return new ImPlotContext(nGetCurrentContext());
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   private static native long nGetCurrentContext();
/*       */ 
/*       */ 
/*       */   
/*       */   public static void setCurrentContext(ImPlotContext ctx) {
/*    71 */     nSetCurrentContext(ctx.ptr);
/*       */   }
/*       */ 
/*       */   
/*       */   private static native void nSetCurrentContext(long paramLong);
/*       */ 
/*       */   
/*       */   public static void setImGuiContext(ImGuiContext ctx) {
/*    79 */     nSetImGuiContext(ctx.ptr);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   private static native void nSetImGuiContext(long paramLong);
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static boolean beginPlot(String titleId) {
/*   108 */     return nBeginPlot(titleId);
/*       */   }
/*       */   
/*       */   public static boolean beginPlot(String titleId, ImVec2 size) {
/*   112 */     return nBeginPlot(titleId, size.x, size.y);
/*       */   }
/*       */   
/*       */   public static boolean beginPlot(String titleId, float sizeX, float sizeY) {
/*   116 */     return nBeginPlot(titleId, sizeX, sizeY);
/*       */   }
/*       */   
/*       */   public static boolean beginPlot(String titleId, ImVec2 size, int flags) {
/*   120 */     return nBeginPlot(titleId, size.x, size.y, flags);
/*       */   }
/*       */   
/*       */   public static boolean beginPlot(String titleId, float sizeX, float sizeY, int flags) {
/*   124 */     return nBeginPlot(titleId, sizeX, sizeY, flags);
/*       */   }
/*       */   
/*       */   public static boolean beginPlot(String titleId, int flags) {
/*   128 */     return nBeginPlot(titleId, flags);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   private static native boolean nBeginPlot(String paramString);
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   private static native boolean nBeginPlot(String paramString, float paramFloat1, float paramFloat2);
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   private static native boolean nBeginPlot(String paramString, float paramFloat1, float paramFloat2, int paramInt);
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   private static native boolean nBeginPlot(String paramString, int paramInt);
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static void endPlot() {
/*   166 */     nEndPlot();
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   private static native void nEndPlot();
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static boolean beginSubplots(String titleID, int rows, int cols, ImVec2 size) {
/*   224 */     return nBeginSubplots(titleID, rows, cols, size.x, size.y);
/*       */   }
/*       */   
/*       */   public static boolean beginSubplots(String titleID, int rows, int cols, float sizeX, float sizeY) {
/*   228 */     return nBeginSubplots(titleID, rows, cols, sizeX, sizeY);
/*       */   }
/*       */   
/*       */   public static boolean beginSubplots(String titleID, int rows, int cols, ImVec2 size, int flags) {
/*   232 */     return nBeginSubplots(titleID, rows, cols, size.x, size.y, flags);
/*       */   }
/*       */   
/*       */   public static boolean beginSubplots(String titleID, int rows, int cols, float sizeX, float sizeY, int flags) {
/*   236 */     return nBeginSubplots(titleID, rows, cols, sizeX, sizeY, flags);
/*       */   }
/*       */   
/*       */   public static boolean beginSubplots(String titleID, int rows, int cols, ImVec2 size, int flags, float[] rowRatios) {
/*   240 */     return nBeginSubplots(titleID, rows, cols, size.x, size.y, flags, rowRatios);
/*       */   }
/*       */   
/*       */   public static boolean beginSubplots(String titleID, int rows, int cols, float sizeX, float sizeY, int flags, float[] rowRatios) {
/*   244 */     return nBeginSubplots(titleID, rows, cols, sizeX, sizeY, flags, rowRatios);
/*       */   }
/*       */   
/*       */   public static boolean beginSubplots(String titleID, int rows, int cols, ImVec2 size, int flags, float[] rowRatios, float[] colRatios) {
/*   248 */     return nBeginSubplots(titleID, rows, cols, size.x, size.y, flags, rowRatios, colRatios);
/*       */   }
/*       */   
/*       */   public static boolean beginSubplots(String titleID, int rows, int cols, float sizeX, float sizeY, int flags, float[] rowRatios, float[] colRatios) {
/*   252 */     return nBeginSubplots(titleID, rows, cols, sizeX, sizeY, flags, rowRatios, colRatios);
/*       */   }
/*       */   
/*       */   public static boolean beginSubplots(String titleID, int rows, int cols, ImVec2 size, float[] rowRatios, float[] colRatios) {
/*   256 */     return nBeginSubplots(titleID, rows, cols, size.x, size.y, rowRatios, colRatios);
/*       */   }
/*       */   
/*       */   public static boolean beginSubplots(String titleID, int rows, int cols, float sizeX, float sizeY, float[] rowRatios, float[] colRatios) {
/*   260 */     return nBeginSubplots(titleID, rows, cols, sizeX, sizeY, rowRatios, colRatios);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   private static native boolean nBeginSubplots(String paramString, int paramInt1, int paramInt2, float paramFloat1, float paramFloat2);
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   private static native boolean nBeginSubplots(String paramString, int paramInt1, int paramInt2, float paramFloat1, float paramFloat2, int paramInt3);
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   private static native boolean nBeginSubplots(String paramString, int paramInt1, int paramInt2, float paramFloat1, float paramFloat2, int paramInt3, float[] paramArrayOffloat);
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   private static native boolean nBeginSubplots(String paramString, int paramInt1, int paramInt2, float paramFloat1, float paramFloat2, int paramInt3, float[] paramArrayOffloat1, float[] paramArrayOffloat2);
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   private static native boolean nBeginSubplots(String paramString, int paramInt1, int paramInt2, float paramFloat1, float paramFloat2, float[] paramArrayOffloat1, float[] paramArrayOffloat2);
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static void endSubplots() {
/*   318 */     nEndSubplots();
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   private static native void nEndSubplots();
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static void setupAxis(int axis) {
/*   359 */     nSetupAxis(axis);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static void setupAxis(int axis, String label) {
/*   367 */     nSetupAxis(axis, label);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static void setupAxis(int axis, String label, int flags) {
/*   375 */     nSetupAxis(axis, label, flags);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static void setupAxis(int axis, int flags) {
/*   383 */     nSetupAxis(axis, flags);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   private static native void nSetupAxis(int paramInt);
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   private static native void nSetupAxis(int paramInt, String paramString);
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   private static native void nSetupAxis(int paramInt1, String paramString, int paramInt2);
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   private static native void nSetupAxis(int paramInt1, int paramInt2);
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static void setupAxisLimits(int axis, double vMin, double vMax) {
/*   411 */     nSetupAxisLimits(axis, vMin, vMax);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static void setupAxisLimits(int axis, double vMin, double vMax, int cond) {
/*   419 */     nSetupAxisLimits(axis, vMin, vMax, cond);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   private static native void nSetupAxisLimits(int paramInt, double paramDouble1, double paramDouble2);
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   private static native void nSetupAxisLimits(int paramInt1, double paramDouble1, double paramDouble2, int paramInt2);
/*       */ 
/*       */ 
/*       */   
/*       */   public static void setupAxisLinks(int axis, ImDouble linkMin, ImDouble linkMax) {
/*   435 */     nSetupAxisLinks(axis, (linkMin != null) ? linkMin.getData() : null, (linkMax != null) ? linkMax.getData() : null);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   private static native void nSetupAxisLinks(int paramInt, double[] paramArrayOfdouble1, double[] paramArrayOfdouble2);
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static void setupAxisFormat(int axis, String fmt) {
/*   451 */     nSetupAxisFormat(axis, fmt);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   private static native void nSetupAxisFormat(int paramInt, String paramString);
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static void setupAxisTicks(int axis, double[] values, int nTicks) {
/*   467 */     nSetupAxisTicks(axis, values, nTicks);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static void setupAxisTicks(int axis, double[] values, int nTicks, String[] labels) {
/*   475 */     nSetupAxisTicks(axis, values, nTicks, labels, labels.length);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static void setupAxisTicks(int axis, double[] values, int nTicks, String[] labels, boolean keepDefault) {
/*   483 */     nSetupAxisTicks(axis, values, nTicks, labels, labels.length, keepDefault);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static void setupAxisTicks(int axis, double[] values, int nTicks, boolean keepDefault) {
/*   491 */     nSetupAxisTicks(axis, values, nTicks, keepDefault);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   private static native void nSetupAxisTicks(int paramInt1, double[] paramArrayOfdouble, int paramInt2);
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   private static native void nSetupAxisTicks(int paramInt1, double[] paramArrayOfdouble, int paramInt2, String[] paramArrayOfString, int paramInt3);
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   private static native void nSetupAxisTicks(int paramInt1, double[] paramArrayOfdouble, int paramInt2, String[] paramArrayOfString, int paramInt3, boolean paramBoolean);
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   private static native void nSetupAxisTicks(int paramInt1, double[] paramArrayOfdouble, int paramInt2, boolean paramBoolean);
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static void setupAxisTicks(int axis, double vMin, double vMax, int nTicks) {
/*   543 */     nSetupAxisTicks(axis, vMin, vMax, nTicks);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static void setupAxisTicks(int axis, double vMin, double vMax, int nTicks, String[] labels) {
/*   551 */     nSetupAxisTicks(axis, vMin, vMax, nTicks, labels, labels.length);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static void setupAxisTicks(int axis, double vMin, double vMax, int nTicks, String[] labels, boolean keepDefault) {
/*   559 */     nSetupAxisTicks(axis, vMin, vMax, nTicks, labels, labels.length, keepDefault);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static void setupAxisTicks(int axis, double vMin, double vMax, int nTicks, boolean keepDefault) {
/*   567 */     nSetupAxisTicks(axis, vMin, vMax, nTicks, keepDefault);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   private static native void nSetupAxisTicks(int paramInt1, double paramDouble1, double paramDouble2, int paramInt2);
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   private static native void nSetupAxisTicks(int paramInt1, double paramDouble1, double paramDouble2, int paramInt2, String[] paramArrayOfString, int paramInt3);
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   private static native void nSetupAxisTicks(int paramInt1, double paramDouble1, double paramDouble2, int paramInt2, String[] paramArrayOfString, int paramInt3, boolean paramBoolean);
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   private static native void nSetupAxisTicks(int paramInt1, double paramDouble1, double paramDouble2, int paramInt2, boolean paramBoolean);
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static void setupAxisScale(int axis, int scale) {
/*   610 */     nSetupAxisScale(axis, scale);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   private static native void nSetupAxisScale(int paramInt1, int paramInt2);
/*       */ 
/*       */ 
/*       */   
/*       */   public static void setupAxisLimitsConstraints(int axis, double vMin, double vMax) {
/*   621 */     nSetupAxisLimitsConstraints(axis, vMin, vMax);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   private static native void nSetupAxisLimitsConstraints(int paramInt, double paramDouble1, double paramDouble2);
/*       */ 
/*       */ 
/*       */   
/*       */   public static void setupAxisZoomConstraints(int axis, double vMin, double vMax) {
/*   632 */     nSetupAxisZoomConstraints(axis, vMin, vMax);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   private static native void nSetupAxisZoomConstraints(int paramInt, double paramDouble1, double paramDouble2);
/*       */ 
/*       */ 
/*       */   
/*       */   public static void setupAxes(String xLabel, String yLabel) {
/*   643 */     nSetupAxes(xLabel, yLabel);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static void setupAxes(String xLabel, String yLabel, int xFlags) {
/*   650 */     nSetupAxes(xLabel, yLabel, xFlags);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static void setupAxes(String xLabel, String yLabel, int xFlags, int yFlags) {
/*   657 */     nSetupAxes(xLabel, yLabel, xFlags, yFlags);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   private static native void nSetupAxes(String paramString1, String paramString2);
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   private static native void nSetupAxes(String paramString1, String paramString2, int paramInt);
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   private static native void nSetupAxes(String paramString1, String paramString2, int paramInt1, int paramInt2);
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static void setupAxesLimits(double xMin, double xMax, double yMin, double yMax) {
/*   689 */     nSetupAxesLimits(xMin, xMax, yMin, yMax);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static void setupAxesLimits(double xMin, double xMax, double yMin, double yMax, int cond) {
/*   697 */     nSetupAxesLimits(xMin, xMax, yMin, yMax, cond);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   private static native void nSetupAxesLimits(double paramDouble1, double paramDouble2, double paramDouble3, double paramDouble4);
/*       */ 
/*       */ 
/*       */   
/*       */   private static native void nSetupAxesLimits(double paramDouble1, double paramDouble2, double paramDouble3, double paramDouble4, int paramInt);
/*       */ 
/*       */ 
/*       */   
/*       */   public static void setupLegend(int location) {
/*   712 */     nSetupLegend(location);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static void setupLegend(int location, int flags) {
/*   719 */     nSetupLegend(location, flags);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   private static native void nSetupLegend(int paramInt);
/*       */ 
/*       */ 
/*       */   
/*       */   private static native void nSetupLegend(int paramInt1, int paramInt2);
/*       */ 
/*       */ 
/*       */   
/*       */   public static void setupMouseText(int location) {
/*   734 */     nSetupMouseText(location);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static void setupMouseText(int location, int flags) {
/*   741 */     nSetupMouseText(location, flags);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   private static native void nSetupMouseText(int paramInt);
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   private static native void nSetupMouseText(int paramInt1, int paramInt2);
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static void setupFinish() {
/*   758 */     nSetupFinish();
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   private static native void nSetupFinish();
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static void setNextAxisLimits(int axis, double vMin, double vMax) {
/*   792 */     nSetNextAxisLimits(axis, vMin, vMax);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static void setNextAxisLimits(int axis, double vMin, double vMax, int cond) {
/*   799 */     nSetNextAxisLimits(axis, vMin, vMax, cond);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   private static native void nSetNextAxisLimits(int paramInt, double paramDouble1, double paramDouble2);
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   private static native void nSetNextAxisLimits(int paramInt1, double paramDouble1, double paramDouble2, int paramInt2);
/*       */ 
/*       */ 
/*       */   
/*       */   public static void setNextAxisLinks(int axis, ImDouble linkMin, ImDouble linkMax) {
/*   815 */     nSetNextAxisLinks(axis, (linkMin != null) ? linkMin.getData() : null, (linkMax != null) ? linkMax.getData() : null);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   private static native void nSetNextAxisLinks(int paramInt, double[] paramArrayOfdouble1, double[] paramArrayOfdouble2);
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static void setNextAxisToFit(int axis) {
/*   830 */     nSetNextAxisToFit(axis);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   private static native void nSetNextAxisToFit(int paramInt);
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static void setNextAxesLimits(double xMin, double xMax, double yMin, double yMax) {
/*   842 */     nSetNextAxesLimits(xMin, xMax, yMin, yMax);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static void setNextAxesLimits(double xMin, double xMax, double yMin, double yMax, int cond) {
/*   850 */     nSetNextAxesLimits(xMin, xMax, yMin, yMax, cond);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   private static native void nSetNextAxesLimits(double paramDouble1, double paramDouble2, double paramDouble3, double paramDouble4);
/*       */ 
/*       */ 
/*       */   
/*       */   private static native void nSetNextAxesLimits(double paramDouble1, double paramDouble2, double paramDouble3, double paramDouble4, int paramInt);
/*       */ 
/*       */ 
/*       */   
/*       */   public static void setNextAxesToFit() {
/*   865 */     nSetNextAxesToFit();
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   private static native void nSetNextAxesToFit();
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static void plotLine(String labelId, short[] values) {
/*   936 */     nPlotLine(labelId, values);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static void plotLine(String labelId, short[] values, double xscale) {
/*   943 */     nPlotLine(labelId, values, xscale);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static void plotLine(String labelId, short[] values, double xscale, double xstart) {
/*   950 */     nPlotLine(labelId, values, xscale, xstart);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static void plotLine(String labelId, short[] values, double xscale, double xstart, int flags) {
/*   957 */     nPlotLine(labelId, values, xscale, xstart, flags);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static void plotLine(String labelId, short[] values, double xscale, double xstart, int flags, int offset) {
/*   964 */     nPlotLine(labelId, values, xscale, xstart, flags, offset);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   private static native void nPlotLine(String paramString, short[] paramArrayOfshort);
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   private static native void nPlotLine(String paramString, short[] paramArrayOfshort, double paramDouble);
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   private static native void nPlotLine(String paramString, short[] paramArrayOfshort, double paramDouble1, double paramDouble2);
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   private static native void nPlotLine(String paramString, short[] paramArrayOfshort, double paramDouble1, double paramDouble2, int paramInt);
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   private static native void nPlotLine(String paramString, short[] paramArrayOfshort, double paramDouble1, double paramDouble2, int paramInt1, int paramInt2);
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static void plotLine(String labelId, int[] values) {
/*  1011 */     nPlotLine(labelId, values);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static void plotLine(String labelId, int[] values, double xscale) {
/*  1018 */     nPlotLine(labelId, values, xscale);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static void plotLine(String labelId, int[] values, double xscale, double xstart) {
/*  1025 */     nPlotLine(labelId, values, xscale, xstart);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static void plotLine(String labelId, int[] values, double xscale, double xstart, int flags) {
/*  1032 */     nPlotLine(labelId, values, xscale, xstart, flags);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static void plotLine(String labelId, int[] values, double xscale, double xstart, int flags, int offset) {
/*  1039 */     nPlotLine(labelId, values, xscale, xstart, flags, offset);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   private static native void nPlotLine(String paramString, int[] paramArrayOfint);
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   private static native void nPlotLine(String paramString, int[] paramArrayOfint, double paramDouble);
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   private static native void nPlotLine(String paramString, int[] paramArrayOfint, double paramDouble1, double paramDouble2);
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   private static native void nPlotLine(String paramString, int[] paramArrayOfint, double paramDouble1, double paramDouble2, int paramInt);
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   private static native void nPlotLine(String paramString, int[] paramArrayOfint, double paramDouble1, double paramDouble2, int paramInt1, int paramInt2);
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static void plotLine(String labelId, long[] values) {
/*  1086 */     nPlotLine(labelId, values);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static void plotLine(String labelId, long[] values, double xscale) {
/*  1093 */     nPlotLine(labelId, values, xscale);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static void plotLine(String labelId, long[] values, double xscale, double xstart) {
/*  1100 */     nPlotLine(labelId, values, xscale, xstart);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static void plotLine(String labelId, long[] values, double xscale, double xstart, int flags) {
/*  1107 */     nPlotLine(labelId, values, xscale, xstart, flags);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static void plotLine(String labelId, long[] values, double xscale, double xstart, int flags, int offset) {
/*  1114 */     nPlotLine(labelId, values, xscale, xstart, flags, offset);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   private static native void nPlotLine(String paramString, long[] paramArrayOflong);
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   private static native void nPlotLine(String paramString, long[] paramArrayOflong, double paramDouble);
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   private static native void nPlotLine(String paramString, long[] paramArrayOflong, double paramDouble1, double paramDouble2);
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   private static native void nPlotLine(String paramString, long[] paramArrayOflong, double paramDouble1, double paramDouble2, int paramInt);
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   private static native void nPlotLine(String paramString, long[] paramArrayOflong, double paramDouble1, double paramDouble2, int paramInt1, int paramInt2);
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static void plotLine(String labelId, float[] values) {
/*  1161 */     nPlotLine(labelId, values);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static void plotLine(String labelId, float[] values, double xscale) {
/*  1168 */     nPlotLine(labelId, values, xscale);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static void plotLine(String labelId, float[] values, double xscale, double xstart) {
/*  1175 */     nPlotLine(labelId, values, xscale, xstart);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static void plotLine(String labelId, float[] values, double xscale, double xstart, int flags) {
/*  1182 */     nPlotLine(labelId, values, xscale, xstart, flags);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static void plotLine(String labelId, float[] values, double xscale, double xstart, int flags, int offset) {
/*  1189 */     nPlotLine(labelId, values, xscale, xstart, flags, offset);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   private static native void nPlotLine(String paramString, float[] paramArrayOffloat);
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   private static native void nPlotLine(String paramString, float[] paramArrayOffloat, double paramDouble);
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   private static native void nPlotLine(String paramString, float[] paramArrayOffloat, double paramDouble1, double paramDouble2);
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   private static native void nPlotLine(String paramString, float[] paramArrayOffloat, double paramDouble1, double paramDouble2, int paramInt);
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   private static native void nPlotLine(String paramString, float[] paramArrayOffloat, double paramDouble1, double paramDouble2, int paramInt1, int paramInt2);
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static void plotLine(String labelId, double[] values) {
/*  1236 */     nPlotLine(labelId, values);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static void plotLine(String labelId, double[] values, double xscale) {
/*  1243 */     nPlotLine(labelId, values, xscale);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static void plotLine(String labelId, double[] values, double xscale, double xstart) {
/*  1250 */     nPlotLine(labelId, values, xscale, xstart);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static void plotLine(String labelId, double[] values, double xscale, double xstart, int flags) {
/*  1257 */     nPlotLine(labelId, values, xscale, xstart, flags);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static void plotLine(String labelId, double[] values, double xscale, double xstart, int flags, int offset) {
/*  1264 */     nPlotLine(labelId, values, xscale, xstart, flags, offset);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   private static native void nPlotLine(String paramString, double[] paramArrayOfdouble);
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   private static native void nPlotLine(String paramString, double[] paramArrayOfdouble, double paramDouble);
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   private static native void nPlotLine(String paramString, double[] paramArrayOfdouble, double paramDouble1, double paramDouble2);
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   private static native void nPlotLine(String paramString, double[] paramArrayOfdouble, double paramDouble1, double paramDouble2, int paramInt);
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   private static native void nPlotLine(String paramString, double[] paramArrayOfdouble, double paramDouble1, double paramDouble2, int paramInt1, int paramInt2);
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static void plotLineV(String labelId, short[] values, int count) {
/*  1311 */     nPlotLineV(labelId, values, count);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static void plotLineV(String labelId, short[] values, int count, double xscale) {
/*  1318 */     nPlotLineV(labelId, values, count, xscale);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static void plotLineV(String labelId, short[] values, int count, double xscale, double xstart) {
/*  1325 */     nPlotLineV(labelId, values, count, xscale, xstart);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static void plotLineV(String labelId, short[] values, int count, double xscale, double xstart, int flags) {
/*  1332 */     nPlotLineV(labelId, values, count, xscale, xstart, flags);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static void plotLineV(String labelId, short[] values, int count, double xscale, double xstart, int flags, int offset) {
/*  1339 */     nPlotLineV(labelId, values, count, xscale, xstart, flags, offset);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   private static native void nPlotLineV(String paramString, short[] paramArrayOfshort, int paramInt);
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   private static native void nPlotLineV(String paramString, short[] paramArrayOfshort, int paramInt, double paramDouble);
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   private static native void nPlotLineV(String paramString, short[] paramArrayOfshort, int paramInt, double paramDouble1, double paramDouble2);
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   private static native void nPlotLineV(String paramString, short[] paramArrayOfshort, int paramInt1, double paramDouble1, double paramDouble2, int paramInt2);
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   private static native void nPlotLineV(String paramString, short[] paramArrayOfshort, int paramInt1, double paramDouble1, double paramDouble2, int paramInt2, int paramInt3);
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static void plotLineV(String labelId, int[] values, int count) {
/*  1386 */     nPlotLineV(labelId, values, count);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static void plotLineV(String labelId, int[] values, int count, double xscale) {
/*  1393 */     nPlotLineV(labelId, values, count, xscale);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static void plotLineV(String labelId, int[] values, int count, double xscale, double xstart) {
/*  1400 */     nPlotLineV(labelId, values, count, xscale, xstart);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static void plotLineV(String labelId, int[] values, int count, double xscale, double xstart, int flags) {
/*  1407 */     nPlotLineV(labelId, values, count, xscale, xstart, flags);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static void plotLineV(String labelId, int[] values, int count, double xscale, double xstart, int flags, int offset) {
/*  1414 */     nPlotLineV(labelId, values, count, xscale, xstart, flags, offset);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   private static native void nPlotLineV(String paramString, int[] paramArrayOfint, int paramInt);
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   private static native void nPlotLineV(String paramString, int[] paramArrayOfint, int paramInt, double paramDouble);
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   private static native void nPlotLineV(String paramString, int[] paramArrayOfint, int paramInt, double paramDouble1, double paramDouble2);
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   private static native void nPlotLineV(String paramString, int[] paramArrayOfint, int paramInt1, double paramDouble1, double paramDouble2, int paramInt2);
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   private static native void nPlotLineV(String paramString, int[] paramArrayOfint, int paramInt1, double paramDouble1, double paramDouble2, int paramInt2, int paramInt3);
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static void plotLineV(String labelId, long[] values, int count) {
/*  1461 */     nPlotLineV(labelId, values, count);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static void plotLineV(String labelId, long[] values, int count, double xscale) {
/*  1468 */     nPlotLineV(labelId, values, count, xscale);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static void plotLineV(String labelId, long[] values, int count, double xscale, double xstart) {
/*  1475 */     nPlotLineV(labelId, values, count, xscale, xstart);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static void plotLineV(String labelId, long[] values, int count, double xscale, double xstart, int flags) {
/*  1482 */     nPlotLineV(labelId, values, count, xscale, xstart, flags);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static void plotLineV(String labelId, long[] values, int count, double xscale, double xstart, int flags, int offset) {
/*  1489 */     nPlotLineV(labelId, values, count, xscale, xstart, flags, offset);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   private static native void nPlotLineV(String paramString, long[] paramArrayOflong, int paramInt);
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   private static native void nPlotLineV(String paramString, long[] paramArrayOflong, int paramInt, double paramDouble);
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   private static native void nPlotLineV(String paramString, long[] paramArrayOflong, int paramInt, double paramDouble1, double paramDouble2);
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   private static native void nPlotLineV(String paramString, long[] paramArrayOflong, int paramInt1, double paramDouble1, double paramDouble2, int paramInt2);
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   private static native void nPlotLineV(String paramString, long[] paramArrayOflong, int paramInt1, double paramDouble1, double paramDouble2, int paramInt2, int paramInt3);
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static void plotLineV(String labelId, float[] values, int count) {
/*  1536 */     nPlotLineV(labelId, values, count);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static void plotLineV(String labelId, float[] values, int count, double xscale) {
/*  1543 */     nPlotLineV(labelId, values, count, xscale);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static void plotLineV(String labelId, float[] values, int count, double xscale, double xstart) {
/*  1550 */     nPlotLineV(labelId, values, count, xscale, xstart);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static void plotLineV(String labelId, float[] values, int count, double xscale, double xstart, int flags) {
/*  1557 */     nPlotLineV(labelId, values, count, xscale, xstart, flags);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static void plotLineV(String labelId, float[] values, int count, double xscale, double xstart, int flags, int offset) {
/*  1564 */     nPlotLineV(labelId, values, count, xscale, xstart, flags, offset);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   private static native void nPlotLineV(String paramString, float[] paramArrayOffloat, int paramInt);
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   private static native void nPlotLineV(String paramString, float[] paramArrayOffloat, int paramInt, double paramDouble);
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   private static native void nPlotLineV(String paramString, float[] paramArrayOffloat, int paramInt, double paramDouble1, double paramDouble2);
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   private static native void nPlotLineV(String paramString, float[] paramArrayOffloat, int paramInt1, double paramDouble1, double paramDouble2, int paramInt2);
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   private static native void nPlotLineV(String paramString, float[] paramArrayOffloat, int paramInt1, double paramDouble1, double paramDouble2, int paramInt2, int paramInt3);
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static void plotLineV(String labelId, double[] values, int count) {
/*  1611 */     nPlotLineV(labelId, values, count);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static void plotLineV(String labelId, double[] values, int count, double xscale) {
/*  1618 */     nPlotLineV(labelId, values, count, xscale);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static void plotLineV(String labelId, double[] values, int count, double xscale, double xstart) {
/*  1625 */     nPlotLineV(labelId, values, count, xscale, xstart);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static void plotLineV(String labelId, double[] values, int count, double xscale, double xstart, int flags) {
/*  1632 */     nPlotLineV(labelId, values, count, xscale, xstart, flags);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static void plotLineV(String labelId, double[] values, int count, double xscale, double xstart, int flags, int offset) {
/*  1639 */     nPlotLineV(labelId, values, count, xscale, xstart, flags, offset);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   private static native void nPlotLineV(String paramString, double[] paramArrayOfdouble, int paramInt);
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   private static native void nPlotLineV(String paramString, double[] paramArrayOfdouble, int paramInt, double paramDouble);
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   private static native void nPlotLineV(String paramString, double[] paramArrayOfdouble, int paramInt, double paramDouble1, double paramDouble2);
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   private static native void nPlotLineV(String paramString, double[] paramArrayOfdouble, int paramInt1, double paramDouble1, double paramDouble2, int paramInt2);
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   private static native void nPlotLineV(String paramString, double[] paramArrayOfdouble, int paramInt1, double paramDouble1, double paramDouble2, int paramInt2, int paramInt3);
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static void plotLine(String labelId, short[] xs, short[] ys) {
/*  1688 */     nPlotLine(labelId, xs, ys);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static void plotLine(String labelId, short[] xs, short[] ys, int flags) {
/*  1695 */     nPlotLine(labelId, xs, ys, flags);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   private static native void nPlotLine(String paramString, short[] paramArrayOfshort1, short[] paramArrayOfshort2);
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   private static native void nPlotLine(String paramString, short[] paramArrayOfshort1, short[] paramArrayOfshort2, int paramInt);
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static void plotLine(String labelId, int[] xs, int[] ys) {
/*  1722 */     nPlotLine(labelId, xs, ys);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static void plotLine(String labelId, int[] xs, int[] ys, int flags) {
/*  1729 */     nPlotLine(labelId, xs, ys, flags);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   private static native void nPlotLine(String paramString, int[] paramArrayOfint1, int[] paramArrayOfint2);
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   private static native void nPlotLine(String paramString, int[] paramArrayOfint1, int[] paramArrayOfint2, int paramInt);
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static void plotLine(String labelId, long[] xs, long[] ys) {
/*  1756 */     nPlotLine(labelId, xs, ys);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static void plotLine(String labelId, long[] xs, long[] ys, int flags) {
/*  1763 */     nPlotLine(labelId, xs, ys, flags);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   private static native void nPlotLine(String paramString, long[] paramArrayOflong1, long[] paramArrayOflong2);
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   private static native void nPlotLine(String paramString, long[] paramArrayOflong1, long[] paramArrayOflong2, int paramInt);
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static void plotLine(String labelId, float[] xs, float[] ys) {
/*  1790 */     nPlotLine(labelId, xs, ys);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static void plotLine(String labelId, float[] xs, float[] ys, int flags) {
/*  1797 */     nPlotLine(labelId, xs, ys, flags);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   private static native void nPlotLine(String paramString, float[] paramArrayOffloat1, float[] paramArrayOffloat2);
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   private static native void nPlotLine(String paramString, float[] paramArrayOffloat1, float[] paramArrayOffloat2, int paramInt);
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static void plotLine(String labelId, double[] xs, double[] ys) {
/*  1824 */     nPlotLine(labelId, xs, ys);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static void plotLine(String labelId, double[] xs, double[] ys, int flags) {
/*  1831 */     nPlotLine(labelId, xs, ys, flags);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   private static native void nPlotLine(String paramString, double[] paramArrayOfdouble1, double[] paramArrayOfdouble2);
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   private static native void nPlotLine(String paramString, double[] paramArrayOfdouble1, double[] paramArrayOfdouble2, int paramInt);
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static void plotLineV(String labelId, short[] xs, short[] ys, int count) {
/*  1858 */     nPlotLineV(labelId, xs, ys, count);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static void plotLineV(String labelId, short[] xs, short[] ys, int count, int flags) {
/*  1865 */     nPlotLineV(labelId, xs, ys, count, flags);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static void plotLineV(String labelId, short[] xs, short[] ys, int count, int flags, int offset) {
/*  1872 */     nPlotLineV(labelId, xs, ys, count, flags, offset);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   private static native void nPlotLineV(String paramString, short[] paramArrayOfshort1, short[] paramArrayOfshort2, int paramInt);
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   private static native void nPlotLineV(String paramString, short[] paramArrayOfshort1, short[] paramArrayOfshort2, int paramInt1, int paramInt2);
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   private static native void nPlotLineV(String paramString, short[] paramArrayOfshort1, short[] paramArrayOfshort2, int paramInt1, int paramInt2, int paramInt3);
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static void plotLineV(String labelId, int[] xs, int[] ys, int count) {
/*  1909 */     nPlotLineV(labelId, xs, ys, count);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static void plotLineV(String labelId, int[] xs, int[] ys, int count, int flags) {
/*  1916 */     nPlotLineV(labelId, xs, ys, count, flags);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static void plotLineV(String labelId, int[] xs, int[] ys, int count, int flags, int offset) {
/*  1923 */     nPlotLineV(labelId, xs, ys, count, flags, offset);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   private static native void nPlotLineV(String paramString, int[] paramArrayOfint1, int[] paramArrayOfint2, int paramInt);
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   private static native void nPlotLineV(String paramString, int[] paramArrayOfint1, int[] paramArrayOfint2, int paramInt1, int paramInt2);
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   private static native void nPlotLineV(String paramString, int[] paramArrayOfint1, int[] paramArrayOfint2, int paramInt1, int paramInt2, int paramInt3);
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static void plotLineV(String labelId, long[] xs, long[] ys, int count) {
/*  1960 */     nPlotLineV(labelId, xs, ys, count);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static void plotLineV(String labelId, long[] xs, long[] ys, int count, int flags) {
/*  1967 */     nPlotLineV(labelId, xs, ys, count, flags);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static void plotLineV(String labelId, long[] xs, long[] ys, int count, int flags, int offset) {
/*  1974 */     nPlotLineV(labelId, xs, ys, count, flags, offset);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   private static native void nPlotLineV(String paramString, long[] paramArrayOflong1, long[] paramArrayOflong2, int paramInt);
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   private static native void nPlotLineV(String paramString, long[] paramArrayOflong1, long[] paramArrayOflong2, int paramInt1, int paramInt2);
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   private static native void nPlotLineV(String paramString, long[] paramArrayOflong1, long[] paramArrayOflong2, int paramInt1, int paramInt2, int paramInt3);
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static void plotLineV(String labelId, float[] xs, float[] ys, int count) {
/*  2011 */     nPlotLineV(labelId, xs, ys, count);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static void plotLineV(String labelId, float[] xs, float[] ys, int count, int flags) {
/*  2018 */     nPlotLineV(labelId, xs, ys, count, flags);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static void plotLineV(String labelId, float[] xs, float[] ys, int count, int flags, int offset) {
/*  2025 */     nPlotLineV(labelId, xs, ys, count, flags, offset);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   private static native void nPlotLineV(String paramString, float[] paramArrayOffloat1, float[] paramArrayOffloat2, int paramInt);
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   private static native void nPlotLineV(String paramString, float[] paramArrayOffloat1, float[] paramArrayOffloat2, int paramInt1, int paramInt2);
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   private static native void nPlotLineV(String paramString, float[] paramArrayOffloat1, float[] paramArrayOffloat2, int paramInt1, int paramInt2, int paramInt3);
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static void plotLineV(String labelId, double[] xs, double[] ys, int count) {
/*  2062 */     nPlotLineV(labelId, xs, ys, count);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static void plotLineV(String labelId, double[] xs, double[] ys, int count, int flags) {
/*  2069 */     nPlotLineV(labelId, xs, ys, count, flags);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static void plotLineV(String labelId, double[] xs, double[] ys, int count, int flags, int offset) {
/*  2076 */     nPlotLineV(labelId, xs, ys, count, flags, offset);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   private static native void nPlotLineV(String paramString, double[] paramArrayOfdouble1, double[] paramArrayOfdouble2, int paramInt);
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   private static native void nPlotLineV(String paramString, double[] paramArrayOfdouble1, double[] paramArrayOfdouble2, int paramInt1, int paramInt2);
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   private static native void nPlotLineV(String paramString, double[] paramArrayOfdouble1, double[] paramArrayOfdouble2, int paramInt1, int paramInt2, int paramInt3);
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static void plotScatter(String labelId, short[] values) {
/*  2115 */     nPlotScatter(labelId, values);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static void plotScatter(String labelId, short[] values, double xscale) {
/*  2122 */     nPlotScatter(labelId, values, xscale);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static void plotScatter(String labelId, short[] values, double xscale, double xstart) {
/*  2129 */     nPlotScatter(labelId, values, xscale, xstart);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static void plotScatter(String labelId, short[] values, double xscale, double xstart, int flags) {
/*  2136 */     nPlotScatter(labelId, values, xscale, xstart, flags);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static void plotScatter(String labelId, short[] values, double xscale, double xstart, int flags, int offset) {
/*  2143 */     nPlotScatter(labelId, values, xscale, xstart, flags, offset);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   private static native void nPlotScatter(String paramString, short[] paramArrayOfshort);
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   private static native void nPlotScatter(String paramString, short[] paramArrayOfshort, double paramDouble);
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   private static native void nPlotScatter(String paramString, short[] paramArrayOfshort, double paramDouble1, double paramDouble2);
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   private static native void nPlotScatter(String paramString, short[] paramArrayOfshort, double paramDouble1, double paramDouble2, int paramInt);
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   private static native void nPlotScatter(String paramString, short[] paramArrayOfshort, double paramDouble1, double paramDouble2, int paramInt1, int paramInt2);
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static void plotScatter(String labelId, int[] values) {
/*  2190 */     nPlotScatter(labelId, values);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static void plotScatter(String labelId, int[] values, double xscale) {
/*  2197 */     nPlotScatter(labelId, values, xscale);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static void plotScatter(String labelId, int[] values, double xscale, double xstart) {
/*  2204 */     nPlotScatter(labelId, values, xscale, xstart);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static void plotScatter(String labelId, int[] values, double xscale, double xstart, int flags) {
/*  2211 */     nPlotScatter(labelId, values, xscale, xstart, flags);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static void plotScatter(String labelId, int[] values, double xscale, double xstart, int flags, int offset) {
/*  2218 */     nPlotScatter(labelId, values, xscale, xstart, flags, offset);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   private static native void nPlotScatter(String paramString, int[] paramArrayOfint);
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   private static native void nPlotScatter(String paramString, int[] paramArrayOfint, double paramDouble);
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   private static native void nPlotScatter(String paramString, int[] paramArrayOfint, double paramDouble1, double paramDouble2);
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   private static native void nPlotScatter(String paramString, int[] paramArrayOfint, double paramDouble1, double paramDouble2, int paramInt);
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   private static native void nPlotScatter(String paramString, int[] paramArrayOfint, double paramDouble1, double paramDouble2, int paramInt1, int paramInt2);
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static void plotScatter(String labelId, long[] values) {
/*  2265 */     nPlotScatter(labelId, values);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static void plotScatter(String labelId, long[] values, double xscale) {
/*  2272 */     nPlotScatter(labelId, values, xscale);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static void plotScatter(String labelId, long[] values, double xscale, double xstart) {
/*  2279 */     nPlotScatter(labelId, values, xscale, xstart);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static void plotScatter(String labelId, long[] values, double xscale, double xstart, int flags) {
/*  2286 */     nPlotScatter(labelId, values, xscale, xstart, flags);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static void plotScatter(String labelId, long[] values, double xscale, double xstart, int flags, int offset) {
/*  2293 */     nPlotScatter(labelId, values, xscale, xstart, flags, offset);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   private static native void nPlotScatter(String paramString, long[] paramArrayOflong);
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   private static native void nPlotScatter(String paramString, long[] paramArrayOflong, double paramDouble);
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   private static native void nPlotScatter(String paramString, long[] paramArrayOflong, double paramDouble1, double paramDouble2);
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   private static native void nPlotScatter(String paramString, long[] paramArrayOflong, double paramDouble1, double paramDouble2, int paramInt);
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   private static native void nPlotScatter(String paramString, long[] paramArrayOflong, double paramDouble1, double paramDouble2, int paramInt1, int paramInt2);
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static void plotScatter(String labelId, float[] values) {
/*  2340 */     nPlotScatter(labelId, values);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static void plotScatter(String labelId, float[] values, double xscale) {
/*  2347 */     nPlotScatter(labelId, values, xscale);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static void plotScatter(String labelId, float[] values, double xscale, double xstart) {
/*  2354 */     nPlotScatter(labelId, values, xscale, xstart);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static void plotScatter(String labelId, float[] values, double xscale, double xstart, int flags) {
/*  2361 */     nPlotScatter(labelId, values, xscale, xstart, flags);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static void plotScatter(String labelId, float[] values, double xscale, double xstart, int flags, int offset) {
/*  2368 */     nPlotScatter(labelId, values, xscale, xstart, flags, offset);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   private static native void nPlotScatter(String paramString, float[] paramArrayOffloat);
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   private static native void nPlotScatter(String paramString, float[] paramArrayOffloat, double paramDouble);
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   private static native void nPlotScatter(String paramString, float[] paramArrayOffloat, double paramDouble1, double paramDouble2);
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   private static native void nPlotScatter(String paramString, float[] paramArrayOffloat, double paramDouble1, double paramDouble2, int paramInt);
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   private static native void nPlotScatter(String paramString, float[] paramArrayOffloat, double paramDouble1, double paramDouble2, int paramInt1, int paramInt2);
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static void plotScatter(String labelId, double[] values) {
/*  2415 */     nPlotScatter(labelId, values);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static void plotScatter(String labelId, double[] values, double xscale) {
/*  2422 */     nPlotScatter(labelId, values, xscale);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static void plotScatter(String labelId, double[] values, double xscale, double xstart) {
/*  2429 */     nPlotScatter(labelId, values, xscale, xstart);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static void plotScatter(String labelId, double[] values, double xscale, double xstart, int flags) {
/*  2436 */     nPlotScatter(labelId, values, xscale, xstart, flags);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static void plotScatter(String labelId, double[] values, double xscale, double xstart, int flags, int offset) {
/*  2443 */     nPlotScatter(labelId, values, xscale, xstart, flags, offset);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   private static native void nPlotScatter(String paramString, double[] paramArrayOfdouble);
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   private static native void nPlotScatter(String paramString, double[] paramArrayOfdouble, double paramDouble);
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   private static native void nPlotScatter(String paramString, double[] paramArrayOfdouble, double paramDouble1, double paramDouble2);
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   private static native void nPlotScatter(String paramString, double[] paramArrayOfdouble, double paramDouble1, double paramDouble2, int paramInt);
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   private static native void nPlotScatter(String paramString, double[] paramArrayOfdouble, double paramDouble1, double paramDouble2, int paramInt1, int paramInt2);
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static void plotScatterV(String labelId, short[] values, int count) {
/*  2490 */     nPlotScatterV(labelId, values, count);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static void plotScatterV(String labelId, short[] values, int count, double xscale) {
/*  2497 */     nPlotScatterV(labelId, values, count, xscale);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static void plotScatterV(String labelId, short[] values, int count, double xscale, double xstart) {
/*  2504 */     nPlotScatterV(labelId, values, count, xscale, xstart);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static void plotScatterV(String labelId, short[] values, int count, double xscale, double xstart, int flags) {
/*  2511 */     nPlotScatterV(labelId, values, count, xscale, xstart, flags);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static void plotScatterV(String labelId, short[] values, int count, double xscale, double xstart, int flags, int offset) {
/*  2518 */     nPlotScatterV(labelId, values, count, xscale, xstart, flags, offset);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   private static native void nPlotScatterV(String paramString, short[] paramArrayOfshort, int paramInt);
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   private static native void nPlotScatterV(String paramString, short[] paramArrayOfshort, int paramInt, double paramDouble);
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   private static native void nPlotScatterV(String paramString, short[] paramArrayOfshort, int paramInt, double paramDouble1, double paramDouble2);
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   private static native void nPlotScatterV(String paramString, short[] paramArrayOfshort, int paramInt1, double paramDouble1, double paramDouble2, int paramInt2);
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   private static native void nPlotScatterV(String paramString, short[] paramArrayOfshort, int paramInt1, double paramDouble1, double paramDouble2, int paramInt2, int paramInt3);
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static void plotScatterV(String labelId, int[] values, int count) {
/*  2565 */     nPlotScatterV(labelId, values, count);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static void plotScatterV(String labelId, int[] values, int count, double xscale) {
/*  2572 */     nPlotScatterV(labelId, values, count, xscale);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static void plotScatterV(String labelId, int[] values, int count, double xscale, double xstart) {
/*  2579 */     nPlotScatterV(labelId, values, count, xscale, xstart);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static void plotScatterV(String labelId, int[] values, int count, double xscale, double xstart, int flags) {
/*  2586 */     nPlotScatterV(labelId, values, count, xscale, xstart, flags);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static void plotScatterV(String labelId, int[] values, int count, double xscale, double xstart, int flags, int offset) {
/*  2593 */     nPlotScatterV(labelId, values, count, xscale, xstart, flags, offset);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   private static native void nPlotScatterV(String paramString, int[] paramArrayOfint, int paramInt);
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   private static native void nPlotScatterV(String paramString, int[] paramArrayOfint, int paramInt, double paramDouble);
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   private static native void nPlotScatterV(String paramString, int[] paramArrayOfint, int paramInt, double paramDouble1, double paramDouble2);
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   private static native void nPlotScatterV(String paramString, int[] paramArrayOfint, int paramInt1, double paramDouble1, double paramDouble2, int paramInt2);
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   private static native void nPlotScatterV(String paramString, int[] paramArrayOfint, int paramInt1, double paramDouble1, double paramDouble2, int paramInt2, int paramInt3);
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static void plotScatterV(String labelId, long[] values, int count) {
/*  2640 */     nPlotScatterV(labelId, values, count);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static void plotScatterV(String labelId, long[] values, int count, double xscale) {
/*  2647 */     nPlotScatterV(labelId, values, count, xscale);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static void plotScatterV(String labelId, long[] values, int count, double xscale, double xstart) {
/*  2654 */     nPlotScatterV(labelId, values, count, xscale, xstart);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static void plotScatterV(String labelId, long[] values, int count, double xscale, double xstart, int flags) {
/*  2661 */     nPlotScatterV(labelId, values, count, xscale, xstart, flags);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static void plotScatterV(String labelId, long[] values, int count, double xscale, double xstart, int flags, int offset) {
/*  2668 */     nPlotScatterV(labelId, values, count, xscale, xstart, flags, offset);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   private static native void nPlotScatterV(String paramString, long[] paramArrayOflong, int paramInt);
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   private static native void nPlotScatterV(String paramString, long[] paramArrayOflong, int paramInt, double paramDouble);
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   private static native void nPlotScatterV(String paramString, long[] paramArrayOflong, int paramInt, double paramDouble1, double paramDouble2);
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   private static native void nPlotScatterV(String paramString, long[] paramArrayOflong, int paramInt1, double paramDouble1, double paramDouble2, int paramInt2);
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   private static native void nPlotScatterV(String paramString, long[] paramArrayOflong, int paramInt1, double paramDouble1, double paramDouble2, int paramInt2, int paramInt3);
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static void plotScatterV(String labelId, float[] values, int count) {
/*  2715 */     nPlotScatterV(labelId, values, count);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static void plotScatterV(String labelId, float[] values, int count, double xscale) {
/*  2722 */     nPlotScatterV(labelId, values, count, xscale);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static void plotScatterV(String labelId, float[] values, int count, double xscale, double xstart) {
/*  2729 */     nPlotScatterV(labelId, values, count, xscale, xstart);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static void plotScatterV(String labelId, float[] values, int count, double xscale, double xstart, int flags) {
/*  2736 */     nPlotScatterV(labelId, values, count, xscale, xstart, flags);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static void plotScatterV(String labelId, float[] values, int count, double xscale, double xstart, int flags, int offset) {
/*  2743 */     nPlotScatterV(labelId, values, count, xscale, xstart, flags, offset);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   private static native void nPlotScatterV(String paramString, float[] paramArrayOffloat, int paramInt);
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   private static native void nPlotScatterV(String paramString, float[] paramArrayOffloat, int paramInt, double paramDouble);
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   private static native void nPlotScatterV(String paramString, float[] paramArrayOffloat, int paramInt, double paramDouble1, double paramDouble2);
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   private static native void nPlotScatterV(String paramString, float[] paramArrayOffloat, int paramInt1, double paramDouble1, double paramDouble2, int paramInt2);
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   private static native void nPlotScatterV(String paramString, float[] paramArrayOffloat, int paramInt1, double paramDouble1, double paramDouble2, int paramInt2, int paramInt3);
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static void plotScatterV(String labelId, double[] values, int count) {
/*  2790 */     nPlotScatterV(labelId, values, count);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static void plotScatterV(String labelId, double[] values, int count, double xscale) {
/*  2797 */     nPlotScatterV(labelId, values, count, xscale);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static void plotScatterV(String labelId, double[] values, int count, double xscale, double xstart) {
/*  2804 */     nPlotScatterV(labelId, values, count, xscale, xstart);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static void plotScatterV(String labelId, double[] values, int count, double xscale, double xstart, int flags) {
/*  2811 */     nPlotScatterV(labelId, values, count, xscale, xstart, flags);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static void plotScatterV(String labelId, double[] values, int count, double xscale, double xstart, int flags, int offset) {
/*  2818 */     nPlotScatterV(labelId, values, count, xscale, xstart, flags, offset);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   private static native void nPlotScatterV(String paramString, double[] paramArrayOfdouble, int paramInt);
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   private static native void nPlotScatterV(String paramString, double[] paramArrayOfdouble, int paramInt, double paramDouble);
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   private static native void nPlotScatterV(String paramString, double[] paramArrayOfdouble, int paramInt, double paramDouble1, double paramDouble2);
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   private static native void nPlotScatterV(String paramString, double[] paramArrayOfdouble, int paramInt1, double paramDouble1, double paramDouble2, int paramInt2);
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   private static native void nPlotScatterV(String paramString, double[] paramArrayOfdouble, int paramInt1, double paramDouble1, double paramDouble2, int paramInt2, int paramInt3);
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static void plotScatter(String labelId, short[] xs, short[] ys) {
/*  2867 */     nPlotScatter(labelId, xs, ys);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static void plotScatter(String labelId, short[] xs, short[] ys, int flags) {
/*  2874 */     nPlotScatter(labelId, xs, ys, flags);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   private static native void nPlotScatter(String paramString, short[] paramArrayOfshort1, short[] paramArrayOfshort2);
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   private static native void nPlotScatter(String paramString, short[] paramArrayOfshort1, short[] paramArrayOfshort2, int paramInt);
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static void plotScatter(String labelId, int[] xs, int[] ys) {
/*  2901 */     nPlotScatter(labelId, xs, ys);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static void plotScatter(String labelId, int[] xs, int[] ys, int flags) {
/*  2908 */     nPlotScatter(labelId, xs, ys, flags);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   private static native void nPlotScatter(String paramString, int[] paramArrayOfint1, int[] paramArrayOfint2);
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   private static native void nPlotScatter(String paramString, int[] paramArrayOfint1, int[] paramArrayOfint2, int paramInt);
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static void plotScatter(String labelId, long[] xs, long[] ys) {
/*  2935 */     nPlotScatter(labelId, xs, ys);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static void plotScatter(String labelId, long[] xs, long[] ys, int flags) {
/*  2942 */     nPlotScatter(labelId, xs, ys, flags);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   private static native void nPlotScatter(String paramString, long[] paramArrayOflong1, long[] paramArrayOflong2);
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   private static native void nPlotScatter(String paramString, long[] paramArrayOflong1, long[] paramArrayOflong2, int paramInt);
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static void plotScatter(String labelId, float[] xs, float[] ys) {
/*  2969 */     nPlotScatter(labelId, xs, ys);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static void plotScatter(String labelId, float[] xs, float[] ys, int flags) {
/*  2976 */     nPlotScatter(labelId, xs, ys, flags);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   private static native void nPlotScatter(String paramString, float[] paramArrayOffloat1, float[] paramArrayOffloat2);
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   private static native void nPlotScatter(String paramString, float[] paramArrayOffloat1, float[] paramArrayOffloat2, int paramInt);
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static void plotScatter(String labelId, double[] xs, double[] ys) {
/*  3003 */     nPlotScatter(labelId, xs, ys);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static void plotScatter(String labelId, double[] xs, double[] ys, int flags) {
/*  3010 */     nPlotScatter(labelId, xs, ys, flags);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   private static native void nPlotScatter(String paramString, double[] paramArrayOfdouble1, double[] paramArrayOfdouble2);
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   private static native void nPlotScatter(String paramString, double[] paramArrayOfdouble1, double[] paramArrayOfdouble2, int paramInt);
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static void plotScatterV(String labelId, short[] xs, short[] ys, int count) {
/*  3037 */     nPlotScatterV(labelId, xs, ys, count);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static void plotScatterV(String labelId, short[] xs, short[] ys, int count, int flags) {
/*  3044 */     nPlotScatterV(labelId, xs, ys, count, flags);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static void plotScatterV(String labelId, short[] xs, short[] ys, int count, int flags, int offset) {
/*  3051 */     nPlotScatterV(labelId, xs, ys, count, flags, offset);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   private static native void nPlotScatterV(String paramString, short[] paramArrayOfshort1, short[] paramArrayOfshort2, int paramInt);
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   private static native void nPlotScatterV(String paramString, short[] paramArrayOfshort1, short[] paramArrayOfshort2, int paramInt1, int paramInt2);
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   private static native void nPlotScatterV(String paramString, short[] paramArrayOfshort1, short[] paramArrayOfshort2, int paramInt1, int paramInt2, int paramInt3);
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static void plotScatterV(String labelId, int[] xs, int[] ys, int count) {
/*  3088 */     nPlotScatterV(labelId, xs, ys, count);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static void plotScatterV(String labelId, int[] xs, int[] ys, int count, int flags) {
/*  3095 */     nPlotScatterV(labelId, xs, ys, count, flags);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static void plotScatterV(String labelId, int[] xs, int[] ys, int count, int flags, int offset) {
/*  3102 */     nPlotScatterV(labelId, xs, ys, count, flags, offset);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   private static native void nPlotScatterV(String paramString, int[] paramArrayOfint1, int[] paramArrayOfint2, int paramInt);
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   private static native void nPlotScatterV(String paramString, int[] paramArrayOfint1, int[] paramArrayOfint2, int paramInt1, int paramInt2);
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   private static native void nPlotScatterV(String paramString, int[] paramArrayOfint1, int[] paramArrayOfint2, int paramInt1, int paramInt2, int paramInt3);
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static void plotScatterV(String labelId, long[] xs, long[] ys, int count) {
/*  3139 */     nPlotScatterV(labelId, xs, ys, count);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static void plotScatterV(String labelId, long[] xs, long[] ys, int count, int flags) {
/*  3146 */     nPlotScatterV(labelId, xs, ys, count, flags);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static void plotScatterV(String labelId, long[] xs, long[] ys, int count, int flags, int offset) {
/*  3153 */     nPlotScatterV(labelId, xs, ys, count, flags, offset);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   private static native void nPlotScatterV(String paramString, long[] paramArrayOflong1, long[] paramArrayOflong2, int paramInt);
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   private static native void nPlotScatterV(String paramString, long[] paramArrayOflong1, long[] paramArrayOflong2, int paramInt1, int paramInt2);
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   private static native void nPlotScatterV(String paramString, long[] paramArrayOflong1, long[] paramArrayOflong2, int paramInt1, int paramInt2, int paramInt3);
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static void plotScatterV(String labelId, float[] xs, float[] ys, int count) {
/*  3190 */     nPlotScatterV(labelId, xs, ys, count);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static void plotScatterV(String labelId, float[] xs, float[] ys, int count, int flags) {
/*  3197 */     nPlotScatterV(labelId, xs, ys, count, flags);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static void plotScatterV(String labelId, float[] xs, float[] ys, int count, int flags, int offset) {
/*  3204 */     nPlotScatterV(labelId, xs, ys, count, flags, offset);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   private static native void nPlotScatterV(String paramString, float[] paramArrayOffloat1, float[] paramArrayOffloat2, int paramInt);
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   private static native void nPlotScatterV(String paramString, float[] paramArrayOffloat1, float[] paramArrayOffloat2, int paramInt1, int paramInt2);
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   private static native void nPlotScatterV(String paramString, float[] paramArrayOffloat1, float[] paramArrayOffloat2, int paramInt1, int paramInt2, int paramInt3);
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static void plotScatterV(String labelId, double[] xs, double[] ys, int count) {
/*  3241 */     nPlotScatterV(labelId, xs, ys, count);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static void plotScatterV(String labelId, double[] xs, double[] ys, int count, int flags) {
/*  3248 */     nPlotScatterV(labelId, xs, ys, count, flags);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static void plotScatterV(String labelId, double[] xs, double[] ys, int count, int flags, int offset) {
/*  3255 */     nPlotScatterV(labelId, xs, ys, count, flags, offset);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   private static native void nPlotScatterV(String paramString, double[] paramArrayOfdouble1, double[] paramArrayOfdouble2, int paramInt);
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   private static native void nPlotScatterV(String paramString, double[] paramArrayOfdouble1, double[] paramArrayOfdouble2, int paramInt1, int paramInt2);
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   private static native void nPlotScatterV(String paramString, double[] paramArrayOfdouble1, double[] paramArrayOfdouble2, int paramInt1, int paramInt2, int paramInt3);
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static void plotStairs(String labelId, short[] values) {
/*  3294 */     nPlotStairs(labelId, values);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static void plotStairs(String labelId, short[] values, double xscale) {
/*  3301 */     nPlotStairs(labelId, values, xscale);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static void plotStairs(String labelId, short[] values, double xscale, double xstart) {
/*  3308 */     nPlotStairs(labelId, values, xscale, xstart);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static void plotStairs(String labelId, short[] values, double xscale, double xstart, int flags) {
/*  3315 */     nPlotStairs(labelId, values, xscale, xstart, flags);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static void plotStairs(String labelId, short[] values, double xscale, double xstart, int flags, int offset) {
/*  3322 */     nPlotStairs(labelId, values, xscale, xstart, flags, offset);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   private static native void nPlotStairs(String paramString, short[] paramArrayOfshort);
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   private static native void nPlotStairs(String paramString, short[] paramArrayOfshort, double paramDouble);
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   private static native void nPlotStairs(String paramString, short[] paramArrayOfshort, double paramDouble1, double paramDouble2);
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   private static native void nPlotStairs(String paramString, short[] paramArrayOfshort, double paramDouble1, double paramDouble2, int paramInt);
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   private static native void nPlotStairs(String paramString, short[] paramArrayOfshort, double paramDouble1, double paramDouble2, int paramInt1, int paramInt2);
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static void plotStairs(String labelId, int[] values) {
/*  3369 */     nPlotStairs(labelId, values);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static void plotStairs(String labelId, int[] values, double xscale) {
/*  3376 */     nPlotStairs(labelId, values, xscale);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static void plotStairs(String labelId, int[] values, double xscale, double xstart) {
/*  3383 */     nPlotStairs(labelId, values, xscale, xstart);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static void plotStairs(String labelId, int[] values, double xscale, double xstart, int flags) {
/*  3390 */     nPlotStairs(labelId, values, xscale, xstart, flags);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static void plotStairs(String labelId, int[] values, double xscale, double xstart, int flags, int offset) {
/*  3397 */     nPlotStairs(labelId, values, xscale, xstart, flags, offset);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   private static native void nPlotStairs(String paramString, int[] paramArrayOfint);
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   private static native void nPlotStairs(String paramString, int[] paramArrayOfint, double paramDouble);
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   private static native void nPlotStairs(String paramString, int[] paramArrayOfint, double paramDouble1, double paramDouble2);
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   private static native void nPlotStairs(String paramString, int[] paramArrayOfint, double paramDouble1, double paramDouble2, int paramInt);
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   private static native void nPlotStairs(String paramString, int[] paramArrayOfint, double paramDouble1, double paramDouble2, int paramInt1, int paramInt2);
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static void plotStairs(String labelId, long[] values) {
/*  3444 */     nPlotStairs(labelId, values);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static void plotStairs(String labelId, long[] values, double xscale) {
/*  3451 */     nPlotStairs(labelId, values, xscale);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static void plotStairs(String labelId, long[] values, double xscale, double xstart) {
/*  3458 */     nPlotStairs(labelId, values, xscale, xstart);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static void plotStairs(String labelId, long[] values, double xscale, double xstart, int flags) {
/*  3465 */     nPlotStairs(labelId, values, xscale, xstart, flags);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static void plotStairs(String labelId, long[] values, double xscale, double xstart, int flags, int offset) {
/*  3472 */     nPlotStairs(labelId, values, xscale, xstart, flags, offset);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   private static native void nPlotStairs(String paramString, long[] paramArrayOflong);
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   private static native void nPlotStairs(String paramString, long[] paramArrayOflong, double paramDouble);
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   private static native void nPlotStairs(String paramString, long[] paramArrayOflong, double paramDouble1, double paramDouble2);
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   private static native void nPlotStairs(String paramString, long[] paramArrayOflong, double paramDouble1, double paramDouble2, int paramInt);
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   private static native void nPlotStairs(String paramString, long[] paramArrayOflong, double paramDouble1, double paramDouble2, int paramInt1, int paramInt2);
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static void plotStairs(String labelId, float[] values) {
/*  3519 */     nPlotStairs(labelId, values);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static void plotStairs(String labelId, float[] values, double xscale) {
/*  3526 */     nPlotStairs(labelId, values, xscale);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static void plotStairs(String labelId, float[] values, double xscale, double xstart) {
/*  3533 */     nPlotStairs(labelId, values, xscale, xstart);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static void plotStairs(String labelId, float[] values, double xscale, double xstart, int flags) {
/*  3540 */     nPlotStairs(labelId, values, xscale, xstart, flags);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static void plotStairs(String labelId, float[] values, double xscale, double xstart, int flags, int offset) {
/*  3547 */     nPlotStairs(labelId, values, xscale, xstart, flags, offset);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   private static native void nPlotStairs(String paramString, float[] paramArrayOffloat);
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   private static native void nPlotStairs(String paramString, float[] paramArrayOffloat, double paramDouble);
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   private static native void nPlotStairs(String paramString, float[] paramArrayOffloat, double paramDouble1, double paramDouble2);
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   private static native void nPlotStairs(String paramString, float[] paramArrayOffloat, double paramDouble1, double paramDouble2, int paramInt);
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   private static native void nPlotStairs(String paramString, float[] paramArrayOffloat, double paramDouble1, double paramDouble2, int paramInt1, int paramInt2);
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static void plotStairs(String labelId, double[] values) {
/*  3594 */     nPlotStairs(labelId, values);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static void plotStairs(String labelId, double[] values, double xscale) {
/*  3601 */     nPlotStairs(labelId, values, xscale);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static void plotStairs(String labelId, double[] values, double xscale, double xstart) {
/*  3608 */     nPlotStairs(labelId, values, xscale, xstart);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static void plotStairs(String labelId, double[] values, double xscale, double xstart, int flags) {
/*  3615 */     nPlotStairs(labelId, values, xscale, xstart, flags);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static void plotStairs(String labelId, double[] values, double xscale, double xstart, int flags, int offset) {
/*  3622 */     nPlotStairs(labelId, values, xscale, xstart, flags, offset);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   private static native void nPlotStairs(String paramString, double[] paramArrayOfdouble);
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   private static native void nPlotStairs(String paramString, double[] paramArrayOfdouble, double paramDouble);
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   private static native void nPlotStairs(String paramString, double[] paramArrayOfdouble, double paramDouble1, double paramDouble2);
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   private static native void nPlotStairs(String paramString, double[] paramArrayOfdouble, double paramDouble1, double paramDouble2, int paramInt);
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   private static native void nPlotStairs(String paramString, double[] paramArrayOfdouble, double paramDouble1, double paramDouble2, int paramInt1, int paramInt2);
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static void plotStairsV(String labelId, short[] values, int count) {
/*  3669 */     nPlotStairsV(labelId, values, count);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static void plotStairsV(String labelId, short[] values, int count, double xscale) {
/*  3676 */     nPlotStairsV(labelId, values, count, xscale);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static void plotStairsV(String labelId, short[] values, int count, double xscale, double xstart) {
/*  3683 */     nPlotStairsV(labelId, values, count, xscale, xstart);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static void plotStairsV(String labelId, short[] values, int count, double xscale, double xstart, int flags) {
/*  3690 */     nPlotStairsV(labelId, values, count, xscale, xstart, flags);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static void plotStairsV(String labelId, short[] values, int count, double xscale, double xstart, int flags, int offset) {
/*  3697 */     nPlotStairsV(labelId, values, count, xscale, xstart, flags, offset);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   private static native void nPlotStairsV(String paramString, short[] paramArrayOfshort, int paramInt);
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   private static native void nPlotStairsV(String paramString, short[] paramArrayOfshort, int paramInt, double paramDouble);
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   private static native void nPlotStairsV(String paramString, short[] paramArrayOfshort, int paramInt, double paramDouble1, double paramDouble2);
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   private static native void nPlotStairsV(String paramString, short[] paramArrayOfshort, int paramInt1, double paramDouble1, double paramDouble2, int paramInt2);
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   private static native void nPlotStairsV(String paramString, short[] paramArrayOfshort, int paramInt1, double paramDouble1, double paramDouble2, int paramInt2, int paramInt3);
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static void plotStairsV(String labelId, int[] values, int count) {
/*  3744 */     nPlotStairsV(labelId, values, count);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static void plotStairsV(String labelId, int[] values, int count, double xscale) {
/*  3751 */     nPlotStairsV(labelId, values, count, xscale);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static void plotStairsV(String labelId, int[] values, int count, double xscale, double xstart) {
/*  3758 */     nPlotStairsV(labelId, values, count, xscale, xstart);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static void plotStairsV(String labelId, int[] values, int count, double xscale, double xstart, int flags) {
/*  3765 */     nPlotStairsV(labelId, values, count, xscale, xstart, flags);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static void plotStairsV(String labelId, int[] values, int count, double xscale, double xstart, int flags, int offset) {
/*  3772 */     nPlotStairsV(labelId, values, count, xscale, xstart, flags, offset);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   private static native void nPlotStairsV(String paramString, int[] paramArrayOfint, int paramInt);
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   private static native void nPlotStairsV(String paramString, int[] paramArrayOfint, int paramInt, double paramDouble);
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   private static native void nPlotStairsV(String paramString, int[] paramArrayOfint, int paramInt, double paramDouble1, double paramDouble2);
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   private static native void nPlotStairsV(String paramString, int[] paramArrayOfint, int paramInt1, double paramDouble1, double paramDouble2, int paramInt2);
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   private static native void nPlotStairsV(String paramString, int[] paramArrayOfint, int paramInt1, double paramDouble1, double paramDouble2, int paramInt2, int paramInt3);
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static void plotStairsV(String labelId, long[] values, int count) {
/*  3819 */     nPlotStairsV(labelId, values, count);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static void plotStairsV(String labelId, long[] values, int count, double xscale) {
/*  3826 */     nPlotStairsV(labelId, values, count, xscale);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static void plotStairsV(String labelId, long[] values, int count, double xscale, double xstart) {
/*  3833 */     nPlotStairsV(labelId, values, count, xscale, xstart);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static void plotStairsV(String labelId, long[] values, int count, double xscale, double xstart, int flags) {
/*  3840 */     nPlotStairsV(labelId, values, count, xscale, xstart, flags);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static void plotStairsV(String labelId, long[] values, int count, double xscale, double xstart, int flags, int offset) {
/*  3847 */     nPlotStairsV(labelId, values, count, xscale, xstart, flags, offset);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   private static native void nPlotStairsV(String paramString, long[] paramArrayOflong, int paramInt);
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   private static native void nPlotStairsV(String paramString, long[] paramArrayOflong, int paramInt, double paramDouble);
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   private static native void nPlotStairsV(String paramString, long[] paramArrayOflong, int paramInt, double paramDouble1, double paramDouble2);
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   private static native void nPlotStairsV(String paramString, long[] paramArrayOflong, int paramInt1, double paramDouble1, double paramDouble2, int paramInt2);
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   private static native void nPlotStairsV(String paramString, long[] paramArrayOflong, int paramInt1, double paramDouble1, double paramDouble2, int paramInt2, int paramInt3);
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static void plotStairsV(String labelId, float[] values, int count) {
/*  3894 */     nPlotStairsV(labelId, values, count);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static void plotStairsV(String labelId, float[] values, int count, double xscale) {
/*  3901 */     nPlotStairsV(labelId, values, count, xscale);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static void plotStairsV(String labelId, float[] values, int count, double xscale, double xstart) {
/*  3908 */     nPlotStairsV(labelId, values, count, xscale, xstart);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static void plotStairsV(String labelId, float[] values, int count, double xscale, double xstart, int flags) {
/*  3915 */     nPlotStairsV(labelId, values, count, xscale, xstart, flags);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static void plotStairsV(String labelId, float[] values, int count, double xscale, double xstart, int flags, int offset) {
/*  3922 */     nPlotStairsV(labelId, values, count, xscale, xstart, flags, offset);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   private static native void nPlotStairsV(String paramString, float[] paramArrayOffloat, int paramInt);
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   private static native void nPlotStairsV(String paramString, float[] paramArrayOffloat, int paramInt, double paramDouble);
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   private static native void nPlotStairsV(String paramString, float[] paramArrayOffloat, int paramInt, double paramDouble1, double paramDouble2);
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   private static native void nPlotStairsV(String paramString, float[] paramArrayOffloat, int paramInt1, double paramDouble1, double paramDouble2, int paramInt2);
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   private static native void nPlotStairsV(String paramString, float[] paramArrayOffloat, int paramInt1, double paramDouble1, double paramDouble2, int paramInt2, int paramInt3);
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static void plotStairsV(String labelId, double[] values, int count) {
/*  3969 */     nPlotStairsV(labelId, values, count);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static void plotStairsV(String labelId, double[] values, int count, double xscale) {
/*  3976 */     nPlotStairsV(labelId, values, count, xscale);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static void plotStairsV(String labelId, double[] values, int count, double xscale, double xstart) {
/*  3983 */     nPlotStairsV(labelId, values, count, xscale, xstart);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static void plotStairsV(String labelId, double[] values, int count, double xscale, double xstart, int flags) {
/*  3990 */     nPlotStairsV(labelId, values, count, xscale, xstart, flags);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static void plotStairsV(String labelId, double[] values, int count, double xscale, double xstart, int flags, int offset) {
/*  3997 */     nPlotStairsV(labelId, values, count, xscale, xstart, flags, offset);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   private static native void nPlotStairsV(String paramString, double[] paramArrayOfdouble, int paramInt);
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   private static native void nPlotStairsV(String paramString, double[] paramArrayOfdouble, int paramInt, double paramDouble);
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   private static native void nPlotStairsV(String paramString, double[] paramArrayOfdouble, int paramInt, double paramDouble1, double paramDouble2);
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   private static native void nPlotStairsV(String paramString, double[] paramArrayOfdouble, int paramInt1, double paramDouble1, double paramDouble2, int paramInt2);
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   private static native void nPlotStairsV(String paramString, double[] paramArrayOfdouble, int paramInt1, double paramDouble1, double paramDouble2, int paramInt2, int paramInt3);
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static void plotStairs(String labelId, short[] xs, short[] ys) {
/*  4046 */     nPlotStairs(labelId, xs, ys);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static void plotStairs(String labelId, short[] xs, short[] ys, int flags) {
/*  4053 */     nPlotStairs(labelId, xs, ys, flags);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   private static native void nPlotStairs(String paramString, short[] paramArrayOfshort1, short[] paramArrayOfshort2);
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   private static native void nPlotStairs(String paramString, short[] paramArrayOfshort1, short[] paramArrayOfshort2, int paramInt);
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static void plotStairs(String labelId, int[] xs, int[] ys) {
/*  4080 */     nPlotStairs(labelId, xs, ys);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static void plotStairs(String labelId, int[] xs, int[] ys, int flags) {
/*  4087 */     nPlotStairs(labelId, xs, ys, flags);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   private static native void nPlotStairs(String paramString, int[] paramArrayOfint1, int[] paramArrayOfint2);
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   private static native void nPlotStairs(String paramString, int[] paramArrayOfint1, int[] paramArrayOfint2, int paramInt);
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static void plotStairs(String labelId, long[] xs, long[] ys) {
/*  4114 */     nPlotStairs(labelId, xs, ys);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static void plotStairs(String labelId, long[] xs, long[] ys, int flags) {
/*  4121 */     nPlotStairs(labelId, xs, ys, flags);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   private static native void nPlotStairs(String paramString, long[] paramArrayOflong1, long[] paramArrayOflong2);
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   private static native void nPlotStairs(String paramString, long[] paramArrayOflong1, long[] paramArrayOflong2, int paramInt);
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static void plotStairs(String labelId, float[] xs, float[] ys) {
/*  4148 */     nPlotStairs(labelId, xs, ys);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static void plotStairs(String labelId, float[] xs, float[] ys, int flags) {
/*  4155 */     nPlotStairs(labelId, xs, ys, flags);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   private static native void nPlotStairs(String paramString, float[] paramArrayOffloat1, float[] paramArrayOffloat2);
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   private static native void nPlotStairs(String paramString, float[] paramArrayOffloat1, float[] paramArrayOffloat2, int paramInt);
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static void plotStairs(String labelId, double[] xs, double[] ys) {
/*  4182 */     nPlotStairs(labelId, xs, ys);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static void plotStairs(String labelId, double[] xs, double[] ys, int flags) {
/*  4189 */     nPlotStairs(labelId, xs, ys, flags);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   private static native void nPlotStairs(String paramString, double[] paramArrayOfdouble1, double[] paramArrayOfdouble2);
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   private static native void nPlotStairs(String paramString, double[] paramArrayOfdouble1, double[] paramArrayOfdouble2, int paramInt);
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static void plotStairsV(String labelId, short[] xs, short[] ys, int count) {
/*  4216 */     nPlotStairsV(labelId, xs, ys, count);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static void plotStairsV(String labelId, short[] xs, short[] ys, int count, int flags) {
/*  4223 */     nPlotStairsV(labelId, xs, ys, count, flags);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static void plotStairsV(String labelId, short[] xs, short[] ys, int count, int flags, int offset) {
/*  4230 */     nPlotStairsV(labelId, xs, ys, count, flags, offset);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   private static native void nPlotStairsV(String paramString, short[] paramArrayOfshort1, short[] paramArrayOfshort2, int paramInt);
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   private static native void nPlotStairsV(String paramString, short[] paramArrayOfshort1, short[] paramArrayOfshort2, int paramInt1, int paramInt2);
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   private static native void nPlotStairsV(String paramString, short[] paramArrayOfshort1, short[] paramArrayOfshort2, int paramInt1, int paramInt2, int paramInt3);
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static void plotStairsV(String labelId, int[] xs, int[] ys, int count) {
/*  4267 */     nPlotStairsV(labelId, xs, ys, count);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static void plotStairsV(String labelId, int[] xs, int[] ys, int count, int flags) {
/*  4274 */     nPlotStairsV(labelId, xs, ys, count, flags);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static void plotStairsV(String labelId, int[] xs, int[] ys, int count, int flags, int offset) {
/*  4281 */     nPlotStairsV(labelId, xs, ys, count, flags, offset);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   private static native void nPlotStairsV(String paramString, int[] paramArrayOfint1, int[] paramArrayOfint2, int paramInt);
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   private static native void nPlotStairsV(String paramString, int[] paramArrayOfint1, int[] paramArrayOfint2, int paramInt1, int paramInt2);
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   private static native void nPlotStairsV(String paramString, int[] paramArrayOfint1, int[] paramArrayOfint2, int paramInt1, int paramInt2, int paramInt3);
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static void plotStairsV(String labelId, long[] xs, long[] ys, int count) {
/*  4318 */     nPlotStairsV(labelId, xs, ys, count);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static void plotStairsV(String labelId, long[] xs, long[] ys, int count, int flags) {
/*  4325 */     nPlotStairsV(labelId, xs, ys, count, flags);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static void plotStairsV(String labelId, long[] xs, long[] ys, int count, int flags, int offset) {
/*  4332 */     nPlotStairsV(labelId, xs, ys, count, flags, offset);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   private static native void nPlotStairsV(String paramString, long[] paramArrayOflong1, long[] paramArrayOflong2, int paramInt);
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   private static native void nPlotStairsV(String paramString, long[] paramArrayOflong1, long[] paramArrayOflong2, int paramInt1, int paramInt2);
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   private static native void nPlotStairsV(String paramString, long[] paramArrayOflong1, long[] paramArrayOflong2, int paramInt1, int paramInt2, int paramInt3);
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static void plotStairsV(String labelId, float[] xs, float[] ys, int count) {
/*  4369 */     nPlotStairsV(labelId, xs, ys, count);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static void plotStairsV(String labelId, float[] xs, float[] ys, int count, int flags) {
/*  4376 */     nPlotStairsV(labelId, xs, ys, count, flags);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static void plotStairsV(String labelId, float[] xs, float[] ys, int count, int flags, int offset) {
/*  4383 */     nPlotStairsV(labelId, xs, ys, count, flags, offset);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   private static native void nPlotStairsV(String paramString, float[] paramArrayOffloat1, float[] paramArrayOffloat2, int paramInt);
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   private static native void nPlotStairsV(String paramString, float[] paramArrayOffloat1, float[] paramArrayOffloat2, int paramInt1, int paramInt2);
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   private static native void nPlotStairsV(String paramString, float[] paramArrayOffloat1, float[] paramArrayOffloat2, int paramInt1, int paramInt2, int paramInt3);
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static void plotStairsV(String labelId, double[] xs, double[] ys, int count) {
/*  4420 */     nPlotStairsV(labelId, xs, ys, count);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static void plotStairsV(String labelId, double[] xs, double[] ys, int count, int flags) {
/*  4427 */     nPlotStairsV(labelId, xs, ys, count, flags);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static void plotStairsV(String labelId, double[] xs, double[] ys, int count, int flags, int offset) {
/*  4434 */     nPlotStairsV(labelId, xs, ys, count, flags, offset);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   private static native void nPlotStairsV(String paramString, double[] paramArrayOfdouble1, double[] paramArrayOfdouble2, int paramInt);
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   private static native void nPlotStairsV(String paramString, double[] paramArrayOfdouble1, double[] paramArrayOfdouble2, int paramInt1, int paramInt2);
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   private static native void nPlotStairsV(String paramString, double[] paramArrayOfdouble1, double[] paramArrayOfdouble2, int paramInt1, int paramInt2, int paramInt3);
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static void plotShaded(String labelId, short[] values) {
/*  4473 */     nPlotShaded(labelId, values);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static void plotShaded(String labelId, short[] values, double yRef) {
/*  4480 */     nPlotShaded(labelId, values, yRef);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static void plotShaded(String labelId, short[] values, double yRef, double xscale) {
/*  4487 */     nPlotShaded(labelId, values, yRef, xscale);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static void plotShaded(String labelId, short[] values, double yRef, double xscale, double xstart) {
/*  4494 */     nPlotShaded(labelId, values, yRef, xscale, xstart);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static void plotShaded(String labelId, short[] values, double yRef, double xscale, double xstart, int flags) {
/*  4501 */     nPlotShaded(labelId, values, yRef, xscale, xstart, flags);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static void plotShaded(String labelId, short[] values, double yRef, double xscale, double xstart, int flags, int offset) {
/*  4508 */     nPlotShaded(labelId, values, yRef, xscale, xstart, flags, offset);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   private static native void nPlotShaded(String paramString, short[] paramArrayOfshort);
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   private static native void nPlotShaded(String paramString, short[] paramArrayOfshort, double paramDouble);
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   private static native void nPlotShaded(String paramString, short[] paramArrayOfshort, double paramDouble1, double paramDouble2);
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   private static native void nPlotShaded(String paramString, short[] paramArrayOfshort, double paramDouble1, double paramDouble2, double paramDouble3);
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   private static native void nPlotShaded(String paramString, short[] paramArrayOfshort, double paramDouble1, double paramDouble2, double paramDouble3, int paramInt);
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   private static native void nPlotShaded(String paramString, short[] paramArrayOfshort, double paramDouble1, double paramDouble2, double paramDouble3, int paramInt1, int paramInt2);
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static void plotShaded(String labelId, int[] values) {
/*  4563 */     nPlotShaded(labelId, values);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static void plotShaded(String labelId, int[] values, double yRef) {
/*  4570 */     nPlotShaded(labelId, values, yRef);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static void plotShaded(String labelId, int[] values, double yRef, double xscale) {
/*  4577 */     nPlotShaded(labelId, values, yRef, xscale);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static void plotShaded(String labelId, int[] values, double yRef, double xscale, double xstart) {
/*  4584 */     nPlotShaded(labelId, values, yRef, xscale, xstart);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static void plotShaded(String labelId, int[] values, double yRef, double xscale, double xstart, int flags) {
/*  4591 */     nPlotShaded(labelId, values, yRef, xscale, xstart, flags);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static void plotShaded(String labelId, int[] values, double yRef, double xscale, double xstart, int flags, int offset) {
/*  4598 */     nPlotShaded(labelId, values, yRef, xscale, xstart, flags, offset);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   private static native void nPlotShaded(String paramString, int[] paramArrayOfint);
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   private static native void nPlotShaded(String paramString, int[] paramArrayOfint, double paramDouble);
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   private static native void nPlotShaded(String paramString, int[] paramArrayOfint, double paramDouble1, double paramDouble2);
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   private static native void nPlotShaded(String paramString, int[] paramArrayOfint, double paramDouble1, double paramDouble2, double paramDouble3);
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   private static native void nPlotShaded(String paramString, int[] paramArrayOfint, double paramDouble1, double paramDouble2, double paramDouble3, int paramInt);
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   private static native void nPlotShaded(String paramString, int[] paramArrayOfint, double paramDouble1, double paramDouble2, double paramDouble3, int paramInt1, int paramInt2);
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static void plotShaded(String labelId, long[] values) {
/*  4653 */     nPlotShaded(labelId, values);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static void plotShaded(String labelId, long[] values, double yRef) {
/*  4660 */     nPlotShaded(labelId, values, yRef);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static void plotShaded(String labelId, long[] values, double yRef, double xscale) {
/*  4667 */     nPlotShaded(labelId, values, yRef, xscale);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static void plotShaded(String labelId, long[] values, double yRef, double xscale, double xstart) {
/*  4674 */     nPlotShaded(labelId, values, yRef, xscale, xstart);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static void plotShaded(String labelId, long[] values, double yRef, double xscale, double xstart, int flags) {
/*  4681 */     nPlotShaded(labelId, values, yRef, xscale, xstart, flags);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static void plotShaded(String labelId, long[] values, double yRef, double xscale, double xstart, int flags, int offset) {
/*  4688 */     nPlotShaded(labelId, values, yRef, xscale, xstart, flags, offset);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   private static native void nPlotShaded(String paramString, long[] paramArrayOflong);
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   private static native void nPlotShaded(String paramString, long[] paramArrayOflong, double paramDouble);
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   private static native void nPlotShaded(String paramString, long[] paramArrayOflong, double paramDouble1, double paramDouble2);
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   private static native void nPlotShaded(String paramString, long[] paramArrayOflong, double paramDouble1, double paramDouble2, double paramDouble3);
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   private static native void nPlotShaded(String paramString, long[] paramArrayOflong, double paramDouble1, double paramDouble2, double paramDouble3, int paramInt);
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   private static native void nPlotShaded(String paramString, long[] paramArrayOflong, double paramDouble1, double paramDouble2, double paramDouble3, int paramInt1, int paramInt2);
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static void plotShaded(String labelId, float[] values) {
/*  4743 */     nPlotShaded(labelId, values);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static void plotShaded(String labelId, float[] values, double yRef) {
/*  4750 */     nPlotShaded(labelId, values, yRef);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static void plotShaded(String labelId, float[] values, double yRef, double xscale) {
/*  4757 */     nPlotShaded(labelId, values, yRef, xscale);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static void plotShaded(String labelId, float[] values, double yRef, double xscale, double xstart) {
/*  4764 */     nPlotShaded(labelId, values, yRef, xscale, xstart);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static void plotShaded(String labelId, float[] values, double yRef, double xscale, double xstart, int flags) {
/*  4771 */     nPlotShaded(labelId, values, yRef, xscale, xstart, flags);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static void plotShaded(String labelId, float[] values, double yRef, double xscale, double xstart, int flags, int offset) {
/*  4778 */     nPlotShaded(labelId, values, yRef, xscale, xstart, flags, offset);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   private static native void nPlotShaded(String paramString, float[] paramArrayOffloat);
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   private static native void nPlotShaded(String paramString, float[] paramArrayOffloat, double paramDouble);
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   private static native void nPlotShaded(String paramString, float[] paramArrayOffloat, double paramDouble1, double paramDouble2);
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   private static native void nPlotShaded(String paramString, float[] paramArrayOffloat, double paramDouble1, double paramDouble2, double paramDouble3);
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   private static native void nPlotShaded(String paramString, float[] paramArrayOffloat, double paramDouble1, double paramDouble2, double paramDouble3, int paramInt);
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   private static native void nPlotShaded(String paramString, float[] paramArrayOffloat, double paramDouble1, double paramDouble2, double paramDouble3, int paramInt1, int paramInt2);
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static void plotShaded(String labelId, double[] values) {
/*  4833 */     nPlotShaded(labelId, values);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static void plotShaded(String labelId, double[] values, double yRef) {
/*  4840 */     nPlotShaded(labelId, values, yRef);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static void plotShaded(String labelId, double[] values, double yRef, double xscale) {
/*  4847 */     nPlotShaded(labelId, values, yRef, xscale);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static void plotShaded(String labelId, double[] values, double yRef, double xscale, double xstart) {
/*  4854 */     nPlotShaded(labelId, values, yRef, xscale, xstart);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static void plotShaded(String labelId, double[] values, double yRef, double xscale, double xstart, int flags) {
/*  4861 */     nPlotShaded(labelId, values, yRef, xscale, xstart, flags);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static void plotShaded(String labelId, double[] values, double yRef, double xscale, double xstart, int flags, int offset) {
/*  4868 */     nPlotShaded(labelId, values, yRef, xscale, xstart, flags, offset);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   private static native void nPlotShaded(String paramString, double[] paramArrayOfdouble);
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   private static native void nPlotShaded(String paramString, double[] paramArrayOfdouble, double paramDouble);
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   private static native void nPlotShaded(String paramString, double[] paramArrayOfdouble, double paramDouble1, double paramDouble2);
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   private static native void nPlotShaded(String paramString, double[] paramArrayOfdouble, double paramDouble1, double paramDouble2, double paramDouble3);
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   private static native void nPlotShaded(String paramString, double[] paramArrayOfdouble, double paramDouble1, double paramDouble2, double paramDouble3, int paramInt);
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   private static native void nPlotShaded(String paramString, double[] paramArrayOfdouble, double paramDouble1, double paramDouble2, double paramDouble3, int paramInt1, int paramInt2);
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static void plotShadedV(String labelId, short[] values, int count) {
/*  4923 */     nPlotShadedV(labelId, values, count);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static void plotShadedV(String labelId, short[] values, int count, double yRef) {
/*  4930 */     nPlotShadedV(labelId, values, count, yRef);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static void plotShadedV(String labelId, short[] values, int count, double yRef, double xscale) {
/*  4937 */     nPlotShadedV(labelId, values, count, yRef, xscale);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static void plotShadedV(String labelId, short[] values, int count, double yRef, double xscale, double xstart) {
/*  4944 */     nPlotShadedV(labelId, values, count, yRef, xscale, xstart);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static void plotShadedV(String labelId, short[] values, int count, double yRef, double xscale, double xstart, int flags) {
/*  4951 */     nPlotShadedV(labelId, values, count, yRef, xscale, xstart, flags);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static void plotShadedV(String labelId, short[] values, int count, double yRef, double xscale, double xstart, int flags, int offset) {
/*  4958 */     nPlotShadedV(labelId, values, count, yRef, xscale, xstart, flags, offset);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   private static native void nPlotShadedV(String paramString, short[] paramArrayOfshort, int paramInt);
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   private static native void nPlotShadedV(String paramString, short[] paramArrayOfshort, int paramInt, double paramDouble);
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   private static native void nPlotShadedV(String paramString, short[] paramArrayOfshort, int paramInt, double paramDouble1, double paramDouble2);
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   private static native void nPlotShadedV(String paramString, short[] paramArrayOfshort, int paramInt, double paramDouble1, double paramDouble2, double paramDouble3);
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   private static native void nPlotShadedV(String paramString, short[] paramArrayOfshort, int paramInt1, double paramDouble1, double paramDouble2, double paramDouble3, int paramInt2);
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   private static native void nPlotShadedV(String paramString, short[] paramArrayOfshort, int paramInt1, double paramDouble1, double paramDouble2, double paramDouble3, int paramInt2, int paramInt3);
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static void plotShadedV(String labelId, int[] values, int count) {
/*  5013 */     nPlotShadedV(labelId, values, count);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static void plotShadedV(String labelId, int[] values, int count, double yRef) {
/*  5020 */     nPlotShadedV(labelId, values, count, yRef);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static void plotShadedV(String labelId, int[] values, int count, double yRef, double xscale) {
/*  5027 */     nPlotShadedV(labelId, values, count, yRef, xscale);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static void plotShadedV(String labelId, int[] values, int count, double yRef, double xscale, double xstart) {
/*  5034 */     nPlotShadedV(labelId, values, count, yRef, xscale, xstart);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static void plotShadedV(String labelId, int[] values, int count, double yRef, double xscale, double xstart, int flags) {
/*  5041 */     nPlotShadedV(labelId, values, count, yRef, xscale, xstart, flags);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static void plotShadedV(String labelId, int[] values, int count, double yRef, double xscale, double xstart, int flags, int offset) {
/*  5048 */     nPlotShadedV(labelId, values, count, yRef, xscale, xstart, flags, offset);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   private static native void nPlotShadedV(String paramString, int[] paramArrayOfint, int paramInt);
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   private static native void nPlotShadedV(String paramString, int[] paramArrayOfint, int paramInt, double paramDouble);
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   private static native void nPlotShadedV(String paramString, int[] paramArrayOfint, int paramInt, double paramDouble1, double paramDouble2);
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   private static native void nPlotShadedV(String paramString, int[] paramArrayOfint, int paramInt, double paramDouble1, double paramDouble2, double paramDouble3);
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   private static native void nPlotShadedV(String paramString, int[] paramArrayOfint, int paramInt1, double paramDouble1, double paramDouble2, double paramDouble3, int paramInt2);
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   private static native void nPlotShadedV(String paramString, int[] paramArrayOfint, int paramInt1, double paramDouble1, double paramDouble2, double paramDouble3, int paramInt2, int paramInt3);
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static void plotShadedV(String labelId, long[] values, int count) {
/*  5103 */     nPlotShadedV(labelId, values, count);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static void plotShadedV(String labelId, long[] values, int count, double yRef) {
/*  5110 */     nPlotShadedV(labelId, values, count, yRef);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static void plotShadedV(String labelId, long[] values, int count, double yRef, double xscale) {
/*  5117 */     nPlotShadedV(labelId, values, count, yRef, xscale);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static void plotShadedV(String labelId, long[] values, int count, double yRef, double xscale, double xstart) {
/*  5124 */     nPlotShadedV(labelId, values, count, yRef, xscale, xstart);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static void plotShadedV(String labelId, long[] values, int count, double yRef, double xscale, double xstart, int flags) {
/*  5131 */     nPlotShadedV(labelId, values, count, yRef, xscale, xstart, flags);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static void plotShadedV(String labelId, long[] values, int count, double yRef, double xscale, double xstart, int flags, int offset) {
/*  5138 */     nPlotShadedV(labelId, values, count, yRef, xscale, xstart, flags, offset);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   private static native void nPlotShadedV(String paramString, long[] paramArrayOflong, int paramInt);
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   private static native void nPlotShadedV(String paramString, long[] paramArrayOflong, int paramInt, double paramDouble);
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   private static native void nPlotShadedV(String paramString, long[] paramArrayOflong, int paramInt, double paramDouble1, double paramDouble2);
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   private static native void nPlotShadedV(String paramString, long[] paramArrayOflong, int paramInt, double paramDouble1, double paramDouble2, double paramDouble3);
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   private static native void nPlotShadedV(String paramString, long[] paramArrayOflong, int paramInt1, double paramDouble1, double paramDouble2, double paramDouble3, int paramInt2);
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   private static native void nPlotShadedV(String paramString, long[] paramArrayOflong, int paramInt1, double paramDouble1, double paramDouble2, double paramDouble3, int paramInt2, int paramInt3);
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static void plotShadedV(String labelId, float[] values, int count) {
/*  5193 */     nPlotShadedV(labelId, values, count);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static void plotShadedV(String labelId, float[] values, int count, double yRef) {
/*  5200 */     nPlotShadedV(labelId, values, count, yRef);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static void plotShadedV(String labelId, float[] values, int count, double yRef, double xscale) {
/*  5207 */     nPlotShadedV(labelId, values, count, yRef, xscale);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static void plotShadedV(String labelId, float[] values, int count, double yRef, double xscale, double xstart) {
/*  5214 */     nPlotShadedV(labelId, values, count, yRef, xscale, xstart);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static void plotShadedV(String labelId, float[] values, int count, double yRef, double xscale, double xstart, int flags) {
/*  5221 */     nPlotShadedV(labelId, values, count, yRef, xscale, xstart, flags);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static void plotShadedV(String labelId, float[] values, int count, double yRef, double xscale, double xstart, int flags, int offset) {
/*  5228 */     nPlotShadedV(labelId, values, count, yRef, xscale, xstart, flags, offset);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   private static native void nPlotShadedV(String paramString, float[] paramArrayOffloat, int paramInt);
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   private static native void nPlotShadedV(String paramString, float[] paramArrayOffloat, int paramInt, double paramDouble);
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   private static native void nPlotShadedV(String paramString, float[] paramArrayOffloat, int paramInt, double paramDouble1, double paramDouble2);
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   private static native void nPlotShadedV(String paramString, float[] paramArrayOffloat, int paramInt, double paramDouble1, double paramDouble2, double paramDouble3);
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   private static native void nPlotShadedV(String paramString, float[] paramArrayOffloat, int paramInt1, double paramDouble1, double paramDouble2, double paramDouble3, int paramInt2);
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   private static native void nPlotShadedV(String paramString, float[] paramArrayOffloat, int paramInt1, double paramDouble1, double paramDouble2, double paramDouble3, int paramInt2, int paramInt3);
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static void plotShadedV(String labelId, double[] values, int count) {
/*  5283 */     nPlotShadedV(labelId, values, count);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static void plotShadedV(String labelId, double[] values, int count, double yRef) {
/*  5290 */     nPlotShadedV(labelId, values, count, yRef);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static void plotShadedV(String labelId, double[] values, int count, double yRef, double xscale) {
/*  5297 */     nPlotShadedV(labelId, values, count, yRef, xscale);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static void plotShadedV(String labelId, double[] values, int count, double yRef, double xscale, double xstart) {
/*  5304 */     nPlotShadedV(labelId, values, count, yRef, xscale, xstart);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static void plotShadedV(String labelId, double[] values, int count, double yRef, double xscale, double xstart, int flags) {
/*  5311 */     nPlotShadedV(labelId, values, count, yRef, xscale, xstart, flags);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static void plotShadedV(String labelId, double[] values, int count, double yRef, double xscale, double xstart, int flags, int offset) {
/*  5318 */     nPlotShadedV(labelId, values, count, yRef, xscale, xstart, flags, offset);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   private static native void nPlotShadedV(String paramString, double[] paramArrayOfdouble, int paramInt);
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   private static native void nPlotShadedV(String paramString, double[] paramArrayOfdouble, int paramInt, double paramDouble);
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   private static native void nPlotShadedV(String paramString, double[] paramArrayOfdouble, int paramInt, double paramDouble1, double paramDouble2);
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   private static native void nPlotShadedV(String paramString, double[] paramArrayOfdouble, int paramInt, double paramDouble1, double paramDouble2, double paramDouble3);
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   private static native void nPlotShadedV(String paramString, double[] paramArrayOfdouble, int paramInt1, double paramDouble1, double paramDouble2, double paramDouble3, int paramInt2);
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   private static native void nPlotShadedV(String paramString, double[] paramArrayOfdouble, int paramInt1, double paramDouble1, double paramDouble2, double paramDouble3, int paramInt2, int paramInt3);
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static void plotShaded(String labelId, short[] xs, short[] ys) {
/*  5375 */     nPlotShaded(labelId, xs, ys);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static void plotShaded(String labelId, short[] xs, short[] ys, double yRef) {
/*  5382 */     nPlotShaded(labelId, xs, ys, yRef);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static void plotShaded(String labelId, short[] xs, short[] ys, double yRef, int flags) {
/*  5389 */     nPlotShaded(labelId, xs, ys, yRef, flags);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static void plotShaded(String labelId, short[] xs, short[] ys, double yRef, int flags, int offset) {
/*  5396 */     nPlotShaded(labelId, xs, ys, yRef, flags, offset);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   private static native void nPlotShaded(String paramString, short[] paramArrayOfshort1, short[] paramArrayOfshort2);
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   private static native void nPlotShaded(String paramString, short[] paramArrayOfshort1, short[] paramArrayOfshort2, double paramDouble);
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   private static native void nPlotShaded(String paramString, short[] paramArrayOfshort1, short[] paramArrayOfshort2, double paramDouble, int paramInt);
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   private static native void nPlotShaded(String paramString, short[] paramArrayOfshort1, short[] paramArrayOfshort2, double paramDouble, int paramInt1, int paramInt2);
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static void plotShaded(String labelId, int[] xs, int[] ys) {
/*  5443 */     nPlotShaded(labelId, xs, ys);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static void plotShaded(String labelId, int[] xs, int[] ys, double yRef) {
/*  5450 */     nPlotShaded(labelId, xs, ys, yRef);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static void plotShaded(String labelId, int[] xs, int[] ys, double yRef, int flags) {
/*  5457 */     nPlotShaded(labelId, xs, ys, yRef, flags);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static void plotShaded(String labelId, int[] xs, int[] ys, double yRef, int flags, int offset) {
/*  5464 */     nPlotShaded(labelId, xs, ys, yRef, flags, offset);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   private static native void nPlotShaded(String paramString, int[] paramArrayOfint1, int[] paramArrayOfint2);
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   private static native void nPlotShaded(String paramString, int[] paramArrayOfint1, int[] paramArrayOfint2, double paramDouble);
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   private static native void nPlotShaded(String paramString, int[] paramArrayOfint1, int[] paramArrayOfint2, double paramDouble, int paramInt);
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   private static native void nPlotShaded(String paramString, int[] paramArrayOfint1, int[] paramArrayOfint2, double paramDouble, int paramInt1, int paramInt2);
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static void plotShaded(String labelId, long[] xs, long[] ys) {
/*  5511 */     nPlotShaded(labelId, xs, ys);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static void plotShaded(String labelId, long[] xs, long[] ys, double yRef) {
/*  5518 */     nPlotShaded(labelId, xs, ys, yRef);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static void plotShaded(String labelId, long[] xs, long[] ys, double yRef, int flags) {
/*  5525 */     nPlotShaded(labelId, xs, ys, yRef, flags);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static void plotShaded(String labelId, long[] xs, long[] ys, double yRef, int flags, int offset) {
/*  5532 */     nPlotShaded(labelId, xs, ys, yRef, flags, offset);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   private static native void nPlotShaded(String paramString, long[] paramArrayOflong1, long[] paramArrayOflong2);
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   private static native void nPlotShaded(String paramString, long[] paramArrayOflong1, long[] paramArrayOflong2, double paramDouble);
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   private static native void nPlotShaded(String paramString, long[] paramArrayOflong1, long[] paramArrayOflong2, double paramDouble, int paramInt);
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   private static native void nPlotShaded(String paramString, long[] paramArrayOflong1, long[] paramArrayOflong2, double paramDouble, int paramInt1, int paramInt2);
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static void plotShaded(String labelId, float[] xs, float[] ys) {
/*  5579 */     nPlotShaded(labelId, xs, ys);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static void plotShaded(String labelId, float[] xs, float[] ys, double yRef) {
/*  5586 */     nPlotShaded(labelId, xs, ys, yRef);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static void plotShaded(String labelId, float[] xs, float[] ys, double yRef, int flags) {
/*  5593 */     nPlotShaded(labelId, xs, ys, yRef, flags);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static void plotShaded(String labelId, float[] xs, float[] ys, double yRef, int flags, int offset) {
/*  5600 */     nPlotShaded(labelId, xs, ys, yRef, flags, offset);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   private static native void nPlotShaded(String paramString, float[] paramArrayOffloat1, float[] paramArrayOffloat2);
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   private static native void nPlotShaded(String paramString, float[] paramArrayOffloat1, float[] paramArrayOffloat2, double paramDouble);
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   private static native void nPlotShaded(String paramString, float[] paramArrayOffloat1, float[] paramArrayOffloat2, double paramDouble, int paramInt);
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   private static native void nPlotShaded(String paramString, float[] paramArrayOffloat1, float[] paramArrayOffloat2, double paramDouble, int paramInt1, int paramInt2);
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static void plotShaded(String labelId, double[] xs, double[] ys) {
/*  5647 */     nPlotShaded(labelId, xs, ys);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static void plotShaded(String labelId, double[] xs, double[] ys, double yRef) {
/*  5654 */     nPlotShaded(labelId, xs, ys, yRef);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static void plotShaded(String labelId, double[] xs, double[] ys, double yRef, int flags) {
/*  5661 */     nPlotShaded(labelId, xs, ys, yRef, flags);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static void plotShaded(String labelId, double[] xs, double[] ys, double yRef, int flags, int offset) {
/*  5668 */     nPlotShaded(labelId, xs, ys, yRef, flags, offset);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   private static native void nPlotShaded(String paramString, double[] paramArrayOfdouble1, double[] paramArrayOfdouble2);
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   private static native void nPlotShaded(String paramString, double[] paramArrayOfdouble1, double[] paramArrayOfdouble2, double paramDouble);
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   private static native void nPlotShaded(String paramString, double[] paramArrayOfdouble1, double[] paramArrayOfdouble2, double paramDouble, int paramInt);
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   private static native void nPlotShaded(String paramString, double[] paramArrayOfdouble1, double[] paramArrayOfdouble2, double paramDouble, int paramInt1, int paramInt2);
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static void plotShadedV(String labelId, short[] xs, short[] ys, int count) {
/*  5715 */     nPlotShadedV(labelId, xs, ys, count);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static void plotShadedV(String labelId, short[] xs, short[] ys, int count, double yRef) {
/*  5722 */     nPlotShadedV(labelId, xs, ys, count, yRef);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static void plotShadedV(String labelId, short[] xs, short[] ys, int count, double yRef, int flags) {
/*  5729 */     nPlotShadedV(labelId, xs, ys, count, yRef, flags);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static void plotShadedV(String labelId, short[] xs, short[] ys, int count, double yRef, int flags, int offset) {
/*  5736 */     nPlotShadedV(labelId, xs, ys, count, yRef, flags, offset);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   private static native void nPlotShadedV(String paramString, short[] paramArrayOfshort1, short[] paramArrayOfshort2, int paramInt);
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   private static native void nPlotShadedV(String paramString, short[] paramArrayOfshort1, short[] paramArrayOfshort2, int paramInt, double paramDouble);
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   private static native void nPlotShadedV(String paramString, short[] paramArrayOfshort1, short[] paramArrayOfshort2, int paramInt1, double paramDouble, int paramInt2);
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   private static native void nPlotShadedV(String paramString, short[] paramArrayOfshort1, short[] paramArrayOfshort2, int paramInt1, double paramDouble, int paramInt2, int paramInt3);
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static void plotShadedV(String labelId, int[] xs, int[] ys, int count) {
/*  5783 */     nPlotShadedV(labelId, xs, ys, count);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static void plotShadedV(String labelId, int[] xs, int[] ys, int count, double yRef) {
/*  5790 */     nPlotShadedV(labelId, xs, ys, count, yRef);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static void plotShadedV(String labelId, int[] xs, int[] ys, int count, double yRef, int flags) {
/*  5797 */     nPlotShadedV(labelId, xs, ys, count, yRef, flags);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static void plotShadedV(String labelId, int[] xs, int[] ys, int count, double yRef, int flags, int offset) {
/*  5804 */     nPlotShadedV(labelId, xs, ys, count, yRef, flags, offset);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   private static native void nPlotShadedV(String paramString, int[] paramArrayOfint1, int[] paramArrayOfint2, int paramInt);
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   private static native void nPlotShadedV(String paramString, int[] paramArrayOfint1, int[] paramArrayOfint2, int paramInt, double paramDouble);
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   private static native void nPlotShadedV(String paramString, int[] paramArrayOfint1, int[] paramArrayOfint2, int paramInt1, double paramDouble, int paramInt2);
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   private static native void nPlotShadedV(String paramString, int[] paramArrayOfint1, int[] paramArrayOfint2, int paramInt1, double paramDouble, int paramInt2, int paramInt3);
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static void plotShadedV(String labelId, long[] xs, long[] ys, int count) {
/*  5851 */     nPlotShadedV(labelId, xs, ys, count);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static void plotShadedV(String labelId, long[] xs, long[] ys, int count, double yRef) {
/*  5858 */     nPlotShadedV(labelId, xs, ys, count, yRef);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static void plotShadedV(String labelId, long[] xs, long[] ys, int count, double yRef, int flags) {
/*  5865 */     nPlotShadedV(labelId, xs, ys, count, yRef, flags);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static void plotShadedV(String labelId, long[] xs, long[] ys, int count, double yRef, int flags, int offset) {
/*  5872 */     nPlotShadedV(labelId, xs, ys, count, yRef, flags, offset);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   private static native void nPlotShadedV(String paramString, long[] paramArrayOflong1, long[] paramArrayOflong2, int paramInt);
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   private static native void nPlotShadedV(String paramString, long[] paramArrayOflong1, long[] paramArrayOflong2, int paramInt, double paramDouble);
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   private static native void nPlotShadedV(String paramString, long[] paramArrayOflong1, long[] paramArrayOflong2, int paramInt1, double paramDouble, int paramInt2);
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   private static native void nPlotShadedV(String paramString, long[] paramArrayOflong1, long[] paramArrayOflong2, int paramInt1, double paramDouble, int paramInt2, int paramInt3);
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static void plotShadedV(String labelId, float[] xs, float[] ys, int count) {
/*  5919 */     nPlotShadedV(labelId, xs, ys, count);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static void plotShadedV(String labelId, float[] xs, float[] ys, int count, double yRef) {
/*  5926 */     nPlotShadedV(labelId, xs, ys, count, yRef);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static void plotShadedV(String labelId, float[] xs, float[] ys, int count, double yRef, int flags) {
/*  5933 */     nPlotShadedV(labelId, xs, ys, count, yRef, flags);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static void plotShadedV(String labelId, float[] xs, float[] ys, int count, double yRef, int flags, int offset) {
/*  5940 */     nPlotShadedV(labelId, xs, ys, count, yRef, flags, offset);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   private static native void nPlotShadedV(String paramString, float[] paramArrayOffloat1, float[] paramArrayOffloat2, int paramInt);
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   private static native void nPlotShadedV(String paramString, float[] paramArrayOffloat1, float[] paramArrayOffloat2, int paramInt, double paramDouble);
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   private static native void nPlotShadedV(String paramString, float[] paramArrayOffloat1, float[] paramArrayOffloat2, int paramInt1, double paramDouble, int paramInt2);
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   private static native void nPlotShadedV(String paramString, float[] paramArrayOffloat1, float[] paramArrayOffloat2, int paramInt1, double paramDouble, int paramInt2, int paramInt3);
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static void plotShadedV(String labelId, double[] xs, double[] ys, int count) {
/*  5987 */     nPlotShadedV(labelId, xs, ys, count);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static void plotShadedV(String labelId, double[] xs, double[] ys, int count, double yRef) {
/*  5994 */     nPlotShadedV(labelId, xs, ys, count, yRef);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static void plotShadedV(String labelId, double[] xs, double[] ys, int count, double yRef, int flags) {
/*  6001 */     nPlotShadedV(labelId, xs, ys, count, yRef, flags);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static void plotShadedV(String labelId, double[] xs, double[] ys, int count, double yRef, int flags, int offset) {
/*  6008 */     nPlotShadedV(labelId, xs, ys, count, yRef, flags, offset);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   private static native void nPlotShadedV(String paramString, double[] paramArrayOfdouble1, double[] paramArrayOfdouble2, int paramInt);
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   private static native void nPlotShadedV(String paramString, double[] paramArrayOfdouble1, double[] paramArrayOfdouble2, int paramInt, double paramDouble);
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   private static native void nPlotShadedV(String paramString, double[] paramArrayOfdouble1, double[] paramArrayOfdouble2, int paramInt1, double paramDouble, int paramInt2);
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   private static native void nPlotShadedV(String paramString, double[] paramArrayOfdouble1, double[] paramArrayOfdouble2, int paramInt1, double paramDouble, int paramInt2, int paramInt3);
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static void plotShaded(String labelId, short[] xs, short[] ys1, short[] ys2) {
/*  6057 */     nPlotShaded(labelId, xs, ys1, ys2);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static void plotShaded(String labelId, short[] xs, short[] ys1, short[] ys2, int flags) {
/*  6064 */     nPlotShaded(labelId, xs, ys1, ys2, flags);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   private static native void nPlotShaded(String paramString, short[] paramArrayOfshort1, short[] paramArrayOfshort2, short[] paramArrayOfshort3);
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   private static native void nPlotShaded(String paramString, short[] paramArrayOfshort1, short[] paramArrayOfshort2, short[] paramArrayOfshort3, int paramInt);
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static void plotShaded(String labelId, int[] xs, int[] ys1, int[] ys2) {
/*  6095 */     nPlotShaded(labelId, xs, ys1, ys2);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static void plotShaded(String labelId, int[] xs, int[] ys1, int[] ys2, int flags) {
/*  6102 */     nPlotShaded(labelId, xs, ys1, ys2, flags);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   private static native void nPlotShaded(String paramString, int[] paramArrayOfint1, int[] paramArrayOfint2, int[] paramArrayOfint3);
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   private static native void nPlotShaded(String paramString, int[] paramArrayOfint1, int[] paramArrayOfint2, int[] paramArrayOfint3, int paramInt);
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static void plotShaded(String labelId, long[] xs, long[] ys1, long[] ys2) {
/*  6133 */     nPlotShaded(labelId, xs, ys1, ys2);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static void plotShaded(String labelId, long[] xs, long[] ys1, long[] ys2, int flags) {
/*  6140 */     nPlotShaded(labelId, xs, ys1, ys2, flags);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   private static native void nPlotShaded(String paramString, long[] paramArrayOflong1, long[] paramArrayOflong2, long[] paramArrayOflong3);
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   private static native void nPlotShaded(String paramString, long[] paramArrayOflong1, long[] paramArrayOflong2, long[] paramArrayOflong3, int paramInt);
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static void plotShaded(String labelId, float[] xs, float[] ys1, float[] ys2) {
/*  6171 */     nPlotShaded(labelId, xs, ys1, ys2);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static void plotShaded(String labelId, float[] xs, float[] ys1, float[] ys2, int flags) {
/*  6178 */     nPlotShaded(labelId, xs, ys1, ys2, flags);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   private static native void nPlotShaded(String paramString, float[] paramArrayOffloat1, float[] paramArrayOffloat2, float[] paramArrayOffloat3);
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   private static native void nPlotShaded(String paramString, float[] paramArrayOffloat1, float[] paramArrayOffloat2, float[] paramArrayOffloat3, int paramInt);
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static void plotShaded(String labelId, double[] xs, double[] ys1, double[] ys2) {
/*  6209 */     nPlotShaded(labelId, xs, ys1, ys2);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static void plotShaded(String labelId, double[] xs, double[] ys1, double[] ys2, int flags) {
/*  6216 */     nPlotShaded(labelId, xs, ys1, ys2, flags);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   private static native void nPlotShaded(String paramString, double[] paramArrayOfdouble1, double[] paramArrayOfdouble2, double[] paramArrayOfdouble3);
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   private static native void nPlotShaded(String paramString, double[] paramArrayOfdouble1, double[] paramArrayOfdouble2, double[] paramArrayOfdouble3, int paramInt);
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static void plotShadedV(String labelId, short[] xs, short[] ys1, short[] ys2, int count) {
/*  6247 */     nPlotShadedV(labelId, xs, ys1, ys2, count);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static void plotShadedV(String labelId, short[] xs, short[] ys1, short[] ys2, int count, int flags) {
/*  6254 */     nPlotShadedV(labelId, xs, ys1, ys2, count, flags);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static void plotShadedV(String labelId, short[] xs, short[] ys1, short[] ys2, int count, int flags, int offset) {
/*  6261 */     nPlotShadedV(labelId, xs, ys1, ys2, count, flags, offset);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   private static native void nPlotShadedV(String paramString, short[] paramArrayOfshort1, short[] paramArrayOfshort2, short[] paramArrayOfshort3, int paramInt);
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   private static native void nPlotShadedV(String paramString, short[] paramArrayOfshort1, short[] paramArrayOfshort2, short[] paramArrayOfshort3, int paramInt1, int paramInt2);
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   private static native void nPlotShadedV(String paramString, short[] paramArrayOfshort1, short[] paramArrayOfshort2, short[] paramArrayOfshort3, int paramInt1, int paramInt2, int paramInt3);
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static void plotShadedV(String labelId, int[] xs, int[] ys1, int[] ys2, int count) {
/*  6304 */     nPlotShadedV(labelId, xs, ys1, ys2, count);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static void plotShadedV(String labelId, int[] xs, int[] ys1, int[] ys2, int count, int flags) {
/*  6311 */     nPlotShadedV(labelId, xs, ys1, ys2, count, flags);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static void plotShadedV(String labelId, int[] xs, int[] ys1, int[] ys2, int count, int flags, int offset) {
/*  6318 */     nPlotShadedV(labelId, xs, ys1, ys2, count, flags, offset);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   private static native void nPlotShadedV(String paramString, int[] paramArrayOfint1, int[] paramArrayOfint2, int[] paramArrayOfint3, int paramInt);
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   private static native void nPlotShadedV(String paramString, int[] paramArrayOfint1, int[] paramArrayOfint2, int[] paramArrayOfint3, int paramInt1, int paramInt2);
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   private static native void nPlotShadedV(String paramString, int[] paramArrayOfint1, int[] paramArrayOfint2, int[] paramArrayOfint3, int paramInt1, int paramInt2, int paramInt3);
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static void plotShadedV(String labelId, long[] xs, long[] ys1, long[] ys2, int count) {
/*  6361 */     nPlotShadedV(labelId, xs, ys1, ys2, count);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static void plotShadedV(String labelId, long[] xs, long[] ys1, long[] ys2, int count, int flags) {
/*  6368 */     nPlotShadedV(labelId, xs, ys1, ys2, count, flags);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static void plotShadedV(String labelId, long[] xs, long[] ys1, long[] ys2, int count, int flags, int offset) {
/*  6375 */     nPlotShadedV(labelId, xs, ys1, ys2, count, flags, offset);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   private static native void nPlotShadedV(String paramString, long[] paramArrayOflong1, long[] paramArrayOflong2, long[] paramArrayOflong3, int paramInt);
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   private static native void nPlotShadedV(String paramString, long[] paramArrayOflong1, long[] paramArrayOflong2, long[] paramArrayOflong3, int paramInt1, int paramInt2);
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   private static native void nPlotShadedV(String paramString, long[] paramArrayOflong1, long[] paramArrayOflong2, long[] paramArrayOflong3, int paramInt1, int paramInt2, int paramInt3);
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static void plotShadedV(String labelId, float[] xs, float[] ys1, float[] ys2, int count) {
/*  6418 */     nPlotShadedV(labelId, xs, ys1, ys2, count);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static void plotShadedV(String labelId, float[] xs, float[] ys1, float[] ys2, int count, int flags) {
/*  6425 */     nPlotShadedV(labelId, xs, ys1, ys2, count, flags);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static void plotShadedV(String labelId, float[] xs, float[] ys1, float[] ys2, int count, int flags, int offset) {
/*  6432 */     nPlotShadedV(labelId, xs, ys1, ys2, count, flags, offset);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   private static native void nPlotShadedV(String paramString, float[] paramArrayOffloat1, float[] paramArrayOffloat2, float[] paramArrayOffloat3, int paramInt);
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   private static native void nPlotShadedV(String paramString, float[] paramArrayOffloat1, float[] paramArrayOffloat2, float[] paramArrayOffloat3, int paramInt1, int paramInt2);
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   private static native void nPlotShadedV(String paramString, float[] paramArrayOffloat1, float[] paramArrayOffloat2, float[] paramArrayOffloat3, int paramInt1, int paramInt2, int paramInt3);
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static void plotShadedV(String labelId, double[] xs, double[] ys1, double[] ys2, int count) {
/*  6475 */     nPlotShadedV(labelId, xs, ys1, ys2, count);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static void plotShadedV(String labelId, double[] xs, double[] ys1, double[] ys2, int count, int flags) {
/*  6482 */     nPlotShadedV(labelId, xs, ys1, ys2, count, flags);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static void plotShadedV(String labelId, double[] xs, double[] ys1, double[] ys2, int count, int flags, int offset) {
/*  6489 */     nPlotShadedV(labelId, xs, ys1, ys2, count, flags, offset);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   private static native void nPlotShadedV(String paramString, double[] paramArrayOfdouble1, double[] paramArrayOfdouble2, double[] paramArrayOfdouble3, int paramInt);
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   private static native void nPlotShadedV(String paramString, double[] paramArrayOfdouble1, double[] paramArrayOfdouble2, double[] paramArrayOfdouble3, int paramInt1, int paramInt2);
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   private static native void nPlotShadedV(String paramString, double[] paramArrayOfdouble1, double[] paramArrayOfdouble2, double[] paramArrayOfdouble3, int paramInt1, int paramInt2, int paramInt3);
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static void plotBars(String labelId, short[] values) {
/*  6534 */     nPlotBars(labelId, values);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static void plotBars(String labelId, short[] values, double barWidth) {
/*  6541 */     nPlotBars(labelId, values, barWidth);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static void plotBars(String labelId, short[] values, double barWidth, double xstart) {
/*  6548 */     nPlotBars(labelId, values, barWidth, xstart);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static void plotBars(String labelId, short[] values, double barWidth, double xstart, int flags) {
/*  6555 */     nPlotBars(labelId, values, barWidth, xstart, flags);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static void plotBars(String labelId, short[] values, double barWidth, double xstart, int flags, int offset) {
/*  6562 */     nPlotBars(labelId, values, barWidth, xstart, flags, offset);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   private static native void nPlotBars(String paramString, short[] paramArrayOfshort);
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   private static native void nPlotBars(String paramString, short[] paramArrayOfshort, double paramDouble);
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   private static native void nPlotBars(String paramString, short[] paramArrayOfshort, double paramDouble1, double paramDouble2);
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   private static native void nPlotBars(String paramString, short[] paramArrayOfshort, double paramDouble1, double paramDouble2, int paramInt);
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   private static native void nPlotBars(String paramString, short[] paramArrayOfshort, double paramDouble1, double paramDouble2, int paramInt1, int paramInt2);
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static void plotBars(String labelId, int[] values) {
/*  6609 */     nPlotBars(labelId, values);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static void plotBars(String labelId, int[] values, double barWidth) {
/*  6616 */     nPlotBars(labelId, values, barWidth);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static void plotBars(String labelId, int[] values, double barWidth, double xstart) {
/*  6623 */     nPlotBars(labelId, values, barWidth, xstart);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static void plotBars(String labelId, int[] values, double barWidth, double xstart, int flags) {
/*  6630 */     nPlotBars(labelId, values, barWidth, xstart, flags);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static void plotBars(String labelId, int[] values, double barWidth, double xstart, int flags, int offset) {
/*  6637 */     nPlotBars(labelId, values, barWidth, xstart, flags, offset);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   private static native void nPlotBars(String paramString, int[] paramArrayOfint);
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   private static native void nPlotBars(String paramString, int[] paramArrayOfint, double paramDouble);
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   private static native void nPlotBars(String paramString, int[] paramArrayOfint, double paramDouble1, double paramDouble2);
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   private static native void nPlotBars(String paramString, int[] paramArrayOfint, double paramDouble1, double paramDouble2, int paramInt);
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   private static native void nPlotBars(String paramString, int[] paramArrayOfint, double paramDouble1, double paramDouble2, int paramInt1, int paramInt2);
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static void plotBars(String labelId, long[] values) {
/*  6684 */     nPlotBars(labelId, values);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static void plotBars(String labelId, long[] values, double barWidth) {
/*  6691 */     nPlotBars(labelId, values, barWidth);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static void plotBars(String labelId, long[] values, double barWidth, double xstart) {
/*  6698 */     nPlotBars(labelId, values, barWidth, xstart);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static void plotBars(String labelId, long[] values, double barWidth, double xstart, int flags) {
/*  6705 */     nPlotBars(labelId, values, barWidth, xstart, flags);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static void plotBars(String labelId, long[] values, double barWidth, double xstart, int flags, int offset) {
/*  6712 */     nPlotBars(labelId, values, barWidth, xstart, flags, offset);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   private static native void nPlotBars(String paramString, long[] paramArrayOflong);
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   private static native void nPlotBars(String paramString, long[] paramArrayOflong, double paramDouble);
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   private static native void nPlotBars(String paramString, long[] paramArrayOflong, double paramDouble1, double paramDouble2);
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   private static native void nPlotBars(String paramString, long[] paramArrayOflong, double paramDouble1, double paramDouble2, int paramInt);
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   private static native void nPlotBars(String paramString, long[] paramArrayOflong, double paramDouble1, double paramDouble2, int paramInt1, int paramInt2);
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static void plotBars(String labelId, float[] values) {
/*  6759 */     nPlotBars(labelId, values);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static void plotBars(String labelId, float[] values, double barWidth) {
/*  6766 */     nPlotBars(labelId, values, barWidth);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static void plotBars(String labelId, float[] values, double barWidth, double xstart) {
/*  6773 */     nPlotBars(labelId, values, barWidth, xstart);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static void plotBars(String labelId, float[] values, double barWidth, double xstart, int flags) {
/*  6780 */     nPlotBars(labelId, values, barWidth, xstart, flags);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static void plotBars(String labelId, float[] values, double barWidth, double xstart, int flags, int offset) {
/*  6787 */     nPlotBars(labelId, values, barWidth, xstart, flags, offset);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   private static native void nPlotBars(String paramString, float[] paramArrayOffloat);
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   private static native void nPlotBars(String paramString, float[] paramArrayOffloat, double paramDouble);
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   private static native void nPlotBars(String paramString, float[] paramArrayOffloat, double paramDouble1, double paramDouble2);
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   private static native void nPlotBars(String paramString, float[] paramArrayOffloat, double paramDouble1, double paramDouble2, int paramInt);
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   private static native void nPlotBars(String paramString, float[] paramArrayOffloat, double paramDouble1, double paramDouble2, int paramInt1, int paramInt2);
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static void plotBars(String labelId, double[] values) {
/*  6834 */     nPlotBars(labelId, values);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static void plotBars(String labelId, double[] values, double barWidth) {
/*  6841 */     nPlotBars(labelId, values, barWidth);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static void plotBars(String labelId, double[] values, double barWidth, double xstart) {
/*  6848 */     nPlotBars(labelId, values, barWidth, xstart);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static void plotBars(String labelId, double[] values, double barWidth, double xstart, int flags) {
/*  6855 */     nPlotBars(labelId, values, barWidth, xstart, flags);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static void plotBars(String labelId, double[] values, double barWidth, double xstart, int flags, int offset) {
/*  6862 */     nPlotBars(labelId, values, barWidth, xstart, flags, offset);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   private static native void nPlotBars(String paramString, double[] paramArrayOfdouble);
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   private static native void nPlotBars(String paramString, double[] paramArrayOfdouble, double paramDouble);
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   private static native void nPlotBars(String paramString, double[] paramArrayOfdouble, double paramDouble1, double paramDouble2);
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   private static native void nPlotBars(String paramString, double[] paramArrayOfdouble, double paramDouble1, double paramDouble2, int paramInt);
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   private static native void nPlotBars(String paramString, double[] paramArrayOfdouble, double paramDouble1, double paramDouble2, int paramInt1, int paramInt2);
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static void plotBarsV(String labelId, short[] values, int count) {
/*  6909 */     nPlotBarsV(labelId, values, count);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static void plotBarsV(String labelId, short[] values, int count, double barWidth) {
/*  6916 */     nPlotBarsV(labelId, values, count, barWidth);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static void plotBarsV(String labelId, short[] values, int count, double barWidth, double xstart) {
/*  6923 */     nPlotBarsV(labelId, values, count, barWidth, xstart);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static void plotBarsV(String labelId, short[] values, int count, double barWidth, double xstart, int flags) {
/*  6930 */     nPlotBarsV(labelId, values, count, barWidth, xstart, flags);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static void plotBarsV(String labelId, short[] values, int count, double barWidth, double xstart, int flags, int offset) {
/*  6937 */     nPlotBarsV(labelId, values, count, barWidth, xstart, flags, offset);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   private static native void nPlotBarsV(String paramString, short[] paramArrayOfshort, int paramInt);
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   private static native void nPlotBarsV(String paramString, short[] paramArrayOfshort, int paramInt, double paramDouble);
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   private static native void nPlotBarsV(String paramString, short[] paramArrayOfshort, int paramInt, double paramDouble1, double paramDouble2);
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   private static native void nPlotBarsV(String paramString, short[] paramArrayOfshort, int paramInt1, double paramDouble1, double paramDouble2, int paramInt2);
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   private static native void nPlotBarsV(String paramString, short[] paramArrayOfshort, int paramInt1, double paramDouble1, double paramDouble2, int paramInt2, int paramInt3);
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static void plotBarsV(String labelId, int[] values, int count) {
/*  6984 */     nPlotBarsV(labelId, values, count);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static void plotBarsV(String labelId, int[] values, int count, double barWidth) {
/*  6991 */     nPlotBarsV(labelId, values, count, barWidth);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static void plotBarsV(String labelId, int[] values, int count, double barWidth, double xstart) {
/*  6998 */     nPlotBarsV(labelId, values, count, barWidth, xstart);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static void plotBarsV(String labelId, int[] values, int count, double barWidth, double xstart, int flags) {
/*  7005 */     nPlotBarsV(labelId, values, count, barWidth, xstart, flags);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static void plotBarsV(String labelId, int[] values, int count, double barWidth, double xstart, int flags, int offset) {
/*  7012 */     nPlotBarsV(labelId, values, count, barWidth, xstart, flags, offset);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   private static native void nPlotBarsV(String paramString, int[] paramArrayOfint, int paramInt);
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   private static native void nPlotBarsV(String paramString, int[] paramArrayOfint, int paramInt, double paramDouble);
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   private static native void nPlotBarsV(String paramString, int[] paramArrayOfint, int paramInt, double paramDouble1, double paramDouble2);
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   private static native void nPlotBarsV(String paramString, int[] paramArrayOfint, int paramInt1, double paramDouble1, double paramDouble2, int paramInt2);
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   private static native void nPlotBarsV(String paramString, int[] paramArrayOfint, int paramInt1, double paramDouble1, double paramDouble2, int paramInt2, int paramInt3);
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static void plotBarsV(String labelId, long[] values, int count) {
/*  7059 */     nPlotBarsV(labelId, values, count);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static void plotBarsV(String labelId, long[] values, int count, double barWidth) {
/*  7066 */     nPlotBarsV(labelId, values, count, barWidth);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static void plotBarsV(String labelId, long[] values, int count, double barWidth, double xstart) {
/*  7073 */     nPlotBarsV(labelId, values, count, barWidth, xstart);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static void plotBarsV(String labelId, long[] values, int count, double barWidth, double xstart, int flags) {
/*  7080 */     nPlotBarsV(labelId, values, count, barWidth, xstart, flags);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static void plotBarsV(String labelId, long[] values, int count, double barWidth, double xstart, int flags, int offset) {
/*  7087 */     nPlotBarsV(labelId, values, count, barWidth, xstart, flags, offset);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   private static native void nPlotBarsV(String paramString, long[] paramArrayOflong, int paramInt);
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   private static native void nPlotBarsV(String paramString, long[] paramArrayOflong, int paramInt, double paramDouble);
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   private static native void nPlotBarsV(String paramString, long[] paramArrayOflong, int paramInt, double paramDouble1, double paramDouble2);
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   private static native void nPlotBarsV(String paramString, long[] paramArrayOflong, int paramInt1, double paramDouble1, double paramDouble2, int paramInt2);
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   private static native void nPlotBarsV(String paramString, long[] paramArrayOflong, int paramInt1, double paramDouble1, double paramDouble2, int paramInt2, int paramInt3);
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static void plotBarsV(String labelId, float[] values, int count) {
/*  7134 */     nPlotBarsV(labelId, values, count);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static void plotBarsV(String labelId, float[] values, int count, double barWidth) {
/*  7141 */     nPlotBarsV(labelId, values, count, barWidth);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static void plotBarsV(String labelId, float[] values, int count, double barWidth, double xstart) {
/*  7148 */     nPlotBarsV(labelId, values, count, barWidth, xstart);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static void plotBarsV(String labelId, float[] values, int count, double barWidth, double xstart, int flags) {
/*  7155 */     nPlotBarsV(labelId, values, count, barWidth, xstart, flags);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static void plotBarsV(String labelId, float[] values, int count, double barWidth, double xstart, int flags, int offset) {
/*  7162 */     nPlotBarsV(labelId, values, count, barWidth, xstart, flags, offset);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   private static native void nPlotBarsV(String paramString, float[] paramArrayOffloat, int paramInt);
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   private static native void nPlotBarsV(String paramString, float[] paramArrayOffloat, int paramInt, double paramDouble);
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   private static native void nPlotBarsV(String paramString, float[] paramArrayOffloat, int paramInt, double paramDouble1, double paramDouble2);
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   private static native void nPlotBarsV(String paramString, float[] paramArrayOffloat, int paramInt1, double paramDouble1, double paramDouble2, int paramInt2);
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   private static native void nPlotBarsV(String paramString, float[] paramArrayOffloat, int paramInt1, double paramDouble1, double paramDouble2, int paramInt2, int paramInt3);
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static void plotBarsV(String labelId, double[] values, int count) {
/*  7209 */     nPlotBarsV(labelId, values, count);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static void plotBarsV(String labelId, double[] values, int count, double barWidth) {
/*  7216 */     nPlotBarsV(labelId, values, count, barWidth);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static void plotBarsV(String labelId, double[] values, int count, double barWidth, double xstart) {
/*  7223 */     nPlotBarsV(labelId, values, count, barWidth, xstart);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static void plotBarsV(String labelId, double[] values, int count, double barWidth, double xstart, int flags) {
/*  7230 */     nPlotBarsV(labelId, values, count, barWidth, xstart, flags);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static void plotBarsV(String labelId, double[] values, int count, double barWidth, double xstart, int flags, int offset) {
/*  7237 */     nPlotBarsV(labelId, values, count, barWidth, xstart, flags, offset);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   private static native void nPlotBarsV(String paramString, double[] paramArrayOfdouble, int paramInt);
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   private static native void nPlotBarsV(String paramString, double[] paramArrayOfdouble, int paramInt, double paramDouble);
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   private static native void nPlotBarsV(String paramString, double[] paramArrayOfdouble, int paramInt, double paramDouble1, double paramDouble2);
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   private static native void nPlotBarsV(String paramString, double[] paramArrayOfdouble, int paramInt1, double paramDouble1, double paramDouble2, int paramInt2);
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   private static native void nPlotBarsV(String paramString, double[] paramArrayOfdouble, int paramInt1, double paramDouble1, double paramDouble2, int paramInt2, int paramInt3);
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static void plotBars(String labelId, short[] xs, short[] ys) {
/*  7286 */     nPlotBars(labelId, xs, ys);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static void plotBars(String labelId, short[] xs, short[] ys, int flags) {
/*  7293 */     nPlotBars(labelId, xs, ys, flags);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static void plotBars(String labelId, short[] xs, short[] ys, int flags, int offset) {
/*  7300 */     nPlotBars(labelId, xs, ys, flags, offset);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   private static native void nPlotBars(String paramString, short[] paramArrayOfshort1, short[] paramArrayOfshort2);
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   private static native void nPlotBars(String paramString, short[] paramArrayOfshort1, short[] paramArrayOfshort2, int paramInt);
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   private static native void nPlotBars(String paramString, short[] paramArrayOfshort1, short[] paramArrayOfshort2, int paramInt1, int paramInt2);
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static void plotBars(String labelId, int[] xs, int[] ys) {
/*  7337 */     nPlotBars(labelId, xs, ys);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static void plotBars(String labelId, int[] xs, int[] ys, int flags) {
/*  7344 */     nPlotBars(labelId, xs, ys, flags);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static void plotBars(String labelId, int[] xs, int[] ys, int flags, int offset) {
/*  7351 */     nPlotBars(labelId, xs, ys, flags, offset);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   private static native void nPlotBars(String paramString, int[] paramArrayOfint1, int[] paramArrayOfint2);
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   private static native void nPlotBars(String paramString, int[] paramArrayOfint1, int[] paramArrayOfint2, int paramInt);
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   private static native void nPlotBars(String paramString, int[] paramArrayOfint1, int[] paramArrayOfint2, int paramInt1, int paramInt2);
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static void plotBars(String labelId, long[] xs, long[] ys) {
/*  7388 */     nPlotBars(labelId, xs, ys);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static void plotBars(String labelId, long[] xs, long[] ys, int flags) {
/*  7395 */     nPlotBars(labelId, xs, ys, flags);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static void plotBars(String labelId, long[] xs, long[] ys, int flags, int offset) {
/*  7402 */     nPlotBars(labelId, xs, ys, flags, offset);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   private static native void nPlotBars(String paramString, long[] paramArrayOflong1, long[] paramArrayOflong2);
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   private static native void nPlotBars(String paramString, long[] paramArrayOflong1, long[] paramArrayOflong2, int paramInt);
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   private static native void nPlotBars(String paramString, long[] paramArrayOflong1, long[] paramArrayOflong2, int paramInt1, int paramInt2);
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static void plotBars(String labelId, float[] xs, float[] ys) {
/*  7439 */     nPlotBars(labelId, xs, ys);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static void plotBars(String labelId, float[] xs, float[] ys, int flags) {
/*  7446 */     nPlotBars(labelId, xs, ys, flags);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static void plotBars(String labelId, float[] xs, float[] ys, int flags, int offset) {
/*  7453 */     nPlotBars(labelId, xs, ys, flags, offset);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   private static native void nPlotBars(String paramString, float[] paramArrayOffloat1, float[] paramArrayOffloat2);
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   private static native void nPlotBars(String paramString, float[] paramArrayOffloat1, float[] paramArrayOffloat2, int paramInt);
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   private static native void nPlotBars(String paramString, float[] paramArrayOffloat1, float[] paramArrayOffloat2, int paramInt1, int paramInt2);
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static void plotBars(String labelId, double[] xs, double[] ys) {
/*  7490 */     nPlotBars(labelId, xs, ys);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static void plotBars(String labelId, double[] xs, double[] ys, int flags) {
/*  7497 */     nPlotBars(labelId, xs, ys, flags);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static void plotBars(String labelId, double[] xs, double[] ys, int flags, int offset) {
/*  7504 */     nPlotBars(labelId, xs, ys, flags, offset);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   private static native void nPlotBars(String paramString, double[] paramArrayOfdouble1, double[] paramArrayOfdouble2);
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   private static native void nPlotBars(String paramString, double[] paramArrayOfdouble1, double[] paramArrayOfdouble2, int paramInt);
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   private static native void nPlotBars(String paramString, double[] paramArrayOfdouble1, double[] paramArrayOfdouble2, int paramInt1, int paramInt2);
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static void plotBarsV(String labelId, short[] xs, short[] ys, double barWidth) {
/*  7541 */     nPlotBarsV(labelId, xs, ys, barWidth);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static void plotBarsV(String labelId, short[] xs, short[] ys, double barWidth, int flags) {
/*  7548 */     nPlotBarsV(labelId, xs, ys, barWidth, flags);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static void plotBarsV(String labelId, short[] xs, short[] ys, double barWidth, int flags, int offset) {
/*  7555 */     nPlotBarsV(labelId, xs, ys, barWidth, flags, offset);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   private static native void nPlotBarsV(String paramString, short[] paramArrayOfshort1, short[] paramArrayOfshort2, double paramDouble);
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   private static native void nPlotBarsV(String paramString, short[] paramArrayOfshort1, short[] paramArrayOfshort2, double paramDouble, int paramInt);
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   private static native void nPlotBarsV(String paramString, short[] paramArrayOfshort1, short[] paramArrayOfshort2, double paramDouble, int paramInt1, int paramInt2);
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static void plotBarsV(String labelId, int[] xs, int[] ys, double barWidth) {
/*  7592 */     nPlotBarsV(labelId, xs, ys, barWidth);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static void plotBarsV(String labelId, int[] xs, int[] ys, double barWidth, int flags) {
/*  7599 */     nPlotBarsV(labelId, xs, ys, barWidth, flags);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static void plotBarsV(String labelId, int[] xs, int[] ys, double barWidth, int flags, int offset) {
/*  7606 */     nPlotBarsV(labelId, xs, ys, barWidth, flags, offset);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   private static native void nPlotBarsV(String paramString, int[] paramArrayOfint1, int[] paramArrayOfint2, double paramDouble);
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   private static native void nPlotBarsV(String paramString, int[] paramArrayOfint1, int[] paramArrayOfint2, double paramDouble, int paramInt);
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   private static native void nPlotBarsV(String paramString, int[] paramArrayOfint1, int[] paramArrayOfint2, double paramDouble, int paramInt1, int paramInt2);
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static void plotBarsV(String labelId, long[] xs, long[] ys, double barWidth) {
/*  7643 */     nPlotBarsV(labelId, xs, ys, barWidth);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static void plotBarsV(String labelId, long[] xs, long[] ys, double barWidth, int flags) {
/*  7650 */     nPlotBarsV(labelId, xs, ys, barWidth, flags);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static void plotBarsV(String labelId, long[] xs, long[] ys, double barWidth, int flags, int offset) {
/*  7657 */     nPlotBarsV(labelId, xs, ys, barWidth, flags, offset);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   private static native void nPlotBarsV(String paramString, long[] paramArrayOflong1, long[] paramArrayOflong2, double paramDouble);
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   private static native void nPlotBarsV(String paramString, long[] paramArrayOflong1, long[] paramArrayOflong2, double paramDouble, int paramInt);
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   private static native void nPlotBarsV(String paramString, long[] paramArrayOflong1, long[] paramArrayOflong2, double paramDouble, int paramInt1, int paramInt2);
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static void plotBarsV(String labelId, float[] xs, float[] ys, double barWidth) {
/*  7694 */     nPlotBarsV(labelId, xs, ys, barWidth);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static void plotBarsV(String labelId, float[] xs, float[] ys, double barWidth, int flags) {
/*  7701 */     nPlotBarsV(labelId, xs, ys, barWidth, flags);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static void plotBarsV(String labelId, float[] xs, float[] ys, double barWidth, int flags, int offset) {
/*  7708 */     nPlotBarsV(labelId, xs, ys, barWidth, flags, offset);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   private static native void nPlotBarsV(String paramString, float[] paramArrayOffloat1, float[] paramArrayOffloat2, double paramDouble);
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   private static native void nPlotBarsV(String paramString, float[] paramArrayOffloat1, float[] paramArrayOffloat2, double paramDouble, int paramInt);
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   private static native void nPlotBarsV(String paramString, float[] paramArrayOffloat1, float[] paramArrayOffloat2, double paramDouble, int paramInt1, int paramInt2);
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static void plotBarsV(String labelId, double[] xs, double[] ys, double barWidth) {
/*  7745 */     nPlotBarsV(labelId, xs, ys, barWidth);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static void plotBarsV(String labelId, double[] xs, double[] ys, double barWidth, int flags) {
/*  7752 */     nPlotBarsV(labelId, xs, ys, barWidth, flags);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static void plotBarsV(String labelId, double[] xs, double[] ys, double barWidth, int flags, int offset) {
/*  7759 */     nPlotBarsV(labelId, xs, ys, barWidth, flags, offset);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   private static native void nPlotBarsV(String paramString, double[] paramArrayOfdouble1, double[] paramArrayOfdouble2, double paramDouble);
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   private static native void nPlotBarsV(String paramString, double[] paramArrayOfdouble1, double[] paramArrayOfdouble2, double paramDouble, int paramInt);
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   private static native void nPlotBarsV(String paramString, double[] paramArrayOfdouble1, double[] paramArrayOfdouble2, double paramDouble, int paramInt1, int paramInt2);
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static void plotBarsV(String labelId, short[] xs, short[] ys, int count, double barWidth) {
/*  7796 */     nPlotBarsV(labelId, xs, ys, count, barWidth);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static void plotBarsV(String labelId, short[] xs, short[] ys, int count, double barWidth, int flags) {
/*  7803 */     nPlotBarsV(labelId, xs, ys, count, barWidth, flags);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static void plotBarsV(String labelId, short[] xs, short[] ys, int count, double barWidth, int flags, int offset) {
/*  7810 */     nPlotBarsV(labelId, xs, ys, count, barWidth, flags, offset);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   private static native void nPlotBarsV(String paramString, short[] paramArrayOfshort1, short[] paramArrayOfshort2, int paramInt, double paramDouble);
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   private static native void nPlotBarsV(String paramString, short[] paramArrayOfshort1, short[] paramArrayOfshort2, int paramInt1, double paramDouble, int paramInt2);
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   private static native void nPlotBarsV(String paramString, short[] paramArrayOfshort1, short[] paramArrayOfshort2, int paramInt1, double paramDouble, int paramInt2, int paramInt3);
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static void plotBarsV(String labelId, int[] xs, int[] ys, int count, double barWidth) {
/*  7847 */     nPlotBarsV(labelId, xs, ys, count, barWidth);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static void plotBarsV(String labelId, int[] xs, int[] ys, int count, double barWidth, int flags) {
/*  7854 */     nPlotBarsV(labelId, xs, ys, count, barWidth, flags);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static void plotBarsV(String labelId, int[] xs, int[] ys, int count, double barWidth, int flags, int offset) {
/*  7861 */     nPlotBarsV(labelId, xs, ys, count, barWidth, flags, offset);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   private static native void nPlotBarsV(String paramString, int[] paramArrayOfint1, int[] paramArrayOfint2, int paramInt, double paramDouble);
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   private static native void nPlotBarsV(String paramString, int[] paramArrayOfint1, int[] paramArrayOfint2, int paramInt1, double paramDouble, int paramInt2);
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   private static native void nPlotBarsV(String paramString, int[] paramArrayOfint1, int[] paramArrayOfint2, int paramInt1, double paramDouble, int paramInt2, int paramInt3);
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static void plotBarsV(String labelId, long[] xs, long[] ys, int count, double barWidth) {
/*  7898 */     nPlotBarsV(labelId, xs, ys, count, barWidth);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static void plotBarsV(String labelId, long[] xs, long[] ys, int count, double barWidth, int flags) {
/*  7905 */     nPlotBarsV(labelId, xs, ys, count, barWidth, flags);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static void plotBarsV(String labelId, long[] xs, long[] ys, int count, double barWidth, int flags, int offset) {
/*  7912 */     nPlotBarsV(labelId, xs, ys, count, barWidth, flags, offset);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   private static native void nPlotBarsV(String paramString, long[] paramArrayOflong1, long[] paramArrayOflong2, int paramInt, double paramDouble);
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   private static native void nPlotBarsV(String paramString, long[] paramArrayOflong1, long[] paramArrayOflong2, int paramInt1, double paramDouble, int paramInt2);
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   private static native void nPlotBarsV(String paramString, long[] paramArrayOflong1, long[] paramArrayOflong2, int paramInt1, double paramDouble, int paramInt2, int paramInt3);
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static void plotBarsV(String labelId, float[] xs, float[] ys, int count, double barWidth) {
/*  7949 */     nPlotBarsV(labelId, xs, ys, count, barWidth);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static void plotBarsV(String labelId, float[] xs, float[] ys, int count, double barWidth, int flags) {
/*  7956 */     nPlotBarsV(labelId, xs, ys, count, barWidth, flags);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static void plotBarsV(String labelId, float[] xs, float[] ys, int count, double barWidth, int flags, int offset) {
/*  7963 */     nPlotBarsV(labelId, xs, ys, count, barWidth, flags, offset);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   private static native void nPlotBarsV(String paramString, float[] paramArrayOffloat1, float[] paramArrayOffloat2, int paramInt, double paramDouble);
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   private static native void nPlotBarsV(String paramString, float[] paramArrayOffloat1, float[] paramArrayOffloat2, int paramInt1, double paramDouble, int paramInt2);
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   private static native void nPlotBarsV(String paramString, float[] paramArrayOffloat1, float[] paramArrayOffloat2, int paramInt1, double paramDouble, int paramInt2, int paramInt3);
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static void plotBarsV(String labelId, double[] xs, double[] ys, int count, double barWidth) {
/*  8000 */     nPlotBarsV(labelId, xs, ys, count, barWidth);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static void plotBarsV(String labelId, double[] xs, double[] ys, int count, double barWidth, int flags) {
/*  8007 */     nPlotBarsV(labelId, xs, ys, count, barWidth, flags);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static void plotBarsV(String labelId, double[] xs, double[] ys, int count, double barWidth, int flags, int offset) {
/*  8014 */     nPlotBarsV(labelId, xs, ys, count, barWidth, flags, offset);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   private static native void nPlotBarsV(String paramString, double[] paramArrayOfdouble1, double[] paramArrayOfdouble2, int paramInt, double paramDouble);
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   private static native void nPlotBarsV(String paramString, double[] paramArrayOfdouble1, double[] paramArrayOfdouble2, int paramInt1, double paramDouble, int paramInt2);
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   private static native void nPlotBarsV(String paramString, double[] paramArrayOfdouble1, double[] paramArrayOfdouble2, int paramInt1, double paramDouble, int paramInt2, int paramInt3);
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static void plotBarGroups(String[] labelIds, short[] values, int groupCount) {
/*  8051 */     nPlotBarGroups(labelIds, labelIds.length, values, groupCount);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static void plotBarGroups(String[] labelIds, short[] values, int groupCount, double groupSize) {
/*  8058 */     nPlotBarGroups(labelIds, labelIds.length, values, groupCount, groupSize);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static void plotBarGroups(String[] labelIds, short[] values, int groupCount, double groupSize, double shift) {
/*  8065 */     nPlotBarGroups(labelIds, labelIds.length, values, groupCount, groupSize, shift);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static void plotBarGroups(String[] labelIds, short[] values, int groupCount, double groupSize, double shift, int flags) {
/*  8072 */     nPlotBarGroups(labelIds, labelIds.length, values, groupCount, groupSize, shift, flags);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   private static native void nPlotBarGroups(String[] paramArrayOfString, int paramInt1, short[] paramArrayOfshort, int paramInt2);
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   private static native void nPlotBarGroups(String[] paramArrayOfString, int paramInt1, short[] paramArrayOfshort, int paramInt2, double paramDouble);
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   private static native void nPlotBarGroups(String[] paramArrayOfString, int paramInt1, short[] paramArrayOfshort, int paramInt2, double paramDouble1, double paramDouble2);
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   private static native void nPlotBarGroups(String[] paramArrayOfString, int paramInt1, short[] paramArrayOfshort, int paramInt2, double paramDouble1, double paramDouble2, int paramInt3);
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static void plotBarGroups(String[] labelIds, int[] values, int groupCount) {
/*  8143 */     nPlotBarGroups(labelIds, labelIds.length, values, groupCount);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static void plotBarGroups(String[] labelIds, int[] values, int groupCount, double groupSize) {
/*  8150 */     nPlotBarGroups(labelIds, labelIds.length, values, groupCount, groupSize);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static void plotBarGroups(String[] labelIds, int[] values, int groupCount, double groupSize, double shift) {
/*  8157 */     nPlotBarGroups(labelIds, labelIds.length, values, groupCount, groupSize, shift);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static void plotBarGroups(String[] labelIds, int[] values, int groupCount, double groupSize, double shift, int flags) {
/*  8164 */     nPlotBarGroups(labelIds, labelIds.length, values, groupCount, groupSize, shift, flags);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   private static native void nPlotBarGroups(String[] paramArrayOfString, int paramInt1, int[] paramArrayOfint, int paramInt2);
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   private static native void nPlotBarGroups(String[] paramArrayOfString, int paramInt1, int[] paramArrayOfint, int paramInt2, double paramDouble);
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   private static native void nPlotBarGroups(String[] paramArrayOfString, int paramInt1, int[] paramArrayOfint, int paramInt2, double paramDouble1, double paramDouble2);
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   private static native void nPlotBarGroups(String[] paramArrayOfString, int paramInt1, int[] paramArrayOfint, int paramInt2, double paramDouble1, double paramDouble2, int paramInt3);
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static void plotBarGroups(String[] labelIds, long[] values, int groupCount) {
/*  8235 */     nPlotBarGroups(labelIds, labelIds.length, values, groupCount);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static void plotBarGroups(String[] labelIds, long[] values, int groupCount, double groupSize) {
/*  8242 */     nPlotBarGroups(labelIds, labelIds.length, values, groupCount, groupSize);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static void plotBarGroups(String[] labelIds, long[] values, int groupCount, double groupSize, double shift) {
/*  8249 */     nPlotBarGroups(labelIds, labelIds.length, values, groupCount, groupSize, shift);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static void plotBarGroups(String[] labelIds, long[] values, int groupCount, double groupSize, double shift, int flags) {
/*  8256 */     nPlotBarGroups(labelIds, labelIds.length, values, groupCount, groupSize, shift, flags);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   private static native void nPlotBarGroups(String[] paramArrayOfString, int paramInt1, long[] paramArrayOflong, int paramInt2);
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   private static native void nPlotBarGroups(String[] paramArrayOfString, int paramInt1, long[] paramArrayOflong, int paramInt2, double paramDouble);
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   private static native void nPlotBarGroups(String[] paramArrayOfString, int paramInt1, long[] paramArrayOflong, int paramInt2, double paramDouble1, double paramDouble2);
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   private static native void nPlotBarGroups(String[] paramArrayOfString, int paramInt1, long[] paramArrayOflong, int paramInt2, double paramDouble1, double paramDouble2, int paramInt3);
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static void plotBarGroups(String[] labelIds, float[] values, int groupCount) {
/*  8327 */     nPlotBarGroups(labelIds, labelIds.length, values, groupCount);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static void plotBarGroups(String[] labelIds, float[] values, int groupCount, double groupSize) {
/*  8334 */     nPlotBarGroups(labelIds, labelIds.length, values, groupCount, groupSize);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static void plotBarGroups(String[] labelIds, float[] values, int groupCount, double groupSize, double shift) {
/*  8341 */     nPlotBarGroups(labelIds, labelIds.length, values, groupCount, groupSize, shift);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static void plotBarGroups(String[] labelIds, float[] values, int groupCount, double groupSize, double shift, int flags) {
/*  8348 */     nPlotBarGroups(labelIds, labelIds.length, values, groupCount, groupSize, shift, flags);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   private static native void nPlotBarGroups(String[] paramArrayOfString, int paramInt1, float[] paramArrayOffloat, int paramInt2);
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   private static native void nPlotBarGroups(String[] paramArrayOfString, int paramInt1, float[] paramArrayOffloat, int paramInt2, double paramDouble);
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   private static native void nPlotBarGroups(String[] paramArrayOfString, int paramInt1, float[] paramArrayOffloat, int paramInt2, double paramDouble1, double paramDouble2);
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   private static native void nPlotBarGroups(String[] paramArrayOfString, int paramInt1, float[] paramArrayOffloat, int paramInt2, double paramDouble1, double paramDouble2, int paramInt3);
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static void plotBarGroups(String[] labelIds, double[] values, int groupCount) {
/*  8419 */     nPlotBarGroups(labelIds, labelIds.length, values, groupCount);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static void plotBarGroups(String[] labelIds, double[] values, int groupCount, double groupSize) {
/*  8426 */     nPlotBarGroups(labelIds, labelIds.length, values, groupCount, groupSize);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static void plotBarGroups(String[] labelIds, double[] values, int groupCount, double groupSize, double shift) {
/*  8433 */     nPlotBarGroups(labelIds, labelIds.length, values, groupCount, groupSize, shift);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static void plotBarGroups(String[] labelIds, double[] values, int groupCount, double groupSize, double shift, int flags) {
/*  8440 */     nPlotBarGroups(labelIds, labelIds.length, values, groupCount, groupSize, shift, flags);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   private static native void nPlotBarGroups(String[] paramArrayOfString, int paramInt1, double[] paramArrayOfdouble, int paramInt2);
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   private static native void nPlotBarGroups(String[] paramArrayOfString, int paramInt1, double[] paramArrayOfdouble, int paramInt2, double paramDouble);
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   private static native void nPlotBarGroups(String[] paramArrayOfString, int paramInt1, double[] paramArrayOfdouble, int paramInt2, double paramDouble1, double paramDouble2);
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   private static native void nPlotBarGroups(String[] paramArrayOfString, int paramInt1, double[] paramArrayOfdouble, int paramInt2, double paramDouble1, double paramDouble2, int paramInt3);
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static void plotBarGroupsV(String[] labelIds, short[] values, int itemCount, int groupCount) {
/*  8511 */     nPlotBarGroupsV(labelIds, labelIds.length, values, itemCount, groupCount);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static void plotBarGroupsV(String[] labelIds, short[] values, int itemCount, int groupCount, double groupSize) {
/*  8518 */     nPlotBarGroupsV(labelIds, labelIds.length, values, itemCount, groupCount, groupSize);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static void plotBarGroupsV(String[] labelIds, short[] values, int itemCount, int groupCount, double groupSize, double shift) {
/*  8525 */     nPlotBarGroupsV(labelIds, labelIds.length, values, itemCount, groupCount, groupSize, shift);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static void plotBarGroupsV(String[] labelIds, short[] values, int itemCount, int groupCount, double groupSize, double shift, int flags) {
/*  8532 */     nPlotBarGroupsV(labelIds, labelIds.length, values, itemCount, groupCount, groupSize, shift, flags);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   private static native void nPlotBarGroupsV(String[] paramArrayOfString, int paramInt1, short[] paramArrayOfshort, int paramInt2, int paramInt3);
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   private static native void nPlotBarGroupsV(String[] paramArrayOfString, int paramInt1, short[] paramArrayOfshort, int paramInt2, int paramInt3, double paramDouble);
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   private static native void nPlotBarGroupsV(String[] paramArrayOfString, int paramInt1, short[] paramArrayOfshort, int paramInt2, int paramInt3, double paramDouble1, double paramDouble2);
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   private static native void nPlotBarGroupsV(String[] paramArrayOfString, int paramInt1, short[] paramArrayOfshort, int paramInt2, int paramInt3, double paramDouble1, double paramDouble2, int paramInt4);
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static void plotBarGroupsV(String[] labelIds, int[] values, int itemCount, int groupCount) {
/*  8603 */     nPlotBarGroupsV(labelIds, labelIds.length, values, itemCount, groupCount);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static void plotBarGroupsV(String[] labelIds, int[] values, int itemCount, int groupCount, double groupSize) {
/*  8610 */     nPlotBarGroupsV(labelIds, labelIds.length, values, itemCount, groupCount, groupSize);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static void plotBarGroupsV(String[] labelIds, int[] values, int itemCount, int groupCount, double groupSize, double shift) {
/*  8617 */     nPlotBarGroupsV(labelIds, labelIds.length, values, itemCount, groupCount, groupSize, shift);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static void plotBarGroupsV(String[] labelIds, int[] values, int itemCount, int groupCount, double groupSize, double shift, int flags) {
/*  8624 */     nPlotBarGroupsV(labelIds, labelIds.length, values, itemCount, groupCount, groupSize, shift, flags);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   private static native void nPlotBarGroupsV(String[] paramArrayOfString, int paramInt1, int[] paramArrayOfint, int paramInt2, int paramInt3);
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   private static native void nPlotBarGroupsV(String[] paramArrayOfString, int paramInt1, int[] paramArrayOfint, int paramInt2, int paramInt3, double paramDouble);
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   private static native void nPlotBarGroupsV(String[] paramArrayOfString, int paramInt1, int[] paramArrayOfint, int paramInt2, int paramInt3, double paramDouble1, double paramDouble2);
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   private static native void nPlotBarGroupsV(String[] paramArrayOfString, int paramInt1, int[] paramArrayOfint, int paramInt2, int paramInt3, double paramDouble1, double paramDouble2, int paramInt4);
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static void plotBarGroupsV(String[] labelIds, long[] values, int itemCount, int groupCount) {
/*  8695 */     nPlotBarGroupsV(labelIds, labelIds.length, values, itemCount, groupCount);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static void plotBarGroupsV(String[] labelIds, long[] values, int itemCount, int groupCount, double groupSize) {
/*  8702 */     nPlotBarGroupsV(labelIds, labelIds.length, values, itemCount, groupCount, groupSize);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static void plotBarGroupsV(String[] labelIds, long[] values, int itemCount, int groupCount, double groupSize, double shift) {
/*  8709 */     nPlotBarGroupsV(labelIds, labelIds.length, values, itemCount, groupCount, groupSize, shift);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static void plotBarGroupsV(String[] labelIds, long[] values, int itemCount, int groupCount, double groupSize, double shift, int flags) {
/*  8716 */     nPlotBarGroupsV(labelIds, labelIds.length, values, itemCount, groupCount, groupSize, shift, flags);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   private static native void nPlotBarGroupsV(String[] paramArrayOfString, int paramInt1, long[] paramArrayOflong, int paramInt2, int paramInt3);
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   private static native void nPlotBarGroupsV(String[] paramArrayOfString, int paramInt1, long[] paramArrayOflong, int paramInt2, int paramInt3, double paramDouble);
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   private static native void nPlotBarGroupsV(String[] paramArrayOfString, int paramInt1, long[] paramArrayOflong, int paramInt2, int paramInt3, double paramDouble1, double paramDouble2);
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   private static native void nPlotBarGroupsV(String[] paramArrayOfString, int paramInt1, long[] paramArrayOflong, int paramInt2, int paramInt3, double paramDouble1, double paramDouble2, int paramInt4);
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static void plotBarGroupsV(String[] labelIds, float[] values, int itemCount, int groupCount) {
/*  8787 */     nPlotBarGroupsV(labelIds, labelIds.length, values, itemCount, groupCount);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static void plotBarGroupsV(String[] labelIds, float[] values, int itemCount, int groupCount, double groupSize) {
/*  8794 */     nPlotBarGroupsV(labelIds, labelIds.length, values, itemCount, groupCount, groupSize);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static void plotBarGroupsV(String[] labelIds, float[] values, int itemCount, int groupCount, double groupSize, double shift) {
/*  8801 */     nPlotBarGroupsV(labelIds, labelIds.length, values, itemCount, groupCount, groupSize, shift);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static void plotBarGroupsV(String[] labelIds, float[] values, int itemCount, int groupCount, double groupSize, double shift, int flags) {
/*  8808 */     nPlotBarGroupsV(labelIds, labelIds.length, values, itemCount, groupCount, groupSize, shift, flags);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   private static native void nPlotBarGroupsV(String[] paramArrayOfString, int paramInt1, float[] paramArrayOffloat, int paramInt2, int paramInt3);
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   private static native void nPlotBarGroupsV(String[] paramArrayOfString, int paramInt1, float[] paramArrayOffloat, int paramInt2, int paramInt3, double paramDouble);
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   private static native void nPlotBarGroupsV(String[] paramArrayOfString, int paramInt1, float[] paramArrayOffloat, int paramInt2, int paramInt3, double paramDouble1, double paramDouble2);
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   private static native void nPlotBarGroupsV(String[] paramArrayOfString, int paramInt1, float[] paramArrayOffloat, int paramInt2, int paramInt3, double paramDouble1, double paramDouble2, int paramInt4);
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static void plotBarGroupsV(String[] labelIds, double[] values, int itemCount, int groupCount) {
/*  8879 */     nPlotBarGroupsV(labelIds, labelIds.length, values, itemCount, groupCount);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static void plotBarGroupsV(String[] labelIds, double[] values, int itemCount, int groupCount, double groupSize) {
/*  8886 */     nPlotBarGroupsV(labelIds, labelIds.length, values, itemCount, groupCount, groupSize);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static void plotBarGroupsV(String[] labelIds, double[] values, int itemCount, int groupCount, double groupSize, double shift) {
/*  8893 */     nPlotBarGroupsV(labelIds, labelIds.length, values, itemCount, groupCount, groupSize, shift);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static void plotBarGroupsV(String[] labelIds, double[] values, int itemCount, int groupCount, double groupSize, double shift, int flags) {
/*  8900 */     nPlotBarGroupsV(labelIds, labelIds.length, values, itemCount, groupCount, groupSize, shift, flags);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   private static native void nPlotBarGroupsV(String[] paramArrayOfString, int paramInt1, double[] paramArrayOfdouble, int paramInt2, int paramInt3);
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   private static native void nPlotBarGroupsV(String[] paramArrayOfString, int paramInt1, double[] paramArrayOfdouble, int paramInt2, int paramInt3, double paramDouble);
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   private static native void nPlotBarGroupsV(String[] paramArrayOfString, int paramInt1, double[] paramArrayOfdouble, int paramInt2, int paramInt3, double paramDouble1, double paramDouble2);
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   private static native void nPlotBarGroupsV(String[] paramArrayOfString, int paramInt1, double[] paramArrayOfdouble, int paramInt2, int paramInt3, double paramDouble1, double paramDouble2, int paramInt4);
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static void plotErrorBars(String labelId, short[] xs, short[] ys, short[] err) {
/*  8971 */     nPlotErrorBars(labelId, xs, ys, err);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static void plotErrorBars(String labelId, short[] xs, short[] ys, short[] err, int flags) {
/*  8978 */     nPlotErrorBars(labelId, xs, ys, err, flags);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static void plotErrorBars(String labelId, short[] xs, short[] ys, short[] err, int flags, int offset) {
/*  8985 */     nPlotErrorBars(labelId, xs, ys, err, flags, offset);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   private static native void nPlotErrorBars(String paramString, short[] paramArrayOfshort1, short[] paramArrayOfshort2, short[] paramArrayOfshort3);
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   private static native void nPlotErrorBars(String paramString, short[] paramArrayOfshort1, short[] paramArrayOfshort2, short[] paramArrayOfshort3, int paramInt);
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   private static native void nPlotErrorBars(String paramString, short[] paramArrayOfshort1, short[] paramArrayOfshort2, short[] paramArrayOfshort3, int paramInt1, int paramInt2);
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static void plotErrorBars(String labelId, int[] xs, int[] ys, int[] err) {
/*  9028 */     nPlotErrorBars(labelId, xs, ys, err);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static void plotErrorBars(String labelId, int[] xs, int[] ys, int[] err, int flags) {
/*  9035 */     nPlotErrorBars(labelId, xs, ys, err, flags);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static void plotErrorBars(String labelId, int[] xs, int[] ys, int[] err, int flags, int offset) {
/*  9042 */     nPlotErrorBars(labelId, xs, ys, err, flags, offset);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   private static native void nPlotErrorBars(String paramString, int[] paramArrayOfint1, int[] paramArrayOfint2, int[] paramArrayOfint3);
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   private static native void nPlotErrorBars(String paramString, int[] paramArrayOfint1, int[] paramArrayOfint2, int[] paramArrayOfint3, int paramInt);
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   private static native void nPlotErrorBars(String paramString, int[] paramArrayOfint1, int[] paramArrayOfint2, int[] paramArrayOfint3, int paramInt1, int paramInt2);
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static void plotErrorBars(String labelId, long[] xs, long[] ys, long[] err) {
/*  9085 */     nPlotErrorBars(labelId, xs, ys, err);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static void plotErrorBars(String labelId, long[] xs, long[] ys, long[] err, int flags) {
/*  9092 */     nPlotErrorBars(labelId, xs, ys, err, flags);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static void plotErrorBars(String labelId, long[] xs, long[] ys, long[] err, int flags, int offset) {
/*  9099 */     nPlotErrorBars(labelId, xs, ys, err, flags, offset);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   private static native void nPlotErrorBars(String paramString, long[] paramArrayOflong1, long[] paramArrayOflong2, long[] paramArrayOflong3);
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   private static native void nPlotErrorBars(String paramString, long[] paramArrayOflong1, long[] paramArrayOflong2, long[] paramArrayOflong3, int paramInt);
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   private static native void nPlotErrorBars(String paramString, long[] paramArrayOflong1, long[] paramArrayOflong2, long[] paramArrayOflong3, int paramInt1, int paramInt2);
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static void plotErrorBars(String labelId, float[] xs, float[] ys, float[] err) {
/*  9142 */     nPlotErrorBars(labelId, xs, ys, err);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static void plotErrorBars(String labelId, float[] xs, float[] ys, float[] err, int flags) {
/*  9149 */     nPlotErrorBars(labelId, xs, ys, err, flags);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static void plotErrorBars(String labelId, float[] xs, float[] ys, float[] err, int flags, int offset) {
/*  9156 */     nPlotErrorBars(labelId, xs, ys, err, flags, offset);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   private static native void nPlotErrorBars(String paramString, float[] paramArrayOffloat1, float[] paramArrayOffloat2, float[] paramArrayOffloat3);
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   private static native void nPlotErrorBars(String paramString, float[] paramArrayOffloat1, float[] paramArrayOffloat2, float[] paramArrayOffloat3, int paramInt);
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   private static native void nPlotErrorBars(String paramString, float[] paramArrayOffloat1, float[] paramArrayOffloat2, float[] paramArrayOffloat3, int paramInt1, int paramInt2);
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static void plotErrorBars(String labelId, double[] xs, double[] ys, double[] err) {
/*  9199 */     nPlotErrorBars(labelId, xs, ys, err);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static void plotErrorBars(String labelId, double[] xs, double[] ys, double[] err, int flags) {
/*  9206 */     nPlotErrorBars(labelId, xs, ys, err, flags);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static void plotErrorBars(String labelId, double[] xs, double[] ys, double[] err, int flags, int offset) {
/*  9213 */     nPlotErrorBars(labelId, xs, ys, err, flags, offset);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   private static native void nPlotErrorBars(String paramString, double[] paramArrayOfdouble1, double[] paramArrayOfdouble2, double[] paramArrayOfdouble3);
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   private static native void nPlotErrorBars(String paramString, double[] paramArrayOfdouble1, double[] paramArrayOfdouble2, double[] paramArrayOfdouble3, int paramInt);
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   private static native void nPlotErrorBars(String paramString, double[] paramArrayOfdouble1, double[] paramArrayOfdouble2, double[] paramArrayOfdouble3, int paramInt1, int paramInt2);
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static void plotErrorBarsV(String labelId, short[] xs, short[] ys, short[] err, int count) {
/*  9256 */     nPlotErrorBarsV(labelId, xs, ys, err, count);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static void plotErrorBarsV(String labelId, short[] xs, short[] ys, short[] err, int count, int flags) {
/*  9263 */     nPlotErrorBarsV(labelId, xs, ys, err, count, flags);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static void plotErrorBarsV(String labelId, short[] xs, short[] ys, short[] err, int count, int flags, int offset) {
/*  9270 */     nPlotErrorBarsV(labelId, xs, ys, err, count, flags, offset);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   private static native void nPlotErrorBarsV(String paramString, short[] paramArrayOfshort1, short[] paramArrayOfshort2, short[] paramArrayOfshort3, int paramInt);
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   private static native void nPlotErrorBarsV(String paramString, short[] paramArrayOfshort1, short[] paramArrayOfshort2, short[] paramArrayOfshort3, int paramInt1, int paramInt2);
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   private static native void nPlotErrorBarsV(String paramString, short[] paramArrayOfshort1, short[] paramArrayOfshort2, short[] paramArrayOfshort3, int paramInt1, int paramInt2, int paramInt3);
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static void plotErrorBarsV(String labelId, int[] xs, int[] ys, int[] err, int count) {
/*  9313 */     nPlotErrorBarsV(labelId, xs, ys, err, count);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static void plotErrorBarsV(String labelId, int[] xs, int[] ys, int[] err, int count, int flags) {
/*  9320 */     nPlotErrorBarsV(labelId, xs, ys, err, count, flags);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static void plotErrorBarsV(String labelId, int[] xs, int[] ys, int[] err, int count, int flags, int offset) {
/*  9327 */     nPlotErrorBarsV(labelId, xs, ys, err, count, flags, offset);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   private static native void nPlotErrorBarsV(String paramString, int[] paramArrayOfint1, int[] paramArrayOfint2, int[] paramArrayOfint3, int paramInt);
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   private static native void nPlotErrorBarsV(String paramString, int[] paramArrayOfint1, int[] paramArrayOfint2, int[] paramArrayOfint3, int paramInt1, int paramInt2);
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   private static native void nPlotErrorBarsV(String paramString, int[] paramArrayOfint1, int[] paramArrayOfint2, int[] paramArrayOfint3, int paramInt1, int paramInt2, int paramInt3);
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static void plotErrorBarsV(String labelId, long[] xs, long[] ys, long[] err, int count) {
/*  9370 */     nPlotErrorBarsV(labelId, xs, ys, err, count);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static void plotErrorBarsV(String labelId, long[] xs, long[] ys, long[] err, int count, int flags) {
/*  9377 */     nPlotErrorBarsV(labelId, xs, ys, err, count, flags);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static void plotErrorBarsV(String labelId, long[] xs, long[] ys, long[] err, int count, int flags, int offset) {
/*  9384 */     nPlotErrorBarsV(labelId, xs, ys, err, count, flags, offset);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   private static native void nPlotErrorBarsV(String paramString, long[] paramArrayOflong1, long[] paramArrayOflong2, long[] paramArrayOflong3, int paramInt);
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   private static native void nPlotErrorBarsV(String paramString, long[] paramArrayOflong1, long[] paramArrayOflong2, long[] paramArrayOflong3, int paramInt1, int paramInt2);
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   private static native void nPlotErrorBarsV(String paramString, long[] paramArrayOflong1, long[] paramArrayOflong2, long[] paramArrayOflong3, int paramInt1, int paramInt2, int paramInt3);
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static void plotErrorBarsV(String labelId, float[] xs, float[] ys, float[] err, int count) {
/*  9427 */     nPlotErrorBarsV(labelId, xs, ys, err, count);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static void plotErrorBarsV(String labelId, float[] xs, float[] ys, float[] err, int count, int flags) {
/*  9434 */     nPlotErrorBarsV(labelId, xs, ys, err, count, flags);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static void plotErrorBarsV(String labelId, float[] xs, float[] ys, float[] err, int count, int flags, int offset) {
/*  9441 */     nPlotErrorBarsV(labelId, xs, ys, err, count, flags, offset);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   private static native void nPlotErrorBarsV(String paramString, float[] paramArrayOffloat1, float[] paramArrayOffloat2, float[] paramArrayOffloat3, int paramInt);
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   private static native void nPlotErrorBarsV(String paramString, float[] paramArrayOffloat1, float[] paramArrayOffloat2, float[] paramArrayOffloat3, int paramInt1, int paramInt2);
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   private static native void nPlotErrorBarsV(String paramString, float[] paramArrayOffloat1, float[] paramArrayOffloat2, float[] paramArrayOffloat3, int paramInt1, int paramInt2, int paramInt3);
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static void plotErrorBarsV(String labelId, double[] xs, double[] ys, double[] err, int count) {
/*  9484 */     nPlotErrorBarsV(labelId, xs, ys, err, count);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static void plotErrorBarsV(String labelId, double[] xs, double[] ys, double[] err, int count, int flags) {
/*  9491 */     nPlotErrorBarsV(labelId, xs, ys, err, count, flags);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static void plotErrorBarsV(String labelId, double[] xs, double[] ys, double[] err, int count, int flags, int offset) {
/*  9498 */     nPlotErrorBarsV(labelId, xs, ys, err, count, flags, offset);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   private static native void nPlotErrorBarsV(String paramString, double[] paramArrayOfdouble1, double[] paramArrayOfdouble2, double[] paramArrayOfdouble3, int paramInt);
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   private static native void nPlotErrorBarsV(String paramString, double[] paramArrayOfdouble1, double[] paramArrayOfdouble2, double[] paramArrayOfdouble3, int paramInt1, int paramInt2);
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   private static native void nPlotErrorBarsV(String paramString, double[] paramArrayOfdouble1, double[] paramArrayOfdouble2, double[] paramArrayOfdouble3, int paramInt1, int paramInt2, int paramInt3);
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static void plotErrorBars(String labelId, short[] xs, short[] ys, short[] neg, short[] pos) {
/*  9541 */     nPlotErrorBars(labelId, xs, ys, neg, pos);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static void plotErrorBars(String labelId, short[] xs, short[] ys, short[] neg, short[] pos, int flags) {
/*  9548 */     nPlotErrorBars(labelId, xs, ys, neg, pos, flags);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static void plotErrorBars(String labelId, short[] xs, short[] ys, short[] neg, short[] pos, int flags, int offset) {
/*  9555 */     nPlotErrorBars(labelId, xs, ys, neg, pos, flags, offset);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   private static native void nPlotErrorBars(String paramString, short[] paramArrayOfshort1, short[] paramArrayOfshort2, short[] paramArrayOfshort3, short[] paramArrayOfshort4);
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   private static native void nPlotErrorBars(String paramString, short[] paramArrayOfshort1, short[] paramArrayOfshort2, short[] paramArrayOfshort3, short[] paramArrayOfshort4, int paramInt);
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   private static native void nPlotErrorBars(String paramString, short[] paramArrayOfshort1, short[] paramArrayOfshort2, short[] paramArrayOfshort3, short[] paramArrayOfshort4, int paramInt1, int paramInt2);
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static void plotErrorBars(String labelId, int[] xs, int[] ys, int[] neg, int[] pos) {
/*  9604 */     nPlotErrorBars(labelId, xs, ys, neg, pos);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static void plotErrorBars(String labelId, int[] xs, int[] ys, int[] neg, int[] pos, int flags) {
/*  9611 */     nPlotErrorBars(labelId, xs, ys, neg, pos, flags);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static void plotErrorBars(String labelId, int[] xs, int[] ys, int[] neg, int[] pos, int flags, int offset) {
/*  9618 */     nPlotErrorBars(labelId, xs, ys, neg, pos, flags, offset);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   private static native void nPlotErrorBars(String paramString, int[] paramArrayOfint1, int[] paramArrayOfint2, int[] paramArrayOfint3, int[] paramArrayOfint4);
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   private static native void nPlotErrorBars(String paramString, int[] paramArrayOfint1, int[] paramArrayOfint2, int[] paramArrayOfint3, int[] paramArrayOfint4, int paramInt);
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   private static native void nPlotErrorBars(String paramString, int[] paramArrayOfint1, int[] paramArrayOfint2, int[] paramArrayOfint3, int[] paramArrayOfint4, int paramInt1, int paramInt2);
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static void plotErrorBars(String labelId, long[] xs, long[] ys, long[] neg, long[] pos) {
/*  9667 */     nPlotErrorBars(labelId, xs, ys, neg, pos);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static void plotErrorBars(String labelId, long[] xs, long[] ys, long[] neg, long[] pos, int flags) {
/*  9674 */     nPlotErrorBars(labelId, xs, ys, neg, pos, flags);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static void plotErrorBars(String labelId, long[] xs, long[] ys, long[] neg, long[] pos, int flags, int offset) {
/*  9681 */     nPlotErrorBars(labelId, xs, ys, neg, pos, flags, offset);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   private static native void nPlotErrorBars(String paramString, long[] paramArrayOflong1, long[] paramArrayOflong2, long[] paramArrayOflong3, long[] paramArrayOflong4);
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   private static native void nPlotErrorBars(String paramString, long[] paramArrayOflong1, long[] paramArrayOflong2, long[] paramArrayOflong3, long[] paramArrayOflong4, int paramInt);
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   private static native void nPlotErrorBars(String paramString, long[] paramArrayOflong1, long[] paramArrayOflong2, long[] paramArrayOflong3, long[] paramArrayOflong4, int paramInt1, int paramInt2);
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static void plotErrorBars(String labelId, float[] xs, float[] ys, float[] neg, float[] pos) {
/*  9730 */     nPlotErrorBars(labelId, xs, ys, neg, pos);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static void plotErrorBars(String labelId, float[] xs, float[] ys, float[] neg, float[] pos, int flags) {
/*  9737 */     nPlotErrorBars(labelId, xs, ys, neg, pos, flags);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static void plotErrorBars(String labelId, float[] xs, float[] ys, float[] neg, float[] pos, int flags, int offset) {
/*  9744 */     nPlotErrorBars(labelId, xs, ys, neg, pos, flags, offset);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   private static native void nPlotErrorBars(String paramString, float[] paramArrayOffloat1, float[] paramArrayOffloat2, float[] paramArrayOffloat3, float[] paramArrayOffloat4);
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   private static native void nPlotErrorBars(String paramString, float[] paramArrayOffloat1, float[] paramArrayOffloat2, float[] paramArrayOffloat3, float[] paramArrayOffloat4, int paramInt);
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   private static native void nPlotErrorBars(String paramString, float[] paramArrayOffloat1, float[] paramArrayOffloat2, float[] paramArrayOffloat3, float[] paramArrayOffloat4, int paramInt1, int paramInt2);
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static void plotErrorBars(String labelId, double[] xs, double[] ys, double[] neg, double[] pos) {
/*  9793 */     nPlotErrorBars(labelId, xs, ys, neg, pos);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static void plotErrorBars(String labelId, double[] xs, double[] ys, double[] neg, double[] pos, int flags) {
/*  9800 */     nPlotErrorBars(labelId, xs, ys, neg, pos, flags);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static void plotErrorBars(String labelId, double[] xs, double[] ys, double[] neg, double[] pos, int flags, int offset) {
/*  9807 */     nPlotErrorBars(labelId, xs, ys, neg, pos, flags, offset);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   private static native void nPlotErrorBars(String paramString, double[] paramArrayOfdouble1, double[] paramArrayOfdouble2, double[] paramArrayOfdouble3, double[] paramArrayOfdouble4);
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   private static native void nPlotErrorBars(String paramString, double[] paramArrayOfdouble1, double[] paramArrayOfdouble2, double[] paramArrayOfdouble3, double[] paramArrayOfdouble4, int paramInt);
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   private static native void nPlotErrorBars(String paramString, double[] paramArrayOfdouble1, double[] paramArrayOfdouble2, double[] paramArrayOfdouble3, double[] paramArrayOfdouble4, int paramInt1, int paramInt2);
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static void plotErrorBarsV(String labelId, short[] xs, short[] ys, short[] neg, short[] pos, int count) {
/*  9856 */     nPlotErrorBarsV(labelId, xs, ys, neg, pos, count);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static void plotErrorBarsV(String labelId, short[] xs, short[] ys, short[] neg, short[] pos, int count, int flags) {
/*  9863 */     nPlotErrorBarsV(labelId, xs, ys, neg, pos, count, flags);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static void plotErrorBarsV(String labelId, short[] xs, short[] ys, short[] neg, short[] pos, int count, int flags, int offset) {
/*  9870 */     nPlotErrorBarsV(labelId, xs, ys, neg, pos, count, flags, offset);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   private static native void nPlotErrorBarsV(String paramString, short[] paramArrayOfshort1, short[] paramArrayOfshort2, short[] paramArrayOfshort3, short[] paramArrayOfshort4, int paramInt);
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   private static native void nPlotErrorBarsV(String paramString, short[] paramArrayOfshort1, short[] paramArrayOfshort2, short[] paramArrayOfshort3, short[] paramArrayOfshort4, int paramInt1, int paramInt2);
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   private static native void nPlotErrorBarsV(String paramString, short[] paramArrayOfshort1, short[] paramArrayOfshort2, short[] paramArrayOfshort3, short[] paramArrayOfshort4, int paramInt1, int paramInt2, int paramInt3);
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static void plotErrorBarsV(String labelId, int[] xs, int[] ys, int[] neg, int[] pos, int count) {
/*  9919 */     nPlotErrorBarsV(labelId, xs, ys, neg, pos, count);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static void plotErrorBarsV(String labelId, int[] xs, int[] ys, int[] neg, int[] pos, int count, int flags) {
/*  9926 */     nPlotErrorBarsV(labelId, xs, ys, neg, pos, count, flags);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static void plotErrorBarsV(String labelId, int[] xs, int[] ys, int[] neg, int[] pos, int count, int flags, int offset) {
/*  9933 */     nPlotErrorBarsV(labelId, xs, ys, neg, pos, count, flags, offset);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   private static native void nPlotErrorBarsV(String paramString, int[] paramArrayOfint1, int[] paramArrayOfint2, int[] paramArrayOfint3, int[] paramArrayOfint4, int paramInt);
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   private static native void nPlotErrorBarsV(String paramString, int[] paramArrayOfint1, int[] paramArrayOfint2, int[] paramArrayOfint3, int[] paramArrayOfint4, int paramInt1, int paramInt2);
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   private static native void nPlotErrorBarsV(String paramString, int[] paramArrayOfint1, int[] paramArrayOfint2, int[] paramArrayOfint3, int[] paramArrayOfint4, int paramInt1, int paramInt2, int paramInt3);
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static void plotErrorBarsV(String labelId, long[] xs, long[] ys, long[] neg, long[] pos, int count) {
/*  9982 */     nPlotErrorBarsV(labelId, xs, ys, neg, pos, count);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static void plotErrorBarsV(String labelId, long[] xs, long[] ys, long[] neg, long[] pos, int count, int flags) {
/*  9989 */     nPlotErrorBarsV(labelId, xs, ys, neg, pos, count, flags);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static void plotErrorBarsV(String labelId, long[] xs, long[] ys, long[] neg, long[] pos, int count, int flags, int offset) {
/*  9996 */     nPlotErrorBarsV(labelId, xs, ys, neg, pos, count, flags, offset);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   private static native void nPlotErrorBarsV(String paramString, long[] paramArrayOflong1, long[] paramArrayOflong2, long[] paramArrayOflong3, long[] paramArrayOflong4, int paramInt);
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   private static native void nPlotErrorBarsV(String paramString, long[] paramArrayOflong1, long[] paramArrayOflong2, long[] paramArrayOflong3, long[] paramArrayOflong4, int paramInt1, int paramInt2);
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   private static native void nPlotErrorBarsV(String paramString, long[] paramArrayOflong1, long[] paramArrayOflong2, long[] paramArrayOflong3, long[] paramArrayOflong4, int paramInt1, int paramInt2, int paramInt3);
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static void plotErrorBarsV(String labelId, float[] xs, float[] ys, float[] neg, float[] pos, int count) {
/* 10045 */     nPlotErrorBarsV(labelId, xs, ys, neg, pos, count);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static void plotErrorBarsV(String labelId, float[] xs, float[] ys, float[] neg, float[] pos, int count, int flags) {
/* 10052 */     nPlotErrorBarsV(labelId, xs, ys, neg, pos, count, flags);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static void plotErrorBarsV(String labelId, float[] xs, float[] ys, float[] neg, float[] pos, int count, int flags, int offset) {
/* 10059 */     nPlotErrorBarsV(labelId, xs, ys, neg, pos, count, flags, offset);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   private static native void nPlotErrorBarsV(String paramString, float[] paramArrayOffloat1, float[] paramArrayOffloat2, float[] paramArrayOffloat3, float[] paramArrayOffloat4, int paramInt);
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   private static native void nPlotErrorBarsV(String paramString, float[] paramArrayOffloat1, float[] paramArrayOffloat2, float[] paramArrayOffloat3, float[] paramArrayOffloat4, int paramInt1, int paramInt2);
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   private static native void nPlotErrorBarsV(String paramString, float[] paramArrayOffloat1, float[] paramArrayOffloat2, float[] paramArrayOffloat3, float[] paramArrayOffloat4, int paramInt1, int paramInt2, int paramInt3);
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static void plotErrorBarsV(String labelId, double[] xs, double[] ys, double[] neg, double[] pos, int count) {
/* 10108 */     nPlotErrorBarsV(labelId, xs, ys, neg, pos, count);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static void plotErrorBarsV(String labelId, double[] xs, double[] ys, double[] neg, double[] pos, int count, int flags) {
/* 10115 */     nPlotErrorBarsV(labelId, xs, ys, neg, pos, count, flags);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static void plotErrorBarsV(String labelId, double[] xs, double[] ys, double[] neg, double[] pos, int count, int flags, int offset) {
/* 10122 */     nPlotErrorBarsV(labelId, xs, ys, neg, pos, count, flags, offset);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   private static native void nPlotErrorBarsV(String paramString, double[] paramArrayOfdouble1, double[] paramArrayOfdouble2, double[] paramArrayOfdouble3, double[] paramArrayOfdouble4, int paramInt);
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   private static native void nPlotErrorBarsV(String paramString, double[] paramArrayOfdouble1, double[] paramArrayOfdouble2, double[] paramArrayOfdouble3, double[] paramArrayOfdouble4, int paramInt1, int paramInt2);
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   private static native void nPlotErrorBarsV(String paramString, double[] paramArrayOfdouble1, double[] paramArrayOfdouble2, double[] paramArrayOfdouble3, double[] paramArrayOfdouble4, int paramInt1, int paramInt2, int paramInt3);
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static void plotStems(String labelId, short[] values) {
/* 10173 */     nPlotStems(labelId, values);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static void plotStems(String labelId, short[] values, double yRef) {
/* 10180 */     nPlotStems(labelId, values, yRef);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static void plotStems(String labelId, short[] values, double yRef, double xscale) {
/* 10187 */     nPlotStems(labelId, values, yRef, xscale);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static void plotStems(String labelId, short[] values, double yRef, double xscale, double xstart) {
/* 10194 */     nPlotStems(labelId, values, yRef, xscale, xstart);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static void plotStems(String labelId, short[] values, double yRef, double xscale, double xstart, int flags) {
/* 10201 */     nPlotStems(labelId, values, yRef, xscale, xstart, flags);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static void plotStems(String labelId, short[] values, double yRef, double xscale, double xstart, int flags, int offset) {
/* 10208 */     nPlotStems(labelId, values, yRef, xscale, xstart, flags, offset);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   private static native void nPlotStems(String paramString, short[] paramArrayOfshort);
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   private static native void nPlotStems(String paramString, short[] paramArrayOfshort, double paramDouble);
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   private static native void nPlotStems(String paramString, short[] paramArrayOfshort, double paramDouble1, double paramDouble2);
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   private static native void nPlotStems(String paramString, short[] paramArrayOfshort, double paramDouble1, double paramDouble2, double paramDouble3);
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   private static native void nPlotStems(String paramString, short[] paramArrayOfshort, double paramDouble1, double paramDouble2, double paramDouble3, int paramInt);
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   private static native void nPlotStems(String paramString, short[] paramArrayOfshort, double paramDouble1, double paramDouble2, double paramDouble3, int paramInt1, int paramInt2);
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static void plotStems(String labelId, int[] values) {
/* 10263 */     nPlotStems(labelId, values);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static void plotStems(String labelId, int[] values, double yRef) {
/* 10270 */     nPlotStems(labelId, values, yRef);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static void plotStems(String labelId, int[] values, double yRef, double xscale) {
/* 10277 */     nPlotStems(labelId, values, yRef, xscale);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static void plotStems(String labelId, int[] values, double yRef, double xscale, double xstart) {
/* 10284 */     nPlotStems(labelId, values, yRef, xscale, xstart);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static void plotStems(String labelId, int[] values, double yRef, double xscale, double xstart, int flags) {
/* 10291 */     nPlotStems(labelId, values, yRef, xscale, xstart, flags);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static void plotStems(String labelId, int[] values, double yRef, double xscale, double xstart, int flags, int offset) {
/* 10298 */     nPlotStems(labelId, values, yRef, xscale, xstart, flags, offset);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   private static native void nPlotStems(String paramString, int[] paramArrayOfint);
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   private static native void nPlotStems(String paramString, int[] paramArrayOfint, double paramDouble);
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   private static native void nPlotStems(String paramString, int[] paramArrayOfint, double paramDouble1, double paramDouble2);
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   private static native void nPlotStems(String paramString, int[] paramArrayOfint, double paramDouble1, double paramDouble2, double paramDouble3);
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   private static native void nPlotStems(String paramString, int[] paramArrayOfint, double paramDouble1, double paramDouble2, double paramDouble3, int paramInt);
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   private static native void nPlotStems(String paramString, int[] paramArrayOfint, double paramDouble1, double paramDouble2, double paramDouble3, int paramInt1, int paramInt2);
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static void plotStems(String labelId, long[] values) {
/* 10353 */     nPlotStems(labelId, values);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static void plotStems(String labelId, long[] values, double yRef) {
/* 10360 */     nPlotStems(labelId, values, yRef);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static void plotStems(String labelId, long[] values, double yRef, double xscale) {
/* 10367 */     nPlotStems(labelId, values, yRef, xscale);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static void plotStems(String labelId, long[] values, double yRef, double xscale, double xstart) {
/* 10374 */     nPlotStems(labelId, values, yRef, xscale, xstart);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static void plotStems(String labelId, long[] values, double yRef, double xscale, double xstart, int flags) {
/* 10381 */     nPlotStems(labelId, values, yRef, xscale, xstart, flags);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static void plotStems(String labelId, long[] values, double yRef, double xscale, double xstart, int flags, int offset) {
/* 10388 */     nPlotStems(labelId, values, yRef, xscale, xstart, flags, offset);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   private static native void nPlotStems(String paramString, long[] paramArrayOflong);
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   private static native void nPlotStems(String paramString, long[] paramArrayOflong, double paramDouble);
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   private static native void nPlotStems(String paramString, long[] paramArrayOflong, double paramDouble1, double paramDouble2);
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   private static native void nPlotStems(String paramString, long[] paramArrayOflong, double paramDouble1, double paramDouble2, double paramDouble3);
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   private static native void nPlotStems(String paramString, long[] paramArrayOflong, double paramDouble1, double paramDouble2, double paramDouble3, int paramInt);
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   private static native void nPlotStems(String paramString, long[] paramArrayOflong, double paramDouble1, double paramDouble2, double paramDouble3, int paramInt1, int paramInt2);
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static void plotStems(String labelId, float[] values) {
/* 10443 */     nPlotStems(labelId, values);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static void plotStems(String labelId, float[] values, double yRef) {
/* 10450 */     nPlotStems(labelId, values, yRef);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static void plotStems(String labelId, float[] values, double yRef, double xscale) {
/* 10457 */     nPlotStems(labelId, values, yRef, xscale);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static void plotStems(String labelId, float[] values, double yRef, double xscale, double xstart) {
/* 10464 */     nPlotStems(labelId, values, yRef, xscale, xstart);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static void plotStems(String labelId, float[] values, double yRef, double xscale, double xstart, int flags) {
/* 10471 */     nPlotStems(labelId, values, yRef, xscale, xstart, flags);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static void plotStems(String labelId, float[] values, double yRef, double xscale, double xstart, int flags, int offset) {
/* 10478 */     nPlotStems(labelId, values, yRef, xscale, xstart, flags, offset);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   private static native void nPlotStems(String paramString, float[] paramArrayOffloat);
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   private static native void nPlotStems(String paramString, float[] paramArrayOffloat, double paramDouble);
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   private static native void nPlotStems(String paramString, float[] paramArrayOffloat, double paramDouble1, double paramDouble2);
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   private static native void nPlotStems(String paramString, float[] paramArrayOffloat, double paramDouble1, double paramDouble2, double paramDouble3);
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   private static native void nPlotStems(String paramString, float[] paramArrayOffloat, double paramDouble1, double paramDouble2, double paramDouble3, int paramInt);
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   private static native void nPlotStems(String paramString, float[] paramArrayOffloat, double paramDouble1, double paramDouble2, double paramDouble3, int paramInt1, int paramInt2);
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static void plotStems(String labelId, double[] values) {
/* 10533 */     nPlotStems(labelId, values);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static void plotStems(String labelId, double[] values, double yRef) {
/* 10540 */     nPlotStems(labelId, values, yRef);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static void plotStems(String labelId, double[] values, double yRef, double xscale) {
/* 10547 */     nPlotStems(labelId, values, yRef, xscale);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static void plotStems(String labelId, double[] values, double yRef, double xscale, double xstart) {
/* 10554 */     nPlotStems(labelId, values, yRef, xscale, xstart);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static void plotStems(String labelId, double[] values, double yRef, double xscale, double xstart, int flags) {
/* 10561 */     nPlotStems(labelId, values, yRef, xscale, xstart, flags);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static void plotStems(String labelId, double[] values, double yRef, double xscale, double xstart, int flags, int offset) {
/* 10568 */     nPlotStems(labelId, values, yRef, xscale, xstart, flags, offset);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   private static native void nPlotStems(String paramString, double[] paramArrayOfdouble);
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   private static native void nPlotStems(String paramString, double[] paramArrayOfdouble, double paramDouble);
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   private static native void nPlotStems(String paramString, double[] paramArrayOfdouble, double paramDouble1, double paramDouble2);
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   private static native void nPlotStems(String paramString, double[] paramArrayOfdouble, double paramDouble1, double paramDouble2, double paramDouble3);
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   private static native void nPlotStems(String paramString, double[] paramArrayOfdouble, double paramDouble1, double paramDouble2, double paramDouble3, int paramInt);
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   private static native void nPlotStems(String paramString, double[] paramArrayOfdouble, double paramDouble1, double paramDouble2, double paramDouble3, int paramInt1, int paramInt2);
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static void plotStemsV(String labelId, short[] values, int count) {
/* 10623 */     nPlotStemsV(labelId, values, count);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static void plotStemsV(String labelId, short[] values, int count, double yRef) {
/* 10630 */     nPlotStemsV(labelId, values, count, yRef);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static void plotStemsV(String labelId, short[] values, int count, double yRef, double scale) {
/* 10637 */     nPlotStemsV(labelId, values, count, yRef, scale);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static void plotStemsV(String labelId, short[] values, int count, double yRef, double scale, double start) {
/* 10644 */     nPlotStemsV(labelId, values, count, yRef, scale, start);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static void plotStemsV(String labelId, short[] values, int count, double yRef, double scale, double start, int flags) {
/* 10651 */     nPlotStemsV(labelId, values, count, yRef, scale, start, flags);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static void plotStemsV(String labelId, short[] values, int count, double yRef, double scale, double start, int flags, int offset) {
/* 10658 */     nPlotStemsV(labelId, values, count, yRef, scale, start, flags, offset);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   private static native void nPlotStemsV(String paramString, short[] paramArrayOfshort, int paramInt);
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   private static native void nPlotStemsV(String paramString, short[] paramArrayOfshort, int paramInt, double paramDouble);
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   private static native void nPlotStemsV(String paramString, short[] paramArrayOfshort, int paramInt, double paramDouble1, double paramDouble2);
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   private static native void nPlotStemsV(String paramString, short[] paramArrayOfshort, int paramInt, double paramDouble1, double paramDouble2, double paramDouble3);
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   private static native void nPlotStemsV(String paramString, short[] paramArrayOfshort, int paramInt1, double paramDouble1, double paramDouble2, double paramDouble3, int paramInt2);
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   private static native void nPlotStemsV(String paramString, short[] paramArrayOfshort, int paramInt1, double paramDouble1, double paramDouble2, double paramDouble3, int paramInt2, int paramInt3);
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static void plotStemsV(String labelId, int[] values, int count) {
/* 10713 */     nPlotStemsV(labelId, values, count);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static void plotStemsV(String labelId, int[] values, int count, double yRef) {
/* 10720 */     nPlotStemsV(labelId, values, count, yRef);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static void plotStemsV(String labelId, int[] values, int count, double yRef, double scale) {
/* 10727 */     nPlotStemsV(labelId, values, count, yRef, scale);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static void plotStemsV(String labelId, int[] values, int count, double yRef, double scale, double start) {
/* 10734 */     nPlotStemsV(labelId, values, count, yRef, scale, start);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static void plotStemsV(String labelId, int[] values, int count, double yRef, double scale, double start, int flags) {
/* 10741 */     nPlotStemsV(labelId, values, count, yRef, scale, start, flags);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static void plotStemsV(String labelId, int[] values, int count, double yRef, double scale, double start, int flags, int offset) {
/* 10748 */     nPlotStemsV(labelId, values, count, yRef, scale, start, flags, offset);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   private static native void nPlotStemsV(String paramString, int[] paramArrayOfint, int paramInt);
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   private static native void nPlotStemsV(String paramString, int[] paramArrayOfint, int paramInt, double paramDouble);
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   private static native void nPlotStemsV(String paramString, int[] paramArrayOfint, int paramInt, double paramDouble1, double paramDouble2);
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   private static native void nPlotStemsV(String paramString, int[] paramArrayOfint, int paramInt, double paramDouble1, double paramDouble2, double paramDouble3);
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   private static native void nPlotStemsV(String paramString, int[] paramArrayOfint, int paramInt1, double paramDouble1, double paramDouble2, double paramDouble3, int paramInt2);
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   private static native void nPlotStemsV(String paramString, int[] paramArrayOfint, int paramInt1, double paramDouble1, double paramDouble2, double paramDouble3, int paramInt2, int paramInt3);
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static void plotStemsV(String labelId, long[] values, int count) {
/* 10803 */     nPlotStemsV(labelId, values, count);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static void plotStemsV(String labelId, long[] values, int count, double yRef) {
/* 10810 */     nPlotStemsV(labelId, values, count, yRef);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static void plotStemsV(String labelId, long[] values, int count, double yRef, double scale) {
/* 10817 */     nPlotStemsV(labelId, values, count, yRef, scale);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static void plotStemsV(String labelId, long[] values, int count, double yRef, double scale, double start) {
/* 10824 */     nPlotStemsV(labelId, values, count, yRef, scale, start);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static void plotStemsV(String labelId, long[] values, int count, double yRef, double scale, double start, int flags) {
/* 10831 */     nPlotStemsV(labelId, values, count, yRef, scale, start, flags);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static void plotStemsV(String labelId, long[] values, int count, double yRef, double scale, double start, int flags, int offset) {
/* 10838 */     nPlotStemsV(labelId, values, count, yRef, scale, start, flags, offset);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   private static native void nPlotStemsV(String paramString, long[] paramArrayOflong, int paramInt);
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   private static native void nPlotStemsV(String paramString, long[] paramArrayOflong, int paramInt, double paramDouble);
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   private static native void nPlotStemsV(String paramString, long[] paramArrayOflong, int paramInt, double paramDouble1, double paramDouble2);
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   private static native void nPlotStemsV(String paramString, long[] paramArrayOflong, int paramInt, double paramDouble1, double paramDouble2, double paramDouble3);
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   private static native void nPlotStemsV(String paramString, long[] paramArrayOflong, int paramInt1, double paramDouble1, double paramDouble2, double paramDouble3, int paramInt2);
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   private static native void nPlotStemsV(String paramString, long[] paramArrayOflong, int paramInt1, double paramDouble1, double paramDouble2, double paramDouble3, int paramInt2, int paramInt3);
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static void plotStemsV(String labelId, float[] values, int count) {
/* 10893 */     nPlotStemsV(labelId, values, count);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static void plotStemsV(String labelId, float[] values, int count, double yRef) {
/* 10900 */     nPlotStemsV(labelId, values, count, yRef);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static void plotStemsV(String labelId, float[] values, int count, double yRef, double scale) {
/* 10907 */     nPlotStemsV(labelId, values, count, yRef, scale);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static void plotStemsV(String labelId, float[] values, int count, double yRef, double scale, double start) {
/* 10914 */     nPlotStemsV(labelId, values, count, yRef, scale, start);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static void plotStemsV(String labelId, float[] values, int count, double yRef, double scale, double start, int flags) {
/* 10921 */     nPlotStemsV(labelId, values, count, yRef, scale, start, flags);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static void plotStemsV(String labelId, float[] values, int count, double yRef, double scale, double start, int flags, int offset) {
/* 10928 */     nPlotStemsV(labelId, values, count, yRef, scale, start, flags, offset);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   private static native void nPlotStemsV(String paramString, float[] paramArrayOffloat, int paramInt);
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   private static native void nPlotStemsV(String paramString, float[] paramArrayOffloat, int paramInt, double paramDouble);
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   private static native void nPlotStemsV(String paramString, float[] paramArrayOffloat, int paramInt, double paramDouble1, double paramDouble2);
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   private static native void nPlotStemsV(String paramString, float[] paramArrayOffloat, int paramInt, double paramDouble1, double paramDouble2, double paramDouble3);
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   private static native void nPlotStemsV(String paramString, float[] paramArrayOffloat, int paramInt1, double paramDouble1, double paramDouble2, double paramDouble3, int paramInt2);
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   private static native void nPlotStemsV(String paramString, float[] paramArrayOffloat, int paramInt1, double paramDouble1, double paramDouble2, double paramDouble3, int paramInt2, int paramInt3);
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static void plotStemsV(String labelId, double[] values, int count) {
/* 10983 */     nPlotStemsV(labelId, values, count);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static void plotStemsV(String labelId, double[] values, int count, double yRef) {
/* 10990 */     nPlotStemsV(labelId, values, count, yRef);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static void plotStemsV(String labelId, double[] values, int count, double yRef, double scale) {
/* 10997 */     nPlotStemsV(labelId, values, count, yRef, scale);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static void plotStemsV(String labelId, double[] values, int count, double yRef, double scale, double start) {
/* 11004 */     nPlotStemsV(labelId, values, count, yRef, scale, start);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static void plotStemsV(String labelId, double[] values, int count, double yRef, double scale, double start, int flags) {
/* 11011 */     nPlotStemsV(labelId, values, count, yRef, scale, start, flags);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static void plotStemsV(String labelId, double[] values, int count, double yRef, double scale, double start, int flags, int offset) {
/* 11018 */     nPlotStemsV(labelId, values, count, yRef, scale, start, flags, offset);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   private static native void nPlotStemsV(String paramString, double[] paramArrayOfdouble, int paramInt);
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   private static native void nPlotStemsV(String paramString, double[] paramArrayOfdouble, int paramInt, double paramDouble);
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   private static native void nPlotStemsV(String paramString, double[] paramArrayOfdouble, int paramInt, double paramDouble1, double paramDouble2);
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   private static native void nPlotStemsV(String paramString, double[] paramArrayOfdouble, int paramInt, double paramDouble1, double paramDouble2, double paramDouble3);
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   private static native void nPlotStemsV(String paramString, double[] paramArrayOfdouble, int paramInt1, double paramDouble1, double paramDouble2, double paramDouble3, int paramInt2);
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   private static native void nPlotStemsV(String paramString, double[] paramArrayOfdouble, int paramInt1, double paramDouble1, double paramDouble2, double paramDouble3, int paramInt2, int paramInt3);
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static void plotStems(String labelId, short[] xs, short[] ys) {
/* 11075 */     nPlotStems(labelId, xs, ys);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static void plotStems(String labelId, short[] xs, short[] ys, double ref) {
/* 11082 */     nPlotStems(labelId, xs, ys, ref);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static void plotStems(String labelId, short[] xs, short[] ys, double ref, int flags) {
/* 11089 */     nPlotStems(labelId, xs, ys, ref, flags);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static void plotStems(String labelId, short[] xs, short[] ys, double ref, int flags, int offset) {
/* 11096 */     nPlotStems(labelId, xs, ys, ref, flags, offset);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   private static native void nPlotStems(String paramString, short[] paramArrayOfshort1, short[] paramArrayOfshort2);
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   private static native void nPlotStems(String paramString, short[] paramArrayOfshort1, short[] paramArrayOfshort2, double paramDouble);
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   private static native void nPlotStems(String paramString, short[] paramArrayOfshort1, short[] paramArrayOfshort2, double paramDouble, int paramInt);
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   private static native void nPlotStems(String paramString, short[] paramArrayOfshort1, short[] paramArrayOfshort2, double paramDouble, int paramInt1, int paramInt2);
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static void plotStems(String labelId, int[] xs, int[] ys) {
/* 11143 */     nPlotStems(labelId, xs, ys);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static void plotStems(String labelId, int[] xs, int[] ys, double ref) {
/* 11150 */     nPlotStems(labelId, xs, ys, ref);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static void plotStems(String labelId, int[] xs, int[] ys, double ref, int flags) {
/* 11157 */     nPlotStems(labelId, xs, ys, ref, flags);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static void plotStems(String labelId, int[] xs, int[] ys, double ref, int flags, int offset) {
/* 11164 */     nPlotStems(labelId, xs, ys, ref, flags, offset);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   private static native void nPlotStems(String paramString, int[] paramArrayOfint1, int[] paramArrayOfint2);
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   private static native void nPlotStems(String paramString, int[] paramArrayOfint1, int[] paramArrayOfint2, double paramDouble);
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   private static native void nPlotStems(String paramString, int[] paramArrayOfint1, int[] paramArrayOfint2, double paramDouble, int paramInt);
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   private static native void nPlotStems(String paramString, int[] paramArrayOfint1, int[] paramArrayOfint2, double paramDouble, int paramInt1, int paramInt2);
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static void plotStems(String labelId, long[] xs, long[] ys) {
/* 11211 */     nPlotStems(labelId, xs, ys);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static void plotStems(String labelId, long[] xs, long[] ys, double ref) {
/* 11218 */     nPlotStems(labelId, xs, ys, ref);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static void plotStems(String labelId, long[] xs, long[] ys, double ref, int flags) {
/* 11225 */     nPlotStems(labelId, xs, ys, ref, flags);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static void plotStems(String labelId, long[] xs, long[] ys, double ref, int flags, int offset) {
/* 11232 */     nPlotStems(labelId, xs, ys, ref, flags, offset);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   private static native void nPlotStems(String paramString, long[] paramArrayOflong1, long[] paramArrayOflong2);
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   private static native void nPlotStems(String paramString, long[] paramArrayOflong1, long[] paramArrayOflong2, double paramDouble);
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   private static native void nPlotStems(String paramString, long[] paramArrayOflong1, long[] paramArrayOflong2, double paramDouble, int paramInt);
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   private static native void nPlotStems(String paramString, long[] paramArrayOflong1, long[] paramArrayOflong2, double paramDouble, int paramInt1, int paramInt2);
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static void plotStems(String labelId, float[] xs, float[] ys) {
/* 11279 */     nPlotStems(labelId, xs, ys);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static void plotStems(String labelId, float[] xs, float[] ys, double ref) {
/* 11286 */     nPlotStems(labelId, xs, ys, ref);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static void plotStems(String labelId, float[] xs, float[] ys, double ref, int flags) {
/* 11293 */     nPlotStems(labelId, xs, ys, ref, flags);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static void plotStems(String labelId, float[] xs, float[] ys, double ref, int flags, int offset) {
/* 11300 */     nPlotStems(labelId, xs, ys, ref, flags, offset);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   private static native void nPlotStems(String paramString, float[] paramArrayOffloat1, float[] paramArrayOffloat2);
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   private static native void nPlotStems(String paramString, float[] paramArrayOffloat1, float[] paramArrayOffloat2, double paramDouble);
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   private static native void nPlotStems(String paramString, float[] paramArrayOffloat1, float[] paramArrayOffloat2, double paramDouble, int paramInt);
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   private static native void nPlotStems(String paramString, float[] paramArrayOffloat1, float[] paramArrayOffloat2, double paramDouble, int paramInt1, int paramInt2);
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static void plotStems(String labelId, double[] xs, double[] ys) {
/* 11347 */     nPlotStems(labelId, xs, ys);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static void plotStems(String labelId, double[] xs, double[] ys, double ref) {
/* 11354 */     nPlotStems(labelId, xs, ys, ref);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static void plotStems(String labelId, double[] xs, double[] ys, double ref, int flags) {
/* 11361 */     nPlotStems(labelId, xs, ys, ref, flags);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static void plotStems(String labelId, double[] xs, double[] ys, double ref, int flags, int offset) {
/* 11368 */     nPlotStems(labelId, xs, ys, ref, flags, offset);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   private static native void nPlotStems(String paramString, double[] paramArrayOfdouble1, double[] paramArrayOfdouble2);
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   private static native void nPlotStems(String paramString, double[] paramArrayOfdouble1, double[] paramArrayOfdouble2, double paramDouble);
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   private static native void nPlotStems(String paramString, double[] paramArrayOfdouble1, double[] paramArrayOfdouble2, double paramDouble, int paramInt);
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   private static native void nPlotStems(String paramString, double[] paramArrayOfdouble1, double[] paramArrayOfdouble2, double paramDouble, int paramInt1, int paramInt2);
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static void plotStemsV(String labelId, short[] xs, short[] ys, int count) {
/* 11415 */     nPlotStemsV(labelId, xs, ys, count);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static void plotStemsV(String labelId, short[] xs, short[] ys, int count, double yRef) {
/* 11422 */     nPlotStemsV(labelId, xs, ys, count, yRef);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static void plotStemsV(String labelId, short[] xs, short[] ys, int count, double yRef, int flags) {
/* 11429 */     nPlotStemsV(labelId, xs, ys, count, yRef, flags);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static void plotStemsV(String labelId, short[] xs, short[] ys, int count, double yRef, int flags, int offset) {
/* 11436 */     nPlotStemsV(labelId, xs, ys, count, yRef, flags, offset);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   private static native void nPlotStemsV(String paramString, short[] paramArrayOfshort1, short[] paramArrayOfshort2, int paramInt);
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   private static native void nPlotStemsV(String paramString, short[] paramArrayOfshort1, short[] paramArrayOfshort2, int paramInt, double paramDouble);
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   private static native void nPlotStemsV(String paramString, short[] paramArrayOfshort1, short[] paramArrayOfshort2, int paramInt1, double paramDouble, int paramInt2);
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   private static native void nPlotStemsV(String paramString, short[] paramArrayOfshort1, short[] paramArrayOfshort2, int paramInt1, double paramDouble, int paramInt2, int paramInt3);
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static void plotStemsV(String labelId, int[] xs, int[] ys, int count) {
/* 11483 */     nPlotStemsV(labelId, xs, ys, count);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static void plotStemsV(String labelId, int[] xs, int[] ys, int count, double yRef) {
/* 11490 */     nPlotStemsV(labelId, xs, ys, count, yRef);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static void plotStemsV(String labelId, int[] xs, int[] ys, int count, double yRef, int flags) {
/* 11497 */     nPlotStemsV(labelId, xs, ys, count, yRef, flags);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static void plotStemsV(String labelId, int[] xs, int[] ys, int count, double yRef, int flags, int offset) {
/* 11504 */     nPlotStemsV(labelId, xs, ys, count, yRef, flags, offset);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   private static native void nPlotStemsV(String paramString, int[] paramArrayOfint1, int[] paramArrayOfint2, int paramInt);
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   private static native void nPlotStemsV(String paramString, int[] paramArrayOfint1, int[] paramArrayOfint2, int paramInt, double paramDouble);
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   private static native void nPlotStemsV(String paramString, int[] paramArrayOfint1, int[] paramArrayOfint2, int paramInt1, double paramDouble, int paramInt2);
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   private static native void nPlotStemsV(String paramString, int[] paramArrayOfint1, int[] paramArrayOfint2, int paramInt1, double paramDouble, int paramInt2, int paramInt3);
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static void plotStemsV(String labelId, long[] xs, long[] ys, int count) {
/* 11551 */     nPlotStemsV(labelId, xs, ys, count);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static void plotStemsV(String labelId, long[] xs, long[] ys, int count, double yRef) {
/* 11558 */     nPlotStemsV(labelId, xs, ys, count, yRef);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static void plotStemsV(String labelId, long[] xs, long[] ys, int count, double yRef, int flags) {
/* 11565 */     nPlotStemsV(labelId, xs, ys, count, yRef, flags);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static void plotStemsV(String labelId, long[] xs, long[] ys, int count, double yRef, int flags, int offset) {
/* 11572 */     nPlotStemsV(labelId, xs, ys, count, yRef, flags, offset);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   private static native void nPlotStemsV(String paramString, long[] paramArrayOflong1, long[] paramArrayOflong2, int paramInt);
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   private static native void nPlotStemsV(String paramString, long[] paramArrayOflong1, long[] paramArrayOflong2, int paramInt, double paramDouble);
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   private static native void nPlotStemsV(String paramString, long[] paramArrayOflong1, long[] paramArrayOflong2, int paramInt1, double paramDouble, int paramInt2);
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   private static native void nPlotStemsV(String paramString, long[] paramArrayOflong1, long[] paramArrayOflong2, int paramInt1, double paramDouble, int paramInt2, int paramInt3);
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static void plotStemsV(String labelId, float[] xs, float[] ys, int count) {
/* 11619 */     nPlotStemsV(labelId, xs, ys, count);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static void plotStemsV(String labelId, float[] xs, float[] ys, int count, double yRef) {
/* 11626 */     nPlotStemsV(labelId, xs, ys, count, yRef);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static void plotStemsV(String labelId, float[] xs, float[] ys, int count, double yRef, int flags) {
/* 11633 */     nPlotStemsV(labelId, xs, ys, count, yRef, flags);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static void plotStemsV(String labelId, float[] xs, float[] ys, int count, double yRef, int flags, int offset) {
/* 11640 */     nPlotStemsV(labelId, xs, ys, count, yRef, flags, offset);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   private static native void nPlotStemsV(String paramString, float[] paramArrayOffloat1, float[] paramArrayOffloat2, int paramInt);
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   private static native void nPlotStemsV(String paramString, float[] paramArrayOffloat1, float[] paramArrayOffloat2, int paramInt, double paramDouble);
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   private static native void nPlotStemsV(String paramString, float[] paramArrayOffloat1, float[] paramArrayOffloat2, int paramInt1, double paramDouble, int paramInt2);
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   private static native void nPlotStemsV(String paramString, float[] paramArrayOffloat1, float[] paramArrayOffloat2, int paramInt1, double paramDouble, int paramInt2, int paramInt3);
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static void plotStemsV(String labelId, double[] xs, double[] ys, int count) {
/* 11687 */     nPlotStemsV(labelId, xs, ys, count);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static void plotStemsV(String labelId, double[] xs, double[] ys, int count, double yRef) {
/* 11694 */     nPlotStemsV(labelId, xs, ys, count, yRef);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static void plotStemsV(String labelId, double[] xs, double[] ys, int count, double yRef, int flags) {
/* 11701 */     nPlotStemsV(labelId, xs, ys, count, yRef, flags);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static void plotStemsV(String labelId, double[] xs, double[] ys, int count, double yRef, int flags, int offset) {
/* 11708 */     nPlotStemsV(labelId, xs, ys, count, yRef, flags, offset);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   private static native void nPlotStemsV(String paramString, double[] paramArrayOfdouble1, double[] paramArrayOfdouble2, int paramInt);
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   private static native void nPlotStemsV(String paramString, double[] paramArrayOfdouble1, double[] paramArrayOfdouble2, int paramInt, double paramDouble);
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   private static native void nPlotStemsV(String paramString, double[] paramArrayOfdouble1, double[] paramArrayOfdouble2, int paramInt1, double paramDouble, int paramInt2);
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   private static native void nPlotStemsV(String paramString, double[] paramArrayOfdouble1, double[] paramArrayOfdouble2, int paramInt1, double paramDouble, int paramInt2, int paramInt3);
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static void plotInfLines(String labelId, short[] values) {
/* 11755 */     nPlotInfLines(labelId, values);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static void plotInfLines(String labelId, short[] values, int flags) {
/* 11762 */     nPlotInfLines(labelId, values, flags);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static void plotInfLines(String labelId, short[] values, int flags, int offset) {
/* 11769 */     nPlotInfLines(labelId, values, flags, offset);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   private static native void nPlotInfLines(String paramString, short[] paramArrayOfshort);
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   private static native void nPlotInfLines(String paramString, short[] paramArrayOfshort, int paramInt);
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   private static native void nPlotInfLines(String paramString, short[] paramArrayOfshort, int paramInt1, int paramInt2);
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static void plotInfLines(String labelId, int[] values) {
/* 11800 */     nPlotInfLines(labelId, values);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static void plotInfLines(String labelId, int[] values, int flags) {
/* 11807 */     nPlotInfLines(labelId, values, flags);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static void plotInfLines(String labelId, int[] values, int flags, int offset) {
/* 11814 */     nPlotInfLines(labelId, values, flags, offset);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   private static native void nPlotInfLines(String paramString, int[] paramArrayOfint);
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   private static native void nPlotInfLines(String paramString, int[] paramArrayOfint, int paramInt);
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   private static native void nPlotInfLines(String paramString, int[] paramArrayOfint, int paramInt1, int paramInt2);
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static void plotInfLines(String labelId, long[] values) {
/* 11845 */     nPlotInfLines(labelId, values);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static void plotInfLines(String labelId, long[] values, int flags) {
/* 11852 */     nPlotInfLines(labelId, values, flags);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static void plotInfLines(String labelId, long[] values, int flags, int offset) {
/* 11859 */     nPlotInfLines(labelId, values, flags, offset);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   private static native void nPlotInfLines(String paramString, long[] paramArrayOflong);
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   private static native void nPlotInfLines(String paramString, long[] paramArrayOflong, int paramInt);
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   private static native void nPlotInfLines(String paramString, long[] paramArrayOflong, int paramInt1, int paramInt2);
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static void plotInfLines(String labelId, float[] values) {
/* 11890 */     nPlotInfLines(labelId, values);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static void plotInfLines(String labelId, float[] values, int flags) {
/* 11897 */     nPlotInfLines(labelId, values, flags);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static void plotInfLines(String labelId, float[] values, int flags, int offset) {
/* 11904 */     nPlotInfLines(labelId, values, flags, offset);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   private static native void nPlotInfLines(String paramString, float[] paramArrayOffloat);
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   private static native void nPlotInfLines(String paramString, float[] paramArrayOffloat, int paramInt);
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   private static native void nPlotInfLines(String paramString, float[] paramArrayOffloat, int paramInt1, int paramInt2);
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static void plotInfLines(String labelId, double[] values) {
/* 11935 */     nPlotInfLines(labelId, values);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static void plotInfLines(String labelId, double[] values, int flags) {
/* 11942 */     nPlotInfLines(labelId, values, flags);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static void plotInfLines(String labelId, double[] values, int flags, int offset) {
/* 11949 */     nPlotInfLines(labelId, values, flags, offset);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   private static native void nPlotInfLines(String paramString, double[] paramArrayOfdouble);
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   private static native void nPlotInfLines(String paramString, double[] paramArrayOfdouble, int paramInt);
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   private static native void nPlotInfLines(String paramString, double[] paramArrayOfdouble, int paramInt1, int paramInt2);
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static void plotInfLinesV(String labelId, short[] values, int count) {
/* 11980 */     nPlotInfLinesV(labelId, values, count);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static void plotInfLinesV(String labelId, short[] values, int count, int flags) {
/* 11987 */     nPlotInfLinesV(labelId, values, count, flags);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static void plotInfLinesV(String labelId, short[] values, int count, int flags, int offset) {
/* 11994 */     nPlotInfLinesV(labelId, values, count, flags, offset);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   private static native void nPlotInfLinesV(String paramString, short[] paramArrayOfshort, int paramInt);
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   private static native void nPlotInfLinesV(String paramString, short[] paramArrayOfshort, int paramInt1, int paramInt2);
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   private static native void nPlotInfLinesV(String paramString, short[] paramArrayOfshort, int paramInt1, int paramInt2, int paramInt3);
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static void plotInfLinesV(String labelId, int[] values, int count) {
/* 12025 */     nPlotInfLinesV(labelId, values, count);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static void plotInfLinesV(String labelId, int[] values, int count, int flags) {
/* 12032 */     nPlotInfLinesV(labelId, values, count, flags);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static void plotInfLinesV(String labelId, int[] values, int count, int flags, int offset) {
/* 12039 */     nPlotInfLinesV(labelId, values, count, flags, offset);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   private static native void nPlotInfLinesV(String paramString, int[] paramArrayOfint, int paramInt);
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   private static native void nPlotInfLinesV(String paramString, int[] paramArrayOfint, int paramInt1, int paramInt2);
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   private static native void nPlotInfLinesV(String paramString, int[] paramArrayOfint, int paramInt1, int paramInt2, int paramInt3);
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static void plotInfLinesV(String labelId, long[] values, int count) {
/* 12070 */     nPlotInfLinesV(labelId, values, count);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static void plotInfLinesV(String labelId, long[] values, int count, int flags) {
/* 12077 */     nPlotInfLinesV(labelId, values, count, flags);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static void plotInfLinesV(String labelId, long[] values, int count, int flags, int offset) {
/* 12084 */     nPlotInfLinesV(labelId, values, count, flags, offset);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   private static native void nPlotInfLinesV(String paramString, long[] paramArrayOflong, int paramInt);
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   private static native void nPlotInfLinesV(String paramString, long[] paramArrayOflong, int paramInt1, int paramInt2);
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   private static native void nPlotInfLinesV(String paramString, long[] paramArrayOflong, int paramInt1, int paramInt2, int paramInt3);
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static void plotInfLinesV(String labelId, float[] values, int count) {
/* 12115 */     nPlotInfLinesV(labelId, values, count);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static void plotInfLinesV(String labelId, float[] values, int count, int flags) {
/* 12122 */     nPlotInfLinesV(labelId, values, count, flags);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static void plotInfLinesV(String labelId, float[] values, int count, int flags, int offset) {
/* 12129 */     nPlotInfLinesV(labelId, values, count, flags, offset);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   private static native void nPlotInfLinesV(String paramString, float[] paramArrayOffloat, int paramInt);
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   private static native void nPlotInfLinesV(String paramString, float[] paramArrayOffloat, int paramInt1, int paramInt2);
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   private static native void nPlotInfLinesV(String paramString, float[] paramArrayOffloat, int paramInt1, int paramInt2, int paramInt3);
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static void plotInfLinesV(String labelId, double[] values, int count) {
/* 12160 */     nPlotInfLinesV(labelId, values, count);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static void plotInfLinesV(String labelId, double[] values, int count, int flags) {
/* 12167 */     nPlotInfLinesV(labelId, values, count, flags);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static void plotInfLinesV(String labelId, double[] values, int count, int flags, int offset) {
/* 12174 */     nPlotInfLinesV(labelId, values, count, flags, offset);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   private static native void nPlotInfLinesV(String paramString, double[] paramArrayOfdouble, int paramInt);
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   private static native void nPlotInfLinesV(String paramString, double[] paramArrayOfdouble, int paramInt1, int paramInt2);
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   private static native void nPlotInfLinesV(String paramString, double[] paramArrayOfdouble, int paramInt1, int paramInt2, int paramInt3);
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static void plotPieChart(String[] labelIds, short[] values, double x, double y, double radius) {
/* 12205 */     nPlotPieChart(labelIds, labelIds.length, values, x, y, radius);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static void plotPieChart(String[] labelIds, short[] values, double x, double y, double radius, String labelFmt) {
/* 12212 */     nPlotPieChart(labelIds, labelIds.length, values, x, y, radius, labelFmt);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static void plotPieChart(String[] labelIds, short[] values, double x, double y, double radius, String labelFmt, double angle0) {
/* 12219 */     nPlotPieChart(labelIds, labelIds.length, values, x, y, radius, labelFmt, angle0);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static void plotPieChart(String[] labelIds, short[] values, double x, double y, double radius, String labelFmt, double angle0, int flags) {
/* 12226 */     nPlotPieChart(labelIds, labelIds.length, values, x, y, radius, labelFmt, angle0, flags);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static void plotPieChart(String[] labelIds, short[] values, double x, double y, double radius, double angle0, int flags) {
/* 12233 */     nPlotPieChart(labelIds, labelIds.length, values, x, y, radius, angle0, flags);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   private static native void nPlotPieChart(String[] paramArrayOfString, int paramInt, short[] paramArrayOfshort, double paramDouble1, double paramDouble2, double paramDouble3);
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   private static native void nPlotPieChart(String[] paramArrayOfString, int paramInt, short[] paramArrayOfshort, double paramDouble1, double paramDouble2, double paramDouble3, String paramString);
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   private static native void nPlotPieChart(String[] paramArrayOfString, int paramInt, short[] paramArrayOfshort, double paramDouble1, double paramDouble2, double paramDouble3, String paramString, double paramDouble4);
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   private static native void nPlotPieChart(String[] paramArrayOfString, int paramInt1, short[] paramArrayOfshort, double paramDouble1, double paramDouble2, double paramDouble3, String paramString, double paramDouble4, int paramInt2);
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   private static native void nPlotPieChart(String[] paramArrayOfString, int paramInt1, short[] paramArrayOfshort, double paramDouble1, double paramDouble2, double paramDouble3, double paramDouble4, int paramInt2);
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static void plotPieChart(String[] labelIds, int[] values, double x, double y, double radius) {
/* 12326 */     nPlotPieChart(labelIds, labelIds.length, values, x, y, radius);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static void plotPieChart(String[] labelIds, int[] values, double x, double y, double radius, String labelFmt) {
/* 12333 */     nPlotPieChart(labelIds, labelIds.length, values, x, y, radius, labelFmt);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static void plotPieChart(String[] labelIds, int[] values, double x, double y, double radius, String labelFmt, double angle0) {
/* 12340 */     nPlotPieChart(labelIds, labelIds.length, values, x, y, radius, labelFmt, angle0);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static void plotPieChart(String[] labelIds, int[] values, double x, double y, double radius, String labelFmt, double angle0, int flags) {
/* 12347 */     nPlotPieChart(labelIds, labelIds.length, values, x, y, radius, labelFmt, angle0, flags);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static void plotPieChart(String[] labelIds, int[] values, double x, double y, double radius, double angle0, int flags) {
/* 12354 */     nPlotPieChart(labelIds, labelIds.length, values, x, y, radius, angle0, flags);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   private static native void nPlotPieChart(String[] paramArrayOfString, int paramInt, int[] paramArrayOfint, double paramDouble1, double paramDouble2, double paramDouble3);
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   private static native void nPlotPieChart(String[] paramArrayOfString, int paramInt, int[] paramArrayOfint, double paramDouble1, double paramDouble2, double paramDouble3, String paramString);
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   private static native void nPlotPieChart(String[] paramArrayOfString, int paramInt, int[] paramArrayOfint, double paramDouble1, double paramDouble2, double paramDouble3, String paramString, double paramDouble4);
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   private static native void nPlotPieChart(String[] paramArrayOfString, int paramInt1, int[] paramArrayOfint, double paramDouble1, double paramDouble2, double paramDouble3, String paramString, double paramDouble4, int paramInt2);
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   private static native void nPlotPieChart(String[] paramArrayOfString, int paramInt1, int[] paramArrayOfint, double paramDouble1, double paramDouble2, double paramDouble3, double paramDouble4, int paramInt2);
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static void plotPieChart(String[] labelIds, long[] values, double x, double y, double radius) {
/* 12447 */     nPlotPieChart(labelIds, labelIds.length, values, x, y, radius);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static void plotPieChart(String[] labelIds, long[] values, double x, double y, double radius, String labelFmt) {
/* 12454 */     nPlotPieChart(labelIds, labelIds.length, values, x, y, radius, labelFmt);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static void plotPieChart(String[] labelIds, long[] values, double x, double y, double radius, String labelFmt, double angle0) {
/* 12461 */     nPlotPieChart(labelIds, labelIds.length, values, x, y, radius, labelFmt, angle0);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static void plotPieChart(String[] labelIds, long[] values, double x, double y, double radius, String labelFmt, double angle0, int flags) {
/* 12468 */     nPlotPieChart(labelIds, labelIds.length, values, x, y, radius, labelFmt, angle0, flags);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static void plotPieChart(String[] labelIds, long[] values, double x, double y, double radius, double angle0, int flags) {
/* 12475 */     nPlotPieChart(labelIds, labelIds.length, values, x, y, radius, angle0, flags);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   private static native void nPlotPieChart(String[] paramArrayOfString, int paramInt, long[] paramArrayOflong, double paramDouble1, double paramDouble2, double paramDouble3);
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   private static native void nPlotPieChart(String[] paramArrayOfString, int paramInt, long[] paramArrayOflong, double paramDouble1, double paramDouble2, double paramDouble3, String paramString);
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   private static native void nPlotPieChart(String[] paramArrayOfString, int paramInt, long[] paramArrayOflong, double paramDouble1, double paramDouble2, double paramDouble3, String paramString, double paramDouble4);
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   private static native void nPlotPieChart(String[] paramArrayOfString, int paramInt1, long[] paramArrayOflong, double paramDouble1, double paramDouble2, double paramDouble3, String paramString, double paramDouble4, int paramInt2);
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   private static native void nPlotPieChart(String[] paramArrayOfString, int paramInt1, long[] paramArrayOflong, double paramDouble1, double paramDouble2, double paramDouble3, double paramDouble4, int paramInt2);
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static void plotPieChart(String[] labelIds, float[] values, double x, double y, double radius) {
/* 12568 */     nPlotPieChart(labelIds, labelIds.length, values, x, y, radius);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static void plotPieChart(String[] labelIds, float[] values, double x, double y, double radius, String labelFmt) {
/* 12575 */     nPlotPieChart(labelIds, labelIds.length, values, x, y, radius, labelFmt);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static void plotPieChart(String[] labelIds, float[] values, double x, double y, double radius, String labelFmt, double angle0) {
/* 12582 */     nPlotPieChart(labelIds, labelIds.length, values, x, y, radius, labelFmt, angle0);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static void plotPieChart(String[] labelIds, float[] values, double x, double y, double radius, String labelFmt, double angle0, int flags) {
/* 12589 */     nPlotPieChart(labelIds, labelIds.length, values, x, y, radius, labelFmt, angle0, flags);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static void plotPieChart(String[] labelIds, float[] values, double x, double y, double radius, double angle0, int flags) {
/* 12596 */     nPlotPieChart(labelIds, labelIds.length, values, x, y, radius, angle0, flags);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   private static native void nPlotPieChart(String[] paramArrayOfString, int paramInt, float[] paramArrayOffloat, double paramDouble1, double paramDouble2, double paramDouble3);
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   private static native void nPlotPieChart(String[] paramArrayOfString, int paramInt, float[] paramArrayOffloat, double paramDouble1, double paramDouble2, double paramDouble3, String paramString);
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   private static native void nPlotPieChart(String[] paramArrayOfString, int paramInt, float[] paramArrayOffloat, double paramDouble1, double paramDouble2, double paramDouble3, String paramString, double paramDouble4);
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   private static native void nPlotPieChart(String[] paramArrayOfString, int paramInt1, float[] paramArrayOffloat, double paramDouble1, double paramDouble2, double paramDouble3, String paramString, double paramDouble4, int paramInt2);
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   private static native void nPlotPieChart(String[] paramArrayOfString, int paramInt1, float[] paramArrayOffloat, double paramDouble1, double paramDouble2, double paramDouble3, double paramDouble4, int paramInt2);
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static void plotPieChart(String[] labelIds, double[] values, double x, double y, double radius) {
/* 12689 */     nPlotPieChart(labelIds, labelIds.length, values, x, y, radius);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static void plotPieChart(String[] labelIds, double[] values, double x, double y, double radius, String labelFmt) {
/* 12696 */     nPlotPieChart(labelIds, labelIds.length, values, x, y, radius, labelFmt);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static void plotPieChart(String[] labelIds, double[] values, double x, double y, double radius, String labelFmt, double angle0) {
/* 12703 */     nPlotPieChart(labelIds, labelIds.length, values, x, y, radius, labelFmt, angle0);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static void plotPieChart(String[] labelIds, double[] values, double x, double y, double radius, String labelFmt, double angle0, int flags) {
/* 12710 */     nPlotPieChart(labelIds, labelIds.length, values, x, y, radius, labelFmt, angle0, flags);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static void plotPieChart(String[] labelIds, double[] values, double x, double y, double radius, double angle0, int flags) {
/* 12717 */     nPlotPieChart(labelIds, labelIds.length, values, x, y, radius, angle0, flags);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   private static native void nPlotPieChart(String[] paramArrayOfString, int paramInt, double[] paramArrayOfdouble, double paramDouble1, double paramDouble2, double paramDouble3);
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   private static native void nPlotPieChart(String[] paramArrayOfString, int paramInt, double[] paramArrayOfdouble, double paramDouble1, double paramDouble2, double paramDouble3, String paramString);
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   private static native void nPlotPieChart(String[] paramArrayOfString, int paramInt, double[] paramArrayOfdouble, double paramDouble1, double paramDouble2, double paramDouble3, String paramString, double paramDouble4);
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   private static native void nPlotPieChart(String[] paramArrayOfString, int paramInt1, double[] paramArrayOfdouble, double paramDouble1, double paramDouble2, double paramDouble3, String paramString, double paramDouble4, int paramInt2);
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   private static native void nPlotPieChart(String[] paramArrayOfString, int paramInt1, double[] paramArrayOfdouble, double paramDouble1, double paramDouble2, double paramDouble3, double paramDouble4, int paramInt2);
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static void plotPieChartV(String[] labelIds, short[] values, int count, double x, double y, double radius) {
/* 12810 */     nPlotPieChartV(labelIds, labelIds.length, values, count, x, y, radius);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static void plotPieChartV(String[] labelIds, short[] values, int count, double x, double y, double radius, String labelFmt) {
/* 12817 */     nPlotPieChartV(labelIds, labelIds.length, values, count, x, y, radius, labelFmt);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static void plotPieChartV(String[] labelIds, short[] values, int count, double x, double y, double radius, String labelFmt, double angle0) {
/* 12824 */     nPlotPieChartV(labelIds, labelIds.length, values, count, x, y, radius, labelFmt, angle0);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static void plotPieChartV(String[] labelIds, short[] values, int count, double x, double y, double radius, String labelFmt, double angle0, int flags) {
/* 12831 */     nPlotPieChartV(labelIds, labelIds.length, values, count, x, y, radius, labelFmt, angle0, flags);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static void plotPieChartV(String[] labelIds, short[] values, int count, double x, double y, double radius, double angle0, int flags) {
/* 12838 */     nPlotPieChartV(labelIds, labelIds.length, values, count, x, y, radius, angle0, flags);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   private static native void nPlotPieChartV(String[] paramArrayOfString, int paramInt1, short[] paramArrayOfshort, int paramInt2, double paramDouble1, double paramDouble2, double paramDouble3);
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   private static native void nPlotPieChartV(String[] paramArrayOfString, int paramInt1, short[] paramArrayOfshort, int paramInt2, double paramDouble1, double paramDouble2, double paramDouble3, String paramString);
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   private static native void nPlotPieChartV(String[] paramArrayOfString, int paramInt1, short[] paramArrayOfshort, int paramInt2, double paramDouble1, double paramDouble2, double paramDouble3, String paramString, double paramDouble4);
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   private static native void nPlotPieChartV(String[] paramArrayOfString, int paramInt1, short[] paramArrayOfshort, int paramInt2, double paramDouble1, double paramDouble2, double paramDouble3, String paramString, double paramDouble4, int paramInt3);
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   private static native void nPlotPieChartV(String[] paramArrayOfString, int paramInt1, short[] paramArrayOfshort, int paramInt2, double paramDouble1, double paramDouble2, double paramDouble3, double paramDouble4, int paramInt3);
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static void plotPieChartV(String[] labelIds, int[] values, int count, double x, double y, double radius) {
/* 12931 */     nPlotPieChartV(labelIds, labelIds.length, values, count, x, y, radius);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static void plotPieChartV(String[] labelIds, int[] values, int count, double x, double y, double radius, String labelFmt) {
/* 12938 */     nPlotPieChartV(labelIds, labelIds.length, values, count, x, y, radius, labelFmt);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static void plotPieChartV(String[] labelIds, int[] values, int count, double x, double y, double radius, String labelFmt, double angle0) {
/* 12945 */     nPlotPieChartV(labelIds, labelIds.length, values, count, x, y, radius, labelFmt, angle0);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static void plotPieChartV(String[] labelIds, int[] values, int count, double x, double y, double radius, String labelFmt, double angle0, int flags) {
/* 12952 */     nPlotPieChartV(labelIds, labelIds.length, values, count, x, y, radius, labelFmt, angle0, flags);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static void plotPieChartV(String[] labelIds, int[] values, int count, double x, double y, double radius, double angle0, int flags) {
/* 12959 */     nPlotPieChartV(labelIds, labelIds.length, values, count, x, y, radius, angle0, flags);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   private static native void nPlotPieChartV(String[] paramArrayOfString, int paramInt1, int[] paramArrayOfint, int paramInt2, double paramDouble1, double paramDouble2, double paramDouble3);
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   private static native void nPlotPieChartV(String[] paramArrayOfString, int paramInt1, int[] paramArrayOfint, int paramInt2, double paramDouble1, double paramDouble2, double paramDouble3, String paramString);
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   private static native void nPlotPieChartV(String[] paramArrayOfString, int paramInt1, int[] paramArrayOfint, int paramInt2, double paramDouble1, double paramDouble2, double paramDouble3, String paramString, double paramDouble4);
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   private static native void nPlotPieChartV(String[] paramArrayOfString, int paramInt1, int[] paramArrayOfint, int paramInt2, double paramDouble1, double paramDouble2, double paramDouble3, String paramString, double paramDouble4, int paramInt3);
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   private static native void nPlotPieChartV(String[] paramArrayOfString, int paramInt1, int[] paramArrayOfint, int paramInt2, double paramDouble1, double paramDouble2, double paramDouble3, double paramDouble4, int paramInt3);
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static void plotPieChartV(String[] labelIds, long[] values, int count, double x, double y, double radius) {
/* 13052 */     nPlotPieChartV(labelIds, labelIds.length, values, count, x, y, radius);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static void plotPieChartV(String[] labelIds, long[] values, int count, double x, double y, double radius, String labelFmt) {
/* 13059 */     nPlotPieChartV(labelIds, labelIds.length, values, count, x, y, radius, labelFmt);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static void plotPieChartV(String[] labelIds, long[] values, int count, double x, double y, double radius, String labelFmt, double angle0) {
/* 13066 */     nPlotPieChartV(labelIds, labelIds.length, values, count, x, y, radius, labelFmt, angle0);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static void plotPieChartV(String[] labelIds, long[] values, int count, double x, double y, double radius, String labelFmt, double angle0, int flags) {
/* 13073 */     nPlotPieChartV(labelIds, labelIds.length, values, count, x, y, radius, labelFmt, angle0, flags);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static void plotPieChartV(String[] labelIds, long[] values, int count, double x, double y, double radius, double angle0, int flags) {
/* 13080 */     nPlotPieChartV(labelIds, labelIds.length, values, count, x, y, radius, angle0, flags);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   private static native void nPlotPieChartV(String[] paramArrayOfString, int paramInt1, long[] paramArrayOflong, int paramInt2, double paramDouble1, double paramDouble2, double paramDouble3);
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   private static native void nPlotPieChartV(String[] paramArrayOfString, int paramInt1, long[] paramArrayOflong, int paramInt2, double paramDouble1, double paramDouble2, double paramDouble3, String paramString);
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   private static native void nPlotPieChartV(String[] paramArrayOfString, int paramInt1, long[] paramArrayOflong, int paramInt2, double paramDouble1, double paramDouble2, double paramDouble3, String paramString, double paramDouble4);
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   private static native void nPlotPieChartV(String[] paramArrayOfString, int paramInt1, long[] paramArrayOflong, int paramInt2, double paramDouble1, double paramDouble2, double paramDouble3, String paramString, double paramDouble4, int paramInt3);
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   private static native void nPlotPieChartV(String[] paramArrayOfString, int paramInt1, long[] paramArrayOflong, int paramInt2, double paramDouble1, double paramDouble2, double paramDouble3, double paramDouble4, int paramInt3);
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static void plotPieChartV(String[] labelIds, float[] values, int count, double x, double y, double radius) {
/* 13173 */     nPlotPieChartV(labelIds, labelIds.length, values, count, x, y, radius);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static void plotPieChartV(String[] labelIds, float[] values, int count, double x, double y, double radius, String labelFmt) {
/* 13180 */     nPlotPieChartV(labelIds, labelIds.length, values, count, x, y, radius, labelFmt);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static void plotPieChartV(String[] labelIds, float[] values, int count, double x, double y, double radius, String labelFmt, double angle0) {
/* 13187 */     nPlotPieChartV(labelIds, labelIds.length, values, count, x, y, radius, labelFmt, angle0);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static void plotPieChartV(String[] labelIds, float[] values, int count, double x, double y, double radius, String labelFmt, double angle0, int flags) {
/* 13194 */     nPlotPieChartV(labelIds, labelIds.length, values, count, x, y, radius, labelFmt, angle0, flags);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static void plotPieChartV(String[] labelIds, float[] values, int count, double x, double y, double radius, double angle0, int flags) {
/* 13201 */     nPlotPieChartV(labelIds, labelIds.length, values, count, x, y, radius, angle0, flags);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   private static native void nPlotPieChartV(String[] paramArrayOfString, int paramInt1, float[] paramArrayOffloat, int paramInt2, double paramDouble1, double paramDouble2, double paramDouble3);
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   private static native void nPlotPieChartV(String[] paramArrayOfString, int paramInt1, float[] paramArrayOffloat, int paramInt2, double paramDouble1, double paramDouble2, double paramDouble3, String paramString);
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   private static native void nPlotPieChartV(String[] paramArrayOfString, int paramInt1, float[] paramArrayOffloat, int paramInt2, double paramDouble1, double paramDouble2, double paramDouble3, String paramString, double paramDouble4);
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   private static native void nPlotPieChartV(String[] paramArrayOfString, int paramInt1, float[] paramArrayOffloat, int paramInt2, double paramDouble1, double paramDouble2, double paramDouble3, String paramString, double paramDouble4, int paramInt3);
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   private static native void nPlotPieChartV(String[] paramArrayOfString, int paramInt1, float[] paramArrayOffloat, int paramInt2, double paramDouble1, double paramDouble2, double paramDouble3, double paramDouble4, int paramInt3);
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static void plotPieChartV(String[] labelIds, double[] values, int count, double x, double y, double radius) {
/* 13294 */     nPlotPieChartV(labelIds, labelIds.length, values, count, x, y, radius);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static void plotPieChartV(String[] labelIds, double[] values, int count, double x, double y, double radius, String labelFmt) {
/* 13301 */     nPlotPieChartV(labelIds, labelIds.length, values, count, x, y, radius, labelFmt);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static void plotPieChartV(String[] labelIds, double[] values, int count, double x, double y, double radius, String labelFmt, double angle0) {
/* 13308 */     nPlotPieChartV(labelIds, labelIds.length, values, count, x, y, radius, labelFmt, angle0);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static void plotPieChartV(String[] labelIds, double[] values, int count, double x, double y, double radius, String labelFmt, double angle0, int flags) {
/* 13315 */     nPlotPieChartV(labelIds, labelIds.length, values, count, x, y, radius, labelFmt, angle0, flags);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static void plotPieChartV(String[] labelIds, double[] values, int count, double x, double y, double radius, double angle0, int flags) {
/* 13322 */     nPlotPieChartV(labelIds, labelIds.length, values, count, x, y, radius, angle0, flags);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   private static native void nPlotPieChartV(String[] paramArrayOfString, int paramInt1, double[] paramArrayOfdouble, int paramInt2, double paramDouble1, double paramDouble2, double paramDouble3);
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   private static native void nPlotPieChartV(String[] paramArrayOfString, int paramInt1, double[] paramArrayOfdouble, int paramInt2, double paramDouble1, double paramDouble2, double paramDouble3, String paramString);
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   private static native void nPlotPieChartV(String[] paramArrayOfString, int paramInt1, double[] paramArrayOfdouble, int paramInt2, double paramDouble1, double paramDouble2, double paramDouble3, String paramString, double paramDouble4);
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   private static native void nPlotPieChartV(String[] paramArrayOfString, int paramInt1, double[] paramArrayOfdouble, int paramInt2, double paramDouble1, double paramDouble2, double paramDouble3, String paramString, double paramDouble4, int paramInt3);
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   private static native void nPlotPieChartV(String[] paramArrayOfString, int paramInt1, double[] paramArrayOfdouble, int paramInt2, double paramDouble1, double paramDouble2, double paramDouble3, double paramDouble4, int paramInt3);
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static void plotHeatmap(String labelId, short[] values, int rows, int cols) {
/* 13415 */     nPlotHeatmap(labelId, values, rows, cols);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static void plotHeatmap(String labelId, short[] values, int rows, int cols, double scaleMin) {
/* 13422 */     nPlotHeatmap(labelId, values, rows, cols, scaleMin);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static void plotHeatmap(String labelId, short[] values, int rows, int cols, double scaleMin, double scaleMax) {
/* 13429 */     nPlotHeatmap(labelId, values, rows, cols, scaleMin, scaleMax);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static void plotHeatmap(String labelId, short[] values, int rows, int cols, double scaleMin, double scaleMax, String labelFmt) {
/* 13436 */     nPlotHeatmap(labelId, values, rows, cols, scaleMin, scaleMax, labelFmt);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static void plotHeatmap(String labelId, short[] values, int rows, int cols, double scaleMin, double scaleMax, String labelFmt, ImPlotPoint boundsMin) {
/* 13443 */     nPlotHeatmap(labelId, values, rows, cols, scaleMin, scaleMax, labelFmt, boundsMin.x, boundsMin.y);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static void plotHeatmap(String labelId, short[] values, int rows, int cols, double scaleMin, double scaleMax, String labelFmt, double boundsMinX, double boundsMinY) {
/* 13450 */     nPlotHeatmap(labelId, values, rows, cols, scaleMin, scaleMax, labelFmt, boundsMinX, boundsMinY);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static void plotHeatmap(String labelId, short[] values, int rows, int cols, double scaleMin, double scaleMax, String labelFmt, ImPlotPoint boundsMin, ImPlotPoint boundsMax) {
/* 13457 */     nPlotHeatmap(labelId, values, rows, cols, scaleMin, scaleMax, labelFmt, boundsMin.x, boundsMin.y, boundsMax.x, boundsMax.y);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static void plotHeatmap(String labelId, short[] values, int rows, int cols, double scaleMin, double scaleMax, String labelFmt, double boundsMinX, double boundsMinY, double boundsMaxX, double boundsMaxY) {
/* 13464 */     nPlotHeatmap(labelId, values, rows, cols, scaleMin, scaleMax, labelFmt, boundsMinX, boundsMinY, boundsMaxX, boundsMaxY);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static void plotHeatmap(String labelId, short[] values, int rows, int cols, double scaleMin, double scaleMax, String labelFmt, ImPlotPoint boundsMin, ImPlotPoint boundsMax, int flags) {
/* 13471 */     nPlotHeatmap(labelId, values, rows, cols, scaleMin, scaleMax, labelFmt, boundsMin.x, boundsMin.y, boundsMax.x, boundsMax.y, flags);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static void plotHeatmap(String labelId, short[] values, int rows, int cols, double scaleMin, double scaleMax, String labelFmt, double boundsMinX, double boundsMinY, double boundsMaxX, double boundsMaxY, int flags) {
/* 13478 */     nPlotHeatmap(labelId, values, rows, cols, scaleMin, scaleMax, labelFmt, boundsMinX, boundsMinY, boundsMaxX, boundsMaxY, flags);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static void plotHeatmap(String labelId, short[] values, int rows, int cols, double scaleMin, double scaleMax, ImPlotPoint boundsMin, ImPlotPoint boundsMax, int flags) {
/* 13485 */     nPlotHeatmap(labelId, values, rows, cols, scaleMin, scaleMax, boundsMin.x, boundsMin.y, boundsMax.x, boundsMax.y, flags);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static void plotHeatmap(String labelId, short[] values, int rows, int cols, double scaleMin, double scaleMax, double boundsMinX, double boundsMinY, double boundsMaxX, double boundsMaxY, int flags) {
/* 13492 */     nPlotHeatmap(labelId, values, rows, cols, scaleMin, scaleMax, boundsMinX, boundsMinY, boundsMaxX, boundsMaxY, flags);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   private static native void nPlotHeatmap(String paramString, short[] paramArrayOfshort, int paramInt1, int paramInt2);
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   private static native void nPlotHeatmap(String paramString, short[] paramArrayOfshort, int paramInt1, int paramInt2, double paramDouble);
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   private static native void nPlotHeatmap(String paramString, short[] paramArrayOfshort, int paramInt1, int paramInt2, double paramDouble1, double paramDouble2);
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   private static native void nPlotHeatmap(String paramString1, short[] paramArrayOfshort, int paramInt1, int paramInt2, double paramDouble1, double paramDouble2, String paramString2);
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   private static native void nPlotHeatmap(String paramString1, short[] paramArrayOfshort, int paramInt1, int paramInt2, double paramDouble1, double paramDouble2, String paramString2, double paramDouble3, double paramDouble4);
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   private static native void nPlotHeatmap(String paramString1, short[] paramArrayOfshort, int paramInt1, int paramInt2, double paramDouble1, double paramDouble2, String paramString2, double paramDouble3, double paramDouble4, double paramDouble5, double paramDouble6);
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   private static native void nPlotHeatmap(String paramString1, short[] paramArrayOfshort, int paramInt1, int paramInt2, double paramDouble1, double paramDouble2, String paramString2, double paramDouble3, double paramDouble4, double paramDouble5, double paramDouble6, int paramInt3);
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   private static native void nPlotHeatmap(String paramString, short[] paramArrayOfshort, int paramInt1, int paramInt2, double paramDouble1, double paramDouble2, double paramDouble3, double paramDouble4, double paramDouble5, double paramDouble6, int paramInt3);
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static void plotHeatmap(String labelId, int[] values, int rows, int cols) {
/* 13571 */     nPlotHeatmap(labelId, values, rows, cols);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static void plotHeatmap(String labelId, int[] values, int rows, int cols, double scaleMin) {
/* 13578 */     nPlotHeatmap(labelId, values, rows, cols, scaleMin);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static void plotHeatmap(String labelId, int[] values, int rows, int cols, double scaleMin, double scaleMax) {
/* 13585 */     nPlotHeatmap(labelId, values, rows, cols, scaleMin, scaleMax);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static void plotHeatmap(String labelId, int[] values, int rows, int cols, double scaleMin, double scaleMax, String labelFmt) {
/* 13592 */     nPlotHeatmap(labelId, values, rows, cols, scaleMin, scaleMax, labelFmt);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static void plotHeatmap(String labelId, int[] values, int rows, int cols, double scaleMin, double scaleMax, String labelFmt, ImPlotPoint boundsMin) {
/* 13599 */     nPlotHeatmap(labelId, values, rows, cols, scaleMin, scaleMax, labelFmt, boundsMin.x, boundsMin.y);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static void plotHeatmap(String labelId, int[] values, int rows, int cols, double scaleMin, double scaleMax, String labelFmt, double boundsMinX, double boundsMinY) {
/* 13606 */     nPlotHeatmap(labelId, values, rows, cols, scaleMin, scaleMax, labelFmt, boundsMinX, boundsMinY);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static void plotHeatmap(String labelId, int[] values, int rows, int cols, double scaleMin, double scaleMax, String labelFmt, ImPlotPoint boundsMin, ImPlotPoint boundsMax) {
/* 13613 */     nPlotHeatmap(labelId, values, rows, cols, scaleMin, scaleMax, labelFmt, boundsMin.x, boundsMin.y, boundsMax.x, boundsMax.y);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static void plotHeatmap(String labelId, int[] values, int rows, int cols, double scaleMin, double scaleMax, String labelFmt, double boundsMinX, double boundsMinY, double boundsMaxX, double boundsMaxY) {
/* 13620 */     nPlotHeatmap(labelId, values, rows, cols, scaleMin, scaleMax, labelFmt, boundsMinX, boundsMinY, boundsMaxX, boundsMaxY);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static void plotHeatmap(String labelId, int[] values, int rows, int cols, double scaleMin, double scaleMax, String labelFmt, ImPlotPoint boundsMin, ImPlotPoint boundsMax, int flags) {
/* 13627 */     nPlotHeatmap(labelId, values, rows, cols, scaleMin, scaleMax, labelFmt, boundsMin.x, boundsMin.y, boundsMax.x, boundsMax.y, flags);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static void plotHeatmap(String labelId, int[] values, int rows, int cols, double scaleMin, double scaleMax, String labelFmt, double boundsMinX, double boundsMinY, double boundsMaxX, double boundsMaxY, int flags) {
/* 13634 */     nPlotHeatmap(labelId, values, rows, cols, scaleMin, scaleMax, labelFmt, boundsMinX, boundsMinY, boundsMaxX, boundsMaxY, flags);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static void plotHeatmap(String labelId, int[] values, int rows, int cols, double scaleMin, double scaleMax, ImPlotPoint boundsMin, ImPlotPoint boundsMax, int flags) {
/* 13641 */     nPlotHeatmap(labelId, values, rows, cols, scaleMin, scaleMax, boundsMin.x, boundsMin.y, boundsMax.x, boundsMax.y, flags);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static void plotHeatmap(String labelId, int[] values, int rows, int cols, double scaleMin, double scaleMax, double boundsMinX, double boundsMinY, double boundsMaxX, double boundsMaxY, int flags) {
/* 13648 */     nPlotHeatmap(labelId, values, rows, cols, scaleMin, scaleMax, boundsMinX, boundsMinY, boundsMaxX, boundsMaxY, flags);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   private static native void nPlotHeatmap(String paramString, int[] paramArrayOfint, int paramInt1, int paramInt2);
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   private static native void nPlotHeatmap(String paramString, int[] paramArrayOfint, int paramInt1, int paramInt2, double paramDouble);
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   private static native void nPlotHeatmap(String paramString, int[] paramArrayOfint, int paramInt1, int paramInt2, double paramDouble1, double paramDouble2);
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   private static native void nPlotHeatmap(String paramString1, int[] paramArrayOfint, int paramInt1, int paramInt2, double paramDouble1, double paramDouble2, String paramString2);
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   private static native void nPlotHeatmap(String paramString1, int[] paramArrayOfint, int paramInt1, int paramInt2, double paramDouble1, double paramDouble2, String paramString2, double paramDouble3, double paramDouble4);
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   private static native void nPlotHeatmap(String paramString1, int[] paramArrayOfint, int paramInt1, int paramInt2, double paramDouble1, double paramDouble2, String paramString2, double paramDouble3, double paramDouble4, double paramDouble5, double paramDouble6);
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   private static native void nPlotHeatmap(String paramString1, int[] paramArrayOfint, int paramInt1, int paramInt2, double paramDouble1, double paramDouble2, String paramString2, double paramDouble3, double paramDouble4, double paramDouble5, double paramDouble6, int paramInt3);
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   private static native void nPlotHeatmap(String paramString, int[] paramArrayOfint, int paramInt1, int paramInt2, double paramDouble1, double paramDouble2, double paramDouble3, double paramDouble4, double paramDouble5, double paramDouble6, int paramInt3);
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static void plotHeatmap(String labelId, long[] values, int rows, int cols) {
/* 13727 */     nPlotHeatmap(labelId, values, rows, cols);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static void plotHeatmap(String labelId, long[] values, int rows, int cols, double scaleMin) {
/* 13734 */     nPlotHeatmap(labelId, values, rows, cols, scaleMin);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static void plotHeatmap(String labelId, long[] values, int rows, int cols, double scaleMin, double scaleMax) {
/* 13741 */     nPlotHeatmap(labelId, values, rows, cols, scaleMin, scaleMax);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static void plotHeatmap(String labelId, long[] values, int rows, int cols, double scaleMin, double scaleMax, String labelFmt) {
/* 13748 */     nPlotHeatmap(labelId, values, rows, cols, scaleMin, scaleMax, labelFmt);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static void plotHeatmap(String labelId, long[] values, int rows, int cols, double scaleMin, double scaleMax, String labelFmt, ImPlotPoint boundsMin) {
/* 13755 */     nPlotHeatmap(labelId, values, rows, cols, scaleMin, scaleMax, labelFmt, boundsMin.x, boundsMin.y);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static void plotHeatmap(String labelId, long[] values, int rows, int cols, double scaleMin, double scaleMax, String labelFmt, double boundsMinX, double boundsMinY) {
/* 13762 */     nPlotHeatmap(labelId, values, rows, cols, scaleMin, scaleMax, labelFmt, boundsMinX, boundsMinY);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static void plotHeatmap(String labelId, long[] values, int rows, int cols, double scaleMin, double scaleMax, String labelFmt, ImPlotPoint boundsMin, ImPlotPoint boundsMax) {
/* 13769 */     nPlotHeatmap(labelId, values, rows, cols, scaleMin, scaleMax, labelFmt, boundsMin.x, boundsMin.y, boundsMax.x, boundsMax.y);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static void plotHeatmap(String labelId, long[] values, int rows, int cols, double scaleMin, double scaleMax, String labelFmt, double boundsMinX, double boundsMinY, double boundsMaxX, double boundsMaxY) {
/* 13776 */     nPlotHeatmap(labelId, values, rows, cols, scaleMin, scaleMax, labelFmt, boundsMinX, boundsMinY, boundsMaxX, boundsMaxY);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static void plotHeatmap(String labelId, long[] values, int rows, int cols, double scaleMin, double scaleMax, String labelFmt, ImPlotPoint boundsMin, ImPlotPoint boundsMax, int flags) {
/* 13783 */     nPlotHeatmap(labelId, values, rows, cols, scaleMin, scaleMax, labelFmt, boundsMin.x, boundsMin.y, boundsMax.x, boundsMax.y, flags);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static void plotHeatmap(String labelId, long[] values, int rows, int cols, double scaleMin, double scaleMax, String labelFmt, double boundsMinX, double boundsMinY, double boundsMaxX, double boundsMaxY, int flags) {
/* 13790 */     nPlotHeatmap(labelId, values, rows, cols, scaleMin, scaleMax, labelFmt, boundsMinX, boundsMinY, boundsMaxX, boundsMaxY, flags);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static void plotHeatmap(String labelId, long[] values, int rows, int cols, double scaleMin, double scaleMax, ImPlotPoint boundsMin, ImPlotPoint boundsMax, int flags) {
/* 13797 */     nPlotHeatmap(labelId, values, rows, cols, scaleMin, scaleMax, boundsMin.x, boundsMin.y, boundsMax.x, boundsMax.y, flags);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static void plotHeatmap(String labelId, long[] values, int rows, int cols, double scaleMin, double scaleMax, double boundsMinX, double boundsMinY, double boundsMaxX, double boundsMaxY, int flags) {
/* 13804 */     nPlotHeatmap(labelId, values, rows, cols, scaleMin, scaleMax, boundsMinX, boundsMinY, boundsMaxX, boundsMaxY, flags);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   private static native void nPlotHeatmap(String paramString, long[] paramArrayOflong, int paramInt1, int paramInt2);
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   private static native void nPlotHeatmap(String paramString, long[] paramArrayOflong, int paramInt1, int paramInt2, double paramDouble);
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   private static native void nPlotHeatmap(String paramString, long[] paramArrayOflong, int paramInt1, int paramInt2, double paramDouble1, double paramDouble2);
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   private static native void nPlotHeatmap(String paramString1, long[] paramArrayOflong, int paramInt1, int paramInt2, double paramDouble1, double paramDouble2, String paramString2);
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   private static native void nPlotHeatmap(String paramString1, long[] paramArrayOflong, int paramInt1, int paramInt2, double paramDouble1, double paramDouble2, String paramString2, double paramDouble3, double paramDouble4);
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   private static native void nPlotHeatmap(String paramString1, long[] paramArrayOflong, int paramInt1, int paramInt2, double paramDouble1, double paramDouble2, String paramString2, double paramDouble3, double paramDouble4, double paramDouble5, double paramDouble6);
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   private static native void nPlotHeatmap(String paramString1, long[] paramArrayOflong, int paramInt1, int paramInt2, double paramDouble1, double paramDouble2, String paramString2, double paramDouble3, double paramDouble4, double paramDouble5, double paramDouble6, int paramInt3);
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   private static native void nPlotHeatmap(String paramString, long[] paramArrayOflong, int paramInt1, int paramInt2, double paramDouble1, double paramDouble2, double paramDouble3, double paramDouble4, double paramDouble5, double paramDouble6, int paramInt3);
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static void plotHeatmap(String labelId, float[] values, int rows, int cols) {
/* 13883 */     nPlotHeatmap(labelId, values, rows, cols);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static void plotHeatmap(String labelId, float[] values, int rows, int cols, double scaleMin) {
/* 13890 */     nPlotHeatmap(labelId, values, rows, cols, scaleMin);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static void plotHeatmap(String labelId, float[] values, int rows, int cols, double scaleMin, double scaleMax) {
/* 13897 */     nPlotHeatmap(labelId, values, rows, cols, scaleMin, scaleMax);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static void plotHeatmap(String labelId, float[] values, int rows, int cols, double scaleMin, double scaleMax, String labelFmt) {
/* 13904 */     nPlotHeatmap(labelId, values, rows, cols, scaleMin, scaleMax, labelFmt);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static void plotHeatmap(String labelId, float[] values, int rows, int cols, double scaleMin, double scaleMax, String labelFmt, ImPlotPoint boundsMin) {
/* 13911 */     nPlotHeatmap(labelId, values, rows, cols, scaleMin, scaleMax, labelFmt, boundsMin.x, boundsMin.y);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static void plotHeatmap(String labelId, float[] values, int rows, int cols, double scaleMin, double scaleMax, String labelFmt, double boundsMinX, double boundsMinY) {
/* 13918 */     nPlotHeatmap(labelId, values, rows, cols, scaleMin, scaleMax, labelFmt, boundsMinX, boundsMinY);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static void plotHeatmap(String labelId, float[] values, int rows, int cols, double scaleMin, double scaleMax, String labelFmt, ImPlotPoint boundsMin, ImPlotPoint boundsMax) {
/* 13925 */     nPlotHeatmap(labelId, values, rows, cols, scaleMin, scaleMax, labelFmt, boundsMin.x, boundsMin.y, boundsMax.x, boundsMax.y);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static void plotHeatmap(String labelId, float[] values, int rows, int cols, double scaleMin, double scaleMax, String labelFmt, double boundsMinX, double boundsMinY, double boundsMaxX, double boundsMaxY) {
/* 13932 */     nPlotHeatmap(labelId, values, rows, cols, scaleMin, scaleMax, labelFmt, boundsMinX, boundsMinY, boundsMaxX, boundsMaxY);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static void plotHeatmap(String labelId, float[] values, int rows, int cols, double scaleMin, double scaleMax, String labelFmt, ImPlotPoint boundsMin, ImPlotPoint boundsMax, int flags) {
/* 13939 */     nPlotHeatmap(labelId, values, rows, cols, scaleMin, scaleMax, labelFmt, boundsMin.x, boundsMin.y, boundsMax.x, boundsMax.y, flags);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static void plotHeatmap(String labelId, float[] values, int rows, int cols, double scaleMin, double scaleMax, String labelFmt, double boundsMinX, double boundsMinY, double boundsMaxX, double boundsMaxY, int flags) {
/* 13946 */     nPlotHeatmap(labelId, values, rows, cols, scaleMin, scaleMax, labelFmt, boundsMinX, boundsMinY, boundsMaxX, boundsMaxY, flags);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static void plotHeatmap(String labelId, float[] values, int rows, int cols, double scaleMin, double scaleMax, ImPlotPoint boundsMin, ImPlotPoint boundsMax, int flags) {
/* 13953 */     nPlotHeatmap(labelId, values, rows, cols, scaleMin, scaleMax, boundsMin.x, boundsMin.y, boundsMax.x, boundsMax.y, flags);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static void plotHeatmap(String labelId, float[] values, int rows, int cols, double scaleMin, double scaleMax, double boundsMinX, double boundsMinY, double boundsMaxX, double boundsMaxY, int flags) {
/* 13960 */     nPlotHeatmap(labelId, values, rows, cols, scaleMin, scaleMax, boundsMinX, boundsMinY, boundsMaxX, boundsMaxY, flags);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   private static native void nPlotHeatmap(String paramString, float[] paramArrayOffloat, int paramInt1, int paramInt2);
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   private static native void nPlotHeatmap(String paramString, float[] paramArrayOffloat, int paramInt1, int paramInt2, double paramDouble);
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   private static native void nPlotHeatmap(String paramString, float[] paramArrayOffloat, int paramInt1, int paramInt2, double paramDouble1, double paramDouble2);
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   private static native void nPlotHeatmap(String paramString1, float[] paramArrayOffloat, int paramInt1, int paramInt2, double paramDouble1, double paramDouble2, String paramString2);
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   private static native void nPlotHeatmap(String paramString1, float[] paramArrayOffloat, int paramInt1, int paramInt2, double paramDouble1, double paramDouble2, String paramString2, double paramDouble3, double paramDouble4);
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   private static native void nPlotHeatmap(String paramString1, float[] paramArrayOffloat, int paramInt1, int paramInt2, double paramDouble1, double paramDouble2, String paramString2, double paramDouble3, double paramDouble4, double paramDouble5, double paramDouble6);
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   private static native void nPlotHeatmap(String paramString1, float[] paramArrayOffloat, int paramInt1, int paramInt2, double paramDouble1, double paramDouble2, String paramString2, double paramDouble3, double paramDouble4, double paramDouble5, double paramDouble6, int paramInt3);
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   private static native void nPlotHeatmap(String paramString, float[] paramArrayOffloat, int paramInt1, int paramInt2, double paramDouble1, double paramDouble2, double paramDouble3, double paramDouble4, double paramDouble5, double paramDouble6, int paramInt3);
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static void plotHeatmap(String labelId, double[] values, int rows, int cols) {
/* 14039 */     nPlotHeatmap(labelId, values, rows, cols);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static void plotHeatmap(String labelId, double[] values, int rows, int cols, double scaleMin) {
/* 14046 */     nPlotHeatmap(labelId, values, rows, cols, scaleMin);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static void plotHeatmap(String labelId, double[] values, int rows, int cols, double scaleMin, double scaleMax) {
/* 14053 */     nPlotHeatmap(labelId, values, rows, cols, scaleMin, scaleMax);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static void plotHeatmap(String labelId, double[] values, int rows, int cols, double scaleMin, double scaleMax, String labelFmt) {
/* 14060 */     nPlotHeatmap(labelId, values, rows, cols, scaleMin, scaleMax, labelFmt);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static void plotHeatmap(String labelId, double[] values, int rows, int cols, double scaleMin, double scaleMax, String labelFmt, ImPlotPoint boundsMin) {
/* 14067 */     nPlotHeatmap(labelId, values, rows, cols, scaleMin, scaleMax, labelFmt, boundsMin.x, boundsMin.y);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static void plotHeatmap(String labelId, double[] values, int rows, int cols, double scaleMin, double scaleMax, String labelFmt, double boundsMinX, double boundsMinY) {
/* 14074 */     nPlotHeatmap(labelId, values, rows, cols, scaleMin, scaleMax, labelFmt, boundsMinX, boundsMinY);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static void plotHeatmap(String labelId, double[] values, int rows, int cols, double scaleMin, double scaleMax, String labelFmt, ImPlotPoint boundsMin, ImPlotPoint boundsMax) {
/* 14081 */     nPlotHeatmap(labelId, values, rows, cols, scaleMin, scaleMax, labelFmt, boundsMin.x, boundsMin.y, boundsMax.x, boundsMax.y);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static void plotHeatmap(String labelId, double[] values, int rows, int cols, double scaleMin, double scaleMax, String labelFmt, double boundsMinX, double boundsMinY, double boundsMaxX, double boundsMaxY) {
/* 14088 */     nPlotHeatmap(labelId, values, rows, cols, scaleMin, scaleMax, labelFmt, boundsMinX, boundsMinY, boundsMaxX, boundsMaxY);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static void plotHeatmap(String labelId, double[] values, int rows, int cols, double scaleMin, double scaleMax, String labelFmt, ImPlotPoint boundsMin, ImPlotPoint boundsMax, int flags) {
/* 14095 */     nPlotHeatmap(labelId, values, rows, cols, scaleMin, scaleMax, labelFmt, boundsMin.x, boundsMin.y, boundsMax.x, boundsMax.y, flags);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static void plotHeatmap(String labelId, double[] values, int rows, int cols, double scaleMin, double scaleMax, String labelFmt, double boundsMinX, double boundsMinY, double boundsMaxX, double boundsMaxY, int flags) {
/* 14102 */     nPlotHeatmap(labelId, values, rows, cols, scaleMin, scaleMax, labelFmt, boundsMinX, boundsMinY, boundsMaxX, boundsMaxY, flags);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static void plotHeatmap(String labelId, double[] values, int rows, int cols, double scaleMin, double scaleMax, ImPlotPoint boundsMin, ImPlotPoint boundsMax, int flags) {
/* 14109 */     nPlotHeatmap(labelId, values, rows, cols, scaleMin, scaleMax, boundsMin.x, boundsMin.y, boundsMax.x, boundsMax.y, flags);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static void plotHeatmap(String labelId, double[] values, int rows, int cols, double scaleMin, double scaleMax, double boundsMinX, double boundsMinY, double boundsMaxX, double boundsMaxY, int flags) {
/* 14116 */     nPlotHeatmap(labelId, values, rows, cols, scaleMin, scaleMax, boundsMinX, boundsMinY, boundsMaxX, boundsMaxY, flags);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   private static native void nPlotHeatmap(String paramString, double[] paramArrayOfdouble, int paramInt1, int paramInt2);
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   private static native void nPlotHeatmap(String paramString, double[] paramArrayOfdouble, int paramInt1, int paramInt2, double paramDouble);
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   private static native void nPlotHeatmap(String paramString, double[] paramArrayOfdouble, int paramInt1, int paramInt2, double paramDouble1, double paramDouble2);
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   private static native void nPlotHeatmap(String paramString1, double[] paramArrayOfdouble, int paramInt1, int paramInt2, double paramDouble1, double paramDouble2, String paramString2);
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   private static native void nPlotHeatmap(String paramString1, double[] paramArrayOfdouble, int paramInt1, int paramInt2, double paramDouble1, double paramDouble2, String paramString2, double paramDouble3, double paramDouble4);
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   private static native void nPlotHeatmap(String paramString1, double[] paramArrayOfdouble, int paramInt1, int paramInt2, double paramDouble1, double paramDouble2, String paramString2, double paramDouble3, double paramDouble4, double paramDouble5, double paramDouble6);
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   private static native void nPlotHeatmap(String paramString1, double[] paramArrayOfdouble, int paramInt1, int paramInt2, double paramDouble1, double paramDouble2, String paramString2, double paramDouble3, double paramDouble4, double paramDouble5, double paramDouble6, int paramInt3);
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   private static native void nPlotHeatmap(String paramString, double[] paramArrayOfdouble, int paramInt1, int paramInt2, double paramDouble1, double paramDouble2, double paramDouble3, double paramDouble4, double paramDouble5, double paramDouble6, int paramInt3);
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static double plotHistogram(String labelId, short[] values) {
/* 14197 */     return nPlotHistogram(labelId, values);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static double plotHistogram(String labelId, short[] values, int bins) {
/* 14206 */     return nPlotHistogram(labelId, values, bins);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static double plotHistogram(String labelId, short[] values, int bins, double barScale) {
/* 14215 */     return nPlotHistogram(labelId, values, bins, barScale);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static double plotHistogram(String labelId, short[] values, int bins, double barScale, ImPlotRange range) {
/* 14224 */     return nPlotHistogram(labelId, values, bins, barScale, range.min, range.max);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static double plotHistogram(String labelId, short[] values, int bins, double barScale, double rangeMin, double rangeMax) {
/* 14233 */     return nPlotHistogram(labelId, values, bins, barScale, rangeMin, rangeMax);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static double plotHistogram(String labelId, short[] values, int bins, double barScale, ImPlotRange range, int flags) {
/* 14242 */     return nPlotHistogram(labelId, values, bins, barScale, range.min, range.max, flags);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static double plotHistogram(String labelId, short[] values, int bins, double barScale, double rangeMin, double rangeMax, int flags) {
/* 14251 */     return nPlotHistogram(labelId, values, bins, barScale, rangeMin, rangeMax, flags);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static double plotHistogram(String labelId, short[] values, double barScale, ImPlotRange range, int flags) {
/* 14260 */     return nPlotHistogram(labelId, values, barScale, range.min, range.max, flags);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static double plotHistogram(String labelId, short[] values, double barScale, double rangeMin, double rangeMax, int flags) {
/* 14269 */     return nPlotHistogram(labelId, values, barScale, rangeMin, rangeMax, flags);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static double plotHistogram(String labelId, short[] values, int bins, double barScale, int flags) {
/* 14278 */     return nPlotHistogram(labelId, values, bins, barScale, flags);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   private static native double nPlotHistogram(String paramString, short[] paramArrayOfshort);
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   private static native double nPlotHistogram(String paramString, short[] paramArrayOfshort, int paramInt);
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   private static native double nPlotHistogram(String paramString, short[] paramArrayOfshort, int paramInt, double paramDouble);
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   private static native double nPlotHistogram(String paramString, short[] paramArrayOfshort, int paramInt, double paramDouble1, double paramDouble2, double paramDouble3);
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   private static native double nPlotHistogram(String paramString, short[] paramArrayOfshort, int paramInt1, double paramDouble1, double paramDouble2, double paramDouble3, int paramInt2);
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   private static native double nPlotHistogram(String paramString, short[] paramArrayOfshort, double paramDouble1, double paramDouble2, double paramDouble3, int paramInt);
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   private static native double nPlotHistogram(String paramString, short[] paramArrayOfshort, int paramInt1, double paramDouble, int paramInt2);
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static double plotHistogram(String labelId, int[] values) {
/* 14350 */     return nPlotHistogram(labelId, values);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static double plotHistogram(String labelId, int[] values, int bins) {
/* 14359 */     return nPlotHistogram(labelId, values, bins);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static double plotHistogram(String labelId, int[] values, int bins, double barScale) {
/* 14368 */     return nPlotHistogram(labelId, values, bins, barScale);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static double plotHistogram(String labelId, int[] values, int bins, double barScale, ImPlotRange range) {
/* 14377 */     return nPlotHistogram(labelId, values, bins, barScale, range.min, range.max);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static double plotHistogram(String labelId, int[] values, int bins, double barScale, double rangeMin, double rangeMax) {
/* 14386 */     return nPlotHistogram(labelId, values, bins, barScale, rangeMin, rangeMax);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static double plotHistogram(String labelId, int[] values, int bins, double barScale, ImPlotRange range, int flags) {
/* 14395 */     return nPlotHistogram(labelId, values, bins, barScale, range.min, range.max, flags);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static double plotHistogram(String labelId, int[] values, int bins, double barScale, double rangeMin, double rangeMax, int flags) {
/* 14404 */     return nPlotHistogram(labelId, values, bins, barScale, rangeMin, rangeMax, flags);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static double plotHistogram(String labelId, int[] values, double barScale, ImPlotRange range, int flags) {
/* 14413 */     return nPlotHistogram(labelId, values, barScale, range.min, range.max, flags);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static double plotHistogram(String labelId, int[] values, double barScale, double rangeMin, double rangeMax, int flags) {
/* 14422 */     return nPlotHistogram(labelId, values, barScale, rangeMin, rangeMax, flags);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static double plotHistogram(String labelId, int[] values, int bins, double barScale, int flags) {
/* 14431 */     return nPlotHistogram(labelId, values, bins, barScale, flags);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   private static native double nPlotHistogram(String paramString, int[] paramArrayOfint);
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   private static native double nPlotHistogram(String paramString, int[] paramArrayOfint, int paramInt);
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   private static native double nPlotHistogram(String paramString, int[] paramArrayOfint, int paramInt, double paramDouble);
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   private static native double nPlotHistogram(String paramString, int[] paramArrayOfint, int paramInt, double paramDouble1, double paramDouble2, double paramDouble3);
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   private static native double nPlotHistogram(String paramString, int[] paramArrayOfint, int paramInt1, double paramDouble1, double paramDouble2, double paramDouble3, int paramInt2);
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   private static native double nPlotHistogram(String paramString, int[] paramArrayOfint, double paramDouble1, double paramDouble2, double paramDouble3, int paramInt);
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   private static native double nPlotHistogram(String paramString, int[] paramArrayOfint, int paramInt1, double paramDouble, int paramInt2);
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static double plotHistogram(String labelId, long[] values) {
/* 14503 */     return nPlotHistogram(labelId, values);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static double plotHistogram(String labelId, long[] values, int bins) {
/* 14512 */     return nPlotHistogram(labelId, values, bins);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static double plotHistogram(String labelId, long[] values, int bins, double barScale) {
/* 14521 */     return nPlotHistogram(labelId, values, bins, barScale);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static double plotHistogram(String labelId, long[] values, int bins, double barScale, ImPlotRange range) {
/* 14530 */     return nPlotHistogram(labelId, values, bins, barScale, range.min, range.max);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static double plotHistogram(String labelId, long[] values, int bins, double barScale, double rangeMin, double rangeMax) {
/* 14539 */     return nPlotHistogram(labelId, values, bins, barScale, rangeMin, rangeMax);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static double plotHistogram(String labelId, long[] values, int bins, double barScale, ImPlotRange range, int flags) {
/* 14548 */     return nPlotHistogram(labelId, values, bins, barScale, range.min, range.max, flags);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static double plotHistogram(String labelId, long[] values, int bins, double barScale, double rangeMin, double rangeMax, int flags) {
/* 14557 */     return nPlotHistogram(labelId, values, bins, barScale, rangeMin, rangeMax, flags);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static double plotHistogram(String labelId, long[] values, double barScale, ImPlotRange range, int flags) {
/* 14566 */     return nPlotHistogram(labelId, values, barScale, range.min, range.max, flags);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static double plotHistogram(String labelId, long[] values, double barScale, double rangeMin, double rangeMax, int flags) {
/* 14575 */     return nPlotHistogram(labelId, values, barScale, rangeMin, rangeMax, flags);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static double plotHistogram(String labelId, long[] values, int bins, double barScale, int flags) {
/* 14584 */     return nPlotHistogram(labelId, values, bins, barScale, flags);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   private static native double nPlotHistogram(String paramString, long[] paramArrayOflong);
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   private static native double nPlotHistogram(String paramString, long[] paramArrayOflong, int paramInt);
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   private static native double nPlotHistogram(String paramString, long[] paramArrayOflong, int paramInt, double paramDouble);
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   private static native double nPlotHistogram(String paramString, long[] paramArrayOflong, int paramInt, double paramDouble1, double paramDouble2, double paramDouble3);
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   private static native double nPlotHistogram(String paramString, long[] paramArrayOflong, int paramInt1, double paramDouble1, double paramDouble2, double paramDouble3, int paramInt2);
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   private static native double nPlotHistogram(String paramString, long[] paramArrayOflong, double paramDouble1, double paramDouble2, double paramDouble3, int paramInt);
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   private static native double nPlotHistogram(String paramString, long[] paramArrayOflong, int paramInt1, double paramDouble, int paramInt2);
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static double plotHistogram(String labelId, float[] values) {
/* 14656 */     return nPlotHistogram(labelId, values);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static double plotHistogram(String labelId, float[] values, int bins) {
/* 14665 */     return nPlotHistogram(labelId, values, bins);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static double plotHistogram(String labelId, float[] values, int bins, double barScale) {
/* 14674 */     return nPlotHistogram(labelId, values, bins, barScale);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static double plotHistogram(String labelId, float[] values, int bins, double barScale, ImPlotRange range) {
/* 14683 */     return nPlotHistogram(labelId, values, bins, barScale, range.min, range.max);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static double plotHistogram(String labelId, float[] values, int bins, double barScale, double rangeMin, double rangeMax) {
/* 14692 */     return nPlotHistogram(labelId, values, bins, barScale, rangeMin, rangeMax);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static double plotHistogram(String labelId, float[] values, int bins, double barScale, ImPlotRange range, int flags) {
/* 14701 */     return nPlotHistogram(labelId, values, bins, barScale, range.min, range.max, flags);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static double plotHistogram(String labelId, float[] values, int bins, double barScale, double rangeMin, double rangeMax, int flags) {
/* 14710 */     return nPlotHistogram(labelId, values, bins, barScale, rangeMin, rangeMax, flags);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static double plotHistogram(String labelId, float[] values, double barScale, ImPlotRange range, int flags) {
/* 14719 */     return nPlotHistogram(labelId, values, barScale, range.min, range.max, flags);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static double plotHistogram(String labelId, float[] values, double barScale, double rangeMin, double rangeMax, int flags) {
/* 14728 */     return nPlotHistogram(labelId, values, barScale, rangeMin, rangeMax, flags);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static double plotHistogram(String labelId, float[] values, int bins, double barScale, int flags) {
/* 14737 */     return nPlotHistogram(labelId, values, bins, barScale, flags);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   private static native double nPlotHistogram(String paramString, float[] paramArrayOffloat);
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   private static native double nPlotHistogram(String paramString, float[] paramArrayOffloat, int paramInt);
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   private static native double nPlotHistogram(String paramString, float[] paramArrayOffloat, int paramInt, double paramDouble);
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   private static native double nPlotHistogram(String paramString, float[] paramArrayOffloat, int paramInt, double paramDouble1, double paramDouble2, double paramDouble3);
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   private static native double nPlotHistogram(String paramString, float[] paramArrayOffloat, int paramInt1, double paramDouble1, double paramDouble2, double paramDouble3, int paramInt2);
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   private static native double nPlotHistogram(String paramString, float[] paramArrayOffloat, double paramDouble1, double paramDouble2, double paramDouble3, int paramInt);
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   private static native double nPlotHistogram(String paramString, float[] paramArrayOffloat, int paramInt1, double paramDouble, int paramInt2);
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static double plotHistogram(String labelId, double[] values) {
/* 14809 */     return nPlotHistogram(labelId, values);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static double plotHistogram(String labelId, double[] values, int bins) {
/* 14818 */     return nPlotHistogram(labelId, values, bins);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static double plotHistogram(String labelId, double[] values, int bins, double barScale) {
/* 14827 */     return nPlotHistogram(labelId, values, bins, barScale);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static double plotHistogram(String labelId, double[] values, int bins, double barScale, ImPlotRange range) {
/* 14836 */     return nPlotHistogram(labelId, values, bins, barScale, range.min, range.max);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static double plotHistogram(String labelId, double[] values, int bins, double barScale, double rangeMin, double rangeMax) {
/* 14845 */     return nPlotHistogram(labelId, values, bins, barScale, rangeMin, rangeMax);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static double plotHistogram(String labelId, double[] values, int bins, double barScale, ImPlotRange range, int flags) {
/* 14854 */     return nPlotHistogram(labelId, values, bins, barScale, range.min, range.max, flags);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static double plotHistogram(String labelId, double[] values, int bins, double barScale, double rangeMin, double rangeMax, int flags) {
/* 14863 */     return nPlotHistogram(labelId, values, bins, barScale, rangeMin, rangeMax, flags);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static double plotHistogram(String labelId, double[] values, double barScale, ImPlotRange range, int flags) {
/* 14872 */     return nPlotHistogram(labelId, values, barScale, range.min, range.max, flags);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static double plotHistogram(String labelId, double[] values, double barScale, double rangeMin, double rangeMax, int flags) {
/* 14881 */     return nPlotHistogram(labelId, values, barScale, rangeMin, rangeMax, flags);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static double plotHistogram(String labelId, double[] values, int bins, double barScale, int flags) {
/* 14890 */     return nPlotHistogram(labelId, values, bins, barScale, flags);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   private static native double nPlotHistogram(String paramString, double[] paramArrayOfdouble);
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   private static native double nPlotHistogram(String paramString, double[] paramArrayOfdouble, int paramInt);
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   private static native double nPlotHistogram(String paramString, double[] paramArrayOfdouble, int paramInt, double paramDouble);
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   private static native double nPlotHistogram(String paramString, double[] paramArrayOfdouble, int paramInt, double paramDouble1, double paramDouble2, double paramDouble3);
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   private static native double nPlotHistogram(String paramString, double[] paramArrayOfdouble, int paramInt1, double paramDouble1, double paramDouble2, double paramDouble3, int paramInt2);
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   private static native double nPlotHistogram(String paramString, double[] paramArrayOfdouble, double paramDouble1, double paramDouble2, double paramDouble3, int paramInt);
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   private static native double nPlotHistogram(String paramString, double[] paramArrayOfdouble, int paramInt1, double paramDouble, int paramInt2);
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static double plotHistogramV(String labelId, short[] values, int count) {
/* 14962 */     return nPlotHistogramV(labelId, values, count);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static double plotHistogramV(String labelId, short[] values, int count, int bins) {
/* 14971 */     return nPlotHistogramV(labelId, values, count, bins);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static double plotHistogramV(String labelId, short[] values, int count, int bins, double barScale) {
/* 14980 */     return nPlotHistogramV(labelId, values, count, bins, barScale);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static double plotHistogramV(String labelId, short[] values, int count, int bins, double barScale, ImPlotRange range) {
/* 14989 */     return nPlotHistogramV(labelId, values, count, bins, barScale, range.min, range.max);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static double plotHistogramV(String labelId, short[] values, int count, int bins, double barScale, double rangeMin, double rangeMax) {
/* 14998 */     return nPlotHistogramV(labelId, values, count, bins, barScale, rangeMin, rangeMax);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static double plotHistogramV(String labelId, short[] values, int count, int bins, double barScale, ImPlotRange range, int flags) {
/* 15007 */     return nPlotHistogramV(labelId, values, count, bins, barScale, range.min, range.max, flags);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static double plotHistogramV(String labelId, short[] values, int count, int bins, double barScale, double rangeMin, double rangeMax, int flags) {
/* 15016 */     return nPlotHistogramV(labelId, values, count, bins, barScale, rangeMin, rangeMax, flags);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static double plotHistogramV(String labelId, short[] values, int count, int bins, double barScale, int flags) {
/* 15025 */     return nPlotHistogramV(labelId, values, count, bins, barScale, flags);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   private static native double nPlotHistogramV(String paramString, short[] paramArrayOfshort, int paramInt);
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   private static native double nPlotHistogramV(String paramString, short[] paramArrayOfshort, int paramInt1, int paramInt2);
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   private static native double nPlotHistogramV(String paramString, short[] paramArrayOfshort, int paramInt1, int paramInt2, double paramDouble);
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   private static native double nPlotHistogramV(String paramString, short[] paramArrayOfshort, int paramInt1, int paramInt2, double paramDouble1, double paramDouble2, double paramDouble3);
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   private static native double nPlotHistogramV(String paramString, short[] paramArrayOfshort, int paramInt1, int paramInt2, double paramDouble1, double paramDouble2, double paramDouble3, int paramInt3);
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   private static native double nPlotHistogramV(String paramString, short[] paramArrayOfshort, int paramInt1, int paramInt2, double paramDouble, int paramInt3);
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static double plotHistogramV(String labelId, int[] values, int count) {
/* 15088 */     return nPlotHistogramV(labelId, values, count);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static double plotHistogramV(String labelId, int[] values, int count, int bins) {
/* 15097 */     return nPlotHistogramV(labelId, values, count, bins);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static double plotHistogramV(String labelId, int[] values, int count, int bins, double barScale) {
/* 15106 */     return nPlotHistogramV(labelId, values, count, bins, barScale);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static double plotHistogramV(String labelId, int[] values, int count, int bins, double barScale, ImPlotRange range) {
/* 15115 */     return nPlotHistogramV(labelId, values, count, bins, barScale, range.min, range.max);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static double plotHistogramV(String labelId, int[] values, int count, int bins, double barScale, double rangeMin, double rangeMax) {
/* 15124 */     return nPlotHistogramV(labelId, values, count, bins, barScale, rangeMin, rangeMax);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static double plotHistogramV(String labelId, int[] values, int count, int bins, double barScale, ImPlotRange range, int flags) {
/* 15133 */     return nPlotHistogramV(labelId, values, count, bins, barScale, range.min, range.max, flags);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static double plotHistogramV(String labelId, int[] values, int count, int bins, double barScale, double rangeMin, double rangeMax, int flags) {
/* 15142 */     return nPlotHistogramV(labelId, values, count, bins, barScale, rangeMin, rangeMax, flags);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static double plotHistogramV(String labelId, int[] values, int count, int bins, double barScale, int flags) {
/* 15151 */     return nPlotHistogramV(labelId, values, count, bins, barScale, flags);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   private static native double nPlotHistogramV(String paramString, int[] paramArrayOfint, int paramInt);
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   private static native double nPlotHistogramV(String paramString, int[] paramArrayOfint, int paramInt1, int paramInt2);
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   private static native double nPlotHistogramV(String paramString, int[] paramArrayOfint, int paramInt1, int paramInt2, double paramDouble);
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   private static native double nPlotHistogramV(String paramString, int[] paramArrayOfint, int paramInt1, int paramInt2, double paramDouble1, double paramDouble2, double paramDouble3);
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   private static native double nPlotHistogramV(String paramString, int[] paramArrayOfint, int paramInt1, int paramInt2, double paramDouble1, double paramDouble2, double paramDouble3, int paramInt3);
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   private static native double nPlotHistogramV(String paramString, int[] paramArrayOfint, int paramInt1, int paramInt2, double paramDouble, int paramInt3);
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static double plotHistogramV(String labelId, long[] values, int count) {
/* 15214 */     return nPlotHistogramV(labelId, values, count);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static double plotHistogramV(String labelId, long[] values, int count, int bins) {
/* 15223 */     return nPlotHistogramV(labelId, values, count, bins);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static double plotHistogramV(String labelId, long[] values, int count, int bins, double barScale) {
/* 15232 */     return nPlotHistogramV(labelId, values, count, bins, barScale);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static double plotHistogramV(String labelId, long[] values, int count, int bins, double barScale, ImPlotRange range) {
/* 15241 */     return nPlotHistogramV(labelId, values, count, bins, barScale, range.min, range.max);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static double plotHistogramV(String labelId, long[] values, int count, int bins, double barScale, double rangeMin, double rangeMax) {
/* 15250 */     return nPlotHistogramV(labelId, values, count, bins, barScale, rangeMin, rangeMax);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static double plotHistogramV(String labelId, long[] values, int count, int bins, double barScale, ImPlotRange range, int flags) {
/* 15259 */     return nPlotHistogramV(labelId, values, count, bins, barScale, range.min, range.max, flags);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static double plotHistogramV(String labelId, long[] values, int count, int bins, double barScale, double rangeMin, double rangeMax, int flags) {
/* 15268 */     return nPlotHistogramV(labelId, values, count, bins, barScale, rangeMin, rangeMax, flags);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static double plotHistogramV(String labelId, long[] values, int count, int bins, double barScale, int flags) {
/* 15277 */     return nPlotHistogramV(labelId, values, count, bins, barScale, flags);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   private static native double nPlotHistogramV(String paramString, long[] paramArrayOflong, int paramInt);
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   private static native double nPlotHistogramV(String paramString, long[] paramArrayOflong, int paramInt1, int paramInt2);
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   private static native double nPlotHistogramV(String paramString, long[] paramArrayOflong, int paramInt1, int paramInt2, double paramDouble);
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   private static native double nPlotHistogramV(String paramString, long[] paramArrayOflong, int paramInt1, int paramInt2, double paramDouble1, double paramDouble2, double paramDouble3);
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   private static native double nPlotHistogramV(String paramString, long[] paramArrayOflong, int paramInt1, int paramInt2, double paramDouble1, double paramDouble2, double paramDouble3, int paramInt3);
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   private static native double nPlotHistogramV(String paramString, long[] paramArrayOflong, int paramInt1, int paramInt2, double paramDouble, int paramInt3);
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static double plotHistogramV(String labelId, float[] values, int count) {
/* 15340 */     return nPlotHistogramV(labelId, values, count);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static double plotHistogramV(String labelId, float[] values, int count, int bins) {
/* 15349 */     return nPlotHistogramV(labelId, values, count, bins);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static double plotHistogramV(String labelId, float[] values, int count, int bins, double barScale) {
/* 15358 */     return nPlotHistogramV(labelId, values, count, bins, barScale);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static double plotHistogramV(String labelId, float[] values, int count, int bins, double barScale, ImPlotRange range) {
/* 15367 */     return nPlotHistogramV(labelId, values, count, bins, barScale, range.min, range.max);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static double plotHistogramV(String labelId, float[] values, int count, int bins, double barScale, double rangeMin, double rangeMax) {
/* 15376 */     return nPlotHistogramV(labelId, values, count, bins, barScale, rangeMin, rangeMax);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static double plotHistogramV(String labelId, float[] values, int count, int bins, double barScale, ImPlotRange range, int flags) {
/* 15385 */     return nPlotHistogramV(labelId, values, count, bins, barScale, range.min, range.max, flags);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static double plotHistogramV(String labelId, float[] values, int count, int bins, double barScale, double rangeMin, double rangeMax, int flags) {
/* 15394 */     return nPlotHistogramV(labelId, values, count, bins, barScale, rangeMin, rangeMax, flags);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static double plotHistogramV(String labelId, float[] values, int count, int bins, double barScale, int flags) {
/* 15403 */     return nPlotHistogramV(labelId, values, count, bins, barScale, flags);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   private static native double nPlotHistogramV(String paramString, float[] paramArrayOffloat, int paramInt);
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   private static native double nPlotHistogramV(String paramString, float[] paramArrayOffloat, int paramInt1, int paramInt2);
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   private static native double nPlotHistogramV(String paramString, float[] paramArrayOffloat, int paramInt1, int paramInt2, double paramDouble);
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   private static native double nPlotHistogramV(String paramString, float[] paramArrayOffloat, int paramInt1, int paramInt2, double paramDouble1, double paramDouble2, double paramDouble3);
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   private static native double nPlotHistogramV(String paramString, float[] paramArrayOffloat, int paramInt1, int paramInt2, double paramDouble1, double paramDouble2, double paramDouble3, int paramInt3);
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   private static native double nPlotHistogramV(String paramString, float[] paramArrayOffloat, int paramInt1, int paramInt2, double paramDouble, int paramInt3);
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static double plotHistogramV(String labelId, double[] values, int count) {
/* 15466 */     return nPlotHistogramV(labelId, values, count);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static double plotHistogramV(String labelId, double[] values, int count, int bins) {
/* 15475 */     return nPlotHistogramV(labelId, values, count, bins);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static double plotHistogramV(String labelId, double[] values, int count, int bins, double barScale) {
/* 15484 */     return nPlotHistogramV(labelId, values, count, bins, barScale);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static double plotHistogramV(String labelId, double[] values, int count, int bins, double barScale, ImPlotRange range) {
/* 15493 */     return nPlotHistogramV(labelId, values, count, bins, barScale, range.min, range.max);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static double plotHistogramV(String labelId, double[] values, int count, int bins, double barScale, double rangeMin, double rangeMax) {
/* 15502 */     return nPlotHistogramV(labelId, values, count, bins, barScale, rangeMin, rangeMax);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static double plotHistogramV(String labelId, double[] values, int count, int bins, double barScale, ImPlotRange range, int flags) {
/* 15511 */     return nPlotHistogramV(labelId, values, count, bins, barScale, range.min, range.max, flags);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static double plotHistogramV(String labelId, double[] values, int count, int bins, double barScale, double rangeMin, double rangeMax, int flags) {
/* 15520 */     return nPlotHistogramV(labelId, values, count, bins, barScale, rangeMin, rangeMax, flags);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static double plotHistogramV(String labelId, double[] values, int count, int bins, double barScale, int flags) {
/* 15529 */     return nPlotHistogramV(labelId, values, count, bins, barScale, flags);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   private static native double nPlotHistogramV(String paramString, double[] paramArrayOfdouble, int paramInt);
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   private static native double nPlotHistogramV(String paramString, double[] paramArrayOfdouble, int paramInt1, int paramInt2);
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   private static native double nPlotHistogramV(String paramString, double[] paramArrayOfdouble, int paramInt1, int paramInt2, double paramDouble);
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   private static native double nPlotHistogramV(String paramString, double[] paramArrayOfdouble, int paramInt1, int paramInt2, double paramDouble1, double paramDouble2, double paramDouble3);
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   private static native double nPlotHistogramV(String paramString, double[] paramArrayOfdouble, int paramInt1, int paramInt2, double paramDouble1, double paramDouble2, double paramDouble3, int paramInt3);
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   private static native double nPlotHistogramV(String paramString, double[] paramArrayOfdouble, int paramInt1, int paramInt2, double paramDouble, int paramInt3);
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static double plotHistogram2D(String labelId, short[] xs, short[] ys) {
/* 15592 */     return nPlotHistogram2D(labelId, xs, ys);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static double plotHistogram2D(String labelId, short[] xs, short[] ys, int xBins) {
/* 15601 */     return nPlotHistogram2D(labelId, xs, ys, xBins);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static double plotHistogram2D(String labelId, short[] xs, short[] ys, int xBins, int yBins) {
/* 15610 */     return nPlotHistogram2D(labelId, xs, ys, xBins, yBins);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static double plotHistogram2D(String labelId, short[] xs, short[] ys, int xBins, int yBins, ImPlotRect range) {
/* 15619 */     return nPlotHistogram2D(labelId, xs, ys, xBins, yBins, range.x.min, range.y.min, range.x.max, range.y.max);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static double plotHistogram2D(String labelId, short[] xs, short[] ys, int xBins, int yBins, double rangeMinX, double rangeMinY, double rangeMaxX, double rangeMaxY) {
/* 15628 */     return nPlotHistogram2D(labelId, xs, ys, xBins, yBins, rangeMinX, rangeMinY, rangeMaxX, rangeMaxY);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static double plotHistogram2D(String labelId, short[] xs, short[] ys, int xBins, int yBins, ImPlotRect range, int flags) {
/* 15637 */     return nPlotHistogram2D(labelId, xs, ys, xBins, yBins, range.x.min, range.y.min, range.x.max, range.y.max, flags);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static double plotHistogram2D(String labelId, short[] xs, short[] ys, int xBins, int yBins, double rangeMinX, double rangeMinY, double rangeMaxX, double rangeMaxY, int flags) {
/* 15646 */     return nPlotHistogram2D(labelId, xs, ys, xBins, yBins, rangeMinX, rangeMinY, rangeMaxX, rangeMaxY, flags);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static double plotHistogram2D(String labelId, short[] xs, short[] ys, int xBins, int yBins, int flags) {
/* 15655 */     return nPlotHistogram2D(labelId, xs, ys, xBins, yBins, flags);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   private static native double nPlotHistogram2D(String paramString, short[] paramArrayOfshort1, short[] paramArrayOfshort2);
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   private static native double nPlotHistogram2D(String paramString, short[] paramArrayOfshort1, short[] paramArrayOfshort2, int paramInt);
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   private static native double nPlotHistogram2D(String paramString, short[] paramArrayOfshort1, short[] paramArrayOfshort2, int paramInt1, int paramInt2);
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   private static native double nPlotHistogram2D(String paramString, short[] paramArrayOfshort1, short[] paramArrayOfshort2, int paramInt1, int paramInt2, double paramDouble1, double paramDouble2, double paramDouble3, double paramDouble4);
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   private static native double nPlotHistogram2D(String paramString, short[] paramArrayOfshort1, short[] paramArrayOfshort2, int paramInt1, int paramInt2, double paramDouble1, double paramDouble2, double paramDouble3, double paramDouble4, int paramInt3);
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   private static native double nPlotHistogram2D(String paramString, short[] paramArrayOfshort1, short[] paramArrayOfshort2, int paramInt1, int paramInt2, int paramInt3);
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static double plotHistogram2D(String labelId, int[] xs, int[] ys) {
/* 15730 */     return nPlotHistogram2D(labelId, xs, ys);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static double plotHistogram2D(String labelId, int[] xs, int[] ys, int xBins) {
/* 15739 */     return nPlotHistogram2D(labelId, xs, ys, xBins);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static double plotHistogram2D(String labelId, int[] xs, int[] ys, int xBins, int yBins) {
/* 15748 */     return nPlotHistogram2D(labelId, xs, ys, xBins, yBins);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static double plotHistogram2D(String labelId, int[] xs, int[] ys, int xBins, int yBins, ImPlotRect range) {
/* 15757 */     return nPlotHistogram2D(labelId, xs, ys, xBins, yBins, range.x.min, range.y.min, range.x.max, range.y.max);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static double plotHistogram2D(String labelId, int[] xs, int[] ys, int xBins, int yBins, double rangeMinX, double rangeMinY, double rangeMaxX, double rangeMaxY) {
/* 15766 */     return nPlotHistogram2D(labelId, xs, ys, xBins, yBins, rangeMinX, rangeMinY, rangeMaxX, rangeMaxY);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static double plotHistogram2D(String labelId, int[] xs, int[] ys, int xBins, int yBins, ImPlotRect range, int flags) {
/* 15775 */     return nPlotHistogram2D(labelId, xs, ys, xBins, yBins, range.x.min, range.y.min, range.x.max, range.y.max, flags);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static double plotHistogram2D(String labelId, int[] xs, int[] ys, int xBins, int yBins, double rangeMinX, double rangeMinY, double rangeMaxX, double rangeMaxY, int flags) {
/* 15784 */     return nPlotHistogram2D(labelId, xs, ys, xBins, yBins, rangeMinX, rangeMinY, rangeMaxX, rangeMaxY, flags);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static double plotHistogram2D(String labelId, int[] xs, int[] ys, int xBins, int yBins, int flags) {
/* 15793 */     return nPlotHistogram2D(labelId, xs, ys, xBins, yBins, flags);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   private static native double nPlotHistogram2D(String paramString, int[] paramArrayOfint1, int[] paramArrayOfint2);
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   private static native double nPlotHistogram2D(String paramString, int[] paramArrayOfint1, int[] paramArrayOfint2, int paramInt);
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   private static native double nPlotHistogram2D(String paramString, int[] paramArrayOfint1, int[] paramArrayOfint2, int paramInt1, int paramInt2);
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   private static native double nPlotHistogram2D(String paramString, int[] paramArrayOfint1, int[] paramArrayOfint2, int paramInt1, int paramInt2, double paramDouble1, double paramDouble2, double paramDouble3, double paramDouble4);
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   private static native double nPlotHistogram2D(String paramString, int[] paramArrayOfint1, int[] paramArrayOfint2, int paramInt1, int paramInt2, double paramDouble1, double paramDouble2, double paramDouble3, double paramDouble4, int paramInt3);
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   private static native double nPlotHistogram2D(String paramString, int[] paramArrayOfint1, int[] paramArrayOfint2, int paramInt1, int paramInt2, int paramInt3);
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static double plotHistogram2D(String labelId, long[] xs, long[] ys) {
/* 15868 */     return nPlotHistogram2D(labelId, xs, ys);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static double plotHistogram2D(String labelId, long[] xs, long[] ys, int xBins) {
/* 15877 */     return nPlotHistogram2D(labelId, xs, ys, xBins);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static double plotHistogram2D(String labelId, long[] xs, long[] ys, int xBins, int yBins) {
/* 15886 */     return nPlotHistogram2D(labelId, xs, ys, xBins, yBins);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static double plotHistogram2D(String labelId, long[] xs, long[] ys, int xBins, int yBins, ImPlotRect range) {
/* 15895 */     return nPlotHistogram2D(labelId, xs, ys, xBins, yBins, range.x.min, range.y.min, range.x.max, range.y.max);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static double plotHistogram2D(String labelId, long[] xs, long[] ys, int xBins, int yBins, double rangeMinX, double rangeMinY, double rangeMaxX, double rangeMaxY) {
/* 15904 */     return nPlotHistogram2D(labelId, xs, ys, xBins, yBins, rangeMinX, rangeMinY, rangeMaxX, rangeMaxY);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static double plotHistogram2D(String labelId, long[] xs, long[] ys, int xBins, int yBins, ImPlotRect range, int flags) {
/* 15913 */     return nPlotHistogram2D(labelId, xs, ys, xBins, yBins, range.x.min, range.y.min, range.x.max, range.y.max, flags);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static double plotHistogram2D(String labelId, long[] xs, long[] ys, int xBins, int yBins, double rangeMinX, double rangeMinY, double rangeMaxX, double rangeMaxY, int flags) {
/* 15922 */     return nPlotHistogram2D(labelId, xs, ys, xBins, yBins, rangeMinX, rangeMinY, rangeMaxX, rangeMaxY, flags);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static double plotHistogram2D(String labelId, long[] xs, long[] ys, int xBins, int yBins, int flags) {
/* 15931 */     return nPlotHistogram2D(labelId, xs, ys, xBins, yBins, flags);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   private static native double nPlotHistogram2D(String paramString, long[] paramArrayOflong1, long[] paramArrayOflong2);
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   private static native double nPlotHistogram2D(String paramString, long[] paramArrayOflong1, long[] paramArrayOflong2, int paramInt);
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   private static native double nPlotHistogram2D(String paramString, long[] paramArrayOflong1, long[] paramArrayOflong2, int paramInt1, int paramInt2);
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   private static native double nPlotHistogram2D(String paramString, long[] paramArrayOflong1, long[] paramArrayOflong2, int paramInt1, int paramInt2, double paramDouble1, double paramDouble2, double paramDouble3, double paramDouble4);
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   private static native double nPlotHistogram2D(String paramString, long[] paramArrayOflong1, long[] paramArrayOflong2, int paramInt1, int paramInt2, double paramDouble1, double paramDouble2, double paramDouble3, double paramDouble4, int paramInt3);
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   private static native double nPlotHistogram2D(String paramString, long[] paramArrayOflong1, long[] paramArrayOflong2, int paramInt1, int paramInt2, int paramInt3);
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static double plotHistogram2D(String labelId, float[] xs, float[] ys) {
/* 16006 */     return nPlotHistogram2D(labelId, xs, ys);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static double plotHistogram2D(String labelId, float[] xs, float[] ys, int xBins) {
/* 16015 */     return nPlotHistogram2D(labelId, xs, ys, xBins);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static double plotHistogram2D(String labelId, float[] xs, float[] ys, int xBins, int yBins) {
/* 16024 */     return nPlotHistogram2D(labelId, xs, ys, xBins, yBins);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static double plotHistogram2D(String labelId, float[] xs, float[] ys, int xBins, int yBins, ImPlotRect range) {
/* 16033 */     return nPlotHistogram2D(labelId, xs, ys, xBins, yBins, range.x.min, range.y.min, range.x.max, range.y.max);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static double plotHistogram2D(String labelId, float[] xs, float[] ys, int xBins, int yBins, double rangeMinX, double rangeMinY, double rangeMaxX, double rangeMaxY) {
/* 16042 */     return nPlotHistogram2D(labelId, xs, ys, xBins, yBins, rangeMinX, rangeMinY, rangeMaxX, rangeMaxY);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static double plotHistogram2D(String labelId, float[] xs, float[] ys, int xBins, int yBins, ImPlotRect range, int flags) {
/* 16051 */     return nPlotHistogram2D(labelId, xs, ys, xBins, yBins, range.x.min, range.y.min, range.x.max, range.y.max, flags);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static double plotHistogram2D(String labelId, float[] xs, float[] ys, int xBins, int yBins, double rangeMinX, double rangeMinY, double rangeMaxX, double rangeMaxY, int flags) {
/* 16060 */     return nPlotHistogram2D(labelId, xs, ys, xBins, yBins, rangeMinX, rangeMinY, rangeMaxX, rangeMaxY, flags);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static double plotHistogram2D(String labelId, float[] xs, float[] ys, int xBins, int yBins, int flags) {
/* 16069 */     return nPlotHistogram2D(labelId, xs, ys, xBins, yBins, flags);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   private static native double nPlotHistogram2D(String paramString, float[] paramArrayOffloat1, float[] paramArrayOffloat2);
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   private static native double nPlotHistogram2D(String paramString, float[] paramArrayOffloat1, float[] paramArrayOffloat2, int paramInt);
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   private static native double nPlotHistogram2D(String paramString, float[] paramArrayOffloat1, float[] paramArrayOffloat2, int paramInt1, int paramInt2);
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   private static native double nPlotHistogram2D(String paramString, float[] paramArrayOffloat1, float[] paramArrayOffloat2, int paramInt1, int paramInt2, double paramDouble1, double paramDouble2, double paramDouble3, double paramDouble4);
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   private static native double nPlotHistogram2D(String paramString, float[] paramArrayOffloat1, float[] paramArrayOffloat2, int paramInt1, int paramInt2, double paramDouble1, double paramDouble2, double paramDouble3, double paramDouble4, int paramInt3);
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   private static native double nPlotHistogram2D(String paramString, float[] paramArrayOffloat1, float[] paramArrayOffloat2, int paramInt1, int paramInt2, int paramInt3);
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static double plotHistogram2D(String labelId, double[] xs, double[] ys) {
/* 16144 */     return nPlotHistogram2D(labelId, xs, ys);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static double plotHistogram2D(String labelId, double[] xs, double[] ys, int xBins) {
/* 16153 */     return nPlotHistogram2D(labelId, xs, ys, xBins);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static double plotHistogram2D(String labelId, double[] xs, double[] ys, int xBins, int yBins) {
/* 16162 */     return nPlotHistogram2D(labelId, xs, ys, xBins, yBins);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static double plotHistogram2D(String labelId, double[] xs, double[] ys, int xBins, int yBins, ImPlotRect range) {
/* 16171 */     return nPlotHistogram2D(labelId, xs, ys, xBins, yBins, range.x.min, range.y.min, range.x.max, range.y.max);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static double plotHistogram2D(String labelId, double[] xs, double[] ys, int xBins, int yBins, double rangeMinX, double rangeMinY, double rangeMaxX, double rangeMaxY) {
/* 16180 */     return nPlotHistogram2D(labelId, xs, ys, xBins, yBins, rangeMinX, rangeMinY, rangeMaxX, rangeMaxY);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static double plotHistogram2D(String labelId, double[] xs, double[] ys, int xBins, int yBins, ImPlotRect range, int flags) {
/* 16189 */     return nPlotHistogram2D(labelId, xs, ys, xBins, yBins, range.x.min, range.y.min, range.x.max, range.y.max, flags);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static double plotHistogram2D(String labelId, double[] xs, double[] ys, int xBins, int yBins, double rangeMinX, double rangeMinY, double rangeMaxX, double rangeMaxY, int flags) {
/* 16198 */     return nPlotHistogram2D(labelId, xs, ys, xBins, yBins, rangeMinX, rangeMinY, rangeMaxX, rangeMaxY, flags);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static double plotHistogram2D(String labelId, double[] xs, double[] ys, int xBins, int yBins, int flags) {
/* 16207 */     return nPlotHistogram2D(labelId, xs, ys, xBins, yBins, flags);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   private static native double nPlotHistogram2D(String paramString, double[] paramArrayOfdouble1, double[] paramArrayOfdouble2);
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   private static native double nPlotHistogram2D(String paramString, double[] paramArrayOfdouble1, double[] paramArrayOfdouble2, int paramInt);
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   private static native double nPlotHistogram2D(String paramString, double[] paramArrayOfdouble1, double[] paramArrayOfdouble2, int paramInt1, int paramInt2);
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   private static native double nPlotHistogram2D(String paramString, double[] paramArrayOfdouble1, double[] paramArrayOfdouble2, int paramInt1, int paramInt2, double paramDouble1, double paramDouble2, double paramDouble3, double paramDouble4);
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   private static native double nPlotHistogram2D(String paramString, double[] paramArrayOfdouble1, double[] paramArrayOfdouble2, int paramInt1, int paramInt2, double paramDouble1, double paramDouble2, double paramDouble3, double paramDouble4, int paramInt3);
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   private static native double nPlotHistogram2D(String paramString, double[] paramArrayOfdouble1, double[] paramArrayOfdouble2, int paramInt1, int paramInt2, int paramInt3);
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static double plotHistogram2DV(String labelId, short[] xs, short[] ys, int count) {
/* 16282 */     return nPlotHistogram2DV(labelId, xs, ys, count);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static double plotHistogram2DV(String labelId, short[] xs, short[] ys, int count, int xBins) {
/* 16291 */     return nPlotHistogram2DV(labelId, xs, ys, count, xBins);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static double plotHistogram2DV(String labelId, short[] xs, short[] ys, int count, int xBins, int yBins) {
/* 16300 */     return nPlotHistogram2DV(labelId, xs, ys, count, xBins, yBins);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static double plotHistogram2DV(String labelId, short[] xs, short[] ys, int count, int xBins, int yBins, ImPlotRect range) {
/* 16309 */     return nPlotHistogram2DV(labelId, xs, ys, count, xBins, yBins, range.x.min, range.y.min, range.x.max, range.y.max);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static double plotHistogram2DV(String labelId, short[] xs, short[] ys, int count, int xBins, int yBins, double rangeMinX, double rangeMinY, double rangeMaxX, double rangeMaxY) {
/* 16318 */     return nPlotHistogram2DV(labelId, xs, ys, count, xBins, yBins, rangeMinX, rangeMinY, rangeMaxX, rangeMaxY);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static double plotHistogram2DV(String labelId, short[] xs, short[] ys, int count, int xBins, int yBins, ImPlotRect range, int flags) {
/* 16327 */     return nPlotHistogram2DV(labelId, xs, ys, count, xBins, yBins, range.x.min, range.y.min, range.x.max, range.y.max, flags);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static double plotHistogram2DV(String labelId, short[] xs, short[] ys, int count, int xBins, int yBins, double rangeMinX, double rangeMinY, double rangeMaxX, double rangeMaxY, int flags) {
/* 16336 */     return nPlotHistogram2DV(labelId, xs, ys, count, xBins, yBins, rangeMinX, rangeMinY, rangeMaxX, rangeMaxY, flags);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static double plotHistogram2DV(String labelId, short[] xs, short[] ys, int count, int xBins, int yBins, int flags) {
/* 16345 */     return nPlotHistogram2DV(labelId, xs, ys, count, xBins, yBins, flags);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   private static native double nPlotHistogram2DV(String paramString, short[] paramArrayOfshort1, short[] paramArrayOfshort2, int paramInt);
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   private static native double nPlotHistogram2DV(String paramString, short[] paramArrayOfshort1, short[] paramArrayOfshort2, int paramInt1, int paramInt2);
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   private static native double nPlotHistogram2DV(String paramString, short[] paramArrayOfshort1, short[] paramArrayOfshort2, int paramInt1, int paramInt2, int paramInt3);
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   private static native double nPlotHistogram2DV(String paramString, short[] paramArrayOfshort1, short[] paramArrayOfshort2, int paramInt1, int paramInt2, int paramInt3, double paramDouble1, double paramDouble2, double paramDouble3, double paramDouble4);
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   private static native double nPlotHistogram2DV(String paramString, short[] paramArrayOfshort1, short[] paramArrayOfshort2, int paramInt1, int paramInt2, int paramInt3, double paramDouble1, double paramDouble2, double paramDouble3, double paramDouble4, int paramInt4);
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   private static native double nPlotHistogram2DV(String paramString, short[] paramArrayOfshort1, short[] paramArrayOfshort2, int paramInt1, int paramInt2, int paramInt3, int paramInt4);
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static double plotHistogram2DV(String labelId, int[] xs, int[] ys, int count) {
/* 16420 */     return nPlotHistogram2DV(labelId, xs, ys, count);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static double plotHistogram2DV(String labelId, int[] xs, int[] ys, int count, int xBins) {
/* 16429 */     return nPlotHistogram2DV(labelId, xs, ys, count, xBins);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static double plotHistogram2DV(String labelId, int[] xs, int[] ys, int count, int xBins, int yBins) {
/* 16438 */     return nPlotHistogram2DV(labelId, xs, ys, count, xBins, yBins);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static double plotHistogram2DV(String labelId, int[] xs, int[] ys, int count, int xBins, int yBins, ImPlotRect range) {
/* 16447 */     return nPlotHistogram2DV(labelId, xs, ys, count, xBins, yBins, range.x.min, range.y.min, range.x.max, range.y.max);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static double plotHistogram2DV(String labelId, int[] xs, int[] ys, int count, int xBins, int yBins, double rangeMinX, double rangeMinY, double rangeMaxX, double rangeMaxY) {
/* 16456 */     return nPlotHistogram2DV(labelId, xs, ys, count, xBins, yBins, rangeMinX, rangeMinY, rangeMaxX, rangeMaxY);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static double plotHistogram2DV(String labelId, int[] xs, int[] ys, int count, int xBins, int yBins, ImPlotRect range, int flags) {
/* 16465 */     return nPlotHistogram2DV(labelId, xs, ys, count, xBins, yBins, range.x.min, range.y.min, range.x.max, range.y.max, flags);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static double plotHistogram2DV(String labelId, int[] xs, int[] ys, int count, int xBins, int yBins, double rangeMinX, double rangeMinY, double rangeMaxX, double rangeMaxY, int flags) {
/* 16474 */     return nPlotHistogram2DV(labelId, xs, ys, count, xBins, yBins, rangeMinX, rangeMinY, rangeMaxX, rangeMaxY, flags);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static double plotHistogram2DV(String labelId, int[] xs, int[] ys, int count, int xBins, int yBins, int flags) {
/* 16483 */     return nPlotHistogram2DV(labelId, xs, ys, count, xBins, yBins, flags);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   private static native double nPlotHistogram2DV(String paramString, int[] paramArrayOfint1, int[] paramArrayOfint2, int paramInt);
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   private static native double nPlotHistogram2DV(String paramString, int[] paramArrayOfint1, int[] paramArrayOfint2, int paramInt1, int paramInt2);
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   private static native double nPlotHistogram2DV(String paramString, int[] paramArrayOfint1, int[] paramArrayOfint2, int paramInt1, int paramInt2, int paramInt3);
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   private static native double nPlotHistogram2DV(String paramString, int[] paramArrayOfint1, int[] paramArrayOfint2, int paramInt1, int paramInt2, int paramInt3, double paramDouble1, double paramDouble2, double paramDouble3, double paramDouble4);
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   private static native double nPlotHistogram2DV(String paramString, int[] paramArrayOfint1, int[] paramArrayOfint2, int paramInt1, int paramInt2, int paramInt3, double paramDouble1, double paramDouble2, double paramDouble3, double paramDouble4, int paramInt4);
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   private static native double nPlotHistogram2DV(String paramString, int[] paramArrayOfint1, int[] paramArrayOfint2, int paramInt1, int paramInt2, int paramInt3, int paramInt4);
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static double plotHistogram2DV(String labelId, long[] xs, long[] ys, int count) {
/* 16558 */     return nPlotHistogram2DV(labelId, xs, ys, count);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static double plotHistogram2DV(String labelId, long[] xs, long[] ys, int count, int xBins) {
/* 16567 */     return nPlotHistogram2DV(labelId, xs, ys, count, xBins);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static double plotHistogram2DV(String labelId, long[] xs, long[] ys, int count, int xBins, int yBins) {
/* 16576 */     return nPlotHistogram2DV(labelId, xs, ys, count, xBins, yBins);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static double plotHistogram2DV(String labelId, long[] xs, long[] ys, int count, int xBins, int yBins, ImPlotRect range) {
/* 16585 */     return nPlotHistogram2DV(labelId, xs, ys, count, xBins, yBins, range.x.min, range.y.min, range.x.max, range.y.max);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static double plotHistogram2DV(String labelId, long[] xs, long[] ys, int count, int xBins, int yBins, double rangeMinX, double rangeMinY, double rangeMaxX, double rangeMaxY) {
/* 16594 */     return nPlotHistogram2DV(labelId, xs, ys, count, xBins, yBins, rangeMinX, rangeMinY, rangeMaxX, rangeMaxY);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static double plotHistogram2DV(String labelId, long[] xs, long[] ys, int count, int xBins, int yBins, ImPlotRect range, int flags) {
/* 16603 */     return nPlotHistogram2DV(labelId, xs, ys, count, xBins, yBins, range.x.min, range.y.min, range.x.max, range.y.max, flags);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static double plotHistogram2DV(String labelId, long[] xs, long[] ys, int count, int xBins, int yBins, double rangeMinX, double rangeMinY, double rangeMaxX, double rangeMaxY, int flags) {
/* 16612 */     return nPlotHistogram2DV(labelId, xs, ys, count, xBins, yBins, rangeMinX, rangeMinY, rangeMaxX, rangeMaxY, flags);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static double plotHistogram2DV(String labelId, long[] xs, long[] ys, int count, int xBins, int yBins, int flags) {
/* 16621 */     return nPlotHistogram2DV(labelId, xs, ys, count, xBins, yBins, flags);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   private static native double nPlotHistogram2DV(String paramString, long[] paramArrayOflong1, long[] paramArrayOflong2, int paramInt);
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   private static native double nPlotHistogram2DV(String paramString, long[] paramArrayOflong1, long[] paramArrayOflong2, int paramInt1, int paramInt2);
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   private static native double nPlotHistogram2DV(String paramString, long[] paramArrayOflong1, long[] paramArrayOflong2, int paramInt1, int paramInt2, int paramInt3);
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   private static native double nPlotHistogram2DV(String paramString, long[] paramArrayOflong1, long[] paramArrayOflong2, int paramInt1, int paramInt2, int paramInt3, double paramDouble1, double paramDouble2, double paramDouble3, double paramDouble4);
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   private static native double nPlotHistogram2DV(String paramString, long[] paramArrayOflong1, long[] paramArrayOflong2, int paramInt1, int paramInt2, int paramInt3, double paramDouble1, double paramDouble2, double paramDouble3, double paramDouble4, int paramInt4);
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   private static native double nPlotHistogram2DV(String paramString, long[] paramArrayOflong1, long[] paramArrayOflong2, int paramInt1, int paramInt2, int paramInt3, int paramInt4);
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static double plotHistogram2DV(String labelId, float[] xs, float[] ys, int count) {
/* 16696 */     return nPlotHistogram2DV(labelId, xs, ys, count);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static double plotHistogram2DV(String labelId, float[] xs, float[] ys, int count, int xBins) {
/* 16705 */     return nPlotHistogram2DV(labelId, xs, ys, count, xBins);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static double plotHistogram2DV(String labelId, float[] xs, float[] ys, int count, int xBins, int yBins) {
/* 16714 */     return nPlotHistogram2DV(labelId, xs, ys, count, xBins, yBins);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static double plotHistogram2DV(String labelId, float[] xs, float[] ys, int count, int xBins, int yBins, ImPlotRect range) {
/* 16723 */     return nPlotHistogram2DV(labelId, xs, ys, count, xBins, yBins, range.x.min, range.y.min, range.x.max, range.y.max);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static double plotHistogram2DV(String labelId, float[] xs, float[] ys, int count, int xBins, int yBins, double rangeMinX, double rangeMinY, double rangeMaxX, double rangeMaxY) {
/* 16732 */     return nPlotHistogram2DV(labelId, xs, ys, count, xBins, yBins, rangeMinX, rangeMinY, rangeMaxX, rangeMaxY);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static double plotHistogram2DV(String labelId, float[] xs, float[] ys, int count, int xBins, int yBins, ImPlotRect range, int flags) {
/* 16741 */     return nPlotHistogram2DV(labelId, xs, ys, count, xBins, yBins, range.x.min, range.y.min, range.x.max, range.y.max, flags);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static double plotHistogram2DV(String labelId, float[] xs, float[] ys, int count, int xBins, int yBins, double rangeMinX, double rangeMinY, double rangeMaxX, double rangeMaxY, int flags) {
/* 16750 */     return nPlotHistogram2DV(labelId, xs, ys, count, xBins, yBins, rangeMinX, rangeMinY, rangeMaxX, rangeMaxY, flags);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static double plotHistogram2DV(String labelId, float[] xs, float[] ys, int count, int xBins, int yBins, int flags) {
/* 16759 */     return nPlotHistogram2DV(labelId, xs, ys, count, xBins, yBins, flags);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   private static native double nPlotHistogram2DV(String paramString, float[] paramArrayOffloat1, float[] paramArrayOffloat2, int paramInt);
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   private static native double nPlotHistogram2DV(String paramString, float[] paramArrayOffloat1, float[] paramArrayOffloat2, int paramInt1, int paramInt2);
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   private static native double nPlotHistogram2DV(String paramString, float[] paramArrayOffloat1, float[] paramArrayOffloat2, int paramInt1, int paramInt2, int paramInt3);
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   private static native double nPlotHistogram2DV(String paramString, float[] paramArrayOffloat1, float[] paramArrayOffloat2, int paramInt1, int paramInt2, int paramInt3, double paramDouble1, double paramDouble2, double paramDouble3, double paramDouble4);
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   private static native double nPlotHistogram2DV(String paramString, float[] paramArrayOffloat1, float[] paramArrayOffloat2, int paramInt1, int paramInt2, int paramInt3, double paramDouble1, double paramDouble2, double paramDouble3, double paramDouble4, int paramInt4);
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   private static native double nPlotHistogram2DV(String paramString, float[] paramArrayOffloat1, float[] paramArrayOffloat2, int paramInt1, int paramInt2, int paramInt3, int paramInt4);
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static double plotHistogram2DV(String labelId, double[] xs, double[] ys, int count) {
/* 16834 */     return nPlotHistogram2DV(labelId, xs, ys, count);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static double plotHistogram2DV(String labelId, double[] xs, double[] ys, int count, int xBins) {
/* 16843 */     return nPlotHistogram2DV(labelId, xs, ys, count, xBins);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static double plotHistogram2DV(String labelId, double[] xs, double[] ys, int count, int xBins, int yBins) {
/* 16852 */     return nPlotHistogram2DV(labelId, xs, ys, count, xBins, yBins);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static double plotHistogram2DV(String labelId, double[] xs, double[] ys, int count, int xBins, int yBins, ImPlotRect range) {
/* 16861 */     return nPlotHistogram2DV(labelId, xs, ys, count, xBins, yBins, range.x.min, range.y.min, range.x.max, range.y.max);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static double plotHistogram2DV(String labelId, double[] xs, double[] ys, int count, int xBins, int yBins, double rangeMinX, double rangeMinY, double rangeMaxX, double rangeMaxY) {
/* 16870 */     return nPlotHistogram2DV(labelId, xs, ys, count, xBins, yBins, rangeMinX, rangeMinY, rangeMaxX, rangeMaxY);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static double plotHistogram2DV(String labelId, double[] xs, double[] ys, int count, int xBins, int yBins, ImPlotRect range, int flags) {
/* 16879 */     return nPlotHistogram2DV(labelId, xs, ys, count, xBins, yBins, range.x.min, range.y.min, range.x.max, range.y.max, flags);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static double plotHistogram2DV(String labelId, double[] xs, double[] ys, int count, int xBins, int yBins, double rangeMinX, double rangeMinY, double rangeMaxX, double rangeMaxY, int flags) {
/* 16888 */     return nPlotHistogram2DV(labelId, xs, ys, count, xBins, yBins, rangeMinX, rangeMinY, rangeMaxX, rangeMaxY, flags);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static double plotHistogram2DV(String labelId, double[] xs, double[] ys, int count, int xBins, int yBins, int flags) {
/* 16897 */     return nPlotHistogram2DV(labelId, xs, ys, count, xBins, yBins, flags);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   private static native double nPlotHistogram2DV(String paramString, double[] paramArrayOfdouble1, double[] paramArrayOfdouble2, int paramInt);
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   private static native double nPlotHistogram2DV(String paramString, double[] paramArrayOfdouble1, double[] paramArrayOfdouble2, int paramInt1, int paramInt2);
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   private static native double nPlotHistogram2DV(String paramString, double[] paramArrayOfdouble1, double[] paramArrayOfdouble2, int paramInt1, int paramInt2, int paramInt3);
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   private static native double nPlotHistogram2DV(String paramString, double[] paramArrayOfdouble1, double[] paramArrayOfdouble2, int paramInt1, int paramInt2, int paramInt3, double paramDouble1, double paramDouble2, double paramDouble3, double paramDouble4);
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   private static native double nPlotHistogram2DV(String paramString, double[] paramArrayOfdouble1, double[] paramArrayOfdouble2, int paramInt1, int paramInt2, int paramInt3, double paramDouble1, double paramDouble2, double paramDouble3, double paramDouble4, int paramInt4);
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   private static native double nPlotHistogram2DV(String paramString, double[] paramArrayOfdouble1, double[] paramArrayOfdouble2, int paramInt1, int paramInt2, int paramInt3, int paramInt4);
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static void plotDigital(String labelId, short[] xs, short[] ys) {
/* 16970 */     nPlotDigital(labelId, xs, ys);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static void plotDigital(String labelId, short[] xs, short[] ys, int flags) {
/* 16977 */     nPlotDigital(labelId, xs, ys, flags);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static void plotDigital(String labelId, short[] xs, short[] ys, int flags, int offset) {
/* 16984 */     nPlotDigital(labelId, xs, ys, flags, offset);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   private static native void nPlotDigital(String paramString, short[] paramArrayOfshort1, short[] paramArrayOfshort2);
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   private static native void nPlotDigital(String paramString, short[] paramArrayOfshort1, short[] paramArrayOfshort2, int paramInt);
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   private static native void nPlotDigital(String paramString, short[] paramArrayOfshort1, short[] paramArrayOfshort2, int paramInt1, int paramInt2);
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static void plotDigital(String labelId, int[] xs, int[] ys) {
/* 17021 */     nPlotDigital(labelId, xs, ys);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static void plotDigital(String labelId, int[] xs, int[] ys, int flags) {
/* 17028 */     nPlotDigital(labelId, xs, ys, flags);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static void plotDigital(String labelId, int[] xs, int[] ys, int flags, int offset) {
/* 17035 */     nPlotDigital(labelId, xs, ys, flags, offset);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   private static native void nPlotDigital(String paramString, int[] paramArrayOfint1, int[] paramArrayOfint2);
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   private static native void nPlotDigital(String paramString, int[] paramArrayOfint1, int[] paramArrayOfint2, int paramInt);
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   private static native void nPlotDigital(String paramString, int[] paramArrayOfint1, int[] paramArrayOfint2, int paramInt1, int paramInt2);
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static void plotDigital(String labelId, long[] xs, long[] ys) {
/* 17072 */     nPlotDigital(labelId, xs, ys);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static void plotDigital(String labelId, long[] xs, long[] ys, int flags) {
/* 17079 */     nPlotDigital(labelId, xs, ys, flags);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static void plotDigital(String labelId, long[] xs, long[] ys, int flags, int offset) {
/* 17086 */     nPlotDigital(labelId, xs, ys, flags, offset);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   private static native void nPlotDigital(String paramString, long[] paramArrayOflong1, long[] paramArrayOflong2);
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   private static native void nPlotDigital(String paramString, long[] paramArrayOflong1, long[] paramArrayOflong2, int paramInt);
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   private static native void nPlotDigital(String paramString, long[] paramArrayOflong1, long[] paramArrayOflong2, int paramInt1, int paramInt2);
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static void plotDigital(String labelId, float[] xs, float[] ys) {
/* 17123 */     nPlotDigital(labelId, xs, ys);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static void plotDigital(String labelId, float[] xs, float[] ys, int flags) {
/* 17130 */     nPlotDigital(labelId, xs, ys, flags);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static void plotDigital(String labelId, float[] xs, float[] ys, int flags, int offset) {
/* 17137 */     nPlotDigital(labelId, xs, ys, flags, offset);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   private static native void nPlotDigital(String paramString, float[] paramArrayOffloat1, float[] paramArrayOffloat2);
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   private static native void nPlotDigital(String paramString, float[] paramArrayOffloat1, float[] paramArrayOffloat2, int paramInt);
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   private static native void nPlotDigital(String paramString, float[] paramArrayOffloat1, float[] paramArrayOffloat2, int paramInt1, int paramInt2);
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static void plotDigital(String labelId, double[] xs, double[] ys) {
/* 17174 */     nPlotDigital(labelId, xs, ys);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static void plotDigital(String labelId, double[] xs, double[] ys, int flags) {
/* 17181 */     nPlotDigital(labelId, xs, ys, flags);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static void plotDigital(String labelId, double[] xs, double[] ys, int flags, int offset) {
/* 17188 */     nPlotDigital(labelId, xs, ys, flags, offset);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   private static native void nPlotDigital(String paramString, double[] paramArrayOfdouble1, double[] paramArrayOfdouble2);
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   private static native void nPlotDigital(String paramString, double[] paramArrayOfdouble1, double[] paramArrayOfdouble2, int paramInt);
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   private static native void nPlotDigital(String paramString, double[] paramArrayOfdouble1, double[] paramArrayOfdouble2, int paramInt1, int paramInt2);
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static void plotDigitalV(String labelId, short[] xs, short[] ys, int count) {
/* 17225 */     nPlotDigitalV(labelId, xs, ys, count);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static void plotDigitalV(String labelId, short[] xs, short[] ys, int count, int flags) {
/* 17232 */     nPlotDigitalV(labelId, xs, ys, count, flags);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static void plotDigitalV(String labelId, short[] xs, short[] ys, int count, int flags, int offset) {
/* 17239 */     nPlotDigitalV(labelId, xs, ys, count, flags, offset);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   private static native void nPlotDigitalV(String paramString, short[] paramArrayOfshort1, short[] paramArrayOfshort2, int paramInt);
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   private static native void nPlotDigitalV(String paramString, short[] paramArrayOfshort1, short[] paramArrayOfshort2, int paramInt1, int paramInt2);
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   private static native void nPlotDigitalV(String paramString, short[] paramArrayOfshort1, short[] paramArrayOfshort2, int paramInt1, int paramInt2, int paramInt3);
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static void plotDigitalV(String labelId, int[] xs, int[] ys, int count) {
/* 17276 */     nPlotDigitalV(labelId, xs, ys, count);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static void plotDigitalV(String labelId, int[] xs, int[] ys, int count, int flags) {
/* 17283 */     nPlotDigitalV(labelId, xs, ys, count, flags);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static void plotDigitalV(String labelId, int[] xs, int[] ys, int count, int flags, int offset) {
/* 17290 */     nPlotDigitalV(labelId, xs, ys, count, flags, offset);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   private static native void nPlotDigitalV(String paramString, int[] paramArrayOfint1, int[] paramArrayOfint2, int paramInt);
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   private static native void nPlotDigitalV(String paramString, int[] paramArrayOfint1, int[] paramArrayOfint2, int paramInt1, int paramInt2);
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   private static native void nPlotDigitalV(String paramString, int[] paramArrayOfint1, int[] paramArrayOfint2, int paramInt1, int paramInt2, int paramInt3);
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static void plotDigitalV(String labelId, long[] xs, long[] ys, int count) {
/* 17327 */     nPlotDigitalV(labelId, xs, ys, count);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static void plotDigitalV(String labelId, long[] xs, long[] ys, int count, int flags) {
/* 17334 */     nPlotDigitalV(labelId, xs, ys, count, flags);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static void plotDigitalV(String labelId, long[] xs, long[] ys, int count, int flags, int offset) {
/* 17341 */     nPlotDigitalV(labelId, xs, ys, count, flags, offset);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   private static native void nPlotDigitalV(String paramString, long[] paramArrayOflong1, long[] paramArrayOflong2, int paramInt);
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   private static native void nPlotDigitalV(String paramString, long[] paramArrayOflong1, long[] paramArrayOflong2, int paramInt1, int paramInt2);
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   private static native void nPlotDigitalV(String paramString, long[] paramArrayOflong1, long[] paramArrayOflong2, int paramInt1, int paramInt2, int paramInt3);
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static void plotDigitalV(String labelId, float[] xs, float[] ys, int count) {
/* 17378 */     nPlotDigitalV(labelId, xs, ys, count);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static void plotDigitalV(String labelId, float[] xs, float[] ys, int count, int flags) {
/* 17385 */     nPlotDigitalV(labelId, xs, ys, count, flags);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static void plotDigitalV(String labelId, float[] xs, float[] ys, int count, int flags, int offset) {
/* 17392 */     nPlotDigitalV(labelId, xs, ys, count, flags, offset);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   private static native void nPlotDigitalV(String paramString, float[] paramArrayOffloat1, float[] paramArrayOffloat2, int paramInt);
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   private static native void nPlotDigitalV(String paramString, float[] paramArrayOffloat1, float[] paramArrayOffloat2, int paramInt1, int paramInt2);
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   private static native void nPlotDigitalV(String paramString, float[] paramArrayOffloat1, float[] paramArrayOffloat2, int paramInt1, int paramInt2, int paramInt3);
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static void plotDigitalV(String labelId, double[] xs, double[] ys, int count) {
/* 17429 */     nPlotDigitalV(labelId, xs, ys, count);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static void plotDigitalV(String labelId, double[] xs, double[] ys, int count, int flags) {
/* 17436 */     nPlotDigitalV(labelId, xs, ys, count, flags);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static void plotDigitalV(String labelId, double[] xs, double[] ys, int count, int flags, int offset) {
/* 17443 */     nPlotDigitalV(labelId, xs, ys, count, flags, offset);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   private static native void nPlotDigitalV(String paramString, double[] paramArrayOfdouble1, double[] paramArrayOfdouble2, int paramInt);
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   private static native void nPlotDigitalV(String paramString, double[] paramArrayOfdouble1, double[] paramArrayOfdouble2, int paramInt1, int paramInt2);
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   private static native void nPlotDigitalV(String paramString, double[] paramArrayOfdouble1, double[] paramArrayOfdouble2, int paramInt1, int paramInt2, int paramInt3);
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static void plotImage(String labelId, long userTextureId, ImPlotPoint boundsMin, ImPlotPoint boundsMax) {
/* 17480 */     nPlotImage(labelId, userTextureId, boundsMin.x, boundsMin.y, boundsMax.x, boundsMax.y);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static void plotImage(String labelId, long userTextureId, double boundsMinX, double boundsMinY, double boundsMaxX, double boundsMaxY) {
/* 17487 */     nPlotImage(labelId, userTextureId, boundsMinX, boundsMinY, boundsMaxX, boundsMaxY);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static void plotImage(String labelId, long userTextureId, ImPlotPoint boundsMin, ImPlotPoint boundsMax, ImVec2 uv0) {
/* 17494 */     nPlotImage(labelId, userTextureId, boundsMin.x, boundsMin.y, boundsMax.x, boundsMax.y, uv0.x, uv0.y);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static void plotImage(String labelId, long userTextureId, ImPlotPoint boundsMin, ImPlotPoint boundsMax, float uv0X, float uv0Y) {
/* 17501 */     nPlotImage(labelId, userTextureId, boundsMin.x, boundsMin.y, boundsMax.x, boundsMax.y, uv0X, uv0Y);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static void plotImage(String labelId, long userTextureId, double boundsMinX, double boundsMinY, double boundsMaxX, double boundsMaxY, ImVec2 uv0) {
/* 17508 */     nPlotImage(labelId, userTextureId, boundsMinX, boundsMinY, boundsMaxX, boundsMaxY, uv0.x, uv0.y);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static void plotImage(String labelId, long userTextureId, ImPlotPoint boundsMin, ImPlotPoint boundsMax, ImVec2 uv0, ImVec2 uv1) {
/* 17515 */     nPlotImage(labelId, userTextureId, boundsMin.x, boundsMin.y, boundsMax.x, boundsMax.y, uv0.x, uv0.y, uv1.x, uv1.y);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static void plotImage(String labelId, long userTextureId, ImPlotPoint boundsMin, ImPlotPoint boundsMax, float uv0X, float uv0Y, float uv1X, float uv1Y) {
/* 17522 */     nPlotImage(labelId, userTextureId, boundsMin.x, boundsMin.y, boundsMax.x, boundsMax.y, uv0X, uv0Y, uv1X, uv1Y);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static void plotImage(String labelId, long userTextureId, double boundsMinX, double boundsMinY, double boundsMaxX, double boundsMaxY, ImVec2 uv0, ImVec2 uv1) {
/* 17529 */     nPlotImage(labelId, userTextureId, boundsMinX, boundsMinY, boundsMaxX, boundsMaxY, uv0.x, uv0.y, uv1.x, uv1.y);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static void plotImage(String labelId, long userTextureId, ImPlotPoint boundsMin, ImPlotPoint boundsMax, ImVec2 uv0, ImVec2 uv1, ImVec4 tintCol) {
/* 17536 */     nPlotImage(labelId, userTextureId, boundsMin.x, boundsMin.y, boundsMax.x, boundsMax.y, uv0.x, uv0.y, uv1.x, uv1.y, tintCol.x, tintCol.y, tintCol.z, tintCol.w);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static void plotImage(String labelId, long userTextureId, ImPlotPoint boundsMin, ImPlotPoint boundsMax, float uv0X, float uv0Y, float uv1X, float uv1Y, float tintColX, float tintColY, float tintColZ, float tintColW) {
/* 17543 */     nPlotImage(labelId, userTextureId, boundsMin.x, boundsMin.y, boundsMax.x, boundsMax.y, uv0X, uv0Y, uv1X, uv1Y, tintColX, tintColY, tintColZ, tintColW);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static void plotImage(String labelId, long userTextureId, double boundsMinX, double boundsMinY, double boundsMaxX, double boundsMaxY, ImVec2 uv0, ImVec2 uv1, ImVec4 tintCol) {
/* 17550 */     nPlotImage(labelId, userTextureId, boundsMinX, boundsMinY, boundsMaxX, boundsMaxY, uv0.x, uv0.y, uv1.x, uv1.y, tintCol.x, tintCol.y, tintCol.z, tintCol.w);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static void plotImage(String labelId, long userTextureId, ImPlotPoint boundsMin, ImPlotPoint boundsMax, ImVec2 uv0, ImVec2 uv1, ImVec4 tintCol, int flags) {
/* 17557 */     nPlotImage(labelId, userTextureId, boundsMin.x, boundsMin.y, boundsMax.x, boundsMax.y, uv0.x, uv0.y, uv1.x, uv1.y, tintCol.x, tintCol.y, tintCol.z, tintCol.w, flags);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static void plotImage(String labelId, long userTextureId, ImPlotPoint boundsMin, ImPlotPoint boundsMax, float uv0X, float uv0Y, float uv1X, float uv1Y, float tintColX, float tintColY, float tintColZ, float tintColW, int flags) {
/* 17564 */     nPlotImage(labelId, userTextureId, boundsMin.x, boundsMin.y, boundsMax.x, boundsMax.y, uv0X, uv0Y, uv1X, uv1Y, tintColX, tintColY, tintColZ, tintColW, flags);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static void plotImage(String labelId, long userTextureId, double boundsMinX, double boundsMinY, double boundsMaxX, double boundsMaxY, ImVec2 uv0, ImVec2 uv1, ImVec4 tintCol, int flags) {
/* 17571 */     nPlotImage(labelId, userTextureId, boundsMinX, boundsMinY, boundsMaxX, boundsMaxY, uv0.x, uv0.y, uv1.x, uv1.y, tintCol.x, tintCol.y, tintCol.z, tintCol.w, flags);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   private static native void nPlotImage(String paramString, long paramLong, double paramDouble1, double paramDouble2, double paramDouble3, double paramDouble4);
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   private static native void nPlotImage(String paramString, long paramLong, double paramDouble1, double paramDouble2, double paramDouble3, double paramDouble4, float paramFloat1, float paramFloat2);
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   private static native void nPlotImage(String paramString, long paramLong, double paramDouble1, double paramDouble2, double paramDouble3, double paramDouble4, float paramFloat1, float paramFloat2, float paramFloat3, float paramFloat4);
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   private static native void nPlotImage(String paramString, long paramLong, double paramDouble1, double paramDouble2, double paramDouble3, double paramDouble4, float paramFloat1, float paramFloat2, float paramFloat3, float paramFloat4, float paramFloat5, float paramFloat6, float paramFloat7, float paramFloat8);
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   private static native void nPlotImage(String paramString, long paramLong, double paramDouble1, double paramDouble2, double paramDouble3, double paramDouble4, float paramFloat1, float paramFloat2, float paramFloat3, float paramFloat4, float paramFloat5, float paramFloat6, float paramFloat7, float paramFloat8, int paramInt);
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static void plotText(String text, double x, double y) {
/* 17617 */     nPlotText(text, x, y);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static void plotText(String text, double x, double y, ImVec2 pixOffset) {
/* 17624 */     nPlotText(text, x, y, pixOffset.x, pixOffset.y);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static void plotText(String text, double x, double y, float pixOffsetX, float pixOffsetY) {
/* 17631 */     nPlotText(text, x, y, pixOffsetX, pixOffsetY);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static void plotText(String text, double x, double y, ImVec2 pixOffset, int flags) {
/* 17638 */     nPlotText(text, x, y, pixOffset.x, pixOffset.y, flags);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static void plotText(String text, double x, double y, float pixOffsetX, float pixOffsetY, int flags) {
/* 17645 */     nPlotText(text, x, y, pixOffsetX, pixOffsetY, flags);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static void plotText(String text, double x, double y, int flags) {
/* 17652 */     nPlotText(text, x, y, flags);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   private static native void nPlotText(String paramString, double paramDouble1, double paramDouble2);
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   private static native void nPlotText(String paramString, double paramDouble1, double paramDouble2, float paramFloat1, float paramFloat2);
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   private static native void nPlotText(String paramString, double paramDouble1, double paramDouble2, float paramFloat1, float paramFloat2, int paramInt);
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   private static native void nPlotText(String paramString, double paramDouble1, double paramDouble2, int paramInt);
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static void plotDummy(String labelID) {
/* 17685 */     nPlotDummy(labelID);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static void plotDummy(String labelID, int flags) {
/* 17692 */     nPlotDummy(labelID, flags);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   private static native void nPlotDummy(String paramString);
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   private static native void nPlotDummy(String paramString, int paramInt);
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static boolean dragPoint(int id, ImDouble x, ImDouble y, ImVec4 col) {
/* 17724 */     return nDragPoint(id, (x != null) ? x.getData() : null, (y != null) ? y.getData() : null, col.x, col.y, col.z, col.w);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static boolean dragPoint(int id, ImDouble x, ImDouble y, float colX, float colY, float colZ, float colW) {
/* 17731 */     return nDragPoint(id, (x != null) ? x.getData() : null, (y != null) ? y.getData() : null, colX, colY, colZ, colW);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static boolean dragPoint(int id, ImDouble x, ImDouble y, ImVec4 col, float size) {
/* 17738 */     return nDragPoint(id, (x != null) ? x.getData() : null, (y != null) ? y.getData() : null, col.x, col.y, col.z, col.w, size);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static boolean dragPoint(int id, ImDouble x, ImDouble y, float colX, float colY, float colZ, float colW, float size) {
/* 17745 */     return nDragPoint(id, (x != null) ? x.getData() : null, (y != null) ? y.getData() : null, colX, colY, colZ, colW, size);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static boolean dragPoint(int id, ImDouble x, ImDouble y, ImVec4 col, float size, int flags) {
/* 17752 */     return nDragPoint(id, (x != null) ? x.getData() : null, (y != null) ? y.getData() : null, col.x, col.y, col.z, col.w, size, flags);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static boolean dragPoint(int id, ImDouble x, ImDouble y, float colX, float colY, float colZ, float colW, float size, int flags) {
/* 17759 */     return nDragPoint(id, (x != null) ? x.getData() : null, (y != null) ? y.getData() : null, colX, colY, colZ, colW, size, flags);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static boolean dragPoint(int id, ImDouble x, ImDouble y, ImVec4 col, int flags) {
/* 17766 */     return nDragPoint(id, (x != null) ? x.getData() : null, (y != null) ? y.getData() : null, col.x, col.y, col.z, col.w, flags);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static boolean dragPoint(int id, ImDouble x, ImDouble y, float colX, float colY, float colZ, float colW, int flags) {
/* 17773 */     return nDragPoint(id, (x != null) ? x.getData() : null, (y != null) ? y.getData() : null, colX, colY, colZ, colW, flags);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   private static native boolean nDragPoint(int paramInt, double[] paramArrayOfdouble1, double[] paramArrayOfdouble2, float paramFloat1, float paramFloat2, float paramFloat3, float paramFloat4);
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   private static native boolean nDragPoint(int paramInt, double[] paramArrayOfdouble1, double[] paramArrayOfdouble2, float paramFloat1, float paramFloat2, float paramFloat3, float paramFloat4, float paramFloat5);
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   private static native boolean nDragPoint(int paramInt1, double[] paramArrayOfdouble1, double[] paramArrayOfdouble2, float paramFloat1, float paramFloat2, float paramFloat3, float paramFloat4, float paramFloat5, int paramInt2);
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   private static native boolean nDragPoint(int paramInt1, double[] paramArrayOfdouble1, double[] paramArrayOfdouble2, float paramFloat1, float paramFloat2, float paramFloat3, float paramFloat4, int paramInt2);
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static boolean dragLineX(int id, ImDouble x, ImVec4 col) {
/* 17820 */     return nDragLineX(id, (x != null) ? x.getData() : null, col.x, col.y, col.z, col.w);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static boolean dragLineX(int id, ImDouble x, float colX, float colY, float colZ, float colW) {
/* 17827 */     return nDragLineX(id, (x != null) ? x.getData() : null, colX, colY, colZ, colW);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static boolean dragLineX(int id, ImDouble x, ImVec4 col, float thickness) {
/* 17834 */     return nDragLineX(id, (x != null) ? x.getData() : null, col.x, col.y, col.z, col.w, thickness);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static boolean dragLineX(int id, ImDouble x, float colX, float colY, float colZ, float colW, float thickness) {
/* 17841 */     return nDragLineX(id, (x != null) ? x.getData() : null, colX, colY, colZ, colW, thickness);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static boolean dragLineX(int id, ImDouble x, ImVec4 col, float thickness, int flags) {
/* 17848 */     return nDragLineX(id, (x != null) ? x.getData() : null, col.x, col.y, col.z, col.w, thickness, flags);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static boolean dragLineX(int id, ImDouble x, float colX, float colY, float colZ, float colW, float thickness, int flags) {
/* 17855 */     return nDragLineX(id, (x != null) ? x.getData() : null, colX, colY, colZ, colW, thickness, flags);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static boolean dragLineX(int id, ImDouble x, ImVec4 col, int flags) {
/* 17862 */     return nDragLineX(id, (x != null) ? x.getData() : null, col.x, col.y, col.z, col.w, flags);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static boolean dragLineX(int id, ImDouble x, float colX, float colY, float colZ, float colW, int flags) {
/* 17869 */     return nDragLineX(id, (x != null) ? x.getData() : null, colX, colY, colZ, colW, flags);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   private static native boolean nDragLineX(int paramInt, double[] paramArrayOfdouble, float paramFloat1, float paramFloat2, float paramFloat3, float paramFloat4);
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   private static native boolean nDragLineX(int paramInt, double[] paramArrayOfdouble, float paramFloat1, float paramFloat2, float paramFloat3, float paramFloat4, float paramFloat5);
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   private static native boolean nDragLineX(int paramInt1, double[] paramArrayOfdouble, float paramFloat1, float paramFloat2, float paramFloat3, float paramFloat4, float paramFloat5, int paramInt2);
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   private static native boolean nDragLineX(int paramInt1, double[] paramArrayOfdouble, float paramFloat1, float paramFloat2, float paramFloat3, float paramFloat4, int paramInt2);
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static boolean dragLineY(int id, ImDouble y, ImVec4 col) {
/* 17908 */     return nDragLineY(id, (y != null) ? y.getData() : null, col.x, col.y, col.z, col.w);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static boolean dragLineY(int id, ImDouble y, float colX, float colY, float colZ, float colW) {
/* 17915 */     return nDragLineY(id, (y != null) ? y.getData() : null, colX, colY, colZ, colW);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static boolean dragLineY(int id, ImDouble y, ImVec4 col, float thickness) {
/* 17922 */     return nDragLineY(id, (y != null) ? y.getData() : null, col.x, col.y, col.z, col.w, thickness);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static boolean dragLineY(int id, ImDouble y, float colX, float colY, float colZ, float colW, float thickness) {
/* 17929 */     return nDragLineY(id, (y != null) ? y.getData() : null, colX, colY, colZ, colW, thickness);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static boolean dragLineY(int id, ImDouble y, ImVec4 col, float thickness, int flags) {
/* 17936 */     return nDragLineY(id, (y != null) ? y.getData() : null, col.x, col.y, col.z, col.w, thickness, flags);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static boolean dragLineY(int id, ImDouble y, float colX, float colY, float colZ, float colW, float thickness, int flags) {
/* 17943 */     return nDragLineY(id, (y != null) ? y.getData() : null, colX, colY, colZ, colW, thickness, flags);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static boolean dragLineY(int id, ImDouble y, ImVec4 col, int flags) {
/* 17950 */     return nDragLineY(id, (y != null) ? y.getData() : null, col.x, col.y, col.z, col.w, flags);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static boolean dragLineY(int id, ImDouble y, float colX, float colY, float colZ, float colW, int flags) {
/* 17957 */     return nDragLineY(id, (y != null) ? y.getData() : null, colX, colY, colZ, colW, flags);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   private static native boolean nDragLineY(int paramInt, double[] paramArrayOfdouble, float paramFloat1, float paramFloat2, float paramFloat3, float paramFloat4);
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   private static native boolean nDragLineY(int paramInt, double[] paramArrayOfdouble, float paramFloat1, float paramFloat2, float paramFloat3, float paramFloat4, float paramFloat5);
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   private static native boolean nDragLineY(int paramInt1, double[] paramArrayOfdouble, float paramFloat1, float paramFloat2, float paramFloat3, float paramFloat4, float paramFloat5, int paramInt2);
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   private static native boolean nDragLineY(int paramInt1, double[] paramArrayOfdouble, float paramFloat1, float paramFloat2, float paramFloat3, float paramFloat4, int paramInt2);
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static boolean dragRect(int id, ImDouble xMin, ImDouble yMin, ImDouble xMax, ImDouble yMax, ImVec4 col) {
/* 17996 */     return nDragRect(id, (xMin != null) ? xMin.getData() : null, (yMin != null) ? yMin.getData() : null, (xMax != null) ? xMax.getData() : null, (yMax != null) ? yMax.getData() : null, col.x, col.y, col.z, col.w);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static boolean dragRect(int id, ImDouble xMin, ImDouble yMin, ImDouble xMax, ImDouble yMax, float colX, float colY, float colZ, float colW) {
/* 18003 */     return nDragRect(id, (xMin != null) ? xMin.getData() : null, (yMin != null) ? yMin.getData() : null, (xMax != null) ? xMax.getData() : null, (yMax != null) ? yMax.getData() : null, colX, colY, colZ, colW);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static boolean dragRect(int id, ImDouble xMin, ImDouble yMin, ImDouble xMax, ImDouble yMax, ImVec4 col, int flags) {
/* 18010 */     return nDragRect(id, (xMin != null) ? xMin.getData() : null, (yMin != null) ? yMin.getData() : null, (xMax != null) ? xMax.getData() : null, (yMax != null) ? yMax.getData() : null, col.x, col.y, col.z, col.w, flags);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static boolean dragRect(int id, ImDouble xMin, ImDouble yMin, ImDouble xMax, ImDouble yMax, float colX, float colY, float colZ, float colW, int flags) {
/* 18017 */     return nDragRect(id, (xMin != null) ? xMin.getData() : null, (yMin != null) ? yMin.getData() : null, (xMax != null) ? xMax.getData() : null, (yMax != null) ? yMax.getData() : null, colX, colY, colZ, colW, flags);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   private static native boolean nDragRect(int paramInt, double[] paramArrayOfdouble1, double[] paramArrayOfdouble2, double[] paramArrayOfdouble3, double[] paramArrayOfdouble4, float paramFloat1, float paramFloat2, float paramFloat3, float paramFloat4);
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   private static native boolean nDragRect(int paramInt1, double[] paramArrayOfdouble1, double[] paramArrayOfdouble2, double[] paramArrayOfdouble3, double[] paramArrayOfdouble4, float paramFloat1, float paramFloat2, float paramFloat3, float paramFloat4, int paramInt2);
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static void annotation(double x, double y, ImVec4 col, ImVec2 pixOffset, boolean clamp) {
/* 18053 */     nAnnotation(x, y, col.x, col.y, col.z, col.w, pixOffset.x, pixOffset.y, clamp);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static void annotation(double x, double y, float colX, float colY, float colZ, float colW, float pixOffsetX, float pixOffsetY, boolean clamp) {
/* 18061 */     nAnnotation(x, y, colX, colY, colZ, colW, pixOffsetX, pixOffsetY, clamp);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static void annotation(double x, double y, ImVec4 col, ImVec2 pixOffset, boolean clamp, boolean round) {
/* 18069 */     nAnnotation(x, y, col.x, col.y, col.z, col.w, pixOffset.x, pixOffset.y, clamp, round);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static void annotation(double x, double y, float colX, float colY, float colZ, float colW, float pixOffsetX, float pixOffsetY, boolean clamp, boolean round) {
/* 18077 */     nAnnotation(x, y, colX, colY, colZ, colW, pixOffsetX, pixOffsetY, clamp, round);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   private static native void nAnnotation(double paramDouble1, double paramDouble2, float paramFloat1, float paramFloat2, float paramFloat3, float paramFloat4, float paramFloat5, float paramFloat6, boolean paramBoolean);
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   private static native void nAnnotation(double paramDouble1, double paramDouble2, float paramFloat1, float paramFloat2, float paramFloat3, float paramFloat4, float paramFloat5, float paramFloat6, boolean paramBoolean1, boolean paramBoolean2);
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static void annotation(double x, double y, ImVec4 col, ImVec2 pixOffset, boolean clamp, String fmt) {
/* 18097 */     nAnnotation(x, y, col.x, col.y, col.z, col.w, pixOffset.x, pixOffset.y, clamp, fmt);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static void annotation(double x, double y, float colX, float colY, float colZ, float colW, float pixOffsetX, float pixOffsetY, boolean clamp, String fmt) {
/* 18105 */     nAnnotation(x, y, colX, colY, colZ, colW, pixOffsetX, pixOffsetY, clamp, fmt);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   private static native void nAnnotation(double paramDouble1, double paramDouble2, float paramFloat1, float paramFloat2, float paramFloat3, float paramFloat4, float paramFloat5, float paramFloat6, boolean paramBoolean, String paramString);
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static void tagX(double x, ImVec4 col) {
/* 18120 */     nTagX(x, col.x, col.y, col.z, col.w);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static void tagX(double x, float colX, float colY, float colZ, float colW) {
/* 18127 */     nTagX(x, colX, colY, colZ, colW);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static void tagX(double x, ImVec4 col, boolean round) {
/* 18134 */     nTagX(x, col.x, col.y, col.z, col.w, round);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static void tagX(double x, float colX, float colY, float colZ, float colW, boolean round) {
/* 18141 */     nTagX(x, colX, colY, colZ, colW, round);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   private static native void nTagX(double paramDouble, float paramFloat1, float paramFloat2, float paramFloat3, float paramFloat4);
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   private static native void nTagX(double paramDouble, float paramFloat1, float paramFloat2, float paramFloat3, float paramFloat4, boolean paramBoolean);
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static void tagX(double x, ImVec4 col, String fmt) {
/* 18158 */     nTagX(x, col.x, col.y, col.z, col.w, fmt);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static void tagX(double x, float colX, float colY, float colZ, float colW, String fmt) {
/* 18165 */     nTagX(x, colX, colY, colZ, colW, fmt);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   private static native void nTagX(double paramDouble, float paramFloat1, float paramFloat2, float paramFloat3, float paramFloat4, String paramString);
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static void tagY(double y, ImVec4 col) {
/* 18179 */     nTagY(y, col.x, col.y, col.z, col.w);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static void tagY(double y, float colX, float colY, float colZ, float colW) {
/* 18186 */     nTagY(y, colX, colY, colZ, colW);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static void tagY(double y, ImVec4 col, boolean round) {
/* 18193 */     nTagY(y, col.x, col.y, col.z, col.w, round);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static void tagY(double y, float colX, float colY, float colZ, float colW, boolean round) {
/* 18200 */     nTagY(y, colX, colY, colZ, colW, round);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   private static native void nTagY(double paramDouble, float paramFloat1, float paramFloat2, float paramFloat3, float paramFloat4);
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   private static native void nTagY(double paramDouble, float paramFloat1, float paramFloat2, float paramFloat3, float paramFloat4, boolean paramBoolean);
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static void tagY(double y, ImVec4 col, String fmt) {
/* 18217 */     nTagY(y, col.x, col.y, col.z, col.w, fmt);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static void tagY(double y, float colX, float colY, float colZ, float colW, String fmt) {
/* 18224 */     nTagY(y, colX, colY, colZ, colW, fmt);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   private static native void nTagY(double paramDouble, float paramFloat1, float paramFloat2, float paramFloat3, float paramFloat4, String paramString);
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static void setAxis(int axis) {
/* 18242 */     nSetAxis(axis);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   private static native void nSetAxis(int paramInt);
/*       */ 
/*       */ 
/*       */   
/*       */   public static void setAxes(int xAxis, int yAxis) {
/* 18253 */     nSetAxes(xAxis, yAxis);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   private static native void nSetAxes(int paramInt1, int paramInt2);
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static ImPlotPoint pixelsToPlot(ImVec2 pix) {
/* 18265 */     ImPlotPoint dst = new ImPlotPoint();
/* 18266 */     nPixelsToPlot(dst, pix.x, pix.y);
/* 18267 */     return dst;
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static ImPlotPoint pixelsToPlot(float pixX, float pixY) {
/* 18275 */     ImPlotPoint dst = new ImPlotPoint();
/* 18276 */     nPixelsToPlot(dst, pixX, pixY);
/* 18277 */     return dst;
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static void pixelsToPlot(ImPlotPoint dst, ImVec2 pix) {
/* 18285 */     nPixelsToPlot(dst, pix.x, pix.y);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static void pixelsToPlot(ImPlotPoint dst, float pixX, float pixY) {
/* 18293 */     nPixelsToPlot(dst, pixX, pixY);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static ImPlotPoint pixelsToPlot(ImVec2 pix, int xAxis) {
/* 18301 */     ImPlotPoint dst = new ImPlotPoint();
/* 18302 */     nPixelsToPlot(dst, pix.x, pix.y, xAxis);
/* 18303 */     return dst;
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static ImPlotPoint pixelsToPlot(float pixX, float pixY, int xAxis) {
/* 18311 */     ImPlotPoint dst = new ImPlotPoint();
/* 18312 */     nPixelsToPlot(dst, pixX, pixY, xAxis);
/* 18313 */     return dst;
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static void pixelsToPlot(ImPlotPoint dst, ImVec2 pix, int xAxis) {
/* 18321 */     nPixelsToPlot(dst, pix.x, pix.y, xAxis);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static void pixelsToPlot(ImPlotPoint dst, float pixX, float pixY, int xAxis) {
/* 18329 */     nPixelsToPlot(dst, pixX, pixY, xAxis);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static ImPlotPoint pixelsToPlot(ImVec2 pix, int xAxis, int yAxis) {
/* 18337 */     ImPlotPoint dst = new ImPlotPoint();
/* 18338 */     nPixelsToPlot(dst, pix.x, pix.y, xAxis, yAxis);
/* 18339 */     return dst;
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static ImPlotPoint pixelsToPlot(float pixX, float pixY, int xAxis, int yAxis) {
/* 18347 */     ImPlotPoint dst = new ImPlotPoint();
/* 18348 */     nPixelsToPlot(dst, pixX, pixY, xAxis, yAxis);
/* 18349 */     return dst;
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static void pixelsToPlot(ImPlotPoint dst, ImVec2 pix, int xAxis, int yAxis) {
/* 18357 */     nPixelsToPlot(dst, pix.x, pix.y, xAxis, yAxis);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static void pixelsToPlot(ImPlotPoint dst, float pixX, float pixY, int xAxis, int yAxis) {
/* 18365 */     nPixelsToPlot(dst, pixX, pixY, xAxis, yAxis);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   private static native void nPixelsToPlot(ImPlotPoint paramImPlotPoint, float paramFloat1, float paramFloat2);
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   private static native void nPixelsToPlot(ImPlotPoint paramImPlotPoint, float paramFloat1, float paramFloat2, int paramInt);
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   private static native void nPixelsToPlot(ImPlotPoint paramImPlotPoint, float paramFloat1, float paramFloat2, int paramInt1, int paramInt2);
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static ImVec2 plotToPixels(ImPlotPoint plt) {
/* 18388 */     ImVec2 dst = new ImVec2();
/* 18389 */     nPlotToPixels(dst, plt.x, plt.y);
/* 18390 */     return dst;
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static ImVec2 plotToPixels(double pltX, double pltY) {
/* 18398 */     ImVec2 dst = new ImVec2();
/* 18399 */     nPlotToPixels(dst, pltX, pltY);
/* 18400 */     return dst;
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static float plotToPixelsX(ImPlotPoint plt) {
/* 18408 */     return nPlotToPixelsX(plt.x, plt.y);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static float plotToPixelsY(ImPlotPoint plt) {
/* 18416 */     return nPlotToPixelsY(plt.x, plt.y);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static void plotToPixels(ImVec2 dst, ImPlotPoint plt) {
/* 18424 */     nPlotToPixels(dst, plt.x, plt.y);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static void plotToPixels(ImVec2 dst, double pltX, double pltY) {
/* 18432 */     nPlotToPixels(dst, pltX, pltY);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static ImVec2 plotToPixels(ImPlotPoint plt, int xAxis) {
/* 18440 */     ImVec2 dst = new ImVec2();
/* 18441 */     nPlotToPixels(dst, plt.x, plt.y, xAxis);
/* 18442 */     return dst;
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static ImVec2 plotToPixels(double pltX, double pltY, int xAxis) {
/* 18450 */     ImVec2 dst = new ImVec2();
/* 18451 */     nPlotToPixels(dst, pltX, pltY, xAxis);
/* 18452 */     return dst;
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static float plotToPixelsX(ImPlotPoint plt, int xAxis) {
/* 18460 */     return nPlotToPixelsX(plt.x, plt.y, xAxis);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static float plotToPixelsY(ImPlotPoint plt, int xAxis) {
/* 18468 */     return nPlotToPixelsY(plt.x, plt.y, xAxis);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static void plotToPixels(ImVec2 dst, ImPlotPoint plt, int xAxis) {
/* 18476 */     nPlotToPixels(dst, plt.x, plt.y, xAxis);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static void plotToPixels(ImVec2 dst, double pltX, double pltY, int xAxis) {
/* 18484 */     nPlotToPixels(dst, pltX, pltY, xAxis);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static ImVec2 plotToPixels(ImPlotPoint plt, int xAxis, int yAxis) {
/* 18492 */     ImVec2 dst = new ImVec2();
/* 18493 */     nPlotToPixels(dst, plt.x, plt.y, xAxis, yAxis);
/* 18494 */     return dst;
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static ImVec2 plotToPixels(double pltX, double pltY, int xAxis, int yAxis) {
/* 18502 */     ImVec2 dst = new ImVec2();
/* 18503 */     nPlotToPixels(dst, pltX, pltY, xAxis, yAxis);
/* 18504 */     return dst;
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static float plotToPixelsX(ImPlotPoint plt, int xAxis, int yAxis) {
/* 18512 */     return nPlotToPixelsX(plt.x, plt.y, xAxis, yAxis);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static float plotToPixelsY(ImPlotPoint plt, int xAxis, int yAxis) {
/* 18520 */     return nPlotToPixelsY(plt.x, plt.y, xAxis, yAxis);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static void plotToPixels(ImVec2 dst, ImPlotPoint plt, int xAxis, int yAxis) {
/* 18528 */     nPlotToPixels(dst, plt.x, plt.y, xAxis, yAxis);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static void plotToPixels(ImVec2 dst, double pltX, double pltY, int xAxis, int yAxis) {
/* 18536 */     nPlotToPixels(dst, pltX, pltY, xAxis, yAxis);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   private static native void nPlotToPixels(ImVec2 paramImVec2, double paramDouble1, double paramDouble2);
/*       */ 
/*       */ 
/*       */   
/*       */   private static native float nPlotToPixelsX(double paramDouble1, double paramDouble2);
/*       */ 
/*       */ 
/*       */   
/*       */   private static native float nPlotToPixelsY(double paramDouble1, double paramDouble2);
/*       */ 
/*       */ 
/*       */   
/*       */   private static native void nPlotToPixels(ImVec2 paramImVec2, double paramDouble1, double paramDouble2, int paramInt);
/*       */ 
/*       */ 
/*       */   
/*       */   private static native float nPlotToPixelsX(double paramDouble1, double paramDouble2, int paramInt);
/*       */ 
/*       */ 
/*       */   
/*       */   private static native float nPlotToPixelsY(double paramDouble1, double paramDouble2, int paramInt);
/*       */ 
/*       */ 
/*       */   
/*       */   private static native void nPlotToPixels(ImVec2 paramImVec2, double paramDouble1, double paramDouble2, int paramInt1, int paramInt2);
/*       */ 
/*       */ 
/*       */   
/*       */   private static native float nPlotToPixelsX(double paramDouble1, double paramDouble2, int paramInt1, int paramInt2);
/*       */ 
/*       */ 
/*       */   
/*       */   private static native float nPlotToPixelsY(double paramDouble1, double paramDouble2, int paramInt1, int paramInt2);
/*       */ 
/*       */ 
/*       */   
/*       */   public static ImVec2 getPlotPos() {
/* 18579 */     ImVec2 dst = new ImVec2();
/* 18580 */     nGetPlotPos(dst);
/* 18581 */     return dst;
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static float getPlotPosX() {
/* 18588 */     return nGetPlotPosX();
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static float getPlotPosY() {
/* 18595 */     return nGetPlotPosY();
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static void getPlotPos(ImVec2 dst) {
/* 18602 */     nGetPlotPos(dst);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   private static native void nGetPlotPos(ImVec2 paramImVec2);
/*       */ 
/*       */ 
/*       */   
/*       */   private static native float nGetPlotPosX();
/*       */ 
/*       */ 
/*       */   
/*       */   private static native float nGetPlotPosY();
/*       */ 
/*       */ 
/*       */   
/*       */   public static ImVec2 getPlotSize() {
/* 18621 */     ImVec2 dst = new ImVec2();
/* 18622 */     nGetPlotSize(dst);
/* 18623 */     return dst;
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static float getPlotSizeX() {
/* 18630 */     return nGetPlotSizeX();
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static float getPlotSizeY() {
/* 18637 */     return nGetPlotSizeY();
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static void getPlotSize(ImVec2 dst) {
/* 18644 */     nGetPlotSize(dst);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   private static native void nGetPlotSize(ImVec2 paramImVec2);
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   private static native float nGetPlotSizeX();
/*       */ 
/*       */ 
/*       */   
/*       */   private static native float nGetPlotSizeY();
/*       */ 
/*       */ 
/*       */   
/*       */   public static ImPlotPoint getPlotMousePos() {
/* 18664 */     ImPlotPoint dst = new ImPlotPoint();
/* 18665 */     nGetPlotMousePos(dst);
/* 18666 */     return dst;
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static void getPlotMousePos(ImPlotPoint dst) {
/* 18674 */     nGetPlotMousePos(dst);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static ImPlotPoint getPlotMousePos(int xAxis) {
/* 18682 */     ImPlotPoint dst = new ImPlotPoint();
/* 18683 */     nGetPlotMousePos(dst, xAxis);
/* 18684 */     return dst;
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static void getPlotMousePos(ImPlotPoint dst, int xAxis) {
/* 18692 */     nGetPlotMousePos(dst, xAxis);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static ImPlotPoint getPlotMousePos(int xAxis, int yAxis) {
/* 18700 */     ImPlotPoint dst = new ImPlotPoint();
/* 18701 */     nGetPlotMousePos(dst, xAxis, yAxis);
/* 18702 */     return dst;
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static void getPlotMousePos(ImPlotPoint dst, int xAxis, int yAxis) {
/* 18710 */     nGetPlotMousePos(dst, xAxis, yAxis);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   private static native void nGetPlotMousePos(ImPlotPoint paramImPlotPoint);
/*       */ 
/*       */ 
/*       */   
/*       */   private static native void nGetPlotMousePos(ImPlotPoint paramImPlotPoint, int paramInt);
/*       */ 
/*       */ 
/*       */   
/*       */   private static native void nGetPlotMousePos(ImPlotPoint paramImPlotPoint, int paramInt1, int paramInt2);
/*       */ 
/*       */ 
/*       */   
/*       */   public static ImPlotRect getPlotLimits() {
/* 18729 */     ImPlotRect dst = new ImPlotRect();
/* 18730 */     nGetPlotLimits(dst);
/* 18731 */     return dst;
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static void getPlotLimits(ImPlotRect dst) {
/* 18738 */     nGetPlotLimits(dst);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static ImPlotRect getPlotLimits(int xAxis) {
/* 18745 */     ImPlotRect dst = new ImPlotRect();
/* 18746 */     nGetPlotLimits(dst, xAxis);
/* 18747 */     return dst;
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static void getPlotLimits(ImPlotRect dst, int xAxis) {
/* 18754 */     nGetPlotLimits(dst, xAxis);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static ImPlotRect getPlotLimits(int xAxis, int yAxis) {
/* 18761 */     ImPlotRect dst = new ImPlotRect();
/* 18762 */     nGetPlotLimits(dst, xAxis, yAxis);
/* 18763 */     return dst;
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static void getPlotLimits(ImPlotRect dst, int xAxis, int yAxis) {
/* 18770 */     nGetPlotLimits(dst, xAxis, yAxis);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   private static native void nGetPlotLimits(ImPlotRect paramImPlotRect);
/*       */ 
/*       */ 
/*       */   
/*       */   private static native void nGetPlotLimits(ImPlotRect paramImPlotRect, int paramInt);
/*       */ 
/*       */ 
/*       */   
/*       */   private static native void nGetPlotLimits(ImPlotRect paramImPlotRect, int paramInt1, int paramInt2);
/*       */ 
/*       */ 
/*       */   
/*       */   public static boolean isPlotHovered() {
/* 18789 */     return nIsPlotHovered();
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   private static native boolean nIsPlotHovered();
/*       */ 
/*       */ 
/*       */   
/*       */   public static boolean isAxisHovered(int axis) {
/* 18800 */     return nIsAxisHovered(axis);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   private static native boolean nIsAxisHovered(int paramInt);
/*       */ 
/*       */ 
/*       */   
/*       */   public static boolean isSubplotsHovered() {
/* 18811 */     return nIsSubplotsHovered();
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   private static native boolean nIsSubplotsHovered();
/*       */ 
/*       */ 
/*       */   
/*       */   public static boolean isPlotSelected() {
/* 18822 */     return nIsPlotSelected();
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   private static native boolean nIsPlotSelected();
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static ImPlotRect getPlotSelection() {
/* 18834 */     ImPlotRect dst = new ImPlotRect();
/* 18835 */     nGetPlotSelection(dst);
/* 18836 */     return dst;
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static void getPlotSelection(ImPlotRect dst) {
/* 18844 */     nGetPlotSelection(dst);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static ImPlotRect getPlotSelection(int xAxis) {
/* 18852 */     ImPlotRect dst = new ImPlotRect();
/* 18853 */     nGetPlotSelection(dst, xAxis);
/* 18854 */     return dst;
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static void getPlotSelection(ImPlotRect dst, int xAxis) {
/* 18862 */     nGetPlotSelection(dst, xAxis);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static ImPlotRect getPlotSelection(int xAxis, int yAxis) {
/* 18870 */     ImPlotRect dst = new ImPlotRect();
/* 18871 */     nGetPlotSelection(dst, xAxis, yAxis);
/* 18872 */     return dst;
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static void getPlotSelection(ImPlotRect dst, int xAxis, int yAxis) {
/* 18880 */     nGetPlotSelection(dst, xAxis, yAxis);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   private static native void nGetPlotSelection(ImPlotRect paramImPlotRect);
/*       */ 
/*       */ 
/*       */   
/*       */   private static native void nGetPlotSelection(ImPlotRect paramImPlotRect, int paramInt);
/*       */ 
/*       */ 
/*       */   
/*       */   private static native void nGetPlotSelection(ImPlotRect paramImPlotRect, int paramInt1, int paramInt2);
/*       */ 
/*       */ 
/*       */   
/*       */   public static void cancelPlotSelection() {
/* 18899 */     nCancelPlotSelection();
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   private static native void nCancelPlotSelection();
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static void hideNextItem() {
/* 18911 */     nHideNextItem();
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static void hideNextItem(boolean hidden) {
/* 18919 */     nHideNextItem(hidden);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static void hideNextItem(boolean hidden, int cond) {
/* 18927 */     nHideNextItem(hidden, cond);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static void hideNextItem(int cond) {
/* 18935 */     nHideNextItem(cond);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   private static native void nHideNextItem();
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   private static native void nHideNextItem(boolean paramBoolean);
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   private static native void nHideNextItem(boolean paramBoolean, int paramInt);
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   private static native void nHideNextItem(int paramInt);
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static boolean beginAlignedPlots(String groupId) {
/* 18964 */     return nBeginAlignedPlots(groupId);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static boolean beginAlignedPlots(String groupId, boolean vertical) {
/* 18972 */     return nBeginAlignedPlots(groupId, vertical);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   private static native boolean nBeginAlignedPlots(String paramString);
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   private static native boolean nBeginAlignedPlots(String paramString, boolean paramBoolean);
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static void endAlignedPlots() {
/* 18993 */     nEndAlignedPlots();
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   private static native void nEndAlignedPlots();
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static boolean beginLegendPopup(String labelId) {
/* 19008 */     return nBeginLegendPopup(labelId);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static boolean beginLegendPopup(String labelId, int mouseButton) {
/* 19015 */     return nBeginLegendPopup(labelId, mouseButton);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   private static native boolean nBeginLegendPopup(String paramString);
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   private static native boolean nBeginLegendPopup(String paramString, int paramInt);
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static void endLegendPopup() {
/* 19036 */     nEndLegendPopup();
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   private static native void nEndLegendPopup();
/*       */ 
/*       */ 
/*       */   
/*       */   public static boolean isLegendEntryHovered(String labelId) {
/* 19047 */     return nIsLegendEntryHovered(labelId);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   private static native boolean nIsLegendEntryHovered(String paramString);
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static boolean beginDragDropTargetPlot() {
/* 19066 */     return nBeginDragDropTargetPlot();
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   private static native boolean nBeginDragDropTargetPlot();
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static boolean beginDragDropTargetAxis(int axis) {
/* 19078 */     return nBeginDragDropTargetAxis(axis);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   private static native boolean nBeginDragDropTargetAxis(int paramInt);
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static boolean beginDragDropTargetLegend() {
/* 19090 */     return nBeginDragDropTargetLegend();
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   private static native boolean nBeginDragDropTargetLegend();
/*       */ 
/*       */ 
/*       */   
/*       */   public static void endDragDropTarget() {
/* 19101 */     nEndDragDropTarget();
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   private static native void nEndDragDropTarget();
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static boolean beginDragDropSourcePlot() {
/* 19116 */     return nBeginDragDropSourcePlot();
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static boolean beginDragDropSourcePlot(int flags) {
/* 19124 */     return nBeginDragDropSourcePlot(flags);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   private static native boolean nBeginDragDropSourcePlot();
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   private static native boolean nBeginDragDropSourcePlot(int paramInt);
/*       */ 
/*       */ 
/*       */   
/*       */   public static boolean beginDragDropSourceAxis(int axis) {
/* 19140 */     return nBeginDragDropSourceAxis(axis);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static boolean beginDragDropSourceAxis(int axis, int flags) {
/* 19148 */     return nBeginDragDropSourceAxis(axis, flags);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   private static native boolean nBeginDragDropSourceAxis(int paramInt);
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   private static native boolean nBeginDragDropSourceAxis(int paramInt1, int paramInt2);
/*       */ 
/*       */ 
/*       */   
/*       */   public static boolean beginDragDropSourceItem(String labelId) {
/* 19164 */     return nBeginDragDropSourceItem(labelId);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static boolean beginDragDropSourceItem(String labelId, int flags) {
/* 19172 */     return nBeginDragDropSourceItem(labelId, flags);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   private static native boolean nBeginDragDropSourceItem(String paramString);
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   private static native boolean nBeginDragDropSourceItem(String paramString, int paramInt);
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static void endDragDropSource() {
/* 19193 */     nEndDragDropSource();
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/* 19233 */   private static final ImPlotStyle _GETSTYLE_1 = new ImPlotStyle(0L);
/*       */ 
/*       */   
/*       */   private static native void nEndDragDropSource();
/*       */   
/*       */   public static ImPlotStyle getStyle() {
/* 19239 */     _GETSTYLE_1.ptr = nGetStyle();
/* 19240 */     return _GETSTYLE_1;
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   private static native long nGetStyle();
/*       */ 
/*       */ 
/*       */   
/*       */   public static void styleColorsAuto() {
/* 19251 */     nStyleColorsAuto();
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static void styleColorsAuto(ImPlotStyle dst) {
/* 19258 */     nStyleColorsAuto(dst.ptr);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   private static native void nStyleColorsAuto();
/*       */ 
/*       */ 
/*       */   
/*       */   private static native void nStyleColorsAuto(long paramLong);
/*       */ 
/*       */ 
/*       */   
/*       */   public static void styleColorsClassic() {
/* 19273 */     nStyleColorsClassic();
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static void styleColorsClassic(ImPlotStyle dst) {
/* 19280 */     nStyleColorsClassic(dst.ptr);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   private static native void nStyleColorsClassic();
/*       */ 
/*       */ 
/*       */   
/*       */   private static native void nStyleColorsClassic(long paramLong);
/*       */ 
/*       */ 
/*       */   
/*       */   public static void styleColorsDark() {
/* 19295 */     nStyleColorsDark();
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static void styleColorsDark(ImPlotStyle dst) {
/* 19302 */     nStyleColorsDark(dst.ptr);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   private static native void nStyleColorsDark();
/*       */ 
/*       */ 
/*       */   
/*       */   private static native void nStyleColorsDark(long paramLong);
/*       */ 
/*       */ 
/*       */   
/*       */   public static void styleColorsLight() {
/* 19317 */     nStyleColorsLight();
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static void styleColorsLight(ImPlotStyle dst) {
/* 19324 */     nStyleColorsLight(dst.ptr);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   private static native void nStyleColorsLight();
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   private static native void nStyleColorsLight(long paramLong);
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static native void pushStyleColor(int paramInt, long paramLong);
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static void pushStyleColor(int idx, int col) {
/* 19350 */     nPushStyleColor(idx, col);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   private static native void nPushStyleColor(int paramInt1, int paramInt2);
/*       */ 
/*       */ 
/*       */   
/*       */   public static void pushStyleColor(int idx, ImVec4 col) {
/* 19361 */     nPushStyleColor(idx, col.x, col.y, col.z, col.w);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static void pushStyleColor(int idx, float colX, float colY, float colZ, float colW) {
/* 19368 */     nPushStyleColor(idx, colX, colY, colZ, colW);
/*       */   }
/*       */ 
/*       */ 
/*       */   
/*       */   private static native void nPushStyleColor(int paramInt, float paramFloat1, float paramFloat2, float paramFloat3, float paramFloat4);
/*       */ 
/*       */   
/*       */   public static void popStyleColor() {
/* 19377 */     nPopStyleColor();
/*       */   }
/*       */   
/*       */   public static void popStyleColor(int count) {
/* 19381 */     nPopStyleColor(count);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   private static native void nPopStyleColor();
/*       */ 
/*       */ 
/*       */   
/*       */   private static native void nPopStyleColor(int paramInt);
/*       */ 
/*       */ 
/*       */   
/*       */   public static void pushStyleVar(int idx, float val) {
/* 19396 */     nPushStyleVar(idx, val);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   private static native void nPushStyleVar(int paramInt, float paramFloat);
/*       */ 
/*       */ 
/*       */   
/*       */   public static void pushStyleVar(int idx, int val) {
/* 19407 */     nPushStyleVar(idx, val);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   private static native void nPushStyleVar(int paramInt1, int paramInt2);
/*       */ 
/*       */ 
/*       */   
/*       */   public static void pushStyleVar(int idx, ImVec2 val) {
/* 19418 */     nPushStyleVar(idx, val.x, val.y);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static void pushStyleVar(int idx, float valX, float valY) {
/* 19425 */     nPushStyleVar(idx, valX, valY);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   private static native void nPushStyleVar(int paramInt, float paramFloat1, float paramFloat2);
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static void popStyleVar() {
/* 19437 */     nPopStyleVar();
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static void popStyleVar(int count) {
/* 19444 */     nPopStyleVar(count);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   private static native void nPopStyleVar();
/*       */ 
/*       */ 
/*       */   
/*       */   private static native void nPopStyleVar(int paramInt);
/*       */ 
/*       */ 
/*       */   
/*       */   public static void setNextLineStyle() {
/* 19459 */     nSetNextLineStyle();
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static void setNextLineStyle(ImVec4 col) {
/* 19466 */     nSetNextLineStyle(col.x, col.y, col.z, col.w);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static void setNextLineStyle(float colX, float colY, float colZ, float colW) {
/* 19473 */     nSetNextLineStyle(colX, colY, colZ, colW);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static void setNextLineStyle(ImVec4 col, float weight) {
/* 19480 */     nSetNextLineStyle(col.x, col.y, col.z, col.w, weight);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static void setNextLineStyle(float colX, float colY, float colZ, float colW, float weight) {
/* 19487 */     nSetNextLineStyle(colX, colY, colZ, colW, weight);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static void setNextLineStyle(float weight) {
/* 19494 */     nSetNextLineStyle(weight);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   private static native void nSetNextLineStyle();
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   private static native void nSetNextLineStyle(float paramFloat1, float paramFloat2, float paramFloat3, float paramFloat4);
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   private static native void nSetNextLineStyle(float paramFloat1, float paramFloat2, float paramFloat3, float paramFloat4, float paramFloat5);
/*       */ 
/*       */ 
/*       */   
/*       */   private static native void nSetNextLineStyle(float paramFloat);
/*       */ 
/*       */ 
/*       */   
/*       */   public static void setNextFillStyle() {
/* 19519 */     nSetNextFillStyle();
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static void setNextFillStyle(ImVec4 col) {
/* 19526 */     nSetNextFillStyle(col.x, col.y, col.z, col.w);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static void setNextFillStyle(float colX, float colY, float colZ, float colW) {
/* 19533 */     nSetNextFillStyle(colX, colY, colZ, colW);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static void setNextFillStyle(ImVec4 col, float alphaMod) {
/* 19540 */     nSetNextFillStyle(col.x, col.y, col.z, col.w, alphaMod);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static void setNextFillStyle(float colX, float colY, float colZ, float colW, float alphaMod) {
/* 19547 */     nSetNextFillStyle(colX, colY, colZ, colW, alphaMod);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static void setNextFillStyle(float alphaMod) {
/* 19554 */     nSetNextFillStyle(alphaMod);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   private static native void nSetNextFillStyle();
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   private static native void nSetNextFillStyle(float paramFloat1, float paramFloat2, float paramFloat3, float paramFloat4);
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   private static native void nSetNextFillStyle(float paramFloat1, float paramFloat2, float paramFloat3, float paramFloat4, float paramFloat5);
/*       */ 
/*       */ 
/*       */   
/*       */   private static native void nSetNextFillStyle(float paramFloat);
/*       */ 
/*       */ 
/*       */   
/*       */   public static void setNextMarkerStyle() {
/* 19579 */     nSetNextMarkerStyle();
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static void setNextMarkerStyle(int marker) {
/* 19586 */     nSetNextMarkerStyle(marker);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static void setNextMarkerStyle(int marker, float size) {
/* 19593 */     nSetNextMarkerStyle(marker, size);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static void setNextMarkerStyle(int marker, float size, ImVec4 fill) {
/* 19600 */     nSetNextMarkerStyle(marker, size, fill.x, fill.y, fill.z, fill.w);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static void setNextMarkerStyle(int marker, float size, float fillX, float fillY, float fillZ, float fillW) {
/* 19607 */     nSetNextMarkerStyle(marker, size, fillX, fillY, fillZ, fillW);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static void setNextMarkerStyle(int marker, float size, ImVec4 fill, float weight) {
/* 19614 */     nSetNextMarkerStyle(marker, size, fill.x, fill.y, fill.z, fill.w, weight);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static void setNextMarkerStyle(int marker, float size, float fillX, float fillY, float fillZ, float fillW, float weight) {
/* 19621 */     nSetNextMarkerStyle(marker, size, fillX, fillY, fillZ, fillW, weight);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static void setNextMarkerStyle(int marker, float size, ImVec4 fill, float weight, ImVec4 outline) {
/* 19628 */     nSetNextMarkerStyle(marker, size, fill.x, fill.y, fill.z, fill.w, weight, outline.x, outline.y, outline.z, outline.w);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static void setNextMarkerStyle(int marker, float size, float fillX, float fillY, float fillZ, float fillW, float weight, float outlineX, float outlineY, float outlineZ, float outlineW) {
/* 19635 */     nSetNextMarkerStyle(marker, size, fillX, fillY, fillZ, fillW, weight, outlineX, outlineY, outlineZ, outlineW);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static void setNextMarkerStyle(int marker, float size, ImVec4 fill, ImVec4 outline) {
/* 19642 */     nSetNextMarkerStyle(marker, size, fill.x, fill.y, fill.z, fill.w, outline.x, outline.y, outline.z, outline.w);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static void setNextMarkerStyle(int marker, float size, float fillX, float fillY, float fillZ, float fillW, float outlineX, float outlineY, float outlineZ, float outlineW) {
/* 19649 */     nSetNextMarkerStyle(marker, size, fillX, fillY, fillZ, fillW, outlineX, outlineY, outlineZ, outlineW);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   private static native void nSetNextMarkerStyle();
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   private static native void nSetNextMarkerStyle(int paramInt);
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   private static native void nSetNextMarkerStyle(int paramInt, float paramFloat);
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   private static native void nSetNextMarkerStyle(int paramInt, float paramFloat1, float paramFloat2, float paramFloat3, float paramFloat4, float paramFloat5);
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   private static native void nSetNextMarkerStyle(int paramInt, float paramFloat1, float paramFloat2, float paramFloat3, float paramFloat4, float paramFloat5, float paramFloat6);
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   private static native void nSetNextMarkerStyle(int paramInt, float paramFloat1, float paramFloat2, float paramFloat3, float paramFloat4, float paramFloat5, float paramFloat6, float paramFloat7, float paramFloat8, float paramFloat9, float paramFloat10);
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   private static native void nSetNextMarkerStyle(int paramInt, float paramFloat1, float paramFloat2, float paramFloat3, float paramFloat4, float paramFloat5, float paramFloat6, float paramFloat7, float paramFloat8, float paramFloat9);
/*       */ 
/*       */ 
/*       */   
/*       */   public static void setNextErrorBarStyle() {
/* 19690 */     nSetNextErrorBarStyle();
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static void setNextErrorBarStyle(ImVec4 col) {
/* 19697 */     nSetNextErrorBarStyle(col.x, col.y, col.z, col.w);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static void setNextErrorBarStyle(float colX, float colY, float colZ, float colW) {
/* 19704 */     nSetNextErrorBarStyle(colX, colY, colZ, colW);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static void setNextErrorBarStyle(ImVec4 col, float size) {
/* 19711 */     nSetNextErrorBarStyle(col.x, col.y, col.z, col.w, size);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static void setNextErrorBarStyle(float colX, float colY, float colZ, float colW, float size) {
/* 19718 */     nSetNextErrorBarStyle(colX, colY, colZ, colW, size);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static void setNextErrorBarStyle(ImVec4 col, float size, float weight) {
/* 19725 */     nSetNextErrorBarStyle(col.x, col.y, col.z, col.w, size, weight);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static void setNextErrorBarStyle(float colX, float colY, float colZ, float colW, float size, float weight) {
/* 19732 */     nSetNextErrorBarStyle(colX, colY, colZ, colW, size, weight);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static void setNextErrorBarStyle(float size, float weight) {
/* 19739 */     nSetNextErrorBarStyle(size, weight);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   private static native void nSetNextErrorBarStyle();
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   private static native void nSetNextErrorBarStyle(float paramFloat1, float paramFloat2, float paramFloat3, float paramFloat4);
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   private static native void nSetNextErrorBarStyle(float paramFloat1, float paramFloat2, float paramFloat3, float paramFloat4, float paramFloat5);
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   private static native void nSetNextErrorBarStyle(float paramFloat1, float paramFloat2, float paramFloat3, float paramFloat4, float paramFloat5, float paramFloat6);
/*       */ 
/*       */ 
/*       */   
/*       */   private static native void nSetNextErrorBarStyle(float paramFloat1, float paramFloat2);
/*       */ 
/*       */ 
/*       */   
/*       */   public static ImVec4 getLastItemColor() {
/* 19769 */     ImVec4 dst = new ImVec4();
/* 19770 */     nGetLastItemColor(dst);
/* 19771 */     return dst;
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static float getLastItemColorX() {
/* 19778 */     return nGetLastItemColorX();
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static float getLastItemColorY() {
/* 19785 */     return nGetLastItemColorY();
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static float getLastItemColorZ() {
/* 19792 */     return nGetLastItemColorZ();
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static float getLastItemColorW() {
/* 19799 */     return nGetLastItemColorW();
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static void getLastItemColor(ImVec4 dst) {
/* 19806 */     nGetLastItemColor(dst);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   private static native void nGetLastItemColor(ImVec4 paramImVec4);
/*       */ 
/*       */ 
/*       */   
/*       */   private static native float nGetLastItemColorX();
/*       */ 
/*       */ 
/*       */   
/*       */   private static native float nGetLastItemColorY();
/*       */ 
/*       */ 
/*       */   
/*       */   private static native float nGetLastItemColorZ();
/*       */ 
/*       */ 
/*       */   
/*       */   private static native float nGetLastItemColorW();
/*       */ 
/*       */ 
/*       */   
/*       */   public static String getStyleColorName(int idx) {
/* 19833 */     return nGetStyleColorName(idx);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   private static native String nGetStyleColorName(int paramInt);
/*       */ 
/*       */ 
/*       */   
/*       */   public static String getMarkerName(int idx) {
/* 19844 */     return nGetMarkerName(idx);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   private static native String nGetMarkerName(int paramInt);
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static int addColormap(String name, ImVec4[] cols) {
/* 19872 */     return nAddColormap(name, cols);
/*       */   }
/*       */   
/*       */   public static int addColormap(String name, ImVec4[] cols, boolean qual) {
/* 19876 */     return nAddColormap(name, cols, qual);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   private static native int nAddColormap(String paramString, ImVec4[] paramArrayOfImVec4);
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   private static native int nAddColormap(String paramString, ImVec4[] paramArrayOfImVec4, boolean paramBoolean);
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static int addColormap(String name, int[] cols) {
/* 19910 */     return nAddColormap(name, cols);
/*       */   }
/*       */   
/*       */   public static int addColormap(String name, int[] cols, boolean qual) {
/* 19914 */     return nAddColormap(name, cols, qual);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   private static native int nAddColormap(String paramString, int[] paramArrayOfint);
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   private static native int nAddColormap(String paramString, int[] paramArrayOfint, boolean paramBoolean);
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static int getColormapCount() {
/* 19939 */     return nGetColormapCount();
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   private static native int nGetColormapCount();
/*       */ 
/*       */ 
/*       */   
/*       */   public static String getColormapName(int cmap) {
/* 19950 */     return nGetColormapName(cmap);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   private static native String nGetColormapName(int paramInt);
/*       */ 
/*       */ 
/*       */   
/*       */   public static int getColormapIndex(String name) {
/* 19961 */     return nGetColormapIndex(name);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   private static native int nGetColormapIndex(String paramString);
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static void pushColormap(int cmap) {
/* 19975 */     nPushColormap(cmap);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   private static native void nPushColormap(int paramInt);
/*       */ 
/*       */ 
/*       */   
/*       */   public static void pushColormap(String name) {
/* 19986 */     nPushColormap(name);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   private static native void nPushColormap(String paramString);
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static void popColormap() {
/* 19999 */     nPopColormap();
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static void popColormap(int count) {
/* 20006 */     nPopColormap(count);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   private static native void nPopColormap();
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   private static native void nPopColormap(int paramInt);
/*       */ 
/*       */ 
/*       */   
/*       */   public static ImVec4 nextColormapColor() {
/* 20022 */     ImVec4 dst = new ImVec4();
/* 20023 */     nNextColormapColor(dst);
/* 20024 */     return dst;
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static float nextColormapColorX() {
/* 20032 */     return nNextColormapColorX();
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static float nextColormapColorY() {
/* 20040 */     return nNextColormapColorY();
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static float nextColormapColorZ() {
/* 20048 */     return nNextColormapColorZ();
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static float nextColormapColorW() {
/* 20056 */     return nNextColormapColorW();
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static void nextColormapColor(ImVec4 dst) {
/* 20064 */     nNextColormapColor(dst);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   private static native void nNextColormapColor(ImVec4 paramImVec4);
/*       */ 
/*       */ 
/*       */   
/*       */   private static native float nNextColormapColorX();
/*       */ 
/*       */ 
/*       */   
/*       */   private static native float nNextColormapColorY();
/*       */ 
/*       */ 
/*       */   
/*       */   private static native float nNextColormapColorZ();
/*       */ 
/*       */ 
/*       */   
/*       */   private static native float nNextColormapColorW();
/*       */ 
/*       */ 
/*       */   
/*       */   public static int getColormapSize() {
/* 20091 */     return nGetColormapSize();
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static int getColormapSize(int cmap) {
/* 20098 */     return nGetColormapSize(cmap);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   private static native int nGetColormapSize();
/*       */ 
/*       */ 
/*       */   
/*       */   private static native int nGetColormapSize(int paramInt);
/*       */ 
/*       */ 
/*       */   
/*       */   public static ImVec4 getColormapColor(int idx) {
/* 20113 */     ImVec4 dst = new ImVec4();
/* 20114 */     nGetColormapColor(dst, idx);
/* 20115 */     return dst;
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static float getColormapColorX(int idx) {
/* 20122 */     return nGetColormapColorX(idx);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static float getColormapColorY(int idx) {
/* 20129 */     return nGetColormapColorY(idx);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static float getColormapColorZ(int idx) {
/* 20136 */     return nGetColormapColorZ(idx);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static float getColormapColorW(int idx) {
/* 20143 */     return nGetColormapColorW(idx);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static void getColormapColor(ImVec4 dst, int idx) {
/* 20150 */     nGetColormapColor(dst, idx);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static ImVec4 getColormapColor(int idx, int cmap) {
/* 20157 */     ImVec4 dst = new ImVec4();
/* 20158 */     nGetColormapColor(dst, idx, cmap);
/* 20159 */     return dst;
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static float getColormapColorX(int idx, int cmap) {
/* 20166 */     return nGetColormapColorX(idx, cmap);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static float getColormapColorY(int idx, int cmap) {
/* 20173 */     return nGetColormapColorY(idx, cmap);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static float getColormapColorZ(int idx, int cmap) {
/* 20180 */     return nGetColormapColorZ(idx, cmap);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static float getColormapColorW(int idx, int cmap) {
/* 20187 */     return nGetColormapColorW(idx, cmap);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static void getColormapColor(ImVec4 dst, int idx, int cmap) {
/* 20194 */     nGetColormapColor(dst, idx, cmap);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   private static native void nGetColormapColor(ImVec4 paramImVec4, int paramInt);
/*       */ 
/*       */ 
/*       */   
/*       */   private static native float nGetColormapColorX(int paramInt);
/*       */ 
/*       */ 
/*       */   
/*       */   private static native float nGetColormapColorY(int paramInt);
/*       */ 
/*       */ 
/*       */   
/*       */   private static native float nGetColormapColorZ(int paramInt);
/*       */ 
/*       */ 
/*       */   
/*       */   private static native float nGetColormapColorW(int paramInt);
/*       */ 
/*       */ 
/*       */   
/*       */   private static native void nGetColormapColor(ImVec4 paramImVec4, int paramInt1, int paramInt2);
/*       */ 
/*       */ 
/*       */   
/*       */   private static native float nGetColormapColorX(int paramInt1, int paramInt2);
/*       */ 
/*       */ 
/*       */   
/*       */   private static native float nGetColormapColorY(int paramInt1, int paramInt2);
/*       */ 
/*       */ 
/*       */   
/*       */   private static native float nGetColormapColorZ(int paramInt1, int paramInt2);
/*       */ 
/*       */ 
/*       */   
/*       */   private static native float nGetColormapColorW(int paramInt1, int paramInt2);
/*       */ 
/*       */ 
/*       */   
/*       */   public static ImVec4 sampleColormap(float t) {
/* 20241 */     ImVec4 dst = new ImVec4();
/* 20242 */     nSampleColormap(dst, t);
/* 20243 */     return dst;
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static float sampleColormapX(float t) {
/* 20250 */     return nSampleColormapX(t);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static float sampleColormapY(float t) {
/* 20257 */     return nSampleColormapY(t);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static float sampleColormapZ(float t) {
/* 20264 */     return nSampleColormapZ(t);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static float sampleColormapW(float t) {
/* 20271 */     return nSampleColormapW(t);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static void sampleColormap(ImVec4 dst, float t) {
/* 20278 */     nSampleColormap(dst, t);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static ImVec4 sampleColormap(float t, int cmap) {
/* 20285 */     ImVec4 dst = new ImVec4();
/* 20286 */     nSampleColormap(dst, t, cmap);
/* 20287 */     return dst;
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static float sampleColormapX(float t, int cmap) {
/* 20294 */     return nSampleColormapX(t, cmap);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static float sampleColormapY(float t, int cmap) {
/* 20301 */     return nSampleColormapY(t, cmap);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static float sampleColormapZ(float t, int cmap) {
/* 20308 */     return nSampleColormapZ(t, cmap);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static float sampleColormapW(float t, int cmap) {
/* 20315 */     return nSampleColormapW(t, cmap);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static void sampleColormap(ImVec4 dst, float t, int cmap) {
/* 20322 */     nSampleColormap(dst, t, cmap);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   private static native void nSampleColormap(ImVec4 paramImVec4, float paramFloat);
/*       */ 
/*       */ 
/*       */   
/*       */   private static native float nSampleColormapX(float paramFloat);
/*       */ 
/*       */ 
/*       */   
/*       */   private static native float nSampleColormapY(float paramFloat);
/*       */ 
/*       */ 
/*       */   
/*       */   private static native float nSampleColormapZ(float paramFloat);
/*       */ 
/*       */ 
/*       */   
/*       */   private static native float nSampleColormapW(float paramFloat);
/*       */ 
/*       */ 
/*       */   
/*       */   private static native void nSampleColormap(ImVec4 paramImVec4, float paramFloat, int paramInt);
/*       */ 
/*       */ 
/*       */   
/*       */   private static native float nSampleColormapX(float paramFloat, int paramInt);
/*       */ 
/*       */ 
/*       */   
/*       */   private static native float nSampleColormapY(float paramFloat, int paramInt);
/*       */ 
/*       */ 
/*       */   
/*       */   private static native float nSampleColormapZ(float paramFloat, int paramInt);
/*       */ 
/*       */ 
/*       */   
/*       */   private static native float nSampleColormapW(float paramFloat, int paramInt);
/*       */ 
/*       */ 
/*       */   
/*       */   public static void colormapScale(String label, double scaleMin, double scaleMax) {
/* 20369 */     nColormapScale(label, scaleMin, scaleMax);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static void colormapScale(String label, double scaleMin, double scaleMax, ImVec2 size) {
/* 20376 */     nColormapScale(label, scaleMin, scaleMax, size.x, size.y);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static void colormapScale(String label, double scaleMin, double scaleMax, float sizeX, float sizeY) {
/* 20383 */     nColormapScale(label, scaleMin, scaleMax, sizeX, sizeY);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static void colormapScale(String label, double scaleMin, double scaleMax, ImVec2 size, String format) {
/* 20390 */     nColormapScale(label, scaleMin, scaleMax, size.x, size.y, format);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static void colormapScale(String label, double scaleMin, double scaleMax, float sizeX, float sizeY, String format) {
/* 20397 */     nColormapScale(label, scaleMin, scaleMax, sizeX, sizeY, format);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static void colormapScale(String label, double scaleMin, double scaleMax, ImVec2 size, String format, int flags) {
/* 20404 */     nColormapScale(label, scaleMin, scaleMax, size.x, size.y, format, flags);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static void colormapScale(String label, double scaleMin, double scaleMax, float sizeX, float sizeY, String format, int flags) {
/* 20411 */     nColormapScale(label, scaleMin, scaleMax, sizeX, sizeY, format, flags);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static void colormapScale(String label, double scaleMin, double scaleMax, ImVec2 size, String format, int flags, int cmap) {
/* 20418 */     nColormapScale(label, scaleMin, scaleMax, size.x, size.y, format, flags, cmap);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static void colormapScale(String label, double scaleMin, double scaleMax, float sizeX, float sizeY, String format, int flags, int cmap) {
/* 20425 */     nColormapScale(label, scaleMin, scaleMax, sizeX, sizeY, format, flags, cmap);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static void colormapScale(String label, double scaleMin, double scaleMax, String format, int flags, int cmap) {
/* 20432 */     nColormapScale(label, scaleMin, scaleMax, format, flags, cmap);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static void colormapScale(String label, double scaleMin, double scaleMax, int flags, int cmap) {
/* 20439 */     nColormapScale(label, scaleMin, scaleMax, flags, cmap);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static void colormapScale(String label, double scaleMin, double scaleMax, ImVec2 size, int flags, int cmap) {
/* 20446 */     nColormapScale(label, scaleMin, scaleMax, size.x, size.y, flags, cmap);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static void colormapScale(String label, double scaleMin, double scaleMax, float sizeX, float sizeY, int flags, int cmap) {
/* 20453 */     nColormapScale(label, scaleMin, scaleMax, sizeX, sizeY, flags, cmap);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   private static native void nColormapScale(String paramString, double paramDouble1, double paramDouble2);
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   private static native void nColormapScale(String paramString, double paramDouble1, double paramDouble2, float paramFloat1, float paramFloat2);
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   private static native void nColormapScale(String paramString1, double paramDouble1, double paramDouble2, float paramFloat1, float paramFloat2, String paramString2);
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   private static native void nColormapScale(String paramString1, double paramDouble1, double paramDouble2, float paramFloat1, float paramFloat2, String paramString2, int paramInt);
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   private static native void nColormapScale(String paramString1, double paramDouble1, double paramDouble2, float paramFloat1, float paramFloat2, String paramString2, int paramInt1, int paramInt2);
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   private static native void nColormapScale(String paramString1, double paramDouble1, double paramDouble2, String paramString2, int paramInt1, int paramInt2);
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   private static native void nColormapScale(String paramString, double paramDouble1, double paramDouble2, int paramInt1, int paramInt2);
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   private static native void nColormapScale(String paramString, double paramDouble1, double paramDouble2, float paramFloat1, float paramFloat2, int paramInt1, int paramInt2);
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static boolean colormapSlider(String label, ImFloat t) {
/* 20522 */     return nColormapSlider(label, (t != null) ? t.getData() : null);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static boolean colormapSlider(String label, ImFloat t, String format) {
/* 20530 */     return nColormapSlider(label, (t != null) ? t.getData() : null, format);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static boolean colormapSlider(String label, ImFloat t, String format, int cmap) {
/* 20538 */     return nColormapSlider(label, (t != null) ? t.getData() : null, format, cmap);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static boolean colormapSlider(String label, ImFloat t, int cmap) {
/* 20546 */     return nColormapSlider(label, (t != null) ? t.getData() : null, cmap);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   private static native boolean nColormapSlider(String paramString, float[] paramArrayOffloat);
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   private static native boolean nColormapSlider(String paramString1, float[] paramArrayOffloat, String paramString2);
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   private static native boolean nColormapSlider(String paramString1, float[] paramArrayOffloat, String paramString2, int paramInt);
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   private static native boolean nColormapSlider(String paramString, float[] paramArrayOffloat, int paramInt);
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static boolean colormapButton(String label) {
/* 20593 */     return nColormapButton(label);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static boolean colormapButton(String label, ImVec2 size) {
/* 20600 */     return nColormapButton(label, size.x, size.y);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static boolean colormapButton(String label, float sizeX, float sizeY) {
/* 20607 */     return nColormapButton(label, sizeX, sizeY);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static boolean colormapButton(String label, ImVec2 size, int cmap) {
/* 20614 */     return nColormapButton(label, size.x, size.y, cmap);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static boolean colormapButton(String label, float sizeX, float sizeY, int cmap) {
/* 20621 */     return nColormapButton(label, sizeX, sizeY, cmap);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static boolean colormapButton(String label, int cmap) {
/* 20628 */     return nColormapButton(label, cmap);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   private static native boolean nColormapButton(String paramString);
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   private static native boolean nColormapButton(String paramString, float paramFloat1, float paramFloat2);
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   private static native boolean nColormapButton(String paramString, float paramFloat1, float paramFloat2, int paramInt);
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   private static native boolean nColormapButton(String paramString, int paramInt);
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static void bustColorCache() {
/* 20671 */     nBustColorCache();
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static void bustColorCache(String plotTitleId) {
/* 20684 */     nBustColorCache(plotTitleId);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/* 20701 */   private static final ImPlotInputMap _GETINPUTMAP_1 = new ImPlotInputMap(0L);
/*       */ 
/*       */   
/*       */   private static native void nBustColorCache();
/*       */   
/*       */   public static ImPlotInputMap getInputMap() {
/* 20707 */     _GETINPUTMAP_1.ptr = nGetInputMap();
/* 20708 */     return _GETINPUTMAP_1;
/*       */   }
/*       */ 
/*       */ 
/*       */   
/*       */   private static native void nBustColorCache(String paramString);
/*       */ 
/*       */   
/*       */   private static native long nGetInputMap();
/*       */ 
/*       */   
/*       */   public static void mapInputDefault() {
/* 20720 */     nMapInputDefault();
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static void mapInputDefault(ImPlotInputMap dst) {
/* 20728 */     nMapInputDefault(dst.ptr);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   private static native void nMapInputDefault();
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   private static native void nMapInputDefault(long paramLong);
/*       */ 
/*       */ 
/*       */   
/*       */   public static void mapInputReverse() {
/* 20744 */     nMapInputReverse();
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static void mapInputReverse(ImPlotInputMap dst) {
/* 20752 */     nMapInputReverse(dst.ptr);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   private static native void nMapInputReverse();
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   private static native void nMapInputReverse(long paramLong);
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static void itemIcon(ImVec4 col) {
/* 20770 */     nItemIcon(col.x, col.y, col.z, col.w);
/*       */   }
/*       */   
/*       */   public static void itemIcon(float colX, float colY, float colZ, float colW) {
/* 20774 */     nItemIcon(colX, colY, colZ, colW);
/*       */   }
/*       */ 
/*       */ 
/*       */   
/*       */   private static native void nItemIcon(float paramFloat1, float paramFloat2, float paramFloat3, float paramFloat4);
/*       */ 
/*       */   
/*       */   public static void itemIcon(int col) {
/* 20783 */     nItemIcon(col);
/*       */   }
/*       */ 
/*       */   
/*       */   private static native void nItemIcon(int paramInt);
/*       */ 
/*       */   
/*       */   public static void colormapIcon(int cmap) {
/* 20791 */     nColormapIcon(cmap);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   private static native void nColormapIcon(int paramInt);
/*       */ 
/*       */ 
/*       */   
/*       */   public static ImDrawList getPlotDrawList() {
/* 20802 */     return new ImDrawList(nGetPlotDrawList());
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   private static native long nGetPlotDrawList();
/*       */ 
/*       */ 
/*       */   
/*       */   public static void pushPlotClipRect() {
/* 20813 */     nPushPlotClipRect();
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static void pushPlotClipRect(float expand) {
/* 20820 */     nPushPlotClipRect(expand);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   private static native void nPushPlotClipRect();
/*       */ 
/*       */ 
/*       */   
/*       */   private static native void nPushPlotClipRect(float paramFloat);
/*       */ 
/*       */ 
/*       */   
/*       */   public static void popPlotClipRect() {
/* 20835 */     nPopPlotClipRect();
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   private static native void nPopPlotClipRect();
/*       */ 
/*       */ 
/*       */   
/*       */   public static boolean showStyleSelector(String label) {
/* 20846 */     return nShowStyleSelector(label);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   private static native boolean nShowStyleSelector(String paramString);
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static boolean showColormapSelector(String label) {
/* 20860 */     return nShowColormapSelector(label);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   private static native boolean nShowColormapSelector(String paramString);
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static boolean showInputMapSelector(String label) {
/* 20874 */     return nShowInputMapSelector(label);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   private static native boolean nShowInputMapSelector(String paramString);
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static void showStyleEditor() {
/* 20888 */     nShowStyleEditor();
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static void showStyleEditor(ImPlotStyle ref) {
/* 20895 */     nShowStyleEditor(ref.ptr);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   private static native void nShowStyleEditor();
/*       */ 
/*       */ 
/*       */   
/*       */   private static native void nShowStyleEditor(long paramLong);
/*       */ 
/*       */ 
/*       */   
/*       */   public static void showUserGuide() {
/* 20910 */     nShowUserGuide();
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   private static native void nShowUserGuide();
/*       */ 
/*       */ 
/*       */   
/*       */   public static void showMetricsWindow() {
/* 20921 */     nShowMetricsWindow();
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static void showMetricsWindow(ImBoolean pOpen) {
/* 20928 */     nShowMetricsWindow((pOpen != null) ? pOpen.getData() : null);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   private static native void nShowMetricsWindow();
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   private static native void nShowMetricsWindow(boolean[] paramArrayOfboolean);
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static void showDemoWindow() {
/* 20949 */     nShowDemoWindow();
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static void showDemoWindow(ImBoolean pOpen) {
/* 20956 */     nShowDemoWindow((pOpen != null) ? pOpen.getData() : null);
/*       */   }
/*       */   
/*       */   private static native void nShowDemoWindow();
/*       */   
/*       */   private static native void nShowDemoWindow(boolean[] paramArrayOfboolean);
/*       */ }


/* Location:              C:\Users\rapha\Downloads\aurora.jar!\META-INF\jars\imgui-java-binding-1.90.0.jar!\imgui\extension\implot\ImPlot.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */