/*     */ package imgui.extension.implot;
/*     */ 
/*     */ import imgui.ImVec2;
/*     */ import java.util.Objects;
/*     */ 
/*     */ public final class ImPlotRect
/*     */   implements Cloneable {
/*   8 */   public final ImPlotRange x = new ImPlotRange();
/*   9 */   public final ImPlotRange y = new ImPlotRange();
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ImPlotRect(double xMin, double yMin, double xMax, double yMax) {
/*  15 */     set(xMin, yMin, xMax, yMax);
/*     */   }
/*     */   
/*     */   public ImPlotRect(ImVec2 min, ImVec2 max) {
/*  19 */     set(min, max);
/*     */   }
/*     */   
/*     */   public ImPlotRect(ImPlotRect value) {
/*  23 */     set(value);
/*     */   }
/*     */   
/*     */   public boolean contains(double x, double y) {
/*  27 */     return (this.x.contains(x) && this.y.contains(y));
/*     */   }
/*     */   
/*     */   public boolean contains(ImPlotPoint value) {
/*  31 */     return contains(value.x, value.y);
/*     */   }
/*     */   
/*     */   public ImPlotPoint size() {
/*  35 */     return new ImPlotPoint(this.x.size(), this.y.size());
/*     */   }
/*     */   
/*     */   public ImPlotPoint clamp(double x, double y) {
/*  39 */     return new ImPlotPoint(this.x.clamp(x), this.y.clamp(y));
/*     */   }
/*     */   
/*     */   public ImPlotPoint clamp(ImPlotPoint p) {
/*  43 */     return clamp(p.x, p.y);
/*     */   }
/*     */   
/*     */   public ImPlotPoint min() {
/*  47 */     return new ImPlotPoint(this.x.min, this.y.min);
/*     */   }
/*     */   
/*     */   public ImPlotPoint max() {
/*  51 */     return new ImPlotPoint(this.x.max, this.y.max);
/*     */   }
/*     */   
/*     */   public void set(double xMin, double yMin, double xMax, double yMax) {
/*  55 */     this.x.min = xMin;
/*  56 */     this.x.max = xMax;
/*  57 */     this.y.min = yMin;
/*  58 */     this.y.max = yMax;
/*     */   }
/*     */   
/*     */   public void set(ImVec2 min, ImVec2 max) {
/*  62 */     set(min.x, min.y, max.x, max.y);
/*     */   }
/*     */   
/*     */   public void set(ImPlotRange x, ImPlotRange y) {
/*  66 */     set(x.min, y.min, x.max, y.max);
/*     */   }
/*     */   
/*     */   public void set(ImPlotRect value) {
/*  70 */     set(value.x, value.y);
/*     */   }
/*     */ 
/*     */   
/*     */   public String toString() {
/*  75 */     return "ImPlotRect{x=" + this.x + ", y=" + this.y + '}';
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean equals(Object o) {
/*  83 */     if (this == o) {
/*  84 */       return true;
/*     */     }
/*     */     
/*  87 */     if (o == null || getClass() != o.getClass()) {
/*  88 */       return false;
/*     */     }
/*     */     
/*  91 */     ImPlotRect imPlotRect = (ImPlotRect)o;
/*  92 */     return (Objects.equals(this.x, imPlotRect.x) && Objects.equals(this.y, imPlotRect.y));
/*     */   }
/*     */ 
/*     */   
/*     */   public int hashCode() {
/*  97 */     return Objects.hash(new Object[] { this.x, this.y });
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public ImPlotRect clone() {
/* 103 */     return new ImPlotRect(this);
/*     */   }
/*     */   
/*     */   public ImPlotRect() {}
/*     */ }


/* Location:              C:\Users\rapha\Downloads\aurora.jar!\META-INF\jars\imgui-java-binding-1.90.0.jar!\imgui\extension\implot\ImPlotRect.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */