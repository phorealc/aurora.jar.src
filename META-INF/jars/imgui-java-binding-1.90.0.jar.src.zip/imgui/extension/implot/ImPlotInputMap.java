/*     */ package imgui.extension.implot;
/*     */ 
/*     */ import imgui.binding.ImGuiStructDestroyable;
/*     */ 
/*     */ public final class ImPlotInputMap
/*     */   extends ImGuiStructDestroyable
/*     */ {
/*     */   public ImPlotInputMap() {}
/*     */   
/*     */   public ImPlotInputMap(long ptr) {
/*  11 */     super(ptr);
/*     */   }
/*     */ 
/*     */   
/*     */   protected long create() {
/*  16 */     return nCreate();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private native long nCreate();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int getPan() {
/*  32 */     return nGetPan();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setPan(int value) {
/*  39 */     nSetPan(value);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private native int nGetPan();
/*     */ 
/*     */ 
/*     */   
/*     */   private native void nSetPan(int paramInt);
/*     */ 
/*     */ 
/*     */   
/*     */   public int getPanMod() {
/*  54 */     return nGetPanMod();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setPanMod(int value) {
/*  61 */     nSetPanMod(value);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private native int nGetPanMod();
/*     */ 
/*     */ 
/*     */   
/*     */   private native void nSetPanMod(int paramInt);
/*     */ 
/*     */ 
/*     */   
/*     */   public int getFit() {
/*  76 */     return nGetFit();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setFit(int value) {
/*  83 */     nSetFit(value);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private native int nGetFit();
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private native void nSetFit(int paramInt);
/*     */ 
/*     */ 
/*     */   
/*     */   public int getSelect() {
/*  99 */     return nGetSelect();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setSelect(int value) {
/* 107 */     nSetSelect(value);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private native int nGetSelect();
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private native void nSetSelect(int paramInt);
/*     */ 
/*     */ 
/*     */   
/*     */   public int getSelectCancel() {
/* 123 */     return nGetSelectCancel();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setSelectCancel(int value) {
/* 131 */     nSetSelectCancel(value);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private native int nGetSelectCancel();
/*     */ 
/*     */ 
/*     */   
/*     */   private native void nSetSelectCancel(int paramInt);
/*     */ 
/*     */ 
/*     */   
/*     */   public int getSelectMod() {
/* 146 */     return nGetSelectMod();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setSelectMod(int value) {
/* 153 */     nSetSelectMod(value);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private native int nGetSelectMod();
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private native void nSetSelectMod(int paramInt);
/*     */ 
/*     */ 
/*     */   
/*     */   public int getSelectHorzMod() {
/* 169 */     return nGetSelectHorzMod();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setSelectHorzMod(int value) {
/* 177 */     nSetSelectHorzMod(value);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private native int nGetSelectHorzMod();
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private native void nSetSelectHorzMod(int paramInt);
/*     */ 
/*     */ 
/*     */   
/*     */   public int getSelectVertMod() {
/* 193 */     return nGetSelectVertMod();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setSelectVertMod(int value) {
/* 201 */     nSetSelectVertMod(value);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private native int nGetSelectVertMod();
/*     */ 
/*     */ 
/*     */   
/*     */   private native void nSetSelectVertMod(int paramInt);
/*     */ 
/*     */ 
/*     */   
/*     */   public int getMenu() {
/* 216 */     return nGetMenu();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setMenu(int value) {
/* 223 */     nSetMenu(value);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private native int nGetMenu();
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private native void nSetMenu(int paramInt);
/*     */ 
/*     */ 
/*     */   
/*     */   public int getOverrideMod() {
/* 239 */     return nGetOverrideMod();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setOverrideMod(int value) {
/* 247 */     nSetOverrideMod(value);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private native int nGetOverrideMod();
/*     */ 
/*     */ 
/*     */   
/*     */   private native void nSetOverrideMod(int paramInt);
/*     */ 
/*     */ 
/*     */   
/*     */   public int getZoomMod() {
/* 262 */     return nGetZoomMod();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setZoomMod(int value) {
/* 269 */     nSetZoomMod(value);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private native int nGetZoomMod();
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private native void nSetZoomMod(int paramInt);
/*     */ 
/*     */ 
/*     */   
/*     */   public float getZoomRate() {
/* 285 */     return nGetZoomRate();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setZoomRate(float value) {
/* 293 */     nSetZoomRate(value);
/*     */   }
/*     */   
/*     */   private native float nGetZoomRate();
/*     */   
/*     */   private native void nSetZoomRate(float paramFloat);
/*     */ }


/* Location:              C:\Users\rapha\Downloads\aurora.jar!\META-INF\jars\imgui-java-binding-1.90.0.jar!\imgui\extension\implot\ImPlotInputMap.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */