/*     */ package imgui.extension.implot;
/*     */ 
/*     */ import java.util.Objects;
/*     */ 
/*     */ public final class ImPlotRange
/*     */   implements Cloneable {
/*     */   public double min;
/*     */   public double max;
/*     */   
/*     */   public ImPlotRange() {}
/*     */   
/*     */   public ImPlotRange(double min, double max) {
/*  13 */     set(min, max);
/*     */   }
/*     */   
/*     */   public ImPlotRange(ImPlotRange value) {
/*  17 */     set(value.min, value.max);
/*     */   }
/*     */   
/*     */   public boolean contains(double value) {
/*  21 */     return (value >= this.min && value <= this.max);
/*     */   }
/*     */   
/*     */   public double size() {
/*  25 */     return this.max - this.min;
/*     */   }
/*     */   
/*     */   public double clamp(double value) {
/*  29 */     return Math.max(this.min, Math.min(this.max, value));
/*     */   }
/*     */   
/*     */   public ImPlotRange set(double min, double max) {
/*  33 */     this.min = min;
/*  34 */     this.max = max;
/*  35 */     return this;
/*     */   }
/*     */   
/*     */   public ImPlotRange set(ImPlotRange value) {
/*  39 */     return set(value.min, value.max);
/*     */   }
/*     */   
/*     */   public ImPlotRange plus(double min, double max) {
/*  43 */     this.min += min;
/*  44 */     this.max += max;
/*  45 */     return this;
/*     */   }
/*     */   
/*     */   public ImPlotRange plus(ImPlotRange value) {
/*  49 */     return plus(value.min, value.max);
/*     */   }
/*     */   
/*     */   public ImPlotRange minus(double min, double max) {
/*  53 */     this.min -= min;
/*  54 */     this.max -= max;
/*  55 */     return this;
/*     */   }
/*     */   
/*     */   public ImPlotRange minus(ImPlotRange value) {
/*  59 */     return minus(value.min, value.max);
/*     */   }
/*     */   
/*     */   public ImPlotRange times(double min, double max) {
/*  63 */     this.min *= min;
/*  64 */     this.max *= max;
/*  65 */     return this;
/*     */   }
/*     */   
/*     */   public ImPlotRange times(ImPlotRange value) {
/*  69 */     return times(value.min, value.max);
/*     */   }
/*     */ 
/*     */   
/*     */   public String toString() {
/*  74 */     return "ImPlotRange{min=" + this.min + ", max=" + this.max + '}';
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean equals(Object o) {
/*  82 */     if (this == o) {
/*  83 */       return true;
/*     */     }
/*  85 */     if (o == null || getClass() != o.getClass()) {
/*  86 */       return false;
/*     */     }
/*  88 */     ImPlotRange imPlotRange = (ImPlotRange)o;
/*  89 */     return (Double.compare(imPlotRange.min, this.min) == 0 && Double.compare(imPlotRange.max, this.max) == 0);
/*     */   }
/*     */ 
/*     */   
/*     */   public int hashCode() {
/*  94 */     return Objects.hash(new Object[] { Double.valueOf(this.min), Double.valueOf(this.max) });
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public ImPlotRange clone() {
/* 100 */     return new ImPlotRange(this);
/*     */   }
/*     */ }


/* Location:              C:\Users\rapha\Downloads\aurora.jar!\META-INF\jars\imgui-java-binding-1.90.0.jar!\imgui\extension\implot\ImPlotRange.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */