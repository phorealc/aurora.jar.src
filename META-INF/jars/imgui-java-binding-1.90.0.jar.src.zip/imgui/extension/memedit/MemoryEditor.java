/*     */ package imgui.extension.memedit;
/*     */ 
/*     */ import imgui.binding.ImGuiStructDestroyable;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class MemoryEditor
/*     */   extends ImGuiStructDestroyable
/*     */ {
/*     */   public MemoryEditor() {}
/*     */   
/*     */   public MemoryEditor(long ptr) {
/*  15 */     super(ptr);
/*     */   }
/*     */ 
/*     */   
/*     */   protected long create() {
/*  20 */     return nCreate();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private native long nCreate();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean getOpen() {
/*  34 */     return nGetOpen();
/*     */   }
/*     */   
/*     */   public void setOpen(boolean value) {
/*  38 */     nSetOpen(value);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private native boolean nGetOpen();
/*     */ 
/*     */   
/*     */   private native void nSetOpen(boolean paramBoolean);
/*     */ 
/*     */   
/*     */   public boolean getReadOnly() {
/*  50 */     return nGetReadOnly();
/*     */   }
/*     */   
/*     */   public void setReadOnly(boolean value) {
/*  54 */     nSetReadOnly(value);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private native boolean nGetReadOnly();
/*     */ 
/*     */   
/*     */   private native void nSetReadOnly(boolean paramBoolean);
/*     */ 
/*     */   
/*     */   public int getCols() {
/*  66 */     return nGetCols();
/*     */   }
/*     */   
/*     */   public void setCols(int value) {
/*  70 */     nSetCols(value);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private native int nGetCols();
/*     */ 
/*     */   
/*     */   private native void nSetCols(int paramInt);
/*     */ 
/*     */   
/*     */   public boolean getOptShowOptions() {
/*  82 */     return nGetOptShowOptions();
/*     */   }
/*     */   
/*     */   public void setOptShowOptions(boolean value) {
/*  86 */     nSetOptShowOptions(value);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private native boolean nGetOptShowOptions();
/*     */ 
/*     */   
/*     */   private native void nSetOptShowOptions(boolean paramBoolean);
/*     */ 
/*     */   
/*     */   public boolean getOptShowDataPreview() {
/*  98 */     return nGetOptShowDataPreview();
/*     */   }
/*     */   
/*     */   public void setOptShowDataPreview(boolean value) {
/* 102 */     nSetOptShowDataPreview(value);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private native boolean nGetOptShowDataPreview();
/*     */ 
/*     */   
/*     */   private native void nSetOptShowDataPreview(boolean paramBoolean);
/*     */ 
/*     */   
/*     */   public boolean getOptShowHexII() {
/* 114 */     return nGetOptShowHexII();
/*     */   }
/*     */   
/*     */   public void setOptShowHexII(boolean value) {
/* 118 */     nSetOptShowHexII(value);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private native boolean nGetOptShowHexII();
/*     */ 
/*     */   
/*     */   private native void nSetOptShowHexII(boolean paramBoolean);
/*     */ 
/*     */   
/*     */   public boolean getOptShowAscii() {
/* 130 */     return nGetOptShowAscii();
/*     */   }
/*     */   
/*     */   public void setOptShowAscii(boolean value) {
/* 134 */     nSetOptShowAscii(value);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private native boolean nGetOptShowAscii();
/*     */ 
/*     */   
/*     */   private native void nSetOptShowAscii(boolean paramBoolean);
/*     */ 
/*     */   
/*     */   public boolean getOptGreyOutZeroes() {
/* 146 */     return nGetOptGreyOutZeroes();
/*     */   }
/*     */   
/*     */   public void setOptGreyOutZeroes(boolean value) {
/* 150 */     nSetOptGreyOutZeroes(value);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private native boolean nGetOptGreyOutZeroes();
/*     */ 
/*     */   
/*     */   private native void nSetOptGreyOutZeroes(boolean paramBoolean);
/*     */ 
/*     */   
/*     */   public boolean getOptUpperCaseHex() {
/* 162 */     return nGetOptUpperCaseHex();
/*     */   }
/*     */   
/*     */   public void setOptUpperCaseHex(boolean value) {
/* 166 */     nSetOptUpperCaseHex(value);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private native boolean nGetOptUpperCaseHex();
/*     */ 
/*     */   
/*     */   private native void nSetOptUpperCaseHex(boolean paramBoolean);
/*     */ 
/*     */   
/*     */   public int getOptMidColsCount() {
/* 178 */     return nGetOptMidColsCount();
/*     */   }
/*     */   
/*     */   public void setOptMidColsCount(int value) {
/* 182 */     nSetOptMidColsCount(value);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private native int nGetOptMidColsCount();
/*     */ 
/*     */   
/*     */   private native void nSetOptMidColsCount(int paramInt);
/*     */ 
/*     */   
/*     */   public int getOptAddrDigitsCount() {
/* 194 */     return nGetOptAddrDigitsCount();
/*     */   }
/*     */   
/*     */   public void setOptAddrDigitsCount(int value) {
/* 198 */     nSetOptAddrDigitsCount(value);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private native int nGetOptAddrDigitsCount();
/*     */ 
/*     */   
/*     */   private native void nSetOptAddrDigitsCount(int paramInt);
/*     */ 
/*     */   
/*     */   public float getOptFooterExtraHeight() {
/* 210 */     return nGetOptFooterExtraHeight();
/*     */   }
/*     */   
/*     */   public void setOptFooterExtraHeight(float value) {
/* 214 */     nSetOptFooterExtraHeight(value);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private native float nGetOptFooterExtraHeight();
/*     */ 
/*     */   
/*     */   private native void nSetOptFooterExtraHeight(float paramFloat);
/*     */ 
/*     */   
/*     */   public int getHighlightColor() {
/* 226 */     return nGetHighlightColor();
/*     */   }
/*     */   
/*     */   public void setHighlightColor(int value) {
/* 230 */     nSetHighlightColor(value);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private native int nGetHighlightColor();
/*     */ 
/*     */   
/*     */   private native void nSetHighlightColor(int paramInt);
/*     */ 
/*     */   
/*     */   public void gotoAddrAndHighlight(long addrMin, long addrMax) {
/* 242 */     nGotoAddrAndHighlight(addrMin, addrMax);
/*     */   }
/*     */ 
/*     */   
/*     */   private native void nGotoAddrAndHighlight(long paramLong1, long paramLong2);
/*     */ 
/*     */   
/*     */   public void calcSizes(MemoryEditorSizes s, long memSize, long baseDisplayAddr) {
/* 250 */     nCalcSizes(s.ptr, memSize, baseDisplayAddr);
/*     */   }
/*     */ 
/*     */   
/*     */   private native void nCalcSizes(long paramLong1, long paramLong2, long paramLong3);
/*     */ 
/*     */   
/*     */   public void drawWindow(String title, long memData, long memSize) {
/* 258 */     nDrawWindow(title, memData, memSize);
/*     */   }
/*     */   
/*     */   public void drawWindow(String title, long memData, long memSize, long baseDisplayAddr) {
/* 262 */     nDrawWindow(title, memData, memSize, baseDisplayAddr);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private native void nDrawWindow(String paramString, long paramLong1, long paramLong2);
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private native void nDrawWindow(String paramString, long paramLong1, long paramLong2, long paramLong3);
/*     */ 
/*     */ 
/*     */   
/*     */   public void drawContents(long memData, long memSize) {
/* 278 */     nDrawContents(memData, memSize);
/*     */   }
/*     */   
/*     */   public void drawContents(long memData, long memSize, long baseDisplayAddr) {
/* 282 */     nDrawContents(memData, memSize, baseDisplayAddr);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private native void nDrawContents(long paramLong1, long paramLong2);
/*     */ 
/*     */   
/*     */   private native void nDrawContents(long paramLong1, long paramLong2, long paramLong3);
/*     */ 
/*     */   
/*     */   public void drawOptionsLine(MemoryEditorSizes s, long memData, long memSize, long baseDisplayAddr) {
/* 294 */     nDrawOptionsLine(s.ptr, memData, memSize, baseDisplayAddr);
/*     */   }
/*     */ 
/*     */   
/*     */   private native void nDrawOptionsLine(long paramLong1, long paramLong2, long paramLong3, long paramLong4);
/*     */ 
/*     */   
/*     */   public void drawPreviewLine(MemoryEditorSizes s, long memDataVoid, long memSize, long baseDisplayAddr) {
/* 302 */     nDrawPreviewLine(s.ptr, memDataVoid, memSize, baseDisplayAddr);
/*     */   }
/*     */   
/*     */   private native void nDrawPreviewLine(long paramLong1, long paramLong2, long paramLong3, long paramLong4);
/*     */ }


/* Location:              C:\Users\rapha\Downloads\aurora.jar!\META-INF\jars\imgui-java-binding-1.90.0.jar!\imgui\extension\memedit\MemoryEditor.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */