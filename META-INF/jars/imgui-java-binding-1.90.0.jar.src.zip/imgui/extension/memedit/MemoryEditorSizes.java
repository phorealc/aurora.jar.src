/*     */ package imgui.extension.memedit;
/*     */ 
/*     */ import imgui.binding.ImGuiStructDestroyable;
/*     */ 
/*     */ public final class MemoryEditorSizes
/*     */   extends ImGuiStructDestroyable
/*     */ {
/*     */   public MemoryEditorSizes() {}
/*     */   
/*     */   public MemoryEditorSizes(long ptr) {
/*  11 */     super(ptr);
/*     */   }
/*     */ 
/*     */   
/*     */   protected long create() {
/*  16 */     return nCreate();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private native long nCreate();
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int getAddrDigitsCount() {
/*  29 */     return nGetAddrDigitsCount();
/*     */   }
/*     */   
/*     */   public void setAddrDigitsCount(int value) {
/*  33 */     nSetAddrDigitsCount(value);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private native int nGetAddrDigitsCount();
/*     */ 
/*     */   
/*     */   private native void nSetAddrDigitsCount(int paramInt);
/*     */ 
/*     */   
/*     */   public float getLineHeight() {
/*  45 */     return nGetLineHeight();
/*     */   }
/*     */   
/*     */   public void setLineHeight(float value) {
/*  49 */     nSetLineHeight(value);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private native float nGetLineHeight();
/*     */ 
/*     */   
/*     */   private native void nSetLineHeight(float paramFloat);
/*     */ 
/*     */   
/*     */   public float getGlyphWidth() {
/*  61 */     return nGetGlyphWidth();
/*     */   }
/*     */   
/*     */   public void setGlyphWidth(float value) {
/*  65 */     nSetGlyphWidth(value);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private native float nGetGlyphWidth();
/*     */ 
/*     */   
/*     */   private native void nSetGlyphWidth(float paramFloat);
/*     */ 
/*     */   
/*     */   public float getHexCellWidth() {
/*  77 */     return nGetHexCellWidth();
/*     */   }
/*     */   
/*     */   public void setHexCellWidth(float value) {
/*  81 */     nSetHexCellWidth(value);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private native float nGetHexCellWidth();
/*     */ 
/*     */   
/*     */   private native void nSetHexCellWidth(float paramFloat);
/*     */ 
/*     */   
/*     */   public float getSpacingBetweenMidCols() {
/*  93 */     return nGetSpacingBetweenMidCols();
/*     */   }
/*     */   
/*     */   public void setSpacingBetweenMidCols(float value) {
/*  97 */     nSetSpacingBetweenMidCols(value);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private native float nGetSpacingBetweenMidCols();
/*     */ 
/*     */   
/*     */   private native void nSetSpacingBetweenMidCols(float paramFloat);
/*     */ 
/*     */   
/*     */   public float getPosHexStart() {
/* 109 */     return nGetPosHexStart();
/*     */   }
/*     */   
/*     */   public void setPosHexStart(float value) {
/* 113 */     nSetPosHexStart(value);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private native float nGetPosHexStart();
/*     */ 
/*     */   
/*     */   private native void nSetPosHexStart(float paramFloat);
/*     */ 
/*     */   
/*     */   public float getPosHexEnd() {
/* 125 */     return nGetPosHexEnd();
/*     */   }
/*     */   
/*     */   public void setPosHexEnd(float value) {
/* 129 */     nSetPosHexEnd(value);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private native float nGetPosHexEnd();
/*     */ 
/*     */   
/*     */   private native void nSetPosHexEnd(float paramFloat);
/*     */ 
/*     */   
/*     */   public float getPosAsciiStart() {
/* 141 */     return nGetPosAsciiStart();
/*     */   }
/*     */   
/*     */   public void setPosAsciiStart(float value) {
/* 145 */     nSetPosAsciiStart(value);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private native float nGetPosAsciiStart();
/*     */ 
/*     */   
/*     */   private native void nSetPosAsciiStart(float paramFloat);
/*     */ 
/*     */   
/*     */   public float getPosAsciiEnd() {
/* 157 */     return nGetPosAsciiEnd();
/*     */   }
/*     */   
/*     */   public void setPosAsciiEnd(float value) {
/* 161 */     nSetPosAsciiEnd(value);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private native float nGetPosAsciiEnd();
/*     */ 
/*     */   
/*     */   private native void nSetPosAsciiEnd(float paramFloat);
/*     */ 
/*     */   
/*     */   public float getWindowWidth() {
/* 173 */     return nGetWindowWidth();
/*     */   }
/*     */   
/*     */   public void setWindowWidth(float value) {
/* 177 */     nSetWindowWidth(value);
/*     */   }
/*     */   
/*     */   private native float nGetWindowWidth();
/*     */   
/*     */   private native void nSetWindowWidth(float paramFloat);
/*     */ }


/* Location:              C:\Users\rapha\Downloads\aurora.jar!\META-INF\jars\imgui-java-binding-1.90.0.jar!\imgui\extension\memedit\MemoryEditorSizes.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */