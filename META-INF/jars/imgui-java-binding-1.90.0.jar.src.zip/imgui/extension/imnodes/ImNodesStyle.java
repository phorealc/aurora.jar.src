/*     */ package imgui.extension.imnodes;
/*     */ 
/*     */ import imgui.ImVec2;
/*     */ import imgui.binding.ImGuiStruct;
/*     */ 
/*     */ public final class ImNodesStyle
/*     */   extends ImGuiStruct {
/*     */   public ImNodesStyle(long ptr) {
/*   9 */     super(ptr);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public float getGridSpacing() {
/*  18 */     return nGetGridSpacing();
/*     */   }
/*     */   
/*     */   public void setGridSpacing(float value) {
/*  22 */     nSetGridSpacing(value);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private native float nGetGridSpacing();
/*     */ 
/*     */   
/*     */   private native void nSetGridSpacing(float paramFloat);
/*     */ 
/*     */   
/*     */   public float getNodeCornerRounding() {
/*  34 */     return nGetNodeCornerRounding();
/*     */   }
/*     */   
/*     */   public void setNodeCornerRounding(float value) {
/*  38 */     nSetNodeCornerRounding(value);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private native float nGetNodeCornerRounding();
/*     */ 
/*     */   
/*     */   private native void nSetNodeCornerRounding(float paramFloat);
/*     */ 
/*     */   
/*     */   public ImVec2 getNodePadding() {
/*  50 */     ImVec2 dst = new ImVec2();
/*  51 */     nGetNodePadding(dst);
/*  52 */     return dst;
/*     */   }
/*     */   
/*     */   public float getNodePaddingX() {
/*  56 */     return nGetNodePaddingX();
/*     */   }
/*     */   
/*     */   public float getNodePaddingY() {
/*  60 */     return nGetNodePaddingY();
/*     */   }
/*     */   
/*     */   public void getNodePadding(ImVec2 dst) {
/*  64 */     nGetNodePadding(dst);
/*     */   }
/*     */   
/*     */   public void setNodePadding(ImVec2 value) {
/*  68 */     nSetNodePadding(value.x, value.y);
/*     */   }
/*     */   
/*     */   public void setNodePadding(float valueX, float valueY) {
/*  72 */     nSetNodePadding(valueX, valueY);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private native void nGetNodePadding(ImVec2 paramImVec2);
/*     */ 
/*     */ 
/*     */   
/*     */   private native float nGetNodePaddingX();
/*     */ 
/*     */ 
/*     */   
/*     */   private native float nGetNodePaddingY();
/*     */ 
/*     */ 
/*     */   
/*     */   private native void nSetNodePadding(float paramFloat1, float paramFloat2);
/*     */ 
/*     */   
/*     */   public float getNodeBorderThickness() {
/*  93 */     return nGetNodeBorderThickness();
/*     */   }
/*     */   
/*     */   public void setNodeBorderThickness(float value) {
/*  97 */     nSetNodeBorderThickness(value);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private native float nGetNodeBorderThickness();
/*     */ 
/*     */   
/*     */   private native void nSetNodeBorderThickness(float paramFloat);
/*     */ 
/*     */   
/*     */   public float getLinkThickness() {
/* 109 */     return nGetLinkThickness();
/*     */   }
/*     */   
/*     */   public void setLinkThickness(float value) {
/* 113 */     nSetLinkThickness(value);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private native float nGetLinkThickness();
/*     */ 
/*     */   
/*     */   private native void nSetLinkThickness(float paramFloat);
/*     */ 
/*     */   
/*     */   public float getLinkLineSegmentsPerLength() {
/* 125 */     return nGetLinkLineSegmentsPerLength();
/*     */   }
/*     */   
/*     */   public void setLinkLineSegmentsPerLength(float value) {
/* 129 */     nSetLinkLineSegmentsPerLength(value);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private native float nGetLinkLineSegmentsPerLength();
/*     */ 
/*     */   
/*     */   private native void nSetLinkLineSegmentsPerLength(float paramFloat);
/*     */ 
/*     */   
/*     */   public float getLinkHoverDistance() {
/* 141 */     return nGetLinkHoverDistance();
/*     */   }
/*     */   
/*     */   public void setLinkHoverDistance(float value) {
/* 145 */     nSetLinkHoverDistance(value);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private native float nGetLinkHoverDistance();
/*     */ 
/*     */ 
/*     */   
/*     */   private native void nSetLinkHoverDistance(float paramFloat);
/*     */ 
/*     */ 
/*     */   
/*     */   public float getPinCircleRadius() {
/* 160 */     return nGetPinCircleRadius();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setPinCircleRadius(float value) {
/* 167 */     nSetPinCircleRadius(value);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private native float nGetPinCircleRadius();
/*     */ 
/*     */ 
/*     */   
/*     */   private native void nSetPinCircleRadius(float paramFloat);
/*     */ 
/*     */ 
/*     */   
/*     */   public float getPinQuadSideLength() {
/* 182 */     return nGetPinQuadSideLength();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setPinQuadSideLength(float value) {
/* 189 */     nSetPinQuadSideLength(value);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private native float nGetPinQuadSideLength();
/*     */ 
/*     */ 
/*     */   
/*     */   private native void nSetPinQuadSideLength(float paramFloat);
/*     */ 
/*     */ 
/*     */   
/*     */   public float getPinTriangleSideLength() {
/* 204 */     return nGetPinTriangleSideLength();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setPinTriangleSideLength(float value) {
/* 211 */     nSetPinTriangleSideLength(value);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private native float nGetPinTriangleSideLength();
/*     */ 
/*     */ 
/*     */   
/*     */   private native void nSetPinTriangleSideLength(float paramFloat);
/*     */ 
/*     */ 
/*     */   
/*     */   public float getPinLineThickness() {
/* 226 */     return nGetPinLineThickness();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setPinLineThickness(float value) {
/* 233 */     nSetPinLineThickness(value);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private native float nGetPinLineThickness();
/*     */ 
/*     */ 
/*     */   
/*     */   private native void nSetPinLineThickness(float paramFloat);
/*     */ 
/*     */ 
/*     */   
/*     */   public float getPinHoverRadius() {
/* 248 */     return nGetPinHoverRadius();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setPinHoverRadius(float value) {
/* 255 */     nSetPinHoverRadius(value);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private native float nGetPinHoverRadius();
/*     */ 
/*     */ 
/*     */   
/*     */   private native void nSetPinHoverRadius(float paramFloat);
/*     */ 
/*     */ 
/*     */   
/*     */   public float getPinOffset() {
/* 270 */     return nGetPinOffset();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setPinOffset(float value) {
/* 277 */     nSetPinOffset(value);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private native float nGetPinOffset();
/*     */ 
/*     */ 
/*     */   
/*     */   private native void nSetPinOffset(float paramFloat);
/*     */ 
/*     */ 
/*     */   
/*     */   public ImVec2 getMiniMapPadding() {
/* 292 */     ImVec2 dst = new ImVec2();
/* 293 */     nGetMiniMapPadding(dst);
/* 294 */     return dst;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public float getMiniMapPaddingX() {
/* 301 */     return nGetMiniMapPaddingX();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public float getMiniMapPaddingY() {
/* 308 */     return nGetMiniMapPaddingY();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void getMiniMapPadding(ImVec2 dst) {
/* 315 */     nGetMiniMapPadding(dst);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setMiniMapPadding(ImVec2 value) {
/* 322 */     nSetMiniMapPadding(value.x, value.y);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setMiniMapPadding(float valueX, float valueY) {
/* 329 */     nSetMiniMapPadding(valueX, valueY);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private native void nGetMiniMapPadding(ImVec2 paramImVec2);
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private native float nGetMiniMapPaddingX();
/*     */ 
/*     */ 
/*     */   
/*     */   private native float nGetMiniMapPaddingY();
/*     */ 
/*     */ 
/*     */   
/*     */   private native void nSetMiniMapPadding(float paramFloat1, float paramFloat2);
/*     */ 
/*     */ 
/*     */   
/*     */   public ImVec2 getMiniMapOffset() {
/* 353 */     ImVec2 dst = new ImVec2();
/* 354 */     nGetMiniMapOffset(dst);
/* 355 */     return dst;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public float getMiniMapOffsetX() {
/* 362 */     return nGetMiniMapOffsetX();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public float getMiniMapOffsetY() {
/* 369 */     return nGetMiniMapOffsetY();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void getMiniMapOffset(ImVec2 dst) {
/* 376 */     nGetMiniMapOffset(dst);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setMiniMapOffset(ImVec2 value) {
/* 383 */     nSetMiniMapOffset(value.x, value.y);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setMiniMapOffset(float valueX, float valueY) {
/* 390 */     nSetMiniMapOffset(valueX, valueY);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private native void nGetMiniMapOffset(ImVec2 paramImVec2);
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private native float nGetMiniMapOffsetX();
/*     */ 
/*     */ 
/*     */   
/*     */   private native float nGetMiniMapOffsetY();
/*     */ 
/*     */ 
/*     */   
/*     */   private native void nSetMiniMapOffset(float paramFloat1, float paramFloat2);
/*     */ 
/*     */ 
/*     */   
/*     */   public int getFlags() {
/* 414 */     return nGetFlags();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setFlags(int value) {
/* 421 */     nSetFlags(value);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void addFlags(int flags) {
/* 428 */     setFlags(getFlags() | flags);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void removeFlags(int flags) {
/* 435 */     setFlags(getFlags() & (flags ^ 0xFFFFFFFF));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean hasFlags(int flags) {
/* 442 */     return ((getFlags() & flags) != 0);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private native int nGetFlags();
/*     */ 
/*     */   
/*     */   private native void nSetFlags(int paramInt);
/*     */ 
/*     */   
/*     */   public int[] getColors() {
/* 454 */     return nGetColors();
/*     */   }
/*     */   
/*     */   public int getColors(int idx) {
/* 458 */     return nGetColors(idx);
/*     */   }
/*     */   
/*     */   public void setColors(int[] value) {
/* 462 */     nSetColors(value);
/*     */   }
/*     */   
/*     */   public void setColors(int idx, int value) {
/* 466 */     nSetColors(idx, value);
/*     */   }
/*     */   
/*     */   private native int[] nGetColors();
/*     */   
/*     */   private native int nGetColors(int paramInt);
/*     */   
/*     */   private native void nSetColors(int[] paramArrayOfint);
/*     */   
/*     */   private native void nSetColors(int paramInt1, int paramInt2);
/*     */ }


/* Location:              C:\Users\rapha\Downloads\aurora.jar!\META-INF\jars\imgui-java-binding-1.90.0.jar!\imgui\extension\imnodes\ImNodesStyle.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */