package imgui.extension.imnodes.flag;

public final class ImNodesMiniMapLocation {
  public static final int BottomLeft = 0;
  
  public static final int BottomRight = 1;
  
  public static final int TopLeft = 2;
  
  public static final int TopRight = 3;
}


/* Location:              C:\Users\rapha\Downloads\aurora.jar!\META-INF\jars\imgui-java-binding-1.90.0.jar!\imgui\extension\imnodes\flag\ImNodesMiniMapLocation.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */