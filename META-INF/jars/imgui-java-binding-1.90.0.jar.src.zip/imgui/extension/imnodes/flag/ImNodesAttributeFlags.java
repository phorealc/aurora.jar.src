package imgui.extension.imnodes.flag;

public final class ImNodesAttributeFlags {
  public static final int None = 0;
  
  public static final int EnableLinkDetachWithDragClick = 1;
  
  public static final int EnableLinkCreationOnSnap = 2;
}


/* Location:              C:\Users\rapha\Downloads\aurora.jar!\META-INF\jars\imgui-java-binding-1.90.0.jar!\imgui\extension\imnodes\flag\ImNodesAttributeFlags.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */