package imgui.extension.imnodes.flag;

public final class ImNodesPinShape {
  public static final int Circle = 0;
  
  public static final int CircleFilled = 1;
  
  public static final int Triangle = 2;
  
  public static final int TriangleFilled = 3;
  
  public static final int Quad = 4;
  
  public static final int QuadFilled = 5;
}


/* Location:              C:\Users\rapha\Downloads\aurora.jar!\META-INF\jars\imgui-java-binding-1.90.0.jar!\imgui\extension\imnodes\flag\ImNodesPinShape.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */