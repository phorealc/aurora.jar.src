package imgui.extension.imnodes.flag;

public final class ImNodesStyleFlags {
  public static final int None = 0;
  
  public static final int NodeOutline = 1;
  
  public static final int GridLines = 4;
  
  public static final int GridLinesPrimary = 8;
  
  public static final int GridSnapping = 16;
}


/* Location:              C:\Users\rapha\Downloads\aurora.jar!\META-INF\jars\imgui-java-binding-1.90.0.jar!\imgui\extension\imnodes\flag\ImNodesStyleFlags.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */