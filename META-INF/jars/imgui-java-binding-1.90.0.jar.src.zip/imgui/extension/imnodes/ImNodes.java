/*      */ package imgui.extension.imnodes;
/*      */ 
/*      */ import imgui.ImVec2;
/*      */ import imgui.internal.ImGuiContext;
/*      */ import imgui.type.ImBoolean;
/*      */ import imgui.type.ImInt;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ public final class ImNodes
/*      */ {
/*      */   public static void setImGuiContext(ImGuiContext ctx) {
/*   29 */     nSetImGuiContext(ctx.ptr);
/*      */   }
/*      */ 
/*      */   
/*      */   private static native void nSetImGuiContext(long paramLong);
/*      */ 
/*      */   
/*      */   public static ImNodesContext createContext() {
/*   37 */     return new ImNodesContext(nCreateContext());
/*      */   }
/*      */ 
/*      */   
/*      */   private static native long nCreateContext();
/*      */ 
/*      */   
/*      */   public static void destroyContext() {
/*   45 */     nDestroyContext();
/*      */   }
/*      */   
/*      */   public static void destroyContext(ImNodesContext ctx) {
/*   49 */     nDestroyContext(ctx.ptr);
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   private static native void nDestroyContext();
/*      */ 
/*      */   
/*      */   private static native void nDestroyContext(long paramLong);
/*      */ 
/*      */   
/*      */   public static ImNodesContext getCurrentContext() {
/*   61 */     return new ImNodesContext(nGetCurrentContext());
/*      */   }
/*      */ 
/*      */   
/*      */   private static native long nGetCurrentContext();
/*      */ 
/*      */   
/*      */   public static void setCurrentContext(ImNodesContext ctx) {
/*   69 */     nSetCurrentContext(ctx.ptr);
/*      */   }
/*      */ 
/*      */   
/*      */   private static native void nSetCurrentContext(long paramLong);
/*      */ 
/*      */   
/*      */   public static ImNodesEditorContext editorContextCreate() {
/*   77 */     return new ImNodesEditorContext(nEditorContextCreate());
/*      */   }
/*      */ 
/*      */   
/*      */   private static native long nEditorContextCreate();
/*      */ 
/*      */   
/*      */   public static void editorContextFree(ImNodesEditorContext context) {
/*   85 */     nEditorContextFree(context.ptr);
/*      */   }
/*      */ 
/*      */   
/*      */   private static native void nEditorContextFree(long paramLong);
/*      */ 
/*      */   
/*      */   public static void editorContextSet(ImNodesEditorContext context) {
/*   93 */     nEditorContextSet(context.ptr);
/*      */   }
/*      */ 
/*      */   
/*      */   private static native void nEditorContextSet(long paramLong);
/*      */ 
/*      */   
/*      */   public static ImVec2 editorContextGetPanning() {
/*  101 */     ImVec2 dst = new ImVec2();
/*  102 */     nEditorContextGetPanning(dst);
/*  103 */     return dst;
/*      */   }
/*      */   
/*      */   public static float editorContextGetPanningX() {
/*  107 */     return nEditorContextGetPanningX();
/*      */   }
/*      */   
/*      */   public static float editorContextGetPanningY() {
/*  111 */     return nEditorContextGetPanningY();
/*      */   }
/*      */   
/*      */   public static void editorContextGetPanning(ImVec2 dst) {
/*  115 */     nEditorContextGetPanning(dst);
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   private static native void nEditorContextGetPanning(ImVec2 paramImVec2);
/*      */ 
/*      */ 
/*      */   
/*      */   private static native float nEditorContextGetPanningX();
/*      */ 
/*      */   
/*      */   private static native float nEditorContextGetPanningY();
/*      */ 
/*      */   
/*      */   public static void editorContextResetPanning(ImVec2 pos) {
/*  131 */     nEditorContextResetPanning(pos.x, pos.y);
/*      */   }
/*      */   
/*      */   public static void editorContextResetPanning(float posX, float posY) {
/*  135 */     nEditorContextResetPanning(posX, posY);
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   private static native void nEditorContextResetPanning(float paramFloat1, float paramFloat2);
/*      */ 
/*      */   
/*      */   public static void editorContextMoveToNode(int nodeId) {
/*  144 */     nEditorContextMoveToNode(nodeId);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  151 */   private static final ImNodesIO _GETIO_1 = new ImNodesIO(0L);
/*      */   
/*      */   public static ImNodesIO getIO() {
/*  154 */     _GETIO_1.ptr = nGetIO();
/*  155 */     return _GETIO_1;
/*      */   }
/*      */ 
/*      */   
/*      */   private static native void nEditorContextMoveToNode(int paramInt);
/*      */ 
/*      */   
/*  162 */   private static final ImNodesStyle _GETSTYLE_1 = new ImNodesStyle(0L);
/*      */ 
/*      */   
/*      */   private static native long nGetIO();
/*      */   
/*      */   public static ImNodesStyle getStyle() {
/*  168 */     _GETSTYLE_1.ptr = nGetStyle();
/*  169 */     return _GETSTYLE_1;
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   private static native long nGetStyle();
/*      */ 
/*      */ 
/*      */   
/*      */   public static void styleColorsDark() {
/*  179 */     nStyleColorsDark();
/*      */   }
/*      */   
/*      */   public static void styleColorsDark(ImNodesStyle style) {
/*  183 */     nStyleColorsDark(style.ptr);
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   private static native void nStyleColorsDark();
/*      */ 
/*      */   
/*      */   private static native void nStyleColorsDark(long paramLong);
/*      */ 
/*      */   
/*      */   public static void styleColorsClassic() {
/*  195 */     nStyleColorsClassic();
/*      */   }
/*      */   
/*      */   public static void styleColorsClassic(ImNodesStyle style) {
/*  199 */     nStyleColorsClassic(style.ptr);
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   private static native void nStyleColorsClassic();
/*      */ 
/*      */   
/*      */   private static native void nStyleColorsClassic(long paramLong);
/*      */ 
/*      */   
/*      */   public static void styleColorsLight() {
/*  211 */     nStyleColorsLight();
/*      */   }
/*      */   
/*      */   public static void styleColorsLight(ImNodesStyle style) {
/*  215 */     nStyleColorsLight(style.ptr);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private static native void nStyleColorsLight();
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private static native void nStyleColorsLight(long paramLong);
/*      */ 
/*      */ 
/*      */   
/*      */   public static void beginNodeEditor() {
/*  231 */     nBeginNodeEditor();
/*      */   }
/*      */ 
/*      */   
/*      */   private static native void nBeginNodeEditor();
/*      */ 
/*      */   
/*      */   public static void endNodeEditor() {
/*  239 */     nEndNodeEditor();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private static native void nEndNodeEditor();
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static void miniMap() {
/*  251 */     nMiniMap();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static void miniMap(float miniMapSizeFraction) {
/*  259 */     nMiniMap(miniMapSizeFraction);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static void miniMap(float miniMapSizeFraction, int miniMapLocation) {
/*  267 */     nMiniMap(miniMapSizeFraction, miniMapLocation);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private static native void nMiniMap();
/*      */ 
/*      */ 
/*      */   
/*      */   private static native void nMiniMap(float paramFloat);
/*      */ 
/*      */ 
/*      */   
/*      */   private static native void nMiniMap(float paramFloat, int paramInt);
/*      */ 
/*      */ 
/*      */   
/*      */   public static void pushColorStyle(int item, int color) {
/*  286 */     nPushColorStyle(item, color);
/*      */   }
/*      */ 
/*      */   
/*      */   private static native void nPushColorStyle(int paramInt1, int paramInt2);
/*      */ 
/*      */   
/*      */   public static void popColorStyle() {
/*  294 */     nPopColorStyle();
/*      */   }
/*      */ 
/*      */   
/*      */   private static native void nPopColorStyle();
/*      */ 
/*      */   
/*      */   public static void pushStyleVar(int styleItem, float value) {
/*  302 */     nPushStyleVar(styleItem, value);
/*      */   }
/*      */ 
/*      */   
/*      */   private static native void nPushStyleVar(int paramInt, float paramFloat);
/*      */ 
/*      */   
/*      */   public static void pushStyleVar(int styleItem, ImVec2 value) {
/*  310 */     nPushStyleVar(styleItem, value.x, value.y);
/*      */   }
/*      */   
/*      */   public static void pushStyleVar(int styleItem, float valueX, float valueY) {
/*  314 */     nPushStyleVar(styleItem, valueX, valueY);
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   private static native void nPushStyleVar(int paramInt, float paramFloat1, float paramFloat2);
/*      */ 
/*      */   
/*      */   public static void popStyleVar() {
/*  323 */     nPopStyleVar();
/*      */   }
/*      */ 
/*      */   
/*      */   private static native void nPopStyleVar();
/*      */ 
/*      */   
/*      */   public static void beginNode(int node) {
/*  331 */     nBeginNode(node);
/*      */   }
/*      */ 
/*      */   
/*      */   private static native void nBeginNode(int paramInt);
/*      */ 
/*      */   
/*      */   public static void endNode() {
/*  339 */     nEndNode();
/*      */   }
/*      */ 
/*      */   
/*      */   private static native void nEndNode();
/*      */ 
/*      */   
/*      */   public static ImVec2 getNodeDimensions(int id) {
/*  347 */     ImVec2 dst = new ImVec2();
/*  348 */     nGetNodeDimensions(dst, id);
/*  349 */     return dst;
/*      */   }
/*      */   
/*      */   public static float getNodeDimensionsX(int id) {
/*  353 */     return nGetNodeDimensionsX(id);
/*      */   }
/*      */   
/*      */   public static float getNodeDimensionsY(int id) {
/*  357 */     return nGetNodeDimensionsY(id);
/*      */   }
/*      */   
/*      */   public static void getNodeDimensions(ImVec2 dst, int id) {
/*  361 */     nGetNodeDimensions(dst, id);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private static native void nGetNodeDimensions(ImVec2 paramImVec2, int paramInt);
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private static native float nGetNodeDimensionsX(int paramInt);
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private static native float nGetNodeDimensionsY(int paramInt);
/*      */ 
/*      */ 
/*      */   
/*      */   public static void beginNodeTitleBar() {
/*  382 */     nBeginNodeTitleBar();
/*      */   }
/*      */ 
/*      */   
/*      */   private static native void nBeginNodeTitleBar();
/*      */ 
/*      */   
/*      */   public static void endNodeTitleBar() {
/*  390 */     nEndNodeTitleBar();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private static native void nEndNodeTitleBar();
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static void beginInputAttribute(int id) {
/*  410 */     nBeginInputAttribute(id);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static void beginInputAttribute(int id, int shape) {
/*  417 */     nBeginInputAttribute(id, shape);
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   private static native void nBeginInputAttribute(int paramInt);
/*      */ 
/*      */ 
/*      */   
/*      */   private static native void nBeginInputAttribute(int paramInt1, int paramInt2);
/*      */ 
/*      */ 
/*      */   
/*      */   public static void endInputAttribute() {
/*  431 */     nEndInputAttribute();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private static native void nEndInputAttribute();
/*      */ 
/*      */ 
/*      */   
/*      */   public static void beginOutputAttribute(int id) {
/*  442 */     nBeginOutputAttribute(id);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static void beginOutputAttribute(int id, int shape) {
/*  449 */     nBeginOutputAttribute(id, shape);
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   private static native void nBeginOutputAttribute(int paramInt);
/*      */ 
/*      */   
/*      */   private static native void nBeginOutputAttribute(int paramInt1, int paramInt2);
/*      */ 
/*      */   
/*      */   public static void endOutputAttribute() {
/*  461 */     nEndOutputAttribute();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private static native void nEndOutputAttribute();
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static void beginStaticAttribute(int id) {
/*  474 */     nBeginStaticAttribute(id);
/*      */   }
/*      */ 
/*      */   
/*      */   private static native void nBeginStaticAttribute(int paramInt);
/*      */ 
/*      */   
/*      */   public static void endStaticAttribute() {
/*  482 */     nEndStaticAttribute();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private static native void nEndStaticAttribute();
/*      */ 
/*      */ 
/*      */   
/*      */   public static void pushAttributeFlag(int flag) {
/*  493 */     nPushAttributeFlag(flag);
/*      */   }
/*      */ 
/*      */   
/*      */   private static native void nPushAttributeFlag(int paramInt);
/*      */ 
/*      */   
/*      */   public static void popAttributeFlag() {
/*  501 */     nPopAttributeFlag();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private static native void nPopAttributeFlag();
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static void link(int id, int source, int target) {
/*  514 */     nLink(id, source, target);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private static native void nLink(int paramInt1, int paramInt2, int paramInt3);
/*      */ 
/*      */ 
/*      */   
/*      */   public static void setNodeDraggable(int nodeId, boolean draggable) {
/*  525 */     nSetNodeDraggable(nodeId, draggable);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private static native void nSetNodeDraggable(int paramInt, boolean paramBoolean);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static void setNodeScreenSpacePos(int nodeId, ImVec2 screenSpacePos) {
/*  541 */     nSetNodeScreenSpacePos(nodeId, screenSpacePos.x, screenSpacePos.y);
/*      */   }
/*      */   
/*      */   public static void setNodeScreenSpacePos(int nodeId, float screenSpacePosX, float screenSpacePosY) {
/*  545 */     nSetNodeScreenSpacePos(nodeId, screenSpacePosX, screenSpacePosY);
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   private static native void nSetNodeScreenSpacePos(int paramInt, float paramFloat1, float paramFloat2);
/*      */ 
/*      */   
/*      */   public static void setNodeEditorSpacePos(int nodeId, ImVec2 editorSpacePos) {
/*  554 */     nSetNodeEditorSpacePos(nodeId, editorSpacePos.x, editorSpacePos.y);
/*      */   }
/*      */   
/*      */   public static void setNodeEditorSpacePos(int nodeId, float editorSpacePosX, float editorSpacePosY) {
/*  558 */     nSetNodeEditorSpacePos(nodeId, editorSpacePosX, editorSpacePosY);
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   private static native void nSetNodeEditorSpacePos(int paramInt, float paramFloat1, float paramFloat2);
/*      */ 
/*      */   
/*      */   public static void setNodeGridSpacePos(int nodeId, ImVec2 gridPos) {
/*  567 */     nSetNodeGridSpacePos(nodeId, gridPos.x, gridPos.y);
/*      */   }
/*      */   
/*      */   public static void setNodeGridSpacePos(int nodeId, float gridPosX, float gridPosY) {
/*  571 */     nSetNodeGridSpacePos(nodeId, gridPosX, gridPosY);
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   private static native void nSetNodeGridSpacePos(int paramInt, float paramFloat1, float paramFloat2);
/*      */ 
/*      */   
/*      */   public static ImVec2 getNodeScreenSpacePos(int nodeId) {
/*  580 */     ImVec2 dst = new ImVec2();
/*  581 */     nGetNodeScreenSpacePos(dst, nodeId);
/*  582 */     return dst;
/*      */   }
/*      */   
/*      */   public static float getNodeScreenSpacePosX(int nodeId) {
/*  586 */     return nGetNodeScreenSpacePosX(nodeId);
/*      */   }
/*      */   
/*      */   public static float getNodeScreenSpacePosY(int nodeId) {
/*  590 */     return nGetNodeScreenSpacePosY(nodeId);
/*      */   }
/*      */   
/*      */   public static void getNodeScreenSpacePos(ImVec2 dst, int nodeId) {
/*  594 */     nGetNodeScreenSpacePos(dst, nodeId);
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   private static native void nGetNodeScreenSpacePos(ImVec2 paramImVec2, int paramInt);
/*      */ 
/*      */ 
/*      */   
/*      */   private static native float nGetNodeScreenSpacePosX(int paramInt);
/*      */ 
/*      */   
/*      */   private static native float nGetNodeScreenSpacePosY(int paramInt);
/*      */ 
/*      */   
/*      */   public static ImVec2 getNodeEditorSpacePos(int nodeId) {
/*  610 */     ImVec2 dst = new ImVec2();
/*  611 */     nGetNodeEditorSpacePos(dst, nodeId);
/*  612 */     return dst;
/*      */   }
/*      */   
/*      */   public static float getNodeEditorSpacePosX(int nodeId) {
/*  616 */     return nGetNodeEditorSpacePosX(nodeId);
/*      */   }
/*      */   
/*      */   public static float getNodeEditorSpacePosY(int nodeId) {
/*  620 */     return nGetNodeEditorSpacePosY(nodeId);
/*      */   }
/*      */   
/*      */   public static void getNodeEditorSpacePos(ImVec2 dst, int nodeId) {
/*  624 */     nGetNodeEditorSpacePos(dst, nodeId);
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   private static native void nGetNodeEditorSpacePos(ImVec2 paramImVec2, int paramInt);
/*      */ 
/*      */ 
/*      */   
/*      */   private static native float nGetNodeEditorSpacePosX(int paramInt);
/*      */ 
/*      */   
/*      */   private static native float nGetNodeEditorSpacePosY(int paramInt);
/*      */ 
/*      */   
/*      */   public static ImVec2 getNodeGridSpacePos(int nodeId) {
/*  640 */     ImVec2 dst = new ImVec2();
/*  641 */     nGetNodeGridSpacePos(dst, nodeId);
/*  642 */     return dst;
/*      */   }
/*      */   
/*      */   public static float getNodeGridSpacePosX(int nodeId) {
/*  646 */     return nGetNodeGridSpacePosX(nodeId);
/*      */   }
/*      */   
/*      */   public static float getNodeGridSpacePosY(int nodeId) {
/*  650 */     return nGetNodeGridSpacePosY(nodeId);
/*      */   }
/*      */   
/*      */   public static void getNodeGridSpacePos(ImVec2 dst, int nodeId) {
/*  654 */     nGetNodeGridSpacePos(dst, nodeId);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private static native void nGetNodeGridSpacePos(ImVec2 paramImVec2, int paramInt);
/*      */ 
/*      */ 
/*      */   
/*      */   private static native float nGetNodeGridSpacePosX(int paramInt);
/*      */ 
/*      */ 
/*      */   
/*      */   private static native float nGetNodeGridSpacePosY(int paramInt);
/*      */ 
/*      */ 
/*      */   
/*      */   public static void snapNodeToGrid(int nodeId) {
/*  673 */     nSnapNodeToGrid(nodeId);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private static native void nSnapNodeToGrid(int paramInt);
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static boolean isEditorHovered() {
/*  685 */     return nIsEditorHovered();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private static native boolean nIsEditorHovered();
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static boolean isNodeHovered(ImInt nodeId) {
/*  697 */     return nIsNodeHovered((nodeId != null) ? nodeId.getData() : null);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private static native boolean nIsNodeHovered(int[] paramArrayOfint);
/*      */ 
/*      */ 
/*      */   
/*      */   public static boolean isLinkHovered(ImInt linkId) {
/*  708 */     return nIsLinkHovered((linkId != null) ? linkId.getData() : null);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private static native boolean nIsLinkHovered(int[] paramArrayOfint);
/*      */ 
/*      */ 
/*      */   
/*      */   public static boolean isPinHovered(ImInt attributeId) {
/*  719 */     return nIsPinHovered((attributeId != null) ? attributeId.getData() : null);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private static native boolean nIsPinHovered(int[] paramArrayOfint);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static native int getHoveredNode();
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static native int getHoveredLink();
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static native int getHoveredPin();
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static int numSelectedNodes() {
/*  765 */     return nNumSelectedNodes();
/*      */   }
/*      */ 
/*      */   
/*      */   private static native int nNumSelectedNodes();
/*      */ 
/*      */   
/*      */   public static int numSelectedLinks() {
/*  773 */     return nNumSelectedLinks();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private static native int nNumSelectedLinks();
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static void getSelectedNodes(int[] nodeIds) {
/*  786 */     nGetSelectedNodes(nodeIds);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private static native void nGetSelectedNodes(int[] paramArrayOfint);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static void getSelectedLinks(int[] linkIds) {
/*  801 */     nGetSelectedLinks(linkIds);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private static native void nGetSelectedLinks(int[] paramArrayOfint);
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static void clearNodeSelection() {
/*  814 */     nClearNodeSelection();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private static native void nClearNodeSelection();
/*      */ 
/*      */ 
/*      */   
/*      */   public static void clearLinkSelection() {
/*  825 */     nClearLinkSelection();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private static native void nClearLinkSelection();
/*      */ 
/*      */ 
/*      */   
/*      */   public static void selectNode(int nodeId) {
/*  836 */     nSelectNode(nodeId);
/*      */   }
/*      */ 
/*      */   
/*      */   private static native void nSelectNode(int paramInt);
/*      */ 
/*      */   
/*      */   public static void clearNodeSelection(int nodeId) {
/*  844 */     nClearNodeSelection(nodeId);
/*      */   }
/*      */ 
/*      */   
/*      */   private static native void nClearNodeSelection(int paramInt);
/*      */ 
/*      */   
/*      */   public static boolean isNodeSelected(int nodeId) {
/*  852 */     return nIsNodeSelected(nodeId);
/*      */   }
/*      */ 
/*      */   
/*      */   private static native boolean nIsNodeSelected(int paramInt);
/*      */ 
/*      */   
/*      */   public static void selectLink(int linkId) {
/*  860 */     nSelectLink(linkId);
/*      */   }
/*      */ 
/*      */   
/*      */   private static native void nSelectLink(int paramInt);
/*      */ 
/*      */   
/*      */   public static void clearLinkSelection(int linkId) {
/*  868 */     nClearLinkSelection(linkId);
/*      */   }
/*      */ 
/*      */   
/*      */   private static native void nClearLinkSelection(int paramInt);
/*      */ 
/*      */   
/*      */   public static boolean isLinkSelected(int linkId) {
/*  876 */     return nIsLinkSelected(linkId);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private static native boolean nIsLinkSelected(int paramInt);
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static boolean isAttributeActive() {
/*  888 */     return nIsAttributeActive();
/*      */   }
/*      */ 
/*      */   
/*      */   private static native boolean nIsAttributeActive();
/*      */ 
/*      */   
/*      */   public static boolean isAnyAttributeActive() {
/*  896 */     return nIsAnyAttributeActive();
/*      */   }
/*      */   
/*      */   public static boolean isAnyAttributeActive(ImInt attributeId) {
/*  900 */     return nIsAnyAttributeActive((attributeId != null) ? attributeId.getData() : null);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private static native boolean nIsAnyAttributeActive();
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private static native boolean nIsAnyAttributeActive(int[] paramArrayOfint);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static native int getActiveAttribute();
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static boolean isLinkStarted(ImInt startedAtAttributeId) {
/*  931 */     return nIsLinkStarted((startedAtAttributeId != null) ? startedAtAttributeId.getData() : null);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private static native boolean nIsLinkStarted(int[] paramArrayOfint);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static boolean isLinkDropped() {
/*  950 */     return nIsLinkDropped();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static boolean isLinkDropped(ImInt startedAtAttributeId) {
/*  962 */     return nIsLinkDropped((startedAtAttributeId != null) ? startedAtAttributeId.getData() : null);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static boolean isLinkDropped(ImInt startedAtAttributeId, boolean includingDetachedLinks) {
/*  974 */     return nIsLinkDropped((startedAtAttributeId != null) ? startedAtAttributeId.getData() : null, includingDetachedLinks);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static boolean isLinkDropped(boolean includingDetachedLinks) {
/*  986 */     return nIsLinkDropped(includingDetachedLinks);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private static native boolean nIsLinkDropped();
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private static native boolean nIsLinkDropped(int[] paramArrayOfint);
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private static native boolean nIsLinkDropped(int[] paramArrayOfint, boolean paramBoolean);
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private static native boolean nIsLinkDropped(boolean paramBoolean);
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static boolean isLinkCreated(ImInt startedAtAttributeId, ImInt endedAtAttributeId) {
/* 1015 */     return nIsLinkCreated((startedAtAttributeId != null) ? startedAtAttributeId.getData() : null, (endedAtAttributeId != null) ? endedAtAttributeId.getData() : null);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static boolean isLinkCreated(ImInt startedAtAttributeId, ImInt endedAtAttributeId, ImBoolean createdFromSnap) {
/* 1022 */     return nIsLinkCreated((startedAtAttributeId != null) ? startedAtAttributeId.getData() : null, (endedAtAttributeId != null) ? endedAtAttributeId.getData() : null, (createdFromSnap != null) ? createdFromSnap.getData() : null);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private static native boolean nIsLinkCreated(int[] paramArrayOfint1, int[] paramArrayOfint2);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private static native boolean nIsLinkCreated(int[] paramArrayOfint1, int[] paramArrayOfint2, boolean[] paramArrayOfboolean);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static boolean isLinkCreated(ImInt startedAtNodeId, ImInt startedAtAttributeId, ImInt endedAtNodeId, ImInt endedAtAttributeId) {
/* 1049 */     return nIsLinkCreated((startedAtNodeId != null) ? startedAtNodeId.getData() : null, (startedAtAttributeId != null) ? startedAtAttributeId.getData() : null, (endedAtNodeId != null) ? endedAtNodeId.getData() : null, (endedAtAttributeId != null) ? endedAtAttributeId.getData() : null);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static boolean isLinkCreated(ImInt startedAtNodeId, ImInt startedAtAttributeId, ImInt endedAtNodeId, ImInt endedAtAttributeId, ImBoolean createdFromSnap) {
/* 1056 */     return nIsLinkCreated((startedAtNodeId != null) ? startedAtNodeId.getData() : null, (startedAtAttributeId != null) ? startedAtAttributeId.getData() : null, (endedAtNodeId != null) ? endedAtNodeId.getData() : null, (endedAtAttributeId != null) ? endedAtAttributeId.getData() : null, (createdFromSnap != null) ? createdFromSnap.getData() : null);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private static native boolean nIsLinkCreated(int[] paramArrayOfint1, int[] paramArrayOfint2, int[] paramArrayOfint3, int[] paramArrayOfint4);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private static native boolean nIsLinkCreated(int[] paramArrayOfint1, int[] paramArrayOfint2, int[] paramArrayOfint3, int[] paramArrayOfint4, boolean[] paramArrayOfboolean);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static boolean isLinkDestroyed(ImInt linkId) {
/* 1092 */     return nIsLinkDestroyed((linkId != null) ? linkId.getData() : null);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private static native boolean nIsLinkDestroyed(int[] paramArrayOfint);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static String saveCurrentEditorStateToIniString() {
/* 1106 */     return nSaveCurrentEditorStateToIniString();
/*      */   }
/*      */ 
/*      */   
/*      */   private static native String nSaveCurrentEditorStateToIniString();
/*      */ 
/*      */   
/*      */   public static String saveEditorStateToIniString(ImNodesEditorContext editor) {
/* 1114 */     return nSaveEditorStateToIniString(editor.ptr);
/*      */   }
/*      */ 
/*      */   
/*      */   private static native String nSaveEditorStateToIniString(long paramLong);
/*      */ 
/*      */   
/*      */   public static void loadCurrentEditorStateFromIniString(String data, int dataSize) {
/* 1122 */     nLoadCurrentEditorStateFromIniString(data, dataSize);
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   private static native void nLoadCurrentEditorStateFromIniString(String paramString, int paramInt);
/*      */ 
/*      */ 
/*      */   
/*      */   public static void loadEditorStateFromIniString(ImNodesEditorContext editor, String data, int dataSize) {
/* 1132 */     nLoadEditorStateFromIniString(editor.ptr, data, dataSize);
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   private static native void nLoadEditorStateFromIniString(long paramLong, String paramString, int paramInt);
/*      */ 
/*      */ 
/*      */   
/*      */   public static void saveCurrentEditorStateToIniFile(String fileName) {
/* 1142 */     nSaveCurrentEditorStateToIniFile(fileName);
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   private static native void nSaveCurrentEditorStateToIniFile(String paramString);
/*      */ 
/*      */ 
/*      */   
/*      */   public static void saveEditorStateToIniFile(ImNodesEditorContext editor, String fileName) {
/* 1152 */     nSaveEditorStateToIniFile(editor.ptr, fileName);
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   private static native void nSaveEditorStateToIniFile(long paramLong, String paramString);
/*      */ 
/*      */ 
/*      */   
/*      */   public static void loadCurrentEditorStateFromIniFile(String fileName) {
/* 1162 */     nLoadCurrentEditorStateFromIniFile(fileName);
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   private static native void nLoadCurrentEditorStateFromIniFile(String paramString);
/*      */ 
/*      */ 
/*      */   
/*      */   public static void loadEditorStateFromIniFile(ImNodesEditorContext editor, String fileName) {
/* 1172 */     nLoadEditorStateFromIniFile(editor.ptr, fileName);
/*      */   }
/*      */   
/*      */   private static native void nLoadEditorStateFromIniFile(long paramLong, String paramString);
/*      */ }


/* Location:              C:\Users\rapha\Downloads\aurora.jar!\META-INF\jars\imgui-java-binding-1.90.0.jar!\imgui\extension\imnodes\ImNodes.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */