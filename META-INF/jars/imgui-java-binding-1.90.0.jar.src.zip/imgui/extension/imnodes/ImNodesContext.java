/*   */ package imgui.extension.imnodes;
/*   */ 
/*   */ import imgui.binding.ImGuiStruct;
/*   */ 
/*   */ public final class ImNodesContext extends ImGuiStruct {
/*   */   public ImNodesContext(long ptr) {
/* 7 */     super(ptr);
/*   */   }
/*   */ }


/* Location:              C:\Users\rapha\Downloads\aurora.jar!\META-INF\jars\imgui-java-binding-1.90.0.jar!\imgui\extension\imnodes\ImNodesContext.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */