/*   */ package imgui.extension.imnodes;
/*   */ 
/*   */ import imgui.binding.ImGuiStruct;
/*   */ 
/*   */ public final class ImNodesEditorContext extends ImGuiStruct {
/*   */   public ImNodesEditorContext(long ptr) {
/* 7 */     super(ptr);
/*   */   }
/*   */ }


/* Location:              C:\Users\rapha\Downloads\aurora.jar!\META-INF\jars\imgui-java-binding-1.90.0.jar!\imgui\extension\imnodes\ImNodesEditorContext.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */