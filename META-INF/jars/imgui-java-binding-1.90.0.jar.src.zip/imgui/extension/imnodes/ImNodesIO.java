/*    */ package imgui.extension.imnodes;
/*    */ 
/*    */ import imgui.binding.ImGuiStruct;
/*    */ 
/*    */ public final class ImNodesIO extends ImGuiStruct {
/*    */   public ImNodesIO(long ptr) {
/*  7 */     super(ptr);
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public int getAltMouseButton() {
/* 20 */     return nGetAltMouseButton();
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public void setAltMouseButton(int value) {
/* 28 */     nSetAltMouseButton(value);
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   private native int nGetAltMouseButton();
/*    */ 
/*    */ 
/*    */   
/*    */   private native void nSetAltMouseButton(int paramInt);
/*    */ 
/*    */ 
/*    */   
/*    */   public float getAutoPanningSpeed() {
/* 43 */     return nGetAutoPanningSpeed();
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public void setAutoPanningSpeed(float value) {
/* 50 */     nSetAutoPanningSpeed(value);
/*    */   }
/*    */   
/*    */   private native float nGetAutoPanningSpeed();
/*    */   
/*    */   private native void nSetAutoPanningSpeed(float paramFloat);
/*    */ }


/* Location:              C:\Users\rapha\Downloads\aurora.jar!\META-INF\jars\imgui-java-binding-1.90.0.jar!\imgui\extension\imnodes\ImNodesIO.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */