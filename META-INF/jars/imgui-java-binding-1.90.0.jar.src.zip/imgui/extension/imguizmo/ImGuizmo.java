/*     */ package imgui.extension.imguizmo;
/*     */ 
/*     */ import imgui.ImDrawList;
/*     */ import imgui.ImVec2;
/*     */ import imgui.internal.ImGuiContext;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class ImGuizmo
/*     */ {
/*     */   public static void setDrawList() {
/*  20 */     nSetDrawList();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static void setDrawList(ImDrawList drawList) {
/*  28 */     nSetDrawList(drawList.ptr);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static native void nSetDrawList();
/*     */ 
/*     */ 
/*     */   
/*     */   private static native void nSetDrawList(long paramLong);
/*     */ 
/*     */ 
/*     */   
/*     */   public static void beginFrame() {
/*  43 */     nBeginFrame();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static native void nBeginFrame();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static void setImGuiContext(ImGuiContext ctx) {
/*  57 */     nSetImGuiContext(ctx.ptr);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static native void nSetImGuiContext(long paramLong);
/*     */ 
/*     */ 
/*     */   
/*     */   public static boolean isOver() {
/*  68 */     return nIsOver();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static native boolean nIsOver();
/*     */ 
/*     */ 
/*     */   
/*     */   public static boolean isUsing() {
/*  79 */     return nIsUsing();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static native boolean nIsUsing();
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static void enable(boolean enable) {
/*  91 */     nEnable(enable);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static native void nEnable(boolean paramBoolean);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static void decomposeMatrixToComponents(float[] matrix, float[] translation, float[] rotation, float[] scale) {
/* 114 */     nDecomposeMatrixToComponents(matrix, translation, rotation, scale);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static native void nDecomposeMatrixToComponents(float[] paramArrayOffloat1, float[] paramArrayOffloat2, float[] paramArrayOffloat3, float[] paramArrayOffloat4);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static void recomposeMatrixFromComponents(float[] translation, float[] rotation, float[] scale, float[] matrix) {
/* 145 */     nRecomposeMatrixFromComponents(translation, rotation, scale, matrix);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static native void nRecomposeMatrixFromComponents(float[] paramArrayOffloat1, float[] paramArrayOffloat2, float[] paramArrayOffloat3, float[] paramArrayOffloat4);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static void setRect(float x, float y, float width, float height) {
/* 173 */     nSetRect(x, y, width, height);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static native void nSetRect(float paramFloat1, float paramFloat2, float paramFloat3, float paramFloat4);
/*     */ 
/*     */ 
/*     */   
/*     */   public static void setOrthographic(boolean isOrthographic) {
/* 184 */     nSetOrthographic(isOrthographic);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static native void nSetOrthographic(boolean paramBoolean);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static void drawCubes(float[] view, float[] projection, float[] matrices) {
/* 202 */     nDrawCubes(view, projection, matrices);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static native void nDrawCubes(float[] paramArrayOffloat1, float[] paramArrayOffloat2, float[] paramArrayOffloat3);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static void drawCubes(float[] view, float[] projection, float[] matrices, int matrixCount) {
/* 228 */     nDrawCubes(view, projection, matrices, matrixCount);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static native void nDrawCubes(float[] paramArrayOffloat1, float[] paramArrayOffloat2, float[] paramArrayOffloat3, int paramInt);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static void drawCubes(float[] view, float[] projection, float[]... matrices) {
/* 249 */     if (matrices.length > 4) {
/* 250 */       throw new IllegalArgumentException("Only up to 4 cubes matrices is supported");
/*     */     }
/*     */     
/* 253 */     float[] cubeMatrices = new float[matrices.length * 16];
/* 254 */     for (int i = 0, cubeMatricesLength = matrices.length; i < cubeMatricesLength; i++) {
/* 255 */       float[] cubeMatrix = matrices[i];
/* 256 */       System.arraycopy(cubeMatrix, 0, cubeMatrices, i * cubeMatrix.length, cubeMatrix.length);
/*     */     } 
/*     */     
/* 259 */     drawCubes(view, projection, cubeMatrices, cubeMatrices.length);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static void drawGrid(float[] view, float[] projection, float[] matrix, float gridSize) {
/* 275 */     nDrawGrid(view, projection, matrix, gridSize);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static native void nDrawGrid(float[] paramArrayOffloat1, float[] paramArrayOffloat2, float[] paramArrayOffloat3, float paramFloat);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static void manipulate(float[] view, float[] projection, int operation, int mode, float[] matrix) {
/* 303 */     nManipulate(view, projection, operation, mode, matrix);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static void manipulate(float[] view, float[] projection, int operation, int mode, float[] matrix, float[] deltaMatrix) {
/* 323 */     nManipulate(view, projection, operation, mode, matrix, deltaMatrix);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static void manipulate(float[] view, float[] projection, int operation, int mode, float[] matrix, float[] deltaMatrix, float[] snap) {
/* 345 */     nManipulate(view, projection, operation, mode, matrix, deltaMatrix, snap);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static void manipulate(float[] view, float[] projection, int operation, int mode, float[] matrix, float[] deltaMatrix, float[] snap, float[] localBounds) {
/* 369 */     nManipulate(view, projection, operation, mode, matrix, deltaMatrix, snap, localBounds);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static void manipulate(float[] view, float[] projection, int operation, int mode, float[] matrix, float[] deltaMatrix, float[] snap, float[] localBounds, float[] boundsSnap) {
/* 395 */     nManipulate(view, projection, operation, mode, matrix, deltaMatrix, snap, localBounds, boundsSnap);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static native void nManipulate(float[] paramArrayOffloat1, float[] paramArrayOffloat2, int paramInt1, int paramInt2, float[] paramArrayOffloat3);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static native void nManipulate(float[] paramArrayOffloat1, float[] paramArrayOffloat2, int paramInt1, int paramInt2, float[] paramArrayOffloat3, float[] paramArrayOffloat4);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static native void nManipulate(float[] paramArrayOffloat1, float[] paramArrayOffloat2, int paramInt1, int paramInt2, float[] paramArrayOffloat3, float[] paramArrayOffloat4, float[] paramArrayOffloat5);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static native void nManipulate(float[] paramArrayOffloat1, float[] paramArrayOffloat2, int paramInt1, int paramInt2, float[] paramArrayOffloat3, float[] paramArrayOffloat4, float[] paramArrayOffloat5, float[] paramArrayOffloat6);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static native void nManipulate(float[] paramArrayOffloat1, float[] paramArrayOffloat2, int paramInt1, int paramInt2, float[] paramArrayOffloat3, float[] paramArrayOffloat4, float[] paramArrayOffloat5, float[] paramArrayOffloat6, float[] paramArrayOffloat7);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static void viewManipulate(float[] view, float length, ImVec2 position, ImVec2 size, int backgroundColor) {
/* 477 */     nViewManipulate(view, length, position.x, position.y, size.x, size.y, backgroundColor);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static void viewManipulate(float[] view, float length, float positionX, float positionY, float sizeX, float sizeY, int backgroundColor) {
/* 489 */     nViewManipulate(view, length, positionX, positionY, sizeX, sizeY, backgroundColor);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static native void nViewManipulate(float[] paramArrayOffloat, float paramFloat1, float paramFloat2, float paramFloat3, float paramFloat4, float paramFloat5, int paramInt);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static void setID(int id) {
/* 504 */     nSetID(id);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static native void nSetID(int paramInt);
/*     */ 
/*     */ 
/*     */   
/*     */   public static boolean isOver(int operation) {
/* 515 */     return nIsOver(operation);
/*     */   }
/*     */ 
/*     */   
/*     */   private static native boolean nIsOver(int paramInt);
/*     */ 
/*     */   
/*     */   public static void setGizmoSizeClipSpace(float value) {
/* 523 */     nSetGizmoSizeClipSpace(value);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static native void nSetGizmoSizeClipSpace(float paramFloat);
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static void allowAxisFlip(boolean value) {
/* 536 */     nAllowAxisFlip(value);
/*     */   }
/*     */   
/*     */   private static native void nAllowAxisFlip(boolean paramBoolean);
/*     */ }


/* Location:              C:\Users\rapha\Downloads\aurora.jar!\META-INF\jars\imgui-java-binding-1.90.0.jar!\imgui\extension\imguizmo\ImGuizmo.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */