package imgui.extension.imguizmo.flag;

public final class Mode {
  public static final int LOCAL = 0;
  
  public static final int WORLD = 1;
}


/* Location:              C:\Users\rapha\Downloads\aurora.jar!\META-INF\jars\imgui-java-binding-1.90.0.jar!\imgui\extension\imguizmo\flag\Mode.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */