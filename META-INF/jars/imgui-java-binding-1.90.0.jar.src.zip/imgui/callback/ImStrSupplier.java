package imgui.callback;

public abstract class ImStrSupplier {
  public abstract String get();
}


/* Location:              C:\Users\rapha\Downloads\aurora.jar!\META-INF\jars\imgui-java-binding-1.90.0.jar!\imgui\callback\ImStrSupplier.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */