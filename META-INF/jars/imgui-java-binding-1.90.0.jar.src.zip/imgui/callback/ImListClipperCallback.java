package imgui.callback;

public abstract class ImListClipperCallback {
  public abstract void accept(int paramInt);
}


/* Location:              C:\Users\rapha\Downloads\aurora.jar!\META-INF\jars\imgui-java-binding-1.90.0.jar!\imgui\callback\ImListClipperCallback.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */