package imgui.callback;

public abstract class ImStrConsumer {
  public abstract void accept(String paramString);
}


/* Location:              C:\Users\rapha\Downloads\aurora.jar!\META-INF\jars\imgui-java-binding-1.90.0.jar!\imgui\callback\ImStrConsumer.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */