package imgui.callback;

import imgui.ImGuiViewport;

public abstract class ImPlatformFuncViewportFloat {
  public abstract void accept(ImGuiViewport paramImGuiViewport, float paramFloat);
}


/* Location:              C:\Users\rapha\Downloads\aurora.jar!\META-INF\jars\imgui-java-binding-1.90.0.jar!\imgui\callback\ImPlatformFuncViewportFloat.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */