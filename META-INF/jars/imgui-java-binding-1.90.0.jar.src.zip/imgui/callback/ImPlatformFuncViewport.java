package imgui.callback;

import imgui.ImGuiViewport;

public abstract class ImPlatformFuncViewport {
  public abstract void accept(ImGuiViewport paramImGuiViewport);
}


/* Location:              C:\Users\rapha\Downloads\aurora.jar!\META-INF\jars\imgui-java-binding-1.90.0.jar!\imgui\callback\ImPlatformFuncViewport.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */