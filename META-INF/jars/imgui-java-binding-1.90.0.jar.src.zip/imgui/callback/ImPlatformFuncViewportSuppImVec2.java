package imgui.callback;

import imgui.ImGuiViewport;
import imgui.ImVec2;

public abstract class ImPlatformFuncViewportSuppImVec2 {
  public abstract void get(ImGuiViewport paramImGuiViewport, ImVec2 paramImVec2);
}


/* Location:              C:\Users\rapha\Downloads\aurora.jar!\META-INF\jars\imgui-java-binding-1.90.0.jar!\imgui\callback\ImPlatformFuncViewportSuppImVec2.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */