/*    */ package imgui.callback;
/*    */ 
/*    */ import imgui.ImGuiInputTextCallbackData;
/*    */ import java.util.function.Consumer;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public abstract class ImGuiInputTextCallback
/*    */   implements Consumer<ImGuiInputTextCallbackData>
/*    */ {
/*    */   public final void accept(long ptr) {
/* 15 */     accept(new ImGuiInputTextCallbackData(ptr));
/*    */   }
/*    */ }


/* Location:              C:\Users\rapha\Downloads\aurora.jar!\META-INF\jars\imgui-java-binding-1.90.0.jar!\imgui\callback\ImGuiInputTextCallback.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */