/*     */ package imgui;
/*     */ 
/*     */ import imgui.binding.ImGuiStruct;
/*     */ import imgui.internal.ImGuiContext;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ImGuiInputTextCallbackData
/*     */   extends ImGuiStruct
/*     */ {
/*     */   public ImGuiInputTextCallbackData(long ptr) {
/*  19 */     super(ptr);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  27 */   private static final ImGuiContext _GETCTX_1 = new ImGuiContext(0L);
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ImGuiContext getCtx() {
/*  33 */     _GETCTX_1.ptr = nGetCtx();
/*  34 */     return _GETCTX_1;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setCtx(ImGuiContext value) {
/*  41 */     nSetCtx(value.ptr);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private native long nGetCtx();
/*     */ 
/*     */ 
/*     */   
/*     */   private native void nSetCtx(long paramLong);
/*     */ 
/*     */ 
/*     */   
/*     */   public int getEventFlag() {
/*  56 */     return nGetEventFlag();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean hasEventFlag(int flags) {
/*  63 */     return ((getEventFlag() & flags) != 0);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private native int nGetEventFlag();
/*     */ 
/*     */ 
/*     */   
/*     */   public int getFlags() {
/*  74 */     return nGetFlags();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean hasFlags(int flags) {
/*  81 */     return ((getFlags() & flags) != 0);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private native int nGetFlags();
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int getEventChar() {
/*  94 */     return nGetEventChar();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setEventChar(int value) {
/* 101 */     nSetEventChar(value);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private native int nGetEventChar();
/*     */ 
/*     */ 
/*     */   
/*     */   private native void nSetEventChar(int paramInt);
/*     */ 
/*     */ 
/*     */   
/*     */   public int getEventKey() {
/* 116 */     return nGetEventKey();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private native int nGetEventKey();
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getBuf() {
/* 128 */     return nGetBuf();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setBuf(String value) {
/* 136 */     nSetBuf(value);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private native String nGetBuf();
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private native void nSetBuf(String paramString);
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int getBufTextLen() {
/* 153 */     return nGetBufTextLen();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setBufTextLen(int value) {
/* 160 */     nSetBufTextLen(value);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private native int nGetBufTextLen();
/*     */ 
/*     */ 
/*     */   
/*     */   private native void nSetBufTextLen(int paramInt);
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean getBufDirty() {
/* 175 */     return nGetBufDirty();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setBufDirty(boolean value) {
/* 182 */     nSetBufDirty(value);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private native boolean nGetBufDirty();
/*     */ 
/*     */ 
/*     */   
/*     */   private native void nSetBufDirty(boolean paramBoolean);
/*     */ 
/*     */ 
/*     */   
/*     */   public int getCursorPos() {
/* 197 */     return nGetCursorPos();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setCursorPos(int value) {
/* 204 */     nSetCursorPos(value);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private native int nGetCursorPos();
/*     */ 
/*     */ 
/*     */   
/*     */   private native void nSetCursorPos(int paramInt);
/*     */ 
/*     */ 
/*     */   
/*     */   public int getSelectionStart() {
/* 219 */     return nGetSelectionStart();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setSelectionStart(int value) {
/* 226 */     nSetSelectionStart(value);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private native int nGetSelectionStart();
/*     */ 
/*     */ 
/*     */   
/*     */   private native void nSetSelectionStart(int paramInt);
/*     */ 
/*     */ 
/*     */   
/*     */   public int getSelectionEnd() {
/* 241 */     return nGetSelectionEnd();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setSelectionEnd(int value) {
/* 248 */     nSetSelectionEnd(value);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private native int nGetSelectionEnd();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private native void nSetSelectionEnd(int paramInt);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void deleteChars(int pos, int bytesCount) {
/* 268 */     nDeleteChars(pos, bytesCount);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private native void nDeleteChars(int paramInt1, int paramInt2);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void insertChars(int pos, String str) {
/* 284 */     nInsertChars(pos, str);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private native void nInsertChars(int paramInt, String paramString);
/*     */ 
/*     */ 
/*     */   
/*     */   public void selectAll() {
/* 294 */     nSelectAll();
/*     */   }
/*     */ 
/*     */   
/*     */   private native void nSelectAll();
/*     */ 
/*     */   
/*     */   public void clearSelection() {
/* 302 */     nClearSelection();
/*     */   }
/*     */ 
/*     */   
/*     */   private native void nClearSelection();
/*     */ 
/*     */   
/*     */   public boolean hasSelection() {
/* 310 */     return nHasSelection();
/*     */   }
/*     */   
/*     */   private native boolean nHasSelection();
/*     */ }


/* Location:              C:\Users\rapha\Downloads\aurora.jar!\META-INF\jars\imgui-java-binding-1.90.0.jar!\imgui\ImGuiInputTextCallbackData.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */