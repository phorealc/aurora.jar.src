package imgui.flag;

public final class ImGuiDockNodeFlags {
  public static final int None = 0;
  
  public static final int KeepAliveOnly = 1;
  
  public static final int NoDockingOverCentralNode = 4;
  
  public static final int PassthruCentralNode = 8;
  
  public static final int NoDockingSplit = 16;
  
  public static final int NoResize = 32;
  
  public static final int AutoHideTabBar = 64;
  
  public static final int NoUndocking = 128;
  
  public static final int NoSplit = 16;
  
  public static final int NoDockingInCentralNode = 4;
}


/* Location:              C:\Users\rapha\Downloads\aurora.jar!\META-INF\jars\imgui-java-binding-1.90.0.jar!\imgui\flag\ImGuiDockNodeFlags.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */