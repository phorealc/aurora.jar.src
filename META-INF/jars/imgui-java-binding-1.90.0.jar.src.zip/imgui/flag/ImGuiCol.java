package imgui.flag;

public final class ImGuiCol {
  public static final int Text = 0;
  
  public static final int TextDisabled = 1;
  
  public static final int WindowBg = 2;
  
  public static final int ChildBg = 3;
  
  public static final int PopupBg = 4;
  
  public static final int Border = 5;
  
  public static final int BorderShadow = 6;
  
  public static final int FrameBg = 7;
  
  public static final int FrameBgHovered = 8;
  
  public static final int FrameBgActive = 9;
  
  public static final int TitleBg = 10;
  
  public static final int TitleBgActive = 11;
  
  public static final int TitleBgCollapsed = 12;
  
  public static final int MenuBarBg = 13;
  
  public static final int ScrollbarBg = 14;
  
  public static final int ScrollbarGrab = 15;
  
  public static final int ScrollbarGrabHovered = 16;
  
  public static final int ScrollbarGrabActive = 17;
  
  public static final int CheckMark = 18;
  
  public static final int SliderGrab = 19;
  
  public static final int SliderGrabActive = 20;
  
  public static final int Button = 21;
  
  public static final int ButtonHovered = 22;
  
  public static final int ButtonActive = 23;
  
  public static final int Header = 24;
  
  public static final int HeaderHovered = 25;
  
  public static final int HeaderActive = 26;
  
  public static final int Separator = 27;
  
  public static final int SeparatorHovered = 28;
  
  public static final int SeparatorActive = 29;
  
  public static final int ResizeGrip = 30;
  
  public static final int ResizeGripHovered = 31;
  
  public static final int ResizeGripActive = 32;
  
  public static final int TabHovered = 33;
  
  public static final int Tab = 34;
  
  public static final int TabSelected = 35;
  
  public static final int TabSelectedOverline = 36;
  
  public static final int TabDimmed = 37;
  
  public static final int TabDimmedSelected = 38;
  
  public static final int TabDimmedSelectedOverline = 39;
  
  public static final int DockingPreview = 40;
  
  public static final int DockingEmptyBg = 41;
  
  public static final int PlotLines = 42;
  
  public static final int PlotLinesHovered = 43;
  
  public static final int PlotHistogram = 44;
  
  public static final int PlotHistogramHovered = 45;
  
  public static final int TableHeaderBg = 46;
  
  public static final int TableBorderStrong = 47;
  
  public static final int TableBorderLight = 48;
  
  public static final int TableRowBg = 49;
  
  public static final int TableRowBgAlt = 50;
  
  public static final int TextSelectedBg = 51;
  
  public static final int DragDropTarget = 52;
  
  public static final int NavHighlight = 53;
  
  public static final int NavWindowingHighlight = 54;
  
  public static final int NavWindowingDimBg = 55;
  
  public static final int ModalWindowDimBg = 56;
  
  public static final int COUNT = 57;
  
  public static final int TabActive = 35;
  
  public static final int TabUnfocused = 37;
  
  public static final int TabUnfocusedActive = 38;
}


/* Location:              C:\Users\rapha\Downloads\aurora.jar!\META-INF\jars\imgui-java-binding-1.90.0.jar!\imgui\flag\ImGuiCol.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */