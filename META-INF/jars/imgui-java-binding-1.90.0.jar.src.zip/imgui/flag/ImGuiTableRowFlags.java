package imgui.flag;

public final class ImGuiTableRowFlags {
  public static final int None = 0;
  
  public static final int Headers = 1;
}


/* Location:              C:\Users\rapha\Downloads\aurora.jar!\META-INF\jars\imgui-java-binding-1.90.0.jar!\imgui\flag\ImGuiTableRowFlags.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */