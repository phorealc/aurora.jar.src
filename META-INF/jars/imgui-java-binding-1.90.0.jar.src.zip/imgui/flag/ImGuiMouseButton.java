package imgui.flag;

public final class ImGuiMouseButton {
  public static final int Left = 0;
  
  public static final int Right = 1;
  
  public static final int Middle = 2;
  
  public static final int COUNT = 5;
}


/* Location:              C:\Users\rapha\Downloads\aurora.jar!\META-INF\jars\imgui-java-binding-1.90.0.jar!\imgui\flag\ImGuiMouseButton.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */