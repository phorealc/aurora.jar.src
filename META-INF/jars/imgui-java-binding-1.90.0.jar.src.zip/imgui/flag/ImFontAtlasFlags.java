package imgui.flag;

public final class ImFontAtlasFlags {
  public static final int None = 0;
  
  public static final int NoPowerOfTwoHeight = 1;
  
  public static final int NoMouseCursors = 2;
  
  public static final int NoBakedLines = 4;
}


/* Location:              C:\Users\rapha\Downloads\aurora.jar!\META-INF\jars\imgui-java-binding-1.90.0.jar!\imgui\flag\ImFontAtlasFlags.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */