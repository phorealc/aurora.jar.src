package imgui.flag;

public final class ImGuiTableBgTarget {
  public static final int None = 0;
  
  public static final int RowBg0 = 1;
  
  public static final int RowBg1 = 2;
  
  public static final int CellBg = 3;
}


/* Location:              C:\Users\rapha\Downloads\aurora.jar!\META-INF\jars\imgui-java-binding-1.90.0.jar!\imgui\flag\ImGuiTableBgTarget.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */