package imgui.flag;

public final class ImGuiFocusedFlags {
  public static final int None = 0;
  
  public static final int ChildWindows = 1;
  
  public static final int RootWindow = 2;
  
  public static final int AnyWindow = 4;
  
  public static final int NoPopupHierarchy = 8;
  
  public static final int DockHierarchy = 16;
  
  public static final int RootAndChildWindows = 3;
}


/* Location:              C:\Users\rapha\Downloads\aurora.jar!\META-INF\jars\imgui-java-binding-1.90.0.jar!\imgui\flag\ImGuiFocusedFlags.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */