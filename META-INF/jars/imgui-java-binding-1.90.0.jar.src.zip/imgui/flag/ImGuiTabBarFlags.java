package imgui.flag;

public final class ImGuiTabBarFlags {
  public static final int None = 0;
  
  public static final int Reorderable = 1;
  
  public static final int AutoSelectNewTabs = 2;
  
  public static final int TabListPopupButton = 4;
  
  public static final int NoCloseWithMiddleMouseButton = 8;
  
  public static final int NoTabListScrollingButtons = 16;
  
  public static final int NoTooltip = 32;
  
  public static final int DrawSelectedOverline = 64;
  
  public static final int FittingPolicyResizeDown = 128;
  
  public static final int FittingPolicyScroll = 256;
  
  public static final int FittingPolicyMask_ = 384;
  
  public static final int FittingPolicyDefault_ = 128;
}


/* Location:              C:\Users\rapha\Downloads\aurora.jar!\META-INF\jars\imgui-java-binding-1.90.0.jar!\imgui\flag\ImGuiTabBarFlags.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */