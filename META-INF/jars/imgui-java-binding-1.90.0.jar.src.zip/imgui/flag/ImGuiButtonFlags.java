package imgui.flag;

public final class ImGuiButtonFlags {
  public static final int None = 0;
  
  public static final int MouseButtonLeft = 1;
  
  public static final int MouseButtonRight = 2;
  
  public static final int MouseButtonMiddle = 4;
  
  public static final int MouseButtonMask_ = 7;
}


/* Location:              C:\Users\rapha\Downloads\aurora.jar!\META-INF\jars\imgui-java-binding-1.90.0.jar!\imgui\flag\ImGuiButtonFlags.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */