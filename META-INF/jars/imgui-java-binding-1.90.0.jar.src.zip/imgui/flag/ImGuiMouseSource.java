package imgui.flag;

public final class ImGuiMouseSource {
  public static final int Mouse = 0;
  
  public static final int TouchScreen = 1;
  
  public static final int Pen = 2;
  
  public static final int COUNT = 3;
}


/* Location:              C:\Users\rapha\Downloads\aurora.jar!\META-INF\jars\imgui-java-binding-1.90.0.jar!\imgui\flag\ImGuiMouseSource.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */