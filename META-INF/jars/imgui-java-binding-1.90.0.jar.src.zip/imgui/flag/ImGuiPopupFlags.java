package imgui.flag;

public final class ImGuiPopupFlags {
  public static final int None = 0;
  
  public static final int MouseButtonLeft = 0;
  
  public static final int MouseButtonRight = 1;
  
  public static final int MouseButtonMiddle = 2;
  
  public static final int MouseButtonMask_ = 31;
  
  public static final int MouseButtonDefault_ = 1;
  
  public static final int NoReopen = 32;
  
  public static final int NoOpenOverExistingPopup = 128;
  
  public static final int NoOpenOverItems = 256;
  
  public static final int AnyPopupId = 1024;
  
  public static final int AnyPopupLevel = 2048;
  
  public static final int AnyPopup = 3072;
}


/* Location:              C:\Users\rapha\Downloads\aurora.jar!\META-INF\jars\imgui-java-binding-1.90.0.jar!\imgui\flag\ImGuiPopupFlags.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */