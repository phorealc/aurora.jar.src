package imgui.flag;

public final class ImGuiTreeNodeFlags {
  public static final int None = 0;
  
  public static final int Selected = 1;
  
  public static final int Framed = 2;
  
  public static final int AllowOverlap = 4;
  
  public static final int NoTreePushOnOpen = 8;
  
  public static final int NoAutoOpenOnLog = 16;
  
  public static final int DefaultOpen = 32;
  
  public static final int OpenOnDoubleClick = 64;
  
  public static final int OpenOnArrow = 128;
  
  public static final int Leaf = 256;
  
  public static final int Bullet = 512;
  
  public static final int FramePadding = 1024;
  
  public static final int SpanAvailWidth = 2048;
  
  public static final int SpanFullWidth = 4096;
  
  public static final int SpanTextWidth = 8192;
  
  public static final int SpanAllColumns = 16384;
  
  public static final int NavLeftJumpsBackHere = 32768;
  
  public static final int CollapsingHeader = 26;
  
  public static final int AllowItemOverlap = 4;
}


/* Location:              C:\Users\rapha\Downloads\aurora.jar!\META-INF\jars\imgui-java-binding-1.90.0.jar!\imgui\flag\ImGuiTreeNodeFlags.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */