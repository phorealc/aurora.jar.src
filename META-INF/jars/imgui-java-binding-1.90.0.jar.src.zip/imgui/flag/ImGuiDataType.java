package imgui.flag;

public final class ImGuiDataType {
  public static final int S8 = 0;
  
  public static final int U8 = 1;
  
  public static final int S16 = 2;
  
  public static final int U16 = 3;
  
  public static final int S32 = 4;
  
  public static final int U32 = 5;
  
  public static final int S64 = 6;
  
  public static final int U64 = 7;
  
  public static final int Float = 8;
  
  public static final int Double = 9;
  
  public static final int COUNT = 10;
}


/* Location:              C:\Users\rapha\Downloads\aurora.jar!\META-INF\jars\imgui-java-binding-1.90.0.jar!\imgui\flag\ImGuiDataType.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */