package imgui.flag;

public final class ImGuiComboFlags {
  public static final int None = 0;
  
  public static final int PopupAlignLeft = 1;
  
  public static final int HeightSmall = 2;
  
  public static final int HeightRegular = 4;
  
  public static final int HeightLarge = 8;
  
  public static final int HeightLargest = 16;
  
  public static final int NoArrowButton = 32;
  
  public static final int NoPreview = 64;
  
  public static final int WidthFitPreview = 128;
  
  public static final int HeightMask_ = 30;
}


/* Location:              C:\Users\rapha\Downloads\aurora.jar!\META-INF\jars\imgui-java-binding-1.90.0.jar!\imgui\flag\ImGuiComboFlags.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */