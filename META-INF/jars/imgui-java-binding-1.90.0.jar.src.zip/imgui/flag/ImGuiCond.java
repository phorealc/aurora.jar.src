package imgui.flag;

public final class ImGuiCond {
  public static final int None = 0;
  
  public static final int Always = 1;
  
  public static final int Once = 2;
  
  public static final int FirstUseEver = 4;
  
  public static final int Appearing = 8;
}


/* Location:              C:\Users\rapha\Downloads\aurora.jar!\META-INF\jars\imgui-java-binding-1.90.0.jar!\imgui\flag\ImGuiCond.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */