package imgui.flag;

public final class ImDrawFlags {
  public static final int None = 0;
  
  public static final int Closed = 1;
  
  public static final int RoundCornersTopLeft = 16;
  
  public static final int RoundCornersTopRight = 32;
  
  public static final int RoundCornersBottomLeft = 64;
  
  public static final int RoundCornersBottomRight = 128;
  
  public static final int RoundCornersNone = 256;
  
  public static final int RoundCornersTop = 48;
  
  public static final int RoundCornersBottom = 192;
  
  public static final int RoundCornersLeft = 80;
  
  public static final int RoundCornersRight = 160;
  
  public static final int RoundCornersAll = 240;
  
  public static final int RoundCornersDefault_ = 240;
  
  public static final int RoundCornersMask_ = 496;
}


/* Location:              C:\Users\rapha\Downloads\aurora.jar!\META-INF\jars\imgui-java-binding-1.90.0.jar!\imgui\flag\ImDrawFlags.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */