package imgui.flag;

public final class ImGuiSortDirection {
  public static final int None = 0;
  
  public static final int Ascending = 1;
  
  public static final int Descending = 2;
}


/* Location:              C:\Users\rapha\Downloads\aurora.jar!\META-INF\jars\imgui-java-binding-1.90.0.jar!\imgui\flag\ImGuiSortDirection.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */