package imgui.flag;

public final class ImGuiStyleVar {
  public static final int Alpha = 0;
  
  public static final int DisabledAlpha = 1;
  
  public static final int WindowPadding = 2;
  
  public static final int WindowRounding = 3;
  
  public static final int WindowBorderSize = 4;
  
  public static final int WindowMinSize = 5;
  
  public static final int WindowTitleAlign = 6;
  
  public static final int ChildRounding = 7;
  
  public static final int ChildBorderSize = 8;
  
  public static final int PopupRounding = 9;
  
  public static final int PopupBorderSize = 10;
  
  public static final int FramePadding = 11;
  
  public static final int FrameRounding = 12;
  
  public static final int FrameBorderSize = 13;
  
  public static final int ItemSpacing = 14;
  
  public static final int ItemInnerSpacing = 15;
  
  public static final int IndentSpacing = 16;
  
  public static final int CellPadding = 17;
  
  public static final int ScrollbarSize = 18;
  
  public static final int ScrollbarRounding = 19;
  
  public static final int GrabMinSize = 20;
  
  public static final int GrabRounding = 21;
  
  public static final int TabRounding = 22;
  
  public static final int TabBorderSize = 23;
  
  public static final int TabBarBorderSize = 24;
  
  public static final int TableAngledHeadersAngle = 25;
  
  public static final int TableAngledHeadersTextAlign = 26;
  
  public static final int ButtonTextAlign = 27;
  
  public static final int SelectableTextAlign = 28;
  
  public static final int SeparatorTextBorderSize = 29;
  
  public static final int SeparatorTextAlign = 30;
  
  public static final int SeparatorTextPadding = 31;
  
  public static final int DockingSeparatorSize = 32;
  
  public static final int COUNT = 33;
}


/* Location:              C:\Users\rapha\Downloads\aurora.jar!\META-INF\jars\imgui-java-binding-1.90.0.jar!\imgui\flag\ImGuiStyleVar.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */