package imgui.flag;

public final class ImGuiSliderFlags {
  public static final int None = 0;
  
  public static final int AlwaysClamp = 16;
  
  public static final int Logarithmic = 32;
  
  public static final int NoRoundToFormat = 64;
  
  public static final int NoInput = 128;
  
  public static final int WrapAround = 256;
  
  public static final int InvalidMask_ = 1879048207;
}


/* Location:              C:\Users\rapha\Downloads\aurora.jar!\META-INF\jars\imgui-java-binding-1.90.0.jar!\imgui\flag\ImGuiSliderFlags.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */