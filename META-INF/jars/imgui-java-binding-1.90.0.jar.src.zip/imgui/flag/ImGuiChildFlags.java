package imgui.flag;

public final class ImGuiChildFlags {
  public static final int None = 0;
  
  public static final int Border = 1;
  
  public static final int AlwaysUseWindowPadding = 2;
  
  public static final int ResizeX = 4;
  
  public static final int ResizeY = 8;
  
  public static final int AutoResizeX = 16;
  
  public static final int AutoResizeY = 32;
  
  public static final int AlwaysAutoResize = 64;
  
  public static final int FrameStyle = 128;
  
  public static final int NavFlattened = 256;
}


/* Location:              C:\Users\rapha\Downloads\aurora.jar!\META-INF\jars\imgui-java-binding-1.90.0.jar!\imgui\flag\ImGuiChildFlags.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */