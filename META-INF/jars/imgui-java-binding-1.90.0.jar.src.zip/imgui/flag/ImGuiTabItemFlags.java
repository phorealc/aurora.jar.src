package imgui.flag;

public final class ImGuiTabItemFlags {
  public static final int None = 0;
  
  public static final int UnsavedDocument = 1;
  
  public static final int SetSelected = 2;
  
  public static final int NoCloseWithMiddleMouseButton = 4;
  
  public static final int NoPushId = 8;
  
  public static final int NoTooltip = 16;
  
  public static final int NoReorder = 32;
  
  public static final int Leading = 64;
  
  public static final int Trailing = 128;
  
  public static final int NoAssumedClosure = 256;
}


/* Location:              C:\Users\rapha\Downloads\aurora.jar!\META-INF\jars\imgui-java-binding-1.90.0.jar!\imgui\flag\ImGuiTabItemFlags.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */