package imgui.flag;

public final class ImGuiFreeTypeBuilderFlags {
  public static final int NoHinting = 1;
  
  public static final int NoAutoHint = 2;
  
  public static final int ForceAutoHint = 4;
  
  public static final int LightHinting = 8;
  
  public static final int MonoHinting = 16;
  
  public static final int Bold = 32;
  
  public static final int Oblique = 64;
  
  public static final int Monochrome = 128;
  
  public static final int LoadColor = 256;
  
  public static final int Bitmap = 512;
}


/* Location:              C:\Users\rapha\Downloads\aurora.jar!\META-INF\jars\imgui-java-binding-1.90.0.jar!\imgui\flag\ImGuiFreeTypeBuilderFlags.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */