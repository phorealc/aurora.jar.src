package imgui.flag;

public final class ImGuiViewportFlags {
  public static final int None = 0;
  
  public static final int IsPlatformWindow = 1;
  
  public static final int IsPlatformMonitor = 2;
  
  public static final int OwnedByApp = 4;
  
  public static final int NoDecoration = 8;
  
  public static final int NoTaskBarIcon = 16;
  
  public static final int NoFocusOnAppearing = 32;
  
  public static final int NoFocusOnClick = 64;
  
  public static final int NoInputs = 128;
  
  public static final int NoRendererClear = 256;
  
  public static final int NoAutoMerge = 512;
  
  public static final int TopMost = 1024;
  
  public static final int CanHostOtherWindows = 2048;
  
  public static final int IsMinimized = 4096;
  
  public static final int IsFocused = 8192;
}


/* Location:              C:\Users\rapha\Downloads\aurora.jar!\META-INF\jars\imgui-java-binding-1.90.0.jar!\imgui\flag\ImGuiViewportFlags.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */