package imgui.flag;

public final class ImGuiSelectableFlags {
  public static final int None = 0;
  
  public static final int DontClosePopups = 1;
  
  public static final int SpanAllColumns = 2;
  
  public static final int AllowDoubleClick = 4;
  
  public static final int Disabled = 8;
  
  public static final int AllowOverlap = 16;
  
  public static final int AllowItemOverlap = 16;
}


/* Location:              C:\Users\rapha\Downloads\aurora.jar!\META-INF\jars\imgui-java-binding-1.90.0.jar!\imgui\flag\ImGuiSelectableFlags.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */