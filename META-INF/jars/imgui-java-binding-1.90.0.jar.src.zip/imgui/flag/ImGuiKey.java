package imgui.flag;

public final class ImGuiKey {
  public static final int None = 0;
  
  public static final int Tab = 512;
  
  public static final int LeftArrow = 513;
  
  public static final int RightArrow = 514;
  
  public static final int UpArrow = 515;
  
  public static final int DownArrow = 516;
  
  public static final int PageUp = 517;
  
  public static final int PageDown = 518;
  
  public static final int Home = 519;
  
  public static final int End = 520;
  
  public static final int Insert = 521;
  
  public static final int Delete = 522;
  
  public static final int Backspace = 523;
  
  public static final int Space = 524;
  
  public static final int Enter = 525;
  
  public static final int Escape = 526;
  
  public static final int LeftCtrl = 527;
  
  public static final int LeftShift = 528;
  
  public static final int LeftAlt = 529;
  
  public static final int LeftSuper = 530;
  
  public static final int RightCtrl = 531;
  
  public static final int RightShift = 532;
  
  public static final int RightAlt = 533;
  
  public static final int RightSuper = 534;
  
  public static final int Menu = 535;
  
  public static final int _0 = 536;
  
  public static final int _1 = 537;
  
  public static final int _2 = 538;
  
  public static final int _3 = 539;
  
  public static final int _4 = 540;
  
  public static final int _5 = 541;
  
  public static final int _6 = 542;
  
  public static final int _7 = 543;
  
  public static final int _8 = 544;
  
  public static final int _9 = 545;
  
  public static final int A = 546;
  
  public static final int B = 547;
  
  public static final int C = 548;
  
  public static final int D = 549;
  
  public static final int E = 550;
  
  public static final int F = 551;
  
  public static final int G = 552;
  
  public static final int H = 553;
  
  public static final int I = 554;
  
  public static final int J = 555;
  
  public static final int K = 556;
  
  public static final int L = 557;
  
  public static final int M = 558;
  
  public static final int N = 559;
  
  public static final int O = 560;
  
  public static final int P = 561;
  
  public static final int Q = 562;
  
  public static final int R = 563;
  
  public static final int S = 564;
  
  public static final int T = 565;
  
  public static final int U = 566;
  
  public static final int V = 567;
  
  public static final int W = 568;
  
  public static final int X = 569;
  
  public static final int Y = 570;
  
  public static final int Z = 571;
  
  public static final int F1 = 572;
  
  public static final int F2 = 573;
  
  public static final int F3 = 574;
  
  public static final int F4 = 575;
  
  public static final int F5 = 576;
  
  public static final int F6 = 577;
  
  public static final int F7 = 578;
  
  public static final int F8 = 579;
  
  public static final int F9 = 580;
  
  public static final int F10 = 581;
  
  public static final int F11 = 582;
  
  public static final int F12 = 583;
  
  public static final int F13 = 584;
  
  public static final int F14 = 585;
  
  public static final int F15 = 586;
  
  public static final int F16 = 587;
  
  public static final int F17 = 588;
  
  public static final int F18 = 589;
  
  public static final int F19 = 590;
  
  public static final int F20 = 591;
  
  public static final int F21 = 592;
  
  public static final int F22 = 593;
  
  public static final int F23 = 594;
  
  public static final int F24 = 595;
  
  public static final int Apostrophe = 596;
  
  public static final int Comma = 597;
  
  public static final int Minus = 598;
  
  public static final int Period = 599;
  
  public static final int Slash = 600;
  
  public static final int Semicolon = 601;
  
  public static final int Equal = 602;
  
  public static final int LeftBracket = 603;
  
  public static final int Backslash = 604;
  
  public static final int RightBracket = 605;
  
  public static final int GraveAccent = 606;
  
  public static final int CapsLock = 607;
  
  public static final int ScrollLock = 608;
  
  public static final int NumLock = 609;
  
  public static final int PrintScreen = 610;
  
  public static final int Pause = 611;
  
  public static final int Keypad0 = 612;
  
  public static final int Keypad1 = 613;
  
  public static final int Keypad2 = 614;
  
  public static final int Keypad3 = 615;
  
  public static final int Keypad4 = 616;
  
  public static final int Keypad5 = 617;
  
  public static final int Keypad6 = 618;
  
  public static final int Keypad7 = 619;
  
  public static final int Keypad8 = 620;
  
  public static final int Keypad9 = 621;
  
  public static final int KeypadDecimal = 622;
  
  public static final int KeypadDivide = 623;
  
  public static final int KeypadMultiply = 624;
  
  public static final int KeypadSubtract = 625;
  
  public static final int KeypadAdd = 626;
  
  public static final int KeypadEnter = 627;
  
  public static final int KeypadEqual = 628;
  
  public static final int AppBack = 629;
  
  public static final int AppForward = 630;
  
  public static final int GamepadStart = 631;
  
  public static final int GamepadBack = 632;
  
  public static final int GamepadFaceLeft = 633;
  
  public static final int GamepadFaceRight = 634;
  
  public static final int GamepadFaceUp = 635;
  
  public static final int GamepadFaceDown = 636;
  
  public static final int GamepadDpadLeft = 637;
  
  public static final int GamepadDpadRight = 638;
  
  public static final int GamepadDpadUp = 639;
  
  public static final int GamepadDpadDown = 640;
  
  public static final int GamepadL1 = 641;
  
  public static final int GamepadR1 = 642;
  
  public static final int GamepadL2 = 643;
  
  public static final int GamepadR2 = 644;
  
  public static final int GamepadL3 = 645;
  
  public static final int GamepadR3 = 646;
  
  public static final int GamepadLStickLeft = 647;
  
  public static final int GamepadLStickRight = 648;
  
  public static final int GamepadLStickUp = 649;
  
  public static final int GamepadLStickDown = 650;
  
  public static final int GamepadRStickLeft = 651;
  
  public static final int GamepadRStickRight = 652;
  
  public static final int GamepadRStickUp = 653;
  
  public static final int GamepadRStickDown = 654;
  
  public static final int MouseLeft = 655;
  
  public static final int MouseRight = 656;
  
  public static final int MouseMiddle = 657;
  
  public static final int MouseX1 = 658;
  
  public static final int MouseX2 = 659;
  
  public static final int MouseWheelX = 660;
  
  public static final int MouseWheelY = 661;
  
  public static final int ReservedForModCtrl = 662;
  
  public static final int ReservedForModShift = 663;
  
  public static final int ReservedForModAlt = 664;
  
  public static final int ReservedForModSuper = 665;
  
  public static final int COUNT = 666;
  
  public static final int ImGuiMod_None = 0;
  
  public static final int ImGuiMod_Ctrl = 4096;
  
  public static final int ImGuiMod_Shift = 8192;
  
  public static final int ImGuiMod_Alt = 16384;
  
  public static final int ImGuiMod_Super = 32768;
  
  public static final int ImGuiMod_Mask_ = 61440;
  
  public static final int NamedKey_BEGIN = 512;
  
  public static final int NamedKey_END = 666;
  
  public static final int NamedKey_COUNT = 154;
  
  public static final int KeysData_SIZE = 666;
  
  public static final int KeysData_OFFSET = 0;
  
  public static final int ImGuiMod_Shortcut = 4096;
  
  public static final int ModCtrl = 4096;
  
  public static final int ModShift = 8192;
  
  public static final int ModAlt = 16384;
  
  public static final int ModSuper = 32768;
}


/* Location:              C:\Users\rapha\Downloads\aurora.jar!\META-INF\jars\imgui-java-binding-1.90.0.jar!\imgui\flag\ImGuiKey.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */