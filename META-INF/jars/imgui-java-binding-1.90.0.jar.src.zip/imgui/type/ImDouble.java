/*    */ package imgui.type;
/*    */ 
/*    */ public final class ImDouble extends Number implements Cloneable, Comparable<ImDouble> {
/*  4 */   private final double[] data = new double[] { 0.0D };
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public ImDouble(ImDouble imDouble) {
/* 10 */     this.data[0] = imDouble.data[0];
/*    */   }
/*    */   
/*    */   public ImDouble(double value) {
/* 14 */     set(value);
/*    */   }
/*    */   
/*    */   public double get() {
/* 18 */     return this.data[0];
/*    */   }
/*    */   
/*    */   public double[] getData() {
/* 22 */     return this.data;
/*    */   }
/*    */   
/*    */   public void set(double value) {
/* 26 */     this.data[0] = value;
/*    */   }
/*    */   
/*    */   public void set(ImDouble value) {
/* 30 */     set(value.get());
/*    */   }
/*    */ 
/*    */   
/*    */   public String toString() {
/* 35 */     return String.valueOf(get());
/*    */   }
/*    */ 
/*    */   
/*    */   public boolean equals(Object o) {
/* 40 */     if (this == o) {
/* 41 */       return true;
/*    */     }
/* 43 */     if (o == null || getClass() != o.getClass()) {
/* 44 */       return false;
/*    */     }
/* 46 */     ImDouble imDouble = (ImDouble)o;
/* 47 */     return (this.data[0] == imDouble.data[0]);
/*    */   }
/*    */ 
/*    */   
/*    */   public int hashCode() {
/* 52 */     return Double.hashCode(this.data[0]);
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public ImDouble clone() {
/* 58 */     return new ImDouble(this);
/*    */   }
/*    */ 
/*    */   
/*    */   public int compareTo(ImDouble o) {
/* 63 */     return Double.compare(get(), o.get());
/*    */   }
/*    */ 
/*    */   
/*    */   public int intValue() {
/* 68 */     return (int)get();
/*    */   }
/*    */ 
/*    */   
/*    */   public long longValue() {
/* 73 */     return (long)get();
/*    */   }
/*    */ 
/*    */   
/*    */   public float floatValue() {
/* 78 */     return (float)get();
/*    */   }
/*    */ 
/*    */   
/*    */   public double doubleValue() {
/* 83 */     return get();
/*    */   }
/*    */   
/*    */   public ImDouble() {}
/*    */ }


/* Location:              C:\Users\rapha\Downloads\aurora.jar!\META-INF\jars\imgui-java-binding-1.90.0.jar!\imgui\type\ImDouble.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */