/*    */ package imgui.type;
/*    */ 
/*    */ public final class ImBoolean implements Cloneable, Comparable<ImBoolean> {
/*  4 */   private final boolean[] data = new boolean[] { false };
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public ImBoolean(ImBoolean imBoolean) {
/* 10 */     this.data[0] = imBoolean.data[0];
/*    */   }
/*    */   
/*    */   public ImBoolean(boolean value) {
/* 14 */     this.data[0] = value;
/*    */   }
/*    */   
/*    */   public boolean get() {
/* 18 */     return this.data[0];
/*    */   }
/*    */   
/*    */   public boolean[] getData() {
/* 22 */     return this.data;
/*    */   }
/*    */   
/*    */   public void set(boolean value) {
/* 26 */     this.data[0] = value;
/*    */   }
/*    */   
/*    */   public void set(ImBoolean value) {
/* 30 */     set(value.get());
/*    */   }
/*    */ 
/*    */   
/*    */   public String toString() {
/* 35 */     return String.valueOf(this.data[0]);
/*    */   }
/*    */ 
/*    */   
/*    */   public boolean equals(Object o) {
/* 40 */     if (this == o) {
/* 41 */       return true;
/*    */     }
/* 43 */     if (o == null || getClass() != o.getClass()) {
/* 44 */       return false;
/*    */     }
/* 46 */     ImBoolean imBoolean = (ImBoolean)o;
/* 47 */     return (this.data[0] == imBoolean.data[0]);
/*    */   }
/*    */ 
/*    */   
/*    */   public int hashCode() {
/* 52 */     return Boolean.hashCode(this.data[0]);
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public ImBoolean clone() {
/* 58 */     return new ImBoolean(this);
/*    */   }
/*    */ 
/*    */   
/*    */   public int compareTo(ImBoolean o) {
/* 63 */     return Boolean.compare(get(), o.get());
/*    */   }
/*    */   
/*    */   public ImBoolean() {}
/*    */ }


/* Location:              C:\Users\rapha\Downloads\aurora.jar!\META-INF\jars\imgui-java-binding-1.90.0.jar!\imgui\type\ImBoolean.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */