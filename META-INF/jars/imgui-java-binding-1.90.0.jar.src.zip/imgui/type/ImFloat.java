/*    */ package imgui.type;
/*    */ 
/*    */ public final class ImFloat extends Number implements Cloneable, Comparable<ImFloat> {
/*  4 */   private final float[] data = new float[] { 0.0F };
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public ImFloat(ImFloat imFloat) {
/* 10 */     this.data[0] = imFloat.data[0];
/*    */   }
/*    */   
/*    */   public ImFloat(float value) {
/* 14 */     set(value);
/*    */   }
/*    */   
/*    */   public float get() {
/* 18 */     return this.data[0];
/*    */   }
/*    */   
/*    */   public float[] getData() {
/* 22 */     return this.data;
/*    */   }
/*    */   
/*    */   public void set(float value) {
/* 26 */     this.data[0] = value;
/*    */   }
/*    */   
/*    */   public void set(ImFloat value) {
/* 30 */     set(value.get());
/*    */   }
/*    */ 
/*    */   
/*    */   public String toString() {
/* 35 */     return String.valueOf(get());
/*    */   }
/*    */ 
/*    */   
/*    */   public boolean equals(Object o) {
/* 40 */     if (this == o) {
/* 41 */       return true;
/*    */     }
/* 43 */     if (o == null || getClass() != o.getClass()) {
/* 44 */       return false;
/*    */     }
/* 46 */     ImFloat imFloat = (ImFloat)o;
/* 47 */     return (this.data[0] == imFloat.data[0]);
/*    */   }
/*    */ 
/*    */   
/*    */   public int hashCode() {
/* 52 */     return Float.hashCode(this.data[0]);
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public ImFloat clone() {
/* 58 */     return new ImFloat(this);
/*    */   }
/*    */ 
/*    */   
/*    */   public int compareTo(ImFloat o) {
/* 63 */     return Float.compare(get(), o.get());
/*    */   }
/*    */ 
/*    */   
/*    */   public int intValue() {
/* 68 */     return (int)get();
/*    */   }
/*    */ 
/*    */   
/*    */   public long longValue() {
/* 73 */     return (long)get();
/*    */   }
/*    */ 
/*    */   
/*    */   public float floatValue() {
/* 78 */     return get();
/*    */   }
/*    */ 
/*    */   
/*    */   public double doubleValue() {
/* 83 */     return get();
/*    */   }
/*    */   
/*    */   public ImFloat() {}
/*    */ }


/* Location:              C:\Users\rapha\Downloads\aurora.jar!\META-INF\jars\imgui-java-binding-1.90.0.jar!\imgui\type\ImFloat.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */