/*     */ package imgui.type;
/*     */ 
/*     */ import java.nio.charset.StandardCharsets;
/*     */ import java.util.Objects;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class ImString
/*     */   implements Cloneable, Comparable<ImString>
/*     */ {
/*     */   public static final short DEFAULT_LENGTH = 100;
/*     */   public static final short CARET_LEN = 1;
/*  23 */   public final InputData inputData = new InputData();
/*     */   
/*     */   private byte[] data;
/*  26 */   private String text = "";
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ImString() {
/*  32 */     this(100);
/*     */   }
/*     */ 
/*     */   
/*     */   public ImString(ImString imString) {
/*  37 */     this(imString.text, imString.data.length);
/*  38 */     this.inputData.allowedChars = imString.inputData.allowedChars;
/*  39 */     this.inputData.isResizable = imString.inputData.isResizable;
/*  40 */     this.inputData.resizeFactor = imString.inputData.resizeFactor;
/*  41 */     this.inputData.size = imString.inputData.size;
/*  42 */     this.inputData.isDirty = imString.inputData.isDirty;
/*  43 */     this.inputData.isResized = imString.inputData.isResized;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ImString(int length) {
/*  52 */     this.data = new byte[length + 1];
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ImString(String text) {
/*  62 */     set(text, true, 0);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ImString(String text, int length) {
/*  72 */     this(length);
/*  73 */     set(text);
/*     */   }
/*     */   
/*     */   public String get() {
/*  77 */     if (this.inputData.isDirty) {
/*  78 */       this.inputData.isDirty = false;
/*  79 */       this.text = new String(this.data, 0, this.inputData.size, StandardCharsets.UTF_8);
/*     */     } 
/*  81 */     return this.text;
/*     */   }
/*     */   
/*     */   public byte[] getData() {
/*  85 */     return this.data;
/*     */   }
/*     */   
/*     */   public void set(Object object) {
/*  89 */     set(String.valueOf(object));
/*     */   }
/*     */   
/*     */   public void set(ImString value) {
/*  93 */     set(value.get(), true);
/*     */   }
/*     */   
/*     */   public void set(ImString value, boolean resize) {
/*  97 */     set(value.get(), resize);
/*     */   }
/*     */   
/*     */   public void set(String value) {
/* 101 */     set(value, this.inputData.isResizable, this.inputData.resizeFactor);
/*     */   }
/*     */   
/*     */   public void set(String value, boolean resize) {
/* 105 */     set(value, resize, this.inputData.resizeFactor);
/*     */   }
/*     */   
/*     */   public void set(String value, boolean resize, int resizeValue) {
/* 109 */     byte[] valueBuff = ((value == null) ? "null" : value).getBytes(StandardCharsets.UTF_8);
/* 110 */     int currentLen = (this.data == null) ? 0 : this.data.length;
/* 111 */     byte[] newBuff = null;
/*     */ 
/*     */     
/* 114 */     if (resize && currentLen - 1 < valueBuff.length) {
/* 115 */       newBuff = new byte[valueBuff.length + resizeValue + 1];
/* 116 */       this.inputData.size = valueBuff.length;
/*     */     } 
/*     */ 
/*     */     
/* 120 */     if (newBuff == null) {
/* 121 */       newBuff = new byte[currentLen];
/* 122 */       this.inputData.size = Math.max(0, Math.min(valueBuff.length, currentLen - 1));
/*     */     } 
/*     */     
/* 125 */     System.arraycopy(valueBuff, 0, newBuff, 0, Math.min(valueBuff.length, newBuff.length - 1));
/* 126 */     this.data = newBuff;
/* 127 */     this.inputData.isDirty = true;
/*     */   }
/*     */   
/*     */   public void resize(int newSize) {
/* 131 */     if (newSize < this.data.length) {
/* 132 */       throw new IllegalArgumentException("New size should be greater than current size of the buffer");
/*     */     }
/*     */     
/* 135 */     int size = newSize + 1;
/* 136 */     byte[] newBuffer = new byte[size];
/* 137 */     System.arraycopy(this.data, 0, newBuffer, 0, this.data.length);
/* 138 */     this.data = newBuffer;
/*     */   }
/*     */   
/*     */   byte[] resizeInternal(int newSize) {
/* 142 */     resize(newSize + this.inputData.resizeFactor);
/* 143 */     return this.data;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int getLength() {
/* 152 */     return get().length();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int getBufferSize() {
/* 161 */     return this.data.length;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isEmpty() {
/* 168 */     return (getLength() == 0);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isNotEmpty() {
/* 175 */     return !isEmpty();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void clear() {
/* 182 */     set("");
/*     */   }
/*     */ 
/*     */   
/*     */   public String toString() {
/* 187 */     return get();
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean equals(Object o) {
/* 192 */     if (this == o) {
/* 193 */       return true;
/*     */     }
/* 195 */     if (o == null || getClass() != o.getClass()) {
/* 196 */       return false;
/*     */     }
/* 198 */     ImString imString = (ImString)o;
/* 199 */     return Objects.equals(this.text, imString.text);
/*     */   }
/*     */ 
/*     */   
/*     */   public int hashCode() {
/* 204 */     return this.text.hashCode();
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public ImString clone() {
/* 210 */     return new ImString(this);
/*     */   }
/*     */ 
/*     */   
/*     */   public int compareTo(ImString o) {
/* 215 */     return get().compareTo(o.get());
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public static final class InputData
/*     */   {
/*     */     private static final short DEFAULT_RESIZE_FACTOR = 10;
/*     */ 
/*     */     
/*     */     private InputData() {}
/*     */ 
/*     */     
/* 228 */     public String allowedChars = "";
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public boolean isResizable;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 241 */     public int resizeFactor = 10;
/*     */     int size;
/*     */     boolean isDirty;
/*     */     boolean isResized = false;
/*     */   }
/*     */ }


/* Location:              C:\Users\rapha\Downloads\aurora.jar!\META-INF\jars\imgui-java-binding-1.90.0.jar!\imgui\type\ImString.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */