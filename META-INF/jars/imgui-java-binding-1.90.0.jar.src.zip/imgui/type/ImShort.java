/*    */ package imgui.type;
/*    */ 
/*    */ public final class ImShort extends Number implements Cloneable, Comparable<ImShort> {
/*  4 */   private final short[] data = new short[] { 0 };
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public ImShort(ImShort imShort) {
/* 10 */     this.data[0] = imShort.data[0];
/*    */   }
/*    */   
/*    */   public ImShort(short value) {
/* 14 */     set(value);
/*    */   }
/*    */   
/*    */   public short get() {
/* 18 */     return this.data[0];
/*    */   }
/*    */   
/*    */   public short[] getData() {
/* 22 */     return this.data;
/*    */   }
/*    */   
/*    */   public void set(short value) {
/* 26 */     this.data[0] = value;
/*    */   }
/*    */   
/*    */   public void set(ImShort value) {
/* 30 */     set(value.get());
/*    */   }
/*    */ 
/*    */   
/*    */   public String toString() {
/* 35 */     return String.valueOf(get());
/*    */   }
/*    */ 
/*    */   
/*    */   public boolean equals(Object o) {
/* 40 */     if (this == o) {
/* 41 */       return true;
/*    */     }
/* 43 */     if (o == null || getClass() != o.getClass()) {
/* 44 */       return false;
/*    */     }
/* 46 */     ImShort imShort = (ImShort)o;
/* 47 */     return (this.data[0] == imShort.data[0]);
/*    */   }
/*    */ 
/*    */   
/*    */   public int hashCode() {
/* 52 */     return Short.hashCode(this.data[0]);
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public ImShort clone() {
/* 58 */     return new ImShort(this);
/*    */   }
/*    */ 
/*    */   
/*    */   public int compareTo(ImShort o) {
/* 63 */     return Short.compare(get(), o.get());
/*    */   }
/*    */ 
/*    */   
/*    */   public int intValue() {
/* 68 */     return get();
/*    */   }
/*    */ 
/*    */   
/*    */   public long longValue() {
/* 73 */     return get();
/*    */   }
/*    */ 
/*    */   
/*    */   public float floatValue() {
/* 78 */     return get();
/*    */   }
/*    */ 
/*    */   
/*    */   public double doubleValue() {
/* 83 */     return get();
/*    */   }
/*    */   
/*    */   public ImShort() {}
/*    */ }


/* Location:              C:\Users\rapha\Downloads\aurora.jar!\META-INF\jars\imgui-java-binding-1.90.0.jar!\imgui\type\ImShort.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */