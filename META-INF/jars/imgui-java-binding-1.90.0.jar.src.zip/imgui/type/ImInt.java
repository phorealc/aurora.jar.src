/*    */ package imgui.type;
/*    */ 
/*    */ public final class ImInt extends Number implements Cloneable, Comparable<ImInt> {
/*  4 */   private final int[] data = new int[] { 0 };
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public ImInt(ImInt imInt) {
/* 10 */     this.data[0] = imInt.data[0];
/*    */   }
/*    */   
/*    */   public ImInt(int value) {
/* 14 */     set(value);
/*    */   }
/*    */   
/*    */   public int get() {
/* 18 */     return this.data[0];
/*    */   }
/*    */   
/*    */   public int[] getData() {
/* 22 */     return this.data;
/*    */   }
/*    */   
/*    */   public void set(int value) {
/* 26 */     this.data[0] = value;
/*    */   }
/*    */   
/*    */   public void set(ImInt value) {
/* 30 */     set(value.get());
/*    */   }
/*    */ 
/*    */   
/*    */   public String toString() {
/* 35 */     return String.valueOf(get());
/*    */   }
/*    */ 
/*    */   
/*    */   public boolean equals(Object o) {
/* 40 */     if (this == o) {
/* 41 */       return true;
/*    */     }
/* 43 */     if (o == null || getClass() != o.getClass()) {
/* 44 */       return false;
/*    */     }
/* 46 */     ImInt imInt = (ImInt)o;
/* 47 */     return (this.data[0] == imInt.data[0]);
/*    */   }
/*    */ 
/*    */   
/*    */   public int hashCode() {
/* 52 */     return Integer.hashCode(this.data[0]);
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public ImInt clone() {
/* 58 */     return new ImInt(this);
/*    */   }
/*    */ 
/*    */   
/*    */   public int compareTo(ImInt o) {
/* 63 */     return Integer.compare(get(), o.get());
/*    */   }
/*    */ 
/*    */   
/*    */   public int intValue() {
/* 68 */     return get();
/*    */   }
/*    */ 
/*    */   
/*    */   public long longValue() {
/* 73 */     return get();
/*    */   }
/*    */ 
/*    */   
/*    */   public float floatValue() {
/* 78 */     return get();
/*    */   }
/*    */ 
/*    */   
/*    */   public double doubleValue() {
/* 83 */     return get();
/*    */   }
/*    */   
/*    */   public ImInt() {}
/*    */ }


/* Location:              C:\Users\rapha\Downloads\aurora.jar!\META-INF\jars\imgui-java-binding-1.90.0.jar!\imgui\type\ImInt.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */