/*    */ package imgui.type;
/*    */ 
/*    */ public final class ImLong extends Number implements Cloneable, Comparable<ImLong> {
/*  4 */   private final long[] data = new long[] { 0L };
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public ImLong(ImLong imLong) {
/* 10 */     this.data[0] = imLong.data[0];
/*    */   }
/*    */   
/*    */   public ImLong(long value) {
/* 14 */     set(value);
/*    */   }
/*    */   
/*    */   public long get() {
/* 18 */     return this.data[0];
/*    */   }
/*    */   
/*    */   public long[] getData() {
/* 22 */     return this.data;
/*    */   }
/*    */   
/*    */   public void set(long value) {
/* 26 */     this.data[0] = value;
/*    */   }
/*    */   
/*    */   public void set(ImLong value) {
/* 30 */     set(value.get());
/*    */   }
/*    */ 
/*    */   
/*    */   public String toString() {
/* 35 */     return String.valueOf(get());
/*    */   }
/*    */ 
/*    */   
/*    */   public boolean equals(Object o) {
/* 40 */     if (this == o) {
/* 41 */       return true;
/*    */     }
/* 43 */     if (o == null || getClass() != o.getClass()) {
/* 44 */       return false;
/*    */     }
/* 46 */     ImLong imLong = (ImLong)o;
/* 47 */     return (this.data[0] == imLong.data[0]);
/*    */   }
/*    */ 
/*    */   
/*    */   public int hashCode() {
/* 52 */     return Long.hashCode(this.data[0]);
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public ImLong clone() {
/* 58 */     return new ImLong(this);
/*    */   }
/*    */ 
/*    */   
/*    */   public int compareTo(ImLong o) {
/* 63 */     return Long.compare(get(), o.get());
/*    */   }
/*    */ 
/*    */   
/*    */   public int intValue() {
/* 68 */     return (int)get();
/*    */   }
/*    */ 
/*    */   
/*    */   public long longValue() {
/* 73 */     return get();
/*    */   }
/*    */ 
/*    */   
/*    */   public float floatValue() {
/* 78 */     return (float)get();
/*    */   }
/*    */ 
/*    */   
/*    */   public double doubleValue() {
/* 83 */     return get();
/*    */   }
/*    */   
/*    */   public ImLong() {}
/*    */ }


/* Location:              C:\Users\rapha\Downloads\aurora.jar!\META-INF\jars\imgui-java-binding-1.90.0.jar!\imgui\type\ImLong.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */