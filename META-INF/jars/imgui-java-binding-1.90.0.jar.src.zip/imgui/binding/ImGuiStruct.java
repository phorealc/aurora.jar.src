/*    */ package imgui.binding;
/*    */ 
/*    */ import imgui.ImGui;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public abstract class ImGuiStruct
/*    */ {
/*    */   public long ptr;
/*    */   
/*    */   public ImGuiStruct(long ptr) {
/* 17 */     ImGui.init();
/* 18 */     this.ptr = ptr;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public final boolean isValidPtr() {
/* 27 */     return (this.ptr != 0L);
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public final boolean isNotValidPtr() {
/* 36 */     return !isValidPtr();
/*    */   }
/*    */ }


/* Location:              C:\Users\rapha\Downloads\aurora.jar!\META-INF\jars\imgui-java-binding-1.90.0.jar!\imgui\binding\ImGuiStruct.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */