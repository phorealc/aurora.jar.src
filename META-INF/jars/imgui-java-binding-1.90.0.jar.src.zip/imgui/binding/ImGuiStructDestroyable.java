/*    */ package imgui.binding;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public abstract class ImGuiStructDestroyable
/*    */   extends ImGuiStruct
/*    */ {
/*    */   public ImGuiStructDestroyable() {
/* 11 */     this(0L);
/* 12 */     this.ptr = create();
/*    */   }
/*    */   
/*    */   public ImGuiStructDestroyable(long ptr) {
/* 16 */     super(ptr);
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   protected abstract long create();
/*    */ 
/*    */   
/*    */   public void destroy() {
/* 25 */     nDestroy(this.ptr);
/*    */   }
/*    */   
/*    */   private native void nDestroy(long paramLong);
/*    */ }


/* Location:              C:\Users\rapha\Downloads\aurora.jar!\META-INF\jars\imgui-java-binding-1.90.0.jar!\imgui\binding\ImGuiStructDestroyable.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */