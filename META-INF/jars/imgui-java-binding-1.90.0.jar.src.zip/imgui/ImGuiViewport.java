/*     */ package imgui;
/*     */ 
/*     */ import imgui.binding.ImGuiStruct;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class ImGuiViewport
/*     */   extends ImGuiStruct
/*     */ {
/*     */   public ImGuiViewport(long ptr) {
/*  12 */     super(ptr);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int getID() {
/*  24 */     return nGetID();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setID(int value) {
/*  31 */     nSetID(value);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private native int nGetID();
/*     */ 
/*     */ 
/*     */   
/*     */   private native void nSetID(int paramInt);
/*     */ 
/*     */ 
/*     */   
/*     */   public int getFlags() {
/*  46 */     return nGetFlags();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setFlags(int value) {
/*  53 */     nSetFlags(value);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void addFlags(int flags) {
/*  60 */     setFlags(getFlags() | flags);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void removeFlags(int flags) {
/*  67 */     setFlags(getFlags() & (flags ^ 0xFFFFFFFF));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean hasFlags(int flags) {
/*  74 */     return ((getFlags() & flags) != 0);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private native int nGetFlags();
/*     */ 
/*     */ 
/*     */   
/*     */   private native void nSetFlags(int paramInt);
/*     */ 
/*     */ 
/*     */   
/*     */   public ImVec2 getPos() {
/*  89 */     ImVec2 dst = new ImVec2();
/*  90 */     nGetPos(dst);
/*  91 */     return dst;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public float getPosX() {
/*  98 */     return nGetPosX();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public float getPosY() {
/* 105 */     return nGetPosY();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void getPos(ImVec2 dst) {
/* 112 */     nGetPos(dst);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setPos(ImVec2 value) {
/* 119 */     nSetPos(value.x, value.y);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setPos(float valueX, float valueY) {
/* 126 */     nSetPos(valueX, valueY);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private native void nGetPos(ImVec2 paramImVec2);
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private native float nGetPosX();
/*     */ 
/*     */ 
/*     */   
/*     */   private native float nGetPosY();
/*     */ 
/*     */ 
/*     */   
/*     */   private native void nSetPos(float paramFloat1, float paramFloat2);
/*     */ 
/*     */ 
/*     */   
/*     */   public ImVec2 getSize() {
/* 150 */     ImVec2 dst = new ImVec2();
/* 151 */     nGetSize(dst);
/* 152 */     return dst;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public float getSizeX() {
/* 159 */     return nGetSizeX();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public float getSizeY() {
/* 166 */     return nGetSizeY();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void getSize(ImVec2 dst) {
/* 173 */     nGetSize(dst);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setSize(ImVec2 value) {
/* 180 */     nSetSize(value.x, value.y);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setSize(float valueX, float valueY) {
/* 187 */     nSetSize(valueX, valueY);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private native void nGetSize(ImVec2 paramImVec2);
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private native float nGetSizeX();
/*     */ 
/*     */ 
/*     */   
/*     */   private native float nGetSizeY();
/*     */ 
/*     */ 
/*     */   
/*     */   private native void nSetSize(float paramFloat1, float paramFloat2);
/*     */ 
/*     */ 
/*     */   
/*     */   public ImVec2 getWorkPos() {
/* 211 */     ImVec2 dst = new ImVec2();
/* 212 */     nGetWorkPos(dst);
/* 213 */     return dst;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public float getWorkPosX() {
/* 220 */     return nGetWorkPosX();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public float getWorkPosY() {
/* 227 */     return nGetWorkPosY();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void getWorkPos(ImVec2 dst) {
/* 234 */     nGetWorkPos(dst);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setWorkPos(ImVec2 value) {
/* 241 */     nSetWorkPos(value.x, value.y);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setWorkPos(float valueX, float valueY) {
/* 248 */     nSetWorkPos(valueX, valueY);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private native void nGetWorkPos(ImVec2 paramImVec2);
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private native float nGetWorkPosX();
/*     */ 
/*     */ 
/*     */   
/*     */   private native float nGetWorkPosY();
/*     */ 
/*     */ 
/*     */   
/*     */   private native void nSetWorkPos(float paramFloat1, float paramFloat2);
/*     */ 
/*     */ 
/*     */   
/*     */   public ImVec2 getWorkSize() {
/* 272 */     ImVec2 dst = new ImVec2();
/* 273 */     nGetWorkSize(dst);
/* 274 */     return dst;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public float getWorkSizeX() {
/* 281 */     return nGetWorkSizeX();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public float getWorkSizeY() {
/* 288 */     return nGetWorkSizeY();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void getWorkSize(ImVec2 dst) {
/* 295 */     nGetWorkSize(dst);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setWorkSize(ImVec2 value) {
/* 302 */     nSetWorkSize(value.x, value.y);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setWorkSize(float valueX, float valueY) {
/* 309 */     nSetWorkSize(valueX, valueY);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private native void nGetWorkSize(ImVec2 paramImVec2);
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private native float nGetWorkSizeX();
/*     */ 
/*     */ 
/*     */   
/*     */   private native float nGetWorkSizeY();
/*     */ 
/*     */ 
/*     */   
/*     */   private native void nSetWorkSize(float paramFloat1, float paramFloat2);
/*     */ 
/*     */ 
/*     */   
/*     */   public float getDpiScale() {
/* 333 */     return nGetDpiScale();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setDpiScale(float value) {
/* 340 */     nSetDpiScale(value);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private native float nGetDpiScale();
/*     */ 
/*     */ 
/*     */   
/*     */   private native void nSetDpiScale(float paramFloat);
/*     */ 
/*     */ 
/*     */   
/*     */   public int getParentViewportId() {
/* 355 */     return nGetParentViewportId();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setParentViewportId(int value) {
/* 362 */     nSetParentViewportId(value);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private native int nGetParentViewportId();
/*     */ 
/*     */ 
/*     */   
/*     */   private native void nSetParentViewportId(int paramInt);
/*     */ 
/*     */ 
/*     */   
/*     */   public ImDrawData getDrawData() {
/* 377 */     return new ImDrawData(nGetDrawData());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setDrawData(ImDrawData value) {
/* 384 */     nSetDrawData(value.ptr);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private native long nGetDrawData();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private native void nSetDrawData(long paramLong);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public native void setRendererUserData(Object paramObject);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public native Object getRendererUserData();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public native void setPlatformUserData(Object paramObject);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public native Object getPlatformUserData();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public native void setPlatformHandle(long paramLong);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public native long getPlatformHandle();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public native void setPlatformHandleRaw(long paramLong);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public native long getPlatformHandleRaw();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean getPlatformWindowCreated() {
/* 466 */     return nGetPlatformWindowCreated();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setPlatformWindowCreated(boolean value) {
/* 473 */     nSetPlatformWindowCreated(value);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private native boolean nGetPlatformWindowCreated();
/*     */ 
/*     */ 
/*     */   
/*     */   private native void nSetPlatformWindowCreated(boolean paramBoolean);
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean getPlatformRequestMove() {
/* 488 */     return nGetPlatformRequestMove();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setPlatformRequestMove(boolean value) {
/* 495 */     nSetPlatformRequestMove(value);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private native boolean nGetPlatformRequestMove();
/*     */ 
/*     */ 
/*     */   
/*     */   private native void nSetPlatformRequestMove(boolean paramBoolean);
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean getPlatformRequestResize() {
/* 510 */     return nGetPlatformRequestResize();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setPlatformRequestResize(boolean value) {
/* 517 */     nSetPlatformRequestResize(value);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private native boolean nGetPlatformRequestResize();
/*     */ 
/*     */ 
/*     */   
/*     */   private native void nSetPlatformRequestResize(boolean paramBoolean);
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean getPlatformRequestClose() {
/* 532 */     return nGetPlatformRequestClose();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setPlatformRequestClose(boolean value) {
/* 539 */     nSetPlatformRequestClose(value);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private native boolean nGetPlatformRequestClose();
/*     */ 
/*     */ 
/*     */   
/*     */   private native void nSetPlatformRequestClose(boolean paramBoolean);
/*     */ 
/*     */ 
/*     */   
/*     */   public ImVec2 getCenter() {
/* 553 */     ImVec2 dst = new ImVec2();
/* 554 */     nGetCenter(dst);
/* 555 */     return dst;
/*     */   }
/*     */   
/*     */   public float getCenterX() {
/* 559 */     return nGetCenterX();
/*     */   }
/*     */   
/*     */   public float getCenterY() {
/* 563 */     return nGetCenterY();
/*     */   }
/*     */   
/*     */   public void getCenter(ImVec2 dst) {
/* 567 */     nGetCenter(dst);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private native void nGetCenter(ImVec2 paramImVec2);
/*     */ 
/*     */ 
/*     */   
/*     */   private native float nGetCenterX();
/*     */ 
/*     */   
/*     */   private native float nGetCenterY();
/*     */ 
/*     */   
/*     */   public ImVec2 getWorkCenter() {
/* 583 */     ImVec2 dst = new ImVec2();
/* 584 */     nGetWorkCenter(dst);
/* 585 */     return dst;
/*     */   }
/*     */   
/*     */   public float getWorkCenterX() {
/* 589 */     return nGetWorkCenterX();
/*     */   }
/*     */   
/*     */   public float getWorkCenterY() {
/* 593 */     return nGetWorkCenterY();
/*     */   }
/*     */   
/*     */   public void getWorkCenter(ImVec2 dst) {
/* 597 */     nGetWorkCenter(dst);
/*     */   }
/*     */   
/*     */   private native void nGetWorkCenter(ImVec2 paramImVec2);
/*     */   
/*     */   private native float nGetWorkCenterX();
/*     */   
/*     */   private native float nGetWorkCenterY();
/*     */ }


/* Location:              C:\Users\rapha\Downloads\aurora.jar!\META-INF\jars\imgui-java-binding-1.90.0.jar!\imgui\ImGuiViewport.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */