/*     */ package imgui;
/*     */ 
/*     */ import imgui.binding.ImGuiStructDestroyable;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class ImGuiWindowClass
/*     */   extends ImGuiStructDestroyable
/*     */ {
/*     */   public ImGuiWindowClass() {}
/*     */   
/*     */   public ImGuiWindowClass(long ptr) {
/*  20 */     super(ptr);
/*     */   }
/*     */ 
/*     */   
/*     */   protected long create() {
/*  25 */     return nCreate();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private native long nCreate();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int getClassId() {
/*  41 */     return nGetClassId();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setClassId(int value) {
/*  48 */     nSetClassId(value);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private native int nGetClassId();
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private native void nSetClassId(int paramInt);
/*     */ 
/*     */ 
/*     */   
/*     */   public int getParentViewportId() {
/*  64 */     return nGetParentViewportId();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setParentViewportId(int value) {
/*  72 */     nSetParentViewportId(value);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private native int nGetParentViewportId();
/*     */ 
/*     */ 
/*     */   
/*     */   private native void nSetParentViewportId(int paramInt);
/*     */ 
/*     */ 
/*     */   
/*     */   public int getFocusRouteParentWindowId() {
/*  87 */     return nGetFocusRouteParentWindowId();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setFocusRouteParentWindowId(int value) {
/*  94 */     nSetFocusRouteParentWindowId(value);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private native int nGetFocusRouteParentWindowId();
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private native void nSetFocusRouteParentWindowId(int paramInt);
/*     */ 
/*     */ 
/*     */   
/*     */   public int getViewportFlagsOverrideSet() {
/* 110 */     return nGetViewportFlagsOverrideSet();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setViewportFlagsOverrideSet(int value) {
/* 118 */     nSetViewportFlagsOverrideSet(value);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void addViewportFlagsOverrideSet(int flags) {
/* 126 */     setViewportFlagsOverrideSet(getViewportFlagsOverrideSet() | flags);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void removeViewportFlagsOverrideSet(int flags) {
/* 134 */     setViewportFlagsOverrideSet(getViewportFlagsOverrideSet() & (flags ^ 0xFFFFFFFF));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean hasViewportFlagsOverrideSet(int flags) {
/* 142 */     return ((getViewportFlagsOverrideSet() & flags) != 0);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private native int nGetViewportFlagsOverrideSet();
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private native void nSetViewportFlagsOverrideSet(int paramInt);
/*     */ 
/*     */ 
/*     */   
/*     */   public int getViewportFlagsOverrideClear() {
/* 158 */     return nGetViewportFlagsOverrideClear();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setViewportFlagsOverrideClear(int value) {
/* 166 */     nSetViewportFlagsOverrideClear(value);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void addViewportFlagsOverrideClear(int flags) {
/* 174 */     setViewportFlagsOverrideClear(getViewportFlagsOverrideClear() | flags);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void removeViewportFlagsOverrideClear(int flags) {
/* 182 */     setViewportFlagsOverrideClear(getViewportFlagsOverrideClear() & (flags ^ 0xFFFFFFFF));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean hasViewportFlagsOverrideClear(int flags) {
/* 190 */     return ((getViewportFlagsOverrideClear() & flags) != 0);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private native int nGetViewportFlagsOverrideClear();
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private native void nSetViewportFlagsOverrideClear(int paramInt);
/*     */ 
/*     */ 
/*     */   
/*     */   public int getTabItemFlagsOverrideSet() {
/* 206 */     return nGetTabItemFlagsOverrideSet();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setTabItemFlagsOverrideSet(int value) {
/* 214 */     nSetTabItemFlagsOverrideSet(value);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void addTabItemFlagsOverrideSet(int flags) {
/* 222 */     setTabItemFlagsOverrideSet(getTabItemFlagsOverrideSet() | flags);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void removeTabItemFlagsOverrideSet(int flags) {
/* 230 */     setTabItemFlagsOverrideSet(getTabItemFlagsOverrideSet() & (flags ^ 0xFFFFFFFF));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean hasTabItemFlagsOverrideSet(int flags) {
/* 238 */     return ((getTabItemFlagsOverrideSet() & flags) != 0);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private native int nGetTabItemFlagsOverrideSet();
/*     */ 
/*     */ 
/*     */   
/*     */   private native void nSetTabItemFlagsOverrideSet(int paramInt);
/*     */ 
/*     */ 
/*     */   
/*     */   public int getDockNodeFlagsOverrideSet() {
/* 253 */     return nGetDockNodeFlagsOverrideSet();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setDockNodeFlagsOverrideSet(int value) {
/* 260 */     nSetDockNodeFlagsOverrideSet(value);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void addDockNodeFlagsOverrideSet(int flags) {
/* 267 */     setDockNodeFlagsOverrideSet(getDockNodeFlagsOverrideSet() | flags);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void removeDockNodeFlagsOverrideSet(int flags) {
/* 274 */     setDockNodeFlagsOverrideSet(getDockNodeFlagsOverrideSet() & (flags ^ 0xFFFFFFFF));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean hasDockNodeFlagsOverrideSet(int flags) {
/* 281 */     return ((getDockNodeFlagsOverrideSet() & flags) != 0);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private native int nGetDockNodeFlagsOverrideSet();
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private native void nSetDockNodeFlagsOverrideSet(int paramInt);
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean getDockingAlwaysTabBar() {
/* 297 */     return nGetDockingAlwaysTabBar();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setDockingAlwaysTabBar(boolean value) {
/* 305 */     nSetDockingAlwaysTabBar(value);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private native boolean nGetDockingAlwaysTabBar();
/*     */ 
/*     */ 
/*     */   
/*     */   private native void nSetDockingAlwaysTabBar(boolean paramBoolean);
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean getDockingAllowUnclassed() {
/* 320 */     return nGetDockingAllowUnclassed();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setDockingAllowUnclassed(boolean value) {
/* 327 */     nSetDockingAllowUnclassed(value);
/*     */   }
/*     */   
/*     */   private native boolean nGetDockingAllowUnclassed();
/*     */   
/*     */   private native void nSetDockingAllowUnclassed(boolean paramBoolean);
/*     */ }


/* Location:              C:\Users\rapha\Downloads\aurora.jar!\META-INF\jars\imgui-java-binding-1.90.0.jar!\imgui\ImGuiWindowClass.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */