/*       */ package imgui;
/*       */ 
/*       */ import imgui.assertion.ImAssertCallback;
/*       */ import imgui.callback.ImGuiInputTextCallback;
/*       */ import imgui.internal.ImGuiContext;
/*       */ import imgui.type.ImBoolean;
/*       */ import imgui.type.ImDouble;
/*       */ import imgui.type.ImFloat;
/*       */ import imgui.type.ImInt;
/*       */ import imgui.type.ImLong;
/*       */ import imgui.type.ImShort;
/*       */ import imgui.type.ImString;
/*       */ import java.io.IOException;
/*       */ import java.io.InputStream;
/*       */ import java.io.UncheckedIOException;
/*       */ import java.lang.ref.WeakReference;
/*       */ import java.nio.file.AccessDeniedException;
/*       */ import java.nio.file.CopyOption;
/*       */ import java.nio.file.Files;
/*       */ import java.nio.file.Path;
/*       */ import java.nio.file.Paths;
/*       */ import java.nio.file.StandardCopyOption;
/*       */ import java.nio.file.attribute.FileAttribute;
/*       */ import java.util.Optional;
/*       */ import java.util.Properties;
/*       */ 
/*       */ public class ImGui {
/*       */   private static final String LIB_PATH_PROP = "imgui.library.path";
/*       */   private static final String LIB_NAME_PROP = "imgui.library.name";
/*       */   private static final String LIB_NAME_DEFAULT = "imgui-java64";
/*       */   private static final String LIB_TMP_DIR_PREFIX = "imgui-java-natives";
/*       */   
/*       */   static {
/*    34 */     String libPath = System.getProperty("imgui.library.path");
/*    35 */     String libName = System.getProperty("imgui.library.name", "imgui-java64");
/*    36 */     String fullLibName = resolveFullLibName();
/*       */     
/*    38 */     if (libPath != null) {
/*    39 */       System.load(Paths.get(libPath, new String[0]).resolve(fullLibName).toAbsolutePath().toString());
/*       */     } else {
/*       */       try {
/*    42 */         System.loadLibrary(libName);
/*    43 */       } catch (Exception|Error e) {
/*    44 */         String extractedLibAbsPath = tryLoadFromClasspath(fullLibName);
/*    45 */         if (extractedLibAbsPath != null) {
/*    46 */           System.load(extractedLibAbsPath);
/*       */         } else {
/*    48 */           throw e;
/*       */         } 
/*       */       } 
/*       */     } 
/*       */     
/*    53 */     nInitJni();
/*    54 */     ImFontAtlas.nInit();
/*    55 */     ImGuiPlatformIO.init();
/*    56 */     nInitInputTextData();
/*       */     
/*    58 */     setAssertCallback(new ImAssertCallback()
/*       */         {
/*       */           public void imAssertCallback(String assertion, int line, String file) {
/*    61 */             System.err.println("Dear ImGui Assertion Failed: " + assertion);
/*    62 */             System.err.println("Assertion Located At: " + file + ":" + line);
/*    63 */             Thread.dumpStack();
/*       */           }
/*       */         });
/*       */   }
/*       */   private static String resolveFullLibName() {
/*       */     String libPrefix, libSuffix;
/*    69 */     boolean isWin = System.getProperty("os.name").toLowerCase().contains("win");
/*    70 */     boolean isMac = System.getProperty("os.name").toLowerCase().contains("mac");
/*       */ 
/*       */ 
/*       */     
/*    74 */     if (isWin) {
/*    75 */       libPrefix = "";
/*    76 */       libSuffix = ".dll";
/*    77 */     } else if (isMac) {
/*    78 */       libPrefix = "lib";
/*    79 */       libSuffix = ".dylib";
/*       */     } else {
/*    81 */       libPrefix = "lib";
/*    82 */       libSuffix = ".so";
/*       */     } 
/*       */     
/*    85 */     return System.getProperty("imgui.library.name", libPrefix + "imgui-java64" + libSuffix);
/*       */   }
/*       */ 
/*       */   
/*       */   private static String tryLoadFromClasspath(String fullLibName) {
/*    90 */     try (InputStream is = ImGui.class.getClassLoader().getResourceAsStream("io/imgui/java/native-bin/" + fullLibName)) {
/*    91 */       if (is == null) {
/*    92 */         return null;
/*       */       }
/*       */       
/*    95 */       String version = getVersionString().orElse("undefined");
/*    96 */       Path tmpDir = Paths.get(System.getProperty("java.io.tmpdir"), new String[0]).resolve("imgui-java-natives").resolve(version);
/*    97 */       if (!Files.exists(tmpDir, new java.nio.file.LinkOption[0])) {
/*    98 */         Files.createDirectories(tmpDir, (FileAttribute<?>[])new FileAttribute[0]);
/*       */       }
/*       */       
/*   101 */       Path libBin = tmpDir.resolve(fullLibName);
/*       */       try {
/*   103 */         Files.copy(is, libBin, new CopyOption[] { StandardCopyOption.REPLACE_EXISTING });
/*   104 */       } catch (AccessDeniedException e) {
/*   105 */         if (!Files.exists(libBin, new java.nio.file.LinkOption[0])) {
/*   106 */           throw e;
/*       */         }
/*       */       } 
/*       */       
/*   110 */       return libBin.toAbsolutePath().toString();
/*   111 */     } catch (IOException e) {
/*   112 */       throw new UncheckedIOException(e);
/*       */     } 
/*       */   }
/*       */   
/*       */   private static Optional<String> getVersionString() {
/*   117 */     Properties properties = new Properties();
/*   118 */     try (InputStream is = ImGui.class.getResourceAsStream("/imgui/imgui-java.properties")) {
/*   119 */       if (is != null) {
/*   120 */         properties.load(is);
/*   121 */         return Optional.of(properties.get("imgui.java.version").toString());
/*       */       } 
/*   123 */     } catch (IOException e) {
/*   124 */       throw new UncheckedIOException(e);
/*       */     } 
/*   126 */     return Optional.empty();
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static void init() {}
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static ImGuiContext createContext() {
/*   167 */     return new ImGuiContext(nCreateContext());
/*       */   }
/*       */   
/*       */   public static ImGuiContext createContext(ImFontAtlas sharedFontAtlas) {
/*   171 */     return new ImGuiContext(nCreateContext(sharedFontAtlas.ptr));
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static void destroyContext() {
/*   183 */     nDestroyContext();
/*       */   }
/*       */   
/*       */   public static void destroyContext(ImGuiContext ctx) {
/*   187 */     nDestroyContext(ctx.ptr);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static ImGuiContext getCurrentContext() {
/*   199 */     return new ImGuiContext(nGetCurrentContext());
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static void setCurrentContext(ImGuiContext ctx) {
/*   207 */     nSetCurrentContext(ctx.ptr);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*   216 */   private static final ImGuiIO _GETIO_1 = new ImGuiIO(0L);
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static ImGuiIO getIO() {
/*   222 */     _GETIO_1.ptr = nGetIO();
/*   223 */     return _GETIO_1;
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*   230 */   private static final ImGuiStyle _GETSTYLE_1 = new ImGuiStyle(0L);
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static ImGuiStyle getStyle() {
/*   236 */     _GETSTYLE_1.ptr = nGetStyle();
/*   237 */     return _GETSTYLE_1;
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static void newFrame() {
/*   248 */     nNewFrame();
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static void endFrame() {
/*   260 */     nEndFrame();
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static void render() {
/*   271 */     nRender();
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*   278 */   private static final ImDrawData _GETDRAWDATA_1 = new ImDrawData(0L);
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static ImDrawData getDrawData() {
/*   284 */     _GETDRAWDATA_1.ptr = nGetDrawData();
/*   285 */     return _GETDRAWDATA_1;
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static void showDemoWindow() {
/*   298 */     nShowDemoWindow();
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static void showDemoWindow(ImBoolean pOpen) {
/*   305 */     nShowDemoWindow((pOpen != null) ? pOpen.getData() : null);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static void showMetricsWindow() {
/*   322 */     nShowMetricsWindow();
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static void showMetricsWindow(ImBoolean pOpen) {
/*   329 */     nShowMetricsWindow((pOpen != null) ? pOpen.getData() : null);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static void showDebugLogWindow() {
/*   346 */     nShowDebugLogWindow();
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static void showDebugLogWindow(ImBoolean pOpen) {
/*   353 */     nShowDebugLogWindow((pOpen != null) ? pOpen.getData() : null);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static void showIDStackToolWindow() {
/*   370 */     nShowIDStackToolWindow();
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static void showIDStackToolWindow(ImBoolean pOpen) {
/*   377 */     nShowIDStackToolWindow((pOpen != null) ? pOpen.getData() : null);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static void showAboutWindow() {
/*   394 */     nShowAboutWindow();
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static void showAboutWindow(ImBoolean pOpen) {
/*   401 */     nShowAboutWindow((pOpen != null) ? pOpen.getData() : null);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static void showStyleEditor() {
/*   419 */     nShowStyleEditor();
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static void showStyleEditor(ImGuiStyle ref) {
/*   427 */     nShowStyleEditor(ref.ptr);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static boolean showStyleSelector(String label) {
/*   442 */     return nShowStyleSelector(label);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static void showFontSelector(String label) {
/*   456 */     nShowFontSelector(label);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static void showUserGuide() {
/*   469 */     nShowUserGuide();
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static String getVersion() {
/*   480 */     return nGetVersion();
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static void styleColorsDark() {
/*   493 */     nStyleColorsDark();
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static void styleColorsDark(ImGuiStyle style) {
/*   500 */     nStyleColorsDark(style.ptr);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static void styleColorsLight() {
/*   515 */     nStyleColorsLight();
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static void styleColorsLight(ImGuiStyle style) {
/*   522 */     nStyleColorsLight(style.ptr);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static void styleColorsClassic() {
/*   537 */     nStyleColorsClassic();
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static void styleColorsClassic(ImGuiStyle style) {
/*   544 */     nStyleColorsClassic(style.ptr);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static boolean begin(String title) {
/*   569 */     return nBegin(title);
/*       */   }
/*       */   
/*       */   public static boolean begin(String title, ImBoolean pOpen) {
/*   573 */     return nBegin(title, (pOpen != null) ? pOpen.getData() : null);
/*       */   }
/*       */   
/*       */   public static boolean begin(String title, ImBoolean pOpen, int imGuiWindowFlags) {
/*   577 */     return nBegin(title, (pOpen != null) ? pOpen.getData() : null, imGuiWindowFlags);
/*       */   }
/*       */   
/*       */   public static boolean begin(String title, int imGuiWindowFlags) {
/*   581 */     return nBegin(title, imGuiWindowFlags);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static void end() {
/*   617 */     nEnd();
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static boolean beginChild(String strId) {
/*   644 */     return nBeginChild(strId);
/*       */   }
/*       */   
/*       */   public static boolean beginChild(String strId, ImVec2 size) {
/*   648 */     return nBeginChild(strId, size.x, size.y);
/*       */   }
/*       */   
/*       */   public static boolean beginChild(String strId, float sizeX, float sizeY) {
/*   652 */     return nBeginChild(strId, sizeX, sizeY);
/*       */   }
/*       */   
/*       */   public static boolean beginChild(String strId, ImVec2 size, int childFlags) {
/*   656 */     return nBeginChild(strId, size.x, size.y, childFlags);
/*       */   }
/*       */   
/*       */   public static boolean beginChild(String strId, float sizeX, float sizeY, int childFlags) {
/*   660 */     return nBeginChild(strId, sizeX, sizeY, childFlags);
/*       */   }
/*       */   
/*       */   public static boolean beginChild(String strId, ImVec2 size, int childFlags, int windowFlags) {
/*   664 */     return nBeginChild(strId, size.x, size.y, childFlags, windowFlags);
/*       */   }
/*       */   
/*       */   public static boolean beginChild(String strId, float sizeX, float sizeY, int childFlags, int windowFlags) {
/*   668 */     return nBeginChild(strId, sizeX, sizeY, childFlags, windowFlags);
/*       */   }
/*       */   
/*       */   public static boolean beginChild(String strId, int childFlags, int windowFlags) {
/*   672 */     return nBeginChild(strId, childFlags, windowFlags);
/*       */   }
/*       */   
/*       */   public static boolean beginChild(String strId, int windowFlags) {
/*   676 */     return nBeginChild(strId, windowFlags);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static boolean beginChild(int id) {
/*   725 */     return nBeginChild(id);
/*       */   }
/*       */   
/*       */   public static boolean beginChild(int id, ImVec2 size) {
/*   729 */     return nBeginChild(id, size.x, size.y);
/*       */   }
/*       */   
/*       */   public static boolean beginChild(int id, float sizeX, float sizeY) {
/*   733 */     return nBeginChild(id, sizeX, sizeY);
/*       */   }
/*       */   
/*       */   public static boolean beginChild(int id, ImVec2 size, int childFlags) {
/*   737 */     return nBeginChild(id, size.x, size.y, childFlags);
/*       */   }
/*       */   
/*       */   public static boolean beginChild(int id, float sizeX, float sizeY, int childFlags) {
/*   741 */     return nBeginChild(id, sizeX, sizeY, childFlags);
/*       */   }
/*       */   
/*       */   public static boolean beginChild(int id, ImVec2 size, int childFlags, int windowFlags) {
/*   745 */     return nBeginChild(id, size.x, size.y, childFlags, windowFlags);
/*       */   }
/*       */   
/*       */   public static boolean beginChild(int id, float sizeX, float sizeY, int childFlags, int windowFlags) {
/*   749 */     return nBeginChild(id, sizeX, sizeY, childFlags, windowFlags);
/*       */   }
/*       */   
/*       */   public static boolean beginChild(int id, int childFlags, int windowFlags) {
/*   753 */     return nBeginChild(id, childFlags, windowFlags);
/*       */   }
/*       */   
/*       */   public static boolean beginChild(int id, int windowFlags) {
/*   757 */     return nBeginChild(id, windowFlags);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static boolean beginChild(String strId, ImVec2 size, boolean border) {
/*   791 */     return nBeginChild(strId, size.x, size.y, border);
/*       */   }
/*       */   
/*       */   public static boolean beginChild(String strId, float sizeX, float sizeY, boolean border) {
/*   795 */     return nBeginChild(strId, sizeX, sizeY, border);
/*       */   }
/*       */   
/*       */   public static boolean beginChild(String strId, ImVec2 size, boolean border, int windowFlags) {
/*   799 */     return nBeginChild(strId, size.x, size.y, border, windowFlags);
/*       */   }
/*       */   
/*       */   public static boolean beginChild(String strId, float sizeX, float sizeY, boolean border, int windowFlags) {
/*   803 */     return nBeginChild(strId, sizeX, sizeY, border, windowFlags);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   @Deprecated
/*       */   public static boolean beginChild(int id, ImVec2 size, boolean border) {
/*   828 */     return nBeginChild(id, size.x, size.y, border);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   @Deprecated
/*       */   public static boolean beginChild(int id, float sizeX, float sizeY, boolean border) {
/*   837 */     return nBeginChild(id, sizeX, sizeY, border);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   @Deprecated
/*       */   public static boolean beginChild(int id, ImVec2 size, boolean border, int windowFlags) {
/*   846 */     return nBeginChild(id, size.x, size.y, border, windowFlags);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   @Deprecated
/*       */   public static boolean beginChild(int id, float sizeX, float sizeY, boolean border, int windowFlags) {
/*   855 */     return nBeginChild(id, sizeX, sizeY, border, windowFlags);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static void endChild() {
/*   871 */     nEndChild();
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static boolean isWindowAppearing() {
/*   882 */     return nIsWindowAppearing();
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static boolean isWindowCollapsed() {
/*   890 */     return nIsWindowCollapsed();
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static boolean isWindowFocused() {
/*   901 */     return nIsWindowFocused();
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static boolean isWindowFocused(int imGuiFocusedFlags) {
/*   908 */     return nIsWindowFocused(imGuiFocusedFlags);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static boolean isWindowHovered() {
/*   926 */     return nIsWindowHovered();
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static boolean isWindowHovered(int imGuiHoveredFlags) {
/*   936 */     return nIsWindowHovered(imGuiHoveredFlags);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static ImDrawList getWindowDrawList() {
/*   951 */     return new ImDrawList(nGetWindowDrawList());
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static float getWindowDpiScale() {
/*   962 */     return nGetWindowDpiScale();
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static ImVec2 getWindowPos() {
/*   974 */     ImVec2 dst = new ImVec2();
/*   975 */     nGetWindowPos(dst);
/*   976 */     return dst;
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static float getWindowPosX() {
/*   984 */     return nGetWindowPosX();
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static float getWindowPosY() {
/*   992 */     return nGetWindowPosY();
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static void getWindowPos(ImVec2 dst) {
/*  1000 */     nGetWindowPos(dst);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static ImVec2 getWindowSize() {
/*  1019 */     ImVec2 dst = new ImVec2();
/*  1020 */     nGetWindowSize(dst);
/*  1021 */     return dst;
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static float getWindowSizeX() {
/*  1028 */     return nGetWindowSizeX();
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static float getWindowSizeY() {
/*  1035 */     return nGetWindowSizeY();
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static void getWindowSize(ImVec2 dst) {
/*  1042 */     nGetWindowSize(dst);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static float getWindowWidth() {
/*  1061 */     return nGetWindowWidth();
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static float getWindowHeight() {
/*  1072 */     return nGetWindowHeight();
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static ImGuiViewport getWindowViewport() {
/*  1083 */     return new ImGuiViewport(nGetWindowViewport());
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static void setNextWindowPos(ImVec2 pos) {
/*  1096 */     nSetNextWindowPos(pos.x, pos.y);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static void setNextWindowPos(float posX, float posY) {
/*  1103 */     nSetNextWindowPos(posX, posY);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static void setNextWindowPos(ImVec2 pos, int cond) {
/*  1110 */     nSetNextWindowPos(pos.x, pos.y, cond);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static void setNextWindowPos(float posX, float posY, int cond) {
/*  1117 */     nSetNextWindowPos(posX, posY, cond);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static void setNextWindowPos(ImVec2 pos, int cond, ImVec2 pivot) {
/*  1124 */     nSetNextWindowPos(pos.x, pos.y, cond, pivot.x, pivot.y);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static void setNextWindowPos(float posX, float posY, int cond, float pivotX, float pivotY) {
/*  1131 */     nSetNextWindowPos(posX, posY, cond, pivotX, pivotY);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static void setNextWindowPos(ImVec2 pos, ImVec2 pivot) {
/*  1138 */     nSetNextWindowPos(pos.x, pos.y, pivot.x, pivot.y);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static void setNextWindowPos(float posX, float posY, float pivotX, float pivotY) {
/*  1145 */     nSetNextWindowPos(posX, posY, pivotX, pivotY);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static void setNextWindowSize(ImVec2 size) {
/*  1174 */     nSetNextWindowSize(size.x, size.y);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static void setNextWindowSize(float sizeX, float sizeY) {
/*  1181 */     nSetNextWindowSize(sizeX, sizeY);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static void setNextWindowSize(ImVec2 size, int cond) {
/*  1188 */     nSetNextWindowSize(size.x, size.y, cond);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static void setNextWindowSize(float sizeX, float sizeY, int cond) {
/*  1195 */     nSetNextWindowSize(sizeX, sizeY, cond);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static void setNextWindowSizeConstraints(ImVec2 sizeMin, ImVec2 sizeMax) {
/*  1213 */     nSetNextWindowSizeConstraints(sizeMin.x, sizeMin.y, sizeMax.x, sizeMax.y);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static void setNextWindowSizeConstraints(float sizeMinX, float sizeMinY, float sizeMaxX, float sizeMaxY) {
/*  1221 */     nSetNextWindowSizeConstraints(sizeMinX, sizeMinY, sizeMaxX, sizeMaxY);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static void setNextWindowContentSize(ImVec2 size) {
/*  1235 */     nSetNextWindowContentSize(size.x, size.y);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static void setNextWindowContentSize(float sizeX, float sizeY) {
/*  1243 */     nSetNextWindowContentSize(sizeX, sizeY);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static void setNextWindowCollapsed(boolean collapsed) {
/*  1255 */     nSetNextWindowCollapsed(collapsed);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static void setNextWindowCollapsed(boolean collapsed, int cond) {
/*  1262 */     nSetNextWindowCollapsed(collapsed, cond);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static void setNextWindowFocus() {
/*  1277 */     nSetNextWindowFocus();
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static void setNextWindowScroll(ImVec2 scroll) {
/*  1288 */     nSetNextWindowScroll(scroll.x, scroll.y);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static void setNextWindowScroll(float scrollX, float scrollY) {
/*  1295 */     nSetNextWindowScroll(scrollX, scrollY);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static void setNextWindowBgAlpha(float alpha) {
/*  1308 */     nSetNextWindowBgAlpha(alpha);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static void setNextWindowViewport(int viewportId) {
/*  1319 */     nSetNextWindowViewport(viewportId);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static void setWindowPos(ImVec2 pos) {
/*  1331 */     nSetWindowPos(pos.x, pos.y);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static void setWindowPos(float posX, float posY) {
/*  1339 */     nSetWindowPos(posX, posY);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static void setWindowPos(ImVec2 pos, int cond) {
/*  1347 */     nSetWindowPos(pos.x, pos.y, cond);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static void setWindowPos(float posX, float posY, int cond) {
/*  1355 */     nSetWindowPos(posX, posY, cond);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static void setWindowSize(ImVec2 size) {
/*  1373 */     nSetWindowSize(size.x, size.y);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static void setWindowSize(float sizeX, float sizeY) {
/*  1381 */     nSetWindowSize(sizeX, sizeY);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static void setWindowSize(ImVec2 size, int cond) {
/*  1389 */     nSetWindowSize(size.x, size.y, cond);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static void setWindowSize(float sizeX, float sizeY, int cond) {
/*  1397 */     nSetWindowSize(sizeX, sizeY, cond);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static void setWindowCollapsed(boolean collapsed) {
/*  1414 */     nSetWindowCollapsed(collapsed);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static void setWindowCollapsed(boolean collapsed, int cond) {
/*  1421 */     nSetWindowCollapsed(collapsed, cond);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static void setWindowFocus() {
/*  1436 */     nSetWindowFocus();
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static void setWindowFontScale(float scale) {
/*  1448 */     nSetWindowFontScale(scale);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static void setWindowPos(String name, ImVec2 pos) {
/*  1459 */     nSetWindowPos(name, pos.x, pos.y);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static void setWindowPos(String name, float posX, float posY) {
/*  1466 */     nSetWindowPos(name, posX, posY);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static void setWindowPos(String name, ImVec2 pos, int cond) {
/*  1473 */     nSetWindowPos(name, pos.x, pos.y, cond);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static void setWindowPos(String name, float posX, float posY, int cond) {
/*  1480 */     nSetWindowPos(name, posX, posY, cond);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static void setWindowSize(String name, ImVec2 size) {
/*  1501 */     nSetWindowSize(name, size.x, size.y);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static void setWindowSize(String name, float sizeX, float sizeY) {
/*  1508 */     nSetWindowSize(name, sizeX, sizeY);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static void setWindowSize(String name, ImVec2 size, int cond) {
/*  1515 */     nSetWindowSize(name, size.x, size.y, cond);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static void setWindowSize(String name, float sizeX, float sizeY, int cond) {
/*  1522 */     nSetWindowSize(name, sizeX, sizeY, cond);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static void setWindowCollapsed(String name, boolean collapsed) {
/*  1543 */     nSetWindowCollapsed(name, collapsed);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static void setWindowCollapsed(String name, boolean collapsed, int cond) {
/*  1550 */     nSetWindowCollapsed(name, collapsed, cond);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static void setWindowFocus(String name) {
/*  1569 */     nSetWindowFocus(name);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static ImVec2 getContentRegionAvail() {
/*  1586 */     ImVec2 dst = new ImVec2();
/*  1587 */     nGetContentRegionAvail(dst);
/*  1588 */     return dst;
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static float getContentRegionAvailX() {
/*  1595 */     return nGetContentRegionAvailX();
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static float getContentRegionAvailY() {
/*  1602 */     return nGetContentRegionAvailY();
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static void getContentRegionAvail(ImVec2 dst) {
/*  1609 */     nGetContentRegionAvail(dst);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static ImVec2 getContentRegionMax() {
/*  1628 */     ImVec2 dst = new ImVec2();
/*  1629 */     nGetContentRegionMax(dst);
/*  1630 */     return dst;
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static float getContentRegionMaxX() {
/*  1637 */     return nGetContentRegionMaxX();
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static float getContentRegionMaxY() {
/*  1644 */     return nGetContentRegionMaxY();
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static void getContentRegionMax(ImVec2 dst) {
/*  1651 */     nGetContentRegionMax(dst);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static ImVec2 getWindowContentRegionMin() {
/*  1670 */     ImVec2 dst = new ImVec2();
/*  1671 */     nGetWindowContentRegionMin(dst);
/*  1672 */     return dst;
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static float getWindowContentRegionMinX() {
/*  1679 */     return nGetWindowContentRegionMinX();
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static float getWindowContentRegionMinY() {
/*  1686 */     return nGetWindowContentRegionMinY();
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static void getWindowContentRegionMin(ImVec2 dst) {
/*  1693 */     nGetWindowContentRegionMin(dst);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static ImVec2 getWindowContentRegionMax() {
/*  1712 */     ImVec2 dst = new ImVec2();
/*  1713 */     nGetWindowContentRegionMax(dst);
/*  1714 */     return dst;
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static float getWindowContentRegionMaxX() {
/*  1721 */     return nGetWindowContentRegionMaxX();
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static float getWindowContentRegionMaxY() {
/*  1728 */     return nGetWindowContentRegionMaxY();
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static void getWindowContentRegionMax(ImVec2 dst) {
/*  1735 */     nGetWindowContentRegionMax(dst);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static float getScrollX() {
/*  1758 */     return nGetScrollX();
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static float getScrollY() {
/*  1769 */     return nGetScrollY();
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static void setScrollX(float scrollX) {
/*  1780 */     nSetScrollX(scrollX);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static void setScrollY(float scrollY) {
/*  1791 */     nSetScrollY(scrollY);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static float getScrollMaxX() {
/*  1802 */     return nGetScrollMaxX();
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static float getScrollMaxY() {
/*  1813 */     return nGetScrollMaxY();
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static void setScrollHereX() {
/*  1825 */     nSetScrollHereX();
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static void setScrollHereX(float centerXRatio) {
/*  1833 */     nSetScrollHereX(centerXRatio);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static void setScrollHereY() {
/*  1849 */     nSetScrollHereY();
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static void setScrollHereY(float centerYRatio) {
/*  1857 */     nSetScrollHereY(centerYRatio);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static void setScrollFromPosX(float localX) {
/*  1872 */     nSetScrollFromPosX(localX);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static void setScrollFromPosX(float localX, float centerXRatio) {
/*  1879 */     nSetScrollFromPosX(localX, centerXRatio);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static void setScrollFromPosY(float localY) {
/*  1894 */     nSetScrollFromPosY(localY);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static void setScrollFromPosY(float localY, float centerYRatio) {
/*  1901 */     nSetScrollFromPosY(localY, centerYRatio);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static void pushFont(ImFont font) {
/*  1915 */     nPushFont(font.ptr);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static void popFont() {
/*  1923 */     nPopFont();
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static void pushStyleColor(int imGuiCol, ImVec4 col) {
/*  1941 */     nPushStyleColor(imGuiCol, col.x, col.y, col.z, col.w);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static void pushStyleColor(int imGuiCol, float colX, float colY, float colZ, float colW) {
/*  1948 */     nPushStyleColor(imGuiCol, colX, colY, colZ, colW);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static void pushStyleColor(int imGuiCol, int col) {
/*  1960 */     nPushStyleColor(imGuiCol, col);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static void popStyleColor() {
/*  1968 */     nPopStyleColor();
/*       */   }
/*       */   
/*       */   public static void popStyleColor(int count) {
/*  1972 */     nPopStyleColor(count);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static void pushStyleVar(int imGuiStyleVar, float val) {
/*  1987 */     nPushStyleVar(imGuiStyleVar, val);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static void pushStyleVar(int imGuiStyleVar, ImVec2 val) {
/*  1998 */     nPushStyleVar(imGuiStyleVar, val.x, val.y);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static void pushStyleVar(int imGuiStyleVar, float valX, float valY) {
/*  2005 */     nPushStyleVar(imGuiStyleVar, valX, valY);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static void popStyleVar() {
/*  2014 */     nPopStyleVar();
/*       */   }
/*       */   
/*       */   public static void popStyleVar(int count) {
/*  2018 */     nPopStyleVar(count);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static void pushTabStop(boolean tabStop) {
/*  2033 */     nPushTabStop(tabStop);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static void popTabStop() {
/*  2041 */     nPopTabStop();
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static void pushButtonRepeat(boolean repeat) {
/*  2053 */     nPushButtonRepeat(repeat);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static void popButtonRepeat() {
/*  2061 */     nPopButtonRepeat();
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static void pushItemWidth(float itemWidth) {
/*  2075 */     nPushItemWidth(itemWidth);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static void popItemWidth() {
/*  2083 */     nPopItemWidth();
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static void setNextItemWidth(float itemWidth) {
/*  2095 */     nSetNextItemWidth(itemWidth);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static float calcItemWidth() {
/*  2106 */     return nCalcItemWidth();
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static void pushTextWrapPos() {
/*  2118 */     nPushTextWrapPos();
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static void pushTextWrapPos(float wrapLocalPosX) {
/*  2126 */     nPushTextWrapPos(wrapLocalPosX);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static void popTextWrapPos() {
/*  2138 */     nPopTextWrapPos();
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*  2148 */   private static final ImFont _GETFONT_1 = new ImFont(0L);
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static ImFont getFont() {
/*  2154 */     _GETFONT_1.ptr = nGetFont();
/*  2155 */     return _GETFONT_1;
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static int getFontSize() {
/*  2166 */     return nGetFontSize();
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static ImVec2 getFontTexUvWhitePixel() {
/*  2177 */     ImVec2 dst = new ImVec2();
/*  2178 */     nGetFontTexUvWhitePixel(dst);
/*  2179 */     return dst;
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static float getFontTexUvWhitePixelX() {
/*  2186 */     return nGetFontTexUvWhitePixelX();
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static float getFontTexUvWhitePixelY() {
/*  2193 */     return nGetFontTexUvWhitePixelY();
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static void getFontTexUvWhitePixel(ImVec2 dst) {
/*  2200 */     nGetFontTexUvWhitePixel(dst);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static int getColorU32(int idx) {
/*  2219 */     return nGetColorU32(idx);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static int getColorU32(int idx, float alphaMul) {
/*  2226 */     return nGetColorU32(idx, alphaMul);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static int getColorU32(ImVec4 col) {
/*  2241 */     return nGetColorU32(col.x, col.y, col.z, col.w);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static int getColorU32(float colX, float colY, float colZ, float colW) {
/*  2248 */     return nGetColorU32(colX, colY, colZ, colW);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static int getColorU32i(int col) {
/*  2261 */     return nGetColorU32i(col);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static int getColorU32i(int col, float alphaMul) {
/*  2268 */     return nGetColorU32i(col, alphaMul);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static ImVec4 getStyleColorVec4(int imGuiColIdx) {
/*  2284 */     ImVec4 dst = new ImVec4();
/*  2285 */     nGetStyleColorVec4(dst, imGuiColIdx);
/*  2286 */     return dst;
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static float getStyleColorVec4X(int imGuiColIdx) {
/*  2294 */     return nGetStyleColorVec4X(imGuiColIdx);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static float getStyleColorVec4Y(int imGuiColIdx) {
/*  2302 */     return nGetStyleColorVec4Y(imGuiColIdx);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static float getStyleColorVec4Z(int imGuiColIdx) {
/*  2310 */     return nGetStyleColorVec4Z(imGuiColIdx);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static float getStyleColorVec4W(int imGuiColIdx) {
/*  2318 */     return nGetStyleColorVec4W(imGuiColIdx);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static void getStyleColorVec4(ImVec4 dst, int imGuiColIdx) {
/*  2326 */     nGetStyleColorVec4(dst, imGuiColIdx);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static ImVec2 getCursorScreenPos() {
/*  2362 */     ImVec2 dst = new ImVec2();
/*  2363 */     nGetCursorScreenPos(dst);
/*  2364 */     return dst;
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static float getCursorScreenPosX() {
/*  2371 */     return nGetCursorScreenPosX();
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static float getCursorScreenPosY() {
/*  2378 */     return nGetCursorScreenPosY();
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static void getCursorScreenPos(ImVec2 dst) {
/*  2385 */     nGetCursorScreenPos(dst);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static void setCursorScreenPos(ImVec2 pos) {
/*  2404 */     nSetCursorScreenPos(pos.x, pos.y);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static void setCursorScreenPos(float posX, float posY) {
/*  2411 */     nSetCursorScreenPos(posX, posY);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static ImVec2 getCursorPos() {
/*  2423 */     ImVec2 dst = new ImVec2();
/*  2424 */     nGetCursorPos(dst);
/*  2425 */     return dst;
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static float getCursorPosX() {
/*  2432 */     return nGetCursorPosX();
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static float getCursorPosY() {
/*  2439 */     return nGetCursorPosY();
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static void getCursorPos(ImVec2 dst) {
/*  2446 */     nGetCursorPos(dst);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static void setCursorPos(ImVec2 localPos) {
/*  2465 */     nSetCursorPos(localPos.x, localPos.y);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static void setCursorPos(float localPosX, float localPosY) {
/*  2472 */     nSetCursorPos(localPosX, localPosY);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static void setCursorPosX(float localX) {
/*  2484 */     nSetCursorPosX(localX);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static void setCursorPosY(float localY) {
/*  2495 */     nSetCursorPosY(localY);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static ImVec2 getCursorStartPos() {
/*  2506 */     ImVec2 dst = new ImVec2();
/*  2507 */     nGetCursorStartPos(dst);
/*  2508 */     return dst;
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static float getCursorStartPosX() {
/*  2515 */     return nGetCursorStartPosX();
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static float getCursorStartPosY() {
/*  2522 */     return nGetCursorStartPosY();
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static void getCursorStartPos(ImVec2 dst) {
/*  2529 */     nGetCursorStartPos(dst);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static void separator() {
/*  2550 */     nSeparator();
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static void sameLine() {
/*  2561 */     nSameLine();
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static void sameLine(float offsetFromStartX) {
/*  2568 */     nSameLine(offsetFromStartX);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static void sameLine(float offsetFromStartX, float spacing) {
/*  2575 */     nSameLine(offsetFromStartX, spacing);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static void newLine() {
/*  2594 */     nNewLine();
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static void spacing() {
/*  2605 */     nSpacing();
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static void dummy(ImVec2 size) {
/*  2616 */     nDummy(size.x, size.y);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static void dummy(float sizeX, float sizeY) {
/*  2623 */     nDummy(sizeX, sizeY);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static void indent() {
/*  2635 */     nIndent();
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static void indent(float indentW) {
/*  2642 */     nIndent(indentW);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static void unindent() {
/*  2657 */     nUnindent();
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static void unindent(float indentW) {
/*  2664 */     nUnindent(indentW);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static void beginGroup() {
/*  2679 */     nBeginGroup();
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static void endGroup() {
/*  2690 */     nEndGroup();
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static void alignTextToFramePadding() {
/*  2706 */     nAlignTextToFramePadding();
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static float getTextLineHeight() {
/*  2717 */     return nGetTextLineHeight();
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static float getTextLineHeightWithSpacing() {
/*  2728 */     return nGetTextLineHeightWithSpacing();
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static float getFrameHeight() {
/*  2739 */     return nGetFrameHeight();
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static float getFrameHeightWithSpacing() {
/*  2750 */     return nGetFrameHeightWithSpacing();
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static void pushID(String strId) {
/*  2773 */     nPushID(strId);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static void pushID(String strIdBegin, String strIdEnd) {
/*  2786 */     nPushID(strIdBegin, strIdEnd);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static void pushID(long ptrId) {
/*  2801 */     nPushID(ptrId);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static void pushID(int intId) {
/*  2812 */     nPushID(intId);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static void popID() {
/*  2823 */     nPopID();
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static int getID(String strId) {
/*  2834 */     return nGetID(strId);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static int getID(String strIdBegin, String strIdEnd) {
/*  2848 */     return nGetID(strIdBegin, strIdEnd);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static int getID(long ptrId) {
/*  2864 */     return nGetID(ptrId);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static void textUnformatted(String text) {
/*  2879 */     nTextUnformatted(text);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static void textUnformatted(String text, String textEnd) {
/*  2888 */     nTextUnformatted(text, textEnd);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static void text(String text) {
/*  2909 */     nText(text);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static void textColored(ImVec4 col, String text) {
/*  2922 */     nTextColored(col.x, col.y, col.z, col.w, text);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static void textColored(float colX, float colY, float colZ, float colW, String text) {
/*  2929 */     nTextColored(colX, colY, colZ, colW, text);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static void textDisabled(String text) {
/*  2957 */     nTextDisabled(text);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static void textWrapped(String text) {
/*  2972 */     nTextWrapped(text);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static void labelText(String label, String text) {
/*  2985 */     nLabelText(label, text);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static void bulletText(String text) {
/*  3000 */     nBulletText(text);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static void separatorText(String label) {
/*  3013 */     nSeparatorText(label);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static boolean button(String label) {
/*  3030 */     return nButton(label);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static boolean button(String label, ImVec2 size) {
/*  3037 */     return nButton(label, size.x, size.y);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static boolean button(String label, float sizeX, float sizeY) {
/*  3044 */     return nButton(label, sizeX, sizeY);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static boolean smallButton(String label) {
/*  3066 */     return nSmallButton(label);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static boolean invisibleButton(String strId, ImVec2 size) {
/*  3080 */     return nInvisibleButton(strId, size.x, size.y);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static boolean invisibleButton(String strId, float sizeX, float sizeY) {
/*  3087 */     return nInvisibleButton(strId, sizeX, sizeY);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static boolean invisibleButton(String strId, ImVec2 size, int imGuiButtonFlags) {
/*  3094 */     return nInvisibleButton(strId, size.x, size.y, imGuiButtonFlags);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static boolean invisibleButton(String strId, float sizeX, float sizeY, int imGuiButtonFlags) {
/*  3101 */     return nInvisibleButton(strId, sizeX, sizeY, imGuiButtonFlags);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static boolean arrowButton(String strId, int dir) {
/*  3124 */     return nArrowButton(strId, dir);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static boolean checkbox(String label, boolean active) {
/*  3135 */     return nCheckbox(label, active);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static boolean checkbox(String label, ImBoolean data) {
/*  3144 */     return nCheckbox(label, (data != null) ? data.getData() : null);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static boolean checkboxFlags(String label, ImInt flags, int flagsValue) {
/*  3157 */     return nCheckboxFlags(label, (flags != null) ? flags.getData() : null, flagsValue);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static boolean radioButton(String label, boolean active) {
/*  3173 */     return nRadioButton(label, active);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static boolean radioButton(String label, ImInt v, int vButton) {
/*  3187 */     return nRadioButton(label, (v != null) ? v.getData() : null, vButton);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static void progressBar(float fraction) {
/*  3200 */     nProgressBar(fraction);
/*       */   }
/*       */   
/*       */   public static void progressBar(float fraction, ImVec2 size) {
/*  3204 */     nProgressBar(fraction, size.x, size.y);
/*       */   }
/*       */   
/*       */   public static void progressBar(float fraction, float sizeX, float sizeY) {
/*  3208 */     nProgressBar(fraction, sizeX, sizeY);
/*       */   }
/*       */   
/*       */   public static void progressBar(float fraction, ImVec2 size, String overlay) {
/*  3212 */     nProgressBar(fraction, size.x, size.y, overlay);
/*       */   }
/*       */   
/*       */   public static void progressBar(float fraction, float sizeX, float sizeY, String overlay) {
/*  3216 */     nProgressBar(fraction, sizeX, sizeY, overlay);
/*       */   }
/*       */   
/*       */   public static void progressBar(float fraction, String overlay) {
/*  3220 */     nProgressBar(fraction, overlay);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static void bullet() {
/*  3249 */     nBullet();
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static void image(long userTextureId, ImVec2 imageSize) {
/*  3260 */     nImage(userTextureId, imageSize.x, imageSize.y);
/*       */   }
/*       */   
/*       */   public static void image(long userTextureId, float imageSizeX, float imageSizeY) {
/*  3264 */     nImage(userTextureId, imageSizeX, imageSizeY);
/*       */   }
/*       */   
/*       */   public static void image(long userTextureId, ImVec2 imageSize, ImVec2 uv0) {
/*  3268 */     nImage(userTextureId, imageSize.x, imageSize.y, uv0.x, uv0.y);
/*       */   }
/*       */   
/*       */   public static void image(long userTextureId, float imageSizeX, float imageSizeY, float uv0X, float uv0Y) {
/*  3272 */     nImage(userTextureId, imageSizeX, imageSizeY, uv0X, uv0Y);
/*       */   }
/*       */   
/*       */   public static void image(long userTextureId, ImVec2 imageSize, ImVec2 uv0, ImVec2 uv1) {
/*  3276 */     nImage(userTextureId, imageSize.x, imageSize.y, uv0.x, uv0.y, uv1.x, uv1.y);
/*       */   }
/*       */   
/*       */   public static void image(long userTextureId, float imageSizeX, float imageSizeY, float uv0X, float uv0Y, float uv1X, float uv1Y) {
/*  3280 */     nImage(userTextureId, imageSizeX, imageSizeY, uv0X, uv0Y, uv1X, uv1Y);
/*       */   }
/*       */   
/*       */   public static void image(long userTextureId, ImVec2 imageSize, ImVec2 uv0, ImVec2 uv1, ImVec4 tintCol) {
/*  3284 */     nImage(userTextureId, imageSize.x, imageSize.y, uv0.x, uv0.y, uv1.x, uv1.y, tintCol.x, tintCol.y, tintCol.z, tintCol.w);
/*       */   }
/*       */   
/*       */   public static void image(long userTextureId, float imageSizeX, float imageSizeY, float uv0X, float uv0Y, float uv1X, float uv1Y, float tintColX, float tintColY, float tintColZ, float tintColW) {
/*  3288 */     nImage(userTextureId, imageSizeX, imageSizeY, uv0X, uv0Y, uv1X, uv1Y, tintColX, tintColY, tintColZ, tintColW);
/*       */   }
/*       */   
/*       */   public static void image(long userTextureId, ImVec2 imageSize, ImVec2 uv0, ImVec2 uv1, ImVec4 tintCol, ImVec4 borderCol) {
/*  3292 */     nImage(userTextureId, imageSize.x, imageSize.y, uv0.x, uv0.y, uv1.x, uv1.y, tintCol.x, tintCol.y, tintCol.z, tintCol.w, borderCol.x, borderCol.y, borderCol.z, borderCol.w);
/*       */   }
/*       */   
/*       */   public static void image(long userTextureId, float imageSizeX, float imageSizeY, float uv0X, float uv0Y, float uv1X, float uv1Y, float tintColX, float tintColY, float tintColZ, float tintColW, float borderColX, float borderColY, float borderColZ, float borderColW) {
/*  3296 */     nImage(userTextureId, imageSizeX, imageSizeY, uv0X, uv0Y, uv1X, uv1Y, tintColX, tintColY, tintColZ, tintColW, borderColX, borderColY, borderColZ, borderColW);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static boolean imageButton(String strId, long userTextureId, ImVec2 imageSize) {
/*  3335 */     return nImageButton(strId, userTextureId, imageSize.x, imageSize.y);
/*       */   }
/*       */   
/*       */   public static boolean imageButton(String strId, long userTextureId, float imageSizeX, float imageSizeY) {
/*  3339 */     return nImageButton(strId, userTextureId, imageSizeX, imageSizeY);
/*       */   }
/*       */   
/*       */   public static boolean imageButton(String strId, long userTextureId, ImVec2 imageSize, ImVec2 uv0) {
/*  3343 */     return nImageButton(strId, userTextureId, imageSize.x, imageSize.y, uv0.x, uv0.y);
/*       */   }
/*       */   
/*       */   public static boolean imageButton(String strId, long userTextureId, float imageSizeX, float imageSizeY, float uv0X, float uv0Y) {
/*  3347 */     return nImageButton(strId, userTextureId, imageSizeX, imageSizeY, uv0X, uv0Y);
/*       */   }
/*       */   
/*       */   public static boolean imageButton(String strId, long userTextureId, ImVec2 imageSize, ImVec2 uv0, ImVec2 uv1) {
/*  3351 */     return nImageButton(strId, userTextureId, imageSize.x, imageSize.y, uv0.x, uv0.y, uv1.x, uv1.y);
/*       */   }
/*       */   
/*       */   public static boolean imageButton(String strId, long userTextureId, float imageSizeX, float imageSizeY, float uv0X, float uv0Y, float uv1X, float uv1Y) {
/*  3355 */     return nImageButton(strId, userTextureId, imageSizeX, imageSizeY, uv0X, uv0Y, uv1X, uv1Y);
/*       */   }
/*       */   
/*       */   public static boolean imageButton(String strId, long userTextureId, ImVec2 imageSize, ImVec2 uv0, ImVec2 uv1, ImVec4 bgCol) {
/*  3359 */     return nImageButton(strId, userTextureId, imageSize.x, imageSize.y, uv0.x, uv0.y, uv1.x, uv1.y, bgCol.x, bgCol.y, bgCol.z, bgCol.w);
/*       */   }
/*       */   
/*       */   public static boolean imageButton(String strId, long userTextureId, float imageSizeX, float imageSizeY, float uv0X, float uv0Y, float uv1X, float uv1Y, float bgColX, float bgColY, float bgColZ, float bgColW) {
/*  3363 */     return nImageButton(strId, userTextureId, imageSizeX, imageSizeY, uv0X, uv0Y, uv1X, uv1Y, bgColX, bgColY, bgColZ, bgColW);
/*       */   }
/*       */   
/*       */   public static boolean imageButton(String strId, long userTextureId, ImVec2 imageSize, ImVec2 uv0, ImVec2 uv1, ImVec4 bgCol, ImVec4 tintCol) {
/*  3367 */     return nImageButton(strId, userTextureId, imageSize.x, imageSize.y, uv0.x, uv0.y, uv1.x, uv1.y, bgCol.x, bgCol.y, bgCol.z, bgCol.w, tintCol.x, tintCol.y, tintCol.z, tintCol.w);
/*       */   }
/*       */   
/*       */   public static boolean imageButton(String strId, long userTextureId, float imageSizeX, float imageSizeY, float uv0X, float uv0Y, float uv1X, float uv1Y, float bgColX, float bgColY, float bgColZ, float bgColW, float tintColX, float tintColY, float tintColZ, float tintColW) {
/*  3371 */     return nImageButton(strId, userTextureId, imageSizeX, imageSizeY, uv0X, uv0Y, uv1X, uv1Y, bgColX, bgColY, bgColZ, bgColW, tintColX, tintColY, tintColZ, tintColW);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static boolean beginCombo(String label, String previewValue) {
/*  3430 */     return nBeginCombo(label, previewValue);
/*       */   }
/*       */   
/*       */   public static boolean beginCombo(String label, String previewValue, int imGuiComboFlags) {
/*  3434 */     return nBeginCombo(label, previewValue, imGuiComboFlags);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static void endCombo() {
/*  3459 */     nEndCombo();
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static boolean combo(String label, ImInt currentItem, String[] items) {
/*  3467 */     return nCombo(label, (currentItem != null) ? currentItem.getData() : null, items, items.length);
/*       */   }
/*       */   
/*       */   public static boolean combo(String label, ImInt currentItem, String[] items, int popupMaxHeightInItems) {
/*  3471 */     return nCombo(label, (currentItem != null) ? currentItem.getData() : null, items, items.length, popupMaxHeightInItems);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static boolean combo(String label, ImInt currentItem, String itemsSeparatedByZeros) {
/*  3516 */     return nCombo(label, (currentItem != null) ? currentItem.getData() : null, itemsSeparatedByZeros);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static boolean combo(String label, ImInt currentItem, String itemsSeparatedByZeros, int popupMaxHeightInItems) {
/*  3523 */     return nCombo(label, (currentItem != null) ? currentItem.getData() : null, itemsSeparatedByZeros, popupMaxHeightInItems);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static boolean dragFloat(String label, float[] v) {
/*  3565 */     return nDragFloat(label, v);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static boolean dragFloat(String label, float[] v, float vSpeed) {
/*  3572 */     return nDragFloat(label, v, vSpeed);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static boolean dragFloat(String label, float[] v, float vSpeed, float vMin) {
/*  3579 */     return nDragFloat(label, v, vSpeed, vMin);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static boolean dragFloat(String label, float[] v, float vSpeed, float vMin, float vMax) {
/*  3586 */     return nDragFloat(label, v, vSpeed, vMin, vMax);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static boolean dragFloat(String label, float[] v, float vSpeed, float vMin, float vMax, String format) {
/*  3593 */     return nDragFloat(label, v, vSpeed, vMin, vMax, format);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static boolean dragFloat(String label, float[] v, float vSpeed, float vMin, float vMax, String format, int imGuiSliderFlags) {
/*  3600 */     return nDragFloat(label, v, vSpeed, vMin, vMax, format, imGuiSliderFlags);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static boolean dragFloat(String label, float[] v, float vSpeed, float vMin, float vMax, int imGuiSliderFlags) {
/*  3607 */     return nDragFloat(label, v, vSpeed, vMin, vMax, imGuiSliderFlags);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static boolean dragFloat2(String label, float[] v) {
/*  3678 */     return nDragFloat2(label, v);
/*       */   }
/*       */   
/*       */   public static boolean dragFloat2(String label, float[] v, float vSpeed) {
/*  3682 */     return nDragFloat2(label, v, vSpeed);
/*       */   }
/*       */   
/*       */   public static boolean dragFloat2(String label, float[] v, float vSpeed, float vMin) {
/*  3686 */     return nDragFloat2(label, v, vSpeed, vMin);
/*       */   }
/*       */   
/*       */   public static boolean dragFloat2(String label, float[] v, float vSpeed, float vMin, float vMax) {
/*  3690 */     return nDragFloat2(label, v, vSpeed, vMin, vMax);
/*       */   }
/*       */   
/*       */   public static boolean dragFloat2(String label, float[] v, float vSpeed, float vMin, float vMax, String format) {
/*  3694 */     return nDragFloat2(label, v, vSpeed, vMin, vMax, format);
/*       */   }
/*       */   
/*       */   public static boolean dragFloat2(String label, float[] v, float vSpeed, float vMin, float vMax, String format, int imGuiSliderFlags) {
/*  3698 */     return nDragFloat2(label, v, vSpeed, vMin, vMax, format, imGuiSliderFlags);
/*       */   }
/*       */   
/*       */   public static boolean dragFloat2(String label, float[] v, float vSpeed, float vMin, float vMax, int imGuiSliderFlags) {
/*  3702 */     return nDragFloat2(label, v, vSpeed, vMin, vMax, imGuiSliderFlags);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static boolean dragFloat3(String label, float[] v) {
/*  3773 */     return nDragFloat3(label, v);
/*       */   }
/*       */   
/*       */   public static boolean dragFloat3(String label, float[] v, float vSpeed) {
/*  3777 */     return nDragFloat3(label, v, vSpeed);
/*       */   }
/*       */   
/*       */   public static boolean dragFloat3(String label, float[] v, float vSpeed, float vMin) {
/*  3781 */     return nDragFloat3(label, v, vSpeed, vMin);
/*       */   }
/*       */   
/*       */   public static boolean dragFloat3(String label, float[] v, float vSpeed, float vMin, float vMax) {
/*  3785 */     return nDragFloat3(label, v, vSpeed, vMin, vMax);
/*       */   }
/*       */   
/*       */   public static boolean dragFloat3(String label, float[] v, float vSpeed, float vMin, float vMax, String format) {
/*  3789 */     return nDragFloat3(label, v, vSpeed, vMin, vMax, format);
/*       */   }
/*       */   
/*       */   public static boolean dragFloat3(String label, float[] v, float vSpeed, float vMin, float vMax, String format, int imGuiSliderFlags) {
/*  3793 */     return nDragFloat3(label, v, vSpeed, vMin, vMax, format, imGuiSliderFlags);
/*       */   }
/*       */   
/*       */   public static boolean dragFloat3(String label, float[] v, float vSpeed, float vMin, float vMax, int imGuiSliderFlags) {
/*  3797 */     return nDragFloat3(label, v, vSpeed, vMin, vMax, imGuiSliderFlags);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static boolean dragFloat4(String label, float[] v) {
/*  3868 */     return nDragFloat4(label, v);
/*       */   }
/*       */   
/*       */   public static boolean dragFloat4(String label, float[] v, float vSpeed) {
/*  3872 */     return nDragFloat4(label, v, vSpeed);
/*       */   }
/*       */   
/*       */   public static boolean dragFloat4(String label, float[] v, float vSpeed, float vMin) {
/*  3876 */     return nDragFloat4(label, v, vSpeed, vMin);
/*       */   }
/*       */   
/*       */   public static boolean dragFloat4(String label, float[] v, float vSpeed, float vMin, float vMax) {
/*  3880 */     return nDragFloat4(label, v, vSpeed, vMin, vMax);
/*       */   }
/*       */   
/*       */   public static boolean dragFloat4(String label, float[] v, float vSpeed, float vMin, float vMax, String format) {
/*  3884 */     return nDragFloat4(label, v, vSpeed, vMin, vMax, format);
/*       */   }
/*       */   
/*       */   public static boolean dragFloat4(String label, float[] v, float vSpeed, float vMin, float vMax, String format, int imGuiSliderFlags) {
/*  3888 */     return nDragFloat4(label, v, vSpeed, vMin, vMax, format, imGuiSliderFlags);
/*       */   }
/*       */   
/*       */   public static boolean dragFloat4(String label, float[] v, float vSpeed, float vMin, float vMax, int imGuiSliderFlags) {
/*  3892 */     return nDragFloat4(label, v, vSpeed, vMin, vMax, imGuiSliderFlags);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static boolean dragFloatRange2(String label, float[] vCurrentMin, float[] vCurrentMax, float vSpeed) {
/*  3963 */     return nDragFloatRange2(label, vCurrentMin, vCurrentMax, vSpeed);
/*       */   }
/*       */   
/*       */   public static boolean dragFloatRange2(String label, float[] vCurrentMin, float[] vCurrentMax, float vSpeed, float vMin) {
/*  3967 */     return nDragFloatRange2(label, vCurrentMin, vCurrentMax, vSpeed, vMin);
/*       */   }
/*       */   
/*       */   public static boolean dragFloatRange2(String label, float[] vCurrentMin, float[] vCurrentMax, float vSpeed, float vMin, float vMax) {
/*  3971 */     return nDragFloatRange2(label, vCurrentMin, vCurrentMax, vSpeed, vMin, vMax);
/*       */   }
/*       */   
/*       */   public static boolean dragFloatRange2(String label, float[] vCurrentMin, float[] vCurrentMax, float vSpeed, float vMin, float vMax, String format) {
/*  3975 */     return nDragFloatRange2(label, vCurrentMin, vCurrentMax, vSpeed, vMin, vMax, format);
/*       */   }
/*       */   
/*       */   public static boolean dragFloatRange2(String label, float[] vCurrentMin, float[] vCurrentMax, float vSpeed, float vMin, float vMax, String format, String formatMax) {
/*  3979 */     return nDragFloatRange2(label, vCurrentMin, vCurrentMax, vSpeed, vMin, vMax, format, formatMax);
/*       */   }
/*       */   
/*       */   public static boolean dragFloatRange2(String label, float[] vCurrentMin, float[] vCurrentMax, float vSpeed, float vMin, float vMax, String format, String formatMax, int imGuiSliderFlags) {
/*  3983 */     return nDragFloatRange2(label, vCurrentMin, vCurrentMax, vSpeed, vMin, vMax, format, formatMax, imGuiSliderFlags);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static boolean dragInt(String label, int[] v) {
/*  4066 */     return nDragInt(label, v);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static boolean dragInt(String label, int[] v, float vSpeed) {
/*  4073 */     return nDragInt(label, v, vSpeed);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static boolean dragInt(String label, int[] v, float vSpeed, int vMin) {
/*  4080 */     return nDragInt(label, v, vSpeed, vMin);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static boolean dragInt(String label, int[] v, float vSpeed, int vMin, int vMax) {
/*  4087 */     return nDragInt(label, v, vSpeed, vMin, vMax);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static boolean dragInt(String label, int[] v, float vSpeed, int vMin, int vMax, String format) {
/*  4094 */     return nDragInt(label, v, vSpeed, vMin, vMax, format);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static boolean dragInt(String label, int[] v, float vSpeed, int vMin, int vMax, String format, int imGuiSliderFlags) {
/*  4101 */     return nDragInt(label, v, vSpeed, vMin, vMax, format, imGuiSliderFlags);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static boolean dragInt(String label, int[] v, float vSpeed, int vMin, int vMax, int imGuiSliderFlags) {
/*  4108 */     return nDragInt(label, v, vSpeed, vMin, vMax, imGuiSliderFlags);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static boolean dragInt2(String label, int[] v) {
/*  4179 */     return nDragInt2(label, v);
/*       */   }
/*       */   
/*       */   public static boolean dragInt2(String label, int[] v, float vSpeed) {
/*  4183 */     return nDragInt2(label, v, vSpeed);
/*       */   }
/*       */   
/*       */   public static boolean dragInt2(String label, int[] v, float vSpeed, int vMin) {
/*  4187 */     return nDragInt2(label, v, vSpeed, vMin);
/*       */   }
/*       */   
/*       */   public static boolean dragInt2(String label, int[] v, float vSpeed, int vMin, int vMax) {
/*  4191 */     return nDragInt2(label, v, vSpeed, vMin, vMax);
/*       */   }
/*       */   
/*       */   public static boolean dragInt2(String label, int[] v, float vSpeed, int vMin, int vMax, String format) {
/*  4195 */     return nDragInt2(label, v, vSpeed, vMin, vMax, format);
/*       */   }
/*       */   
/*       */   public static boolean dragInt2(String label, int[] v, float vSpeed, int vMin, int vMax, String format, int imGuiSliderFlags) {
/*  4199 */     return nDragInt2(label, v, vSpeed, vMin, vMax, format, imGuiSliderFlags);
/*       */   }
/*       */   
/*       */   public static boolean dragInt2(String label, int[] v, float vSpeed, int vMin, int vMax, int imGuiSliderFlags) {
/*  4203 */     return nDragInt2(label, v, vSpeed, vMin, vMax, imGuiSliderFlags);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static boolean dragInt3(String label, int[] v) {
/*  4274 */     return nDragInt3(label, v);
/*       */   }
/*       */   
/*       */   public static boolean dragInt3(String label, int[] v, float vSpeed) {
/*  4278 */     return nDragInt3(label, v, vSpeed);
/*       */   }
/*       */   
/*       */   public static boolean dragInt3(String label, int[] v, float vSpeed, int vMin) {
/*  4282 */     return nDragInt3(label, v, vSpeed, vMin);
/*       */   }
/*       */   
/*       */   public static boolean dragInt3(String label, int[] v, float vSpeed, int vMin, int vMax) {
/*  4286 */     return nDragInt3(label, v, vSpeed, vMin, vMax);
/*       */   }
/*       */   
/*       */   public static boolean dragInt3(String label, int[] v, float vSpeed, int vMin, int vMax, String format) {
/*  4290 */     return nDragInt3(label, v, vSpeed, vMin, vMax, format);
/*       */   }
/*       */   
/*       */   public static boolean dragInt3(String label, int[] v, float vSpeed, int vMin, int vMax, String format, int imGuiSliderFlags) {
/*  4294 */     return nDragInt3(label, v, vSpeed, vMin, vMax, format, imGuiSliderFlags);
/*       */   }
/*       */   
/*       */   public static boolean dragInt3(String label, int[] v, float vSpeed, int vMin, int vMax, int imGuiSliderFlags) {
/*  4298 */     return nDragInt3(label, v, vSpeed, vMin, vMax, imGuiSliderFlags);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static boolean dragInt4(String label, int[] v) {
/*  4369 */     return nDragInt4(label, v);
/*       */   }
/*       */   
/*       */   public static boolean dragInt4(String label, int[] v, float vSpeed) {
/*  4373 */     return nDragInt4(label, v, vSpeed);
/*       */   }
/*       */   
/*       */   public static boolean dragInt4(String label, int[] v, float vSpeed, int vMin) {
/*  4377 */     return nDragInt4(label, v, vSpeed, vMin);
/*       */   }
/*       */   
/*       */   public static boolean dragInt4(String label, int[] v, float vSpeed, int vMin, int vMax) {
/*  4381 */     return nDragInt4(label, v, vSpeed, vMin, vMax);
/*       */   }
/*       */   
/*       */   public static boolean dragInt4(String label, int[] v, float vSpeed, int vMin, int vMax, String format) {
/*  4385 */     return nDragInt4(label, v, vSpeed, vMin, vMax, format);
/*       */   }
/*       */   
/*       */   public static boolean dragInt4(String label, int[] v, float vSpeed, int vMin, int vMax, String format, int imGuiSliderFlags) {
/*  4389 */     return nDragInt4(label, v, vSpeed, vMin, vMax, format, imGuiSliderFlags);
/*       */   }
/*       */   
/*       */   public static boolean dragInt4(String label, int[] v, float vSpeed, int vMin, int vMax, int imGuiSliderFlags) {
/*  4393 */     return nDragInt4(label, v, vSpeed, vMin, vMax, imGuiSliderFlags);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static boolean dragIntRange2(String label, int[] vCurrentMin, int[] vCurrentMax) {
/*  4464 */     return nDragIntRange2(label, vCurrentMin, vCurrentMax);
/*       */   }
/*       */   
/*       */   public static boolean dragIntRange2(String label, int[] vCurrentMin, int[] vCurrentMax, float vSpeed) {
/*  4468 */     return nDragIntRange2(label, vCurrentMin, vCurrentMax, vSpeed);
/*       */   }
/*       */   
/*       */   public static boolean dragIntRange2(String label, int[] vCurrentMin, int[] vCurrentMax, float vSpeed, int vMin) {
/*  4472 */     return nDragIntRange2(label, vCurrentMin, vCurrentMax, vSpeed, vMin);
/*       */   }
/*       */   
/*       */   public static boolean dragIntRange2(String label, int[] vCurrentMin, int[] vCurrentMax, float vSpeed, int vMin, int vMax) {
/*  4476 */     return nDragIntRange2(label, vCurrentMin, vCurrentMax, vSpeed, vMin, vMax);
/*       */   }
/*       */   
/*       */   public static boolean dragIntRange2(String label, int[] vCurrentMin, int[] vCurrentMax, float vSpeed, int vMin, int vMax, String format) {
/*  4480 */     return nDragIntRange2(label, vCurrentMin, vCurrentMax, vSpeed, vMin, vMax, format);
/*       */   }
/*       */   
/*       */   public static boolean dragIntRange2(String label, int[] vCurrentMin, int[] vCurrentMax, float vSpeed, int vMin, int vMax, String format, String formatMax) {
/*  4484 */     return nDragIntRange2(label, vCurrentMin, vCurrentMax, vSpeed, vMin, vMax, format, formatMax);
/*       */   }
/*       */   
/*       */   public static boolean dragIntRange2(String label, int[] vCurrentMin, int[] vCurrentMax, float vSpeed, int vMin, int vMax, String format, String formatMax, int imGuiSliderFlags) {
/*  4488 */     return nDragIntRange2(label, vCurrentMin, vCurrentMax, vSpeed, vMin, vMax, format, formatMax, imGuiSliderFlags);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static boolean dragScalar(String label, short[] pData) {
/*  4579 */     return nDragScalar(label, pData);
/*       */   }
/*       */   
/*       */   public static boolean dragScalar(String label, short[] pData, float vSpeed) {
/*  4583 */     return nDragScalar(label, pData, vSpeed);
/*       */   }
/*       */   
/*       */   public static boolean dragScalar(String label, short[] pData, float vSpeed, short pMin) {
/*  4587 */     return nDragScalar(label, pData, vSpeed, pMin);
/*       */   }
/*       */   
/*       */   public static boolean dragScalar(String label, short[] pData, float vSpeed, short pMin, short pMax) {
/*  4591 */     return nDragScalar(label, pData, vSpeed, pMin, pMax);
/*       */   }
/*       */   
/*       */   public static boolean dragScalar(String label, short[] pData, float vSpeed, short pMin, short pMax, String format) {
/*  4595 */     return nDragScalar(label, pData, vSpeed, pMin, pMax, format);
/*       */   }
/*       */   
/*       */   public static boolean dragScalar(String label, short[] pData, float vSpeed, short pMin, short pMax, String format, int imGuiSliderFlags) {
/*  4599 */     return nDragScalar(label, pData, vSpeed, pMin, pMax, format, imGuiSliderFlags);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static boolean dragScalar(String label, int[] pData) {
/*  4661 */     return nDragScalar(label, pData);
/*       */   }
/*       */   
/*       */   public static boolean dragScalar(String label, int[] pData, float vSpeed) {
/*  4665 */     return nDragScalar(label, pData, vSpeed);
/*       */   }
/*       */   
/*       */   public static boolean dragScalar(String label, int[] pData, float vSpeed, int pMin) {
/*  4669 */     return nDragScalar(label, pData, vSpeed, pMin);
/*       */   }
/*       */   
/*       */   public static boolean dragScalar(String label, int[] pData, float vSpeed, int pMin, int pMax) {
/*  4673 */     return nDragScalar(label, pData, vSpeed, pMin, pMax);
/*       */   }
/*       */   
/*       */   public static boolean dragScalar(String label, int[] pData, float vSpeed, int pMin, int pMax, String format) {
/*  4677 */     return nDragScalar(label, pData, vSpeed, pMin, pMax, format);
/*       */   }
/*       */   
/*       */   public static boolean dragScalar(String label, int[] pData, float vSpeed, int pMin, int pMax, String format, int imGuiSliderFlags) {
/*  4681 */     return nDragScalar(label, pData, vSpeed, pMin, pMax, format, imGuiSliderFlags);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static boolean dragScalar(String label, long[] pData) {
/*  4743 */     return nDragScalar(label, pData);
/*       */   }
/*       */   
/*       */   public static boolean dragScalar(String label, long[] pData, float vSpeed) {
/*  4747 */     return nDragScalar(label, pData, vSpeed);
/*       */   }
/*       */   
/*       */   public static boolean dragScalar(String label, long[] pData, float vSpeed, long pMin) {
/*  4751 */     return nDragScalar(label, pData, vSpeed, pMin);
/*       */   }
/*       */   
/*       */   public static boolean dragScalar(String label, long[] pData, float vSpeed, long pMin, long pMax) {
/*  4755 */     return nDragScalar(label, pData, vSpeed, pMin, pMax);
/*       */   }
/*       */   
/*       */   public static boolean dragScalar(String label, long[] pData, float vSpeed, long pMin, long pMax, String format) {
/*  4759 */     return nDragScalar(label, pData, vSpeed, pMin, pMax, format);
/*       */   }
/*       */   
/*       */   public static boolean dragScalar(String label, long[] pData, float vSpeed, long pMin, long pMax, String format, int imGuiSliderFlags) {
/*  4763 */     return nDragScalar(label, pData, vSpeed, pMin, pMax, format, imGuiSliderFlags);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static boolean dragScalar(String label, float[] pData) {
/*  4825 */     return nDragScalar(label, pData);
/*       */   }
/*       */   
/*       */   public static boolean dragScalar(String label, float[] pData, float vSpeed) {
/*  4829 */     return nDragScalar(label, pData, vSpeed);
/*       */   }
/*       */   
/*       */   public static boolean dragScalar(String label, float[] pData, float vSpeed, float pMin) {
/*  4833 */     return nDragScalar(label, pData, vSpeed, pMin);
/*       */   }
/*       */   
/*       */   public static boolean dragScalar(String label, float[] pData, float vSpeed, float pMin, float pMax) {
/*  4837 */     return nDragScalar(label, pData, vSpeed, pMin, pMax);
/*       */   }
/*       */   
/*       */   public static boolean dragScalar(String label, float[] pData, float vSpeed, float pMin, float pMax, String format) {
/*  4841 */     return nDragScalar(label, pData, vSpeed, pMin, pMax, format);
/*       */   }
/*       */   
/*       */   public static boolean dragScalar(String label, float[] pData, float vSpeed, float pMin, float pMax, String format, int imGuiSliderFlags) {
/*  4845 */     return nDragScalar(label, pData, vSpeed, pMin, pMax, format, imGuiSliderFlags);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static boolean dragScalar(String label, double[] pData) {
/*  4907 */     return nDragScalar(label, pData);
/*       */   }
/*       */   
/*       */   public static boolean dragScalar(String label, double[] pData, float vSpeed) {
/*  4911 */     return nDragScalar(label, pData, vSpeed);
/*       */   }
/*       */   
/*       */   public static boolean dragScalar(String label, double[] pData, float vSpeed, double pMin) {
/*  4915 */     return nDragScalar(label, pData, vSpeed, pMin);
/*       */   }
/*       */   
/*       */   public static boolean dragScalar(String label, double[] pData, float vSpeed, double pMin, double pMax) {
/*  4919 */     return nDragScalar(label, pData, vSpeed, pMin, pMax);
/*       */   }
/*       */   
/*       */   public static boolean dragScalar(String label, double[] pData, float vSpeed, double pMin, double pMax, String format) {
/*  4923 */     return nDragScalar(label, pData, vSpeed, pMin, pMax, format);
/*       */   }
/*       */   
/*       */   public static boolean dragScalar(String label, double[] pData, float vSpeed, double pMin, double pMax, String format, int imGuiSliderFlags) {
/*  4927 */     return nDragScalar(label, pData, vSpeed, pMin, pMax, format, imGuiSliderFlags);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static boolean dragScalarN(String label, short[] pData, int components) {
/*  4989 */     return nDragScalarN(label, pData, components);
/*       */   }
/*       */   
/*       */   public static boolean dragScalarN(String label, short[] pData, int components, float vSpeed) {
/*  4993 */     return nDragScalarN(label, pData, components, vSpeed);
/*       */   }
/*       */   
/*       */   public static boolean dragScalarN(String label, short[] pData, int components, float vSpeed, short pMin) {
/*  4997 */     return nDragScalarN(label, pData, components, vSpeed, pMin);
/*       */   }
/*       */   
/*       */   public static boolean dragScalarN(String label, short[] pData, int components, float vSpeed, short pMin, short pMax) {
/*  5001 */     return nDragScalarN(label, pData, components, vSpeed, pMin, pMax);
/*       */   }
/*       */   
/*       */   public static boolean dragScalarN(String label, short[] pData, int components, float vSpeed, short pMin, short pMax, String format) {
/*  5005 */     return nDragScalarN(label, pData, components, vSpeed, pMin, pMax, format);
/*       */   }
/*       */   
/*       */   public static boolean dragScalarN(String label, short[] pData, int components, float vSpeed, short pMin, short pMax, String format, int imGuiSliderFlags) {
/*  5009 */     return nDragScalarN(label, pData, components, vSpeed, pMin, pMax, format, imGuiSliderFlags);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static boolean dragScalarN(String label, int[] pData, int components) {
/*  5071 */     return nDragScalarN(label, pData, components);
/*       */   }
/*       */   
/*       */   public static boolean dragScalarN(String label, int[] pData, int components, float vSpeed) {
/*  5075 */     return nDragScalarN(label, pData, components, vSpeed);
/*       */   }
/*       */   
/*       */   public static boolean dragScalarN(String label, int[] pData, int components, float vSpeed, int pMin) {
/*  5079 */     return nDragScalarN(label, pData, components, vSpeed, pMin);
/*       */   }
/*       */   
/*       */   public static boolean dragScalarN(String label, int[] pData, int components, float vSpeed, int pMin, int pMax) {
/*  5083 */     return nDragScalarN(label, pData, components, vSpeed, pMin, pMax);
/*       */   }
/*       */   
/*       */   public static boolean dragScalarN(String label, int[] pData, int components, float vSpeed, int pMin, int pMax, String format) {
/*  5087 */     return nDragScalarN(label, pData, components, vSpeed, pMin, pMax, format);
/*       */   }
/*       */   
/*       */   public static boolean dragScalarN(String label, int[] pData, int components, float vSpeed, int pMin, int pMax, String format, int imGuiSliderFlags) {
/*  5091 */     return nDragScalarN(label, pData, components, vSpeed, pMin, pMax, format, imGuiSliderFlags);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static boolean dragScalarN(String label, long[] pData, int components) {
/*  5153 */     return nDragScalarN(label, pData, components);
/*       */   }
/*       */   
/*       */   public static boolean dragScalarN(String label, long[] pData, int components, float vSpeed) {
/*  5157 */     return nDragScalarN(label, pData, components, vSpeed);
/*       */   }
/*       */   
/*       */   public static boolean dragScalarN(String label, long[] pData, int components, float vSpeed, long pMin) {
/*  5161 */     return nDragScalarN(label, pData, components, vSpeed, pMin);
/*       */   }
/*       */   
/*       */   public static boolean dragScalarN(String label, long[] pData, int components, float vSpeed, long pMin, long pMax) {
/*  5165 */     return nDragScalarN(label, pData, components, vSpeed, pMin, pMax);
/*       */   }
/*       */   
/*       */   public static boolean dragScalarN(String label, long[] pData, int components, float vSpeed, long pMin, long pMax, String format) {
/*  5169 */     return nDragScalarN(label, pData, components, vSpeed, pMin, pMax, format);
/*       */   }
/*       */   
/*       */   public static boolean dragScalarN(String label, long[] pData, int components, float vSpeed, long pMin, long pMax, String format, int imGuiSliderFlags) {
/*  5173 */     return nDragScalarN(label, pData, components, vSpeed, pMin, pMax, format, imGuiSliderFlags);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static boolean dragScalarN(String label, float[] pData, int components) {
/*  5235 */     return nDragScalarN(label, pData, components);
/*       */   }
/*       */   
/*       */   public static boolean dragScalarN(String label, float[] pData, int components, float vSpeed) {
/*  5239 */     return nDragScalarN(label, pData, components, vSpeed);
/*       */   }
/*       */   
/*       */   public static boolean dragScalarN(String label, float[] pData, int components, float vSpeed, float pMin) {
/*  5243 */     return nDragScalarN(label, pData, components, vSpeed, pMin);
/*       */   }
/*       */   
/*       */   public static boolean dragScalarN(String label, float[] pData, int components, float vSpeed, float pMin, float pMax) {
/*  5247 */     return nDragScalarN(label, pData, components, vSpeed, pMin, pMax);
/*       */   }
/*       */   
/*       */   public static boolean dragScalarN(String label, float[] pData, int components, float vSpeed, float pMin, float pMax, String format) {
/*  5251 */     return nDragScalarN(label, pData, components, vSpeed, pMin, pMax, format);
/*       */   }
/*       */   
/*       */   public static boolean dragScalarN(String label, float[] pData, int components, float vSpeed, float pMin, float pMax, String format, int imGuiSliderFlags) {
/*  5255 */     return nDragScalarN(label, pData, components, vSpeed, pMin, pMax, format, imGuiSliderFlags);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static boolean dragScalarN(String label, double[] pData, int components) {
/*  5317 */     return nDragScalarN(label, pData, components);
/*       */   }
/*       */   
/*       */   public static boolean dragScalarN(String label, double[] pData, int components, float vSpeed) {
/*  5321 */     return nDragScalarN(label, pData, components, vSpeed);
/*       */   }
/*       */   
/*       */   public static boolean dragScalarN(String label, double[] pData, int components, float vSpeed, double pMin) {
/*  5325 */     return nDragScalarN(label, pData, components, vSpeed, pMin);
/*       */   }
/*       */   
/*       */   public static boolean dragScalarN(String label, double[] pData, int components, float vSpeed, double pMin, double pMax) {
/*  5329 */     return nDragScalarN(label, pData, components, vSpeed, pMin, pMax);
/*       */   }
/*       */   
/*       */   public static boolean dragScalarN(String label, double[] pData, int components, float vSpeed, double pMin, double pMax, String format) {
/*  5333 */     return nDragScalarN(label, pData, components, vSpeed, pMin, pMax, format);
/*       */   }
/*       */   
/*       */   public static boolean dragScalarN(String label, double[] pData, int components, float vSpeed, double pMin, double pMax, String format, int imGuiSliderFlags) {
/*  5337 */     return nDragScalarN(label, pData, components, vSpeed, pMin, pMax, format, imGuiSliderFlags);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static boolean sliderFloat(String label, float[] v, float vMin, float vMax) {
/*  5409 */     return nSliderFloat(label, v, vMin, vMax);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static boolean sliderFloat(String label, float[] v, float vMin, float vMax, String format) {
/*  5416 */     return nSliderFloat(label, v, vMin, vMax, format);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static boolean sliderFloat(String label, float[] v, float vMin, float vMax, String format, int imGuiSliderFlags) {
/*  5423 */     return nSliderFloat(label, v, vMin, vMax, format, imGuiSliderFlags);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static boolean sliderFloat(String label, float[] v, float vMin, float vMax, int imGuiSliderFlags) {
/*  5430 */     return nSliderFloat(label, v, vMin, vMax, imGuiSliderFlags);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static boolean sliderFloat2(String label, float[] v, float vMin, float vMax) {
/*  5474 */     return nSliderFloat2(label, v, vMin, vMax);
/*       */   }
/*       */   
/*       */   public static boolean sliderFloat2(String label, float[] v, float vMin, float vMax, String format) {
/*  5478 */     return nSliderFloat2(label, v, vMin, vMax, format);
/*       */   }
/*       */   
/*       */   public static boolean sliderFloat2(String label, float[] v, float vMin, float vMax, String format, int imGuiSliderFlags) {
/*  5482 */     return nSliderFloat2(label, v, vMin, vMax, format, imGuiSliderFlags);
/*       */   }
/*       */   
/*       */   public static boolean sliderFloat2(String label, float[] v, float vMin, float vMax, int imGuiSliderFlags) {
/*  5486 */     return nSliderFloat2(label, v, vMin, vMax, imGuiSliderFlags);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static boolean sliderFloat3(String label, float[] v, float vMin, float vMax) {
/*  5530 */     return nSliderFloat3(label, v, vMin, vMax);
/*       */   }
/*       */   
/*       */   public static boolean sliderFloat3(String label, float[] v, float vMin, float vMax, String format) {
/*  5534 */     return nSliderFloat3(label, v, vMin, vMax, format);
/*       */   }
/*       */   
/*       */   public static boolean sliderFloat3(String label, float[] v, float vMin, float vMax, String format, int imGuiSliderFlags) {
/*  5538 */     return nSliderFloat3(label, v, vMin, vMax, format, imGuiSliderFlags);
/*       */   }
/*       */   
/*       */   public static boolean sliderFloat3(String label, float[] v, float vMin, float vMax, int imGuiSliderFlags) {
/*  5542 */     return nSliderFloat3(label, v, vMin, vMax, imGuiSliderFlags);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static boolean sliderFloat4(String label, float[] v, float vMin, float vMax) {
/*  5586 */     return nSliderFloat4(label, v, vMin, vMax);
/*       */   }
/*       */   
/*       */   public static boolean sliderFloat4(String label, float[] v, float vMin, float vMax, String format) {
/*  5590 */     return nSliderFloat4(label, v, vMin, vMax, format);
/*       */   }
/*       */   
/*       */   public static boolean sliderFloat4(String label, float[] v, float vMin, float vMax, String format, int imGuiSliderFlags) {
/*  5594 */     return nSliderFloat4(label, v, vMin, vMax, format, imGuiSliderFlags);
/*       */   }
/*       */   
/*       */   public static boolean sliderFloat4(String label, float[] v, float vMin, float vMax, int imGuiSliderFlags) {
/*  5598 */     return nSliderFloat4(label, v, vMin, vMax, imGuiSliderFlags);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static boolean sliderAngle(String label, float[] vRad) {
/*  5642 */     return nSliderAngle(label, vRad);
/*       */   }
/*       */   
/*       */   public static boolean sliderAngle(String label, float[] vRad, float vDegreesMin) {
/*  5646 */     return nSliderAngle(label, vRad, vDegreesMin);
/*       */   }
/*       */   
/*       */   public static boolean sliderAngle(String label, float[] vRad, float vDegreesMin, float vDegreesMax) {
/*  5650 */     return nSliderAngle(label, vRad, vDegreesMin, vDegreesMax);
/*       */   }
/*       */   
/*       */   public static boolean sliderAngle(String label, float[] vRad, float vDegreesMin, float vDegreesMax, String format) {
/*  5654 */     return nSliderAngle(label, vRad, vDegreesMin, vDegreesMax, format);
/*       */   }
/*       */   
/*       */   public static boolean sliderAngle(String label, float[] vRad, float vDegreesMin, float vDegreesMax, String format, int imGuiSliderFlags) {
/*  5658 */     return nSliderAngle(label, vRad, vDegreesMin, vDegreesMax, format, imGuiSliderFlags);
/*       */   }
/*       */   
/*       */   public static boolean sliderAngle(String label, float[] vRad, float vDegreesMin, float vDegreesMax, int imGuiSliderFlags) {
/*  5662 */     return nSliderAngle(label, vRad, vDegreesMin, vDegreesMax, imGuiSliderFlags);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static boolean sliderInt(String label, int[] v, int vMin, int vMax) {
/*  5724 */     return nSliderInt(label, v, vMin, vMax);
/*       */   }
/*       */   
/*       */   public static boolean sliderInt(String label, int[] v, int vMin, int vMax, String format) {
/*  5728 */     return nSliderInt(label, v, vMin, vMax, format);
/*       */   }
/*       */   
/*       */   public static boolean sliderInt(String label, int[] v, int vMin, int vMax, String format, int imGuiSliderFlags) {
/*  5732 */     return nSliderInt(label, v, vMin, vMax, format, imGuiSliderFlags);
/*       */   }
/*       */   
/*       */   public static boolean sliderInt(String label, int[] v, int vMin, int vMax, int imGuiSliderFlags) {
/*  5736 */     return nSliderInt(label, v, vMin, vMax, imGuiSliderFlags);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static boolean sliderInt2(String label, int[] v, int vMin, int vMax) {
/*  5780 */     return nSliderInt2(label, v, vMin, vMax);
/*       */   }
/*       */   
/*       */   public static boolean sliderInt2(String label, int[] v, int vMin, int vMax, String format) {
/*  5784 */     return nSliderInt2(label, v, vMin, vMax, format);
/*       */   }
/*       */   
/*       */   public static boolean sliderInt2(String label, int[] v, int vMin, int vMax, String format, int imGuiSliderFlags) {
/*  5788 */     return nSliderInt2(label, v, vMin, vMax, format, imGuiSliderFlags);
/*       */   }
/*       */   
/*       */   public static boolean sliderInt2(String label, int[] v, int vMin, int vMax, int imGuiSliderFlags) {
/*  5792 */     return nSliderInt2(label, v, vMin, vMax, imGuiSliderFlags);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static boolean sliderInt3(String label, int[] v, int vMin, int vMax) {
/*  5836 */     return nSliderInt3(label, v, vMin, vMax);
/*       */   }
/*       */   
/*       */   public static boolean sliderInt3(String label, int[] v, int vMin, int vMax, String format) {
/*  5840 */     return nSliderInt3(label, v, vMin, vMax, format);
/*       */   }
/*       */   
/*       */   public static boolean sliderInt3(String label, int[] v, int vMin, int vMax, String format, int imGuiSliderFlags) {
/*  5844 */     return nSliderInt3(label, v, vMin, vMax, format, imGuiSliderFlags);
/*       */   }
/*       */   
/*       */   public static boolean sliderInt3(String label, int[] v, int vMin, int vMax, int imGuiSliderFlags) {
/*  5848 */     return nSliderInt3(label, v, vMin, vMax, imGuiSliderFlags);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static boolean sliderInt4(String label, int[] v, int vMin, int vMax) {
/*  5892 */     return nSliderInt4(label, v, vMin, vMax);
/*       */   }
/*       */   
/*       */   public static boolean sliderInt4(String label, int[] v, int vMin, int vMax, String format) {
/*  5896 */     return nSliderInt4(label, v, vMin, vMax, format);
/*       */   }
/*       */   
/*       */   public static boolean sliderInt4(String label, int[] v, int vMin, int vMax, String format, int imGuiSliderFlags) {
/*  5900 */     return nSliderInt4(label, v, vMin, vMax, format, imGuiSliderFlags);
/*       */   }
/*       */   
/*       */   public static boolean sliderInt4(String label, int[] v, int vMin, int vMax, int imGuiSliderFlags) {
/*  5904 */     return nSliderInt4(label, v, vMin, vMax, imGuiSliderFlags);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static boolean sliderScalar(String label, short[] pData, short pMin, short pMax) {
/*  5948 */     return nSliderScalar(label, pData, pMin, pMax);
/*       */   }
/*       */   
/*       */   public static boolean sliderScalar(String label, short[] pData, short pMin, short pMax, String format) {
/*  5952 */     return nSliderScalar(label, pData, pMin, pMax, format);
/*       */   }
/*       */   
/*       */   public static boolean sliderScalar(String label, short[] pData, short pMin, short pMax, String format, int imGuiSliderFlags) {
/*  5956 */     return nSliderScalar(label, pData, pMin, pMax, format, imGuiSliderFlags);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static boolean sliderScalar(String label, int[] pData, int pMin, int pMax) {
/*  5991 */     return nSliderScalar(label, pData, pMin, pMax);
/*       */   }
/*       */   
/*       */   public static boolean sliderScalar(String label, int[] pData, int pMin, int pMax, String format) {
/*  5995 */     return nSliderScalar(label, pData, pMin, pMax, format);
/*       */   }
/*       */   
/*       */   public static boolean sliderScalar(String label, int[] pData, int pMin, int pMax, String format, int imGuiSliderFlags) {
/*  5999 */     return nSliderScalar(label, pData, pMin, pMax, format, imGuiSliderFlags);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static boolean sliderScalar(String label, long[] pData, long pMin, long pMax) {
/*  6034 */     return nSliderScalar(label, pData, pMin, pMax);
/*       */   }
/*       */   
/*       */   public static boolean sliderScalar(String label, long[] pData, long pMin, long pMax, String format) {
/*  6038 */     return nSliderScalar(label, pData, pMin, pMax, format);
/*       */   }
/*       */   
/*       */   public static boolean sliderScalar(String label, long[] pData, long pMin, long pMax, String format, int imGuiSliderFlags) {
/*  6042 */     return nSliderScalar(label, pData, pMin, pMax, format, imGuiSliderFlags);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static boolean sliderScalar(String label, float[] pData, float pMin, float pMax) {
/*  6077 */     return nSliderScalar(label, pData, pMin, pMax);
/*       */   }
/*       */   
/*       */   public static boolean sliderScalar(String label, float[] pData, float pMin, float pMax, String format) {
/*  6081 */     return nSliderScalar(label, pData, pMin, pMax, format);
/*       */   }
/*       */   
/*       */   public static boolean sliderScalar(String label, float[] pData, float pMin, float pMax, String format, int imGuiSliderFlags) {
/*  6085 */     return nSliderScalar(label, pData, pMin, pMax, format, imGuiSliderFlags);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static boolean sliderScalar(String label, double[] pData, double pMin, double pMax) {
/*  6120 */     return nSliderScalar(label, pData, pMin, pMax);
/*       */   }
/*       */   
/*       */   public static boolean sliderScalar(String label, double[] pData, double pMin, double pMax, String format) {
/*  6124 */     return nSliderScalar(label, pData, pMin, pMax, format);
/*       */   }
/*       */   
/*       */   public static boolean sliderScalar(String label, double[] pData, double pMin, double pMax, String format, int imGuiSliderFlags) {
/*  6128 */     return nSliderScalar(label, pData, pMin, pMax, format, imGuiSliderFlags);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static boolean sliderScalarN(String label, short[] pData, int components, short pMin, short pMax) {
/*  6163 */     return nSliderScalarN(label, pData, components, pMin, pMax);
/*       */   }
/*       */   
/*       */   public static boolean sliderScalarN(String label, short[] pData, int components, short pMin, short pMax, String format) {
/*  6167 */     return nSliderScalarN(label, pData, components, pMin, pMax, format);
/*       */   }
/*       */   
/*       */   public static boolean sliderScalarN(String label, short[] pData, int components, short pMin, short pMax, String format, int imGuiSliderFlags) {
/*  6171 */     return nSliderScalarN(label, pData, components, pMin, pMax, format, imGuiSliderFlags);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static boolean sliderScalarN(String label, int[] pData, int components, int pMin, int pMax) {
/*  6206 */     return nSliderScalarN(label, pData, components, pMin, pMax);
/*       */   }
/*       */   
/*       */   public static boolean sliderScalarN(String label, int[] pData, int components, int pMin, int pMax, String format) {
/*  6210 */     return nSliderScalarN(label, pData, components, pMin, pMax, format);
/*       */   }
/*       */   
/*       */   public static boolean sliderScalarN(String label, int[] pData, int components, int pMin, int pMax, String format, int imGuiSliderFlags) {
/*  6214 */     return nSliderScalarN(label, pData, components, pMin, pMax, format, imGuiSliderFlags);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static boolean sliderScalarN(String label, long[] pData, int components, long pMin, long pMax) {
/*  6249 */     return nSliderScalarN(label, pData, components, pMin, pMax);
/*       */   }
/*       */   
/*       */   public static boolean sliderScalarN(String label, long[] pData, int components, long pMin, long pMax, String format) {
/*  6253 */     return nSliderScalarN(label, pData, components, pMin, pMax, format);
/*       */   }
/*       */   
/*       */   public static boolean sliderScalarN(String label, long[] pData, int components, long pMin, long pMax, String format, int imGuiSliderFlags) {
/*  6257 */     return nSliderScalarN(label, pData, components, pMin, pMax, format, imGuiSliderFlags);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static boolean sliderScalarN(String label, float[] pData, int components, float pMin, float pMax) {
/*  6292 */     return nSliderScalarN(label, pData, components, pMin, pMax);
/*       */   }
/*       */   
/*       */   public static boolean sliderScalarN(String label, float[] pData, int components, float pMin, float pMax, String format) {
/*  6296 */     return nSliderScalarN(label, pData, components, pMin, pMax, format);
/*       */   }
/*       */   
/*       */   public static boolean sliderScalarN(String label, float[] pData, int components, float pMin, float pMax, String format, int imGuiSliderFlags) {
/*  6300 */     return nSliderScalarN(label, pData, components, pMin, pMax, format, imGuiSliderFlags);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static boolean sliderScalarN(String label, double[] pData, int components, double pMin, double pMax) {
/*  6335 */     return nSliderScalarN(label, pData, components, pMin, pMax);
/*       */   }
/*       */   
/*       */   public static boolean sliderScalarN(String label, double[] pData, int components, double pMin, double pMax, String format) {
/*  6339 */     return nSliderScalarN(label, pData, components, pMin, pMax, format);
/*       */   }
/*       */   
/*       */   public static boolean sliderScalarN(String label, double[] pData, int components, double pMin, double pMax, String format, int imGuiSliderFlags) {
/*  6343 */     return nSliderScalarN(label, pData, components, pMin, pMax, format, imGuiSliderFlags);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static boolean vSliderFloat(String label, ImVec2 size, float[] v, float vMin, float vMax) {
/*  6378 */     return nVSliderFloat(label, size.x, size.y, v, vMin, vMax);
/*       */   }
/*       */   
/*       */   public static boolean vSliderFloat(String label, float sizeX, float sizeY, float[] v, float vMin, float vMax) {
/*  6382 */     return nVSliderFloat(label, sizeX, sizeY, v, vMin, vMax);
/*       */   }
/*       */   
/*       */   public static boolean vSliderFloat(String label, ImVec2 size, float[] v, float vMin, float vMax, String format) {
/*  6386 */     return nVSliderFloat(label, size.x, size.y, v, vMin, vMax, format);
/*       */   }
/*       */   
/*       */   public static boolean vSliderFloat(String label, float sizeX, float sizeY, float[] v, float vMin, float vMax, String format) {
/*  6390 */     return nVSliderFloat(label, sizeX, sizeY, v, vMin, vMax, format);
/*       */   }
/*       */   
/*       */   public static boolean vSliderFloat(String label, ImVec2 size, float[] v, float vMin, float vMax, String format, int imGuiSliderFlags) {
/*  6394 */     return nVSliderFloat(label, size.x, size.y, v, vMin, vMax, format, imGuiSliderFlags);
/*       */   }
/*       */   
/*       */   public static boolean vSliderFloat(String label, float sizeX, float sizeY, float[] v, float vMin, float vMax, String format, int imGuiSliderFlags) {
/*  6398 */     return nVSliderFloat(label, sizeX, sizeY, v, vMin, vMax, format, imGuiSliderFlags);
/*       */   }
/*       */   
/*       */   public static boolean vSliderFloat(String label, ImVec2 size, float[] v, float vMin, float vMax, int imGuiSliderFlags) {
/*  6402 */     return nVSliderFloat(label, size.x, size.y, v, vMin, vMax, imGuiSliderFlags);
/*       */   }
/*       */   
/*       */   public static boolean vSliderFloat(String label, float sizeX, float sizeY, float[] v, float vMin, float vMax, int imGuiSliderFlags) {
/*  6406 */     return nVSliderFloat(label, sizeX, sizeY, v, vMin, vMax, imGuiSliderFlags);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static boolean vSliderInt(String label, ImVec2 size, int[] v, int vMin, int vMax) {
/*  6454 */     return nVSliderInt(label, size.x, size.y, v, vMin, vMax);
/*       */   }
/*       */   
/*       */   public static boolean vSliderInt(String label, float sizeX, float sizeY, int[] v, int vMin, int vMax) {
/*  6458 */     return nVSliderInt(label, sizeX, sizeY, v, vMin, vMax);
/*       */   }
/*       */   
/*       */   public static boolean vSliderInt(String label, ImVec2 size, int[] v, int vMin, int vMax, String format) {
/*  6462 */     return nVSliderInt(label, size.x, size.y, v, vMin, vMax, format);
/*       */   }
/*       */   
/*       */   public static boolean vSliderInt(String label, float sizeX, float sizeY, int[] v, int vMin, int vMax, String format) {
/*  6466 */     return nVSliderInt(label, sizeX, sizeY, v, vMin, vMax, format);
/*       */   }
/*       */   
/*       */   public static boolean vSliderInt(String label, ImVec2 size, int[] v, int vMin, int vMax, String format, int imGuiSliderFlags) {
/*  6470 */     return nVSliderInt(label, size.x, size.y, v, vMin, vMax, format, imGuiSliderFlags);
/*       */   }
/*       */   
/*       */   public static boolean vSliderInt(String label, float sizeX, float sizeY, int[] v, int vMin, int vMax, String format, int imGuiSliderFlags) {
/*  6474 */     return nVSliderInt(label, sizeX, sizeY, v, vMin, vMax, format, imGuiSliderFlags);
/*       */   }
/*       */   
/*       */   public static boolean vSliderInt(String label, ImVec2 size, int[] v, int vMin, int vMax, int imGuiSliderFlags) {
/*  6478 */     return nVSliderInt(label, size.x, size.y, v, vMin, vMax, imGuiSliderFlags);
/*       */   }
/*       */   
/*       */   public static boolean vSliderInt(String label, float sizeX, float sizeY, int[] v, int vMin, int vMax, int imGuiSliderFlags) {
/*  6482 */     return nVSliderInt(label, sizeX, sizeY, v, vMin, vMax, imGuiSliderFlags);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static boolean vSliderScalar(String label, ImVec2 size, short[] pData, short pMin, short pMax) {
/*  6530 */     return nVSliderScalar(label, size.x, size.y, pData, pMin, pMax);
/*       */   }
/*       */   
/*       */   public static boolean vSliderScalar(String label, float sizeX, float sizeY, short[] pData, short pMin, short pMax) {
/*  6534 */     return nVSliderScalar(label, sizeX, sizeY, pData, pMin, pMax);
/*       */   }
/*       */   
/*       */   public static boolean vSliderScalar(String label, ImVec2 size, short[] pData, short pMin, short pMax, String format) {
/*  6538 */     return nVSliderScalar(label, size.x, size.y, pData, pMin, pMax, format);
/*       */   }
/*       */   
/*       */   public static boolean vSliderScalar(String label, float sizeX, float sizeY, short[] pData, short pMin, short pMax, String format) {
/*  6542 */     return nVSliderScalar(label, sizeX, sizeY, pData, pMin, pMax, format);
/*       */   }
/*       */   
/*       */   public static boolean vSliderScalar(String label, ImVec2 size, short[] pData, short pMin, short pMax, String format, int imGuiSliderFlags) {
/*  6546 */     return nVSliderScalar(label, size.x, size.y, pData, pMin, pMax, format, imGuiSliderFlags);
/*       */   }
/*       */   
/*       */   public static boolean vSliderScalar(String label, float sizeX, float sizeY, short[] pData, short pMin, short pMax, String format, int imGuiSliderFlags) {
/*  6550 */     return nVSliderScalar(label, sizeX, sizeY, pData, pMin, pMax, format, imGuiSliderFlags);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static boolean vSliderScalar(String label, ImVec2 size, int[] pData, int pMin, int pMax) {
/*  6588 */     return nVSliderScalar(label, size.x, size.y, pData, pMin, pMax);
/*       */   }
/*       */   
/*       */   public static boolean vSliderScalar(String label, float sizeX, float sizeY, int[] pData, int pMin, int pMax) {
/*  6592 */     return nVSliderScalar(label, sizeX, sizeY, pData, pMin, pMax);
/*       */   }
/*       */   
/*       */   public static boolean vSliderScalar(String label, ImVec2 size, int[] pData, int pMin, int pMax, String format) {
/*  6596 */     return nVSliderScalar(label, size.x, size.y, pData, pMin, pMax, format);
/*       */   }
/*       */   
/*       */   public static boolean vSliderScalar(String label, float sizeX, float sizeY, int[] pData, int pMin, int pMax, String format) {
/*  6600 */     return nVSliderScalar(label, sizeX, sizeY, pData, pMin, pMax, format);
/*       */   }
/*       */   
/*       */   public static boolean vSliderScalar(String label, ImVec2 size, int[] pData, int pMin, int pMax, String format, int imGuiSliderFlags) {
/*  6604 */     return nVSliderScalar(label, size.x, size.y, pData, pMin, pMax, format, imGuiSliderFlags);
/*       */   }
/*       */   
/*       */   public static boolean vSliderScalar(String label, float sizeX, float sizeY, int[] pData, int pMin, int pMax, String format, int imGuiSliderFlags) {
/*  6608 */     return nVSliderScalar(label, sizeX, sizeY, pData, pMin, pMax, format, imGuiSliderFlags);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static boolean vSliderScalar(String label, ImVec2 size, long[] pData, long pMin, long pMax) {
/*  6646 */     return nVSliderScalar(label, size.x, size.y, pData, pMin, pMax);
/*       */   }
/*       */   
/*       */   public static boolean vSliderScalar(String label, float sizeX, float sizeY, long[] pData, long pMin, long pMax) {
/*  6650 */     return nVSliderScalar(label, sizeX, sizeY, pData, pMin, pMax);
/*       */   }
/*       */   
/*       */   public static boolean vSliderScalar(String label, ImVec2 size, long[] pData, long pMin, long pMax, String format) {
/*  6654 */     return nVSliderScalar(label, size.x, size.y, pData, pMin, pMax, format);
/*       */   }
/*       */   
/*       */   public static boolean vSliderScalar(String label, float sizeX, float sizeY, long[] pData, long pMin, long pMax, String format) {
/*  6658 */     return nVSliderScalar(label, sizeX, sizeY, pData, pMin, pMax, format);
/*       */   }
/*       */   
/*       */   public static boolean vSliderScalar(String label, ImVec2 size, long[] pData, long pMin, long pMax, String format, int imGuiSliderFlags) {
/*  6662 */     return nVSliderScalar(label, size.x, size.y, pData, pMin, pMax, format, imGuiSliderFlags);
/*       */   }
/*       */   
/*       */   public static boolean vSliderScalar(String label, float sizeX, float sizeY, long[] pData, long pMin, long pMax, String format, int imGuiSliderFlags) {
/*  6666 */     return nVSliderScalar(label, sizeX, sizeY, pData, pMin, pMax, format, imGuiSliderFlags);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static boolean vSliderScalar(String label, ImVec2 size, float[] pData, float pMin, float pMax) {
/*  6704 */     return nVSliderScalar(label, size.x, size.y, pData, pMin, pMax);
/*       */   }
/*       */   
/*       */   public static boolean vSliderScalar(String label, float sizeX, float sizeY, float[] pData, float pMin, float pMax) {
/*  6708 */     return nVSliderScalar(label, sizeX, sizeY, pData, pMin, pMax);
/*       */   }
/*       */   
/*       */   public static boolean vSliderScalar(String label, ImVec2 size, float[] pData, float pMin, float pMax, String format) {
/*  6712 */     return nVSliderScalar(label, size.x, size.y, pData, pMin, pMax, format);
/*       */   }
/*       */   
/*       */   public static boolean vSliderScalar(String label, float sizeX, float sizeY, float[] pData, float pMin, float pMax, String format) {
/*  6716 */     return nVSliderScalar(label, sizeX, sizeY, pData, pMin, pMax, format);
/*       */   }
/*       */   
/*       */   public static boolean vSliderScalar(String label, ImVec2 size, float[] pData, float pMin, float pMax, String format, int imGuiSliderFlags) {
/*  6720 */     return nVSliderScalar(label, size.x, size.y, pData, pMin, pMax, format, imGuiSliderFlags);
/*       */   }
/*       */   
/*       */   public static boolean vSliderScalar(String label, float sizeX, float sizeY, float[] pData, float pMin, float pMax, String format, int imGuiSliderFlags) {
/*  6724 */     return nVSliderScalar(label, sizeX, sizeY, pData, pMin, pMax, format, imGuiSliderFlags);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static boolean vSliderScalar(String label, ImVec2 size, double[] pData, double pMin, double pMax) {
/*  6762 */     return nVSliderScalar(label, size.x, size.y, pData, pMin, pMax);
/*       */   }
/*       */   
/*       */   public static boolean vSliderScalar(String label, float sizeX, float sizeY, double[] pData, double pMin, double pMax) {
/*  6766 */     return nVSliderScalar(label, sizeX, sizeY, pData, pMin, pMax);
/*       */   }
/*       */   
/*       */   public static boolean vSliderScalar(String label, ImVec2 size, double[] pData, double pMin, double pMax, String format) {
/*  6770 */     return nVSliderScalar(label, size.x, size.y, pData, pMin, pMax, format);
/*       */   }
/*       */   
/*       */   public static boolean vSliderScalar(String label, float sizeX, float sizeY, double[] pData, double pMin, double pMax, String format) {
/*  6774 */     return nVSliderScalar(label, sizeX, sizeY, pData, pMin, pMax, format);
/*       */   }
/*       */   
/*       */   public static boolean vSliderScalar(String label, ImVec2 size, double[] pData, double pMin, double pMax, String format, int imGuiSliderFlags) {
/*  6778 */     return nVSliderScalar(label, size.x, size.y, pData, pMin, pMax, format, imGuiSliderFlags);
/*       */   }
/*       */   
/*       */   public static boolean vSliderScalar(String label, float sizeX, float sizeY, double[] pData, double pMin, double pMax, String format, int imGuiSliderFlags) {
/*  6782 */     return nVSliderScalar(label, sizeX, sizeY, pData, pMin, pMax, format, imGuiSliderFlags);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static boolean inputText(String label, ImString text) {
/*  6895 */     return preInputText(false, label, null, text);
/*       */   }
/*       */   
/*       */   public static boolean inputText(String label, ImString text, int imGuiInputTextFlags) {
/*  6899 */     return preInputText(false, label, null, text, 0.0F, 0.0F, imGuiInputTextFlags);
/*       */   }
/*       */   
/*       */   public static boolean inputText(String label, ImString text, int imGuiInputTextFlags, ImGuiInputTextCallback callback) {
/*  6903 */     return preInputText(false, label, null, text, 0.0F, 0.0F, imGuiInputTextFlags, callback);
/*       */   }
/*       */   
/*       */   public static boolean inputTextMultiline(String label, ImString text) {
/*  6907 */     return preInputText(true, label, null, text);
/*       */   }
/*       */   
/*       */   public static boolean inputTextMultiline(String label, ImString text, float width, float height) {
/*  6911 */     return preInputText(true, label, null, text, width, height);
/*       */   }
/*       */   
/*       */   public static boolean inputTextMultiline(String label, ImString text, int imGuiInputTextFlags) {
/*  6915 */     return preInputText(true, label, null, text, 0.0F, 0.0F, imGuiInputTextFlags);
/*       */   }
/*       */   
/*       */   public static boolean inputTextMultiline(String label, ImString text, int imGuiInputTextFlags, ImGuiInputTextCallback callback) {
/*  6919 */     return preInputText(true, label, null, text, 0.0F, 0.0F, imGuiInputTextFlags, callback);
/*       */   }
/*       */   
/*       */   public static boolean inputTextMultiline(String label, ImString text, float width, float height, int imGuiInputTextFlags) {
/*  6923 */     return preInputText(true, label, null, text, width, height, imGuiInputTextFlags);
/*       */   }
/*       */   
/*       */   public static boolean inputTextMultiline(String label, ImString text, float width, float height, int imGuiInputTextFlags, ImGuiInputTextCallback callback) {
/*  6927 */     return preInputText(true, label, null, text, width, height, imGuiInputTextFlags, callback);
/*       */   }
/*       */   
/*       */   public static boolean inputTextWithHint(String label, String hint, ImString text) {
/*  6931 */     return preInputText(false, label, hint, text);
/*       */   }
/*       */   
/*       */   public static boolean inputTextWithHint(String label, String hint, ImString text, int imGuiInputTextFlags) {
/*  6935 */     return preInputText(false, label, hint, text, 0.0F, 0.0F, imGuiInputTextFlags);
/*       */   }
/*       */   
/*       */   public static boolean inputTextWithHint(String label, String hint, ImString text, int imGuiInputTextFlags, ImGuiInputTextCallback callback) {
/*  6939 */     return preInputText(false, label, hint, text, 0.0F, 0.0F, imGuiInputTextFlags, callback);
/*       */   }
/*       */   
/*       */   private static boolean preInputText(boolean multiline, String label, String hint, ImString text) {
/*  6943 */     return preInputText(multiline, label, hint, text, 0.0F, 0.0F);
/*       */   }
/*       */   
/*       */   private static boolean preInputText(boolean multiline, String label, String hint, ImString text, float width, float height) {
/*  6947 */     return preInputText(multiline, label, hint, text, width, height, 0);
/*       */   }
/*       */   
/*       */   private static boolean preInputText(boolean multiline, String label, String hint, ImString text, float width, float height, int flags) {
/*  6951 */     return preInputText(multiline, label, hint, text, width, height, flags, null);
/*       */   }
/*       */   
/*       */   private static boolean preInputText(boolean multiline, String label, String hint, ImString text, float width, float height, int flags, ImGuiInputTextCallback callback) {
/*  6955 */     ImString.InputData inputData = text.inputData;
/*       */     
/*  6957 */     String hintLabel = hint;
/*  6958 */     if (hintLabel == null) {
/*  6959 */       hintLabel = "";
/*       */     }
/*       */     
/*  6962 */     return nInputText(multiline, (hint != null), label, hintLabel, text, text
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */         
/*  6968 */         .getData(), (text
/*  6969 */         .getData()).length, width, height, flags, inputData, inputData.allowedChars, inputData.isResizable, callback);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static boolean inputFloat(String label, ImFloat v) {
/*  7042 */     return nInputFloat(label, (v != null) ? v.getData() : null);
/*       */   }
/*       */   
/*       */   public static boolean inputFloat(String label, ImFloat v, float step) {
/*  7046 */     return nInputFloat(label, (v != null) ? v.getData() : null, step);
/*       */   }
/*       */   
/*       */   public static boolean inputFloat(String label, ImFloat v, float step, float stepFast) {
/*  7050 */     return nInputFloat(label, (v != null) ? v.getData() : null, step, stepFast);
/*       */   }
/*       */   
/*       */   public static boolean inputFloat(String label, ImFloat v, float step, float stepFast, String format) {
/*  7054 */     return nInputFloat(label, (v != null) ? v.getData() : null, step, stepFast, format);
/*       */   }
/*       */   
/*       */   public static boolean inputFloat(String label, ImFloat v, float step, float stepFast, String format, int imGuiInputTextFlags) {
/*  7058 */     return nInputFloat(label, (v != null) ? v.getData() : null, step, stepFast, format, imGuiInputTextFlags);
/*       */   }
/*       */   
/*       */   public static boolean inputFloat(String label, ImFloat v, float step, float stepFast, int imGuiInputTextFlags) {
/*  7062 */     return nInputFloat(label, (v != null) ? v.getData() : null, step, stepFast, imGuiInputTextFlags);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static boolean inputFloat2(String label, float[] v) {
/*  7124 */     return nInputFloat2(label, v);
/*       */   }
/*       */   
/*       */   public static boolean inputFloat2(String label, float[] v, String format) {
/*  7128 */     return nInputFloat2(label, v, format);
/*       */   }
/*       */   
/*       */   public static boolean inputFloat2(String label, float[] v, String format, int imGuiInputTextFlags) {
/*  7132 */     return nInputFloat2(label, v, format, imGuiInputTextFlags);
/*       */   }
/*       */   
/*       */   public static boolean inputFloat2(String label, float[] v, int imGuiInputTextFlags) {
/*  7136 */     return nInputFloat2(label, v, imGuiInputTextFlags);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static boolean inputFloat3(String label, float[] v) {
/*  7180 */     return nInputFloat3(label, v);
/*       */   }
/*       */   
/*       */   public static boolean inputFloat3(String label, float[] v, String format) {
/*  7184 */     return nInputFloat3(label, v, format);
/*       */   }
/*       */   
/*       */   public static boolean inputFloat3(String label, float[] v, String format, int imGuiInputTextFlags) {
/*  7188 */     return nInputFloat3(label, v, format, imGuiInputTextFlags);
/*       */   }
/*       */   
/*       */   public static boolean inputFloat3(String label, float[] v, int imGuiInputTextFlags) {
/*  7192 */     return nInputFloat3(label, v, imGuiInputTextFlags);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static boolean inputFloat4(String label, float[] v) {
/*  7236 */     return nInputFloat4(label, v);
/*       */   }
/*       */   
/*       */   public static boolean inputFloat4(String label, float[] v, String format) {
/*  7240 */     return nInputFloat4(label, v, format);
/*       */   }
/*       */   
/*       */   public static boolean inputFloat4(String label, float[] v, String format, int imGuiInputTextFlags) {
/*  7244 */     return nInputFloat4(label, v, format, imGuiInputTextFlags);
/*       */   }
/*       */   
/*       */   public static boolean inputFloat4(String label, float[] v, int imGuiInputTextFlags) {
/*  7248 */     return nInputFloat4(label, v, imGuiInputTextFlags);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static boolean inputInt(String label, ImInt v) {
/*  7292 */     return nInputInt(label, (v != null) ? v.getData() : null);
/*       */   }
/*       */   
/*       */   public static boolean inputInt(String label, ImInt v, int step) {
/*  7296 */     return nInputInt(label, (v != null) ? v.getData() : null, step);
/*       */   }
/*       */   
/*       */   public static boolean inputInt(String label, ImInt v, int step, int stepFast) {
/*  7300 */     return nInputInt(label, (v != null) ? v.getData() : null, step, stepFast);
/*       */   }
/*       */   
/*       */   public static boolean inputInt(String label, ImInt v, int step, int stepFast, int imGuiInputTextFlags) {
/*  7304 */     return nInputInt(label, (v != null) ? v.getData() : null, step, stepFast, imGuiInputTextFlags);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static boolean inputInt2(String label, int[] v) {
/*  7344 */     return nInputInt2(label, v);
/*       */   }
/*       */   
/*       */   public static boolean inputInt2(String label, int[] v, int imGuiInputTextFlags) {
/*  7348 */     return nInputInt2(label, v, imGuiInputTextFlags);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static boolean inputInt3(String label, int[] v) {
/*  7370 */     return nInputInt3(label, v);
/*       */   }
/*       */   
/*       */   public static boolean inputInt3(String label, int[] v, int imGuiInputTextFlags) {
/*  7374 */     return nInputInt3(label, v, imGuiInputTextFlags);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static boolean inputInt4(String label, int[] v) {
/*  7396 */     return nInputInt4(label, v);
/*       */   }
/*       */   
/*       */   public static boolean inputInt4(String label, int[] v, int imGuiInputTextFlags) {
/*  7400 */     return nInputInt4(label, v, imGuiInputTextFlags);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static boolean inputDouble(String label, ImDouble v) {
/*  7422 */     return nInputDouble(label, (v != null) ? v.getData() : null);
/*       */   }
/*       */   
/*       */   public static boolean inputDouble(String label, ImDouble v, double step) {
/*  7426 */     return nInputDouble(label, (v != null) ? v.getData() : null, step);
/*       */   }
/*       */   
/*       */   public static boolean inputDouble(String label, ImDouble v, double step, double stepFast) {
/*  7430 */     return nInputDouble(label, (v != null) ? v.getData() : null, step, stepFast);
/*       */   }
/*       */   
/*       */   public static boolean inputDouble(String label, ImDouble v, double step, double stepFast, String format) {
/*  7434 */     return nInputDouble(label, (v != null) ? v.getData() : null, step, stepFast, format);
/*       */   }
/*       */   
/*       */   public static boolean inputDouble(String label, ImDouble v, double step, double stepFast, String format, int imGuiInputTextFlags) {
/*  7438 */     return nInputDouble(label, (v != null) ? v.getData() : null, step, stepFast, format, imGuiInputTextFlags);
/*       */   }
/*       */   
/*       */   public static boolean inputDouble(String label, ImDouble v, double step, double stepFast, int imGuiInputTextFlags) {
/*  7442 */     return nInputDouble(label, (v != null) ? v.getData() : null, step, stepFast, imGuiInputTextFlags);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static boolean inputScalar(String label, ImShort pData) {
/*  7504 */     return nInputScalar(label, (pData != null) ? pData.getData() : null);
/*       */   }
/*       */   
/*       */   public static boolean inputScalar(String label, ImShort pData, short pStep) {
/*  7508 */     return nInputScalar(label, (pData != null) ? pData.getData() : null, pStep);
/*       */   }
/*       */   
/*       */   public static boolean inputScalar(String label, ImShort pData, short pStep, short pStepFast) {
/*  7512 */     return nInputScalar(label, (pData != null) ? pData.getData() : null, pStep, pStepFast);
/*       */   }
/*       */   
/*       */   public static boolean inputScalar(String label, ImShort pData, short pStep, short pStepFast, String format) {
/*  7516 */     return nInputScalar(label, (pData != null) ? pData.getData() : null, pStep, pStepFast, format);
/*       */   }
/*       */   
/*       */   public static boolean inputScalar(String label, ImShort pData, short pStep, short pStepFast, String format, int imGuiSliderFlags) {
/*  7520 */     return nInputScalar(label, (pData != null) ? pData.getData() : null, pStep, pStepFast, format, imGuiSliderFlags);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static boolean inputScalar(String label, ImInt pData) {
/*  7573 */     return nInputScalar(label, (pData != null) ? pData.getData() : null);
/*       */   }
/*       */   
/*       */   public static boolean inputScalar(String label, ImInt pData, int pStep) {
/*  7577 */     return nInputScalar(label, (pData != null) ? pData.getData() : null, pStep);
/*       */   }
/*       */   
/*       */   public static boolean inputScalar(String label, ImInt pData, int pStep, int pStepFast) {
/*  7581 */     return nInputScalar(label, (pData != null) ? pData.getData() : null, pStep, pStepFast);
/*       */   }
/*       */   
/*       */   public static boolean inputScalar(String label, ImInt pData, int pStep, int pStepFast, String format) {
/*  7585 */     return nInputScalar(label, (pData != null) ? pData.getData() : null, pStep, pStepFast, format);
/*       */   }
/*       */   
/*       */   public static boolean inputScalar(String label, ImInt pData, int pStep, int pStepFast, String format, int imGuiSliderFlags) {
/*  7589 */     return nInputScalar(label, (pData != null) ? pData.getData() : null, pStep, pStepFast, format, imGuiSliderFlags);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static boolean inputScalar(String label, ImLong pData) {
/*  7642 */     return nInputScalar(label, (pData != null) ? pData.getData() : null);
/*       */   }
/*       */   
/*       */   public static boolean inputScalar(String label, ImLong pData, long pStep) {
/*  7646 */     return nInputScalar(label, (pData != null) ? pData.getData() : null, pStep);
/*       */   }
/*       */   
/*       */   public static boolean inputScalar(String label, ImLong pData, long pStep, long pStepFast) {
/*  7650 */     return nInputScalar(label, (pData != null) ? pData.getData() : null, pStep, pStepFast);
/*       */   }
/*       */   
/*       */   public static boolean inputScalar(String label, ImLong pData, long pStep, long pStepFast, String format) {
/*  7654 */     return nInputScalar(label, (pData != null) ? pData.getData() : null, pStep, pStepFast, format);
/*       */   }
/*       */   
/*       */   public static boolean inputScalar(String label, ImLong pData, long pStep, long pStepFast, String format, int imGuiSliderFlags) {
/*  7658 */     return nInputScalar(label, (pData != null) ? pData.getData() : null, pStep, pStepFast, format, imGuiSliderFlags);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static boolean inputScalar(String label, ImFloat pData) {
/*  7711 */     return nInputScalar(label, (pData != null) ? pData.getData() : null);
/*       */   }
/*       */   
/*       */   public static boolean inputScalar(String label, ImFloat pData, float pStep) {
/*  7715 */     return nInputScalar(label, (pData != null) ? pData.getData() : null, pStep);
/*       */   }
/*       */   
/*       */   public static boolean inputScalar(String label, ImFloat pData, float pStep, float pStepFast) {
/*  7719 */     return nInputScalar(label, (pData != null) ? pData.getData() : null, pStep, pStepFast);
/*       */   }
/*       */   
/*       */   public static boolean inputScalar(String label, ImFloat pData, float pStep, float pStepFast, String format) {
/*  7723 */     return nInputScalar(label, (pData != null) ? pData.getData() : null, pStep, pStepFast, format);
/*       */   }
/*       */   
/*       */   public static boolean inputScalar(String label, ImFloat pData, float pStep, float pStepFast, String format, int imGuiSliderFlags) {
/*  7727 */     return nInputScalar(label, (pData != null) ? pData.getData() : null, pStep, pStepFast, format, imGuiSliderFlags);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static boolean inputScalar(String label, ImDouble pData) {
/*  7780 */     return nInputScalar(label, (pData != null) ? pData.getData() : null);
/*       */   }
/*       */   
/*       */   public static boolean inputScalar(String label, ImDouble pData, double pStep) {
/*  7784 */     return nInputScalar(label, (pData != null) ? pData.getData() : null, pStep);
/*       */   }
/*       */   
/*       */   public static boolean inputScalar(String label, ImDouble pData, double pStep, double pStepFast) {
/*  7788 */     return nInputScalar(label, (pData != null) ? pData.getData() : null, pStep, pStepFast);
/*       */   }
/*       */   
/*       */   public static boolean inputScalar(String label, ImDouble pData, double pStep, double pStepFast, String format) {
/*  7792 */     return nInputScalar(label, (pData != null) ? pData.getData() : null, pStep, pStepFast, format);
/*       */   }
/*       */   
/*       */   public static boolean inputScalar(String label, ImDouble pData, double pStep, double pStepFast, String format, int imGuiSliderFlags) {
/*  7796 */     return nInputScalar(label, (pData != null) ? pData.getData() : null, pStep, pStepFast, format, imGuiSliderFlags);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static boolean inputScalar(String label, int dataType, ImShort pData) {
/*  7849 */     return nInputScalar(label, dataType, (pData != null) ? pData.getData() : null);
/*       */   }
/*       */   
/*       */   public static boolean inputScalar(String label, int dataType, ImShort pData, short pStep) {
/*  7853 */     return nInputScalar(label, dataType, (pData != null) ? pData.getData() : null, pStep);
/*       */   }
/*       */   
/*       */   public static boolean inputScalar(String label, int dataType, ImShort pData, short pStep, short pStepFast) {
/*  7857 */     return nInputScalar(label, dataType, (pData != null) ? pData.getData() : null, pStep, pStepFast);
/*       */   }
/*       */   
/*       */   public static boolean inputScalar(String label, int dataType, ImShort pData, short pStep, short pStepFast, String format) {
/*  7861 */     return nInputScalar(label, dataType, (pData != null) ? pData.getData() : null, pStep, pStepFast, format);
/*       */   }
/*       */   
/*       */   public static boolean inputScalar(String label, int dataType, ImShort pData, short pStep, short pStepFast, String format, int imGuiSliderFlags) {
/*  7865 */     return nInputScalar(label, dataType, (pData != null) ? pData.getData() : null, pStep, pStepFast, format, imGuiSliderFlags);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static boolean inputScalar(String label, int dataType, ImInt pData) {
/*  7918 */     return nInputScalar(label, dataType, (pData != null) ? pData.getData() : null);
/*       */   }
/*       */   
/*       */   public static boolean inputScalar(String label, int dataType, ImInt pData, int pStep) {
/*  7922 */     return nInputScalar(label, dataType, (pData != null) ? pData.getData() : null, pStep);
/*       */   }
/*       */   
/*       */   public static boolean inputScalar(String label, int dataType, ImInt pData, int pStep, int pStepFast) {
/*  7926 */     return nInputScalar(label, dataType, (pData != null) ? pData.getData() : null, pStep, pStepFast);
/*       */   }
/*       */   
/*       */   public static boolean inputScalar(String label, int dataType, ImInt pData, int pStep, int pStepFast, String format) {
/*  7930 */     return nInputScalar(label, dataType, (pData != null) ? pData.getData() : null, pStep, pStepFast, format);
/*       */   }
/*       */   
/*       */   public static boolean inputScalar(String label, int dataType, ImInt pData, int pStep, int pStepFast, String format, int imGuiSliderFlags) {
/*  7934 */     return nInputScalar(label, dataType, (pData != null) ? pData.getData() : null, pStep, pStepFast, format, imGuiSliderFlags);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static boolean inputScalar(String label, int dataType, ImLong pData) {
/*  7987 */     return nInputScalar(label, dataType, (pData != null) ? pData.getData() : null);
/*       */   }
/*       */   
/*       */   public static boolean inputScalar(String label, int dataType, ImLong pData, long pStep) {
/*  7991 */     return nInputScalar(label, dataType, (pData != null) ? pData.getData() : null, pStep);
/*       */   }
/*       */   
/*       */   public static boolean inputScalar(String label, int dataType, ImLong pData, long pStep, long pStepFast) {
/*  7995 */     return nInputScalar(label, dataType, (pData != null) ? pData.getData() : null, pStep, pStepFast);
/*       */   }
/*       */   
/*       */   public static boolean inputScalar(String label, int dataType, ImLong pData, long pStep, long pStepFast, String format) {
/*  7999 */     return nInputScalar(label, dataType, (pData != null) ? pData.getData() : null, pStep, pStepFast, format);
/*       */   }
/*       */   
/*       */   public static boolean inputScalar(String label, int dataType, ImLong pData, long pStep, long pStepFast, String format, int imGuiSliderFlags) {
/*  8003 */     return nInputScalar(label, dataType, (pData != null) ? pData.getData() : null, pStep, pStepFast, format, imGuiSliderFlags);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static boolean inputScalar(String label, int dataType, ImFloat pData) {
/*  8056 */     return nInputScalar(label, dataType, (pData != null) ? pData.getData() : null);
/*       */   }
/*       */   
/*       */   public static boolean inputScalar(String label, int dataType, ImFloat pData, float pStep) {
/*  8060 */     return nInputScalar(label, dataType, (pData != null) ? pData.getData() : null, pStep);
/*       */   }
/*       */   
/*       */   public static boolean inputScalar(String label, int dataType, ImFloat pData, float pStep, float pStepFast) {
/*  8064 */     return nInputScalar(label, dataType, (pData != null) ? pData.getData() : null, pStep, pStepFast);
/*       */   }
/*       */   
/*       */   public static boolean inputScalar(String label, int dataType, ImFloat pData, float pStep, float pStepFast, String format) {
/*  8068 */     return nInputScalar(label, dataType, (pData != null) ? pData.getData() : null, pStep, pStepFast, format);
/*       */   }
/*       */   
/*       */   public static boolean inputScalar(String label, int dataType, ImFloat pData, float pStep, float pStepFast, String format, int imGuiSliderFlags) {
/*  8072 */     return nInputScalar(label, dataType, (pData != null) ? pData.getData() : null, pStep, pStepFast, format, imGuiSliderFlags);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static boolean inputScalar(String label, int dataType, ImDouble pData) {
/*  8125 */     return nInputScalar(label, dataType, (pData != null) ? pData.getData() : null);
/*       */   }
/*       */   
/*       */   public static boolean inputScalar(String label, int dataType, ImDouble pData, double pStep) {
/*  8129 */     return nInputScalar(label, dataType, (pData != null) ? pData.getData() : null, pStep);
/*       */   }
/*       */   
/*       */   public static boolean inputScalar(String label, int dataType, ImDouble pData, double pStep, double pStepFast) {
/*  8133 */     return nInputScalar(label, dataType, (pData != null) ? pData.getData() : null, pStep, pStepFast);
/*       */   }
/*       */   
/*       */   public static boolean inputScalar(String label, int dataType, ImDouble pData, double pStep, double pStepFast, String format) {
/*  8137 */     return nInputScalar(label, dataType, (pData != null) ? pData.getData() : null, pStep, pStepFast, format);
/*       */   }
/*       */   
/*       */   public static boolean inputScalar(String label, int dataType, ImDouble pData, double pStep, double pStepFast, String format, int imGuiSliderFlags) {
/*  8141 */     return nInputScalar(label, dataType, (pData != null) ? pData.getData() : null, pStep, pStepFast, format, imGuiSliderFlags);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static boolean inputScalarN(String label, short[] pData, int components) {
/*  8194 */     return nInputScalarN(label, pData, components);
/*       */   }
/*       */   
/*       */   public static boolean inputScalarN(String label, short[] pData, int components, short pStep) {
/*  8198 */     return nInputScalarN(label, pData, components, pStep);
/*       */   }
/*       */   
/*       */   public static boolean inputScalarN(String label, short[] pData, int components, short pStep, short pStepFast) {
/*  8202 */     return nInputScalarN(label, pData, components, pStep, pStepFast);
/*       */   }
/*       */   
/*       */   public static boolean inputScalarN(String label, short[] pData, int components, short pStep, short pStepFast, String format) {
/*  8206 */     return nInputScalarN(label, pData, components, pStep, pStepFast, format);
/*       */   }
/*       */   
/*       */   public static boolean inputScalarN(String label, short[] pData, int components, short pStep, short pStepFast, String format, int imGuiSliderFlags) {
/*  8210 */     return nInputScalarN(label, pData, components, pStep, pStepFast, format, imGuiSliderFlags);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static boolean inputScalarN(String label, int[] pData, int components) {
/*  8263 */     return nInputScalarN(label, pData, components);
/*       */   }
/*       */   
/*       */   public static boolean inputScalarN(String label, int[] pData, int components, int pStep) {
/*  8267 */     return nInputScalarN(label, pData, components, pStep);
/*       */   }
/*       */   
/*       */   public static boolean inputScalarN(String label, int[] pData, int components, int pStep, int pStepFast) {
/*  8271 */     return nInputScalarN(label, pData, components, pStep, pStepFast);
/*       */   }
/*       */   
/*       */   public static boolean inputScalarN(String label, int[] pData, int components, int pStep, int pStepFast, String format) {
/*  8275 */     return nInputScalarN(label, pData, components, pStep, pStepFast, format);
/*       */   }
/*       */   
/*       */   public static boolean inputScalarN(String label, int[] pData, int components, int pStep, int pStepFast, String format, int imGuiSliderFlags) {
/*  8279 */     return nInputScalarN(label, pData, components, pStep, pStepFast, format, imGuiSliderFlags);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static boolean inputScalarN(String label, long[] pData, int components) {
/*  8332 */     return nInputScalarN(label, pData, components);
/*       */   }
/*       */   
/*       */   public static boolean inputScalarN(String label, long[] pData, int components, long pStep) {
/*  8336 */     return nInputScalarN(label, pData, components, pStep);
/*       */   }
/*       */   
/*       */   public static boolean inputScalarN(String label, long[] pData, int components, long pStep, long pStepFast) {
/*  8340 */     return nInputScalarN(label, pData, components, pStep, pStepFast);
/*       */   }
/*       */   
/*       */   public static boolean inputScalarN(String label, long[] pData, int components, long pStep, long pStepFast, String format) {
/*  8344 */     return nInputScalarN(label, pData, components, pStep, pStepFast, format);
/*       */   }
/*       */   
/*       */   public static boolean inputScalarN(String label, long[] pData, int components, long pStep, long pStepFast, String format, int imGuiSliderFlags) {
/*  8348 */     return nInputScalarN(label, pData, components, pStep, pStepFast, format, imGuiSliderFlags);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static boolean inputScalarN(String label, float[] pData, int components) {
/*  8401 */     return nInputScalarN(label, pData, components);
/*       */   }
/*       */   
/*       */   public static boolean inputScalarN(String label, float[] pData, int components, float pStep) {
/*  8405 */     return nInputScalarN(label, pData, components, pStep);
/*       */   }
/*       */   
/*       */   public static boolean inputScalarN(String label, float[] pData, int components, float pStep, float pStepFast) {
/*  8409 */     return nInputScalarN(label, pData, components, pStep, pStepFast);
/*       */   }
/*       */   
/*       */   public static boolean inputScalarN(String label, float[] pData, int components, float pStep, float pStepFast, String format) {
/*  8413 */     return nInputScalarN(label, pData, components, pStep, pStepFast, format);
/*       */   }
/*       */   
/*       */   public static boolean inputScalarN(String label, float[] pData, int components, float pStep, float pStepFast, String format, int imGuiSliderFlags) {
/*  8417 */     return nInputScalarN(label, pData, components, pStep, pStepFast, format, imGuiSliderFlags);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static boolean inputScalarN(String label, double[] pData, int components) {
/*  8470 */     return nInputScalarN(label, pData, components);
/*       */   }
/*       */   
/*       */   public static boolean inputScalarN(String label, double[] pData, int components, double pStep) {
/*  8474 */     return nInputScalarN(label, pData, components, pStep);
/*       */   }
/*       */   
/*       */   public static boolean inputScalarN(String label, double[] pData, int components, double pStep, double pStepFast) {
/*  8478 */     return nInputScalarN(label, pData, components, pStep, pStepFast);
/*       */   }
/*       */   
/*       */   public static boolean inputScalarN(String label, double[] pData, int components, double pStep, double pStepFast, String format) {
/*  8482 */     return nInputScalarN(label, pData, components, pStep, pStepFast, format);
/*       */   }
/*       */   
/*       */   public static boolean inputScalarN(String label, double[] pData, int components, double pStep, double pStepFast, String format, int imGuiSliderFlags) {
/*  8486 */     return nInputScalarN(label, pData, components, pStep, pStepFast, format, imGuiSliderFlags);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static boolean inputScalarN(String label, int dataType, short[] pData, int components) {
/*  8539 */     return nInputScalarN(label, dataType, pData, components);
/*       */   }
/*       */   
/*       */   public static boolean inputScalarN(String label, int dataType, short[] pData, int components, short pStep) {
/*  8543 */     return nInputScalarN(label, dataType, pData, components, pStep);
/*       */   }
/*       */   
/*       */   public static boolean inputScalarN(String label, int dataType, short[] pData, int components, short pStep, short pStepFast) {
/*  8547 */     return nInputScalarN(label, dataType, pData, components, pStep, pStepFast);
/*       */   }
/*       */   
/*       */   public static boolean inputScalarN(String label, int dataType, short[] pData, int components, short pStep, short pStepFast, String format) {
/*  8551 */     return nInputScalarN(label, dataType, pData, components, pStep, pStepFast, format);
/*       */   }
/*       */   
/*       */   public static boolean inputScalarN(String label, int dataType, short[] pData, int components, short pStep, short pStepFast, String format, int imGuiSliderFlags) {
/*  8555 */     return nInputScalarN(label, dataType, pData, components, pStep, pStepFast, format, imGuiSliderFlags);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static boolean inputScalarN(String label, int dataType, int[] pData, int components) {
/*  8608 */     return nInputScalarN(label, dataType, pData, components);
/*       */   }
/*       */   
/*       */   public static boolean inputScalarN(String label, int dataType, int[] pData, int components, int pStep) {
/*  8612 */     return nInputScalarN(label, dataType, pData, components, pStep);
/*       */   }
/*       */   
/*       */   public static boolean inputScalarN(String label, int dataType, int[] pData, int components, int pStep, int pStepFast) {
/*  8616 */     return nInputScalarN(label, dataType, pData, components, pStep, pStepFast);
/*       */   }
/*       */   
/*       */   public static boolean inputScalarN(String label, int dataType, int[] pData, int components, int pStep, int pStepFast, String format) {
/*  8620 */     return nInputScalarN(label, dataType, pData, components, pStep, pStepFast, format);
/*       */   }
/*       */   
/*       */   public static boolean inputScalarN(String label, int dataType, int[] pData, int components, int pStep, int pStepFast, String format, int imGuiSliderFlags) {
/*  8624 */     return nInputScalarN(label, dataType, pData, components, pStep, pStepFast, format, imGuiSliderFlags);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static boolean inputScalarN(String label, int dataType, long[] pData, int components) {
/*  8677 */     return nInputScalarN(label, dataType, pData, components);
/*       */   }
/*       */   
/*       */   public static boolean inputScalarN(String label, int dataType, long[] pData, int components, long pStep) {
/*  8681 */     return nInputScalarN(label, dataType, pData, components, pStep);
/*       */   }
/*       */   
/*       */   public static boolean inputScalarN(String label, int dataType, long[] pData, int components, long pStep, long pStepFast) {
/*  8685 */     return nInputScalarN(label, dataType, pData, components, pStep, pStepFast);
/*       */   }
/*       */   
/*       */   public static boolean inputScalarN(String label, int dataType, long[] pData, int components, long pStep, long pStepFast, String format) {
/*  8689 */     return nInputScalarN(label, dataType, pData, components, pStep, pStepFast, format);
/*       */   }
/*       */   
/*       */   public static boolean inputScalarN(String label, int dataType, long[] pData, int components, long pStep, long pStepFast, String format, int imGuiSliderFlags) {
/*  8693 */     return nInputScalarN(label, dataType, pData, components, pStep, pStepFast, format, imGuiSliderFlags);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static boolean inputScalarN(String label, int dataType, float[] pData, int components) {
/*  8746 */     return nInputScalarN(label, dataType, pData, components);
/*       */   }
/*       */   
/*       */   public static boolean inputScalarN(String label, int dataType, float[] pData, int components, float pStep) {
/*  8750 */     return nInputScalarN(label, dataType, pData, components, pStep);
/*       */   }
/*       */   
/*       */   public static boolean inputScalarN(String label, int dataType, float[] pData, int components, float pStep, float pStepFast) {
/*  8754 */     return nInputScalarN(label, dataType, pData, components, pStep, pStepFast);
/*       */   }
/*       */   
/*       */   public static boolean inputScalarN(String label, int dataType, float[] pData, int components, float pStep, float pStepFast, String format) {
/*  8758 */     return nInputScalarN(label, dataType, pData, components, pStep, pStepFast, format);
/*       */   }
/*       */   
/*       */   public static boolean inputScalarN(String label, int dataType, float[] pData, int components, float pStep, float pStepFast, String format, int imGuiSliderFlags) {
/*  8762 */     return nInputScalarN(label, dataType, pData, components, pStep, pStepFast, format, imGuiSliderFlags);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static boolean inputScalarN(String label, int dataType, double[] pData, int components) {
/*  8815 */     return nInputScalarN(label, dataType, pData, components);
/*       */   }
/*       */   
/*       */   public static boolean inputScalarN(String label, int dataType, double[] pData, int components, double pStep) {
/*  8819 */     return nInputScalarN(label, dataType, pData, components, pStep);
/*       */   }
/*       */   
/*       */   public static boolean inputScalarN(String label, int dataType, double[] pData, int components, double pStep, double pStepFast) {
/*  8823 */     return nInputScalarN(label, dataType, pData, components, pStep, pStepFast);
/*       */   }
/*       */   
/*       */   public static boolean inputScalarN(String label, int dataType, double[] pData, int components, double pStep, double pStepFast, String format) {
/*  8827 */     return nInputScalarN(label, dataType, pData, components, pStep, pStepFast, format);
/*       */   }
/*       */   
/*       */   public static boolean inputScalarN(String label, int dataType, double[] pData, int components, double pStep, double pStepFast, String format, int imGuiSliderFlags) {
/*  8831 */     return nInputScalarN(label, dataType, pData, components, pStep, pStepFast, format, imGuiSliderFlags);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static boolean colorEdit3(String label, float[] col) {
/*  8888 */     return nColorEdit3(label, col);
/*       */   }
/*       */   
/*       */   public static boolean colorEdit3(String label, float[] col, int imGuiColorEditFlags) {
/*  8892 */     return nColorEdit3(label, col, imGuiColorEditFlags);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static boolean colorEdit4(String label, float[] col) {
/*  8914 */     return nColorEdit4(label, col);
/*       */   }
/*       */   
/*       */   public static boolean colorEdit4(String label, float[] col, int imGuiColorEditFlags) {
/*  8918 */     return nColorEdit4(label, col, imGuiColorEditFlags);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static boolean colorPicker3(String label, float[] col) {
/*  8940 */     return nColorPicker3(label, col);
/*       */   }
/*       */   
/*       */   public static boolean colorPicker3(String label, float[] col, int imGuiColorEditFlags) {
/*  8944 */     return nColorPicker3(label, col, imGuiColorEditFlags);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static boolean colorPicker4(String label, float[] col) {
/*  8966 */     return nColorPicker4(label, col);
/*       */   }
/*       */   
/*       */   public static boolean colorPicker4(String label, float[] col, int imGuiColorEditFlags) {
/*  8970 */     return nColorPicker4(label, col, imGuiColorEditFlags);
/*       */   }
/*       */   
/*       */   public static boolean colorPicker4(String label, float[] col, int imGuiColorEditFlags, float[] refCol) {
/*  8974 */     return nColorPicker4(label, col, imGuiColorEditFlags, refCol);
/*       */   }
/*       */   
/*       */   public static boolean colorPicker4(String label, float[] col, float[] refCol) {
/*  8978 */     return nColorPicker4(label, col, refCol);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static boolean colorButton(String descId, ImVec4 col) {
/*  9025 */     return nColorButton(descId, col.x, col.y, col.z, col.w);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static boolean colorButton(String descId, float colX, float colY, float colZ, float colW) {
/*  9032 */     return nColorButton(descId, colX, colY, colZ, colW);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static boolean colorButton(String descId, ImVec4 col, int imGuiColorEditFlags) {
/*  9039 */     return nColorButton(descId, col.x, col.y, col.z, col.w, imGuiColorEditFlags);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static boolean colorButton(String descId, float colX, float colY, float colZ, float colW, int imGuiColorEditFlags) {
/*  9046 */     return nColorButton(descId, colX, colY, colZ, colW, imGuiColorEditFlags);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static boolean colorButton(String descId, ImVec4 col, int imGuiColorEditFlags, ImVec2 size) {
/*  9053 */     return nColorButton(descId, col.x, col.y, col.z, col.w, imGuiColorEditFlags, size.x, size.y);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static boolean colorButton(String descId, float colX, float colY, float colZ, float colW, int imGuiColorEditFlags, float sizeX, float sizeY) {
/*  9060 */     return nColorButton(descId, colX, colY, colZ, colW, imGuiColorEditFlags, sizeX, sizeY);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static boolean colorButton(String descId, ImVec4 col, ImVec2 size) {
/*  9067 */     return nColorButton(descId, col.x, col.y, col.z, col.w, size.x, size.y);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static boolean colorButton(String descId, float colX, float colY, float colZ, float colW, float sizeX, float sizeY) {
/*  9074 */     return nColorButton(descId, colX, colY, colZ, colW, sizeX, sizeY);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   @Deprecated
/*       */   public static boolean colorButton(String descId, float[] col) {
/*  9118 */     return nColorButton(descId, col);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   @Deprecated
/*       */   public static boolean colorButton(String descId, float[] col, int imGuiColorEditFlags) {
/*  9128 */     return nColorButton(descId, col, imGuiColorEditFlags);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   @Deprecated
/*       */   public static boolean colorButton(String descId, float[] col, int imGuiColorEditFlags, ImVec2 size) {
/*  9138 */     return nColorButton(descId, col, imGuiColorEditFlags, size.x, size.y);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   @Deprecated
/*       */   public static boolean colorButton(String descId, float[] col, int imGuiColorEditFlags, float sizeX, float sizeY) {
/*  9148 */     return nColorButton(descId, col, imGuiColorEditFlags, sizeX, sizeY);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   @Deprecated
/*       */   public static boolean colorButton(String descId, float[] col, ImVec2 size) {
/*  9158 */     return nColorButton(descId, col, size.x, size.y);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   @Deprecated
/*       */   public static boolean colorButton(String descId, float[] col, float sizeX, float sizeY) {
/*  9168 */     return nColorButton(descId, col, sizeX, sizeY);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static void setColorEditOptions(int imGuiColorEditFlags) {
/*  9214 */     nSetColorEditOptions(imGuiColorEditFlags);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static boolean treeNode(String label) {
/*  9225 */     return nTreeNode(label);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static boolean treeNode(String strId, String label) {
/*  9240 */     return nTreeNode(strId, label);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static boolean treeNode(long ptrId, String label) {
/*  9253 */     return nTreeNode(ptrId, label);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static boolean treeNodeEx(String label) {
/*  9264 */     return nTreeNodeEx(label);
/*       */   }
/*       */   
/*       */   public static boolean treeNodeEx(String label, int flags) {
/*  9268 */     return nTreeNodeEx(label, flags);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static boolean treeNodeEx(String strId, int flags, String label) {
/*  9286 */     return nTreeNodeEx(strId, flags, label);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static boolean treeNodeEx(long ptrId, int flags, String label) {
/*  9299 */     return nTreeNodeEx(ptrId, flags, label);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static void treePush(String strId) {
/*  9313 */     nTreePush(strId);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static void treePush(long ptrId) {
/*  9326 */     nTreePush(ptrId);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static void treePop() {
/*  9337 */     nTreePop();
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static float getTreeNodeToLabelSpacing() {
/*  9348 */     return nGetTreeNodeToLabelSpacing();
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static boolean collapsingHeader(String label) {
/*  9359 */     return nCollapsingHeader(label);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static boolean collapsingHeader(String label, int imGuiTreeNodeFlags) {
/*  9366 */     return nCollapsingHeader(label, imGuiTreeNodeFlags);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static boolean collapsingHeader(String label, ImBoolean pVisible) {
/*  9388 */     return nCollapsingHeader(label, (pVisible != null) ? pVisible.getData() : null);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static boolean collapsingHeader(String label, ImBoolean pVisible, int imGuiTreeNodeFlags) {
/*  9396 */     return nCollapsingHeader(label, (pVisible != null) ? pVisible.getData() : null, imGuiTreeNodeFlags);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static void setNextItemOpen(boolean isOpen) {
/*  9421 */     nSetNextItemOpen(isOpen);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static void setNextItemOpen(boolean isOpen, int cond) {
/*  9428 */     nSetNextItemOpen(isOpen, cond);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static boolean selectable(String label) {
/*  9444 */     return nSelectable(label);
/*       */   }
/*       */   
/*       */   public static boolean selectable(String label, boolean selected) {
/*  9448 */     return nSelectable(label, selected);
/*       */   }
/*       */   
/*       */   public static boolean selectable(String label, boolean selected, int imGuiSelectableFlags) {
/*  9452 */     return nSelectable(label, selected, imGuiSelectableFlags);
/*       */   }
/*       */   
/*       */   public static boolean selectable(String label, boolean selected, int imGuiSelectableFlags, ImVec2 size) {
/*  9456 */     return nSelectable(label, selected, imGuiSelectableFlags, size.x, size.y);
/*       */   }
/*       */   
/*       */   public static boolean selectable(String label, boolean selected, int imGuiSelectableFlags, float sizeX, float sizeY) {
/*  9460 */     return nSelectable(label, selected, imGuiSelectableFlags, sizeX, sizeY);
/*       */   }
/*       */   
/*       */   public static boolean selectable(String label, int imGuiSelectableFlags, ImVec2 size) {
/*  9464 */     return nSelectable(label, imGuiSelectableFlags, size.x, size.y);
/*       */   }
/*       */   
/*       */   public static boolean selectable(String label, int imGuiSelectableFlags, float sizeX, float sizeY) {
/*  9468 */     return nSelectable(label, imGuiSelectableFlags, sizeX, sizeY);
/*       */   }
/*       */   
/*       */   public static boolean selectable(String label, ImVec2 size) {
/*  9472 */     return nSelectable(label, size.x, size.y);
/*       */   }
/*       */   
/*       */   public static boolean selectable(String label, float sizeX, float sizeY) {
/*  9476 */     return nSelectable(label, sizeX, sizeY);
/*       */   }
/*       */   
/*       */   public static boolean selectable(String label, boolean selected, ImVec2 size) {
/*  9480 */     return nSelectable(label, selected, size.x, size.y);
/*       */   }
/*       */   
/*       */   public static boolean selectable(String label, boolean selected, float sizeX, float sizeY) {
/*  9484 */     return nSelectable(label, selected, sizeX, sizeY);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static boolean selectable(String label, ImBoolean pSelected) {
/*  9541 */     return nSelectable(label, (pSelected != null) ? pSelected.getData() : null);
/*       */   }
/*       */   
/*       */   public static boolean selectable(String label, ImBoolean pSelected, int imGuiSelectableFlags) {
/*  9545 */     return nSelectable(label, (pSelected != null) ? pSelected.getData() : null, imGuiSelectableFlags);
/*       */   }
/*       */   
/*       */   public static boolean selectable(String label, ImBoolean pSelected, int imGuiSelectableFlags, ImVec2 size) {
/*  9549 */     return nSelectable(label, (pSelected != null) ? pSelected.getData() : null, imGuiSelectableFlags, size.x, size.y);
/*       */   }
/*       */   
/*       */   public static boolean selectable(String label, ImBoolean pSelected, int imGuiSelectableFlags, float sizeX, float sizeY) {
/*  9553 */     return nSelectable(label, (pSelected != null) ? pSelected.getData() : null, imGuiSelectableFlags, sizeX, sizeY);
/*       */   }
/*       */   
/*       */   public static boolean selectable(String label, ImBoolean pSelected, ImVec2 size) {
/*  9557 */     return nSelectable(label, (pSelected != null) ? pSelected.getData() : null, size.x, size.y);
/*       */   }
/*       */   
/*       */   public static boolean selectable(String label, ImBoolean pSelected, float sizeX, float sizeY) {
/*  9561 */     return nSelectable(label, (pSelected != null) ? pSelected.getData() : null, sizeX, sizeY);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static boolean beginListBox(String label) {
/*  9613 */     return nBeginListBox(label);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static boolean beginListBox(String label, ImVec2 size) {
/*  9620 */     return nBeginListBox(label, size.x, size.y);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static boolean beginListBox(String label, float sizeX, float sizeY) {
/*  9627 */     return nBeginListBox(label, sizeX, sizeY);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static void endListBox() {
/*  9649 */     nEndListBox();
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static void listBox(String label, ImInt currentItem, String[] items) {
/*  9657 */     nListBox(label, (currentItem != null) ? currentItem.getData() : null, items, items.length);
/*       */   }
/*       */   
/*       */   public static void listBox(String label, ImInt currentItem, String[] items, int heightInItems) {
/*  9661 */     nListBox(label, (currentItem != null) ? currentItem.getData() : null, items, items.length, heightInItems);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static void plotLines(String label, float[] values, int valuesCount) {
/*  9704 */     nPlotLines(label, values, valuesCount);
/*       */   }
/*       */   
/*       */   public static void plotLines(String label, float[] values, int valuesCount, int valuesOffset) {
/*  9708 */     nPlotLines(label, values, valuesCount, valuesOffset);
/*       */   }
/*       */   
/*       */   public static void plotLines(String label, float[] values, int valuesCount, int valuesOffset, String overlayText) {
/*  9712 */     nPlotLines(label, values, valuesCount, valuesOffset, overlayText);
/*       */   }
/*       */   
/*       */   public static void plotLines(String label, float[] values, int valuesCount, int valuesOffset, String overlayText, float scaleMin) {
/*  9716 */     nPlotLines(label, values, valuesCount, valuesOffset, overlayText, scaleMin);
/*       */   }
/*       */   
/*       */   public static void plotLines(String label, float[] values, int valuesCount, int valuesOffset, String overlayText, float scaleMin, float scaleMax) {
/*  9720 */     nPlotLines(label, values, valuesCount, valuesOffset, overlayText, scaleMin, scaleMax);
/*       */   }
/*       */   
/*       */   public static void plotLines(String label, float[] values, int valuesCount, int valuesOffset, String overlayText, float scaleMin, float scaleMax, ImVec2 graphSize) {
/*  9724 */     nPlotLines(label, values, valuesCount, valuesOffset, overlayText, scaleMin, scaleMax, graphSize.x, graphSize.y);
/*       */   }
/*       */   
/*       */   public static void plotLines(String label, float[] values, int valuesCount, int valuesOffset, String overlayText, float scaleMin, float scaleMax, float graphSizeX, float graphSizeY) {
/*  9728 */     nPlotLines(label, values, valuesCount, valuesOffset, overlayText, scaleMin, scaleMax, graphSizeX, graphSizeY);
/*       */   }
/*       */   
/*       */   public static void plotLines(String label, float[] values, int valuesCount, int valuesOffset, String overlayText, float scaleMin, float scaleMax, ImVec2 graphSize, int stride) {
/*  9732 */     nPlotLines(label, values, valuesCount, valuesOffset, overlayText, scaleMin, scaleMax, graphSize.x, graphSize.y, stride);
/*       */   }
/*       */   
/*       */   public static void plotLines(String label, float[] values, int valuesCount, int valuesOffset, String overlayText, float scaleMin, float scaleMax, float graphSizeX, float graphSizeY, int stride) {
/*  9736 */     nPlotLines(label, values, valuesCount, valuesOffset, overlayText, scaleMin, scaleMax, graphSizeX, graphSizeY, stride);
/*       */   }
/*       */   
/*       */   public static void plotLines(String label, float[] values, int valuesCount, String overlayText, float scaleMin, float scaleMax, ImVec2 graphSize, int stride) {
/*  9740 */     nPlotLines(label, values, valuesCount, overlayText, scaleMin, scaleMax, graphSize.x, graphSize.y, stride);
/*       */   }
/*       */   
/*       */   public static void plotLines(String label, float[] values, int valuesCount, String overlayText, float scaleMin, float scaleMax, float graphSizeX, float graphSizeY, int stride) {
/*  9744 */     nPlotLines(label, values, valuesCount, overlayText, scaleMin, scaleMax, graphSizeX, graphSizeY, stride);
/*       */   }
/*       */   
/*       */   public static void plotLines(String label, float[] values, int valuesCount, float scaleMin, float scaleMax, ImVec2 graphSize, int stride) {
/*  9748 */     nPlotLines(label, values, valuesCount, scaleMin, scaleMax, graphSize.x, graphSize.y, stride);
/*       */   }
/*       */   
/*       */   public static void plotLines(String label, float[] values, int valuesCount, float scaleMin, float scaleMax, float graphSizeX, float graphSizeY, int stride) {
/*  9752 */     nPlotLines(label, values, valuesCount, scaleMin, scaleMax, graphSizeX, graphSizeY, stride);
/*       */   }
/*       */   
/*       */   public static void plotLines(String label, float[] values, int valuesCount, int valuesOffset, float scaleMin, float scaleMax, ImVec2 graphSize, int stride) {
/*  9756 */     nPlotLines(label, values, valuesCount, valuesOffset, scaleMin, scaleMax, graphSize.x, graphSize.y, stride);
/*       */   }
/*       */   
/*       */   public static void plotLines(String label, float[] values, int valuesCount, int valuesOffset, float scaleMin, float scaleMax, float graphSizeX, float graphSizeY, int stride) {
/*  9760 */     nPlotLines(label, values, valuesCount, valuesOffset, scaleMin, scaleMax, graphSizeX, graphSizeY, stride);
/*       */   }
/*       */   
/*       */   public static void plotLines(String label, float[] values, int valuesCount, int valuesOffset, String overlayText, float scaleMin, float scaleMax, int stride) {
/*  9764 */     nPlotLines(label, values, valuesCount, valuesOffset, overlayText, scaleMin, scaleMax, stride);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static void plotHistogram(String label, float[] values, int valuesCount) {
/*  9875 */     nPlotHistogram(label, values, valuesCount);
/*       */   }
/*       */   
/*       */   public static void plotHistogram(String label, float[] values, int valuesCount, int valuesOffset) {
/*  9879 */     nPlotHistogram(label, values, valuesCount, valuesOffset);
/*       */   }
/*       */   
/*       */   public static void plotHistogram(String label, float[] values, int valuesCount, int valuesOffset, String overlayText) {
/*  9883 */     nPlotHistogram(label, values, valuesCount, valuesOffset, overlayText);
/*       */   }
/*       */   
/*       */   public static void plotHistogram(String label, float[] values, int valuesCount, int valuesOffset, String overlayText, float scaleMin) {
/*  9887 */     nPlotHistogram(label, values, valuesCount, valuesOffset, overlayText, scaleMin);
/*       */   }
/*       */   
/*       */   public static void plotHistogram(String label, float[] values, int valuesCount, int valuesOffset, String overlayText, float scaleMin, float scaleMax) {
/*  9891 */     nPlotHistogram(label, values, valuesCount, valuesOffset, overlayText, scaleMin, scaleMax);
/*       */   }
/*       */   
/*       */   public static void plotHistogram(String label, float[] values, int valuesCount, int valuesOffset, String overlayText, float scaleMin, float scaleMax, ImVec2 graphSize) {
/*  9895 */     nPlotHistogram(label, values, valuesCount, valuesOffset, overlayText, scaleMin, scaleMax, graphSize.x, graphSize.y);
/*       */   }
/*       */   
/*       */   public static void plotHistogram(String label, float[] values, int valuesCount, int valuesOffset, String overlayText, float scaleMin, float scaleMax, float graphSizeX, float graphSizeY) {
/*  9899 */     nPlotHistogram(label, values, valuesCount, valuesOffset, overlayText, scaleMin, scaleMax, graphSizeX, graphSizeY);
/*       */   }
/*       */   
/*       */   public static void plotHistogram(String label, float[] values, int valuesCount, int valuesOffset, String overlayText, float scaleMin, float scaleMax, ImVec2 graphSize, int stride) {
/*  9903 */     nPlotHistogram(label, values, valuesCount, valuesOffset, overlayText, scaleMin, scaleMax, graphSize.x, graphSize.y, stride);
/*       */   }
/*       */   
/*       */   public static void plotHistogram(String label, float[] values, int valuesCount, int valuesOffset, String overlayText, float scaleMin, float scaleMax, float graphSizeX, float graphSizeY, int stride) {
/*  9907 */     nPlotHistogram(label, values, valuesCount, valuesOffset, overlayText, scaleMin, scaleMax, graphSizeX, graphSizeY, stride);
/*       */   }
/*       */   
/*       */   public static void plotHistogram(String label, float[] values, int valuesCount, String overlayText, float scaleMin, float scaleMax, ImVec2 graphSize, int stride) {
/*  9911 */     nPlotHistogram(label, values, valuesCount, overlayText, scaleMin, scaleMax, graphSize.x, graphSize.y, stride);
/*       */   }
/*       */   
/*       */   public static void plotHistogram(String label, float[] values, int valuesCount, String overlayText, float scaleMin, float scaleMax, float graphSizeX, float graphSizeY, int stride) {
/*  9915 */     nPlotHistogram(label, values, valuesCount, overlayText, scaleMin, scaleMax, graphSizeX, graphSizeY, stride);
/*       */   }
/*       */   
/*       */   public static void plotHistogram(String label, float[] values, int valuesCount, float scaleMin, float scaleMax, ImVec2 graphSize, int stride) {
/*  9919 */     nPlotHistogram(label, values, valuesCount, scaleMin, scaleMax, graphSize.x, graphSize.y, stride);
/*       */   }
/*       */   
/*       */   public static void plotHistogram(String label, float[] values, int valuesCount, float scaleMin, float scaleMax, float graphSizeX, float graphSizeY, int stride) {
/*  9923 */     nPlotHistogram(label, values, valuesCount, scaleMin, scaleMax, graphSizeX, graphSizeY, stride);
/*       */   }
/*       */   
/*       */   public static void plotHistogram(String label, float[] values, int valuesCount, int valuesOffset, float scaleMin, float scaleMax, ImVec2 graphSize, int stride) {
/*  9927 */     nPlotHistogram(label, values, valuesCount, valuesOffset, scaleMin, scaleMax, graphSize.x, graphSize.y, stride);
/*       */   }
/*       */   
/*       */   public static void plotHistogram(String label, float[] values, int valuesCount, int valuesOffset, float scaleMin, float scaleMax, float graphSizeX, float graphSizeY, int stride) {
/*  9931 */     nPlotHistogram(label, values, valuesCount, valuesOffset, scaleMin, scaleMax, graphSizeX, graphSizeY, stride);
/*       */   }
/*       */   
/*       */   public static void plotHistogram(String label, float[] values, int valuesCount, int valuesOffset, String overlayText, float scaleMin, float scaleMax, int stride) {
/*  9935 */     nPlotHistogram(label, values, valuesCount, valuesOffset, overlayText, scaleMin, scaleMax, stride);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static void value(String prefix, Number value) {
/* 10049 */     nValue(prefix, value.toString());
/*       */   }
/*       */   
/*       */   public static void value(String prefix, float value, String floatFormat) {
/* 10053 */     nValue(prefix, String.format(floatFormat, new Object[] { Float.valueOf(value) }));
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static boolean beginMenuBar() {
/* 10069 */     return nBeginMenuBar();
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static void endMenuBar() {
/* 10080 */     nEndMenuBar();
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static boolean beginMainMenuBar() {
/* 10091 */     return nBeginMainMenuBar();
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static void endMainMenuBar() {
/* 10102 */     nEndMainMenuBar();
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static boolean beginMenu(String label) {
/* 10113 */     return nBeginMenu(label);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static boolean beginMenu(String label, boolean enabled) {
/* 10120 */     return nBeginMenu(label, enabled);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static void endMenu() {
/* 10141 */     nEndMenu();
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static boolean menuItem(String label) {
/* 10152 */     return nMenuItem(label);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static boolean menuItem(String label, boolean selected) {
/* 10159 */     return nMenuItem(label, selected);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static boolean menuItem(String label, boolean selected, boolean enabled) {
/* 10166 */     return nMenuItem(label, selected, enabled);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static boolean menuItem(String label, String shortcut) {
/* 10194 */     return nMenuItem(label, shortcut);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static boolean menuItem(String label, String shortcut, boolean selected) {
/* 10201 */     return nMenuItem(label, shortcut, selected);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static boolean menuItem(String label, String shortcut, boolean selected, boolean enabled) {
/* 10208 */     return nMenuItem(label, shortcut, selected, enabled);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static boolean menuItem(String label, String shortcut, ImBoolean pSelected) {
/* 10242 */     return nMenuItem(label, shortcut, (pSelected != null) ? pSelected.getData() : null);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static boolean menuItem(String label, String shortcut, ImBoolean pSelected, boolean enabled) {
/* 10249 */     return nMenuItem(label, shortcut, (pSelected != null) ? pSelected.getData() : null, enabled);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static void beginTooltip() {
/* 10283 */     nBeginTooltip();
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static void endTooltip() {
/* 10294 */     nEndTooltip();
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static void setTooltip(String text) {
/* 10305 */     nSetTooltip(text);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static boolean beginItemTooltip() {
/* 10323 */     return nBeginItemTooltip();
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static void setItemTooltip(String text) {
/* 10334 */     nSetItemTooltip(text);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static boolean beginPopup(String strId) {
/* 10358 */     return nBeginPopup(strId);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static boolean beginPopup(String strId, int imGuiWindowFlags) {
/* 10365 */     return nBeginPopup(strId, imGuiWindowFlags);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static boolean beginPopupModal(String name) {
/* 10386 */     return nBeginPopupModal(name);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static boolean beginPopupModal(String name, ImBoolean pOpen) {
/* 10393 */     return nBeginPopupModal(name, (pOpen != null) ? pOpen.getData() : null);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static boolean beginPopupModal(String name, ImBoolean pOpen, int imGuiWindowFlags) {
/* 10400 */     return nBeginPopupModal(name, (pOpen != null) ? pOpen.getData() : null, imGuiWindowFlags);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static boolean beginPopupModal(String name, int imGuiWindowFlags) {
/* 10407 */     return nBeginPopupModal(name, imGuiWindowFlags);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static void endPopup() {
/* 10446 */     nEndPopup();
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static void openPopup(String strId) {
/* 10464 */     nOpenPopup(strId);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static void openPopup(String strId, int imGuiPopupFlags) {
/* 10471 */     nOpenPopup(strId, imGuiPopupFlags);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static void openPopup(int id) {
/* 10490 */     nOpenPopup(id);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static void openPopup(int id, int imGuiPopupFlags) {
/* 10497 */     nOpenPopup(id, imGuiPopupFlags);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static void openPopupOnItemClick() {
/* 10512 */     nOpenPopupOnItemClick();
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static void openPopupOnItemClick(String strId) {
/* 10519 */     nOpenPopupOnItemClick(strId);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static void openPopupOnItemClick(String strId, int imGuiPopupFlags) {
/* 10526 */     nOpenPopupOnItemClick(strId, imGuiPopupFlags);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static void openPopupOnItemClick(int imGuiPopupFlags) {
/* 10533 */     nOpenPopupOnItemClick(imGuiPopupFlags);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static void closeCurrentPopup() {
/* 10560 */     nCloseCurrentPopup();
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static boolean beginPopupContextItem() {
/* 10578 */     return nBeginPopupContextItem();
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static boolean beginPopupContextItem(String strId) {
/* 10586 */     return nBeginPopupContextItem(strId);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static boolean beginPopupContextItem(String strId, int imGuiPopupFlags) {
/* 10594 */     return nBeginPopupContextItem(strId, imGuiPopupFlags);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static boolean beginPopupContextItem(int imGuiPopupFlags) {
/* 10602 */     return nBeginPopupContextItem(imGuiPopupFlags);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static boolean beginPopupContextWindow() {
/* 10631 */     return nBeginPopupContextWindow();
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static boolean beginPopupContextWindow(String strId) {
/* 10638 */     return nBeginPopupContextWindow(strId);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static boolean beginPopupContextWindow(String strId, int imGuiPopupFlags) {
/* 10645 */     return nBeginPopupContextWindow(strId, imGuiPopupFlags);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static boolean beginPopupContextWindow(int imGuiPopupFlags) {
/* 10652 */     return nBeginPopupContextWindow(imGuiPopupFlags);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static boolean beginPopupContextVoid() {
/* 10681 */     return nBeginPopupContextVoid();
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static boolean beginPopupContextVoid(String strId) {
/* 10688 */     return nBeginPopupContextVoid(strId);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static boolean beginPopupContextVoid(String strId, int imGuiPopupFlags) {
/* 10695 */     return nBeginPopupContextVoid(strId, imGuiPopupFlags);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static boolean beginPopupContextVoid(int imGuiPopupFlags) {
/* 10702 */     return nBeginPopupContextVoid(imGuiPopupFlags);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static boolean isPopupOpen(String strId) {
/* 10736 */     return nIsPopupOpen(strId);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static boolean isPopupOpen(String strId, int imGuiPopupFlags) {
/* 10743 */     return nIsPopupOpen(strId, imGuiPopupFlags);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static boolean beginTable(String id, int columns) {
/* 10783 */     return nBeginTable(id, columns);
/*       */   }
/*       */   
/*       */   public static boolean beginTable(String id, int columns, int imGuiTableFlags) {
/* 10787 */     return nBeginTable(id, columns, imGuiTableFlags);
/*       */   }
/*       */   
/*       */   public static boolean beginTable(String id, int columns, int imGuiTableFlags, ImVec2 outerSize) {
/* 10791 */     return nBeginTable(id, columns, imGuiTableFlags, outerSize.x, outerSize.y);
/*       */   }
/*       */   
/*       */   public static boolean beginTable(String id, int columns, int imGuiTableFlags, float outerSizeX, float outerSizeY) {
/* 10795 */     return nBeginTable(id, columns, imGuiTableFlags, outerSizeX, outerSizeY);
/*       */   }
/*       */   
/*       */   public static boolean beginTable(String id, int columns, int imGuiTableFlags, ImVec2 outerSize, float innerWidth) {
/* 10799 */     return nBeginTable(id, columns, imGuiTableFlags, outerSize.x, outerSize.y, innerWidth);
/*       */   }
/*       */   
/*       */   public static boolean beginTable(String id, int columns, int imGuiTableFlags, float outerSizeX, float outerSizeY, float innerWidth) {
/* 10803 */     return nBeginTable(id, columns, imGuiTableFlags, outerSizeX, outerSizeY, innerWidth);
/*       */   }
/*       */   
/*       */   public static boolean beginTable(String id, int columns, ImVec2 outerSize, float innerWidth) {
/* 10807 */     return nBeginTable(id, columns, outerSize.x, outerSize.y, innerWidth);
/*       */   }
/*       */   
/*       */   public static boolean beginTable(String id, int columns, float outerSizeX, float outerSizeY, float innerWidth) {
/* 10811 */     return nBeginTable(id, columns, outerSizeX, outerSizeY, innerWidth);
/*       */   }
/*       */   
/*       */   public static boolean beginTable(String id, int columns, float innerWidth) {
/* 10815 */     return nBeginTable(id, columns, innerWidth);
/*       */   }
/*       */   
/*       */   public static boolean beginTable(String id, int columns, int imGuiTableFlags, float innerWidth) {
/* 10819 */     return nBeginTable(id, columns, imGuiTableFlags, innerWidth);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static void endTable() {
/* 10878 */     nEndTable();
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static void tableNextRow() {
/* 10889 */     nTableNextRow();
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static void tableNextRow(int imGuiTableRowFlags) {
/* 10896 */     nTableNextRow(imGuiTableRowFlags);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static void tableNextRow(int imGuiTableRowFlags, float minRowHeight) {
/* 10903 */     nTableNextRow(imGuiTableRowFlags, minRowHeight);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static void tableNextRow(float minRowHeight) {
/* 10910 */     nTableNextRow(minRowHeight);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static boolean tableNextColumn() {
/* 10933 */     return nTableNextColumn();
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static boolean tableSetColumnIndex(int columnN) {
/* 10944 */     return nTableSetColumnIndex(columnN);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static void tableSetupColumn(String label) {
/* 10961 */     nTableSetupColumn(label);
/*       */   }
/*       */   
/*       */   public static void tableSetupColumn(String label, int imGuiTableColumnFlags) {
/* 10965 */     nTableSetupColumn(label, imGuiTableColumnFlags);
/*       */   }
/*       */   
/*       */   public static void tableSetupColumn(String label, int imGuiTableColumnFlags, float initWidthOrWeight) {
/* 10969 */     nTableSetupColumn(label, imGuiTableColumnFlags, initWidthOrWeight);
/*       */   }
/*       */   
/*       */   public static void tableSetupColumn(String label, int imGuiTableColumnFlags, float initWidthOrWeight, int userId) {
/* 10973 */     nTableSetupColumn(label, imGuiTableColumnFlags, initWidthOrWeight, userId);
/*       */   }
/*       */   
/*       */   public static void tableSetupColumn(String label, float initWidthOrWeight, int userId) {
/* 10977 */     nTableSetupColumn(label, initWidthOrWeight, userId);
/*       */   }
/*       */   
/*       */   public static void tableSetupColumn(String label, int imGuiTableColumnFlags, int userId) {
/* 10981 */     nTableSetupColumn(label, imGuiTableColumnFlags, userId);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static void tableSetupScrollFreeze(int cols, int rows) {
/* 11024 */     nTableSetupScrollFreeze(cols, rows);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static void tableHeader(String label) {
/* 11035 */     nTableHeader(label);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static void tableHeadersRow() {
/* 11048 */     nTableHeadersRow();
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static void tableAngledHeadersRow() {
/* 11059 */     nTableAngledHeadersRow();
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static ImGuiTableSortSpecs tableGetSortSpecs() {
/* 11078 */     return new ImGuiTableSortSpecs(nTableGetSortSpecs());
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static int tableGetColumnCount() {
/* 11092 */     return nTableGetColumnCount();
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static int tableGetColumnIndex() {
/* 11103 */     return nTableGetColumnIndex();
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static int tableGetRowIndex() {
/* 11114 */     return nTableGetRowIndex();
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static String tableGetColumnName() {
/* 11125 */     return nTableGetColumnName();
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static String tableGetColumnName(int columnN) {
/* 11132 */     return nTableGetColumnName(columnN);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static int tableGetColumnFlags() {
/* 11147 */     return nTableGetColumnFlags();
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static int tableGetColumnFlags(int columnN) {
/* 11154 */     return nTableGetColumnFlags(columnN);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static void tableSetColumnEnabled(int columnN, boolean value) {
/* 11170 */     nTableSetColumnEnabled(columnN, value);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static int tableGetHoveredColumn() {
/* 11181 */     return nTableGetHoveredColumn();
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static void tableSetBgColor(int imGuiTableBgTarget, int color) {
/* 11192 */     nTableSetBgColor(imGuiTableBgTarget, color);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static void tableSetBgColor(int imGuiTableBgTarget, int color, int columnN) {
/* 11199 */     nTableSetBgColor(imGuiTableBgTarget, color, columnN);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static void columns() {
/* 11215 */     nColumns();
/*       */   }
/*       */   
/*       */   public static void columns(int count) {
/* 11219 */     nColumns(count);
/*       */   }
/*       */   
/*       */   public static void columns(int count, String id) {
/* 11223 */     nColumns(count, id);
/*       */   }
/*       */   
/*       */   public static void columns(int count, String id, boolean border) {
/* 11227 */     nColumns(count, id, border);
/*       */   }
/*       */   
/*       */   public static void columns(String id, boolean border) {
/* 11231 */     nColumns(id, border);
/*       */   }
/*       */   
/*       */   public static void columns(boolean border) {
/* 11235 */     nColumns(border);
/*       */   }
/*       */   
/*       */   public static void columns(int count, boolean border) {
/* 11239 */     nColumns(count, border);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static void nextColumn() {
/* 11280 */     nNextColumn();
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static int getColumnIndex() {
/* 11291 */     return nGetColumnIndex();
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static float getColumnWidth() {
/* 11302 */     return nGetColumnWidth();
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static float getColumnWidth(int columnIndex) {
/* 11309 */     return nGetColumnWidth(columnIndex);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static void setColumnWidth(int columnIndex, float width) {
/* 11324 */     nSetColumnWidth(columnIndex, width);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static float getColumnOffset() {
/* 11335 */     return nGetColumnOffset();
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static float getColumnOffset(int columnIndex) {
/* 11342 */     return nGetColumnOffset(columnIndex);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static void setColumnOffset(int columnIndex, float offsetX) {
/* 11357 */     nSetColumnOffset(columnIndex, offsetX);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static int getColumnsCount() {
/* 11365 */     return nGetColumnsCount();
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static boolean beginTabBar(String strId) {
/* 11379 */     return nBeginTabBar(strId);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static boolean beginTabBar(String strId, int imGuiTabBarFlags) {
/* 11386 */     return nBeginTabBar(strId, imGuiTabBarFlags);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static void endTabBar() {
/* 11407 */     nEndTabBar();
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static boolean beginTabItem(String label) {
/* 11418 */     return nBeginTabItem(label);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static boolean beginTabItem(String label, ImBoolean pOpen) {
/* 11425 */     return nBeginTabItem(label, (pOpen != null) ? pOpen.getData() : null);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static boolean beginTabItem(String label, ImBoolean pOpen, int imGuiTabItemFlags) {
/* 11432 */     return nBeginTabItem(label, (pOpen != null) ? pOpen.getData() : null, imGuiTabItemFlags);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static boolean beginTabItem(String label, int imGuiTabItemFlags) {
/* 11439 */     return nBeginTabItem(label, imGuiTabItemFlags);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static void endTabItem() {
/* 11478 */     nEndTabItem();
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static boolean tabItemButton(String label) {
/* 11489 */     return nTabItemButton(label);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static boolean tabItemButton(String label, int imGuiTabItemFlags) {
/* 11496 */     return nTabItemButton(label, imGuiTabItemFlags);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static void setTabItemClosed(String tabOrDockedWindowLabel) {
/* 11518 */     nSetTabItemClosed(tabOrDockedWindowLabel);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static int dockSpace(int dockspaceId) {
/* 11542 */     return nDockSpace(dockspaceId);
/*       */   }
/*       */   
/*       */   public static int dockSpace(int dockspaceId, ImVec2 size) {
/* 11546 */     return nDockSpace(dockspaceId, size.x, size.y);
/*       */   }
/*       */   
/*       */   public static int dockSpace(int dockspaceId, float sizeX, float sizeY) {
/* 11550 */     return nDockSpace(dockspaceId, sizeX, sizeY);
/*       */   }
/*       */   
/*       */   public static int dockSpace(int dockspaceId, ImVec2 size, int imGuiDockNodeFlags) {
/* 11554 */     return nDockSpace(dockspaceId, size.x, size.y, imGuiDockNodeFlags);
/*       */   }
/*       */   
/*       */   public static int dockSpace(int dockspaceId, float sizeX, float sizeY, int imGuiDockNodeFlags) {
/* 11558 */     return nDockSpace(dockspaceId, sizeX, sizeY, imGuiDockNodeFlags);
/*       */   }
/*       */   
/*       */   public static int dockSpace(int dockspaceId, ImVec2 size, int imGuiDockNodeFlags, ImGuiWindowClass windowClass) {
/* 11562 */     return nDockSpace(dockspaceId, size.x, size.y, imGuiDockNodeFlags, windowClass.ptr);
/*       */   }
/*       */   
/*       */   public static int dockSpace(int dockspaceId, float sizeX, float sizeY, int imGuiDockNodeFlags, ImGuiWindowClass windowClass) {
/* 11566 */     return nDockSpace(dockspaceId, sizeX, sizeY, imGuiDockNodeFlags, windowClass.ptr);
/*       */   }
/*       */   
/*       */   public static int dockSpace(int dockspaceId, int imGuiDockNodeFlags, ImGuiWindowClass windowClass) {
/* 11570 */     return nDockSpace(dockspaceId, imGuiDockNodeFlags, windowClass.ptr);
/*       */   }
/*       */   
/*       */   public static int dockSpace(int dockspaceId, ImGuiWindowClass windowClass) {
/* 11574 */     return nDockSpace(dockspaceId, windowClass.ptr);
/*       */   }
/*       */   
/*       */   public static int dockSpace(int dockspaceId, ImVec2 size, ImGuiWindowClass windowClass) {
/* 11578 */     return nDockSpace(dockspaceId, size.x, size.y, windowClass.ptr);
/*       */   }
/*       */   
/*       */   public static int dockSpace(int dockspaceId, float sizeX, float sizeY, ImGuiWindowClass windowClass) {
/* 11582 */     return nDockSpace(dockspaceId, sizeX, sizeY, windowClass.ptr);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static int dockSpaceOverViewport() {
/* 11622 */     return nDockSpaceOverViewport();
/*       */   }
/*       */   
/*       */   public static int dockSpaceOverViewport(int dockspaceId) {
/* 11626 */     return nDockSpaceOverViewport(dockspaceId);
/*       */   }
/*       */   
/*       */   public static int dockSpaceOverViewport(int dockspaceId, ImGuiViewport viewport) {
/* 11630 */     return nDockSpaceOverViewport(dockspaceId, viewport.ptr);
/*       */   }
/*       */   
/*       */   public static int dockSpaceOverViewport(int dockspaceId, ImGuiViewport viewport, int imGuiDockNodeFlags) {
/* 11634 */     return nDockSpaceOverViewport(dockspaceId, viewport.ptr, imGuiDockNodeFlags);
/*       */   }
/*       */   
/*       */   public static int dockSpaceOverViewport(int dockspaceId, ImGuiViewport viewport, int imGuiDockNodeFlags, ImGuiWindowClass windowClass) {
/* 11638 */     return nDockSpaceOverViewport(dockspaceId, viewport.ptr, imGuiDockNodeFlags, windowClass.ptr);
/*       */   }
/*       */   
/*       */   public static int dockSpaceOverViewport(ImGuiViewport viewport, int imGuiDockNodeFlags, ImGuiWindowClass windowClass) {
/* 11642 */     return nDockSpaceOverViewport(viewport.ptr, imGuiDockNodeFlags, windowClass.ptr);
/*       */   }
/*       */   
/*       */   public static int dockSpaceOverViewport(int dockspaceId, ImGuiViewport viewport, ImGuiWindowClass windowClass) {
/* 11646 */     return nDockSpaceOverViewport(dockspaceId, viewport.ptr, windowClass.ptr);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static void setNextWindowDockID(int dockId) {
/* 11681 */     nSetNextWindowDockID(dockId);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static void setNextWindowDockID(int dockId, int imGuiCond) {
/* 11688 */     nSetNextWindowDockID(dockId, imGuiCond);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static void setNextWindowClass(ImGuiWindowClass windowClass) {
/* 11703 */     nSetNextWindowClass(windowClass.ptr);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static int getWindowDockID() {
/* 11711 */     return nGetWindowDockID();
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static boolean isWindowDocked() {
/* 11722 */     return nIsWindowDocked();
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static void logToTTY() {
/* 11736 */     nLogToTTY();
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static void logToTTY(int autoOpenDepth) {
/* 11743 */     nLogToTTY(autoOpenDepth);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static void logToFile() {
/* 11758 */     nLogToFile();
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static void logToFile(int autoOpenDepth) {
/* 11765 */     nLogToFile(autoOpenDepth);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static void logToFile(int autoOpenDepth, String filename) {
/* 11772 */     nLogToFile(autoOpenDepth, filename);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static void logToFile(String filename) {
/* 11779 */     nLogToFile(filename);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static void logToClipboard() {
/* 11806 */     nLogToClipboard();
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static void logToClipboard(int autoOpenDepth) {
/* 11813 */     nLogToClipboard(autoOpenDepth);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static void logFinish() {
/* 11828 */     nLogFinish();
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static void logButtons() {
/* 11839 */     nLogButtons();
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static void logText(String text) {
/* 11850 */     nLogText(text);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static boolean beginDragDropSource() {
/* 11866 */     return nBeginDragDropSource();
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static boolean beginDragDropSource(int imGuiDragDropFlags) {
/* 11873 */     return nBeginDragDropSource(imGuiDragDropFlags);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/* 11884 */   private static WeakReference<Object> payloadRef = null;
/* 11885 */   private static final byte[] PAYLOAD_PLACEHOLDER_DATA = new byte[1];
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static boolean setDragDropPayload(String dataType, Object payload) {
/* 11895 */     return setDragDropPayload(dataType, payload, 0);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static boolean setDragDropPayload(String dataType, Object payload, int imGuiCond) {
/* 11906 */     if (payloadRef == null || payloadRef.get() != payload) {
/* 11907 */       payloadRef = new WeakReference(payload);
/*       */     }
/* 11909 */     return nSetDragDropPayload(dataType, PAYLOAD_PLACEHOLDER_DATA, 1, imGuiCond);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static boolean setDragDropPayload(Object payload) {
/* 11916 */     return setDragDropPayload(payload, 0);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static boolean setDragDropPayload(Object payload, int imGuiCond) {
/* 11923 */     return setDragDropPayload(String.valueOf(payload.getClass().hashCode()), payload, imGuiCond);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static void endDragDropSource() {
/* 11934 */     nEndDragDropSource();
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static boolean beginDragDropTarget() {
/* 11945 */     return nBeginDragDropTarget();
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static <T> T acceptDragDropPayload(String dataType) {
/* 11956 */     return acceptDragDropPayload(dataType, 0);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static <T> T acceptDragDropPayload(String dataType, Class<T> aClass) {
/* 11963 */     return acceptDragDropPayload(dataType, 0, aClass);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static <T> T acceptDragDropPayload(String dataType, int imGuiDragDropFlags) {
/* 11970 */     return acceptDragDropPayload(dataType, imGuiDragDropFlags, null);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static <T> T acceptDragDropPayload(String dataType, int imGuiDragDropFlags, Class<T> aClass) {
/* 11978 */     if (payloadRef != null && nAcceptDragDropPayload(dataType, imGuiDragDropFlags)) {
/* 11979 */       Object rawPayload = payloadRef.get();
/* 11980 */       if (rawPayload != null && (
/* 11981 */         aClass == null || rawPayload.getClass().isAssignableFrom(aClass))) {
/* 11982 */         return (T)rawPayload;
/*       */       }
/*       */     } 
/*       */     
/* 11986 */     return null;
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static <T> T acceptDragDropPayload(Class<T> aClass) {
/* 11993 */     return acceptDragDropPayload(String.valueOf(aClass.hashCode()), 0, aClass);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static <T> T acceptDragDropPayload(Class<T> aClass, int imGuiDragDropFlags) {
/* 12000 */     return acceptDragDropPayload(String.valueOf(aClass.hashCode()), imGuiDragDropFlags, aClass);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static void endDragDropTarget() {
/* 12011 */     nEndDragDropTarget();
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static <T> T getDragDropPayload() {
/* 12023 */     if (payloadRef != null && nHasDragDropPayload()) {
/* 12024 */       Object rawPayload = payloadRef.get();
/* 12025 */       if (rawPayload != null) {
/* 12026 */         return (T)rawPayload;
/*       */       }
/*       */     } 
/* 12029 */     return null;
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static <T> T getDragDropPayload(String dataType) {
/* 12037 */     if (payloadRef != null && nHasDragDropPayload(dataType)) {
/* 12038 */       Object rawPayload = payloadRef.get();
/* 12039 */       if (rawPayload != null) {
/* 12040 */         return (T)rawPayload;
/*       */       }
/*       */     } 
/* 12043 */     return null;
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static <T> T getDragDropPayload(Class<T> aClass) {
/* 12050 */     return getDragDropPayload(String.valueOf(aClass.hashCode()));
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static void beginDisabled() {
/* 12075 */     nBeginDisabled();
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static void beginDisabled(boolean disabled) {
/* 12084 */     nBeginDisabled(disabled);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static void endDisabled() {
/* 12096 */     nEndDisabled();
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static void pushClipRect(ImVec2 clipRectMin, ImVec2 clipRectMax, boolean intersectWithCurrentClipRect) {
/* 12107 */     nPushClipRect(clipRectMin.x, clipRectMin.y, clipRectMax.x, clipRectMax.y, intersectWithCurrentClipRect);
/*       */   }
/*       */   
/*       */   public static void pushClipRect(float clipRectMinX, float clipRectMinY, float clipRectMaxX, float clipRectMaxY, boolean intersectWithCurrentClipRect) {
/* 12111 */     nPushClipRect(clipRectMinX, clipRectMinY, clipRectMaxX, clipRectMaxY, intersectWithCurrentClipRect);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static void popClipRect() {
/* 12121 */     nPopClipRect();
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static void setItemDefaultFocus() {
/* 12135 */     nSetItemDefaultFocus();
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static void setKeyboardFocusHere() {
/* 12146 */     nSetKeyboardFocusHere();
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static void setKeyboardFocusHere(int offset) {
/* 12153 */     nSetKeyboardFocusHere(offset);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static void setNextItemAllowOverlap() {
/* 12172 */     nSetNextItemAllowOverlap();
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static boolean isItemHovered() {
/* 12187 */     return nIsItemHovered();
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static boolean isItemHovered(int imGuiHoveredFlags) {
/* 12194 */     return nIsItemHovered(imGuiHoveredFlags);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static boolean isItemActive() {
/* 12211 */     return nIsItemActive();
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static boolean isItemFocused() {
/* 12222 */     return nIsItemFocused();
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static boolean isItemClicked() {
/* 12234 */     return nIsItemClicked();
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static boolean isItemClicked(int mouseButton) {
/* 12242 */     return nIsItemClicked(mouseButton);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static boolean isItemVisible() {
/* 12257 */     return nIsItemVisible();
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static boolean isItemEdited() {
/* 12268 */     return nIsItemEdited();
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static boolean isItemActivated() {
/* 12279 */     return nIsItemActivated();
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static boolean isItemDeactivated() {
/* 12290 */     return nIsItemDeactivated();
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static boolean isItemDeactivatedAfterEdit() {
/* 12303 */     return nIsItemDeactivatedAfterEdit();
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static boolean isItemToggledOpen() {
/* 12314 */     return nIsItemToggledOpen();
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static boolean isAnyItemHovered() {
/* 12325 */     return nIsAnyItemHovered();
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static boolean isAnyItemActive() {
/* 12336 */     return nIsAnyItemActive();
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static boolean isAnyItemFocused() {
/* 12346 */     return nIsAnyItemFocused();
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static int getItemID() {
/* 12357 */     return nGetItemID();
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static ImVec2 getItemRectMin() {
/* 12368 */     ImVec2 dst = new ImVec2();
/* 12369 */     nGetItemRectMin(dst);
/* 12370 */     return dst;
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static float getItemRectMinX() {
/* 12377 */     return nGetItemRectMinX();
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static float getItemRectMinY() {
/* 12384 */     return nGetItemRectMinY();
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static void getItemRectMin(ImVec2 dst) {
/* 12391 */     nGetItemRectMin(dst);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static ImVec2 getItemRectMax() {
/* 12410 */     ImVec2 dst = new ImVec2();
/* 12411 */     nGetItemRectMax(dst);
/* 12412 */     return dst;
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static float getItemRectMaxX() {
/* 12419 */     return nGetItemRectMaxX();
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static float getItemRectMaxY() {
/* 12426 */     return nGetItemRectMaxY();
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static void getItemRectMax(ImVec2 dst) {
/* 12433 */     nGetItemRectMax(dst);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static ImVec2 getItemRectSize() {
/* 12452 */     ImVec2 dst = new ImVec2();
/* 12453 */     nGetItemRectSize(dst);
/* 12454 */     return dst;
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static float getItemRectSizeX() {
/* 12461 */     return nGetItemRectSizeX();
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static float getItemRectSizeY() {
/* 12468 */     return nGetItemRectSizeY();
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static void getItemRectSize(ImVec2 dst) {
/* 12475 */     nGetItemRectSize(dst);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/* 12495 */   private static final ImGuiViewport _GETMAINVIEWPORT_1 = new ImGuiViewport(0L);
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static ImGuiViewport getMainViewport() {
/* 12501 */     _GETMAINVIEWPORT_1.ptr = nGetMainViewport();
/* 12502 */     return _GETMAINVIEWPORT_1;
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static ImDrawList getBackgroundDrawList() {
/* 12516 */     return new ImDrawList(nGetBackgroundDrawList());
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static ImDrawList getBackgroundDrawList(ImGuiViewport viewport) {
/* 12524 */     return new ImDrawList(nGetBackgroundDrawList(viewport.ptr));
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static ImDrawList getForegroundDrawList() {
/* 12540 */     return new ImDrawList(nGetForegroundDrawList());
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static ImDrawList getForegroundDrawList(ImGuiViewport viewport) {
/* 12548 */     return new ImDrawList(nGetForegroundDrawList(viewport.ptr));
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static boolean isRectVisible(ImVec2 size) {
/* 12565 */     return nIsRectVisible(size.x, size.y);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static boolean isRectVisible(float sizeX, float sizeY) {
/* 12572 */     return nIsRectVisible(sizeX, sizeY);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static boolean isRectVisible(ImVec2 rectMin, ImVec2 rectMax) {
/* 12585 */     return nIsRectVisible(rectMin.x, rectMin.y, rectMax.x, rectMax.y);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static boolean isRectVisible(float rectMinX, float rectMinY, float rectMaxX, float rectMaxY) {
/* 12592 */     return nIsRectVisible(rectMinX, rectMinY, rectMaxX, rectMaxY);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static double getTime() {
/* 12606 */     return nGetTime();
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static int getFrameCount() {
/* 12617 */     return nGetFrameCount();
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static String getStyleColorName(int imGuiColIdx) {
/* 12632 */     return nGetStyleColorName(imGuiColIdx);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static void setStateStorage(ImGuiStorage storage) {
/* 12643 */     nSetStateStorage(storage.ptr);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static ImGuiStorage getStateStorage() {
/* 12651 */     return new ImGuiStorage(nGetStateStorage());
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static ImVec2 calcTextSize(String text) {
/* 12661 */     ImVec2 dst = new ImVec2();
/* 12662 */     nCalcTextSize(dst, text);
/* 12663 */     return dst;
/*       */   }
/*       */   
/*       */   public static float calcTextSizeX(String text) {
/* 12667 */     return nCalcTextSizeX(text);
/*       */   }
/*       */   
/*       */   public static float calcTextSizeY(String text) {
/* 12671 */     return nCalcTextSizeY(text);
/*       */   }
/*       */   
/*       */   public static void calcTextSize(ImVec2 dst, String text) {
/* 12675 */     nCalcTextSize(dst, text);
/*       */   }
/*       */   
/*       */   public static ImVec2 calcTextSize(String text, boolean hideTextAfterDoubleHash) {
/* 12679 */     ImVec2 dst = new ImVec2();
/* 12680 */     nCalcTextSize(dst, text, hideTextAfterDoubleHash);
/* 12681 */     return dst;
/*       */   }
/*       */   
/*       */   public static float calcTextSizeX(String text, boolean hideTextAfterDoubleHash) {
/* 12685 */     return nCalcTextSizeX(text, hideTextAfterDoubleHash);
/*       */   }
/*       */   
/*       */   public static float calcTextSizeY(String text, boolean hideTextAfterDoubleHash) {
/* 12689 */     return nCalcTextSizeY(text, hideTextAfterDoubleHash);
/*       */   }
/*       */   
/*       */   public static void calcTextSize(ImVec2 dst, String text, boolean hideTextAfterDoubleHash) {
/* 12693 */     nCalcTextSize(dst, text, hideTextAfterDoubleHash);
/*       */   }
/*       */   
/*       */   public static ImVec2 calcTextSize(String text, boolean hideTextAfterDoubleHash, float wrapWidth) {
/* 12697 */     ImVec2 dst = new ImVec2();
/* 12698 */     nCalcTextSize(dst, text, hideTextAfterDoubleHash, wrapWidth);
/* 12699 */     return dst;
/*       */   }
/*       */   
/*       */   public static float calcTextSizeX(String text, boolean hideTextAfterDoubleHash, float wrapWidth) {
/* 12703 */     return nCalcTextSizeX(text, hideTextAfterDoubleHash, wrapWidth);
/*       */   }
/*       */   
/*       */   public static float calcTextSizeY(String text, boolean hideTextAfterDoubleHash, float wrapWidth) {
/* 12707 */     return nCalcTextSizeY(text, hideTextAfterDoubleHash, wrapWidth);
/*       */   }
/*       */   
/*       */   public static void calcTextSize(ImVec2 dst, String text, boolean hideTextAfterDoubleHash, float wrapWidth) {
/* 12711 */     nCalcTextSize(dst, text, hideTextAfterDoubleHash, wrapWidth);
/*       */   }
/*       */   
/*       */   public static ImVec2 calcTextSize(String text, float wrapWidth) {
/* 12715 */     ImVec2 dst = new ImVec2();
/* 12716 */     nCalcTextSize(dst, text, wrapWidth);
/* 12717 */     return dst;
/*       */   }
/*       */   
/*       */   public static float calcTextSizeX(String text, float wrapWidth) {
/* 12721 */     return nCalcTextSizeX(text, wrapWidth);
/*       */   }
/*       */   
/*       */   public static float calcTextSizeY(String text, float wrapWidth) {
/* 12725 */     return nCalcTextSizeY(text, wrapWidth);
/*       */   }
/*       */   
/*       */   public static void calcTextSize(ImVec2 dst, String text, float wrapWidth) {
/* 12729 */     nCalcTextSize(dst, text, wrapWidth);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static ImVec4 colorConvertU32ToFloat4(int in) {
/* 12815 */     ImVec4 dst = new ImVec4();
/* 12816 */     nColorConvertU32ToFloat4(dst, in);
/* 12817 */     return dst;
/*       */   }
/*       */   
/*       */   public static float colorConvertU32ToFloat4X(int in) {
/* 12821 */     return nColorConvertU32ToFloat4X(in);
/*       */   }
/*       */   
/*       */   public static float colorConvertU32ToFloat4Y(int in) {
/* 12825 */     return nColorConvertU32ToFloat4Y(in);
/*       */   }
/*       */   
/*       */   public static float colorConvertU32ToFloat4Z(int in) {
/* 12829 */     return nColorConvertU32ToFloat4Z(in);
/*       */   }
/*       */   
/*       */   public static float colorConvertU32ToFloat4W(int in) {
/* 12833 */     return nColorConvertU32ToFloat4W(in);
/*       */   }
/*       */   
/*       */   public static void colorConvertU32ToFloat4(ImVec4 dst, int in) {
/* 12837 */     nColorConvertU32ToFloat4(dst, in);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static int colorConvertFloat4ToU32(ImVec4 in) {
/* 12861 */     return nColorConvertFloat4ToU32(in.x, in.y, in.z, in.w);
/*       */   }
/*       */   
/*       */   public static int colorConvertFloat4ToU32(float inX, float inY, float inZ, float inW) {
/* 12865 */     return nColorConvertFloat4ToU32(inX, inY, inZ, inW);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static void colorConvertRGBtoHSV(float[] rgb, float[] hsv) {
/* 12875 */     nColorConvertRGBtoHSV(rgb, hsv);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static void colorConvertHSVtoRGB(float[] hsv, float[] rgb) {
/* 12883 */     nColorConvertHSVtoRGB(hsv, rgb);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static boolean isKeyDown(int key) {
/* 12900 */     return nIsKeyDown(key);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static boolean isKeyPressed(int key) {
/* 12911 */     return nIsKeyPressed(key);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static boolean isKeyPressed(int key, boolean repeat) {
/* 12918 */     return nIsKeyPressed(key, repeat);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static boolean isKeyReleased(int key) {
/* 12933 */     return nIsKeyReleased(key);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static boolean isKeyChordPressed(int keyChord) {
/* 12945 */     return nIsKeyChordPressed(keyChord);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static boolean getKeyPressedAmount(int key, float repeatDelay, float rate) {
/* 12957 */     return nGetKeyPressedAmount(key, repeatDelay, rate);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static String getKeyName(int key) {
/* 12968 */     return nGetKeyName(key);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static void setNextFrameWantCaptureKeyboard(boolean wantCaptureKeyboard) {
/* 12981 */     nSetNextFrameWantCaptureKeyboard(wantCaptureKeyboard);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static boolean shortcut(int keyChord) {
/* 13005 */     return nShortcut(keyChord);
/*       */   }
/*       */   
/*       */   public static boolean shortcut(int keyChord, int flags) {
/* 13009 */     return nShortcut(keyChord, flags);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static void setNextItemShortcut(int keyChord) {
/* 13021 */     nSetNextItemShortcut(keyChord);
/*       */   }
/*       */   
/*       */   public static void setNextItemShortcut(int keyChord, int flags) {
/* 13025 */     nSetNextItemShortcut(keyChord, flags);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static boolean isMouseDown(int button) {
/* 13045 */     return nIsMouseDown(button);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static boolean isMouseClicked(int button) {
/* 13056 */     return nIsMouseClicked(button);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static boolean isMouseClicked(int button, boolean repeat) {
/* 13063 */     return nIsMouseClicked(button, repeat);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static boolean isMouseReleased(int button) {
/* 13078 */     return nIsMouseReleased(button);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static boolean isMouseDoubleClicked(int button) {
/* 13089 */     return nIsMouseDoubleClicked(button);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static int getMouseClickedCount(int button) {
/* 13100 */     return nGetMouseClickedCount(button);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static boolean isMouseHoveringRect(ImVec2 rMin, ImVec2 rMax) {
/* 13111 */     return nIsMouseHoveringRect(rMin.x, rMin.y, rMax.x, rMax.y);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static boolean isMouseHoveringRect(float rMinX, float rMinY, float rMaxX, float rMaxY) {
/* 13118 */     return nIsMouseHoveringRect(rMinX, rMinY, rMaxX, rMaxY);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static boolean isMouseHoveringRect(ImVec2 rMin, ImVec2 rMax, boolean clip) {
/* 13125 */     return nIsMouseHoveringRect(rMin.x, rMin.y, rMax.x, rMax.y, clip);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static boolean isMouseHoveringRect(float rMinX, float rMinY, float rMaxX, float rMaxY, boolean clip) {
/* 13132 */     return nIsMouseHoveringRect(rMinX, rMinY, rMaxX, rMaxY, clip);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static boolean isMousePosValid() {
/* 13153 */     return nIsMousePosValid();
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static boolean isMousePosValid(ImVec2 mousePos) {
/* 13160 */     return nIsMousePosValid(mousePos.x, mousePos.y);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static boolean isMousePosValid(float mousePosX, float mousePosY) {
/* 13167 */     return nIsMousePosValid(mousePosX, mousePosY);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static boolean isAnyMouseDown() {
/* 13184 */     return nIsAnyMouseDown();
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static ImVec2 getMousePos() {
/* 13195 */     ImVec2 dst = new ImVec2();
/* 13196 */     nGetMousePos(dst);
/* 13197 */     return dst;
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static float getMousePosX() {
/* 13204 */     return nGetMousePosX();
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static float getMousePosY() {
/* 13211 */     return nGetMousePosY();
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static void getMousePos(ImVec2 dst) {
/* 13218 */     nGetMousePos(dst);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static ImVec2 getMousePosOnOpeningCurrentPopup() {
/* 13237 */     ImVec2 dst = new ImVec2();
/* 13238 */     nGetMousePosOnOpeningCurrentPopup(dst);
/* 13239 */     return dst;
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static float getMousePosOnOpeningCurrentPopupX() {
/* 13246 */     return nGetMousePosOnOpeningCurrentPopupX();
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static float getMousePosOnOpeningCurrentPopupY() {
/* 13253 */     return nGetMousePosOnOpeningCurrentPopupY();
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static void getMousePosOnOpeningCurrentPopup(ImVec2 dst) {
/* 13260 */     nGetMousePosOnOpeningCurrentPopup(dst);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static boolean isMouseDragging(int button) {
/* 13279 */     return nIsMouseDragging(button);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static boolean isMouseDragging(int button, float lockThreshold) {
/* 13286 */     return nIsMouseDragging(button, lockThreshold);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static ImVec2 getMouseDragDelta() {
/* 13302 */     ImVec2 dst = new ImVec2();
/* 13303 */     nGetMouseDragDelta(dst);
/* 13304 */     return dst;
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static float getMouseDragDeltaX() {
/* 13312 */     return nGetMouseDragDeltaX();
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static float getMouseDragDeltaY() {
/* 13320 */     return nGetMouseDragDeltaY();
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static void getMouseDragDelta(ImVec2 dst) {
/* 13328 */     nGetMouseDragDelta(dst);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static ImVec2 getMouseDragDelta(int button) {
/* 13336 */     ImVec2 dst = new ImVec2();
/* 13337 */     nGetMouseDragDelta(dst, button);
/* 13338 */     return dst;
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static float getMouseDragDeltaX(int button) {
/* 13346 */     return nGetMouseDragDeltaX(button);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static float getMouseDragDeltaY(int button) {
/* 13354 */     return nGetMouseDragDeltaY(button);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static void getMouseDragDelta(ImVec2 dst, int button) {
/* 13362 */     nGetMouseDragDelta(dst, button);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static ImVec2 getMouseDragDelta(int button, float lockThreshold) {
/* 13370 */     ImVec2 dst = new ImVec2();
/* 13371 */     nGetMouseDragDelta(dst, button, lockThreshold);
/* 13372 */     return dst;
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static float getMouseDragDeltaX(int button, float lockThreshold) {
/* 13380 */     return nGetMouseDragDeltaX(button, lockThreshold);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static float getMouseDragDeltaY(int button, float lockThreshold) {
/* 13388 */     return nGetMouseDragDeltaY(button, lockThreshold);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static void getMouseDragDelta(ImVec2 dst, int button, float lockThreshold) {
/* 13396 */     nGetMouseDragDelta(dst, button, lockThreshold);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static void resetMouseDragDelta() {
/* 13436 */     nResetMouseDragDelta();
/*       */   }
/*       */   
/*       */   public static void resetMouseDragDelta(int button) {
/* 13440 */     nResetMouseDragDelta(button);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static int getMouseCursor() {
/* 13456 */     return nGetMouseCursor();
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static void setMouseCursor(int type) {
/* 13467 */     nSetMouseCursor(type);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static void setNextFrameWantCaptureMouse(boolean wantCaptureMouse) {
/* 13480 */     nSetNextFrameWantCaptureMouse(wantCaptureMouse);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static String getClipboardText() {
/* 13491 */     return nGetClipboardText();
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static void setClipboardText(String text) {
/* 13499 */     nSetClipboardText(text);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static void loadIniSettingsFromDisk(String iniFilename) {
/* 13516 */     nLoadIniSettingsFromDisk(iniFilename);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static void loadIniSettingsFromMemory(String iniData) {
/* 13529 */     nLoadIniSettingsFromMemory(iniData);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static void loadIniSettingsFromMemory(String iniData, int iniSize) {
/* 13536 */     nLoadIniSettingsFromMemory(iniData, iniSize);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static void saveIniSettingsToDisk(String iniFilename) {
/* 13555 */     nSaveIniSettingsToDisk(iniFilename);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static String saveIniSettingsToMemory() {
/* 13569 */     return nSaveIniSettingsToMemory();
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static String saveIniSettingsToMemory(long outIniSize) {
/* 13577 */     return nSaveIniSettingsToMemory(outIniSize);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static void debugTextEncoding(String text) {
/* 13592 */     nDebugTextEncoding(text);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static void debugFlashStyleColor(int idx) {
/* 13602 */     nDebugFlashStyleColor(idx);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static void debugStartItemPicker() {
/* 13610 */     nDebugStartItemPicker();
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static boolean debugCheckVersionAndDataLayout(String versionStr, int szIo, int szStyle, int szVec2, int szVec4, int szDrawVert, int szDrawIdx) {
/* 13618 */     return nDebugCheckVersionAndDataLayout(versionStr, szIo, szStyle, szVec2, szVec4, szDrawVert, szDrawIdx);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/* 13632 */   private static final ImGuiPlatformIO _GETPLATFORMIO_1 = new ImGuiPlatformIO(0L);
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static ImGuiPlatformIO getPlatformIO() {
/* 13638 */     _GETPLATFORMIO_1.ptr = nGetPlatformIO();
/* 13639 */     return _GETPLATFORMIO_1;
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static void updatePlatformWindows() {
/* 13650 */     nUpdatePlatformWindows();
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static void renderPlatformWindowsDefault() {
/* 13662 */     nRenderPlatformWindowsDefault();
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static void destroyPlatformWindows() {
/* 13675 */     nDestroyPlatformWindows();
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static ImGuiViewport findViewportByID(int imGuiID) {
/* 13686 */     return new ImGuiViewport(nFindViewportByID(imGuiID));
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static ImGuiViewport findViewportByPlatformHandle(long platformHandle) {
/* 13697 */     return new ImGuiViewport(nFindViewportByPlatformHandle(platformHandle));
/*       */   }
/*       */   
/*       */   private static native void nInitJni();
/*       */   
/*       */   public static native void setAssertCallback(ImAssertCallback paramImAssertCallback);
/*       */   
/*       */   private static native long nCreateContext();
/*       */   
/*       */   private static native long nCreateContext(long paramLong);
/*       */   
/*       */   private static native void nDestroyContext();
/*       */   
/*       */   private static native void nDestroyContext(long paramLong);
/*       */   
/*       */   private static native long nGetCurrentContext();
/*       */   
/*       */   private static native void nSetCurrentContext(long paramLong);
/*       */   
/*       */   private static native long nGetIO();
/*       */   
/*       */   private static native long nGetStyle();
/*       */   
/*       */   private static native void nNewFrame();
/*       */   
/*       */   private static native void nEndFrame();
/*       */   
/*       */   private static native void nRender();
/*       */   
/*       */   private static native long nGetDrawData();
/*       */   
/*       */   private static native void nShowDemoWindow();
/*       */   
/*       */   private static native void nShowDemoWindow(boolean[] paramArrayOfboolean);
/*       */   
/*       */   private static native void nShowMetricsWindow();
/*       */   
/*       */   private static native void nShowMetricsWindow(boolean[] paramArrayOfboolean);
/*       */   
/*       */   private static native void nShowDebugLogWindow();
/*       */   
/*       */   private static native void nShowDebugLogWindow(boolean[] paramArrayOfboolean);
/*       */   
/*       */   private static native void nShowIDStackToolWindow();
/*       */   
/*       */   private static native void nShowIDStackToolWindow(boolean[] paramArrayOfboolean);
/*       */   
/*       */   private static native void nShowAboutWindow();
/*       */   
/*       */   private static native void nShowAboutWindow(boolean[] paramArrayOfboolean);
/*       */   
/*       */   private static native void nShowStyleEditor();
/*       */   
/*       */   private static native void nShowStyleEditor(long paramLong);
/*       */   
/*       */   private static native boolean nShowStyleSelector(String paramString);
/*       */   
/*       */   private static native void nShowFontSelector(String paramString);
/*       */   
/*       */   private static native void nShowUserGuide();
/*       */   
/*       */   private static native String nGetVersion();
/*       */   
/*       */   private static native void nStyleColorsDark();
/*       */   
/*       */   private static native void nStyleColorsDark(long paramLong);
/*       */   
/*       */   private static native void nStyleColorsLight();
/*       */   
/*       */   private static native void nStyleColorsLight(long paramLong);
/*       */   
/*       */   private static native void nStyleColorsClassic();
/*       */   
/*       */   private static native void nStyleColorsClassic(long paramLong);
/*       */   
/*       */   private static native boolean nBegin(String paramString);
/*       */   
/*       */   private static native boolean nBegin(String paramString, boolean[] paramArrayOfboolean);
/*       */   
/*       */   private static native boolean nBegin(String paramString, boolean[] paramArrayOfboolean, int paramInt);
/*       */   
/*       */   private static native boolean nBegin(String paramString, int paramInt);
/*       */   
/*       */   private static native void nEnd();
/*       */   
/*       */   private static native boolean nBeginChild(String paramString);
/*       */   
/*       */   private static native boolean nBeginChild(String paramString, float paramFloat1, float paramFloat2);
/*       */   
/*       */   private static native boolean nBeginChild(String paramString, float paramFloat1, float paramFloat2, int paramInt);
/*       */   
/*       */   private static native boolean nBeginChild(String paramString, float paramFloat1, float paramFloat2, int paramInt1, int paramInt2);
/*       */   
/*       */   private static native boolean nBeginChild(String paramString, int paramInt1, int paramInt2);
/*       */   
/*       */   private static native boolean nBeginChild(String paramString, int paramInt);
/*       */   
/*       */   private static native boolean nBeginChild(int paramInt);
/*       */   
/*       */   private static native boolean nBeginChild(int paramInt, float paramFloat1, float paramFloat2);
/*       */   
/*       */   private static native boolean nBeginChild(int paramInt1, float paramFloat1, float paramFloat2, int paramInt2);
/*       */   
/*       */   private static native boolean nBeginChild(int paramInt1, float paramFloat1, float paramFloat2, int paramInt2, int paramInt3);
/*       */   
/*       */   private static native boolean nBeginChild(int paramInt1, int paramInt2, int paramInt3);
/*       */   
/*       */   private static native boolean nBeginChild(int paramInt1, int paramInt2);
/*       */   
/*       */   private static native boolean nBeginChild(String paramString, float paramFloat1, float paramFloat2, boolean paramBoolean);
/*       */   
/*       */   private static native boolean nBeginChild(String paramString, float paramFloat1, float paramFloat2, boolean paramBoolean, int paramInt);
/*       */   
/*       */   private static native boolean nBeginChild(int paramInt, float paramFloat1, float paramFloat2, boolean paramBoolean);
/*       */   
/*       */   private static native boolean nBeginChild(int paramInt1, float paramFloat1, float paramFloat2, boolean paramBoolean, int paramInt2);
/*       */   
/*       */   private static native void nEndChild();
/*       */   
/*       */   private static native boolean nIsWindowAppearing();
/*       */   
/*       */   private static native boolean nIsWindowCollapsed();
/*       */   
/*       */   private static native boolean nIsWindowFocused();
/*       */   
/*       */   private static native boolean nIsWindowFocused(int paramInt);
/*       */   
/*       */   private static native boolean nIsWindowHovered();
/*       */   
/*       */   private static native boolean nIsWindowHovered(int paramInt);
/*       */   
/*       */   private static native long nGetWindowDrawList();
/*       */   
/*       */   private static native float nGetWindowDpiScale();
/*       */   
/*       */   private static native void nGetWindowPos(ImVec2 paramImVec2);
/*       */   
/*       */   private static native float nGetWindowPosX();
/*       */   
/*       */   private static native float nGetWindowPosY();
/*       */   
/*       */   private static native void nGetWindowSize(ImVec2 paramImVec2);
/*       */   
/*       */   private static native float nGetWindowSizeX();
/*       */   
/*       */   private static native float nGetWindowSizeY();
/*       */   
/*       */   private static native float nGetWindowWidth();
/*       */   
/*       */   private static native float nGetWindowHeight();
/*       */   
/*       */   private static native long nGetWindowViewport();
/*       */   
/*       */   private static native void nSetNextWindowPos(float paramFloat1, float paramFloat2);
/*       */   
/*       */   private static native void nSetNextWindowPos(float paramFloat1, float paramFloat2, int paramInt);
/*       */   
/*       */   private static native void nSetNextWindowPos(float paramFloat1, float paramFloat2, int paramInt, float paramFloat3, float paramFloat4);
/*       */   
/*       */   private static native void nSetNextWindowPos(float paramFloat1, float paramFloat2, float paramFloat3, float paramFloat4);
/*       */   
/*       */   private static native void nSetNextWindowSize(float paramFloat1, float paramFloat2);
/*       */   
/*       */   private static native void nSetNextWindowSize(float paramFloat1, float paramFloat2, int paramInt);
/*       */   
/*       */   private static native void nSetNextWindowSizeConstraints(float paramFloat1, float paramFloat2, float paramFloat3, float paramFloat4);
/*       */   
/*       */   private static native void nSetNextWindowContentSize(float paramFloat1, float paramFloat2);
/*       */   
/*       */   private static native void nSetNextWindowCollapsed(boolean paramBoolean);
/*       */   
/*       */   private static native void nSetNextWindowCollapsed(boolean paramBoolean, int paramInt);
/*       */   
/*       */   private static native void nSetNextWindowFocus();
/*       */   
/*       */   private static native void nSetNextWindowScroll(float paramFloat1, float paramFloat2);
/*       */   
/*       */   private static native void nSetNextWindowBgAlpha(float paramFloat);
/*       */   
/*       */   private static native void nSetNextWindowViewport(int paramInt);
/*       */   
/*       */   private static native void nSetWindowPos(float paramFloat1, float paramFloat2);
/*       */   
/*       */   private static native void nSetWindowPos(float paramFloat1, float paramFloat2, int paramInt);
/*       */   
/*       */   private static native void nSetWindowSize(float paramFloat1, float paramFloat2);
/*       */   
/*       */   private static native void nSetWindowSize(float paramFloat1, float paramFloat2, int paramInt);
/*       */   
/*       */   private static native void nSetWindowCollapsed(boolean paramBoolean);
/*       */   
/*       */   private static native void nSetWindowCollapsed(boolean paramBoolean, int paramInt);
/*       */   
/*       */   private static native void nSetWindowFocus();
/*       */   
/*       */   private static native void nSetWindowFontScale(float paramFloat);
/*       */   
/*       */   private static native void nSetWindowPos(String paramString, float paramFloat1, float paramFloat2);
/*       */   
/*       */   private static native void nSetWindowPos(String paramString, float paramFloat1, float paramFloat2, int paramInt);
/*       */   
/*       */   private static native void nSetWindowSize(String paramString, float paramFloat1, float paramFloat2);
/*       */   
/*       */   private static native void nSetWindowSize(String paramString, float paramFloat1, float paramFloat2, int paramInt);
/*       */   
/*       */   private static native void nSetWindowCollapsed(String paramString, boolean paramBoolean);
/*       */   
/*       */   private static native void nSetWindowCollapsed(String paramString, boolean paramBoolean, int paramInt);
/*       */   
/*       */   private static native void nSetWindowFocus(String paramString);
/*       */   
/*       */   private static native void nGetContentRegionAvail(ImVec2 paramImVec2);
/*       */   
/*       */   private static native float nGetContentRegionAvailX();
/*       */   
/*       */   private static native float nGetContentRegionAvailY();
/*       */   
/*       */   private static native void nGetContentRegionMax(ImVec2 paramImVec2);
/*       */   
/*       */   private static native float nGetContentRegionMaxX();
/*       */   
/*       */   private static native float nGetContentRegionMaxY();
/*       */   
/*       */   private static native void nGetWindowContentRegionMin(ImVec2 paramImVec2);
/*       */   
/*       */   private static native float nGetWindowContentRegionMinX();
/*       */   
/*       */   private static native float nGetWindowContentRegionMinY();
/*       */   
/*       */   private static native void nGetWindowContentRegionMax(ImVec2 paramImVec2);
/*       */   
/*       */   private static native float nGetWindowContentRegionMaxX();
/*       */   
/*       */   private static native float nGetWindowContentRegionMaxY();
/*       */   
/*       */   private static native float nGetScrollX();
/*       */   
/*       */   private static native float nGetScrollY();
/*       */   
/*       */   private static native void nSetScrollX(float paramFloat);
/*       */   
/*       */   private static native void nSetScrollY(float paramFloat);
/*       */   
/*       */   private static native float nGetScrollMaxX();
/*       */   
/*       */   private static native float nGetScrollMaxY();
/*       */   
/*       */   private static native void nSetScrollHereX();
/*       */   
/*       */   private static native void nSetScrollHereX(float paramFloat);
/*       */   
/*       */   private static native void nSetScrollHereY();
/*       */   
/*       */   private static native void nSetScrollHereY(float paramFloat);
/*       */   
/*       */   private static native void nSetScrollFromPosX(float paramFloat);
/*       */   
/*       */   private static native void nSetScrollFromPosX(float paramFloat1, float paramFloat2);
/*       */   
/*       */   private static native void nSetScrollFromPosY(float paramFloat);
/*       */   
/*       */   private static native void nSetScrollFromPosY(float paramFloat1, float paramFloat2);
/*       */   
/*       */   private static native void nPushFont(long paramLong);
/*       */   
/*       */   private static native void nPopFont();
/*       */   
/*       */   public static native void pushStyleColor(int paramInt1, int paramInt2, int paramInt3, int paramInt4, int paramInt5);
/*       */   
/*       */   private static native void nPushStyleColor(int paramInt, float paramFloat1, float paramFloat2, float paramFloat3, float paramFloat4);
/*       */   
/*       */   private static native void nPushStyleColor(int paramInt1, int paramInt2);
/*       */   
/*       */   private static native void nPopStyleColor();
/*       */   
/*       */   private static native void nPopStyleColor(int paramInt);
/*       */   
/*       */   private static native void nPushStyleVar(int paramInt, float paramFloat);
/*       */   
/*       */   private static native void nPushStyleVar(int paramInt, float paramFloat1, float paramFloat2);
/*       */   
/*       */   private static native void nPopStyleVar();
/*       */   
/*       */   private static native void nPopStyleVar(int paramInt);
/*       */   
/*       */   private static native void nPushTabStop(boolean paramBoolean);
/*       */   
/*       */   private static native void nPopTabStop();
/*       */   
/*       */   private static native void nPushButtonRepeat(boolean paramBoolean);
/*       */   
/*       */   private static native void nPopButtonRepeat();
/*       */   
/*       */   private static native void nPushItemWidth(float paramFloat);
/*       */   
/*       */   private static native void nPopItemWidth();
/*       */   
/*       */   private static native void nSetNextItemWidth(float paramFloat);
/*       */   
/*       */   private static native float nCalcItemWidth();
/*       */   
/*       */   private static native void nPushTextWrapPos();
/*       */   
/*       */   private static native void nPushTextWrapPos(float paramFloat);
/*       */   
/*       */   private static native void nPopTextWrapPos();
/*       */   
/*       */   private static native long nGetFont();
/*       */   
/*       */   private static native int nGetFontSize();
/*       */   
/*       */   private static native void nGetFontTexUvWhitePixel(ImVec2 paramImVec2);
/*       */   
/*       */   private static native float nGetFontTexUvWhitePixelX();
/*       */   
/*       */   private static native float nGetFontTexUvWhitePixelY();
/*       */   
/*       */   private static native int nGetColorU32(int paramInt);
/*       */   
/*       */   private static native int nGetColorU32(int paramInt, float paramFloat);
/*       */   
/*       */   private static native int nGetColorU32(float paramFloat1, float paramFloat2, float paramFloat3, float paramFloat4);
/*       */   
/*       */   private static native int nGetColorU32i(int paramInt);
/*       */   
/*       */   private static native int nGetColorU32i(int paramInt, float paramFloat);
/*       */   
/*       */   private static native void nGetStyleColorVec4(ImVec4 paramImVec4, int paramInt);
/*       */   
/*       */   private static native float nGetStyleColorVec4X(int paramInt);
/*       */   
/*       */   private static native float nGetStyleColorVec4Y(int paramInt);
/*       */   
/*       */   private static native float nGetStyleColorVec4Z(int paramInt);
/*       */   
/*       */   private static native float nGetStyleColorVec4W(int paramInt);
/*       */   
/*       */   private static native void nGetCursorScreenPos(ImVec2 paramImVec2);
/*       */   
/*       */   private static native float nGetCursorScreenPosX();
/*       */   
/*       */   private static native float nGetCursorScreenPosY();
/*       */   
/*       */   private static native void nSetCursorScreenPos(float paramFloat1, float paramFloat2);
/*       */   
/*       */   private static native void nGetCursorPos(ImVec2 paramImVec2);
/*       */   
/*       */   private static native float nGetCursorPosX();
/*       */   
/*       */   private static native float nGetCursorPosY();
/*       */   
/*       */   private static native void nSetCursorPos(float paramFloat1, float paramFloat2);
/*       */   
/*       */   private static native void nSetCursorPosX(float paramFloat);
/*       */   
/*       */   private static native void nSetCursorPosY(float paramFloat);
/*       */   
/*       */   private static native void nGetCursorStartPos(ImVec2 paramImVec2);
/*       */   
/*       */   private static native float nGetCursorStartPosX();
/*       */   
/*       */   private static native float nGetCursorStartPosY();
/*       */   
/*       */   private static native void nSeparator();
/*       */   
/*       */   private static native void nSameLine();
/*       */   
/*       */   private static native void nSameLine(float paramFloat);
/*       */   
/*       */   private static native void nSameLine(float paramFloat1, float paramFloat2);
/*       */   
/*       */   private static native void nNewLine();
/*       */   
/*       */   private static native void nSpacing();
/*       */   
/*       */   private static native void nDummy(float paramFloat1, float paramFloat2);
/*       */   
/*       */   private static native void nIndent();
/*       */   
/*       */   private static native void nIndent(float paramFloat);
/*       */   
/*       */   private static native void nUnindent();
/*       */   
/*       */   private static native void nUnindent(float paramFloat);
/*       */   
/*       */   private static native void nBeginGroup();
/*       */   
/*       */   private static native void nEndGroup();
/*       */   
/*       */   private static native void nAlignTextToFramePadding();
/*       */   
/*       */   private static native float nGetTextLineHeight();
/*       */   
/*       */   private static native float nGetTextLineHeightWithSpacing();
/*       */   
/*       */   private static native float nGetFrameHeight();
/*       */   
/*       */   private static native float nGetFrameHeightWithSpacing();
/*       */   
/*       */   private static native void nPushID(String paramString);
/*       */   
/*       */   private static native void nPushID(String paramString1, String paramString2);
/*       */   
/*       */   private static native void nPushID(long paramLong);
/*       */   
/*       */   private static native void nPushID(int paramInt);
/*       */   
/*       */   private static native void nPopID();
/*       */   
/*       */   private static native int nGetID(String paramString);
/*       */   
/*       */   private static native int nGetID(String paramString1, String paramString2);
/*       */   
/*       */   private static native int nGetID(long paramLong);
/*       */   
/*       */   private static native void nTextUnformatted(String paramString);
/*       */   
/*       */   private static native void nTextUnformatted(String paramString1, String paramString2);
/*       */   
/*       */   private static native void nText(String paramString);
/*       */   
/*       */   private static native void nTextColored(float paramFloat1, float paramFloat2, float paramFloat3, float paramFloat4, String paramString);
/*       */   
/*       */   public static native void textColored(int paramInt1, int paramInt2, int paramInt3, int paramInt4, String paramString);
/*       */   
/*       */   public static native void textColored(int paramInt, String paramString);
/*       */   
/*       */   private static native void nTextDisabled(String paramString);
/*       */   
/*       */   private static native void nTextWrapped(String paramString);
/*       */   
/*       */   private static native void nLabelText(String paramString1, String paramString2);
/*       */   
/*       */   private static native void nBulletText(String paramString);
/*       */   
/*       */   private static native void nSeparatorText(String paramString);
/*       */   
/*       */   private static native boolean nButton(String paramString);
/*       */   
/*       */   private static native boolean nButton(String paramString, float paramFloat1, float paramFloat2);
/*       */   
/*       */   private static native boolean nSmallButton(String paramString);
/*       */   
/*       */   private static native boolean nInvisibleButton(String paramString, float paramFloat1, float paramFloat2);
/*       */   
/*       */   private static native boolean nInvisibleButton(String paramString, float paramFloat1, float paramFloat2, int paramInt);
/*       */   
/*       */   private static native boolean nArrowButton(String paramString, int paramInt);
/*       */   
/*       */   private static native boolean nCheckbox(String paramString, boolean paramBoolean);
/*       */   
/*       */   private static native boolean nCheckbox(String paramString, boolean[] paramArrayOfboolean);
/*       */   
/*       */   private static native boolean nCheckboxFlags(String paramString, int[] paramArrayOfint, int paramInt);
/*       */   
/*       */   private static native boolean nRadioButton(String paramString, boolean paramBoolean);
/*       */   
/*       */   private static native boolean nRadioButton(String paramString, int[] paramArrayOfint, int paramInt);
/*       */   
/*       */   private static native void nProgressBar(float paramFloat);
/*       */   
/*       */   private static native void nProgressBar(float paramFloat1, float paramFloat2, float paramFloat3);
/*       */   
/*       */   private static native void nProgressBar(float paramFloat1, float paramFloat2, float paramFloat3, String paramString);
/*       */   
/*       */   private static native void nProgressBar(float paramFloat, String paramString);
/*       */   
/*       */   private static native void nBullet();
/*       */   
/*       */   private static native void nImage(long paramLong, float paramFloat1, float paramFloat2);
/*       */   
/*       */   private static native void nImage(long paramLong, float paramFloat1, float paramFloat2, float paramFloat3, float paramFloat4);
/*       */   
/*       */   private static native void nImage(long paramLong, float paramFloat1, float paramFloat2, float paramFloat3, float paramFloat4, float paramFloat5, float paramFloat6);
/*       */   
/*       */   private static native void nImage(long paramLong, float paramFloat1, float paramFloat2, float paramFloat3, float paramFloat4, float paramFloat5, float paramFloat6, float paramFloat7, float paramFloat8, float paramFloat9, float paramFloat10);
/*       */   
/*       */   private static native void nImage(long paramLong, float paramFloat1, float paramFloat2, float paramFloat3, float paramFloat4, float paramFloat5, float paramFloat6, float paramFloat7, float paramFloat8, float paramFloat9, float paramFloat10, float paramFloat11, float paramFloat12, float paramFloat13, float paramFloat14);
/*       */   
/*       */   private static native boolean nImageButton(String paramString, long paramLong, float paramFloat1, float paramFloat2);
/*       */   
/*       */   private static native boolean nImageButton(String paramString, long paramLong, float paramFloat1, float paramFloat2, float paramFloat3, float paramFloat4);
/*       */   
/*       */   private static native boolean nImageButton(String paramString, long paramLong, float paramFloat1, float paramFloat2, float paramFloat3, float paramFloat4, float paramFloat5, float paramFloat6);
/*       */   
/*       */   private static native boolean nImageButton(String paramString, long paramLong, float paramFloat1, float paramFloat2, float paramFloat3, float paramFloat4, float paramFloat5, float paramFloat6, float paramFloat7, float paramFloat8, float paramFloat9, float paramFloat10);
/*       */   
/*       */   private static native boolean nImageButton(String paramString, long paramLong, float paramFloat1, float paramFloat2, float paramFloat3, float paramFloat4, float paramFloat5, float paramFloat6, float paramFloat7, float paramFloat8, float paramFloat9, float paramFloat10, float paramFloat11, float paramFloat12, float paramFloat13, float paramFloat14);
/*       */   
/*       */   private static native boolean nBeginCombo(String paramString1, String paramString2);
/*       */   
/*       */   private static native boolean nBeginCombo(String paramString1, String paramString2, int paramInt);
/*       */   
/*       */   private static native void nEndCombo();
/*       */   
/*       */   private static native boolean nCombo(String paramString, int[] paramArrayOfint, String[] paramArrayOfString, int paramInt);
/*       */   
/*       */   private static native boolean nCombo(String paramString, int[] paramArrayOfint, String[] paramArrayOfString, int paramInt1, int paramInt2);
/*       */   
/*       */   private static native boolean nCombo(String paramString1, int[] paramArrayOfint, String paramString2);
/*       */   
/*       */   private static native boolean nCombo(String paramString1, int[] paramArrayOfint, String paramString2, int paramInt);
/*       */   
/*       */   private static native boolean nDragFloat(String paramString, float[] paramArrayOffloat);
/*       */   
/*       */   private static native boolean nDragFloat(String paramString, float[] paramArrayOffloat, float paramFloat);
/*       */   
/*       */   private static native boolean nDragFloat(String paramString, float[] paramArrayOffloat, float paramFloat1, float paramFloat2);
/*       */   
/*       */   private static native boolean nDragFloat(String paramString, float[] paramArrayOffloat, float paramFloat1, float paramFloat2, float paramFloat3);
/*       */   
/*       */   private static native boolean nDragFloat(String paramString1, float[] paramArrayOffloat, float paramFloat1, float paramFloat2, float paramFloat3, String paramString2);
/*       */   
/*       */   private static native boolean nDragFloat(String paramString1, float[] paramArrayOffloat, float paramFloat1, float paramFloat2, float paramFloat3, String paramString2, int paramInt);
/*       */   
/*       */   private static native boolean nDragFloat(String paramString, float[] paramArrayOffloat, float paramFloat1, float paramFloat2, float paramFloat3, int paramInt);
/*       */   
/*       */   private static native boolean nDragFloat2(String paramString, float[] paramArrayOffloat);
/*       */   
/*       */   private static native boolean nDragFloat2(String paramString, float[] paramArrayOffloat, float paramFloat);
/*       */   
/*       */   private static native boolean nDragFloat2(String paramString, float[] paramArrayOffloat, float paramFloat1, float paramFloat2);
/*       */   
/*       */   private static native boolean nDragFloat2(String paramString, float[] paramArrayOffloat, float paramFloat1, float paramFloat2, float paramFloat3);
/*       */   
/*       */   private static native boolean nDragFloat2(String paramString1, float[] paramArrayOffloat, float paramFloat1, float paramFloat2, float paramFloat3, String paramString2);
/*       */   
/*       */   private static native boolean nDragFloat2(String paramString1, float[] paramArrayOffloat, float paramFloat1, float paramFloat2, float paramFloat3, String paramString2, int paramInt);
/*       */   
/*       */   private static native boolean nDragFloat2(String paramString, float[] paramArrayOffloat, float paramFloat1, float paramFloat2, float paramFloat3, int paramInt);
/*       */   
/*       */   private static native boolean nDragFloat3(String paramString, float[] paramArrayOffloat);
/*       */   
/*       */   private static native boolean nDragFloat3(String paramString, float[] paramArrayOffloat, float paramFloat);
/*       */   
/*       */   private static native boolean nDragFloat3(String paramString, float[] paramArrayOffloat, float paramFloat1, float paramFloat2);
/*       */   
/*       */   private static native boolean nDragFloat3(String paramString, float[] paramArrayOffloat, float paramFloat1, float paramFloat2, float paramFloat3);
/*       */   
/*       */   private static native boolean nDragFloat3(String paramString1, float[] paramArrayOffloat, float paramFloat1, float paramFloat2, float paramFloat3, String paramString2);
/*       */   
/*       */   private static native boolean nDragFloat3(String paramString1, float[] paramArrayOffloat, float paramFloat1, float paramFloat2, float paramFloat3, String paramString2, int paramInt);
/*       */   
/*       */   private static native boolean nDragFloat3(String paramString, float[] paramArrayOffloat, float paramFloat1, float paramFloat2, float paramFloat3, int paramInt);
/*       */   
/*       */   private static native boolean nDragFloat4(String paramString, float[] paramArrayOffloat);
/*       */   
/*       */   private static native boolean nDragFloat4(String paramString, float[] paramArrayOffloat, float paramFloat);
/*       */   
/*       */   private static native boolean nDragFloat4(String paramString, float[] paramArrayOffloat, float paramFloat1, float paramFloat2);
/*       */   
/*       */   private static native boolean nDragFloat4(String paramString, float[] paramArrayOffloat, float paramFloat1, float paramFloat2, float paramFloat3);
/*       */   
/*       */   private static native boolean nDragFloat4(String paramString1, float[] paramArrayOffloat, float paramFloat1, float paramFloat2, float paramFloat3, String paramString2);
/*       */   
/*       */   private static native boolean nDragFloat4(String paramString1, float[] paramArrayOffloat, float paramFloat1, float paramFloat2, float paramFloat3, String paramString2, int paramInt);
/*       */   
/*       */   private static native boolean nDragFloat4(String paramString, float[] paramArrayOffloat, float paramFloat1, float paramFloat2, float paramFloat3, int paramInt);
/*       */   
/*       */   private static native boolean nDragFloatRange2(String paramString, float[] paramArrayOffloat1, float[] paramArrayOffloat2, float paramFloat);
/*       */   
/*       */   private static native boolean nDragFloatRange2(String paramString, float[] paramArrayOffloat1, float[] paramArrayOffloat2, float paramFloat1, float paramFloat2);
/*       */   
/*       */   private static native boolean nDragFloatRange2(String paramString, float[] paramArrayOffloat1, float[] paramArrayOffloat2, float paramFloat1, float paramFloat2, float paramFloat3);
/*       */   
/*       */   private static native boolean nDragFloatRange2(String paramString1, float[] paramArrayOffloat1, float[] paramArrayOffloat2, float paramFloat1, float paramFloat2, float paramFloat3, String paramString2);
/*       */   
/*       */   private static native boolean nDragFloatRange2(String paramString1, float[] paramArrayOffloat1, float[] paramArrayOffloat2, float paramFloat1, float paramFloat2, float paramFloat3, String paramString2, String paramString3);
/*       */   
/*       */   private static native boolean nDragFloatRange2(String paramString1, float[] paramArrayOffloat1, float[] paramArrayOffloat2, float paramFloat1, float paramFloat2, float paramFloat3, String paramString2, String paramString3, int paramInt);
/*       */   
/*       */   private static native boolean nDragInt(String paramString, int[] paramArrayOfint);
/*       */   
/*       */   private static native boolean nDragInt(String paramString, int[] paramArrayOfint, float paramFloat);
/*       */   
/*       */   private static native boolean nDragInt(String paramString, int[] paramArrayOfint, float paramFloat, int paramInt);
/*       */   
/*       */   private static native boolean nDragInt(String paramString, int[] paramArrayOfint, float paramFloat, int paramInt1, int paramInt2);
/*       */   
/*       */   private static native boolean nDragInt(String paramString1, int[] paramArrayOfint, float paramFloat, int paramInt1, int paramInt2, String paramString2);
/*       */   
/*       */   private static native boolean nDragInt(String paramString1, int[] paramArrayOfint, float paramFloat, int paramInt1, int paramInt2, String paramString2, int paramInt3);
/*       */   
/*       */   private static native boolean nDragInt(String paramString, int[] paramArrayOfint, float paramFloat, int paramInt1, int paramInt2, int paramInt3);
/*       */   
/*       */   private static native boolean nDragInt2(String paramString, int[] paramArrayOfint);
/*       */   
/*       */   private static native boolean nDragInt2(String paramString, int[] paramArrayOfint, float paramFloat);
/*       */   
/*       */   private static native boolean nDragInt2(String paramString, int[] paramArrayOfint, float paramFloat, int paramInt);
/*       */   
/*       */   private static native boolean nDragInt2(String paramString, int[] paramArrayOfint, float paramFloat, int paramInt1, int paramInt2);
/*       */   
/*       */   private static native boolean nDragInt2(String paramString1, int[] paramArrayOfint, float paramFloat, int paramInt1, int paramInt2, String paramString2);
/*       */   
/*       */   private static native boolean nDragInt2(String paramString1, int[] paramArrayOfint, float paramFloat, int paramInt1, int paramInt2, String paramString2, int paramInt3);
/*       */   
/*       */   private static native boolean nDragInt2(String paramString, int[] paramArrayOfint, float paramFloat, int paramInt1, int paramInt2, int paramInt3);
/*       */   
/*       */   private static native boolean nDragInt3(String paramString, int[] paramArrayOfint);
/*       */   
/*       */   private static native boolean nDragInt3(String paramString, int[] paramArrayOfint, float paramFloat);
/*       */   
/*       */   private static native boolean nDragInt3(String paramString, int[] paramArrayOfint, float paramFloat, int paramInt);
/*       */   
/*       */   private static native boolean nDragInt3(String paramString, int[] paramArrayOfint, float paramFloat, int paramInt1, int paramInt2);
/*       */   
/*       */   private static native boolean nDragInt3(String paramString1, int[] paramArrayOfint, float paramFloat, int paramInt1, int paramInt2, String paramString2);
/*       */   
/*       */   private static native boolean nDragInt3(String paramString1, int[] paramArrayOfint, float paramFloat, int paramInt1, int paramInt2, String paramString2, int paramInt3);
/*       */   
/*       */   private static native boolean nDragInt3(String paramString, int[] paramArrayOfint, float paramFloat, int paramInt1, int paramInt2, int paramInt3);
/*       */   
/*       */   private static native boolean nDragInt4(String paramString, int[] paramArrayOfint);
/*       */   
/*       */   private static native boolean nDragInt4(String paramString, int[] paramArrayOfint, float paramFloat);
/*       */   
/*       */   private static native boolean nDragInt4(String paramString, int[] paramArrayOfint, float paramFloat, int paramInt);
/*       */   
/*       */   private static native boolean nDragInt4(String paramString, int[] paramArrayOfint, float paramFloat, int paramInt1, int paramInt2);
/*       */   
/*       */   private static native boolean nDragInt4(String paramString1, int[] paramArrayOfint, float paramFloat, int paramInt1, int paramInt2, String paramString2);
/*       */   
/*       */   private static native boolean nDragInt4(String paramString1, int[] paramArrayOfint, float paramFloat, int paramInt1, int paramInt2, String paramString2, int paramInt3);
/*       */   
/*       */   private static native boolean nDragInt4(String paramString, int[] paramArrayOfint, float paramFloat, int paramInt1, int paramInt2, int paramInt3);
/*       */   
/*       */   private static native boolean nDragIntRange2(String paramString, int[] paramArrayOfint1, int[] paramArrayOfint2);
/*       */   
/*       */   private static native boolean nDragIntRange2(String paramString, int[] paramArrayOfint1, int[] paramArrayOfint2, float paramFloat);
/*       */   
/*       */   private static native boolean nDragIntRange2(String paramString, int[] paramArrayOfint1, int[] paramArrayOfint2, float paramFloat, int paramInt);
/*       */   
/*       */   private static native boolean nDragIntRange2(String paramString, int[] paramArrayOfint1, int[] paramArrayOfint2, float paramFloat, int paramInt1, int paramInt2);
/*       */   
/*       */   private static native boolean nDragIntRange2(String paramString1, int[] paramArrayOfint1, int[] paramArrayOfint2, float paramFloat, int paramInt1, int paramInt2, String paramString2);
/*       */   
/*       */   private static native boolean nDragIntRange2(String paramString1, int[] paramArrayOfint1, int[] paramArrayOfint2, float paramFloat, int paramInt1, int paramInt2, String paramString2, String paramString3);
/*       */   
/*       */   private static native boolean nDragIntRange2(String paramString1, int[] paramArrayOfint1, int[] paramArrayOfint2, float paramFloat, int paramInt1, int paramInt2, String paramString2, String paramString3, int paramInt3);
/*       */   
/*       */   private static native boolean nDragScalar(String paramString, short[] paramArrayOfshort);
/*       */   
/*       */   private static native boolean nDragScalar(String paramString, short[] paramArrayOfshort, float paramFloat);
/*       */   
/*       */   private static native boolean nDragScalar(String paramString, short[] paramArrayOfshort, float paramFloat, short paramShort);
/*       */   
/*       */   private static native boolean nDragScalar(String paramString, short[] paramArrayOfshort, float paramFloat, short paramShort1, short paramShort2);
/*       */   
/*       */   private static native boolean nDragScalar(String paramString1, short[] paramArrayOfshort, float paramFloat, short paramShort1, short paramShort2, String paramString2);
/*       */   
/*       */   private static native boolean nDragScalar(String paramString1, short[] paramArrayOfshort, float paramFloat, short paramShort1, short paramShort2, String paramString2, int paramInt);
/*       */   
/*       */   private static native boolean nDragScalar(String paramString, int[] paramArrayOfint);
/*       */   
/*       */   private static native boolean nDragScalar(String paramString, int[] paramArrayOfint, float paramFloat);
/*       */   
/*       */   private static native boolean nDragScalar(String paramString, int[] paramArrayOfint, float paramFloat, int paramInt);
/*       */   
/*       */   private static native boolean nDragScalar(String paramString, int[] paramArrayOfint, float paramFloat, int paramInt1, int paramInt2);
/*       */   
/*       */   private static native boolean nDragScalar(String paramString1, int[] paramArrayOfint, float paramFloat, int paramInt1, int paramInt2, String paramString2);
/*       */   
/*       */   private static native boolean nDragScalar(String paramString1, int[] paramArrayOfint, float paramFloat, int paramInt1, int paramInt2, String paramString2, int paramInt3);
/*       */   
/*       */   private static native boolean nDragScalar(String paramString, long[] paramArrayOflong);
/*       */   
/*       */   private static native boolean nDragScalar(String paramString, long[] paramArrayOflong, float paramFloat);
/*       */   
/*       */   private static native boolean nDragScalar(String paramString, long[] paramArrayOflong, float paramFloat, long paramLong);
/*       */   
/*       */   private static native boolean nDragScalar(String paramString, long[] paramArrayOflong, float paramFloat, long paramLong1, long paramLong2);
/*       */   
/*       */   private static native boolean nDragScalar(String paramString1, long[] paramArrayOflong, float paramFloat, long paramLong1, long paramLong2, String paramString2);
/*       */   
/*       */   private static native boolean nDragScalar(String paramString1, long[] paramArrayOflong, float paramFloat, long paramLong1, long paramLong2, String paramString2, int paramInt);
/*       */   
/*       */   private static native boolean nDragScalar(String paramString, float[] paramArrayOffloat);
/*       */   
/*       */   private static native boolean nDragScalar(String paramString, float[] paramArrayOffloat, float paramFloat);
/*       */   
/*       */   private static native boolean nDragScalar(String paramString, float[] paramArrayOffloat, float paramFloat1, float paramFloat2);
/*       */   
/*       */   private static native boolean nDragScalar(String paramString, float[] paramArrayOffloat, float paramFloat1, float paramFloat2, float paramFloat3);
/*       */   
/*       */   private static native boolean nDragScalar(String paramString1, float[] paramArrayOffloat, float paramFloat1, float paramFloat2, float paramFloat3, String paramString2);
/*       */   
/*       */   private static native boolean nDragScalar(String paramString1, float[] paramArrayOffloat, float paramFloat1, float paramFloat2, float paramFloat3, String paramString2, int paramInt);
/*       */   
/*       */   private static native boolean nDragScalar(String paramString, double[] paramArrayOfdouble);
/*       */   
/*       */   private static native boolean nDragScalar(String paramString, double[] paramArrayOfdouble, float paramFloat);
/*       */   
/*       */   private static native boolean nDragScalar(String paramString, double[] paramArrayOfdouble, float paramFloat, double paramDouble);
/*       */   
/*       */   private static native boolean nDragScalar(String paramString, double[] paramArrayOfdouble, float paramFloat, double paramDouble1, double paramDouble2);
/*       */   
/*       */   private static native boolean nDragScalar(String paramString1, double[] paramArrayOfdouble, float paramFloat, double paramDouble1, double paramDouble2, String paramString2);
/*       */   
/*       */   private static native boolean nDragScalar(String paramString1, double[] paramArrayOfdouble, float paramFloat, double paramDouble1, double paramDouble2, String paramString2, int paramInt);
/*       */   
/*       */   private static native boolean nDragScalarN(String paramString, short[] paramArrayOfshort, int paramInt);
/*       */   
/*       */   private static native boolean nDragScalarN(String paramString, short[] paramArrayOfshort, int paramInt, float paramFloat);
/*       */   
/*       */   private static native boolean nDragScalarN(String paramString, short[] paramArrayOfshort, int paramInt, float paramFloat, short paramShort);
/*       */   
/*       */   private static native boolean nDragScalarN(String paramString, short[] paramArrayOfshort, int paramInt, float paramFloat, short paramShort1, short paramShort2);
/*       */   
/*       */   private static native boolean nDragScalarN(String paramString1, short[] paramArrayOfshort, int paramInt, float paramFloat, short paramShort1, short paramShort2, String paramString2);
/*       */   
/*       */   private static native boolean nDragScalarN(String paramString1, short[] paramArrayOfshort, int paramInt1, float paramFloat, short paramShort1, short paramShort2, String paramString2, int paramInt2);
/*       */   
/*       */   private static native boolean nDragScalarN(String paramString, int[] paramArrayOfint, int paramInt);
/*       */   
/*       */   private static native boolean nDragScalarN(String paramString, int[] paramArrayOfint, int paramInt, float paramFloat);
/*       */   
/*       */   private static native boolean nDragScalarN(String paramString, int[] paramArrayOfint, int paramInt1, float paramFloat, int paramInt2);
/*       */   
/*       */   private static native boolean nDragScalarN(String paramString, int[] paramArrayOfint, int paramInt1, float paramFloat, int paramInt2, int paramInt3);
/*       */   
/*       */   private static native boolean nDragScalarN(String paramString1, int[] paramArrayOfint, int paramInt1, float paramFloat, int paramInt2, int paramInt3, String paramString2);
/*       */   
/*       */   private static native boolean nDragScalarN(String paramString1, int[] paramArrayOfint, int paramInt1, float paramFloat, int paramInt2, int paramInt3, String paramString2, int paramInt4);
/*       */   
/*       */   private static native boolean nDragScalarN(String paramString, long[] paramArrayOflong, int paramInt);
/*       */   
/*       */   private static native boolean nDragScalarN(String paramString, long[] paramArrayOflong, int paramInt, float paramFloat);
/*       */   
/*       */   private static native boolean nDragScalarN(String paramString, long[] paramArrayOflong, int paramInt, float paramFloat, long paramLong);
/*       */   
/*       */   private static native boolean nDragScalarN(String paramString, long[] paramArrayOflong, int paramInt, float paramFloat, long paramLong1, long paramLong2);
/*       */   
/*       */   private static native boolean nDragScalarN(String paramString1, long[] paramArrayOflong, int paramInt, float paramFloat, long paramLong1, long paramLong2, String paramString2);
/*       */   
/*       */   private static native boolean nDragScalarN(String paramString1, long[] paramArrayOflong, int paramInt1, float paramFloat, long paramLong1, long paramLong2, String paramString2, int paramInt2);
/*       */   
/*       */   private static native boolean nDragScalarN(String paramString, float[] paramArrayOffloat, int paramInt);
/*       */   
/*       */   private static native boolean nDragScalarN(String paramString, float[] paramArrayOffloat, int paramInt, float paramFloat);
/*       */   
/*       */   private static native boolean nDragScalarN(String paramString, float[] paramArrayOffloat, int paramInt, float paramFloat1, float paramFloat2);
/*       */   
/*       */   private static native boolean nDragScalarN(String paramString, float[] paramArrayOffloat, int paramInt, float paramFloat1, float paramFloat2, float paramFloat3);
/*       */   
/*       */   private static native boolean nDragScalarN(String paramString1, float[] paramArrayOffloat, int paramInt, float paramFloat1, float paramFloat2, float paramFloat3, String paramString2);
/*       */   
/*       */   private static native boolean nDragScalarN(String paramString1, float[] paramArrayOffloat, int paramInt1, float paramFloat1, float paramFloat2, float paramFloat3, String paramString2, int paramInt2);
/*       */   
/*       */   private static native boolean nDragScalarN(String paramString, double[] paramArrayOfdouble, int paramInt);
/*       */   
/*       */   private static native boolean nDragScalarN(String paramString, double[] paramArrayOfdouble, int paramInt, float paramFloat);
/*       */   
/*       */   private static native boolean nDragScalarN(String paramString, double[] paramArrayOfdouble, int paramInt, float paramFloat, double paramDouble);
/*       */   
/*       */   private static native boolean nDragScalarN(String paramString, double[] paramArrayOfdouble, int paramInt, float paramFloat, double paramDouble1, double paramDouble2);
/*       */   
/*       */   private static native boolean nDragScalarN(String paramString1, double[] paramArrayOfdouble, int paramInt, float paramFloat, double paramDouble1, double paramDouble2, String paramString2);
/*       */   
/*       */   private static native boolean nDragScalarN(String paramString1, double[] paramArrayOfdouble, int paramInt1, float paramFloat, double paramDouble1, double paramDouble2, String paramString2, int paramInt2);
/*       */   
/*       */   private static native boolean nSliderFloat(String paramString, float[] paramArrayOffloat, float paramFloat1, float paramFloat2);
/*       */   
/*       */   private static native boolean nSliderFloat(String paramString1, float[] paramArrayOffloat, float paramFloat1, float paramFloat2, String paramString2);
/*       */   
/*       */   private static native boolean nSliderFloat(String paramString1, float[] paramArrayOffloat, float paramFloat1, float paramFloat2, String paramString2, int paramInt);
/*       */   
/*       */   private static native boolean nSliderFloat(String paramString, float[] paramArrayOffloat, float paramFloat1, float paramFloat2, int paramInt);
/*       */   
/*       */   private static native boolean nSliderFloat2(String paramString, float[] paramArrayOffloat, float paramFloat1, float paramFloat2);
/*       */   
/*       */   private static native boolean nSliderFloat2(String paramString1, float[] paramArrayOffloat, float paramFloat1, float paramFloat2, String paramString2);
/*       */   
/*       */   private static native boolean nSliderFloat2(String paramString1, float[] paramArrayOffloat, float paramFloat1, float paramFloat2, String paramString2, int paramInt);
/*       */   
/*       */   private static native boolean nSliderFloat2(String paramString, float[] paramArrayOffloat, float paramFloat1, float paramFloat2, int paramInt);
/*       */   
/*       */   private static native boolean nSliderFloat3(String paramString, float[] paramArrayOffloat, float paramFloat1, float paramFloat2);
/*       */   
/*       */   private static native boolean nSliderFloat3(String paramString1, float[] paramArrayOffloat, float paramFloat1, float paramFloat2, String paramString2);
/*       */   
/*       */   private static native boolean nSliderFloat3(String paramString1, float[] paramArrayOffloat, float paramFloat1, float paramFloat2, String paramString2, int paramInt);
/*       */   
/*       */   private static native boolean nSliderFloat3(String paramString, float[] paramArrayOffloat, float paramFloat1, float paramFloat2, int paramInt);
/*       */   
/*       */   private static native boolean nSliderFloat4(String paramString, float[] paramArrayOffloat, float paramFloat1, float paramFloat2);
/*       */   
/*       */   private static native boolean nSliderFloat4(String paramString1, float[] paramArrayOffloat, float paramFloat1, float paramFloat2, String paramString2);
/*       */   
/*       */   private static native boolean nSliderFloat4(String paramString1, float[] paramArrayOffloat, float paramFloat1, float paramFloat2, String paramString2, int paramInt);
/*       */   
/*       */   private static native boolean nSliderFloat4(String paramString, float[] paramArrayOffloat, float paramFloat1, float paramFloat2, int paramInt);
/*       */   
/*       */   private static native boolean nSliderAngle(String paramString, float[] paramArrayOffloat);
/*       */   
/*       */   private static native boolean nSliderAngle(String paramString, float[] paramArrayOffloat, float paramFloat);
/*       */   
/*       */   private static native boolean nSliderAngle(String paramString, float[] paramArrayOffloat, float paramFloat1, float paramFloat2);
/*       */   
/*       */   private static native boolean nSliderAngle(String paramString1, float[] paramArrayOffloat, float paramFloat1, float paramFloat2, String paramString2);
/*       */   
/*       */   private static native boolean nSliderAngle(String paramString1, float[] paramArrayOffloat, float paramFloat1, float paramFloat2, String paramString2, int paramInt);
/*       */   
/*       */   private static native boolean nSliderAngle(String paramString, float[] paramArrayOffloat, float paramFloat1, float paramFloat2, int paramInt);
/*       */   
/*       */   private static native boolean nSliderInt(String paramString, int[] paramArrayOfint, int paramInt1, int paramInt2);
/*       */   
/*       */   private static native boolean nSliderInt(String paramString1, int[] paramArrayOfint, int paramInt1, int paramInt2, String paramString2);
/*       */   
/*       */   private static native boolean nSliderInt(String paramString1, int[] paramArrayOfint, int paramInt1, int paramInt2, String paramString2, int paramInt3);
/*       */   
/*       */   private static native boolean nSliderInt(String paramString, int[] paramArrayOfint, int paramInt1, int paramInt2, int paramInt3);
/*       */   
/*       */   private static native boolean nSliderInt2(String paramString, int[] paramArrayOfint, int paramInt1, int paramInt2);
/*       */   
/*       */   private static native boolean nSliderInt2(String paramString1, int[] paramArrayOfint, int paramInt1, int paramInt2, String paramString2);
/*       */   
/*       */   private static native boolean nSliderInt2(String paramString1, int[] paramArrayOfint, int paramInt1, int paramInt2, String paramString2, int paramInt3);
/*       */   
/*       */   private static native boolean nSliderInt2(String paramString, int[] paramArrayOfint, int paramInt1, int paramInt2, int paramInt3);
/*       */   
/*       */   private static native boolean nSliderInt3(String paramString, int[] paramArrayOfint, int paramInt1, int paramInt2);
/*       */   
/*       */   private static native boolean nSliderInt3(String paramString1, int[] paramArrayOfint, int paramInt1, int paramInt2, String paramString2);
/*       */   
/*       */   private static native boolean nSliderInt3(String paramString1, int[] paramArrayOfint, int paramInt1, int paramInt2, String paramString2, int paramInt3);
/*       */   
/*       */   private static native boolean nSliderInt3(String paramString, int[] paramArrayOfint, int paramInt1, int paramInt2, int paramInt3);
/*       */   
/*       */   private static native boolean nSliderInt4(String paramString, int[] paramArrayOfint, int paramInt1, int paramInt2);
/*       */   
/*       */   private static native boolean nSliderInt4(String paramString1, int[] paramArrayOfint, int paramInt1, int paramInt2, String paramString2);
/*       */   
/*       */   private static native boolean nSliderInt4(String paramString1, int[] paramArrayOfint, int paramInt1, int paramInt2, String paramString2, int paramInt3);
/*       */   
/*       */   private static native boolean nSliderInt4(String paramString, int[] paramArrayOfint, int paramInt1, int paramInt2, int paramInt3);
/*       */   
/*       */   private static native boolean nSliderScalar(String paramString, short[] paramArrayOfshort, short paramShort1, short paramShort2);
/*       */   
/*       */   private static native boolean nSliderScalar(String paramString1, short[] paramArrayOfshort, short paramShort1, short paramShort2, String paramString2);
/*       */   
/*       */   private static native boolean nSliderScalar(String paramString1, short[] paramArrayOfshort, short paramShort1, short paramShort2, String paramString2, int paramInt);
/*       */   
/*       */   private static native boolean nSliderScalar(String paramString, int[] paramArrayOfint, int paramInt1, int paramInt2);
/*       */   
/*       */   private static native boolean nSliderScalar(String paramString1, int[] paramArrayOfint, int paramInt1, int paramInt2, String paramString2);
/*       */   
/*       */   private static native boolean nSliderScalar(String paramString1, int[] paramArrayOfint, int paramInt1, int paramInt2, String paramString2, int paramInt3);
/*       */   
/*       */   private static native boolean nSliderScalar(String paramString, long[] paramArrayOflong, long paramLong1, long paramLong2);
/*       */   
/*       */   private static native boolean nSliderScalar(String paramString1, long[] paramArrayOflong, long paramLong1, long paramLong2, String paramString2);
/*       */   
/*       */   private static native boolean nSliderScalar(String paramString1, long[] paramArrayOflong, long paramLong1, long paramLong2, String paramString2, int paramInt);
/*       */   
/*       */   private static native boolean nSliderScalar(String paramString, float[] paramArrayOffloat, float paramFloat1, float paramFloat2);
/*       */   
/*       */   private static native boolean nSliderScalar(String paramString1, float[] paramArrayOffloat, float paramFloat1, float paramFloat2, String paramString2);
/*       */   
/*       */   private static native boolean nSliderScalar(String paramString1, float[] paramArrayOffloat, float paramFloat1, float paramFloat2, String paramString2, int paramInt);
/*       */   
/*       */   private static native boolean nSliderScalar(String paramString, double[] paramArrayOfdouble, double paramDouble1, double paramDouble2);
/*       */   
/*       */   private static native boolean nSliderScalar(String paramString1, double[] paramArrayOfdouble, double paramDouble1, double paramDouble2, String paramString2);
/*       */   
/*       */   private static native boolean nSliderScalar(String paramString1, double[] paramArrayOfdouble, double paramDouble1, double paramDouble2, String paramString2, int paramInt);
/*       */   
/*       */   private static native boolean nSliderScalarN(String paramString, short[] paramArrayOfshort, int paramInt, short paramShort1, short paramShort2);
/*       */   
/*       */   private static native boolean nSliderScalarN(String paramString1, short[] paramArrayOfshort, int paramInt, short paramShort1, short paramShort2, String paramString2);
/*       */   
/*       */   private static native boolean nSliderScalarN(String paramString1, short[] paramArrayOfshort, int paramInt1, short paramShort1, short paramShort2, String paramString2, int paramInt2);
/*       */   
/*       */   private static native boolean nSliderScalarN(String paramString, int[] paramArrayOfint, int paramInt1, int paramInt2, int paramInt3);
/*       */   
/*       */   private static native boolean nSliderScalarN(String paramString1, int[] paramArrayOfint, int paramInt1, int paramInt2, int paramInt3, String paramString2);
/*       */   
/*       */   private static native boolean nSliderScalarN(String paramString1, int[] paramArrayOfint, int paramInt1, int paramInt2, int paramInt3, String paramString2, int paramInt4);
/*       */   
/*       */   private static native boolean nSliderScalarN(String paramString, long[] paramArrayOflong, int paramInt, long paramLong1, long paramLong2);
/*       */   
/*       */   private static native boolean nSliderScalarN(String paramString1, long[] paramArrayOflong, int paramInt, long paramLong1, long paramLong2, String paramString2);
/*       */   
/*       */   private static native boolean nSliderScalarN(String paramString1, long[] paramArrayOflong, int paramInt1, long paramLong1, long paramLong2, String paramString2, int paramInt2);
/*       */   
/*       */   private static native boolean nSliderScalarN(String paramString, float[] paramArrayOffloat, int paramInt, float paramFloat1, float paramFloat2);
/*       */   
/*       */   private static native boolean nSliderScalarN(String paramString1, float[] paramArrayOffloat, int paramInt, float paramFloat1, float paramFloat2, String paramString2);
/*       */   
/*       */   private static native boolean nSliderScalarN(String paramString1, float[] paramArrayOffloat, int paramInt1, float paramFloat1, float paramFloat2, String paramString2, int paramInt2);
/*       */   
/*       */   private static native boolean nSliderScalarN(String paramString, double[] paramArrayOfdouble, int paramInt, double paramDouble1, double paramDouble2);
/*       */   
/*       */   private static native boolean nSliderScalarN(String paramString1, double[] paramArrayOfdouble, int paramInt, double paramDouble1, double paramDouble2, String paramString2);
/*       */   
/*       */   private static native boolean nSliderScalarN(String paramString1, double[] paramArrayOfdouble, int paramInt1, double paramDouble1, double paramDouble2, String paramString2, int paramInt2);
/*       */   
/*       */   private static native boolean nVSliderFloat(String paramString, float paramFloat1, float paramFloat2, float[] paramArrayOffloat, float paramFloat3, float paramFloat4);
/*       */   
/*       */   private static native boolean nVSliderFloat(String paramString1, float paramFloat1, float paramFloat2, float[] paramArrayOffloat, float paramFloat3, float paramFloat4, String paramString2);
/*       */   
/*       */   private static native boolean nVSliderFloat(String paramString1, float paramFloat1, float paramFloat2, float[] paramArrayOffloat, float paramFloat3, float paramFloat4, String paramString2, int paramInt);
/*       */   
/*       */   private static native boolean nVSliderFloat(String paramString, float paramFloat1, float paramFloat2, float[] paramArrayOffloat, float paramFloat3, float paramFloat4, int paramInt);
/*       */   
/*       */   private static native boolean nVSliderInt(String paramString, float paramFloat1, float paramFloat2, int[] paramArrayOfint, int paramInt1, int paramInt2);
/*       */   
/*       */   private static native boolean nVSliderInt(String paramString1, float paramFloat1, float paramFloat2, int[] paramArrayOfint, int paramInt1, int paramInt2, String paramString2);
/*       */   
/*       */   private static native boolean nVSliderInt(String paramString1, float paramFloat1, float paramFloat2, int[] paramArrayOfint, int paramInt1, int paramInt2, String paramString2, int paramInt3);
/*       */   
/*       */   private static native boolean nVSliderInt(String paramString, float paramFloat1, float paramFloat2, int[] paramArrayOfint, int paramInt1, int paramInt2, int paramInt3);
/*       */   
/*       */   private static native boolean nVSliderScalar(String paramString, float paramFloat1, float paramFloat2, short[] paramArrayOfshort, short paramShort1, short paramShort2);
/*       */   
/*       */   private static native boolean nVSliderScalar(String paramString1, float paramFloat1, float paramFloat2, short[] paramArrayOfshort, short paramShort1, short paramShort2, String paramString2);
/*       */   
/*       */   private static native boolean nVSliderScalar(String paramString1, float paramFloat1, float paramFloat2, short[] paramArrayOfshort, short paramShort1, short paramShort2, String paramString2, int paramInt);
/*       */   
/*       */   private static native boolean nVSliderScalar(String paramString, float paramFloat1, float paramFloat2, int[] paramArrayOfint, int paramInt1, int paramInt2);
/*       */   
/*       */   private static native boolean nVSliderScalar(String paramString1, float paramFloat1, float paramFloat2, int[] paramArrayOfint, int paramInt1, int paramInt2, String paramString2);
/*       */   
/*       */   private static native boolean nVSliderScalar(String paramString1, float paramFloat1, float paramFloat2, int[] paramArrayOfint, int paramInt1, int paramInt2, String paramString2, int paramInt3);
/*       */   
/*       */   private static native boolean nVSliderScalar(String paramString, float paramFloat1, float paramFloat2, long[] paramArrayOflong, long paramLong1, long paramLong2);
/*       */   
/*       */   private static native boolean nVSliderScalar(String paramString1, float paramFloat1, float paramFloat2, long[] paramArrayOflong, long paramLong1, long paramLong2, String paramString2);
/*       */   
/*       */   private static native boolean nVSliderScalar(String paramString1, float paramFloat1, float paramFloat2, long[] paramArrayOflong, long paramLong1, long paramLong2, String paramString2, int paramInt);
/*       */   
/*       */   private static native boolean nVSliderScalar(String paramString, float paramFloat1, float paramFloat2, float[] paramArrayOffloat, float paramFloat3, float paramFloat4);
/*       */   
/*       */   private static native boolean nVSliderScalar(String paramString1, float paramFloat1, float paramFloat2, float[] paramArrayOffloat, float paramFloat3, float paramFloat4, String paramString2);
/*       */   
/*       */   private static native boolean nVSliderScalar(String paramString1, float paramFloat1, float paramFloat2, float[] paramArrayOffloat, float paramFloat3, float paramFloat4, String paramString2, int paramInt);
/*       */   
/*       */   private static native boolean nVSliderScalar(String paramString, float paramFloat1, float paramFloat2, double[] paramArrayOfdouble, double paramDouble1, double paramDouble2);
/*       */   
/*       */   private static native boolean nVSliderScalar(String paramString1, float paramFloat1, float paramFloat2, double[] paramArrayOfdouble, double paramDouble1, double paramDouble2, String paramString2);
/*       */   
/*       */   private static native boolean nVSliderScalar(String paramString1, float paramFloat1, float paramFloat2, double[] paramArrayOfdouble, double paramDouble1, double paramDouble2, String paramString2, int paramInt);
/*       */   
/*       */   private static native void nInitInputTextData();
/*       */   
/*       */   private static native boolean nInputText(boolean paramBoolean1, boolean paramBoolean2, String paramString1, String paramString2, ImString paramImString, byte[] paramArrayOfbyte, int paramInt1, float paramFloat1, float paramFloat2, int paramInt2, ImString.InputData paramInputData, String paramString3, boolean paramBoolean3, ImGuiInputTextCallback paramImGuiInputTextCallback);
/*       */   
/*       */   private static native boolean nInputFloat(String paramString, float[] paramArrayOffloat);
/*       */   
/*       */   private static native boolean nInputFloat(String paramString, float[] paramArrayOffloat, float paramFloat);
/*       */   
/*       */   private static native boolean nInputFloat(String paramString, float[] paramArrayOffloat, float paramFloat1, float paramFloat2);
/*       */   
/*       */   private static native boolean nInputFloat(String paramString1, float[] paramArrayOffloat, float paramFloat1, float paramFloat2, String paramString2);
/*       */   
/*       */   private static native boolean nInputFloat(String paramString1, float[] paramArrayOffloat, float paramFloat1, float paramFloat2, String paramString2, int paramInt);
/*       */   
/*       */   private static native boolean nInputFloat(String paramString, float[] paramArrayOffloat, float paramFloat1, float paramFloat2, int paramInt);
/*       */   
/*       */   private static native boolean nInputFloat2(String paramString, float[] paramArrayOffloat);
/*       */   
/*       */   private static native boolean nInputFloat2(String paramString1, float[] paramArrayOffloat, String paramString2);
/*       */   
/*       */   private static native boolean nInputFloat2(String paramString1, float[] paramArrayOffloat, String paramString2, int paramInt);
/*       */   
/*       */   private static native boolean nInputFloat2(String paramString, float[] paramArrayOffloat, int paramInt);
/*       */   
/*       */   private static native boolean nInputFloat3(String paramString, float[] paramArrayOffloat);
/*       */   
/*       */   private static native boolean nInputFloat3(String paramString1, float[] paramArrayOffloat, String paramString2);
/*       */   
/*       */   private static native boolean nInputFloat3(String paramString1, float[] paramArrayOffloat, String paramString2, int paramInt);
/*       */   
/*       */   private static native boolean nInputFloat3(String paramString, float[] paramArrayOffloat, int paramInt);
/*       */   
/*       */   private static native boolean nInputFloat4(String paramString, float[] paramArrayOffloat);
/*       */   
/*       */   private static native boolean nInputFloat4(String paramString1, float[] paramArrayOffloat, String paramString2);
/*       */   
/*       */   private static native boolean nInputFloat4(String paramString1, float[] paramArrayOffloat, String paramString2, int paramInt);
/*       */   
/*       */   private static native boolean nInputFloat4(String paramString, float[] paramArrayOffloat, int paramInt);
/*       */   
/*       */   private static native boolean nInputInt(String paramString, int[] paramArrayOfint);
/*       */   
/*       */   private static native boolean nInputInt(String paramString, int[] paramArrayOfint, int paramInt);
/*       */   
/*       */   private static native boolean nInputInt(String paramString, int[] paramArrayOfint, int paramInt1, int paramInt2);
/*       */   
/*       */   private static native boolean nInputInt(String paramString, int[] paramArrayOfint, int paramInt1, int paramInt2, int paramInt3);
/*       */   
/*       */   private static native boolean nInputInt2(String paramString, int[] paramArrayOfint);
/*       */   
/*       */   private static native boolean nInputInt2(String paramString, int[] paramArrayOfint, int paramInt);
/*       */   
/*       */   private static native boolean nInputInt3(String paramString, int[] paramArrayOfint);
/*       */   
/*       */   private static native boolean nInputInt3(String paramString, int[] paramArrayOfint, int paramInt);
/*       */   
/*       */   private static native boolean nInputInt4(String paramString, int[] paramArrayOfint);
/*       */   
/*       */   private static native boolean nInputInt4(String paramString, int[] paramArrayOfint, int paramInt);
/*       */   
/*       */   private static native boolean nInputDouble(String paramString, double[] paramArrayOfdouble);
/*       */   
/*       */   private static native boolean nInputDouble(String paramString, double[] paramArrayOfdouble, double paramDouble);
/*       */   
/*       */   private static native boolean nInputDouble(String paramString, double[] paramArrayOfdouble, double paramDouble1, double paramDouble2);
/*       */   
/*       */   private static native boolean nInputDouble(String paramString1, double[] paramArrayOfdouble, double paramDouble1, double paramDouble2, String paramString2);
/*       */   
/*       */   private static native boolean nInputDouble(String paramString1, double[] paramArrayOfdouble, double paramDouble1, double paramDouble2, String paramString2, int paramInt);
/*       */   
/*       */   private static native boolean nInputDouble(String paramString, double[] paramArrayOfdouble, double paramDouble1, double paramDouble2, int paramInt);
/*       */   
/*       */   private static native boolean nInputScalar(String paramString, short[] paramArrayOfshort);
/*       */   
/*       */   private static native boolean nInputScalar(String paramString, short[] paramArrayOfshort, short paramShort);
/*       */   
/*       */   private static native boolean nInputScalar(String paramString, short[] paramArrayOfshort, short paramShort1, short paramShort2);
/*       */   
/*       */   private static native boolean nInputScalar(String paramString1, short[] paramArrayOfshort, short paramShort1, short paramShort2, String paramString2);
/*       */   
/*       */   private static native boolean nInputScalar(String paramString1, short[] paramArrayOfshort, short paramShort1, short paramShort2, String paramString2, int paramInt);
/*       */   
/*       */   private static native boolean nInputScalar(String paramString, int[] paramArrayOfint);
/*       */   
/*       */   private static native boolean nInputScalar(String paramString, int[] paramArrayOfint, int paramInt);
/*       */   
/*       */   private static native boolean nInputScalar(String paramString, int[] paramArrayOfint, int paramInt1, int paramInt2);
/*       */   
/*       */   private static native boolean nInputScalar(String paramString1, int[] paramArrayOfint, int paramInt1, int paramInt2, String paramString2);
/*       */   
/*       */   private static native boolean nInputScalar(String paramString1, int[] paramArrayOfint, int paramInt1, int paramInt2, String paramString2, int paramInt3);
/*       */   
/*       */   private static native boolean nInputScalar(String paramString, long[] paramArrayOflong);
/*       */   
/*       */   private static native boolean nInputScalar(String paramString, long[] paramArrayOflong, long paramLong);
/*       */   
/*       */   private static native boolean nInputScalar(String paramString, long[] paramArrayOflong, long paramLong1, long paramLong2);
/*       */   
/*       */   private static native boolean nInputScalar(String paramString1, long[] paramArrayOflong, long paramLong1, long paramLong2, String paramString2);
/*       */   
/*       */   private static native boolean nInputScalar(String paramString1, long[] paramArrayOflong, long paramLong1, long paramLong2, String paramString2, int paramInt);
/*       */   
/*       */   private static native boolean nInputScalar(String paramString, float[] paramArrayOffloat);
/*       */   
/*       */   private static native boolean nInputScalar(String paramString, float[] paramArrayOffloat, float paramFloat);
/*       */   
/*       */   private static native boolean nInputScalar(String paramString, float[] paramArrayOffloat, float paramFloat1, float paramFloat2);
/*       */   
/*       */   private static native boolean nInputScalar(String paramString1, float[] paramArrayOffloat, float paramFloat1, float paramFloat2, String paramString2);
/*       */   
/*       */   private static native boolean nInputScalar(String paramString1, float[] paramArrayOffloat, float paramFloat1, float paramFloat2, String paramString2, int paramInt);
/*       */   
/*       */   private static native boolean nInputScalar(String paramString, double[] paramArrayOfdouble);
/*       */   
/*       */   private static native boolean nInputScalar(String paramString, double[] paramArrayOfdouble, double paramDouble);
/*       */   
/*       */   private static native boolean nInputScalar(String paramString, double[] paramArrayOfdouble, double paramDouble1, double paramDouble2);
/*       */   
/*       */   private static native boolean nInputScalar(String paramString1, double[] paramArrayOfdouble, double paramDouble1, double paramDouble2, String paramString2);
/*       */   
/*       */   private static native boolean nInputScalar(String paramString1, double[] paramArrayOfdouble, double paramDouble1, double paramDouble2, String paramString2, int paramInt);
/*       */   
/*       */   private static native boolean nInputScalar(String paramString, int paramInt, short[] paramArrayOfshort);
/*       */   
/*       */   private static native boolean nInputScalar(String paramString, int paramInt, short[] paramArrayOfshort, short paramShort);
/*       */   
/*       */   private static native boolean nInputScalar(String paramString, int paramInt, short[] paramArrayOfshort, short paramShort1, short paramShort2);
/*       */   
/*       */   private static native boolean nInputScalar(String paramString1, int paramInt, short[] paramArrayOfshort, short paramShort1, short paramShort2, String paramString2);
/*       */   
/*       */   private static native boolean nInputScalar(String paramString1, int paramInt1, short[] paramArrayOfshort, short paramShort1, short paramShort2, String paramString2, int paramInt2);
/*       */   
/*       */   private static native boolean nInputScalar(String paramString, int paramInt, int[] paramArrayOfint);
/*       */   
/*       */   private static native boolean nInputScalar(String paramString, int paramInt1, int[] paramArrayOfint, int paramInt2);
/*       */   
/*       */   private static native boolean nInputScalar(String paramString, int paramInt1, int[] paramArrayOfint, int paramInt2, int paramInt3);
/*       */   
/*       */   private static native boolean nInputScalar(String paramString1, int paramInt1, int[] paramArrayOfint, int paramInt2, int paramInt3, String paramString2);
/*       */   
/*       */   private static native boolean nInputScalar(String paramString1, int paramInt1, int[] paramArrayOfint, int paramInt2, int paramInt3, String paramString2, int paramInt4);
/*       */   
/*       */   private static native boolean nInputScalar(String paramString, int paramInt, long[] paramArrayOflong);
/*       */   
/*       */   private static native boolean nInputScalar(String paramString, int paramInt, long[] paramArrayOflong, long paramLong);
/*       */   
/*       */   private static native boolean nInputScalar(String paramString, int paramInt, long[] paramArrayOflong, long paramLong1, long paramLong2);
/*       */   
/*       */   private static native boolean nInputScalar(String paramString1, int paramInt, long[] paramArrayOflong, long paramLong1, long paramLong2, String paramString2);
/*       */   
/*       */   private static native boolean nInputScalar(String paramString1, int paramInt1, long[] paramArrayOflong, long paramLong1, long paramLong2, String paramString2, int paramInt2);
/*       */   
/*       */   private static native boolean nInputScalar(String paramString, int paramInt, float[] paramArrayOffloat);
/*       */   
/*       */   private static native boolean nInputScalar(String paramString, int paramInt, float[] paramArrayOffloat, float paramFloat);
/*       */   
/*       */   private static native boolean nInputScalar(String paramString, int paramInt, float[] paramArrayOffloat, float paramFloat1, float paramFloat2);
/*       */   
/*       */   private static native boolean nInputScalar(String paramString1, int paramInt, float[] paramArrayOffloat, float paramFloat1, float paramFloat2, String paramString2);
/*       */   
/*       */   private static native boolean nInputScalar(String paramString1, int paramInt1, float[] paramArrayOffloat, float paramFloat1, float paramFloat2, String paramString2, int paramInt2);
/*       */   
/*       */   private static native boolean nInputScalar(String paramString, int paramInt, double[] paramArrayOfdouble);
/*       */   
/*       */   private static native boolean nInputScalar(String paramString, int paramInt, double[] paramArrayOfdouble, double paramDouble);
/*       */   
/*       */   private static native boolean nInputScalar(String paramString, int paramInt, double[] paramArrayOfdouble, double paramDouble1, double paramDouble2);
/*       */   
/*       */   private static native boolean nInputScalar(String paramString1, int paramInt, double[] paramArrayOfdouble, double paramDouble1, double paramDouble2, String paramString2);
/*       */   
/*       */   private static native boolean nInputScalar(String paramString1, int paramInt1, double[] paramArrayOfdouble, double paramDouble1, double paramDouble2, String paramString2, int paramInt2);
/*       */   
/*       */   private static native boolean nInputScalarN(String paramString, short[] paramArrayOfshort, int paramInt);
/*       */   
/*       */   private static native boolean nInputScalarN(String paramString, short[] paramArrayOfshort, int paramInt, short paramShort);
/*       */   
/*       */   private static native boolean nInputScalarN(String paramString, short[] paramArrayOfshort, int paramInt, short paramShort1, short paramShort2);
/*       */   
/*       */   private static native boolean nInputScalarN(String paramString1, short[] paramArrayOfshort, int paramInt, short paramShort1, short paramShort2, String paramString2);
/*       */   
/*       */   private static native boolean nInputScalarN(String paramString1, short[] paramArrayOfshort, int paramInt1, short paramShort1, short paramShort2, String paramString2, int paramInt2);
/*       */   
/*       */   private static native boolean nInputScalarN(String paramString, int[] paramArrayOfint, int paramInt);
/*       */   
/*       */   private static native boolean nInputScalarN(String paramString, int[] paramArrayOfint, int paramInt1, int paramInt2);
/*       */   
/*       */   private static native boolean nInputScalarN(String paramString, int[] paramArrayOfint, int paramInt1, int paramInt2, int paramInt3);
/*       */   
/*       */   private static native boolean nInputScalarN(String paramString1, int[] paramArrayOfint, int paramInt1, int paramInt2, int paramInt3, String paramString2);
/*       */   
/*       */   private static native boolean nInputScalarN(String paramString1, int[] paramArrayOfint, int paramInt1, int paramInt2, int paramInt3, String paramString2, int paramInt4);
/*       */   
/*       */   private static native boolean nInputScalarN(String paramString, long[] paramArrayOflong, int paramInt);
/*       */   
/*       */   private static native boolean nInputScalarN(String paramString, long[] paramArrayOflong, int paramInt, long paramLong);
/*       */   
/*       */   private static native boolean nInputScalarN(String paramString, long[] paramArrayOflong, int paramInt, long paramLong1, long paramLong2);
/*       */   
/*       */   private static native boolean nInputScalarN(String paramString1, long[] paramArrayOflong, int paramInt, long paramLong1, long paramLong2, String paramString2);
/*       */   
/*       */   private static native boolean nInputScalarN(String paramString1, long[] paramArrayOflong, int paramInt1, long paramLong1, long paramLong2, String paramString2, int paramInt2);
/*       */   
/*       */   private static native boolean nInputScalarN(String paramString, float[] paramArrayOffloat, int paramInt);
/*       */   
/*       */   private static native boolean nInputScalarN(String paramString, float[] paramArrayOffloat, int paramInt, float paramFloat);
/*       */   
/*       */   private static native boolean nInputScalarN(String paramString, float[] paramArrayOffloat, int paramInt, float paramFloat1, float paramFloat2);
/*       */   
/*       */   private static native boolean nInputScalarN(String paramString1, float[] paramArrayOffloat, int paramInt, float paramFloat1, float paramFloat2, String paramString2);
/*       */   
/*       */   private static native boolean nInputScalarN(String paramString1, float[] paramArrayOffloat, int paramInt1, float paramFloat1, float paramFloat2, String paramString2, int paramInt2);
/*       */   
/*       */   private static native boolean nInputScalarN(String paramString, double[] paramArrayOfdouble, int paramInt);
/*       */   
/*       */   private static native boolean nInputScalarN(String paramString, double[] paramArrayOfdouble, int paramInt, double paramDouble);
/*       */   
/*       */   private static native boolean nInputScalarN(String paramString, double[] paramArrayOfdouble, int paramInt, double paramDouble1, double paramDouble2);
/*       */   
/*       */   private static native boolean nInputScalarN(String paramString1, double[] paramArrayOfdouble, int paramInt, double paramDouble1, double paramDouble2, String paramString2);
/*       */   
/*       */   private static native boolean nInputScalarN(String paramString1, double[] paramArrayOfdouble, int paramInt1, double paramDouble1, double paramDouble2, String paramString2, int paramInt2);
/*       */   
/*       */   private static native boolean nInputScalarN(String paramString, int paramInt1, short[] paramArrayOfshort, int paramInt2);
/*       */   
/*       */   private static native boolean nInputScalarN(String paramString, int paramInt1, short[] paramArrayOfshort, int paramInt2, short paramShort);
/*       */   
/*       */   private static native boolean nInputScalarN(String paramString, int paramInt1, short[] paramArrayOfshort, int paramInt2, short paramShort1, short paramShort2);
/*       */   
/*       */   private static native boolean nInputScalarN(String paramString1, int paramInt1, short[] paramArrayOfshort, int paramInt2, short paramShort1, short paramShort2, String paramString2);
/*       */   
/*       */   private static native boolean nInputScalarN(String paramString1, int paramInt1, short[] paramArrayOfshort, int paramInt2, short paramShort1, short paramShort2, String paramString2, int paramInt3);
/*       */   
/*       */   private static native boolean nInputScalarN(String paramString, int paramInt1, int[] paramArrayOfint, int paramInt2);
/*       */   
/*       */   private static native boolean nInputScalarN(String paramString, int paramInt1, int[] paramArrayOfint, int paramInt2, int paramInt3);
/*       */   
/*       */   private static native boolean nInputScalarN(String paramString, int paramInt1, int[] paramArrayOfint, int paramInt2, int paramInt3, int paramInt4);
/*       */   
/*       */   private static native boolean nInputScalarN(String paramString1, int paramInt1, int[] paramArrayOfint, int paramInt2, int paramInt3, int paramInt4, String paramString2);
/*       */   
/*       */   private static native boolean nInputScalarN(String paramString1, int paramInt1, int[] paramArrayOfint, int paramInt2, int paramInt3, int paramInt4, String paramString2, int paramInt5);
/*       */   
/*       */   private static native boolean nInputScalarN(String paramString, int paramInt1, long[] paramArrayOflong, int paramInt2);
/*       */   
/*       */   private static native boolean nInputScalarN(String paramString, int paramInt1, long[] paramArrayOflong, int paramInt2, long paramLong);
/*       */   
/*       */   private static native boolean nInputScalarN(String paramString, int paramInt1, long[] paramArrayOflong, int paramInt2, long paramLong1, long paramLong2);
/*       */   
/*       */   private static native boolean nInputScalarN(String paramString1, int paramInt1, long[] paramArrayOflong, int paramInt2, long paramLong1, long paramLong2, String paramString2);
/*       */   
/*       */   private static native boolean nInputScalarN(String paramString1, int paramInt1, long[] paramArrayOflong, int paramInt2, long paramLong1, long paramLong2, String paramString2, int paramInt3);
/*       */   
/*       */   private static native boolean nInputScalarN(String paramString, int paramInt1, float[] paramArrayOffloat, int paramInt2);
/*       */   
/*       */   private static native boolean nInputScalarN(String paramString, int paramInt1, float[] paramArrayOffloat, int paramInt2, float paramFloat);
/*       */   
/*       */   private static native boolean nInputScalarN(String paramString, int paramInt1, float[] paramArrayOffloat, int paramInt2, float paramFloat1, float paramFloat2);
/*       */   
/*       */   private static native boolean nInputScalarN(String paramString1, int paramInt1, float[] paramArrayOffloat, int paramInt2, float paramFloat1, float paramFloat2, String paramString2);
/*       */   
/*       */   private static native boolean nInputScalarN(String paramString1, int paramInt1, float[] paramArrayOffloat, int paramInt2, float paramFloat1, float paramFloat2, String paramString2, int paramInt3);
/*       */   
/*       */   private static native boolean nInputScalarN(String paramString, int paramInt1, double[] paramArrayOfdouble, int paramInt2);
/*       */   
/*       */   private static native boolean nInputScalarN(String paramString, int paramInt1, double[] paramArrayOfdouble, int paramInt2, double paramDouble);
/*       */   
/*       */   private static native boolean nInputScalarN(String paramString, int paramInt1, double[] paramArrayOfdouble, int paramInt2, double paramDouble1, double paramDouble2);
/*       */   
/*       */   private static native boolean nInputScalarN(String paramString1, int paramInt1, double[] paramArrayOfdouble, int paramInt2, double paramDouble1, double paramDouble2, String paramString2);
/*       */   
/*       */   private static native boolean nInputScalarN(String paramString1, int paramInt1, double[] paramArrayOfdouble, int paramInt2, double paramDouble1, double paramDouble2, String paramString2, int paramInt3);
/*       */   
/*       */   private static native boolean nColorEdit3(String paramString, float[] paramArrayOffloat);
/*       */   
/*       */   private static native boolean nColorEdit3(String paramString, float[] paramArrayOffloat, int paramInt);
/*       */   
/*       */   private static native boolean nColorEdit4(String paramString, float[] paramArrayOffloat);
/*       */   
/*       */   private static native boolean nColorEdit4(String paramString, float[] paramArrayOffloat, int paramInt);
/*       */   
/*       */   private static native boolean nColorPicker3(String paramString, float[] paramArrayOffloat);
/*       */   
/*       */   private static native boolean nColorPicker3(String paramString, float[] paramArrayOffloat, int paramInt);
/*       */   
/*       */   private static native boolean nColorPicker4(String paramString, float[] paramArrayOffloat);
/*       */   
/*       */   private static native boolean nColorPicker4(String paramString, float[] paramArrayOffloat, int paramInt);
/*       */   
/*       */   private static native boolean nColorPicker4(String paramString, float[] paramArrayOffloat1, int paramInt, float[] paramArrayOffloat2);
/*       */   
/*       */   private static native boolean nColorPicker4(String paramString, float[] paramArrayOffloat1, float[] paramArrayOffloat2);
/*       */   
/*       */   private static native boolean nColorButton(String paramString, float paramFloat1, float paramFloat2, float paramFloat3, float paramFloat4);
/*       */   
/*       */   private static native boolean nColorButton(String paramString, float paramFloat1, float paramFloat2, float paramFloat3, float paramFloat4, int paramInt);
/*       */   
/*       */   private static native boolean nColorButton(String paramString, float paramFloat1, float paramFloat2, float paramFloat3, float paramFloat4, int paramInt, float paramFloat5, float paramFloat6);
/*       */   
/*       */   private static native boolean nColorButton(String paramString, float paramFloat1, float paramFloat2, float paramFloat3, float paramFloat4, float paramFloat5, float paramFloat6);
/*       */   
/*       */   private static native boolean nColorButton(String paramString, float[] paramArrayOffloat);
/*       */   
/*       */   private static native boolean nColorButton(String paramString, float[] paramArrayOffloat, int paramInt);
/*       */   
/*       */   private static native boolean nColorButton(String paramString, float[] paramArrayOffloat, int paramInt, float paramFloat1, float paramFloat2);
/*       */   
/*       */   private static native boolean nColorButton(String paramString, float[] paramArrayOffloat, float paramFloat1, float paramFloat2);
/*       */   
/*       */   private static native void nSetColorEditOptions(int paramInt);
/*       */   
/*       */   private static native boolean nTreeNode(String paramString);
/*       */   
/*       */   private static native boolean nTreeNode(String paramString1, String paramString2);
/*       */   
/*       */   private static native boolean nTreeNode(long paramLong, String paramString);
/*       */   
/*       */   private static native boolean nTreeNodeEx(String paramString);
/*       */   
/*       */   private static native boolean nTreeNodeEx(String paramString, int paramInt);
/*       */   
/*       */   private static native boolean nTreeNodeEx(String paramString1, int paramInt, String paramString2);
/*       */   
/*       */   private static native boolean nTreeNodeEx(long paramLong, int paramInt, String paramString);
/*       */   
/*       */   private static native void nTreePush(String paramString);
/*       */   
/*       */   private static native void nTreePush(long paramLong);
/*       */   
/*       */   private static native void nTreePop();
/*       */   
/*       */   private static native float nGetTreeNodeToLabelSpacing();
/*       */   
/*       */   private static native boolean nCollapsingHeader(String paramString);
/*       */   
/*       */   private static native boolean nCollapsingHeader(String paramString, int paramInt);
/*       */   
/*       */   private static native boolean nCollapsingHeader(String paramString, boolean[] paramArrayOfboolean);
/*       */   
/*       */   private static native boolean nCollapsingHeader(String paramString, boolean[] paramArrayOfboolean, int paramInt);
/*       */   
/*       */   private static native void nSetNextItemOpen(boolean paramBoolean);
/*       */   
/*       */   private static native void nSetNextItemOpen(boolean paramBoolean, int paramInt);
/*       */   
/*       */   private static native boolean nSelectable(String paramString);
/*       */   
/*       */   private static native boolean nSelectable(String paramString, boolean paramBoolean);
/*       */   
/*       */   private static native boolean nSelectable(String paramString, boolean paramBoolean, int paramInt);
/*       */   
/*       */   private static native boolean nSelectable(String paramString, boolean paramBoolean, int paramInt, float paramFloat1, float paramFloat2);
/*       */   
/*       */   private static native boolean nSelectable(String paramString, int paramInt, float paramFloat1, float paramFloat2);
/*       */   
/*       */   private static native boolean nSelectable(String paramString, float paramFloat1, float paramFloat2);
/*       */   
/*       */   private static native boolean nSelectable(String paramString, boolean paramBoolean, float paramFloat1, float paramFloat2);
/*       */   
/*       */   private static native boolean nSelectable(String paramString, boolean[] paramArrayOfboolean);
/*       */   
/*       */   private static native boolean nSelectable(String paramString, boolean[] paramArrayOfboolean, int paramInt);
/*       */   
/*       */   private static native boolean nSelectable(String paramString, boolean[] paramArrayOfboolean, int paramInt, float paramFloat1, float paramFloat2);
/*       */   
/*       */   private static native boolean nSelectable(String paramString, boolean[] paramArrayOfboolean, float paramFloat1, float paramFloat2);
/*       */   
/*       */   private static native boolean nBeginListBox(String paramString);
/*       */   
/*       */   private static native boolean nBeginListBox(String paramString, float paramFloat1, float paramFloat2);
/*       */   
/*       */   private static native void nEndListBox();
/*       */   
/*       */   private static native void nListBox(String paramString, int[] paramArrayOfint, String[] paramArrayOfString, int paramInt);
/*       */   
/*       */   private static native void nListBox(String paramString, int[] paramArrayOfint, String[] paramArrayOfString, int paramInt1, int paramInt2);
/*       */   
/*       */   private static native void nPlotLines(String paramString, float[] paramArrayOffloat, int paramInt);
/*       */   
/*       */   private static native void nPlotLines(String paramString, float[] paramArrayOffloat, int paramInt1, int paramInt2);
/*       */   
/*       */   private static native void nPlotLines(String paramString1, float[] paramArrayOffloat, int paramInt1, int paramInt2, String paramString2);
/*       */   
/*       */   private static native void nPlotLines(String paramString1, float[] paramArrayOffloat, int paramInt1, int paramInt2, String paramString2, float paramFloat);
/*       */   
/*       */   private static native void nPlotLines(String paramString1, float[] paramArrayOffloat, int paramInt1, int paramInt2, String paramString2, float paramFloat1, float paramFloat2);
/*       */   
/*       */   private static native void nPlotLines(String paramString1, float[] paramArrayOffloat, int paramInt1, int paramInt2, String paramString2, float paramFloat1, float paramFloat2, float paramFloat3, float paramFloat4);
/*       */   
/*       */   private static native void nPlotLines(String paramString1, float[] paramArrayOffloat, int paramInt1, int paramInt2, String paramString2, float paramFloat1, float paramFloat2, float paramFloat3, float paramFloat4, int paramInt3);
/*       */   
/*       */   private static native void nPlotLines(String paramString1, float[] paramArrayOffloat, int paramInt1, String paramString2, float paramFloat1, float paramFloat2, float paramFloat3, float paramFloat4, int paramInt2);
/*       */   
/*       */   private static native void nPlotLines(String paramString, float[] paramArrayOffloat, int paramInt1, float paramFloat1, float paramFloat2, float paramFloat3, float paramFloat4, int paramInt2);
/*       */   
/*       */   private static native void nPlotLines(String paramString, float[] paramArrayOffloat, int paramInt1, int paramInt2, float paramFloat1, float paramFloat2, float paramFloat3, float paramFloat4, int paramInt3);
/*       */   
/*       */   private static native void nPlotLines(String paramString1, float[] paramArrayOffloat, int paramInt1, int paramInt2, String paramString2, float paramFloat1, float paramFloat2, int paramInt3);
/*       */   
/*       */   private static native void nPlotHistogram(String paramString, float[] paramArrayOffloat, int paramInt);
/*       */   
/*       */   private static native void nPlotHistogram(String paramString, float[] paramArrayOffloat, int paramInt1, int paramInt2);
/*       */   
/*       */   private static native void nPlotHistogram(String paramString1, float[] paramArrayOffloat, int paramInt1, int paramInt2, String paramString2);
/*       */   
/*       */   private static native void nPlotHistogram(String paramString1, float[] paramArrayOffloat, int paramInt1, int paramInt2, String paramString2, float paramFloat);
/*       */   
/*       */   private static native void nPlotHistogram(String paramString1, float[] paramArrayOffloat, int paramInt1, int paramInt2, String paramString2, float paramFloat1, float paramFloat2);
/*       */   
/*       */   private static native void nPlotHistogram(String paramString1, float[] paramArrayOffloat, int paramInt1, int paramInt2, String paramString2, float paramFloat1, float paramFloat2, float paramFloat3, float paramFloat4);
/*       */   
/*       */   private static native void nPlotHistogram(String paramString1, float[] paramArrayOffloat, int paramInt1, int paramInt2, String paramString2, float paramFloat1, float paramFloat2, float paramFloat3, float paramFloat4, int paramInt3);
/*       */   
/*       */   private static native void nPlotHistogram(String paramString1, float[] paramArrayOffloat, int paramInt1, String paramString2, float paramFloat1, float paramFloat2, float paramFloat3, float paramFloat4, int paramInt2);
/*       */   
/*       */   private static native void nPlotHistogram(String paramString, float[] paramArrayOffloat, int paramInt1, float paramFloat1, float paramFloat2, float paramFloat3, float paramFloat4, int paramInt2);
/*       */   
/*       */   private static native void nPlotHistogram(String paramString, float[] paramArrayOffloat, int paramInt1, int paramInt2, float paramFloat1, float paramFloat2, float paramFloat3, float paramFloat4, int paramInt3);
/*       */   
/*       */   private static native void nPlotHistogram(String paramString1, float[] paramArrayOffloat, int paramInt1, int paramInt2, String paramString2, float paramFloat1, float paramFloat2, int paramInt3);
/*       */   
/*       */   private static native void nValue(String paramString1, String paramString2);
/*       */   
/*       */   private static native boolean nBeginMenuBar();
/*       */   
/*       */   private static native void nEndMenuBar();
/*       */   
/*       */   private static native boolean nBeginMainMenuBar();
/*       */   
/*       */   private static native void nEndMainMenuBar();
/*       */   
/*       */   private static native boolean nBeginMenu(String paramString);
/*       */   
/*       */   private static native boolean nBeginMenu(String paramString, boolean paramBoolean);
/*       */   
/*       */   private static native void nEndMenu();
/*       */   
/*       */   private static native boolean nMenuItem(String paramString);
/*       */   
/*       */   private static native boolean nMenuItem(String paramString, boolean paramBoolean);
/*       */   
/*       */   private static native boolean nMenuItem(String paramString, boolean paramBoolean1, boolean paramBoolean2);
/*       */   
/*       */   private static native boolean nMenuItem(String paramString1, String paramString2);
/*       */   
/*       */   private static native boolean nMenuItem(String paramString1, String paramString2, boolean paramBoolean);
/*       */   
/*       */   private static native boolean nMenuItem(String paramString1, String paramString2, boolean paramBoolean1, boolean paramBoolean2);
/*       */   
/*       */   private static native boolean nMenuItem(String paramString1, String paramString2, boolean[] paramArrayOfboolean);
/*       */   
/*       */   private static native boolean nMenuItem(String paramString1, String paramString2, boolean[] paramArrayOfboolean, boolean paramBoolean);
/*       */   
/*       */   private static native void nBeginTooltip();
/*       */   
/*       */   private static native void nEndTooltip();
/*       */   
/*       */   private static native void nSetTooltip(String paramString);
/*       */   
/*       */   private static native boolean nBeginItemTooltip();
/*       */   
/*       */   private static native void nSetItemTooltip(String paramString);
/*       */   
/*       */   private static native boolean nBeginPopup(String paramString);
/*       */   
/*       */   private static native boolean nBeginPopup(String paramString, int paramInt);
/*       */   
/*       */   private static native boolean nBeginPopupModal(String paramString);
/*       */   
/*       */   private static native boolean nBeginPopupModal(String paramString, boolean[] paramArrayOfboolean);
/*       */   
/*       */   private static native boolean nBeginPopupModal(String paramString, boolean[] paramArrayOfboolean, int paramInt);
/*       */   
/*       */   private static native boolean nBeginPopupModal(String paramString, int paramInt);
/*       */   
/*       */   private static native void nEndPopup();
/*       */   
/*       */   private static native void nOpenPopup(String paramString);
/*       */   
/*       */   private static native void nOpenPopup(String paramString, int paramInt);
/*       */   
/*       */   private static native void nOpenPopup(int paramInt);
/*       */   
/*       */   private static native void nOpenPopup(int paramInt1, int paramInt2);
/*       */   
/*       */   private static native void nOpenPopupOnItemClick();
/*       */   
/*       */   private static native void nOpenPopupOnItemClick(String paramString);
/*       */   
/*       */   private static native void nOpenPopupOnItemClick(String paramString, int paramInt);
/*       */   
/*       */   private static native void nOpenPopupOnItemClick(int paramInt);
/*       */   
/*       */   private static native void nCloseCurrentPopup();
/*       */   
/*       */   private static native boolean nBeginPopupContextItem();
/*       */   
/*       */   private static native boolean nBeginPopupContextItem(String paramString);
/*       */   
/*       */   private static native boolean nBeginPopupContextItem(String paramString, int paramInt);
/*       */   
/*       */   private static native boolean nBeginPopupContextItem(int paramInt);
/*       */   
/*       */   private static native boolean nBeginPopupContextWindow();
/*       */   
/*       */   private static native boolean nBeginPopupContextWindow(String paramString);
/*       */   
/*       */   private static native boolean nBeginPopupContextWindow(String paramString, int paramInt);
/*       */   
/*       */   private static native boolean nBeginPopupContextWindow(int paramInt);
/*       */   
/*       */   private static native boolean nBeginPopupContextVoid();
/*       */   
/*       */   private static native boolean nBeginPopupContextVoid(String paramString);
/*       */   
/*       */   private static native boolean nBeginPopupContextVoid(String paramString, int paramInt);
/*       */   
/*       */   private static native boolean nBeginPopupContextVoid(int paramInt);
/*       */   
/*       */   private static native boolean nIsPopupOpen(String paramString);
/*       */   
/*       */   private static native boolean nIsPopupOpen(String paramString, int paramInt);
/*       */   
/*       */   private static native boolean nBeginTable(String paramString, int paramInt);
/*       */   
/*       */   private static native boolean nBeginTable(String paramString, int paramInt1, int paramInt2);
/*       */   
/*       */   private static native boolean nBeginTable(String paramString, int paramInt1, int paramInt2, float paramFloat1, float paramFloat2);
/*       */   
/*       */   private static native boolean nBeginTable(String paramString, int paramInt1, int paramInt2, float paramFloat1, float paramFloat2, float paramFloat3);
/*       */   
/*       */   private static native boolean nBeginTable(String paramString, int paramInt, float paramFloat1, float paramFloat2, float paramFloat3);
/*       */   
/*       */   private static native boolean nBeginTable(String paramString, int paramInt, float paramFloat);
/*       */   
/*       */   private static native boolean nBeginTable(String paramString, int paramInt1, int paramInt2, float paramFloat);
/*       */   
/*       */   private static native void nEndTable();
/*       */   
/*       */   private static native void nTableNextRow();
/*       */   
/*       */   private static native void nTableNextRow(int paramInt);
/*       */   
/*       */   private static native void nTableNextRow(int paramInt, float paramFloat);
/*       */   
/*       */   private static native void nTableNextRow(float paramFloat);
/*       */   
/*       */   private static native boolean nTableNextColumn();
/*       */   
/*       */   private static native boolean nTableSetColumnIndex(int paramInt);
/*       */   
/*       */   private static native void nTableSetupColumn(String paramString);
/*       */   
/*       */   private static native void nTableSetupColumn(String paramString, int paramInt);
/*       */   
/*       */   private static native void nTableSetupColumn(String paramString, int paramInt, float paramFloat);
/*       */   
/*       */   private static native void nTableSetupColumn(String paramString, int paramInt1, float paramFloat, int paramInt2);
/*       */   
/*       */   private static native void nTableSetupColumn(String paramString, float paramFloat, int paramInt);
/*       */   
/*       */   private static native void nTableSetupColumn(String paramString, int paramInt1, int paramInt2);
/*       */   
/*       */   private static native void nTableSetupScrollFreeze(int paramInt1, int paramInt2);
/*       */   
/*       */   private static native void nTableHeader(String paramString);
/*       */   
/*       */   private static native void nTableHeadersRow();
/*       */   
/*       */   private static native void nTableAngledHeadersRow();
/*       */   
/*       */   private static native long nTableGetSortSpecs();
/*       */   
/*       */   private static native int nTableGetColumnCount();
/*       */   
/*       */   private static native int nTableGetColumnIndex();
/*       */   
/*       */   private static native int nTableGetRowIndex();
/*       */   
/*       */   private static native String nTableGetColumnName();
/*       */   
/*       */   private static native String nTableGetColumnName(int paramInt);
/*       */   
/*       */   private static native int nTableGetColumnFlags();
/*       */   
/*       */   private static native int nTableGetColumnFlags(int paramInt);
/*       */   
/*       */   private static native void nTableSetColumnEnabled(int paramInt, boolean paramBoolean);
/*       */   
/*       */   private static native int nTableGetHoveredColumn();
/*       */   
/*       */   private static native void nTableSetBgColor(int paramInt1, int paramInt2);
/*       */   
/*       */   private static native void nTableSetBgColor(int paramInt1, int paramInt2, int paramInt3);
/*       */   
/*       */   private static native void nColumns();
/*       */   
/*       */   private static native void nColumns(int paramInt);
/*       */   
/*       */   private static native void nColumns(int paramInt, String paramString);
/*       */   
/*       */   private static native void nColumns(int paramInt, String paramString, boolean paramBoolean);
/*       */   
/*       */   private static native void nColumns(String paramString, boolean paramBoolean);
/*       */   
/*       */   private static native void nColumns(boolean paramBoolean);
/*       */   
/*       */   private static native void nColumns(int paramInt, boolean paramBoolean);
/*       */   
/*       */   private static native void nNextColumn();
/*       */   
/*       */   private static native int nGetColumnIndex();
/*       */   
/*       */   private static native float nGetColumnWidth();
/*       */   
/*       */   private static native float nGetColumnWidth(int paramInt);
/*       */   
/*       */   private static native void nSetColumnWidth(int paramInt, float paramFloat);
/*       */   
/*       */   private static native float nGetColumnOffset();
/*       */   
/*       */   private static native float nGetColumnOffset(int paramInt);
/*       */   
/*       */   private static native void nSetColumnOffset(int paramInt, float paramFloat);
/*       */   
/*       */   private static native int nGetColumnsCount();
/*       */   
/*       */   private static native boolean nBeginTabBar(String paramString);
/*       */   
/*       */   private static native boolean nBeginTabBar(String paramString, int paramInt);
/*       */   
/*       */   private static native void nEndTabBar();
/*       */   
/*       */   private static native boolean nBeginTabItem(String paramString);
/*       */   
/*       */   private static native boolean nBeginTabItem(String paramString, boolean[] paramArrayOfboolean);
/*       */   
/*       */   private static native boolean nBeginTabItem(String paramString, boolean[] paramArrayOfboolean, int paramInt);
/*       */   
/*       */   private static native boolean nBeginTabItem(String paramString, int paramInt);
/*       */   
/*       */   private static native void nEndTabItem();
/*       */   
/*       */   private static native boolean nTabItemButton(String paramString);
/*       */   
/*       */   private static native boolean nTabItemButton(String paramString, int paramInt);
/*       */   
/*       */   private static native void nSetTabItemClosed(String paramString);
/*       */   
/*       */   private static native int nDockSpace(int paramInt);
/*       */   
/*       */   private static native int nDockSpace(int paramInt, float paramFloat1, float paramFloat2);
/*       */   
/*       */   private static native int nDockSpace(int paramInt1, float paramFloat1, float paramFloat2, int paramInt2);
/*       */   
/*       */   private static native int nDockSpace(int paramInt1, float paramFloat1, float paramFloat2, int paramInt2, long paramLong);
/*       */   
/*       */   private static native int nDockSpace(int paramInt1, int paramInt2, long paramLong);
/*       */   
/*       */   private static native int nDockSpace(int paramInt, long paramLong);
/*       */   
/*       */   private static native int nDockSpace(int paramInt, float paramFloat1, float paramFloat2, long paramLong);
/*       */   
/*       */   private static native int nDockSpaceOverViewport();
/*       */   
/*       */   private static native int nDockSpaceOverViewport(int paramInt);
/*       */   
/*       */   private static native int nDockSpaceOverViewport(int paramInt, long paramLong);
/*       */   
/*       */   private static native int nDockSpaceOverViewport(int paramInt1, long paramLong, int paramInt2);
/*       */   
/*       */   private static native int nDockSpaceOverViewport(int paramInt1, long paramLong1, int paramInt2, long paramLong2);
/*       */   
/*       */   private static native int nDockSpaceOverViewport(long paramLong1, int paramInt, long paramLong2);
/*       */   
/*       */   private static native int nDockSpaceOverViewport(int paramInt, long paramLong1, long paramLong2);
/*       */   
/*       */   private static native void nSetNextWindowDockID(int paramInt);
/*       */   
/*       */   private static native void nSetNextWindowDockID(int paramInt1, int paramInt2);
/*       */   
/*       */   private static native void nSetNextWindowClass(long paramLong);
/*       */   
/*       */   private static native int nGetWindowDockID();
/*       */   
/*       */   private static native boolean nIsWindowDocked();
/*       */   
/*       */   private static native void nLogToTTY();
/*       */   
/*       */   private static native void nLogToTTY(int paramInt);
/*       */   
/*       */   private static native void nLogToFile();
/*       */   
/*       */   private static native void nLogToFile(int paramInt);
/*       */   
/*       */   private static native void nLogToFile(int paramInt, String paramString);
/*       */   
/*       */   private static native void nLogToFile(String paramString);
/*       */   
/*       */   private static native void nLogToClipboard();
/*       */   
/*       */   private static native void nLogToClipboard(int paramInt);
/*       */   
/*       */   private static native void nLogFinish();
/*       */   
/*       */   private static native void nLogButtons();
/*       */   
/*       */   private static native void nLogText(String paramString);
/*       */   
/*       */   private static native boolean nBeginDragDropSource();
/*       */   
/*       */   private static native boolean nBeginDragDropSource(int paramInt);
/*       */   
/*       */   private static native boolean nSetDragDropPayload(String paramString, byte[] paramArrayOfbyte, int paramInt1, int paramInt2);
/*       */   
/*       */   private static native void nEndDragDropSource();
/*       */   
/*       */   private static native boolean nBeginDragDropTarget();
/*       */   
/*       */   private static native boolean nAcceptDragDropPayload(String paramString, int paramInt);
/*       */   
/*       */   private static native void nEndDragDropTarget();
/*       */   
/*       */   private static native boolean nHasDragDropPayload();
/*       */   
/*       */   private static native boolean nHasDragDropPayload(String paramString);
/*       */   
/*       */   private static native void nBeginDisabled();
/*       */   
/*       */   private static native void nBeginDisabled(boolean paramBoolean);
/*       */   
/*       */   private static native void nEndDisabled();
/*       */   
/*       */   private static native void nPushClipRect(float paramFloat1, float paramFloat2, float paramFloat3, float paramFloat4, boolean paramBoolean);
/*       */   
/*       */   private static native void nPopClipRect();
/*       */   
/*       */   private static native void nSetItemDefaultFocus();
/*       */   
/*       */   private static native void nSetKeyboardFocusHere();
/*       */   
/*       */   private static native void nSetKeyboardFocusHere(int paramInt);
/*       */   
/*       */   private static native void nSetNextItemAllowOverlap();
/*       */   
/*       */   private static native boolean nIsItemHovered();
/*       */   
/*       */   private static native boolean nIsItemHovered(int paramInt);
/*       */   
/*       */   private static native boolean nIsItemActive();
/*       */   
/*       */   private static native boolean nIsItemFocused();
/*       */   
/*       */   private static native boolean nIsItemClicked();
/*       */   
/*       */   private static native boolean nIsItemClicked(int paramInt);
/*       */   
/*       */   private static native boolean nIsItemVisible();
/*       */   
/*       */   private static native boolean nIsItemEdited();
/*       */   
/*       */   private static native boolean nIsItemActivated();
/*       */   
/*       */   private static native boolean nIsItemDeactivated();
/*       */   
/*       */   private static native boolean nIsItemDeactivatedAfterEdit();
/*       */   
/*       */   private static native boolean nIsItemToggledOpen();
/*       */   
/*       */   private static native boolean nIsAnyItemHovered();
/*       */   
/*       */   private static native boolean nIsAnyItemActive();
/*       */   
/*       */   private static native boolean nIsAnyItemFocused();
/*       */   
/*       */   private static native int nGetItemID();
/*       */   
/*       */   private static native void nGetItemRectMin(ImVec2 paramImVec2);
/*       */   
/*       */   private static native float nGetItemRectMinX();
/*       */   
/*       */   private static native float nGetItemRectMinY();
/*       */   
/*       */   private static native void nGetItemRectMax(ImVec2 paramImVec2);
/*       */   
/*       */   private static native float nGetItemRectMaxX();
/*       */   
/*       */   private static native float nGetItemRectMaxY();
/*       */   
/*       */   private static native void nGetItemRectSize(ImVec2 paramImVec2);
/*       */   
/*       */   private static native float nGetItemRectSizeX();
/*       */   
/*       */   private static native float nGetItemRectSizeY();
/*       */   
/*       */   private static native long nGetMainViewport();
/*       */   
/*       */   private static native long nGetBackgroundDrawList();
/*       */   
/*       */   private static native long nGetBackgroundDrawList(long paramLong);
/*       */   
/*       */   private static native long nGetForegroundDrawList();
/*       */   
/*       */   private static native long nGetForegroundDrawList(long paramLong);
/*       */   
/*       */   private static native boolean nIsRectVisible(float paramFloat1, float paramFloat2);
/*       */   
/*       */   private static native boolean nIsRectVisible(float paramFloat1, float paramFloat2, float paramFloat3, float paramFloat4);
/*       */   
/*       */   private static native double nGetTime();
/*       */   
/*       */   private static native int nGetFrameCount();
/*       */   
/*       */   private static native String nGetStyleColorName(int paramInt);
/*       */   
/*       */   private static native void nSetStateStorage(long paramLong);
/*       */   
/*       */   private static native long nGetStateStorage();
/*       */   
/*       */   private static native void nCalcTextSize(ImVec2 paramImVec2, String paramString);
/*       */   
/*       */   private static native float nCalcTextSizeX(String paramString);
/*       */   
/*       */   private static native float nCalcTextSizeY(String paramString);
/*       */   
/*       */   private static native void nCalcTextSize(ImVec2 paramImVec2, String paramString, boolean paramBoolean);
/*       */   
/*       */   private static native float nCalcTextSizeX(String paramString, boolean paramBoolean);
/*       */   
/*       */   private static native float nCalcTextSizeY(String paramString, boolean paramBoolean);
/*       */   
/*       */   private static native void nCalcTextSize(ImVec2 paramImVec2, String paramString, boolean paramBoolean, float paramFloat);
/*       */   
/*       */   private static native float nCalcTextSizeX(String paramString, boolean paramBoolean, float paramFloat);
/*       */   
/*       */   private static native float nCalcTextSizeY(String paramString, boolean paramBoolean, float paramFloat);
/*       */   
/*       */   private static native void nCalcTextSize(ImVec2 paramImVec2, String paramString, float paramFloat);
/*       */   
/*       */   private static native float nCalcTextSizeX(String paramString, float paramFloat);
/*       */   
/*       */   private static native float nCalcTextSizeY(String paramString, float paramFloat);
/*       */   
/*       */   private static native void nColorConvertU32ToFloat4(ImVec4 paramImVec4, int paramInt);
/*       */   
/*       */   private static native float nColorConvertU32ToFloat4X(int paramInt);
/*       */   
/*       */   private static native float nColorConvertU32ToFloat4Y(int paramInt);
/*       */   
/*       */   private static native float nColorConvertU32ToFloat4Z(int paramInt);
/*       */   
/*       */   private static native float nColorConvertU32ToFloat4W(int paramInt);
/*       */   
/*       */   private static native int nColorConvertFloat4ToU32(float paramFloat1, float paramFloat2, float paramFloat3, float paramFloat4);
/*       */   
/*       */   public static native void nColorConvertRGBtoHSV(float[] paramArrayOffloat1, float[] paramArrayOffloat2);
/*       */   
/*       */   public static native void nColorConvertHSVtoRGB(float[] paramArrayOffloat1, float[] paramArrayOffloat2);
/*       */   
/*       */   private static native boolean nIsKeyDown(int paramInt);
/*       */   
/*       */   private static native boolean nIsKeyPressed(int paramInt);
/*       */   
/*       */   private static native boolean nIsKeyPressed(int paramInt, boolean paramBoolean);
/*       */   
/*       */   private static native boolean nIsKeyReleased(int paramInt);
/*       */   
/*       */   private static native boolean nIsKeyChordPressed(int paramInt);
/*       */   
/*       */   private static native boolean nGetKeyPressedAmount(int paramInt, float paramFloat1, float paramFloat2);
/*       */   
/*       */   private static native String nGetKeyName(int paramInt);
/*       */   
/*       */   private static native void nSetNextFrameWantCaptureKeyboard(boolean paramBoolean);
/*       */   
/*       */   private static native boolean nShortcut(int paramInt);
/*       */   
/*       */   private static native boolean nShortcut(int paramInt1, int paramInt2);
/*       */   
/*       */   private static native void nSetNextItemShortcut(int paramInt);
/*       */   
/*       */   private static native void nSetNextItemShortcut(int paramInt1, int paramInt2);
/*       */   
/*       */   private static native boolean nIsMouseDown(int paramInt);
/*       */   
/*       */   private static native boolean nIsMouseClicked(int paramInt);
/*       */   
/*       */   private static native boolean nIsMouseClicked(int paramInt, boolean paramBoolean);
/*       */   
/*       */   private static native boolean nIsMouseReleased(int paramInt);
/*       */   
/*       */   private static native boolean nIsMouseDoubleClicked(int paramInt);
/*       */   
/*       */   private static native int nGetMouseClickedCount(int paramInt);
/*       */   
/*       */   private static native boolean nIsMouseHoveringRect(float paramFloat1, float paramFloat2, float paramFloat3, float paramFloat4);
/*       */   
/*       */   private static native boolean nIsMouseHoveringRect(float paramFloat1, float paramFloat2, float paramFloat3, float paramFloat4, boolean paramBoolean);
/*       */   
/*       */   private static native boolean nIsMousePosValid();
/*       */   
/*       */   private static native boolean nIsMousePosValid(float paramFloat1, float paramFloat2);
/*       */   
/*       */   private static native boolean nIsAnyMouseDown();
/*       */   
/*       */   private static native void nGetMousePos(ImVec2 paramImVec2);
/*       */   
/*       */   private static native float nGetMousePosX();
/*       */   
/*       */   private static native float nGetMousePosY();
/*       */   
/*       */   private static native void nGetMousePosOnOpeningCurrentPopup(ImVec2 paramImVec2);
/*       */   
/*       */   private static native float nGetMousePosOnOpeningCurrentPopupX();
/*       */   
/*       */   private static native float nGetMousePosOnOpeningCurrentPopupY();
/*       */   
/*       */   private static native boolean nIsMouseDragging(int paramInt);
/*       */   
/*       */   private static native boolean nIsMouseDragging(int paramInt, float paramFloat);
/*       */   
/*       */   private static native void nGetMouseDragDelta(ImVec2 paramImVec2);
/*       */   
/*       */   private static native float nGetMouseDragDeltaX();
/*       */   
/*       */   private static native float nGetMouseDragDeltaY();
/*       */   
/*       */   private static native void nGetMouseDragDelta(ImVec2 paramImVec2, int paramInt);
/*       */   
/*       */   private static native float nGetMouseDragDeltaX(int paramInt);
/*       */   
/*       */   private static native float nGetMouseDragDeltaY(int paramInt);
/*       */   
/*       */   private static native void nGetMouseDragDelta(ImVec2 paramImVec2, int paramInt, float paramFloat);
/*       */   
/*       */   private static native float nGetMouseDragDeltaX(int paramInt, float paramFloat);
/*       */   
/*       */   private static native float nGetMouseDragDeltaY(int paramInt, float paramFloat);
/*       */   
/*       */   private static native void nResetMouseDragDelta();
/*       */   
/*       */   private static native void nResetMouseDragDelta(int paramInt);
/*       */   
/*       */   private static native int nGetMouseCursor();
/*       */   
/*       */   private static native void nSetMouseCursor(int paramInt);
/*       */   
/*       */   private static native void nSetNextFrameWantCaptureMouse(boolean paramBoolean);
/*       */   
/*       */   private static native String nGetClipboardText();
/*       */   
/*       */   private static native void nSetClipboardText(String paramString);
/*       */   
/*       */   private static native void nLoadIniSettingsFromDisk(String paramString);
/*       */   
/*       */   private static native void nLoadIniSettingsFromMemory(String paramString);
/*       */   
/*       */   private static native void nLoadIniSettingsFromMemory(String paramString, int paramInt);
/*       */   
/*       */   private static native void nSaveIniSettingsToDisk(String paramString);
/*       */   
/*       */   private static native String nSaveIniSettingsToMemory();
/*       */   
/*       */   private static native String nSaveIniSettingsToMemory(long paramLong);
/*       */   
/*       */   private static native void nDebugTextEncoding(String paramString);
/*       */   
/*       */   private static native void nDebugFlashStyleColor(int paramInt);
/*       */   
/*       */   private static native void nDebugStartItemPicker();
/*       */   
/*       */   private static native boolean nDebugCheckVersionAndDataLayout(String paramString, int paramInt1, int paramInt2, int paramInt3, int paramInt4, int paramInt5, int paramInt6);
/*       */   
/*       */   private static native long nGetPlatformIO();
/*       */   
/*       */   private static native void nUpdatePlatformWindows();
/*       */   
/*       */   private static native void nRenderPlatformWindowsDefault();
/*       */   
/*       */   private static native void nDestroyPlatformWindows();
/*       */   
/*       */   private static native long nFindViewportByID(int paramInt);
/*       */   
/*       */   private static native long nFindViewportByPlatformHandle(long paramLong);
/*       */ }


/* Location:              C:\Users\rapha\Downloads\aurora.jar!\META-INF\jars\imgui-java-binding-1.90.0.jar!\imgui\ImGui.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */