/*     */ package imgui;
/*     */ 
/*     */ import imgui.binding.ImGuiStructDestroyable;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class ImFontGlyph
/*     */   extends ImGuiStructDestroyable
/*     */ {
/*     */   public ImFontGlyph() {}
/*     */   
/*     */   public ImFontGlyph(long ptr) {
/*  15 */     super(ptr);
/*     */   }
/*     */ 
/*     */   
/*     */   protected long create() {
/*  20 */     return nCreate();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private native long nCreate();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int getColored() {
/*  36 */     return nGetColored();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setColored(int value) {
/*  43 */     nSetColored(value);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private native int nGetColored();
/*     */ 
/*     */ 
/*     */   
/*     */   private native void nSetColored(int paramInt);
/*     */ 
/*     */ 
/*     */   
/*     */   public int getVisible() {
/*  58 */     return nGetVisible();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setVisible(int value) {
/*  65 */     nSetVisible(value);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private native int nGetVisible();
/*     */ 
/*     */ 
/*     */   
/*     */   private native void nSetVisible(int paramInt);
/*     */ 
/*     */ 
/*     */   
/*     */   public int getCodepoint() {
/*  80 */     return nGetCodepoint();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setCodepoint(int value) {
/*  87 */     nSetCodepoint(value);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private native int nGetCodepoint();
/*     */ 
/*     */ 
/*     */   
/*     */   private native void nSetCodepoint(int paramInt);
/*     */ 
/*     */ 
/*     */   
/*     */   public float getAdvanceX() {
/* 102 */     return nGetAdvanceX();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setAdvanceX(float value) {
/* 109 */     nSetAdvanceX(value);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private native float nGetAdvanceX();
/*     */ 
/*     */ 
/*     */   
/*     */   private native void nSetAdvanceX(float paramFloat);
/*     */ 
/*     */ 
/*     */   
/*     */   public float getX0() {
/* 124 */     return nGetX0();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setX0(float value) {
/* 131 */     nSetX0(value);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private native float nGetX0();
/*     */ 
/*     */ 
/*     */   
/*     */   private native void nSetX0(float paramFloat);
/*     */ 
/*     */ 
/*     */   
/*     */   public float getY0() {
/* 146 */     return nGetY0();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setY0(float value) {
/* 153 */     nSetY0(value);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private native float nGetY0();
/*     */ 
/*     */ 
/*     */   
/*     */   private native void nSetY0(float paramFloat);
/*     */ 
/*     */ 
/*     */   
/*     */   public float getX1() {
/* 168 */     return nGetX1();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setX1(float value) {
/* 175 */     nSetX1(value);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private native float nGetX1();
/*     */ 
/*     */ 
/*     */   
/*     */   private native void nSetX1(float paramFloat);
/*     */ 
/*     */ 
/*     */   
/*     */   public float getY1() {
/* 190 */     return nGetY1();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setY1(float value) {
/* 197 */     nSetY1(value);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private native float nGetY1();
/*     */ 
/*     */ 
/*     */   
/*     */   private native void nSetY1(float paramFloat);
/*     */ 
/*     */ 
/*     */   
/*     */   public float getU0() {
/* 212 */     return nGetU0();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setU0(float value) {
/* 219 */     nSetU0(value);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private native float nGetU0();
/*     */ 
/*     */ 
/*     */   
/*     */   private native void nSetU0(float paramFloat);
/*     */ 
/*     */ 
/*     */   
/*     */   public float getV0() {
/* 234 */     return nGetV0();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setV0(float value) {
/* 241 */     nSetV0(value);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private native float nGetV0();
/*     */ 
/*     */ 
/*     */   
/*     */   private native void nSetV0(float paramFloat);
/*     */ 
/*     */ 
/*     */   
/*     */   public float getU1() {
/* 256 */     return nGetU1();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setU1(float value) {
/* 263 */     nSetU1(value);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private native float nGetU1();
/*     */ 
/*     */ 
/*     */   
/*     */   private native void nSetU1(float paramFloat);
/*     */ 
/*     */ 
/*     */   
/*     */   public float getV1() {
/* 278 */     return nGetV1();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setV1(float value) {
/* 285 */     nSetV1(value);
/*     */   }
/*     */   
/*     */   private native float nGetV1();
/*     */   
/*     */   private native void nSetV1(float paramFloat);
/*     */ }


/* Location:              C:\Users\rapha\Downloads\aurora.jar!\META-INF\jars\imgui-java-binding-1.90.0.jar!\imgui\ImFontGlyph.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */