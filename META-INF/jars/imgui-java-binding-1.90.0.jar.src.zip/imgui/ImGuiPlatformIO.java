/*     */ package imgui;
/*     */ 
/*     */ import imgui.binding.ImGuiStruct;
/*     */ import imgui.callback.ImPlatformFuncViewport;
/*     */ import imgui.callback.ImPlatformFuncViewportFloat;
/*     */ import imgui.callback.ImPlatformFuncViewportImVec2;
/*     */ import imgui.callback.ImPlatformFuncViewportString;
/*     */ import imgui.callback.ImPlatformFuncViewportSuppBoolean;
/*     */ import imgui.callback.ImPlatformFuncViewportSuppFloat;
/*     */ import imgui.callback.ImPlatformFuncViewportSuppImVec2;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class ImGuiPlatformIO
/*     */   extends ImGuiStruct
/*     */ {
/*  73 */   private static final ImGuiViewport TMP_VIEWPORT = new ImGuiViewport(0L);
/*  74 */   private static final ImGuiPlatformMonitor TMP_MONITOR = new ImGuiPlatformMonitor(0L);
/*  75 */   private static final ImVec2 TMP_IM_VEC2 = new ImVec2();
/*     */   
/*     */   public ImGuiPlatformIO(long ptr) {
/*  78 */     super(ptr);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static void init() {
/*  91 */     nInit(TMP_VIEWPORT, TMP_IM_VEC2);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static native void nInit(ImGuiViewport paramImGuiViewport, ImVec2 paramImVec2);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public native void setPlatformCreateWindow(ImPlatformFuncViewport paramImPlatformFuncViewport);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public native void setPlatformDestroyWindow(ImPlatformFuncViewport paramImPlatformFuncViewport);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public native void setPlatformShowWindow(ImPlatformFuncViewport paramImPlatformFuncViewport);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public native void setPlatformSetWindowPos(ImPlatformFuncViewportImVec2 paramImPlatformFuncViewportImVec2);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public native void setPlatformGetWindowPos(ImPlatformFuncViewportSuppImVec2 paramImPlatformFuncViewportSuppImVec2);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public native void setPlatformSetWindowSize(ImPlatformFuncViewportImVec2 paramImPlatformFuncViewportImVec2);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public native void setPlatformGetWindowSize(ImPlatformFuncViewportSuppImVec2 paramImPlatformFuncViewportSuppImVec2);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public native void setPlatformSetWindowFocus(ImPlatformFuncViewport paramImPlatformFuncViewport);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public native void setPlatformGetWindowFocus(ImPlatformFuncViewportSuppBoolean paramImPlatformFuncViewportSuppBoolean);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public native void setPlatformGetWindowMinimized(ImPlatformFuncViewportSuppBoolean paramImPlatformFuncViewportSuppBoolean);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public native void setPlatformSetWindowTitle(ImPlatformFuncViewportString paramImPlatformFuncViewportString);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public native void setPlatformSetWindowAlpha(ImPlatformFuncViewportFloat paramImPlatformFuncViewportFloat);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public native void setPlatformUpdateWindow(ImPlatformFuncViewport paramImPlatformFuncViewport);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public native void setPlatformRenderWindow(ImPlatformFuncViewport paramImPlatformFuncViewport);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public native void setPlatformSwapBuffers(ImPlatformFuncViewport paramImPlatformFuncViewport);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public native void setPlatformGetWindowDpiScale(ImPlatformFuncViewportSuppFloat paramImPlatformFuncViewportSuppFloat);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public native void setPlatformOnChangedViewport(ImPlatformFuncViewport paramImPlatformFuncViewport);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public native void setRendererCreateWindow(ImPlatformFuncViewport paramImPlatformFuncViewport);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public native void setRendererDestroyWindow(ImPlatformFuncViewport paramImPlatformFuncViewport);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public native void setRendererSetWindowPos(ImPlatformFuncViewportImVec2 paramImPlatformFuncViewportImVec2);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public native void setRendererRenderWindow(ImPlatformFuncViewport paramImPlatformFuncViewport);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public native void setRendererSwapBuffers(ImPlatformFuncViewport paramImPlatformFuncViewport);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public native void resizeMonitors(int paramInt);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public native int getMonitorsSize();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public native void pushMonitors(long paramLong, float paramFloat1, float paramFloat2, float paramFloat3, float paramFloat4, float paramFloat5, float paramFloat6, float paramFloat7, float paramFloat8, float paramFloat9);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ImGuiPlatformMonitor getMonitors(int idx) {
/* 525 */     TMP_MONITOR.ptr = nGetMonitors(idx);
/* 526 */     return TMP_MONITOR;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private native long nGetMonitors(int paramInt);
/*     */ 
/*     */ 
/*     */   
/*     */   public native int getViewportsSize();
/*     */ 
/*     */ 
/*     */   
/*     */   public ImGuiViewport getViewports(int idx) {
/* 541 */     TMP_VIEWPORT.ptr = nGetViewports(idx);
/* 542 */     return TMP_VIEWPORT;
/*     */   }
/*     */   
/*     */   private native long nGetViewports(int paramInt);
/*     */ }


/* Location:              C:\Users\rapha\Downloads\aurora.jar!\META-INF\jars\imgui-java-binding-1.90.0.jar!\imgui\ImGuiPlatformIO.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */