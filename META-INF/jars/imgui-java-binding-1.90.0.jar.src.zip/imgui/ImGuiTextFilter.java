/*     */ package imgui;
/*     */ 
/*     */ import imgui.binding.ImGuiStructDestroyable;
/*     */ 
/*     */ 
/*     */ public final class ImGuiTextFilter
/*     */   extends ImGuiStructDestroyable
/*     */ {
/*     */   public ImGuiTextFilter() {
/*  10 */     this("");
/*     */   }
/*     */   
/*     */   public ImGuiTextFilter(String defaultFilter) {
/*  14 */     this.ptr = nCreate(defaultFilter);
/*     */   }
/*     */   
/*     */   public ImGuiTextFilter(long ptr) {
/*  18 */     super(ptr);
/*     */   }
/*     */ 
/*     */   
/*     */   protected long create() {
/*  23 */     return nCreate("");
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private native long nCreate(String paramString);
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean draw() {
/*  36 */     return nDraw();
/*     */   }
/*     */   
/*     */   public boolean draw(String label) {
/*  40 */     return nDraw(label);
/*     */   }
/*     */   
/*     */   public boolean draw(String label, float width) {
/*  44 */     return nDraw(label, width);
/*     */   }
/*     */   
/*     */   public boolean draw(float width) {
/*  48 */     return nDraw(width);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private native boolean nDraw();
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private native boolean nDraw(String paramString);
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private native boolean nDraw(String paramString, float paramFloat);
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private native boolean nDraw(float paramFloat);
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean passFilter(String text) {
/*  74 */     return nPassFilter(text);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private native boolean nPassFilter(String paramString);
/*     */ 
/*     */ 
/*     */   
/*     */   public void build() {
/*  85 */     nBuild();
/*     */   }
/*     */ 
/*     */   
/*     */   private native void nBuild();
/*     */ 
/*     */   
/*     */   public void clear() {
/*  93 */     nClear();
/*     */   }
/*     */ 
/*     */   
/*     */   private native void nClear();
/*     */ 
/*     */   
/*     */   public boolean isActive() {
/* 101 */     return nIsActive();
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private native boolean nIsActive();
/*     */ 
/*     */ 
/*     */   
/*     */   public native String getInputBuffer();
/*     */ 
/*     */   
/*     */   public native void setInputBuffer(String paramString);
/*     */ 
/*     */   
/*     */   public int getCountGrep() {
/* 117 */     return nGetCountGrep();
/*     */   }
/*     */   
/*     */   public void setCountGrep(int value) {
/* 121 */     nSetCountGrep(value);
/*     */   }
/*     */   
/*     */   private native int nGetCountGrep();
/*     */   
/*     */   private native void nSetCountGrep(int paramInt);
/*     */ }


/* Location:              C:\Users\rapha\Downloads\aurora.jar!\META-INF\jars\imgui-java-binding-1.90.0.jar!\imgui\ImGuiTextFilter.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */