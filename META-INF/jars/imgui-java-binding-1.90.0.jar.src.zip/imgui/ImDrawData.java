/*     */ package imgui;
/*     */ 
/*     */ import imgui.binding.ImGuiStruct;
/*     */ import java.nio.ByteBuffer;
/*     */ import java.nio.ByteOrder;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class ImDrawData
/*     */   extends ImGuiStruct
/*     */ {
/*     */   private static final int RESIZE_FACTOR = 5000;
/*  18 */   private static ByteBuffer dataBuffer = ByteBuffer.allocateDirect(25000).order(ByteOrder.nativeOrder());
/*     */   
/*     */   public ImDrawData(long ptr) {
/*  21 */     super(ptr);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public native int getCmdListCmdBufferSize(int paramInt);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public native int getCmdListCmdBufferElemCount(int paramInt1, int paramInt2);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ImVec4 getCmdListCmdBufferClipRect(int cmdListIdx, int cmdBufferIdx) {
/*  50 */     ImVec4 dst = new ImVec4();
/*  51 */     getCmdListCmdBufferClipRect(dst, cmdListIdx, cmdBufferIdx);
/*  52 */     return dst;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public native void getCmdListCmdBufferClipRect(ImVec4 paramImVec4, int paramInt1, int paramInt2);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public native long getCmdListCmdBufferTextureId(int paramInt1, int paramInt2);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public native int getCmdListCmdBufferVtxOffset(int paramInt1, int paramInt2);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public native int getCmdListCmdBufferIdxOffset(int paramInt1, int paramInt2);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public native int getCmdListIdxBufferSize(int paramInt);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ByteBuffer getCmdListIdxBufferData(int cmdListIdx) {
/*  93 */     int idxBufferCapacity = getCmdListIdxBufferSize(cmdListIdx) * sizeOfImDrawIdx();
/*  94 */     if (dataBuffer.capacity() < idxBufferCapacity) {
/*  95 */       dataBuffer.clear();
/*  96 */       dataBuffer = ByteBuffer.allocateDirect(idxBufferCapacity + 5000).order(ByteOrder.nativeOrder());
/*     */     } 
/*     */     
/*  99 */     nGetCmdListIdxBufferData(cmdListIdx, dataBuffer, idxBufferCapacity);
/*     */     
/* 101 */     dataBuffer.position(0);
/* 102 */     dataBuffer.limit(idxBufferCapacity);
/*     */     
/* 104 */     return dataBuffer;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private native void nGetCmdListIdxBufferData(int paramInt1, ByteBuffer paramByteBuffer, int paramInt2);
/*     */ 
/*     */ 
/*     */   
/*     */   public native int getCmdListVtxBufferSize(int paramInt);
/*     */ 
/*     */ 
/*     */   
/*     */   public ByteBuffer getCmdListVtxBufferData(int cmdListIdx) {
/* 119 */     int vtxBufferCapacity = getCmdListVtxBufferSize(cmdListIdx) * sizeOfImDrawVert();
/* 120 */     if (dataBuffer.capacity() < vtxBufferCapacity) {
/* 121 */       dataBuffer.clear();
/* 122 */       dataBuffer = ByteBuffer.allocateDirect(vtxBufferCapacity + 5000).order(ByteOrder.nativeOrder());
/*     */     } 
/*     */     
/* 125 */     nGetCmdListVtxBufferData(cmdListIdx, dataBuffer, vtxBufferCapacity);
/*     */     
/* 127 */     dataBuffer.position(0);
/* 128 */     dataBuffer.limit(vtxBufferCapacity);
/*     */     
/* 130 */     return dataBuffer;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private native void nGetCmdListVtxBufferData(int paramInt1, ByteBuffer paramByteBuffer, int paramInt2);
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static native int sizeOfImDrawVert();
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static native int sizeOfImDrawIdx();
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean getValid() {
/* 151 */     return nGetValid();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private native boolean nGetValid();
/*     */ 
/*     */ 
/*     */   
/*     */   public int getCmdListsCount() {
/* 162 */     return nGetCmdListsCount();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private native int nGetCmdListsCount();
/*     */ 
/*     */ 
/*     */   
/*     */   public int getTotalIdxCount() {
/* 173 */     return nGetTotalIdxCount();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private native int nGetTotalIdxCount();
/*     */ 
/*     */ 
/*     */   
/*     */   public int getTotalVtxCount() {
/* 184 */     return nGetTotalVtxCount();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private native int nGetTotalVtxCount();
/*     */ 
/*     */ 
/*     */   
/*     */   public ImVec2 getDisplayPos() {
/* 195 */     ImVec2 dst = new ImVec2();
/* 196 */     nGetDisplayPos(dst);
/* 197 */     return dst;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public float getDisplayPosX() {
/* 204 */     return nGetDisplayPosX();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public float getDisplayPosY() {
/* 211 */     return nGetDisplayPosY();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void getDisplayPos(ImVec2 dst) {
/* 218 */     nGetDisplayPos(dst);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private native void nGetDisplayPos(ImVec2 paramImVec2);
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private native float nGetDisplayPosX();
/*     */ 
/*     */ 
/*     */   
/*     */   private native float nGetDisplayPosY();
/*     */ 
/*     */ 
/*     */   
/*     */   public ImVec2 getDisplaySize() {
/* 238 */     ImVec2 dst = new ImVec2();
/* 239 */     nGetDisplaySize(dst);
/* 240 */     return dst;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public float getDisplaySizeX() {
/* 248 */     return nGetDisplaySizeX();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public float getDisplaySizeY() {
/* 256 */     return nGetDisplaySizeY();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void getDisplaySize(ImVec2 dst) {
/* 264 */     nGetDisplaySize(dst);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private native void nGetDisplaySize(ImVec2 paramImVec2);
/*     */ 
/*     */ 
/*     */   
/*     */   private native float nGetDisplaySizeX();
/*     */ 
/*     */ 
/*     */   
/*     */   private native float nGetDisplaySizeY();
/*     */ 
/*     */ 
/*     */   
/*     */   public ImVec2 getFramebufferScale() {
/* 283 */     ImVec2 dst = new ImVec2();
/* 284 */     nGetFramebufferScale(dst);
/* 285 */     return dst;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public float getFramebufferScaleX() {
/* 292 */     return nGetFramebufferScaleX();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public float getFramebufferScaleY() {
/* 299 */     return nGetFramebufferScaleY();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void getFramebufferScale(ImVec2 dst) {
/* 306 */     nGetFramebufferScale(dst);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private native void nGetFramebufferScale(ImVec2 paramImVec2);
/*     */ 
/*     */ 
/*     */   
/*     */   private native float nGetFramebufferScaleX();
/*     */ 
/*     */ 
/*     */   
/*     */   private native float nGetFramebufferScaleY();
/*     */ 
/*     */ 
/*     */   
/*     */   public ImGuiViewport getOwnerViewport() {
/* 325 */     return new ImGuiViewport(nGetOwnerViewport());
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private native long nGetOwnerViewport();
/*     */ 
/*     */ 
/*     */   
/*     */   public void clear() {
/* 335 */     nClear();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private native void nClear();
/*     */ 
/*     */ 
/*     */   
/*     */   public void addDrawList(ImDrawList drawList) {
/* 346 */     nAddDrawList(drawList.ptr);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private native void nAddDrawList(long paramLong);
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void deIndexAllBuffers() {
/* 358 */     nDeIndexAllBuffers();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private native void nDeIndexAllBuffers();
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void scaleClipRects(ImVec2 fbScale) {
/* 370 */     nScaleClipRects(fbScale.x, fbScale.y);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void scaleClipRects(float fbScaleX, float fbScaleY) {
/* 378 */     nScaleClipRects(fbScaleX, fbScaleY);
/*     */   }
/*     */   
/*     */   private native void nScaleClipRects(float paramFloat1, float paramFloat2);
/*     */ }


/* Location:              C:\Users\rapha\Downloads\aurora.jar!\META-INF\jars\imgui-java-binding-1.90.0.jar!\imgui\ImDrawData.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */