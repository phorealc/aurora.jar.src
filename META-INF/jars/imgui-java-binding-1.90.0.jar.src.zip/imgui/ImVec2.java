/*    */ package imgui;
/*    */ 
/*    */ import java.util.Objects;
/*    */ 
/*    */ 
/*    */ 
/*    */ public final class ImVec2
/*    */   implements Cloneable
/*    */ {
/*    */   public float x;
/*    */   public float y;
/*    */   
/*    */   public ImVec2() {}
/*    */   
/*    */   public ImVec2(float x, float y) {
/* 16 */     set(x, y);
/*    */   }
/*    */   
/*    */   public ImVec2(ImVec2 value) {
/* 20 */     set(value.x, value.y);
/*    */   }
/*    */   
/*    */   public ImVec2 set(float x, float y) {
/* 24 */     this.x = x;
/* 25 */     this.y = y;
/* 26 */     return this;
/*    */   }
/*    */   
/*    */   public ImVec2 set(ImVec2 value) {
/* 30 */     return set(value.x, value.y);
/*    */   }
/*    */   
/*    */   public ImVec2 plus(float x, float y) {
/* 34 */     return new ImVec2(this.x + x, this.y + y);
/*    */   }
/*    */   
/*    */   public ImVec2 plus(ImVec2 value) {
/* 38 */     return plus(value.x, value.y);
/*    */   }
/*    */   
/*    */   public ImVec2 minus(float x, float y) {
/* 42 */     return new ImVec2(this.x - x, this.y - y);
/*    */   }
/*    */   
/*    */   public ImVec2 minus(ImVec2 value) {
/* 46 */     return minus(value.x, value.y);
/*    */   }
/*    */   
/*    */   public ImVec2 times(float x, float y) {
/* 50 */     return new ImVec2(this.x * x, this.y * y);
/*    */   }
/*    */   
/*    */   public ImVec2 times(ImVec2 value) {
/* 54 */     return times(value.x, value.y);
/*    */   }
/*    */   
/*    */   public ImVec2 div(float x, float y) {
/* 58 */     return new ImVec2(this.x / x, this.y / y);
/*    */   }
/*    */   
/*    */   public ImVec2 div(ImVec2 value) {
/* 62 */     return div(value.x, value.y);
/*    */   }
/*    */ 
/*    */   
/*    */   public String toString() {
/* 67 */     return "ImVec2{x=" + this.x + ", y=" + this.y + '}';
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public boolean equals(Object o) {
/* 75 */     if (this == o) {
/* 76 */       return true;
/*    */     }
/* 78 */     if (o == null || getClass() != o.getClass()) {
/* 79 */       return false;
/*    */     }
/* 81 */     ImVec2 imVec2 = (ImVec2)o;
/* 82 */     return (Float.compare(imVec2.x, this.x) == 0 && Float.compare(imVec2.y, this.y) == 0);
/*    */   }
/*    */ 
/*    */   
/*    */   public int hashCode() {
/* 87 */     return Objects.hash(new Object[] { Float.valueOf(this.x), Float.valueOf(this.y) });
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public ImVec2 clone() {
/* 93 */     return new ImVec2(this);
/*    */   }
/*    */ }


/* Location:              C:\Users\rapha\Downloads\aurora.jar!\META-INF\jars\imgui-java-binding-1.90.0.jar!\imgui\ImVec2.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */