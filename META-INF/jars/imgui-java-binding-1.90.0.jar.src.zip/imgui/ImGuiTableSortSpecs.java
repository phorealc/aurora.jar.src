/*    */ package imgui;
/*    */ 
/*    */ import imgui.binding.ImGuiStruct;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public final class ImGuiTableSortSpecs
/*    */   extends ImGuiStruct
/*    */ {
/*    */   public ImGuiTableSortSpecs(long ptr) {
/* 13 */     super(ptr);
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public ImGuiTableColumnSortSpecs[] getSpecs() {
/* 25 */     long[] specsPointers = nGetSpecs();
/* 26 */     ImGuiTableColumnSortSpecs[] specs = new ImGuiTableColumnSortSpecs[specsPointers.length];
/* 27 */     for (int i = 0; i < specsPointers.length; i++) {
/* 28 */       specs[i] = new ImGuiTableColumnSortSpecs(specsPointers[i]);
/*    */     }
/* 30 */     return specs;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   private native long[] nGetSpecs();
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public int getSpecsCount() {
/* 50 */     return nGetSpecsCount();
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   private native int nGetSpecsCount();
/*    */ 
/*    */ 
/*    */   
/*    */   public boolean getSpecsDirty() {
/* 61 */     return nGetSpecsDirty();
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public void setSpecsDirty(boolean value) {
/* 68 */     nSetSpecsDirty(value);
/*    */   }
/*    */   
/*    */   private native boolean nGetSpecsDirty();
/*    */   
/*    */   private native void nSetSpecsDirty(boolean paramBoolean);
/*    */ }


/* Location:              C:\Users\rapha\Downloads\aurora.jar!\META-INF\jars\imgui-java-binding-1.90.0.jar!\imgui\ImGuiTableSortSpecs.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */