/*     */ package imgui;
/*     */ 
/*     */ import imgui.binding.ImGuiStructDestroyable;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class ImFont
/*     */   extends ImGuiStructDestroyable
/*     */ {
/*     */   public ImFont() {}
/*     */   
/*     */   public ImFont(long ptr) {
/*  15 */     super(ptr);
/*     */   }
/*     */ 
/*     */   
/*     */   protected long create() {
/*  20 */     return nCreate();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private native long nCreate();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public float getFallbackAdvanceX() {
/*  38 */     return nGetFallbackAdvanceX();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setFallbackAdvanceX(float value) {
/*  45 */     nSetFallbackAdvanceX(value);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private native float nGetFallbackAdvanceX();
/*     */ 
/*     */ 
/*     */   
/*     */   private native void nSetFallbackAdvanceX(float paramFloat);
/*     */ 
/*     */ 
/*     */   
/*     */   public float getFontSize() {
/*  60 */     return nGetFontSize();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setFontSize(float value) {
/*  67 */     nSetFontSize(value);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  80 */   private static final ImFontGlyph _GETFALLBACKGLYPH_1 = new ImFontGlyph(0L);
/*     */ 
/*     */   
/*     */   private native float nGetFontSize();
/*     */   
/*     */   public ImFontGlyph getFallbackGlyph() {
/*  86 */     _GETFALLBACKGLYPH_1.ptr = nGetFallbackGlyph();
/*  87 */     return _GETFALLBACKGLYPH_1;
/*     */   }
/*     */ 
/*     */   
/*     */   private native void nSetFontSize(float paramFloat);
/*     */   
/*     */   public void setFallbackGlyph(ImFontGlyph value) {
/*  94 */     nSetFallbackGlyph(value.ptr);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private native long nGetFallbackGlyph();
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private native void nSetFallbackGlyph(long paramLong);
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public short getConfigDataCount() {
/* 112 */     return nGetConfigDataCount();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setConfigDataCount(short value) {
/* 120 */     nSetConfigDataCount(value);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private native short nGetConfigDataCount();
/*     */ 
/*     */ 
/*     */   
/*     */   private native void nSetConfigDataCount(short paramShort);
/*     */ 
/*     */ 
/*     */   
/*     */   public short getEllipsisChar() {
/* 135 */     return nGetEllipsisChar();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setEllipsisChar(short value) {
/* 142 */     nSetEllipsisChar(value);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private native short nGetEllipsisChar();
/*     */ 
/*     */   
/*     */   private native void nSetEllipsisChar(short paramShort);
/*     */ 
/*     */   
/*     */   public short getEllipsisCharCount() {
/* 154 */     return nGetEllipsisCharCount();
/*     */   }
/*     */   
/*     */   public void setEllipsisCharCount(short value) {
/* 158 */     nSetEllipsisCharCount(value);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private native short nGetEllipsisCharCount();
/*     */ 
/*     */   
/*     */   private native void nSetEllipsisCharCount(short paramShort);
/*     */ 
/*     */   
/*     */   public float getEllipsisWidth() {
/* 170 */     return nGetEllipsisWidth();
/*     */   }
/*     */   
/*     */   public void setEllipsisWidth(float value) {
/* 174 */     nSetEllipsisWidth(value);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private native float nGetEllipsisWidth();
/*     */ 
/*     */   
/*     */   private native void nSetEllipsisWidth(float paramFloat);
/*     */ 
/*     */   
/*     */   public float getEllipsisCharStep() {
/* 186 */     return nGetEllipsisCharStep();
/*     */   }
/*     */   
/*     */   public void setEllipsisCharStep(float value) {
/* 190 */     nSetEllipsisCharStep(value);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private native float nGetEllipsisCharStep();
/*     */ 
/*     */   
/*     */   private native void nSetEllipsisCharStep(float paramFloat);
/*     */ 
/*     */   
/*     */   public boolean getDirtyLookupTables() {
/* 202 */     return nGetDirtyLookupTables();
/*     */   }
/*     */   
/*     */   public void setDirtyLookupTables(boolean value) {
/* 206 */     nSetDirtyLookupTables(value);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private native boolean nGetDirtyLookupTables();
/*     */ 
/*     */ 
/*     */   
/*     */   private native void nSetDirtyLookupTables(boolean paramBoolean);
/*     */ 
/*     */ 
/*     */   
/*     */   public float getScale() {
/* 221 */     return nGetScale();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setScale(float value) {
/* 228 */     nSetScale(value);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private native float nGetScale();
/*     */ 
/*     */ 
/*     */   
/*     */   private native void nSetScale(float paramFloat);
/*     */ 
/*     */ 
/*     */   
/*     */   public float getAscent() {
/* 243 */     return nGetAscent();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setAscent(float value) {
/* 250 */     nSetAscent(value);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private native float nGetAscent();
/*     */ 
/*     */   
/*     */   private native void nSetAscent(float paramFloat);
/*     */ 
/*     */   
/*     */   public float getDescent() {
/* 262 */     return nGetDescent();
/*     */   }
/*     */   
/*     */   public void setDescent(float value) {
/* 266 */     nSetDescent(value);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private native float nGetDescent();
/*     */ 
/*     */ 
/*     */   
/*     */   private native void nSetDescent(float paramFloat);
/*     */ 
/*     */ 
/*     */   
/*     */   public int getMetricsTotalSurface() {
/* 281 */     return nGetMetricsTotalSurface();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setMetricsTotalSurface(int value) {
/* 288 */     nSetMetricsTotalSurface(value);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private native int nGetMetricsTotalSurface();
/*     */ 
/*     */ 
/*     */   
/*     */   private native void nSetMetricsTotalSurface(int paramInt);
/*     */ 
/*     */ 
/*     */   
/*     */   public ImFontGlyph findGlyph(int c) {
/* 302 */     return new ImFontGlyph(nFindGlyph(c));
/*     */   }
/*     */ 
/*     */   
/*     */   private native long nFindGlyph(int paramInt);
/*     */ 
/*     */   
/*     */   public ImFontGlyph findGlyphNoFallback(int c) {
/* 310 */     return new ImFontGlyph(nFindGlyphNoFallback(c));
/*     */   }
/*     */ 
/*     */   
/*     */   private native long nFindGlyphNoFallback(int paramInt);
/*     */ 
/*     */   
/*     */   public float getCharAdvance(int c) {
/* 318 */     return nGetCharAdvance(c);
/*     */   }
/*     */ 
/*     */   
/*     */   private native float nGetCharAdvance(int paramInt);
/*     */ 
/*     */   
/*     */   public boolean isLoaded() {
/* 326 */     return nIsLoaded();
/*     */   }
/*     */ 
/*     */   
/*     */   private native boolean nIsLoaded();
/*     */ 
/*     */   
/*     */   public String getDebugName() {
/* 334 */     return nGetDebugName();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private native String nGetDebugName();
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ImVec2 calcTextSizeA(float size, float maxWidth, float wrapWidth, String textBegin) {
/* 346 */     ImVec2 dst = new ImVec2();
/* 347 */     nCalcTextSizeA(dst, size, maxWidth, wrapWidth, textBegin);
/* 348 */     return dst;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public float calcTextSizeAX(float size, float maxWidth, float wrapWidth, String textBegin) {
/* 356 */     return nCalcTextSizeAX(size, maxWidth, wrapWidth, textBegin);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public float calcTextSizeAY(float size, float maxWidth, float wrapWidth, String textBegin) {
/* 364 */     return nCalcTextSizeAY(size, maxWidth, wrapWidth, textBegin);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void calcTextSizeA(ImVec2 dst, float size, float maxWidth, float wrapWidth, String textBegin) {
/* 372 */     nCalcTextSizeA(dst, size, maxWidth, wrapWidth, textBegin);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ImVec2 calcTextSizeA(float size, float maxWidth, float wrapWidth, String textBegin, String textEnd) {
/* 380 */     ImVec2 dst = new ImVec2();
/* 381 */     nCalcTextSizeA(dst, size, maxWidth, wrapWidth, textBegin, textEnd);
/* 382 */     return dst;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public float calcTextSizeAX(float size, float maxWidth, float wrapWidth, String textBegin, String textEnd) {
/* 390 */     return nCalcTextSizeAX(size, maxWidth, wrapWidth, textBegin, textEnd);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public float calcTextSizeAY(float size, float maxWidth, float wrapWidth, String textBegin, String textEnd) {
/* 398 */     return nCalcTextSizeAY(size, maxWidth, wrapWidth, textBegin, textEnd);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void calcTextSizeA(ImVec2 dst, float size, float maxWidth, float wrapWidth, String textBegin, String textEnd) {
/* 406 */     nCalcTextSizeA(dst, size, maxWidth, wrapWidth, textBegin, textEnd);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private native void nCalcTextSizeA(ImVec2 paramImVec2, float paramFloat1, float paramFloat2, float paramFloat3, String paramString);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private native float nCalcTextSizeAX(float paramFloat1, float paramFloat2, float paramFloat3, String paramString);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private native float nCalcTextSizeAY(float paramFloat1, float paramFloat2, float paramFloat3, String paramString);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private native void nCalcTextSizeA(ImVec2 paramImVec2, float paramFloat1, float paramFloat2, float paramFloat3, String paramString1, String paramString2);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private native float nCalcTextSizeAX(float paramFloat1, float paramFloat2, float paramFloat3, String paramString1, String paramString2);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private native float nCalcTextSizeAY(float paramFloat1, float paramFloat2, float paramFloat3, String paramString1, String paramString2);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String calcWordWrapPositionA(float scale, String text, String textEnd, float wrapWidth) {
/* 456 */     return nCalcWordWrapPositionA(scale, text, textEnd, wrapWidth);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private native String nCalcWordWrapPositionA(float paramFloat1, String paramString1, String paramString2, float paramFloat2);
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void renderChar(ImDrawList drawList, float size, ImVec2 pos, int col, int c) {
/* 469 */     nRenderChar(drawList.ptr, size, pos.x, pos.y, col, c);
/*     */   }
/*     */   
/*     */   public void renderChar(ImDrawList drawList, float size, float posX, float posY, int col, int c) {
/* 473 */     nRenderChar(drawList.ptr, size, posX, posY, col, c);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private native void nRenderChar(long paramLong, float paramFloat1, float paramFloat2, float paramFloat3, int paramInt1, int paramInt2);
/*     */ 
/*     */   
/*     */   public void renderText(ImDrawList drawList, float size, ImVec2 pos, int col, ImVec4 clipRect, String textBegin, String textEnd) {
/* 482 */     nRenderText(drawList.ptr, size, pos.x, pos.y, col, clipRect.x, clipRect.y, clipRect.z, clipRect.w, textBegin, textEnd);
/*     */   }
/*     */   
/*     */   public void renderText(ImDrawList drawList, float size, float posX, float posY, int col, float clipRectX, float clipRectY, float clipRectZ, float clipRectW, String textBegin, String textEnd) {
/* 486 */     nRenderText(drawList.ptr, size, posX, posY, col, clipRectX, clipRectY, clipRectZ, clipRectW, textBegin, textEnd);
/*     */   }
/*     */   
/*     */   public void renderText(ImDrawList drawList, float size, ImVec2 pos, int col, ImVec4 clipRect, String textBegin, String textEnd, float wrapWidth) {
/* 490 */     nRenderText(drawList.ptr, size, pos.x, pos.y, col, clipRect.x, clipRect.y, clipRect.z, clipRect.w, textBegin, textEnd, wrapWidth);
/*     */   }
/*     */   
/*     */   public void renderText(ImDrawList drawList, float size, float posX, float posY, int col, float clipRectX, float clipRectY, float clipRectZ, float clipRectW, String textBegin, String textEnd, float wrapWidth) {
/* 494 */     nRenderText(drawList.ptr, size, posX, posY, col, clipRectX, clipRectY, clipRectZ, clipRectW, textBegin, textEnd, wrapWidth);
/*     */   }
/*     */   
/*     */   public void renderText(ImDrawList drawList, float size, ImVec2 pos, int col, ImVec4 clipRect, String textBegin, String textEnd, float wrapWidth, boolean cpuFineClip) {
/* 498 */     nRenderText(drawList.ptr, size, pos.x, pos.y, col, clipRect.x, clipRect.y, clipRect.z, clipRect.w, textBegin, textEnd, wrapWidth, cpuFineClip);
/*     */   }
/*     */   
/*     */   public void renderText(ImDrawList drawList, float size, float posX, float posY, int col, float clipRectX, float clipRectY, float clipRectZ, float clipRectW, String textBegin, String textEnd, float wrapWidth, boolean cpuFineClip) {
/* 502 */     nRenderText(drawList.ptr, size, posX, posY, col, clipRectX, clipRectY, clipRectZ, clipRectW, textBegin, textEnd, wrapWidth, cpuFineClip);
/*     */   }
/*     */   
/*     */   public void renderText(ImDrawList drawList, float size, ImVec2 pos, int col, ImVec4 clipRect, String textBegin, String textEnd, boolean cpuFineClip) {
/* 506 */     nRenderText(drawList.ptr, size, pos.x, pos.y, col, clipRect.x, clipRect.y, clipRect.z, clipRect.w, textBegin, textEnd, cpuFineClip);
/*     */   }
/*     */   
/*     */   public void renderText(ImDrawList drawList, float size, float posX, float posY, int col, float clipRectX, float clipRectY, float clipRectZ, float clipRectW, String textBegin, String textEnd, boolean cpuFineClip) {
/* 510 */     nRenderText(drawList.ptr, size, posX, posY, col, clipRectX, clipRectY, clipRectZ, clipRectW, textBegin, textEnd, cpuFineClip);
/*     */   }
/*     */   
/*     */   private native void nRenderText(long paramLong, float paramFloat1, float paramFloat2, float paramFloat3, int paramInt, float paramFloat4, float paramFloat5, float paramFloat6, float paramFloat7, String paramString1, String paramString2);
/*     */   
/*     */   private native void nRenderText(long paramLong, float paramFloat1, float paramFloat2, float paramFloat3, int paramInt, float paramFloat4, float paramFloat5, float paramFloat6, float paramFloat7, String paramString1, String paramString2, float paramFloat8);
/*     */   
/*     */   private native void nRenderText(long paramLong, float paramFloat1, float paramFloat2, float paramFloat3, int paramInt, float paramFloat4, float paramFloat5, float paramFloat6, float paramFloat7, String paramString1, String paramString2, float paramFloat8, boolean paramBoolean);
/*     */   
/*     */   private native void nRenderText(long paramLong, float paramFloat1, float paramFloat2, float paramFloat3, int paramInt, float paramFloat4, float paramFloat5, float paramFloat6, float paramFloat7, String paramString1, String paramString2, boolean paramBoolean);
/*     */ }


/* Location:              C:\Users\rapha\Downloads\aurora.jar!\META-INF\jars\imgui-java-binding-1.90.0.jar!\imgui\ImFont.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */