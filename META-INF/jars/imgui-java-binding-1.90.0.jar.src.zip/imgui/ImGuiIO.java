/*      */ package imgui;
/*      */ 
/*      */ import imgui.binding.ImGuiStruct;
/*      */ import imgui.callback.ImStrConsumer;
/*      */ import imgui.callback.ImStrSupplier;
/*      */ import imgui.internal.ImGuiContext;
/*      */ 
/*      */ 
/*      */ 
/*      */ public final class ImGuiIO
/*      */   extends ImGuiStruct
/*      */ {
/*      */   public ImGuiIO(long ptr) {
/*   14 */     super(ptr);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public int getConfigFlags() {
/*   30 */     return nGetConfigFlags();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setConfigFlags(int value) {
/*   37 */     nSetConfigFlags(value);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void addConfigFlags(int flags) {
/*   44 */     setConfigFlags(getConfigFlags() | flags);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void removeConfigFlags(int flags) {
/*   51 */     setConfigFlags(getConfigFlags() & (flags ^ 0xFFFFFFFF));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean hasConfigFlags(int flags) {
/*   58 */     return ((getConfigFlags() & flags) != 0);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private native int nGetConfigFlags();
/*      */ 
/*      */ 
/*      */   
/*      */   private native void nSetConfigFlags(int paramInt);
/*      */ 
/*      */ 
/*      */   
/*      */   public int getBackendFlags() {
/*   73 */     return nGetBackendFlags();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setBackendFlags(int value) {
/*   80 */     nSetBackendFlags(value);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void addBackendFlags(int flags) {
/*   87 */     setBackendFlags(getBackendFlags() | flags);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void removeBackendFlags(int flags) {
/*   94 */     setBackendFlags(getBackendFlags() & (flags ^ 0xFFFFFFFF));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean hasBackendFlags(int flags) {
/*  101 */     return ((getBackendFlags() & flags) != 0);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private native int nGetBackendFlags();
/*      */ 
/*      */ 
/*      */   
/*      */   private native void nSetBackendFlags(int paramInt);
/*      */ 
/*      */ 
/*      */   
/*      */   public ImVec2 getDisplaySize() {
/*  116 */     ImVec2 dst = new ImVec2();
/*  117 */     nGetDisplaySize(dst);
/*  118 */     return dst;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public float getDisplaySizeX() {
/*  125 */     return nGetDisplaySizeX();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public float getDisplaySizeY() {
/*  132 */     return nGetDisplaySizeY();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void getDisplaySize(ImVec2 dst) {
/*  139 */     nGetDisplaySize(dst);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setDisplaySize(ImVec2 value) {
/*  146 */     nSetDisplaySize(value.x, value.y);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setDisplaySize(float valueX, float valueY) {
/*  153 */     nSetDisplaySize(valueX, valueY);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private native void nGetDisplaySize(ImVec2 paramImVec2);
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private native float nGetDisplaySizeX();
/*      */ 
/*      */ 
/*      */   
/*      */   private native float nGetDisplaySizeY();
/*      */ 
/*      */ 
/*      */   
/*      */   private native void nSetDisplaySize(float paramFloat1, float paramFloat2);
/*      */ 
/*      */ 
/*      */   
/*      */   public float getDeltaTime() {
/*  177 */     return nGetDeltaTime();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setDeltaTime(float value) {
/*  184 */     nSetDeltaTime(value);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private native float nGetDeltaTime();
/*      */ 
/*      */ 
/*      */   
/*      */   private native void nSetDeltaTime(float paramFloat);
/*      */ 
/*      */ 
/*      */   
/*      */   public float getIniSavingRate() {
/*  199 */     return nGetIniSavingRate();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setIniSavingRate(float value) {
/*  206 */     nSetIniSavingRate(value);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private native float nGetIniSavingRate();
/*      */ 
/*      */ 
/*      */   
/*      */   private native void nSetIniSavingRate(float paramFloat);
/*      */ 
/*      */ 
/*      */   
/*      */   public String getIniFilename() {
/*  221 */     return nGetIniFilename();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setIniFilename(String value) {
/*  228 */     nSetIniFilename(value);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private native String nGetIniFilename();
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private native void nSetIniFilename(String paramString);
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public String getLogFilename() {
/*  245 */     return nGetLogFilename();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setLogFilename(String value) {
/*  252 */     nSetLogFilename(value);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  265 */   private static final ImFontAtlas _GETFONTS_1 = new ImFontAtlas(0L);
/*      */ 
/*      */   
/*      */   private native String nGetLogFilename();
/*      */   
/*      */   public ImFontAtlas getFonts() {
/*  271 */     _GETFONTS_1.ptr = nGetFonts();
/*  272 */     return _GETFONTS_1;
/*      */   }
/*      */ 
/*      */   
/*      */   private native void nSetLogFilename(String paramString);
/*      */   
/*      */   public void setFonts(ImFontAtlas value) {
/*  279 */     nSetFonts(value.ptr);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private native long nGetFonts();
/*      */ 
/*      */ 
/*      */   
/*      */   private native void nSetFonts(long paramLong);
/*      */ 
/*      */ 
/*      */   
/*      */   public float getFontGlobalScale() {
/*  294 */     return nGetFontGlobalScale();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setFontGlobalScale(float value) {
/*  301 */     nSetFontGlobalScale(value);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private native float nGetFontGlobalScale();
/*      */ 
/*      */ 
/*      */   
/*      */   private native void nSetFontGlobalScale(float paramFloat);
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean getFontAllowUserScaling() {
/*  316 */     return nGetFontAllowUserScaling();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setFontAllowUserScaling(boolean value) {
/*  323 */     nSetFontAllowUserScaling(value);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private native boolean nGetFontAllowUserScaling();
/*      */ 
/*      */ 
/*      */   
/*      */   private native void nSetFontAllowUserScaling(boolean paramBoolean);
/*      */ 
/*      */ 
/*      */   
/*      */   public ImFont getFontDefault() {
/*  338 */     return new ImFont(nGetFontDefault());
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setFontDefault(ImFont value) {
/*  345 */     nSetFontDefault(value.ptr);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private native long nGetFontDefault();
/*      */ 
/*      */ 
/*      */   
/*      */   private native void nSetFontDefault(long paramLong);
/*      */ 
/*      */ 
/*      */   
/*      */   public ImVec2 getDisplayFramebufferScale() {
/*  360 */     ImVec2 dst = new ImVec2();
/*  361 */     nGetDisplayFramebufferScale(dst);
/*  362 */     return dst;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public float getDisplayFramebufferScaleX() {
/*  369 */     return nGetDisplayFramebufferScaleX();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public float getDisplayFramebufferScaleY() {
/*  376 */     return nGetDisplayFramebufferScaleY();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void getDisplayFramebufferScale(ImVec2 dst) {
/*  383 */     nGetDisplayFramebufferScale(dst);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setDisplayFramebufferScale(ImVec2 value) {
/*  390 */     nSetDisplayFramebufferScale(value.x, value.y);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setDisplayFramebufferScale(float valueX, float valueY) {
/*  397 */     nSetDisplayFramebufferScale(valueX, valueY);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private native void nGetDisplayFramebufferScale(ImVec2 paramImVec2);
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private native float nGetDisplayFramebufferScaleX();
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private native float nGetDisplayFramebufferScaleY();
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private native void nSetDisplayFramebufferScale(float paramFloat1, float paramFloat2);
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean getConfigDockingNoSplit() {
/*  423 */     return nGetConfigDockingNoSplit();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setConfigDockingNoSplit(boolean value) {
/*  430 */     nSetConfigDockingNoSplit(value);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private native boolean nGetConfigDockingNoSplit();
/*      */ 
/*      */ 
/*      */   
/*      */   private native void nSetConfigDockingNoSplit(boolean paramBoolean);
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean getConfigDockingWithShift() {
/*  445 */     return nGetConfigDockingWithShift();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setConfigDockingWithShift(boolean value) {
/*  452 */     nSetConfigDockingWithShift(value);
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   private native boolean nGetConfigDockingWithShift();
/*      */ 
/*      */   
/*      */   private native void nSetConfigDockingWithShift(boolean paramBoolean);
/*      */ 
/*      */   
/*      */   public boolean getConfigDockingAlwaysTabBar() {
/*  464 */     return nGetConfigDockingAlwaysTabBar();
/*      */   }
/*      */   
/*      */   public void setConfigDockingAlwaysTabBar(boolean value) {
/*  468 */     nSetConfigDockingAlwaysTabBar(value);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private native boolean nGetConfigDockingAlwaysTabBar();
/*      */ 
/*      */ 
/*      */   
/*      */   private native void nSetConfigDockingAlwaysTabBar(boolean paramBoolean);
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean getConfigDockingTransparentPayload() {
/*  483 */     return nGetConfigDockingTransparentPayload();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setConfigDockingTransparentPayload(boolean value) {
/*  490 */     nSetConfigDockingTransparentPayload(value);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private native boolean nGetConfigDockingTransparentPayload();
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private native void nSetConfigDockingTransparentPayload(boolean paramBoolean);
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean getConfigViewportsNoAutoMerge() {
/*  507 */     return nGetConfigViewportsNoAutoMerge();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setConfigViewportsNoAutoMerge(boolean value) {
/*  514 */     nSetConfigViewportsNoAutoMerge(value);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private native boolean nGetConfigViewportsNoAutoMerge();
/*      */ 
/*      */ 
/*      */   
/*      */   private native void nSetConfigViewportsNoAutoMerge(boolean paramBoolean);
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean getConfigViewportsNoTaskBarIcon() {
/*  529 */     return nGetConfigViewportsNoTaskBarIcon();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setConfigViewportsNoTaskBarIcon(boolean value) {
/*  536 */     nSetConfigViewportsNoTaskBarIcon(value);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private native boolean nGetConfigViewportsNoTaskBarIcon();
/*      */ 
/*      */ 
/*      */   
/*      */   private native void nSetConfigViewportsNoTaskBarIcon(boolean paramBoolean);
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean getConfigViewportsNoDecoration() {
/*  551 */     return nGetConfigViewportsNoDecoration();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setConfigViewportsNoDecoration(boolean value) {
/*  558 */     nSetConfigViewportsNoDecoration(value);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private native boolean nGetConfigViewportsNoDecoration();
/*      */ 
/*      */ 
/*      */   
/*      */   private native void nSetConfigViewportsNoDecoration(boolean paramBoolean);
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean getConfigViewportsNoDefaultParent() {
/*  573 */     return nGetConfigViewportsNoDefaultParent();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setConfigViewportsNoDefaultParent(boolean value) {
/*  580 */     nSetConfigViewportsNoDefaultParent(value);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private native boolean nGetConfigViewportsNoDefaultParent();
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private native void nSetConfigViewportsNoDefaultParent(boolean paramBoolean);
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean getMouseDrawCursor() {
/*  598 */     return nGetMouseDrawCursor();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setMouseDrawCursor(boolean value) {
/*  606 */     nSetMouseDrawCursor(value);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private native boolean nGetMouseDrawCursor();
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private native void nSetMouseDrawCursor(boolean paramBoolean);
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean getConfigMacOSXBehaviors() {
/*  623 */     return nGetConfigMacOSXBehaviors();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setConfigMacOSXBehaviors(boolean value) {
/*  632 */     nSetConfigMacOSXBehaviors(value);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private native boolean nGetConfigMacOSXBehaviors();
/*      */ 
/*      */ 
/*      */   
/*      */   private native void nSetConfigMacOSXBehaviors(boolean paramBoolean);
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean getConfigInputTrickleEventQueue() {
/*  647 */     return nGetConfigInputTrickleEventQueue();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setConfigInputTrickleEventQueue(boolean value) {
/*  654 */     nSetConfigInputTrickleEventQueue(value);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private native boolean nGetConfigInputTrickleEventQueue();
/*      */ 
/*      */ 
/*      */   
/*      */   private native void nSetConfigInputTrickleEventQueue(boolean paramBoolean);
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean getConfigInputTextCursorBlink() {
/*  669 */     return nGetConfigInputTextCursorBlink();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setConfigInputTextCursorBlink(boolean value) {
/*  676 */     nSetConfigInputTextCursorBlink(value);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private native boolean nGetConfigInputTextCursorBlink();
/*      */ 
/*      */ 
/*      */   
/*      */   private native void nSetConfigInputTextCursorBlink(boolean paramBoolean);
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean getConfigInputTextEnterKeepActive() {
/*  691 */     return nGetConfigInputTextEnterKeepActive();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setConfigInputTextEnterKeepActive(boolean value) {
/*  698 */     nSetConfigInputTextEnterKeepActive(value);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private native boolean nGetConfigInputTextEnterKeepActive();
/*      */ 
/*      */ 
/*      */   
/*      */   private native void nSetConfigInputTextEnterKeepActive(boolean paramBoolean);
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean getConfigDragClickToInputText() {
/*  713 */     return nGetConfigDragClickToInputText();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setConfigDragClickToInputText(boolean value) {
/*  720 */     nSetConfigDragClickToInputText(value);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private native boolean nGetConfigDragClickToInputText();
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private native void nSetConfigDragClickToInputText(boolean paramBoolean);
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean getConfigWindowsResizeFromEdges() {
/*  737 */     return nGetConfigWindowsResizeFromEdges();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setConfigWindowsResizeFromEdges(boolean value) {
/*  746 */     nSetConfigWindowsResizeFromEdges(value);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private native boolean nGetConfigWindowsResizeFromEdges();
/*      */ 
/*      */ 
/*      */   
/*      */   private native void nSetConfigWindowsResizeFromEdges(boolean paramBoolean);
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean getConfigWindowsMoveFromTitleBarOnly() {
/*  761 */     return nGetConfigWindowsMoveFromTitleBarOnly();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setConfigWindowsMoveFromTitleBarOnly(boolean value) {
/*  768 */     nSetConfigWindowsMoveFromTitleBarOnly(value);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private native boolean nGetConfigWindowsMoveFromTitleBarOnly();
/*      */ 
/*      */ 
/*      */   
/*      */   private native void nSetConfigWindowsMoveFromTitleBarOnly(boolean paramBoolean);
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean getConfigMemoryCompactTimer() {
/*  783 */     return nGetConfigMemoryCompactTimer();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setConfigMemoryCompactTimer(boolean value) {
/*  790 */     nSetConfigMemoryCompactTimer(value);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private native boolean nGetConfigMemoryCompactTimer();
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private native void nSetConfigMemoryCompactTimer(boolean paramBoolean);
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public float getMouseDoubleClickTime() {
/*  809 */     return nGetMouseDoubleClickTime();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setMouseDoubleClickTime(float value) {
/*  816 */     nSetMouseDoubleClickTime(value);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private native float nGetMouseDoubleClickTime();
/*      */ 
/*      */ 
/*      */   
/*      */   private native void nSetMouseDoubleClickTime(float paramFloat);
/*      */ 
/*      */ 
/*      */   
/*      */   public float getMouseDoubleClickMaxDist() {
/*  831 */     return nGetMouseDoubleClickMaxDist();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setMouseDoubleClickMaxDist(float value) {
/*  838 */     nSetMouseDoubleClickMaxDist(value);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private native float nGetMouseDoubleClickMaxDist();
/*      */ 
/*      */ 
/*      */   
/*      */   private native void nSetMouseDoubleClickMaxDist(float paramFloat);
/*      */ 
/*      */ 
/*      */   
/*      */   public float getMouseDragThreshold() {
/*  853 */     return nGetMouseDragThreshold();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setMouseDragThreshold(float value) {
/*  860 */     nSetMouseDragThreshold(value);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private native float nGetMouseDragThreshold();
/*      */ 
/*      */ 
/*      */   
/*      */   private native void nSetMouseDragThreshold(float paramFloat);
/*      */ 
/*      */ 
/*      */   
/*      */   public float getKeyRepeatDelay() {
/*  875 */     return nGetKeyRepeatDelay();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setKeyRepeatDelay(float value) {
/*  882 */     nSetKeyRepeatDelay(value);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private native float nGetKeyRepeatDelay();
/*      */ 
/*      */ 
/*      */   
/*      */   private native void nSetKeyRepeatDelay(float paramFloat);
/*      */ 
/*      */ 
/*      */   
/*      */   public float getKeyRepeatRate() {
/*  897 */     return nGetKeyRepeatRate();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setKeyRepeatRate(float value) {
/*  904 */     nSetKeyRepeatRate(value);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private native float nGetKeyRepeatRate();
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private native void nSetKeyRepeatRate(float paramFloat);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean getConfigDebugIsDebuggerPresent() {
/*  926 */     return nGetConfigDebugIsDebuggerPresent();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setConfigDebugIsDebuggerPresent(boolean value) {
/*  936 */     nSetConfigDebugIsDebuggerPresent(value);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private native boolean nGetConfigDebugIsDebuggerPresent();
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private native void nSetConfigDebugIsDebuggerPresent(boolean paramBoolean);
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean getConfigDebugBeginReturnValueOnce() {
/*  955 */     return nGetConfigDebugBeginReturnValueOnce();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setConfigDebugBeginReturnValueOnce(boolean value) {
/*  966 */     nSetConfigDebugBeginReturnValueOnce(value);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private native boolean nGetConfigDebugBeginReturnValueOnce();
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private native void nSetConfigDebugBeginReturnValueOnce(boolean paramBoolean);
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean getConfigDebugBeginReturnValueLoop() {
/*  983 */     return nGetConfigDebugBeginReturnValueLoop();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setConfigDebugBeginReturnValueLoop(boolean value) {
/*  992 */     nSetConfigDebugBeginReturnValueLoop(value);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private native boolean nGetConfigDebugBeginReturnValueLoop();
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private native void nSetConfigDebugBeginReturnValueLoop(boolean paramBoolean);
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean getConfigDebugIgnoreFocusLoss() {
/* 1010 */     return nGetConfigDebugIgnoreFocusLoss();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setConfigDebugIgnoreFocusLoss(boolean value) {
/* 1020 */     nSetConfigDebugIgnoreFocusLoss(value);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private native boolean nGetConfigDebugIgnoreFocusLoss();
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private native void nSetConfigDebugIgnoreFocusLoss(boolean paramBoolean);
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean getConfigDebugIniSettings() {
/* 1036 */     return nGetConfigDebugIniSettings();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setConfigDebugIniSettings(boolean value) {
/* 1044 */     nSetConfigDebugIniSettings(value);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private native boolean nGetConfigDebugIniSettings();
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private native void nSetConfigDebugIniSettings(boolean paramBoolean);
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public String getBackendPlatformName() {
/* 1063 */     return nGetBackendPlatformName();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setBackendPlatformName(String value) {
/* 1070 */     nSetBackendPlatformName(value);
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   private native String nGetBackendPlatformName();
/*      */ 
/*      */ 
/*      */   
/*      */   private native void nSetBackendPlatformName(String paramString);
/*      */ 
/*      */ 
/*      */   
/*      */   public String getBackendRendererName() {
/* 1084 */     return nGetBackendRendererName();
/*      */   }
/*      */   
/*      */   public void setBackendRendererName(String value) {
/* 1088 */     nSetBackendRendererName(value);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private native String nGetBackendRendererName();
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private native void nSetBackendRendererName(String paramString);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public native void setSetClipboardTextFn(ImStrConsumer paramImStrConsumer);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public native void setGetClipboardTextFn(ImStrSupplier paramImStrSupplier);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public short getPlatformLocaleDecimalPoint() {
/* 1140 */     return nGetPlatformLocaleDecimalPoint();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setPlatformLocaleDecimalPoint(short value) {
/* 1148 */     nSetPlatformLocaleDecimalPoint(value);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private native short nGetPlatformLocaleDecimalPoint();
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private native void nSetPlatformLocaleDecimalPoint(short paramShort);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void addKeyEvent(int key, boolean down) {
/* 1169 */     nAddKeyEvent(key, down);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private native void nAddKeyEvent(int paramInt, boolean paramBoolean);
/*      */ 
/*      */ 
/*      */   
/*      */   public void addKeyAnalogEvent(int key, boolean down, float v) {
/* 1180 */     nAddKeyAnalogEvent(key, down, v);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private native void nAddKeyAnalogEvent(int paramInt, boolean paramBoolean, float paramFloat);
/*      */ 
/*      */ 
/*      */   
/*      */   public void addMousePosEvent(float x, float y) {
/* 1191 */     nAddMousePosEvent(x, y);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private native void nAddMousePosEvent(float paramFloat1, float paramFloat2);
/*      */ 
/*      */ 
/*      */   
/*      */   public void addMouseButtonEvent(int button, boolean down) {
/* 1202 */     nAddMouseButtonEvent(button, down);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private native void nAddMouseButtonEvent(int paramInt, boolean paramBoolean);
/*      */ 
/*      */ 
/*      */   
/*      */   public void addMouseWheelEvent(float whX, float whY) {
/* 1213 */     nAddMouseWheelEvent(whX, whY);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private native void nAddMouseWheelEvent(float paramFloat1, float paramFloat2);
/*      */ 
/*      */ 
/*      */   
/*      */   public void addMouseSourceEvent(int source) {
/* 1224 */     nAddMouseSourceEvent(source);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private native void nAddMouseSourceEvent(int paramInt);
/*      */ 
/*      */ 
/*      */   
/*      */   public void addMouseViewportEvent(int id) {
/* 1235 */     nAddMouseViewportEvent(id);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private native void nAddMouseViewportEvent(int paramInt);
/*      */ 
/*      */ 
/*      */   
/*      */   public void addFocusEvent(boolean focused) {
/* 1246 */     nAddFocusEvent(focused);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private native void nAddFocusEvent(boolean paramBoolean);
/*      */ 
/*      */ 
/*      */   
/*      */   public void addInputCharacter(int c) {
/* 1257 */     nAddInputCharacter(c);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private native void nAddInputCharacter(int paramInt);
/*      */ 
/*      */ 
/*      */   
/*      */   public void addInputCharacterUTF16(short c) {
/* 1268 */     nAddInputCharacterUTF16(c);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private native void nAddInputCharacterUTF16(short paramShort);
/*      */ 
/*      */ 
/*      */   
/*      */   public void addInputCharactersUTF8(String str) {
/* 1279 */     nAddInputCharactersUTF8(str);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private native void nAddInputCharactersUTF8(String paramString);
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setKeyEventNativeData(int key, int nativeKeycode, int nativeScancode) {
/* 1292 */     nSetKeyEventNativeData(key, nativeKeycode, nativeScancode);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setKeyEventNativeData(int key, int nativeKeycode, int nativeScancode, int nativeLegacyIndex) {
/* 1299 */     nSetKeyEventNativeData(key, nativeKeycode, nativeScancode, nativeLegacyIndex);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private native void nSetKeyEventNativeData(int paramInt1, int paramInt2, int paramInt3);
/*      */ 
/*      */ 
/*      */   
/*      */   private native void nSetKeyEventNativeData(int paramInt1, int paramInt2, int paramInt3, int paramInt4);
/*      */ 
/*      */ 
/*      */   
/*      */   public void setAppAcceptingEvents(boolean acceptingEvents) {
/* 1314 */     nSetAppAcceptingEvents(acceptingEvents);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private native void nSetAppAcceptingEvents(boolean paramBoolean);
/*      */ 
/*      */ 
/*      */   
/*      */   public void clearEventsQueue() {
/* 1325 */     nClearEventsQueue();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private native void nClearEventsQueue();
/*      */ 
/*      */ 
/*      */   
/*      */   public void clearInputKeys() {
/* 1336 */     nClearInputKeys();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private native void nClearInputKeys();
/*      */ 
/*      */ 
/*      */   
/*      */   public void clearInputMouse() {
/* 1347 */     nClearInputMouse();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private native void nClearInputMouse();
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean getWantCaptureMouse() {
/* 1366 */     return nGetWantCaptureMouse();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setWantCaptureMouse(boolean value) {
/* 1375 */     nSetWantCaptureMouse(value);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private native boolean nGetWantCaptureMouse();
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private native void nSetWantCaptureMouse(boolean paramBoolean);
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean getWantCaptureKeyboard() {
/* 1391 */     return nGetWantCaptureKeyboard();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setWantCaptureKeyboard(boolean value) {
/* 1399 */     nSetWantCaptureKeyboard(value);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private native boolean nGetWantCaptureKeyboard();
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private native void nSetWantCaptureKeyboard(boolean paramBoolean);
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean getWantTextInput() {
/* 1415 */     return nGetWantTextInput();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setWantTextInput(boolean value) {
/* 1423 */     nSetWantTextInput(value);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private native boolean nGetWantTextInput();
/*      */ 
/*      */ 
/*      */   
/*      */   private native void nSetWantTextInput(boolean paramBoolean);
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean getWantSetMousePos() {
/* 1438 */     return nGetWantSetMousePos();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setWantSetMousePos(boolean value) {
/* 1445 */     nSetWantSetMousePos(value);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private native boolean nGetWantSetMousePos();
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private native void nSetWantSetMousePos(boolean paramBoolean);
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean getWantSaveIniSettings() {
/* 1462 */     return nGetWantSaveIniSettings();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setWantSaveIniSettings(boolean value) {
/* 1471 */     nSetWantSaveIniSettings(value);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private native boolean nGetWantSaveIniSettings();
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private native void nSetWantSaveIniSettings(boolean paramBoolean);
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean getNavActive() {
/* 1487 */     return nGetNavActive();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setNavActive(boolean value) {
/* 1495 */     nSetNavActive(value);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private native boolean nGetNavActive();
/*      */ 
/*      */ 
/*      */   
/*      */   private native void nSetNavActive(boolean paramBoolean);
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean getNavVisible() {
/* 1510 */     return nGetNavVisible();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setNavVisible(boolean value) {
/* 1517 */     nSetNavVisible(value);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private native boolean nGetNavVisible();
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private native void nSetNavVisible(boolean paramBoolean);
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public float getFramerate() {
/* 1534 */     return nGetFramerate();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setFramerate(float value) {
/* 1543 */     nSetFramerate(value);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private native float nGetFramerate();
/*      */ 
/*      */ 
/*      */   
/*      */   private native void nSetFramerate(float paramFloat);
/*      */ 
/*      */ 
/*      */   
/*      */   public int getMetricsRenderVertices() {
/* 1558 */     return nGetMetricsRenderVertices();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setMetricsRenderVertices(int value) {
/* 1565 */     nSetMetricsRenderVertices(value);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private native int nGetMetricsRenderVertices();
/*      */ 
/*      */ 
/*      */   
/*      */   private native void nSetMetricsRenderVertices(int paramInt);
/*      */ 
/*      */ 
/*      */   
/*      */   public int getMetricsRenderIndices() {
/* 1580 */     return nGetMetricsRenderIndices();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setMetricsRenderIndices(int value) {
/* 1587 */     nSetMetricsRenderIndices(value);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private native int nGetMetricsRenderIndices();
/*      */ 
/*      */ 
/*      */   
/*      */   private native void nSetMetricsRenderIndices(int paramInt);
/*      */ 
/*      */ 
/*      */   
/*      */   public int getMetricsRenderWindows() {
/* 1602 */     return nGetMetricsRenderWindows();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setMetricsRenderWindows(int value) {
/* 1609 */     nSetMetricsRenderWindows(value);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private native int nGetMetricsRenderWindows();
/*      */ 
/*      */ 
/*      */   
/*      */   private native void nSetMetricsRenderWindows(int paramInt);
/*      */ 
/*      */ 
/*      */   
/*      */   public int getMetricsActiveWindows() {
/* 1624 */     return nGetMetricsActiveWindows();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setMetricsActiveWindows(int value) {
/* 1631 */     nSetMetricsActiveWindows(value);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private native int nGetMetricsActiveWindows();
/*      */ 
/*      */ 
/*      */   
/*      */   private native void nSetMetricsActiveWindows(int paramInt);
/*      */ 
/*      */ 
/*      */   
/*      */   public ImVec2 getMouseDelta() {
/* 1646 */     ImVec2 dst = new ImVec2();
/* 1647 */     nGetMouseDelta(dst);
/* 1648 */     return dst;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public float getMouseDeltaX() {
/* 1655 */     return nGetMouseDeltaX();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public float getMouseDeltaY() {
/* 1662 */     return nGetMouseDeltaY();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void getMouseDelta(ImVec2 dst) {
/* 1669 */     nGetMouseDelta(dst);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setMouseDelta(ImVec2 value) {
/* 1676 */     nSetMouseDelta(value.x, value.y);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setMouseDelta(float valueX, float valueY) {
/* 1683 */     nSetMouseDelta(valueX, valueY);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private native void nGetMouseDelta(ImVec2 paramImVec2);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/* 1707 */   private static final ImGuiContext _GETCTX_1 = new ImGuiContext(0L);
/*      */ 
/*      */   
/*      */   private native float nGetMouseDeltaX();
/*      */   
/*      */   public ImGuiContext getCtx() {
/* 1713 */     _GETCTX_1.ptr = nGetCtx();
/* 1714 */     return _GETCTX_1;
/*      */   }
/*      */ 
/*      */   
/*      */   private native float nGetMouseDeltaY();
/*      */   
/*      */   public void setCtx(ImGuiContext value) {
/* 1721 */     nSetCtx(value.ptr);
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   private native void nSetMouseDelta(float paramFloat1, float paramFloat2);
/*      */ 
/*      */   
/*      */   private native long nGetCtx();
/*      */ 
/*      */   
/*      */   private native void nSetCtx(long paramLong);
/*      */ 
/*      */   
/*      */   public ImVec2 getMousePos() {
/* 1736 */     ImVec2 dst = new ImVec2();
/* 1737 */     nGetMousePos(dst);
/* 1738 */     return dst;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public float getMousePosX() {
/* 1745 */     return nGetMousePosX();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public float getMousePosY() {
/* 1752 */     return nGetMousePosY();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void getMousePos(ImVec2 dst) {
/* 1759 */     nGetMousePos(dst);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setMousePos(ImVec2 value) {
/* 1766 */     nSetMousePos(value.x, value.y);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setMousePos(float valueX, float valueY) {
/* 1773 */     nSetMousePos(valueX, valueY);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private native void nGetMousePos(ImVec2 paramImVec2);
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private native float nGetMousePosX();
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private native float nGetMousePosY();
/*      */ 
/*      */ 
/*      */   
/*      */   private native void nSetMousePos(float paramFloat1, float paramFloat2);
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean[] getMouseDown() {
/* 1798 */     return nGetMouseDown();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean getMouseDown(int idx) {
/* 1806 */     return nGetMouseDown(idx);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setMouseDown(boolean[] value) {
/* 1814 */     nSetMouseDown(value);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setMouseDown(int idx, boolean value) {
/* 1822 */     nSetMouseDown(idx, value);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private native boolean[] nGetMouseDown();
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private native boolean nGetMouseDown(int paramInt);
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private native void nSetMouseDown(boolean[] paramArrayOfboolean);
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private native void nSetMouseDown(int paramInt, boolean paramBoolean);
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public float getMouseWheel() {
/* 1851 */     return nGetMouseWheel();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setMouseWheel(float value) {
/* 1858 */     nSetMouseWheel(value);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private native float nGetMouseWheel();
/*      */ 
/*      */ 
/*      */   
/*      */   private native void nSetMouseWheel(float paramFloat);
/*      */ 
/*      */ 
/*      */   
/*      */   public float getMouseWheelH() {
/* 1873 */     return nGetMouseWheelH();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setMouseWheelH(float value) {
/* 1880 */     nSetMouseWheelH(value);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private native float nGetMouseWheelH();
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private native void nSetMouseWheelH(float paramFloat);
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public int getMouseHoveredViewport() {
/* 1897 */     return nGetMouseHoveredViewport();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setMouseHoveredViewport(int value) {
/* 1906 */     nSetMouseHoveredViewport(value);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private native int nGetMouseHoveredViewport();
/*      */ 
/*      */ 
/*      */   
/*      */   private native void nSetMouseHoveredViewport(int paramInt);
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean getKeyCtrl() {
/* 1921 */     return nGetKeyCtrl();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setKeyCtrl(boolean value) {
/* 1928 */     nSetKeyCtrl(value);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private native boolean nGetKeyCtrl();
/*      */ 
/*      */ 
/*      */   
/*      */   private native void nSetKeyCtrl(boolean paramBoolean);
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean getKeyShift() {
/* 1943 */     return nGetKeyShift();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setKeyShift(boolean value) {
/* 1950 */     nSetKeyShift(value);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private native boolean nGetKeyShift();
/*      */ 
/*      */ 
/*      */   
/*      */   private native void nSetKeyShift(boolean paramBoolean);
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean getKeyAlt() {
/* 1965 */     return nGetKeyAlt();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setKeyAlt(boolean value) {
/* 1972 */     nSetKeyAlt(value);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private native boolean nGetKeyAlt();
/*      */ 
/*      */ 
/*      */   
/*      */   private native void nSetKeyAlt(boolean paramBoolean);
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean getKeySuper() {
/* 1987 */     return nGetKeySuper();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setKeySuper(boolean value) {
/* 1994 */     nSetKeySuper(value);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private native boolean nGetKeySuper();
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private native void nSetKeySuper(boolean paramBoolean);
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public int getKeyMods() {
/* 2011 */     return nGetKeyMods();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setKeyMods(int value) {
/* 2018 */     nSetKeyMods(value);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private native int nGetKeyMods();
/*      */ 
/*      */ 
/*      */   
/*      */   private native void nSetKeyMods(int paramInt);
/*      */ 
/*      */ 
/*      */   
/*      */   public ImGuiKeyData[] getKeysData() {
/* 2033 */     return nGetKeysData();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setKeysData(ImGuiKeyData[] value) {
/* 2040 */     nSetKeysData(value);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private native ImGuiKeyData[] nGetKeysData();
/*      */ 
/*      */ 
/*      */   
/*      */   private native void nSetKeysData(ImGuiKeyData[] paramArrayOfImGuiKeyData);
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean getWantCaptureMouseUnlessPopupClose() {
/* 2055 */     return nGetWantCaptureMouseUnlessPopupClose();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setWantCaptureMouseUnlessPopupClose(boolean value) {
/* 2062 */     nSetWantCaptureMouseUnlessPopupClose(value);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private native boolean nGetWantCaptureMouseUnlessPopupClose();
/*      */ 
/*      */ 
/*      */   
/*      */   private native void nSetWantCaptureMouseUnlessPopupClose(boolean paramBoolean);
/*      */ 
/*      */ 
/*      */   
/*      */   public ImVec2 getMousePosPrev() {
/* 2077 */     ImVec2 dst = new ImVec2();
/* 2078 */     nGetMousePosPrev(dst);
/* 2079 */     return dst;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public float getMousePosPrevX() {
/* 2086 */     return nGetMousePosPrevX();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public float getMousePosPrevY() {
/* 2093 */     return nGetMousePosPrevY();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void getMousePosPrev(ImVec2 dst) {
/* 2100 */     nGetMousePosPrev(dst);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setMousePosPrev(ImVec2 value) {
/* 2107 */     nSetMousePosPrev(value.x, value.y);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setMousePosPrev(float valueX, float valueY) {
/* 2114 */     nSetMousePosPrev(valueX, valueY);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private native void nGetMousePosPrev(ImVec2 paramImVec2);
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private native float nGetMousePosPrevX();
/*      */ 
/*      */ 
/*      */   
/*      */   private native float nGetMousePosPrevY();
/*      */ 
/*      */ 
/*      */   
/*      */   private native void nSetMousePosPrev(float paramFloat1, float paramFloat2);
/*      */ 
/*      */ 
/*      */   
/*      */   public ImVec2[] getMouseClickedPos() {
/* 2138 */     return nGetMouseClickedPos();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setMouseClickedPos(ImVec2[] value) {
/* 2145 */     nSetMouseClickedPos(value);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private native ImVec2[] nGetMouseClickedPos();
/*      */ 
/*      */ 
/*      */   
/*      */   private native void nSetMouseClickedPos(ImVec2[] paramArrayOfImVec2);
/*      */ 
/*      */ 
/*      */   
/*      */   public double[] getMouseClickedTime() {
/* 2160 */     return nGetMouseClickedTime();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public double getMouseClickedTime(int idx) {
/* 2167 */     return nGetMouseClickedTime(idx);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setMouseClickedTime(double[] value) {
/* 2174 */     nSetMouseClickedTime(value);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setMouseClickedTime(int idx, double value) {
/* 2181 */     nSetMouseClickedTime(idx, value);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private native double[] nGetMouseClickedTime();
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private native double nGetMouseClickedTime(int paramInt);
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private native void nSetMouseClickedTime(double[] paramArrayOfdouble);
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private native void nSetMouseClickedTime(int paramInt, double paramDouble);
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean[] getMouseClicked() {
/* 2210 */     return nGetMouseClicked();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean getMouseClicked(int idx) {
/* 2217 */     return nGetMouseClicked(idx);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setMouseClicked(boolean[] value) {
/* 2224 */     nSetMouseClicked(value);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setMouseClicked(int idx, boolean value) {
/* 2231 */     nSetMouseClicked(idx, value);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private native boolean[] nGetMouseClicked();
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private native boolean nGetMouseClicked(int paramInt);
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private native void nSetMouseClicked(boolean[] paramArrayOfboolean);
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private native void nSetMouseClicked(int paramInt, boolean paramBoolean);
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean[] getMouseDoubleClicked() {
/* 2260 */     return nGetMouseDoubleClicked();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean getMouseDoubleClicked(int idx) {
/* 2267 */     return nGetMouseDoubleClicked(idx);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setMouseDoubleClicked(boolean[] value) {
/* 2274 */     nSetMouseDoubleClicked(value);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setMouseDoubleClicked(int idx, boolean value) {
/* 2281 */     nSetMouseDoubleClicked(idx, value);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private native boolean[] nGetMouseDoubleClicked();
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private native boolean nGetMouseDoubleClicked(int paramInt);
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private native void nSetMouseDoubleClicked(boolean[] paramArrayOfboolean);
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private native void nSetMouseDoubleClicked(int paramInt, boolean paramBoolean);
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public int[] getMouseClickedCount() {
/* 2310 */     return nGetMouseClickedCount();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public int getMouseClickedCount(int idx) {
/* 2317 */     return nGetMouseClickedCount(idx);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setMouseClickedCount(int[] value) {
/* 2324 */     nSetMouseClickedCount(value);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setMouseClickedCount(int idx, int value) {
/* 2331 */     nSetMouseClickedCount(idx, value);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private native int[] nGetMouseClickedCount();
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private native int nGetMouseClickedCount(int paramInt);
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private native void nSetMouseClickedCount(int[] paramArrayOfint);
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private native void nSetMouseClickedCount(int paramInt1, int paramInt2);
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public int[] getMouseClickedLastCount() {
/* 2360 */     return nGetMouseClickedLastCount();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public int getMouseClickedLastCount(int idx) {
/* 2367 */     return nGetMouseClickedLastCount(idx);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setMouseClickedLastCount(int[] value) {
/* 2374 */     nSetMouseClickedLastCount(value);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setMouseClickedLastCount(int idx, int value) {
/* 2381 */     nSetMouseClickedLastCount(idx, value);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private native int[] nGetMouseClickedLastCount();
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private native int nGetMouseClickedLastCount(int paramInt);
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private native void nSetMouseClickedLastCount(int[] paramArrayOfint);
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private native void nSetMouseClickedLastCount(int paramInt1, int paramInt2);
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean[] getMouseReleased() {
/* 2410 */     return nGetMouseReleased();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean getMouseReleased(int idx) {
/* 2417 */     return nGetMouseReleased(idx);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setMouseReleased(boolean[] value) {
/* 2424 */     nSetMouseReleased(value);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setMouseReleased(int idx, boolean value) {
/* 2431 */     nSetMouseReleased(idx, value);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private native boolean[] nGetMouseReleased();
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private native boolean nGetMouseReleased(int paramInt);
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private native void nSetMouseReleased(boolean[] paramArrayOfboolean);
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private native void nSetMouseReleased(int paramInt, boolean paramBoolean);
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean[] getMouseDownOwned() {
/* 2460 */     return nGetMouseDownOwned();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean getMouseDownOwned(int idx) {
/* 2467 */     return nGetMouseDownOwned(idx);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setMouseDownOwned(boolean[] value) {
/* 2474 */     nSetMouseDownOwned(value);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setMouseDownOwned(int idx, boolean value) {
/* 2481 */     nSetMouseDownOwned(idx, value);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private native boolean[] nGetMouseDownOwned();
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private native boolean nGetMouseDownOwned(int paramInt);
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private native void nSetMouseDownOwned(boolean[] paramArrayOfboolean);
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private native void nSetMouseDownOwned(int paramInt, boolean paramBoolean);
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean[] getMouseDownOwnedUnlessPopupClose() {
/* 2510 */     return nGetMouseDownOwnedUnlessPopupClose();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean getMouseDownOwnedUnlessPopupClose(int idx) {
/* 2517 */     return nGetMouseDownOwnedUnlessPopupClose(idx);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setMouseDownOwnedUnlessPopupClose(boolean[] value) {
/* 2524 */     nSetMouseDownOwnedUnlessPopupClose(value);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setMouseDownOwnedUnlessPopupClose(int idx, boolean value) {
/* 2531 */     nSetMouseDownOwnedUnlessPopupClose(idx, value);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private native boolean[] nGetMouseDownOwnedUnlessPopupClose();
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private native boolean nGetMouseDownOwnedUnlessPopupClose(int paramInt);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private native void nSetMouseDownOwnedUnlessPopupClose(boolean[] paramArrayOfboolean);
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private native void nSetMouseDownOwnedUnlessPopupClose(int paramInt, boolean paramBoolean);
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean getMouseWheelRequestAxisSwap() {
/* 2561 */     return nGetMouseWheelRequestAxisSwap();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setMouseWheelRequestAxisSwap(boolean value) {
/* 2569 */     nSetMouseWheelRequestAxisSwap(value);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private native boolean nGetMouseWheelRequestAxisSwap();
/*      */ 
/*      */ 
/*      */   
/*      */   private native void nSetMouseWheelRequestAxisSwap(boolean paramBoolean);
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean getMouseCtrlLeftAsRightClick() {
/* 2584 */     return nGetMouseCtrlLeftAsRightClick();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setMouseCtrlLeftAsRightClick(boolean value) {
/* 2591 */     nSetMouseCtrlLeftAsRightClick(value);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private native boolean nGetMouseCtrlLeftAsRightClick();
/*      */ 
/*      */ 
/*      */   
/*      */   private native void nSetMouseCtrlLeftAsRightClick(boolean paramBoolean);
/*      */ 
/*      */ 
/*      */   
/*      */   public float[] getMouseDownDuration() {
/* 2606 */     return nGetMouseDownDuration();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public float getMouseDownDuration(int idx) {
/* 2613 */     return nGetMouseDownDuration(idx);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setMouseDownDuration(float[] value) {
/* 2620 */     nSetMouseDownDuration(value);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setMouseDownDuration(int idx, float value) {
/* 2627 */     nSetMouseDownDuration(idx, value);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private native float[] nGetMouseDownDuration();
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private native float nGetMouseDownDuration(int paramInt);
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private native void nSetMouseDownDuration(float[] paramArrayOffloat);
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private native void nSetMouseDownDuration(int paramInt, float paramFloat);
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public float[] getMouseDownDurationPrev() {
/* 2656 */     return nGetMouseDownDurationPrev();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public float getMouseDownDurationPrev(int idx) {
/* 2663 */     return nGetMouseDownDurationPrev(idx);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setMouseDownDurationPrev(float[] value) {
/* 2670 */     nSetMouseDownDurationPrev(value);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setMouseDownDurationPrev(int idx, float value) {
/* 2677 */     nSetMouseDownDurationPrev(idx, value);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private native float[] nGetMouseDownDurationPrev();
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private native float nGetMouseDownDurationPrev(int paramInt);
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private native void nSetMouseDownDurationPrev(float[] paramArrayOffloat);
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private native void nSetMouseDownDurationPrev(int paramInt, float paramFloat);
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public ImVec2[] getMouseDragMaxDistanceAbs() {
/* 2706 */     return nGetMouseDragMaxDistanceAbs();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setMouseDragMaxDistanceAbs(ImVec2[] value) {
/* 2713 */     nSetMouseDragMaxDistanceAbs(value);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private native ImVec2[] nGetMouseDragMaxDistanceAbs();
/*      */ 
/*      */ 
/*      */   
/*      */   private native void nSetMouseDragMaxDistanceAbs(ImVec2[] paramArrayOfImVec2);
/*      */ 
/*      */ 
/*      */   
/*      */   public float[] getMouseDragMaxDistanceSqr() {
/* 2728 */     return nGetMouseDragMaxDistanceSqr();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public float getMouseDragMaxDistanceSqr(int idx) {
/* 2735 */     return nGetMouseDragMaxDistanceSqr(idx);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setMouseDragMaxDistanceSqr(float[] value) {
/* 2742 */     nSetMouseDragMaxDistanceSqr(value);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setMouseDragMaxDistanceSqr(int idx, float value) {
/* 2749 */     nSetMouseDragMaxDistanceSqr(idx, value);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private native float[] nGetMouseDragMaxDistanceSqr();
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private native float nGetMouseDragMaxDistanceSqr(int paramInt);
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private native void nSetMouseDragMaxDistanceSqr(float[] paramArrayOffloat);
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private native void nSetMouseDragMaxDistanceSqr(int paramInt, float paramFloat);
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public float getPenPressure() {
/* 2778 */     return nGetPenPressure();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setPenPressure(float value) {
/* 2785 */     nSetPenPressure(value);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private native float nGetPenPressure();
/*      */ 
/*      */ 
/*      */   
/*      */   private native void nSetPenPressure(float paramFloat);
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean getAppFocusLost() {
/* 2800 */     return nGetAppFocusLost();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private native boolean nGetAppFocusLost();
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean getAppAcceptingEvents() {
/* 2811 */     return nGetAppAcceptingEvents();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private native boolean nGetAppAcceptingEvents();
/*      */ 
/*      */ 
/*      */   
/*      */   public short getBackendUsingLegacyKeyArrays() {
/* 2822 */     return nGetBackendUsingLegacyKeyArrays();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setBackendUsingLegacyKeyArrays(short value) {
/* 2829 */     nSetBackendUsingLegacyKeyArrays(value);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private native short nGetBackendUsingLegacyKeyArrays();
/*      */ 
/*      */ 
/*      */   
/*      */   private native void nSetBackendUsingLegacyKeyArrays(short paramShort);
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean getBackendUsingLegacyNavInputArray() {
/* 2844 */     return nGetBackendUsingLegacyNavInputArray();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setBackendUsingLegacyNavInputArray(boolean value) {
/* 2851 */     nSetBackendUsingLegacyNavInputArray(value);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private native boolean nGetBackendUsingLegacyNavInputArray();
/*      */ 
/*      */ 
/*      */   
/*      */   private native void nSetBackendUsingLegacyNavInputArray(boolean paramBoolean);
/*      */ 
/*      */ 
/*      */   
/*      */   public short getInputQueueSurrogate() {
/* 2866 */     return nGetInputQueueSurrogate();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setInputQueueSurrogate(short value) {
/* 2873 */     nSetInputQueueSurrogate(value);
/*      */   }
/*      */   
/*      */   private native short nGetInputQueueSurrogate();
/*      */   
/*      */   private native void nSetInputQueueSurrogate(short paramShort);
/*      */ }


/* Location:              C:\Users\rapha\Downloads\aurora.jar!\META-INF\jars\imgui-java-binding-1.90.0.jar!\imgui\ImGuiIO.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */