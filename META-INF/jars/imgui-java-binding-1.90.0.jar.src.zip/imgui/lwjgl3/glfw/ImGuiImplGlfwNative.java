package imgui.lwjgl3.glfw;

public final class ImGuiImplGlfwNative {
  public static native void win32hideFromTaskBar(long paramLong);
}


/* Location:              C:\Users\rapha\Downloads\aurora.jar!\META-INF\jars\imgui-java-binding-1.90.0.jar!\imgui\lwjgl3\glfw\ImGuiImplGlfwNative.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */