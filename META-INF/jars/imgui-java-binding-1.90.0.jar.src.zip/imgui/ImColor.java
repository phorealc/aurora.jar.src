/*     */ package imgui;
/*     */ 
/*     */ import java.awt.Color;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class ImColor
/*     */ {
/*     */   public static int rgba(int r, int g, int b, int a) {
/*  13 */     return intToColor(r, g, b, a);
/*     */   }
/*     */   
/*     */   public static int rgb(int r, int g, int b) {
/*  17 */     return intToColor(r, g, b);
/*     */   }
/*     */   
/*     */   public static int rgba(float r, float g, float b, float a) {
/*  21 */     return floatToColor(r, g, b, a);
/*     */   }
/*     */   
/*     */   public static int rgb(float r, float g, float b) {
/*  25 */     return floatToColor(r, g, b);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static int rgba(String hex) {
/*  32 */     return rgbaToColor(hex);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static int rgb(String hex) {
/*  39 */     return rgbToColor(hex);
/*     */   }
/*     */   
/*     */   public static int rgba(ImVec4 color) {
/*  43 */     return rgba(color.x, color.y, color.z, color.w);
/*     */   }
/*     */   
/*     */   public static int rgb(ImVec4 color) {
/*  47 */     return rgb(color.x, color.y, color.z);
/*     */   }
/*     */   
/*     */   public static int rgba(Color color) {
/*  51 */     return rgba(color.getRed(), color.getGreen(), color.getBlue(), color.getAlpha());
/*     */   }
/*     */   
/*     */   public static int rgb(Color color) {
/*  55 */     return rgb(color.getRed(), color.getGreen(), color.getBlue());
/*     */   }
/*     */   
/*     */   public static int hsla(float h, float s, float l, float a) {
/*  59 */     return hslToColor(h, s, l, a);
/*     */   }
/*     */   
/*     */   public static int hsl(float h, float s, float l) {
/*  63 */     return hslToColor(h, s, l);
/*     */   }
/*     */   
/*     */   public static int hsla(int h, int s, int l, int a) {
/*  67 */     return hslToColor(h, s, l, a);
/*     */   }
/*     */   
/*     */   public static int hsl(int h, int s, int l) {
/*  71 */     return hslToColor(h, s, l);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Deprecated
/*     */   public static int intToColor(int r, int g, int b, int a) {
/*  79 */     return a << 24 | b << 16 | g << 8 | r;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Deprecated
/*     */   public static int intToColor(int r, int g, int b) {
/*  87 */     return intToColor(r, g, b, 255);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Deprecated
/*     */   public static int floatToColor(float r, float g, float b, float a) {
/*  95 */     return intToColor((int)(r * 255.0F), (int)(g * 255.0F), (int)(b * 255.0F), (int)(a * 255.0F));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Deprecated
/*     */   public static int floatToColor(float r, float g, float b) {
/* 103 */     return floatToColor(r, g, b, 1.0F);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Deprecated
/*     */   public static int rgbToColor(String hex) {
/* 112 */     return intToColor(
/* 113 */         Integer.parseInt(hex.substring(1, 3), 16), 
/* 114 */         Integer.parseInt(hex.substring(3, 5), 16), 
/* 115 */         Integer.parseInt(hex.substring(5, 7), 16));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Deprecated
/*     */   public static int rgbaToColor(String hex) {
/* 125 */     return intToColor(
/* 126 */         Integer.parseInt(hex.substring(1, 3), 16), 
/* 127 */         Integer.parseInt(hex.substring(3, 5), 16), 
/* 128 */         Integer.parseInt(hex.substring(5, 7), 16), 
/* 129 */         Integer.parseInt(hex.substring(7, 9), 16));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Deprecated
/*     */   public static int hslToColor(int h, int s, int l) {
/* 138 */     return hslToColor(h, s, l, 1.0F);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Deprecated
/*     */   public static int hslToColor(int h, int s, int l, float a) {
/* 146 */     return hslToColor(h / 360.0F, s / 100.0F, l / 100.0F, a);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Deprecated
/*     */   public static int hslToColor(float h, float s, float l) {
/* 154 */     return hslToColor(h, s, l, 1.0F);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Deprecated
/*     */   public static int hslToColor(float h, float s, float l, float a) {
/*     */     float r;
/*     */     float g;
/*     */     float b;
/* 169 */     if (s == 0.0F) {
/* 170 */       r = l;
/* 171 */       g = l;
/* 172 */       b = l;
/*     */     } else {
/* 174 */       float q = (l < 0.5D) ? (l * (1.0F + s)) : (l + s - l * s);
/* 175 */       float p = 2.0F * l - q;
/* 176 */       r = hue2rgb(p, q, h + 0.33333334F);
/* 177 */       g = hue2rgb(p, q, h);
/* 178 */       b = hue2rgb(p, q, h - 0.33333334F);
/*     */     } 
/*     */     
/* 181 */     return floatToColor(r, g, b, a);
/*     */   }
/*     */   
/*     */   private static float hue2rgb(float p, float q, float hue) {
/* 185 */     float h = hue;
/*     */     
/* 187 */     if (h < 0.0F) {
/* 188 */       h++;
/*     */     }
/*     */     
/* 191 */     if (h > 1.0F) {
/* 192 */       h--;
/*     */     }
/*     */     
/* 195 */     if (6.0F * h < 1.0F) {
/* 196 */       return p + (q - p) * 6.0F * h;
/*     */     }
/*     */     
/* 199 */     if (2.0F * h < 1.0F) {
/* 200 */       return q;
/*     */     }
/*     */     
/* 203 */     if (3.0F * h < 2.0F) {
/* 204 */       return p + (q - p) * 6.0F * (0.6666667F - h);
/*     */     }
/*     */     
/* 207 */     return p;
/*     */   }
/*     */ }


/* Location:              C:\Users\rapha\Downloads\aurora.jar!\META-INF\jars\imgui-java-binding-1.90.0.jar!\imgui\ImColor.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */