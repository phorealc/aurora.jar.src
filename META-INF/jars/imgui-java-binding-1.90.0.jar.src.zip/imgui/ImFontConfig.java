/*     */ package imgui;
/*     */ 
/*     */ import imgui.binding.ImGuiStructDestroyable;
/*     */ 
/*     */ public final class ImFontConfig extends ImGuiStructDestroyable {
/*     */   private short[] glyphRanges;
/*     */   
/*     */   public ImFontConfig() {}
/*     */   
/*     */   ImFontConfig(long ptr) {
/*  11 */     super(ptr);
/*     */   }
/*     */ 
/*     */   
/*     */   protected long create() {
/*  16 */     return nCreate();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private native long nCreate();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public native byte[] getFontData();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public native void setFontData(byte[] paramArrayOfbyte);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int getFontDataSize() {
/*  51 */     return nGetFontDataSize();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setFontDataSize(int value) {
/*  58 */     nSetFontDataSize(value);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private native int nGetFontDataSize();
/*     */ 
/*     */ 
/*     */   
/*     */   private native void nSetFontDataSize(int paramInt);
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean getFontDataOwnedByAtlas() {
/*  73 */     return nGetFontDataOwnedByAtlas();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setFontDataOwnedByAtlas(boolean value) {
/*  80 */     nSetFontDataOwnedByAtlas(value);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private native boolean nGetFontDataOwnedByAtlas();
/*     */ 
/*     */ 
/*     */   
/*     */   private native void nSetFontDataOwnedByAtlas(boolean paramBoolean);
/*     */ 
/*     */ 
/*     */   
/*     */   public int getFontNo() {
/*  95 */     return nGetFontNo();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setFontNo(int value) {
/* 102 */     nSetFontNo(value);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private native int nGetFontNo();
/*     */ 
/*     */ 
/*     */   
/*     */   private native void nSetFontNo(int paramInt);
/*     */ 
/*     */ 
/*     */   
/*     */   public float getSizePixels() {
/* 117 */     return nGetSizePixels();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setSizePixels(float value) {
/* 124 */     nSetSizePixels(value);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private native float nGetSizePixels();
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private native void nSetSizePixels(float paramFloat);
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int getOversampleH() {
/* 141 */     return nGetOversampleH();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setOversampleH(int value) {
/* 150 */     nSetOversampleH(value);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private native int nGetOversampleH();
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private native void nSetOversampleH(int paramInt);
/*     */ 
/*     */ 
/*     */   
/*     */   public int getOversampleV() {
/* 166 */     return nGetOversampleV();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setOversampleV(int value) {
/* 174 */     nSetOversampleV(value);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private native int nGetOversampleV();
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private native void nSetOversampleV(int paramInt);
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean getPixelSnapH() {
/* 190 */     return nGetPixelSnapH();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setPixelSnapH(boolean value) {
/* 198 */     nSetPixelSnapH(value);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private native boolean nGetPixelSnapH();
/*     */ 
/*     */ 
/*     */   
/*     */   private native void nSetPixelSnapH(boolean paramBoolean);
/*     */ 
/*     */ 
/*     */   
/*     */   public ImVec2 getGlyphExtraSpacing() {
/* 213 */     ImVec2 dst = new ImVec2();
/* 214 */     nGetGlyphExtraSpacing(dst);
/* 215 */     return dst;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public float getGlyphExtraSpacingX() {
/* 222 */     return nGetGlyphExtraSpacingX();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public float getGlyphExtraSpacingY() {
/* 229 */     return nGetGlyphExtraSpacingY();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void getGlyphExtraSpacing(ImVec2 dst) {
/* 236 */     nGetGlyphExtraSpacing(dst);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setGlyphExtraSpacing(ImVec2 value) {
/* 243 */     nSetGlyphExtraSpacing(value.x, value.y);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setGlyphExtraSpacing(float valueX, float valueY) {
/* 250 */     nSetGlyphExtraSpacing(valueX, valueY);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private native void nGetGlyphExtraSpacing(ImVec2 paramImVec2);
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private native float nGetGlyphExtraSpacingX();
/*     */ 
/*     */ 
/*     */   
/*     */   private native float nGetGlyphExtraSpacingY();
/*     */ 
/*     */ 
/*     */   
/*     */   private native void nSetGlyphExtraSpacing(float paramFloat1, float paramFloat2);
/*     */ 
/*     */ 
/*     */   
/*     */   public ImVec2 getGlyphOffset() {
/* 274 */     ImVec2 dst = new ImVec2();
/* 275 */     nGetGlyphOffset(dst);
/* 276 */     return dst;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public float getGlyphOffsetX() {
/* 283 */     return nGetGlyphOffsetX();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public float getGlyphOffsetY() {
/* 290 */     return nGetGlyphOffsetY();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void getGlyphOffset(ImVec2 dst) {
/* 297 */     nGetGlyphOffset(dst);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setGlyphOffset(ImVec2 value) {
/* 304 */     nSetGlyphOffset(value.x, value.y);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setGlyphOffset(float valueX, float valueY) {
/* 311 */     nSetGlyphOffset(valueX, valueY);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private native void nGetGlyphOffset(ImVec2 paramImVec2);
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private native float nGetGlyphOffsetX();
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private native float nGetGlyphOffsetY();
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private native void nSetGlyphOffset(float paramFloat1, float paramFloat2);
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public short[] getGlyphRanges() {
/* 338 */     return this.glyphRanges;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setGlyphRanges(short[] glyphRanges) {
/* 346 */     this.glyphRanges = glyphRanges;
/* 347 */     nSetGlyphRanges(glyphRanges);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private native void nSetGlyphRanges(short[] paramArrayOfshort);
/*     */ 
/*     */ 
/*     */   
/*     */   public float getGlyphMinAdvanceX() {
/* 358 */     return nGetGlyphMinAdvanceX();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setGlyphMinAdvanceX(float value) {
/* 365 */     nSetGlyphMinAdvanceX(value);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private native float nGetGlyphMinAdvanceX();
/*     */ 
/*     */ 
/*     */   
/*     */   private native void nSetGlyphMinAdvanceX(float paramFloat);
/*     */ 
/*     */ 
/*     */   
/*     */   public float getGlyphMaxAdvanceX() {
/* 380 */     return nGetGlyphMaxAdvanceX();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setGlyphMaxAdvanceX(float value) {
/* 387 */     nSetGlyphMaxAdvanceX(value);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private native float nGetGlyphMaxAdvanceX();
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private native void nSetGlyphMaxAdvanceX(float paramFloat);
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean getMergeMode() {
/* 403 */     return nGetMergeMode();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setMergeMode(boolean value) {
/* 411 */     nSetMergeMode(value);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private native boolean nGetMergeMode();
/*     */ 
/*     */ 
/*     */   
/*     */   private native void nSetMergeMode(boolean paramBoolean);
/*     */ 
/*     */ 
/*     */   
/*     */   public int getFontBuilderFlags() {
/* 426 */     return nGetFontBuilderFlags();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setFontBuilderFlags(int value) {
/* 433 */     nSetFontBuilderFlags(value);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void addFontBuilderFlags(int flags) {
/* 440 */     setFontBuilderFlags(getFontBuilderFlags() | flags);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void removeFontBuilderFlags(int flags) {
/* 447 */     setFontBuilderFlags(getFontBuilderFlags() & (flags ^ 0xFFFFFFFF));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean hasFontBuilderFlags(int flags) {
/* 454 */     return ((getFontBuilderFlags() & flags) != 0);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private native int nGetFontBuilderFlags();
/*     */ 
/*     */ 
/*     */   
/*     */   private native void nSetFontBuilderFlags(int paramInt);
/*     */ 
/*     */ 
/*     */   
/*     */   public float getRasterizerMultiply() {
/* 469 */     return nGetRasterizerMultiply();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setRasterizerMultiply(float value) {
/* 476 */     nSetRasterizerMultiply(value);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private native float nGetRasterizerMultiply();
/*     */ 
/*     */ 
/*     */   
/*     */   private native void nSetRasterizerMultiply(float paramFloat);
/*     */ 
/*     */ 
/*     */   
/*     */   public float getRasterizerDensity() {
/* 491 */     return nGetRasterizerDensity();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setRasterizerDensity(float value) {
/* 498 */     nSetRasterizerDensity(value);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private native float nGetRasterizerDensity();
/*     */ 
/*     */ 
/*     */   
/*     */   private native void nSetRasterizerDensity(float paramFloat);
/*     */ 
/*     */ 
/*     */   
/*     */   public short getEllipsisChar() {
/* 513 */     return nGetEllipsisChar();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setEllipsisChar(short value) {
/* 520 */     nSetEllipsisChar(value);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private native short nGetEllipsisChar();
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private native void nSetEllipsisChar(short paramShort);
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public native void setName(String paramString);
/*     */ 
/*     */ 
/*     */   
/*     */   public ImFont getDstFont() {
/* 541 */     return new ImFont(nGetDstFont());
/*     */   }
/*     */   
/*     */   public void setDstFont(ImFont value) {
/* 545 */     nSetDstFont(value.ptr);
/*     */   }
/*     */   
/*     */   private native long nGetDstFont();
/*     */   
/*     */   private native void nSetDstFont(long paramLong);
/*     */ }


/* Location:              C:\Users\rapha\Downloads\aurora.jar!\META-INF\jars\imgui-java-binding-1.90.0.jar!\imgui\ImFontConfig.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */