/*     */ package imgui;
/*     */ 
/*     */ import imgui.binding.ImGuiStructDestroyable;
/*     */ import imgui.callback.ImListClipperCallback;
/*     */ import imgui.internal.ImGuiContext;
/*     */ import java.util.function.Consumer;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class ImGuiListClipper
/*     */   extends ImGuiStructDestroyable
/*     */ {
/*     */   public ImGuiListClipper() {}
/*     */   
/*     */   public ImGuiListClipper(long ptr) {
/*  39 */     super(ptr);
/*     */   }
/*     */ 
/*     */   
/*     */   protected long create() {
/*  44 */     return nCreate();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  56 */   private static final ImGuiContext _GETCTX_1 = new ImGuiContext(0L);
/*     */ 
/*     */   
/*     */   private native long nCreate();
/*     */   
/*     */   public ImGuiContext getCtx() {
/*  62 */     _GETCTX_1.ptr = nGetCtx();
/*  63 */     return _GETCTX_1;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setCtx(ImGuiContext value) {
/*  70 */     nSetCtx(value.ptr);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private native long nGetCtx();
/*     */ 
/*     */   
/*     */   private native void nSetCtx(long paramLong);
/*     */ 
/*     */   
/*     */   public int getDisplayStart() {
/*  82 */     return nGetDisplayStart();
/*     */   }
/*     */   
/*     */   public void setDisplayStart(int value) {
/*  86 */     nSetDisplayStart(value);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private native int nGetDisplayStart();
/*     */ 
/*     */   
/*     */   private native void nSetDisplayStart(int paramInt);
/*     */ 
/*     */   
/*     */   public int getDisplayEnd() {
/*  98 */     return nGetDisplayEnd();
/*     */   }
/*     */   
/*     */   public void setDisplayEnd(int value) {
/* 102 */     nSetDisplayEnd(value);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private native int nGetDisplayEnd();
/*     */ 
/*     */   
/*     */   private native void nSetDisplayEnd(int paramInt);
/*     */ 
/*     */   
/*     */   public int getItemsCount() {
/* 114 */     return nGetItemsCount();
/*     */   }
/*     */ 
/*     */   
/*     */   private native int nGetItemsCount();
/*     */ 
/*     */   
/*     */   public float getItemsHeight() {
/* 122 */     return nGetItemsHeight();
/*     */   }
/*     */ 
/*     */   
/*     */   private native float nGetItemsHeight();
/*     */ 
/*     */   
/*     */   public float getStartPosY() {
/* 130 */     return nGetStartPosY();
/*     */   }
/*     */ 
/*     */   
/*     */   private native float nGetStartPosY();
/*     */ 
/*     */   
/*     */   public void begin(int itemsCount) {
/* 138 */     nBegin(itemsCount);
/*     */   }
/*     */   
/*     */   public void begin(int itemsCount, float itemsHeight) {
/* 142 */     nBegin(itemsCount, itemsHeight);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private native void nBegin(int paramInt);
/*     */ 
/*     */ 
/*     */   
/*     */   private native void nBegin(int paramInt, float paramFloat);
/*     */ 
/*     */ 
/*     */   
/*     */   public void end() {
/* 157 */     nEnd();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private native void nEnd();
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean step() {
/* 168 */     return nStep();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private native boolean nStep();
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void includeItemByIndex(int itemIndex) {
/* 180 */     nIncludeItemByIndex(itemIndex);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private native void nIncludeItemByIndex(int paramInt);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void includeItemsByIndex(int itemBegin, int itemEnd) {
/* 195 */     nIncludeItemsByIndex(itemBegin, itemEnd);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private native void nIncludeItemsByIndex(int paramInt1, int paramInt2);
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static void forEach(Consumer<ImGuiListClipper> clipAction) {
/* 208 */     ImGuiListClipper clipper = new ImGuiListClipper();
/* 209 */     clipAction.accept(clipper);
/* 210 */     clipper.destroy();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static void forEach(int itemsCount, ImListClipperCallback callback) {
/* 219 */     nForEach(itemsCount, -1, callback);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static void forEach(int itemsCount, int itemsHeight, ImListClipperCallback callback) {
/* 230 */     nForEach(itemsCount, itemsHeight, callback);
/*     */   }
/*     */   
/*     */   private static native void nForEach(int paramInt1, int paramInt2, ImListClipperCallback paramImListClipperCallback);
/*     */ }


/* Location:              C:\Users\rapha\Downloads\aurora.jar!\META-INF\jars\imgui-java-binding-1.90.0.jar!\imgui\ImGuiListClipper.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */