/*    */ package imgui;
/*    */ 
/*    */ import java.util.Objects;
/*    */ 
/*    */ 
/*    */ 
/*    */ public final class ImVec4
/*    */   implements Cloneable
/*    */ {
/*    */   public float x;
/*    */   public float y;
/*    */   public float z;
/*    */   public float w;
/*    */   
/*    */   public ImVec4() {}
/*    */   
/*    */   public ImVec4(float x, float y, float z, float w) {
/* 18 */     set(x, y, z, w);
/*    */   }
/*    */   
/*    */   public ImVec4(ImVec4 value) {
/* 22 */     set(value.x, value.y, value.z, value.w);
/*    */   }
/*    */   
/*    */   public ImVec4 set(float x, float y, float z, float w) {
/* 26 */     this.x = x;
/* 27 */     this.y = y;
/* 28 */     this.z = z;
/* 29 */     this.w = w;
/* 30 */     return this;
/*    */   }
/*    */   
/*    */   public ImVec4 set(ImVec4 value) {
/* 34 */     return set(value.x, value.y, value.z, value.w);
/*    */   }
/*    */   
/*    */   public ImVec4 plus(float x, float y, float z, float w) {
/* 38 */     return new ImVec4(this.x + x, this.y + y, this.z + z, this.w + w);
/*    */   }
/*    */   
/*    */   public ImVec4 plus(ImVec4 value) {
/* 42 */     return plus(value.x, value.y, value.z, value.w);
/*    */   }
/*    */   
/*    */   public ImVec4 minus(float x, float y, float z, float w) {
/* 46 */     return new ImVec4(this.x - x, this.y - y, this.z - z, this.w - w);
/*    */   }
/*    */   
/*    */   public ImVec4 minus(ImVec4 value) {
/* 50 */     return minus(value.x, value.y, value.z, value.w);
/*    */   }
/*    */   
/*    */   public ImVec4 times(float x, float y, float z, float w) {
/* 54 */     return new ImVec4(this.x * x, this.y * y, this.z * z, this.w * w);
/*    */   }
/*    */   
/*    */   public ImVec4 times(ImVec4 value) {
/* 58 */     return times(value.x, value.y, value.z, value.w);
/*    */   }
/*    */   
/*    */   public ImVec4 div(float x, float y, float z, float w) {
/* 62 */     return new ImVec4(this.x / x, this.y / y, this.z / z, this.w / w);
/*    */   }
/*    */   
/*    */   public ImVec4 div(ImVec4 value) {
/* 66 */     return div(value.x, value.y, value.z, value.w);
/*    */   }
/*    */ 
/*    */   
/*    */   public String toString() {
/* 71 */     return "ImVec4{x=" + this.x + ", y=" + this.y + ", z=" + this.z + ", w=" + this.w + '}';
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public boolean equals(Object o) {
/* 81 */     if (this == o) {
/* 82 */       return true;
/*    */     }
/* 84 */     if (o == null || getClass() != o.getClass()) {
/* 85 */       return false;
/*    */     }
/* 87 */     ImVec4 imVec4 = (ImVec4)o;
/* 88 */     return (Float.compare(imVec4.x, this.x) == 0 && Float.compare(imVec4.y, this.y) == 0 && Float.compare(imVec4.z, this.z) == 0 && Float.compare(imVec4.w, this.w) == 0);
/*    */   }
/*    */ 
/*    */   
/*    */   public int hashCode() {
/* 93 */     return Objects.hash(new Object[] { Float.valueOf(this.x), Float.valueOf(this.y), Float.valueOf(this.z), Float.valueOf(this.w) });
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public ImVec4 clone() {
/* 99 */     return new ImVec4(this);
/*    */   }
/*    */ }


/* Location:              C:\Users\rapha\Downloads\aurora.jar!\META-INF\jars\imgui-java-binding-1.90.0.jar!\imgui\ImVec4.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */