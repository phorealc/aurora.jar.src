/*     */ package imgui;
/*     */ 
/*     */ import imgui.binding.ImGuiStructDestroyable;
/*     */ import imgui.type.ImInt;
/*     */ import java.nio.ByteBuffer;
/*     */ import java.nio.ByteOrder;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class ImFontAtlas
/*     */   extends ImGuiStructDestroyable
/*     */ {
/*  29 */   private ByteBuffer alpha8pixels = null;
/*  30 */   private ByteBuffer rgba32pixels = null;
/*     */ 
/*     */   
/*     */   public ImFontAtlas() {}
/*     */ 
/*     */   
/*     */   public ImFontAtlas(long ptr) {
/*  37 */     super(ptr);
/*     */   }
/*     */ 
/*     */   
/*     */   protected long create() {
/*  42 */     return nCreate();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static native void nInit();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private native long nCreate();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ImFont addFont(ImFontConfig imFontConfig) {
/*  64 */     return new ImFont(nAddFont(imFontConfig.ptr));
/*     */   }
/*     */ 
/*     */   
/*     */   private native long nAddFont(long paramLong);
/*     */ 
/*     */   
/*     */   public ImFont addFontDefault() {
/*  72 */     return new ImFont(nAddFontDefault());
/*     */   }
/*     */   
/*     */   public ImFont addFontDefault(ImFontConfig imFontConfig) {
/*  76 */     return new ImFont(nAddFontDefault(imFontConfig.ptr));
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private native long nAddFontDefault();
/*     */ 
/*     */   
/*     */   private native long nAddFontDefault(long paramLong);
/*     */ 
/*     */   
/*     */   public ImFont addFontFromFileTTF(String filename, float sizePixels) {
/*  88 */     return new ImFont(nAddFontFromFileTTF(filename, sizePixels));
/*     */   }
/*     */   
/*     */   public ImFont addFontFromFileTTF(String filename, float sizePixels, ImFontConfig fontConfig) {
/*  92 */     return new ImFont(nAddFontFromFileTTF(filename, sizePixels, fontConfig.ptr));
/*     */   }
/*     */   
/*     */   public ImFont addFontFromFileTTF(String filename, float sizePixels, ImFontConfig fontConfig, short[] glyphRanges) {
/*  96 */     return new ImFont(nAddFontFromFileTTF(filename, sizePixels, fontConfig.ptr, glyphRanges));
/*     */   }
/*     */   
/*     */   public ImFont addFontFromFileTTF(String filename, float sizePixels, short[] glyphRanges) {
/* 100 */     return new ImFont(nAddFontFromFileTTF(filename, sizePixels, glyphRanges));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private native long nAddFontFromFileTTF(String paramString, float paramFloat);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private native long nAddFontFromFileTTF(String paramString, float paramFloat, long paramLong);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private native long nAddFontFromFileTTF(String paramString, float paramFloat, long paramLong, short[] paramArrayOfshort);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private native long nAddFontFromFileTTF(String paramString, float paramFloat, short[] paramArrayOfshort);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ImFont addFontFromMemoryTTF(byte[] fontData, float sizePixels) {
/* 140 */     return new ImFont(nAddFontFromMemoryTTF(fontData, sizePixels));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ImFont addFontFromMemoryTTF(byte[] fontData, float sizePixels, ImFontConfig fontConfig) {
/* 148 */     return new ImFont(nAddFontFromMemoryTTF(fontData, sizePixels, fontConfig.ptr));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ImFont addFontFromMemoryTTF(byte[] fontData, float sizePixels, ImFontConfig fontConfig, short[] glyphRanges) {
/* 156 */     return new ImFont(nAddFontFromMemoryTTF(fontData, sizePixels, fontConfig.ptr, glyphRanges));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ImFont addFontFromMemoryTTF(byte[] fontData, float sizePixels, short[] glyphRanges) {
/* 164 */     return new ImFont(nAddFontFromMemoryTTF(fontData, sizePixels, glyphRanges));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private native long nAddFontFromMemoryTTF(byte[] paramArrayOfbyte, float paramFloat);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private native long nAddFontFromMemoryTTF(byte[] paramArrayOfbyte, float paramFloat, long paramLong);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private native long nAddFontFromMemoryTTF(byte[] paramArrayOfbyte, float paramFloat, long paramLong, short[] paramArrayOfshort);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private native long nAddFontFromMemoryTTF(byte[] paramArrayOfbyte, float paramFloat, short[] paramArrayOfshort);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ImFont addFontFromMemoryTTF(byte[] fontData, int fontDataSize, float sizePixels) {
/* 204 */     return new ImFont(nAddFontFromMemoryTTF(fontData, fontDataSize, sizePixels));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ImFont addFontFromMemoryTTF(byte[] fontData, int fontDataSize, float sizePixels, ImFontConfig fontConfig) {
/* 212 */     return new ImFont(nAddFontFromMemoryTTF(fontData, fontDataSize, sizePixels, fontConfig.ptr));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ImFont addFontFromMemoryTTF(byte[] fontData, int fontDataSize, float sizePixels, ImFontConfig fontConfig, short[] glyphRanges) {
/* 220 */     return new ImFont(nAddFontFromMemoryTTF(fontData, fontDataSize, sizePixels, fontConfig.ptr, glyphRanges));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ImFont addFontFromMemoryTTF(byte[] fontData, int fontDataSize, float sizePixels, short[] glyphRanges) {
/* 228 */     return new ImFont(nAddFontFromMemoryTTF(fontData, fontDataSize, sizePixels, glyphRanges));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private native long nAddFontFromMemoryTTF(byte[] paramArrayOfbyte, int paramInt, float paramFloat);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private native long nAddFontFromMemoryTTF(byte[] paramArrayOfbyte, int paramInt, float paramFloat, long paramLong);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private native long nAddFontFromMemoryTTF(byte[] paramArrayOfbyte, int paramInt, float paramFloat, long paramLong, short[] paramArrayOfshort);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private native long nAddFontFromMemoryTTF(byte[] paramArrayOfbyte, int paramInt, float paramFloat, short[] paramArrayOfshort);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ImFont addFontFromMemoryCompressedTTF(byte[] compressedFontData, float sizePixels) {
/* 267 */     return new ImFont(nAddFontFromMemoryCompressedTTF(compressedFontData, sizePixels));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ImFont addFontFromMemoryCompressedTTF(byte[] compressedFontData, float sizePixels, ImFontConfig imFontConfig) {
/* 274 */     return new ImFont(nAddFontFromMemoryCompressedTTF(compressedFontData, sizePixels, imFontConfig.ptr));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ImFont addFontFromMemoryCompressedTTF(byte[] compressedFontData, float sizePixels, ImFontConfig imFontConfig, short[] glyphRanges) {
/* 281 */     return new ImFont(nAddFontFromMemoryCompressedTTF(compressedFontData, sizePixels, imFontConfig.ptr, glyphRanges));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ImFont addFontFromMemoryCompressedTTF(byte[] compressedFontData, float sizePixels, short[] glyphRanges) {
/* 288 */     return new ImFont(nAddFontFromMemoryCompressedTTF(compressedFontData, sizePixels, glyphRanges));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private native long nAddFontFromMemoryCompressedTTF(byte[] paramArrayOfbyte, float paramFloat);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private native long nAddFontFromMemoryCompressedTTF(byte[] paramArrayOfbyte, float paramFloat, long paramLong);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private native long nAddFontFromMemoryCompressedTTF(byte[] paramArrayOfbyte, float paramFloat, long paramLong, short[] paramArrayOfshort);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private native long nAddFontFromMemoryCompressedTTF(byte[] paramArrayOfbyte, float paramFloat, short[] paramArrayOfshort);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ImFont addFontFromMemoryCompressedTTF(byte[] compressedFontData, int compressedFontDataSize, float sizePixels) {
/* 327 */     return new ImFont(nAddFontFromMemoryCompressedTTF(compressedFontData, compressedFontDataSize, sizePixels));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ImFont addFontFromMemoryCompressedTTF(byte[] compressedFontData, int compressedFontDataSize, float sizePixels, ImFontConfig imFontConfig) {
/* 334 */     return new ImFont(nAddFontFromMemoryCompressedTTF(compressedFontData, compressedFontDataSize, sizePixels, imFontConfig.ptr));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ImFont addFontFromMemoryCompressedTTF(byte[] compressedFontData, int compressedFontDataSize, float sizePixels, ImFontConfig imFontConfig, short[] glyphRanges) {
/* 341 */     return new ImFont(nAddFontFromMemoryCompressedTTF(compressedFontData, compressedFontDataSize, sizePixels, imFontConfig.ptr, glyphRanges));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ImFont addFontFromMemoryCompressedTTF(byte[] compressedFontData, int compressedFontDataSize, float sizePixels, short[] glyphRanges) {
/* 348 */     return new ImFont(nAddFontFromMemoryCompressedTTF(compressedFontData, compressedFontDataSize, sizePixels, glyphRanges));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private native long nAddFontFromMemoryCompressedTTF(byte[] paramArrayOfbyte, int paramInt, float paramFloat);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private native long nAddFontFromMemoryCompressedTTF(byte[] paramArrayOfbyte, int paramInt, float paramFloat, long paramLong);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private native long nAddFontFromMemoryCompressedTTF(byte[] paramArrayOfbyte, int paramInt, float paramFloat, long paramLong, short[] paramArrayOfshort);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private native long nAddFontFromMemoryCompressedTTF(byte[] paramArrayOfbyte, int paramInt, float paramFloat, short[] paramArrayOfshort);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ImFont addFontFromMemoryCompressedBase85TTF(String compressedFontDataBase85, float sizePixels, ImFontConfig fontConfig) {
/* 387 */     return new ImFont(nAddFontFromMemoryCompressedBase85TTF(compressedFontDataBase85, sizePixels, fontConfig.ptr));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ImFont addFontFromMemoryCompressedBase85TTF(String compressedFontDataBase85, float sizePixels, ImFontConfig fontConfig, short[] glyphRanges) {
/* 394 */     return new ImFont(nAddFontFromMemoryCompressedBase85TTF(compressedFontDataBase85, sizePixels, fontConfig.ptr, glyphRanges));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private native long nAddFontFromMemoryCompressedBase85TTF(String paramString, float paramFloat, long paramLong);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private native long nAddFontFromMemoryCompressedBase85TTF(String paramString, float paramFloat, long paramLong, short[] paramArrayOfshort);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void clearInputData() {
/* 417 */     nClearInputData();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private native void nClearInputData();
/*     */ 
/*     */ 
/*     */   
/*     */   public void clearTexData() {
/* 428 */     nClearTexData();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private native void nClearTexData();
/*     */ 
/*     */ 
/*     */   
/*     */   public void clearFonts() {
/* 439 */     nClearFonts();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private native void nClearFonts();
/*     */ 
/*     */ 
/*     */   
/*     */   public void clear() {
/* 450 */     nClear();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private native void nClear();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public native void setFreeTypeRenderer(boolean paramBoolean);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean build() {
/* 493 */     return nBuild();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private native boolean nBuild();
/*     */ 
/*     */ 
/*     */   
/*     */   public ByteBuffer getTexDataAsAlpha8(ImInt outWidth, ImInt outHeight) {
/* 504 */     return getTexDataAsAlpha8(outWidth, outHeight, new ImInt());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ByteBuffer getTexDataAsAlpha8(ImInt outWidth, ImInt outHeight, ImInt outBytesPerPixel) {
/* 511 */     getTexDataAsAlpha8(outWidth.getData(), outHeight.getData(), outBytesPerPixel.getData());
/* 512 */     return this.alpha8pixels;
/*     */   }
/*     */   
/*     */   private ByteBuffer createAlpha8Pixels(int size) {
/* 516 */     if (this.alpha8pixels == null || this.alpha8pixels.limit() != size) {
/* 517 */       this.alpha8pixels = ByteBuffer.allocateDirect(size).order(ByteOrder.nativeOrder());
/*     */     } else {
/* 519 */       this.alpha8pixels.clear();
/*     */     } 
/* 521 */     return this.alpha8pixels;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private native void getTexDataAsAlpha8(int[] paramArrayOfint1, int[] paramArrayOfint2, int[] paramArrayOfint3);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ByteBuffer getTexDataAsRGBA32(ImInt outWidth, ImInt outHeight) {
/* 537 */     return getTexDataAsRGBA32(outWidth, outHeight, new ImInt());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ByteBuffer getTexDataAsRGBA32(ImInt outWidth, ImInt outHeight, ImInt outBytesPerPixel) {
/* 544 */     nGetTexDataAsRGBA32(outWidth.getData(), outHeight.getData(), outBytesPerPixel.getData());
/* 545 */     return this.rgba32pixels;
/*     */   }
/*     */   
/*     */   private ByteBuffer createRgba32Pixels(int size) {
/* 549 */     if (this.rgba32pixels == null || this.rgba32pixels.limit() != size) {
/* 550 */       this.rgba32pixels = ByteBuffer.allocateDirect(size).order(ByteOrder.nativeOrder());
/*     */     } else {
/* 552 */       this.rgba32pixels.clear();
/*     */     } 
/* 554 */     return this.rgba32pixels;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private native void nGetTexDataAsRGBA32(int[] paramArrayOfint1, int[] paramArrayOfint2, int[] paramArrayOfint3);
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isBuilt() {
/* 567 */     return nIsBuilt();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private native boolean nIsBuilt();
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setTexID(long textureID) {
/* 579 */     nSetTexID(textureID);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private native void nSetTexID(long paramLong);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public native short[] getGlyphRangesDefault();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public native short[] getGlyphRangesGreek();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public native short[] getGlyphRangesKorean();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public native short[] getGlyphRangesJapanese();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public native short[] getGlyphRangesChineseFull();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public native short[] getGlyphRangesChineseSimplifiedCommon();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public native short[] getGlyphRangesCyrillic();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public native short[] getGlyphRangesThai();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public native short[] getGlyphRangesVietnamese();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int addCustomRectRegular(int width, int height) {
/* 685 */     return nAddCustomRectRegular(width, height);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private native int nAddCustomRectRegular(int paramInt1, int paramInt2);
/*     */ 
/*     */ 
/*     */   
/*     */   public int addCustomRectFontGlyph(ImFont imFont, short id, int width, int height, float advanceX) {
/* 696 */     return nAddCustomRectFontGlyph(imFont.ptr, id, width, height, advanceX);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int addCustomRectFontGlyph(ImFont imFont, short id, int width, int height, float advanceX, ImVec2 offset) {
/* 703 */     return nAddCustomRectFontGlyph(imFont.ptr, id, width, height, advanceX, offset.x, offset.y);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int addCustomRectFontGlyph(ImFont imFont, short id, int width, int height, float advanceX, float offsetX, float offsetY) {
/* 710 */     return nAddCustomRectFontGlyph(imFont.ptr, id, width, height, advanceX, offsetX, offsetY);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private native int nAddCustomRectFontGlyph(long paramLong, short paramShort, int paramInt1, int paramInt2, float paramFloat);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private native int nAddCustomRectFontGlyph(long paramLong, short paramShort, int paramInt1, int paramInt2, float paramFloat1, float paramFloat2, float paramFloat3);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int getFlags() {
/* 733 */     return nGetFlags();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setFlags(int value) {
/* 740 */     nSetFlags(value);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void addFlags(int flags) {
/* 747 */     setFlags(getFlags() | flags);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void removeFlags(int flags) {
/* 754 */     setFlags(getFlags() & (flags ^ 0xFFFFFFFF));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean hasFlags(int flags) {
/* 761 */     return ((getFlags() & flags) != 0);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private native int nGetFlags();
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private native void nSetFlags(int paramInt);
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int getTexDesiredWidth() {
/* 779 */     return nGetTexDesiredWidth();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setTexDesiredWidth(int value) {
/* 787 */     nSetTexDesiredWidth(value);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private native int nGetTexDesiredWidth();
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private native void nSetTexDesiredWidth(int paramInt);
/*     */ 
/*     */ 
/*     */   
/*     */   public int getTexGlyphPadding() {
/* 803 */     return nGetTexGlyphPadding();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setTexGlyphPadding(int value) {
/* 811 */     nSetTexGlyphPadding(value);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private native int nGetTexGlyphPadding();
/*     */ 
/*     */ 
/*     */   
/*     */   private native void nSetTexGlyphPadding(int paramInt);
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean getLocked() {
/* 826 */     return nGetLocked();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setLocked(boolean value) {
/* 833 */     nSetLocked(value);
/*     */   }
/*     */   
/*     */   private native boolean nGetLocked();
/*     */   
/*     */   private native void nSetLocked(boolean paramBoolean);
/*     */ }


/* Location:              C:\Users\rapha\Downloads\aurora.jar!\META-INF\jars\imgui-java-binding-1.90.0.jar!\imgui\ImFontAtlas.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */