/*      */ package imgui;
/*      */ 
/*      */ import imgui.binding.ImGuiStructDestroyable;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ public final class ImGuiStyle
/*      */   extends ImGuiStructDestroyable
/*      */ {
/*      */   public ImGuiStyle() {}
/*      */   
/*      */   public ImGuiStyle(long ptr) {
/*   16 */     super(ptr);
/*      */   }
/*      */ 
/*      */   
/*      */   protected long create() {
/*   21 */     return nCreate();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private native long nCreate();
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public float getAlpha() {
/*   37 */     return nGetAlpha();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setAlpha(float value) {
/*   44 */     nSetAlpha(value);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private native float nGetAlpha();
/*      */ 
/*      */ 
/*      */   
/*      */   private native void nSetAlpha(float paramFloat);
/*      */ 
/*      */ 
/*      */   
/*      */   public float getDisabledAlpha() {
/*   59 */     return nGetDisabledAlpha();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setDisabledAlpha(float value) {
/*   66 */     nSetDisabledAlpha(value);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private native float nGetDisabledAlpha();
/*      */ 
/*      */ 
/*      */   
/*      */   private native void nSetDisabledAlpha(float paramFloat);
/*      */ 
/*      */ 
/*      */   
/*      */   public ImVec2 getWindowPadding() {
/*   81 */     ImVec2 dst = new ImVec2();
/*   82 */     nGetWindowPadding(dst);
/*   83 */     return dst;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public float getWindowPaddingX() {
/*   90 */     return nGetWindowPaddingX();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public float getWindowPaddingY() {
/*   97 */     return nGetWindowPaddingY();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void getWindowPadding(ImVec2 dst) {
/*  104 */     nGetWindowPadding(dst);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setWindowPadding(ImVec2 value) {
/*  111 */     nSetWindowPadding(value.x, value.y);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setWindowPadding(float valueX, float valueY) {
/*  118 */     nSetWindowPadding(valueX, valueY);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private native void nGetWindowPadding(ImVec2 paramImVec2);
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private native float nGetWindowPaddingX();
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private native float nGetWindowPaddingY();
/*      */ 
/*      */ 
/*      */   
/*      */   private native void nSetWindowPadding(float paramFloat1, float paramFloat2);
/*      */ 
/*      */ 
/*      */   
/*      */   public float getWindowRounding() {
/*  143 */     return nGetWindowRounding();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setWindowRounding(float value) {
/*  151 */     nSetWindowRounding(value);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private native float nGetWindowRounding();
/*      */ 
/*      */ 
/*      */   
/*      */   private native void nSetWindowRounding(float paramFloat);
/*      */ 
/*      */ 
/*      */   
/*      */   public float getWindowBorderSize() {
/*  166 */     return nGetWindowBorderSize();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setWindowBorderSize(float value) {
/*  173 */     nSetWindowBorderSize(value);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private native float nGetWindowBorderSize();
/*      */ 
/*      */ 
/*      */   
/*      */   private native void nSetWindowBorderSize(float paramFloat);
/*      */ 
/*      */ 
/*      */   
/*      */   public ImVec2 getWindowMinSize() {
/*  188 */     ImVec2 dst = new ImVec2();
/*  189 */     nGetWindowMinSize(dst);
/*  190 */     return dst;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public float getWindowMinSizeX() {
/*  197 */     return nGetWindowMinSizeX();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public float getWindowMinSizeY() {
/*  204 */     return nGetWindowMinSizeY();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void getWindowMinSize(ImVec2 dst) {
/*  211 */     nGetWindowMinSize(dst);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setWindowMinSize(ImVec2 value) {
/*  218 */     nSetWindowMinSize(value.x, value.y);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setWindowMinSize(float valueX, float valueY) {
/*  225 */     nSetWindowMinSize(valueX, valueY);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private native void nGetWindowMinSize(ImVec2 paramImVec2);
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private native float nGetWindowMinSizeX();
/*      */ 
/*      */ 
/*      */   
/*      */   private native float nGetWindowMinSizeY();
/*      */ 
/*      */ 
/*      */   
/*      */   private native void nSetWindowMinSize(float paramFloat1, float paramFloat2);
/*      */ 
/*      */ 
/*      */   
/*      */   public ImVec2 getWindowTitleAlign() {
/*  249 */     ImVec2 dst = new ImVec2();
/*  250 */     nGetWindowTitleAlign(dst);
/*  251 */     return dst;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public float getWindowTitleAlignX() {
/*  258 */     return nGetWindowTitleAlignX();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public float getWindowTitleAlignY() {
/*  265 */     return nGetWindowTitleAlignY();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void getWindowTitleAlign(ImVec2 dst) {
/*  272 */     nGetWindowTitleAlign(dst);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setWindowTitleAlign(ImVec2 value) {
/*  279 */     nSetWindowTitleAlign(value.x, value.y);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setWindowTitleAlign(float valueX, float valueY) {
/*  286 */     nSetWindowTitleAlign(valueX, valueY);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private native void nGetWindowTitleAlign(ImVec2 paramImVec2);
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private native float nGetWindowTitleAlignX();
/*      */ 
/*      */ 
/*      */   
/*      */   private native float nGetWindowTitleAlignY();
/*      */ 
/*      */ 
/*      */   
/*      */   private native void nSetWindowTitleAlign(float paramFloat1, float paramFloat2);
/*      */ 
/*      */ 
/*      */   
/*      */   public int getWindowMenuButtonPosition() {
/*  310 */     return nGetWindowMenuButtonPosition();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setWindowMenuButtonPosition(int value) {
/*  317 */     nSetWindowMenuButtonPosition(value);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private native int nGetWindowMenuButtonPosition();
/*      */ 
/*      */ 
/*      */   
/*      */   private native void nSetWindowMenuButtonPosition(int paramInt);
/*      */ 
/*      */ 
/*      */   
/*      */   public float getChildRounding() {
/*  332 */     return nGetChildRounding();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setChildRounding(float value) {
/*  339 */     nSetChildRounding(value);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private native float nGetChildRounding();
/*      */ 
/*      */ 
/*      */   
/*      */   private native void nSetChildRounding(float paramFloat);
/*      */ 
/*      */ 
/*      */   
/*      */   public float getChildBorderSize() {
/*  354 */     return nGetChildBorderSize();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setChildBorderSize(float value) {
/*  361 */     nSetChildBorderSize(value);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private native float nGetChildBorderSize();
/*      */ 
/*      */ 
/*      */   
/*      */   private native void nSetChildBorderSize(float paramFloat);
/*      */ 
/*      */ 
/*      */   
/*      */   public float getPopupRounding() {
/*  376 */     return nGetPopupRounding();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setPopupRounding(float value) {
/*  383 */     nSetPopupRounding(value);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private native float nGetPopupRounding();
/*      */ 
/*      */ 
/*      */   
/*      */   private native void nSetPopupRounding(float paramFloat);
/*      */ 
/*      */ 
/*      */   
/*      */   public float getPopupBorderSize() {
/*  398 */     return nGetPopupBorderSize();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setPopupBorderSize(float value) {
/*  405 */     nSetPopupBorderSize(value);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private native float nGetPopupBorderSize();
/*      */ 
/*      */ 
/*      */   
/*      */   private native void nSetPopupBorderSize(float paramFloat);
/*      */ 
/*      */ 
/*      */   
/*      */   public ImVec2 getFramePadding() {
/*  420 */     ImVec2 dst = new ImVec2();
/*  421 */     nGetFramePadding(dst);
/*  422 */     return dst;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public float getFramePaddingX() {
/*  429 */     return nGetFramePaddingX();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public float getFramePaddingY() {
/*  436 */     return nGetFramePaddingY();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void getFramePadding(ImVec2 dst) {
/*  443 */     nGetFramePadding(dst);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setFramePadding(ImVec2 value) {
/*  450 */     nSetFramePadding(value.x, value.y);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setFramePadding(float valueX, float valueY) {
/*  457 */     nSetFramePadding(valueX, valueY);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private native void nGetFramePadding(ImVec2 paramImVec2);
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private native float nGetFramePaddingX();
/*      */ 
/*      */ 
/*      */   
/*      */   private native float nGetFramePaddingY();
/*      */ 
/*      */ 
/*      */   
/*      */   private native void nSetFramePadding(float paramFloat1, float paramFloat2);
/*      */ 
/*      */ 
/*      */   
/*      */   public float getFrameRounding() {
/*  481 */     return nGetFrameRounding();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setFrameRounding(float value) {
/*  488 */     nSetFrameRounding(value);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private native float nGetFrameRounding();
/*      */ 
/*      */ 
/*      */   
/*      */   private native void nSetFrameRounding(float paramFloat);
/*      */ 
/*      */ 
/*      */   
/*      */   public float getFrameBorderSize() {
/*  503 */     return nGetFrameBorderSize();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setFrameBorderSize(float value) {
/*  510 */     nSetFrameBorderSize(value);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private native float nGetFrameBorderSize();
/*      */ 
/*      */ 
/*      */   
/*      */   private native void nSetFrameBorderSize(float paramFloat);
/*      */ 
/*      */ 
/*      */   
/*      */   public ImVec2 getItemSpacing() {
/*  525 */     ImVec2 dst = new ImVec2();
/*  526 */     nGetItemSpacing(dst);
/*  527 */     return dst;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public float getItemSpacingX() {
/*  534 */     return nGetItemSpacingX();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public float getItemSpacingY() {
/*  541 */     return nGetItemSpacingY();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void getItemSpacing(ImVec2 dst) {
/*  548 */     nGetItemSpacing(dst);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setItemSpacing(ImVec2 value) {
/*  555 */     nSetItemSpacing(value.x, value.y);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setItemSpacing(float valueX, float valueY) {
/*  562 */     nSetItemSpacing(valueX, valueY);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private native void nGetItemSpacing(ImVec2 paramImVec2);
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private native float nGetItemSpacingX();
/*      */ 
/*      */ 
/*      */   
/*      */   private native float nGetItemSpacingY();
/*      */ 
/*      */ 
/*      */   
/*      */   private native void nSetItemSpacing(float paramFloat1, float paramFloat2);
/*      */ 
/*      */ 
/*      */   
/*      */   public ImVec2 getItemInnerSpacing() {
/*  586 */     ImVec2 dst = new ImVec2();
/*  587 */     nGetItemInnerSpacing(dst);
/*  588 */     return dst;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public float getItemInnerSpacingX() {
/*  595 */     return nGetItemInnerSpacingX();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public float getItemInnerSpacingY() {
/*  602 */     return nGetItemInnerSpacingY();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void getItemInnerSpacing(ImVec2 dst) {
/*  609 */     nGetItemInnerSpacing(dst);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setItemInnerSpacing(ImVec2 value) {
/*  616 */     nSetItemInnerSpacing(value.x, value.y);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setItemInnerSpacing(float valueX, float valueY) {
/*  623 */     nSetItemInnerSpacing(valueX, valueY);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private native void nGetItemInnerSpacing(ImVec2 paramImVec2);
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private native float nGetItemInnerSpacingX();
/*      */ 
/*      */ 
/*      */   
/*      */   private native float nGetItemInnerSpacingY();
/*      */ 
/*      */ 
/*      */   
/*      */   private native void nSetItemInnerSpacing(float paramFloat1, float paramFloat2);
/*      */ 
/*      */ 
/*      */   
/*      */   public ImVec2 getCellPadding() {
/*  647 */     ImVec2 dst = new ImVec2();
/*  648 */     nGetCellPadding(dst);
/*  649 */     return dst;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public float getCellPaddingX() {
/*  656 */     return nGetCellPaddingX();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public float getCellPaddingY() {
/*  663 */     return nGetCellPaddingY();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void getCellPadding(ImVec2 dst) {
/*  670 */     nGetCellPadding(dst);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setCellPadding(ImVec2 value) {
/*  677 */     nSetCellPadding(value.x, value.y);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setCellPadding(float valueX, float valueY) {
/*  684 */     nSetCellPadding(valueX, valueY);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private native void nGetCellPadding(ImVec2 paramImVec2);
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private native float nGetCellPaddingX();
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private native float nGetCellPaddingY();
/*      */ 
/*      */ 
/*      */   
/*      */   private native void nSetCellPadding(float paramFloat1, float paramFloat2);
/*      */ 
/*      */ 
/*      */   
/*      */   public ImVec2 getTouchExtraPadding() {
/*  709 */     ImVec2 dst = new ImVec2();
/*  710 */     nGetTouchExtraPadding(dst);
/*  711 */     return dst;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public float getTouchExtraPaddingX() {
/*  719 */     return nGetTouchExtraPaddingX();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public float getTouchExtraPaddingY() {
/*  727 */     return nGetTouchExtraPaddingY();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void getTouchExtraPadding(ImVec2 dst) {
/*  735 */     nGetTouchExtraPadding(dst);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setTouchExtraPadding(ImVec2 value) {
/*  743 */     nSetTouchExtraPadding(value.x, value.y);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setTouchExtraPadding(float valueX, float valueY) {
/*  751 */     nSetTouchExtraPadding(valueX, valueY);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private native void nGetTouchExtraPadding(ImVec2 paramImVec2);
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private native float nGetTouchExtraPaddingX();
/*      */ 
/*      */ 
/*      */   
/*      */   private native float nGetTouchExtraPaddingY();
/*      */ 
/*      */ 
/*      */   
/*      */   private native void nSetTouchExtraPadding(float paramFloat1, float paramFloat2);
/*      */ 
/*      */ 
/*      */   
/*      */   public float getIndentSpacing() {
/*  775 */     return nGetIndentSpacing();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setIndentSpacing(float value) {
/*  782 */     nSetIndentSpacing(value);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private native float nGetIndentSpacing();
/*      */ 
/*      */ 
/*      */   
/*      */   private native void nSetIndentSpacing(float paramFloat);
/*      */ 
/*      */ 
/*      */   
/*      */   public float getColumnsMinSpacing() {
/*  797 */     return nGetColumnsMinSpacing();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setColumnsMinSpacing(float value) {
/*  804 */     nSetColumnsMinSpacing(value);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private native float nGetColumnsMinSpacing();
/*      */ 
/*      */ 
/*      */   
/*      */   private native void nSetColumnsMinSpacing(float paramFloat);
/*      */ 
/*      */ 
/*      */   
/*      */   public float getScrollbarSize() {
/*  819 */     return nGetScrollbarSize();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setScrollbarSize(float value) {
/*  826 */     nSetScrollbarSize(value);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private native float nGetScrollbarSize();
/*      */ 
/*      */ 
/*      */   
/*      */   private native void nSetScrollbarSize(float paramFloat);
/*      */ 
/*      */ 
/*      */   
/*      */   public float getScrollbarRounding() {
/*  841 */     return nGetScrollbarRounding();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setScrollbarRounding(float value) {
/*  848 */     nSetScrollbarRounding(value);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private native float nGetScrollbarRounding();
/*      */ 
/*      */ 
/*      */   
/*      */   private native void nSetScrollbarRounding(float paramFloat);
/*      */ 
/*      */ 
/*      */   
/*      */   public float getGrabMinSize() {
/*  863 */     return nGetGrabMinSize();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setGrabMinSize(float value) {
/*  870 */     nSetGrabMinSize(value);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private native float nGetGrabMinSize();
/*      */ 
/*      */ 
/*      */   
/*      */   private native void nSetGrabMinSize(float paramFloat);
/*      */ 
/*      */ 
/*      */   
/*      */   public float getGrabRounding() {
/*  885 */     return nGetGrabRounding();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setGrabRounding(float value) {
/*  892 */     nSetGrabRounding(value);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private native float nGetGrabRounding();
/*      */ 
/*      */ 
/*      */   
/*      */   private native void nSetGrabRounding(float paramFloat);
/*      */ 
/*      */ 
/*      */   
/*      */   public float getLogSliderDeadzone() {
/*  907 */     return nGetLogSliderDeadzone();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setLogSliderDeadzone(float value) {
/*  914 */     nSetLogSliderDeadzone(value);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private native float nGetLogSliderDeadzone();
/*      */ 
/*      */ 
/*      */   
/*      */   private native void nSetLogSliderDeadzone(float paramFloat);
/*      */ 
/*      */ 
/*      */   
/*      */   public float getTabRounding() {
/*  929 */     return nGetTabRounding();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setTabRounding(float value) {
/*  936 */     nSetTabRounding(value);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private native float nGetTabRounding();
/*      */ 
/*      */ 
/*      */   
/*      */   private native void nSetTabRounding(float paramFloat);
/*      */ 
/*      */ 
/*      */   
/*      */   public float getTabBorderSize() {
/*  951 */     return nGetTabBorderSize();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setTabBorderSize(float value) {
/*  958 */     nSetTabBorderSize(value);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private native float nGetTabBorderSize();
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private native void nSetTabBorderSize(float paramFloat);
/*      */ 
/*      */ 
/*      */   
/*      */   public float getTabMinWidthForCloseButton() {
/*  974 */     return nGetTabMinWidthForCloseButton();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setTabMinWidthForCloseButton(float value) {
/*  982 */     nSetTabMinWidthForCloseButton(value);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private native float nGetTabMinWidthForCloseButton();
/*      */ 
/*      */ 
/*      */   
/*      */   private native void nSetTabMinWidthForCloseButton(float paramFloat);
/*      */ 
/*      */ 
/*      */   
/*      */   public int getColorButtonPosition() {
/*  997 */     return nGetColorButtonPosition();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setColorButtonPosition(int value) {
/* 1004 */     nSetColorButtonPosition(value);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private native int nGetColorButtonPosition();
/*      */ 
/*      */ 
/*      */   
/*      */   private native void nSetColorButtonPosition(int paramInt);
/*      */ 
/*      */ 
/*      */   
/*      */   public ImVec2 getButtonTextAlign() {
/* 1019 */     ImVec2 dst = new ImVec2();
/* 1020 */     nGetButtonTextAlign(dst);
/* 1021 */     return dst;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public float getButtonTextAlignX() {
/* 1028 */     return nGetButtonTextAlignX();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public float getButtonTextAlignY() {
/* 1035 */     return nGetButtonTextAlignY();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void getButtonTextAlign(ImVec2 dst) {
/* 1042 */     nGetButtonTextAlign(dst);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setButtonTextAlign(ImVec2 value) {
/* 1049 */     nSetButtonTextAlign(value.x, value.y);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setButtonTextAlign(float valueX, float valueY) {
/* 1056 */     nSetButtonTextAlign(valueX, valueY);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private native void nGetButtonTextAlign(ImVec2 paramImVec2);
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private native float nGetButtonTextAlignX();
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private native float nGetButtonTextAlignY();
/*      */ 
/*      */ 
/*      */   
/*      */   private native void nSetButtonTextAlign(float paramFloat1, float paramFloat2);
/*      */ 
/*      */ 
/*      */   
/*      */   public ImVec2 getSelectableTextAlign() {
/* 1081 */     ImVec2 dst = new ImVec2();
/* 1082 */     nGetSelectableTextAlign(dst);
/* 1083 */     return dst;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public float getSelectableTextAlignX() {
/* 1091 */     return nGetSelectableTextAlignX();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public float getSelectableTextAlignY() {
/* 1099 */     return nGetSelectableTextAlignY();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void getSelectableTextAlign(ImVec2 dst) {
/* 1107 */     nGetSelectableTextAlign(dst);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setSelectableTextAlign(ImVec2 value) {
/* 1115 */     nSetSelectableTextAlign(value.x, value.y);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setSelectableTextAlign(float valueX, float valueY) {
/* 1123 */     nSetSelectableTextAlign(valueX, valueY);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private native void nGetSelectableTextAlign(ImVec2 paramImVec2);
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private native float nGetSelectableTextAlignX();
/*      */ 
/*      */ 
/*      */   
/*      */   private native float nGetSelectableTextAlignY();
/*      */ 
/*      */ 
/*      */   
/*      */   private native void nSetSelectableTextAlign(float paramFloat1, float paramFloat2);
/*      */ 
/*      */ 
/*      */   
/*      */   public float getSeparatorTextBorderSize() {
/* 1147 */     return nGetSeparatorTextBorderSize();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setSeparatorTextBorderSize(float value) {
/* 1154 */     nSetSeparatorTextBorderSize(value);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private native float nGetSeparatorTextBorderSize();
/*      */ 
/*      */ 
/*      */   
/*      */   private native void nSetSeparatorTextBorderSize(float paramFloat);
/*      */ 
/*      */ 
/*      */   
/*      */   public ImVec2 getSeparatorTextAlign() {
/* 1169 */     ImVec2 dst = new ImVec2();
/* 1170 */     nGetSeparatorTextAlign(dst);
/* 1171 */     return dst;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public float getSeparatorTextAlignX() {
/* 1178 */     return nGetSeparatorTextAlignX();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public float getSeparatorTextAlignY() {
/* 1185 */     return nGetSeparatorTextAlignY();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void getSeparatorTextAlign(ImVec2 dst) {
/* 1192 */     nGetSeparatorTextAlign(dst);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setSeparatorTextAlign(ImVec2 value) {
/* 1199 */     nSetSeparatorTextAlign(value.x, value.y);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setSeparatorTextAlign(float valueX, float valueY) {
/* 1206 */     nSetSeparatorTextAlign(valueX, valueY);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private native void nGetSeparatorTextAlign(ImVec2 paramImVec2);
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private native float nGetSeparatorTextAlignX();
/*      */ 
/*      */ 
/*      */   
/*      */   private native float nGetSeparatorTextAlignY();
/*      */ 
/*      */ 
/*      */   
/*      */   private native void nSetSeparatorTextAlign(float paramFloat1, float paramFloat2);
/*      */ 
/*      */ 
/*      */   
/*      */   public ImVec2 getSeparatorTextPadding() {
/* 1230 */     ImVec2 dst = new ImVec2();
/* 1231 */     nGetSeparatorTextPadding(dst);
/* 1232 */     return dst;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public float getSeparatorTextPaddingX() {
/* 1239 */     return nGetSeparatorTextPaddingX();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public float getSeparatorTextPaddingY() {
/* 1246 */     return nGetSeparatorTextPaddingY();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void getSeparatorTextPadding(ImVec2 dst) {
/* 1253 */     nGetSeparatorTextPadding(dst);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setSeparatorTextPadding(ImVec2 value) {
/* 1260 */     nSetSeparatorTextPadding(value.x, value.y);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setSeparatorTextPadding(float valueX, float valueY) {
/* 1267 */     nSetSeparatorTextPadding(valueX, valueY);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private native void nGetSeparatorTextPadding(ImVec2 paramImVec2);
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private native float nGetSeparatorTextPaddingX();
/*      */ 
/*      */ 
/*      */   
/*      */   private native float nGetSeparatorTextPaddingY();
/*      */ 
/*      */ 
/*      */   
/*      */   private native void nSetSeparatorTextPadding(float paramFloat1, float paramFloat2);
/*      */ 
/*      */ 
/*      */   
/*      */   public ImVec2 getDisplayWindowPadding() {
/* 1291 */     ImVec2 dst = new ImVec2();
/* 1292 */     nGetDisplayWindowPadding(dst);
/* 1293 */     return dst;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public float getDisplayWindowPaddingX() {
/* 1300 */     return nGetDisplayWindowPaddingX();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public float getDisplayWindowPaddingY() {
/* 1307 */     return nGetDisplayWindowPaddingY();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void getDisplayWindowPadding(ImVec2 dst) {
/* 1314 */     nGetDisplayWindowPadding(dst);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setDisplayWindowPadding(ImVec2 value) {
/* 1321 */     nSetDisplayWindowPadding(value.x, value.y);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setDisplayWindowPadding(float valueX, float valueY) {
/* 1328 */     nSetDisplayWindowPadding(valueX, valueY);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private native void nGetDisplayWindowPadding(ImVec2 paramImVec2);
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private native float nGetDisplayWindowPaddingX();
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private native float nGetDisplayWindowPaddingY();
/*      */ 
/*      */ 
/*      */   
/*      */   private native void nSetDisplayWindowPadding(float paramFloat1, float paramFloat2);
/*      */ 
/*      */ 
/*      */   
/*      */   public ImVec2 getDisplaySafeAreaPadding() {
/* 1353 */     ImVec2 dst = new ImVec2();
/* 1354 */     nGetDisplaySafeAreaPadding(dst);
/* 1355 */     return dst;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public float getDisplaySafeAreaPaddingX() {
/* 1363 */     return nGetDisplaySafeAreaPaddingX();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public float getDisplaySafeAreaPaddingY() {
/* 1371 */     return nGetDisplaySafeAreaPaddingY();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void getDisplaySafeAreaPadding(ImVec2 dst) {
/* 1379 */     nGetDisplaySafeAreaPadding(dst);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setDisplaySafeAreaPadding(ImVec2 value) {
/* 1387 */     nSetDisplaySafeAreaPadding(value.x, value.y);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setDisplaySafeAreaPadding(float valueX, float valueY) {
/* 1395 */     nSetDisplaySafeAreaPadding(valueX, valueY);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private native void nGetDisplaySafeAreaPadding(ImVec2 paramImVec2);
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private native float nGetDisplaySafeAreaPaddingX();
/*      */ 
/*      */ 
/*      */   
/*      */   private native float nGetDisplaySafeAreaPaddingY();
/*      */ 
/*      */ 
/*      */   
/*      */   private native void nSetDisplaySafeAreaPadding(float paramFloat1, float paramFloat2);
/*      */ 
/*      */ 
/*      */   
/*      */   public float getDockingSeparatorSize() {
/* 1419 */     return nGetDockingSeparatorSize();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setDockingSeparatorSize(float value) {
/* 1426 */     nSetDockingSeparatorSize(value);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private native float nGetDockingSeparatorSize();
/*      */ 
/*      */ 
/*      */   
/*      */   private native void nSetDockingSeparatorSize(float paramFloat);
/*      */ 
/*      */ 
/*      */   
/*      */   public float getMouseCursorScale() {
/* 1441 */     return nGetMouseCursorScale();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setMouseCursorScale(float value) {
/* 1448 */     nSetMouseCursorScale(value);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private native float nGetMouseCursorScale();
/*      */ 
/*      */ 
/*      */   
/*      */   private native void nSetMouseCursorScale(float paramFloat);
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean getAntiAliasedLines() {
/* 1463 */     return nGetAntiAliasedLines();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setAntiAliasedLines(boolean value) {
/* 1470 */     nSetAntiAliasedLines(value);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private native boolean nGetAntiAliasedLines();
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private native void nSetAntiAliasedLines(boolean paramBoolean);
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean getAntiAliasedLinesUseTex() {
/* 1487 */     return nGetAntiAliasedLinesUseTex();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setAntiAliasedLinesUseTex(boolean value) {
/* 1496 */     nSetAntiAliasedLinesUseTex(value);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private native boolean nGetAntiAliasedLinesUseTex();
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private native void nSetAntiAliasedLinesUseTex(boolean paramBoolean);
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean getAntiAliasedFill() {
/* 1512 */     return nGetAntiAliasedFill();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setAntiAliasedFill(boolean value) {
/* 1520 */     nSetAntiAliasedFill(value);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private native boolean nGetAntiAliasedFill();
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private native void nSetAntiAliasedFill(boolean paramBoolean);
/*      */ 
/*      */ 
/*      */   
/*      */   public float getCurveTessellationTol() {
/* 1536 */     return nGetCurveTessellationTol();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setCurveTessellationTol(float value) {
/* 1544 */     nSetCurveTessellationTol(value);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private native float nGetCurveTessellationTol();
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private native void nSetCurveTessellationTol(float paramFloat);
/*      */ 
/*      */ 
/*      */   
/*      */   public float getCircleTessellationMaxError() {
/* 1560 */     return nGetCircleTessellationMaxError();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setCircleTessellationMaxError(float value) {
/* 1568 */     nSetCircleTessellationMaxError(value);
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   private native float nGetCircleTessellationMaxError();
/*      */ 
/*      */   
/*      */   private native void nSetCircleTessellationMaxError(float paramFloat);
/*      */ 
/*      */   
/*      */   public ImVec4[] getColors() {
/* 1580 */     return nGetColors();
/*      */   }
/*      */   
/*      */   public void setColors(ImVec4[] value) {
/* 1584 */     nSetColors(value);
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   private native ImVec4[] nGetColors();
/*      */ 
/*      */   
/*      */   private native void nSetColors(ImVec4[] paramArrayOfImVec4);
/*      */ 
/*      */   
/*      */   public ImVec4 getColor(int col) {
/* 1596 */     ImVec4 dst = new ImVec4();
/* 1597 */     getColor(col, dst);
/* 1598 */     return dst;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public native void getColor(int paramInt, ImVec4 paramImVec4);
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public native void setColor(int paramInt, float paramFloat1, float paramFloat2, float paramFloat3, float paramFloat4);
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public native void setColor(int paramInt1, int paramInt2, int paramInt3, int paramInt4, int paramInt5);
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public native void setColor(int paramInt1, int paramInt2);
/*      */ 
/*      */ 
/*      */   
/*      */   public float getHoverStationaryDelay() {
/* 1624 */     return nGetHoverStationaryDelay();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setHoverStationaryDelay(float value) {
/* 1631 */     nSetHoverStationaryDelay(value);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private native float nGetHoverStationaryDelay();
/*      */ 
/*      */ 
/*      */   
/*      */   private native void nSetHoverStationaryDelay(float paramFloat);
/*      */ 
/*      */ 
/*      */   
/*      */   public float getHoverDelayShort() {
/* 1646 */     return nGetHoverDelayShort();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setHoverDelayShort(float value) {
/* 1653 */     nSetHoverDelayShort(value);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private native float nGetHoverDelayShort();
/*      */ 
/*      */ 
/*      */   
/*      */   private native void nSetHoverDelayShort(float paramFloat);
/*      */ 
/*      */ 
/*      */   
/*      */   public float getHoverDelayNormal() {
/* 1668 */     return nGetHoverDelayNormal();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setHoverDelayNormal(float value) {
/* 1675 */     nSetHoverDelayNormal(value);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private native float nGetHoverDelayNormal();
/*      */ 
/*      */ 
/*      */   
/*      */   private native void nSetHoverDelayNormal(float paramFloat);
/*      */ 
/*      */ 
/*      */   
/*      */   public int getHoverFlagsForTooltipMouse() {
/* 1690 */     return nGetHoverFlagsForTooltipMouse();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setHoverFlagsForTooltipMouse(int value) {
/* 1697 */     nSetHoverFlagsForTooltipMouse(value);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private native int nGetHoverFlagsForTooltipMouse();
/*      */ 
/*      */ 
/*      */   
/*      */   private native void nSetHoverFlagsForTooltipMouse(int paramInt);
/*      */ 
/*      */ 
/*      */   
/*      */   public int getHoverFlagsForTooltipNav() {
/* 1712 */     return nGetHoverFlagsForTooltipNav();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setHoverFlagsForTooltipNav(int value) {
/* 1719 */     nSetHoverFlagsForTooltipNav(value);
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   private native int nGetHoverFlagsForTooltipNav();
/*      */ 
/*      */   
/*      */   private native void nSetHoverFlagsForTooltipNav(int paramInt);
/*      */ 
/*      */   
/*      */   public void scaleAllSizes(float scaleFactor) {
/* 1731 */     nScaleAllSizes(scaleFactor);
/*      */   }
/*      */   
/*      */   private native void nScaleAllSizes(float paramFloat);
/*      */ }


/* Location:              C:\Users\rapha\Downloads\aurora.jar!\META-INF\jars\imgui-java-binding-1.90.0.jar!\imgui\ImGuiStyle.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */