/*    */ package imgui;
/*    */ 
/*    */ import imgui.binding.ImGuiStruct;
/*    */ 
/*    */ 
/*    */ 
/*    */ public final class ImGuiTableColumnSortSpecs
/*    */   extends ImGuiStruct
/*    */ {
/*    */   public ImGuiTableColumnSortSpecs(long ptr) {
/* 11 */     super(ptr);
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public int getColumnUserID() {
/* 23 */     return nGetColumnUserID();
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   private native int nGetColumnUserID();
/*    */ 
/*    */ 
/*    */   
/*    */   public int getColumnIndex() {
/* 34 */     return nGetColumnIndex();
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   private native int nGetColumnIndex();
/*    */ 
/*    */ 
/*    */   
/*    */   public int getSortOrder() {
/* 45 */     return nGetSortOrder();
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   private native int nGetSortOrder();
/*    */ 
/*    */ 
/*    */   
/*    */   public int getSortDirection() {
/* 56 */     return nGetSortDirection();
/*    */   }
/*    */   
/*    */   private native int nGetSortDirection();
/*    */ }


/* Location:              C:\Users\rapha\Downloads\aurora.jar!\META-INF\jars\imgui-java-binding-1.90.0.jar!\imgui\ImGuiTableColumnSortSpecs.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */