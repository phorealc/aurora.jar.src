/*    */ package imgui.assertion;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public abstract class ImAssertCallback
/*    */ {
/*    */   public void imAssert(String assertion, int line, String file) {
/*    */     try {
/* 21 */       imAssertCallback(assertion, line, file);
/* 22 */     } catch (Exception ex) {
/* 23 */       System.err.println("WARNING: Exception thrown in Dear ImGui Assertion Callback!");
/* 24 */       System.err.println("Dear ImGui Assertion Failed: " + assertion);
/* 25 */       System.err.println("Assertion Located At: " + file + ":" + line);
/* 26 */       ex.printStackTrace();
/*    */     } 
/* 28 */     System.exit(1);
/*    */   }
/*    */   
/*    */   public abstract void imAssertCallback(String paramString1, int paramInt, String paramString2);
/*    */ }


/* Location:              C:\Users\rapha\Downloads\aurora.jar!\META-INF\jars\imgui-java-binding-1.90.0.jar!\imgui\assertion\ImAssertCallback.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */