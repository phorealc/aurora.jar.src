/*     */ package imgui;
/*     */ 
/*     */ import imgui.binding.ImGuiStruct;
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class ImGuiPlatformMonitor
/*     */   extends ImGuiStruct
/*     */ {
/*     */   public ImGuiPlatformMonitor(long ptr) {
/*  11 */     super(ptr);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ImVec2 getMainPos() {
/*  23 */     ImVec2 dst = new ImVec2();
/*  24 */     nGetMainPos(dst);
/*  25 */     return dst;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public float getMainPosX() {
/*  32 */     return nGetMainPosX();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public float getMainPosY() {
/*  39 */     return nGetMainPosY();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void getMainPos(ImVec2 dst) {
/*  46 */     nGetMainPos(dst);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setMainPos(ImVec2 value) {
/*  53 */     nSetMainPos(value.x, value.y);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setMainPos(float valueX, float valueY) {
/*  60 */     nSetMainPos(valueX, valueY);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private native void nGetMainPos(ImVec2 paramImVec2);
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private native float nGetMainPosX();
/*     */ 
/*     */ 
/*     */   
/*     */   private native float nGetMainPosY();
/*     */ 
/*     */ 
/*     */   
/*     */   private native void nSetMainPos(float paramFloat1, float paramFloat2);
/*     */ 
/*     */ 
/*     */   
/*     */   public ImVec2 getMainSize() {
/*  84 */     ImVec2 dst = new ImVec2();
/*  85 */     nGetMainSize(dst);
/*  86 */     return dst;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public float getMainSizeX() {
/*  93 */     return nGetMainSizeX();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public float getMainSizeY() {
/* 100 */     return nGetMainSizeY();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void getMainSize(ImVec2 dst) {
/* 107 */     nGetMainSize(dst);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setMainSize(ImVec2 value) {
/* 114 */     nSetMainSize(value.x, value.y);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setMainSize(float valueX, float valueY) {
/* 121 */     nSetMainSize(valueX, valueY);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private native void nGetMainSize(ImVec2 paramImVec2);
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private native float nGetMainSizeX();
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private native float nGetMainSizeY();
/*     */ 
/*     */ 
/*     */   
/*     */   private native void nSetMainSize(float paramFloat1, float paramFloat2);
/*     */ 
/*     */ 
/*     */   
/*     */   public ImVec2 getWorkPos() {
/* 146 */     ImVec2 dst = new ImVec2();
/* 147 */     nGetWorkPos(dst);
/* 148 */     return dst;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public float getWorkPosX() {
/* 156 */     return nGetWorkPosX();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public float getWorkPosY() {
/* 164 */     return nGetWorkPosY();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void getWorkPos(ImVec2 dst) {
/* 172 */     nGetWorkPos(dst);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setWorkPos(ImVec2 value) {
/* 180 */     nSetWorkPos(value.x, value.y);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setWorkPos(float valueX, float valueY) {
/* 188 */     nSetWorkPos(valueX, valueY);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private native void nGetWorkPos(ImVec2 paramImVec2);
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private native float nGetWorkPosX();
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private native float nGetWorkPosY();
/*     */ 
/*     */ 
/*     */   
/*     */   private native void nSetWorkPos(float paramFloat1, float paramFloat2);
/*     */ 
/*     */ 
/*     */   
/*     */   public ImVec2 getWorkSize() {
/* 213 */     ImVec2 dst = new ImVec2();
/* 214 */     nGetWorkSize(dst);
/* 215 */     return dst;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public float getWorkSizeX() {
/* 223 */     return nGetWorkSizeX();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public float getWorkSizeY() {
/* 231 */     return nGetWorkSizeY();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void getWorkSize(ImVec2 dst) {
/* 239 */     nGetWorkSize(dst);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setWorkSize(ImVec2 value) {
/* 247 */     nSetWorkSize(value.x, value.y);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setWorkSize(float valueX, float valueY) {
/* 255 */     nSetWorkSize(valueX, valueY);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private native void nGetWorkSize(ImVec2 paramImVec2);
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private native float nGetWorkSizeX();
/*     */ 
/*     */ 
/*     */   
/*     */   private native float nGetWorkSizeY();
/*     */ 
/*     */ 
/*     */   
/*     */   private native void nSetWorkSize(float paramFloat1, float paramFloat2);
/*     */ 
/*     */ 
/*     */   
/*     */   public float getDpiScale() {
/* 279 */     return nGetDpiScale();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setDpiScale(float value) {
/* 286 */     nSetDpiScale(value);
/*     */   }
/*     */   
/*     */   private native float nGetDpiScale();
/*     */   
/*     */   private native void nSetDpiScale(float paramFloat);
/*     */   
/*     */   public native void setPlatformHandle(long paramLong);
/*     */   
/*     */   public native long getPlatformHandle();
/*     */ }


/* Location:              C:\Users\rapha\Downloads\aurora.jar!\META-INF\jars\imgui-java-binding-1.90.0.jar!\imgui\ImGuiPlatformMonitor.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */