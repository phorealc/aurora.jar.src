/*    */ package imgui.internal;
/*    */ 
/*    */ import imgui.binding.ImGuiStruct;
/*    */ 
/*    */ public class ImGuiWindow extends ImGuiStruct {
/*    */   public ImGuiWindow(long ptr) {
/*  7 */     super(ptr);
/*  8 */     ImGui.init();
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public boolean getScrollbarX() {
/* 21 */     return nGetScrollbarX();
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   private native boolean nGetScrollbarX();
/*    */ 
/*    */ 
/*    */   
/*    */   public boolean getScrollbarY() {
/* 32 */     return nGetScrollbarY();
/*    */   }
/*    */   
/*    */   private native boolean nGetScrollbarY();
/*    */ }


/* Location:              C:\Users\rapha\Downloads\aurora.jar!\META-INF\jars\imgui-java-binding-1.90.0.jar!\imgui\internal\ImGuiWindow.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */