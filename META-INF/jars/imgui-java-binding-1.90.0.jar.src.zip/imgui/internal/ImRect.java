/*    */ package imgui.internal;
/*    */ 
/*    */ import imgui.ImVec2;
/*    */ import java.util.Objects;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public final class ImRect
/*    */   implements Cloneable
/*    */ {
/* 15 */   public final ImVec2 min = new ImVec2();
/*    */ 
/*    */ 
/*    */   
/* 19 */   public final ImVec2 max = new ImVec2();
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public ImRect(float minX, float minY, float maxX, float maxY) {
/* 25 */     set(minX, minY, maxX, maxY);
/*    */   }
/*    */   
/*    */   public ImRect(ImVec2 min, ImVec2 max) {
/* 29 */     set(min, max);
/*    */   }
/*    */   
/*    */   public ImRect(ImRect value) {
/* 33 */     set(value);
/*    */   }
/*    */   
/*    */   public void set(float minX, float minY, float maxX, float maxY) {
/* 37 */     this.min.x = minX;
/* 38 */     this.min.y = minY;
/* 39 */     this.max.x = maxX;
/* 40 */     this.max.y = maxY;
/*    */   }
/*    */   
/*    */   public void set(ImVec2 min, ImVec2 max) {
/* 44 */     set(min.x, min.y, max.x, max.y);
/*    */   }
/*    */   
/*    */   public void set(ImRect value) {
/* 48 */     set(value.min, value.max);
/*    */   }
/*    */ 
/*    */   
/*    */   public String toString() {
/* 53 */     return "ImRect{min=" + this.min + ", max=" + this.max + '}';
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public boolean equals(Object o) {
/* 61 */     if (this == o) {
/* 62 */       return true;
/*    */     }
/*    */     
/* 65 */     if (o == null || getClass() != o.getClass()) {
/* 66 */       return false;
/*    */     }
/*    */     
/* 69 */     ImRect imRect = (ImRect)o;
/* 70 */     return (Objects.equals(this.min, imRect.min) && Objects.equals(this.max, imRect.max));
/*    */   }
/*    */ 
/*    */   
/*    */   public int hashCode() {
/* 75 */     return Objects.hash(new Object[] { this.min, this.max });
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public ImRect clone() {
/* 81 */     return new ImRect(this);
/*    */   }
/*    */   
/*    */   public ImRect() {}
/*    */ }


/* Location:              C:\Users\rapha\Downloads\aurora.jar!\META-INF\jars\imgui-java-binding-1.90.0.jar!\imgui\internal\ImRect.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */