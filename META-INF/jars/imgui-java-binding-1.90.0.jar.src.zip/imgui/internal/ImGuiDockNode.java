/*      */ package imgui.internal;
/*      */ 
/*      */ import imgui.ImGuiWindowClass;
/*      */ import imgui.ImVec2;
/*      */ import imgui.binding.ImGuiStruct;
/*      */ 
/*      */ public final class ImGuiDockNode extends ImGuiStruct {
/*      */   public ImGuiDockNode(long ptr) {
/*    9 */     super(ptr);
/*   10 */     ImGui.init();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public int getID() {
/*   20 */     return nGetID();
/*      */   }
/*      */   
/*      */   public void setID(int value) {
/*   24 */     nSetID(value);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private native int nGetID();
/*      */ 
/*      */ 
/*      */   
/*      */   private native void nSetID(int paramInt);
/*      */ 
/*      */ 
/*      */   
/*      */   public int getSharedFlags() {
/*   39 */     return nGetSharedFlags();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setSharedFlags(int value) {
/*   46 */     nSetSharedFlags(value);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void addSharedFlags(int flags) {
/*   53 */     setSharedFlags(getSharedFlags() | flags);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void removeSharedFlags(int flags) {
/*   60 */     setSharedFlags(getSharedFlags() & (flags ^ 0xFFFFFFFF));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean hasSharedFlags(int flags) {
/*   67 */     return ((getSharedFlags() & flags) != 0);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private native int nGetSharedFlags();
/*      */ 
/*      */ 
/*      */   
/*      */   private native void nSetSharedFlags(int paramInt);
/*      */ 
/*      */ 
/*      */   
/*      */   public int getLocalFlags() {
/*   82 */     return nGetLocalFlags();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setLocalFlags(int value) {
/*   89 */     nSetLocalFlags(value);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void addLocalFlags(int flags) {
/*   96 */     setLocalFlags(getLocalFlags() | flags);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void removeLocalFlags(int flags) {
/*  103 */     setLocalFlags(getLocalFlags() & (flags ^ 0xFFFFFFFF));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean hasLocalFlags(int flags) {
/*  110 */     return ((getLocalFlags() & flags) != 0);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private native int nGetLocalFlags();
/*      */ 
/*      */ 
/*      */   
/*      */   private native void nSetLocalFlags(int paramInt);
/*      */ 
/*      */ 
/*      */   
/*      */   public int getLocalFlagsInWindows() {
/*  125 */     return nGetLocalFlagsInWindows();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setLocalFlagsInWindows(int value) {
/*  132 */     nSetLocalFlagsInWindows(value);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void addLocalFlagsInWindows(int flags) {
/*  139 */     setLocalFlagsInWindows(getLocalFlagsInWindows() | flags);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void removeLocalFlagsInWindows(int flags) {
/*  146 */     setLocalFlagsInWindows(getLocalFlagsInWindows() & (flags ^ 0xFFFFFFFF));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean hasLocalFlagsInWindows(int flags) {
/*  153 */     return ((getLocalFlagsInWindows() & flags) != 0);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private native int nGetLocalFlagsInWindows();
/*      */ 
/*      */ 
/*      */   
/*      */   private native void nSetLocalFlagsInWindows(int paramInt);
/*      */ 
/*      */ 
/*      */   
/*      */   public int getMergedFlags() {
/*  168 */     return nGetMergedFlags();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean hasMergedFlags(int flags) {
/*  175 */     return ((getMergedFlags() & flags) != 0);
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   private native int nGetMergedFlags();
/*      */ 
/*      */ 
/*      */   
/*      */   public ImGuiDockNode getParentNode() {
/*  185 */     return new ImGuiDockNode(nGetParentNode());
/*      */   }
/*      */   
/*      */   public void setParentNode(ImGuiDockNode value) {
/*  189 */     nSetParentNode(value.ptr);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private native long nGetParentNode();
/*      */ 
/*      */ 
/*      */   
/*      */   private native void nSetParentNode(long paramLong);
/*      */ 
/*      */ 
/*      */   
/*      */   public ImGuiDockNode getChildNodeFirst() {
/*  204 */     return new ImGuiDockNode(nGetChildNodeFirst());
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private native long nGetChildNodeFirst();
/*      */ 
/*      */ 
/*      */   
/*      */   public void setChildNodeFirst(ImGuiDockNode imGuiDockNode) {
/*  215 */     nSetChildNodeFirst(imGuiDockNode.ptr);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private native void nSetChildNodeFirst(long paramLong);
/*      */ 
/*      */ 
/*      */   
/*      */   public ImGuiDockNode getChildNodeSecond() {
/*  226 */     return new ImGuiDockNode(nGetChildNodeSecond());
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private native long nGetChildNodeSecond();
/*      */ 
/*      */ 
/*      */   
/*      */   public void setChildNodeSecond(ImGuiDockNode imGuiDockNode) {
/*  237 */     nSetChildNodeSecond(imGuiDockNode.ptr);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private native void nSetChildNodeSecond(long paramLong);
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public ImVec2 getPos() {
/*  250 */     ImVec2 dst = new ImVec2();
/*  251 */     nGetPos(dst);
/*  252 */     return dst;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public float getPosX() {
/*  259 */     return nGetPosX();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public float getPosY() {
/*  266 */     return nGetPosY();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void getPos(ImVec2 dst) {
/*  273 */     nGetPos(dst);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setPos(ImVec2 value) {
/*  280 */     nSetPos(value.x, value.y);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setPos(float valueX, float valueY) {
/*  287 */     nSetPos(valueX, valueY);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private native void nGetPos(ImVec2 paramImVec2);
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private native float nGetPosX();
/*      */ 
/*      */ 
/*      */   
/*      */   private native float nGetPosY();
/*      */ 
/*      */ 
/*      */   
/*      */   private native void nSetPos(float paramFloat1, float paramFloat2);
/*      */ 
/*      */ 
/*      */   
/*      */   public ImVec2 getSize() {
/*  311 */     ImVec2 dst = new ImVec2();
/*  312 */     nGetSize(dst);
/*  313 */     return dst;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public float getSizeX() {
/*  320 */     return nGetSizeX();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public float getSizeY() {
/*  327 */     return nGetSizeY();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void getSize(ImVec2 dst) {
/*  334 */     nGetSize(dst);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setSize(ImVec2 value) {
/*  341 */     nSetSize(value.x, value.y);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setSize(float valueX, float valueY) {
/*  348 */     nSetSize(valueX, valueY);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private native void nGetSize(ImVec2 paramImVec2);
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private native float nGetSizeX();
/*      */ 
/*      */ 
/*      */   
/*      */   private native float nGetSizeY();
/*      */ 
/*      */ 
/*      */   
/*      */   private native void nSetSize(float paramFloat1, float paramFloat2);
/*      */ 
/*      */ 
/*      */   
/*      */   public ImVec2 getSizeRef() {
/*  372 */     ImVec2 dst = new ImVec2();
/*  373 */     nGetSizeRef(dst);
/*  374 */     return dst;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public float getSizeRefX() {
/*  381 */     return nGetSizeRefX();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public float getSizeRefY() {
/*  388 */     return nGetSizeRefY();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void getSizeRef(ImVec2 dst) {
/*  395 */     nGetSizeRef(dst);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setSizeRef(ImVec2 value) {
/*  402 */     nSetSizeRef(value.x, value.y);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setSizeRef(float valueX, float valueY) {
/*  409 */     nSetSizeRef(valueX, valueY);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private native void nGetSizeRef(ImVec2 paramImVec2);
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private native float nGetSizeRefX();
/*      */ 
/*      */ 
/*      */   
/*      */   private native float nGetSizeRefY();
/*      */ 
/*      */ 
/*      */   
/*      */   private native void nSetSizeRef(float paramFloat1, float paramFloat2);
/*      */ 
/*      */ 
/*      */   
/*      */   public int getSplitAxis() {
/*  433 */     return nGetSplitAxis();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private native int nGetSplitAxis();
/*      */ 
/*      */ 
/*      */   
/*      */   public ImGuiWindowClass getWindowClass() {
/*  444 */     return new ImGuiWindowClass(nGetWindowClass());
/*      */   }
/*      */ 
/*      */   
/*      */   private native long nGetWindowClass();
/*      */ 
/*      */   
/*      */   public int getLastBgColor() {
/*  452 */     return nGetLastBgColor();
/*      */   }
/*      */   
/*      */   public void setLastBgColor(int value) {
/*  456 */     nSetLastBgColor(value);
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   private native int nGetLastBgColor();
/*      */ 
/*      */   
/*      */   private native void nSetLastBgColor(int paramInt);
/*      */ 
/*      */   
/*      */   public ImGuiWindow getHostWindow() {
/*  468 */     return new ImGuiWindow(nGetHostWindow());
/*      */   }
/*      */   
/*      */   public void setHostWindow(ImGuiWindow value) {
/*  472 */     nSetHostWindow(value.ptr);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private native long nGetHostWindow();
/*      */ 
/*      */ 
/*      */   
/*      */   private native void nSetHostWindow(long paramLong);
/*      */ 
/*      */ 
/*      */   
/*      */   public ImGuiWindow getVisibleWindow() {
/*  487 */     return new ImGuiWindow(nGetVisibleWindow());
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setVisibleWindow(ImGuiWindow value) {
/*  494 */     nSetVisibleWindow(value.ptr);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private native long nGetVisibleWindow();
/*      */ 
/*      */ 
/*      */   
/*      */   private native void nSetVisibleWindow(long paramLong);
/*      */ 
/*      */ 
/*      */   
/*      */   public ImGuiDockNode getCentralNode() {
/*  509 */     return new ImGuiDockNode(nGetCentralNode());
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setCentralNode(ImGuiDockNode value) {
/*  516 */     nSetCentralNode(value.ptr);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private native long nGetCentralNode();
/*      */ 
/*      */ 
/*      */   
/*      */   private native void nSetCentralNode(long paramLong);
/*      */ 
/*      */ 
/*      */   
/*      */   public ImGuiDockNode getOnlyNodeWithWindows() {
/*  531 */     return new ImGuiDockNode(nGetOnlyNodeWithWindows());
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setOnlyNodeWithWindows(ImGuiDockNode value) {
/*  538 */     nSetOnlyNodeWithWindows(value.ptr);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private native long nGetOnlyNodeWithWindows();
/*      */ 
/*      */ 
/*      */   
/*      */   private native void nSetOnlyNodeWithWindows(long paramLong);
/*      */ 
/*      */ 
/*      */   
/*      */   public int getLastFrameAlive() {
/*  553 */     return nGetLastFrameAlive();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setLastFrameAlive(int value) {
/*  560 */     nSetLastFrameAlive(value);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private native int nGetLastFrameAlive();
/*      */ 
/*      */ 
/*      */   
/*      */   private native void nSetLastFrameAlive(int paramInt);
/*      */ 
/*      */ 
/*      */   
/*      */   public int getLastFrameActive() {
/*  575 */     return nGetLastFrameActive();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setLastFrameActive(int value) {
/*  582 */     nSetLastFrameActive(value);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private native int nGetLastFrameActive();
/*      */ 
/*      */ 
/*      */   
/*      */   private native void nSetLastFrameActive(int paramInt);
/*      */ 
/*      */ 
/*      */   
/*      */   public int getLastFrameFocused() {
/*  597 */     return nGetLastFrameFocused();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setLastFrameFocused(int value) {
/*  604 */     nSetLastFrameFocused(value);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private native int nGetLastFrameFocused();
/*      */ 
/*      */ 
/*      */   
/*      */   private native void nSetLastFrameFocused(int paramInt);
/*      */ 
/*      */ 
/*      */   
/*      */   public int getLastFocusedNodeId() {
/*  619 */     return nGetLastFocusedNodeId();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setLastFocusedNodeId(int value) {
/*  626 */     nSetLastFocusedNodeId(value);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private native int nGetLastFocusedNodeId();
/*      */ 
/*      */ 
/*      */   
/*      */   private native void nSetLastFocusedNodeId(int paramInt);
/*      */ 
/*      */ 
/*      */   
/*      */   public int getSelectedTabId() {
/*  641 */     return nGetSelectedTabId();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setSelectedTabId(int value) {
/*  648 */     nSetSelectedTabId(value);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private native int nGetSelectedTabId();
/*      */ 
/*      */ 
/*      */   
/*      */   private native void nSetSelectedTabId(int paramInt);
/*      */ 
/*      */ 
/*      */   
/*      */   public int getWantCloseTabId() {
/*  663 */     return nGetWantCloseTabId();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setWantCloseTabId(int value) {
/*  670 */     nSetWantCloseTabId(value);
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   private native int nGetWantCloseTabId();
/*      */ 
/*      */   
/*      */   private native void nSetWantCloseTabId(int paramInt);
/*      */ 
/*      */   
/*      */   public int getAuthorityForPos() {
/*  682 */     return nGetAuthorityForPos();
/*      */   }
/*      */   
/*      */   public void setAuthorityForPos(int value) {
/*  686 */     nSetAuthorityForPos(value);
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   private native int nGetAuthorityForPos();
/*      */ 
/*      */   
/*      */   private native void nSetAuthorityForPos(int paramInt);
/*      */ 
/*      */   
/*      */   public int getAuthorityForSize() {
/*  698 */     return nGetAuthorityForSize();
/*      */   }
/*      */   
/*      */   public void setAuthorityForSize(int value) {
/*  702 */     nSetAuthorityForSize(value);
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   private native int nGetAuthorityForSize();
/*      */ 
/*      */   
/*      */   private native void nSetAuthorityForSize(int paramInt);
/*      */ 
/*      */   
/*      */   public int getAuthorityForViewport() {
/*  714 */     return nGetAuthorityForViewport();
/*      */   }
/*      */   
/*      */   public void setAuthorityForViewport(int value) {
/*  718 */     nSetAuthorityForViewport(value);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private native int nGetAuthorityForViewport();
/*      */ 
/*      */ 
/*      */   
/*      */   private native void nSetAuthorityForViewport(int paramInt);
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean getIsVisible() {
/*  733 */     return nGetIsVisible();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setIsVisible(boolean value) {
/*  740 */     nSetIsVisible(value);
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   private native boolean nGetIsVisible();
/*      */ 
/*      */   
/*      */   private native void nSetIsVisible(boolean paramBoolean);
/*      */ 
/*      */   
/*      */   public boolean getIsFocused() {
/*  752 */     return nGetIsFocused();
/*      */   }
/*      */   
/*      */   public void setIsFocused(boolean value) {
/*  756 */     nSetIsFocused(value);
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   private native boolean nGetIsFocused();
/*      */ 
/*      */   
/*      */   private native void nSetIsFocused(boolean paramBoolean);
/*      */ 
/*      */   
/*      */   public boolean getHasCloseButton() {
/*  768 */     return nGetHasCloseButton();
/*      */   }
/*      */   
/*      */   public void setHasCloseButton(boolean value) {
/*  772 */     nSetHasCloseButton(value);
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   private native boolean nGetHasCloseButton();
/*      */ 
/*      */   
/*      */   private native void nSetHasCloseButton(boolean paramBoolean);
/*      */ 
/*      */   
/*      */   public boolean getHasWindowMenuButton() {
/*  784 */     return nGetHasWindowMenuButton();
/*      */   }
/*      */   
/*      */   public void setHasWindowMenuButton(boolean value) {
/*  788 */     nSetHasWindowMenuButton(value);
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   private native boolean nGetHasWindowMenuButton();
/*      */ 
/*      */   
/*      */   private native void nSetHasWindowMenuButton(boolean paramBoolean);
/*      */ 
/*      */   
/*      */   public boolean getHasCentralNodeChild() {
/*  800 */     return nGetHasCentralNodeChild();
/*      */   }
/*      */   
/*      */   public void setHasCentralNodeChild(boolean value) {
/*  804 */     nSetHasCentralNodeChild(value);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private native boolean nGetHasCentralNodeChild();
/*      */ 
/*      */ 
/*      */   
/*      */   private native void nSetHasCentralNodeChild(boolean paramBoolean);
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean getWantCloseAll() {
/*  819 */     return nGetWantCloseAll();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setWantCloseAll(boolean value) {
/*  826 */     nSetWantCloseAll(value);
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   private native boolean nGetWantCloseAll();
/*      */ 
/*      */   
/*      */   private native void nSetWantCloseAll(boolean paramBoolean);
/*      */ 
/*      */   
/*      */   public boolean getWantLockSizeOnce() {
/*  838 */     return nGetWantLockSizeOnce();
/*      */   }
/*      */   
/*      */   public void setWantLockSizeOnce(boolean value) {
/*  842 */     nSetWantLockSizeOnce(value);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private native boolean nGetWantLockSizeOnce();
/*      */ 
/*      */ 
/*      */   
/*      */   private native void nSetWantLockSizeOnce(boolean paramBoolean);
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean getWantMouseMove() {
/*  857 */     return nGetWantMouseMove();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setWantMouseMove(boolean value) {
/*  864 */     nSetWantMouseMove(value);
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   private native boolean nGetWantMouseMove();
/*      */ 
/*      */   
/*      */   private native void nSetWantMouseMove(boolean paramBoolean);
/*      */ 
/*      */   
/*      */   public boolean getWantHiddenTabBarUpdate() {
/*  876 */     return nGetWantHiddenTabBarUpdate();
/*      */   }
/*      */   
/*      */   public void setWantHiddenTabBarUpdate(boolean value) {
/*  880 */     nSetWantHiddenTabBarUpdate(value);
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   private native boolean nGetWantHiddenTabBarUpdate();
/*      */ 
/*      */   
/*      */   private native void nSetWantHiddenTabBarUpdate(boolean paramBoolean);
/*      */ 
/*      */   
/*      */   public boolean getWantHiddenTabBarToggle() {
/*  892 */     return nGetWantHiddenTabBarToggle();
/*      */   }
/*      */   
/*      */   public void setWantHiddenTabBarToggle(boolean value) {
/*  896 */     nSetWantHiddenTabBarToggle(value);
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   private native boolean nGetWantHiddenTabBarToggle();
/*      */ 
/*      */   
/*      */   private native void nSetWantHiddenTabBarToggle(boolean paramBoolean);
/*      */ 
/*      */   
/*      */   public boolean isRootNode() {
/*  908 */     return nIsRootNode();
/*      */   }
/*      */ 
/*      */   
/*      */   private native boolean nIsRootNode();
/*      */ 
/*      */   
/*      */   public boolean isDockSpace() {
/*  916 */     return nIsDockSpace();
/*      */   }
/*      */ 
/*      */   
/*      */   private native boolean nIsDockSpace();
/*      */ 
/*      */   
/*      */   public boolean isFloatingNode() {
/*  924 */     return nIsFloatingNode();
/*      */   }
/*      */ 
/*      */   
/*      */   private native boolean nIsFloatingNode();
/*      */ 
/*      */   
/*      */   public boolean isCentralNode() {
/*  932 */     return nIsCentralNode();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private native boolean nIsCentralNode();
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean isHiddenTabBar() {
/*  943 */     return nIsHiddenTabBar();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private native boolean nIsHiddenTabBar();
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean isNoTabBar() {
/*  954 */     return nIsNoTabBar();
/*      */   }
/*      */ 
/*      */   
/*      */   private native boolean nIsNoTabBar();
/*      */ 
/*      */   
/*      */   public boolean isSplitNode() {
/*  962 */     return nIsSplitNode();
/*      */   }
/*      */ 
/*      */   
/*      */   private native boolean nIsSplitNode();
/*      */ 
/*      */   
/*      */   public boolean isLeafNode() {
/*  970 */     return nIsLeafNode();
/*      */   }
/*      */ 
/*      */   
/*      */   private native boolean nIsLeafNode();
/*      */ 
/*      */   
/*      */   public boolean isEmpty() {
/*  978 */     return nIsEmpty();
/*      */   }
/*      */ 
/*      */   
/*      */   private native boolean nIsEmpty();
/*      */ 
/*      */   
/*      */   public ImRect rect() {
/*  986 */     ImRect dst = new ImRect();
/*  987 */     nRect(dst);
/*  988 */     return dst;
/*      */   }
/*      */   
/*      */   public void rect(ImRect dst) {
/*  992 */     nRect(dst);
/*      */   }
/*      */ 
/*      */   
/*      */   private native void nRect(ImRect paramImRect);
/*      */ 
/*      */   
/*      */   public void updateMergedFlags() {
/* 1000 */     nUpdateMergedFlags();
/*      */   }
/*      */   
/*      */   private native void nUpdateMergedFlags();
/*      */ }


/* Location:              C:\Users\rapha\Downloads\aurora.jar!\META-INF\jars\imgui-java-binding-1.90.0.jar!\imgui\internal\ImGuiDockNode.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */