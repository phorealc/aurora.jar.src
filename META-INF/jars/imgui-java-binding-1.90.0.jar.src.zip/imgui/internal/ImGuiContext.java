/*   */ package imgui.internal;
/*   */ 
/*   */ import imgui.binding.ImGuiStruct;
/*   */ 
/*   */ public class ImGuiContext extends ImGuiStruct {
/*   */   public ImGuiContext(long ptr) {
/* 7 */     super(ptr);
/* 8 */     ImGui.init();
/*   */   }
/*   */ }


/* Location:              C:\Users\rapha\Downloads\aurora.jar!\META-INF\jars\imgui-java-binding-1.90.0.jar!\imgui\internal\ImGuiContext.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */