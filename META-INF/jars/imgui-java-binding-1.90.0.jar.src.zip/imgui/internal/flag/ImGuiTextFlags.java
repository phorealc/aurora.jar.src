package imgui.internal.flag;

public class ImGuiTextFlags {
  public static final int None = 0;
  
  public static final int NoWidthForLargeClippedText = 1;
}


/* Location:              C:\Users\rapha\Downloads\aurora.jar!\META-INF\jars\imgui-java-binding-1.90.0.jar!\imgui\internal\flag\ImGuiTextFlags.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */