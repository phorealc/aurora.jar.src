package imgui.internal.flag;

public final class ImGuiAxis {
  public static final int None = -1;
  
  public static final int X = 0;
  
  public static final int Y = 1;
}


/* Location:              C:\Users\rapha\Downloads\aurora.jar!\META-INF\jars\imgui-java-binding-1.90.0.jar!\imgui\internal\flag\ImGuiAxis.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */