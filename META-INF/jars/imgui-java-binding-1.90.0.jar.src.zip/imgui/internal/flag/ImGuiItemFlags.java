package imgui.internal.flag;

public final class ImGuiItemFlags {
  public static final int None = 0;
  
  public static final int NoTabStop = 1;
  
  public static final int ButtonRepeat = 2;
  
  public static final int Disabled = 4;
  
  public static final int NoNav = 8;
  
  public static final int NoNavDefaultFocus = 16;
  
  public static final int SelectableDontClosePopup = 32;
  
  public static final int MixedValue = 64;
  
  public static final int ReadOnly = 128;
  
  public static final int NoWindowHoverableCheck = 256;
  
  public static final int AllowOverlap = 512;
  
  public static final int Inputable = 1024;
  
  public static final int HasSelectionUserData = 2048;
}


/* Location:              C:\Users\rapha\Downloads\aurora.jar!\META-INF\jars\imgui-java-binding-1.90.0.jar!\imgui\internal\flag\ImGuiItemFlags.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */