package imgui.internal.flag;

public class ImGuiSeparatorFlags {
  public static final int None = 0;
  
  public static final int Horizontal = 1;
  
  public static final int Vertical = 2;
  
  public static final int SpanAllColumns = 4;
}


/* Location:              C:\Users\rapha\Downloads\aurora.jar!\META-INF\jars\imgui-java-binding-1.90.0.jar!\imgui\internal\flag\ImGuiSeparatorFlags.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */