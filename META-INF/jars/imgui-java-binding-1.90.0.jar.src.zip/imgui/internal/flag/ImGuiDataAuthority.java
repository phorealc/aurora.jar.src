package imgui.internal.flag;

public final class ImGuiDataAuthority {
  public static final int Auto = 0;
  
  public static final int DockNode = 1;
  
  public static final int Window = 2;
}


/* Location:              C:\Users\rapha\Downloads\aurora.jar!\META-INF\jars\imgui-java-binding-1.90.0.jar!\imgui\internal\flag\ImGuiDataAuthority.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */