package imgui.internal.flag;

public final class ImGuiFocusRequestFlags {
  public static final int None = 0;
  
  public static final int RestoreFocusedChild = 1;
  
  public static final int UnlessBelowModal = 2;
}


/* Location:              C:\Users\rapha\Downloads\aurora.jar!\META-INF\jars\imgui-java-binding-1.90.0.jar!\imgui\internal\flag\ImGuiFocusRequestFlags.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */