package imgui.internal.flag;

public class ImGuiItemStatusFlags {
  public static final int None = 0;
  
  public static final int HoveredRect = 1;
  
  public static final int HasDisplayRect = 2;
  
  public static final int Edited = 4;
  
  public static final int ToggledSelection = 8;
  
  public static final int ToggledOpen = 16;
  
  public static final int HasDeactivated = 32;
  
  public static final int Deactivated = 64;
  
  public static final int HoveredWindow = 128;
  
  public static final int Visible = 256;
  
  public static final int HasClipRect = 512;
  
  public static final int HasShortcut = 1024;
}


/* Location:              C:\Users\rapha\Downloads\aurora.jar!\META-INF\jars\imgui-java-binding-1.90.0.jar!\imgui\internal\flag\ImGuiItemStatusFlags.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */