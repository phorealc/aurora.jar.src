package imgui.internal.flag;

public final class ImGuiDockNodeState {
  public static final int Unknown = 0;
  
  public static final int HostWindowHiddenBecauseSingleWindow = 1;
  
  public static final int HostWindowHiddenBecauseWindowsAreResizing = 2;
  
  public static final int HostWindowVisible = 3;
}


/* Location:              C:\Users\rapha\Downloads\aurora.jar!\META-INF\jars\imgui-java-binding-1.90.0.jar!\imgui\internal\flag\ImGuiDockNodeState.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */