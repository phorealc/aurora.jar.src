/*      */ package imgui.internal;
/*      */ 
/*      */ import imgui.ImDrawList;
/*      */ import imgui.ImFont;
/*      */ import imgui.ImGui;
/*      */ import imgui.ImGuiPlatformMonitor;
/*      */ import imgui.ImGuiViewport;
/*      */ import imgui.ImVec2;
/*      */ import imgui.ImVec4;
/*      */ import imgui.type.ImBoolean;
/*      */ import imgui.type.ImFloat;
/*      */ import imgui.type.ImInt;
/*      */ 
/*      */ 
/*      */ 
/*      */ public final class ImGui
/*      */   extends ImGui
/*      */ {
/*      */   static {
/*   20 */     nInit();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static void init() {}
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static ImGuiWindow getCurrentWindowRead() {
/*   37 */     return new ImGuiWindow(nGetCurrentWindowRead());
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static ImGuiWindow getCurrentWindow() {
/*   45 */     return new ImGuiWindow(nGetCurrentWindow());
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static ImGuiWindow findWindowByID(int id) {
/*   53 */     return new ImGuiWindow(nFindWindowByID(id));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static ImGuiWindow findWindowByName(String name) {
/*   61 */     return new ImGuiWindow(nFindWindowByName(name));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static void updateWindowParentAndRootLinks(ImGuiWindow window, int flags, ImGuiWindow parentWindow) {
/*   72 */     nUpdateWindowParentAndRootLinks(window.ptr, flags, parentWindow.ptr);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static ImVec2 calcWindowNextAutoFitSize(ImGuiWindow window) {
/*   80 */     ImVec2 dst = new ImVec2();
/*   81 */     nCalcWindowNextAutoFitSize(dst, window.ptr);
/*   82 */     return dst;
/*      */   }
/*      */   
/*      */   public static float calcWindowNextAutoFitSizeX(ImGuiWindow window) {
/*   86 */     return nCalcWindowNextAutoFitSizeX(window.ptr);
/*      */   }
/*      */   
/*      */   public static float calcWindowNextAutoFitSizeY(ImGuiWindow window) {
/*   90 */     return nCalcWindowNextAutoFitSizeY(window.ptr);
/*      */   }
/*      */   
/*      */   public static void calcWindowNextAutoFitSize(ImVec2 dst, ImGuiWindow window) {
/*   94 */     nCalcWindowNextAutoFitSize(dst, window.ptr);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static boolean isWindowChildOf(ImGuiWindow window, ImGuiWindow potentialParent, boolean popupHierarchy, boolean dockHierarchy) {
/*  110 */     return nIsWindowChildOf(window.ptr, potentialParent.ptr, popupHierarchy, dockHierarchy);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static boolean isWindowWithinBeginStackOf(ImGuiWindow window, ImGuiWindow potentialParent) {
/*  118 */     return nIsWindowWithinBeginStackOf(window.ptr, potentialParent.ptr);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static boolean isWindowAbove(ImGuiWindow potentialAbove, ImGuiWindow potentialBelow) {
/*  126 */     return nIsWindowAbove(potentialAbove.ptr, potentialBelow.ptr);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static boolean isWindowNavFocusable(ImGuiWindow window) {
/*  134 */     return nIsWindowNavFocusable(window.ptr);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static void setWindowPos(ImGuiWindow window, ImVec2 pos) {
/*  142 */     nSetWindowPos(window.ptr, pos.x, pos.y);
/*      */   }
/*      */   
/*      */   public static void setWindowPos(ImGuiWindow window, float posX, float posY) {
/*  146 */     nSetWindowPos(window.ptr, posX, posY);
/*      */   }
/*      */   
/*      */   public static void setWindowPos(ImGuiWindow window, ImVec2 pos, int cond) {
/*  150 */     nSetWindowPos(window.ptr, pos.x, pos.y, cond);
/*      */   }
/*      */   
/*      */   public static void setWindowPos(ImGuiWindow window, float posX, float posY, int cond) {
/*  154 */     nSetWindowPos(window.ptr, posX, posY, cond);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static void setWindowSize(ImGuiWindow window, ImVec2 size) {
/*  168 */     nSetWindowSize(window.ptr, size.x, size.y);
/*      */   }
/*      */   
/*      */   public static void setWindowSize(ImGuiWindow window, float sizeX, float sizeY) {
/*  172 */     nSetWindowSize(window.ptr, sizeX, sizeY);
/*      */   }
/*      */   
/*      */   public static void setWindowSize(ImGuiWindow window, ImVec2 size, int cond) {
/*  176 */     nSetWindowSize(window.ptr, size.x, size.y, cond);
/*      */   }
/*      */   
/*      */   public static void setWindowSize(ImGuiWindow window, float sizeX, float sizeY, int cond) {
/*  180 */     nSetWindowSize(window.ptr, sizeX, sizeY, cond);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static void setWindowCollapsed(ImGuiWindow window, boolean collapsed) {
/*  194 */     nSetWindowCollapsed(window.ptr, collapsed);
/*      */   }
/*      */   
/*      */   public static void setWindowCollapsed(ImGuiWindow window, boolean collapsed, int cond) {
/*  198 */     nSetWindowCollapsed(window.ptr, collapsed, cond);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static void setWindowHitTestHole(ImGuiWindow window, ImVec2 pos, ImVec2 size) {
/*  210 */     nSetWindowHitTestHole(window.ptr, pos.x, pos.y, size.x, size.y);
/*      */   }
/*      */   
/*      */   public static void setWindowHitTestHole(ImGuiWindow window, float posX, float posY, float sizeX, float sizeY) {
/*  214 */     nSetWindowHitTestHole(window.ptr, posX, posY, sizeX, sizeY);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static ImRect windowRectAbsToRel(ImGuiWindow window, ImRect r) {
/*  224 */     ImRect dst = new ImRect();
/*  225 */     nWindowRectAbsToRel(dst, window.ptr, r.min.x, r.min.y, r.max.x, r.max.y);
/*  226 */     return dst;
/*      */   }
/*      */   
/*      */   public static ImRect windowRectAbsToRel(ImGuiWindow window, float rMinX, float rMinY, float rMaxX, float rMaxY) {
/*  230 */     ImRect dst = new ImRect();
/*  231 */     nWindowRectAbsToRel(dst, window.ptr, rMinX, rMinY, rMaxX, rMaxY);
/*  232 */     return dst;
/*      */   }
/*      */   
/*      */   public static void windowRectAbsToRel(ImRect dst, ImGuiWindow window, ImRect r) {
/*  236 */     nWindowRectAbsToRel(dst, window.ptr, r.min.x, r.min.y, r.max.x, r.max.y);
/*      */   }
/*      */   
/*      */   public static void windowRectAbsToRel(ImRect dst, ImGuiWindow window, float rMinX, float rMinY, float rMaxX, float rMaxY) {
/*  240 */     nWindowRectAbsToRel(dst, window.ptr, rMinX, rMinY, rMaxX, rMaxY);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static ImRect windowRectRelToAbs(ImGuiWindow window, ImRect r) {
/*  248 */     ImRect dst = new ImRect();
/*  249 */     nWindowRectRelToAbs(dst, window.ptr, r.min.x, r.min.y, r.max.x, r.max.y);
/*  250 */     return dst;
/*      */   }
/*      */   
/*      */   public static ImRect windowRectRelToAbs(ImGuiWindow window, float rMinX, float rMinY, float rMaxX, float rMaxY) {
/*  254 */     ImRect dst = new ImRect();
/*  255 */     nWindowRectRelToAbs(dst, window.ptr, rMinX, rMinY, rMaxX, rMaxY);
/*  256 */     return dst;
/*      */   }
/*      */   
/*      */   public static void windowRectRelToAbs(ImRect dst, ImGuiWindow window, ImRect r) {
/*  260 */     nWindowRectRelToAbs(dst, window.ptr, r.min.x, r.min.y, r.max.x, r.max.y);
/*      */   }
/*      */   
/*      */   public static void windowRectRelToAbs(ImRect dst, ImGuiWindow window, float rMinX, float rMinY, float rMaxX, float rMaxY) {
/*  264 */     nWindowRectRelToAbs(dst, window.ptr, rMinX, rMinY, rMaxX, rMaxY);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static void focusWindow(ImGuiWindow window) {
/*  275 */     nFocusWindow(window.ptr);
/*      */   }
/*      */   
/*      */   public static void focusWindow(ImGuiWindow window, int flags) {
/*  279 */     nFocusWindow(window.ptr, flags);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static void focusTopMostWindowUnderOne(ImGuiWindow underThisWindow, ImGuiWindow ignoreWindow, ImGuiViewport filterViewport, int flags) {
/*  291 */     nFocusTopMostWindowUnderOne(underThisWindow.ptr, ignoreWindow.ptr, filterViewport.ptr, flags);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static void bringWindowToFocusFront(ImGuiWindow window) {
/*  299 */     nBringWindowToFocusFront(window.ptr);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static void bringWindowToDisplayFront(ImGuiWindow window) {
/*  307 */     nBringWindowToDisplayFront(window.ptr);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static void bringWindowToDisplayBack(ImGuiWindow window) {
/*  315 */     nBringWindowToDisplayBack(window.ptr);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static void bringWindowToDisplayBehind(ImGuiWindow window, ImGuiWindow aboveWindow) {
/*  323 */     nBringWindowToDisplayBehind(window.ptr, aboveWindow.ptr);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static int findWindowDisplayIndex(ImGuiWindow window) {
/*  331 */     return nFindWindowDisplayIndex(window.ptr);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static ImGuiWindow findBottomMostVisibleWindowWithinBeginStack(ImGuiWindow window) {
/*  339 */     return new ImGuiWindow(nFindBottomMostVisibleWindowWithinBeginStack(window.ptr));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static void setCurrentFont(ImFont font) {
/*  349 */     nSetCurrentFont(font.ptr);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static ImFont getDefaultFont() {
/*  357 */     return new ImFont(nGetDefaultFont());
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static ImDrawList getForegroundDrawList(ImGuiWindow window) {
/*  365 */     return new ImDrawList(nGetForegroundDrawList(window.ptr));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static void initialize() {
/*  375 */     nInitialize();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static void shutdown() {
/*  383 */     nShutdown();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static void updateInputEvents(boolean trickleFastInputs) {
/*  393 */     nUpdateInputEvents(trickleFastInputs);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static void updateHoveredWindowAndCaptureFlags() {
/*  401 */     nUpdateHoveredWindowAndCaptureFlags();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static void startMouseMovingWindow(ImGuiWindow window) {
/*  409 */     nStartMouseMovingWindow(window.ptr);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static void startMouseMovingWindowOrNode(ImGuiWindow window, ImGuiDockNode node, boolean undockFloatingNode) {
/*  417 */     nStartMouseMovingWindowOrNode(window.ptr, node.ptr, undockFloatingNode);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static void updateMouseMovingWindowNewFrame() {
/*  425 */     nUpdateMouseMovingWindowNewFrame();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static void updateMouseMovingWindowEndFrame() {
/*  433 */     nUpdateMouseMovingWindowEndFrame();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static ImGuiPlatformMonitor getViewportPlatformMonitor(ImGuiViewport viewport) {
/*  445 */     return new ImGuiPlatformMonitor(nGetViewportPlatformMonitor(viewport.ptr));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static void setNextWindowScroll(ImVec2 scroll) {
/*  457 */     nSetNextWindowScroll(scroll.x, scroll.y);
/*      */   }
/*      */   
/*      */   public static void setNextWindowScroll(float scrollX, float scrollY) {
/*  461 */     nSetNextWindowScroll(scrollX, scrollY);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static void setScrollX(ImGuiWindow window, float scrollX) {
/*  470 */     nSetScrollX(window.ptr, scrollX);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static void setScrollY(ImGuiWindow window, float scrollY) {
/*  478 */     nSetScrollY(window.ptr, scrollY);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static void setScrollFromPosX(ImGuiWindow window, float localX, float centerXRatio) {
/*  486 */     nSetScrollFromPosX(window.ptr, localX, centerXRatio);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static void setScrollFromPosY(ImGuiWindow window, float localY, float centerYRatio) {
/*  494 */     nSetScrollFromPosY(window.ptr, localY, centerYRatio);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static void scrollToItem() {
/*  504 */     nScrollToItem();
/*      */   }
/*      */   
/*      */   public static void scrollToItem(int flags) {
/*  508 */     nScrollToItem(flags);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static void scrollToRect(ImGuiWindow window, ImRect rect) {
/*  520 */     nScrollToRect(window.ptr, rect.min.x, rect.min.y, rect.max.x, rect.max.y);
/*      */   }
/*      */   
/*      */   public static void scrollToRect(ImGuiWindow window, float rectMinX, float rectMinY, float rectMaxX, float rectMaxY) {
/*  524 */     nScrollToRect(window.ptr, rectMinX, rectMinY, rectMaxX, rectMaxY);
/*      */   }
/*      */   
/*      */   public static void scrollToRect(ImGuiWindow window, ImRect rect, int flags) {
/*  528 */     nScrollToRect(window.ptr, rect.min.x, rect.min.y, rect.max.x, rect.max.y, flags);
/*      */   }
/*      */   
/*      */   public static void scrollToRect(ImGuiWindow window, float rectMinX, float rectMinY, float rectMaxX, float rectMaxY, int flags) {
/*  532 */     nScrollToRect(window.ptr, rectMinX, rectMinY, rectMaxX, rectMaxY, flags);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static ImVec2 scrollToRectEx(ImGuiWindow window, ImRect rect) {
/*  544 */     ImVec2 dst = new ImVec2();
/*  545 */     nScrollToRectEx(dst, window.ptr, rect.min.x, rect.min.y, rect.max.x, rect.max.y);
/*  546 */     return dst;
/*      */   }
/*      */   
/*      */   public static ImVec2 scrollToRectEx(ImGuiWindow window, float rectMinX, float rectMinY, float rectMaxX, float rectMaxY) {
/*  550 */     ImVec2 dst = new ImVec2();
/*  551 */     nScrollToRectEx(dst, window.ptr, rectMinX, rectMinY, rectMaxX, rectMaxY);
/*  552 */     return dst;
/*      */   }
/*      */   
/*      */   public static float scrollToRectExX(ImGuiWindow window, ImRect rect) {
/*  556 */     return nScrollToRectExX(window.ptr, rect.min.x, rect.min.y, rect.max.x, rect.max.y);
/*      */   }
/*      */   
/*      */   public static float scrollToRectExY(ImGuiWindow window, ImRect rect) {
/*  560 */     return nScrollToRectExY(window.ptr, rect.min.x, rect.min.y, rect.max.x, rect.max.y);
/*      */   }
/*      */   
/*      */   public static void scrollToRectEx(ImVec2 dst, ImGuiWindow window, ImRect rect) {
/*  564 */     nScrollToRectEx(dst, window.ptr, rect.min.x, rect.min.y, rect.max.x, rect.max.y);
/*      */   }
/*      */   
/*      */   public static void scrollToRectEx(ImVec2 dst, ImGuiWindow window, float rectMinX, float rectMinY, float rectMaxX, float rectMaxY) {
/*  568 */     nScrollToRectEx(dst, window.ptr, rectMinX, rectMinY, rectMaxX, rectMaxY);
/*      */   }
/*      */   
/*      */   public static ImVec2 scrollToRectEx(ImGuiWindow window, ImRect rect, int flags) {
/*  572 */     ImVec2 dst = new ImVec2();
/*  573 */     nScrollToRectEx(dst, window.ptr, rect.min.x, rect.min.y, rect.max.x, rect.max.y, flags);
/*  574 */     return dst;
/*      */   }
/*      */   
/*      */   public static ImVec2 scrollToRectEx(ImGuiWindow window, float rectMinX, float rectMinY, float rectMaxX, float rectMaxY, int flags) {
/*  578 */     ImVec2 dst = new ImVec2();
/*  579 */     nScrollToRectEx(dst, window.ptr, rectMinX, rectMinY, rectMaxX, rectMaxY, flags);
/*  580 */     return dst;
/*      */   }
/*      */   
/*      */   public static float scrollToRectExX(ImGuiWindow window, ImRect rect, int flags) {
/*  584 */     return nScrollToRectExX(window.ptr, rect.min.x, rect.min.y, rect.max.x, rect.max.y, flags);
/*      */   }
/*      */   
/*      */   public static float scrollToRectExY(ImGuiWindow window, ImRect rect, int flags) {
/*  588 */     return nScrollToRectExY(window.ptr, rect.min.x, rect.min.y, rect.max.x, rect.max.y, flags);
/*      */   }
/*      */   
/*      */   public static void scrollToRectEx(ImVec2 dst, ImGuiWindow window, ImRect rect, int flags) {
/*  592 */     nScrollToRectEx(dst, window.ptr, rect.min.x, rect.min.y, rect.max.x, rect.max.y, flags);
/*      */   }
/*      */   
/*      */   public static void scrollToRectEx(ImVec2 dst, ImGuiWindow window, float rectMinX, float rectMinY, float rectMaxX, float rectMaxY, int flags) {
/*  596 */     nScrollToRectEx(dst, window.ptr, rectMinX, rectMinY, rectMaxX, rectMaxY, flags);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static int getItemStatusFlags() {
/*  626 */     return nGetItemStatusFlags();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static int getItemFlags() {
/*  634 */     return nGetItemFlags();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static int getActiveID() {
/*  642 */     return nGetActiveID();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static int getFocusID() {
/*  650 */     return nGetFocusID();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static void setActiveID(int id, ImGuiWindow window) {
/*  658 */     nSetActiveID(id, window.ptr);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static void setFocusID(int id, ImGuiWindow window) {
/*  666 */     nSetFocusID(id, window.ptr);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static void clearActiveID() {
/*  674 */     nClearActiveID();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static int getHoveredID() {
/*  682 */     return nGetHoveredID();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static void setHoveredID(int id) {
/*  690 */     nSetHoveredID(id);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static void keepAliveID(int id) {
/*  698 */     nKeepAliveID(id);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static void markItemEdited(int id) {
/*  706 */     nMarkItemEdited(id);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static void pushOverrideID(int id) {
/*  714 */     nPushOverrideID(id);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static int getIDWithSeed(String strIdBegin, String strIdEnd, int seed) {
/*  722 */     return nGetIDWithSeed(strIdBegin, strIdEnd, seed);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static void itemSize(ImVec2 size) {
/*  737 */     nItemSize(size.x, size.y);
/*      */   }
/*      */   
/*      */   public static void itemSize(float sizeX, float sizeY) {
/*  741 */     nItemSize(sizeX, sizeY);
/*      */   }
/*      */   
/*      */   public static void itemSize(ImVec2 size, float textBaselineY) {
/*  745 */     nItemSize(size.x, size.y, textBaselineY);
/*      */   }
/*      */   
/*      */   public static void itemSize(float sizeX, float sizeY, float textBaselineY) {
/*  749 */     nItemSize(sizeX, sizeY, textBaselineY);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static void itemSize(ImRect bb) {
/*  763 */     nItemSize(bb.min.x, bb.min.y, bb.max.x, bb.max.y);
/*      */   }
/*      */   
/*      */   public static void itemSize(float bbMinX, float bbMinY, float bbMaxX, float bbMaxY) {
/*  767 */     nItemSize(bbMinX, bbMinY, bbMaxX, bbMaxY);
/*      */   }
/*      */   
/*      */   public static void itemSize(ImRect bb, float textBaselineY) {
/*  771 */     nItemSize(bb.min.x, bb.min.y, bb.max.x, bb.max.y, textBaselineY);
/*      */   }
/*      */   
/*      */   public static void itemSize(float bbMinX, float bbMinY, float bbMaxX, float bbMaxY, float textBaselineY) {
/*  775 */     nItemSize(bbMinX, bbMinY, bbMaxX, bbMaxY, textBaselineY);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static boolean itemHoverable(ImRect bb, int id, int itemFlags) {
/*  789 */     return nItemHoverable(bb.min.x, bb.min.y, bb.max.x, bb.max.y, id, itemFlags);
/*      */   }
/*      */   
/*      */   public static boolean itemHoverable(float bbMinX, float bbMinY, float bbMaxX, float bbMaxY, int id, int itemFlags) {
/*  793 */     return nItemHoverable(bbMinX, bbMinY, bbMaxX, bbMaxY, id, itemFlags);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static boolean isWindowContentHoverable(ImGuiWindow window, int flags) {
/*  801 */     return nIsWindowContentHoverable(window.ptr, flags);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static boolean isClippedEx(ImRect bb, int id) {
/*  809 */     return nIsClippedEx(bb.min.x, bb.min.y, bb.max.x, bb.max.y, id);
/*      */   }
/*      */   
/*      */   public static boolean isClippedEx(float bbMinX, float bbMinY, float bbMaxX, float bbMaxY, int id) {
/*  813 */     return nIsClippedEx(bbMinX, bbMinY, bbMaxX, bbMaxY, id);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static void setLastItemData(int itemId, int inFlags, int statusFlags, ImRect itemRect) {
/*  821 */     nSetLastItemData(itemId, inFlags, statusFlags, itemRect.min.x, itemRect.min.y, itemRect.max.x, itemRect.max.y);
/*      */   }
/*      */   
/*      */   public static void setLastItemData(int itemId, int inFlags, int statusFlags, float itemRectMinX, float itemRectMinY, float itemRectMaxX, float itemRectMaxY) {
/*  825 */     nSetLastItemData(itemId, inFlags, statusFlags, itemRectMinX, itemRectMinY, itemRectMaxX, itemRectMaxY);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static ImVec2 calcItemSize(ImVec2 size, float defaultW, float defaultH) {
/*  833 */     ImVec2 dst = new ImVec2();
/*  834 */     nCalcItemSize(dst, size.x, size.y, defaultW, defaultH);
/*  835 */     return dst;
/*      */   }
/*      */   
/*      */   public static ImVec2 calcItemSize(float sizeX, float sizeY, float defaultW, float defaultH) {
/*  839 */     ImVec2 dst = new ImVec2();
/*  840 */     nCalcItemSize(dst, sizeX, sizeY, defaultW, defaultH);
/*  841 */     return dst;
/*      */   }
/*      */   
/*      */   public static float calcItemSizeX(ImVec2 size, float defaultW, float defaultH) {
/*  845 */     return nCalcItemSizeX(size.x, size.y, defaultW, defaultH);
/*      */   }
/*      */   
/*      */   public static float calcItemSizeY(ImVec2 size, float defaultW, float defaultH) {
/*  849 */     return nCalcItemSizeY(size.x, size.y, defaultW, defaultH);
/*      */   }
/*      */   
/*      */   public static void calcItemSize(ImVec2 dst, ImVec2 size, float defaultW, float defaultH) {
/*  853 */     nCalcItemSize(dst, size.x, size.y, defaultW, defaultH);
/*      */   }
/*      */   
/*      */   public static void calcItemSize(ImVec2 dst, float sizeX, float sizeY, float defaultW, float defaultH) {
/*  857 */     nCalcItemSize(dst, sizeX, sizeY, defaultW, defaultH);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static float calcWrapWidthForPos(ImVec2 pos, float wrapPosX) {
/*  878 */     return nCalcWrapWidthForPos(pos.x, pos.y, wrapPosX);
/*      */   }
/*      */   
/*      */   public static float calcWrapWidthForPos(float posX, float posY, float wrapPosX) {
/*  882 */     return nCalcWrapWidthForPos(posX, posY, wrapPosX);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static void pushMultiItemsWidths(int components, float widthFull) {
/*  892 */     nPushMultiItemsWidths(components, widthFull);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static boolean isItemToggledSelection() {
/*  900 */     return nIsItemToggledSelection();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static ImVec2 getContentRegionMaxAbs() {
/*  908 */     ImVec2 dst = new ImVec2();
/*  909 */     nGetContentRegionMaxAbs(dst);
/*  910 */     return dst;
/*      */   }
/*      */   
/*      */   public static float getContentRegionMaxAbsX() {
/*  914 */     return nGetContentRegionMaxAbsX();
/*      */   }
/*      */   
/*      */   public static float getContentRegionMaxAbsY() {
/*  918 */     return nGetContentRegionMaxAbsY();
/*      */   }
/*      */   
/*      */   public static void getContentRegionMaxAbs(ImVec2 dst) {
/*  922 */     nGetContentRegionMaxAbs(dst);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static void pushItemFlag(int option, boolean enabled) {
/*  942 */     nPushItemFlag(option, enabled);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static void popItemFlag() {
/*  950 */     nPopItemFlag();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static void dockBuilderDockWindow(String windowName, int nodeId) {
/*  968 */     nDockBuilderDockWindow(windowName, nodeId);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static ImGuiDockNode dockBuilderGetNode(int nodeId) {
/*  978 */     return new ImGuiDockNode(nDockBuilderGetNode(nodeId));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static ImGuiDockNode dockBuilderGetCentralNode(int nodeId) {
/*  986 */     return new ImGuiDockNode(nDockBuilderGetCentralNode(nodeId));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static int dockBuilderAddNode() {
/*  994 */     return nDockBuilderAddNode();
/*      */   }
/*      */   
/*      */   public static int dockBuilderAddNode(int nodeId) {
/*  998 */     return nDockBuilderAddNode(nodeId);
/*      */   }
/*      */   
/*      */   public static int dockBuilderAddNode(int nodeId, int flags) {
/* 1002 */     return nDockBuilderAddNode(nodeId, flags);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static void dockBuilderRemoveNode(int nodeId) {
/* 1021 */     nDockBuilderRemoveNode(nodeId);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static void dockBuilderRemoveNodeDockedWindows(int nodeId) {
/* 1029 */     nDockBuilderRemoveNodeDockedWindows(nodeId);
/*      */   }
/*      */   
/*      */   public static void dockBuilderRemoveNodeDockedWindows(int nodeId, boolean clearSettingsRefs) {
/* 1033 */     nDockBuilderRemoveNodeDockedWindows(nodeId, clearSettingsRefs);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static void dockBuilderRemoveNodeChildNodes(int nodeId) {
/* 1048 */     nDockBuilderRemoveNodeChildNodes(nodeId);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static void dockBuilderSetNodePos(int nodeId, ImVec2 pos) {
/* 1056 */     nDockBuilderSetNodePos(nodeId, pos.x, pos.y);
/*      */   }
/*      */   
/*      */   public static void dockBuilderSetNodePos(int nodeId, float posX, float posY) {
/* 1060 */     nDockBuilderSetNodePos(nodeId, posX, posY);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static void dockBuilderSetNodeSize(int nodeId, ImVec2 size) {
/* 1069 */     nDockBuilderSetNodeSize(nodeId, size.x, size.y);
/*      */   }
/*      */   
/*      */   public static void dockBuilderSetNodeSize(int nodeId, float sizeX, float sizeY) {
/* 1073 */     nDockBuilderSetNodeSize(nodeId, sizeX, sizeY);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static int dockBuilderSplitNode(int nodeId, int splitDir, float sizeRatioForNodeAtDir, ImInt outIdAtDir, ImInt outIdAtOppositeDir) {
/* 1085 */     return nDockBuilderSplitNode(nodeId, splitDir, sizeRatioForNodeAtDir, (outIdAtDir != null) ? outIdAtDir.getData() : null, (outIdAtOppositeDir != null) ? outIdAtOppositeDir.getData() : null);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static void dockBuilderCopyWindowSettings(String srcName, String dstName) {
/* 1100 */     nDockBuilderCopyWindowSettings(srcName, dstName);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static void dockBuilderFinish(int nodeId) {
/* 1112 */     nDockBuilderFinish(nodeId);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static void tableOpenContextMenu() {
/* 1122 */     nTableOpenContextMenu();
/*      */   }
/*      */   
/*      */   public static void tableOpenContextMenu(int columnN) {
/* 1126 */     nTableOpenContextMenu(columnN);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static void tableSetColumnWidth(int columnN, float width) {
/* 1138 */     nTableSetColumnWidth(columnN, width);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static void tableSetColumnSortDirection(int columnN, int sortDirection, boolean appendToSortSpecs) {
/* 1146 */     nTableSetColumnSortDirection(columnN, sortDirection, appendToSortSpecs);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static int tableGetHoveredColumn() {
/* 1158 */     return nTableGetHoveredColumn();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static int tableGetHoveredRow() {
/* 1169 */     return nTableGetHoveredRow();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static float tableGetHeaderRowHeight() {
/* 1177 */     return nTableGetHeaderRowHeight();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static void tablePushBackgroundChannel() {
/* 1185 */     nTablePushBackgroundChannel();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static void tablePopBackgroundChannel() {
/* 1193 */     nTablePopBackgroundChannel();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static void textEx(String beginText) {
/* 1203 */     nTextEx(beginText);
/*      */   }
/*      */   
/*      */   public static void textEx(String beginText, String endText) {
/* 1207 */     nTextEx(beginText, endText);
/*      */   }
/*      */   
/*      */   public static void textEx(String beginText, String endText, int flags) {
/* 1211 */     nTextEx(beginText, endText, flags);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static boolean buttonEx(String label) {
/* 1237 */     return nButtonEx(label);
/*      */   }
/*      */   
/*      */   public static boolean buttonEx(String label, ImVec2 size) {
/* 1241 */     return nButtonEx(label, size.x, size.y);
/*      */   }
/*      */   
/*      */   public static boolean buttonEx(String label, float sizeX, float sizeY) {
/* 1245 */     return nButtonEx(label, sizeX, sizeY);
/*      */   }
/*      */   
/*      */   public static boolean buttonEx(String label, ImVec2 size, int flags) {
/* 1249 */     return nButtonEx(label, size.x, size.y, flags);
/*      */   }
/*      */   
/*      */   public static boolean buttonEx(String label, float sizeX, float sizeY, int flags) {
/* 1253 */     return nButtonEx(label, sizeX, sizeY, flags);
/*      */   }
/*      */   
/*      */   public static boolean buttonEx(String label, int flags) {
/* 1257 */     return nButtonEx(label, flags);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static boolean arrowButtonEx(String strId, int dir, ImVec2 size) {
/* 1291 */     return nArrowButtonEx(strId, dir, size.x, size.y);
/*      */   }
/*      */   
/*      */   public static boolean arrowButtonEx(String strId, int dir, float sizeX, float sizeY) {
/* 1295 */     return nArrowButtonEx(strId, dir, sizeX, sizeY);
/*      */   }
/*      */   
/*      */   public static boolean arrowButtonEx(String strId, int dir, ImVec2 size, int flags) {
/* 1299 */     return nArrowButtonEx(strId, dir, size.x, size.y, flags);
/*      */   }
/*      */   
/*      */   public static boolean arrowButtonEx(String strId, int dir, float sizeX, float sizeY, int flags) {
/* 1303 */     return nArrowButtonEx(strId, dir, sizeX, sizeY, flags);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static boolean imageButtonEx(int id, long textureId, ImVec2 size, ImVec2 uv0, ImVec2 uv1, ImVec4 bgCol, ImVec4 tintCol, int flags) {
/* 1323 */     return nImageButtonEx(id, textureId, size.x, size.y, uv0.x, uv0.y, uv1.x, uv1.y, bgCol.x, bgCol.y, bgCol.z, bgCol.w, tintCol.x, tintCol.y, tintCol.z, tintCol.w, flags);
/*      */   }
/*      */   
/*      */   public static boolean imageButtonEx(int id, long textureId, float sizeX, float sizeY, float uv0X, float uv0Y, float uv1X, float uv1Y, float bgColX, float bgColY, float bgColZ, float bgColW, float tintColX, float tintColY, float tintColZ, float tintColW, int flags) {
/* 1327 */     return nImageButtonEx(id, textureId, sizeX, sizeY, uv0X, uv0Y, uv1X, uv1Y, bgColX, bgColY, bgColZ, bgColW, tintColX, tintColY, tintColZ, tintColW, flags);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static void separatorEx(int flags) {
/* 1341 */     nSeparatorEx(flags);
/*      */   }
/*      */   
/*      */   public static void separatorEx(int flags, float thickness) {
/* 1345 */     nSeparatorEx(flags, thickness);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static void separatorTextEx(int id, String label, String labelEnd, float extraWidth) {
/* 1357 */     nSeparatorTextEx(id, label, labelEnd, extraWidth);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static boolean closeButton(int id, ImVec2 pos) {
/* 1371 */     return nCloseButton(id, pos.x, pos.y);
/*      */   }
/*      */   
/*      */   public static boolean closeButton(int id, float posX, float posY) {
/* 1375 */     return nCloseButton(id, posX, posY);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static boolean collapseButton(int id, ImVec2 pos, ImGuiDockNode dockNode) {
/* 1385 */     return nCollapseButton(id, pos.x, pos.y, dockNode.ptr);
/*      */   }
/*      */   
/*      */   public static boolean collapseButton(int id, float posX, float posY, ImGuiDockNode dockNode) {
/* 1389 */     return nCollapseButton(id, posX, posY, dockNode.ptr);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static void scrollbar(int axis) {
/* 1399 */     nScrollbar(axis);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static ImRect getWindowScrollbarRect(ImGuiWindow imGuiWindow, int axis) {
/* 1407 */     ImRect dst = new ImRect();
/* 1408 */     nGetWindowScrollbarRect(dst, imGuiWindow.ptr, axis);
/* 1409 */     return dst;
/*      */   }
/*      */   
/*      */   public static void getWindowScrollbarRect(ImRect dst, ImGuiWindow imGuiWindow, int axis) {
/* 1413 */     nGetWindowScrollbarRect(dst, imGuiWindow.ptr, axis);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static int getWindowScrollbarID(ImGuiWindow window, int axis) {
/* 1421 */     return nGetWindowScrollbarID(window.ptr, axis);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static int getWindowResizeCornerID(ImGuiWindow window, int n) {
/* 1429 */     return nGetWindowResizeCornerID(window.ptr, n);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static int getWindowResizeBorderID(ImGuiWindow window, int dir) {
/* 1437 */     return nGetWindowResizeBorderID(window.ptr, dir);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static boolean buttonBehavior(ImRect bb, int id, ImBoolean outHovered, ImBoolean outHeld) {
/* 1447 */     return nButtonBehavior(bb.min.x, bb.min.y, bb.max.x, bb.max.y, id, (outHovered != null) ? outHovered.getData() : null, (outHeld != null) ? outHeld.getData() : null);
/*      */   }
/*      */   
/*      */   public static boolean buttonBehavior(float bbMinX, float bbMinY, float bbMaxX, float bbMaxY, int id, ImBoolean outHovered, ImBoolean outHeld) {
/* 1451 */     return nButtonBehavior(bbMinX, bbMinY, bbMaxX, bbMaxY, id, (outHovered != null) ? outHovered.getData() : null, (outHeld != null) ? outHeld.getData() : null);
/*      */   }
/*      */   
/*      */   public static boolean buttonBehavior(ImRect bb, int id, ImBoolean outHovered, ImBoolean outHeld, int imGuiButtonFlags) {
/* 1455 */     return nButtonBehavior(bb.min.x, bb.min.y, bb.max.x, bb.max.y, id, (outHovered != null) ? outHovered.getData() : null, (outHeld != null) ? outHeld.getData() : null, imGuiButtonFlags);
/*      */   }
/*      */   
/*      */   public static boolean buttonBehavior(float bbMinX, float bbMinY, float bbMaxX, float bbMaxY, int id, ImBoolean outHovered, ImBoolean outHeld, int imGuiButtonFlags) {
/* 1459 */     return nButtonBehavior(bbMinX, bbMinY, bbMaxX, bbMaxY, id, (outHovered != null) ? outHovered.getData() : null, (outHeld != null) ? outHeld.getData() : null, imGuiButtonFlags);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static boolean splitterBehavior(ImRect bb, int id, int axis, ImFloat size1, ImFloat size2, float minSize1, float minSize2) {
/* 1481 */     return nSplitterBehavior(bb.min.x, bb.min.y, bb.max.x, bb.max.y, id, axis, (size1 != null) ? size1.getData() : null, (size2 != null) ? size2.getData() : null, minSize1, minSize2);
/*      */   }
/*      */   
/*      */   public static boolean splitterBehavior(float bbMinX, float bbMinY, float bbMaxX, float bbMaxY, int id, int axis, ImFloat size1, ImFloat size2, float minSize1, float minSize2) {
/* 1485 */     return nSplitterBehavior(bbMinX, bbMinY, bbMaxX, bbMaxY, id, axis, (size1 != null) ? size1.getData() : null, (size2 != null) ? size2.getData() : null, minSize1, minSize2);
/*      */   }
/*      */   
/*      */   public static boolean splitterBehavior(ImRect bb, int id, int axis, ImFloat size1, ImFloat size2, float minSize1, float minSize2, float hoverExtend) {
/* 1489 */     return nSplitterBehavior(bb.min.x, bb.min.y, bb.max.x, bb.max.y, id, axis, (size1 != null) ? size1.getData() : null, (size2 != null) ? size2.getData() : null, minSize1, minSize2, hoverExtend);
/*      */   }
/*      */   
/*      */   public static boolean splitterBehavior(float bbMinX, float bbMinY, float bbMaxX, float bbMaxY, int id, int axis, ImFloat size1, ImFloat size2, float minSize1, float minSize2, float hoverExtend) {
/* 1493 */     return nSplitterBehavior(bbMinX, bbMinY, bbMaxX, bbMaxY, id, axis, (size1 != null) ? size1.getData() : null, (size2 != null) ? size2.getData() : null, minSize1, minSize2, hoverExtend);
/*      */   }
/*      */   
/*      */   public static boolean splitterBehavior(ImRect bb, int id, int axis, ImFloat size1, ImFloat size2, float minSize1, float minSize2, float hoverExtend, float hoverVisibilityDelay) {
/* 1497 */     return nSplitterBehavior(bb.min.x, bb.min.y, bb.max.x, bb.max.y, id, axis, (size1 != null) ? size1.getData() : null, (size2 != null) ? size2.getData() : null, minSize1, minSize2, hoverExtend, hoverVisibilityDelay);
/*      */   }
/*      */   
/*      */   public static boolean splitterBehavior(float bbMinX, float bbMinY, float bbMaxX, float bbMaxY, int id, int axis, ImFloat size1, ImFloat size2, float minSize1, float minSize2, float hoverExtend, float hoverVisibilityDelay) {
/* 1501 */     return nSplitterBehavior(bbMinX, bbMinY, bbMaxX, bbMaxY, id, axis, (size1 != null) ? size1.getData() : null, (size2 != null) ? size2.getData() : null, minSize1, minSize2, hoverExtend, hoverVisibilityDelay);
/*      */   }
/*      */   
/*      */   public static boolean splitterBehavior(ImRect bb, int id, int axis, ImFloat size1, ImFloat size2, float minSize1, float minSize2, float hoverExtend, float hoverVisibilityDelay, int bgCol) {
/* 1505 */     return nSplitterBehavior(bb.min.x, bb.min.y, bb.max.x, bb.max.y, id, axis, (size1 != null) ? size1.getData() : null, (size2 != null) ? size2.getData() : null, minSize1, minSize2, hoverExtend, hoverVisibilityDelay, bgCol);
/*      */   }
/*      */   
/*      */   public static boolean splitterBehavior(float bbMinX, float bbMinY, float bbMaxX, float bbMaxY, int id, int axis, ImFloat size1, ImFloat size2, float minSize1, float minSize2, float hoverExtend, float hoverVisibilityDelay, int bgCol) {
/* 1509 */     return nSplitterBehavior(bbMinX, bbMinY, bbMaxX, bbMaxY, id, axis, (size1 != null) ? size1.getData() : null, (size2 != null) ? size2.getData() : null, minSize1, minSize2, hoverExtend, hoverVisibilityDelay, bgCol);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static void shadeVertsTransformPos(ImDrawList drawList, int vertStartIdx, int vertEndIdx, ImVec2 pivotIn, float cosA, float sinA, ImVec2 pivotOut) {
/* 1551 */     nShadeVertsTransformPos(drawList.ptr, vertStartIdx, vertEndIdx, pivotIn.x, pivotIn.y, cosA, sinA, pivotOut.x, pivotOut.y);
/*      */   }
/*      */   
/*      */   public static void shadeVertsTransformPos(ImDrawList drawList, int vertStartIdx, int vertEndIdx, float pivotInX, float pivotInY, float cosA, float sinA, float pivotOutX, float pivotOutY) {
/* 1555 */     nShadeVertsTransformPos(drawList.ptr, vertStartIdx, vertEndIdx, pivotInX, pivotInY, cosA, sinA, pivotOutX, pivotOutY);
/*      */   }
/*      */   
/*      */   private static native void nInit();
/*      */   
/*      */   private static native long nGetCurrentWindowRead();
/*      */   
/*      */   private static native long nGetCurrentWindow();
/*      */   
/*      */   private static native long nFindWindowByID(int paramInt);
/*      */   
/*      */   private static native long nFindWindowByName(String paramString);
/*      */   
/*      */   private static native void nUpdateWindowParentAndRootLinks(long paramLong1, int paramInt, long paramLong2);
/*      */   
/*      */   private static native void nCalcWindowNextAutoFitSize(ImVec2 paramImVec2, long paramLong);
/*      */   
/*      */   private static native float nCalcWindowNextAutoFitSizeX(long paramLong);
/*      */   
/*      */   private static native float nCalcWindowNextAutoFitSizeY(long paramLong);
/*      */   
/*      */   private static native boolean nIsWindowChildOf(long paramLong1, long paramLong2, boolean paramBoolean1, boolean paramBoolean2);
/*      */   
/*      */   private static native boolean nIsWindowWithinBeginStackOf(long paramLong1, long paramLong2);
/*      */   
/*      */   private static native boolean nIsWindowAbove(long paramLong1, long paramLong2);
/*      */   
/*      */   private static native boolean nIsWindowNavFocusable(long paramLong);
/*      */   
/*      */   private static native void nSetWindowPos(long paramLong, float paramFloat1, float paramFloat2);
/*      */   
/*      */   private static native void nSetWindowPos(long paramLong, float paramFloat1, float paramFloat2, int paramInt);
/*      */   
/*      */   private static native void nSetWindowSize(long paramLong, float paramFloat1, float paramFloat2);
/*      */   
/*      */   private static native void nSetWindowSize(long paramLong, float paramFloat1, float paramFloat2, int paramInt);
/*      */   
/*      */   private static native void nSetWindowCollapsed(long paramLong, boolean paramBoolean);
/*      */   
/*      */   private static native void nSetWindowCollapsed(long paramLong, boolean paramBoolean, int paramInt);
/*      */   
/*      */   private static native void nSetWindowHitTestHole(long paramLong, float paramFloat1, float paramFloat2, float paramFloat3, float paramFloat4);
/*      */   
/*      */   private static native void nWindowRectAbsToRel(ImRect paramImRect, long paramLong, float paramFloat1, float paramFloat2, float paramFloat3, float paramFloat4);
/*      */   
/*      */   private static native void nWindowRectRelToAbs(ImRect paramImRect, long paramLong, float paramFloat1, float paramFloat2, float paramFloat3, float paramFloat4);
/*      */   
/*      */   private static native void nFocusWindow(long paramLong);
/*      */   
/*      */   private static native void nFocusWindow(long paramLong, int paramInt);
/*      */   
/*      */   private static native void nFocusTopMostWindowUnderOne(long paramLong1, long paramLong2, long paramLong3, int paramInt);
/*      */   
/*      */   private static native void nBringWindowToFocusFront(long paramLong);
/*      */   
/*      */   private static native void nBringWindowToDisplayFront(long paramLong);
/*      */   
/*      */   private static native void nBringWindowToDisplayBack(long paramLong);
/*      */   
/*      */   private static native void nBringWindowToDisplayBehind(long paramLong1, long paramLong2);
/*      */   
/*      */   private static native int nFindWindowDisplayIndex(long paramLong);
/*      */   
/*      */   private static native long nFindBottomMostVisibleWindowWithinBeginStack(long paramLong);
/*      */   
/*      */   private static native void nSetCurrentFont(long paramLong);
/*      */   
/*      */   private static native long nGetDefaultFont();
/*      */   
/*      */   private static native long nGetForegroundDrawList(long paramLong);
/*      */   
/*      */   private static native void nInitialize();
/*      */   
/*      */   private static native void nShutdown();
/*      */   
/*      */   private static native void nUpdateInputEvents(boolean paramBoolean);
/*      */   
/*      */   private static native void nUpdateHoveredWindowAndCaptureFlags();
/*      */   
/*      */   private static native void nStartMouseMovingWindow(long paramLong);
/*      */   
/*      */   private static native void nStartMouseMovingWindowOrNode(long paramLong1, long paramLong2, boolean paramBoolean);
/*      */   
/*      */   private static native void nUpdateMouseMovingWindowNewFrame();
/*      */   
/*      */   private static native void nUpdateMouseMovingWindowEndFrame();
/*      */   
/*      */   private static native long nGetViewportPlatformMonitor(long paramLong);
/*      */   
/*      */   private static native void nSetNextWindowScroll(float paramFloat1, float paramFloat2);
/*      */   
/*      */   private static native void nSetScrollX(long paramLong, float paramFloat);
/*      */   
/*      */   private static native void nSetScrollY(long paramLong, float paramFloat);
/*      */   
/*      */   private static native void nSetScrollFromPosX(long paramLong, float paramFloat1, float paramFloat2);
/*      */   
/*      */   private static native void nSetScrollFromPosY(long paramLong, float paramFloat1, float paramFloat2);
/*      */   
/*      */   private static native void nScrollToItem();
/*      */   
/*      */   private static native void nScrollToItem(int paramInt);
/*      */   
/*      */   private static native void nScrollToRect(long paramLong, float paramFloat1, float paramFloat2, float paramFloat3, float paramFloat4);
/*      */   
/*      */   private static native void nScrollToRect(long paramLong, float paramFloat1, float paramFloat2, float paramFloat3, float paramFloat4, int paramInt);
/*      */   
/*      */   private static native void nScrollToRectEx(ImVec2 paramImVec2, long paramLong, float paramFloat1, float paramFloat2, float paramFloat3, float paramFloat4);
/*      */   
/*      */   private static native float nScrollToRectExX(long paramLong, float paramFloat1, float paramFloat2, float paramFloat3, float paramFloat4);
/*      */   
/*      */   private static native float nScrollToRectExY(long paramLong, float paramFloat1, float paramFloat2, float paramFloat3, float paramFloat4);
/*      */   
/*      */   private static native void nScrollToRectEx(ImVec2 paramImVec2, long paramLong, float paramFloat1, float paramFloat2, float paramFloat3, float paramFloat4, int paramInt);
/*      */   
/*      */   private static native float nScrollToRectExX(long paramLong, float paramFloat1, float paramFloat2, float paramFloat3, float paramFloat4, int paramInt);
/*      */   
/*      */   private static native float nScrollToRectExY(long paramLong, float paramFloat1, float paramFloat2, float paramFloat3, float paramFloat4, int paramInt);
/*      */   
/*      */   private static native int nGetItemStatusFlags();
/*      */   
/*      */   private static native int nGetItemFlags();
/*      */   
/*      */   private static native int nGetActiveID();
/*      */   
/*      */   private static native int nGetFocusID();
/*      */   
/*      */   private static native void nSetActiveID(int paramInt, long paramLong);
/*      */   
/*      */   private static native void nSetFocusID(int paramInt, long paramLong);
/*      */   
/*      */   private static native void nClearActiveID();
/*      */   
/*      */   private static native int nGetHoveredID();
/*      */   
/*      */   private static native void nSetHoveredID(int paramInt);
/*      */   
/*      */   private static native void nKeepAliveID(int paramInt);
/*      */   
/*      */   private static native void nMarkItemEdited(int paramInt);
/*      */   
/*      */   private static native void nPushOverrideID(int paramInt);
/*      */   
/*      */   private static native int nGetIDWithSeed(String paramString1, String paramString2, int paramInt);
/*      */   
/*      */   private static native void nItemSize(float paramFloat1, float paramFloat2);
/*      */   
/*      */   private static native void nItemSize(float paramFloat1, float paramFloat2, float paramFloat3);
/*      */   
/*      */   private static native void nItemSize(float paramFloat1, float paramFloat2, float paramFloat3, float paramFloat4);
/*      */   
/*      */   private static native void nItemSize(float paramFloat1, float paramFloat2, float paramFloat3, float paramFloat4, float paramFloat5);
/*      */   
/*      */   private static native boolean nItemHoverable(float paramFloat1, float paramFloat2, float paramFloat3, float paramFloat4, int paramInt1, int paramInt2);
/*      */   
/*      */   private static native boolean nIsWindowContentHoverable(long paramLong, int paramInt);
/*      */   
/*      */   private static native boolean nIsClippedEx(float paramFloat1, float paramFloat2, float paramFloat3, float paramFloat4, int paramInt);
/*      */   
/*      */   private static native void nSetLastItemData(int paramInt1, int paramInt2, int paramInt3, float paramFloat1, float paramFloat2, float paramFloat3, float paramFloat4);
/*      */   
/*      */   private static native void nCalcItemSize(ImVec2 paramImVec2, float paramFloat1, float paramFloat2, float paramFloat3, float paramFloat4);
/*      */   
/*      */   private static native float nCalcItemSizeX(float paramFloat1, float paramFloat2, float paramFloat3, float paramFloat4);
/*      */   
/*      */   private static native float nCalcItemSizeY(float paramFloat1, float paramFloat2, float paramFloat3, float paramFloat4);
/*      */   
/*      */   private static native float nCalcWrapWidthForPos(float paramFloat1, float paramFloat2, float paramFloat3);
/*      */   
/*      */   private static native void nPushMultiItemsWidths(int paramInt, float paramFloat);
/*      */   
/*      */   private static native boolean nIsItemToggledSelection();
/*      */   
/*      */   private static native void nGetContentRegionMaxAbs(ImVec2 paramImVec2);
/*      */   
/*      */   private static native float nGetContentRegionMaxAbsX();
/*      */   
/*      */   private static native float nGetContentRegionMaxAbsY();
/*      */   
/*      */   private static native void nPushItemFlag(int paramInt, boolean paramBoolean);
/*      */   
/*      */   private static native void nPopItemFlag();
/*      */   
/*      */   private static native void nDockBuilderDockWindow(String paramString, int paramInt);
/*      */   
/*      */   private static native long nDockBuilderGetNode(int paramInt);
/*      */   
/*      */   private static native long nDockBuilderGetCentralNode(int paramInt);
/*      */   
/*      */   private static native int nDockBuilderAddNode();
/*      */   
/*      */   private static native int nDockBuilderAddNode(int paramInt);
/*      */   
/*      */   private static native int nDockBuilderAddNode(int paramInt1, int paramInt2);
/*      */   
/*      */   private static native void nDockBuilderRemoveNode(int paramInt);
/*      */   
/*      */   private static native void nDockBuilderRemoveNodeDockedWindows(int paramInt);
/*      */   
/*      */   private static native void nDockBuilderRemoveNodeDockedWindows(int paramInt, boolean paramBoolean);
/*      */   
/*      */   private static native void nDockBuilderRemoveNodeChildNodes(int paramInt);
/*      */   
/*      */   private static native void nDockBuilderSetNodePos(int paramInt, float paramFloat1, float paramFloat2);
/*      */   
/*      */   private static native void nDockBuilderSetNodeSize(int paramInt, float paramFloat1, float paramFloat2);
/*      */   
/*      */   private static native int nDockBuilderSplitNode(int paramInt1, int paramInt2, float paramFloat, int[] paramArrayOfint1, int[] paramArrayOfint2);
/*      */   
/*      */   private static native void nDockBuilderCopyWindowSettings(String paramString1, String paramString2);
/*      */   
/*      */   private static native void nDockBuilderFinish(int paramInt);
/*      */   
/*      */   private static native void nTableOpenContextMenu();
/*      */   
/*      */   private static native void nTableOpenContextMenu(int paramInt);
/*      */   
/*      */   private static native void nTableSetColumnWidth(int paramInt, float paramFloat);
/*      */   
/*      */   private static native void nTableSetColumnSortDirection(int paramInt1, int paramInt2, boolean paramBoolean);
/*      */   
/*      */   private static native int nTableGetHoveredColumn();
/*      */   
/*      */   private static native int nTableGetHoveredRow();
/*      */   
/*      */   private static native float nTableGetHeaderRowHeight();
/*      */   
/*      */   private static native void nTablePushBackgroundChannel();
/*      */   
/*      */   private static native void nTablePopBackgroundChannel();
/*      */   
/*      */   private static native void nTextEx(String paramString);
/*      */   
/*      */   private static native void nTextEx(String paramString1, String paramString2);
/*      */   
/*      */   private static native void nTextEx(String paramString1, String paramString2, int paramInt);
/*      */   
/*      */   private static native boolean nButtonEx(String paramString);
/*      */   
/*      */   private static native boolean nButtonEx(String paramString, float paramFloat1, float paramFloat2);
/*      */   
/*      */   private static native boolean nButtonEx(String paramString, float paramFloat1, float paramFloat2, int paramInt);
/*      */   
/*      */   private static native boolean nButtonEx(String paramString, int paramInt);
/*      */   
/*      */   private static native boolean nArrowButtonEx(String paramString, int paramInt, float paramFloat1, float paramFloat2);
/*      */   
/*      */   private static native boolean nArrowButtonEx(String paramString, int paramInt1, float paramFloat1, float paramFloat2, int paramInt2);
/*      */   
/*      */   private static native boolean nImageButtonEx(int paramInt1, long paramLong, float paramFloat1, float paramFloat2, float paramFloat3, float paramFloat4, float paramFloat5, float paramFloat6, float paramFloat7, float paramFloat8, float paramFloat9, float paramFloat10, float paramFloat11, float paramFloat12, float paramFloat13, float paramFloat14, int paramInt2);
/*      */   
/*      */   private static native void nSeparatorEx(int paramInt);
/*      */   
/*      */   private static native void nSeparatorEx(int paramInt, float paramFloat);
/*      */   
/*      */   private static native void nSeparatorTextEx(int paramInt, String paramString1, String paramString2, float paramFloat);
/*      */   
/*      */   private static native boolean nCloseButton(int paramInt, float paramFloat1, float paramFloat2);
/*      */   
/*      */   private static native boolean nCollapseButton(int paramInt, float paramFloat1, float paramFloat2, long paramLong);
/*      */   
/*      */   private static native void nScrollbar(int paramInt);
/*      */   
/*      */   private static native void nGetWindowScrollbarRect(ImRect paramImRect, long paramLong, int paramInt);
/*      */   
/*      */   private static native int nGetWindowScrollbarID(long paramLong, int paramInt);
/*      */   
/*      */   private static native int nGetWindowResizeCornerID(long paramLong, int paramInt);
/*      */   
/*      */   private static native int nGetWindowResizeBorderID(long paramLong, int paramInt);
/*      */   
/*      */   private static native boolean nButtonBehavior(float paramFloat1, float paramFloat2, float paramFloat3, float paramFloat4, int paramInt, boolean[] paramArrayOfboolean1, boolean[] paramArrayOfboolean2);
/*      */   
/*      */   private static native boolean nButtonBehavior(float paramFloat1, float paramFloat2, float paramFloat3, float paramFloat4, int paramInt1, boolean[] paramArrayOfboolean1, boolean[] paramArrayOfboolean2, int paramInt2);
/*      */   
/*      */   private static native boolean nSplitterBehavior(float paramFloat1, float paramFloat2, float paramFloat3, float paramFloat4, int paramInt1, int paramInt2, float[] paramArrayOffloat1, float[] paramArrayOffloat2, float paramFloat5, float paramFloat6);
/*      */   
/*      */   private static native boolean nSplitterBehavior(float paramFloat1, float paramFloat2, float paramFloat3, float paramFloat4, int paramInt1, int paramInt2, float[] paramArrayOffloat1, float[] paramArrayOffloat2, float paramFloat5, float paramFloat6, float paramFloat7);
/*      */   
/*      */   private static native boolean nSplitterBehavior(float paramFloat1, float paramFloat2, float paramFloat3, float paramFloat4, int paramInt1, int paramInt2, float[] paramArrayOffloat1, float[] paramArrayOffloat2, float paramFloat5, float paramFloat6, float paramFloat7, float paramFloat8);
/*      */   
/*      */   private static native boolean nSplitterBehavior(float paramFloat1, float paramFloat2, float paramFloat3, float paramFloat4, int paramInt1, int paramInt2, float[] paramArrayOffloat1, float[] paramArrayOffloat2, float paramFloat5, float paramFloat6, float paramFloat7, float paramFloat8, int paramInt3);
/*      */   
/*      */   private static native void nShadeVertsTransformPos(long paramLong, int paramInt1, int paramInt2, float paramFloat1, float paramFloat2, float paramFloat3, float paramFloat4, float paramFloat5, float paramFloat6);
/*      */ }


/* Location:              C:\Users\rapha\Downloads\aurora.jar!\META-INF\jars\imgui-java-binding-1.90.0.jar!\imgui\internal\ImGui.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */