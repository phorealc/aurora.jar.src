/*     */ package com.zigythebird.playeranimcore.network;
/*     */ 
/*     */ import com.zigythebird.playeranimcore.animation.Animation;
/*     */ import com.zigythebird.playeranimcore.animation.ExtraAnimationData;
/*     */ import com.zigythebird.playeranimcore.animation.keyframe.BoneAnimation;
/*     */ import com.zigythebird.playeranimcore.animation.keyframe.Keyframe;
/*     */ import com.zigythebird.playeranimcore.easing.EasingType;
/*     */ import com.zigythebird.playeranimcore.enums.AnimationFormat;
/*     */ import com.zigythebird.playeranimcore.loading.PlayerAnimatorLoader;
/*     */ import com.zigythebird.playeranimcore.loading.UniversalAnimLoader;
/*     */ import com.zigythebird.playeranimcore.math.Vec3f;
/*     */ import com.zigythebird.playeranimcore.molang.MolangLoader;
/*     */ import io.netty.buffer.ByteBuf;
/*     */ import java.io.IOException;
/*     */ import java.nio.charset.StandardCharsets;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Collections;
/*     */ import java.util.HashMap;
/*     */ import java.util.LinkedHashMap;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import java.util.function.Predicate;
/*     */ import team.unnamed.mocha.parser.ast.Expression;
/*     */ import team.unnamed.mocha.parser.ast.FloatExpression;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class LegacyAnimationBinary
/*     */ {
/*     */   public static final Predicate<String> BEND_BONE;
/*     */   public static final Predicate<String> ITEM_BONE;
/*     */   
/*     */   static {
/*  54 */     BEND_BONE = (name -> (!name.equals("head") && !name.equals("left_item") && !name.equals("right_item")));
/*  55 */     ITEM_BONE = (name -> (name.equals("left_item") || name.equals("right_item")));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static void write(Animation animation, ByteBuf buf, int version) {
/*  68 */     Map<String, BoneAnimation> boneAnimations = bonesToWrite(animation);
/*  69 */     buf.writeInt(((Float)animation.data().get("beginTick").orElse(Float.valueOf(0.0F))).intValue());
/*  70 */     int endTick = ((Float)animation.data().get("endTick").orElse(Float.valueOf(animation.length()))).intValue();
/*  71 */     buf.writeInt(endTick);
/*  72 */     buf.writeInt((int)animation.length());
/*  73 */     if (animation.loopType() == Animation.LoopType.HOLD_ON_LAST_FRAME) {
/*  74 */       putBoolean(buf, true);
/*  75 */       buf.writeInt(endTick);
/*     */     } else {
/*  77 */       putBoolean(buf, animation.loopType().shouldPlayAgain(null, animation));
/*  78 */       buf.writeInt((int)animation.loopType().restartFromTick(null, animation) + 1);
/*     */     } 
/*     */     
/*  81 */     boolean easeBefore = ((Boolean)animation.data().get("easeBeforeKeyframe").orElse(Boolean.valueOf((animation.data().data().getOrDefault("format", AnimationFormat.GECKOLIB) == AnimationFormat.GECKOLIB)))).booleanValue();
/*  82 */     putBoolean(buf, easeBefore);
/*  83 */     putBoolean(buf, false);
/*  84 */     buf.writeByte(keyframeSize(version));
/*  85 */     if (version >= 2) {
/*  86 */       buf.writeInt(boneAnimations.size());
/*  87 */       for (Map.Entry<String, BoneAnimation> part : boneAnimations.entrySet()) {
/*  88 */         putString(buf, UniversalAnimLoader.restorePlayerBoneName(part.getKey()));
/*  89 */         writePart(buf, part.getKey(), part.getValue(), version, easeBefore);
/*     */       } 
/*     */     } else {
/*  92 */       writePart(buf, "head", boneAnimations.get("head"), version, easeBefore);
/*  93 */       writePart(buf, "body", boneAnimations.get("body"), version, easeBefore);
/*  94 */       writePart(buf, "right_arm", boneAnimations.get("right_arm"), version, easeBefore);
/*  95 */       writePart(buf, "left_arm", boneAnimations.get("left_arm"), version, easeBefore);
/*  96 */       writePart(buf, "right_leg", boneAnimations.get("right_leg"), version, easeBefore);
/*  97 */       writePart(buf, "left_leg", boneAnimations.get("left_leg"), version, easeBefore);
/*     */     } 
/*  99 */     NetworkUtils.writeUuid(buf, animation.uuid());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static Map<String, BoneAnimation> bonesToWrite(Animation animation) {
/* 109 */     BoneAnimation torso = (BoneAnimation)animation.boneAnimations().get("torso");
/* 110 */     if (torso == null || torso.bendKeyFrames().isEmpty() || animation
/* 111 */       .data().getNullable("applyBendToOtherBones") != Boolean.TRUE) {
/* 112 */       return animation.boneAnimations();
/*     */     }
/* 114 */     Map<String, BoneAnimation> bones = new LinkedHashMap<>(animation.boneAnimations());
/* 115 */     BoneAnimation body = bones.getOrDefault("body", new BoneAnimation());
/* 116 */     bones.put("body", new BoneAnimation(body.rotationKeyFrames(), body.positionKeyFrames(), body.scaleKeyFrames(), torso.bendKeyFrames()));
/*     */     
/* 118 */     BoneAnimation bendlessTorso = new BoneAnimation(torso.rotationKeyFrames(), torso.positionKeyFrames(), torso.scaleKeyFrames(), Collections.emptyList());
/* 119 */     if (bendlessTorso.hasKeyframes()) { bones.put("torso", bendlessTorso); }
/* 120 */     else { bones.remove("torso"); }
/*     */     
/* 122 */     return bones;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static void write(Animation animation, ByteBuf buf) {
/* 131 */     write(animation, buf, getCurrentVersion());
/*     */   }
/*     */   
/*     */   private static void writePart(ByteBuf buf, String name, BoneAnimation part, int version, boolean easeBefore) {
/* 135 */     if (part == null) {
/* 136 */       int i = 6;
/* 137 */       if (BEND_BONE.test(name)) i += 2; 
/* 138 */       if (version >= 3) i += 3; 
/* 139 */       for (; i > 0; i--) {
/* 140 */         if (version >= 2)
/* 141 */         { putBoolean(buf, false);
/* 142 */           buf.writeInt(0); }
/* 143 */         else { buf.writeInt(-1); }
/*     */       
/*     */       }  return;
/*     */     } 
/* 147 */     Vec3f def = PlayerAnimatorLoader.getDefaultValues(name);
/* 148 */     boolean isItem = ITEM_BONE.test(name);
/* 149 */     boolean isBody = name.equals("body");
/* 150 */     boolean isCape = name.equals("cape");
/* 151 */     writeKeyframes(buf, part.positionKeyFrames().xKeyframes(), def.x(), version, easeBefore, isBody, (isItem || isCape || isBody));
/* 152 */     writeKeyframes(buf, isItem ? part.positionKeyFrames().zKeyframes() : part.positionKeyFrames().yKeyframes(), def.y(), version, easeBefore, isBody, !isBody);
/* 153 */     writeKeyframes(buf, isItem ? part.positionKeyFrames().yKeyframes() : part.positionKeyFrames().zKeyframes(), def.z(), version, easeBefore, isBody, isCape);
/* 154 */     writeKeyframes(buf, part.rotationKeyFrames().xKeyframes(), version, easeBefore, (isItem || isCape || isBody));
/* 155 */     writeKeyframes(buf, isItem ? part.rotationKeyFrames().zKeyframes() : part.rotationKeyFrames().yKeyframes(), version, easeBefore, (isItem || isBody));
/* 156 */     writeKeyframes(buf, isItem ? part.rotationKeyFrames().yKeyframes() : part.rotationKeyFrames().zKeyframes(), version, easeBefore, (isItem || isCape));
/* 157 */     if (BEND_BONE.test(name)) {
/*     */       
/* 159 */       if (version >= 2) {
/* 160 */         putBoolean(buf, false);
/* 161 */         buf.writeInt(0);
/*     */       } else {
/* 163 */         buf.writeInt(-1);
/*     */       } 
/* 165 */       writeKeyframes(buf, part.bendKeyFrames(), version, easeBefore, false);
/*     */     } 
/* 167 */     if (version >= 3) {
/* 168 */       writeKeyframes(buf, part.scaleKeyFrames().xKeyframes(), version, easeBefore, false);
/* 169 */       writeKeyframes(buf, part.scaleKeyFrames().yKeyframes(), version, easeBefore, false);
/* 170 */       writeKeyframes(buf, part.scaleKeyFrames().zKeyframes(), version, easeBefore, false);
/*     */     } 
/*     */   }
/*     */   
/*     */   private static void writeKeyframes(ByteBuf buf, List<Keyframe> part, int version, boolean easeBefore, boolean negate) {
/* 175 */     writeKeyframes(buf, part, 0.0F, version, easeBefore, false, negate);
/*     */   }
/*     */   
/*     */   private static void writeKeyframes(ByteBuf buf, List<Keyframe> part, float def, int version, boolean easeBefore, boolean div, boolean negate) {
/* 179 */     if (version >= 2) {
/* 180 */       putBoolean(buf, !part.isEmpty());
/*     */     }
/*     */     
/* 183 */     int keyframeCount = part.size();
/* 184 */     if (!easeBefore) keyframeCount--; 
/* 185 */     buf.writeInt(keyframeCount);
/* 186 */     if (keyframeCount <= 0)
/*     */       return; 
/* 188 */     float tickAccumulator = 0.0F;
/* 189 */     for (int i = 0; i < keyframeCount; i++) {
/* 190 */       EasingType easingToWrite; Keyframe move = part.get(i);
/*     */       
/* 192 */       tickAccumulator += move.length();
/* 193 */       buf.writeInt((int)Math.floor(tickAccumulator));
/*     */       
/* 195 */       buf.writeFloat((MolangLoader.MOCHA_ENGINE.eval(move.endValue()) * (negate ? -1 : true) + def) / (div ? 16.0F : 1.0F));
/*     */ 
/*     */       
/* 198 */       List<Expression> easingArgsToWrite = Collections.emptyList();
/*     */       
/* 200 */       if (easeBefore) {
/* 201 */         easingToWrite = move.easingType();
/* 202 */         if (move.easingArgs() != null && !move.easingArgs().isEmpty() && !((List)move.easingArgs().getFirst()).isEmpty()) {
/* 203 */           easingArgsToWrite = (List<Expression>)move.easingArgs().getFirst();
/*     */         }
/*     */       } else {
/* 206 */         Keyframe nextMove = part.get(i + 1);
/* 207 */         easingToWrite = nextMove.easingType();
/* 208 */         if (nextMove.easingArgs() != null && !nextMove.easingArgs().isEmpty() && !((List)nextMove.easingArgs().getFirst()).isEmpty()) {
/* 209 */           easingArgsToWrite = (List<Expression>)nextMove.easingArgs().getFirst();
/*     */         }
/*     */       } 
/*     */       
/* 213 */       buf.writeByte(easingToWrite.id);
/*     */       
/* 215 */       if (version >= 4) {
/* 216 */         if (easingArgsToWrite != null && !easingArgsToWrite.isEmpty()) {
/* 217 */           buf.writeFloat(MolangLoader.MOCHA_ENGINE.eval(easingArgsToWrite));
/*     */         } else {
/* 219 */           buf.writeFloat(Float.NaN);
/*     */         } 
/*     */       }
/*     */     } 
/*     */   }
/*     */   
/*     */   public static Animation read(ByteBuf buf) throws IOException {
/* 226 */     return read(buf, getCurrentVersion());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Animation read(ByteBuf buf, int version) throws IOException {
/* 238 */     ExtraAnimationData data = new ExtraAnimationData();
/*     */     
/* 240 */     int beginTick = buf.readInt();
/* 241 */     data.put("beginTick", Float.valueOf(beginTick));
/*     */     
/* 243 */     int endTick = Math.max(buf.readInt(), beginTick + 1);
/* 244 */     if (endTick <= 0) throw new IOException("endTick must be bigger than 0"); 
/* 245 */     data.put("endTick", Float.valueOf(endTick));
/*     */     
/* 247 */     int stopTick = buf.readInt();
/*     */     
/* 249 */     boolean isLooped = getBoolean(buf);
/* 250 */     int returnTick = Math.max(0, buf.readInt() - 1);
/* 251 */     Animation.LoopType loopType = Animation.LoopType.PLAY_ONCE;
/* 252 */     if (isLooped) {
/* 253 */       if (returnTick > endTick) {
/* 254 */         throw new IOException("The returnTick has to be a non-negative value smaller than the endTick value");
/*     */       }
/* 256 */       if (returnTick == 0) { loopType = Animation.LoopType.LOOP; }
/* 257 */       else { loopType = Animation.LoopType.returnToTickLoop(returnTick); }
/*     */     
/* 259 */     }  if (loopType == Animation.LoopType.PLAY_ONCE) {
/* 260 */       endTick = (stopTick <= endTick) ? (endTick + 3) : stopTick;
/*     */     }
/*     */     
/* 263 */     boolean easeBefore = getBoolean(buf);
/* 264 */     data.put("easeBeforeKeyframe", Boolean.valueOf(easeBefore));
/* 265 */     getBoolean(buf);
/* 266 */     int keyframeSize = buf.readByte();
/* 267 */     if (keyframeSize <= 0) throw new IOException("keyframe size must be greater than 0, current: " + keyframeSize); 
/* 268 */     Map<String, BoneAnimation> boneAnimations = new HashMap<>();
/* 269 */     if (version >= 2) {
/* 270 */       int count = buf.readInt();
/* 271 */       for (int i = 0; i < count; i++) {
/* 272 */         String name = UniversalAnimLoader.getCorrectPlayerBoneName(getString(buf));
/* 273 */         boneAnimations.put(name, readPart(buf, name, new BoneAnimation(), version, keyframeSize, easeBefore));
/*     */       } 
/*     */     } else {
/* 276 */       boneAnimations.put("head", readPart(buf, "head", new BoneAnimation(), version, keyframeSize, easeBefore));
/* 277 */       boneAnimations.put("body", readPart(buf, "body", new BoneAnimation(), version, keyframeSize, easeBefore));
/* 278 */       boneAnimations.put("right_arm", readPart(buf, "right_arm", new BoneAnimation(), version, keyframeSize, easeBefore));
/* 279 */       boneAnimations.put("left_arm", readPart(buf, "left_arm", new BoneAnimation(), version, keyframeSize, easeBefore));
/* 280 */       boneAnimations.put("right_leg", readPart(buf, "right_leg", new BoneAnimation(), version, keyframeSize, easeBefore));
/* 281 */       boneAnimations.put("left_leg", readPart(buf, "left_leg", new BoneAnimation(), version, keyframeSize, easeBefore));
/*     */     } 
/*     */     
/* 284 */     boneAnimations.values().removeIf(bone -> !bone.hasKeyframes());
/*     */     
/* 286 */     BoneAnimation body = boneAnimations.get("body");
/* 287 */     if (body != null && !body.bendKeyFrames().isEmpty()) {
/* 288 */       BoneAnimation torso = boneAnimations.computeIfAbsent("torso", name -> new BoneAnimation());
/* 289 */       torso.bendKeyFrames().addAll(body.bendKeyFrames());
/* 290 */       body.bendKeyFrames().clear();
/* 291 */       if (!body.hasKeyframes()) boneAnimations.remove("body"); 
/* 292 */       data.put("applyBendToOtherBones", Boolean.valueOf(true));
/*     */     } 
/* 294 */     data.put("uuid", NetworkUtils.readUuid(buf));
/* 295 */     data.put("format", AnimationFormat.PLAYER_ANIMATOR);
/*     */     
/* 297 */     return new Animation(data, endTick, loopType, boneAnimations, UniversalAnimLoader.NO_KEYFRAMES, new HashMap<>(), new HashMap<>());
/*     */   }
/*     */   
/*     */   private static BoneAnimation readPart(ByteBuf buf, String name, BoneAnimation part, int version, int keyframeSize, boolean easeBefore) {
/* 301 */     Vec3f def = PlayerAnimatorLoader.getDefaultValues(name);
/* 302 */     boolean isBody = name.equals("body");
/* 303 */     boolean isItem = ITEM_BONE.test(name);
/* 304 */     boolean isCape = name.equals("cape");
/* 305 */     readKeyframes(buf, part.positionKeyFrames().xKeyframes(), def.x(), version, keyframeSize, isBody, (isItem || isCape || isBody), easeBefore, PlayerAnimatorLoader.ZERO);
/* 306 */     readKeyframes(buf, part.positionKeyFrames().yKeyframes(), def.y(), version, keyframeSize, isBody, !isBody, easeBefore, PlayerAnimatorLoader.ZERO);
/* 307 */     readKeyframes(buf, part.positionKeyFrames().zKeyframes(), def.z(), version, keyframeSize, isBody, isCape, easeBefore, PlayerAnimatorLoader.ZERO);
/* 308 */     readKeyframes(buf, part.rotationKeyFrames().xKeyframes(), version, keyframeSize, (isItem || isCape || isBody), easeBefore, PlayerAnimatorLoader.ZERO);
/* 309 */     readKeyframes(buf, part.rotationKeyFrames().yKeyframes(), version, keyframeSize, (isItem || isBody), easeBefore, PlayerAnimatorLoader.ZERO);
/* 310 */     readKeyframes(buf, part.rotationKeyFrames().zKeyframes(), version, keyframeSize, (isItem || isCape), easeBefore, PlayerAnimatorLoader.ZERO);
/* 311 */     if (BEND_BONE.test(name)) {
/* 312 */       readKeyframes(buf, new ArrayList<>(), version, keyframeSize, false, easeBefore, PlayerAnimatorLoader.ZERO);
/* 313 */       readKeyframes(buf, part.bendKeyFrames(), version, keyframeSize, false, easeBefore, PlayerAnimatorLoader.ZERO);
/*     */     } 
/* 315 */     if (version >= 3) {
/* 316 */       readKeyframes(buf, part.scaleKeyFrames().xKeyframes(), version, keyframeSize, false, easeBefore, PlayerAnimatorLoader.ONE);
/* 317 */       readKeyframes(buf, part.scaleKeyFrames().yKeyframes(), version, keyframeSize, false, easeBefore, PlayerAnimatorLoader.ONE);
/* 318 */       readKeyframes(buf, part.scaleKeyFrames().zKeyframes(), version, keyframeSize, false, easeBefore, PlayerAnimatorLoader.ONE);
/*     */     } 
/* 320 */     if (!easeBefore) {
/* 321 */       PlayerAnimatorLoader.correctEasings(part.positionKeyFrames());
/* 322 */       PlayerAnimatorLoader.correctEasings(part.rotationKeyFrames());
/* 323 */       PlayerAnimatorLoader.correctEasings(part.scaleKeyFrames());
/* 324 */       PlayerAnimatorLoader.correctEasings(part.bendKeyFrames());
/*     */     } 
/* 326 */     if (isItem) {
/* 327 */       PlayerAnimatorLoader.swapTheZYAxis(part.positionKeyFrames());
/* 328 */       PlayerAnimatorLoader.swapTheZYAxis(part.rotationKeyFrames());
/*     */     } 
/* 330 */     return part;
/*     */   }
/*     */   
/*     */   private static void readKeyframes(ByteBuf buf, List<Keyframe> part, int version, int keyframeSize, boolean negate, boolean easeBefore, List<Expression> fallback) {
/* 334 */     readKeyframes(buf, part, 0.0F, version, keyframeSize, false, negate, easeBefore, fallback);
/*     */   }
/*     */   
/*     */   private static void readKeyframes(ByteBuf buf, List<Keyframe> part, float def, int version, int keyframeSize, boolean mul, boolean negate, boolean easeBefore, List<Expression> fallback) {
/*     */     int length;
/*     */     boolean enabled;
/* 340 */     if (version >= 2) {
/* 341 */       enabled = getBoolean(buf);
/* 342 */       length = buf.readInt();
/*     */     } else {
/* 344 */       length = buf.readInt();
/* 345 */       enabled = (length >= 0);
/*     */     } 
/*     */     
/* 348 */     if (!enabled) {
/* 349 */       if (length > 0) {
/* 350 */         buf.readerIndex(buf.readerIndex() + length * keyframeSize);
/*     */       }
/* 352 */       part.clear();
/*     */       
/*     */       return;
/*     */     } 
/* 356 */     int lastTick = 0;
/* 357 */     for (int i = 0; i < length; i++) {
/* 358 */       Keyframe prevKeyframe = part.isEmpty() ? null : (Keyframe)part.getLast();
/* 359 */       int currentPos = buf.readerIndex();
/*     */       
/* 361 */       int tick = buf.readInt();
/* 362 */       float keyframeLength = tick - lastTick;
/* 363 */       lastTick = tick;
/*     */       
/* 365 */       List<Expression> expression = (List)Collections.singletonList(FloatExpression.of((buf.readFloat() - def) * (mul ? 16 : true) * (negate ? -1 : true)));
/* 366 */       EasingType easingType = EasingType.fromId(buf.readByte());
/* 367 */       Float easingArg = null;
/*     */       
/* 369 */       if (version >= 4) {
/* 370 */         easingArg = Float.valueOf(buf.readFloat());
/*     */         
/* 372 */         if (Float.isNaN(easingArg.floatValue())) {
/* 373 */           easingArg = null;
/*     */         }
/*     */       } 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 381 */       List<Expression> startValue = (prevKeyframe != null) ? prevKeyframe.endValue() : (easeBefore ? expression : fallback);
/* 382 */       part.add(new Keyframe(keyframeLength, startValue, expression, easingType, 
/* 383 */             (easingArg == null) ? Collections.singletonList(Collections.emptyList()) : 
/* 384 */             Collections.singletonList(Collections.singletonList(FloatExpression.of(easingArg.floatValue())))));
/* 385 */       buf.readerIndex(currentPos + keyframeSize);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static int getCurrentVersion() {
/* 394 */     return 4;
/*     */   }
/*     */   
/*     */   public static int calculateSize(Animation animation) {
/* 398 */     return calculateSize(animation, getCurrentVersion());
/*     */   }
/*     */ 
/*     */   
/*     */   public static int calculateSize(Animation animation, int version) {
/* 403 */     int size = 36;
/* 404 */     Map<String, BoneAnimation> boneAnimations = bonesToWrite(animation);
/*     */     
/* 406 */     boolean easeBefore = ((Boolean)animation.data().get("easeBeforeKeyframe").orElse(Boolean.valueOf((animation.data().data().getOrDefault("format", AnimationFormat.GECKOLIB) == AnimationFormat.GECKOLIB)))).booleanValue();
/* 407 */     if (version < 2) {
/* 408 */       size += partSize(boneAnimations.get("head"), false, version, easeBefore);
/* 409 */       size += partSize(boneAnimations.get("body"), true, version, easeBefore);
/* 410 */       size += partSize(boneAnimations.get("right_arm"), true, version, easeBefore);
/* 411 */       size += partSize(boneAnimations.get("left_arm"), true, version, easeBefore);
/* 412 */       size += partSize(boneAnimations.get("right_leg"), true, version, easeBefore);
/* 413 */       size += partSize(boneAnimations.get("left_leg"), true, version, easeBefore);
/*     */     } else {
/* 415 */       size += 4;
/* 416 */       for (Map.Entry<String, BoneAnimation> entry : boneAnimations.entrySet()) {
/* 417 */         size += stringSize(UniversalAnimLoader.restorePlayerBoneName(entry.getKey())) + partSize(entry.getValue(), BEND_BONE.test(entry.getKey()), version, easeBefore);
/*     */       }
/*     */     } 
/*     */ 
/*     */ 
/*     */     
/* 423 */     return size;
/*     */   }
/*     */   
/*     */   private static int stringSize(String str) {
/* 427 */     byte[] bytes = str.getBytes(StandardCharsets.UTF_8);
/* 428 */     return bytes.length + 4;
/*     */   }
/*     */   
/*     */   private static int partSize(BoneAnimation part, boolean bendable, int version, boolean easeBefore) {
/* 432 */     if (part == null) {
/* 433 */       int i = 6;
/* 434 */       if (bendable) i += 2; 
/* 435 */       if (version >= 3) i += 3; 
/* 436 */       return i * ((version >= 2) ? 5 : 4);
/*     */     } 
/* 438 */     int size = 0;
/* 439 */     size += axisSize(part.positionKeyFrames().xKeyframes(), version, easeBefore);
/* 440 */     size += axisSize(part.positionKeyFrames().yKeyframes(), version, easeBefore);
/* 441 */     size += axisSize(part.positionKeyFrames().zKeyframes(), version, easeBefore);
/* 442 */     size += axisSize(part.rotationKeyFrames().xKeyframes(), version, easeBefore);
/* 443 */     size += axisSize(part.rotationKeyFrames().yKeyframes(), version, easeBefore);
/* 444 */     size += axisSize(part.rotationKeyFrames().zKeyframes(), version, easeBefore);
/* 445 */     if (bendable) {
/* 446 */       size += (version >= 2) ? 5 : 4;
/* 447 */       size += axisSize(part.bendKeyFrames(), version, easeBefore);
/*     */     } 
/* 449 */     if (version >= 3) {
/* 450 */       size += axisSize(part.scaleKeyFrames().xKeyframes(), version, easeBefore);
/* 451 */       size += axisSize(part.scaleKeyFrames().yKeyframes(), version, easeBefore);
/* 452 */       size += axisSize(part.scaleKeyFrames().zKeyframes(), version, easeBefore);
/*     */     } 
/* 454 */     return size;
/*     */   }
/*     */   
/*     */   private static int axisSize(List<Keyframe> axis, int version, boolean easeBefore) {
/* 458 */     return Math.max(0, axis.size() - (easeBefore ? 0 : 1)) * keyframeSize(version) + ((version >= 2) ? 5 : 4);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static byte keyframeSize(int version) {
/* 465 */     return (version < 4) ? 9 : 13;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static void putBoolean(ByteBuf byteBuffer, boolean bl) {
/* 474 */     byteBuffer.writeByte((byte)(bl ? 1 : 0));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static boolean getBoolean(ByteBuf buf) {
/* 483 */     return (buf.readByte() != 0);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static void putString(ByteBuf buf, String str) {
/* 493 */     byte[] bytes = str.getBytes(StandardCharsets.UTF_8);
/* 494 */     buf.writeInt(bytes.length);
/* 495 */     buf.writeBytes(bytes);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static String getString(ByteBuf buf) {
/* 504 */     int len = buf.readInt();
/* 505 */     byte[] bytes = new byte[len];
/* 506 */     buf.readBytes(bytes);
/* 507 */     return new String(bytes, StandardCharsets.UTF_8);
/*     */   }
/*     */ }


/* Location:              C:\Users\rapha\Downloads\aurora.jar!\META-INF\jars\player-animation-library-wJLdv4ZQ.jar!\com\zigythebird\playeranimcore\network\LegacyAnimationBinary.class
 * Java compiler version: 21 (65.0)
 * JD-Core Version:       1.1.3
 */