/*     */ package com.zigythebird.playeranimcore.network;
/*     */ 
/*     */ import com.zigythebird.playeranimcore.animation.Animation;
/*     */ import com.zigythebird.playeranimcore.animation.ExtraAnimationData;
/*     */ import com.zigythebird.playeranimcore.animation.keyframe.BoneAnimation;
/*     */ import com.zigythebird.playeranimcore.animation.keyframe.Keyframe;
/*     */ import com.zigythebird.playeranimcore.animation.keyframe.KeyframeStack;
/*     */ import com.zigythebird.playeranimcore.animation.keyframe.event.data.CustomInstructionKeyframeData;
/*     */ import com.zigythebird.playeranimcore.animation.keyframe.event.data.ParticleKeyframeData;
/*     */ import com.zigythebird.playeranimcore.animation.keyframe.event.data.SoundKeyframeData;
/*     */ import com.zigythebird.playeranimcore.easing.EasingType;
/*     */ import com.zigythebird.playeranimcore.enums.AnimationFormat;
/*     */ import com.zigythebird.playeranimcore.enums.TransformType;
/*     */ import com.zigythebird.playeranimcore.loading.PlayerAnimatorLoader;
/*     */ import com.zigythebird.playeranimcore.math.Vec3f;
/*     */ import com.zigythebird.playeranimcore.molang.MolangLoader;
/*     */ import io.netty.buffer.ByteBuf;
/*     */ import java.util.ArrayList;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import team.unnamed.mocha.parser.ast.Expression;
/*     */ import team.unnamed.mocha.parser.ast.FloatExpression;
/*     */ import team.unnamed.mocha.runtime.IsConstantExpression;
/*     */ import team.unnamed.mocha.util.ExprBytesUtils;
/*     */ import team.unnamed.mocha.util.network.ProtocolUtils;
/*     */ import team.unnamed.mocha.util.network.VarIntUtils;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class AnimationBinary
/*     */ {
/*     */   public static final int CURRENT_VERSION = 5;
/*     */   
/*     */   public static void write(ByteBuf buf, Animation animation) {
/*  43 */     write(buf, 5, animation);
/*     */   }
/*     */   
/*     */   public static void write(ByteBuf buf, int version, Animation animation) {
/*  47 */     Map<String, Object> data = animation.data().data();
/*  48 */     boolean applyBendToOtherBones = ((Boolean)data.getOrDefault("applyBendToOtherBones", Boolean.valueOf(false))).booleanValue();
/*  49 */     if (version < 3 && applyBendToOtherBones && animation.boneAnimations().containsKey("torso") && 
/*  50 */       !((BoneAnimation)animation.boneAnimations().get("torso")).bendKeyFrames().isEmpty()) {
/*  51 */       applyBendToOtherBones = false;
/*     */     }
/*  53 */     buf.writeFloat(animation.length());
/*  54 */     boolean shouldPlayAgain = animation.loopType().shouldPlayAgain(null, animation);
/*  55 */     buf.writeBoolean(shouldPlayAgain);
/*  56 */     if (shouldPlayAgain) {
/*  57 */       if (animation.loopType() == Animation.LoopType.HOLD_ON_LAST_FRAME) {
/*  58 */         buf.writeBoolean(true);
/*     */       } else {
/*  60 */         buf.writeBoolean(false);
/*  61 */         buf.writeFloat(animation.loopType().restartFromTick(null, animation));
/*     */       } 
/*     */     }
/*  64 */     buf.writeByte(((AnimationFormat)data.getOrDefault("format", (V)AnimationFormat.GECKOLIB)).id);
/*  65 */     buf.writeFloat(((Float)data.getOrDefault("beginTick", Float.valueOf(Float.NaN))).floatValue());
/*  66 */     buf.writeFloat(((Float)data.getOrDefault("endTick", Float.valueOf(Float.NaN))).floatValue());
/*  67 */     if (version > 1) {
/*  68 */       buf.writeBoolean(applyBendToOtherBones);
/*  69 */       buf.writeBoolean(((Boolean)data.getOrDefault("easeBeforeKeyframe", Boolean.valueOf(true))).booleanValue());
/*     */     } 
/*  71 */     NetworkUtils.writeUuid(buf, animation.uuid());
/*  72 */     VarIntUtils.writeVarInt(buf, animation.boneAnimations().size());
/*  73 */     for (Map.Entry<String, BoneAnimation> entry : (Iterable<Map.Entry<String, BoneAnimation>>)animation.boneAnimations().entrySet()) {
/*  74 */       ProtocolUtils.writeString(buf, entry.getKey());
/*  75 */       writeBoneAnimation(buf, entry.getValue(), (version < 4 && ((String)entry.getKey()).equals("body")), (version < 5 && LegacyAnimationBinary.ITEM_BONE.test(entry.getKey())));
/*     */     } 
/*     */ 
/*     */     
/*  79 */     VarIntUtils.writeVarInt(buf, (animation.keyFrames().sounds()).length);
/*  80 */     for (SoundKeyframeData soundKeyframe : animation.keyFrames().sounds()) {
/*  81 */       buf.writeFloat(soundKeyframe.getStartTick());
/*  82 */       ProtocolUtils.writeString(buf, soundKeyframe.getSound());
/*     */     } 
/*     */ 
/*     */     
/*  86 */     VarIntUtils.writeVarInt(buf, (animation.keyFrames().particles()).length);
/*  87 */     for (ParticleKeyframeData particleKeyframe : animation.keyFrames().particles()) {
/*  88 */       buf.writeFloat(particleKeyframe.getStartTick());
/*  89 */       ProtocolUtils.writeString(buf, particleKeyframe.getEffect());
/*  90 */       ProtocolUtils.writeString(buf, particleKeyframe.getLocator());
/*  91 */       ProtocolUtils.writeString(buf, particleKeyframe.script());
/*     */     } 
/*     */ 
/*     */     
/*  95 */     VarIntUtils.writeVarInt(buf, (animation.keyFrames().customInstructions()).length);
/*  96 */     for (CustomInstructionKeyframeData instructionKeyframe : animation.keyFrames().customInstructions()) {
/*  97 */       buf.writeFloat(instructionKeyframe.getStartTick());
/*  98 */       ProtocolUtils.writeString(buf, instructionKeyframe.getInstructions());
/*     */     } 
/*     */     
/* 101 */     NetworkUtils.writeMap(buf, animation.bones(), ProtocolUtils::writeString, NetworkUtils::writeVec3f);
/* 102 */     NetworkUtils.writeMap(buf, animation.parents(), ProtocolUtils::writeString, ProtocolUtils::writeString);
/*     */   }
/*     */   
/*     */   public static void writeBoneAnimation(ByteBuf buf, BoneAnimation bone, boolean isBody, boolean isItem) {
/* 106 */     writeKeyframeStack(buf, bone.rotationKeyFrames(), isBody, false, TransformType.ROTATION);
/* 107 */     writeKeyframeStack(buf, bone.positionKeyFrames(), isBody, isItem, TransformType.POSITION);
/* 108 */     writeKeyframeStack(buf, bone.scaleKeyFrames(), false, false, TransformType.SCALE);
/* 109 */     ProtocolUtils.writeList(buf, bone.bendKeyFrames(), AnimationBinary::writeKeyframe);
/*     */   }
/*     */   
/*     */   public static void writeKeyframeStack(ByteBuf buf, KeyframeStack stack, boolean isBody, boolean isItem, TransformType type) {
/* 113 */     ProtocolUtils.writeList(buf, isBody ? negateKeyframes(stack.xKeyframes()) : stack.xKeyframes(), AnimationBinary::writeKeyframe);
/* 114 */     ProtocolUtils.writeList(buf, (isItem || (isBody && type == TransformType.ROTATION)) ? negateKeyframes(stack.yKeyframes()) : stack.yKeyframes(), AnimationBinary::writeKeyframe);
/* 115 */     ProtocolUtils.writeList(buf, stack.zKeyframes(), AnimationBinary::writeKeyframe);
/*     */   }
/*     */   
/*     */   public static void writeKeyframe(Keyframe keyframe, ByteBuf buf) {
/* 119 */     buf.writeFloat(keyframe.length());
/* 120 */     ExprBytesUtils.writeExpressions(keyframe.endValue(), buf);
/* 121 */     buf.writeByte((keyframe.easingType()).id);
/* 122 */     ProtocolUtils.writeList(buf, keyframe.easingArgs(), ExprBytesUtils::writeExpressions);
/*     */   }
/*     */   
/*     */   public static Animation read(ByteBuf buf) {
/* 126 */     return read(buf, 5);
/*     */   }
/*     */   
/*     */   public static Animation read(ByteBuf buf, int version) {
/* 130 */     float length = buf.readFloat();
/* 131 */     Animation.LoopType loopType = Animation.LoopType.PLAY_ONCE;
/* 132 */     if (buf.readBoolean())
/* 133 */       if (buf.readBoolean()) { loopType = Animation.LoopType.HOLD_ON_LAST_FRAME; }
/* 134 */       else { loopType = Animation.LoopType.returnToTickLoop(buf.readFloat()); }
/*     */        
/* 136 */     ExtraAnimationData data = new ExtraAnimationData();
/* 137 */     AnimationFormat format = AnimationFormat.fromId(buf.readByte());
/* 138 */     data.put("format", format);
/* 139 */     float beginTick = buf.readFloat();
/* 140 */     float endTick = buf.readFloat();
/* 141 */     if (!Float.isNaN(beginTick))
/* 142 */       data.put("beginTick", Float.valueOf(beginTick)); 
/* 143 */     if (!Float.isNaN(endTick))
/* 144 */       data.put("endTick", Float.valueOf(endTick)); 
/* 145 */     if (version > 1)
/* 146 */     { boolean applyBendToOtherBones = buf.readBoolean();
/* 147 */       boolean easeBefore = buf.readBoolean();
/* 148 */       if (applyBendToOtherBones)
/* 149 */         data.put("applyBendToOtherBones", Boolean.valueOf(true)); 
/* 150 */       if (!easeBefore)
/* 151 */         data.put("easeBeforeKeyframe", Boolean.valueOf(false));  }
/* 152 */     else { data.put("applyBendToOtherBones", Boolean.valueOf(true)); }
/*     */     
/* 154 */     data.put("uuid", NetworkUtils.readUuid(buf));
/* 155 */     Map<String, BoneAnimation> boneAnimations = NetworkUtils.readMap(buf, ProtocolUtils::readString, buf1 -> readBoneAnimation(buf1, (format == AnimationFormat.PLAYER_ANIMATOR)));
/*     */     
/* 157 */     if (version < 4 && boneAnimations.containsKey("body")) {
/* 158 */       BoneAnimation body = boneAnimations.get("body");
/* 159 */       body.positionKeyFrames().xKeyframes().replaceAll(AnimationBinary::negateKeyframeExpressions);
/* 160 */       body.rotationKeyFrames().xKeyframes().replaceAll(AnimationBinary::negateKeyframeExpressions);
/* 161 */       body.rotationKeyFrames().yKeyframes().replaceAll(AnimationBinary::negateKeyframeExpressions);
/*     */     } 
/*     */     
/* 164 */     if (version < 5) {
/* 165 */       if (boneAnimations.containsKey("right_item"))
/* 166 */         ((BoneAnimation)boneAnimations.get("right_item")).positionKeyFrames().yKeyframes().replaceAll(AnimationBinary::negateKeyframeExpressions); 
/* 167 */       if (boneAnimations.containsKey("left_item")) {
/* 168 */         ((BoneAnimation)boneAnimations.get("left_item")).positionKeyFrames().yKeyframes().replaceAll(AnimationBinary::negateKeyframeExpressions);
/*     */       }
/*     */     } 
/*     */     
/* 172 */     int soundCount = VarIntUtils.readVarInt(buf);
/* 173 */     SoundKeyframeData[] sounds = new SoundKeyframeData[soundCount];
/* 174 */     for (int i = 0; i < soundCount; i++) {
/* 175 */       float startTick = buf.readFloat();
/* 176 */       String sound = ProtocolUtils.readString(buf);
/* 177 */       sounds[i] = new SoundKeyframeData(Float.valueOf(startTick), sound);
/*     */     } 
/*     */ 
/*     */     
/* 181 */     int particleCount = VarIntUtils.readVarInt(buf);
/* 182 */     ParticleKeyframeData[] particles = new ParticleKeyframeData[particleCount];
/* 183 */     for (int j = 0; j < particleCount; j++) {
/* 184 */       float startTick = buf.readFloat();
/* 185 */       String effect = ProtocolUtils.readString(buf);
/* 186 */       String locator = ProtocolUtils.readString(buf);
/* 187 */       String script = ProtocolUtils.readString(buf);
/* 188 */       particles[j] = new ParticleKeyframeData(startTick, effect, locator, script);
/*     */     } 
/*     */ 
/*     */     
/* 192 */     int customInstructionCount = VarIntUtils.readVarInt(buf);
/* 193 */     CustomInstructionKeyframeData[] customInstructions = new CustomInstructionKeyframeData[customInstructionCount];
/* 194 */     for (int k = 0; k < customInstructionCount; k++) {
/* 195 */       float startTick = buf.readFloat();
/* 196 */       String instructions = ProtocolUtils.readString(buf);
/* 197 */       customInstructions[k] = new CustomInstructionKeyframeData(startTick, instructions);
/*     */     } 
/* 199 */     Animation.Keyframes keyFrames = new Animation.Keyframes(sounds, particles, customInstructions);
/*     */     
/* 201 */     Map<String, Vec3f> pivotBones = NetworkUtils.readMap(buf, ProtocolUtils::readString, NetworkUtils::readVec3f);
/* 202 */     Map<String, String> parents = NetworkUtils.readMap(buf, ProtocolUtils::readString, ProtocolUtils::readString);
/*     */     
/* 204 */     return new Animation(data, length, loopType, boneAnimations, keyFrames, pivotBones, parents);
/*     */   }
/*     */   
/*     */   public static BoneAnimation readBoneAnimation(ByteBuf buf, boolean shouldStartFromDefault) {
/* 208 */     KeyframeStack rotationKeyFrames = readKeyframeStack(buf, shouldStartFromDefault, false);
/* 209 */     KeyframeStack positionKeyFrames = readKeyframeStack(buf, shouldStartFromDefault, false);
/* 210 */     KeyframeStack scaleKeyFrames = readKeyframeStack(buf, shouldStartFromDefault, true);
/* 211 */     List<Keyframe> bendKeyFrames = readKeyframeList(buf, shouldStartFromDefault, false);
/*     */     
/* 213 */     return new BoneAnimation(rotationKeyFrames, positionKeyFrames, scaleKeyFrames, bendKeyFrames);
/*     */   }
/*     */   
/*     */   public static KeyframeStack readKeyframeStack(ByteBuf buf, boolean shouldStartFromDefault, boolean isScale) {
/* 217 */     List<Keyframe> xKeyframes = readKeyframeList(buf, shouldStartFromDefault, isScale);
/* 218 */     List<Keyframe> yKeyframes = readKeyframeList(buf, shouldStartFromDefault, isScale);
/* 219 */     List<Keyframe> zKeyframes = readKeyframeList(buf, shouldStartFromDefault, isScale);
/*     */     
/* 221 */     return new KeyframeStack(xKeyframes, yKeyframes, zKeyframes);
/*     */   }
/*     */   
/*     */   public static List<Keyframe> readKeyframeList(ByteBuf buf, boolean shouldStartFromDefault, boolean isScale) {
/* 225 */     int count = VarIntUtils.readVarInt(buf);
/* 226 */     List<Keyframe> list = new ArrayList<>(count);
/*     */     
/* 228 */     for (int i = 0; i < count; i++) {
/* 229 */       float length = buf.readFloat();
/*     */       
/* 231 */       List<Expression> endValue = ExprBytesUtils.readExpressions(buf);
/* 232 */       List<Expression> startValue = list.isEmpty() ? (shouldStartFromDefault ? (isScale ? PlayerAnimatorLoader.ONE : PlayerAnimatorLoader.ZERO) : endValue) : ((Keyframe)list.getLast()).endValue();
/* 233 */       EasingType easingType = EasingType.fromId(buf.readByte());
/* 234 */       List<List<Expression>> easingArgs = ProtocolUtils.readList(buf, ExprBytesUtils::readExpressions);
/*     */       
/* 236 */       list.add(new Keyframe(length, startValue, endValue, easingType, easingArgs));
/*     */     } 
/*     */     
/* 239 */     return list;
/*     */   }
/*     */   
/*     */   private static List<Keyframe> negateKeyframes(List<Keyframe> keyframes) {
/* 243 */     keyframes = new ArrayList<>(keyframes);
/* 244 */     keyframes.replaceAll(AnimationBinary::negateKeyframeExpressions);
/* 245 */     return keyframes;
/*     */   }
/*     */   
/*     */   private static Keyframe negateKeyframeExpressions(Keyframe keyframe) {
/* 249 */     keyframe = new Keyframe(keyframe.length(), new ArrayList(keyframe.startValue()), new ArrayList(keyframe.endValue()), keyframe.easingType(), keyframe.easingArgs());
/* 250 */     negateKeyframeExpressions(keyframe.startValue());
/* 251 */     negateKeyframeExpressions(keyframe.endValue());
/* 252 */     return keyframe;
/*     */   }
/*     */   
/*     */   private static void negateKeyframeExpressions(List<Expression> expressions) {
/* 256 */     if (expressions.size() == 1 && IsConstantExpression.test((Expression)expressions.getFirst()))
/* 257 */       expressions.set(0, FloatExpression.of(-MolangLoader.MOCHA_ENGINE.eval(expressions))); 
/*     */   }
/*     */ }


/* Location:              C:\Users\rapha\Downloads\aurora.jar!\META-INF\jars\player-animation-library-wJLdv4ZQ.jar!\com\zigythebird\playeranimcore\network\AnimationBinary.class
 * Java compiler version: 21 (65.0)
 * JD-Core Version:       1.1.3
 */