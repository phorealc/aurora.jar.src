/*    */ package com.zigythebird.playeranimcore.network;
/*    */ 
/*    */ import com.zigythebird.playeranimcore.math.Vec3f;
/*    */ import io.netty.buffer.ByteBuf;
/*    */ import java.util.HashMap;
/*    */ import java.util.Map;
/*    */ import java.util.UUID;
/*    */ import java.util.function.BiConsumer;
/*    */ import java.util.function.Function;
/*    */ import team.unnamed.mocha.util.network.VarIntUtils;
/*    */ 
/*    */ public class NetworkUtils
/*    */ {
/*    */   public static <K, V> Map<K, V> readMap(ByteBuf buf, Function<ByteBuf, K> keyReader, Function<ByteBuf, V> valueReader) {
/* 15 */     int count = VarIntUtils.readVarInt(buf);
/* 16 */     Map<K, V> map = new HashMap<>(count);
/* 17 */     for (int i = 0; i < count; i++) {
/* 18 */       K key = keyReader.apply(buf);
/* 19 */       V value = valueReader.apply(buf);
/* 20 */       map.put(key, value);
/*    */     } 
/* 22 */     return map;
/*    */   }
/*    */   
/*    */   public static <K, V> void writeMap(ByteBuf buf, Map<K, V> map, BiConsumer<ByteBuf, K> keyWriter, BiConsumer<ByteBuf, V> valueWriter) {
/* 26 */     VarIntUtils.writeVarInt(buf, map.size());
/* 27 */     for (Map.Entry<K, V> entry : map.entrySet()) {
/* 28 */       keyWriter.accept(buf, entry.getKey());
/* 29 */       valueWriter.accept(buf, entry.getValue());
/*    */     } 
/*    */   }
/*    */   
/*    */   public static Vec3f readVec3f(ByteBuf buf) {
/* 34 */     float x = buf.readFloat();
/* 35 */     float y = buf.readFloat();
/* 36 */     float z = buf.readFloat();
/* 37 */     return new Vec3f(x, y, z);
/*    */   }
/*    */   
/*    */   public static void writeVec3f(ByteBuf buf, Vec3f vec3f) {
/* 41 */     buf.writeFloat(vec3f.x());
/* 42 */     buf.writeFloat(vec3f.y());
/* 43 */     buf.writeFloat(vec3f.z());
/*    */   }
/*    */   
/*    */   public static UUID readUuid(ByteBuf buf) {
/* 47 */     long msb = buf.readLong();
/* 48 */     long lsb = buf.readLong();
/* 49 */     return new UUID(msb, lsb);
/*    */   }
/*    */   
/*    */   public static void writeUuid(ByteBuf buf, UUID uuid) {
/* 53 */     buf.writeLong(uuid.getMostSignificantBits());
/* 54 */     buf.writeLong(uuid.getLeastSignificantBits());
/*    */   }
/*    */ }


/* Location:              C:\Users\rapha\Downloads\aurora.jar!\META-INF\jars\player-animation-library-wJLdv4ZQ.jar!\com\zigythebird\playeranimcore\network\NetworkUtils.class
 * Java compiler version: 21 (65.0)
 * JD-Core Version:       1.1.3
 */