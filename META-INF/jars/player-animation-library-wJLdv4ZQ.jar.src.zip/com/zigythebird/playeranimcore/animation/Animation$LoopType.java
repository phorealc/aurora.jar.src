/*     */ package com.zigythebird.playeranimcore.animation;
/*     */ 
/*     */ import com.google.gson.JsonElement;
/*     */ import com.google.gson.JsonPrimitive;
/*     */ import java.util.Map;
/*     */ import java.util.concurrent.ConcurrentHashMap;
/*     */ import org.jetbrains.annotations.Nullable;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ @FunctionalInterface
/*     */ public interface LoopType
/*     */ {
/*  81 */   public static final Map<String, LoopType> LOOP_TYPES = new ConcurrentHashMap<>(4);
/*     */   
/*  83 */   public static final LoopType DEFAULT = new LoopType()
/*     */     {
/*     */       public boolean shouldPlayAgain(@Nullable AnimationController controller, Animation currentAnimation) {
/*  86 */         return currentAnimation.loopType().shouldPlayAgain(controller, currentAnimation);
/*     */       }
/*     */ 
/*     */       
/*     */       public float restartFromTick(@Nullable AnimationController controller, Animation currentAnimation) {
/*  91 */         return currentAnimation.loopType().restartFromTick(controller, currentAnimation);
/*     */       }
/*     */     };
/*  94 */   public static final LoopType HOLD_ON_LAST_FRAME; public static final LoopType PLAY_ONCE = register("play_once", register("false", (controller, currentAnimation) -> false)); static {
/*  95 */     HOLD_ON_LAST_FRAME = register("hold_on_last_frame", (controller, currentAnimation) -> {
/*     */           if (controller != null)
/*     */             controller.pause(); 
/*     */           return true;
/*  99 */         }); } public static final LoopType LOOP = register("loop", register("true", (controller, currentAnimation) -> true));
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   default float restartFromTick(@Nullable AnimationController controller, Animation currentAnimation) {
/* 118 */     return 0.0F;
/*     */   }
/*     */   
/*     */   static LoopType returnToTickLoop(final float tick) {
/* 122 */     return new LoopType()
/*     */       {
/*     */         public boolean shouldPlayAgain(@Nullable AnimationController controller, Animation currentAnimation) {
/* 125 */           return true;
/*     */         }
/*     */ 
/*     */         
/*     */         public float restartFromTick(@Nullable AnimationController controller, Animation currentAnimation) {
/* 130 */           return tick;
/*     */         }
/*     */       };
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static LoopType fromJson(JsonElement json) {
/* 145 */     if (json == null || !json.isJsonPrimitive()) {
/* 146 */       return PLAY_ONCE;
/*     */     }
/* 148 */     JsonPrimitive primitive = json.getAsJsonPrimitive();
/*     */     
/* 150 */     if (primitive.isBoolean()) {
/* 151 */       return primitive.getAsBoolean() ? LOOP : PLAY_ONCE;
/*     */     }
/* 153 */     if (primitive.isString()) {
/* 154 */       return fromString(primitive.getAsString());
/*     */     }
/* 156 */     return PLAY_ONCE;
/*     */   }
/*     */   
/*     */   static LoopType fromString(String name) {
/* 160 */     return LOOP_TYPES.getOrDefault(name, PLAY_ONCE);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static LoopType register(String name, LoopType loopType) {
/* 174 */     LOOP_TYPES.put(name, loopType);
/*     */     
/* 176 */     return loopType;
/*     */   }
/*     */   
/*     */   boolean shouldPlayAgain(@Nullable AnimationController paramAnimationController, Animation paramAnimation);
/*     */ }


/* Location:              C:\Users\rapha\Downloads\aurora.jar!\META-INF\jars\player-animation-library-wJLdv4ZQ.jar!\com\zigythebird\playeranimcore\animation\Animation$LoopType.class
 * Java compiler version: 21 (65.0)
 * JD-Core Version:       1.1.3
 */