/*      */ package com.zigythebird.playeranimcore.animation;
/*      */ 
/*      */ import com.zigythebird.playeranimcore.PlayerAnimLib;
/*      */ import com.zigythebird.playeranimcore.animation.keyframe.AnimationPoint;
/*      */ import com.zigythebird.playeranimcore.animation.keyframe.BoneAnimation;
/*      */ import com.zigythebird.playeranimcore.animation.keyframe.Keyframe;
/*      */ import com.zigythebird.playeranimcore.animation.keyframe.KeyframeLocation;
/*      */ import com.zigythebird.playeranimcore.animation.keyframe.KeyframeStack;
/*      */ import com.zigythebird.playeranimcore.animation.keyframe.event.CustomKeyFrameEvents;
/*      */ import com.zigythebird.playeranimcore.animation.keyframe.event.data.CustomInstructionKeyframeData;
/*      */ import com.zigythebird.playeranimcore.animation.keyframe.event.data.KeyFrameData;
/*      */ import com.zigythebird.playeranimcore.animation.keyframe.event.data.ParticleKeyframeData;
/*      */ import com.zigythebird.playeranimcore.animation.keyframe.event.data.SoundKeyframeData;
/*      */ import com.zigythebird.playeranimcore.animation.layered.AnimationContainer;
/*      */ import com.zigythebird.playeranimcore.animation.layered.AnimationSnapshot;
/*      */ import com.zigythebird.playeranimcore.animation.layered.IAnimation;
/*      */ import com.zigythebird.playeranimcore.animation.layered.modifier.AbstractFadeModifier;
/*      */ import com.zigythebird.playeranimcore.animation.layered.modifier.AbstractModifier;
/*      */ import com.zigythebird.playeranimcore.animation.layered.modifier.SpeedModifier;
/*      */ import com.zigythebird.playeranimcore.api.firstPerson.FirstPersonConfiguration;
/*      */ import com.zigythebird.playeranimcore.api.firstPerson.FirstPersonMode;
/*      */ import com.zigythebird.playeranimcore.bones.AdvancedBoneSnapshot;
/*      */ import com.zigythebird.playeranimcore.bones.AdvancedPlayerAnimBone;
/*      */ import com.zigythebird.playeranimcore.bones.PivotBone;
/*      */ import com.zigythebird.playeranimcore.bones.PlayerAnimBone;
/*      */ import com.zigythebird.playeranimcore.easing.EasingType;
/*      */ import com.zigythebird.playeranimcore.enums.AnimationStage;
/*      */ import com.zigythebird.playeranimcore.enums.PlayState;
/*      */ import com.zigythebird.playeranimcore.enums.State;
/*      */ import com.zigythebird.playeranimcore.enums.TransformType;
/*      */ import com.zigythebird.playeranimcore.event.EventResult;
/*      */ import com.zigythebird.playeranimcore.math.Vec3f;
/*      */ import com.zigythebird.playeranimcore.molang.MolangLoader;
/*      */ import com.zigythebird.playeranimcore.util.MatrixUtil;
/*      */ import it.unimi.dsi.fastutil.objects.Object2ObjectOpenHashMap;
/*      */ import it.unimi.dsi.fastutil.objects.ObjectOpenHashSet;
/*      */ import java.util.ArrayList;
/*      */ import java.util.Collections;
/*      */ import java.util.HashMap;
/*      */ import java.util.HashSet;
/*      */ import java.util.Iterator;
/*      */ import java.util.LinkedList;
/*      */ import java.util.List;
/*      */ import java.util.Map;
/*      */ import java.util.Objects;
/*      */ import java.util.Queue;
/*      */ import java.util.Set;
/*      */ import java.util.function.Consumer;
/*      */ import java.util.function.Function;
/*      */ import java.util.function.Predicate;
/*      */ import org.jetbrains.annotations.ApiStatus.Internal;
/*      */ import org.jetbrains.annotations.NotNull;
/*      */ import org.jetbrains.annotations.Nullable;
/*      */ import team.unnamed.mocha.MochaEngine;
/*      */ import team.unnamed.mocha.parser.ast.FloatExpression;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ public abstract class AnimationController
/*      */   implements IAnimation
/*      */ {
/*   72 */   public static KeyframeLocation<Keyframe> EMPTY_KEYFRAME_LOCATION = new KeyframeLocation(new Keyframe(0.0F), 0.0F);
/*   73 */   public static KeyframeLocation<Keyframe> EMPTY_SCALE_KEYFRAME_LOCATION = new KeyframeLocation(new Keyframe(0.0F, Collections.singletonList(FloatExpression.ONE), Collections.singletonList(FloatExpression.ONE)), 0.0F);
/*      */   
/*      */   protected final AnimationStateHandler stateHandler;
/*      */   protected final Map<String, Vec3f> bonePositions;
/*   77 */   protected final Map<String, AdvancedPlayerAnimBone> bones = (Map<String, AdvancedPlayerAnimBone>)new Object2ObjectOpenHashMap();
/*   78 */   protected final Map<String, PlayerAnimBone> activeBones = (Map<String, PlayerAnimBone>)new Object2ObjectOpenHashMap();
/*   79 */   protected final Map<String, PivotBone> pivotBones = (Map<String, PivotBone>)new Object2ObjectOpenHashMap();
/*   80 */   protected Queue<QueuedAnimation> animationQueue = new LinkedList<>();
/*      */   
/*      */   protected final MochaEngine<AnimationController> molangRuntime;
/*      */   
/*      */   protected boolean needsAnimationReload = false;
/*   85 */   protected CustomKeyFrameEvents.CustomKeyFrameHandler<SoundKeyframeData> soundKeyframeHandler = null;
/*   86 */   protected CustomKeyFrameEvents.CustomKeyFrameHandler<ParticleKeyframeData> particleKeyframeHandler = null;
/*   87 */   protected CustomKeyFrameEvents.CustomKeyFrameHandler<CustomInstructionKeyframeData> customKeyframeHandler = null;
/*      */   
/*   89 */   protected RawAnimation triggeredAnimation = null;
/*      */   
/*      */   protected boolean handlingTriggeredAnimations = false;
/*      */   protected RawAnimation currentRawAnimation;
/*      */   protected QueuedAnimation currentAnimation;
/*      */   protected int tick;
/*      */   protected float startAnimFrom;
/*   96 */   protected State animationState = State.STOPPED; protected boolean isLoopStarted = false; protected Consumer<Function<String, AdvancedPlayerAnimBone>> postAnimationSetupConsumer = function -> {
/*      */     
/*      */     };
/*      */   protected Function<AnimationController, EasingType> overrideEasingTypeFunction = controller -> null;
/*  100 */   private final Set<KeyFrameData> executedKeyFrames = (Set<KeyFrameData>)new ObjectOpenHashSet();
/*      */   
/*      */   protected AnimationData animationData;
/*  103 */   protected Function<AnimationController, FirstPersonMode> firstPersonMode = null;
/*  104 */   protected Function<AnimationController, FirstPersonConfiguration> firstPersonConfiguration = null;
/*      */   private boolean firstPersonFollowsCamera = false;
/*  106 */   private int firstPersonTransitionLength = 0;
/*  107 */   private final List<AbstractModifier> modifiers = new ArrayList<>();
/*      */   
/*  109 */   private final InternalAnimationAccessor internalAnimationAccessor = new InternalAnimationAccessor(this);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public AnimationController(AnimationStateHandler animationHandler, Map<String, Vec3f> bonePositions, Function<AnimationController, MochaEngine<AnimationController>> molangRuntime) {
/*  119 */     this.stateHandler = animationHandler;
/*  120 */     this.bonePositions = bonePositions;
/*  121 */     this.molangRuntime = molangRuntime.apply(this);
/*      */     
/*  123 */     registerBones();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setFirstPersonFollowsCamera(boolean followsCamera) {
/*  132 */     this.firstPersonFollowsCamera = followsCamera;
/*      */   }
/*      */ 
/*      */   
/*      */   public boolean isFirstPersonFollowsCamera() {
/*  137 */     return this.firstPersonFollowsCamera;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setFirstPersonTransitionLength(int ticks) {
/*  144 */     this.firstPersonTransitionLength = Math.max(0, ticks);
/*      */   }
/*      */ 
/*      */   
/*      */   public int getFirstPersonTransitionLength() {
/*  149 */     return this.firstPersonTransitionLength;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public AnimationController setSoundKeyframeHandler(CustomKeyFrameEvents.CustomKeyFrameHandler<SoundKeyframeData> soundHandler) {
/*  156 */     this.soundKeyframeHandler = soundHandler;
/*      */     
/*  158 */     return this;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public AnimationController setParticleKeyframeHandler(CustomKeyFrameEvents.CustomKeyFrameHandler<ParticleKeyframeData> particleHandler) {
/*  165 */     this.particleKeyframeHandler = particleHandler;
/*      */     
/*  167 */     return this;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public AnimationController setCustomInstructionKeyframeHandler(CustomKeyFrameEvents.CustomKeyFrameHandler<CustomInstructionKeyframeData> customInstructionHandler) {
/*  174 */     this.customKeyframeHandler = customInstructionHandler;
/*      */     
/*  176 */     return this;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public AnimationController setPostAnimationSetupConsumer(Consumer<Function<String, AdvancedPlayerAnimBone>> postAnimationSetupConsumer) {
/*  184 */     this.postAnimationSetupConsumer = postAnimationSetupConsumer;
/*      */     
/*  186 */     return this;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public AnimationController setOverrideEasingType(EasingType easingTypeFunction) {
/*  195 */     return setOverrideEasingTypeFunction(animatable -> easingTypeFunction);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public AnimationController setOverrideEasingTypeFunction(Function<AnimationController, EasingType> easingType) {
/*  204 */     this.overrideEasingTypeFunction = easingType;
/*      */     
/*  206 */     return this;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public AnimationController receiveTriggeredAnimations() {
/*  217 */     this.handlingTriggeredAnimations = true;
/*      */     
/*  219 */     return this;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @Nullable
/*      */   public QueuedAnimation getCurrentAnimation() {
/*  229 */     return this.currentAnimation;
/*      */   }
/*      */   
/*      */   @Nullable
/*      */   public Animation getCurrentAnimationInstance() {
/*  234 */     QueuedAnimation queuedAnimation = getCurrentAnimation();
/*  235 */     if (queuedAnimation != null) {
/*  236 */       Animation animation = queuedAnimation.animation();
/*  237 */       if (animation != null) {
/*  238 */         return animation;
/*      */       }
/*      */     } 
/*      */     
/*  242 */     RawAnimation rawAnimation = getTriggeredAnimation();
/*  243 */     if (rawAnimation != null) {
/*  244 */       List<RawAnimation.Stage> stages = rawAnimation.getAnimationStages();
/*  245 */       if (!stages.isEmpty()) {
/*  246 */         return ((RawAnimation.Stage)stages.getFirst()).animation();
/*      */       }
/*      */     } 
/*      */     
/*  250 */     return null;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @Nullable
/*      */   public RawAnimation getTriggeredAnimation() {
/*  258 */     return this.triggeredAnimation;
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   @NotNull
/*      */   public State getAnimationState() {
/*  265 */     return this.animationState;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean isLoopStarted() {
/*  272 */     return this.isLoopStarted;
/*      */   }
/*      */ 
/*      */   
/*      */   public boolean isActive() {
/*  277 */     return this.animationState.isActive();
/*      */   }
/*      */   
/*      */   public AnimationData getAnimationData() {
/*  281 */     return this.animationData;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void forceAnimationReset() {
/*  290 */     this.needsAnimationReload = true;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void stop() {
/*  300 */     this.animationState = State.STOPPED;
/*  301 */     resetEventKeyFrames();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void pause() {
/*  308 */     this.animationState = State.PAUSED;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void unpause() {
/*  315 */     if (this.animationState == State.PAUSED) {
/*  316 */       this.animationState = State.RUNNING;
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean hasAnimationFinished() {
/*  328 */     return (this.currentRawAnimation != null && this.animationState == State.STOPPED);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public RawAnimation getCurrentRawAnimation() {
/*  337 */     return this.currentRawAnimation;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean isPlayingTriggeredAnimation() {
/*  344 */     return (this.triggeredAnimation != null && !hasAnimationFinished());
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected void setAnimation(RawAnimation rawAnimation, float startAnimFrom) {
/*  360 */     if (rawAnimation == null || rawAnimation.getAnimationStages().isEmpty()) {
/*  361 */       stop();
/*      */       
/*      */       return;
/*      */     } 
/*      */     
/*  366 */     if (this.needsAnimationReload || !rawAnimation.equals(this.currentRawAnimation)) {
/*  367 */       Queue<QueuedAnimation> animations = getQueuedAnimations(rawAnimation);
/*      */       
/*  369 */       if (animations != null) {
/*  370 */         this.animationQueue = animations;
/*  371 */         this.currentRawAnimation = rawAnimation;
/*  372 */         this.startAnimFrom = startAnimFrom;
/*  373 */         this.tick = 0;
/*  374 */         this.animationState = State.RUNNING;
/*  375 */         this.currentAnimation = this.animationQueue.poll();
/*  376 */         setupNewAnimation();
/*  377 */         this.needsAnimationReload = false;
/*      */         
/*      */         return;
/*      */       } 
/*      */       
/*  382 */       stop();
/*      */     } 
/*      */   }
/*      */   
/*      */   protected void setAnimation(RawAnimation rawAnimation) {
/*  387 */     setAnimation(rawAnimation, 0.0F);
/*      */   }
/*      */   
/*      */   protected Queue<QueuedAnimation> getQueuedAnimations(RawAnimation rawAnimation) {
/*  391 */     LinkedList<QueuedAnimation> animations = new LinkedList<>();
/*  392 */     for (RawAnimation.Stage stage : rawAnimation.getAnimationStages()) {
/*      */       Animation animation;
/*  394 */       if (stage.stage() == AnimationStage.WAIT) {
/*  395 */         animation = Animation.generateWaitAnimation(stage.additionalTicks());
/*      */       } else {
/*  397 */         animation = stage.animation();
/*      */       } 
/*      */       
/*  400 */       if (animation != null) animations.add(new QueuedAnimation(animation, stage.loopType())); 
/*      */     } 
/*  402 */     return animations;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void triggerAnimation(RawAnimation newAnimation, float startAnimFrom) {
/*  411 */     if (newAnimation == null) {
/*      */       return;
/*      */     }
/*  414 */     stop();
/*  415 */     this.triggeredAnimation = newAnimation;
/*      */     
/*  417 */     this.needsAnimationReload = true;
/*  418 */     this.animationState = State.RUNNING;
/*  419 */     this.tick = 0;
/*  420 */     this.startAnimFrom = startAnimFrom;
/*      */   }
/*      */   
/*      */   public void triggerAnimation(RawAnimation newAnimation) {
/*  424 */     triggerAnimation(newAnimation, 0.0F);
/*      */   }
/*      */   
/*      */   public void triggerAnimation(Animation newAnimation, float startAnimFrom) {
/*  428 */     triggerAnimation(RawAnimation.begin().then(newAnimation, Animation.LoopType.DEFAULT), startAnimFrom);
/*      */   }
/*      */   
/*      */   public void triggerAnimation(Animation newAnimation) {
/*  432 */     triggerAnimation(RawAnimation.begin().then(newAnimation, Animation.LoopType.DEFAULT), 0.0F);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void replaceAnimationWithFade(@NotNull AbstractFadeModifier fadeModifier, @Nullable RawAnimation newAnimation, boolean fadeFromNothing) {
/*  442 */     if (fadeFromNothing || isActive()) {
/*  443 */       if (isActive()) {
/*  444 */         Map<String, AdvancedBoneSnapshot> snapshots = new HashMap<>();
/*  445 */         for (PlayerAnimBone bone : this.activeBones.values()) {
/*  446 */           snapshots.put(bone.getName(), new AdvancedBoneSnapshot(bone));
/*      */         }
/*  448 */         fadeModifier.setTransitionAnimation((IAnimation)new AnimationSnapshot(snapshots));
/*      */       } 
/*  450 */       addModifierLast((AbstractModifier)fadeModifier);
/*      */     } 
/*  452 */     triggerAnimation(newAnimation);
/*      */   }
/*      */   
/*      */   public void replaceAnimationWithFade(@NotNull AbstractFadeModifier fadeModifier, @Nullable RawAnimation newAnimation) {
/*  456 */     replaceAnimationWithFade(fadeModifier, newAnimation, true);
/*      */   }
/*      */   
/*      */   public void replaceAnimationWithFade(@NotNull AbstractFadeModifier fadeModifier, @Nullable Animation newAnimation, boolean fadeFromNothing) {
/*  460 */     replaceAnimationWithFade(fadeModifier, RawAnimation.begin().then(newAnimation, Animation.LoopType.DEFAULT), fadeFromNothing);
/*      */   }
/*      */   
/*      */   public void replaceAnimationWithFade(@NotNull AbstractFadeModifier fadeModifier, @Nullable Animation newAnimation) {
/*  464 */     replaceAnimationWithFade(fadeModifier, newAnimation, true);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean stopTriggeredAnimation() {
/*  473 */     if (this.triggeredAnimation == null) {
/*  474 */       return false;
/*      */     }
/*  476 */     if (this.currentRawAnimation == this.triggeredAnimation) {
/*  477 */       this.currentAnimation = null;
/*  478 */       this.currentRawAnimation = null;
/*      */     } 
/*      */     
/*  481 */     this.triggeredAnimation = null;
/*  482 */     this.needsAnimationReload = true;
/*      */     
/*  484 */     return true;
/*      */   }
/*      */   
/*      */   protected PlayState handleAnimation(AnimationData state) {
/*  488 */     if (this.triggeredAnimation != null) {
/*  489 */       if (this.currentRawAnimation != this.triggeredAnimation) {
/*  490 */         this.currentAnimation = null;
/*      */       }
/*  492 */       setAnimation(this.triggeredAnimation, this.startAnimFrom);
/*      */       
/*  494 */       if (!hasAnimationFinished() && !this.handlingTriggeredAnimations) {
/*  495 */         return PlayState.CONTINUE;
/*      */       }
/*  497 */       this.triggeredAnimation = null;
/*  498 */       this.needsAnimationReload = true;
/*      */     } 
/*      */     
/*  501 */     return this.stateHandler.handle(this, state, (animation, startTick) -> {
/*      */           setAnimation(animation, startTick - state.getPartialTick());
/*      */           return PlayState.CONTINUE;
/*      */         });
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void process(AnimationData state) {
/*  514 */     float adjustedTick = state.getPartialTick() + this.startAnimFrom + this.tick;
/*      */     
/*  516 */     PlayState playState = handleAnimation(state);
/*      */     
/*  518 */     if (playState == PlayState.STOP || (this.currentAnimation == null && this.animationQueue.isEmpty())) {
/*  519 */       this.animationState = State.STOPPED;
/*      */       
/*      */       return;
/*      */     } 
/*      */     
/*  524 */     if (getAnimationState() == State.RUNNING) {
/*  525 */       processCurrentAnimation(adjustedTick, state);
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public float getAnimationSpeed() {
/*  537 */     float speed = 1.0F;
/*  538 */     for (AbstractModifier modifier : this.modifiers) {
/*  539 */       if (modifier instanceof SpeedModifier) { SpeedModifier speedModifier = (SpeedModifier)modifier;
/*  540 */         speed *= speedModifier.speed; }
/*      */     
/*  542 */     }  return speed;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private void processCurrentAnimation(float adjustedTick, AnimationData animationData) {
/*  551 */     QueuedAnimation queued = this.currentAnimation;
/*  552 */     if (queued == null) {
/*  553 */       this.animationState = State.STOPPED;
/*      */       return;
/*      */     } 
/*  556 */     Animation animation = queued.animation();
/*      */     
/*  558 */     if (adjustedTick >= animation.length()) {
/*  559 */       if (queued.loopType().shouldPlayAgain(this, animation)) {
/*  560 */         if (this.animationState != State.PAUSED) {
/*  561 */           this.tick = 0;
/*  562 */           this.startAnimFrom = queued.loopType().restartFromTick(this, animation);
/*  563 */           adjustedTick = this.startAnimFrom;
/*  564 */           this.startAnimFrom -= animationData.getPartialTick();
/*  565 */           resetEventKeyFrames();
/*  566 */           this.isLoopStarted = true;
/*      */         } 
/*      */       } else {
/*  569 */         QueuedAnimation nextAnimation = this.animationQueue.peek();
/*      */         
/*  571 */         resetEventKeyFrames();
/*      */         
/*  573 */         if (nextAnimation == null) {
/*  574 */           this.animationState = State.STOPPED;
/*  575 */           this.currentAnimation = null;
/*  576 */           for (AdvancedPlayerAnimBone bone : this.bones.values()) {
/*  577 */             bone.setToInitialPose();
/*      */           }
/*  579 */           for (PlayerAnimBone bone : this.pivotBones.values()) {
/*  580 */             bone.setToInitialPose();
/*      */           }
/*      */           
/*      */           return;
/*      */         } 
/*  585 */         this.animationState = State.RUNNING;
/*  586 */         this.tick = 0;
/*  587 */         this.startAnimFrom = -animationData.getPartialTick();
/*  588 */         adjustedTick = 0.0F;
/*  589 */         this.currentAnimation = this.animationQueue.poll();
/*  590 */         queued = this.currentAnimation;
/*  591 */         setupNewAnimation();
/*      */       } 
/*      */     }
/*      */ 
/*      */     
/*  596 */     if (queued == null)
/*  597 */       return;  for (PlayerAnimBone bone : this.bones.values()) {
/*  598 */       bone.setToInitialPose();
/*      */     }
/*  600 */     for (PlayerAnimBone bone : this.pivotBones.values()) {
/*  601 */       bone.setToInitialPose();
/*      */     }
/*      */     
/*  604 */     for (Map.Entry<String, BoneAnimation> entry : animation.boneAnimations().entrySet()) {
/*  605 */       PlayerAnimBone bone = (PlayerAnimBone)this.bones.getOrDefault(entry.getKey(), null);
/*  606 */       boolean isAdvancedBone = false;
/*  607 */       AdvancedPlayerAnimBone advancedBone = null;
/*  608 */       if (bone == null) { bone = (PlayerAnimBone)this.pivotBones.getOrDefault(entry.getKey(), null); }
/*      */       else
/*  610 */       { advancedBone = (AdvancedPlayerAnimBone)bone;
/*  611 */         isAdvancedBone = true; }
/*      */       
/*  613 */       if (bone == null)
/*      */         continue; 
/*  615 */       BoneAnimation boneAnimation = entry.getValue();
/*  616 */       KeyframeStack rotationKeyFrames = boneAnimation.rotationKeyFrames();
/*  617 */       KeyframeStack positionKeyFrames = boneAnimation.positionKeyFrames();
/*  618 */       KeyframeStack scaleKeyFrames = boneAnimation.scaleKeyFrames();
/*  619 */       List<Keyframe> bendKeyFrames = boneAnimation.bendKeyFrames();
/*      */       
/*  621 */       Objects.requireNonNull(advancedBone); AnimationPoint rotXPoint = getAnimationPointAtTick(queued, rotationKeyFrames.xKeyframes(), adjustedTick, TransformType.ROTATION, isAdvancedBone ? advancedBone::setRotXTransitionLength : null);
/*  622 */       Objects.requireNonNull(advancedBone); AnimationPoint rotYPoint = getAnimationPointAtTick(queued, rotationKeyFrames.yKeyframes(), adjustedTick, TransformType.ROTATION, isAdvancedBone ? advancedBone::setRotYTransitionLength : null);
/*  623 */       Objects.requireNonNull(advancedBone); AnimationPoint rotZPoint = getAnimationPointAtTick(queued, rotationKeyFrames.zKeyframes(), adjustedTick, TransformType.ROTATION, isAdvancedBone ? advancedBone::setRotZTransitionLength : null);
/*  624 */       Objects.requireNonNull(advancedBone); AnimationPoint posXPoint = getAnimationPointAtTick(queued, positionKeyFrames.xKeyframes(), adjustedTick, TransformType.POSITION, isAdvancedBone ? advancedBone::setPositionXTransitionLength : null);
/*  625 */       Objects.requireNonNull(advancedBone); AnimationPoint posYPoint = getAnimationPointAtTick(queued, positionKeyFrames.yKeyframes(), adjustedTick, TransformType.POSITION, isAdvancedBone ? advancedBone::setPositionYTransitionLength : null);
/*  626 */       Objects.requireNonNull(advancedBone); AnimationPoint posZPoint = getAnimationPointAtTick(queued, positionKeyFrames.zKeyframes(), adjustedTick, TransformType.POSITION, isAdvancedBone ? advancedBone::setPositionZTransitionLength : null);
/*  627 */       Objects.requireNonNull(advancedBone); AnimationPoint scaleXPoint = getAnimationPointAtTick(queued, scaleKeyFrames.xKeyframes(), adjustedTick, TransformType.SCALE, isAdvancedBone ? advancedBone::setScaleXTransitionLength : null);
/*  628 */       Objects.requireNonNull(advancedBone); AnimationPoint scaleYPoint = getAnimationPointAtTick(queued, scaleKeyFrames.yKeyframes(), adjustedTick, TransformType.SCALE, isAdvancedBone ? advancedBone::setScaleYTransitionLength : null);
/*  629 */       Objects.requireNonNull(advancedBone); AnimationPoint scaleZPoint = getAnimationPointAtTick(queued, scaleKeyFrames.zKeyframes(), adjustedTick, TransformType.SCALE, isAdvancedBone ? advancedBone::setScaleZTransitionLength : null);
/*  630 */       Objects.requireNonNull(advancedBone); AnimationPoint bendPoint = getAnimationPointAtTick(queued, bendKeyFrames, adjustedTick, TransformType.BEND, isAdvancedBone ? advancedBone::setBendTransitionLength : null);
/*  631 */       EasingType easingType = this.overrideEasingTypeFunction.apply(this);
/*      */       
/*  633 */       bone.setRotX(EasingType.lerpWithOverride(this.molangRuntime, rotXPoint, easingType));
/*  634 */       bone.setRotY(EasingType.lerpWithOverride(this.molangRuntime, rotYPoint, easingType));
/*  635 */       bone.setRotZ(EasingType.lerpWithOverride(this.molangRuntime, rotZPoint, easingType));
/*      */       
/*  637 */       bone.setPosX(EasingType.lerpWithOverride(this.molangRuntime, posXPoint, easingType));
/*  638 */       bone.setPosY(EasingType.lerpWithOverride(this.molangRuntime, posYPoint, easingType));
/*  639 */       bone.setPosZ(EasingType.lerpWithOverride(this.molangRuntime, posZPoint, easingType));
/*      */       
/*  641 */       bone.setScaleX(EasingType.lerpWithOverride(this.molangRuntime, scaleXPoint, easingType));
/*  642 */       bone.setScaleY(EasingType.lerpWithOverride(this.molangRuntime, scaleYPoint, easingType));
/*  643 */       bone.setScaleZ(EasingType.lerpWithOverride(this.molangRuntime, scaleZPoint, easingType));
/*      */       
/*  645 */       bone.setBend(EasingType.lerpWithOverride(this.molangRuntime, bendPoint, easingType));
/*      */     } 
/*      */     
/*  648 */     applyCustomPivotPoints();
/*      */     
/*  650 */     handleCustomKeyframe(animation
/*  651 */         .keyFrames().sounds(), this.soundKeyframeHandler, (CustomKeyFrameEvents.CustomKeyFrameHandler<SoundKeyframeData>)CustomKeyFrameEvents.SOUND_KEYFRAME_EVENT
/*  652 */         .invoker(), adjustedTick, animationData);
/*      */ 
/*      */ 
/*      */     
/*  656 */     handleCustomKeyframe(animation
/*  657 */         .keyFrames().particles(), this.particleKeyframeHandler, (CustomKeyFrameEvents.CustomKeyFrameHandler<ParticleKeyframeData>)CustomKeyFrameEvents.PARTICLE_KEYFRAME_EVENT
/*  658 */         .invoker(), adjustedTick, animationData);
/*      */ 
/*      */ 
/*      */     
/*  662 */     handleCustomKeyframe(animation
/*  663 */         .keyFrames().customInstructions(), this.customKeyframeHandler, (CustomKeyFrameEvents.CustomKeyFrameHandler<CustomInstructionKeyframeData>)CustomKeyFrameEvents.CUSTOM_INSTRUCTION_KEYFRAME_EVENT
/*  664 */         .invoker(), adjustedTick, animationData);
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   protected void applyCustomPivotPoints() {
/*  670 */     if (this.currentAnimation == null)
/*  671 */       return;  Map<String, String> parentsMap = this.currentAnimation.animation().parents();
/*  672 */     if (parentsMap.isEmpty())
/*      */       return; 
/*  674 */     Set<String> processedBones = new HashSet<>();
/*  675 */     for (PlayerAnimBone bone : this.bones.values()) {
/*  676 */       processBoneHierarchy(bone, parentsMap, processedBones);
/*      */     }
/*  678 */     for (PlayerAnimBone bone : this.pivotBones.values()) {
/*  679 */       processBoneHierarchy(bone, parentsMap, processedBones);
/*      */     }
/*      */   }
/*      */   
/*      */   private void processBoneHierarchy(PlayerAnimBone bone, Map<String, String> parentsMap, Set<String> processedBones) {
/*  684 */     String boneName = bone.getName();
/*  685 */     if (processedBones.contains(boneName))
/*      */       return; 
/*  687 */     String parentName = parentsMap.get(boneName);
/*  688 */     if (parentName == null) {
/*  689 */       processedBones.add(boneName);
/*      */       
/*      */       return;
/*      */     } 
/*  693 */     PlayerAnimBone parent = (PlayerAnimBone)this.pivotBones.get(parentName);
/*  694 */     if (parent == null) parent = (PlayerAnimBone)this.bones.get(parentName); 
/*  695 */     if (parent == null) {
/*  696 */       PlayerAnimLib.LOGGER.error("Parent {} not found for {}", parentName, boneName);
/*      */       
/*      */       return;
/*      */     } 
/*  700 */     processBoneHierarchy(parent, parentsMap, processedBones);
/*      */     
/*  702 */     this.activeBones.put(boneName, bone);
/*  703 */     MatrixUtil.applyParentsToChild(bone, Collections.singletonList(parent), this::getBonePosition);
/*      */     
/*  705 */     processedBones.add(boneName);
/*      */   }
/*      */   
/*      */   protected <T extends KeyFrameData> void handleCustomKeyframe(T[] keyframes, @Nullable CustomKeyFrameEvents.CustomKeyFrameHandler<T> main, CustomKeyFrameEvents.CustomKeyFrameHandler<T> event, float animationTick, AnimationData animationData) {
/*  709 */     for (T keyframeData : keyframes) {
/*  710 */       if (animationTick >= keyframeData.getStartTick() && this.executedKeyFrames.add((KeyFrameData)keyframeData)) {
/*      */         
/*  712 */         EventResult result = (main == null) ? EventResult.PASS : main.handle(animationTick, this, (KeyFrameData)keyframeData, animationData);
/*  713 */         if (result == EventResult.PASS) {
/*  714 */           result = event.handle(animationTick, this, (KeyFrameData)keyframeData, animationData);
/*      */         }
/*      */         
/*  717 */         if (result == EventResult.FAIL) {
/*      */           return;
/*      */         }
/*      */       } 
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public float getAnimationTime() {
/*  728 */     return getAnimationTicks() / 20.0F;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public float getAnimationTicks() {
/*  736 */     if (this.animationData == null) return 0.0F; 
/*  737 */     return this.tick + this.startAnimFrom + this.animationData.getPartialTick();
/*      */   }
/*      */   
/*      */   protected void setupNewAnimation() {
/*  741 */     this.isLoopStarted = false;
/*  742 */     if (this.currentAnimation == null)
/*  743 */       return;  this.activeBones.clear();
/*  744 */     resetEventKeyFrames();
/*  745 */     for (AdvancedPlayerAnimBone bone : this.bones.values()) {
/*  746 */       bone.setEnabled((this.currentAnimation.animation().getBone(bone.getName()) != null));
/*      */     }
/*  748 */     for (Map.Entry<String, BoneAnimation> entry : this.currentAnimation.animation().boneAnimations().entrySet()) {
/*  749 */       if (this.bones.containsKey(entry.getKey())) {
/*  750 */         AdvancedPlayerAnimBone bone = this.bones.get(entry.getKey());
/*  751 */         this.activeBones.put(entry.getKey(), bone);
/*  752 */         if (this.currentAnimation.isDisableAxisIfNotModified()) {
/*  753 */           BoneAnimation boneAnimation = entry.getValue();
/*  754 */           bone.positionXEnabled = !boneAnimation.positionKeyFrames().xKeyframes().isEmpty();
/*  755 */           bone.positionYEnabled = !boneAnimation.positionKeyFrames().yKeyframes().isEmpty();
/*  756 */           bone.positionZEnabled = !boneAnimation.positionKeyFrames().zKeyframes().isEmpty();
/*      */           
/*  758 */           bone.rotXEnabled = !boneAnimation.rotationKeyFrames().xKeyframes().isEmpty();
/*  759 */           bone.rotYEnabled = !boneAnimation.rotationKeyFrames().yKeyframes().isEmpty();
/*  760 */           bone.rotZEnabled = !boneAnimation.rotationKeyFrames().zKeyframes().isEmpty();
/*      */           
/*  762 */           bone.scaleXEnabled = !boneAnimation.scaleKeyFrames().xKeyframes().isEmpty();
/*  763 */           bone.scaleYEnabled = !boneAnimation.scaleKeyFrames().yKeyframes().isEmpty();
/*  764 */           bone.scaleZEnabled = !boneAnimation.scaleKeyFrames().zKeyframes().isEmpty();
/*      */           
/*  766 */           bone.bendEnabled = !boneAnimation.bendKeyFrames().isEmpty(); continue;
/*  767 */         }  bone.setEnabled(true); continue;
/*      */       } 
/*  769 */       if (this.pivotBones.containsKey(entry.getKey())) {
/*  770 */         this.activeBones.put(entry.getKey(), (PlayerAnimBone)this.pivotBones.get(entry.getKey()));
/*      */       }
/*      */     } 
/*  773 */     for (String entry : this.currentAnimation.animation().parents().keySet()) {
/*  774 */       if (this.bones.containsKey(entry)) ((AdvancedPlayerAnimBone)this.bones.get(entry)).setEnabled(true);
/*      */     
/*      */     } 
/*  777 */     this.pivotBones.clear();
/*  778 */     for (Map.Entry<String, Vec3f> entry : this.currentAnimation.animation().bones().entrySet()) {
/*  779 */       this.pivotBones.put(entry.getKey(), new PivotBone(entry.getKey(), entry.getValue()));
/*      */     }
/*      */     
/*  782 */     Objects.requireNonNull(this.bones); this.postAnimationSetupConsumer.accept(this.bones::get);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private AnimationPoint getAnimationPointAtTick(QueuedAnimation queued, List<Keyframe> frames, float tick, TransformType type, Consumer<Float> transitionLengthSetter) {
/*  789 */     Animation animation = queued.animation();
/*  790 */     ExtraAnimationData extraData = animation.data();
/*  791 */     float endTick = ((Float)extraData.<Float>get("endTick").orElse(Float.valueOf(animation.length() - 1.0F))).floatValue();
/*      */     
/*  793 */     KeyframeLocation<Keyframe> location = getCurrentKeyFrameLocation(frames, tick, type, (extraData.isAnimationPlayerAnimatorFormat() && queued.loopType().shouldPlayAgain(null, animation)), animation.length(), queued.loopType().restartFromTick(null, animation));
/*  794 */     Keyframe currentFrame = location.keyframe();
/*  795 */     float startValue = this.molangRuntime.eval(currentFrame.startValue());
/*  796 */     float endValue = this.molangRuntime.eval(currentFrame.endValue());
/*      */     
/*  798 */     if (type == TransformType.ROTATION || type == TransformType.BEND) {
/*  799 */       if (!MolangLoader.isConstant(currentFrame.startValue())) {
/*  800 */         startValue = (float)Math.toRadians(startValue);
/*      */       }
/*      */       
/*  803 */       if (!MolangLoader.isConstant(currentFrame.endValue())) {
/*  804 */         endValue = (float)Math.toRadians(endValue);
/*      */       }
/*      */     } 
/*      */     
/*  808 */     if (transitionLengthSetter != null) {
/*  809 */       if (queued.hasBeginTick() && !frames.isEmpty() && currentFrame == frames.getFirst() && ((Float)extraData.<Float>get("beginTick").get()).floatValue() > tick)
/*  810 */       { startValue = endValue;
/*  811 */         transitionLengthSetter.accept(Float.valueOf(currentFrame.length())); }
/*  812 */       else if (queued.hasEndTick() && !frames.isEmpty() && currentFrame == frames.getLast() && endTick <= tick)
/*  813 */       { transitionLengthSetter.accept(Float.valueOf(animation.length() - endTick)); }
/*  814 */       else { transitionLengthSetter.accept(null); }
/*      */     
/*      */     }
/*  817 */     return new AnimationPoint(currentFrame.easingType(), currentFrame.easingArgs(), location.startTick(), currentFrame.length(), startValue, endValue);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private KeyframeLocation<Keyframe> getCurrentKeyFrameLocation(List<Keyframe> frames, float ageInTicks, TransformType type, boolean isPlayerAnimatorLoop, float animTime, float returnToTick) {
/*  828 */     if (frames.isEmpty()) {
/*  829 */       return (type == TransformType.SCALE) ? EMPTY_SCALE_KEYFRAME_LOCATION : EMPTY_KEYFRAME_LOCATION;
/*      */     }
/*  831 */     Keyframe firstFrame = (returnToTick == 0.0F) ? (Keyframe)frames.getFirst() : Keyframe.getKeyframeAtTime(frames, returnToTick);
/*  832 */     float totalFrameTime = 0.0F;
/*      */     
/*  834 */     for (Keyframe frame : frames) {
/*  835 */       totalFrameTime += frame.length();
/*      */       
/*  837 */       if (totalFrameTime > ageInTicks) {
/*  838 */         if (isPlayerAnimatorLoop && isLoopStarted() && frame == firstFrame) {
/*  839 */           float stopTickMinusLastKeyframe = animTime - Keyframe.getLastKeyframeTime(frames);
/*  840 */           return new KeyframeLocation(new Keyframe(frame.length() + stopTickMinusLastKeyframe, ((Keyframe)frames.getLast()).endValue(), frame.endValue(), frame.easingType(), frame.easingArgs()), ageInTicks + stopTickMinusLastKeyframe);
/*      */         } 
/*  842 */         return new KeyframeLocation(frame, ageInTicks - totalFrameTime - frame.length());
/*      */       } 
/*      */     } 
/*      */     
/*  846 */     if (isPlayerAnimatorLoop) {
/*  847 */       return new KeyframeLocation(new Keyframe(firstFrame.length() + animTime - totalFrameTime, ((Keyframe)frames.getLast()).endValue(), firstFrame.endValue(), firstFrame.easingType(), firstFrame.easingArgs()), ageInTicks - totalFrameTime);
/*      */     }
/*  849 */     return new KeyframeLocation((Keyframe)frames.getLast(), ageInTicks);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected void resetEventKeyFrames() {
/*  856 */     if (!this.executedKeyFrames.isEmpty()) {
/*  857 */       ((CustomKeyFrameEvents.ResetKeyFramesHandler)CustomKeyFrameEvents.RESET_KEYFRAMES_EVENT.invoker()).handle(this, this.executedKeyFrames);
/*      */     }
/*  859 */     this.executedKeyFrames.clear();
/*      */   }
/*      */   
/*      */   public PlayerAnimBone get3DTransformRaw(@NotNull PlayerAnimBone bone) {
/*  863 */     if (this.activeBones.containsKey(bone.getName())) {
/*  864 */       PlayerAnimBone bone1 = this.activeBones.get(bone.getName());
/*  865 */       QueuedAnimation queued = this.currentAnimation;
/*  866 */       if (queued != null && bone1 instanceof AdvancedPlayerAnimBone) { AdvancedPlayerAnimBone advancedBone = (AdvancedPlayerAnimBone)bone1;
/*  867 */         ExtraAnimationData extraData = queued.animation().data();
/*  868 */         if (queued.hasBeginTick() && ((Float)extraData.<Float>get("beginTick").get()).floatValue() > getAnimationTicks()) {
/*  869 */           bone.beginOrEndTickLerp(advancedBone, getAnimationTicks(), null);
/*  870 */         } else if (queued.hasEndTick() && ((Float)extraData.<Float>get("endTick").get()).floatValue() <= getAnimationTicks()) {
/*  871 */           bone.beginOrEndTickLerp(advancedBone, getAnimationTicks() - ((Float)extraData.<Float>get("endTick").get()).floatValue(), this.currentAnimation.animation());
/*      */         } else {
/*  873 */           bone.copyOtherBoneIfNotDisabled(bone1);
/*      */         }  }
/*  875 */       else { bone.copyOtherBoneIfNotDisabled(bone1); }
/*      */     
/*  877 */     }  return bone;
/*      */   }
/*      */ 
/*      */   
/*      */   public PlayerAnimBone get3DTransform(@NotNull PlayerAnimBone bone) {
/*  882 */     if (!this.modifiers.isEmpty()) {
/*  883 */       return ((AbstractModifier)this.modifiers.getFirst()).get3DTransform(bone);
/*      */     }
/*  885 */     return get3DTransformRaw(bone);
/*      */   }
/*      */   
/*      */   @NotNull
/*      */   public FirstPersonMode getFirstPersonMode() {
/*  890 */     if (this.firstPersonMode != null) return this.firstPersonMode.apply(this); 
/*  891 */     return FirstPersonMode.NONE;
/*      */   }
/*      */   
/*      */   @NotNull
/*      */   public FirstPersonConfiguration getFirstPersonConfiguration() {
/*  896 */     if (this.firstPersonConfiguration != null) return this.firstPersonConfiguration.apply(this); 
/*  897 */     return IAnimation.DEFAULT_FIRST_PERSON_CONFIG;
/*      */   }
/*      */   
/*      */   public AnimationController setFirstPersonMode(FirstPersonMode mode) {
/*  901 */     this.firstPersonMode = (controller -> mode);
/*      */     
/*  903 */     return this;
/*      */   }
/*      */   
/*      */   public AnimationController setFirstPersonModeHandler(Function<AnimationController, FirstPersonMode> modeHandler) {
/*  907 */     this.firstPersonMode = modeHandler;
/*      */     
/*  909 */     return this;
/*      */   }
/*      */   
/*      */   public AnimationController setFirstPersonConfiguration(FirstPersonConfiguration config) {
/*  913 */     this.firstPersonConfiguration = (controller -> config);
/*      */     
/*  915 */     return this;
/*      */   }
/*      */   
/*      */   public AnimationController setFirstPersonConfigurationHandler(Function<AnimationController, FirstPersonConfiguration> configHandler) {
/*  919 */     this.firstPersonConfiguration = configHandler;
/*      */     
/*  921 */     return this;
/*      */   }
/*      */ 
/*      */   
/*      */   public void tick(AnimationData state) {
/*  926 */     this.animationData = state;
/*  927 */     for (int i = 0; i < this.modifiers.size(); i++) {
/*  928 */       if (((AbstractModifier)this.modifiers.get(i)).canRemove()) {
/*  929 */         removeModifier(i--);
/*      */       }
/*      */     } 
/*  932 */     if (!this.modifiers.isEmpty()) {
/*  933 */       ((AbstractModifier)this.modifiers.getFirst()).tick(state);
/*      */     } else {
/*  935 */       handleAnimation(state);
/*  936 */       if (this.animationState == State.RUNNING) {
/*  937 */         this.tick++;
/*      */       }
/*      */     } 
/*      */   }
/*      */ 
/*      */   
/*      */   public void setupAnim(AnimationData state) {
/*  944 */     this.animationData = state;
/*  945 */     if (!this.modifiers.isEmpty())
/*  946 */     { ((AbstractModifier)this.modifiers.getFirst()).setupAnim(state); }
/*  947 */     else { process(state); }
/*      */   
/*      */   }
/*      */   public Vec3f getBonePosition(String name) {
/*  951 */     if (this.bonePositions.containsKey(name)) return this.bonePositions.get(name); 
/*  952 */     if (this.pivotBones.containsKey(name)) return ((PivotBone)this.pivotBones.get(name)).getPivot(); 
/*  953 */     return Vec3f.ZERO;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @Internal
/*      */   public List<AbstractModifier> getModifiers() {
/*  962 */     return this.modifiers;
/*      */   }
/*      */   
/*      */   public AnimationController addModifier(@NotNull AbstractModifier modifier, int idx) {
/*  966 */     modifier.setHost(this);
/*  967 */     this.modifiers.add(idx, modifier);
/*  968 */     linkModifiers();
/*  969 */     return this;
/*      */   }
/*      */   
/*      */   public AnimationController addModifierBefore(@NotNull AbstractModifier modifier) {
/*  973 */     addModifier(modifier, 0);
/*  974 */     return this;
/*      */   }
/*      */   
/*      */   public AnimationController addModifierLast(@NotNull AbstractModifier modifier) {
/*  978 */     addModifier(modifier, this.modifiers.size());
/*  979 */     return this;
/*      */   }
/*      */   
/*      */   public AnimationController removeModifier(int idx) {
/*  983 */     this.modifiers.remove(idx);
/*  984 */     linkModifiers();
/*  985 */     return this;
/*      */   }
/*      */   
/*      */   public AnimationController removeAllModifiers() {
/*  989 */     this.modifiers.clear();
/*  990 */     return this;
/*      */   }
/*      */   
/*      */   public int getModifierCount() {
/*  994 */     return this.modifiers.size();
/*      */   }
/*      */   @Nullable
/*      */   public AbstractModifier getModifier(int idx) {
/*      */     try {
/*  999 */       return this.modifiers.get(idx);
/* 1000 */     } catch (IndexOutOfBoundsException e) {
/* 1001 */       return null;
/*      */     } 
/*      */   }
/*      */   
/*      */   public boolean removeModifierIf(Predicate<? super AbstractModifier> predicate) {
/* 1006 */     boolean success = this.modifiers.removeIf(predicate);
/* 1007 */     linkModifiers();
/* 1008 */     return success;
/*      */   }
/*      */   
/*      */   protected void linkModifiers() {
/* 1012 */     Iterator<AbstractModifier> modifierIterator = this.modifiers.iterator();
/* 1013 */     if (modifierIterator.hasNext()) {
/* 1014 */       AbstractModifier tmp = modifierIterator.next();
/* 1015 */       while (modifierIterator.hasNext()) {
/* 1016 */         AbstractModifier tmp2 = modifierIterator.next();
/* 1017 */         tmp.setAnim((IAnimation)tmp2);
/* 1018 */         tmp = tmp2;
/*      */       } 
/* 1020 */       tmp.setAnim((IAnimation)this.internalAnimationAccessor);
/*      */     } 
/*      */   }
/*      */   
/*      */   public AdvancedPlayerAnimBone registerPlayerAnimBone(String name) {
/* 1025 */     return registerPlayerAnimBone(new AdvancedPlayerAnimBone(name));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public AdvancedPlayerAnimBone registerPlayerAnimBone(AdvancedPlayerAnimBone bone) {
/* 1034 */     this.bones.put(bone.getName(), bone);
/* 1035 */     return bone;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @Nullable
/*      */   public AdvancedPlayerAnimBone getBone(String name) {
/* 1047 */     return this.bones.get(name);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @FunctionalInterface
/*      */   public static interface AnimationSetter
/*      */   {
/*      */     PlayState setAnimation(RawAnimation param1RawAnimation, int param1Int);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     default PlayState setAnimation(RawAnimation animation) {
/* 1078 */       return setAnimation(animation, 0);
/*      */     }
/*      */   }
/*      */   
/*      */   @FunctionalInterface
/*      */   public static interface AnimationStateHandler { PlayState handle(AnimationController param1AnimationController, AnimationData param1AnimationData, AnimationController.AnimationSetter param1AnimationSetter); }
/*      */   
/*      */   private static class InternalAnimationAccessor extends AnimationContainer<AnimationController> { private InternalAnimationAccessor(AnimationController controller) {
/* 1086 */       super(controller);
/*      */     }
/*      */ 
/*      */     
/*      */     public void tick(AnimationData state) {
/* 1091 */       ((AnimationController)this.anim).handleAnimation(state);
/* 1092 */       if (((AnimationController)this.anim).animationState == State.RUNNING) ((AnimationController)this.anim).tick++;
/*      */     
/*      */     }
/*      */     
/*      */     public void setupAnim(AnimationData state) {
/* 1097 */       ((AnimationController)this.anim).process(state);
/*      */     }
/*      */ 
/*      */     
/*      */     public PlayerAnimBone get3DTransform(@NotNull PlayerAnimBone bone) {
/* 1102 */       return ((AnimationController)this.anim).get3DTransformRaw(bone);
/*      */     } }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public String toString() {
/* 1109 */     return "AnimationController{currentAnimation=" + String.valueOf(getCurrentAnimationInstance()) + ", tick=" + 
/* 1110 */       getAnimationTicks() + ", modifiers=" + String.valueOf(this.modifiers) + "}";
/*      */   }
/*      */   
/*      */   public abstract void registerBones();
/*      */ }


/* Location:              C:\Users\rapha\Downloads\aurora.jar!\META-INF\jars\player-animation-library-wJLdv4ZQ.jar!\com\zigythebird\playeranimcore\animation\AnimationController.class
 * Java compiler version: 21 (65.0)
 * JD-Core Version:       1.1.3
 */