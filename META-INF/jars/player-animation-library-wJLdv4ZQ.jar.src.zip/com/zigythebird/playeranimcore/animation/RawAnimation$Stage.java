/*     */ package com.zigythebird.playeranimcore.animation;
/*     */ 
/*     */ import com.zigythebird.playeranimcore.enums.AnimationStage;
/*     */ import java.util.Objects;
/*     */ import org.jetbrains.annotations.Nullable;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class Stage
/*     */   extends Record
/*     */ {
/*     */   private final AnimationStage stage;
/*     */   @Nullable
/*     */   private final Animation animation;
/*     */   private final Animation.LoopType loopType;
/*     */   private final int additionalTicks;
/*     */   
/*     */   public final String toString() {
/*     */     // Byte code:
/*     */     //   0: aload_0
/*     */     //   1: <illegal opcode> toString : (Lcom/zigythebird/playeranimcore/animation/RawAnimation$Stage;)Ljava/lang/String;
/*     */     //   6: areturn
/*     */     // Line number table:
/*     */     //   Java source line number -> byte code offset
/*     */     //   #170	-> 0
/*     */     // Local variable table:
/*     */     //   start	length	slot	name	descriptor
/*     */     //   0	7	0	this	Lcom/zigythebird/playeranimcore/animation/RawAnimation$Stage;
/*     */   }
/*     */   
/*     */   public Stage(AnimationStage stage, @Nullable Animation animation, Animation.LoopType loopType, int additionalTicks) {
/* 170 */     this.stage = stage; this.animation = animation; this.loopType = loopType; this.additionalTicks = additionalTicks; } public AnimationStage stage() { return this.stage; } @Nullable public Animation animation() { return this.animation; } public Animation.LoopType loopType() { return this.loopType; } public int additionalTicks() { return this.additionalTicks; }
/*     */    public Stage(AnimationStage stage, Animation animation, Animation.LoopType loopType) {
/* 172 */     this(stage, animation, loopType, 0);
/*     */   }
/*     */   
/*     */   public Stage(Animation animation, Animation.LoopType loopType) {
/* 176 */     this(AnimationStage.ANIMATION, animation, loopType);
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean equals(Object obj) {
/* 181 */     if (this == obj) {
/* 182 */       return true;
/*     */     }
/* 184 */     if (obj == null || getClass() != obj.getClass()) {
/* 185 */       return false;
/*     */     }
/* 187 */     return (hashCode() == obj.hashCode());
/*     */   }
/*     */ 
/*     */   
/*     */   public int hashCode() {
/* 192 */     return Objects.hash(new Object[] { this.stage, this.animation, this.loopType });
/*     */   }
/*     */ }


/* Location:              C:\Users\rapha\Downloads\aurora.jar!\META-INF\jars\player-animation-library-wJLdv4ZQ.jar!\com\zigythebird\playeranimcore\animation\RawAnimation$Stage.class
 * Java compiler version: 21 (65.0)
 * JD-Core Version:       1.1.3
 */