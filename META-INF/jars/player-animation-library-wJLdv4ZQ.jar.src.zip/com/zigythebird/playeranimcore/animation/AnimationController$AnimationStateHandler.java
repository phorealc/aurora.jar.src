package com.zigythebird.playeranimcore.animation;

import com.zigythebird.playeranimcore.enums.PlayState;

@FunctionalInterface
public interface AnimationStateHandler {
  PlayState handle(AnimationController paramAnimationController, AnimationData paramAnimationData, AnimationController.AnimationSetter paramAnimationSetter);
}


/* Location:              C:\Users\rapha\Downloads\aurora.jar!\META-INF\jars\player-animation-library-wJLdv4ZQ.jar!\com\zigythebird\playeranimcore\animation\AnimationController$AnimationStateHandler.class
 * Java compiler version: 21 (65.0)
 * JD-Core Version:       1.1.3
 */