/*     */ package com.zigythebird.playeranimcore.animation;
/*     */ 
/*     */ import com.zigythebird.playeranimcore.bones.AdvancedPlayerAnimBone;
/*     */ import com.zigythebird.playeranimcore.bones.PlayerAnimBone;
/*     */ import com.zigythebird.playeranimcore.math.Vec3f;
/*     */ import com.zigythebird.playeranimcore.util.MatrixUtil;
/*     */ import java.util.ArrayList;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import java.util.function.Function;
/*     */ import org.jetbrains.annotations.NotNull;
/*     */ import org.joml.Matrix4f;
/*     */ import team.unnamed.mocha.MochaEngine;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class HumanoidAnimationController
/*     */   extends AnimationController
/*     */ {
/*  45 */   public static final Map<String, Vec3f> BONE_POSITIONS = Map.ofEntries((Map.Entry<? extends String, ? extends Vec3f>[])new Map.Entry[] { 
/*  46 */         Map.entry("right_item", new Vec3f(6.0F, 12.0F, -2.0F)), 
/*  47 */         Map.entry("left_item", new Vec3f(-6.0F, 12.0F, -2.0F)), 
/*  48 */         Map.entry("right_arm", new Vec3f(5.0F, 22.0F, 0.0F)), 
/*  49 */         Map.entry("left_arm", new Vec3f(-5.0F, 22.0F, 0.0F)), 
/*  50 */         Map.entry("left_leg", new Vec3f(-2.0F, 12.0F, 0.0F)), 
/*  51 */         Map.entry("right_leg", new Vec3f(2.0F, 12.0F, 0.0F)), 
/*  52 */         Map.entry("torso", new Vec3f(0.0F, 24.0F, 0.0F)), 
/*  53 */         Map.entry("head", new Vec3f(0.0F, 24.0F, 0.0F)), 
/*  54 */         Map.entry("body", new Vec3f(0.0F, 12.0F, 0.0F)), 
/*  55 */         Map.entry("cape", new Vec3f(0.0F, 24.0F, 2.0F)), 
/*  56 */         Map.entry("elytra", new Vec3f(0.0F, 24.0F, 2.0F)) });
/*     */ 
/*     */ 
/*     */   
/*     */   protected List<String> top_bones;
/*     */ 
/*     */ 
/*     */   
/*     */   private float torsoBend;
/*     */ 
/*     */ 
/*     */   
/*     */   private int torsoBendSign;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public HumanoidAnimationController(AnimationController.AnimationStateHandler animationHandler, Function<AnimationController, MochaEngine<AnimationController>> molangRuntime) {
/*  74 */     this(animationHandler, BONE_POSITIONS, molangRuntime);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public HumanoidAnimationController(AnimationController.AnimationStateHandler animationHandler, Map<String, Vec3f> bonePositions, Function<AnimationController, MochaEngine<AnimationController>> molangRuntime) {
/*  85 */     super(animationHandler, bonePositions, molangRuntime);
/*     */   }
/*     */ 
/*     */   
/*     */   public void registerBones() {
/*  90 */     this.top_bones = new ArrayList<>();
/*     */     
/*  92 */     registerPlayerAnimBone("body");
/*  93 */     registerTopPlayerAnimBone("right_arm");
/*  94 */     registerTopPlayerAnimBone("left_arm");
/*  95 */     registerPlayerAnimBone("right_leg");
/*  96 */     registerPlayerAnimBone("left_leg");
/*  97 */     registerTopPlayerAnimBone("head");
/*  98 */     registerPlayerAnimBone("torso");
/*  99 */     registerPlayerAnimBone("right_item");
/* 100 */     registerPlayerAnimBone("left_item");
/* 101 */     registerTopPlayerAnimBone("cape");
/* 102 */     registerPlayerAnimBone("elytra");
/*     */   }
/*     */   
/*     */   public void registerTopPlayerAnimBone(String name) {
/* 106 */     this.top_bones.add(name);
/* 107 */     registerPlayerAnimBone(name);
/*     */   }
/*     */ 
/*     */   
/*     */   public void process(AnimationData state) {
/* 112 */     super.process(state);
/* 113 */     this.torsoBend = ((AdvancedPlayerAnimBone)this.bones.get("torso")).getBend();
/* 114 */     float absBend = Math.abs(this.torsoBend);
/* 115 */     if (absBend > 0.001D && this.currentAnimation != null && this.currentAnimation.animation().data().getNullable("applyBendToOtherBones") == Boolean.TRUE)
/* 116 */     { this.torsoBendSign = (int)Math.signum(this.torsoBend); }
/* 117 */     else { this.torsoBendSign = 0; }
/*     */   
/*     */   }
/*     */   
/*     */   public PlayerAnimBone get3DTransformRaw(@NotNull PlayerAnimBone bone) {
/* 122 */     bone = super.get3DTransformRaw(bone);
/* 123 */     String name = bone.getName();
/* 124 */     if (this.torsoBendSign != 0 && this.top_bones.contains(name)) {
/* 125 */       Matrix4f matrix4f = new Matrix4f();
/* 126 */       matrix4f.translate(0.0F, 18.0F, 0.0F);
/* 127 */       matrix4f.rotateX(this.torsoBend);
/* 128 */       matrix4f.translate(0.0F, -18.0F, 0.0F);
/* 129 */       MatrixUtil.applyMatrixToBone(bone, matrix4f, getBonePosition(name));
/*     */     } 
/* 131 */     return bone;
/*     */   }
/*     */ }


/* Location:              C:\Users\rapha\Downloads\aurora.jar!\META-INF\jars\player-animation-library-wJLdv4ZQ.jar!\com\zigythebird\playeranimcore\animation\HumanoidAnimationController.class
 * Java compiler version: 21 (65.0)
 * JD-Core Version:       1.1.3
 */