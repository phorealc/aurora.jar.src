/*    */ package com.zigythebird.playeranimcore.animation;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public final class QueuedAnimation
/*    */   extends Record
/*    */ {
/*    */   private final Animation animation;
/*    */   private final Animation.LoopType loopType;
/*    */   
/*    */   public final String toString() {
/*    */     // Byte code:
/*    */     //   0: aload_0
/*    */     //   1: <illegal opcode> toString : (Lcom/zigythebird/playeranimcore/animation/QueuedAnimation;)Ljava/lang/String;
/*    */     //   6: areturn
/*    */     // Line number table:
/*    */     //   Java source line number -> byte code offset
/*    */     //   #31	-> 0
/*    */     // Local variable table:
/*    */     //   start	length	slot	name	descriptor
/*    */     //   0	7	0	this	Lcom/zigythebird/playeranimcore/animation/QueuedAnimation;
/*    */   }
/*    */   
/*    */   public final int hashCode() {
/*    */     // Byte code:
/*    */     //   0: aload_0
/*    */     //   1: <illegal opcode> hashCode : (Lcom/zigythebird/playeranimcore/animation/QueuedAnimation;)I
/*    */     //   6: ireturn
/*    */     // Line number table:
/*    */     //   Java source line number -> byte code offset
/*    */     //   #31	-> 0
/*    */     // Local variable table:
/*    */     //   start	length	slot	name	descriptor
/*    */     //   0	7	0	this	Lcom/zigythebird/playeranimcore/animation/QueuedAnimation;
/*    */   }
/*    */   
/*    */   public final boolean equals(Object o) {
/*    */     // Byte code:
/*    */     //   0: aload_0
/*    */     //   1: aload_1
/*    */     //   2: <illegal opcode> equals : (Lcom/zigythebird/playeranimcore/animation/QueuedAnimation;Ljava/lang/Object;)Z
/*    */     //   7: ireturn
/*    */     // Line number table:
/*    */     //   Java source line number -> byte code offset
/*    */     //   #31	-> 0
/*    */     // Local variable table:
/*    */     //   start	length	slot	name	descriptor
/*    */     //   0	8	0	this	Lcom/zigythebird/playeranimcore/animation/QueuedAnimation;
/*    */     //   0	8	1	o	Ljava/lang/Object;
/*    */   }
/*    */   
/*    */   public QueuedAnimation(Animation animation, Animation.LoopType loopType) {
/* 31 */     this.animation = animation; this.loopType = loopType; } public Animation animation() { return this.animation; } public Animation.LoopType loopType() { return this.loopType; }
/*    */    public boolean hasBeginTick() {
/* 33 */     return this.animation.data().has("beginTick");
/*    */   }
/*    */   
/*    */   public boolean hasEndTick() {
/* 37 */     return (!this.animation.loopType().shouldPlayAgain(null, this.animation) && this.animation.data().has("endTick"));
/*    */   }
/*    */   
/*    */   public boolean isDisableAxisIfNotModified() {
/* 41 */     return this.animation.data().isDisableAxisIfNotModified();
/*    */   }
/*    */   
/*    */   public boolean isAnimationPlayerAnimatorFormat() {
/* 45 */     return this.animation.data().isAnimationPlayerAnimatorFormat();
/*    */   }
/*    */ }


/* Location:              C:\Users\rapha\Downloads\aurora.jar!\META-INF\jars\player-animation-library-wJLdv4ZQ.jar!\com\zigythebird\playeranimcore\animation\QueuedAnimation.class
 * Java compiler version: 21 (65.0)
 * JD-Core Version:       1.1.3
 */