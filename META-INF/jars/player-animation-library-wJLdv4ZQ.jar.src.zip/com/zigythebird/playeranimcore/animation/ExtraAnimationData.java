/*     */ package com.zigythebird.playeranimcore.animation;
/*     */ 
/*     */ import com.google.gson.JsonElement;
/*     */ import com.google.gson.JsonPrimitive;
/*     */ import java.util.Map;
/*     */ 
/*     */ public final class ExtraAnimationData extends Record {
/*     */   private final Map<String, Object> data;
/*     */   public static final String NAME_KEY = "name";
/*     */   public static final String UUID_KEY = "uuid";
/*     */   public static final String FORMAT_KEY = "format";
/*     */   public static final String BEGIN_TICK_KEY = "beginTick";
/*     */   
/*  14 */   public ExtraAnimationData(Map<String, Object> data) { this.data = data; } public static final String END_TICK_KEY = "endTick"; public static final String EASING_BEFORE_KEY = "easeBeforeKeyframe"; public static final String APPLY_BEND_TO_OTHER_BONES_KEY = "applyBendToOtherBones"; public static final String PARTICLE_EFFECTS_KEY = "particleEffects"; public static final String DISABLE_AXIS_IF_NOT_MODIFIED = "disableAxisIfNotModified"; public final int hashCode() { // Byte code:
/*     */     //   0: aload_0
/*     */     //   1: <illegal opcode> hashCode : (Lcom/zigythebird/playeranimcore/animation/ExtraAnimationData;)I
/*     */     //   6: ireturn
/*     */     // Line number table:
/*     */     //   Java source line number -> byte code offset
/*     */     //   #14	-> 0
/*     */     // Local variable table:
/*     */     //   start	length	slot	name	descriptor
/*     */     //   0	7	0	this	Lcom/zigythebird/playeranimcore/animation/ExtraAnimationData; } public final boolean equals(Object o) { // Byte code:
/*     */     //   0: aload_0
/*     */     //   1: aload_1
/*     */     //   2: <illegal opcode> equals : (Lcom/zigythebird/playeranimcore/animation/ExtraAnimationData;Ljava/lang/Object;)Z
/*     */     //   7: ireturn
/*     */     // Line number table:
/*     */     //   Java source line number -> byte code offset
/*     */     //   #14	-> 0
/*     */     // Local variable table:
/*     */     //   start	length	slot	name	descriptor
/*     */     //   0	8	0	this	Lcom/zigythebird/playeranimcore/animation/ExtraAnimationData;
/*  14 */     //   0	8	1	o	Ljava/lang/Object; } public Map<String, Object> data() { return this.data; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ExtraAnimationData(String key, Object value) {
/*  26 */     this(new HashMap<>(Collections.singletonMap(key, value)));
/*     */   }
/*     */   
/*     */   public ExtraAnimationData() {
/*  30 */     this(new HashMap<>(1));
/*     */   }
/*     */   @Nullable
/*     */   public String name() {
/*     */     String name;
/*  35 */     Object data = data().get("name");
/*     */     
/*  37 */     if (data instanceof JsonObject) { JsonObject jsonObject = (JsonObject)data;
/*  38 */       name = jsonObject.get("fallback").getAsString(); }
/*  39 */     else { name = (String)data; }
/*  40 */      return (name != null) ? name.toLowerCase(Locale.ROOT).replace("\"", "").replace(" ", "_") : null;
/*     */   }
/*     */   
/*     */   public boolean has(String name) {
/*  44 */     return data().containsKey(name);
/*     */   }
/*     */   @Nullable
/*     */   public ByteBuffer getBinary(String name) {
/*  48 */     Object obj = getRaw(name);
/*  49 */     if (obj == null) return null;
/*     */     
/*  51 */     if (obj instanceof String) { String str = (String)obj;
/*     */       try {
/*  53 */         put(name, obj = Base64.getDecoder().decode(str));
/*  54 */       } catch (IllegalArgumentException e) {
/*  55 */         return null;
/*     */       }  }
/*     */     
/*  58 */     if (obj instanceof byte[]) { byte[] bytes = (byte[])obj;
/*  59 */       put(name, obj = ByteBuffer.wrap(bytes).asReadOnlyBuffer()); }
/*     */     
/*  61 */     if (obj instanceof ByteBuffer) { ByteBuffer buffer = (ByteBuffer)obj;
/*  62 */       return buffer.asReadOnlyBuffer(); }
/*     */     
/*  64 */     return null;
/*     */   }
/*     */   
/*     */   public Object getRaw(String name) {
/*  68 */     return data().get(name);
/*     */   }
/*     */ 
/*     */   
/*     */   public <T> Optional<T> get(String key) {
/*  73 */     Object obj = getRaw(key);
/*  74 */     if (obj == null) return Optional.empty();
/*     */     
/*     */     try {
/*  77 */       return Optional.of((T)obj);
/*  78 */     } catch (Throwable throwable) {
/*     */       
/*  80 */       return Optional.empty();
/*     */     } 
/*     */   }
/*     */   public <T> T getNullable(String key) {
/*  84 */     return get(key).orElse(null);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public List<?> getList(String key) {
/*     */     // Byte code:
/*     */     //   0: aload_0
/*     */     //   1: aload_1
/*     */     //   2: invokevirtual getRaw : (Ljava/lang/String;)Ljava/lang/Object;
/*     */     //   5: astore_2
/*     */     //   6: aload_2
/*     */     //   7: astore_3
/*     */     //   8: iconst_0
/*     */     //   9: istore #4
/*     */     //   11: aload_3
/*     */     //   12: iload #4
/*     */     //   14: <illegal opcode> typeSwitch : (Ljava/lang/Object;I)I
/*     */     //   19: tableswitch default -> 75, -1 -> 44, 0 -> 50, 1 -> 64
/*     */     //   44: invokestatic emptyList : ()Ljava/util/List;
/*     */     //   47: goto -> 90
/*     */     //   50: aload_3
/*     */     //   51: checkcast com/google/gson/JsonArray
/*     */     //   54: astore #5
/*     */     //   56: aload #5
/*     */     //   58: invokevirtual asList : ()Ljava/util/List;
/*     */     //   61: goto -> 90
/*     */     //   64: aload_3
/*     */     //   65: checkcast java/util/List
/*     */     //   68: astore #6
/*     */     //   70: aload #6
/*     */     //   72: goto -> 90
/*     */     //   75: new java/lang/ClassCastException
/*     */     //   78: dup
/*     */     //   79: aload_2
/*     */     //   80: invokevirtual getClass : ()Ljava/lang/Class;
/*     */     //   83: invokevirtual getName : ()Ljava/lang/String;
/*     */     //   86: invokespecial <init> : (Ljava/lang/String;)V
/*     */     //   89: athrow
/*     */     //   90: areturn
/*     */     // Line number table:
/*     */     //   Java source line number -> byte code offset
/*     */     //   #88	-> 0
/*     */     //   #89	-> 6
/*     */     //   #90	-> 44
/*     */     //   #91	-> 50
/*     */     //   #92	-> 64
/*     */     //   #93	-> 75
/*     */     //   #89	-> 90
/*     */     // Local variable table:
/*     */     //   start	length	slot	name	descriptor
/*     */     //   56	8	5	json	Lcom/google/gson/JsonArray;
/*     */     //   70	5	6	list	Ljava/util/List;
/*     */     //   0	91	0	this	Lcom/zigythebird/playeranimcore/animation/ExtraAnimationData;
/*     */     //   0	91	1	key	Ljava/lang/String;
/*     */     //   6	85	2	obj	Ljava/lang/Object;
/*     */     // Local variable type table:
/*     */     //   start	length	slot	name	signature
/*     */     //   70	5	6	list	Ljava/util/List<*>;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void put(String name, Object object) {
/*  98 */     this.data.put(name, object);
/*     */   }
/*     */   
/*     */   public void fromJson(JsonObject node, boolean root) {
/* 102 */     for (Map.Entry<String, JsonElement> entry : (Iterable<Map.Entry<String, JsonElement>>)node.entrySet()) {
/* 103 */       String key = entry.getKey();
/* 104 */       if (root && ("version".equalsIgnoreCase(key) || "emote".equalsIgnoreCase(key)))
/* 105 */         continue;  data().put(key, getValue(entry.getValue()));
/*     */     } 
/*     */   }
/*     */   
/*     */   public Object getValue(JsonElement element) {
/* 110 */     if (element instanceof JsonPrimitive) { JsonPrimitive p = (JsonPrimitive)element;
/* 111 */       if (p.isBoolean())
/* 112 */         return Boolean.valueOf(p.getAsBoolean()); 
/* 113 */       if (p.isString())
/* 114 */         return p.getAsString(); 
/* 115 */       if (p.isNumber()) {
/* 116 */         return Float.valueOf(p.getAsFloat());
/*     */       } }
/*     */     
/* 119 */     if (element instanceof JsonArray) { JsonArray array = (JsonArray)element;
/* 120 */       List<Object> list = new ArrayList(array.size());
/* 121 */       for (JsonElement element1 : array) {
/* 122 */         list.add(getValue(element1));
/*     */       }
/* 124 */       return list; }
/*     */     
/* 126 */     return element.toString();
/*     */   }
/*     */   
/*     */   public ExtraAnimationData copy() {
/* 130 */     return new ExtraAnimationData(new HashMap<>(data()));
/*     */   }
/*     */   
/*     */   public boolean isDisableAxisIfNotModified() {
/* 134 */     return ((Boolean)get("disableAxisIfNotModified").orElse(Boolean.valueOf(true))).booleanValue();
/*     */   }
/*     */   
/*     */   public boolean isAnimationPlayerAnimatorFormat() {
/* 138 */     return (get("format").orElse(null) == AnimationFormat.PLAYER_ANIMATOR);
/*     */   }
/*     */   
/*     */   @NotNull
/*     */   public String toString() {
/* 143 */     return this.data.toString();
/*     */   }
/*     */ }


/* Location:              C:\Users\rapha\Downloads\aurora.jar!\META-INF\jars\player-animation-library-wJLdv4ZQ.jar!\com\zigythebird\playeranimcore\animation\ExtraAnimationData.class
 * Java compiler version: 21 (65.0)
 * JD-Core Version:       1.1.3
 */