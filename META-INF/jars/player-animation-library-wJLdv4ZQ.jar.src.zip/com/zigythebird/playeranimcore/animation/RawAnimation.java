/*     */ package com.zigythebird.playeranimcore.animation;
/*     */ 
/*     */ import com.zigythebird.playeranimcore.enums.AnimationStage;
/*     */ import it.unimi.dsi.fastutil.objects.ObjectArrayList;
/*     */ import java.util.List;
/*     */ import java.util.Objects;
/*     */ import org.jetbrains.annotations.Nullable;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class RawAnimation
/*     */ {
/*  46 */   private final List<Stage> animationList = (List<Stage>)new ObjectArrayList();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static RawAnimation begin() {
/*  57 */     return new RawAnimation();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public RawAnimation thenPlay(Animation animation) {
/*  67 */     return then(animation, Animation.LoopType.DEFAULT);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public RawAnimation thenLoop(Animation animation) {
/*  76 */     return then(animation, Animation.LoopType.LOOP);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public RawAnimation thenWait(int ticks) {
/*  87 */     this.animationList.add(new Stage(AnimationStage.WAIT, null, Animation.LoopType.PLAY_ONCE, ticks));
/*     */     
/*  89 */     return this;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public RawAnimation thenPlayAndHold(Animation animation) {
/*  99 */     return then(animation, Animation.LoopType.HOLD_ON_LAST_FRAME);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public RawAnimation thenPlayXTimes(Animation animation, int playCount) {
/* 110 */     for (int i = 0; i < playCount; i++) {
/* 111 */       then(animation, (i == playCount - 1) ? Animation.LoopType.DEFAULT : Animation.LoopType.PLAY_ONCE);
/*     */     }
/*     */     
/* 114 */     return this;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public RawAnimation then(Animation animation, Animation.LoopType loopType) {
/* 124 */     this.animationList.add(new Stage(animation, loopType));
/*     */     
/* 126 */     return this;
/*     */   }
/*     */   
/*     */   public List<Stage> getAnimationStages() {
/* 130 */     return this.animationList;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static RawAnimation copyOf(RawAnimation other) {
/* 142 */     RawAnimation newInstance = begin();
/*     */     
/* 144 */     newInstance.animationList.addAll(other.animationList);
/*     */     
/* 146 */     return newInstance;
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean equals(Object obj) {
/* 151 */     if (this == obj) {
/* 152 */       return true;
/*     */     }
/* 154 */     if (obj == null || getClass() != obj.getClass()) {
/* 155 */       return false;
/*     */     }
/* 157 */     return (hashCode() == obj.hashCode());
/*     */   }
/*     */ 
/*     */   
/*     */   public int hashCode() {
/* 162 */     return Objects.hash(new Object[] { this.animationList });
/*     */   }
/*     */   public static final class Stage extends Record {
/*     */     private final AnimationStage stage; @Nullable
/*     */     private final Animation animation; private final Animation.LoopType loopType; private final int additionalTicks;
/*     */     public final String toString() {
/*     */       // Byte code:
/*     */       //   0: aload_0
/*     */       //   1: <illegal opcode> toString : (Lcom/zigythebird/playeranimcore/animation/RawAnimation$Stage;)Ljava/lang/String;
/*     */       //   6: areturn
/*     */       // Line number table:
/*     */       //   Java source line number -> byte code offset
/*     */       //   #170	-> 0
/*     */       // Local variable table:
/*     */       //   start	length	slot	name	descriptor
/*     */       //   0	7	0	this	Lcom/zigythebird/playeranimcore/animation/RawAnimation$Stage;
/*     */     }
/* 170 */     public Stage(AnimationStage stage, @Nullable Animation animation, Animation.LoopType loopType, int additionalTicks) { this.stage = stage; this.animation = animation; this.loopType = loopType; this.additionalTicks = additionalTicks; } public AnimationStage stage() { return this.stage; } @Nullable public Animation animation() { return this.animation; } public Animation.LoopType loopType() { return this.loopType; } public int additionalTicks() { return this.additionalTicks; }
/*     */      public Stage(AnimationStage stage, Animation animation, Animation.LoopType loopType) {
/* 172 */       this(stage, animation, loopType, 0);
/*     */     }
/*     */     
/*     */     public Stage(Animation animation, Animation.LoopType loopType) {
/* 176 */       this(AnimationStage.ANIMATION, animation, loopType);
/*     */     }
/*     */ 
/*     */     
/*     */     public boolean equals(Object obj) {
/* 181 */       if (this == obj) {
/* 182 */         return true;
/*     */       }
/* 184 */       if (obj == null || getClass() != obj.getClass()) {
/* 185 */         return false;
/*     */       }
/* 187 */       return (hashCode() == obj.hashCode());
/*     */     }
/*     */ 
/*     */     
/*     */     public int hashCode() {
/* 192 */       return Objects.hash(new Object[] { this.stage, this.animation, this.loopType });
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\rapha\Downloads\aurora.jar!\META-INF\jars\player-animation-library-wJLdv4ZQ.jar!\com\zigythebird\playeranimcore\animation\RawAnimation.class
 * Java compiler version: 21 (65.0)
 * JD-Core Version:       1.1.3
 */