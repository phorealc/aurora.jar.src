/*    */ package com.zigythebird.playeranimcore.animation;
/*    */ 
/*    */ import com.zigythebird.playeranimcore.animation.keyframe.event.data.CustomInstructionKeyframeData;
/*    */ import com.zigythebird.playeranimcore.animation.keyframe.event.data.ParticleKeyframeData;
/*    */ import com.zigythebird.playeranimcore.animation.keyframe.event.data.SoundKeyframeData;
/*    */ import java.util.Arrays;
/*    */ import java.util.Objects;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public final class Keyframes
/*    */   extends Record
/*    */ {
/*    */   private final SoundKeyframeData[] sounds;
/*    */   private final ParticleKeyframeData[] particles;
/*    */   private final CustomInstructionKeyframeData[] customInstructions;
/*    */   
/*    */   public final String toString() {
/*    */     // Byte code:
/*    */     //   0: aload_0
/*    */     //   1: <illegal opcode> toString : (Lcom/zigythebird/playeranimcore/animation/Animation$Keyframes;)Ljava/lang/String;
/*    */     //   6: areturn
/*    */     // Line number table:
/*    */     //   Java source line number -> byte code offset
/*    */     //   #49	-> 0
/*    */     // Local variable table:
/*    */     //   start	length	slot	name	descriptor
/*    */     //   0	7	0	this	Lcom/zigythebird/playeranimcore/animation/Animation$Keyframes;
/*    */   }
/*    */   
/*    */   public final boolean equals(Object o) {
/*    */     // Byte code:
/*    */     //   0: aload_0
/*    */     //   1: aload_1
/*    */     //   2: <illegal opcode> equals : (Lcom/zigythebird/playeranimcore/animation/Animation$Keyframes;Ljava/lang/Object;)Z
/*    */     //   7: ireturn
/*    */     // Line number table:
/*    */     //   Java source line number -> byte code offset
/*    */     //   #49	-> 0
/*    */     // Local variable table:
/*    */     //   start	length	slot	name	descriptor
/*    */     //   0	8	0	this	Lcom/zigythebird/playeranimcore/animation/Animation$Keyframes;
/*    */     //   0	8	1	o	Ljava/lang/Object;
/*    */   }
/*    */   
/*    */   public Keyframes(SoundKeyframeData[] sounds, ParticleKeyframeData[] particles, CustomInstructionKeyframeData[] customInstructions) {
/* 49 */     this.sounds = sounds; this.particles = particles; this.customInstructions = customInstructions; } public SoundKeyframeData[] sounds() { return this.sounds; } public ParticleKeyframeData[] particles() { return this.particles; } public CustomInstructionKeyframeData[] customInstructions() { return this.customInstructions; }
/*    */   
/*    */   public int hashCode() {
/* 52 */     return Objects.hash(new Object[] { Integer.valueOf(Arrays.hashCode((Object[])this.sounds)), Integer.valueOf(Arrays.hashCode((Object[])this.particles)), Integer.valueOf(Arrays.hashCode((Object[])this.customInstructions)) });
/*    */   }
/*    */ }


/* Location:              C:\Users\rapha\Downloads\aurora.jar!\META-INF\jars\player-animation-library-wJLdv4ZQ.jar!\com\zigythebird\playeranimcore\animation\Animation$Keyframes.class
 * Java compiler version: 21 (65.0)
 * JD-Core Version:       1.1.3
 */