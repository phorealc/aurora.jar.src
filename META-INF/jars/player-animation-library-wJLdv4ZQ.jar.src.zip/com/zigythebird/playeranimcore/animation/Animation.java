/*     */ package com.zigythebird.playeranimcore.animation;
/*     */ 
/*     */ import com.google.gson.JsonElement;
/*     */ import com.google.gson.JsonPrimitive;
/*     */ import com.zigythebird.playeranimcore.animation.keyframe.BoneAnimation;
/*     */ import com.zigythebird.playeranimcore.animation.keyframe.event.data.CustomInstructionKeyframeData;
/*     */ import com.zigythebird.playeranimcore.animation.keyframe.event.data.ParticleKeyframeData;
/*     */ import com.zigythebird.playeranimcore.animation.keyframe.event.data.SoundKeyframeData;
/*     */ import com.zigythebird.playeranimcore.enums.AnimationStage;
/*     */ import com.zigythebird.playeranimcore.loading.UniversalAnimLoader;
/*     */ import com.zigythebird.playeranimcore.math.Vec3f;
/*     */ import java.util.Arrays;
/*     */ import java.util.Collections;
/*     */ import java.util.HashMap;
/*     */ import java.util.Map;
/*     */ import java.util.Objects;
/*     */ import java.util.Optional;
/*     */ import java.util.UUID;
/*     */ import java.util.concurrent.ConcurrentHashMap;
/*     */ import java.util.function.Supplier;
/*     */ import org.jetbrains.annotations.NotNull;
/*     */ import org.jetbrains.annotations.Nullable;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class Animation
/*     */   extends Record
/*     */   implements Supplier<UUID>
/*     */ {
/*     */   private final ExtraAnimationData data;
/*     */   private final float length;
/*     */   private final LoopType loopType;
/*     */   private final Map<String, BoneAnimation> boneAnimations;
/*     */   private final Keyframes keyFrames;
/*     */   private final Map<String, Vec3f> bones;
/*     */   private final Map<String, String> parents;
/*     */   
/*     */   public Animation(ExtraAnimationData data, float length, LoopType loopType, Map<String, BoneAnimation> boneAnimations, Keyframes keyFrames, Map<String, Vec3f> bones, Map<String, String> parents) {
/*  48 */     this.data = data; this.length = length; this.loopType = loopType; this.boneAnimations = boneAnimations; this.keyFrames = keyFrames; this.bones = bones; this.parents = parents; } public ExtraAnimationData data() { return this.data; } public float length() { return this.length; } public LoopType loopType() { return this.loopType; } public Map<String, BoneAnimation> boneAnimations() { return this.boneAnimations; } public Keyframes keyFrames() { return this.keyFrames; } public Map<String, Vec3f> bones() { return this.bones; } public Map<String, String> parents() { return this.parents; } public static final class Keyframes extends Record { private final SoundKeyframeData[] sounds; private final ParticleKeyframeData[] particles; private final CustomInstructionKeyframeData[] customInstructions;
/*  49 */     public Keyframes(SoundKeyframeData[] sounds, ParticleKeyframeData[] particles, CustomInstructionKeyframeData[] customInstructions) { this.sounds = sounds; this.particles = particles; this.customInstructions = customInstructions; } public final String toString() { // Byte code:
/*     */       //   0: aload_0
/*     */       //   1: <illegal opcode> toString : (Lcom/zigythebird/playeranimcore/animation/Animation$Keyframes;)Ljava/lang/String;
/*     */       //   6: areturn
/*     */       // Line number table:
/*     */       //   Java source line number -> byte code offset
/*     */       //   #49	-> 0
/*     */       // Local variable table:
/*     */       //   start	length	slot	name	descriptor
/*     */       //   0	7	0	this	Lcom/zigythebird/playeranimcore/animation/Animation$Keyframes; } public final boolean equals(Object o) { // Byte code:
/*     */       //   0: aload_0
/*     */       //   1: aload_1
/*     */       //   2: <illegal opcode> equals : (Lcom/zigythebird/playeranimcore/animation/Animation$Keyframes;Ljava/lang/Object;)Z
/*     */       //   7: ireturn
/*     */       // Line number table:
/*     */       //   Java source line number -> byte code offset
/*     */       //   #49	-> 0
/*     */       // Local variable table:
/*     */       //   start	length	slot	name	descriptor
/*     */       //   0	8	0	this	Lcom/zigythebird/playeranimcore/animation/Animation$Keyframes;
/*  49 */       //   0	8	1	o	Ljava/lang/Object; } public SoundKeyframeData[] sounds() { return this.sounds; } public ParticleKeyframeData[] particles() { return this.particles; } public CustomInstructionKeyframeData[] customInstructions() { return this.customInstructions; }
/*     */     
/*     */     public int hashCode() {
/*  52 */       return Objects.hash(new Object[] { Integer.valueOf(Arrays.hashCode((Object[])this.sounds)), Integer.valueOf(Arrays.hashCode((Object[])this.particles)), Integer.valueOf(Arrays.hashCode((Object[])this.customInstructions)) });
/*     */     } }
/*     */ 
/*     */   
/*     */   static Animation generateWaitAnimation(float length) {
/*  57 */     return new Animation(new ExtraAnimationData("name", AnimationStage.WAIT.name()), length, LoopType.PLAY_ONCE, 
/*  58 */         Collections.emptyMap(), UniversalAnimLoader.NO_KEYFRAMES, new HashMap<>(), new HashMap<>());
/*     */   }
/*     */   
/*     */   public boolean isPlayingAt(float tick) {
/*  62 */     return (this.loopType.shouldPlayAgain(null, this) || (tick < length() && tick > 0.0F));
/*     */   }
/*     */   
/*     */   @Nullable
/*     */   public BoneAnimation getBone(String id) {
/*  67 */     return this.boneAnimations.get(id);
/*     */   }
/*     */   
/*     */   public Optional<BoneAnimation> getBoneOptional(String id) {
/*  71 */     return Optional.ofNullable(getBone(id));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   class null
/*     */     implements LoopType
/*     */   {
/*     */     public boolean shouldPlayAgain(@Nullable AnimationController controller, Animation currentAnimation) {
/*  86 */       return currentAnimation.loopType().shouldPlayAgain(controller, currentAnimation);
/*     */     }
/*     */     
/*     */     public float restartFromTick(@Nullable AnimationController controller, Animation currentAnimation)
/*     */     {
/*  91 */       return currentAnimation.loopType().restartFromTick(controller, currentAnimation); } } @FunctionalInterface public static interface LoopType { public static final Map<String, LoopType> LOOP_TYPES = new ConcurrentHashMap<>(4); public static final LoopType DEFAULT = new LoopType() { public float restartFromTick(@Nullable AnimationController controller, Animation currentAnimation) { return currentAnimation.loopType().restartFromTick(controller, currentAnimation); } public boolean shouldPlayAgain(@Nullable AnimationController controller, Animation currentAnimation) {
/*     */           return currentAnimation.loopType().shouldPlayAgain(controller, currentAnimation);
/*     */         } }
/*  94 */     ; public static final LoopType PLAY_ONCE = register("play_once", register("false", (controller, currentAnimation) -> false)); public static final LoopType HOLD_ON_LAST_FRAME;
/*  95 */     static { HOLD_ON_LAST_FRAME = register("hold_on_last_frame", (controller, currentAnimation) -> {
/*     */             if (controller != null)
/*     */               controller.pause(); 
/*     */             return true;
/*  99 */           }); } public static final LoopType LOOP = register("loop", register("true", (controller, currentAnimation) -> true));
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     default float restartFromTick(@Nullable AnimationController controller, Animation currentAnimation) {
/* 118 */       return 0.0F;
/*     */     }
/*     */     
/*     */     static LoopType returnToTickLoop(final float tick) {
/* 122 */       return new LoopType()
/*     */         {
/*     */           public boolean shouldPlayAgain(@Nullable AnimationController controller, Animation currentAnimation) {
/* 125 */             return true;
/*     */           }
/*     */ 
/*     */           
/*     */           public float restartFromTick(@Nullable AnimationController controller, Animation currentAnimation) {
/* 130 */             return tick;
/*     */           }
/*     */         };
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     static LoopType fromJson(JsonElement json) {
/* 145 */       if (json == null || !json.isJsonPrimitive()) {
/* 146 */         return PLAY_ONCE;
/*     */       }
/* 148 */       JsonPrimitive primitive = json.getAsJsonPrimitive();
/*     */       
/* 150 */       if (primitive.isBoolean()) {
/* 151 */         return primitive.getAsBoolean() ? LOOP : PLAY_ONCE;
/*     */       }
/* 153 */       if (primitive.isString()) {
/* 154 */         return fromString(primitive.getAsString());
/*     */       }
/* 156 */       return PLAY_ONCE;
/*     */     }
/*     */     
/*     */     static LoopType fromString(String name) {
/* 160 */       return LOOP_TYPES.getOrDefault(name, PLAY_ONCE);
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     static LoopType register(String name, LoopType loopType) {
/* 174 */       LOOP_TYPES.put(name, loopType);
/*     */       
/* 176 */       return loopType;
/*     */     } boolean shouldPlayAgain(@Nullable AnimationController param1AnimationController, Animation param1Animation); } class null implements LoopType { public boolean shouldPlayAgain(@Nullable AnimationController controller, Animation currentAnimation) { return true; } public float restartFromTick(@Nullable AnimationController controller, Animation currentAnimation) {
/*     */       return tick;
/*     */     } }
/*     */   public boolean equals(Object o) {
/*     */     Animation animation;
/* 182 */     if (o instanceof Animation) { animation = (Animation)o; } else { return false; }
/* 183 */      return (Float.compare(this.length, animation.length) == 0 && Objects.equals(this.keyFrames, animation.keyFrames) && Objects.equals(this.bones, animation.bones) && Objects.equals(this.parents, animation.parents) && Objects.equals(this.boneAnimations, animation.boneAnimations));
/*     */   }
/*     */ 
/*     */   
/*     */   public int hashCode() {
/* 188 */     return Objects.hash(new Object[] { Float.valueOf(this.length), this.boneAnimations, this.keyFrames, this.bones, this.parents });
/*     */   }
/*     */   
/*     */   private UUID generateUuid() {
/* 192 */     return generateUuid(new int[] {
/* 193 */           Float.floatToIntBits(this.length), this.boneAnimations
/* 194 */           .hashCode(), this.keyFrames
/* 195 */           .hashCode(), this.bones
/* 196 */           .hashCode(), this.parents
/* 197 */           .hashCode()
/*     */         });
/*     */   }
/*     */   
/*     */   private static UUID generateUuid(int... hashes) {
/* 202 */     long mostSigBits = 17L;
/* 203 */     long leastSigBits = 31L;
/* 204 */     for (int hash : hashes) {
/* 205 */       mostSigBits = 31L * mostSigBits + hash;
/* 206 */       leastSigBits = 37L * leastSigBits + hash;
/*     */     } 
/* 208 */     return new UUID(mostSigBits, leastSigBits);
/*     */   }
/*     */   
/*     */   public UUID uuid() {
/* 212 */     if (!data().has("uuid"))
/* 213 */     { data().put("uuid", generateUuid()); }
/* 214 */     else { Object object = data().getRaw("uuid"); if (object instanceof String) { String str = (String)object;
/* 215 */         data().put("uuid", UUID.fromString(str)); }
/*     */        }
/* 217 */      return data().<UUID>get("uuid").orElseThrow();
/*     */   }
/*     */   
/*     */   @NotNull
/*     */   public String toString() {
/* 222 */     return "Animation{data=" + String.valueOf(this.data) + ", length=" + this.length + "}";
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public UUID get() {
/* 230 */     return uuid();
/*     */   }
/*     */   
/*     */   @NotNull
/*     */   public String getNameOrId() {
/* 235 */     return Objects.<String>requireNonNullElseGet(data().name(), () -> uuid().toString());
/*     */   }
/*     */ }


/* Location:              C:\Users\rapha\Downloads\aurora.jar!\META-INF\jars\player-animation-library-wJLdv4ZQ.jar!\com\zigythebird\playeranimcore\animation\Animation.class
 * Java compiler version: 21 (65.0)
 * JD-Core Version:       1.1.3
 */