package com.zigythebird.playeranimcore.animation.layered.modifier;

@FunctionalInterface
public interface EasingFunction {
  float ease(String paramString, float paramFloat);
}


/* Location:              C:\Users\rapha\Downloads\aurora.jar!\META-INF\jars\player-animation-library-wJLdv4ZQ.jar!\com\zigythebird\playeranimcore\animation\layered\modifier\AbstractFadeModifier$EasingFunction.class
 * Java compiler version: 21 (65.0)
 * JD-Core Version:       1.1.3
 */