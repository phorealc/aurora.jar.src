/*    */ package com.zigythebird.playeranimcore.animation.layered.modifier;
/*    */ 
/*    */ import com.zigythebird.playeranimcore.animation.AnimationController;
/*    */ import com.zigythebird.playeranimcore.animation.layered.AnimationContainer;
/*    */ import com.zigythebird.playeranimcore.animation.layered.IAnimation;
/*    */ import org.jetbrains.annotations.Nullable;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public abstract class AbstractModifier
/*    */   extends AnimationContainer<IAnimation>
/*    */ {
/*    */   protected IAnimation host;
/*    */   
/*    */   public void setHost(IAnimation host) {
/* 36 */     this.host = host;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   @Nullable
/*    */   protected AnimationController getController() {
/* 44 */     IAnimation iAnimation = this.host; if (iAnimation instanceof AnimationController) return (AnimationController)iAnimation; 
/* 45 */     return null;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public boolean canRemove() {
/* 55 */     return false;
/*    */   }
/*    */ }


/* Location:              C:\Users\rapha\Downloads\aurora.jar!\META-INF\jars\player-animation-library-wJLdv4ZQ.jar!\com\zigythebird\playeranimcore\animation\layered\modifier\AbstractModifier.class
 * Java compiler version: 21 (65.0)
 * JD-Core Version:       1.1.3
 */