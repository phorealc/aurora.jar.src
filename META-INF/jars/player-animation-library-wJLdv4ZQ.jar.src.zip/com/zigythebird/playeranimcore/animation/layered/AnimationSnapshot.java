/*    */ package com.zigythebird.playeranimcore.animation.layered;
/*    */ 
/*    */ import com.zigythebird.playeranimcore.bones.PlayerAnimBone;
/*    */ import java.util.Map;
/*    */ 
/*    */ public final class AnimationSnapshot extends Record implements IAnimation {
/*    */   private final Map<String, AdvancedBoneSnapshot> snapshots;
/*    */   
/*  9 */   public AnimationSnapshot(Map<String, AdvancedBoneSnapshot> snapshots) { this.snapshots = snapshots; } public final int hashCode() { // Byte code:
/*    */     //   0: aload_0
/*    */     //   1: <illegal opcode> hashCode : (Lcom/zigythebird/playeranimcore/animation/layered/AnimationSnapshot;)I
/*    */     //   6: ireturn
/*    */     // Line number table:
/*    */     //   Java source line number -> byte code offset
/*    */     //   #9	-> 0
/*    */     // Local variable table:
/*    */     //   start	length	slot	name	descriptor
/*  9 */     //   0	7	0	this	Lcom/zigythebird/playeranimcore/animation/layered/AnimationSnapshot; } public Map<String, AdvancedBoneSnapshot> snapshots() { return this.snapshots; } public final boolean equals(Object o) {
/*    */     // Byte code:
/*    */     //   0: aload_0
/*    */     //   1: aload_1
/*    */     //   2: <illegal opcode> equals : (Lcom/zigythebird/playeranimcore/animation/layered/AnimationSnapshot;Ljava/lang/Object;)Z
/*    */     //   7: ireturn
/*    */     // Line number table:
/*    */     //   Java source line number -> byte code offset
/*    */     //   #9	-> 0
/*    */     // Local variable table:
/*    */     //   start	length	slot	name	descriptor
/*    */     //   0	8	0	this	Lcom/zigythebird/playeranimcore/animation/layered/AnimationSnapshot;
/*    */     //   0	8	1	o	Ljava/lang/Object;
/*    */   } public boolean isActive() {
/* 12 */     return true;
/*    */   }
/*    */ 
/*    */   
/*    */   public PlayerAnimBone get3DTransform(@NotNull PlayerAnimBone bone) {
/* 17 */     if (this.snapshots.containsKey(bone.getName())) {
/* 18 */       return bone.copySnapshotSafe(this.snapshots.get(bone.getName()));
/*    */     }
/* 20 */     return bone;
/*    */   }
/*    */   
/*    */   @NotNull
/*    */   public String toString() {
/* 25 */     return "AnimationSnapshot{snapshots=" + String.valueOf(this.snapshots) + "}";
/*    */   }
/*    */ }


/* Location:              C:\Users\rapha\Downloads\aurora.jar!\META-INF\jars\player-animation-library-wJLdv4ZQ.jar!\com\zigythebird\playeranimcore\animation\layered\AnimationSnapshot.class
 * Java compiler version: 21 (65.0)
 * JD-Core Version:       1.1.3
 */