/*    */ package com.zigythebird.playeranimcore.animation.layered.modifier;
/*    */ 
/*    */ import com.zigythebird.playeranimcore.animation.AnimationData;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class SpeedModifier
/*    */   extends AbstractModifier
/*    */ {
/*    */   public float speed;
/* 37 */   private float delta = 0.0F;
/*    */   
/* 39 */   private float shiftedDelta = 0.0F;
/*    */   
/*    */   public SpeedModifier(float speed) {
/* 42 */     if (!Float.isFinite(speed)) throw new IllegalArgumentException("Speed must be a finite number"); 
/* 43 */     this.speed = speed;
/*    */   }
/*    */ 
/*    */   
/*    */   public void tick(AnimationData state) {
/* 48 */     float delta = 1.0F - this.delta;
/* 49 */     this.delta = 0.0F;
/* 50 */     step(delta, state);
/*    */   }
/*    */ 
/*    */   
/*    */   public void setupAnim(AnimationData state) {
/* 55 */     float delta = state.getPartialTick() - this.delta;
/* 56 */     this.delta = state.getPartialTick();
/* 57 */     step(delta, state);
/* 58 */     super.setupAnim(state);
/*    */   }
/*    */   
/*    */   protected void step(float delta, AnimationData state) {
/* 62 */     delta *= this.speed;
/* 63 */     delta += this.shiftedDelta;
/* 64 */     while (delta > 1.0F) {
/* 65 */       delta--;
/* 66 */       super.tick(state);
/*    */     } 
/* 68 */     state.setPartialTick(delta);
/* 69 */     this.shiftedDelta = delta;
/*    */   }
/*    */ 
/*    */   
/*    */   public String toString() {
/* 74 */     return "SpeedModifier{speed=" + this.speed + ", anim=" + String.valueOf(this.anim) + "}";
/*    */   }
/*    */ }


/* Location:              C:\Users\rapha\Downloads\aurora.jar!\META-INF\jars\player-animation-library-wJLdv4ZQ.jar!\com\zigythebird\playeranimcore\animation\layered\modifier\SpeedModifier.class
 * Java compiler version: 21 (65.0)
 * JD-Core Version:       1.1.3
 */