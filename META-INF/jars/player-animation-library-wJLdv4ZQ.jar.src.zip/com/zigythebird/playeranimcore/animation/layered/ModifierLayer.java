/*     */ package com.zigythebird.playeranimcore.animation.layered;
/*     */ 
/*     */ import com.zigythebird.playeranimcore.animation.AnimationData;
/*     */ import com.zigythebird.playeranimcore.animation.layered.modifier.AbstractFadeModifier;
/*     */ import com.zigythebird.playeranimcore.animation.layered.modifier.AbstractModifier;
/*     */ import com.zigythebird.playeranimcore.api.firstPerson.FirstPersonConfiguration;
/*     */ import com.zigythebird.playeranimcore.api.firstPerson.FirstPersonMode;
/*     */ import com.zigythebird.playeranimcore.bones.PlayerAnimBone;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Collections;
/*     */ import java.util.Iterator;
/*     */ import java.util.List;
/*     */ import java.util.function.Predicate;
/*     */ import org.jetbrains.annotations.NotNull;
/*     */ import org.jetbrains.annotations.Nullable;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ModifierLayer<T extends IAnimation>
/*     */   implements IAnimation
/*     */ {
/*  26 */   protected final List<AbstractModifier> modifiers = new ArrayList<>();
/*     */   
/*     */   @Nullable
/*     */   T animation;
/*     */   
/*     */   public ModifierLayer(@Nullable T animation, AbstractModifier... modifiers) {
/*  32 */     this.animation = animation;
/*  33 */     Collections.addAll(this.modifiers, modifiers);
/*     */   }
/*     */   
/*     */   public ModifierLayer() {
/*  37 */     this(null, new AbstractModifier[0]);
/*     */   }
/*     */   @Nullable
/*     */   public T getAnimation() {
/*  41 */     return this.animation;
/*     */   }
/*     */ 
/*     */   
/*     */   public void tick(AnimationData state) {
/*  46 */     for (int i = 0; i < this.modifiers.size(); i++) {
/*  47 */       if (((AbstractModifier)this.modifiers.get(i)).canRemove()) {
/*  48 */         removeModifier(i--);
/*     */       }
/*     */     } 
/*  51 */     if (this.modifiers.size() > 0)
/*  52 */     { ((AbstractModifier)this.modifiers.get(0)).tick(state); }
/*  53 */     else if (this.animation != null) { this.animation.tick(state); }
/*     */   
/*     */   }
/*     */   public void addModifier(@NotNull AbstractModifier modifier, int idx) {
/*  57 */     modifier.setHost(this);
/*  58 */     this.modifiers.add(idx, modifier);
/*  59 */     linkModifiers();
/*     */   }
/*     */   
/*     */   public void addModifierBefore(@NotNull AbstractModifier modifier) {
/*  63 */     addModifier(modifier, 0);
/*     */   }
/*     */   
/*     */   public void addModifierLast(@NotNull AbstractModifier modifier) {
/*  67 */     addModifier(modifier, this.modifiers.size());
/*     */   }
/*     */   
/*     */   public void removeModifier(int idx) {
/*  71 */     this.modifiers.remove(idx);
/*  72 */     linkModifiers();
/*     */   }
/*     */   
/*     */   public void removeAllModifiers() {
/*  76 */     this.modifiers.clear();
/*     */   }
/*     */   
/*     */   public int getModifierCount() {
/*  80 */     return this.modifiers.size();
/*     */   }
/*     */   @Nullable
/*     */   public AbstractModifier getModifier(int idx) {
/*     */     try {
/*  85 */       return this.modifiers.get(idx);
/*  86 */     } catch (IndexOutOfBoundsException e) {
/*  87 */       return null;
/*     */     } 
/*     */   }
/*     */   
/*     */   public boolean removeModifierIf(Predicate<? super AbstractModifier> predicate) {
/*  92 */     return this.modifiers.removeIf(predicate);
/*     */   }
/*     */   
/*     */   public void setAnimation(@Nullable T animation) {
/*  96 */     this.animation = animation;
/*  97 */     linkModifiers();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void replaceAnimationWithFade(@NotNull AbstractFadeModifier fadeModifier, @Nullable T newAnimation) {
/* 107 */     replaceAnimationWithFade(fadeModifier, newAnimation, true);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void replaceAnimationWithFade(@NotNull AbstractFadeModifier fadeModifier, @Nullable T newAnimation, boolean fadeFromNothing) {
/* 117 */     if (fadeFromNothing || (getAnimation() != null && getAnimation().isActive())) {
/* 118 */       fadeModifier.setTransitionAnimation((IAnimation)getAnimation());
/* 119 */       addModifierLast((AbstractModifier)fadeModifier);
/*     */     } 
/* 121 */     setAnimation(newAnimation);
/*     */   }
/*     */   
/*     */   public int size() {
/* 125 */     return this.modifiers.size();
/*     */   }
/*     */   
/*     */   protected void linkModifiers() {
/* 129 */     Iterator<AbstractModifier> modifierIterator = this.modifiers.iterator();
/* 130 */     if (modifierIterator.hasNext()) {
/* 131 */       AbstractModifier tmp = modifierIterator.next();
/* 132 */       while (modifierIterator.hasNext()) {
/* 133 */         AbstractModifier tmp2 = modifierIterator.next();
/* 134 */         tmp.setAnim((IAnimation)tmp2);
/* 135 */         tmp = tmp2;
/*     */       } 
/* 137 */       tmp.setAnim((IAnimation)this.animation);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isActive() {
/* 144 */     if (!this.modifiers.isEmpty())
/* 145 */       return ((AbstractModifier)this.modifiers.get(0)).isActive(); 
/* 146 */     if (this.animation != null) return this.animation.isActive(); 
/* 147 */     return false;
/*     */   }
/*     */ 
/*     */   
/*     */   public PlayerAnimBone get3DTransform(@NotNull PlayerAnimBone bone) {
/* 152 */     if (!this.modifiers.isEmpty())
/* 153 */       return ((AbstractModifier)this.modifiers.get(0)).get3DTransform(bone); 
/* 154 */     if (this.animation != null) return this.animation.get3DTransform(bone); 
/* 155 */     return bone;
/*     */   }
/*     */ 
/*     */   
/*     */   public void setupAnim(AnimationData state) {
/* 160 */     if (!this.modifiers.isEmpty())
/* 161 */     { ((AbstractModifier)this.modifiers.get(0)).setupAnim(state); }
/* 162 */     else if (this.animation != null) { this.animation.setupAnim(state); }
/*     */   
/*     */   }
/*     */   @NotNull
/*     */   public FirstPersonMode getFirstPersonMode() {
/* 167 */     if (!this.modifiers.isEmpty())
/* 168 */       return ((AbstractModifier)this.modifiers.get(0)).getFirstPersonMode(); 
/* 169 */     if (this.animation != null) return this.animation.getFirstPersonMode(); 
/* 170 */     return super.getFirstPersonMode();
/*     */   }
/*     */   
/*     */   @NotNull
/*     */   public FirstPersonConfiguration getFirstPersonConfiguration() {
/* 175 */     if (!this.modifiers.isEmpty())
/* 176 */       return ((AbstractModifier)this.modifiers.get(0)).getFirstPersonConfiguration(); 
/* 177 */     if (this.animation != null) return this.animation.getFirstPersonConfiguration(); 
/* 178 */     return super.getFirstPersonConfiguration();
/*     */   }
/*     */ 
/*     */   
/*     */   public String toString() {
/* 183 */     return "ModifierLayer{modifiers=" + String.valueOf(this.modifiers) + ", animation=" + String.valueOf(this.animation) + "}";
/*     */   }
/*     */ }


/* Location:              C:\Users\rapha\Downloads\aurora.jar!\META-INF\jars\player-animation-library-wJLdv4ZQ.jar!\com\zigythebird\playeranimcore\animation\layered\ModifierLayer.class
 * Java compiler version: 21 (65.0)
 * JD-Core Version:       1.1.3
 */