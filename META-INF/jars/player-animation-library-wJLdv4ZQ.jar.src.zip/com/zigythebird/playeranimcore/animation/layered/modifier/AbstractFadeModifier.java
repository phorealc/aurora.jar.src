/*     */ package com.zigythebird.playeranimcore.animation.layered.modifier;
/*     */ 
/*     */ import com.zigythebird.playeranimcore.PlayerAnimLib;
/*     */ import com.zigythebird.playeranimcore.animation.AnimationController;
/*     */ import com.zigythebird.playeranimcore.animation.AnimationData;
/*     */ import com.zigythebird.playeranimcore.animation.layered.IAnimation;
/*     */ import com.zigythebird.playeranimcore.bones.PlayerAnimBone;
/*     */ import com.zigythebird.playeranimcore.easing.EasingType;
/*     */ import com.zigythebird.playeranimcore.enums.FadeType;
/*     */ import org.jetbrains.annotations.NotNull;
/*     */ import org.jetbrains.annotations.Nullable;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class AbstractFadeModifier
/*     */   extends AbstractModifier
/*     */ {
/*     */   protected int length;
/*     */   protected int time;
/*     */   protected float tickDelta;
/*     */   
/*     */   public void setTransitionAnimation(@Nullable IAnimation transitionAnimation) {
/*  48 */     this.transitionAnimation = transitionAnimation;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Nullable
/*  55 */   protected IAnimation transitionAnimation = null;
/*     */ 
/*     */   
/*     */   protected AbstractFadeModifier(int length) {
/*  59 */     this.length = length;
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean isActive() {
/*  64 */     return (super.isActive() || (this.transitionAnimation != null && this.transitionAnimation.isActive()));
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean canRemove() {
/*  69 */     return (getFadeType() == FadeType.FADE_IN && calculateProgress(this.tickDelta, (String)null) >= 1.0F);
/*     */   }
/*     */ 
/*     */   
/*     */   public void setupAnim(AnimationData state) {
/*  74 */     super.setupAnim(state);
/*  75 */     if (this.transitionAnimation != null) this.transitionAnimation.setupAnim(state); 
/*  76 */     this.tickDelta = state.getPartialTick();
/*     */   }
/*     */ 
/*     */   
/*     */   public void tick(AnimationData state) {
/*  81 */     super.tick(state);
/*  82 */     if (this.transitionAnimation != null) this.transitionAnimation.tick(state); 
/*  83 */     this.time++;
/*     */   }
/*     */ 
/*     */   
/*     */   public PlayerAnimBone get3DTransform(@NotNull PlayerAnimBone bone) {
/*  88 */     if (calculateProgress(this.tickDelta, bone.getName()) > 1.0F) {
/*  89 */       return super.get3DTransform(bone);
/*     */     }
/*  91 */     PlayerAnimBone copy2 = new PlayerAnimBone(bone.getName());
/*  92 */     copy2.copyOtherBone(bone);
/*  93 */     super.get3DTransform(copy2);
/*  94 */     float a = getAlpha(copy2.getName(), calculateProgress(this.tickDelta, bone.getName()));
/*  95 */     if (getFadeType() == FadeType.FADE_IN && 
/*  96 */       this.transitionAnimation != null && this.transitionAnimation.isActive()) this.transitionAnimation.get3DTransform(bone);
/*     */     
/*  98 */     return bone.scale(1.0F - a).add(copy2.scale(a));
/*     */   }
/*     */   
/*     */   protected float calculateProgress(float f, String boneName) {
/* 102 */     float actualTime = this.time + f;
/* 103 */     if (getFadeType() == FadeType.FADE_IN) return actualTime / this.length; 
/* 104 */     float endTime = getEndTime(boneName);
/* 105 */     if (actualTime >= endTime) return 0.0F; 
/* 106 */     if (actualTime < endTime - this.length) return 1.0F; 
/* 107 */     return (endTime - actualTime) / this.length;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected abstract float getAlpha(String paramString, float paramFloat);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected abstract FadeType getFadeType();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected float getEndTime(String boneName) {
/* 128 */     AnimationController animationController = getController(); if (animationController instanceof AnimationController) { AnimationController controller = animationController; if (controller.getCurrentAnimation() != null)
/* 129 */         return controller.getCurrentAnimation().animation().length();  }
/*     */     
/* 131 */     PlayerAnimLib.LOGGER.debug("The fade out modifier doesn't work on animations that aren't AnimationController instances! Please override the getEndTime method.");
/* 132 */     return 0.0F;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static AbstractFadeModifier standardFadeIn(int length, EasingType ease) {
/* 139 */     return standardFadeIn(length, ease, (Float)null);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static AbstractFadeModifier standardFadeIn(int length, EasingType ease, @Nullable Float easingVariable) {
/* 146 */     return standardFade(length, ease, easingVariable, FadeType.FADE_IN);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static AbstractFadeModifier functionalFadeIn(int length, EasingFunction function) {
/* 153 */     return functionalFade(length, function, FadeType.FADE_IN);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static AbstractFadeModifier standardFadeOut(int length, EasingType ease) {
/* 160 */     return standardFadeOut(length, ease, (Float)null);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static AbstractFadeModifier standardFadeOut(int length, EasingType ease, @Nullable Float easingVariable) {
/* 167 */     return standardFade(length, ease, easingVariable, FadeType.FADE_OUT);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static AbstractFadeModifier functionalFadeOut(int length, EasingFunction function) {
/* 174 */     return functionalFade(length, function, FadeType.FADE_OUT);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static AbstractFadeModifier standardFade(int length, final EasingType ease, @Nullable final Float easingVariable, final FadeType fadeType) {
/* 185 */     return new AbstractFadeModifier(length)
/*     */       {
/*     */         protected float getAlpha(String boneName, float progress) {
/* 188 */           return ((Float)ease.buildTransformer(easingVariable).apply(Float.valueOf(progress))).floatValue();
/*     */         }
/*     */ 
/*     */         
/*     */         protected FadeType getFadeType() {
/* 193 */           return fadeType;
/*     */         }
/*     */       };
/*     */   }
/*     */   
/*     */   @FunctionalInterface
/*     */   public static interface EasingFunction
/*     */   {
/*     */     float ease(String param1String, float param1Float);
/*     */   }
/*     */   
/*     */   public static AbstractFadeModifier functionalFade(int length, final EasingFunction function, final FadeType fadeType) {
/* 205 */     return new AbstractFadeModifier(length)
/*     */       {
/*     */         protected float getAlpha(String boneName, float progress) {
/* 208 */           return function.ease(boneName, progress);
/*     */         }
/*     */ 
/*     */         
/*     */         protected FadeType getFadeType() {
/* 213 */           return fadeType;
/*     */         }
/*     */       };
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String toString() {
/* 225 */     return "AbstractFadeModifier{anim=" + String.valueOf(this.anim) + ", length=" + this.length + ", transitionAnimation=" + String.valueOf(this.transitionAnimation) + "}";
/*     */   }
/*     */ }


/* Location:              C:\Users\rapha\Downloads\aurora.jar!\META-INF\jars\player-animation-library-wJLdv4ZQ.jar!\com\zigythebird\playeranimcore\animation\layered\modifier\AbstractFadeModifier.class
 * Java compiler version: 21 (65.0)
 * JD-Core Version:       1.1.3
 */