/*     */ package com.zigythebird.playeranimcore.animation.layered.modifier;
/*     */ 
/*     */ import com.zigythebird.playeranimcore.animation.AnimationController;
/*     */ import com.zigythebird.playeranimcore.animation.AnimationData;
/*     */ import com.zigythebird.playeranimcore.bones.PlayerAnimBone;
/*     */ import com.zigythebird.playeranimcore.math.Vec3f;
/*     */ import java.util.Objects;
/*     */ import java.util.Optional;
/*     */ import java.util.function.BiFunction;
/*     */ import java.util.function.Function;
/*     */ import org.jetbrains.annotations.NotNull;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class AdjustmentModifier
/*     */   extends AbstractModifier
/*     */ {
/*     */   public static final class PartModifier
/*     */   {
/*     */     private final Vec3f rotation;
/*     */     private final Vec3f scale;
/*     */     private final Vec3f offset;
/*     */     
/*     */     public PartModifier(Vec3f rotation, Vec3f offset) {
/*  86 */       this(rotation, Vec3f.ZERO, offset);
/*     */     }
/*     */     
/*     */     public PartModifier(Vec3f rotation, Vec3f scale, Vec3f offset) {
/*  90 */       this.rotation = rotation;
/*  91 */       this.scale = scale;
/*  92 */       this.offset = offset;
/*     */     }
/*     */     
/*     */     public Vec3f rotation() {
/*  96 */       return this.rotation;
/*     */     }
/*     */     
/*     */     public Vec3f scale() {
/* 100 */       return this.scale;
/*     */     }
/*     */     
/*     */     public Vec3f offset() {
/* 104 */       return this.offset;
/*     */     }
/*     */ 
/*     */     
/*     */     public boolean equals(Object obj) {
/* 109 */       if (obj == this) return true; 
/* 110 */       if (obj == null || obj.getClass() != getClass()) return false; 
/* 111 */       PartModifier that = (PartModifier)obj;
/* 112 */       return (Objects.equals(this.rotation, that.rotation) && 
/* 113 */         Objects.equals(this.scale, that.scale) && 
/* 114 */         Objects.equals(this.offset, that.offset));
/*     */     }
/*     */ 
/*     */     
/*     */     public int hashCode() {
/* 119 */       return Objects.hash(new Object[] { this.rotation, this.scale, this.offset });
/*     */     }
/*     */ 
/*     */     
/*     */     public String toString() {
/* 124 */       return "PartModifier[rotation=" + String.valueOf(this.rotation) + ", scale=" + String.valueOf(this.scale) + ", offset=" + String.valueOf(this.offset) + "]";
/*     */     }
/*     */   }
/*     */   
/*     */   public boolean fadeIn = true;
/*     */   
/*     */   public boolean fadeOut = true;
/*     */   
/*     */   public boolean enabled = true;
/*     */   
/*     */   private AnimationData data;
/*     */   
/*     */   protected BiFunction<String, AnimationData, Optional<PartModifier>> source;
/*     */   
/*     */   protected int instructedFadeout;
/*     */   
/*     */   private int remainingFadeout;
/*     */ 
/*     */   
/*     */   public AdjustmentModifier(Function<String, Optional<PartModifier>> source) {
/* 144 */     this((name, data) -> (Optional)source.apply(name));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void tick(AnimationData state) {
/* 153 */     super.tick(state);
/* 154 */     this.data = state;
/*     */     
/* 156 */     if (this.remainingFadeout > 0) {
/* 157 */       this.remainingFadeout--;
/* 158 */       if (this.remainingFadeout <= 0) {
/* 159 */         this.instructedFadeout = 0;
/*     */       }
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public void setupAnim(AnimationData state) {
/* 166 */     super.setupAnim(state);
/* 167 */     this.data = state;
/*     */   }
/*     */   public AdjustmentModifier(BiFunction<String, AnimationData, Optional<PartModifier>> source) {
/* 170 */     this.instructedFadeout = 0;
/* 171 */     this.remainingFadeout = 0;
/*     */     this.source = source;
/*     */   } public void fadeOut(int fadeOut) {
/* 174 */     this.instructedFadeout = fadeOut;
/* 175 */     this.remainingFadeout = fadeOut + 1;
/*     */   }
/*     */   
/*     */   protected float getFadeOut(float delta) {
/* 179 */     float fadeOut = 1.0F;
/* 180 */     if (this.remainingFadeout > 0 && this.instructedFadeout > 0) {
/* 181 */       float current = Math.max(this.remainingFadeout - delta, 0.0F);
/* 182 */       fadeOut = current / this.instructedFadeout;
/* 183 */       fadeOut = Math.min(fadeOut, 1.0F);
/* 184 */       return fadeOut;
/*     */     } 
/* 186 */     if (this.fadeOut) { AnimationController animationController = getController(); if (animationController instanceof AnimationController) { AnimationController controller = animationController; if (controller.getCurrentAnimation() != null) {
/* 187 */           float stopTick = controller.getCurrentAnimation().animation().length();
/* 188 */           float endTick = ((Float)controller.getCurrentAnimation().animation().data().get("endTick").orElse(Float.valueOf(stopTick))).floatValue();
/* 189 */           float position = -1.0F * (controller.getAnimationTicks() - stopTick);
/* 190 */           float length = stopTick - endTick;
/* 191 */           if (length > 0.0F)
/* 192 */           { fadeOut = position / length;
/* 193 */             fadeOut = Math.min(fadeOut, 1.0F); } 
/*     */         }  }
/*     */        }
/* 196 */      return fadeOut;
/*     */   }
/*     */   
/*     */   protected float getFadeIn() {
/* 200 */     float fadeIn = 1.0F;
/* 201 */     if (this.fadeIn) { AnimationController animationController = getController(); if (animationController instanceof AnimationController) { AnimationController controller = animationController; if (controller.getCurrentAnimation() != null)
/* 202 */         { float beginTick = ((Float)controller.getCurrentAnimation().animation().data().get("beginTick").orElse(Float.valueOf(0.0F))).floatValue();
/* 203 */           fadeIn = (beginTick > 0.0F) ? (controller.getAnimationTicks() / beginTick) : 1.0F;
/* 204 */           fadeIn = Math.min(fadeIn, 1.0F); }  }
/*     */        }
/* 206 */      return fadeIn;
/*     */   }
/*     */ 
/*     */   
/*     */   public PlayerAnimBone get3DTransform(@NotNull PlayerAnimBone bone) {
/* 211 */     if (!this.enabled) {
/* 212 */       return super.get3DTransform(bone);
/*     */     }
/*     */     
/* 215 */     Optional<PartModifier> partModifier = this.source.apply(bone.getName(), this.data);
/*     */     
/* 217 */     float fade = getFadeIn() * getFadeOut(this.data.getPartialTick());
/* 218 */     if (partModifier.isPresent()) {
/* 219 */       super.get3DTransform(bone);
/* 220 */       transformBone(bone, partModifier.get(), fade);
/* 221 */       return bone;
/*     */     } 
/* 223 */     return super.get3DTransform(bone);
/*     */   }
/*     */   
/*     */   protected void transformBone(PlayerAnimBone bone, PartModifier partModifier, float fade) {
/* 227 */     Vec3f pos = partModifier.offset().mul(fade);
/* 228 */     Vec3f rot = partModifier.rotation().mul(fade);
/* 229 */     Vec3f scale = partModifier.scale().mul(fade);
/* 230 */     bone.updatePosition(pos.x() + bone.getPosX(), pos.y() + bone.getPosY(), pos.z() + bone.getPosZ());
/* 231 */     bone.updateRotation(rot.x() + bone.getRotX(), rot.y() + bone.getRotY(), rot.z() + bone.getRotZ());
/* 232 */     bone.updateScale(scale.x() + bone.getScaleX(), scale.y() + bone.getScaleY(), scale.z() + bone.getScaleZ());
/*     */   }
/*     */ 
/*     */   
/*     */   public String toString() {
/* 237 */     return "AdjustmentModifier{anim=" + String.valueOf(this.anim) + ", enabled=" + this.enabled + "}";
/*     */   }
/*     */ }


/* Location:              C:\Users\rapha\Downloads\aurora.jar!\META-INF\jars\player-animation-library-wJLdv4ZQ.jar!\com\zigythebird\playeranimcore\animation\layered\modifier\AdjustmentModifier.class
 * Java compiler version: 21 (65.0)
 * JD-Core Version:       1.1.3
 */