/*     */ package com.zigythebird.playeranimcore.animation.layered;
/*     */ 
/*     */ import com.zigythebird.playeranimcore.bones.PlayerAnimBone;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class PlayerBone
/*     */ {
/* 102 */   public Float offsetPosX = null;
/* 103 */   public Float offsetPosY = null;
/* 104 */   public Float offsetPosZ = null;
/*     */   
/* 106 */   public Float rotX = null;
/* 107 */   public Float rotY = null;
/* 108 */   public Float rotZ = null;
/*     */   
/* 110 */   public Float scaleX = null;
/* 111 */   public Float scaleY = null;
/* 112 */   public Float scaleZ = null;
/*     */   
/* 114 */   public Float bend = null;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setToInitialPose() {
/* 125 */     this.rotX = null;
/* 126 */     this.rotY = null;
/* 127 */     this.rotZ = null;
/*     */     
/* 129 */     this.offsetPosX = null;
/* 130 */     this.offsetPosY = null;
/* 131 */     this.offsetPosZ = null;
/*     */     
/* 133 */     this.scaleX = null;
/* 134 */     this.scaleY = null;
/* 135 */     this.scaleZ = null;
/*     */     
/* 137 */     this.bend = null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void enableAll() {
/* 144 */     this.rotX = Float.valueOf(0.0F);
/* 145 */     this.rotY = Float.valueOf(0.0F);
/* 146 */     this.rotZ = Float.valueOf(0.0F);
/*     */     
/* 148 */     this.offsetPosX = Float.valueOf(0.0F);
/* 149 */     this.offsetPosY = Float.valueOf(0.0F);
/* 150 */     this.offsetPosZ = Float.valueOf(0.0F);
/*     */     
/* 152 */     this.scaleX = Float.valueOf(1.0F);
/* 153 */     this.scaleY = Float.valueOf(1.0F);
/* 154 */     this.scaleZ = Float.valueOf(1.0F);
/*     */     
/* 156 */     this.bend = Float.valueOf(0.0F);
/*     */   }
/*     */   
/*     */   public PlayerAnimBone applyToBone(PlayerAnimBone bone) {
/* 160 */     if (this.offsetPosX != null)
/* 161 */       bone.setPosX(this.offsetPosX.floatValue()); 
/* 162 */     if (this.offsetPosY != null)
/* 163 */       bone.setPosY(this.offsetPosY.floatValue()); 
/* 164 */     if (this.offsetPosZ != null) {
/* 165 */       bone.setPosZ(this.offsetPosZ.floatValue());
/*     */     }
/* 167 */     if (this.rotX != null)
/* 168 */       bone.setRotX(this.rotX.floatValue()); 
/* 169 */     if (this.rotY != null)
/* 170 */       bone.setRotY(this.rotY.floatValue()); 
/* 171 */     if (this.rotZ != null) {
/* 172 */       bone.setRotZ(this.rotZ.floatValue());
/*     */     }
/* 174 */     if (this.scaleX != null)
/* 175 */       bone.setScaleX(this.scaleX.floatValue()); 
/* 176 */     if (this.scaleY != null)
/* 177 */       bone.setScaleY(this.scaleY.floatValue()); 
/* 178 */     if (this.scaleZ != null) {
/* 179 */       bone.setScaleZ(this.scaleZ.floatValue());
/*     */     }
/* 181 */     if (this.bend != null) {
/* 182 */       bone.setBend(this.bend.floatValue());
/*     */     }
/* 184 */     return bone;
/*     */   }
/*     */ }


/* Location:              C:\Users\rapha\Downloads\aurora.jar!\META-INF\jars\player-animation-library-wJLdv4ZQ.jar!\com\zigythebird\playeranimcore\animation\layered\PlayerAnimationFrame$PlayerBone.class
 * Java compiler version: 21 (65.0)
 * JD-Core Version:       1.1.3
 */