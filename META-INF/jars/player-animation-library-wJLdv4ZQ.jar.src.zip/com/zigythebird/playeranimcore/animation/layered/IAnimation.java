/*     */ package com.zigythebird.playeranimcore.animation.layered;
/*     */ 
/*     */ import com.zigythebird.playeranimcore.animation.AnimationData;
/*     */ import com.zigythebird.playeranimcore.api.firstPerson.FirstPersonConfiguration;
/*     */ import com.zigythebird.playeranimcore.api.firstPerson.FirstPersonMode;
/*     */ import com.zigythebird.playeranimcore.bones.PlayerAnimBone;
/*     */ import org.jetbrains.annotations.NotNull;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public interface IAnimation
/*     */ {
/*  34 */   public static final FirstPersonConfiguration DEFAULT_FIRST_PERSON_CONFIG = new FirstPersonConfiguration();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   default void tick(AnimationData state) {}
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   default void setupAnim(AnimationData state) {}
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   boolean isActive();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   default PlayerAnimBone get3DTransform(@NotNull PlayerAnimBone bone) {
/*  62 */     return bone;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @NotNull
/*     */   default FirstPersonMode getFirstPersonMode() {
/*  70 */     return FirstPersonMode.NONE;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @NotNull
/*     */   default FirstPersonConfiguration getFirstPersonConfiguration() {
/*  78 */     return DEFAULT_FIRST_PERSON_CONFIG;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   default boolean isFirstPersonFollowsCamera() {
/*  85 */     return false;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   default int getFirstPersonTransitionLength() {
/*  93 */     return 0;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   default boolean canRemove() {
/* 100 */     return false;
/*     */   }
/*     */ }


/* Location:              C:\Users\rapha\Downloads\aurora.jar!\META-INF\jars\player-animation-library-wJLdv4ZQ.jar!\com\zigythebird\playeranimcore\animation\layered\IAnimation.class
 * Java compiler version: 21 (65.0)
 * JD-Core Version:       1.1.3
 */