/*     */ package com.zigythebird.playeranimcore.animation.layered;
/*     */ 
/*     */ import com.zigythebird.playeranimcore.animation.AnimationData;
/*     */ import com.zigythebird.playeranimcore.api.firstPerson.FirstPersonConfiguration;
/*     */ import com.zigythebird.playeranimcore.api.firstPerson.FirstPersonMode;
/*     */ import com.zigythebird.playeranimcore.bones.PlayerAnimBone;
/*     */ import org.jetbrains.annotations.NotNull;
/*     */ import org.jetbrains.annotations.Nullable;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class AnimationContainer<T extends IAnimation>
/*     */   implements IAnimation
/*     */ {
/*     */   @Nullable
/*     */   protected T anim;
/*     */   
/*     */   public AnimationContainer(@Nullable T anim) {
/*  46 */     this.anim = anim;
/*     */   }
/*     */   
/*     */   public AnimationContainer() {
/*  50 */     this.anim = null;
/*     */   }
/*     */   
/*     */   public void setAnim(@Nullable T newAnim) {
/*  54 */     this.anim = newAnim;
/*     */   }
/*     */   @Nullable
/*     */   public T getAnim() {
/*  58 */     return this.anim;
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean isActive() {
/*  63 */     return (this.anim != null && this.anim.isActive());
/*     */   }
/*     */ 
/*     */   
/*     */   public void tick(AnimationData state) {
/*  68 */     if (this.anim != null) this.anim.tick(state);
/*     */   
/*     */   }
/*     */   
/*     */   public PlayerAnimBone get3DTransform(@NotNull PlayerAnimBone bone) {
/*  73 */     if (this.anim != null) return this.anim.get3DTransform(bone); 
/*  74 */     return bone;
/*     */   }
/*     */ 
/*     */   
/*     */   public void setupAnim(AnimationData state) {
/*  79 */     if (this.anim != null) this.anim.setupAnim(state); 
/*     */   }
/*     */   
/*     */   @NotNull
/*     */   public FirstPersonMode getFirstPersonMode() {
/*  84 */     return (this.anim != null) ? this.anim.getFirstPersonMode() : FirstPersonMode.NONE;
/*     */   }
/*     */   
/*     */   @NotNull
/*     */   public FirstPersonConfiguration getFirstPersonConfiguration() {
/*  89 */     return (this.anim != null) ? this.anim.getFirstPersonConfiguration() : super.getFirstPersonConfiguration();
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean isFirstPersonFollowsCamera() {
/*  94 */     return (this.anim != null) ? this.anim.isFirstPersonFollowsCamera() : super.isFirstPersonFollowsCamera();
/*     */   }
/*     */ 
/*     */   
/*     */   public int getFirstPersonTransitionLength() {
/*  99 */     return (this.anim != null) ? this.anim.getFirstPersonTransitionLength() : super.getFirstPersonTransitionLength();
/*     */   }
/*     */ 
/*     */   
/*     */   public String toString() {
/* 104 */     return "AnimationContainer{anim=" + String.valueOf(this.anim) + "}";
/*     */   }
/*     */ }


/* Location:              C:\Users\rapha\Downloads\aurora.jar!\META-INF\jars\player-animation-library-wJLdv4ZQ.jar!\com\zigythebird\playeranimcore\animation\layered\AnimationContainer.class
 * Java compiler version: 21 (65.0)
 * JD-Core Version:       1.1.3
 */