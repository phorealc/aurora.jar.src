/*    */ package com.zigythebird.playeranimcore.animation.layered.modifier;
/*    */ 
/*    */ import com.zigythebird.playeranimcore.api.firstPerson.FirstPersonConfiguration;
/*    */ import com.zigythebird.playeranimcore.bones.PlayerAnimBone;
/*    */ import java.util.Collections;
/*    */ import java.util.HashMap;
/*    */ import java.util.Map;
/*    */ import org.jetbrains.annotations.NotNull;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class MirrorModifier
/*    */   extends AbstractModifier
/*    */ {
/*    */   public static final Map<String, String> mirrorMap;
/*    */   public boolean enabled = true;
/*    */   
/*    */   public PlayerAnimBone get3DTransform(@NotNull PlayerAnimBone bone) {
/* 42 */     if (!this.enabled) return super.get3DTransform(bone);
/*    */     
/* 44 */     String modelName = bone.getName();
/* 45 */     if (mirrorMap.containsKey(modelName)) modelName = mirrorMap.get(modelName); 
/* 46 */     transformBone(bone);
/*    */     
/* 48 */     PlayerAnimBone newBone = new PlayerAnimBone(modelName);
/* 49 */     newBone.copyOtherBone(bone);
/* 50 */     newBone = super.get3DTransform(newBone);
/* 51 */     transformBone(newBone);
/* 52 */     bone.copyOtherBone(newBone);
/* 53 */     return bone;
/*    */   }
/*    */   
/*    */   @NotNull
/*    */   public FirstPersonConfiguration getFirstPersonConfiguration() {
/* 58 */     FirstPersonConfiguration configuration = super.getFirstPersonConfiguration();
/* 59 */     if (!this.enabled) return configuration; 
/* 60 */     return (new FirstPersonConfiguration())
/* 61 */       .setShowLeftArm(configuration.isShowRightArm())
/* 62 */       .setShowRightArm(configuration.isShowLeftArm())
/* 63 */       .setShowLeftItem(configuration.isShowRightItem())
/* 64 */       .setShowRightItem(configuration.isShowLeftItem());
/*    */   }
/*    */   
/*    */   protected void transformBone(PlayerAnimBone bone) {
/* 68 */     bone.positionX *= -1.0F;
/* 69 */     bone.rotY *= -1.0F;
/* 70 */     bone.rotZ *= -1.0F;
/* 71 */     bone.bend *= -1.0F;
/*    */   }
/*    */   
/*    */   static {
/* 75 */     HashMap<String, String> partMap = new HashMap<>();
/* 76 */     partMap.put("left_arm", "right_arm");
/* 77 */     partMap.put("left_leg", "right_leg");
/* 78 */     partMap.put("left_item", "right_item");
/* 79 */     partMap.put("right_arm", "left_arm");
/* 80 */     partMap.put("right_leg", "left_leg");
/* 81 */     partMap.put("right_item", "left_item");
/* 82 */     mirrorMap = Collections.unmodifiableMap(partMap);
/*    */   }
/*    */ 
/*    */   
/*    */   public String toString() {
/* 87 */     return "MirrorModifier{anim=" + String.valueOf(this.anim) + ", enabled=" + this.enabled + "}";
/*    */   }
/*    */ }


/* Location:              C:\Users\rapha\Downloads\aurora.jar!\META-INF\jars\player-animation-library-wJLdv4ZQ.jar!\com\zigythebird\playeranimcore\animation\layered\modifier\MirrorModifier.class
 * Java compiler version: 21 (65.0)
 * JD-Core Version:       1.1.3
 */