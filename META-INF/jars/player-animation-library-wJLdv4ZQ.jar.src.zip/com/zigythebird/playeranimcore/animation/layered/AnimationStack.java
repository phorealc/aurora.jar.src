/*     */ package com.zigythebird.playeranimcore.animation.layered;
/*     */ 
/*     */ import com.zigythebird.playeranimcore.animation.AnimationData;
/*     */ import com.zigythebird.playeranimcore.api.firstPerson.FirstPersonConfiguration;
/*     */ import com.zigythebird.playeranimcore.api.firstPerson.FirstPersonMode;
/*     */ import com.zigythebird.playeranimcore.bones.PlayerAnimBone;
/*     */ import it.unimi.dsi.fastutil.Pair;
/*     */ import java.util.ArrayList;
/*     */ import java.util.List;
/*     */ import org.jetbrains.annotations.NotNull;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class AnimationStack
/*     */   implements IAnimation
/*     */ {
/*  18 */   protected final List<Pair<Integer, IAnimation>> layers = new ArrayList<>();
/*     */   
/*     */   public List<Pair<Integer, IAnimation>> getLayers() {
/*  21 */     return this.layers;
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean isActive() {
/*  26 */     for (Pair<Integer, IAnimation> layer : this.layers) {
/*  27 */       if (((IAnimation)layer.right()).isActive()) return true; 
/*     */     } 
/*  29 */     return false;
/*     */   }
/*     */ 
/*     */   
/*     */   public void tick(AnimationData state) {
/*  34 */     for (Pair<Integer, IAnimation> layer : this.layers) {
/*  35 */       ((IAnimation)layer.right()).tick(state);
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   public PlayerAnimBone get3DTransform(@NotNull PlayerAnimBone bone) {
/*  41 */     for (Pair<Integer, IAnimation> layer : this.layers) {
/*  42 */       if (((IAnimation)layer.right()).isActive())
/*     */       {
/*     */ 
/*     */         
/*  46 */         bone = ((IAnimation)layer.right()).get3DTransform(bone);
/*     */       }
/*     */     } 
/*  49 */     return bone;
/*     */   }
/*     */ 
/*     */   
/*     */   public void setupAnim(AnimationData state) {
/*  54 */     for (Pair<Integer, IAnimation> layer : this.layers) {
/*  55 */       if (((IAnimation)layer.right()).isActive()) {
/*  56 */         ((IAnimation)layer.right()).setupAnim(state);
/*     */       }
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void addAnimLayer(int priority, IAnimation layer) {
/*  67 */     int search = 0;
/*     */     
/*  69 */     while (this.layers.size() > search && ((Integer)((Pair)this.layers.get(search)).left()).intValue() < priority) {
/*  70 */       search++;
/*     */     }
/*  72 */     this.layers.add(search, Pair.of(Integer.valueOf(priority), layer));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean removeLayer(IAnimation layer) {
/*  81 */     return this.layers.removeIf(integerIAnimationPair -> (integerIAnimationPair.right() == layer));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean removeLayer(int layerLevel) {
/*  90 */     return this.layers.removeIf(integerIAnimationPair -> (((Integer)integerIAnimationPair.left()).intValue() == layerLevel));
/*     */   }
/*     */   
/*     */   @NotNull
/*     */   public FirstPersonMode getFirstPersonMode() {
/*  95 */     for (int i = this.layers.size(); i > 0; ) {
/*  96 */       Pair<Integer, IAnimation> layer = this.layers.get(--i);
/*  97 */       if (((IAnimation)layer.right()).isActive()) {
/*  98 */         FirstPersonMode mode = ((IAnimation)layer.right()).getFirstPersonMode();
/*  99 */         if (mode != FirstPersonMode.NONE) return mode; 
/*     */       } 
/*     */     } 
/* 102 */     return FirstPersonMode.NONE;
/*     */   }
/*     */   
/*     */   @NotNull
/*     */   public FirstPersonConfiguration getFirstPersonConfiguration() {
/* 107 */     for (int i = this.layers.size(); i > 0; ) {
/* 108 */       Pair<Integer, IAnimation> layer = this.layers.get(--i);
/* 109 */       if (((IAnimation)layer.right()).isActive()) {
/* 110 */         FirstPersonMode mode = ((IAnimation)layer.right()).getFirstPersonMode();
/* 111 */         if (mode != FirstPersonMode.NONE) return ((IAnimation)layer.right()).getFirstPersonConfiguration(); 
/*     */       } 
/*     */     } 
/* 114 */     return super.getFirstPersonConfiguration();
/*     */   }
/*     */   
/*     */   public int getFirstPersonTransitionLength() {
/* 118 */     for (int i = this.layers.size() - 1; i >= 0; i--) {
/* 119 */       IAnimation layer = (IAnimation)((Pair)this.layers.get(i)).right();
/* 120 */       if (layer.isActive() && layer.getFirstPersonMode() == FirstPersonMode.THIRD_PERSON_MODEL) {
/* 121 */         int transitionLength = layer.getFirstPersonTransitionLength();
/* 122 */         if (transitionLength > 0) return transitionLength; 
/*     */       } 
/*     */     } 
/* 125 */     return 0;
/*     */   }
/*     */   
/*     */   public boolean isFirstPersonFollowsCamera() {
/* 129 */     for (int i = this.layers.size() - 1; i >= 0; i--) {
/* 130 */       IAnimation layer = (IAnimation)((Pair)this.layers.get(i)).right();
/* 131 */       if (layer.isActive()) return layer.isFirstPersonFollowsCamera(); 
/*     */     } 
/* 133 */     return super.isFirstPersonFollowsCamera();
/*     */   }
/*     */   
/*     */   public int getPriority() {
/* 137 */     int priority = 0;
/* 138 */     for (int i = this.layers.size() - 1; i >= 0; i--) {
/* 139 */       Pair<Integer, IAnimation> layer = this.layers.get(i);
/* 140 */       if (((IAnimation)layer.right()).isActive()) {
/* 141 */         priority = ((Integer)layer.left()).intValue();
/*     */         break;
/*     */       } 
/*     */     } 
/* 145 */     return priority;
/*     */   }
/*     */ 
/*     */   
/*     */   public String toString() {
/* 150 */     return "AnimationStack{layers=" + String.valueOf(this.layers) + "}";
/*     */   }
/*     */ }


/* Location:              C:\Users\rapha\Downloads\aurora.jar!\META-INF\jars\player-animation-library-wJLdv4ZQ.jar!\com\zigythebird\playeranimcore\animation\layered\AnimationStack.class
 * Java compiler version: 21 (65.0)
 * JD-Core Version:       1.1.3
 */