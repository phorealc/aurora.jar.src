/*     */ package com.zigythebird.playeranimcore.animation.layered.modifier;
/*     */ 
/*     */ import com.zigythebird.playeranimcore.math.Vec3f;
/*     */ import java.util.Objects;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class PartModifier
/*     */ {
/*     */   private final Vec3f rotation;
/*     */   private final Vec3f scale;
/*     */   private final Vec3f offset;
/*     */   
/*     */   public PartModifier(Vec3f rotation, Vec3f offset) {
/*  86 */     this(rotation, Vec3f.ZERO, offset);
/*     */   }
/*     */   
/*     */   public PartModifier(Vec3f rotation, Vec3f scale, Vec3f offset) {
/*  90 */     this.rotation = rotation;
/*  91 */     this.scale = scale;
/*  92 */     this.offset = offset;
/*     */   }
/*     */   
/*     */   public Vec3f rotation() {
/*  96 */     return this.rotation;
/*     */   }
/*     */   
/*     */   public Vec3f scale() {
/* 100 */     return this.scale;
/*     */   }
/*     */   
/*     */   public Vec3f offset() {
/* 104 */     return this.offset;
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean equals(Object obj) {
/* 109 */     if (obj == this) return true; 
/* 110 */     if (obj == null || obj.getClass() != getClass()) return false; 
/* 111 */     PartModifier that = (PartModifier)obj;
/* 112 */     return (Objects.equals(this.rotation, that.rotation) && 
/* 113 */       Objects.equals(this.scale, that.scale) && 
/* 114 */       Objects.equals(this.offset, that.offset));
/*     */   }
/*     */ 
/*     */   
/*     */   public int hashCode() {
/* 119 */     return Objects.hash(new Object[] { this.rotation, this.scale, this.offset });
/*     */   }
/*     */ 
/*     */   
/*     */   public String toString() {
/* 124 */     return "PartModifier[rotation=" + String.valueOf(this.rotation) + ", scale=" + String.valueOf(this.scale) + ", offset=" + String.valueOf(this.offset) + "]";
/*     */   }
/*     */ }


/* Location:              C:\Users\rapha\Downloads\aurora.jar!\META-INF\jars\player-animation-library-wJLdv4ZQ.jar!\com\zigythebird\playeranimcore\animation\layered\modifier\AdjustmentModifier$PartModifier.class
 * Java compiler version: 21 (65.0)
 * JD-Core Version:       1.1.3
 */