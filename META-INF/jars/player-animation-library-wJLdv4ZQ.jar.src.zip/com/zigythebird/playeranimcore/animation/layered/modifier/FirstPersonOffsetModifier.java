/*    */ package com.zigythebird.playeranimcore.animation.layered.modifier;
/*    */ 
/*    */ import com.zigythebird.playeranimcore.animation.AnimationData;
/*    */ import com.zigythebird.playeranimcore.bones.PlayerAnimBone;
/*    */ import org.jetbrains.annotations.NotNull;
/*    */ 
/*    */ public class FirstPersonOffsetModifier extends AbstractModifier {
/*    */   private boolean isFirstPersonPass;
/*    */   public float offset;
/*    */   
/*    */   public FirstPersonOffsetModifier() {
/* 12 */     this(1.92F);
/*    */   }
/*    */   
/*    */   public FirstPersonOffsetModifier(float offset) {
/* 16 */     this.offset = offset;
/*    */   }
/*    */ 
/*    */   
/*    */   public void setupAnim(AnimationData state) {
/* 21 */     super.setupAnim(state);
/* 22 */     this.isFirstPersonPass = state.isFirstPersonPass();
/*    */   }
/*    */ 
/*    */   
/*    */   public PlayerAnimBone get3DTransform(@NotNull PlayerAnimBone bone) {
/* 27 */     bone = super.get3DTransform(bone);
/* 28 */     if (this.isFirstPersonPass && "body".equals(bone.getName()))
/* 29 */       bone.positionY += this.offset; 
/* 30 */     return bone;
/*    */   }
/*    */ }


/* Location:              C:\Users\rapha\Downloads\aurora.jar!\META-INF\jars\player-animation-library-wJLdv4ZQ.jar!\com\zigythebird\playeranimcore\animation\layered\modifier\FirstPersonOffsetModifier.class
 * Java compiler version: 21 (65.0)
 * JD-Core Version:       1.1.3
 */