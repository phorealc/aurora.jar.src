/*    */ package com.zigythebird.playeranimcore.animation;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class AnimationData
/*    */ {
/*    */   private float velocity;
/*    */   private float partialTick;
/*    */   private final boolean isFirstPersonPass;
/*    */   
/*    */   public AnimationData(float velocity, float partialTick, boolean isFirstPersonPass) {
/* 33 */     this.velocity = velocity;
/* 34 */     this.partialTick = partialTick;
/* 35 */     this.isFirstPersonPass = isFirstPersonPass;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public float getPartialTick() {
/* 42 */     return this.partialTick;
/*    */   }
/*    */   
/*    */   public float getVelocity() {
/* 46 */     return this.velocity;
/*    */   }
/*    */   
/*    */   public boolean isFirstPersonPass() {
/* 50 */     return this.isFirstPersonPass;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public boolean isMoving() {
/* 57 */     return (this.velocity > 0.015F);
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public boolean isMovingLenient() {
/* 64 */     return (this.velocity > 1.0E-6F);
/*    */   }
/*    */   
/*    */   public void setVelocity(float velocity) {
/* 68 */     this.velocity = velocity;
/*    */   }
/*    */   
/*    */   public void setPartialTick(float partialTick) {
/* 72 */     this.partialTick = partialTick;
/*    */   }
/*    */   
/*    */   public AnimationData copy() {
/* 76 */     return new AnimationData(this.velocity, this.partialTick, this.isFirstPersonPass);
/*    */   }
/*    */ }


/* Location:              C:\Users\rapha\Downloads\aurora.jar!\META-INF\jars\player-animation-library-wJLdv4ZQ.jar!\com\zigythebird\playeranimcore\animation\AnimationData.class
 * Java compiler version: 21 (65.0)
 * JD-Core Version:       1.1.3
 */