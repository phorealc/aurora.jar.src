/*    */ package com.zigythebird.playeranimcore.animation.keyframe;
/*    */ 
/*    */ import java.util.ArrayList;
/*    */ import java.util.List;
/*    */ import java.util.Objects;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public final class BoneAnimation
/*    */   extends Record
/*    */ {
/*    */   private final KeyframeStack rotationKeyFrames;
/*    */   private final KeyframeStack positionKeyFrames;
/*    */   private final KeyframeStack scaleKeyFrames;
/*    */   private final List<Keyframe> bendKeyFrames;
/*    */   
/*    */   public final String toString() {
/*    */     // Byte code:
/*    */     //   0: aload_0
/*    */     //   1: <illegal opcode> toString : (Lcom/zigythebird/playeranimcore/animation/keyframe/BoneAnimation;)Ljava/lang/String;
/*    */     //   6: areturn
/*    */     // Line number table:
/*    */     //   Java source line number -> byte code offset
/*    */     //   #41	-> 0
/*    */     // Local variable table:
/*    */     //   start	length	slot	name	descriptor
/*    */     //   0	7	0	this	Lcom/zigythebird/playeranimcore/animation/keyframe/BoneAnimation;
/*    */   }
/*    */   
/*    */   public BoneAnimation(KeyframeStack rotationKeyFrames, KeyframeStack positionKeyFrames, KeyframeStack scaleKeyFrames, List<Keyframe> bendKeyFrames) {
/* 41 */     this.rotationKeyFrames = rotationKeyFrames; this.positionKeyFrames = positionKeyFrames; this.scaleKeyFrames = scaleKeyFrames; this.bendKeyFrames = bendKeyFrames; } public KeyframeStack rotationKeyFrames() { return this.rotationKeyFrames; } public KeyframeStack positionKeyFrames() { return this.positionKeyFrames; } public KeyframeStack scaleKeyFrames() { return this.scaleKeyFrames; } public List<Keyframe> bendKeyFrames() { return this.bendKeyFrames; }
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public BoneAnimation() {
/* 47 */     this(new KeyframeStack(), new KeyframeStack(), new KeyframeStack(), new ArrayList<>());
/*    */   }
/*    */   
/*    */   public boolean hasKeyframes() {
/* 51 */     return (rotationKeyFrames().hasKeyframes() || positionKeyFrames().hasKeyframes() || 
/* 52 */       scaleKeyFrames().hasKeyframes() || !this.bendKeyFrames.isEmpty());
/*    */   }
/*    */   
/*    */   public boolean equals(Object o) {
/*    */     BoneAnimation that;
/* 57 */     if (o instanceof BoneAnimation) { that = (BoneAnimation)o; } else { return false; }
/* 58 */      return (Objects.equals(this.scaleKeyFrames, that.scaleKeyFrames) && Objects.equals(this.bendKeyFrames, that.bendKeyFrames) && Objects.equals(this.rotationKeyFrames, that.rotationKeyFrames) && Objects.equals(this.positionKeyFrames, that.positionKeyFrames));
/*    */   }
/*    */ 
/*    */   
/*    */   public int hashCode() {
/* 63 */     return Objects.hash(new Object[] { this.rotationKeyFrames, this.positionKeyFrames, this.scaleKeyFrames, this.bendKeyFrames });
/*    */   }
/*    */ }


/* Location:              C:\Users\rapha\Downloads\aurora.jar!\META-INF\jars\player-animation-library-wJLdv4ZQ.jar!\com\zigythebird\playeranimcore\animation\keyframe\BoneAnimation.class
 * Java compiler version: 21 (65.0)
 * JD-Core Version:       1.1.3
 */