package com.zigythebird.playeranimcore.animation.keyframe.event;

import com.zigythebird.playeranimcore.animation.AnimationController;
import com.zigythebird.playeranimcore.animation.keyframe.event.data.KeyFrameData;
import java.util.Set;

@FunctionalInterface
public interface ResetKeyFramesHandler {
  void handle(AnimationController paramAnimationController, Set<KeyFrameData> paramSet);
}


/* Location:              C:\Users\rapha\Downloads\aurora.jar!\META-INF\jars\player-animation-library-wJLdv4ZQ.jar!\com\zigythebird\playeranimcore\animation\keyframe\event\CustomKeyFrameEvents$ResetKeyFramesHandler.class
 * Java compiler version: 21 (65.0)
 * JD-Core Version:       1.1.3
 */