/*    */ package com.zigythebird.playeranimcore.animation.keyframe.event;
/*    */ 
/*    */ import com.zigythebird.playeranimcore.animation.AnimationController;
/*    */ import com.zigythebird.playeranimcore.animation.AnimationData;
/*    */ import com.zigythebird.playeranimcore.animation.keyframe.event.data.CustomInstructionKeyframeData;
/*    */ import com.zigythebird.playeranimcore.animation.keyframe.event.data.KeyFrameData;
/*    */ import com.zigythebird.playeranimcore.animation.keyframe.event.data.ParticleKeyframeData;
/*    */ import com.zigythebird.playeranimcore.animation.keyframe.event.data.SoundKeyframeData;
/*    */ import com.zigythebird.playeranimcore.event.Event;
/*    */ import com.zigythebird.playeranimcore.event.EventResult;
/*    */ import java.util.Set;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class CustomKeyFrameEvents
/*    */ {
/* 45 */   public static final Event<CustomKeyFrameHandler<CustomInstructionKeyframeData>> CUSTOM_INSTRUCTION_KEYFRAME_EVENT = new Event(listeners -> ());
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/* 61 */   public static final Event<CustomKeyFrameHandler<ParticleKeyframeData>> PARTICLE_KEYFRAME_EVENT = new Event(listeners -> ());
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/* 77 */   public static final Event<CustomKeyFrameHandler<SoundKeyframeData>> SOUND_KEYFRAME_EVENT = new Event(listeners -> ());
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/* 87 */   public static final Event<ResetKeyFramesHandler> RESET_KEYFRAMES_EVENT = new Event(listeners -> ());
/*    */   
/*    */   @FunctionalInterface
/*    */   public static interface ResetKeyFramesHandler {
/*    */     void handle(AnimationController param1AnimationController, Set<KeyFrameData> param1Set);
/*    */   }
/*    */   
/*    */   @FunctionalInterface
/*    */   public static interface CustomKeyFrameHandler<T extends KeyFrameData> {
/*    */     EventResult handle(float param1Float, AnimationController param1AnimationController, T param1T, AnimationData param1AnimationData);
/*    */   }
/*    */ }


/* Location:              C:\Users\rapha\Downloads\aurora.jar!\META-INF\jars\player-animation-library-wJLdv4ZQ.jar!\com\zigythebird\playeranimcore\animation\keyframe\event\CustomKeyFrameEvents.class
 * Java compiler version: 21 (65.0)
 * JD-Core Version:       1.1.3
 */