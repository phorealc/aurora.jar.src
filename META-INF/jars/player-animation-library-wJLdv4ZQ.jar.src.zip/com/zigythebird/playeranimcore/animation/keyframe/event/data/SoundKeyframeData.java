/*    */ package com.zigythebird.playeranimcore.animation.keyframe.event.data;
/*    */ 
/*    */ import java.util.Objects;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class SoundKeyframeData
/*    */   extends KeyFrameData
/*    */ {
/*    */   private final String sound;
/*    */   
/*    */   public SoundKeyframeData(Float startTick, String sound) {
/* 38 */     super(startTick.floatValue());
/*    */     
/* 40 */     this.sound = sound;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public String getSound() {
/* 47 */     return this.sound;
/*    */   }
/*    */ 
/*    */   
/*    */   public int hashCode() {
/* 52 */     return Objects.hash(new Object[] { Float.valueOf(getStartTick()), this.sound });
/*    */   }
/*    */ }


/* Location:              C:\Users\rapha\Downloads\aurora.jar!\META-INF\jars\player-animation-library-wJLdv4ZQ.jar!\com\zigythebird\playeranimcore\animation\keyframe\event\data\SoundKeyframeData.class
 * Java compiler version: 21 (65.0)
 * JD-Core Version:       1.1.3
 */