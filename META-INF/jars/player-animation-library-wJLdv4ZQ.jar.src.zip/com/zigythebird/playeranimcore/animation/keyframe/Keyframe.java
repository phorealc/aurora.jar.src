/*    */ package com.zigythebird.playeranimcore.animation.keyframe;
/*    */ 
/*    */ import com.zigythebird.playeranimcore.easing.EasingType;
/*    */ import it.unimi.dsi.fastutil.objects.ObjectArrayList;
/*    */ import java.util.Collections;
/*    */ import java.util.List;
/*    */ import java.util.Objects;
/*    */ import team.unnamed.mocha.parser.ast.Expression;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public final class Keyframe
/*    */   extends Record
/*    */ {
/*    */   private final float length;
/*    */   private final List<Expression> startValue;
/*    */   private final List<Expression> endValue;
/*    */   private final EasingType easingType;
/*    */   private final List<List<Expression>> easingArgs;
/*    */   
/*    */   public final String toString() {
/*    */     // Byte code:
/*    */     //   0: aload_0
/*    */     //   1: <illegal opcode> toString : (Lcom/zigythebird/playeranimcore/animation/keyframe/Keyframe;)Ljava/lang/String;
/*    */     //   6: areturn
/*    */     // Line number table:
/*    */     //   Java source line number -> byte code offset
/*    */     //   #44	-> 0
/*    */     // Local variable table:
/*    */     //   start	length	slot	name	descriptor
/*    */     //   0	7	0	this	Lcom/zigythebird/playeranimcore/animation/keyframe/Keyframe;
/*    */   }
/*    */   
/*    */   public Keyframe(float length, List<Expression> startValue, List<Expression> endValue, EasingType easingType, List<List<Expression>> easingArgs) {
/* 44 */     this.length = length; this.startValue = startValue; this.endValue = endValue; this.easingType = easingType; this.easingArgs = easingArgs; } public float length() { return this.length; } public List<Expression> startValue() { return this.startValue; } public List<Expression> endValue() { return this.endValue; } public EasingType easingType() { return this.easingType; } public List<List<Expression>> easingArgs() { return this.easingArgs; }
/*    */    public Keyframe(float length, List<Expression> startValue, List<Expression> endValue) {
/* 46 */     this(length, startValue, endValue, EasingType.LINEAR);
/*    */   }
/*    */   
/*    */   public Keyframe(float length, List<Expression> startValue, List<Expression> endValue, EasingType easingType) {
/* 50 */     this(length, startValue, endValue, easingType, (List<List<Expression>>)new ObjectArrayList(0));
/*    */   }
/*    */   
/*    */   public Keyframe(float length) {
/* 54 */     this(length, Collections.emptyList(), Collections.emptyList());
/*    */   }
/*    */   
/*    */   public static float getLastKeyframeTime(List<Keyframe> list) {
/* 58 */     return (float)list.stream().mapToDouble(Keyframe::length).sum();
/*    */   }
/*    */   
/*    */   public static Keyframe getKeyframeAtTime(List<Keyframe> list, float tick) {
/* 62 */     float totalFrameTime = 0.0F;
/*    */     
/* 64 */     for (Keyframe keyframe : list) {
/* 65 */       totalFrameTime += keyframe.length;
/* 66 */       if (totalFrameTime >= tick) return keyframe;
/*    */     
/*    */     } 
/* 69 */     return (Keyframe)list.getLast();
/*    */   }
/*    */ 
/*    */   
/*    */   public int hashCode() {
/* 74 */     return Objects.hash(new Object[] { Float.valueOf(this.length), this.startValue, this.endValue, Byte.valueOf(this.easingType.id), this.easingArgs });
/*    */   }
/*    */   
/*    */   public boolean equals(Object o) {
/*    */     Keyframe keyframe;
/* 79 */     if (o instanceof Keyframe) { keyframe = (Keyframe)o; } else { return false; }
/* 80 */      return (Float.compare(this.length, keyframe.length) == 0 && this.easingType.id == keyframe.easingType.id && Objects.equals(this.endValue, keyframe.endValue) && Objects.equals(this.startValue, keyframe.startValue) && Objects.equals(this.easingArgs, keyframe.easingArgs));
/*    */   }
/*    */ }


/* Location:              C:\Users\rapha\Downloads\aurora.jar!\META-INF\jars\player-animation-library-wJLdv4ZQ.jar!\com\zigythebird\playeranimcore\animation\keyframe\Keyframe.class
 * Java compiler version: 21 (65.0)
 * JD-Core Version:       1.1.3
 */