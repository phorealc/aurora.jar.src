/*    */ package com.zigythebird.playeranimcore.animation.keyframe.event.data;
/*    */ 
/*    */ import java.util.Objects;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class CustomInstructionKeyframeData
/*    */   extends KeyFrameData
/*    */ {
/*    */   private final String instructions;
/*    */   
/*    */   public CustomInstructionKeyframeData(float startTick, String instructions) {
/* 38 */     super(startTick);
/*    */     
/* 40 */     this.instructions = instructions;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public String getInstructions() {
/* 47 */     return this.instructions;
/*    */   }
/*    */ 
/*    */   
/*    */   public int hashCode() {
/* 52 */     return Objects.hash(new Object[] { Float.valueOf(getStartTick()), this.instructions });
/*    */   }
/*    */ }


/* Location:              C:\Users\rapha\Downloads\aurora.jar!\META-INF\jars\player-animation-library-wJLdv4ZQ.jar!\com\zigythebird\playeranimcore\animation\keyframe\event\data\CustomInstructionKeyframeData.class
 * Java compiler version: 21 (65.0)
 * JD-Core Version:       1.1.3
 */