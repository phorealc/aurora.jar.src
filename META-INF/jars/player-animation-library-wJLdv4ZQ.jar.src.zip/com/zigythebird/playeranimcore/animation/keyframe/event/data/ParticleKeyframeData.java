/*    */ package com.zigythebird.playeranimcore.animation.keyframe.event.data;
/*    */ 
/*    */ import java.util.Objects;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class ParticleKeyframeData
/*    */   extends KeyFrameData
/*    */ {
/*    */   private final String effect;
/*    */   private final String locator;
/*    */   private final String script;
/*    */   
/*    */   public ParticleKeyframeData(float startTick, String effect, String locator, String script) {
/* 40 */     super(startTick);
/*    */     
/* 42 */     this.script = script;
/* 43 */     this.locator = locator;
/* 44 */     this.effect = effect;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public String getEffect() {
/* 51 */     return this.effect;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public String getLocator() {
/* 58 */     return this.locator;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public String script() {
/* 65 */     return this.script;
/*    */   }
/*    */ 
/*    */   
/*    */   public int hashCode() {
/* 70 */     return Objects.hash(new Object[] { Float.valueOf(getStartTick()), this.effect, this.locator, this.script });
/*    */   }
/*    */ }


/* Location:              C:\Users\rapha\Downloads\aurora.jar!\META-INF\jars\player-animation-library-wJLdv4ZQ.jar!\com\zigythebird\playeranimcore\animation\keyframe\event\data\ParticleKeyframeData.class
 * Java compiler version: 21 (65.0)
 * JD-Core Version:       1.1.3
 */