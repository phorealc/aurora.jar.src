/*    */ package com.zigythebird.playeranimcore.animation.keyframe.event.data;
/*    */ 
/*    */ import java.util.Objects;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public abstract class KeyFrameData
/*    */ {
/*    */   private final float startTick;
/*    */   
/*    */   public KeyFrameData(float startTick) {
/* 41 */     this.startTick = startTick;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public float getStartTick() {
/* 48 */     return this.startTick;
/*    */   }
/*    */ 
/*    */   
/*    */   public boolean equals(Object obj) {
/* 53 */     if (this == obj) {
/* 54 */       return true;
/*    */     }
/* 56 */     if (obj == null || getClass() != obj.getClass()) {
/* 57 */       return false;
/*    */     }
/* 59 */     return (hashCode() == obj.hashCode());
/*    */   }
/*    */ 
/*    */   
/*    */   public int hashCode() {
/* 64 */     return Objects.hashCode(Float.valueOf(this.startTick));
/*    */   }
/*    */ }


/* Location:              C:\Users\rapha\Downloads\aurora.jar!\META-INF\jars\player-animation-library-wJLdv4ZQ.jar!\com\zigythebird\playeranimcore\animation\keyframe\event\data\KeyFrameData.class
 * Java compiler version: 21 (65.0)
 * JD-Core Version:       1.1.3
 */