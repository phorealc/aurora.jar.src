/*    */ package com.zigythebird.playeranimcore.animation.keyframe;
/*    */ 
/*    */ import com.zigythebird.playeranimcore.easing.EasingType;
/*    */ import java.util.List;
/*    */ import org.jetbrains.annotations.Nullable;
/*    */ import team.unnamed.mocha.parser.ast.Expression;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public final class AnimationPoint
/*    */   extends Record
/*    */ {
/*    */   private final EasingType easingType;
/*    */   @Nullable
/*    */   private final List<List<Expression>> easingArgs;
/*    */   private final float currentTick;
/*    */   private final float transitionLength;
/*    */   private final float animationStartValue;
/*    */   private final float animationEndValue;
/*    */   
/*    */   public final int hashCode() {
/*    */     // Byte code:
/*    */     //   0: aload_0
/*    */     //   1: <illegal opcode> hashCode : (Lcom/zigythebird/playeranimcore/animation/keyframe/AnimationPoint;)I
/*    */     //   6: ireturn
/*    */     // Line number table:
/*    */     //   Java source line number -> byte code offset
/*    */     //   #43	-> 0
/*    */     // Local variable table:
/*    */     //   start	length	slot	name	descriptor
/*    */     //   0	7	0	this	Lcom/zigythebird/playeranimcore/animation/keyframe/AnimationPoint;
/*    */   }
/*    */   
/*    */   public final boolean equals(Object o) {
/*    */     // Byte code:
/*    */     //   0: aload_0
/*    */     //   1: aload_1
/*    */     //   2: <illegal opcode> equals : (Lcom/zigythebird/playeranimcore/animation/keyframe/AnimationPoint;Ljava/lang/Object;)Z
/*    */     //   7: ireturn
/*    */     // Line number table:
/*    */     //   Java source line number -> byte code offset
/*    */     //   #43	-> 0
/*    */     // Local variable table:
/*    */     //   start	length	slot	name	descriptor
/*    */     //   0	8	0	this	Lcom/zigythebird/playeranimcore/animation/keyframe/AnimationPoint;
/*    */     //   0	8	1	o	Ljava/lang/Object;
/*    */   }
/*    */   
/*    */   public AnimationPoint(EasingType easingType, @Nullable List<List<Expression>> easingArgs, float currentTick, float transitionLength, float animationStartValue, float animationEndValue) {
/* 43 */     this.easingType = easingType; this.easingArgs = easingArgs; this.currentTick = currentTick; this.transitionLength = transitionLength; this.animationStartValue = animationStartValue; this.animationEndValue = animationEndValue; } public EasingType easingType() { return this.easingType; } @Nullable public List<List<Expression>> easingArgs() { return this.easingArgs; } public float currentTick() { return this.currentTick; } public float transitionLength() { return this.transitionLength; } public float animationStartValue() { return this.animationStartValue; } public float animationEndValue() { return this.animationEndValue; }
/*    */    public AnimationPoint(Keyframe keyframe, float currentTick, float transitionLength, float animationStartValue, float animationEndValue) {
/* 45 */     this((keyframe == null) ? EasingType.LINEAR : keyframe.easingType(), (keyframe == null) ? null : keyframe.easingArgs(), currentTick, transitionLength, animationStartValue, animationEndValue);
/*    */   }
/*    */ 
/*    */   
/*    */   public String toString() {
/* 50 */     return "Tick: " + this.currentTick + " | Transition Length: " + this.transitionLength + " | Start Value: " + this.animationStartValue + " | End Value: " + this.animationEndValue;
/*    */   }
/*    */ }


/* Location:              C:\Users\rapha\Downloads\aurora.jar!\META-INF\jars\player-animation-library-wJLdv4ZQ.jar!\com\zigythebird\playeranimcore\animation\keyframe\AnimationPoint.class
 * Java compiler version: 21 (65.0)
 * JD-Core Version:       1.1.3
 */