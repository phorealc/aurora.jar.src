package com.zigythebird.playeranimcore.animation.keyframe.event;

import com.zigythebird.playeranimcore.animation.AnimationController;
import com.zigythebird.playeranimcore.animation.AnimationData;
import com.zigythebird.playeranimcore.event.EventResult;

@FunctionalInterface
public interface CustomKeyFrameHandler<T extends com.zigythebird.playeranimcore.animation.keyframe.event.data.KeyFrameData> {
  EventResult handle(float paramFloat, AnimationController paramAnimationController, T paramT, AnimationData paramAnimationData);
}


/* Location:              C:\Users\rapha\Downloads\aurora.jar!\META-INF\jars\player-animation-library-wJLdv4ZQ.jar!\com\zigythebird\playeranimcore\animation\keyframe\event\CustomKeyFrameEvents$CustomKeyFrameHandler.class
 * Java compiler version: 21 (65.0)
 * JD-Core Version:       1.1.3
 */