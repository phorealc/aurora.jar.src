/*    */ package com.zigythebird.playeranimcore.animation.keyframe;
/*    */ 
/*    */ import com.zigythebird.playeranimcore.enums.Axis;
/*    */ import it.unimi.dsi.fastutil.objects.ObjectArrayList;
/*    */ import java.util.List;
/*    */ import java.util.Objects;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public final class KeyframeStack
/*    */   extends Record
/*    */ {
/*    */   private final List<Keyframe> xKeyframes;
/*    */   private final List<Keyframe> yKeyframes;
/*    */   private final List<Keyframe> zKeyframes;
/*    */   
/*    */   public final String toString() {
/*    */     // Byte code:
/*    */     //   0: aload_0
/*    */     //   1: <illegal opcode> toString : (Lcom/zigythebird/playeranimcore/animation/keyframe/KeyframeStack;)Ljava/lang/String;
/*    */     //   6: areturn
/*    */     // Line number table:
/*    */     //   Java source line number -> byte code offset
/*    */     //   #36	-> 0
/*    */     // Local variable table:
/*    */     //   start	length	slot	name	descriptor
/*    */     //   0	7	0	this	Lcom/zigythebird/playeranimcore/animation/keyframe/KeyframeStack;
/*    */   }
/*    */   
/*    */   public KeyframeStack(List<Keyframe> xKeyframes, List<Keyframe> yKeyframes, List<Keyframe> zKeyframes) {
/* 36 */     this.xKeyframes = xKeyframes; this.yKeyframes = yKeyframes; this.zKeyframes = zKeyframes; } public List<Keyframe> xKeyframes() { return this.xKeyframes; } public List<Keyframe> yKeyframes() { return this.yKeyframes; } public List<Keyframe> zKeyframes() { return this.zKeyframes; }
/*    */    public KeyframeStack() {
/* 38 */     this((List<Keyframe>)new ObjectArrayList(), (List<Keyframe>)new ObjectArrayList(), (List<Keyframe>)new ObjectArrayList());
/*    */   }
/*    */   
/*    */   public static KeyframeStack from(KeyframeStack otherStack) {
/* 42 */     return new KeyframeStack(otherStack.xKeyframes, otherStack.yKeyframes, otherStack.zKeyframes);
/*    */   }
/*    */   
/*    */   public float getLastKeyframeTime() {
/* 46 */     return Math.max(getLastXAxisKeyframeTime(), Math.max(getLastYAxisKeyframeTime(), getLastZAxisKeyframeTime()));
/*    */   }
/*    */   
/*    */   public float getLastXAxisKeyframeTime() {
/* 50 */     return Keyframe.getLastKeyframeTime(this.xKeyframes);
/*    */   }
/*    */   
/*    */   public float getLastYAxisKeyframeTime() {
/* 54 */     return Keyframe.getLastKeyframeTime(this.yKeyframes);
/*    */   }
/*    */   
/*    */   public float getLastZAxisKeyframeTime() {
/* 58 */     return Keyframe.getLastKeyframeTime(this.zKeyframes);
/*    */   }
/*    */   
/*    */   public List<Keyframe> getKeyFramesForAxis(Axis axis) {
/* 62 */     switch (axis) { default: throw new MatchException(null, null);case X: case Y: case Z: break; }  return 
/*    */ 
/*    */       
/* 65 */       zKeyframes();
/*    */   }
/*    */ 
/*    */   
/*    */   public boolean hasKeyframes() {
/* 70 */     return (!xKeyframes().isEmpty() || !yKeyframes().isEmpty() || !zKeyframes().isEmpty());
/*    */   }
/*    */   
/*    */   public boolean equals(Object o) {
/*    */     KeyframeStack that;
/* 75 */     if (o instanceof KeyframeStack) { that = (KeyframeStack)o; } else { return false; }
/* 76 */      return (Objects.equals(this.xKeyframes, that.xKeyframes) && Objects.equals(this.yKeyframes, that.yKeyframes) && Objects.equals(this.zKeyframes, that.zKeyframes));
/*    */   }
/*    */ 
/*    */   
/*    */   public int hashCode() {
/* 81 */     return Objects.hash(new Object[] { this.xKeyframes, this.yKeyframes, this.zKeyframes });
/*    */   }
/*    */ }


/* Location:              C:\Users\rapha\Downloads\aurora.jar!\META-INF\jars\player-animation-library-wJLdv4ZQ.jar!\com\zigythebird\playeranimcore\animation\keyframe\KeyframeStack.class
 * Java compiler version: 21 (65.0)
 * JD-Core Version:       1.1.3
 */