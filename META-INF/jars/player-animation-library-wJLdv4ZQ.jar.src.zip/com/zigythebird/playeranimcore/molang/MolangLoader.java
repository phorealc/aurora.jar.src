/*     */ package com.zigythebird.playeranimcore.molang;
/*     */ import com.google.gson.JsonElement;
/*     */ import com.zigythebird.playeranimcore.PlayerAnimLib;
/*     */ import com.zigythebird.playeranimcore.animation.AnimationController;
/*     */ import com.zigythebird.playeranimcore.event.MolangEvent;
/*     */ import java.io.IOException;
/*     */ import java.util.List;
/*     */ import java.util.function.Consumer;
/*     */ import java.util.function.Function;
/*     */ import java.util.function.ToDoubleFunction;
/*     */ import org.jetbrains.annotations.Contract;
/*     */ import org.jetbrains.annotations.NotNull;
/*     */ import org.jetbrains.annotations.Nullable;
/*     */ import team.unnamed.mocha.MochaEngine;
/*     */ import team.unnamed.mocha.parser.MolangParser;
/*     */ import team.unnamed.mocha.parser.ParseException;
/*     */ import team.unnamed.mocha.parser.ast.Expression;
/*     */ import team.unnamed.mocha.runtime.ExecutionContext;
/*     */ import team.unnamed.mocha.runtime.IsConstantExpression;
/*     */ import team.unnamed.mocha.runtime.value.Function;
/*     */ import team.unnamed.mocha.runtime.value.NumberValue;
/*     */ import team.unnamed.mocha.runtime.value.Value;
/*     */ 
/*     */ public class MolangLoader {
/*     */   private static final Consumer<ParseException> HANDLER;
/*     */   
/*     */   static {
/*  28 */     HANDLER = (e -> PlayerAnimLib.LOGGER.warn("Failed to parse!", (Throwable)e));
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*  33 */   public static final MochaEngine<?> MOCHA_ENGINE = createNewEngine();
/*     */   
/*     */   @Contract("_, null, _ -> new; _, !null, _ -> new")
/*     */   public static List<Expression> parseJson(boolean isForRotation, @Nullable JsonElement element, @NotNull Expression defaultValue) {
/*  37 */     return parseJson(isForRotation, element, Collections.singletonList(defaultValue));
/*     */   }
/*     */   @Contract("_, null, _ -> param3; _, !null, _ -> !null")
/*     */   public static List<Expression> parseJson(boolean isForRotation, @Nullable JsonElement element, @NotNull List<Expression> defaultValue) {
/*     */     List<Expression> expressions;
/*  42 */     if (element == null) return defaultValue;
/*     */ 
/*     */     
/*  45 */     try { MolangParser parser = MolangParser.parser(element.getAsString()); 
/*  46 */       try { List<Expression> expressions1 = parser.parseAll();
/*  47 */         if (expressions1.size() == 1 && isForRotation && IsConstantExpression.test((Expression)expressions1.getFirst())) {
/*  48 */           expressions = new ArrayList<>();
/*  49 */           expressions.add(FloatExpression.of(Math.toRadians(MOCHA_ENGINE.eval(expressions1))));
/*     */         } else {
/*  51 */           expressions = expressions1;
/*     */         } 
/*  53 */         if (parser != null) parser.close();  } catch (Throwable throwable) { if (parser != null) try { parser.close(); } catch (Throwable throwable1) { throwable.addSuppressed(throwable1); }   throw throwable; }  } catch (IOException e)
/*  54 */     { PlayerAnimLib.LOGGER.error("Failed to compile molang '{}'!", element, e);
/*  55 */       return defaultValue; }
/*     */     
/*  57 */     return expressions;
/*     */   }
/*     */   
/*     */   public static MochaEngine<AnimationController> createNewEngine(AnimationController controller) {
/*  61 */     MochaEngine<AnimationController> engine = createBaseEngine(controller);
/*     */     
/*  63 */     QueryBinding<AnimationController> queryBinding = new QueryBinding<>(controller);
/*  64 */     setDoubleQuery(queryBinding, "anim_time", AnimationController::getAnimationTime);
/*  65 */     setDoubleQuery(queryBinding, "controller_speed", AnimationController::getAnimationSpeed);
/*     */     
/*  67 */     ((MolangEvent.MolangEventInterface)MolangEvent.MOLANG_EVENT.invoker()).registerMolangQueries(controller, engine, queryBinding);
/*  68 */     queryBinding.block();
/*     */     
/*  70 */     engine.scope().set("query", (Value)queryBinding);
/*  71 */     engine.scope().set("q", (Value)queryBinding);
/*  72 */     return engine;
/*     */   }
/*     */   
/*     */   public static MochaEngine<?> createNewEngine() {
/*  76 */     return createNewEngine(null);
/*     */   }
/*     */   
/*     */   public static <T> MochaEngine<T> createBaseEngine(T entity) {
/*  80 */     MochaEngine<T> engine = MochaEngine.createStandard(entity);
/*  81 */     engine.handleParseExceptions(HANDLER);
/*  82 */     engine.warnOnReflectiveFunctionUsage(true);
/*     */     
/*  84 */     engine.scope().set("math", (Value)new MochaMathExtensions(engine.scope().getProperty("math")));
/*  85 */     return engine;
/*     */   }
/*     */   
/*     */   public static <T> boolean setDoubleQuery(QueryBinding<T> binding, String name, ToDoubleFunction<T> value) {
/*  89 */     return setControllerQuery(binding, name, controller -> NumberValue.of(value.applyAsDouble(controller)));
/*     */   }
/*     */   
/*     */   public static <T> boolean setBoolQuery(QueryBinding<T> binding, String name, Function<T, Boolean> value) {
/*  93 */     return setControllerQuery(binding, name, controller -> Value.of(((Boolean)value.apply(controller)).booleanValue()));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static <T> boolean setControllerQuery(QueryBinding<T> binding, String name, Function<T, Value> value) {
/* 100 */     return binding.set(name, (Value)((ctx, args) -> (Value)value.apply(ctx.entity())));
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public static boolean isConstant(List<Expression> expressions) {
/* 106 */     return expressions.stream().anyMatch(IsConstantExpression::test);
/*     */   }
/*     */ }


/* Location:              C:\Users\rapha\Downloads\aurora.jar!\META-INF\jars\player-animation-library-wJLdv4ZQ.jar!\com\zigythebird\playeranimcore\molang\MolangLoader.class
 * Java compiler version: 21 (65.0)
 * JD-Core Version:       1.1.3
 */