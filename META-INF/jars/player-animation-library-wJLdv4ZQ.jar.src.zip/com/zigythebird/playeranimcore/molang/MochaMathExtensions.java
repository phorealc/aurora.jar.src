/*    */ package com.zigythebird.playeranimcore.molang;
/*    */ 
/*    */ import com.zigythebird.playeranimcore.easing.EasingType;
/*    */ import java.util.Locale;
/*    */ import java.util.Map;
/*    */ import org.jetbrains.annotations.NotNull;
/*    */ import org.jetbrains.annotations.Nullable;
/*    */ import team.unnamed.mocha.runtime.binding.Binding;
/*    */ import team.unnamed.mocha.runtime.value.ObjectProperty;
/*    */ import team.unnamed.mocha.runtime.value.ObjectValue;
/*    */ import team.unnamed.mocha.runtime.value.Value;
/*    */ import team.unnamed.mocha.util.CaseInsensitiveStringHashMap;
/*    */ 
/*    */ @Binding({"math"})
/*    */ public class MochaMathExtensions
/*    */   implements ObjectValue {
/* 17 */   private final Map<String, ObjectProperty> entries = (Map<String, ObjectProperty>)new CaseInsensitiveStringHashMap();
/*    */   
/*    */   @Nullable
/*    */   private final ObjectValue mochaMath;
/*    */   
/*    */   public MochaMathExtensions(@Nullable ObjectProperty property) {
/* 23 */     this((ObjectValue)property.value());
/*    */   }
/*    */   
/*    */   public MochaMathExtensions(@Nullable ObjectValue mochaMath) {
/* 27 */     this.mochaMath = mochaMath;
/*    */     
/* 29 */     for (EasingType type : EasingType.values()) {
/* 30 */       String name = type.name().toLowerCase(Locale.ROOT);
/* 31 */       if (name.startsWith("ease_")) {
/* 32 */         setFunction(name, (ObjectValue.FloatFunction3)type);
/*    */       }
/*    */     } 
/*    */   }
/*    */   
/*    */   public boolean set(@NotNull String name, @Nullable Value value) {
/* 38 */     return (this.entries.put(name, ObjectProperty.property(value, false)) == null);
/*    */   }
/*    */   
/*    */   @Nullable
/*    */   public ObjectProperty getProperty(@NotNull String name) {
/* 43 */     ObjectProperty extension = this.entries.get(name);
/* 44 */     if (extension == null && this.mochaMath != null) {
/* 45 */       return this.mochaMath.getProperty(name);
/*    */     }
/* 47 */     return extension;
/*    */   }
/*    */ }


/* Location:              C:\Users\rapha\Downloads\aurora.jar!\META-INF\jars\player-animation-library-wJLdv4ZQ.jar!\com\zigythebird\playeranimcore\molang\MochaMathExtensions.class
 * Java compiler version: 21 (65.0)
 * JD-Core Version:       1.1.3
 */