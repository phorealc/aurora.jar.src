/*    */ package com.zigythebird.playeranimcore.molang;
/*    */ 
/*    */ import com.zigythebird.playeranimcore.PlayerAnimLib;
/*    */ import java.util.Objects;
/*    */ import org.jetbrains.annotations.NotNull;
/*    */ import org.jetbrains.annotations.Nullable;
/*    */ import team.unnamed.mocha.parser.ast.Expression;
/*    */ import team.unnamed.mocha.runtime.ExecutionContext;
/*    */ import team.unnamed.mocha.runtime.value.Function;
/*    */ import team.unnamed.mocha.runtime.value.MutableObjectBinding;
/*    */ import team.unnamed.mocha.runtime.value.ObjectProperty;
/*    */ import team.unnamed.mocha.runtime.value.Value;
/*    */ 
/*    */ public class QueryBinding<T>
/*    */   extends MutableObjectBinding implements ExecutionContext<T> {
/*    */   private final T entity;
/*    */   
/*    */   public QueryBinding(T entity) {
/* 19 */     this.entity = entity;
/*    */   }
/*    */ 
/*    */   
/*    */   @Nullable
/*    */   public ObjectProperty getProperty(@NotNull String name) {
/* 25 */     ObjectProperty property = super.getProperty(name);
/* 26 */     if (property == null) return null;
/*    */     
/* 28 */     Value value = property.value(); if (value instanceof Function) { Function function = (Function)value; if (!property.constant()) {
/*    */         try {
/* 30 */           return ObjectProperty.property(Objects.<Value>requireNonNull(function.evaluate(this)), false);
/* 31 */         } catch (Throwable th) {
/* 32 */           PlayerAnimLib.LOGGER.warn("Failed to evaluate function property '{}'", name, th);
/*    */         } 
/*    */       } }
/*    */     
/* 36 */     return property;
/*    */   }
/*    */ 
/*    */   
/*    */   public T entity() {
/* 41 */     return this.entity;
/*    */   }
/*    */   
/*    */   @Nullable
/*    */   public Value eval(@NotNull Expression expression) {
/* 46 */     throw new UnsupportedOperationException();
/*    */   }
/*    */   
/*    */   @Nullable
/*    */   public Object flag() {
/* 51 */     throw new UnsupportedOperationException();
/*    */   }
/*    */ 
/*    */   
/*    */   public void flag(@Nullable Object flag) {
/* 56 */     throw new UnsupportedOperationException();
/*    */   }
/*    */ }


/* Location:              C:\Users\rapha\Downloads\aurora.jar!\META-INF\jars\player-animation-library-wJLdv4ZQ.jar!\com\zigythebird\playeranimcore\molang\QueryBinding.class
 * Java compiler version: 21 (65.0)
 * JD-Core Version:       1.1.3
 */