/*    */ package com.zigythebird.playeranimcore.event;
/*    */ 
/*    */ import it.unimi.dsi.fastutil.objects.ObjectArrayList;
/*    */ import java.util.List;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class Event<T>
/*    */ {
/* 36 */   private final List<T> listeners = (List<T>)new ObjectArrayList();
/*    */   private final Invoker<T> invoker;
/*    */   
/*    */   public Event(Invoker<T> invoker) {
/* 40 */     this.invoker = invoker;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public final T invoker() {
/* 50 */     return this.invoker.invoker(this.listeners);
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public void register(T listener) {
/* 59 */     if (listener == null) throw new NullPointerException("listener can not be null"); 
/* 60 */     this.listeners.add(listener);
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public void unregister(T listener) {
/* 68 */     this.listeners.remove(listener);
/*    */   }
/*    */   
/*    */   @FunctionalInterface
/*    */   public static interface Invoker<T> {
/*    */     T invoker(Iterable<T> param1Iterable);
/*    */   }
/*    */ }


/* Location:              C:\Users\rapha\Downloads\aurora.jar!\META-INF\jars\player-animation-library-wJLdv4ZQ.jar!\com\zigythebird\playeranimcore\event\Event.class
 * Java compiler version: 21 (65.0)
 * JD-Core Version:       1.1.3
 */