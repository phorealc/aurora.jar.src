package com.zigythebird.playeranimcore.event;

import com.zigythebird.playeranimcore.animation.AnimationController;
import com.zigythebird.playeranimcore.molang.QueryBinding;
import team.unnamed.mocha.MochaEngine;

@FunctionalInterface
public interface MolangEventInterface {
  void registerMolangQueries(AnimationController paramAnimationController, MochaEngine<AnimationController> paramMochaEngine, QueryBinding<AnimationController> paramQueryBinding);
}


/* Location:              C:\Users\rapha\Downloads\aurora.jar!\META-INF\jars\player-animation-library-wJLdv4ZQ.jar!\com\zigythebird\playeranimcore\event\MolangEvent$MolangEventInterface.class
 * Java compiler version: 21 (65.0)
 * JD-Core Version:       1.1.3
 */