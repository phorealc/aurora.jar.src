package com.zigythebird.playeranimcore.event;

@FunctionalInterface
public interface Invoker<T> {
  T invoker(Iterable<T> paramIterable);
}


/* Location:              C:\Users\rapha\Downloads\aurora.jar!\META-INF\jars\player-animation-library-wJLdv4ZQ.jar!\com\zigythebird\playeranimcore\event\Event$Invoker.class
 * Java compiler version: 21 (65.0)
 * JD-Core Version:       1.1.3
 */