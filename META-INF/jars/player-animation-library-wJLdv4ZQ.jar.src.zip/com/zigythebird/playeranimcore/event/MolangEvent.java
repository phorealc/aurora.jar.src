/*    */ package com.zigythebird.playeranimcore.event;
/*    */ 
/*    */ import com.zigythebird.playeranimcore.animation.AnimationController;
/*    */ import com.zigythebird.playeranimcore.molang.QueryBinding;
/*    */ import team.unnamed.mocha.MochaEngine;
/*    */ 
/*    */ 
/*    */ 
/*    */ public class MolangEvent
/*    */ {
/* 11 */   public static final Event<MolangEventInterface> MOLANG_EVENT = new Event<>(listeners -> ());
/*    */   
/*    */   @FunctionalInterface
/*    */   public static interface MolangEventInterface {
/*    */     void registerMolangQueries(AnimationController param1AnimationController, MochaEngine<AnimationController> param1MochaEngine, QueryBinding<AnimationController> param1QueryBinding);
/*    */   }
/*    */ }


/* Location:              C:\Users\rapha\Downloads\aurora.jar!\META-INF\jars\player-animation-library-wJLdv4ZQ.jar!\com\zigythebird\playeranimcore\event\MolangEvent.class
 * Java compiler version: 21 (65.0)
 * JD-Core Version:       1.1.3
 */