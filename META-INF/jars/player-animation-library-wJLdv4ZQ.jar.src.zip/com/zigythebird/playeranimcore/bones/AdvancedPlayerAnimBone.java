/*     */ package com.zigythebird.playeranimcore.bones;
/*     */ 
/*     */ public class AdvancedPlayerAnimBone extends PlayerAnimBone implements IBoneEnabled {
/*   4 */   public Float scaleXTransitionLength = null;
/*   5 */   public Float scaleYTransitionLength = null;
/*   6 */   public Float scaleZTransitionLength = null;
/*     */   
/*   8 */   public Float positionXTransitionLength = null;
/*   9 */   public Float positionYTransitionLength = null;
/*  10 */   public Float positionZTransitionLength = null;
/*     */   
/*  12 */   public Float rotXTransitionLength = null;
/*  13 */   public Float rotYTransitionLength = null;
/*  14 */   public Float rotZTransitionLength = null;
/*     */   
/*  16 */   public Float bendTransitionLength = null;
/*     */   
/*     */   public boolean scaleXEnabled = true;
/*     */   
/*     */   public boolean scaleYEnabled = true;
/*     */   
/*     */   public boolean scaleZEnabled = true;
/*     */   
/*     */   public boolean positionXEnabled = true;
/*     */   public boolean positionYEnabled = true;
/*     */   public boolean positionZEnabled = true;
/*     */   public boolean rotXEnabled = true;
/*     */   public boolean rotYEnabled = true;
/*     */   public boolean rotZEnabled = true;
/*     */   public boolean bendEnabled = true;
/*     */   
/*     */   public AdvancedPlayerAnimBone(String name) {
/*  33 */     super(name);
/*     */   }
/*     */   
/*     */   public void setEnabled(boolean enabled) {
/*  37 */     this.scaleXEnabled = enabled;
/*  38 */     this.scaleYEnabled = enabled;
/*  39 */     this.scaleZEnabled = enabled;
/*     */     
/*  41 */     this.positionXEnabled = enabled;
/*  42 */     this.positionYEnabled = enabled;
/*  43 */     this.positionZEnabled = enabled;
/*     */     
/*  45 */     this.rotXEnabled = enabled;
/*  46 */     this.rotYEnabled = enabled;
/*  47 */     this.rotZEnabled = enabled;
/*     */     
/*  49 */     this.bendEnabled = enabled;
/*     */   }
/*     */   
/*     */   public void setBendTransitionLength(Float bendTransitionLength) {
/*  53 */     this.bendTransitionLength = bendTransitionLength;
/*     */   }
/*     */   
/*     */   public void setRotZTransitionLength(Float rotZTransitionLength) {
/*  57 */     this.rotZTransitionLength = rotZTransitionLength;
/*     */   }
/*     */   
/*     */   public void setRotYTransitionLength(Float rotYTransitionLength) {
/*  61 */     this.rotYTransitionLength = rotYTransitionLength;
/*     */   }
/*     */   
/*     */   public void setRotXTransitionLength(Float rotXTransitionLength) {
/*  65 */     this.rotXTransitionLength = rotXTransitionLength;
/*     */   }
/*     */   
/*     */   public void setPositionZTransitionLength(Float positionZTransitionLength) {
/*  69 */     this.positionZTransitionLength = positionZTransitionLength;
/*     */   }
/*     */   
/*     */   public void setPositionYTransitionLength(Float positionYTransitionLength) {
/*  73 */     this.positionYTransitionLength = positionYTransitionLength;
/*     */   }
/*     */   
/*     */   public void setPositionXTransitionLength(Float positionXTransitionLength) {
/*  77 */     this.positionXTransitionLength = positionXTransitionLength;
/*     */   }
/*     */   
/*     */   public void setScaleZTransitionLength(Float scaleZTransitionLength) {
/*  81 */     this.scaleZTransitionLength = scaleZTransitionLength;
/*     */   }
/*     */   
/*     */   public void setScaleYTransitionLength(Float scaleYTransitionLength) {
/*  85 */     this.scaleYTransitionLength = scaleYTransitionLength;
/*     */   }
/*     */   
/*     */   public void setScaleXTransitionLength(Float scaleXTransitionLength) {
/*  89 */     this.scaleXTransitionLength = scaleXTransitionLength;
/*     */   }
/*     */   
/*     */   public void setPositionEnabled(boolean enabled) {
/*  93 */     this.positionXEnabled = enabled;
/*  94 */     this.positionYEnabled = enabled;
/*  95 */     this.positionZEnabled = enabled;
/*     */   }
/*     */   
/*     */   public void setRotEnabled(boolean enabled) {
/*  99 */     this.rotXEnabled = enabled;
/* 100 */     this.rotYEnabled = enabled;
/* 101 */     this.rotZEnabled = enabled;
/*     */   }
/*     */   
/*     */   public void setScaleEnabled(boolean enabled) {
/* 105 */     this.scaleXEnabled = enabled;
/* 106 */     this.scaleYEnabled = enabled;
/* 107 */     this.scaleZEnabled = enabled;
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean isScaleXEnabled() {
/* 112 */     return this.scaleXEnabled;
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean isScaleYEnabled() {
/* 117 */     return this.scaleYEnabled;
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean isScaleZEnabled() {
/* 122 */     return this.scaleZEnabled;
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean isPositionXEnabled() {
/* 127 */     return this.positionXEnabled;
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean isPositionYEnabled() {
/* 132 */     return this.positionYEnabled;
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean isPositionZEnabled() {
/* 137 */     return this.positionZEnabled;
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean isRotXEnabled() {
/* 142 */     return this.rotXEnabled;
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean isRotYEnabled() {
/* 147 */     return this.rotYEnabled;
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean isRotZEnabled() {
/* 152 */     return this.rotZEnabled;
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean isBendEnabled() {
/* 157 */     return this.bendEnabled;
/*     */   }
/*     */ }


/* Location:              C:\Users\rapha\Downloads\aurora.jar!\META-INF\jars\player-animation-library-wJLdv4ZQ.jar!\com\zigythebird\playeranimcore\bones\AdvancedPlayerAnimBone.class
 * Java compiler version: 21 (65.0)
 * JD-Core Version:       1.1.3
 */