/*    */ package com.zigythebird.playeranimcore.bones;
/*    */ 
/*    */ import com.zigythebird.playeranimcore.math.Vec3f;
/*    */ 
/*    */ public class PivotBone extends PlayerAnimBone {
/*    */   private final Vec3f pivot;
/*    */   
/*    */   public PivotBone(String name, Vec3f pivot) {
/*  9 */     super(name);
/* 10 */     this.pivot = pivot;
/*    */   }
/*    */   
/*    */   public Vec3f getPivot() {
/* 14 */     return this.pivot;
/*    */   }
/*    */ }


/* Location:              C:\Users\rapha\Downloads\aurora.jar!\META-INF\jars\player-animation-library-wJLdv4ZQ.jar!\com\zigythebird\playeranimcore\bones\PivotBone.class
 * Java compiler version: 21 (65.0)
 * JD-Core Version:       1.1.3
 */