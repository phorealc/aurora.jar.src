/*    */ package com.zigythebird.playeranimcore.bones;
/*    */ 
/*    */ 
/*    */ public class AdvancedBoneSnapshot
/*    */   extends BoneSnapshot
/*    */ {
/*    */   public boolean scaleXEnabled;
/*    */   public boolean scaleYEnabled;
/*    */   public boolean scaleZEnabled;
/*    */   public boolean positionXEnabled;
/*    */   public boolean positionYEnabled;
/*    */   public boolean positionZEnabled;
/*    */   public boolean rotXEnabled;
/*    */   public boolean rotYEnabled;
/*    */   public boolean rotZEnabled;
/*    */   public boolean bendEnabled;
/*    */   
/*    */   public AdvancedBoneSnapshot(PlayerAnimBone bone) {
/* 19 */     super(bone);
/*    */     
/* 21 */     if (bone instanceof IBoneEnabled) { IBoneEnabled boneEnabled = (IBoneEnabled)bone;
/* 22 */       this.scaleXEnabled = boneEnabled.isScaleXEnabled();
/* 23 */       this.scaleYEnabled = boneEnabled.isScaleYEnabled();
/* 24 */       this.scaleZEnabled = boneEnabled.isScaleZEnabled();
/*    */       
/* 26 */       this.positionXEnabled = boneEnabled.isPositionXEnabled();
/* 27 */       this.positionYEnabled = boneEnabled.isPositionYEnabled();
/* 28 */       this.positionZEnabled = boneEnabled.isPositionZEnabled();
/*    */       
/* 30 */       this.rotXEnabled = boneEnabled.isRotXEnabled();
/* 31 */       this.rotYEnabled = boneEnabled.isRotYEnabled();
/* 32 */       this.rotZEnabled = boneEnabled.isRotZEnabled();
/*    */       
/* 34 */       this.bendEnabled = boneEnabled.isBendEnabled(); }
/*    */   
/*    */   }
/*    */ }


/* Location:              C:\Users\rapha\Downloads\aurora.jar!\META-INF\jars\player-animation-library-wJLdv4ZQ.jar!\com\zigythebird\playeranimcore\bones\AdvancedBoneSnapshot.class
 * Java compiler version: 21 (65.0)
 * JD-Core Version:       1.1.3
 */