/*     */ package com.zigythebird.playeranimcore.bones;
/*     */ 
/*     */ import com.zigythebird.playeranimcore.enums.TransformType;
/*     */ import com.zigythebird.playeranimcore.math.Vec3f;
/*     */ import it.unimi.dsi.fastutil.Pair;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class BoneSnapshot
/*     */ {
/*     */   public final PlayerAnimBone bone;
/*     */   private float scaleX;
/*     */   private float scaleY;
/*     */   private float scaleZ;
/*     */   private float offsetPosX;
/*     */   private float offsetPosY;
/*     */   private float offsetPosZ;
/*     */   private float rotX;
/*     */   private float rotY;
/*     */   private float rotZ;
/*     */   private float bendAxis;
/*     */   private float bend;
/*     */   
/*     */   public BoneSnapshot() {
/*  31 */     this.bone = null;
/*  32 */     setToInitialPose();
/*     */   }
/*     */   
/*     */   public BoneSnapshot(PlayerAnimBone bone) {
/*  36 */     this.rotX = bone.getRotX();
/*  37 */     this.rotY = bone.getRotY();
/*  38 */     this.rotZ = bone.getRotZ();
/*     */     
/*  40 */     this.offsetPosX = bone.getPosX();
/*  41 */     this.offsetPosY = bone.getPosY();
/*  42 */     this.offsetPosZ = bone.getPosZ();
/*     */     
/*  44 */     this.scaleX = bone.getScaleX();
/*  45 */     this.scaleY = bone.getScaleY();
/*  46 */     this.scaleZ = bone.getScaleZ();
/*     */     
/*  48 */     this.bend = bone.getBend();
/*     */     
/*  50 */     this.bone = bone;
/*     */   }
/*     */   
/*     */   public BoneSnapshot(BoneSnapshot bone) {
/*  54 */     this.bone = bone.getBone();
/*     */     
/*  56 */     this.rotX = bone.getRotX();
/*  57 */     this.rotY = bone.getRotY();
/*  58 */     this.rotZ = bone.getRotZ();
/*     */     
/*  60 */     this.offsetPosX = bone.getOffsetX();
/*  61 */     this.offsetPosY = bone.getOffsetY();
/*  62 */     this.offsetPosZ = bone.getOffsetZ();
/*     */     
/*  64 */     this.scaleX = bone.getScaleX();
/*  65 */     this.scaleY = bone.getScaleY();
/*  66 */     this.scaleZ = bone.getScaleZ();
/*     */     
/*  68 */     this.bendAxis = bone.getBendAxis();
/*  69 */     this.bend = bone.getBend();
/*     */   }
/*     */   
/*     */   public BoneSnapshot(PlayerAnimBone bone, boolean isInitial) {
/*  73 */     this.bone = bone;
/*  74 */     if (!isInitial) {
/*  75 */       this.rotX = bone.getRotX();
/*  76 */       this.rotY = bone.getRotY();
/*  77 */       this.rotZ = bone.getRotZ();
/*     */       
/*  79 */       this.offsetPosX = bone.getPosX();
/*  80 */       this.offsetPosY = bone.getPosY();
/*  81 */       this.offsetPosZ = bone.getPosZ();
/*     */       
/*  83 */       this.scaleX = bone.getScaleX();
/*  84 */       this.scaleY = bone.getScaleY();
/*  85 */       this.scaleZ = bone.getScaleZ();
/*     */       
/*  87 */       this.bend = bone.getBend();
/*     */     } else {
/*  89 */       setToInitialPose();
/*     */     } 
/*     */   } public PlayerAnimBone getBone() {
/*  92 */     return this.bone;
/*     */   }
/*     */   public float getScaleX() {
/*  95 */     return this.scaleX;
/*     */   }
/*     */   
/*     */   public float getScaleY() {
/*  99 */     return this.scaleY;
/*     */   }
/*     */   
/*     */   public float getScaleZ() {
/* 103 */     return this.scaleZ;
/*     */   }
/*     */   
/*     */   public float getOffsetX() {
/* 107 */     return this.offsetPosX;
/*     */   }
/*     */   
/*     */   public float getOffsetY() {
/* 111 */     return this.offsetPosY;
/*     */   }
/*     */   
/*     */   public float getOffsetZ() {
/* 115 */     return this.offsetPosZ;
/*     */   }
/*     */   
/*     */   public float getRotX() {
/* 119 */     return this.rotX;
/*     */   }
/*     */   
/*     */   public float getRotY() {
/* 123 */     return this.rotY;
/*     */   }
/*     */   
/*     */   public float getRotZ() {
/* 127 */     return this.rotZ;
/*     */   }
/*     */   
/*     */   public float getBendAxis() {
/* 131 */     return this.bendAxis;
/*     */   }
/*     */   
/*     */   public float getBend() {
/* 135 */     return this.bend;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void updateScale(float scaleX, float scaleY, float scaleZ) {
/* 142 */     this.scaleX = scaleX;
/* 143 */     this.scaleY = scaleY;
/* 144 */     this.scaleZ = scaleZ;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void updateOffset(float offsetX, float offsetY, float offsetZ) {
/* 151 */     this.offsetPosX = offsetX;
/* 152 */     this.offsetPosY = offsetY;
/* 153 */     this.offsetPosZ = offsetZ;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void updateRotation(float rotX, float rotY, float rotZ) {
/* 160 */     this.rotX = rotX;
/* 161 */     this.rotY = rotY;
/* 162 */     this.rotZ = rotZ;
/*     */   }
/*     */   
/*     */   public void updateBend(float bendAxis, float bend) {
/* 166 */     this.bendAxis = bendAxis;
/* 167 */     this.bend = bend;
/*     */   }
/*     */   
/*     */   public void updateBend(Pair<Float, Float> bend) {
/* 171 */     updateBend(((Float)bend.left()).floatValue(), ((Float)bend.right()).floatValue());
/*     */   }
/*     */   
/*     */   public Vec3f getTransformFromType(TransformType type) {
/* 175 */     switch (type) {
/*     */       case POSITION:
/* 177 */         return new Vec3f(this.offsetPosX, this.offsetPosY, this.offsetPosZ);
/*     */       
/*     */       case ROTATION:
/* 180 */         return new Vec3f(this.rotX, this.rotY, this.rotZ);
/*     */       
/*     */       case SCALE:
/* 183 */         return new Vec3f(this.scaleX, this.scaleY, this.scaleZ);
/*     */       
/*     */       case BEND:
/* 186 */         return new Vec3f(this.bendAxis, this.bend, 0.0F);
/*     */     } 
/*     */     
/* 189 */     return null;
/*     */   }
/*     */   
/*     */   public void setToInitialPose() {
/* 193 */     this.rotX = 0.0F;
/* 194 */     this.rotY = 0.0F;
/* 195 */     this.rotZ = 0.0F;
/*     */     
/* 197 */     this.offsetPosX = 0.0F;
/* 198 */     this.offsetPosY = 0.0F;
/* 199 */     this.offsetPosZ = 0.0F;
/*     */     
/* 201 */     this.scaleX = 1.0F;
/* 202 */     this.scaleY = 1.0F;
/* 203 */     this.scaleZ = 1.0F;
/*     */     
/* 205 */     this.bendAxis = 0.0F;
/* 206 */     this.bend = 0.0F;
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean equals(Object obj) {
/* 211 */     if (this == obj) {
/* 212 */       return true;
/*     */     }
/* 214 */     if (obj == null || getClass() != obj.getClass()) {
/* 215 */       return false;
/*     */     }
/* 217 */     return (hashCode() == obj.hashCode());
/*     */   }
/*     */ 
/*     */   
/*     */   public int hashCode() {
/* 222 */     return this.bone.getName().hashCode();
/*     */   }
/*     */ }


/* Location:              C:\Users\rapha\Downloads\aurora.jar!\META-INF\jars\player-animation-library-wJLdv4ZQ.jar!\com\zigythebird\playeranimcore\bones\BoneSnapshot.class
 * Java compiler version: 21 (65.0)
 * JD-Core Version:       1.1.3
 */