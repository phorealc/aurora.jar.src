/*     */ package com.zigythebird.playeranimcore.bones;
/*     */ 
/*     */ import com.zigythebird.playeranimcore.animation.Animation;
/*     */ import com.zigythebird.playeranimcore.animation.keyframe.BoneAnimation;
/*     */ import com.zigythebird.playeranimcore.animation.keyframe.Keyframe;
/*     */ import com.zigythebird.playeranimcore.animation.keyframe.KeyframeStack;
/*     */ import com.zigythebird.playeranimcore.easing.EasingType;
/*     */ import com.zigythebird.playeranimcore.enums.Axis;
/*     */ import com.zigythebird.playeranimcore.enums.TransformType;
/*     */ import com.zigythebird.playeranimcore.math.Vec3f;
/*     */ import java.util.List;
/*     */ import org.jetbrains.annotations.ApiStatus.Internal;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class PlayerAnimBone
/*     */ {
/*     */   private final String name;
/*  22 */   public float scaleX = 1.0F;
/*  23 */   public float scaleY = 1.0F;
/*  24 */   public float scaleZ = 1.0F;
/*     */   
/*     */   public float positionX;
/*     */   
/*     */   public float positionY;
/*     */   
/*     */   public float positionZ;
/*     */   public float rotX;
/*     */   public float rotY;
/*     */   public float rotZ;
/*     */   public float bend;
/*     */   
/*     */   public PlayerAnimBone(String name) {
/*  37 */     this.name = name;
/*     */   }
/*     */   
/*     */   public String getName() {
/*  41 */     return this.name;
/*     */   }
/*     */   
/*     */   public float getRotX() {
/*  45 */     return this.rotX;
/*     */   }
/*     */   
/*     */   public float getRotY() {
/*  49 */     return this.rotY;
/*     */   }
/*     */   
/*     */   public float getRotZ() {
/*  53 */     return this.rotZ;
/*     */   }
/*     */   
/*     */   public float getPosX() {
/*  57 */     return this.positionX;
/*     */   }
/*     */   
/*     */   public float getPosY() {
/*  61 */     return this.positionY;
/*     */   }
/*     */   
/*     */   public float getPosZ() {
/*  65 */     return this.positionZ;
/*     */   }
/*     */   
/*     */   public float getScaleX() {
/*  69 */     return this.scaleX;
/*     */   }
/*     */   
/*     */   public float getScaleY() {
/*  73 */     return this.scaleY;
/*     */   }
/*     */   
/*     */   public float getScaleZ() {
/*  77 */     return this.scaleZ;
/*     */   }
/*     */   
/*     */   public float getBend() {
/*  81 */     return this.bend;
/*     */   }
/*     */   
/*     */   public void setRotX(float value) {
/*  85 */     this.rotX = value;
/*     */   }
/*     */   
/*     */   public void setRotY(float value) {
/*  89 */     this.rotY = value;
/*     */   }
/*     */   
/*     */   public void setRotZ(float value) {
/*  93 */     this.rotZ = value;
/*     */   }
/*     */   
/*     */   public void updateRotation(float xRot, float yRot, float zRot) {
/*  97 */     setRotX(xRot);
/*  98 */     setRotY(yRot);
/*  99 */     setRotZ(zRot);
/*     */   }
/*     */   
/*     */   public void setPosX(float value) {
/* 103 */     this.positionX = value;
/*     */   }
/*     */   
/*     */   public void setPosY(float value) {
/* 107 */     this.positionY = value;
/*     */   }
/*     */   
/*     */   public void setPosZ(float value) {
/* 111 */     this.positionZ = value;
/*     */   }
/*     */   
/*     */   public void updatePosition(float posX, float posY, float posZ) {
/* 115 */     setPosX(posX);
/* 116 */     setPosY(posY);
/* 117 */     setPosZ(posZ);
/*     */   }
/*     */   
/*     */   public void setScaleX(float value) {
/* 121 */     this.scaleX = value;
/*     */   }
/*     */   
/*     */   public void setScaleY(float value) {
/* 125 */     this.scaleY = value;
/*     */   }
/*     */   
/*     */   public void setScaleZ(float value) {
/* 129 */     this.scaleZ = value;
/*     */   }
/*     */   
/*     */   public void updateScale(float scaleX, float scaleY, float scaleZ) {
/* 133 */     setScaleX(scaleX);
/* 134 */     setScaleY(scaleY);
/* 135 */     setScaleZ(scaleZ);
/*     */   }
/*     */   
/*     */   public void setBend(float value) {
/* 139 */     this.bend = value;
/*     */   }
/*     */   
/*     */   public void setToInitialPose() {
/* 143 */     this.positionX = 0.0F;
/* 144 */     this.positionY = 0.0F;
/* 145 */     this.positionZ = 0.0F;
/*     */     
/* 147 */     this.rotX = 0.0F;
/* 148 */     this.rotY = 0.0F;
/* 149 */     this.rotZ = 0.0F;
/*     */     
/* 151 */     this.scaleX = 1.0F;
/* 152 */     this.scaleY = 1.0F;
/* 153 */     this.scaleZ = 1.0F;
/*     */     
/* 155 */     this.bend = 0.0F;
/*     */   }
/*     */   
/*     */   public Vec3f getPositionVector() {
/* 159 */     return new Vec3f(getPosX(), getPosY(), getPosZ());
/*     */   }
/*     */   
/*     */   public Vec3f getRotationVector() {
/* 163 */     return new Vec3f(getRotX(), getRotY(), getRotZ());
/*     */   }
/*     */   
/*     */   public Vec3f getScaleVector() {
/* 167 */     return new Vec3f(getScaleX(), getScaleY(), getScaleZ());
/*     */   }
/*     */   
/*     */   public void addRotationOffsetFromBone(PlayerAnimBone source) {
/* 171 */     setRotX(getRotX() + source.getRotX());
/* 172 */     setRotY(getRotY() + source.getRotY());
/* 173 */     setRotZ(getRotZ() + source.getRotZ());
/*     */   }
/*     */   
/*     */   public PlayerAnimBone scale(float value) {
/* 177 */     this.positionX *= value;
/* 178 */     this.positionY *= value;
/* 179 */     this.positionZ *= value;
/*     */     
/* 181 */     this.rotX *= value;
/* 182 */     this.rotY *= value;
/* 183 */     this.rotZ *= value;
/*     */     
/* 185 */     this.scaleX *= value;
/* 186 */     this.scaleY *= value;
/* 187 */     this.scaleZ *= value;
/*     */     
/* 189 */     this.bend *= value;
/*     */     
/* 191 */     return this;
/*     */   }
/*     */   
/*     */   public PlayerAnimBone add(PlayerAnimBone bone) {
/* 195 */     this.positionX += bone.positionX;
/* 196 */     this.positionY += bone.positionY;
/* 197 */     this.positionZ += bone.positionZ;
/*     */     
/* 199 */     this.rotX += bone.rotX;
/* 200 */     this.rotY += bone.rotY;
/* 201 */     this.rotZ += bone.rotZ;
/*     */     
/* 203 */     this.scaleX += bone.scaleX;
/* 204 */     this.scaleY += bone.scaleY;
/* 205 */     this.scaleZ += bone.scaleZ;
/*     */     
/* 207 */     this.bend += bone.bend;
/*     */     
/* 209 */     return this;
/*     */   }
/*     */   
/*     */   public PlayerAnimBone applyOtherBone(PlayerAnimBone bone) {
/* 213 */     this.positionX += bone.positionX;
/* 214 */     this.positionY += bone.positionY;
/* 215 */     this.positionZ += bone.positionZ;
/*     */     
/* 217 */     this.rotX += bone.rotX;
/* 218 */     this.rotY += bone.rotY;
/* 219 */     this.rotZ += bone.rotZ;
/*     */     
/* 221 */     this.scaleX *= bone.scaleX;
/* 222 */     this.scaleY *= bone.scaleY;
/* 223 */     this.scaleZ *= bone.scaleZ;
/*     */     
/* 225 */     this.bend += bone.bend;
/*     */     
/* 227 */     return this;
/*     */   }
/*     */   
/*     */   public PlayerAnimBone addPos(float value) {
/* 231 */     return addPos(value, value, value);
/*     */   }
/*     */   
/*     */   public PlayerAnimBone mulPos(float value) {
/* 235 */     return mulPos(value, value, value);
/*     */   }
/*     */   
/*     */   public PlayerAnimBone divPos(float value) {
/* 239 */     return divPos(value, value, value);
/*     */   }
/*     */   
/*     */   public PlayerAnimBone addRot(float value) {
/* 243 */     return addRot(value, value, value);
/*     */   }
/*     */   
/*     */   public PlayerAnimBone mulRot(float value) {
/* 247 */     return mulRot(value, value, value);
/*     */   }
/*     */   
/*     */   public PlayerAnimBone divRot(float value) {
/* 251 */     return divRot(value, value, value);
/*     */   }
/*     */   
/*     */   public PlayerAnimBone addScale(float value) {
/* 255 */     return addScale(value, value, value);
/*     */   }
/*     */   
/*     */   public PlayerAnimBone mulScale(float value) {
/* 259 */     return mulScale(value, value, value);
/*     */   }
/*     */   
/*     */   public PlayerAnimBone divScale(float value) {
/* 263 */     return divScale(value, value, value);
/*     */   }
/*     */   
/*     */   public PlayerAnimBone addPos(float x, float y, float z) {
/* 267 */     this.positionX += x;
/* 268 */     this.positionY += y;
/* 269 */     this.positionZ += z;
/*     */     
/* 271 */     return this;
/*     */   }
/*     */   
/*     */   public PlayerAnimBone addRot(float x, float y, float z) {
/* 275 */     this.rotX += x;
/* 276 */     this.rotY += y;
/* 277 */     this.rotZ += z;
/*     */     
/* 279 */     return this;
/*     */   }
/*     */   
/*     */   public PlayerAnimBone addScale(float x, float y, float z) {
/* 283 */     this.scaleX += x;
/* 284 */     this.scaleY += y;
/* 285 */     this.scaleZ += z;
/*     */     
/* 287 */     return this;
/*     */   }
/*     */   
/*     */   public PlayerAnimBone mulPos(float x, float y, float z) {
/* 291 */     this.positionX *= x;
/* 292 */     this.positionY *= y;
/* 293 */     this.positionZ *= z;
/* 294 */     return this;
/*     */   }
/*     */   
/*     */   public PlayerAnimBone mulRot(float x, float y, float z) {
/* 298 */     this.rotX *= x;
/* 299 */     this.rotY *= y;
/* 300 */     this.rotZ *= z;
/* 301 */     return this;
/*     */   }
/*     */   
/*     */   public PlayerAnimBone mulScale(float x, float y, float z) {
/* 305 */     this.scaleX *= x;
/* 306 */     this.scaleY *= y;
/* 307 */     this.scaleZ *= z;
/* 308 */     return this;
/*     */   }
/*     */   
/*     */   public PlayerAnimBone divPos(float x, float y, float z) {
/* 312 */     this.positionX /= x;
/* 313 */     this.positionY /= y;
/* 314 */     this.positionZ /= z;
/* 315 */     return this;
/*     */   }
/*     */   
/*     */   public PlayerAnimBone divRot(float x, float y, float z) {
/* 319 */     this.rotX /= x;
/* 320 */     this.rotY /= y;
/* 321 */     this.rotZ /= z;
/* 322 */     return this;
/*     */   }
/*     */   
/*     */   public PlayerAnimBone divScale(float x, float y, float z) {
/* 326 */     this.scaleX /= x;
/* 327 */     this.scaleY /= y;
/* 328 */     this.scaleZ /= z;
/* 329 */     return this;
/*     */   }
/*     */   
/*     */   public PlayerAnimBone copyOtherBone(PlayerAnimBone bone) {
/* 333 */     this.positionX = bone.positionX;
/* 334 */     this.positionY = bone.positionY;
/* 335 */     this.positionZ = bone.positionZ;
/*     */     
/* 337 */     this.rotX = bone.rotX;
/* 338 */     this.rotY = bone.rotY;
/* 339 */     this.rotZ = bone.rotZ;
/*     */     
/* 341 */     this.scaleX = bone.scaleX;
/* 342 */     this.scaleY = bone.scaleY;
/* 343 */     this.scaleZ = bone.scaleZ;
/*     */     
/* 345 */     this.bend = bone.bend;
/* 346 */     return this;
/*     */   }
/*     */   
/*     */   public PlayerAnimBone copyOtherBoneIfNotDisabled(PlayerAnimBone bone) {
/* 350 */     if (bone instanceof IBoneEnabled) { IBoneEnabled advancedBone = (IBoneEnabled)bone;
/* 351 */       if (advancedBone.isPositionXEnabled())
/* 352 */         this.positionX = bone.positionX; 
/* 353 */       if (advancedBone.isPositionYEnabled())
/* 354 */         this.positionY = bone.positionY; 
/* 355 */       if (advancedBone.isPositionZEnabled()) {
/* 356 */         this.positionZ = bone.positionZ;
/*     */       }
/* 358 */       if (advancedBone.isRotXEnabled())
/* 359 */         this.rotX = bone.rotX; 
/* 360 */       if (advancedBone.isRotYEnabled())
/* 361 */         this.rotY = bone.rotY; 
/* 362 */       if (advancedBone.isRotZEnabled()) {
/* 363 */         this.rotZ = bone.rotZ;
/*     */       }
/* 365 */       if (advancedBone.isScaleXEnabled())
/* 366 */         this.scaleX = bone.scaleX; 
/* 367 */       if (advancedBone.isScaleYEnabled())
/* 368 */         this.scaleY = bone.scaleY; 
/* 369 */       if (advancedBone.isScaleZEnabled()) {
/* 370 */         this.scaleZ = bone.scaleZ;
/*     */       }
/* 372 */       if (advancedBone.isBendEnabled()) {
/* 373 */         this.bend = bone.bend;
/*     */       }
/* 375 */       return this; }
/*     */     
/* 377 */     return copyOtherBone(bone);
/*     */   }
/*     */   
/*     */   @Internal
/*     */   public PlayerAnimBone beginOrEndTickLerp(AdvancedPlayerAnimBone bone, float animTime, Animation animation) {
/* 382 */     if (bone.positionXEnabled)
/* 383 */       this.positionX = beginOrEndTickLerp(this.positionX, bone.positionX, bone.positionXTransitionLength, animTime, animation, TransformType.POSITION, Axis.X); 
/* 384 */     if (bone.positionYEnabled)
/* 385 */       this.positionY = beginOrEndTickLerp(this.positionY, bone.positionY, bone.positionYTransitionLength, animTime, animation, TransformType.POSITION, Axis.Y); 
/* 386 */     if (bone.positionZEnabled) {
/* 387 */       this.positionZ = beginOrEndTickLerp(this.positionZ, bone.positionZ, bone.positionZTransitionLength, animTime, animation, TransformType.POSITION, Axis.Z);
/*     */     }
/* 389 */     if (bone.rotXEnabled)
/* 390 */       this.rotX = beginOrEndTickLerp(this.rotX, bone.rotX, bone.rotXTransitionLength, animTime, animation, TransformType.ROTATION, Axis.X); 
/* 391 */     if (bone.rotYEnabled)
/* 392 */       this.rotY = beginOrEndTickLerp(this.rotY, bone.rotY, bone.rotYTransitionLength, animTime, animation, TransformType.ROTATION, Axis.Y); 
/* 393 */     if (bone.rotZEnabled) {
/* 394 */       this.rotZ = beginOrEndTickLerp(this.rotZ, bone.rotZ, bone.rotZTransitionLength, animTime, animation, TransformType.ROTATION, Axis.Z);
/*     */     }
/* 396 */     if (bone.scaleXEnabled)
/* 397 */       this.scaleX = beginOrEndTickLerp(this.scaleX, bone.scaleX, bone.scaleXTransitionLength, animTime, animation, TransformType.SCALE, Axis.X); 
/* 398 */     if (bone.scaleYEnabled)
/* 399 */       this.scaleY = beginOrEndTickLerp(this.scaleY, bone.scaleY, bone.scaleYTransitionLength, animTime, animation, TransformType.SCALE, Axis.Y); 
/* 400 */     if (bone.scaleZEnabled) {
/* 401 */       this.scaleZ = beginOrEndTickLerp(this.scaleZ, bone.scaleZ, bone.scaleZTransitionLength, animTime, animation, TransformType.SCALE, Axis.Z);
/*     */     }
/* 403 */     if (bone.bendEnabled) {
/* 404 */       this.bend = beginOrEndTickLerp(this.bend, bone.bend, bone.bendTransitionLength, animTime, animation, TransformType.BEND, Axis.Y);
/*     */     }
/* 406 */     return this;
/*     */   }
/*     */   
/*     */   private float beginOrEndTickLerp(float startValue, float endValue, Float transitionLength, float animTime, Animation animation, TransformType type, Axis axis) {
/* 410 */     EasingType easingType = EasingType.EASE_IN_OUT_SINE;
/* 411 */     if (animation != null) {
/* 412 */       float temp = startValue;
/* 413 */       startValue = endValue;
/* 414 */       endValue = temp;
/*     */       
/* 416 */       if (transitionLength == null) transitionLength = Float.valueOf(animation.length() - ((Float)animation.data().getRaw("endTick")).floatValue());
/*     */       
/* 418 */       if (animation.data().has("easeBeforeKeyframe") && !((Boolean)animation.data().getRaw("easeBeforeKeyframe")).booleanValue()) {
/* 419 */         List<Keyframe> bendKeyFrames; BoneAnimation boneAnimation = animation.getBone(getName());
/* 420 */         switch (type) { default: throw new MatchException(null, null);
/*     */           case BEND:
/* 422 */             bendKeyFrames = boneAnimation.bendKeyFrames();
/* 423 */             if (!bendKeyFrames.isEmpty()) easingType = ((Keyframe)bendKeyFrames.getLast()).easingType(); 
/*     */           case ROTATION: 
/*     */           case SCALE:
/*     */           
/*     */           case POSITION:
/* 428 */             break; }  KeyframeStack keyframeStack = (boneAnimation == null) ? null : boneAnimation.positionKeyFrames();
/*     */         
/* 430 */         if (keyframeStack != null) {
/* 431 */           List<Keyframe> keyFrames = keyframeStack.getKeyFramesForAxis(axis);
/* 432 */           if (!keyFrames.isEmpty()) easingType = ((Keyframe)keyFrames.getLast()).easingType(); 
/*     */         } 
/*     */       } 
/* 435 */       if (easingType == EasingType.BEZIER || easingType == EasingType.CATMULLROM)
/* 436 */         easingType = EasingType.EASE_IN_OUT_SINE; 
/*     */     } 
/* 438 */     if (transitionLength == null) return endValue; 
/* 439 */     return easingType.apply(startValue, endValue, animTime / transitionLength.floatValue());
/*     */   }
/*     */   
/*     */   public void copySnapshot(BoneSnapshot snapshot) {
/* 443 */     this.positionX = snapshot.getOffsetX();
/* 444 */     this.positionY = snapshot.getOffsetY();
/* 445 */     this.positionZ = snapshot.getOffsetZ();
/*     */     
/* 447 */     this.rotX = snapshot.getRotX();
/* 448 */     this.rotY = snapshot.getRotY();
/* 449 */     this.rotZ = snapshot.getRotZ();
/*     */     
/* 451 */     this.scaleX = snapshot.getScaleX();
/* 452 */     this.scaleY = snapshot.getScaleY();
/* 453 */     this.scaleZ = snapshot.getScaleZ();
/*     */     
/* 455 */     this.bend = snapshot.getBend();
/*     */   }
/*     */   
/*     */   public PlayerAnimBone copySnapshotSafe(AdvancedBoneSnapshot snapshot) {
/* 459 */     if (snapshot.positionXEnabled)
/* 460 */       this.positionX = snapshot.getOffsetX(); 
/* 461 */     if (snapshot.positionYEnabled)
/* 462 */       this.positionY = snapshot.getOffsetY(); 
/* 463 */     if (snapshot.positionZEnabled) {
/* 464 */       this.positionZ = snapshot.getOffsetZ();
/*     */     }
/* 466 */     if (snapshot.rotXEnabled)
/* 467 */       this.rotX = snapshot.getRotX(); 
/* 468 */     if (snapshot.rotYEnabled)
/* 469 */       this.rotY = snapshot.getRotY(); 
/* 470 */     if (snapshot.rotZEnabled) {
/* 471 */       this.rotZ = snapshot.getRotZ();
/*     */     }
/* 473 */     if (snapshot.scaleXEnabled)
/* 474 */       this.scaleX = snapshot.getScaleX(); 
/* 475 */     if (snapshot.scaleYEnabled)
/* 476 */       this.scaleY = snapshot.getScaleY(); 
/* 477 */     if (snapshot.scaleZEnabled) {
/* 478 */       this.scaleZ = snapshot.getScaleZ();
/*     */     }
/* 480 */     if (snapshot.bendEnabled) {
/* 481 */       this.bend = snapshot.getBend();
/*     */     }
/* 483 */     return this;
/*     */   }
/*     */   
/*     */   public BoneSnapshot saveSnapshot() {
/* 487 */     return new BoneSnapshot(this);
/*     */   }
/*     */   
/*     */   public boolean equals(Object obj) {
/* 491 */     if (this == obj) {
/* 492 */       return true;
/*     */     }
/* 494 */     if (obj == null || getClass() != obj.getClass()) {
/* 495 */       return false;
/*     */     }
/* 497 */     return (hashCode() == obj.hashCode());
/*     */   }
/*     */   
/*     */   public int hashCode() {
/* 501 */     return getName().hashCode();
/*     */   }
/*     */ }


/* Location:              C:\Users\rapha\Downloads\aurora.jar!\META-INF\jars\player-animation-library-wJLdv4ZQ.jar!\com\zigythebird\playeranimcore\bones\PlayerAnimBone.class
 * Java compiler version: 21 (65.0)
 * JD-Core Version:       1.1.3
 */