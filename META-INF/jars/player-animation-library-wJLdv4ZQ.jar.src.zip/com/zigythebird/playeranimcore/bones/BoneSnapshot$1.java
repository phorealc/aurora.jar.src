/*     */ package com.zigythebird.playeranimcore.bones;
/*     */ 
/*     */ import com.zigythebird.playeranimcore.enums.TransformType;
/*     */ 


/* Location:              C:\Users\rapha\Downloads\aurora.jar!\META-INF\jars\player-animation-library-wJLdv4ZQ.jar!\com\zigythebird\playeranimcore\bones\BoneSnapshot$1.class
 * Java compiler version: 21 (65.0)
 * JD-Core Version:       1.1.3
 */