package com.zigythebird.playeranimcore.bones;

public interface IBoneEnabled {
  boolean isScaleXEnabled();
  
  boolean isScaleYEnabled();
  
  boolean isScaleZEnabled();
  
  boolean isPositionXEnabled();
  
  boolean isPositionYEnabled();
  
  boolean isPositionZEnabled();
  
  boolean isRotXEnabled();
  
  boolean isRotYEnabled();
  
  boolean isRotZEnabled();
  
  boolean isBendEnabled();
}


/* Location:              C:\Users\rapha\Downloads\aurora.jar!\META-INF\jars\player-animation-library-wJLdv4ZQ.jar!\com\zigythebird\playeranimcore\bones\IBoneEnabled.class
 * Java compiler version: 21 (65.0)
 * JD-Core Version:       1.1.3
 */