/*    */ package com.zigythebird.playeranimcore.math;
/*    */ 
/*    */ import team.unnamed.mocha.runtime.standard.MochaMath;
/*    */ 
/*    */ 
/*    */ 
/*    */ public class MathHelper
/*    */ {
/*    */   public static float cos(float a) {
/* 10 */     return (float)Math.cos(a);
/*    */   }
/*    */   
/*    */   public static float cosFromSin(float sin, float angle) {
/* 14 */     float cos = MochaMath.sqrt(1.0F - sin * sin);
/* 15 */     float a = angle + 1.5707964F;
/* 16 */     float b = a - (int)(a / 6.2831855F) * 6.2831855F;
/* 17 */     if (b < 0.0D) {
/* 18 */       b += 6.2831855F;
/*    */     }
/*    */     
/* 21 */     return (b >= 3.1415927F) ? -cos : cos;
/*    */   }
/*    */   
/*    */   public static boolean absEqualsOne(float r) {
/* 25 */     return ((Float.floatToRawIntBits(r) & Integer.MAX_VALUE) == 1065353216);
/*    */   }
/*    */   
/*    */   public static float safeAsin(float r) {
/* 29 */     return (r <= -1.0F) ? -1.5707964F : (float)((r >= 1.0F) ? 1.5707963705062866D : Math.asin(r));
/*    */   }
/*    */   
/*    */   public static float length(float x, float y, float z, float w) {
/* 33 */     return MochaMath.sqrt(Math.fma(x, x, Math.fma(y, y, Math.fma(z, z, w * w))));
/*    */   }
/*    */ }


/* Location:              C:\Users\rapha\Downloads\aurora.jar!\META-INF\jars\player-animation-library-wJLdv4ZQ.jar!\com\zigythebird\playeranimcore\math\MathHelper.class
 * Java compiler version: 21 (65.0)
 * JD-Core Version:       1.1.3
 */