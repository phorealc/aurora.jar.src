/*    */ package com.zigythebird.playeranimcore.math;
/*    */ public final class Vec3f extends Record {
/*    */   private final float x;
/*    */   
/*  5 */   public Vec3f(float x, float y, float z) { this.x = x; this.y = y; this.z = z; } private final float y; private final float z; public float x() { return this.x; } public float y() { return this.y; } public float z() { return this.z; }
/*  6 */    public static final Vec3f ZERO = new Vec3f(0.0F, 0.0F, 0.0F);
/*  7 */   public static final Vec3f ONE = new Vec3f(1.0F, 1.0F, 1.0F);
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public Vec3f mul(float scalar) {
/* 16 */     return new Vec3f(this.x * scalar, this.y * scalar, this.z * scalar);
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public Vec3f add(Vec3f other) {
/* 26 */     return new Vec3f(this.x + other.x, this.y + other.y, this.z + other.z);
/*    */   }
/*    */   
/*    */   public boolean equals(Object o) {
/*    */     Vec3f vec;
/* 31 */     if (this == o) return true; 
/* 32 */     if (o instanceof Vec3f) { vec = (Vec3f)o; } else { return false; }
/* 33 */      return (Objects.equals(Float.valueOf(this.x), Float.valueOf(vec.x)) && Objects.equals(Float.valueOf(this.y), Float.valueOf(vec.y)) && Objects.equals(Float.valueOf(this.z), Float.valueOf(vec.z)));
/*    */   }
/*    */ 
/*    */   
/*    */   public String toString() {
/* 38 */     return "Vec3f[" + this.x + "; " + this.y + "; " + this.z + "]";
/*    */   }
/*    */ 
/*    */   
/*    */   public int hashCode() {
/* 43 */     return Objects.hash(new Object[] { Float.valueOf(this.x), Float.valueOf(this.y), Float.valueOf(this.z) });
/*    */   }
/*    */ }


/* Location:              C:\Users\rapha\Downloads\aurora.jar!\META-INF\jars\player-animation-library-wJLdv4ZQ.jar!\com\zigythebird\playeranimcore\math\Vec3f.class
 * Java compiler version: 21 (65.0)
 * JD-Core Version:       1.1.3
 */