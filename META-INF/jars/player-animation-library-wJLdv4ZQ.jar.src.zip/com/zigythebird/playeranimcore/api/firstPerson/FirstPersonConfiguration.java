/*    */ package com.zigythebird.playeranimcore.api.firstPerson;
/*    */ 
/*    */ public class FirstPersonConfiguration
/*    */ {
/*    */   boolean showRightArm = false;
/*    */   boolean showLeftArm = false;
/*    */   boolean showRightItem = true;
/*    */   boolean showLeftItem = true;
/*    */   boolean showArmor = false;
/*    */   
/*    */   public FirstPersonConfiguration() {}
/*    */   
/*    */   public FirstPersonConfiguration(boolean showRightArm, boolean showLeftArm, boolean showRightItem, boolean showLeftItem) {
/* 14 */     this(showRightArm, showLeftArm, showRightItem, showLeftItem, false);
/*    */   }
/*    */   
/*    */   public FirstPersonConfiguration(boolean showRightArm, boolean showLeftArm, boolean showRightItem, boolean showLeftItem, boolean showArmor) {
/* 18 */     this.showRightArm = showRightArm;
/* 19 */     this.showLeftArm = showLeftArm;
/* 20 */     this.showRightItem = showRightItem;
/* 21 */     this.showLeftItem = showLeftItem;
/* 22 */     this.showArmor = showArmor;
/*    */   }
/*    */   
/*    */   public boolean isShowArmor() {
/* 26 */     return this.showArmor;
/*    */   }
/*    */   
/*    */   public boolean isShowLeftItem() {
/* 30 */     return this.showLeftItem;
/*    */   }
/*    */   
/*    */   public boolean isShowRightItem() {
/* 34 */     return this.showRightItem;
/*    */   }
/*    */   
/*    */   public boolean isShowLeftArm() {
/* 38 */     return this.showLeftArm;
/*    */   }
/*    */   
/*    */   public boolean isShowRightArm() {
/* 42 */     return this.showRightArm;
/*    */   }
/*    */   
/*    */   public FirstPersonConfiguration setShowRightItem(boolean showRightItem) {
/* 46 */     this.showRightItem = showRightItem;
/* 47 */     return this;
/*    */   }
/*    */   
/*    */   public FirstPersonConfiguration setShowArmor(boolean showArmor) {
/* 51 */     this.showArmor = showArmor;
/* 52 */     return this;
/*    */   }
/*    */   
/*    */   public FirstPersonConfiguration setShowLeftItem(boolean showLeftItem) {
/* 56 */     this.showLeftItem = showLeftItem;
/* 57 */     return this;
/*    */   }
/*    */   
/*    */   public FirstPersonConfiguration setShowLeftArm(boolean showLeftArm) {
/* 61 */     this.showLeftArm = showLeftArm;
/* 62 */     return this;
/*    */   }
/*    */   
/*    */   public FirstPersonConfiguration setShowRightArm(boolean showRightArm) {
/* 66 */     this.showRightArm = showRightArm;
/* 67 */     return this;
/*    */   }
/*    */ }


/* Location:              C:\Users\rapha\Downloads\aurora.jar!\META-INF\jars\player-animation-library-wJLdv4ZQ.jar!\com\zigythebird\playeranimcore\api\firstPerson\FirstPersonConfiguration.class
 * Java compiler version: 21 (65.0)
 * JD-Core Version:       1.1.3
 */