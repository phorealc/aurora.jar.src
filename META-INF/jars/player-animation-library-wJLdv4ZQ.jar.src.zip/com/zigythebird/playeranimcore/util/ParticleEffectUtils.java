/*    */ package com.zigythebird.playeranimcore.util;
/*    */ 
/*    */ import com.google.gson.JsonObject;
/*    */ import com.zigythebird.playeranimcore.PlayerAnimLib;
/*    */ 
/*    */ public class ParticleEffectUtils {
/*    */   public static String parseIdentifier(String raw) {
/*  8 */     return getIdentifier((JsonObject)PlayerAnimLib.GSON.fromJson(raw, JsonObject.class));
/*    */   }
/*    */   
/*    */   public static String getIdentifier(JsonObject obj) {
/* 12 */     return obj.getAsJsonObject("particle_effect")
/* 13 */       .getAsJsonObject("description")
/* 14 */       .get("identifier").getAsString();
/*    */   }
/*    */ }


/* Location:              C:\Users\rapha\Downloads\aurora.jar!\META-INF\jars\player-animation-library-wJLdv4ZQ.jar!\com\zigythebird\playeranimcor\\util\ParticleEffectUtils.class
 * Java compiler version: 21 (65.0)
 * JD-Core Version:       1.1.3
 */