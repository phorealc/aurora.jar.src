/*    */ package com.zigythebird.playeranimcore.util;
/*    */ 
/*    */ import com.zigythebird.playeranimcore.bones.PivotBone;
/*    */ import com.zigythebird.playeranimcore.bones.PlayerAnimBone;
/*    */ import com.zigythebird.playeranimcore.math.Vec3f;
/*    */ import java.util.function.Function;
/*    */ import org.joml.Matrix4f;
/*    */ import org.joml.Vector3f;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class MatrixUtil
/*    */ {
/*    */   public static void translateMatrixForBone(Matrix4f matrix, PlayerAnimBone bone) {
/* 17 */     matrix.translate(-bone.getPosX(), bone.getPosY(), -bone.getPosZ());
/*    */   }
/*    */   
/*    */   public static void rotateMatrixAroundBone(Matrix4f matrix, PlayerAnimBone bone) {
/* 21 */     if (bone.getRotZ() != 0.0F || bone.getRotY() != 0.0F || bone.getRotX() != 0.0F)
/* 22 */       matrix.rotateZ(bone.getRotZ()).rotateY(bone.getRotY()).rotateX(bone.getRotX()); 
/*    */   }
/*    */   
/*    */   public static void scaleMatrixForBone(Matrix4f matrix, PlayerAnimBone bone) {
/* 26 */     matrix.scale(bone.getScaleX(), bone.getScaleY(), bone.getScaleZ());
/*    */   }
/*    */   
/*    */   public static void translateToPivotPoint(Matrix4f matrix, Vec3f pivot) {
/* 30 */     matrix.translate(pivot.x(), pivot.y(), -pivot.z());
/*    */   }
/*    */   
/*    */   public static void translateAwayFromPivotPoint(Matrix4f matrix, Vec3f pivot) {
/* 34 */     matrix.translate(-pivot.x(), -pivot.y(), pivot.z());
/*    */   }
/*    */   
/*    */   public static void prepMatrixForBone(Matrix4f matrix, PlayerAnimBone bone, Vec3f pivot) {
/* 38 */     translateToPivotPoint(matrix, pivot);
/* 39 */     translateMatrixForBone(matrix, bone);
/* 40 */     rotateMatrixAroundBone(matrix, bone);
/* 41 */     scaleMatrixForBone(matrix, bone);
/* 42 */     translateAwayFromPivotPoint(matrix, pivot);
/*    */   }
/*    */   
/*    */   public static void applyParentsToChild(PlayerAnimBone child, Iterable<? extends PlayerAnimBone> parents, Function<String, Vec3f> positions) {
/* 46 */     Matrix4f matrix = new Matrix4f();
/*    */     
/* 48 */     for (PlayerAnimBone parent : parents) {
/* 49 */       PivotBone pivotBone = (PivotBone)parent; Vec3f pivot = (parent instanceof PivotBone) ? pivotBone.getPivot() : positions.apply(parent.getName());
/* 50 */       prepMatrixForBone(matrix, parent, pivot);
/*    */     } 
/*    */     
/* 53 */     applyMatrixToBone(child, matrix, positions.apply(child.getName()));
/*    */   }
/*    */   
/*    */   public static void applyMatrixToBone(PlayerAnimBone bone, Matrix4f matrix, Vec3f pivot) {
/* 57 */     translateToPivotPoint(matrix, pivot);
/* 58 */     translateMatrixForBone(matrix, bone);
/* 59 */     rotateMatrixAroundBone(matrix, bone);
/* 60 */     bone.setPosX(-matrix.m30() + pivot.x());
/* 61 */     bone.setPosY(matrix.m31() - pivot.y());
/* 62 */     bone.setPosZ(-matrix.m32() + pivot.z());
/*    */     
/* 64 */     Vector3f rotation = matrix.getEulerAnglesZYX(new Vector3f());
/* 65 */     bone.updateRotation(rotation.x(), rotation.y(), rotation.z());
/*    */     
/* 67 */     Vector3f scale = matrix.getScale(new Vector3f());
/* 68 */     bone.mulScale(scale.x(), scale.y(), scale.z());
/*    */   }
/*    */ }


/* Location:              C:\Users\rapha\Downloads\aurora.jar!\META-INF\jars\player-animation-library-wJLdv4ZQ.jar!\com\zigythebird\playeranimcor\\util\MatrixUtil.class
 * Java compiler version: 21 (65.0)
 * JD-Core Version:       1.1.3
 */