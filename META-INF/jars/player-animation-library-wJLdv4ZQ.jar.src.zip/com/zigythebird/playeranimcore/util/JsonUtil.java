/*     */ package com.zigythebird.playeranimcore.util;
/*     */ 
/*     */ import com.google.gson.JsonArray;
/*     */ import com.google.gson.JsonElement;
/*     */ import com.google.gson.JsonObject;
/*     */ import com.google.gson.JsonPrimitive;
/*     */ import com.google.gson.JsonSyntaxException;
/*     */ import it.unimi.dsi.fastutil.objects.ObjectArrayList;
/*     */ import java.util.List;
/*     */ import java.util.function.Function;
/*     */ import org.jetbrains.annotations.Contract;
/*     */ import org.jetbrains.annotations.Nullable;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class JsonUtil
/*     */ {
/*     */   public static <T> List<T> jsonArrayToList(@Nullable JsonArray array, Function<JsonElement, T> elementTransformer) {
/*  24 */     if (array == null) {
/*  25 */       return (List<T>)new ObjectArrayList();
/*     */     }
/*  27 */     ObjectArrayList objectArrayList = new ObjectArrayList(array.size());
/*     */     
/*  29 */     for (JsonElement element : array) {
/*  30 */       objectArrayList.add(elementTransformer.apply(element));
/*     */     }
/*     */     
/*  33 */     return (List<T>)objectArrayList;
/*     */   }
/*     */   
/*     */   @Nullable
/*     */   @Contract("_,_,!null->!null;_,_,null->_")
/*     */   public static String getAsString(JsonObject json, String memberName, @Nullable String fallback) {
/*  39 */     return json.has(memberName) ? convertToString(json.get(memberName), memberName) : fallback;
/*     */   }
/*     */   
/*     */   public static boolean convertToBoolean(JsonElement json, String memberName) {
/*  43 */     if (json.isJsonPrimitive()) {
/*  44 */       return json.getAsBoolean();
/*     */     }
/*  46 */     throw new JsonSyntaxException("Expected " + memberName + " to be a Boolean, was " + getType(json));
/*     */   }
/*     */ 
/*     */   
/*     */   public static boolean getAsBoolean(JsonObject json, String memberName, boolean fallback) {
/*  51 */     return json.has(memberName) ? convertToBoolean(json.get(memberName), memberName) : fallback;
/*     */   }
/*     */   
/*     */   public static float convertToFloat(JsonElement json, String memberName) {
/*  55 */     if (json.isJsonPrimitive() && json.getAsJsonPrimitive().isNumber()) {
/*  56 */       return json.getAsFloat();
/*     */     }
/*  58 */     throw new JsonSyntaxException("Expected " + memberName + " to be a Float, was " + getType(json));
/*     */   }
/*     */ 
/*     */   
/*     */   public static float getAsFloat(JsonObject json, String memberName) {
/*  63 */     if (json.has(memberName)) {
/*  64 */       return convertToFloat(json.get(memberName), memberName);
/*     */     }
/*  66 */     throw new JsonSyntaxException("Missing " + memberName + ", expected to find a Float");
/*     */   }
/*     */ 
/*     */   
/*     */   public static JsonObject convertToJsonObject(JsonElement json, String memberName) {
/*  71 */     if (json.isJsonObject()) {
/*  72 */       return json.getAsJsonObject();
/*     */     }
/*  74 */     throw new JsonSyntaxException("Expected " + memberName + " to be a JsonObject, was " + getType(json));
/*     */   }
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   @Contract("_,_,!null->!null;_,_,null->_")
/*     */   public static JsonObject getAsJsonObject(JsonObject json, String memberName, @Nullable JsonObject fallback) {
/*  81 */     return json.has(memberName) ? convertToJsonObject(json.get(memberName), memberName) : fallback;
/*     */   }
/*     */   
/*     */   public static String convertToString(JsonElement json, String memberName) {
/*  85 */     if (json.isJsonPrimitive()) {
/*  86 */       return json.getAsString();
/*     */     }
/*  88 */     throw new JsonSyntaxException("Expected " + memberName + " to be a string, was " + getType(json));
/*     */   }
/*     */ 
/*     */   
/*     */   public static String getAsString(JsonObject json, String memberName) {
/*  93 */     if (json.has(memberName)) {
/*  94 */       return convertToString(json.get(memberName), memberName);
/*     */     }
/*  96 */     throw new JsonSyntaxException("Missing " + memberName + ", expected to find a string");
/*     */   }
/*     */ 
/*     */   
/*     */   public static JsonArray convertToJsonArray(JsonElement json, String memberName) {
/* 101 */     if (json.isJsonArray()) {
/* 102 */       return json.getAsJsonArray();
/*     */     }
/* 104 */     throw new JsonSyntaxException("Expected " + memberName + " to be a JsonArray, was " + getType(json));
/*     */   }
/*     */ 
/*     */   
/*     */   public static JsonArray getAsJsonArray(JsonObject json, String memberName) {
/* 109 */     if (json.has(memberName)) {
/* 110 */       return convertToJsonArray(json.get(memberName), memberName);
/*     */     }
/* 112 */     throw new JsonSyntaxException("Missing " + memberName + ", expected to find a JsonArray");
/*     */   }
/*     */ 
/*     */   
/*     */   public static String getType(@Nullable JsonElement json) {
/* 117 */     String string = String.valueOf(json);
/* 118 */     if (json == null)
/* 119 */       return "null (missing)"; 
/* 120 */     if (json.isJsonNull())
/* 121 */       return "null (json)"; 
/* 122 */     if (json.isJsonArray())
/* 123 */       return "an array (" + string + ")"; 
/* 124 */     if (json.isJsonObject()) {
/* 125 */       return "an object (" + string + ")";
/*     */     }
/* 127 */     if (json.isJsonPrimitive()) {
/* 128 */       JsonPrimitive jsonPrimitive = json.getAsJsonPrimitive();
/* 129 */       if (jsonPrimitive.isNumber()) {
/* 130 */         return "a number (" + string + ")";
/*     */       }
/*     */       
/* 133 */       if (jsonPrimitive.isBoolean()) {
/* 134 */         return "a boolean (" + string + ")";
/*     */       }
/*     */     } 
/*     */     
/* 138 */     return string;
/*     */   }
/*     */ }


/* Location:              C:\Users\rapha\Downloads\aurora.jar!\META-INF\jars\player-animation-library-wJLdv4ZQ.jar!\com\zigythebird\playeranimcor\\util\JsonUtil.class
 * Java compiler version: 21 (65.0)
 * JD-Core Version:       1.1.3
 */