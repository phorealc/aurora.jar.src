/*    */ package com.zigythebird.playeranimcore.easing;
/*    */ 
/*    */ import com.zigythebird.playeranimcore.animation.keyframe.AnimationPoint;
/*    */ import it.unimi.dsi.fastutil.floats.Float2FloatFunction;
/*    */ import java.util.List;
/*    */ import org.jetbrains.annotations.Nullable;
/*    */ import team.unnamed.mocha.MochaEngine;
/*    */ import team.unnamed.mocha.runtime.standard.MochaMath;
/*    */ import team.unnamed.mocha.runtime.value.ObjectValue;
/*    */ 
/*    */ @FunctionalInterface
/*    */ public interface EasingTypeTransformer
/*    */   extends ObjectValue.FloatFunction3 {
/*    */   default float apply(MochaEngine<?> env, AnimationPoint animationPoint) {
/* 15 */     Float easingVariable = null;
/*    */     
/* 17 */     if (animationPoint.easingArgs() != null && !animationPoint.easingArgs().isEmpty()) {
/* 18 */       easingVariable = Float.valueOf(env.eval((List)animationPoint.easingArgs().getFirst()));
/*    */     }
/* 20 */     return apply(env, animationPoint, easingVariable, animationPoint.currentTick() / animationPoint.transitionLength());
/*    */   }
/*    */   Float2FloatFunction buildTransformer(@Nullable Float paramFloat);
/*    */   default float apply(MochaEngine<?> env, AnimationPoint animationPoint, @Nullable Float easingValue, float lerpValue) {
/* 24 */     if (lerpValue >= 1.0F)
/* 25 */       return animationPoint.animationEndValue(); 
/* 26 */     if (Float.isNaN(lerpValue)) {
/* 27 */       return animationPoint.animationStartValue();
/*    */     }
/* 29 */     return apply(animationPoint.animationStartValue(), animationPoint.animationEndValue(), easingValue, lerpValue);
/*    */   }
/*    */ 
/*    */   
/*    */   default float apply(float startValue, float endValue, float lerpValue) {
/* 34 */     return apply(startValue, endValue, (Float)null, lerpValue);
/*    */   }
/*    */   
/*    */   default float apply(float startValue, float endValue, @Nullable Float easingValue, float lerpValue) {
/* 38 */     return MochaMath.lerp(startValue, endValue, ((Float)buildTransformer(easingValue).apply(Float.valueOf(lerpValue))).floatValue());
/*    */   }
/*    */ }


/* Location:              C:\Users\rapha\Downloads\aurora.jar!\META-INF\jars\player-animation-library-wJLdv4ZQ.jar!\com\zigythebird\playeranimcore\easing\EasingTypeTransformer.class
 * Java compiler version: 21 (65.0)
 * JD-Core Version:       1.1.3
 */