/*    */ package com.zigythebird.playeranimcore.easing;
/*    */ 
/*    */ import com.zigythebird.playeranimcore.animation.keyframe.AnimationPoint;
/*    */ import it.unimi.dsi.fastutil.floats.Float2FloatFunction;
/*    */ import java.util.List;
/*    */ import org.jetbrains.annotations.Nullable;
/*    */ import team.unnamed.mocha.MochaEngine;
/*    */ import team.unnamed.mocha.parser.ast.Expression;
/*    */ import team.unnamed.mocha.runtime.standard.MochaMath;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class CatmullRomEasing
/*    */   implements EasingTypeTransformer
/*    */ {
/*    */   public static float getPointOnSpline(float delta, float p0, float p1, float p2, float p3) {
/* 26 */     return 0.5F * (2.0F * p1 + (p2 - p0) * delta + (2.0F * p0 - 5.0F * p1 + 4.0F * p2 - p3) * delta * delta + (3.0F * p1 - p0 - 3.0F * p2 + p3) * delta * delta * delta);
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public Float2FloatFunction buildTransformer(Float value) {
/* 33 */     return EasingType.easeIn(EasingType::linear);
/*    */   }
/*    */ 
/*    */   
/*    */   public float apply(MochaEngine<?> env, AnimationPoint animationPoint, @Nullable Float easingValue, float lerpValue) {
/* 38 */     if (animationPoint.currentTick() >= animationPoint.transitionLength()) {
/* 39 */       return animationPoint.animationEndValue();
/*    */     }
/* 41 */     List<List<Expression>> easingArgs = animationPoint.easingArgs();
/*    */     
/* 43 */     if (easingArgs.size() < 2) {
/* 44 */       return MochaMath.lerp(animationPoint.animationStartValue(), animationPoint.animationEndValue(), ((Float)buildTransformer(easingValue).apply(Float.valueOf(lerpValue))).floatValue());
/*    */     }
/* 46 */     return getPointOnSpline(lerpValue, env.eval(easingArgs.get(0)), animationPoint.animationStartValue(), animationPoint.animationEndValue(), env.eval(easingArgs.get(1)));
/*    */   }
/*    */ }


/* Location:              C:\Users\rapha\Downloads\aurora.jar!\META-INF\jars\player-animation-library-wJLdv4ZQ.jar!\com\zigythebird\playeranimcore\easing\CatmullRomEasing.class
 * Java compiler version: 21 (65.0)
 * JD-Core Version:       1.1.3
 */