/*     */ package com.zigythebird.playeranimcore.easing;
/*     */ 
/*     */ import com.zigythebird.playeranimcore.animation.keyframe.AnimationPoint;
/*     */ import it.unimi.dsi.fastutil.floats.Float2FloatFunction;
/*     */ import java.util.ArrayList;
/*     */ import java.util.List;
/*     */ import org.jetbrains.annotations.Nullable;
/*     */ import org.joml.Vector2f;
/*     */ import team.unnamed.mocha.MochaEngine;
/*     */ import team.unnamed.mocha.parser.ast.Expression;
/*     */ import team.unnamed.mocha.runtime.standard.MochaMath;
/*     */ 
/*     */ public class BezierEasing
/*     */   implements EasingTypeTransformer
/*     */ {
/*     */   public Float2FloatFunction buildTransformer(@Nullable Float value) {
/*  17 */     return EasingType.easeIn(EasingType::linear);
/*     */   }
/*     */   
/*     */   public float apply(MochaEngine<?> env, AnimationPoint animationPoint, @Nullable Float easingValue, float lerpValue) {
/*     */     float rightValue, rightTime;
/*  22 */     if (lerpValue >= 1.0F) return animationPoint.animationEndValue(); 
/*  23 */     if (Float.isNaN(lerpValue) || lerpValue == 0.0F) return animationPoint.animationStartValue();
/*     */     
/*  25 */     List<List<Expression>> easingArgs = animationPoint.easingArgs();
/*     */     
/*  27 */     if (easingArgs == null || easingArgs.isEmpty()) {
/*  28 */       return MochaMath.lerp(animationPoint.animationStartValue(), animationPoint.animationEndValue(), ((Float)buildTransformer(null).apply(Float.valueOf(lerpValue))).floatValue());
/*     */     }
/*     */ 
/*     */     
/*  32 */     float leftValue = env.eval((List)easingArgs.getFirst());
/*  33 */     float leftTime = env.eval(easingArgs.get(1));
/*     */     
/*  35 */     if (easingArgs.size() > 3) {
/*  36 */       rightValue = env.eval(easingArgs.get(2));
/*  37 */       rightTime = env.eval(easingArgs.get(3));
/*     */     } else {
/*     */       
/*  40 */       rightValue = 0.0F;
/*  41 */       rightTime = 0.1F;
/*     */     } 
/*     */     
/*  44 */     float transitionLength = animationPoint.transitionLength() / 20.0F;
/*     */     
/*  46 */     float time_handle_before = rightTime / transitionLength;
/*  47 */     float time_handle_after = leftTime / transitionLength;
/*     */ 
/*     */     
/*  50 */     if (time_handle_before > 1.0F || time_handle_before < 0.0F) {
/*  51 */       float unclamped = time_handle_before;
/*  52 */       time_handle_before = Math.clamp(time_handle_before, 0.0F, 1.0F);
/*  53 */       rightValue /= 1.0F + Math.abs(time_handle_before - unclamped);
/*     */     } 
/*  55 */     if (time_handle_after > 0.0F || time_handle_after < -1.0F) {
/*  56 */       float unclamped = time_handle_after;
/*  57 */       time_handle_after = Math.clamp(time_handle_after, -1.0F, 0.0F);
/*  58 */       leftValue /= 1.0F + Math.abs(time_handle_after - unclamped);
/*     */     } 
/*     */     
/*  61 */     Vector2f P0 = new Vector2f(0.0F, animationPoint.animationStartValue());
/*  62 */     Vector2f P1 = new Vector2f(time_handle_before, animationPoint.animationStartValue() + rightValue);
/*  63 */     Vector2f P2 = new Vector2f(time_handle_after + 1.0F, animationPoint.animationEndValue() + leftValue);
/*  64 */     Vector2f P3 = new Vector2f(1.0F, animationPoint.animationEndValue());
/*     */     
/*  66 */     List<Vector2f> points = new ArrayList<>();
/*     */     
/*  68 */     int divisions = 200;
/*  69 */     for (int d = 0; d <= 200; d++) {
/*  70 */       float t = d / 200.0F;
/*  71 */       points.add(new Vector2f(
/*  72 */             CubicBezier(t, P0.x, P1.x, P2.x, P3.x), 
/*  73 */             CubicBezier(t, P0.y, P1.y, P2.y, P3.y)));
/*     */     } 
/*     */ 
/*     */     
/*  77 */     Vector2f closest = new Vector2f();
/*  78 */     float closest_diff = Float.POSITIVE_INFINITY;
/*  79 */     for (Vector2f point : points) {
/*  80 */       float diff = Math.abs(point.x - lerpValue);
/*  81 */       if (diff < closest_diff) {
/*  82 */         closest_diff = diff;
/*  83 */         closest = point;
/*     */       } 
/*     */     } 
/*  86 */     Vector2f second_closest = new Vector2f();
/*  87 */     closest_diff = Float.POSITIVE_INFINITY;
/*  88 */     for (Vector2f point : points) {
/*  89 */       if (point == closest)
/*  90 */         break;  float diff = Math.abs(point.x - lerpValue);
/*  91 */       if (diff < closest_diff) {
/*  92 */         closest_diff = diff;
/*  93 */         second_closest = point;
/*     */       } 
/*     */     } 
/*  96 */     return MochaMath.lerp(closest.y, second_closest.y, Math.clamp(MochaMath.lerp(closest.x, second_closest.x, lerpValue), 0.0F, 1.0F));
/*     */   }
/*     */   
/*     */   float CubicBezierP0(float t, float p) {
/* 100 */     float k = 1.0F - t;
/* 101 */     return k * k * k * p;
/*     */   }
/*     */   
/*     */   float CubicBezierP1(float t, float p) {
/* 105 */     float k = 1.0F - t;
/* 106 */     return 3.0F * k * k * t * p;
/*     */   }
/*     */   
/*     */   float CubicBezierP2(float t, float p) {
/* 110 */     return 3.0F * (1.0F - t) * t * t * p;
/*     */   }
/*     */   
/*     */   float CubicBezierP3(float t, float p) {
/* 114 */     return t * t * t * p;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   float CubicBezier(float t, float p0, float p1, float p2, float p3) {
/* 128 */     return CubicBezierP0(t, p0) + CubicBezierP1(t, p1) + CubicBezierP2(t, p2) + 
/* 129 */       CubicBezierP3(t, p3);
/*     */   }
/*     */ }


/* Location:              C:\Users\rapha\Downloads\aurora.jar!\META-INF\jars\player-animation-library-wJLdv4ZQ.jar!\com\zigythebird\playeranimcore\easing\BezierEasing.class
 * Java compiler version: 21 (65.0)
 * JD-Core Version:       1.1.3
 */