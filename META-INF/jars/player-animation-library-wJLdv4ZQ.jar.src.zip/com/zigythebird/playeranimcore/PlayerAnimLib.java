/*    */ package com.zigythebird.playeranimcore;
/*    */ 
/*    */ import com.google.gson.Gson;
/*    */ import com.google.gson.GsonBuilder;
/*    */ import com.google.gson.reflect.TypeToken;
/*    */ import com.zigythebird.playeranimcore.animation.Animation;
/*    */ import com.zigythebird.playeranimcore.loading.AnimationLoader;
/*    */ import com.zigythebird.playeranimcore.loading.KeyFrameLoader;
/*    */ import com.zigythebird.playeranimcore.loading.UniversalAnimLoader;
/*    */ import java.lang.reflect.Type;
/*    */ import java.util.Map;
/*    */ import org.slf4j.Logger;
/*    */ import org.slf4j.LoggerFactory;
/*    */ 
/*    */ public class PlayerAnimLib
/*    */ {
/*    */   public static final String MOD_ID = "player_animation_library";
/* 18 */   public static final Logger LOGGER = LoggerFactory.getLogger("player_animation_library");
/*    */   
/* 20 */   public static final Type ANIMATIONS_MAP_TYPE = (new TypeToken<Map<String, Animation>>() {  }).getType();
/* 21 */   public static final Gson GSON = (new GsonBuilder())
/* 22 */     .registerTypeAdapter(Animation.Keyframes.class, new KeyFrameLoader())
/* 23 */     .registerTypeAdapter(Animation.class, new AnimationLoader())
/* 24 */     .registerTypeAdapter(ANIMATIONS_MAP_TYPE, new UniversalAnimLoader())
/* 25 */     .disableHtmlEscaping()
/* 26 */     .create();
/*    */ }


/* Location:              C:\Users\rapha\Downloads\aurora.jar!\META-INF\jars\player-animation-library-wJLdv4ZQ.jar!\com\zigythebird\playeranimcore\PlayerAnimLib.class
 * Java compiler version: 21 (65.0)
 * JD-Core Version:       1.1.3
 */