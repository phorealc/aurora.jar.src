package com.zigythebird.playeranimcore;

import com.google.gson.reflect.TypeToken;
import com.zigythebird.playeranimcore.animation.Animation;
import java.util.Map;

class null extends TypeToken<Map<String, Animation>> {}


/* Location:              C:\Users\rapha\Downloads\aurora.jar!\META-INF\jars\player-animation-library-wJLdv4ZQ.jar!\com\zigythebird\playeranimcore\PlayerAnimLib$1.class
 * Java compiler version: 21 (65.0)
 * JD-Core Version:       1.1.3
 */