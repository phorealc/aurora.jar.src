package com.zigythebird.playeranim.accessors;

import com.zigythebird.playeranim.animation.AvatarAnimManager;
import com.zigythebird.playeranimcore.animation.layered.IAnimation;
import net.minecraft.class_2960;

public interface IAnimatedAvatar {
  AvatarAnimManager playerAnimLib$getAnimManager();
  
  IAnimation playerAnimLib$getAnimation(class_2960 paramclass_2960);
}


/* Location:              C:\Users\rapha\Downloads\aurora.jar!\META-INF\jars\player-animation-library-wJLdv4ZQ.jar!\com\zigythebird\playeranim\accessors\IAnimatedAvatar.class
 * Java compiler version: 21 (65.0)
 * JD-Core Version:       1.1.3
 */