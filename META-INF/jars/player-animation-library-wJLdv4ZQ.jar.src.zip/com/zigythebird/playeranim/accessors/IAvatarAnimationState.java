package com.zigythebird.playeranim.accessors;

import com.zigythebird.playeranim.animation.AvatarAnimManager;

public interface IAvatarAnimationState {
  boolean playerAnimLib$isFirstPersonPass();
  
  void playerAnimLib$setFirstPersonPass(boolean paramBoolean);
  
  void playerAnimLib$setAnimManager(AvatarAnimManager paramAvatarAnimManager);
  
  AvatarAnimManager playerAnimLib$getAnimManager();
}


/* Location:              C:\Users\rapha\Downloads\aurora.jar!\META-INF\jars\player-animation-library-wJLdv4ZQ.jar!\com\zigythebird\playeranim\accessors\IAvatarAnimationState.class
 * Java compiler version: 21 (65.0)
 * JD-Core Version:       1.1.3
 */