package com.zigythebird.playeranim.accessors;

import com.zigythebird.playeranim.animation.AvatarAnimManager;

@Deprecated(forRemoval = true)
public interface ICapeLayer {
  default void applyBend(AvatarAnimManager manager, float bend) {}
  
  default void resetBend() {}
}


/* Location:              C:\Users\rapha\Downloads\aurora.jar!\META-INF\jars\player-animation-library-wJLdv4ZQ.jar!\com\zigythebird\playeranim\accessors\ICapeLayer.class
 * Java compiler version: 21 (65.0)
 * JD-Core Version:       1.1.3
 */