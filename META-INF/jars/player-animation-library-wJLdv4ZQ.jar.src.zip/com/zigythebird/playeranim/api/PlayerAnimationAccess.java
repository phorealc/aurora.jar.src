/*    */ package com.zigythebird.playeranim.api;
/*    */ 
/*    */ import com.zigythebird.playeranim.animation.AvatarAnimManager;
/*    */ import com.zigythebird.playeranimcore.animation.layered.IAnimation;
/*    */ import com.zigythebird.playeranimcore.event.Event;
/*    */ import net.minecraft.class_11890;
/*    */ import net.minecraft.class_2960;
/*    */ import org.jetbrains.annotations.NotNull;
/*    */ import org.jetbrains.annotations.Nullable;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public final class PlayerAnimationAccess
/*    */ {
/*    */   public static AvatarAnimManager getPlayerAnimManager(class_11890 avatar) throws IllegalArgumentException {
/* 21 */     if (avatar instanceof com.zigythebird.playeranim.accessors.IAnimatedAvatar) { class_11890 class_118901 = avatar;
/* 22 */       return class_118901.playerAnimLib$getAnimManager(); }
/* 23 */      throw new IllegalArgumentException(String.valueOf(avatar) + " is not a player or library mixins failed");
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   @Nullable
/*    */   public static IAnimation getPlayerAnimationLayer(@NotNull class_11890 avatar, @NotNull class_2960 id) {
/* 33 */     if (avatar instanceof com.zigythebird.playeranim.accessors.IAnimatedAvatar) { class_11890 class_118901 = avatar;
/* 34 */       return class_118901.playerAnimLib$getAnimation(id); }
/* 35 */      throw new IllegalArgumentException(String.valueOf(avatar) + " is not a player or library mixins failed");
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/* 44 */   public static final Event<AnimationRegister> REGISTER_ANIMATION_EVENT = new Event(listeners -> ());
/*    */   
/*    */   @FunctionalInterface
/*    */   public static interface AnimationRegister {
/*    */     void registerAnimation(@NotNull class_11890 param1class_11890, @NotNull AvatarAnimManager param1AvatarAnimManager);
/*    */   }
/*    */ }


/* Location:              C:\Users\rapha\Downloads\aurora.jar!\META-INF\jars\player-animation-library-wJLdv4ZQ.jar!\com\zigythebird\playeranim\api\PlayerAnimationAccess.class
 * Java compiler version: 21 (65.0)
 * JD-Core Version:       1.1.3
 */