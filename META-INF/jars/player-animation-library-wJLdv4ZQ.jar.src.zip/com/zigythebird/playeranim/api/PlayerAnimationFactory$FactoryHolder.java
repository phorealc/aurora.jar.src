/*    */ package com.zigythebird.playeranim.api;
/*    */ 
/*    */ import com.zigythebird.playeranim.animation.AvatarAnimManager;
/*    */ import com.zigythebird.playeranimcore.animation.layered.IAnimation;
/*    */ import java.util.ArrayList;
/*    */ import java.util.List;
/*    */ import java.util.Map;
/*    */ import java.util.Optional;
/*    */ import java.util.function.Function;
/*    */ import net.minecraft.class_11890;
/*    */ import net.minecraft.class_2960;
/*    */ import org.jetbrains.annotations.ApiStatus.Internal;
/*    */ import org.jetbrains.annotations.NotNull;
/*    */ import org.jetbrains.annotations.Nullable;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class FactoryHolder
/*    */ {
/* 32 */   private static final List<Function<class_11890, DataHolder>> factories = new ArrayList<>();
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public void registerFactory(@Nullable class_2960 id, int priority, @NotNull PlayerAnimationFactory factory)
/*    */   {
/* 41 */     factories.add(player -> (DataHolder)Optional.<IAnimation>ofNullable(factory.invoke(player)).map(()).orElse(null)); } @Internal private static final class DataHolder extends Record { @Nullable
/*    */     private final class_2960 id; private final int priority; @NotNull
/*    */     private final IAnimation animation; @NotNull
/* 44 */     public IAnimation animation() { return this.animation; } public int priority() { return this.priority; } @Nullable public class_2960 id() { return this.id; }
/*    */     public final boolean equals(Object o) { // Byte code:
/*    */       //   0: aload_0
/*    */       //   1: aload_1
/*    */       //   2: <illegal opcode> equals : (Lcom/zigythebird/playeranim/api/PlayerAnimationFactory$FactoryHolder$DataHolder;Ljava/lang/Object;)Z
/*    */       //   7: ireturn
/*    */       // Line number table:
/*    */       //   Java source line number -> byte code offset
/*    */       //   #44	-> 0
/*    */       // Local variable table:
/*    */       //   start	length	slot	name	descriptor
/*    */       //   0	8	0	this	Lcom/zigythebird/playeranim/api/PlayerAnimationFactory$FactoryHolder$DataHolder;
/*    */       //   0	8	1	o	Ljava/lang/Object; } public final int hashCode() { // Byte code:
/*    */       //   0: aload_0
/*    */       //   1: <illegal opcode> hashCode : (Lcom/zigythebird/playeranim/api/PlayerAnimationFactory$FactoryHolder$DataHolder;)I
/*    */       //   6: ireturn
/*    */       // Line number table:
/*    */       //   Java source line number -> byte code offset
/*    */       //   #44	-> 0
/*    */       // Local variable table:
/*    */       //   start	length	slot	name	descriptor
/* 45 */       //   0	7	0	this	Lcom/zigythebird/playeranim/api/PlayerAnimationFactory$FactoryHolder$DataHolder; } private DataHolder(@Nullable class_2960 id, int priority, @NotNull IAnimation animation) { this.id = id; this.priority = priority; this.animation = animation; } public final String toString() {
/*    */       // Byte code:
/*    */       //   0: aload_0
/*    */       //   1: <illegal opcode> toString : (Lcom/zigythebird/playeranim/api/PlayerAnimationFactory$FactoryHolder$DataHolder;)Ljava/lang/String;
/*    */       //   6: areturn
/*    */       // Line number table:
/*    */       //   Java source line number -> byte code offset
/*    */       //   #44	-> 0
/*    */       // Local variable table:
/*    */       //   start	length	slot	name	descriptor
/*    */       //   0	7	0	this	Lcom/zigythebird/playeranim/api/PlayerAnimationFactory$FactoryHolder$DataHolder;
/*    */     } } @Internal
/*    */   public void prepareAnimations(class_11890 player, AvatarAnimManager playerStack, Map<class_2960, IAnimation> animationMap) {
/* 49 */     for (Function<class_11890, DataHolder> factory : factories) {
/* 50 */       DataHolder dataHolder = factory.apply(player);
/* 51 */       if (dataHolder != null) {
/* 52 */         playerStack.addAnimLayer(dataHolder.priority(), dataHolder.animation());
/* 53 */         if (dataHolder.id() != null)
/* 54 */           animationMap.put(dataHolder.id(), dataHolder.animation()); 
/*    */       } 
/*    */     } 
/*    */   }
/*    */ }


/* Location:              C:\Users\rapha\Downloads\aurora.jar!\META-INF\jars\player-animation-library-wJLdv4ZQ.jar!\com\zigythebird\playeranim\api\PlayerAnimationFactory$FactoryHolder.class
 * Java compiler version: 21 (65.0)
 * JD-Core Version:       1.1.3
 */