/*    */ package com.zigythebird.playeranim.api;
/*    */ 
/*    */ import com.zigythebird.playeranimcore.animation.layered.IAnimation;
/*    */ import net.minecraft.class_2960;
/*    */ import org.jetbrains.annotations.ApiStatus.Internal;
/*    */ import org.jetbrains.annotations.NotNull;
/*    */ import org.jetbrains.annotations.Nullable;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ @Internal
/*    */ final class DataHolder
/*    */   extends Record
/*    */ {
/*    */   @Nullable
/*    */   private final class_2960 id;
/*    */   private final int priority;
/*    */   @NotNull
/*    */   private final IAnimation animation;
/*    */   
/*    */   @NotNull
/*    */   public IAnimation animation() {
/* 44 */     return this.animation; } public int priority() { return this.priority; } @Nullable public class_2960 id() { return this.id; } private DataHolder(@Nullable class_2960 id, int priority, @NotNull IAnimation animation) {
/* 45 */     this.id = id; this.priority = priority; this.animation = animation;
/*    */   }
/*    */   
/*    */   public final boolean equals(Object o) {
/*    */     // Byte code:
/*    */     //   0: aload_0
/*    */     //   1: aload_1
/*    */     //   2: <illegal opcode> equals : (Lcom/zigythebird/playeranim/api/PlayerAnimationFactory$FactoryHolder$DataHolder;Ljava/lang/Object;)Z
/*    */     //   7: ireturn
/*    */     // Line number table:
/*    */     //   Java source line number -> byte code offset
/*    */     //   #44	-> 0
/*    */     // Local variable table:
/*    */     //   start	length	slot	name	descriptor
/*    */     //   0	8	0	this	Lcom/zigythebird/playeranim/api/PlayerAnimationFactory$FactoryHolder$DataHolder;
/*    */     //   0	8	1	o	Ljava/lang/Object;
/*    */   }
/*    */   
/*    */   public final int hashCode() {
/*    */     // Byte code:
/*    */     //   0: aload_0
/*    */     //   1: <illegal opcode> hashCode : (Lcom/zigythebird/playeranim/api/PlayerAnimationFactory$FactoryHolder$DataHolder;)I
/*    */     //   6: ireturn
/*    */     // Line number table:
/*    */     //   Java source line number -> byte code offset
/*    */     //   #44	-> 0
/*    */     // Local variable table:
/*    */     //   start	length	slot	name	descriptor
/*    */     //   0	7	0	this	Lcom/zigythebird/playeranim/api/PlayerAnimationFactory$FactoryHolder$DataHolder;
/*    */   }
/*    */   
/*    */   public final String toString() {
/*    */     // Byte code:
/*    */     //   0: aload_0
/*    */     //   1: <illegal opcode> toString : (Lcom/zigythebird/playeranim/api/PlayerAnimationFactory$FactoryHolder$DataHolder;)Ljava/lang/String;
/*    */     //   6: areturn
/*    */     // Line number table:
/*    */     //   Java source line number -> byte code offset
/*    */     //   #44	-> 0
/*    */     // Local variable table:
/*    */     //   start	length	slot	name	descriptor
/*    */     //   0	7	0	this	Lcom/zigythebird/playeranim/api/PlayerAnimationFactory$FactoryHolder$DataHolder;
/*    */   }
/*    */ }


/* Location:              C:\Users\rapha\Downloads\aurora.jar!\META-INF\jars\player-animation-library-wJLdv4ZQ.jar!\com\zigythebird\playeranim\api\PlayerAnimationFactory$FactoryHolder$DataHolder.class
 * Java compiler version: 21 (65.0)
 * JD-Core Version:       1.1.3
 */