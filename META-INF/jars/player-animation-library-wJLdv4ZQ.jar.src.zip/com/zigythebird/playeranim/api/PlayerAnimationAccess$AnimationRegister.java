package com.zigythebird.playeranim.api;

import com.zigythebird.playeranim.animation.AvatarAnimManager;
import net.minecraft.class_11890;
import org.jetbrains.annotations.NotNull;

@FunctionalInterface
public interface AnimationRegister {
  void registerAnimation(@NotNull class_11890 paramclass_11890, @NotNull AvatarAnimManager paramAvatarAnimManager);
}


/* Location:              C:\Users\rapha\Downloads\aurora.jar!\META-INF\jars\player-animation-library-wJLdv4ZQ.jar!\com\zigythebird\playeranim\api\PlayerAnimationAccess$AnimationRegister.class
 * Java compiler version: 21 (65.0)
 * JD-Core Version:       1.1.3
 */