/*    */ package com.zigythebird.playeranim.util;
/*    */ 
/*    */ import com.zigythebird.playeranimcore.bones.PlayerAnimBone;
/*    */ import net.minecraft.class_4587;
/*    */ import net.minecraft.class_5603;
/*    */ import net.minecraft.class_630;
/*    */ 
/*    */ 
/*    */ 
/*    */ public final class RenderUtil
/*    */ {
/*    */   public static void rotateMatrixAroundBone(class_4587 poseStack, PlayerAnimBone bone) {
/* 13 */     rotateZYX(poseStack.method_23760(), bone.getRotZ(), bone.getRotY(), bone.getRotX());
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public static void translatePartToCape(class_630 part, PlayerAnimBone bone, class_5603 initialPose) {
/* 20 */     part.field_3657 = bone.getPosX() + initialPose.comp_2997();
/* 21 */     part.field_3656 = -(bone.getPosY() + initialPose.comp_2998());
/* 22 */     part.field_3655 = bone.getPosZ() + initialPose.comp_2999();
/*    */     
/* 24 */     part.field_3654 = bone.getRotX();
/* 25 */     part.field_3675 = bone.getRotY();
/* 26 */     part.field_3674 = bone.getRotZ();
/*    */     
/* 28 */     part.field_37938 = bone.getScaleX();
/* 29 */     part.field_37939 = bone.getScaleY();
/* 30 */     part.field_37940 = bone.getScaleZ();
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public static void translatePartToBone(class_630 part, PlayerAnimBone bone, class_5603 initialPose) {
/* 37 */     part.field_3657 = bone.getPosX() + initialPose.comp_2997();
/* 38 */     part.field_3656 = -bone.getPosY() + initialPose.comp_2998();
/* 39 */     part.field_3655 = bone.getPosZ() + initialPose.comp_2999();
/*    */     
/* 41 */     part.field_3654 = bone.getRotX();
/* 42 */     part.field_3675 = bone.getRotY() + initialPose.comp_3001();
/* 43 */     part.field_3674 = bone.getRotZ();
/*    */     
/* 45 */     part.field_37938 = bone.getScaleX();
/* 46 */     part.field_37939 = bone.getScaleY();
/* 47 */     part.field_37940 = bone.getScaleZ();
/*    */   }
/*    */   
/*    */   public static void translateMatrixToBone(class_4587 poseStack, PlayerAnimBone bone) {
/* 51 */     poseStack.method_46416(bone.getPosX() / 16.0F, bone.getPosY() / 16.0F, bone.getPosZ() / 16.0F);
/* 52 */     rotateMatrixAroundBone(poseStack, bone);
/* 53 */     poseStack.method_22905(bone.getScaleX(), bone.getScaleY(), bone.getScaleZ());
/*    */   }
/*    */   
/*    */   public static PlayerAnimBone copyVanillaPart(class_630 part, PlayerAnimBone bone) {
/* 57 */     class_5603 initialPose = part.method_41921();
/*    */     
/* 59 */     bone.setPosX(part.field_3657 - initialPose.comp_2997());
/* 60 */     bone.setPosY(-(part.field_3656 - initialPose.comp_2998()));
/* 61 */     bone.setPosZ(part.field_3655 - initialPose.comp_2999());
/*    */     
/* 63 */     bone.setRotX(part.field_3654);
/* 64 */     bone.setRotY(part.field_3675);
/* 65 */     bone.setRotZ(part.field_3674);
/*    */     
/* 67 */     bone.setScaleX(part.field_37938);
/* 68 */     bone.setScaleY(part.field_37939);
/* 69 */     bone.setScaleZ(part.field_37940);
/*    */     
/* 71 */     bone.setBend(0.0F);
/*    */     
/* 73 */     return bone;
/*    */   }
/*    */   
/*    */   public static void rotateZYX(class_4587.class_4665 matrices, float angleZ, float angleY, float angleX) {
/* 77 */     matrices.method_23761().rotateZYX(angleZ, angleY, angleX);
/* 78 */     matrices.method_23762().rotateZYX(angleZ, angleY, angleX);
/*    */   }
/*    */ }


/* Location:              C:\Users\rapha\Downloads\aurora.jar!\META-INF\jars\player-animation-library-wJLdv4ZQ.jar!\com\zigythebird\playerani\\util\RenderUtil.class
 * Java compiler version: 21 (65.0)
 * JD-Core Version:       1.1.3
 */