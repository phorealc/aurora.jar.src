/*    */ package com.zigythebird.playeranim.util;
/*    */ 
/*    */ import net.minecraft.class_1937;
/*    */ import net.minecraft.class_310;
/*    */ import net.minecraft.class_4184;
/*    */ import net.minecraft.class_746;
/*    */ import org.jetbrains.annotations.ApiStatus.Internal;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public final class ClientUtil
/*    */ {
/*    */   public static class_746 getClientPlayer() {
/* 20 */     return (class_310.method_1551()).field_1724;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public static class_1937 getLevel() {
/* 27 */     return (class_1937)(class_310.method_1551()).field_1687;
/*    */   }
/*    */   
/*    */   @Internal
/*    */   public static boolean shouldBeFirstPersonPass() {
/* 32 */     return shouldBeFirstPersonPass((class_310.method_1551()).field_1773.method_19418());
/*    */   }
/*    */   
/*    */   @Internal
/*    */   public static boolean shouldBeFirstPersonPass(class_4184 camera) {
/*    */     // Byte code:
/*    */     //   0: aload_0
/*    */     //   1: invokevirtual method_19333 : ()Z
/*    */     //   4: ifne -> 92
/*    */     //   7: aload_0
/*    */     //   8: invokevirtual method_19331 : ()Lnet/minecraft/class_1297;
/*    */     //   11: astore_2
/*    */     //   12: aload_2
/*    */     //   13: instanceof com/zigythebird/playeranim/accessors/IAnimatedAvatar
/*    */     //   16: ifeq -> 92
/*    */     //   19: aload_2
/*    */     //   20: checkcast com/zigythebird/playeranim/accessors/IAnimatedAvatar
/*    */     //   23: astore_1
/*    */     //   24: aload_1
/*    */     //   25: invokeinterface playerAnimLib$getAnimManager : ()Lcom/zigythebird/playeranim/animation/AvatarAnimManager;
/*    */     //   30: invokevirtual isActive : ()Z
/*    */     //   33: ifeq -> 92
/*    */     //   36: aload_1
/*    */     //   37: invokeinterface playerAnimLib$getAnimManager : ()Lcom/zigythebird/playeranim/animation/AvatarAnimManager;
/*    */     //   42: invokevirtual getFirstPersonMode : ()Lcom/zigythebird/playeranimcore/api/firstPerson/FirstPersonMode;
/*    */     //   45: getstatic com/zigythebird/playeranimcore/api/firstPerson/FirstPersonMode.THIRD_PERSON_MODEL : Lcom/zigythebird/playeranimcore/api/firstPerson/FirstPersonMode;
/*    */     //   48: if_acmpne -> 92
/*    */     //   51: aload_1
/*    */     //   52: invokeinterface playerAnimLib$getAnimManager : ()Lcom/zigythebird/playeranim/animation/AvatarAnimManager;
/*    */     //   57: invokevirtual getFirstPersonTransitionProgress : ()F
/*    */     //   60: fconst_1
/*    */     //   61: fcmpl
/*    */     //   62: ifne -> 92
/*    */     //   65: aload_0
/*    */     //   66: invokevirtual method_19331 : ()Lnet/minecraft/class_1297;
/*    */     //   69: instanceof net/minecraft/class_1309
/*    */     //   72: ifeq -> 88
/*    */     //   75: aload_0
/*    */     //   76: invokevirtual method_19331 : ()Lnet/minecraft/class_1297;
/*    */     //   79: checkcast net/minecraft/class_1309
/*    */     //   82: invokevirtual method_6113 : ()Z
/*    */     //   85: ifne -> 92
/*    */     //   88: iconst_1
/*    */     //   89: goto -> 93
/*    */     //   92: iconst_0
/*    */     //   93: ireturn
/*    */     // Line number table:
/*    */     //   Java source line number -> byte code offset
/*    */     //   #40	-> 0
/*    */     //   #37	-> 1
/*    */     //   #38	-> 37
/*    */     //   #39	-> 52
/*    */     //   #40	-> 66
/*    */     //   #37	-> 93
/*    */     // Local variable table:
/*    */     //   start	length	slot	name	descriptor
/*    */     //   24	68	1	player	Lcom/zigythebird/playeranim/accessors/IAnimatedAvatar;
/*    */     //   0	94	0	camera	Lnet/minecraft/class_4184;
/*    */   }
/*    */ }


/* Location:              C:\Users\rapha\Downloads\aurora.jar!\META-INF\jars\player-animation-library-wJLdv4ZQ.jar!\com\zigythebird\playerani\\util\ClientUtil.class
 * Java compiler version: 21 (65.0)
 * JD-Core Version:       1.1.3
 */