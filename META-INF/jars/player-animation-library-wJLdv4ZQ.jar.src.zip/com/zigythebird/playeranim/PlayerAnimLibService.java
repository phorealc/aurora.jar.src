/*    */ package com.zigythebird.playeranim;
/*    */ 
/*    */ import java.util.ServiceLoader;
/*    */ import java.util.stream.Stream;
/*    */ 
/*    */ public interface PlayerAnimLibService {
/*  7 */   public static final PlayerAnimLibService INSTANCE = loadServices(PlayerAnimLibService.class).findAny().orElseThrow();
/*    */   
/*    */   boolean isModLoaded(String paramString);
/*    */   
/*    */   static <T> Stream<T> loadServices(Class<T> serviceClass) {
/* 12 */     ModuleLayer layer = serviceClass.getModule().getLayer();
/*    */ 
/*    */     
/* 15 */     ServiceLoader<T> loader = (layer == null) ? ServiceLoader.<T>load(serviceClass, serviceClass.getClassLoader()) : ServiceLoader.<T>load(layer, serviceClass);
/* 16 */     return loader.stream().map(ServiceLoader.Provider::get);
/*    */   }
/*    */ }


/* Location:              C:\Users\rapha\Downloads\aurora.jar!\META-INF\jars\player-animation-library-wJLdv4ZQ.jar!\com\zigythebird\playeranim\PlayerAnimLibService.class
 * Java compiler version: 21 (65.0)
 * JD-Core Version:       1.1.3
 */