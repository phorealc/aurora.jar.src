/*    */ package com.zigythebird.playeranim;
/*    */ import com.zigythebird.playeranim.animation.PlayerAnimationController;
/*    */ import com.zigythebird.playeranim.animation.keyframe.event.builtin.AutoPlayingSoundKeyframeHandler;
/*    */ import com.zigythebird.playeranim.molang.MolangQueries;
/*    */ import com.zigythebird.playeranimcore.animation.AnimationController;
/*    */ import com.zigythebird.playeranimcore.animation.AnimationData;
/*    */ import com.zigythebird.playeranimcore.animation.layered.IAnimation;
/*    */ import com.zigythebird.playeranimcore.enums.PlayState;
/*    */ import com.zigythebird.playeranimcore.molang.QueryBinding;
/*    */ import net.minecraft.class_11890;
/*    */ import net.minecraft.class_2960;
/*    */ 
/*    */ public abstract class PlayerAnimLibMod extends PlayerAnimLib {
/* 14 */   public static final class_2960 ANIMATION_LAYER_ID = id("factory");
/*    */   
/*    */   public static class_2960 id(String name) {
/* 17 */     return class_2960.method_60655("player_animation_library", name);
/*    */   }
/*    */   
/*    */   protected void init() {
/* 21 */     PlayerAnimationFactory.ANIMATION_DATA_FACTORY.registerFactory(ANIMATION_LAYER_ID, 1000, player -> new PlayerAnimationController(player, ()));
/*    */ 
/*    */ 
/*    */ 
/*    */     
/* 26 */     MolangEvent.MOLANG_EVENT.register((controller, engine, queryBinding) -> MolangQueries.setDefaultQueryValues(queryBinding));
/*    */ 
/*    */     
/* 29 */     CustomKeyFrameEvents.SOUND_KEYFRAME_EVENT.register(new AutoPlayingSoundKeyframeHandler());
/*    */   }
/*    */ }


/* Location:              C:\Users\rapha\Downloads\aurora.jar!\META-INF\jars\player-animation-library-wJLdv4ZQ.jar!\com\zigythebird\playeranim\PlayerAnimLibMod.class
 * Java compiler version: 21 (65.0)
 * JD-Core Version:       1.1.3
 */