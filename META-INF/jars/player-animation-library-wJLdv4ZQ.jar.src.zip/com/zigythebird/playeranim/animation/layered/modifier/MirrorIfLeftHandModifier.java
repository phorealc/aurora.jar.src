/*    */ package com.zigythebird.playeranim.animation.layered.modifier;
/*    */ 
/*    */ import com.zigythebird.playeranim.animation.PlayerAnimationController;
/*    */ import com.zigythebird.playeranimcore.animation.AnimationController;
/*    */ import com.zigythebird.playeranimcore.animation.layered.modifier.MirrorModifier;
/*    */ import com.zigythebird.playeranimcore.bones.PlayerAnimBone;
/*    */ import net.minecraft.class_1306;
/*    */ import net.minecraft.class_310;
/*    */ import org.jetbrains.annotations.NotNull;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class MirrorIfLeftHandModifier
/*    */   extends MirrorModifier
/*    */ {
/*    */   public PlayerAnimBone get3DTransform(@NotNull PlayerAnimBone bone) {
/* 18 */     AnimationController animationController = getController(); if (animationController instanceof PlayerAnimationController) { PlayerAnimationController controller = (PlayerAnimationController)animationController; if (controller.getAvatar() == (class_310.method_1551()).field_1724 && (class_310.method_1551()).field_1690.method_42552().method_41753() == class_1306.field_6182) return bone;  }
/* 19 */      return super.get3DTransform(bone);
/*    */   }
/*    */ }


/* Location:              C:\Users\rapha\Downloads\aurora.jar!\META-INF\jars\player-animation-library-wJLdv4ZQ.jar!\com\zigythebird\playeranim\animation\layered\modifier\MirrorIfLeftHandModifier.class
 * Java compiler version: 21 (65.0)
 * JD-Core Version:       1.1.3
 */