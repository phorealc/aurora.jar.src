/*     */ package com.zigythebird.playeranim.animation;
/*     */ 
/*     */ import com.zigythebird.playeranim.util.RenderUtil;
/*     */ import com.zigythebird.playeranimcore.animation.AnimationData;
/*     */ import com.zigythebird.playeranimcore.animation.layered.AnimationStack;
/*     */ import com.zigythebird.playeranimcore.animation.layered.IAnimation;
/*     */ import com.zigythebird.playeranimcore.api.firstPerson.FirstPersonMode;
/*     */ import com.zigythebird.playeranimcore.bones.PlayerAnimBone;
/*     */ import it.unimi.dsi.fastutil.Pair;
/*     */ import net.minecraft.class_11890;
/*     */ import net.minecraft.class_243;
/*     */ import net.minecraft.class_310;
/*     */ import net.minecraft.class_5603;
/*     */ import net.minecraft.class_630;
/*     */ import org.jetbrains.annotations.ApiStatus.Internal;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class AvatarAnimManager
/*     */   extends AnimationStack
/*     */ {
/*     */   private final class_11890 avatar;
/*     */   private float lastUpdateTime;
/*     */   private boolean isFirstTick = true;
/*     */   private float tickDelta;
/*  29 */   private float firstPersonTransitionProgress = 0.0F;
/*     */   private boolean firstPersonTransitioningToPAL;
/*     */   
/*     */   public AvatarAnimManager(class_11890 avatar) {
/*  33 */     this.avatar = avatar;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void tickAnimation(AnimationStack playerAnimManager, AnimationData state) {
/*  43 */     playerAnimManager.getLayers().removeIf(pair -> (pair.right() == null || ((IAnimation)pair.right()).canRemove()));
/*  44 */     for (Pair<Integer, IAnimation> pair : (Iterable<Pair<Integer, IAnimation>>)playerAnimManager.getLayers()) {
/*  45 */       IAnimation animation = (IAnimation)pair.right();
/*     */       
/*  47 */       if (animation.isActive())
/*  48 */         animation.setupAnim(state.copy()); 
/*     */     } 
/*  50 */     finishFirstTick();
/*     */   }
/*     */   
/*     */   public float getLastUpdateTime() {
/*  54 */     return this.lastUpdateTime;
/*     */   }
/*     */   
/*     */   public void updatedAt(float updateTime) {
/*  58 */     this.lastUpdateTime = updateTime;
/*     */   }
/*     */   
/*     */   public boolean isFirstTick() {
/*  62 */     return this.isFirstTick;
/*     */   }
/*     */   
/*     */   protected void finishFirstTick() {
/*  66 */     this.isFirstTick = false;
/*     */   }
/*     */   
/*     */   public float getTickDelta() {
/*  70 */     return this.tickDelta;
/*     */   }
/*     */   
/*     */   public float getFirstPersonTransitionProgress() {
/*  74 */     return this.firstPersonTransitionProgress;
/*     */   }
/*     */   
/*     */   public boolean isFirstPersonTransitioningToPAL() {
/*  78 */     return this.firstPersonTransitioningToPAL;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Internal
/*     */   public void setTickDelta(float tickDelta) {
/*  86 */     this.tickDelta = tickDelta;
/*     */   }
/*     */   
/*     */   public void updatePart(class_630 part, PlayerAnimBone bone) {
/*  90 */     class_5603 initialPose = part.method_41921();
/*  91 */     bone = get3DTransform(bone);
/*  92 */     RenderUtil.translatePartToBone(part, bone, initialPose);
/*     */   }
/*     */   
/*     */   public void handleAnimations(float partialTick, boolean fullTick, boolean isFirstPersonPass) {
/*  96 */     class_243 velocity = this.avatar.method_18798();
/*     */     
/*  98 */     AvatarAnimManager animatableManager = this.avatar.playerAnimLib$getAnimManager();
/*  99 */     int currentTick = this.avatar.field_6012;
/*     */     
/* 101 */     float currentFrameTime = currentTick + partialTick;
/*     */     
/* 103 */     AnimationData animationData = new AnimationData((float)((Math.abs(velocity.field_1352) + Math.abs(velocity.field_1350)) / 2.0D), partialTick, isFirstPersonPass);
/*     */     
/* 105 */     if (fullTick) animatableManager.tick(animationData.copy());
/*     */     
/* 107 */     if (!animatableManager.isFirstTick() && currentFrameTime == animatableManager.getLastUpdateTime()) {
/*     */       return;
/*     */     }
/* 110 */     if (!class_310.method_1551().method_1493()) {
/* 111 */       animatableManager.updatedAt(currentFrameTime);
/*     */     }
/*     */     
/* 114 */     tickAnimation(animatableManager, animationData);
/*     */   }
/*     */   
/*     */   public class_11890 getAvatar() {
/* 118 */     return this.avatar;
/*     */   }
/*     */ 
/*     */   
/*     */   public void tick(AnimationData state) {
/* 123 */     super.tick(state);
/*     */     
/* 125 */     int firstPersonTransitionLength = getFirstPersonTransitionLength();
/* 126 */     float target = (getFirstPersonMode() == FirstPersonMode.THIRD_PERSON_MODEL) ? 1.0F : 0.0F;
/* 127 */     if (firstPersonTransitionLength <= 0) { this.firstPersonTransitionProgress = target; }
/*     */     else
/* 129 */     { float step = 1.0F / firstPersonTransitionLength;
/* 130 */       if (this.firstPersonTransitionProgress < target) {
/* 131 */         this.firstPersonTransitionProgress += step;
/* 132 */         this.firstPersonTransitioningToPAL = true;
/* 133 */         if (this.firstPersonTransitionProgress > target) this.firstPersonTransitionProgress = target; 
/* 134 */       } else if (this.firstPersonTransitionProgress > target) {
/* 135 */         this.firstPersonTransitionProgress -= step;
/* 136 */         this.firstPersonTransitioningToPAL = false;
/* 137 */         if (this.firstPersonTransitionProgress < target) this.firstPersonTransitionProgress = target; 
/*     */       }  }
/*     */   
/*     */   }
/*     */ }


/* Location:              C:\Users\rapha\Downloads\aurora.jar!\META-INF\jars\player-animation-library-wJLdv4ZQ.jar!\com\zigythebird\playeranim\animation\AvatarAnimManager.class
 * Java compiler version: 21 (65.0)
 * JD-Core Version:       1.1.3
 */