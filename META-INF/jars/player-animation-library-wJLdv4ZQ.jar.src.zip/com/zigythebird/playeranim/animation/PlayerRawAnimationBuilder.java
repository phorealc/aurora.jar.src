/*    */ package com.zigythebird.playeranim.animation;
/*    */ 
/*    */ import com.zigythebird.playeranimcore.animation.Animation;
/*    */ import com.zigythebird.playeranimcore.animation.RawAnimation;
/*    */ import net.minecraft.class_2960;
/*    */ 
/*    */ 
/*    */ 
/*    */ public class PlayerRawAnimationBuilder
/*    */ {
/* 11 */   private final RawAnimation rawAnimation = RawAnimation.begin();
/*    */   
/*    */   public static PlayerRawAnimationBuilder begin() {
/* 14 */     return new PlayerRawAnimationBuilder();
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public PlayerRawAnimationBuilder thenPlay(class_2960 animation) {
/* 24 */     return then(animation, Animation.LoopType.DEFAULT);
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public PlayerRawAnimationBuilder thenLoop(class_2960 animation) {
/* 33 */     return then(animation, Animation.LoopType.LOOP);
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public PlayerRawAnimationBuilder thenWait(int ticks) {
/* 44 */     this.rawAnimation.thenWait(ticks);
/*    */     
/* 46 */     return this;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public PlayerRawAnimationBuilder thenPlayAndHold(class_2960 animation) {
/* 56 */     return then(animation, Animation.LoopType.HOLD_ON_LAST_FRAME);
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public PlayerRawAnimationBuilder thenPlayXTimes(class_2960 animation, int playCount) {
/* 67 */     for (int i = 0; i < playCount; i++) {
/* 68 */       then(animation, (i == playCount - 1) ? Animation.LoopType.DEFAULT : Animation.LoopType.PLAY_ONCE);
/*    */     }
/*    */     
/* 71 */     return this;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public PlayerRawAnimationBuilder then(class_2960 animation, Animation.LoopType loopType) {
/* 81 */     Animation instance = PlayerAnimResources.getAnimation(animation);
/* 82 */     if (instance == null) throw new IllegalArgumentException("Could not find animation with name: " + String.valueOf(animation)); 
/* 83 */     this.rawAnimation.then(instance, loopType);
/*    */     
/* 85 */     return this;
/*    */   }
/*    */   
/*    */   public RawAnimation build() {
/* 89 */     return this.rawAnimation;
/*    */   }
/*    */ }


/* Location:              C:\Users\rapha\Downloads\aurora.jar!\META-INF\jars\player-animation-library-wJLdv4ZQ.jar!\com\zigythebird\playeranim\animation\PlayerRawAnimationBuilder.class
 * Java compiler version: 21 (65.0)
 * JD-Core Version:       1.1.3
 */