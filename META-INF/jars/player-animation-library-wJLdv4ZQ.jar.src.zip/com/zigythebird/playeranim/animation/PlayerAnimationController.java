/*    */ package com.zigythebird.playeranim.animation;
/*    */ 
/*    */ import com.zigythebird.playeranim.PlayerAnimLibMod;
/*    */ import com.zigythebird.playeranim.util.RenderUtil;
/*    */ import com.zigythebird.playeranimcore.animation.AnimationController;
/*    */ import com.zigythebird.playeranimcore.animation.HumanoidAnimationController;
/*    */ import com.zigythebird.playeranimcore.animation.layered.modifier.AbstractFadeModifier;
/*    */ import com.zigythebird.playeranimcore.bones.PlayerAnimBone;
/*    */ import com.zigythebird.playeranimcore.math.Vec3f;
/*    */ import com.zigythebird.playeranimcore.molang.MolangLoader;
/*    */ import java.util.function.Function;
/*    */ import net.minecraft.class_11890;
/*    */ import net.minecraft.class_243;
/*    */ import net.minecraft.class_2960;
/*    */ import net.minecraft.class_3532;
/*    */ import net.minecraft.class_4587;
/*    */ import net.minecraft.class_7833;
/*    */ import org.jetbrains.annotations.NotNull;
/*    */ import org.jetbrains.annotations.Nullable;
/*    */ import org.joml.Quaternionfc;
/*    */ import team.unnamed.mocha.MochaEngine;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class PlayerAnimationController
/*    */   extends HumanoidAnimationController
/*    */ {
/*    */   protected final class_11890 avatar;
/*    */   
/*    */   public PlayerAnimationController(class_11890 avatar, AnimationController.AnimationStateHandler animationHandler) {
/* 32 */     this(avatar, animationHandler, MolangLoader::createNewEngine);
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public PlayerAnimationController(class_11890 avatar, AnimationController.AnimationStateHandler animationHandler, Function<AnimationController, MochaEngine<AnimationController>> molangRuntime) {
/* 43 */     super(animationHandler, molangRuntime);
/* 44 */     this.avatar = avatar;
/*    */   }
/*    */   
/*    */   public class_11890 getAvatar() {
/* 48 */     return this.avatar;
/*    */   }
/*    */   
/*    */   public boolean triggerAnimation(class_2960 newAnimation, float startAnimFrom) {
/* 52 */     if (PlayerAnimResources.hasAnimation(newAnimation)) {
/* 53 */       triggerAnimation(PlayerAnimResources.getAnimation(newAnimation), startAnimFrom);
/* 54 */       return true;
/*    */     } 
/* 56 */     PlayerAnimLibMod.LOGGER.error("Could not find animation with the name:" + String.valueOf(newAnimation));
/* 57 */     return false;
/*    */   }
/*    */   
/*    */   public boolean triggerAnimation(class_2960 newAnimation) {
/* 61 */     return triggerAnimation(newAnimation, 0.0F);
/*    */   }
/*    */   
/*    */   public boolean replaceAnimationWithFade(@NotNull AbstractFadeModifier fadeModifier, @Nullable class_2960 newAnimation, boolean fadeFromNothing) {
/* 65 */     if (PlayerAnimResources.hasAnimation(newAnimation)) {
/* 66 */       replaceAnimationWithFade(fadeModifier, PlayerAnimResources.getAnimation(newAnimation), fadeFromNothing);
/* 67 */       return true;
/*    */     } 
/* 69 */     return false;
/*    */   }
/*    */   
/*    */   public boolean replaceAnimationWithFade(@NotNull AbstractFadeModifier fadeModifier, @Nullable class_2960 newAnimation) {
/* 73 */     return replaceAnimationWithFade(fadeModifier, newAnimation, true);
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   @Nullable
/*    */   public class_4587 getBoneWorldPositionPoseStack(String name, float tickDelta, class_243 cameraPos) {
/* 80 */     if (!this.activeBones.containsKey(name)) return null; 
/* 81 */     class_4587 poseStack = new class_4587();
/* 82 */     Vec3f pivot = getBonePosition(name);
/* 83 */     class_243 position = this.avatar.method_30950(tickDelta).method_1020(cameraPos).method_1031(pivot.x(), pivot.y(), pivot.z());
/* 84 */     poseStack.method_22904(position.method_10216(), position.method_10214(), position.method_10215());
/* 85 */     poseStack.method_22907((Quaternionfc)class_7833.field_40716.rotationDegrees(180.0F - class_3532.method_16439(tickDelta, this.avatar.field_6220, this.avatar.field_6283)));
/* 86 */     RenderUtil.translateMatrixToBone(poseStack, (PlayerAnimBone)this.activeBones.get(name));
/* 87 */     return poseStack;
/*    */   }
/*    */ }


/* Location:              C:\Users\rapha\Downloads\aurora.jar!\META-INF\jars\player-animation-library-wJLdv4ZQ.jar!\com\zigythebird\playeranim\animation\PlayerAnimationController.class
 * Java compiler version: 21 (65.0)
 * JD-Core Version:       1.1.3
 */