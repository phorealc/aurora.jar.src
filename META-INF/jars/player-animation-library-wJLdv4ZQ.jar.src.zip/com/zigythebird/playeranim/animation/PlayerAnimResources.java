/*     */ package com.zigythebird.playeranim.animation;
/*     */ 
/*     */ import com.zigythebird.playeranim.PlayerAnimLibMod;
/*     */ import com.zigythebird.playeranimcore.PlayerAnimLib;
/*     */ import com.zigythebird.playeranimcore.animation.Animation;
/*     */ import com.zigythebird.playeranimcore.loading.UniversalAnimLoader;
/*     */ import it.unimi.dsi.fastutil.objects.Object2ObjectOpenHashMap;
/*     */ import java.io.InputStream;
/*     */ import java.util.Collections;
/*     */ import java.util.HashMap;
/*     */ import java.util.Map;
/*     */ import java.util.Objects;
/*     */ import java.util.Optional;
/*     */ import java.util.concurrent.CompletableFuture;
/*     */ import java.util.concurrent.Executor;
/*     */ import net.minecraft.class_2960;
/*     */ import net.minecraft.class_3298;
/*     */ import net.minecraft.class_3300;
/*     */ import net.minecraft.class_3302;
/*     */ import net.minecraft.class_4013;
/*     */ import org.jetbrains.annotations.NotNull;
/*     */ import org.jetbrains.annotations.Nullable;
/*     */ 
/*     */ public class PlayerAnimResources
/*     */   implements class_4013 {
/*  26 */   public static final class_2960 KEY = PlayerAnimLibMod.id("animation");
/*  27 */   private static final Map<class_2960, Animation> ANIMATIONS = (Map<class_2960, Animation>)new Object2ObjectOpenHashMap();
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   public static Animation getAnimation(class_2960 id) {
/*  34 */     return ANIMATIONS.get(id);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @NotNull
/*     */   public static Optional<Animation> getAnimationOptional(@NotNull class_2960 identifier) {
/*  44 */     return Optional.ofNullable(getAnimation(identifier));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Map<class_2960, Animation> getAnimations() {
/*  51 */     return Collections.unmodifiableMap(ANIMATIONS);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @NotNull
/*     */   public static Map<String, Animation> getModAnimations(@NotNull String modid) {
/*  61 */     HashMap<String, Animation> map = new HashMap<>();
/*  62 */     for (Map.Entry<class_2960, Animation> entry : ANIMATIONS.entrySet()) {
/*  63 */       if (((class_2960)entry.getKey()).method_12836().equals(modid)) {
/*  64 */         map.put(((class_2960)entry.getKey()).method_12832(), entry.getValue());
/*     */       }
/*     */     } 
/*  67 */     return map;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static boolean hasAnimation(class_2960 id) {
/*  75 */     return ANIMATIONS.containsKey(id);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void method_14491(class_3300 manager) {
/*  84 */     ANIMATIONS.clear();
/*     */     
/*  86 */     for (Map.Entry<class_2960, class_3298> resource : (Iterable<Map.Entry<class_2960, class_3298>>)manager.method_14488("player_animations", resourceLocation -> resourceLocation.method_12832().endsWith(".json")).entrySet()) {
/*  87 */       String namespace = ((class_2960)resource.getKey()).method_12836(); 
/*  88 */       try { InputStream is = ((class_3298)resource.getValue()).method_14482(); 
/*  89 */         try { for (Map.Entry<String, Animation> entry : (Iterable<Map.Entry<String, Animation>>)UniversalAnimLoader.loadAnimations(is).entrySet()) {
/*  90 */             ANIMATIONS.put(class_2960.method_60655(namespace, entry.getKey()), entry.getValue());
/*     */           }
/*  92 */           if (is != null) is.close();  } catch (Throwable throwable) { if (is != null) try { is.close(); } catch (Throwable throwable1) { throwable.addSuppressed(throwable1); }   throw throwable; }  } catch (Exception e)
/*  93 */       { PlayerAnimLib.LOGGER.error("Player Animation Library failed to load animation {} because:", resource.getKey(), e); }
/*     */     
/*     */     } 
/*     */   }
/*     */   
/*     */   @NotNull
/*     */   public CompletableFuture<Void> method_25931(class_3302.class_11558 sharedState, Executor backgroundExecutor, class_3302.class_4045 barrier, Executor gameExecutor) {
/* 100 */     class_3300 manager = sharedState.method_72361();
/* 101 */     Objects.requireNonNull(barrier); return CompletableFuture.runAsync(() -> method_14491(manager), backgroundExecutor).thenCompose(barrier::method_18352);
/*     */   }
/*     */ }


/* Location:              C:\Users\rapha\Downloads\aurora.jar!\META-INF\jars\player-animation-library-wJLdv4ZQ.jar!\com\zigythebird\playeranim\animation\PlayerAnimResources.class
 * Java compiler version: 21 (65.0)
 * JD-Core Version:       1.1.3
 */