/*    */ package com.zigythebird.playeranim.mixin;
/*    */ 
/*    */ import com.zigythebird.playeranim.accessors.IAvatarAnimationState;
/*    */ import com.zigythebird.playeranim.animation.AvatarAnimManager;
/*    */ import com.zigythebird.playeranim.util.RenderUtil;
/*    */ import com.zigythebird.playeranimcore.bones.PlayerAnimBone;
/*    */ import net.minecraft.class_10042;
/*    */ import net.minecraft.class_11659;
/*    */ import net.minecraft.class_12075;
/*    */ import net.minecraft.class_4587;
/*    */ import net.minecraft.class_7833;
/*    */ import net.minecraft.class_922;
/*    */ import org.joml.Quaternionfc;
/*    */ import org.spongepowered.asm.mixin.Mixin;
/*    */ import org.spongepowered.asm.mixin.injection.At;
/*    */ import org.spongepowered.asm.mixin.injection.Inject;
/*    */ import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ @Mixin({class_922.class})
/*    */ public class LivingEntityRendererMixin<S extends class_10042>
/*    */ {
/*    */   @Inject(method = {"method_4054(Lnet/minecraft/class_10042;Lnet/minecraft/class_4587;Lnet/minecraft/class_11659;Lnet/minecraft/class_12075;)V"}, at = {@At(value = "INVOKE", target = "Lnet/minecraft/class_922;method_4042(Lnet/minecraft/class_10042;Lnet/minecraft/class_4587;)V")})
/*    */   private void doTranslations(S livingEntityRenderState, class_4587 poseStack, class_11659 submitNodeCollector, class_12075 cameraRenderState, CallbackInfo ci) {
/* 45 */     if (livingEntityRenderState instanceof IAvatarAnimationState) { IAvatarAnimationState avatarRenderState = (IAvatarAnimationState)livingEntityRenderState;
/* 46 */       AvatarAnimManager animationPlayer = avatarRenderState.playerAnimLib$getAnimManager();
/* 47 */       if (animationPlayer != null && animationPlayer.isActive()) {
/* 48 */         avatarRenderState.playerAnimLib$getAnimManager().handleAnimations(animationPlayer.getTickDelta(), false, avatarRenderState.playerAnimLib$isFirstPersonPass());
/* 49 */         poseStack.method_22905(-1.0F, -1.0F, 1.0F);
/*    */         
/* 51 */         if (avatarRenderState.playerAnimLib$isFirstPersonPass()) {
/* 52 */           poseStack.method_46416(0.0F, ((class_10042)livingEntityRenderState).field_53331, 0.0F);
/* 53 */           if (animationPlayer.isFirstPersonFollowsCamera()) {
/* 54 */             poseStack.method_22907((Quaternionfc)class_7833.field_40716.rotationDegrees(-((class_10042)livingEntityRenderState).field_53447));
/* 55 */             poseStack.method_22907((Quaternionfc)class_7833.field_40714.rotationDegrees(-((class_10042)livingEntityRenderState).field_53448));
/*    */           } 
/* 57 */           poseStack.method_46416(0.0F, -((class_10042)livingEntityRenderState).field_53331, 0.0F);
/*    */         } 
/*    */ 
/*    */         
/* 61 */         PlayerAnimBone body = animationPlayer.get3DTransform(new PlayerAnimBone("body"));
/*    */         
/* 63 */         poseStack.method_22904((-body.getPosX() / 16.0F), (body.getPosY() / 16.0F) + 0.75D, (body.getPosZ() / 16.0F));
/* 64 */         body.rotX *= -1.0F;
/* 65 */         body.rotY *= -1.0F;
/* 66 */         RenderUtil.rotateMatrixAroundBone(poseStack, body);
/* 67 */         poseStack.method_22905(body.getScaleX(), body.getScaleY(), body.getScaleZ());
/*    */         
/* 69 */         poseStack.method_22904(0.0D, -0.75D, 0.0D);
/*    */         
/* 71 */         poseStack.method_22905(-1.0F, -1.0F, 1.0F);
/*    */       }  }
/*    */   
/*    */   }
/*    */ }


/* Location:              C:\Users\rapha\Downloads\aurora.jar!\META-INF\jars\player-animation-library-wJLdv4ZQ.jar!\com\zigythebird\playeranim\mixin\LivingEntityRendererMixin.class
 * Java compiler version: 21 (65.0)
 * JD-Core Version:       1.1.3
 */