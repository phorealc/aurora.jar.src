/*    */ package com.zigythebird.playeranim.mixin;
/*    */ 
/*    */ import com.zigythebird.playeranim.accessors.IAvatarAnimationState;
/*    */ import com.zigythebird.playeranim.animation.AvatarAnimManager;
/*    */ import net.minecraft.class_10055;
/*    */ import org.jetbrains.annotations.NotNull;
/*    */ import org.spongepowered.asm.mixin.Mixin;
/*    */ import org.spongepowered.asm.mixin.Unique;
/*    */ 
/*    */ @Mixin({class_10055.class})
/*    */ public class AvatarRenderStateMixin implements IAvatarAnimationState {
/*    */   @Unique
/*    */   boolean playerAnimLib$isFirstPersonPass = false;
/*    */   @Unique
/* 15 */   AvatarAnimManager playerAnimLib$avatarAnimManager = null;
/*    */ 
/*    */ 
/*    */   
/*    */   public boolean playerAnimLib$isFirstPersonPass() {
/* 20 */     return this.playerAnimLib$isFirstPersonPass;
/*    */   }
/*    */ 
/*    */   
/*    */   public void playerAnimLib$setFirstPersonPass(boolean value) {
/* 25 */     this.playerAnimLib$isFirstPersonPass = value;
/*    */   }
/*    */ 
/*    */   
/*    */   public void playerAnimLib$setAnimManager(AvatarAnimManager manager) {
/* 30 */     this.playerAnimLib$avatarAnimManager = manager;
/*    */   }
/*    */   
/*    */   @NotNull
/*    */   public AvatarAnimManager playerAnimLib$getAnimManager() {
/* 35 */     return this.playerAnimLib$avatarAnimManager;
/*    */   }
/*    */ }


/* Location:              C:\Users\rapha\Downloads\aurora.jar!\META-INF\jars\player-animation-library-wJLdv4ZQ.jar!\com\zigythebird\playeranim\mixin\AvatarRenderStateMixin.class
 * Java compiler version: 21 (65.0)
 * JD-Core Version:       1.1.3
 */