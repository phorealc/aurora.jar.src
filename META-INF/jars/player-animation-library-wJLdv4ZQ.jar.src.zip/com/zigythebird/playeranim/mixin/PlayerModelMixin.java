/*     */ package com.zigythebird.playeranim.mixin;
/*     */ 
/*     */ import com.llamalad7.mixinextras.injector.v2.WrapWithCondition;
/*     */ import com.llamalad7.mixinextras.sugar.Local;
/*     */ import com.zigythebird.playeranim.accessors.IBoneUpdater;
/*     */ import com.zigythebird.playeranim.animation.AvatarAnimManager;
/*     */ import com.zigythebird.playeranim.util.RenderUtil;
/*     */ import com.zigythebird.playeranimcore.api.firstPerson.FirstPersonConfiguration;
/*     */ import com.zigythebird.playeranimcore.bones.PlayerAnimBone;
/*     */ import java.util.function.Function;
/*     */ import net.minecraft.class_10055;
/*     */ import net.minecraft.class_1921;
/*     */ import net.minecraft.class_2960;
/*     */ import net.minecraft.class_4587;
/*     */ import net.minecraft.class_572;
/*     */ import net.minecraft.class_591;
/*     */ import net.minecraft.class_630;
/*     */ import org.jetbrains.annotations.Nullable;
/*     */ import org.spongepowered.asm.mixin.Mixin;
/*     */ import org.spongepowered.asm.mixin.Unique;
/*     */ import org.spongepowered.asm.mixin.injection.At;
/*     */ import org.spongepowered.asm.mixin.injection.Inject;
/*     */ import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ @Mixin(value = {class_591.class}, priority = 2001)
/*     */ public class PlayerModelMixin
/*     */   extends class_572<class_10055>
/*     */   implements IBoneUpdater
/*     */ {
/*     */   @Unique
/*  53 */   private final PlayerAnimBone pal$head = new PlayerAnimBone("head");
/*     */   @Unique
/*  55 */   private final PlayerAnimBone pal$torso = new PlayerAnimBone("torso");
/*     */   @Unique
/*  57 */   private final PlayerAnimBone pal$rightArm = new PlayerAnimBone("right_arm");
/*     */   @Unique
/*  59 */   private final PlayerAnimBone pal$leftArm = new PlayerAnimBone("left_arm");
/*     */   @Unique
/*  61 */   private final PlayerAnimBone pal$rightLeg = new PlayerAnimBone("right_leg");
/*     */   @Unique
/*  63 */   private final PlayerAnimBone pal$leftLeg = new PlayerAnimBone("left_leg");
/*     */ 
/*     */   
/*     */   public PlayerModelMixin(class_630 root, Function<class_2960, class_1921> renderType) {
/*  67 */     super(root, renderType);
/*     */   }
/*     */   
/*     */   @Inject(method = {"method_62110(Lnet/minecraft/class_10055;)V"}, at = {@At("HEAD")})
/*     */   private void setDefaultBeforeRender(class_10055 avatarRenderState, CallbackInfo ci) {
/*  72 */     this.field_3398.field_3665 = true;
/*     */   }
/*     */   
/*     */   @Inject(method = {"method_62110(Lnet/minecraft/class_10055;)V"}, at = {@At("RETURN")})
/*     */   private void setupPlayerAnimation(class_10055 avatarRenderState, CallbackInfo ci) {
/*  77 */     if (avatarRenderState instanceof com.zigythebird.playeranim.accessors.IAvatarAnimationState) { class_10055 class_100551 = avatarRenderState; if (class_100551.playerAnimLib$getAnimManager() != null) {
/*  78 */         AvatarAnimManager emote = class_100551.playerAnimLib$getAnimManager();
/*     */         
/*  80 */         if (emote.isActive()) {
/*  81 */           pal$updatePart(emote, this.field_3398, this.pal$head);
/*  82 */           pal$updatePart(emote, this.field_3401, this.pal$rightArm);
/*  83 */           pal$updatePart(emote, this.field_27433, this.pal$leftArm);
/*  84 */           pal$updatePart(emote, this.field_3392, this.pal$rightLeg);
/*  85 */           pal$updatePart(emote, this.field_3397, this.pal$leftLeg);
/*  86 */           pal$updatePart(emote, this.field_3391, this.pal$torso);
/*     */         } else {
/*  88 */           pal$resetAll(emote);
/*     */         } 
/*     */         
/*  91 */         if (class_100551.playerAnimLib$isFirstPersonPass()) {
/*     */           
/*  93 */           this.field_3398.field_3665 = false;
/*  94 */           this.field_3391.field_3665 = false;
/*  95 */           this.field_3397.field_3665 = false;
/*  96 */           this.field_3392.field_3665 = false;
/*     */           
/*  98 */           FirstPersonConfiguration config = emote.getFirstPersonConfiguration();
/*  99 */           this.field_3401.field_3665 = config.isShowRightArm();
/* 100 */           this.field_27433.field_3665 = config.isShowLeftArm();
/*     */         }  return;
/*     */       }  }
/* 103 */      pal$resetAll((AvatarAnimManager)null);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void pal$updatePart(AvatarAnimManager emote, class_630 part, PlayerAnimBone bone) {
/* 109 */     RenderUtil.copyVanillaPart(part, bone);
/* 110 */     emote.updatePart(part, bone);
/*     */   }
/*     */   
/*     */   @WrapWithCondition(method = {"method_72859(Lnet/minecraft/class_10055;Lnet/minecraft/class_1306;Lnet/minecraft/class_4587;)V"}, at = {@At(value = "INVOKE", target = "Lnet/minecraft/class_630;method_22703(Lnet/minecraft/class_4587;)V")})
/*     */   private boolean translateToHand(class_630 modelPart, class_4587 poseStack, @Local(argsOnly = true) class_10055 avatarRenderState) {
/* 115 */     if (avatarRenderState instanceof com.zigythebird.playeranim.accessors.IAvatarAnimationState) { class_10055 class_100551 = avatarRenderState; if (class_100551.playerAnimLib$getAnimManager() != null && class_100551.playerAnimLib$getAnimManager().isActive()) {
/* 116 */         poseStack.method_46416(modelPart.field_3657 / 16.0F, modelPart.field_3656 / 16.0F, modelPart.field_3655 / 16.0F);
/* 117 */         if (modelPart.field_3654 != 0.0F || modelPart.field_3675 != 0.0F || modelPart.field_3674 != 0.0F) {
/* 118 */           RenderUtil.rotateZYX(poseStack.method_23760(), modelPart.field_3674, modelPart.field_3675, modelPart.field_3654);
/*     */         }
/* 120 */         poseStack.method_22904(0.0D, (modelPart.field_37939 - 1.0F) * 0.609375D, (modelPart.field_37940 - 1.0F) * 0.0625D);
/*     */         
/* 122 */         return false;
/*     */       }  }
/* 124 */      return true;
/*     */   }
/*     */   
/*     */   public void pal$resetAll(@Nullable AvatarAnimManager emote) {}
/*     */ }


/* Location:              C:\Users\rapha\Downloads\aurora.jar!\META-INF\jars\player-animation-library-wJLdv4ZQ.jar!\com\zigythebird\playeranim\mixin\PlayerModelMixin.class
 * Java compiler version: 21 (65.0)
 * JD-Core Version:       1.1.3
 */