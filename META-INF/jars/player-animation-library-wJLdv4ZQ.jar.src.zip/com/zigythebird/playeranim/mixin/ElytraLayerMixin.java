/*    */ package com.zigythebird.playeranim.mixin;
/*    */ import com.zigythebird.playeranim.accessors.IAvatarAnimationState;
/*    */ import com.zigythebird.playeranim.animation.AvatarAnimManager;
/*    */ import com.zigythebird.playeranim.util.RenderUtil;
/*    */ import com.zigythebird.playeranimcore.bones.PlayerAnimBone;
/*    */ import net.minecraft.class_10034;
/*    */ import net.minecraft.class_1007;
/*    */ import net.minecraft.class_11659;
/*    */ import net.minecraft.class_3883;
/*    */ import net.minecraft.class_3887;
/*    */ import net.minecraft.class_4587;
/*    */ import net.minecraft.class_583;
/*    */ import net.minecraft.class_591;
/*    */ import net.minecraft.class_979;
/*    */ import org.spongepowered.asm.mixin.Mixin;
/*    */ import org.spongepowered.asm.mixin.injection.At;
/*    */ import org.spongepowered.asm.mixin.injection.Inject;
/*    */ import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
/*    */ 
/*    */ @Mixin({class_979.class})
/*    */ public abstract class ElytraLayerMixin<S extends class_10034, M extends class_583<S>> extends class_3887<S, M> {
/*    */   private ElytraLayerMixin(class_3883<S, M> renderLayerParent) {
/* 23 */     super(renderLayerParent);
/*    */   }
/*    */   
/*    */   @Inject(method = {"method_17161(Lnet/minecraft/class_4587;Lnet/minecraft/class_11659;ILnet/minecraft/class_10034;FF)V"}, at = {@At(value = "INVOKE", target = "Lnet/minecraft/class_10197;method_64078(Lnet/minecraft/class_10186$class_10190;Lnet/minecraft/class_5321;Lnet/minecraft/class_3879;Ljava/lang/Object;Lnet/minecraft/class_1799;Lnet/minecraft/class_4587;Lnet/minecraft/class_11659;ILnet/minecraft/class_2960;II)V")})
/*    */   private void inject(class_4587 poseStack, class_11659 submitNodeCollector, int i, S humanoidRenderState, float f, float g, CallbackInfo ci) {
/* 28 */     if (humanoidRenderState instanceof IAvatarAnimationState) { IAvatarAnimationState animationState = (IAvatarAnimationState)humanoidRenderState;
/* 29 */       AvatarAnimManager emote = animationState.playerAnimLib$getAnimManager();
/* 30 */       if (emote != null && emote.isActive()) { class_3883 class_3883 = this.field_17155; if (class_3883 instanceof class_1007) { class_1007<?> playerRenderer = (class_1007)class_3883;
/* 31 */           ((class_591)playerRenderer.method_4038()).field_3391.method_22703(poseStack);
/* 32 */           poseStack.method_22904(0.0D, 0.0D, 0.125D);
/* 33 */           PlayerAnimBone bone = emote.get3DTransform(new PlayerAnimBone("elytra"));
/* 34 */           bone.applyOtherBone(emote.get3DTransform(new PlayerAnimBone("cape")));
/* 35 */           bone.positionY *= -1.0F;
/* 36 */           RenderUtil.translateMatrixToBone(poseStack, bone);
/* 37 */           poseStack.method_22904(0.0D, 0.0D, -0.125D); }
/*    */          }
/*    */        }
/*    */   
/*    */   }
/*    */ }


/* Location:              C:\Users\rapha\Downloads\aurora.jar!\META-INF\jars\player-animation-library-wJLdv4ZQ.jar!\com\zigythebird\playeranim\mixin\ElytraLayerMixin.class
 * Java compiler version: 21 (65.0)
 * JD-Core Version:       1.1.3
 */