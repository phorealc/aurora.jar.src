/*    */ package com.zigythebird.playeranim.mixin;
/*    */ 
/*    */ import com.zigythebird.playeranim.accessors.IAnimatedAvatar;
/*    */ import com.zigythebird.playeranim.animation.AvatarAnimManager;
/*    */ import com.zigythebird.playeranim.api.PlayerAnimationAccess;
/*    */ import com.zigythebird.playeranim.api.PlayerAnimationFactory;
/*    */ import com.zigythebird.playeranim.util.ClientUtil;
/*    */ import com.zigythebird.playeranimcore.animation.layered.IAnimation;
/*    */ import java.util.HashMap;
/*    */ import java.util.Map;
/*    */ import net.minecraft.class_11890;
/*    */ import net.minecraft.class_1299;
/*    */ import net.minecraft.class_1309;
/*    */ import net.minecraft.class_1937;
/*    */ import net.minecraft.class_2960;
/*    */ import org.spongepowered.asm.mixin.Intrinsic;
/*    */ import org.spongepowered.asm.mixin.Mixin;
/*    */ import org.spongepowered.asm.mixin.Unique;
/*    */ import org.spongepowered.asm.mixin.injection.At;
/*    */ import org.spongepowered.asm.mixin.injection.Inject;
/*    */ import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ @Mixin({class_11890.class})
/*    */ public abstract class AvatarMixin
/*    */   extends class_1309
/*    */   implements IAnimatedAvatar
/*    */ {
/*    */   @Unique
/* 50 */   private final Map<class_2960, IAnimation> playerAnimLib$modAnimationData = new HashMap<>();
/*    */   
/*    */   @Unique
/* 53 */   private final AvatarAnimManager playerAnimLib$animationManager = playerAnimLib$createAnimationStack();
/*    */   
/*    */   protected AvatarMixin(class_1299<? extends class_1309> entityType, class_1937 level) {
/* 56 */     super(entityType, level);
/*    */   }
/*    */   
/*    */   @Unique
/*    */   private AvatarAnimManager playerAnimLib$createAnimationStack() {
/* 61 */     AvatarAnimManager manager = new AvatarAnimManager((class_11890)this);
/* 62 */     PlayerAnimationFactory.ANIMATION_DATA_FACTORY.prepareAnimations((class_11890)this, manager, this.playerAnimLib$modAnimationData);
/* 63 */     ((PlayerAnimationAccess.AnimationRegister)PlayerAnimationAccess.REGISTER_ANIMATION_EVENT.invoker()).registerAnimation((class_11890)this, manager);
/* 64 */     return manager;
/*    */   }
/*    */ 
/*    */   
/*    */   public AvatarAnimManager playerAnimLib$getAnimManager() {
/* 69 */     return this.playerAnimLib$animationManager;
/*    */   }
/*    */ 
/*    */   
/*    */   public IAnimation playerAnimLib$getAnimation(class_2960 id) {
/* 74 */     if (this.playerAnimLib$modAnimationData.containsKey(id)) return this.playerAnimLib$modAnimationData.get(id); 
/* 75 */     return null;
/*    */   }
/*    */ 
/*    */   
/*    */   @Intrinsic
/*    */   public void method_5773() {
/* 81 */     super.method_5773();
/*    */   }
/*    */ 
/*    */   
/*    */   @Inject(method = {"tick", "method_5773"}, at = {@At("TAIL")}, remap = false)
/*    */   private void tick(CallbackInfo ci) {
/* 87 */     if (!method_73183().method_8608())
/* 88 */       return;  this.playerAnimLib$animationManager.handleAnimations(0.0F, true, ClientUtil.shouldBeFirstPersonPass());
/*    */   }
/*    */ }


/* Location:              C:\Users\rapha\Downloads\aurora.jar!\META-INF\jars\player-animation-library-wJLdv4ZQ.jar!\com\zigythebird\playeranim\mixin\AvatarMixin.class
 * Java compiler version: 21 (65.0)
 * JD-Core Version:       1.1.3
 */