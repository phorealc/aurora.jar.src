/*    */ package com.zigythebird.playeranim.mixin;
/*    */ 
/*    */ import com.llamalad7.mixinextras.sugar.Share;
/*    */ import com.llamalad7.mixinextras.sugar.ref.LocalBooleanRef;
/*    */ import com.zigythebird.playeranim.accessors.IAvatarAnimationState;
/*    */ import com.zigythebird.playeranim.animation.AvatarAnimManager;
/*    */ import com.zigythebird.playeranimcore.bones.PlayerAnimBone;
/*    */ import net.minecraft.class_10426;
/*    */ import net.minecraft.class_10444;
/*    */ import net.minecraft.class_11659;
/*    */ import net.minecraft.class_1306;
/*    */ import net.minecraft.class_1799;
/*    */ import net.minecraft.class_4587;
/*    */ import net.minecraft.class_7833;
/*    */ import net.minecraft.class_989;
/*    */ import org.joml.Quaternionfc;
/*    */ import org.spongepowered.asm.mixin.Mixin;
/*    */ import org.spongepowered.asm.mixin.Unique;
/*    */ import org.spongepowered.asm.mixin.injection.At;
/*    */ import org.spongepowered.asm.mixin.injection.Inject;
/*    */ import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ @Mixin({class_989.class})
/*    */ public class ItemInHandLayerMixin
/*    */ {
/*    */   @Unique
/* 48 */   private final PlayerAnimBone playerAnimLib$rightItem = new PlayerAnimBone("right_item");
/*    */   @Unique
/* 50 */   private final PlayerAnimBone playerAnimLib$leftItem = new PlayerAnimBone("left_item");
/*    */ 
/*    */   
/*    */   @Inject(method = {"method_4192(Lnet/minecraft/class_10426;Lnet/minecraft/class_10444;Lnet/minecraft/class_1799;Lnet/minecraft/class_1306;Lnet/minecraft/class_4587;Lnet/minecraft/class_11659;I)V"}, at = {@At(value = "INVOKE", target = "Lnet/minecraft/class_4587;method_22907(Lorg/joml/Quaternionfc;)V", ordinal = 0)})
/*    */   private void changeItemLocation(class_10426 renderState, class_10444 itemStackRenderState, class_1799 itemStack, class_1306 arm, class_4587 matrices, class_11659 submitNodeCollector, int i, CallbackInfo ci, @Share("pal_active") LocalBooleanRef active) {
/* 55 */     if (renderState instanceof IAvatarAnimationState) { IAvatarAnimationState state = (IAvatarAnimationState)renderState; if (state.playerAnimLib$getAnimManager() != null && state.playerAnimLib$getAnimManager().isActive()) {
/* 56 */         PlayerAnimBone bone; AvatarAnimManager anim = state.playerAnimLib$getAnimManager();
/* 57 */         active.set(true);
/*    */ 
/*    */ 
/*    */         
/* 61 */         if (arm == class_1306.field_6182) { bone = this.playerAnimLib$leftItem; }
/* 62 */         else { bone = this.playerAnimLib$rightItem; }
/*    */         
/* 64 */         bone.setToInitialPose();
/* 65 */         anim.get3DTransform(bone);
/*    */         
/* 67 */         matrices.method_46416(bone.getPosX() / 16.0F, -bone.getPosY() / 16.0F, bone.getPosZ() / 16.0F); return;
/*    */       }  }
/* 69 */      active.set(false);
/*    */   }
/*    */   
/*    */   @Inject(method = {"method_4192(Lnet/minecraft/class_10426;Lnet/minecraft/class_10444;Lnet/minecraft/class_1799;Lnet/minecraft/class_1306;Lnet/minecraft/class_4587;Lnet/minecraft/class_11659;I)V"}, at = {@At(value = "INVOKE", target = "Lnet/minecraft/class_10444;method_65604(Lnet/minecraft/class_4587;Lnet/minecraft/class_11659;III)V")})
/*    */   private void changeItemRotationAndScale(class_10426 renderState, class_10444 itemStackRenderState, class_1799 itemStack, class_1306 arm, class_4587 poseStack, class_11659 submitNodeCollector, int packedLight, CallbackInfo ci, @Share("pal_active") LocalBooleanRef active) {
/* 74 */     if (active.get()) {
/*    */       PlayerAnimBone bone;
/*    */       
/* 77 */       if (arm == class_1306.field_6182) { bone = this.playerAnimLib$leftItem; }
/* 78 */       else { bone = this.playerAnimLib$rightItem; }
/*    */       
/* 80 */       if (bone.getRotY() != 0.0F) {
/* 81 */         poseStack.method_22907((Quaternionfc)class_7833.field_40718.rotation(-bone.getRotY()));
/*    */       }
/* 83 */       if (bone.getRotZ() != 0.0F) {
/* 84 */         poseStack.method_22907((Quaternionfc)class_7833.field_40716.rotation(-bone.getRotZ()));
/*    */       }
/* 86 */       if (bone.getRotX() != 0.0F) {
/* 87 */         poseStack.method_22907((Quaternionfc)class_7833.field_40714.rotation(-bone.getRotX()));
/*    */       }
/* 89 */       poseStack.method_22905(bone.getScaleX(), bone.getScaleY(), bone.getScaleZ());
/*    */     } 
/*    */   }
/*    */ }


/* Location:              C:\Users\rapha\Downloads\aurora.jar!\META-INF\jars\player-animation-library-wJLdv4ZQ.jar!\com\zigythebird\playeranim\mixin\ItemInHandLayerMixin.class
 * Java compiler version: 21 (65.0)
 * JD-Core Version:       1.1.3
 */