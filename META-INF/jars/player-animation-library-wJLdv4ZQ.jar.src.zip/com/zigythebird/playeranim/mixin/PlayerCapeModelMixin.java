/*    */ package com.zigythebird.playeranim.mixin;
/*    */ 
/*    */ import com.zigythebird.playeranim.accessors.IBoneUpdater;
/*    */ import com.zigythebird.playeranim.accessors.ICapeLayer;
/*    */ import com.zigythebird.playeranim.animation.AvatarAnimManager;
/*    */ import com.zigythebird.playeranim.util.RenderUtil;
/*    */ import com.zigythebird.playeranimcore.bones.PlayerAnimBone;
/*    */ import net.minecraft.class_10055;
/*    */ import net.minecraft.class_630;
/*    */ import net.minecraft.class_9950;
/*    */ import org.jetbrains.annotations.Nullable;
/*    */ import org.spongepowered.asm.mixin.Final;
/*    */ import org.spongepowered.asm.mixin.Mixin;
/*    */ import org.spongepowered.asm.mixin.Shadow;
/*    */ import org.spongepowered.asm.mixin.injection.At;
/*    */ import org.spongepowered.asm.mixin.injection.Inject;
/*    */ import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
/*    */ 
/*    */ 
/*    */ @Mixin(value = {class_9950.class}, priority = 2001)
/*    */ public class PlayerCapeModelMixin
/*    */   implements IBoneUpdater, ICapeLayer
/*    */ {
/*    */   @Shadow
/*    */   @Final
/*    */   private class_630 field_52927;
/*    */   
/*    */   @Inject(method = {"method_62110(Lnet/minecraft/class_10055;)V"}, at = {@At("TAIL")})
/*    */   private void setupAnim(class_10055 avatarRenderState, CallbackInfo ci) {
/* 30 */     AvatarAnimManager emote = avatarRenderState.playerAnimLib$getAnimManager();
/* 31 */     if (emote != null && emote.isActive()) {
/* 32 */       PlayerAnimBone bone = RenderUtil.copyVanillaPart(this.field_52927, new PlayerAnimBone("cape"));
/*    */       
/* 34 */       bone.rotX -= 3.1415927F;
/* 35 */       bone.rotZ -= 3.1415927F;
/* 36 */       bone.rotX *= -1.0F;
/* 37 */       bone.rotY *= -1.0F;
/* 38 */       bone = emote.get3DTransform(bone);
/* 39 */       bone.rotX *= -1.0F;
/* 40 */       bone.rotY *= -1.0F;
/* 41 */       bone.rotX += 3.1415927F;
/* 42 */       bone.rotZ += 3.1415927F;
/*    */       
/* 44 */       pal$updatePart(emote, this.field_52927, bone);
/*    */     } else {
/* 46 */       pal$resetAll(emote);
/*    */     } 
/*    */   }
/*    */ 
/*    */   
/*    */   public void pal$updatePart(AvatarAnimManager emote, class_630 part, PlayerAnimBone bone) {
/* 52 */     RenderUtil.translatePartToCape(part, bone, part.method_41921());
/* 53 */     applyBend(emote, bone.getBend());
/*    */   }
/*    */ 
/*    */   
/*    */   public void pal$resetAll(@Nullable AvatarAnimManager emote) {
/* 58 */     resetBend();
/*    */   }
/*    */ }


/* Location:              C:\Users\rapha\Downloads\aurora.jar!\META-INF\jars\player-animation-library-wJLdv4ZQ.jar!\com\zigythebird\playeranim\mixin\PlayerCapeModelMixin.class
 * Java compiler version: 21 (65.0)
 * JD-Core Version:       1.1.3
 */