/*    */ package com.zigythebird.playeranim.commands;
/*    */ 
/*    */ import com.mojang.brigadier.context.CommandContext;
/*    */ import com.mojang.brigadier.suggestion.SuggestionProvider;
/*    */ import com.mojang.brigadier.suggestion.Suggestions;
/*    */ import com.mojang.brigadier.suggestion.SuggestionsBuilder;
/*    */ import com.zigythebird.playeranim.animation.PlayerAnimResources;
/*    */ import java.util.LinkedList;
/*    */ import java.util.List;
/*    */ import java.util.concurrent.CompletableFuture;
/*    */ import net.minecraft.class_2172;
/*    */ import net.minecraft.class_2960;
/*    */ 
/*    */ public class AnimationArgumentProvider<S>
/*    */   implements SuggestionProvider<S>
/*    */ {
/*    */   public CompletableFuture<Suggestions> getSuggestions(CommandContext<S> context, SuggestionsBuilder builder) {
/* 18 */     List<String> suggestions = new LinkedList<>();
/* 19 */     for (class_2960 animation : PlayerAnimResources.getAnimations().keySet()) {
/* 20 */       suggestions.add(animation.toString());
/*    */     }
/* 22 */     return class_2172.method_9265(suggestions, builder);
/*    */   }
/*    */ }


/* Location:              C:\Users\rapha\Downloads\aurora.jar!\META-INF\jars\player-animation-library-wJLdv4ZQ.jar!\com\zigythebird\playeranim\commands\AnimationArgumentProvider.class
 * Java compiler version: 21 (65.0)
 * JD-Core Version:       1.1.3
 */