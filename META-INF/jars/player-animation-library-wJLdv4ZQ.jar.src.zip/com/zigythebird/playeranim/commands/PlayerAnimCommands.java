/*     */ package com.zigythebird.playeranim.commands;
/*     */ 
/*     */ import com.mojang.brigadier.CommandDispatcher;
/*     */ import com.mojang.brigadier.arguments.ArgumentType;
/*     */ import com.mojang.brigadier.arguments.IntegerArgumentType;
/*     */ import com.mojang.brigadier.builder.LiteralArgumentBuilder;
/*     */ import com.mojang.brigadier.context.CommandContext;
/*     */ import com.zigythebird.playeranim.PlayerAnimLibMod;
/*     */ import com.zigythebird.playeranim.animation.PlayerAnimResources;
/*     */ import com.zigythebird.playeranim.api.PlayerAnimationAccess;
/*     */ import com.zigythebird.playeranimcore.animation.Animation;
/*     */ import com.zigythebird.playeranimcore.animation.AnimationController;
/*     */ import com.zigythebird.playeranimcore.animation.RawAnimation;
/*     */ import com.zigythebird.playeranimcore.network.AnimationBinary;
/*     */ import com.zigythebird.playeranimcore.network.LegacyAnimationBinary;
/*     */ import io.netty.buffer.ByteBuf;
/*     */ import io.netty.buffer.Unpooled;
/*     */ import java.io.IOException;
/*     */ import java.util.Objects;
/*     */ import net.minecraft.class_11890;
/*     */ import net.minecraft.class_2168;
/*     */ import net.minecraft.class_2170;
/*     */ import net.minecraft.class_2232;
/*     */ import net.minecraft.class_2960;
/*     */ import net.minecraft.class_310;
/*     */ import net.minecraft.class_5242;
/*     */ import net.minecraft.class_7157;
/*     */ 
/*     */ public class PlayerAnimCommands
/*     */ {
/*     */   public static <T> void register(CommandDispatcher<T> dispatcher, class_7157 registryAccess) {
/*  32 */     dispatcher.register((LiteralArgumentBuilder)class_2170.method_9247("testPlayerAnimation")
/*  33 */         .then(class_2170.method_9244("animationID", (ArgumentType)class_2232.method_9441())
/*  34 */           .suggests(new AnimationArgumentProvider())
/*  35 */           .executes(PlayerAnimCommands::execute)));
/*     */ 
/*     */     
/*  38 */     dispatcher.register((LiteralArgumentBuilder)class_2170.method_9247("testLegacyAnimationBinary")
/*  39 */         .then(class_2170.method_9244("animationID", (ArgumentType)class_2232.method_9441())
/*  40 */           .suggests(new AnimationArgumentProvider())
/*  41 */           .then(class_2170.method_9244("version", (ArgumentType)IntegerArgumentType.integer(1, LegacyAnimationBinary.getCurrentVersion()))
/*  42 */             .executes(PlayerAnimCommands::executeLegacy))));
/*     */ 
/*     */ 
/*     */     
/*  46 */     dispatcher.register((LiteralArgumentBuilder)class_2170.method_9247("testAnimationBinary")
/*  47 */         .then(class_2170.method_9244("animationID", (ArgumentType)class_2232.method_9441())
/*  48 */           .suggests(new AnimationArgumentProvider())
/*  49 */           .then(class_2170.method_9244("version", (ArgumentType)IntegerArgumentType.integer(1, 5))
/*  50 */             .executes(PlayerAnimCommands::executeBinary))));
/*     */ 
/*     */ 
/*     */     
/*  54 */     dispatcher.register((LiteralArgumentBuilder)class_2170.method_9247("testMannequin")
/*  55 */         .then(class_2170.method_9244("animationID", (ArgumentType)class_2232.method_9441())
/*  56 */           .suggests(new AnimationArgumentProvider())
/*  57 */           .then(class_2170.method_9244("mannequin", (ArgumentType)class_5242.method_27643())
/*  58 */             .executes(PlayerAnimCommands::executeMannequin))));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static int execute(CommandContext<class_2168> context) {
/*  65 */     class_2960 animation = class_2232.method_9443(context, "animationID");
/*  66 */     return playAnimation(PlayerAnimResources.getAnimation(animation));
/*     */   }
/*     */   
/*     */   private static int executeLegacy(CommandContext<class_2168> context) {
/*  70 */     Animation animation = Objects.<Animation>requireNonNull(PlayerAnimResources.getAnimation(class_2232.method_9443(context, "animationID")));
/*  71 */     int version = IntegerArgumentType.getInteger(context, "version");
/*     */     
/*  73 */     ByteBuf byteBuffer = Unpooled.buffer(LegacyAnimationBinary.calculateSize(animation, version));
/*  74 */     LegacyAnimationBinary.write(animation, byteBuffer, version);
/*     */     
/*     */     try {
/*  77 */       return playAnimation(LegacyAnimationBinary.read(byteBuffer, version));
/*  78 */     } catch (IOException e) {
/*  79 */       throw new RuntimeException(e);
/*     */     } finally {
/*  81 */       byteBuffer.release();
/*     */     } 
/*     */   }
/*     */   
/*     */   private static int executeBinary(CommandContext<class_2168> context) {
/*  86 */     Animation animation = Objects.<Animation>requireNonNull(PlayerAnimResources.getAnimation(class_2232.method_9443(context, "animationID")));
/*  87 */     int version = IntegerArgumentType.getInteger(context, "version");
/*     */     
/*  89 */     ByteBuf byteBuf = Unpooled.buffer();
/*  90 */     AnimationBinary.write(byteBuf, version, animation);
/*     */     
/*  92 */     return playAnimation(AnimationBinary.read(byteBuf, version));
/*     */   }
/*     */   
/*     */   private static int playAnimation(Animation animation) {
/*  96 */     AnimationController controller = (AnimationController)PlayerAnimationAccess.getPlayerAnimationLayer(
/*  97 */         (class_11890)Objects.requireNonNull((class_310.method_1551()).field_1724), PlayerAnimLibMod.ANIMATION_LAYER_ID);
/*     */     
/*  99 */     if (controller == null) return 0; 
/* 100 */     controller.triggerAnimation(RawAnimation.begin().thenPlay(animation));
/* 101 */     return 1;
/*     */   }
/*     */   
/*     */   private static int executeMannequin(CommandContext<class_2168> context) {
/* 105 */     Animation animation = Objects.<Animation>requireNonNull(PlayerAnimResources.getAnimation(class_2232.method_9443(context, "animationID")));
/* 106 */     class_11890 avatar = (class_11890)Objects.requireNonNull((class_310.method_1551()).field_1687.method_66347(class_5242.method_27645(context, "mannequin")));
/*     */     
/* 108 */     AnimationController controller = (AnimationController)PlayerAnimationAccess.getPlayerAnimationLayer(avatar, PlayerAnimLibMod.ANIMATION_LAYER_ID);
/*     */ 
/*     */     
/* 111 */     if (controller == null) return 0; 
/* 112 */     controller.triggerAnimation(RawAnimation.begin().thenPlay(animation));
/* 113 */     return 1;
/*     */   }
/*     */ }


/* Location:              C:\Users\rapha\Downloads\aurora.jar!\META-INF\jars\player-animation-library-wJLdv4ZQ.jar!\com\zigythebird\playeranim\commands\PlayerAnimCommands.class
 * Java compiler version: 21 (65.0)
 * JD-Core Version:       1.1.3
 */