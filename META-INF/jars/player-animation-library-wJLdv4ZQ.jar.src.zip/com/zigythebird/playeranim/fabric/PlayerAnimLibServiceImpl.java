/*   */ package com.zigythebird.playeranim.fabric;
/*   */ 
/*   */ import com.zigythebird.playeranim.PlayerAnimLibService;
/*   */ import net.fabricmc.loader.api.FabricLoader;
/*   */ 
/*   */ public final class PlayerAnimLibServiceImpl
/*   */   implements PlayerAnimLibService {
/*   */   public boolean isModLoaded(String id) {
/* 9 */     return FabricLoader.getInstance().isModLoaded(id);
/*   */   }
/*   */ }


/* Location:              C:\Users\rapha\Downloads\aurora.jar!\META-INF\jars\player-animation-library-wJLdv4ZQ.jar!\com\zigythebird\playeranim\fabric\PlayerAnimLibServiceImpl.class
 * Java compiler version: 21 (65.0)
 * JD-Core Version:       1.1.3
 */