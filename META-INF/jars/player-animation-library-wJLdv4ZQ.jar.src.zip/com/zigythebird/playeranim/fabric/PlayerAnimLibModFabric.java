/*    */ package com.zigythebird.playeranim.fabric;
/*    */ import com.zigythebird.playeranim.PlayerAnimLibMod;
/*    */ import com.zigythebird.playeranim.animation.PlayerAnimResources;
/*    */ import com.zigythebird.playeranim.commands.PlayerAnimCommands;
/*    */ import net.fabricmc.api.ClientModInitializer;
/*    */ import net.fabricmc.fabric.api.client.command.v2.ClientCommandRegistrationCallback;
/*    */ import net.fabricmc.fabric.api.resource.v1.ResourceLoader;
/*    */ import net.fabricmc.loader.api.FabricLoader;
/*    */ import net.fabricmc.loader.api.ModContainer;
/*    */ import net.minecraft.class_3264;
/*    */ import net.minecraft.class_3302;
/*    */ 
/*    */ public final class PlayerAnimLibModFabric extends PlayerAnimLibMod implements ClientModInitializer {
/*    */   public void onInitializeClient() {
/* 15 */     ResourceLoader.get(class_3264.field_14188).registerReloader(PlayerAnimResources.KEY, (class_3302)new PlayerAnimResources());
/* 16 */     if (FabricLoader.getInstance().isDevelopmentEnvironment() || ((ModContainer)FabricLoader.getInstance().getModContainer("player_animation_library").get()).getMetadata().getVersion().getFriendlyString().contains("dev")) {
/* 17 */       ClientCommandRegistrationCallback.EVENT.register(PlayerAnimCommands::register);
/*    */     }
/* 19 */     init();
/*    */   }
/*    */ }


/* Location:              C:\Users\rapha\Downloads\aurora.jar!\META-INF\jars\player-animation-library-wJLdv4ZQ.jar!\com\zigythebird\playeranim\fabric\PlayerAnimLibModFabric.class
 * Java compiler version: 21 (65.0)
 * JD-Core Version:       1.1.3
 */