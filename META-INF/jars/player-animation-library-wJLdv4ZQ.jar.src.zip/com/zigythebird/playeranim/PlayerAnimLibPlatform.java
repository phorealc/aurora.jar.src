/*   */ package com.zigythebird.playeranim;
/*   */ 
/*   */ @Deprecated(forRemoval = true)
/*   */ public class PlayerAnimLibPlatform {
/*   */   @Deprecated(forRemoval = true)
/*   */   public static boolean isModLoaded(String id) {
/* 7 */     return PlayerAnimLibService.INSTANCE.isModLoaded(id);
/*   */   }
/*   */ }


/* Location:              C:\Users\rapha\Downloads\aurora.jar!\META-INF\jars\player-animation-library-wJLdv4ZQ.jar!\com\zigythebird\playeranim\PlayerAnimLibPlatform.class
 * Java compiler version: 21 (65.0)
 * JD-Core Version:       1.1.3
 */