/*      */ package imgui.glfw;
/*      */ 
/*      */ import imgui.ImGui;
/*      */ import imgui.ImGuiIO;
/*      */ import imgui.ImGuiPlatformIO;
/*      */ import imgui.ImGuiViewport;
/*      */ import imgui.ImVec2;
/*      */ import imgui.callback.ImPlatformFuncViewport;
/*      */ import imgui.callback.ImPlatformFuncViewportFloat;
/*      */ import imgui.callback.ImPlatformFuncViewportImVec2;
/*      */ import imgui.callback.ImPlatformFuncViewportString;
/*      */ import imgui.callback.ImPlatformFuncViewportSuppBoolean;
/*      */ import imgui.callback.ImPlatformFuncViewportSuppImVec2;
/*      */ import imgui.callback.ImStrConsumer;
/*      */ import imgui.callback.ImStrSupplier;
/*      */ import imgui.lwjgl3.glfw.ImGuiImplGlfwNative;
/*      */ import java.nio.ByteBuffer;
/*      */ import java.nio.FloatBuffer;
/*      */ import org.lwjgl.PointerBuffer;
/*      */ import org.lwjgl.glfw.Callbacks;
/*      */ import org.lwjgl.glfw.GLFW;
/*      */ import org.lwjgl.glfw.GLFWCharCallback;
/*      */ import org.lwjgl.glfw.GLFWCharCallbackI;
/*      */ import org.lwjgl.glfw.GLFWCursorEnterCallback;
/*      */ import org.lwjgl.glfw.GLFWCursorEnterCallbackI;
/*      */ import org.lwjgl.glfw.GLFWCursorPosCallback;
/*      */ import org.lwjgl.glfw.GLFWCursorPosCallbackI;
/*      */ import org.lwjgl.glfw.GLFWErrorCallback;
/*      */ import org.lwjgl.glfw.GLFWErrorCallbackI;
/*      */ import org.lwjgl.glfw.GLFWGamepadState;
/*      */ import org.lwjgl.glfw.GLFWKeyCallback;
/*      */ import org.lwjgl.glfw.GLFWKeyCallbackI;
/*      */ import org.lwjgl.glfw.GLFWMonitorCallback;
/*      */ import org.lwjgl.glfw.GLFWMonitorCallbackI;
/*      */ import org.lwjgl.glfw.GLFWMouseButtonCallback;
/*      */ import org.lwjgl.glfw.GLFWMouseButtonCallbackI;
/*      */ import org.lwjgl.glfw.GLFWNativeCocoa;
/*      */ import org.lwjgl.glfw.GLFWNativeWin32;
/*      */ import org.lwjgl.glfw.GLFWScrollCallback;
/*      */ import org.lwjgl.glfw.GLFWScrollCallbackI;
/*      */ import org.lwjgl.glfw.GLFWVidMode;
/*      */ import org.lwjgl.glfw.GLFWWindowFocusCallback;
/*      */ import org.lwjgl.glfw.GLFWWindowFocusCallbackI;
/*      */ import org.lwjgl.system.Callback;
/*      */ import org.lwjgl.system.CustomBuffer;
/*      */ import org.lwjgl.system.MemoryUtil;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ public class ImGuiImplGlfw
/*      */ {
/*  272 */   protected static final String OS = System.getProperty("os.name", "generic").toLowerCase();
/*  273 */   protected static final boolean IS_WINDOWS = OS.contains("win");
/*  274 */   protected static final boolean IS_APPLE = (OS.contains("mac") || OS.contains("darwin"));
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected static class Data
/*      */   {
/*  281 */     protected long window = -1L;
/*  282 */     protected double time = 0.0D;
/*  283 */     protected long mouseWindow = -1L;
/*  284 */     protected long[] mouseCursors = new long[9];
/*  285 */     protected ImVec2 lastValidMousePos = new ImVec2();
/*  286 */     protected long[] keyOwnerWindows = new long[348];
/*      */     
/*      */     protected boolean installedCallbacks = false;
/*      */     
/*      */     protected boolean callbacksChainForAllWindows = false;
/*      */     protected boolean wantUpdateMonitors = true;
/*  292 */     protected GLFWWindowFocusCallback prevUserCallbackWindowFocus = null;
/*  293 */     protected GLFWCursorPosCallback prevUserCallbackCursorPos = null;
/*  294 */     protected GLFWCursorEnterCallback prevUserCallbackCursorEnter = null;
/*  295 */     protected GLFWMouseButtonCallback prevUserCallbackMousebutton = null;
/*  296 */     protected GLFWScrollCallback prevUserCallbackScroll = null;
/*  297 */     protected GLFWKeyCallback prevUserCallbackKey = null;
/*  298 */     protected GLFWCharCallback prevUserCallbackChar = null;
/*  299 */     protected GLFWMonitorCallback prevUserCallbackMonitor = null;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private static final class Properties
/*      */   {
/*      */     private Properties() {}
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  312 */     private final int[] windowW = new int[1];
/*  313 */     private final int[] windowH = new int[1];
/*  314 */     private final int[] windowX = new int[1];
/*  315 */     private final int[] windowY = new int[1];
/*  316 */     private final int[] displayW = new int[1];
/*  317 */     private final int[] displayH = new int[1];
/*      */ 
/*      */     
/*  320 */     private final ImVec2 mousePosPrev = new ImVec2();
/*  321 */     private final double[] mouseX = new double[1];
/*  322 */     private final double[] mouseY = new double[1];
/*      */ 
/*      */     
/*  325 */     private final int[] monitorX = new int[1];
/*  326 */     private final int[] monitorY = new int[1];
/*  327 */     private final int[] monitorWorkAreaX = new int[1];
/*  328 */     private final int[] monitorWorkAreaY = new int[1];
/*  329 */     private final int[] monitorWorkAreaWidth = new int[1];
/*  330 */     private final int[] monitorWorkAreaHeight = new int[1];
/*  331 */     private final float[] monitorContentScaleX = new float[1];
/*  332 */     private final float[] monitorContentScaleY = new float[1];
/*      */ 
/*      */     
/*  335 */     private final String charNames = "`-=[]\\,;'./";
/*  336 */     private final int[] charKeys = new int[] { 96, 45, 61, 91, 93, 92, 44, 59, 39, 46, 47 };
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  343 */   protected Data data = null;
/*  344 */   private final Properties props = new Properties();
/*      */   
/*      */   protected static final int glfwVersionCombined = 3400;
/*      */   
/*      */   protected static final boolean glfwHawWindowTopmost = true;
/*      */   
/*      */   protected static final boolean glfwHasWindowHovered = true;
/*      */   protected static final boolean glfwHasWindowAlpha = true;
/*      */   protected static final boolean glfwHasPerMonitorDpi = true;
/*      */   protected static final boolean glfwHasFocusWindow = true;
/*      */   protected static final boolean glfwHasFocusOnShow = true;
/*      */   protected static final boolean glfwHasMonitorWorkArea = true;
/*      */   protected static final boolean glfwHasOsxWindowPosFix = true;
/*      */   protected static final boolean glfwHasNewCursors = true;
/*      */   protected static final boolean glfwHasMousePassthrough = true;
/*      */   protected static final boolean glfwHasGamepadApi = true;
/*      */   protected static final boolean glfwHasGetKeyName = true;
/*      */   protected static final boolean glfwHasGetError = true;
/*      */   
/*      */   protected ImStrSupplier getClipboardTextFn() {
/*  364 */     return new ImStrSupplier()
/*      */       {
/*      */         public String get() {
/*  367 */           String clipboardString = GLFW.glfwGetClipboardString(ImGuiImplGlfw.this.data.window);
/*  368 */           return (clipboardString != null) ? clipboardString : "";
/*      */         }
/*      */       };
/*      */   }
/*      */   
/*      */   protected ImStrConsumer setClipboardTextFn() {
/*  374 */     return new ImStrConsumer()
/*      */       {
/*      */         public void accept(String text) {
/*  377 */           GLFW.glfwSetClipboardString(ImGuiImplGlfw.this.data.window, text);
/*      */         }
/*      */       };
/*      */   }
/*      */   
/*      */   protected int glfwKeyToImGuiKey(int glfwKey) {
/*  383 */     switch (glfwKey) {
/*      */       case 258:
/*  385 */         return 512;
/*      */       case 263:
/*  387 */         return 513;
/*      */       case 262:
/*  389 */         return 514;
/*      */       case 265:
/*  391 */         return 515;
/*      */       case 264:
/*  393 */         return 516;
/*      */       case 266:
/*  395 */         return 517;
/*      */       case 267:
/*  397 */         return 518;
/*      */       case 268:
/*  399 */         return 519;
/*      */       case 269:
/*  401 */         return 520;
/*      */       case 260:
/*  403 */         return 521;
/*      */       case 261:
/*  405 */         return 522;
/*      */       case 259:
/*  407 */         return 523;
/*      */       case 32:
/*  409 */         return 524;
/*      */       case 257:
/*  411 */         return 525;
/*      */       case 256:
/*  413 */         return 526;
/*      */       case 39:
/*  415 */         return 596;
/*      */       case 44:
/*  417 */         return 597;
/*      */       case 45:
/*  419 */         return 598;
/*      */       case 46:
/*  421 */         return 599;
/*      */       case 47:
/*  423 */         return 600;
/*      */       case 59:
/*  425 */         return 601;
/*      */       case 61:
/*  427 */         return 602;
/*      */       case 91:
/*  429 */         return 603;
/*      */       case 92:
/*  431 */         return 604;
/*      */       case 93:
/*  433 */         return 605;
/*      */       case 96:
/*  435 */         return 606;
/*      */       case 280:
/*  437 */         return 607;
/*      */       case 281:
/*  439 */         return 608;
/*      */       case 282:
/*  441 */         return 609;
/*      */       case 283:
/*  443 */         return 610;
/*      */       case 284:
/*  445 */         return 611;
/*      */       case 320:
/*  447 */         return 612;
/*      */       case 321:
/*  449 */         return 613;
/*      */       case 322:
/*  451 */         return 614;
/*      */       case 323:
/*  453 */         return 615;
/*      */       case 324:
/*  455 */         return 616;
/*      */       case 325:
/*  457 */         return 617;
/*      */       case 326:
/*  459 */         return 618;
/*      */       case 327:
/*  461 */         return 619;
/*      */       case 328:
/*  463 */         return 620;
/*      */       case 329:
/*  465 */         return 621;
/*      */       case 330:
/*  467 */         return 622;
/*      */       case 331:
/*  469 */         return 623;
/*      */       case 332:
/*  471 */         return 624;
/*      */       case 333:
/*  473 */         return 625;
/*      */       case 334:
/*  475 */         return 626;
/*      */       case 335:
/*  477 */         return 627;
/*      */       case 336:
/*  479 */         return 628;
/*      */       case 340:
/*  481 */         return 528;
/*      */       case 341:
/*  483 */         return 527;
/*      */       case 342:
/*  485 */         return 529;
/*      */       case 343:
/*  487 */         return 530;
/*      */       case 344:
/*  489 */         return 532;
/*      */       case 345:
/*  491 */         return 531;
/*      */       case 346:
/*  493 */         return 533;
/*      */       case 347:
/*  495 */         return 534;
/*      */       case 348:
/*  497 */         return 535;
/*      */       case 48:
/*  499 */         return 536;
/*      */       case 49:
/*  501 */         return 537;
/*      */       case 50:
/*  503 */         return 538;
/*      */       case 51:
/*  505 */         return 539;
/*      */       case 52:
/*  507 */         return 540;
/*      */       case 53:
/*  509 */         return 541;
/*      */       case 54:
/*  511 */         return 542;
/*      */       case 55:
/*  513 */         return 543;
/*      */       case 56:
/*  515 */         return 544;
/*      */       case 57:
/*  517 */         return 545;
/*      */       case 65:
/*  519 */         return 546;
/*      */       case 66:
/*  521 */         return 547;
/*      */       case 67:
/*  523 */         return 548;
/*      */       case 68:
/*  525 */         return 549;
/*      */       case 69:
/*  527 */         return 550;
/*      */       case 70:
/*  529 */         return 551;
/*      */       case 71:
/*  531 */         return 552;
/*      */       case 72:
/*  533 */         return 553;
/*      */       case 73:
/*  535 */         return 554;
/*      */       case 74:
/*  537 */         return 555;
/*      */       case 75:
/*  539 */         return 556;
/*      */       case 76:
/*  541 */         return 557;
/*      */       case 77:
/*  543 */         return 558;
/*      */       case 78:
/*  545 */         return 559;
/*      */       case 79:
/*  547 */         return 560;
/*      */       case 80:
/*  549 */         return 561;
/*      */       case 81:
/*  551 */         return 562;
/*      */       case 82:
/*  553 */         return 563;
/*      */       case 83:
/*  555 */         return 564;
/*      */       case 84:
/*  557 */         return 565;
/*      */       case 85:
/*  559 */         return 566;
/*      */       case 86:
/*  561 */         return 567;
/*      */       case 87:
/*  563 */         return 568;
/*      */       case 88:
/*  565 */         return 569;
/*      */       case 89:
/*  567 */         return 570;
/*      */       case 90:
/*  569 */         return 571;
/*      */       case 290:
/*  571 */         return 572;
/*      */       case 291:
/*  573 */         return 573;
/*      */       case 292:
/*  575 */         return 574;
/*      */       case 293:
/*  577 */         return 575;
/*      */       case 294:
/*  579 */         return 576;
/*      */       case 295:
/*  581 */         return 577;
/*      */       case 296:
/*  583 */         return 578;
/*      */       case 297:
/*  585 */         return 579;
/*      */       case 298:
/*  587 */         return 580;
/*      */       case 299:
/*  589 */         return 581;
/*      */       case 300:
/*  591 */         return 582;
/*      */       case 301:
/*  593 */         return 583;
/*      */       case 302:
/*  595 */         return 584;
/*      */       case 303:
/*  597 */         return 585;
/*      */       case 304:
/*  599 */         return 586;
/*      */       case 305:
/*  601 */         return 587;
/*      */       case 306:
/*  603 */         return 588;
/*      */       case 307:
/*  605 */         return 589;
/*      */       case 308:
/*  607 */         return 590;
/*      */       case 309:
/*  609 */         return 591;
/*      */       case 310:
/*  611 */         return 592;
/*      */       case 311:
/*  613 */         return 593;
/*      */       case 312:
/*  615 */         return 594;
/*      */       case 313:
/*  617 */         return 595;
/*      */     } 
/*  619 */     return 0;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected void updateKeyModifiers(long window) {
/*  626 */     ImGuiIO io = ImGui.getIO();
/*  627 */     io.addKeyEvent(4096, (GLFW.glfwGetKey(window, 341) == 1 || GLFW.glfwGetKey(window, 345) == 1));
/*  628 */     io.addKeyEvent(8192, (GLFW.glfwGetKey(window, 340) == 1 || GLFW.glfwGetKey(window, 344) == 1));
/*  629 */     io.addKeyEvent(16384, (GLFW.glfwGetKey(window, 342) == 1 || GLFW.glfwGetKey(window, 346) == 1));
/*  630 */     io.addKeyEvent(32768, (GLFW.glfwGetKey(window, 343) == 1 || GLFW.glfwGetKey(window, 347) == 1));
/*      */   }
/*      */   
/*      */   protected boolean shouldChainCallback(long window) {
/*  634 */     return this.data.callbacksChainForAllWindows ? true : ((window == this.data.window));
/*      */   }
/*      */   
/*      */   public void mouseButtonCallback(long window, int button, int action, int mods) {
/*  638 */     if (this.data.prevUserCallbackMousebutton != null && shouldChainCallback(window)) {
/*  639 */       this.data.prevUserCallbackMousebutton.invoke(window, button, action, mods);
/*      */     }
/*      */     
/*  642 */     updateKeyModifiers(window);
/*      */     
/*  644 */     ImGuiIO io = ImGui.getIO();
/*  645 */     if (button >= 0 && button < 5) {
/*  646 */       io.addMouseButtonEvent(button, (action == 1));
/*      */     }
/*      */   }
/*      */   
/*      */   public void scrollCallback(long window, double xOffset, double yOffset) {
/*  651 */     if (this.data.prevUserCallbackScroll != null && shouldChainCallback(window)) {
/*  652 */       this.data.prevUserCallbackScroll.invoke(window, xOffset, yOffset);
/*      */     }
/*      */     
/*  655 */     ImGuiIO io = ImGui.getIO();
/*  656 */     io.addMouseWheelEvent((float)xOffset, (float)yOffset);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected int translateUntranslatedKey(int key, int scancode) {
/*  669 */     if (key >= 320 && key <= 336) {
/*  670 */       return key;
/*      */     }
/*      */     
/*  673 */     int resultKey = key;
/*  674 */     String keyName = GLFW.glfwGetKeyName(key, scancode);
/*  675 */     eatErrors();
/*  676 */     if (keyName != null && keyName.length() > 2 && keyName.charAt(0) != '\000' && keyName.charAt(1) == '\000') {
/*  677 */       if (keyName.charAt(0) >= '0' && keyName.charAt(0) <= '9') {
/*  678 */         resultKey = 48 + keyName.charAt(0) - 48;
/*  679 */       } else if (keyName.charAt(0) >= 'A' && keyName.charAt(0) <= 'Z') {
/*  680 */         resultKey = 65 + keyName.charAt(0) - 65;
/*  681 */       } else if (keyName.charAt(0) >= 'a' && keyName.charAt(0) <= 'z') {
/*  682 */         resultKey = 65 + keyName.charAt(0) - 97;
/*      */       } else {
/*  684 */         int index = "`-=[]\\,;'./".indexOf(keyName.charAt(0));
/*  685 */         if (index != -1) {
/*  686 */           resultKey = this.props.charKeys[index];
/*      */         }
/*      */       } 
/*      */     }
/*      */     
/*  691 */     return resultKey;
/*      */   }
/*      */ 
/*      */   
/*      */   protected void eatErrors() {
/*  696 */     PointerBuffer pb = MemoryUtil.memAllocPointer(1);
/*  697 */     GLFW.glfwGetError(pb);
/*  698 */     MemoryUtil.memFree((CustomBuffer)pb);
/*      */   }
/*      */ 
/*      */   
/*      */   public void keyCallback(long window, int keycode, int scancode, int action, int mods) {
/*  703 */     if (this.data.prevUserCallbackKey != null && shouldChainCallback(window)) {
/*  704 */       this.data.prevUserCallbackKey.invoke(window, keycode, scancode, action, mods);
/*      */     }
/*      */     
/*  707 */     if (action != 1 && action != 0) {
/*      */       return;
/*      */     }
/*      */     
/*  711 */     updateKeyModifiers(window);
/*      */     
/*  713 */     if (keycode >= 0 && keycode < this.data.keyOwnerWindows.length) {
/*  714 */       this.data.keyOwnerWindows[keycode] = (action == 1) ? window : -1L;
/*      */     }
/*      */     
/*  717 */     int key = translateUntranslatedKey(keycode, scancode);
/*      */     
/*  719 */     ImGuiIO io = ImGui.getIO();
/*  720 */     int imguiKey = glfwKeyToImGuiKey(key);
/*  721 */     io.addKeyEvent(imguiKey, (action == 1));
/*  722 */     io.setKeyEventNativeData(imguiKey, key, scancode);
/*      */   }
/*      */   
/*      */   public void windowFocusCallback(long window, boolean focused) {
/*  726 */     if (this.data.prevUserCallbackWindowFocus != null && shouldChainCallback(window)) {
/*  727 */       this.data.prevUserCallbackWindowFocus.invoke(window, focused);
/*      */     }
/*      */     
/*  730 */     ImGui.getIO().addFocusEvent(focused);
/*      */   }
/*      */   
/*      */   public void cursorPosCallback(long window, double x, double y) {
/*  734 */     if (this.data.prevUserCallbackCursorPos != null && shouldChainCallback(window)) {
/*  735 */       this.data.prevUserCallbackCursorPos.invoke(window, x, y);
/*      */     }
/*      */     
/*  738 */     float posX = (float)x;
/*  739 */     float posY = (float)y;
/*      */     
/*  741 */     ImGuiIO io = ImGui.getIO();
/*      */     
/*  743 */     if (io.hasConfigFlags(1024)) {
/*  744 */       GLFW.glfwGetWindowPos(window, this.props.windowX, this.props.windowY);
/*  745 */       posX += this.props.windowX[0];
/*  746 */       posY += this.props.windowY[0];
/*      */     } 
/*      */     
/*  749 */     io.addMousePosEvent(posX, posY);
/*  750 */     this.data.lastValidMousePos.set(posX, posY);
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public void cursorEnterCallback(long window, boolean entered) {
/*  756 */     if (this.data.prevUserCallbackCursorEnter != null && shouldChainCallback(window)) {
/*  757 */       this.data.prevUserCallbackCursorEnter.invoke(window, entered);
/*      */     }
/*      */     
/*  760 */     ImGuiIO io = ImGui.getIO();
/*      */     
/*  762 */     if (entered) {
/*  763 */       this.data.mouseWindow = window;
/*  764 */       io.addMousePosEvent(this.data.lastValidMousePos.x, this.data.lastValidMousePos.y);
/*  765 */     } else if (this.data.mouseWindow == window) {
/*  766 */       io.getMousePos(this.data.lastValidMousePos);
/*  767 */       this.data.mouseWindow = -1L;
/*  768 */       io.addMousePosEvent(Float.MIN_VALUE, Float.MIN_VALUE);
/*      */     } 
/*      */   }
/*      */   
/*      */   public void charCallback(long window, int c) {
/*  773 */     if (this.data.prevUserCallbackChar != null && shouldChainCallback(window)) {
/*  774 */       this.data.prevUserCallbackChar.invoke(window, c);
/*      */     }
/*      */     
/*  777 */     ImGui.getIO().addInputCharacter(c);
/*      */   }
/*      */   
/*      */   public void monitorCallback(long window, int event) {
/*  781 */     this.data.wantUpdateMonitors = true;
/*      */   }
/*      */   
/*      */   public void installCallbacks(long window) {
/*  785 */     this.data.prevUserCallbackWindowFocus = GLFW.glfwSetWindowFocusCallback(window, this::windowFocusCallback);
/*  786 */     this.data.prevUserCallbackCursorEnter = GLFW.glfwSetCursorEnterCallback(window, this::cursorEnterCallback);
/*  787 */     this.data.prevUserCallbackCursorPos = GLFW.glfwSetCursorPosCallback(window, this::cursorPosCallback);
/*  788 */     this.data.prevUserCallbackMousebutton = GLFW.glfwSetMouseButtonCallback(window, this::mouseButtonCallback);
/*  789 */     this.data.prevUserCallbackScroll = GLFW.glfwSetScrollCallback(window, this::scrollCallback);
/*  790 */     this.data.prevUserCallbackKey = GLFW.glfwSetKeyCallback(window, this::keyCallback);
/*  791 */     this.data.prevUserCallbackChar = GLFW.glfwSetCharCallback(window, this::charCallback);
/*  792 */     this.data.prevUserCallbackMonitor = GLFW.glfwSetMonitorCallback(this::monitorCallback);
/*  793 */     this.data.installedCallbacks = true;
/*      */   }
/*      */   
/*      */   protected void freeCallback(Callback cb) {
/*  797 */     if (cb != null) {
/*  798 */       cb.free();
/*      */     }
/*      */   }
/*      */   
/*      */   public void restoreCallbacks(long window) {
/*  803 */     freeCallback((Callback)GLFW.glfwSetWindowFocusCallback(window, (GLFWWindowFocusCallbackI)this.data.prevUserCallbackWindowFocus));
/*  804 */     freeCallback((Callback)GLFW.glfwSetCursorEnterCallback(window, (GLFWCursorEnterCallbackI)this.data.prevUserCallbackCursorEnter));
/*  805 */     freeCallback((Callback)GLFW.glfwSetCursorPosCallback(window, (GLFWCursorPosCallbackI)this.data.prevUserCallbackCursorPos));
/*  806 */     freeCallback((Callback)GLFW.glfwSetMouseButtonCallback(window, (GLFWMouseButtonCallbackI)this.data.prevUserCallbackMousebutton));
/*  807 */     freeCallback((Callback)GLFW.glfwSetScrollCallback(window, (GLFWScrollCallbackI)this.data.prevUserCallbackScroll));
/*  808 */     freeCallback((Callback)GLFW.glfwSetKeyCallback(window, (GLFWKeyCallbackI)this.data.prevUserCallbackKey));
/*  809 */     freeCallback((Callback)GLFW.glfwSetCharCallback(window, (GLFWCharCallbackI)this.data.prevUserCallbackChar));
/*  810 */     freeCallback((Callback)GLFW.glfwSetMonitorCallback((GLFWMonitorCallbackI)this.data.prevUserCallbackMonitor));
/*  811 */     this.data.installedCallbacks = false;
/*  812 */     this.data.prevUserCallbackWindowFocus = null;
/*  813 */     this.data.prevUserCallbackCursorEnter = null;
/*  814 */     this.data.prevUserCallbackCursorPos = null;
/*  815 */     this.data.prevUserCallbackMousebutton = null;
/*  816 */     this.data.prevUserCallbackScroll = null;
/*  817 */     this.data.prevUserCallbackKey = null;
/*  818 */     this.data.prevUserCallbackChar = null;
/*  819 */     this.data.prevUserCallbackMonitor = null;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setCallbacksChainForAllWindows(boolean chainForAllWindows) {
/*  829 */     this.data.callbacksChainForAllWindows = chainForAllWindows;
/*      */   }
/*      */   
/*      */   protected Data newData() {
/*  833 */     return new Data();
/*      */   }
/*      */   
/*      */   public boolean init(long window, boolean installCallbacks) {
/*  837 */     ImGuiIO io = ImGui.getIO();
/*      */     
/*  839 */     io.setBackendPlatformName("imgui-java_impl_glfw");
/*  840 */     io.addBackendFlags(1030);
/*      */     
/*  842 */     io.addBackendFlags(2048);
/*      */ 
/*      */     
/*  845 */     this.data = newData();
/*  846 */     this.data.window = window;
/*  847 */     this.data.time = 0.0D;
/*  848 */     this.data.wantUpdateMonitors = true;
/*      */     
/*  850 */     io.setGetClipboardTextFn(getClipboardTextFn());
/*  851 */     io.setSetClipboardTextFn(setClipboardTextFn());
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  857 */     GLFWErrorCallback prevErrorCallback = GLFW.glfwSetErrorCallback(null);
/*  858 */     this.data.mouseCursors[0] = GLFW.glfwCreateStandardCursor(221185);
/*  859 */     this.data.mouseCursors[1] = GLFW.glfwCreateStandardCursor(221186);
/*  860 */     this.data.mouseCursors[3] = GLFW.glfwCreateStandardCursor(221190);
/*  861 */     this.data.mouseCursors[4] = GLFW.glfwCreateStandardCursor(221189);
/*  862 */     this.data.mouseCursors[7] = GLFW.glfwCreateStandardCursor(221188);
/*      */     
/*  864 */     this.data.mouseCursors[2] = GLFW.glfwCreateStandardCursor(221193);
/*  865 */     this.data.mouseCursors[5] = GLFW.glfwCreateStandardCursor(221192);
/*  866 */     this.data.mouseCursors[6] = GLFW.glfwCreateStandardCursor(221191);
/*  867 */     this.data.mouseCursors[8] = GLFW.glfwCreateStandardCursor(221194);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  874 */     GLFW.glfwSetErrorCallback((GLFWErrorCallbackI)prevErrorCallback);
/*  875 */     eatErrors();
/*      */ 
/*      */     
/*  878 */     if (installCallbacks) {
/*  879 */       installCallbacks(window);
/*      */     }
/*      */ 
/*      */     
/*  883 */     updateMonitors();
/*  884 */     GLFW.glfwSetMonitorCallback(this::monitorCallback);
/*      */ 
/*      */     
/*  887 */     ImGuiViewport mainViewport = ImGui.getMainViewport();
/*  888 */     mainViewport.setPlatformHandle(window);
/*  889 */     if (IS_WINDOWS) {
/*  890 */       mainViewport.setPlatformHandleRaw(GLFWNativeWin32.glfwGetWin32Window(window));
/*      */     }
/*  892 */     if (IS_APPLE) {
/*  893 */       mainViewport.setPlatformHandleRaw(GLFWNativeCocoa.glfwGetCocoaWindow(window));
/*      */     }
/*  895 */     if (io.hasConfigFlags(1024)) {
/*  896 */       initPlatformInterface();
/*      */     }
/*      */     
/*  899 */     return true;
/*      */   }
/*      */   
/*      */   public void shutdown() {
/*  903 */     ImGuiIO io = ImGui.getIO();
/*      */     
/*  905 */     shutdownPlatformInterface();
/*      */     
/*  907 */     if (this.data.installedCallbacks) {
/*  908 */       restoreCallbacks(this.data.window);
/*      */     }
/*      */     
/*  911 */     for (int cursorN = 0; cursorN < 9; cursorN++) {
/*  912 */       GLFW.glfwDestroyCursor(this.data.mouseCursors[cursorN]);
/*      */     }
/*      */     
/*  915 */     io.setBackendPlatformName(null);
/*  916 */     this.data = null;
/*  917 */     io.removeBackendFlags(3079);
/*      */   }
/*      */ 
/*      */   
/*      */   protected void updateMouseData() {
/*  922 */     ImGuiIO io = ImGui.getIO();
/*  923 */     ImGuiPlatformIO platformIO = ImGui.getPlatformIO();
/*      */     
/*  925 */     int mouseViewportId = 0;
/*  926 */     io.getMousePos(this.props.mousePosPrev);
/*      */     
/*  928 */     for (int n = 0; n < platformIO.getViewportsSize(); n++) {
/*  929 */       ImGuiViewport viewport = platformIO.getViewports(n);
/*  930 */       long window = viewport.getPlatformHandle();
/*  931 */       boolean isWindowFocused = (GLFW.glfwGetWindowAttrib(window, 131073) != 0);
/*      */       
/*  933 */       if (isWindowFocused) {
/*      */ 
/*      */         
/*  936 */         if (io.getWantSetMousePos()) {
/*  937 */           GLFW.glfwSetCursorPos(window, (this.props.mousePosPrev.x - viewport.getPosX()), (this.props.mousePosPrev.y - viewport.getPosY()));
/*      */         }
/*      */ 
/*      */         
/*  941 */         if (this.data.mouseWindow == -1L) {
/*  942 */           GLFW.glfwGetCursorPos(window, this.props.mouseX, this.props.mouseY);
/*  943 */           double mouseX = this.props.mouseX[0];
/*  944 */           double mouseY = this.props.mouseY[0];
/*  945 */           if (io.hasConfigFlags(1024)) {
/*      */ 
/*      */             
/*  948 */             GLFW.glfwGetWindowPos(window, this.props.windowX, this.props.windowY);
/*  949 */             mouseX += this.props.windowX[0];
/*  950 */             mouseY += this.props.windowY[0];
/*      */           } 
/*  952 */           this.data.lastValidMousePos.set((float)mouseX, (float)mouseY);
/*  953 */           io.addMousePosEvent((float)mouseX, (float)mouseY);
/*      */         } 
/*      */       } 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*  969 */       boolean windowNoInput = viewport.hasFlags(128);
/*      */       
/*  971 */       GLFW.glfwSetWindowAttrib(window, 131085, windowNoInput ? 1 : 0);
/*      */       
/*  973 */       if (GLFW.glfwGetWindowAttrib(window, 131083) == 1 && !windowNoInput) {
/*  974 */         mouseViewportId = viewport.getID();
/*      */       }
/*      */     } 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  981 */     if (io.hasBackendFlags(2048)) {
/*  982 */       io.addMouseViewportEvent(mouseViewportId);
/*      */     }
/*      */   }
/*      */   
/*      */   protected void updateMouseCursor() {
/*  987 */     ImGuiIO io = ImGui.getIO();
/*      */     
/*  989 */     if (io.hasConfigFlags(32) || GLFW.glfwGetInputMode(this.data.window, 208897) == 212995) {
/*      */       return;
/*      */     }
/*      */     
/*  993 */     int imguiCursor = ImGui.getMouseCursor();
/*  994 */     ImGuiPlatformIO platformIO = ImGui.getPlatformIO();
/*      */     
/*  996 */     for (int n = 0; n < platformIO.getViewportsSize(); n++) {
/*  997 */       long windowPtr = platformIO.getViewports(n).getPlatformHandle();
/*      */       
/*  999 */       if (imguiCursor == -1 || io.getMouseDrawCursor()) {
/*      */         
/* 1001 */         GLFW.glfwSetInputMode(windowPtr, 208897, 212994);
/*      */       }
/*      */       else {
/*      */         
/* 1005 */         GLFW.glfwSetCursor(windowPtr, (this.data.mouseCursors[imguiCursor] != 0L) ? this.data.mouseCursors[imguiCursor] : this.data.mouseCursors[0]);
/* 1006 */         GLFW.glfwSetInputMode(windowPtr, 208897, 212993);
/*      */       } 
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private float saturate(float v) {
/* 1023 */     return (v < 0.0F) ? 0.0F : ((v > 1.0F) ? 1.0F : v);
/*      */   } protected void updateGamepads() {
/*      */     MapButton mapButton;
/*      */     MapAnalog mapAnalog;
/* 1027 */     ImGuiIO io = ImGui.getIO();
/*      */     
/* 1029 */     if (!io.hasConfigFlags(2)) {
/*      */       return;
/*      */     }
/*      */     
/* 1033 */     io.removeBackendFlags(1);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 1039 */     try (GLFWGamepadState gamepad = GLFWGamepadState.create()) {
/* 1040 */       if (!GLFW.glfwGetGamepadState(0, gamepad)) {
/*      */         return;
/*      */       }
/* 1043 */       mapButton = ((keyNo, buttonNo, _unused) -> io.addKeyEvent(keyNo, (gamepad.buttons(buttonNo) != 0)));
/* 1044 */       mapAnalog = ((keyNo, axisNo, _unused, v0, v1) -> {
/*      */           float v = gamepad.axes(axisNo);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */           
/*      */           v = (v - v0) / (v1 - v0);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */           
/*      */           io.addKeyAnalogEvent(keyNo, (v > 0.1F), saturate(v));
/*      */         });
/*      */     } 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 1064 */     io.addBackendFlags(1);
/* 1065 */     mapButton.run(631, 7, 7);
/* 1066 */     mapButton.run(632, 6, 6);
/* 1067 */     mapButton.run(633, 2, 2);
/* 1068 */     mapButton.run(634, 1, 1);
/* 1069 */     mapButton.run(635, 3, 3);
/* 1070 */     mapButton.run(636, 0, 0);
/* 1071 */     mapButton.run(637, 14, 13);
/* 1072 */     mapButton.run(638, 12, 11);
/* 1073 */     mapButton.run(639, 11, 10);
/* 1074 */     mapButton.run(640, 13, 12);
/* 1075 */     mapButton.run(641, 4, 4);
/* 1076 */     mapButton.run(642, 5, 5);
/* 1077 */     mapAnalog.run(643, 4, 4, -0.75F, 1.0F);
/* 1078 */     mapAnalog.run(644, 5, 5, -0.75F, 1.0F);
/* 1079 */     mapButton.run(645, 9, 8);
/* 1080 */     mapButton.run(646, 10, 9);
/* 1081 */     mapAnalog.run(647, 0, 0, -0.25F, -1.0F);
/* 1082 */     mapAnalog.run(648, 0, 0, 0.25F, 1.0F);
/* 1083 */     mapAnalog.run(649, 1, 1, -0.25F, -1.0F);
/* 1084 */     mapAnalog.run(650, 1, 1, 0.25F, 1.0F);
/* 1085 */     mapAnalog.run(651, 2, 2, -0.25F, -1.0F);
/* 1086 */     mapAnalog.run(652, 2, 2, 0.25F, 1.0F);
/* 1087 */     mapAnalog.run(653, 3, 3, -0.25F, -1.0F);
/* 1088 */     mapAnalog.run(654, 3, 3, 0.25F, 1.0F);
/*      */   }
/*      */   
/*      */   protected void updateMonitors() {
/* 1092 */     ImGuiPlatformIO platformIO = ImGui.getPlatformIO();
/* 1093 */     this.data.wantUpdateMonitors = false;
/*      */     
/* 1095 */     PointerBuffer monitors = GLFW.glfwGetMonitors();
/* 1096 */     if (monitors == null) {
/* 1097 */       System.err.println("Unable to get monitors!");
/*      */       return;
/*      */     } 
/* 1100 */     if (monitors.limit() == 0) {
/*      */       return;
/*      */     }
/*      */     
/* 1104 */     platformIO.resizeMonitors(0);
/*      */     
/* 1106 */     for (int n = 0; n < monitors.limit(); n++) {
/* 1107 */       long monitor = monitors.get(n);
/*      */       
/* 1109 */       GLFWVidMode vidMode = GLFW.glfwGetVideoMode(monitor);
/* 1110 */       if (vidMode != null) {
/*      */ 
/*      */ 
/*      */         
/* 1114 */         GLFW.glfwGetMonitorPos(monitor, this.props.monitorX, this.props.monitorY);
/*      */         
/* 1116 */         float mainPosX = this.props.monitorX[0];
/* 1117 */         float mainPosY = this.props.monitorY[0];
/* 1118 */         float mainSizeX = vidMode.width();
/* 1119 */         float mainSizeY = vidMode.height();
/*      */         
/* 1121 */         float workPosX = 0.0F;
/* 1122 */         float workPosY = 0.0F;
/* 1123 */         float workSizeX = 0.0F;
/* 1124 */         float workSizeY = 0.0F;
/*      */ 
/*      */ 
/*      */         
/* 1128 */         GLFW.glfwGetMonitorWorkarea(monitor, this.props.monitorWorkAreaX, this.props.monitorWorkAreaY, this.props.monitorWorkAreaWidth, this.props.monitorWorkAreaHeight);
/* 1129 */         if (this.props.monitorWorkAreaWidth[0] > 0 && this.props.monitorWorkAreaHeight[0] > 0) {
/* 1130 */           workPosX = this.props.monitorWorkAreaX[0];
/* 1131 */           workPosY = this.props.monitorWorkAreaY[0];
/* 1132 */           workSizeX = this.props.monitorWorkAreaWidth[0];
/* 1133 */           workSizeY = this.props.monitorWorkAreaHeight[0];
/*      */         } 
/*      */ 
/*      */         
/* 1137 */         float dpiScale = 0.0F;
/*      */ 
/*      */ 
/*      */ 
/*      */         
/* 1142 */         GLFW.glfwGetMonitorContentScale(monitor, this.props.monitorContentScaleX, this.props.monitorContentScaleY);
/* 1143 */         dpiScale = this.props.monitorContentScaleX[0];
/*      */ 
/*      */         
/* 1146 */         platformIO.pushMonitors(monitor, mainPosX, mainPosY, mainSizeX, mainSizeY, workPosX, workPosY, workSizeX, workSizeY, dpiScale);
/*      */       } 
/*      */     } 
/*      */   }
/*      */   public void newFrame() {
/* 1151 */     ImGuiIO io = ImGui.getIO();
/*      */ 
/*      */     
/* 1154 */     GLFW.glfwGetWindowSize(this.data.window, this.props.windowW, this.props.windowH);
/* 1155 */     GLFW.glfwGetFramebufferSize(this.data.window, this.props.displayW, this.props.displayH);
/* 1156 */     io.setDisplaySize(this.props.windowW[0], this.props.windowH[0]);
/* 1157 */     if (this.props.windowW[0] > 0 && this.props.windowH[0] > 0) {
/* 1158 */       float scaleX = this.props.displayW[0] / this.props.windowW[0];
/* 1159 */       float scaleY = this.props.displayH[0] / this.props.windowH[0];
/* 1160 */       io.setDisplayFramebufferScale(scaleX, scaleY);
/*      */     } 
/*      */     
/* 1163 */     if (this.data.wantUpdateMonitors) {
/* 1164 */       updateMonitors();
/*      */     }
/*      */ 
/*      */ 
/*      */     
/* 1169 */     double currentTime = GLFW.glfwGetTime();
/* 1170 */     if (currentTime <= this.data.time) {
/* 1171 */       currentTime = this.data.time + 9.999999747378752E-6D;
/*      */     }
/* 1173 */     io.setDeltaTime((this.data.time > 0.0D) ? (float)(currentTime - this.data.time) : 0.016666668F);
/* 1174 */     this.data.time = currentTime;
/*      */     
/* 1176 */     updateMouseData();
/* 1177 */     updateMouseCursor();
/*      */ 
/*      */     
/* 1180 */     updateGamepads();
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   private static final class ViewportData
/*      */   {
/*      */     private ViewportData() {}
/*      */ 
/*      */     
/* 1190 */     long window = -1L;
/*      */     boolean windowOwned = false;
/* 1192 */     int ignoreWindowPosEventFrame = -1;
/* 1193 */     int ignoreWindowSizeEventFrame = -1;
/*      */   }
/*      */   
/*      */   private void windowCloseCallback(long windowId) {
/* 1197 */     ImGuiViewport vp = ImGui.findViewportByPlatformHandle(windowId);
/* 1198 */     if (vp.isValidPtr()) {
/* 1199 */       vp.setPlatformRequestClose(true);
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private void windowPosCallback(long windowId, int xPos, int yPos) {
/* 1210 */     ImGuiViewport vp = ImGui.findViewportByPlatformHandle(windowId);
/* 1211 */     if (vp.isNotValidPtr()) {
/*      */       return;
/*      */     }
/*      */     
/* 1215 */     ViewportData vd = (ViewportData)vp.getPlatformUserData();
/* 1216 */     if (vd != null) {
/* 1217 */       boolean ignoreEvent = (ImGui.getFrameCount() <= vd.ignoreWindowPosEventFrame + 1);
/* 1218 */       if (ignoreEvent) {
/*      */         return;
/*      */       }
/*      */     } 
/*      */     
/* 1223 */     vp.setPlatformRequestMove(true);
/*      */   }
/*      */   
/*      */   private void windowSizeCallback(long windowId, int width, int height) {
/* 1227 */     ImGuiViewport vp = ImGui.findViewportByPlatformHandle(windowId);
/* 1228 */     if (vp.isNotValidPtr()) {
/*      */       return;
/*      */     }
/*      */     
/* 1232 */     ViewportData vd = (ViewportData)vp.getPlatformUserData();
/* 1233 */     if (vd != null) {
/* 1234 */       boolean ignoreEvent = (ImGui.getFrameCount() <= vd.ignoreWindowSizeEventFrame + 1);
/* 1235 */       if (ignoreEvent) {
/*      */         return;
/*      */       }
/*      */     } 
/*      */     
/* 1240 */     vp.setPlatformRequestResize(true);
/*      */   }
/*      */   
/*      */   private final class CreateWindowFunction extends ImPlatformFuncViewport { private CreateWindowFunction() {}
/*      */     
/*      */     public void accept(ImGuiViewport vp) {
/* 1246 */       ImGuiImplGlfw.ViewportData vd = new ImGuiImplGlfw.ViewportData();
/* 1247 */       vp.setPlatformUserData(vd);
/*      */ 
/*      */ 
/*      */       
/* 1251 */       GLFW.glfwWindowHint(131076, 0);
/* 1252 */       GLFW.glfwWindowHint(131073, 0);
/*      */       
/* 1254 */       GLFW.glfwWindowHint(131084, 0);
/*      */       
/* 1256 */       GLFW.glfwWindowHint(131077, vp.hasFlags(8) ? 0 : 1);
/*      */       
/* 1258 */       GLFW.glfwWindowHint(131079, vp.hasFlags(1024) ? 1 : 0);
/*      */ 
/*      */       
/* 1261 */       vd.window = GLFW.glfwCreateWindow((int)vp.getSizeX(), (int)vp.getSizeY(), "No Title Yet", 0L, ImGuiImplGlfw.this.data.window);
/* 1262 */       vd.windowOwned = true;
/*      */       
/* 1264 */       vp.setPlatformHandle(vd.window);
/*      */       
/* 1266 */       if (ImGuiImplGlfw.IS_WINDOWS) {
/* 1267 */         vp.setPlatformHandleRaw(GLFWNativeWin32.glfwGetWin32Window(vd.window));
/* 1268 */       } else if (ImGuiImplGlfw.IS_APPLE) {
/* 1269 */         vp.setPlatformHandleRaw(GLFWNativeCocoa.glfwGetCocoaWindow(vd.window));
/*      */       } 
/*      */       
/* 1272 */       GLFW.glfwSetWindowPos(vd.window, (int)vp.getPosX(), (int)vp.getPosY());
/*      */ 
/*      */       
/* 1275 */       GLFW.glfwSetWindowFocusCallback(vd.window, ImGuiImplGlfw.this::windowFocusCallback);
/* 1276 */       GLFW.glfwSetCursorEnterCallback(vd.window, ImGuiImplGlfw.this::cursorEnterCallback);
/* 1277 */       GLFW.glfwSetCursorPosCallback(vd.window, ImGuiImplGlfw.this::cursorPosCallback);
/* 1278 */       GLFW.glfwSetMouseButtonCallback(vd.window, ImGuiImplGlfw.this::mouseButtonCallback);
/* 1279 */       GLFW.glfwSetScrollCallback(vd.window, ImGuiImplGlfw.this::scrollCallback);
/* 1280 */       GLFW.glfwSetKeyCallback(vd.window, ImGuiImplGlfw.this::keyCallback);
/* 1281 */       GLFW.glfwSetCharCallback(vd.window, ImGuiImplGlfw.this::charCallback);
/* 1282 */       GLFW.glfwSetWindowCloseCallback(vd.window, x$0 -> rec$.windowCloseCallback(x$0));
/* 1283 */       GLFW.glfwSetWindowPosCallback(vd.window, (x$0, x$1, x$2) -> rec$.windowPosCallback(x$0, x$1, x$2));
/* 1284 */       GLFW.glfwSetWindowSizeCallback(vd.window, (x$0, x$1, x$2) -> rec$.windowSizeCallback(x$0, x$1, x$2));
/*      */       
/* 1286 */       GLFW.glfwMakeContextCurrent(vd.window);
/* 1287 */       GLFW.glfwSwapInterval(0);
/*      */     } }
/*      */ 
/*      */   
/*      */   private final class DestroyWindowFunction extends ImPlatformFuncViewport { private DestroyWindowFunction() {}
/*      */     
/*      */     public void accept(ImGuiViewport vp) {
/* 1294 */       ImGuiImplGlfw.ViewportData vd = (ImGuiImplGlfw.ViewportData)vp.getPlatformUserData();
/*      */       
/* 1296 */       if (vd != null && vd.windowOwned) {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/* 1303 */         for (int i = 0; i < ImGuiImplGlfw.this.data.keyOwnerWindows.length; i++) {
/* 1304 */           if (ImGuiImplGlfw.this.data.keyOwnerWindows[i] == vd.window) {
/* 1305 */             ImGuiImplGlfw.this.keyCallback(vd.window, i, 0, 0, 0);
/*      */           }
/*      */         } 
/*      */         
/* 1309 */         Callbacks.glfwFreeCallbacks(vd.window);
/* 1310 */         GLFW.glfwDestroyWindow(vd.window);
/*      */         
/* 1312 */         vd.window = -1L;
/*      */       } 
/*      */ 
/*      */       
/* 1316 */       vp.setPlatformHandle(-1L);
/* 1317 */       vp.setPlatformUserData(null);
/*      */     } }
/*      */   
/*      */   private static final class ShowWindowFunction extends ImPlatformFuncViewport {
/*      */     private ShowWindowFunction() {}
/*      */     
/*      */     public void accept(ImGuiViewport vp) {
/* 1324 */       ImGuiImplGlfw.ViewportData vd = (ImGuiImplGlfw.ViewportData)vp.getPlatformUserData();
/* 1325 */       if (vd == null) {
/*      */         return;
/*      */       }
/*      */       
/* 1329 */       if (ImGuiImplGlfw.IS_WINDOWS && vp.hasFlags(16)) {
/* 1330 */         ImGuiImplGlfwNative.win32hideFromTaskBar(vp.getPlatformHandleRaw());
/*      */       }
/*      */       
/* 1333 */       GLFW.glfwShowWindow(vd.window);
/*      */     }
/*      */   }
/*      */   
/*      */   private static final class GetWindowPosFunction extends ImPlatformFuncViewportSuppImVec2 {
/* 1338 */     private final int[] posX = new int[1];
/* 1339 */     private final int[] posY = new int[1];
/*      */     private GetWindowPosFunction() {}
/*      */     
/*      */     public void get(ImGuiViewport vp, ImVec2 dst) {
/* 1343 */       ImGuiImplGlfw.ViewportData vd = (ImGuiImplGlfw.ViewportData)vp.getPlatformUserData();
/* 1344 */       if (vd == null) {
/*      */         return;
/*      */       }
/* 1347 */       this.posX[0] = 0;
/* 1348 */       this.posY[0] = 0;
/* 1349 */       GLFW.glfwGetWindowPos(vd.window, this.posX, this.posY);
/* 1350 */       dst.set(this.posX[0], this.posY[0]);
/*      */     } }
/*      */   
/*      */   private static final class SetWindowPosFunction extends ImPlatformFuncViewportImVec2 {
/*      */     private SetWindowPosFunction() {}
/*      */     
/*      */     public void accept(ImGuiViewport vp, ImVec2 value) {
/* 1357 */       ImGuiImplGlfw.ViewportData vd = (ImGuiImplGlfw.ViewportData)vp.getPlatformUserData();
/* 1358 */       if (vd == null) {
/*      */         return;
/*      */       }
/* 1361 */       vd.ignoreWindowPosEventFrame = ImGui.getFrameCount();
/* 1362 */       GLFW.glfwSetWindowPos(vd.window, (int)value.x, (int)value.y);
/*      */     }
/*      */   }
/*      */   
/*      */   private static final class GetWindowSizeFunction extends ImPlatformFuncViewportSuppImVec2 {
/* 1367 */     private final int[] width = new int[1];
/* 1368 */     private final int[] height = new int[1];
/*      */ 
/*      */     
/*      */     public void get(ImGuiViewport vp, ImVec2 dst) {
/* 1372 */       ImGuiImplGlfw.ViewportData vd = (ImGuiImplGlfw.ViewportData)vp.getPlatformUserData();
/* 1373 */       if (vd == null) {
/*      */         return;
/*      */       }
/* 1376 */       this.width[0] = 0;
/* 1377 */       this.height[0] = 0;
/* 1378 */       GLFW.glfwGetWindowSize(vd.window, this.width, this.height);
/* 1379 */       dst.x = this.width[0];
/* 1380 */       dst.y = this.height[0];
/*      */     }
/*      */     
/*      */     private GetWindowSizeFunction() {} }
/*      */   
/* 1385 */   private final class SetWindowSizeFunction extends ImPlatformFuncViewportImVec2 { private final int[] x = new int[1];
/* 1386 */     private final int[] y = new int[1];
/* 1387 */     private final int[] width = new int[1];
/* 1388 */     private final int[] height = new int[1];
/*      */ 
/*      */     
/*      */     public void accept(ImGuiViewport vp, ImVec2 value) {
/* 1392 */       ImGuiImplGlfw.ViewportData vd = (ImGuiImplGlfw.ViewportData)vp.getPlatformUserData();
/* 1393 */       if (vd == null) {
/*      */         return;
/*      */       }
/* 1396 */       if (ImGuiImplGlfw.IS_APPLE);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/* 1409 */       vd.ignoreWindowSizeEventFrame = ImGui.getFrameCount();
/* 1410 */       GLFW.glfwSetWindowSize(vd.window, (int)value.x, (int)value.y);
/*      */     }
/*      */     
/*      */     private SetWindowSizeFunction() {} }
/*      */ 
/*      */   
/*      */   private static final class SetWindowTitleFunction extends ImPlatformFuncViewportString { public void accept(ImGuiViewport vp, String value) {
/* 1417 */       ImGuiImplGlfw.ViewportData vd = (ImGuiImplGlfw.ViewportData)vp.getPlatformUserData();
/* 1418 */       if (vd != null)
/* 1419 */         GLFW.glfwSetWindowTitle(vd.window, value); 
/*      */     }
/*      */     
/*      */     private SetWindowTitleFunction() {} }
/*      */   
/*      */   private final class SetWindowFocusFunction extends ImPlatformFuncViewport {
/*      */     private SetWindowFocusFunction() {}
/*      */     
/*      */     public void accept(ImGuiViewport vp) {
/* 1428 */       ImGuiImplGlfw.ViewportData vd = (ImGuiImplGlfw.ViewportData)vp.getPlatformUserData();
/* 1429 */       if (vd != null)
/* 1430 */         GLFW.glfwFocusWindow(vd.window); 
/*      */     }
/*      */   }
/*      */   
/*      */   private static final class GetWindowFocusFunction
/*      */     extends ImPlatformFuncViewportSuppBoolean {
/*      */     private GetWindowFocusFunction() {}
/*      */     
/*      */     public boolean get(ImGuiViewport vp) {
/* 1439 */       ImGuiImplGlfw.ViewportData data = (ImGuiImplGlfw.ViewportData)vp.getPlatformUserData();
/* 1440 */       return (GLFW.glfwGetWindowAttrib(data.window, 131073) != 0);
/*      */     } }
/*      */   
/*      */   private static final class GetWindowMinimizedFunction extends ImPlatformFuncViewportSuppBoolean {
/*      */     private GetWindowMinimizedFunction() {}
/*      */     
/*      */     public boolean get(ImGuiViewport vp) {
/* 1447 */       ImGuiImplGlfw.ViewportData vd = (ImGuiImplGlfw.ViewportData)vp.getPlatformUserData();
/* 1448 */       if (vd != null) {
/* 1449 */         return (GLFW.glfwGetWindowAttrib(vd.window, 131074) != 0);
/*      */       }
/* 1451 */       return false;
/*      */     }
/*      */   }
/*      */   
/*      */   private final class SetWindowAlphaFunction extends ImPlatformFuncViewportFloat {
/*      */     private SetWindowAlphaFunction() {}
/*      */     
/*      */     public void accept(ImGuiViewport vp, float value) {
/* 1459 */       ImGuiImplGlfw.ViewportData vd = (ImGuiImplGlfw.ViewportData)vp.getPlatformUserData();
/* 1460 */       if (vd != null)
/* 1461 */         GLFW.glfwSetWindowOpacity(vd.window, value); 
/*      */     }
/*      */   }
/*      */   
/*      */   private static final class RenderWindowFunction
/*      */     extends ImPlatformFuncViewport {
/*      */     private RenderWindowFunction() {}
/*      */     
/*      */     public void accept(ImGuiViewport vp) {
/* 1470 */       ImGuiImplGlfw.ViewportData vd = (ImGuiImplGlfw.ViewportData)vp.getPlatformUserData();
/* 1471 */       if (vd != null)
/* 1472 */         GLFW.glfwMakeContextCurrent(vd.window); 
/*      */     }
/*      */   }
/*      */   
/*      */   private static final class SwapBuffersFunction extends ImPlatformFuncViewport {
/*      */     private SwapBuffersFunction() {}
/*      */     
/*      */     public void accept(ImGuiViewport vp) {
/* 1480 */       ImGuiImplGlfw.ViewportData vd = (ImGuiImplGlfw.ViewportData)vp.getPlatformUserData();
/* 1481 */       if (vd != null) {
/* 1482 */         GLFW.glfwMakeContextCurrent(vd.window);
/* 1483 */         GLFW.glfwSwapBuffers(vd.window);
/*      */       } 
/*      */     }
/*      */   }
/*      */   
/*      */   protected void initPlatformInterface() {
/* 1489 */     ImGuiPlatformIO platformIO = ImGui.getPlatformIO();
/*      */ 
/*      */     
/* 1492 */     platformIO.setPlatformCreateWindow(new CreateWindowFunction());
/* 1493 */     platformIO.setPlatformDestroyWindow(new DestroyWindowFunction());
/* 1494 */     platformIO.setPlatformShowWindow(new ShowWindowFunction());
/* 1495 */     platformIO.setPlatformGetWindowPos(new GetWindowPosFunction());
/* 1496 */     platformIO.setPlatformSetWindowPos(new SetWindowPosFunction());
/* 1497 */     platformIO.setPlatformGetWindowSize(new GetWindowSizeFunction());
/* 1498 */     platformIO.setPlatformSetWindowSize(new SetWindowSizeFunction());
/* 1499 */     platformIO.setPlatformSetWindowTitle(new SetWindowTitleFunction());
/* 1500 */     platformIO.setPlatformSetWindowFocus(new SetWindowFocusFunction());
/* 1501 */     platformIO.setPlatformGetWindowFocus(new GetWindowFocusFunction());
/* 1502 */     platformIO.setPlatformGetWindowMinimized(new GetWindowMinimizedFunction());
/* 1503 */     platformIO.setPlatformSetWindowAlpha(new SetWindowAlphaFunction());
/* 1504 */     platformIO.setPlatformRenderWindow(new RenderWindowFunction());
/* 1505 */     platformIO.setPlatformSwapBuffers(new SwapBuffersFunction());
/*      */ 
/*      */ 
/*      */     
/* 1509 */     ImGuiViewport mainViewport = ImGui.getMainViewport();
/* 1510 */     ViewportData vd = new ViewportData();
/* 1511 */     vd.window = this.data.window;
/* 1512 */     vd.windowOwned = false;
/* 1513 */     mainViewport.setPlatformUserData(vd);
/* 1514 */     mainViewport.setPlatformHandle(this.data.window);
/*      */   }
/*      */   
/*      */   protected void shutdownPlatformInterface() {
/* 1518 */     ImGui.destroyPlatformWindows();
/*      */   }
/*      */   
/*      */   @FunctionalInterface
/*      */   private static interface MapAnalog {
/*      */     void run(int param1Int1, int param1Int2, int param1Int3, float param1Float1, float param1Float2);
/*      */   }
/*      */   
/*      */   @FunctionalInterface
/*      */   private static interface MapButton {
/*      */     void run(int param1Int1, int param1Int2, int param1Int3);
/*      */   }
/*      */ }


/* Location:              C:\Users\rapha\Downloads\aurora.jar!\META-INF\jars\imgui-java-lwjgl3-1.90.0.jar!\imgui\glfw\ImGuiImplGlfw.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */