/*     */ package imgui.gl3;
/*     */ 
/*     */ import imgui.ImDrawData;
/*     */ import imgui.ImFontAtlas;
/*     */ import imgui.ImGui;
/*     */ import imgui.ImGuiIO;
/*     */ import imgui.ImGuiViewport;
/*     */ import imgui.ImVec4;
/*     */ import imgui.callback.ImPlatformFuncViewport;
/*     */ import imgui.type.ImInt;
/*     */ import java.nio.ByteBuffer;
/*     */ import java.util.regex.Matcher;
/*     */ import java.util.regex.Pattern;
/*     */ import org.lwjgl.opengl.GL;
/*     */ import org.lwjgl.opengl.GL20;
/*     */ import org.lwjgl.opengl.GL32;
/*     */ import org.lwjgl.opengl.GL33;
/*     */ import org.lwjgl.opengl.GLCapabilities;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ImGuiImplGl3
/*     */ {
/* 149 */   protected static final String OS = System.getProperty("os.name", "generic").toLowerCase();
/* 150 */   protected static final boolean IS_APPLE = (OS.contains("mac") || OS.contains("darwin"));
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected static class Data
/*     */   {
/* 157 */     protected int glVersion = 0;
/*     */     
/*     */     protected boolean glProfileIsCompat;
/*     */     
/*     */     protected int glProfileMask;
/* 162 */     protected GLCapabilities glCapabilities = null;
/* 163 */     protected String glslVersion = "";
/* 164 */     protected int fontTexture = 0;
/* 165 */     protected int shaderHandle = 0;
/* 166 */     protected int attribLocationTex = 0;
/* 167 */     protected int attribLocationProjMtx = 0;
/* 168 */     protected int attribLocationVtxPos = 0;
/* 169 */     protected int attribLocationVtxUV = 0;
/* 170 */     protected int attribLocationVtxColor = 0;
/* 171 */     protected int vboHandle = 0;
/* 172 */     protected int elementsHandle = 0;
/*     */ 
/*     */     
/*     */     protected boolean hasClipOrigin;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private static final class Properties
/*     */   {
/*     */     private Properties() {}
/*     */ 
/*     */     
/* 185 */     private final ImVec4 clipRect = new ImVec4();
/* 186 */     private final float[] orthoProjMatrix = new float[16];
/* 187 */     private final int[] lastActiveTexture = new int[1];
/* 188 */     private final int[] lastProgram = new int[1];
/* 189 */     private final int[] lastTexture = new int[1];
/* 190 */     private final int[] lastSampler = new int[1];
/* 191 */     private final int[] lastArrayBuffer = new int[1];
/* 192 */     private final int[] lastVertexArrayObject = new int[1];
/* 193 */     private final int[] lastPolygonMode = new int[2];
/* 194 */     private final int[] lastViewport = new int[4];
/* 195 */     private final int[] lastScissorBox = new int[4];
/* 196 */     private final int[] lastBlendSrcRgb = new int[1];
/* 197 */     private final int[] lastBlendDstRgb = new int[1];
/* 198 */     private final int[] lastBlendSrcAlpha = new int[1];
/* 199 */     private final int[] lastBlendDstAlpha = new int[1];
/* 200 */     private final int[] lastBlendEquationRgb = new int[1];
/* 201 */     private final int[] lastBlendEquationAlpha = new int[1];
/*     */     private boolean lastEnableBlend = false;
/*     */     private boolean lastEnableCullFace = false;
/*     */     private boolean lastEnableDepthTest = false;
/*     */     private boolean lastEnableStencilTest = false;
/*     */     private boolean lastEnableScissorTest = false;
/*     */     private boolean lastEnablePrimitiveRestart = false;
/*     */   }
/*     */   
/* 210 */   protected Data data = null;
/* 211 */   private final Properties props = new Properties();
/*     */   
/*     */   protected Data newData() {
/* 214 */     return new Data();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean init() {
/* 227 */     return init(null);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean init(String glslVersion) {
/* 260 */     this.data = newData();
/*     */     
/* 262 */     ImGuiIO io = ImGui.getIO();
/* 263 */     io.setBackendRendererName("imgui-java_impl_opengl3");
/*     */ 
/*     */     
/* 266 */     String glVersion = GL32.glGetString(7938);
/* 267 */     int major = GL32.glGetInteger(33307);
/* 268 */     int minor = GL32.glGetInteger(33308);
/* 269 */     if (major == 0 && minor == 0)
/*     */     {
/* 271 */       if (glVersion != null) {
/* 272 */         String[] glVersions = glVersion.split("\\.");
/* 273 */         major = Integer.parseInt(glVersions[0]);
/* 274 */         minor = Integer.parseInt(glVersions[1]);
/*     */       } 
/*     */     }
/* 277 */     this.data.glVersion = major * 100 + minor * 10;
/* 278 */     this.data.glProfileMask = GL32.glGetInteger(37158);
/* 279 */     this.data.glProfileIsCompat = ((this.data.glProfileMask & 0x2) != 0);
/* 280 */     if (this.data.glVersion < 330) {
/*     */       try {
/* 282 */         this.data.glCapabilities = GL.getCapabilities();
/* 283 */       } catch (IllegalStateException illegalStateException) {}
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 292 */     if (this.data.glVersion >= 320) {
/* 293 */       io.addBackendFlags(8);
/*     */     }
/*     */ 
/*     */     
/* 297 */     io.addBackendFlags(4096);
/*     */     
/* 299 */     if (glslVersion == null) {
/* 300 */       if (IS_APPLE) {
/* 301 */         this.data.glslVersion = "#version 150";
/*     */       } else {
/* 303 */         this.data.glslVersion = "#version 130";
/*     */       } 
/*     */     } else {
/* 306 */       this.data.glslVersion = glslVersion;
/*     */     } 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 312 */     int[] currentTexture = new int[1];
/* 313 */     GL32.glGetIntegerv(32873, currentTexture);
/*     */ 
/*     */     
/* 316 */     this.data.hasClipOrigin = (this.data.glVersion >= 450);
/*     */ 
/*     */     
/* 319 */     if (ImGui.getIO().hasConfigFlags(1024)) {
/* 320 */       initPlatformInterface();
/*     */     }
/*     */     
/* 323 */     return true;
/*     */   }
/*     */   
/*     */   public void shutdown() {
/* 327 */     ImGuiIO io = ImGui.getIO();
/*     */     
/* 329 */     shutdownPlatformInterface();
/* 330 */     destroyDeviceObjects();
/*     */     
/* 332 */     io.setBackendRendererName(null);
/* 333 */     io.removeBackendFlags(4104);
/* 334 */     this.data = null;
/*     */   }
/*     */   
/*     */   public void newFrame() {
/* 338 */     if (this.data.shaderHandle == 0) {
/* 339 */       createDeviceObjects();
/*     */     }
/* 341 */     if (this.data.fontTexture == 0) {
/* 342 */       createFontsTexture();
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   protected void setupRenderState(ImDrawData drawData, int fbWidth, int fbHeight, int gVertexArrayObject) {
/* 348 */     GL32.glEnable(3042);
/* 349 */     GL32.glBlendEquation(32774);
/* 350 */     GL32.glBlendFuncSeparate(770, 771, 1, 771);
/* 351 */     GL32.glDisable(2884);
/* 352 */     GL32.glDisable(2929);
/* 353 */     GL32.glDisable(2960);
/* 354 */     GL32.glEnable(3089);
/*     */     
/* 356 */     if (this.data.glVersion >= 310) {
/* 357 */       GL32.glDisable(36765);
/*     */     }
/* 359 */     if (this.data.glVersion >= 200) {
/* 360 */       GL32.glPolygonMode(1032, 6914);
/*     */     }
/*     */ 
/*     */     
/* 364 */     boolean clipOriginLowerLeft = true;
/* 365 */     if (this.data.hasClipOrigin) {
/* 366 */       int[] currentClipOrigin = new int[1];
/* 367 */       GL32.glGetIntegerv(37724, currentClipOrigin);
/* 368 */       if (currentClipOrigin[0] == 36002) {
/* 369 */         clipOriginLowerLeft = false;
/*     */       }
/*     */     } 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 376 */     GL32.glViewport(0, 0, fbWidth, fbHeight);
/* 377 */     float L = drawData.getDisplayPosX();
/* 378 */     float R = drawData.getDisplayPosX() + drawData.getDisplaySizeX();
/* 379 */     float T = drawData.getDisplayPosY();
/* 380 */     float B = drawData.getDisplayPosY() + drawData.getDisplaySizeY();
/*     */ 
/*     */     
/* 383 */     if (this.data.hasClipOrigin && !clipOriginLowerLeft) {
/* 384 */       float tmp = T;
/* 385 */       T = B;
/* 386 */       B = tmp;
/*     */     } 
/*     */     
/* 389 */     this.props.orthoProjMatrix[0] = 2.0F / (R - L);
/* 390 */     this.props.orthoProjMatrix[5] = 2.0F / (T - B);
/* 391 */     this.props.orthoProjMatrix[10] = -1.0F;
/* 392 */     this.props.orthoProjMatrix[12] = (R + L) / (L - R);
/* 393 */     this.props.orthoProjMatrix[13] = (T + B) / (B - T);
/* 394 */     this.props.orthoProjMatrix[15] = 1.0F;
/*     */     
/* 396 */     GL32.glUseProgram(this.data.shaderHandle);
/* 397 */     GL32.glUniform1i(this.data.attribLocationTex, 0);
/* 398 */     GL32.glUniformMatrix4fv(this.data.attribLocationProjMtx, false, this.props.orthoProjMatrix);
/*     */     
/* 400 */     if (this.data.glVersion >= 330 || (this.data.glCapabilities != null && this.data.glCapabilities.GL_ARB_sampler_objects)) {
/* 401 */       GL33.glBindSampler(0, 0);
/*     */     }
/*     */     
/* 404 */     GL32.glBindVertexArray(gVertexArrayObject);
/*     */ 
/*     */     
/* 407 */     GL32.glBindBuffer(34962, this.data.vboHandle);
/* 408 */     GL32.glBindBuffer(34963, this.data.elementsHandle);
/* 409 */     GL32.glEnableVertexAttribArray(this.data.attribLocationVtxPos);
/* 410 */     GL32.glEnableVertexAttribArray(this.data.attribLocationVtxUV);
/* 411 */     GL32.glEnableVertexAttribArray(this.data.attribLocationVtxColor);
/* 412 */     GL32.glVertexAttribPointer(this.data.attribLocationVtxPos, 2, 5126, false, ImDrawData.sizeOfImDrawVert(), 0L);
/* 413 */     GL32.glVertexAttribPointer(this.data.attribLocationVtxUV, 2, 5126, false, ImDrawData.sizeOfImDrawVert(), 8L);
/* 414 */     GL32.glVertexAttribPointer(this.data.attribLocationVtxColor, 4, 5121, true, ImDrawData.sizeOfImDrawVert(), 16L);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void renderDrawData(ImDrawData drawData) {
/* 426 */     int fbWidth = (int)(drawData.getDisplaySizeX() * drawData.getFramebufferScaleX());
/* 427 */     int fbHeight = (int)(drawData.getDisplaySizeY() * drawData.getFramebufferScaleY());
/* 428 */     if (fbWidth <= 0 || fbHeight <= 0) {
/*     */       return;
/*     */     }
/*     */     
/* 432 */     if (drawData.getCmdListsCount() <= 0) {
/*     */       return;
/*     */     }
/*     */     
/* 436 */     GL32.glGetIntegerv(34016, this.props.lastActiveTexture);
/* 437 */     GL32.glActiveTexture(33984);
/* 438 */     GL32.glGetIntegerv(35725, this.props.lastProgram);
/* 439 */     GL32.glGetIntegerv(32873, this.props.lastTexture);
/* 440 */     if (this.data.glVersion >= 330 || (this.data.glCapabilities != null && this.data.glCapabilities.GL_ARB_sampler_objects)) {
/* 441 */       GL32.glGetIntegerv(35097, this.props.lastSampler);
/*     */     }
/* 443 */     GL32.glGetIntegerv(34964, this.props.lastArrayBuffer);
/* 444 */     GL32.glGetIntegerv(34229, this.props.lastVertexArrayObject);
/* 445 */     if (this.data.glVersion >= 200) {
/* 446 */       GL32.glGetIntegerv(2880, this.props.lastPolygonMode);
/*     */     }
/* 448 */     GL32.glGetIntegerv(2978, this.props.lastViewport);
/* 449 */     GL32.glGetIntegerv(3088, this.props.lastScissorBox);
/* 450 */     GL32.glGetIntegerv(32969, this.props.lastBlendSrcRgb);
/* 451 */     GL32.glGetIntegerv(32968, this.props.lastBlendDstRgb);
/* 452 */     GL32.glGetIntegerv(32971, this.props.lastBlendSrcAlpha);
/* 453 */     GL32.glGetIntegerv(32970, this.props.lastBlendDstAlpha);
/* 454 */     GL32.glGetIntegerv(32777, this.props.lastBlendEquationRgb);
/* 455 */     GL32.glGetIntegerv(34877, this.props.lastBlendEquationAlpha);
/* 456 */     this.props.lastEnableBlend = GL32.glIsEnabled(3042);
/* 457 */     this.props.lastEnableCullFace = GL32.glIsEnabled(2884);
/* 458 */     this.props.lastEnableDepthTest = GL32.glIsEnabled(2929);
/* 459 */     this.props.lastEnableStencilTest = GL32.glIsEnabled(2960);
/* 460 */     this.props.lastEnableScissorTest = GL32.glIsEnabled(3089);
/* 461 */     if (this.data.glVersion >= 310) {
/* 462 */       this.props.lastEnablePrimitiveRestart = GL32.glIsEnabled(36765);
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 468 */     int vertexArrayObject = GL32.glGenVertexArrays();
/* 469 */     setupRenderState(drawData, fbWidth, fbHeight, vertexArrayObject);
/*     */ 
/*     */     
/* 472 */     float clipOffX = drawData.getDisplayPosX();
/* 473 */     float clipOffY = drawData.getDisplayPosY();
/* 474 */     float clipScaleX = drawData.getFramebufferScaleX();
/* 475 */     float clipScaleY = drawData.getFramebufferScaleY();
/*     */ 
/*     */     
/* 478 */     for (int n = 0; n < drawData.getCmdListsCount(); n++) {
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 495 */       GL32.glBufferData(34962, drawData.getCmdListVtxBufferData(n), 35040);
/* 496 */       GL32.glBufferData(34963, drawData.getCmdListIdxBufferData(n), 35040);
/*     */       
/* 498 */       for (int cmdIdx = 0; cmdIdx < drawData.getCmdListCmdBufferSize(n); cmdIdx++) {
/*     */ 
/*     */ 
/*     */ 
/*     */         
/* 503 */         drawData.getCmdListCmdBufferClipRect(this.props.clipRect, n, cmdIdx);
/*     */         
/* 505 */         float clipMinX = (this.props.clipRect.x - clipOffX) * clipScaleX;
/* 506 */         float clipMinY = (this.props.clipRect.y - clipOffY) * clipScaleY;
/* 507 */         float clipMaxX = (this.props.clipRect.z - clipOffX) * clipScaleX;
/* 508 */         float clipMaxY = (this.props.clipRect.w - clipOffY) * clipScaleY;
/*     */         
/* 510 */         if (clipMaxX > clipMinX && clipMaxY > clipMinY) {
/*     */ 
/*     */ 
/*     */ 
/*     */           
/* 515 */           GL32.glScissor((int)clipMinX, (int)(fbHeight - clipMaxY), (int)(clipMaxX - clipMinX), (int)(clipMaxY - clipMinY));
/*     */ 
/*     */           
/* 518 */           long textureId = drawData.getCmdListCmdBufferTextureId(n, cmdIdx);
/* 519 */           int elemCount = drawData.getCmdListCmdBufferElemCount(n, cmdIdx);
/* 520 */           int idxOffset = drawData.getCmdListCmdBufferIdxOffset(n, cmdIdx);
/* 521 */           int vtxOffset = drawData.getCmdListCmdBufferVtxOffset(n, cmdIdx);
/* 522 */           long indices = idxOffset * ImDrawData.sizeOfImDrawIdx();
/* 523 */           int type = (ImDrawData.sizeOfImDrawIdx() == 2) ? 5123 : 5125;
/*     */           
/* 525 */           GL32.glBindTexture(3553, (int)textureId);
/*     */           
/* 527 */           if (this.data.glVersion >= 320) {
/* 528 */             GL32.glDrawElementsBaseVertex(4, elemCount, type, indices, vtxOffset);
/*     */           } else {
/* 530 */             GL32.glDrawElements(4, elemCount, type, indices);
/*     */           } 
/*     */         } 
/*     */       } 
/*     */     } 
/*     */     
/* 536 */     GL32.glDeleteVertexArrays(vertexArrayObject);
/*     */ 
/*     */ 
/*     */     
/* 540 */     if (this.props.lastProgram[0] == 0 || GL32.glIsProgram(this.props.lastProgram[0])) {
/* 541 */       GL32.glUseProgram(this.props.lastProgram[0]);
/*     */     }
/* 543 */     GL32.glBindTexture(3553, this.props.lastTexture[0]);
/* 544 */     if (this.data.glVersion >= 330 || (this.data.glCapabilities != null && this.data.glCapabilities.GL_ARB_sampler_objects)) {
/* 545 */       GL33.glBindSampler(0, this.props.lastSampler[0]);
/*     */     }
/* 547 */     GL32.glActiveTexture(this.props.lastActiveTexture[0]);
/* 548 */     GL32.glBindVertexArray(this.props.lastVertexArrayObject[0]);
/* 549 */     GL32.glBindBuffer(34962, this.props.lastArrayBuffer[0]);
/* 550 */     GL32.glBlendEquationSeparate(this.props.lastBlendEquationRgb[0], this.props.lastBlendEquationAlpha[0]);
/* 551 */     GL32.glBlendFuncSeparate(this.props.lastBlendSrcRgb[0], this.props.lastBlendDstRgb[0], this.props.lastBlendSrcAlpha[0], this.props.lastBlendDstAlpha[0]);
/* 552 */     if (this.props.lastEnableBlend) { GL32.glEnable(3042); }
/* 553 */     else { GL32.glDisable(3042); }
/* 554 */      if (this.props.lastEnableCullFace) { GL32.glEnable(2884); }
/* 555 */     else { GL32.glDisable(2884); }
/* 556 */      if (this.props.lastEnableDepthTest) { GL32.glEnable(2929); }
/* 557 */     else { GL32.glDisable(2929); }
/* 558 */      if (this.props.lastEnableStencilTest) { GL32.glEnable(2960); }
/* 559 */     else { GL32.glDisable(2960); }
/* 560 */      if (this.props.lastEnableScissorTest) { GL32.glEnable(3089); }
/* 561 */     else { GL32.glDisable(3089); }
/* 562 */      if (this.data.glVersion >= 310) {
/* 563 */       if (this.props.lastEnablePrimitiveRestart) {
/* 564 */         GL32.glEnable(36765);
/*     */       } else {
/* 566 */         GL32.glDisable(36765);
/*     */       } 
/*     */     }
/* 569 */     if (this.data.glVersion <= 310 || this.data.glProfileIsCompat) {
/* 570 */       GL32.glPolygonMode(1028, this.props.lastPolygonMode[0]);
/* 571 */       GL32.glPolygonMode(1029, this.props.lastPolygonMode[1]);
/*     */     } else {
/* 573 */       GL32.glPolygonMode(1032, this.props.lastPolygonMode[0]);
/*     */     } 
/* 575 */     GL32.glViewport(this.props.lastViewport[0], this.props.lastViewport[1], this.props.lastViewport[2], this.props.lastViewport[3]);
/* 576 */     GL32.glScissor(this.props.lastScissorBox[0], this.props.lastScissorBox[1], this.props.lastScissorBox[2], this.props.lastScissorBox[3]);
/*     */   }
/*     */   
/*     */   public boolean createFontsTexture() {
/* 580 */     ImFontAtlas fontAtlas = ImGui.getIO().getFonts();
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 585 */     ImInt width = new ImInt();
/* 586 */     ImInt height = new ImInt();
/* 587 */     ByteBuffer pixels = fontAtlas.getTexDataAsRGBA32(width, height);
/*     */     
/* 589 */     int[] lastTexture = new int[1];
/* 590 */     GL32.glGetIntegerv(32873, lastTexture);
/* 591 */     this.data.fontTexture = GL32.glGenTextures();
/* 592 */     GL32.glBindTexture(3553, this.data.fontTexture);
/* 593 */     GL32.glTexParameteri(3553, 10241, 9729);
/* 594 */     GL32.glTexParameteri(3553, 10240, 9729);
/* 595 */     GL32.glPixelStorei(3317, 4);
/* 596 */     GL32.glPixelStorei(3316, 0);
/* 597 */     GL32.glPixelStorei(3315, 0);
/* 598 */     GL32.glPixelStorei(3314, 0);
/* 599 */     GL32.glTexImage2D(3553, 0, 6408, width.get(), height.get(), 0, 6408, 5121, pixels);
/*     */ 
/*     */     
/* 602 */     fontAtlas.setTexID(this.data.fontTexture);
/*     */     
/* 604 */     GL32.glBindTexture(3553, lastTexture[0]);
/*     */     
/* 606 */     return true;
/*     */   }
/*     */   
/*     */   public void destroyFontsTexture() {
/* 610 */     ImGuiIO io = ImGui.getIO();
/* 611 */     if (this.data.fontTexture != 0) {
/* 612 */       GL32.glDeleteTextures(this.data.fontTexture);
/* 613 */       io.getFonts().setTexID(0L);
/* 614 */       this.data.fontTexture = 0;
/*     */     } 
/*     */   }
/*     */   
/*     */   protected boolean checkShader(int handle, String desc) {
/* 619 */     int[] status = new int[1];
/* 620 */     int[] logLength = new int[1];
/* 621 */     GL32.glGetShaderiv(handle, 35713, status);
/* 622 */     GL32.glGetShaderiv(handle, 35716, logLength);
/* 623 */     if (status[0] == 0) {
/* 624 */       System.err.printf("%s: failed to compile %s! With GLSL: %s\n", new Object[] { this, desc, this.data.glslVersion });
/*     */     }
/* 626 */     if (logLength[0] > 1) {
/* 627 */       String log = GL32.glGetShaderInfoLog(handle);
/* 628 */       System.err.println(log);
/*     */     } 
/* 630 */     return (status[0] == 1);
/*     */   }
/*     */   
/*     */   protected boolean checkProgram(int handle, String desc) {
/* 634 */     int[] status = new int[1];
/* 635 */     int[] logLength = new int[1];
/* 636 */     GL20.glGetProgramiv(handle, 35714, status);
/* 637 */     GL20.glGetProgramiv(handle, 35716, logLength);
/* 638 */     if (status[0] == 0) {
/* 639 */       System.err.printf("%s: failed to link %s! With GLSL: %s\n", new Object[] { this, desc, this.data.glslVersion });
/*     */     }
/* 641 */     if (logLength[0] > 1) {
/* 642 */       String log = GL32.glGetProgramInfoLog(handle);
/* 643 */       System.err.println(log);
/*     */     } 
/* 645 */     return (status[0] == 1);
/*     */   }
/*     */   
/*     */   protected int parseGlslVersionString(String glslVersion) {
/* 649 */     Pattern p = Pattern.compile("\\d+");
/* 650 */     Matcher m = p.matcher(glslVersion);
/*     */     
/* 652 */     if (m.find()) {
/* 653 */       return Integer.parseInt(m.group());
/*     */     }
/*     */     
/* 656 */     return 130;
/*     */   }
/*     */   
/*     */   protected boolean createDeviceObjects() {
/*     */     CharSequence vertexShader, fragmentShader;
/* 661 */     int[] lastTexture = new int[1];
/* 662 */     int[] lastArrayBuffer = new int[1];
/* 663 */     int[] lastVertexArray = new int[1];
/* 664 */     GL32.glGetIntegerv(32873, lastTexture);
/* 665 */     GL32.glGetIntegerv(34964, lastArrayBuffer);
/* 666 */     GL32.glGetIntegerv(34229, lastVertexArray);
/*     */     
/* 668 */     int glslVersionValue = parseGlslVersionString(this.data.glslVersion);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 674 */     if (glslVersionValue < 130) {
/* 675 */       vertexShader = vertexShaderGlsl120();
/* 676 */       fragmentShader = fragmentShaderGlsl120();
/* 677 */     } else if (glslVersionValue >= 410) {
/* 678 */       vertexShader = vertexShaderGlsl410Core();
/* 679 */       fragmentShader = fragmentShaderGlsl410Core();
/* 680 */     } else if (glslVersionValue == 300) {
/* 681 */       vertexShader = vertexShaderGlsl300es();
/* 682 */       fragmentShader = fragmentShaderGlsl300es();
/*     */     } else {
/* 684 */       vertexShader = vertexShaderGlsl130();
/* 685 */       fragmentShader = fragmentShaderGlsl130();
/*     */     } 
/*     */ 
/*     */     
/* 689 */     int vertHandle = GL32.glCreateShader(35633);
/* 690 */     GL32.glShaderSource(vertHandle, vertexShader);
/* 691 */     GL32.glCompileShader(vertHandle);
/* 692 */     checkShader(vertHandle, "vertex shader");
/*     */     
/* 694 */     int fragHandle = GL32.glCreateShader(35632);
/* 695 */     GL32.glShaderSource(fragHandle, fragmentShader);
/* 696 */     GL32.glCompileShader(fragHandle);
/* 697 */     checkShader(fragHandle, "fragment shader");
/*     */ 
/*     */     
/* 700 */     this.data.shaderHandle = GL32.glCreateProgram();
/* 701 */     GL32.glAttachShader(this.data.shaderHandle, vertHandle);
/* 702 */     GL32.glAttachShader(this.data.shaderHandle, fragHandle);
/* 703 */     GL32.glLinkProgram(this.data.shaderHandle);
/* 704 */     checkProgram(this.data.shaderHandle, "shader program");
/*     */     
/* 706 */     GL20.glDetachShader(this.data.shaderHandle, vertHandle);
/* 707 */     GL20.glDetachShader(this.data.shaderHandle, fragHandle);
/* 708 */     GL20.glDeleteShader(vertHandle);
/* 709 */     GL20.glDeleteShader(fragHandle);
/*     */     
/* 711 */     this.data.attribLocationTex = GL20.glGetUniformLocation(this.data.shaderHandle, "Texture");
/* 712 */     this.data.attribLocationProjMtx = GL20.glGetUniformLocation(this.data.shaderHandle, "ProjMtx");
/* 713 */     this.data.attribLocationVtxPos = GL20.glGetAttribLocation(this.data.shaderHandle, "Position");
/* 714 */     this.data.attribLocationVtxUV = GL20.glGetAttribLocation(this.data.shaderHandle, "UV");
/* 715 */     this.data.attribLocationVtxColor = GL20.glGetAttribLocation(this.data.shaderHandle, "Color");
/*     */ 
/*     */     
/* 718 */     this.data.vboHandle = GL32.glGenBuffers();
/* 719 */     this.data.elementsHandle = GL32.glGenBuffers();
/*     */     
/* 721 */     createFontsTexture();
/*     */ 
/*     */     
/* 724 */     GL32.glBindTexture(3553, lastTexture[0]);
/* 725 */     GL32.glBindBuffer(34962, lastArrayBuffer[0]);
/* 726 */     GL32.glBindVertexArray(lastVertexArray[0]);
/*     */     
/* 728 */     return true;
/*     */   }
/*     */   
/*     */   public void destroyDeviceObjects() {
/* 732 */     if (this.data.vboHandle != 0) {
/* 733 */       GL32.glDeleteBuffers(this.data.vboHandle);
/* 734 */       this.data.vboHandle = 0;
/*     */     } 
/* 736 */     if (this.data.elementsHandle != 0) {
/* 737 */       GL32.glDeleteBuffers(this.data.elementsHandle);
/* 738 */       this.data.elementsHandle = 0;
/*     */     } 
/* 740 */     if (this.data.shaderHandle != 0) {
/* 741 */       GL32.glDeleteProgram(this.data.shaderHandle);
/* 742 */       this.data.shaderHandle = 0;
/*     */     } 
/* 744 */     destroyFontsTexture();
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private final class RendererRenderWindowFunction
/*     */     extends ImPlatformFuncViewport
/*     */   {
/*     */     private RendererRenderWindowFunction() {}
/*     */ 
/*     */     
/*     */     public void accept(ImGuiViewport vp) {
/* 756 */       if (!vp.hasFlags(256)) {
/* 757 */         GL32.glClearColor(0.0F, 0.0F, 0.0F, 0.0F);
/* 758 */         GL32.glClear(16384);
/*     */       } 
/* 760 */       ImGuiImplGl3.this.renderDrawData(vp.getDrawData());
/*     */     }
/*     */   }
/*     */   
/*     */   protected void initPlatformInterface() {
/* 765 */     ImGui.getPlatformIO().setRendererRenderWindow(new RendererRenderWindowFunction());
/*     */   }
/*     */   
/*     */   protected void shutdownPlatformInterface() {
/* 769 */     ImGui.destroyPlatformWindows();
/*     */   }
/*     */   
/*     */   protected String vertexShaderGlsl120() {
/* 773 */     return this.data.glslVersion + "\nuniform mat4 ProjMtx;\nattribute vec2 Position;\nattribute vec2 UV;\nattribute vec4 Color;\nvarying vec2 Frag_UV;\nvarying vec4 Frag_Color;\nvoid main()\n{\n    Frag_UV = UV;\n    Frag_Color = Color;\n    gl_Position = ProjMtx * vec4(Position.xy,0,1);\n}\n";
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected String vertexShaderGlsl130() {
/* 789 */     return this.data.glslVersion + "\nuniform mat4 ProjMtx;\nin vec2 Position;\nin vec2 UV;\nin vec4 Color;\nout vec2 Frag_UV;\nout vec4 Frag_Color;\nvoid main()\n{\n    Frag_UV = UV;\n    Frag_Color = Color;\n    gl_Position = ProjMtx * vec4(Position.xy,0,1);\n}\n";
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private String vertexShaderGlsl300es() {
/* 805 */     return this.data.glslVersion + "\nprecision highp float;\nlayout (location = 0) in vec2 Position;\nlayout (location = 1) in vec2 UV;\nlayout (location = 2) in vec4 Color;\nuniform mat4 ProjMtx;\nout vec2 Frag_UV;\nout vec4 Frag_Color;\nvoid main()\n{\n    Frag_UV = UV;\n    Frag_Color = Color;\n    gl_Position = ProjMtx * vec4(Position.xy,0,1);\n}\n";
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected String vertexShaderGlsl410Core() {
/* 822 */     return this.data.glslVersion + "\nlayout (location = 0) in vec2 Position;\nlayout (location = 1) in vec2 UV;\nlayout (location = 2) in vec4 Color;\nuniform mat4 ProjMtx;\nout vec2 Frag_UV;\nout vec4 Frag_Color;\nvoid main()\n{\n    Frag_UV = UV;\n    Frag_Color = Color;\n    gl_Position = ProjMtx * vec4(Position.xy,0,1);\n}\n";
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected String fragmentShaderGlsl120() {
/* 838 */     return this.data.glslVersion + "\n#ifdef GL_ES\n    precision mediump float;\n#endif\nuniform sampler2D Texture;\nvarying vec2 Frag_UV;\nvarying vec4 Frag_Color;\nvoid main()\n{\n    gl_FragColor = Frag_Color * texture2D(Texture, Frag_UV.st);\n}\n";
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected String fragmentShaderGlsl130() {
/* 852 */     return this.data.glslVersion + "\nuniform sampler2D Texture;\nin vec2 Frag_UV;\nin vec4 Frag_Color;\nout vec4 Out_Color;\nvoid main()\n{\n    Out_Color = Frag_Color * texture(Texture, Frag_UV.st);\n}\n";
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected String fragmentShaderGlsl300es() {
/* 864 */     return this.data.glslVersion + "\nprecision mediump float;\nuniform sampler2D Texture;\nin vec2 Frag_UV;\nin vec4 Frag_Color;\nlayout (location = 0) out vec4 Out_Color;\nvoid main()\n{\n    Out_Color = Frag_Color * texture(Texture, Frag_UV.st);\n}\n";
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected String fragmentShaderGlsl410Core() {
/* 877 */     return this.data.glslVersion + "\nin vec2 Frag_UV;\nin vec4 Frag_Color;\nuniform sampler2D Texture;\nlayout (location = 0) out vec4 Out_Color;\nvoid main()\n{\n    Out_Color = Frag_Color * texture(Texture, Frag_UV.st);\n}\n";
/*     */   }
/*     */ }


/* Location:              C:\Users\rapha\Downloads\aurora.jar!\META-INF\jars\imgui-java-lwjgl3-1.90.0.jar!\imgui\gl3\ImGuiImplGl3.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */